import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVH1FK   = "v5.5.0"
VV0a2r    = "26-06-2022"
EASY_MODE    = 0
VVkZjF   = 0
VVqV29   = 0
VVDwGq  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVuZTi  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVIlHj    = "/media/usb/"
VVEF2M    = "/usr/share/enigma2/picon/"
VVLwHd = "/etc/enigma2/blacklist"
VVR2Ml   = "/etc/enigma2/"
VVkD8W  = "ajpanel_update_url"
VVJV84   = "AJPan"
VVmyfR  = "AUTO FIND"
VVbioR  = "Custom"
VVRy6N    = ""
VVUA23    = "Regular"
VVsYfD      = "-" * 80
VVImCt    = ("-" * 100, )
VV7k9C    = ""
VVPbWU   = " && echo 'Successful' || echo 'Failed!'"
VV1WRP    = []
VVBIfo  = "Cannot continue (No Enough Memory) !"
VVIGxe  = False
VVFrOP  = False
VVkw26 = False
VVavIl     = 0
VVtpeW    = 1
VV3A9p    = 2
VVEcC3   = 3
VVy8KX    = 4
VVRLnl    = 5
VVAK4W = 6
VV8biG = 7
VVzhs8  = 8
VV15d1   = 9
VVysq6   = 10
VVEZH2   = 11
VVZvOF  = 12
VVoGN2  = 13
VV377I    = 14
VVu0m7   = 15
VVtQs4   = 16
VV40Wa    = 17
WINDOW_SUBTITLE    = 18
VVpEAW  = 19
VVOM7o   = 0
VVXjVQ   = 1
VVhZGE   = 2
def FFHGPv():
 fList = None
 try:
  from enigma import getFontFaces
  return set(getFontFaces())
 except:
  try:
   from skin import getFontFaces
   return set(getFontFaces())
  except:
   pass
 return [VVUA23]
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices=[ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.forceUtf8Encoding   = ConfigYesNo(default=True)
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVmyfR, visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.PIconsPath     = ConfigDirectory(default=VVEF2M, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVIlHj, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
tmp = [("srt", "From SRT File"), ("#FFFFFF", "White"), ("#C0C0C0", "Silver"), ("#808080", "Gray"), ("#000000", "Black"), ("#FF0000", "Red"), ("#800000", "Maroon"), ("#FFFF00", "Yellow"), ("#808000", "Olive"), ("#00FF00", "Lime"), ("#008000", "Green"), ("#00FFFF", "Aqua"), ("#008080", "Teal"), ("#0000FF", "Blue"), ("#000080", "Navy"), ("#FF00FF", "Fuchsia"), ("#800080", "Purple")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-300, max=300, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="srt", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVUA23, choices=[ (x,  x) for x in FFHGPv() ])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[ ("0", "Left"), ("1", "Center"), ("2", "Right") ])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=0, stepwidth=10, min=-140, max=140, wraparound=False)
del tmp
def FFVimY():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVCY7o  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVfLn6 = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVCY7o  : return 0
  elif VVfLn6 : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVNyZj = FFVimY()
VVPBk2 = VVkO2P = VV0wBB = VVyU04 = VVX67O = VV5GFt = VV9pCx = VV8mIi = COLOR_CONS_BRIGHT_YELLOW = VVumHI = VVqImC = VVPgsh = VVmG5f = ""
def FFKTDA()  : FFMEyL(FFJZ39())
def FF23f0()  : FFMEyL(FFepel())
def FF9FWq(tDict): FFMEyL(iDumps(tDict, indent=4, sort_keys=True))
def FFx9kh(*args): FFXaFJ(True, False, *args)
def FFMEyL(*args) : FFXaFJ(True , True , *args)
def FFZiQo(*args): FFXaFJ(False, True , *args)
def FFXaFJ(addSep=True, oneLine=True, *args):
 if VVkZjF:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if oneLine:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  else:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item:
      txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFYuhR(txt, isAppend=True, ignoreErr=False):
 if VVkZjF:
  tm = FFC0DJ()
  err = ""
  if not ignoreErr:
   err = FFepel()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFMEyL(err)
  FFMEyL("Output Log File : %s" % fileName)
def FFepel():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFC0DJ()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFJZ39():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VV1WRP = []
def FF9Drq(win):
 global VV1WRP
 if not win in VV1WRP:
  VV1WRP.append(win)
def FF7VFz(*args):
 global VV1WRP
 for win in VV1WRP:
  try:
   win.close()
  except:
   pass
 VV1WRP = []
def FFEJp7():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VV45da = FFEJp7()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFEhph()     : return PluginDescriptor(fnc=FFB0wV, where=[PluginDescriptor.WHERE_SESSIONSTART] , needsRestart=True   , description="AJPanel Startup")
def FF1Ql4()      : return getDescriptor(FFlHMf   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFaUGA()       : return getDescriptor(FFLnqm  , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFJKUL()   : return getDescriptor(FFhGMV , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFOgnB(): return getDescriptor(FFJT2U , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player"  , descr="Signal Monitor / Player")
def FFCMe8()  : return getDescriptor(FFJlYB  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV"     , descr="IPTV Menu")
def FFCRIN()     : return getDescriptor(FFBXyo , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info."    , descr="Service Info")
def Plugins(**kwargs):
 result = [ FF1Ql4() , FFaUGA() , FFEhph() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFJKUL())
  result.append(FFOgnB())
  result.append(FFCMe8())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFCRIN())
 return result
def FFB0wV(reason, **kwargs):
 if reason == 0:
  FFtUOn()
  if "session" in kwargs:
   session = kwargs["session"]
   FFSQfK(session)
   CCWa9p(session)
  CCkHya.VVErfW()
def FFLnqm(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFlHMf, PLUGIN_NAME, 45)]
 else:
  return []
def FFlHMf(session, **kwargs):
 session.open(Main_Menu)
def FFhGMV(session, **kwargs):
 session.open(CCg2YR)
def FFJT2U(session, **kwargs):
 FFYJSt(session, isFromSession=True)
def FFJlYB(session, **kwargs):
 session.open(CCUfgv)
def FFBXyo(session, **kwargs):
 session.open(CCSQQx, fncMode=CCSQQx.VVBt5O)
def FFvVDz():
 FFscMJ(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFJKUL(), FFOgnB(), FFCMe8() ])
 FFscMJ(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFCRIN() ])
def FFscMJ(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VVvXbU = None
def FFtUOn():
 try:
  global VVvXbU
  if VVvXbU is None:
   VVvXbU    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFl4W5
  ChannelContextMenu.FF76Y4 = FF76Y4
 except:
  pass
def FFl4W5(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVvXbU(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , BF(SELF.FF76Y4, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , BF(SELF.FF76Y4, title1, csel, isFind=True))))
def FF76Y4(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFupyT(refCode)
 except:
  pass
 self.session.open(BF(CCKAMZ, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFSQfK(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = BF(FFFrCf, session, "lok")
 hk.actions['longCancel'] = BF(FFFrCf, session, "lesc")
 hk.actions['longRed']  = BF(FFFrCf, session, "lred")
def FFFrCf(session, key):
 if CFG.hotkey_signal.getValue() == key:
  session.open(CCVY8O, isFromExternal=True)
def FFRqJR(SELF, title="", addLabel=False, addScrollLabel=False, VVJtuN=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFvK43()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCvJ2g(SELF)
 if VVJtuN:
  SELF["myMenu"] = MenuList(VVJtuN)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVlQQ7        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFsWyR(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FF0gK4, SELF, "0") ,
  "1" : BF(FF0gK4, SELF, "1") ,
  "2" : BF(FF0gK4, SELF, "2") ,
  "3" : BF(FF0gK4, SELF, "3") ,
  "4" : BF(FF0gK4, SELF, "4") ,
  "5" : BF(FF0gK4, SELF, "5") ,
  "6" : BF(FF0gK4, SELF, "6") ,
  "7" : BF(FF0gK4, SELF, "7") ,
  "8" : BF(FF0gK4, SELF, "8") ,
  "9" : BF(FF0gK4, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFf2ui, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FF0gK4(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVmG5f:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVmG5f + SELF.keyPressed + VVkO2P)
    txt = VVkO2P + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFlDiQ(SELF, txt)
def FFf2ui(SELF, tableObj, colNum):
 FFlDiQ(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     SELF.VVRvKN(i)
     break
 except:
  pass
def FF3aN3(SELF, setMenuAction=True):
 if setMenuAction:
  global VV7k9C
  VV7k9C = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFvK43():
 return ("  %s" % VV7k9C)
def FFINW5(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFj0Hy(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFBQBk(color):
 return parseColor(color).argb()
def FFeqjP(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFLgZ9(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FF8q6B(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFugQf(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVmG5f)
 else:
  return ""
def FFnHBa(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVsYfD, word, VVsYfD, VVmG5f)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVsYfD, word, VVsYfD)
def FF0IFC(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVmG5f
def FFWnKF(color):
 if color: return "echo -e '%s' %s;" % (VVsYfD, FFugQf(VVsYfD, VV8mIi))
 else : return "echo -e '%s';" % VVsYfD
def FFvvVG(title, color):
 title = "%s\n%s\n%s\n" % (VVsYfD, title, VVsYfD)
 return FF0IFC(title, color)
def FF7a1g(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFapvt(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FF1Gz0(callBackFunction):
 tCons = CCbhqA()
 tCons.ePopen("echo", BF(FFo9tx, callBackFunction))
def FFo9tx(callBackFunction, result, retval):
 callBackFunction()
def FFItMF(SELF, fnc, title="Processing ...", clearMsg=True):
 FFlDiQ(SELF, title)
 tCons = CCbhqA()
 tCons.ePopen("echo", BF(FFJbUv, SELF, fnc, clearMsg))
def FFJbUv(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFlDiQ(SELF)
def FFJoh0(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVBIfo
  else       : return ""
def FFOAMF(cmd):
 txt = FFJoh0(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FF8oWX(cmd):
 lines = FFOAMF(cmd)
 if lines: return lines[0]
 else : return ""
def FFtRVe(SELF, cmd):
 lines = FFOAMF(cmd)
 VVMDmE = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVMDmE.append((key, val))
  elif line:
   VVMDmE.append((line, ""))
 if VVMDmE:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFBL02(SELF, None, header=header, VVdLtF=VVMDmE, VVGpzZ=widths, VVYOiV=28)
 else:
  FFsu1t(SELF, cmd)
def FFsu1t(    SELF, cmd, **kwargs): SELF.session.open(CCBqjg, VVU7IO=cmd, VVVhvb=True, VV0vZt=VVXjVQ, **kwargs)
def FFn50K(  SELF, cmd, **kwargs): SELF.session.open(CCBqjg, VVU7IO=cmd, **kwargs)
def FFGZGa(   SELF, cmd, **kwargs): SELF.session.open(CCBqjg, VVU7IO=cmd, VVY3Iu=True, VVSfhJ=True, VV0vZt=VVXjVQ, **kwargs)
def FF1gYG(  SELF, cmd, **kwargs): SELF.session.open(CCBqjg, VVU7IO=cmd, VVY3Iu=True, VVSfhJ=True, VV0vZt=VVhZGE, **kwargs)
def FFjX9J(  SELF, cmd, **kwargs): SELF.session.open(CCBqjg, VVU7IO=cmd, VVN4nE=True , **kwargs)
def FFMkf6( SELF, cmd, **kwargs): SELF.session.open(CCBqjg, VVU7IO=cmd, VVmwop=True   , **kwargs)
def FFSBxT( SELF, cmd, **kwargs): SELF.session.open(CCBqjg, VVU7IO=cmd, VV9ajQ=True  , **kwargs)
def FFIwml(cmd):
 return cmd + " > /dev/null 2>&1"
def FFnQME():
 return " > /dev/null 2>&1"
def FF0sBI(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFaoFr(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFMkdO():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FF8oWX(cmd)
VVjUDZ     = 0
VVf6AS      = 1
VVWA2P   = 2
VVoEPD      = 3
VVEHDi      = 4
VVh7ay     = 5
VVKMZF     = 6
VVuITN = 7
VVELFq = 8
VVgb0U = 9
VVsXhK  = 10
VV6aGr     = 11
VVHK5M  = 12
VVuLC7  = 13
def FFVZA6(parmNum, grepTxt):
 if   parmNum == VVjUDZ  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVf6AS   : param = ["list"   , "apt list" ]
 elif parmNum == VVWA2P: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFMkdO()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFxvW9(parmNum, package):
 if   parmNum == VVoEPD      : param = ["info"      , "apt show"         ]
 elif parmNum == VVEHDi      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVh7ay     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVKMZF     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVuITN : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVELFq : param = ["install --force-overwrite" , "dpkg -i --force-overwrite"     ]
 elif parmNum == VVgb0U : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVsXhK  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VV6aGr     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVHK5M  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVuLC7  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFMkdO()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFRopk():
 result = FF8oWX("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFxvW9(VVKMZF , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFIwml("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFIwml("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFugQf(failed1, VV8mIi))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFugQf(failed2, VV8mIi))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFugQf(failed3, VV0wBB))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFHvxv(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFxvW9(VVKMZF , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFIwml("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFugQf(failed1, VV8mIi))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFugQf(failed2, VV0wBB))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFSTMp(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFIwml('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFIwml("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFt4Zg(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCkHya.VVpck2()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFNoK6(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFt4Zg(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FF1PJc(SELF, path, VV1LYo=True):
 try:
  with ioOpen(path, "r", encoding="UTF-8") as f:
   txt = f.read()
  return True
 except:
  if VV1LYo:
   FFc8qc(SELF, '"lamedb" file is not a standard UTF-8 file !')
  return False
def FFMnHX(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFEZp1(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFt4Zg(path, maxSize=maxSize, encLst=encLst)
  if lines: FFPt7a(SELF, lines, title=title, VV0vZt=VVXjVQ)
  else : FFmT9W(SELF, path, title=title)
 else:
  FFJJSt(SELF, path, title)
def FFsJjT(SELF, path, title):
 if fileExists(path):
  txt = FFt4Zg(path)
  txt = txt.replace("#W#", VVmG5f)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVkO2P)
  txt = txt.replace("#C#", VVumHI)
  txt = txt.replace("#P#", VVyU04)
  FFPt7a(SELF, txt, title=title)
 else:
  FFJJSt(SELF, path, title)
def FFBLii(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FFuI41(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFmhI7(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFPG8X(parent)
 else    : return FFbHHt(parent)
def FFEZp1(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFPG8X(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFbHHt(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFdtKQ():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVDwGq)
 paths.append(VVDwGq.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFuI41(ba)
 for p in list:
  p = ba + p + VVDwGq
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVJV84, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVDwGq, VVJV84 , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVpPVM, VVAquH = FFdtKQ()
def FFg2lz():
 def VVZIHf(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = VVZIHf(CFG.MovieDownloadPath, CCUd13.VVXo1Q())
 VVqfHU   = VVZIHf(CFG.backupPath, CCL50P.VV4KAW())
 VV7ckI   = VVZIHf(CFG.downloadedPackagesPath, t)
 VVzQpF  = VVZIHf(CFG.exportedTablesPath, t)
 VVfTLB  = VVZIHf(CFG.exportedPIconsPath, t)
 VVfqYx   = VVZIHf(CFG.packageOutputPath, t)
 global VVIlHj
 VVIlHj = FFPG8X(CFG.backupPath.getValue())
 if VVqfHU or VVfqYx or VV7ckI or VVzQpF or VVfTLB or oldMovieDownloadPath:
  configfile.save()
 return VVqfHU, VVfqYx, VV7ckI, VVzQpF, VVfTLB, oldMovieDownloadPath
def FFhMgk(path):
 path = FFbHHt(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFDcWB(SELF, pathList, tarFileName, addTimeStamp=True):
 VVdLtF = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVdLtF.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVdLtF.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVdLtF.append(path)
 if not VVdLtF:
  FFc8qc(SELF, "Files not found!")
 elif not pathExists(VVIlHj):
  FFc8qc(SELF, "Path not found!\n\n%s" % VVIlHj)
 else:
  VVSHVP = FFPG8X(VVIlHj)
  tarFileName = "%s%s" % (VVSHVP, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFSGFz())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVdLtF:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVsYfD
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFugQf(tarFileName, VV9pCx))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFugQf(failed, VV9pCx))
  cmd += "fi;"
  cmd +=  sep
  FFn50K(SELF, cmd)
def FFmyX2(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFLtUd(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFLtUd(SELF["keyInfo"], "info")
def FFLtUd(barObj, fName):
 path = "%s%s%s" % (VVAquH, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FF7DLp(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFIWN7(satNum)
  return satName
def FFIWN7(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFbHaq(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FF7DLp(val)
  else  : sat = FFIWN7(val)
 return sat
def FFNqvq(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FF7DLp(num)
 except:
  pass
 return sat
def FFI2fS(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFrHOu(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFJ0c4(info, iServiceInformation.sServiceref)
   prov = FFJ0c4(info, iServiceInformation.sProvider)
   state = str(FFJ0c4(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFgKj2(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFDfd9(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFJ0c4(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFbKYW(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFupyT(refCode):
 info = FFAWW8(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFIdwC(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFunIf(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFAWW8(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VV6kmz = eServiceCenter.getInstance()
  if VV6kmz:
   info = VV6kmz.info(service)
 return info
def FFTrMq(SELF, refCode, VVz9ev=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFyc8f(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVz9ev:
   FFYJSt(SELF, isFromSession)
 try:
  VVjITu = InfoBar.instance
  if VVjITu:
   VVtKZg = VVjITu.servicelist
   if VVtKZg:
    servRef = eServiceReference(refCode)
    VVtKZg.saveChannel(servRef)
 except:
  pass
def FFyc8f(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCytqZ()
    if pr.VVSd1b(refCode, chName, decodedUrl, iptvRef):
     pr.VV8Yi1(SELF, isFromSession)
def FFgKj2(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFHwNJ(url): return FFEdRO(url) or FFMDjw(url)
def FFEdRO(url)  : return any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFMDjw(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FFDfd9(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFl4xc(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFl4xc(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFsvs4(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFkqA3(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFwC08(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FF6SUc(txt):
 try:
  return FFkqA3(FFwC08(txt)) == txt
 except:
  return False
def FFYJSt(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCVY8O, isFromExternal=isFromSession)
 else      : FFupPm(session, reopen=True, isFromExternal=isFromSession)
def FFupPm(session, reopen=False, isFromExternal=False):
 if reopen:
  try:
   session.openWithCallback(BF(FFupPm, session, isFromExternal=isFromExternal), BF(CCoR4p, isFromExternal=isFromExternal))
  except:
   try:
    FFfs5M(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFmFUH(refCode):
 tp = CCMZhh()
 if tp.VVMW5z(refCode) : return True
 else        : return False
def FFEWxD(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFSZ2d():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FFKD9U():
 VVjITu = InfoBar.instance
 if VVjITu:
  VVtKZg = VVjITu.servicelist
  if VVtKZg:
   return VVtKZg.getBouquetList()
 return []
def FFCxp0():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFOc9w():
 path = FFCxp0()
 if path:
  txt = FFt4Zg(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FFLQO2(userBfile):
 txt = ""
 bFile = VVR2Ml + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVR2Ml + userBfile):
  fTxt = FFt4Zg(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FF8oWX('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
def FFn5xE():
 return FFpZCL(InfoBar.instance.servicelist.getRoot())
def FFpZCL(root):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VV6kmz = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VV6kmz.info(service)
    lst.append((service.toString(), info.getName(service)))
 except:
  pass
 return lst
def FFlQ76():
 VVCEke = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVQUG0 = list(VVCEke)
 return VVQUG0, VVCEke
def FFBV8r():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFTFH5(session, VVdX6n):
 VVCven, VVGXgQ, VVNAMS, camCommand = FFMesL()
 if VVGXgQ:
  runLog = False
  if   VVdX6n == CCTS9h.VVn64l : runLog = True
  elif VVdX6n == CCTS9h.VVAiX0 : runLog = True
  elif not VVNAMS          : FFfs5M(session, message="SoftCam not started yet!")
  elif fileExists(VVNAMS)        : runLog = True
  else             : FFfs5M(session, message="File not found !\n\n%s" % VVNAMS)
  if runLog:
   session.open(BF(CCTS9h, VVCven=VVCven, VVGXgQ=VVGXgQ, VVNAMS=VVNAMS, VVdX6n=VVdX6n))
 else:
  FFfs5M(session, message="No active OSCam/NCam found !", title="Live Log")
def FFMesL():
 VVCven = "/etc/tuxbox/config/"
 VVGXgQ = None
 VVNAMS  = None
 camCommand = FF8oWX("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVGXgQ = "oscam"
 elif "ncam"  in camCommand : VVGXgQ = "ncam"
 if VVGXgQ:
  path = FF8oWX(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFPG8X(path)
  if pathExists(path):
   VVCven = path
  tFile = VVCven + VVGXgQ + ".conf"
  tFile = FF8oWX("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVNAMS = tFile
 return VVCven, VVGXgQ, VVNAMS, camCommand
def FFjsXk(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFZwup():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFSGFz():
 return FFZwup().replace(" ", "_").replace("-", "").replace(":", "")
def FF2LS5(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFC0DJ():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFWvl5(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCUfgv.VVOsYy(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCUfgv.VV6gQE_forBouquet(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFIwml("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FF2XXx(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFbZQf(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
VVbD2f = 0
def FFawPV():
 global VVbD2f
 VVbD2f = iTime()
def FFbL4e():
 FFMEyL(">>>>>> Elapsed\t: {:.6f} seconds".format(iTime() - VVbD2f).rstrip("0").rstrip("."))
def FF9xND(SELF, message, title=""):
 SELF.session.open(BF(CChxgF, title=title, message=message, VV5QWZ=True))
def FFPt7a(SELF, message, title="", VV0vZt=VVXjVQ, **kwargs):
 SELF.session.open(BF(CChxgF, title=title, message=message, VV0vZt=VV0vZt, **kwargs))
def FFc8qc(SELF, message, title="")  : FFfs5M(SELF.session, message, title)
def FFJJSt(SELF, path, title="") : FFfs5M(SELF.session, "File not found !\n\n%s" % path, title)
def FFmT9W(SELF, path, title="") : FFfs5M(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFa4IH(SELF, title="")  : FFfs5M(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFfs5M(session, message, title="") : session.open(BF(CCGSN2, title=title, message=message))
def FFBJqp(SELF, VVOIg8, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVOIg8, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVOIg8, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVOIg8, BF(CC7eE6, title=title, message=message, VVLK78=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFc8qc(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFAIFY(SELF, callBack_Yes, VVbzEY, callBack_No=None, title="", VV1oM4=False, VVoXTx=True):
 SELF.session.openWithCallback(BF(FFyypZ, callBack_Yes, callBack_No)
        , BF(CCqZnf, title=title, VVbzEY=VVbzEY, VVoXTx=VVoXTx, VV1oM4=VV1oM4))
def FFyypZ(callBack_Yes, callBack_No, FFAIFYed):
 if FFAIFYed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFlDiQ(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFLgZ9(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFTiZh(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFM8Du(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVk1vv = eTimer()
def FFTiZh(SELF, milliSeconds=1000):
 SELF.onClose.append(BF(FFtbC3, SELF))
 fnc = BF(FFtbC3, SELF)
 try:
  t = VVk1vv.timeout.connect(fnc)
 except:
  VVk1vv.callback.append(fnc)
 VVk1vv.start(milliSeconds, 1)
def FFtbC3(SELF):
 VVk1vv.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFBL02(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCbz99, **kwargs))
  else   : win = SELF.session.open(BF(CCbz99, **kwargs))
  FF9Drq(win)
  return win
 except:
  return None
def FF0km9(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CC37eN, **kwargs))
 FF9Drq(win)
 return win
def FFsVRo(SELF, **kwargs):
 SELF.session.open(CCSQQx, **kwargs)
def FFSrMl(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FF8WkH(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FFZtqU(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVUA23, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFvDVP(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFZtqU(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFSAjK():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFI6li(VVYOiV):
 screenSize  = FFSAjK()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVYOiV)
 return bodyFontSize
def FFDISy(VVYOiV, extraSpace):
 font = gFont(VVUA23, VVYOiV)
 VV2awD = fontRenderClass.getInstance().getLineHeight(font) or (VVYOiV * 1.25)
 return int(VV2awD + VV2awD * extraSpace)
def FFi9TE(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True):
 screenSize = FFSAjK()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVUA23, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFDISy(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVUA23, titleFontSize, alignLeftCenter)
 if winType == VVavIl or winType == VVtpeW:
  if winType == VVtpeW : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVpEAW:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == WINDOW_SUBTITLE:
  lineH = int((height - 8) / 3.0)
  top = 2
  tmp += '<widget name="mySubtFr" position="0,0" size="%d,%d" zPosition="10" backgroundColor="#55113355" />' % (width, height)
  for i in range(3):
   tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="11" foregroundColor="#ffffff" shadowColor="#555555" shadowOffset="-2,-2" backgroundColor="#ff000000" %s %s />' % (i, top + 2, width - 2, lineH - 2, bodyFontStr, alignCenter)
   top += lineH
 elif winType == VV377I:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FF9xNDL = b2Left2 + timeW + marginLeft
  FF9xNDW = b2Left3 - marginLeft - FF9xNDL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FF9xNDL  , b2Top, FF9xNDW , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
 elif winType == VVu0m7:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVy8KX:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VV3A9p:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVEcC3:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVUA23, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVUA23, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVysq6:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FF9xNDH = int(bodyH * 0.5)
  inpTop = bodyTop + FF9xNDH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FF9xNDH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVUA23, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVUA23, mapF, alignCenter)
 elif winType == VVEZH2:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVZvOF:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVUA23, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVtQs4:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVUA23, fontH, alignCenter)
 elif winType == VVoGN2:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVUA23, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVUA23, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVUA23, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VV40Wa:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVRLnl:
  tmp += '<widget name="myPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (marginLeft, bodyTop, bodyW, bodyH)
 else:
  if   winType == VV8biG : align = alignLeftCenter
  elif winType == VVAK4W : align = alignLeftTop
  else          : align = alignCenter
  if winType == VV15d1:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVUA23
  if usefixedFont and winType == VVAK4W:
   fnt = "Fixed"
   if fnt in FFHGPv():
    fontName = "Fixed"
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVYOiV = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVUA23, VVYOiV, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVspm3 = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVUA23, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVspm3[i], VVUA23, barFont, alignCenter)
   left += btnW + gap
 if winType == VVAK4W:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVspm3 = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVspm3[i], VVUA23, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFi9TE(VVavIl, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.VVDV3p = ""
  self.themsList  = []
  VVJtuN = []
  if VVqV29:
   VVJtuN.append(("-- MY TEST --"    , "myTest"   ))
  VVJtuN.append(("  File Manager"     , "FileManager"  ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("  Services/Channels"    , "ChannelsTools" ))
  VVJtuN.append(("  IPTV"       , "IptvTools"  ))
  VVJtuN.append(("  PIcons"       , "PIconsTools"  ))
  VVJtuN.append(("  SoftCam"      , "SoftCam"   ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("  Plugins"      , "PluginsTools" ))
  VVJtuN.append(("  Terminal"      , "Terminal"  ))
  VVJtuN.append(("  Backup & Restore"    , "BackupRestore" ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("  Date/Time"      , "Date_Time"  ))
  VVJtuN.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVJtuN)
  FFRqJR(self, VVJtuN=VVJtuN)
  FFINW5(self["keyRed"] , "Exit")
  FFINW5(self["keyGreen"] , "Settings")
  FFINW5(self["keyYellow"], "Dev. Info.")
  FFINW5(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close      ,
   "green"   : self.VVDrWv     ,
   "yellow"  : self.VVDF5z     ,
   "blue"   : self.VV5QnC     ,
   "info"   : self.VV5QnC     ,
   "next"   : self.VVxM2C     ,
   "menu"   : self.VVAYXC   ,
   "text"   : self.VVhkAw    ,
   "0"    : BF(self.VVS9sk, 0)  ,
   "1"    : BF(self.VVPNeF, 1)   ,
   "2"    : BF(self.VVPNeF, 2)   ,
   "3"    : BF(self.VVPNeF, 3)   ,
   "4"    : BF(self.VVPNeF, 4)   ,
   "5"    : BF(self.VVPNeF, 5)   ,
   "6"    : BF(self.VVPNeF, 6)   ,
   "7"    : BF(self.VVPNeF, 7)   ,
   "8"    : BF(self.VVPNeF, 8)   ,
   "9"    : BF(self.VVPNeF, 9)
  })
  self.onShown.append(self.VVDpWe)
  self.onClose.append(self.onExit)
  global VVIGxe, VVFrOP, VVkw26
  VVIGxe = VVFrOP = VVkw26 = False
 def VVlQQ7(self):
  item = FF3aN3(self)
  self.VVPNeF(item)
 def VVPNeF(self, item):
  if item is not None:
   if   item == "myTest"     : self.VV9GzD()
   elif item in ("FileManager"  , 1) : self.session.open(CCg2YR)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCcNAu)
   elif item in ("IptvTools"  , 3) : self.session.open(CCUfgv)
   elif item in ("PIconsTools"  , 4) : self.VVVVLV()
   elif item in ("SoftCam"   , 5) : self.session.open(CCRfQn)
   elif item in ("PluginsTools" , 6) : self.session.open(CCCzDl)
   elif item in ("Terminal"  , 7) : self.session.open(CCRP7s)
   elif item in ("BackupRestore" , 8) : self.session.open(CC9LNq)
   elif item in ("Date_Time"  , 9) : self.session.open(CCylQ9)
   elif item in ("CheckInternet" , 10) : self.session.open(CCeBE2)
   else         : self.close()
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FF7a1g(self["myMenu"])
  FFvDVP(self)
  FFSrMl(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVH1FK)
  self["myTitle"].setText(title)
  VVqfHU, VVfqYx, VV7ckI, VVzQpF, VVfTLB, oldMovieDownloadPath = FFg2lz()
  self.VVTA7I()
  if VVqfHU or VVfqYx or VV7ckI or VVzQpF or VVfTLB or oldMovieDownloadPath:
   VVxcQr = lambda path, subj: "%s:\n%s\n\n" % (subj, FF0IFC(path, VV0wBB)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVxcQr(VVqfHU   , "Backup/Restore Path"    )
   txt += VVxcQr(VVfqYx  , "Created Package Files (IPK/DEB)" )
   txt += VVxcQr(VV7ckI  , "Download Packages (from feeds)" )
   txt += VVxcQr(VVzQpF , "Exported Tables"     )
   txt += VVxcQr(VVfTLB , "Exported PIcons"     )
   txt += VVxcQr(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFPt7a(self, txt, title="Settings Paths")
  if (EASY_MODE or VVkZjF or VVqV29):
   FFLgZ9(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFlDiQ(self, "Welcome", 300)
  FF1Gz0(BF(self.VV6G4n, title))
 def VV6G4n(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCL50P.VV05Yk()
   if url:
    newWebVer = CCL50P.VVibJy(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFIwml("rm /tmp/ajpanel*"))
  global VVIGxe, VVFrOP, VVkw26
  VVIGxe = VVFrOP = VVkw26 = False
 def VVS9sk(self, digit):
  self.VVDV3p += str(digit)
  ln = len(self.VVDV3p)
  global VVIGxe, VVkw26
  if ln == 4:
   if self.VVDV3p == "0" * ln:
    VVIGxe = True
    FFLgZ9(self["myTitle"], "#800080")
   else:
    self.VVDV3p = "x"
  elif self.VVDV3p == "0" * 8:
   VVkw26 = True
 def VVxM2C(self):
  self.VVDV3p += ">"
  if self.VVDV3p == "0" * 4 + ">" * 2:
   global VVFrOP
   VVFrOP = True
   FFLgZ9(self["myTitle"], "#dd5588")
 def VVhkAw(self):
  if self.VVDV3p == "0" * 4:
   ok = False
   fnt = "ae_AlMateen.ttf"
   fontFile = "/usr/share/fonts/%s" % fnt
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    try:
     addFont(fontFile, fontName, 100, True)
     ok = True
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      ok = True
     except:
      pass
   if ok: txt = 'Added Font: "%s"' % fnt
   else : txt = '"%s" Not Found' % fnt
   FFlDiQ(self, txt, 2000, isGrn=ok)
 def VVVVLV(self):
  found = False
  pPath = CC2T9T.VVP17o()
  if pathExists(pPath):
   for fName, fType in CC2T9T.VVkxJK(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CC2T9T)
  else:
   VVJtuN = []
   VVJtuN.append(("PIcons Tools" , "CC2T9T" ))
   VVJtuN.append(VVImCt)
   VVJtuN.append(CC2T9T.VVw0Q9())
   VVJtuN.append(VVImCt)
   VVJtuN += CC2T9T.VVXAbb()
   FF0km9(self, self.VVgNW6, VVJtuN=VVJtuN)
 def VVgNW6(self, item=None):
  if item:
   if   item == "CC2T9T"   : self.session.open(CC2T9T)
   elif item == "VV6kpa"  : CC2T9T.VV6kpa(self)
   elif item == "VVVM2i"  : CC2T9T.VVVM2i(self)
   elif item == "findPiconBrokenSymLinks" : CC2T9T.VVZgX1(self, True)
   elif item == "FindAllBrokenSymLinks" : CC2T9T.VVZgX1(self, False)
 def VVDrWv(self):
  self.session.open(CCL50P)
 def VVDF5z(self):
  self.session.open(CCIhgz)
 def VV5QnC(self):
  changeLogFile = VVAquH + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FFNoK6(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FF0IFC("\n%s\n%s\n%s" % (VVsYfD, line, VVsYfD), VV8mIi, VVmG5f)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FF0IFC(line, VVkO2P, VVmG5f)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFPt7a(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVH1FK, PLUGIN_DESCRIPTION), VVYOiV=26)
 def VVAYXC(self):
  VVJtuN = []
  VVJtuN.append(("Title Colors"   , "title" ))
  VVJtuN.append(("Menu Area Colors"  , "body" ))
  VVJtuN.append(("Menu Pointer Colors" , "cursor" ))
  VVJtuN.append(("Bottom Bar Colors" , "bar"  ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Reset Colors"   , "reset" ))
  title = "Main Menu Colors"
  FF0km9(self, BF(self.VVLmUJ, title), VVJtuN=VVJtuN, width=500, title=title)
 def VVLmUJ(self, title, item=None):
  if item:
   if item == "reset":
    FFAIFY(self, self.VVgPRv, "Reset to default colors ?", title=title)
   else:
    tDict = self.VV54TD()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVcKNo, tDict, item), CCPSxo, defFG=fg, defBG=bg)
 def VVSdNV(self):
  return VVIlHj + "ajpanel_colors"
 def VV54TD(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVSdNV()
  if fileExists(p):
   txt = FFt4Zg(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVcKNo(self, tDict, item, fg, bg):
  if fg:
   self.VVMJrH(item, fg)
   self.VVD3ta(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVY34M(tDict)
 def VVY34M(self, tDict):
   p = self.VVSdNV()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVMJrH(self, item, fg):
  if   item == "title" : FFeqjP(self["myTitle"], fg)
  elif item == "body"  :
   FFeqjP(self["myMenu"], fg)
   FFeqjP(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFLgZ9(self["myBar"], fg)
   FFeqjP(self["keyRed"], fg)
   FFeqjP(self["keyGreen"], fg)
   FFeqjP(self["keyYellow"], fg)
   FFeqjP(self["keyBlue"], fg)
 def VVD3ta(self, item, bg):
  if   item == "title" : FFLgZ9(self["myTitle"], bg)
  elif item == "body"  :
   FFLgZ9(self["myMenu"], bg)
   FFLgZ9(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFLgZ9(self["myBar"], bg)
 def VVgPRv(self):
  os.system(FFIwml("rm %s" % self.VVSdNV()))
  self.close()
 def VVTA7I(self):
  tDict = self.VV54TD()
  self.VVv3yH(tDict, "title")
  self.VVv3yH(tDict, "body")
  self.VVv3yH(tDict, "cursor")
  self.VVv3yH(tDict, "bar")
 def VVv3yH(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVMJrH(name, fg)
  if bg: self.VVD3ta(name, bg)
 def VV9GzD(self):
  self.session.open(CCVY8O)
class CCkHya():
 @staticmethod
 def VVpck2():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVErfW(isApply=False):
  global VVv1m4, VV6ZSr
  VVv1m4  = True
  VV6ZSr = CCkHya.VVYN1d()
  CCkHya.VVy5CU()
 @staticmethod
 def VVy5CU():
  if VV6ZSr:
   global VVv1m4
   if CFG.forceUtf8Encoding.getValue():
    if CCkHya.VVejfd() : VVv1m4 = True
    else        : VVv1m4 = False
   else:
    CCkHya.VVYMOF()
    VVv1m4 = False
 @staticmethod
 def VVYN1d(isApply=False):
  from sys import version_info
  if version_info[0] >= 3 and version_info[1] >= 10:
   path = "/etc/issue"
   if fileExists(path):
    path = "/etc/issue"
    if fileExists(path):
     txt = FFt4Zg(path)
     span = iSearch(r"open.?vision", txt, IGNORECASE)
     if span:
      return True
  return False
 @staticmethod
 def VVejfd():
  import locale
  enc = locale.getdefaultlocale()[1]
  span = iSearch(r"UTF.?8", enc, IGNORECASE)
  if not span:
   try:
    import locale
    return locale.setlocale(locale.LC_ALL, "en_GB.UTF-8")
   except:
    pass
  return None
 @staticmethod
 def VVYMOF():
  try:
   import locale
   return locale.setlocale(locale.LC_ALL, "")
  except:
   return None
 @staticmethod
 def VVhqY7(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFBL02(SELF, None, VVdLtF=lst, VVYOiV=30, VVBMOB=True)
 @staticmethod
 def VVkGCD(path, SELF=None):
  for enc in CCkHya.VVpck2():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFc8qc(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VV8Gsw(SELF, path, cbFnc, defEnc="", pos=0):
  FFlDiQ(SELF)
  lst = CCkHya.VVFlHo(path)
  if lst:
   VVJtuN = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if defEnc == enc:
     txt = FF0IFC(txt, VV9pCx)
    VVJtuN.append((txt, enc))
   win = FF0km9(SELF, cbFnc, title="Select Encoding", VVJtuN=VVJtuN, width=900, height=500 if pos == 1 else 0)
   if pos == 1:
    win.instance.move(ePoint(40, 40))
  else:
   FFlDiQ(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVFlHo(path):
  encLst = []
  cPath = VVAquH + "codecs"
  if fileExists(cPath):
   lines = FFNoK6(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCkHya.VVpck2())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    try:
     with ioOpen(path, "r", encoding=enc) as f:
      for line in f:
       pass
     lst.append((item[0], enc))
    except:
     pass
  return lst
class CCIhgz(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFi9TE(VVavIl, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVJtuN = []
  VVJtuN.append(("Settings File"        , "SettingsFile"   ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Box Info"          , "VVHLYf"    ))
  VVJtuN.append(("Tuners Info"         , "VV55hW"   ))
  VVJtuN.append(("Python Version"        , "VVVPpX"   ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Screen Size"         , "ScreenSize"    ))
  VVJtuN.append(("Language/Locale"        , "Locale"     ))
  VVJtuN.append(("Processor"         , "Processor"    ))
  VVJtuN.append(("Operating System"        , "OperatingSystem"   ))
  VVJtuN.append(("Drivers"          , "drivers"     ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("System Users"         , "SystemUsers"    ))
  VVJtuN.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVJtuN.append(("Uptime"          , "Uptime"     ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Host Name"         , "HostName"    ))
  VVJtuN.append(("MAC Address"         , "MACAddress"    ))
  VVJtuN.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVJtuN.append(("Network Status"        , "NetworkStatus"   ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Disk Usage"         , "VVozwL"    ))
  VVJtuN.append(("Mount Points"         , "MountPoints"    ))
  VVJtuN.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVJtuN.append(("USB Devices"         , "USB_Devices"    ))
  VVJtuN.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVJtuN.append(("Directory Size"        , "DirectorySize"   ))
  VVJtuN.append(("Memory"          , "Memory"     ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVJtuN.append(("Running Processes"       , "RunningProcesses"  ))
  VVJtuN.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFRqJR(self, VVJtuN=VVJtuN, title="Device Information")
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FF7a1g(self["myMenu"])
  FFvDVP(self)
 def VVlQQ7(self):
  global VV7k9C
  VV7k9C = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCjW7H)
   elif item == "VVHLYf"    : self.VVHLYf()
   elif item == "VV55hW"   : self.VV55hW()
   elif item == "VVVPpX"   : self.VVVPpX()
   elif item == "ScreenSize"    : FFPt7a(self, "Width\t: %s\nHeight\t: %s" % (FFSAjK()[0], FFSAjK()[1]))
   elif item == "Locale"     : CCkHya.VVhqY7(self)
   elif item == "Processor"    : self.VV7CMQ()
   elif item == "OperatingSystem"   : FFsu1t(self, "uname -a"        )
   elif item == "drivers"     : self.VVMWKI()
   elif item == "SystemUsers"    : FFsu1t(self, "id"          )
   elif item == "LoggedInUsers"   : FFsu1t(self, "who -a"         )
   elif item == "Uptime"     : FFsu1t(self, "uptime"         )
   elif item == "HostName"     : FFsu1t(self, "hostname"        )
   elif item == "MACAddress"    : self.VVfTVL()
   elif item == "NetworkConfiguration"  : FFsu1t(self, "ifconfig %s %s" % (FFugQf("HWaddr", VVPgsh), FFugQf("addr:", VV8mIi)))
   elif item == "NetworkStatus"   : FFsu1t(self, "netstat -tulpn"       )
   elif item == "VVozwL"    : self.VVozwL()
   elif item == "MountPoints"    : FFsu1t(self, "mount %s" % (FFugQf(" on ", VV8mIi)))
   elif item == "FileSystemTable"   : FFsu1t(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFsu1t(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFsu1t(self, "blkid"         )
   elif item == "DirectorySize"   : FFsu1t(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VV9v81="Reading size ...")
   elif item == "Memory"     : FFsu1t(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVwDxj()
   elif item == "RunningProcesses"   : FFsu1t(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFsu1t(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVCaMR()
   else         : self.close()
 def VVfTVL(self):
  res = FFJoh0("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFPt7a(self, txt)
  else:
   FFsu1t(self, "ip link")
 def VV0ZyB(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFOAMF(cmd)
  return lines
 def VVjMgH(self, lines, headerRepl, widths, VVQQbo):
  VVMDmE = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVMDmE.append(parts)
  if VVMDmE and len(header) == len(widths):
   VVMDmE.sort(key=lambda x: x[0].lower())
   FFBL02(self, None, header=header, VVdLtF=VVMDmE, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=28, VVBMOB=True)
   return True
  else:
   return False
 def VVozwL(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFJoh0(cmd)
  if not "invalid option" in txt:
   lines  = self.VV0ZyB(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VVQQbo = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVjMgH(lines, headerRepl, widths, VVQQbo)
  else:
   cmd = "df -h"
   lines  = self.VV0ZyB(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VVQQbo = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVjMgH(lines, headerRepl, widths, VVQQbo)
  if not allOK:
   lines = FFOAMF(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFbHHt(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VV9pCx:
     note = "\n%s" % FF0IFC("Green = Mounted Partitions", VV9pCx)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VV8mIi
     elif line.endswith(mountList) : color = VV9pCx
     else       : color = VVkO2P
     txt += FF0IFC(line, color) + "\n"
    FFPt7a(self, txt + note)
   else:
    FFc8qc(self, "Not data from system !")
 def VVwDxj(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VV0ZyB(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVQQbo = (LEFT , CENTER, LEFT )
  allOK = self.VVjMgH(lines, headerRepl, widths, VVQQbo)
  if not allOK:
   FFsu1t(self, cmd)
 def VVMWKI(self):
  cmd = FFVZA6(VVWA2P, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFsu1t(self, cmd)
  else : FFa4IH(self)
 def VV7CMQ(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFsu1t(self, cmd)
 def VVCaMR(self):
  cmd = FFVZA6(VVf6AS, "| grep secondstage")
  if cmd : FFsu1t(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFa4IH(self)
 def VVHLYf(self):
  c = VV9pCx
  VVdLtF = []
  VVdLtF.append((FF0IFC("Box Type"  , c), FF0IFC(self.VVQzVg("boxtype").upper(), c)))
  VVdLtF.append((FF0IFC("Board Version", c), FF0IFC(self.VVQzVg("board_revision") , c)))
  VVdLtF.append((FF0IFC("Chipset"  , c), FF0IFC(self.VVQzVg("chipset")  , c)))
  VVdLtF.append((FF0IFC("S/N"   , c), FF0IFC(self.VVQzVg("sn")    , c)))
  VVdLtF.append((FF0IFC("Version"  , c), FF0IFC(self.VVQzVg("version")  , c)))
  VVPgch   = []
  VV45kh = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VV45kh = SystemInfo[key]
     else:
      VVPgch.append((FF0IFC(str(key), VVumHI), FF0IFC(str(SystemInfo[key]), VVumHI)))
  except:
   pass
  if VV45kh:
   VV5IPR = self.VVwxCl(VV45kh)
   if VV5IPR:
    VV5IPR.sort(key=lambda x: x[0].lower())
    VVdLtF += VV5IPR
  if VVPgch:
   VVPgch.sort(key=lambda x: x[0].lower())
   VVdLtF += VVPgch
  if VVdLtF:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFBL02(self, None, header=header, VVdLtF=VVdLtF, VVGpzZ=widths, VVYOiV=28, VVBMOB=True)
  else:
   FFPt7a(self, "Could not read info!")
 def VVQzVg(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFNoK6(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVwxCl(self, mbDict):
  try:
   mbList = list(mbDict)
   VVdLtF = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVdLtF.append((FF0IFC(subject, VV8mIi), FF0IFC(value, VV8mIi)))
  except:
   pass
  return VVdLtF
 def VV55hW(self):
  txt = self.VVA6x0("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVA6x0("/proc/bus/nim_sockets")
  if not txt: txt = self.VVkTup()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFPt7a(self, txt)
 def VVkTup(self):
  txt = ""
  VVxcQr = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVxcQr("Slot Name" , slot.getSlotName())
     txt += FF0IFC(slotName, VV8mIi)
     txt += VVxcQr("Description"  , slot.getFullDescription())
     txt += VVxcQr("Frontend ID"  , slot.frontend_id)
     txt += VVxcQr("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVA6x0(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFNoK6(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FF0IFC(line, VV8mIi)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVVPpX(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFPt7a(self, txt)
class CCjW7H(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFi9TE(VVavIl, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVJtuN = []
  VVJtuN.append(("Settings (All)"   , "Settings_All"   ))
  VVJtuN.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  if VVFrOP:
   VVJtuN.append(("Settings (FHDG-17)" , "Settings_FHDG_17"  ))
  VVJtuN.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVJtuN.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVJtuN.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVJtuN.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVJtuN.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFRqJR(self, VVJtuN=VVJtuN)
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FF7a1g(self["myMenu"])
  FFvDVP(self)
 def VVlQQ7(self):
  global VV7k9C
  VV7k9C = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFsu1t(self, cmd                )
   elif item == "Settings_HotKeys"   : FFsu1t(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFsu1t(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFsu1t(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFsu1t(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFsu1t(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFsu1t(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFsu1t(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCRfQn(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFi9TE(VVavIl, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVCven, VVGXgQ, VVNAMS, camCommand = FFMesL()
  self.VVGXgQ = VVGXgQ
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVJtuN = []
  VVJtuN.append(("OSCam Files"        , "OSCamFiles"  ))
  VVJtuN.append(("NCam Files"        , "NCamFiles"  ))
  VVJtuN.append(("CCcam Files"        , "CCcamFiles"  ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVJtuN.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVJtuN.append(VVImCt)
  if VVGXgQ:
   if   "oscam" in VVGXgQ : camName = "OSCam"
   elif "ncam"  in VVGXgQ : camName = "NCam"
   VVJtuN.append((camName + " Info."      , "camInfo"   ))
   VVJtuN.append((camName + " Live Status"    , "camLiveStatus" ))
   VVJtuN.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVJtuN.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVJtuN.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFRqJR(self, VVJtuN=VVJtuN)
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FF7a1g(self["myMenu"])
  FFvDVP(self)
 def VVlQQ7(self):
  global VV7k9C
  VV7k9C = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CC8dc0, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CC8dc0, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CC8dc0, "cccam"))
   elif item == "OSCamReaders"  : self.VVIcoH("os")
   elif item == "NSCamReaders"  : self.VVIcoH("n")
   elif item == "camInfo"   : FFtRVe(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFTFH5(self.session, CCTS9h.VVn64l)
   elif item == "camLiveReaders" : FFTFH5(self.session, CCTS9h.VVAiX0)
   elif item == "camLiveLog"  : FFTFH5(self.session, CCTS9h.VVM43C)
   else       : self.close()
 def VVIcoH(self, camPrefix):
  VVMDmE = self.VVaczy(camPrefix)
  if VVMDmE:
   VVMDmE.sort(key=lambda x: int(x[0]))
   if self.VVGXgQ and self.VVGXgQ.startswith(camPrefix):
    VVieK7 = ("Toggle State", self.VVPGz6, [camPrefix], "Changing State ...")
   else:
    VVieK7 = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVQQbo  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFBL02(self, None, header=header, VVdLtF=VVMDmE, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=26, VVieK7=VVieK7, VVxbA6=True)
 def VVaczy(self, camPrefix):
  readersFile = self.VVCven + camPrefix + "cam.server"
  VVMDmE = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFNoK6(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVMDmE.append((str(len(VVMDmE) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVMDmE:
    FFc8qc(self, "No readers found !")
  else:
   FFJJSt(self, readersFile)
  return VVMDmE
 def VVPGz6(self, VV57kA, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVCven, camPrefix)
  readerState  = VV57kA.VVIrRe(1)
  readerLabel  = VV57kA.VVIrRe(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCRfQn.VVYY9b(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VV57kA.VVDvRR()
    FFc8qc(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVMDmE = self.VVaczy(camPrefix)
   if VVMDmE:
    VV57kA.VV3aGD(VVMDmE)
 @staticmethod
 def VVYY9b(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFNoK6(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFc8qc(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFc8qc(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFJJSt(SELF, confFile)
   return None
  if not iRequest:
   FFc8qc(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FFc8qc(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FFc8qc(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CC8dc0(Screen):
 def __init__(self, VVpX8J, session, args=0):
  self.skin, self.skinParam = FFi9TE(VVavIl, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVCven, VVGXgQ, VVNAMS, camCommand = FFMesL()
  if   VVpX8J == "ncam" : self.prefix = "n"
  elif VVpX8J == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVJtuN = []
  if self.prefix == "":
   VVJtuN.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVJtuN.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVJtuN.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVJtuN.append(("constant.cw"         , "x_constant_cw" ))
   VVJtuN.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVJtuN.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVJtuN.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVJtuN.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVJtuN.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVJtuN.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVJtuN.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVJtuN.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVJtuN.append(VVImCt)
   VVJtuN.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVJtuN.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVJtuN.append(VVImCt)
   VVJtuN.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVJtuN.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVJtuN.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFRqJR(self, VVJtuN=VVJtuN)
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FF7a1g(self["myMenu"])
  FFvDVP(self)
 def VVlQQ7(self):
  global VV7k9C
  VV7k9C = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFMnHX(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFMnHX(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFMnHX(self, self.VVCven + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFMnHX(self, self.VVCven + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVXsE9("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVXsE9("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVXsE9("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVXsE9("cam.provid"        )
   elif item == "x_cam_server"  : self.VVXsE9("cam.server"        )
   elif item == "x_cam_services" : self.VVXsE9("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVXsE9("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVXsE9("cam.user"        )
   elif item == "x_VVsYfD"   : pass
   elif item == "x_SoftCam_Key" : self.VVNevc()
   elif item == "x_CCcam_cfg"  : FFMnHX(self, self.VVCven + "CCcam.cfg"    )
   elif item == "x_VVsYfD"   : pass
   elif item == "x_cam_log"  : FFMnHX(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFMnHX(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFMnHX(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVXsE9(self, fileName):
  FFMnHX(self, self.VVCven + self.prefix + fileName)
 def VVNevc(self):
  path = self.VVCven + "SoftCam.Key"
  if fileExists(path) : FFMnHX(self, path)
  else    : FFMnHX(self, path.replace(".Key", ".key"))
class CCTS9h(Screen):
 VVn64l  = 0
 VVAiX0 = 1
 VVM43C = 2
 def __init__(self, session, VVCven="", VVGXgQ="", VVNAMS="", VVdX6n=VVn64l):
  self.skin, self.skinParam = FFi9TE(VVAK4W, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVNAMS   = VVNAMS
  self.VVdX6n  = VVdX6n
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVCven + VVGXgQ + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVGXgQ : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVCven, self.camPrefix)
  if self.VVdX6n == self.VVn64l:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVdX6n == self.VVAiX0:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFRqJR(self, self.Title, addScrollLabel=True)
  FFINW5(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VV6PoK
  self.onShown.append(self.VVDpWe)
  self.onClose.append(self.onExit)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  self["myLabel"].VVfE6M(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFSrMl(self)
  self.VV6PoK()
 def onExit(self):
  self.timer.stop()
 def VVsn4W(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVzf51)
  except:
   self.timer.callback.append(self.VVzf51)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFlDiQ(self, "Started", 1000)
 def VVWYHm(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVzf51)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFlDiQ(self, "Stopped", 1000)
 def VV6PoK(self):
  if self.timerRunning:
   self.VVWYHm()
  else:
   self.VVsn4W()
   if self.VVdX6n == self.VVn64l or self.VVdX6n == self.VVAiX0:
    if self.VVdX6n == self.VVn64l : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCRfQn.VVYY9b(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FF1Gz0(self.VVG0So)
    else:
     self.close()
   else:
    self.VVnACO()
 def VVzf51(self):
  if self.timerRunning:
   if   self.VVdX6n == self.VVn64l : self.VVcrra()
   elif self.VVdX6n == self.VVAiX0 : self.VVcrra()
   else            : self.VVnACO()
 def VVnACO(self):
  if fileExists(self.VVNAMS):
   fTime = FFjsXk(os.path.getmtime(self.VVNAMS))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VV9Krb(), VV0vZt=VVhZGE)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVNAMS)
 def VVG0So(self):
  self.VVcrra()
 def VVcrra(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FF0IFC("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVyU04))
   self.camWebIfErrorFound = True
   self.VVWYHm()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVdX6n == self.VVn64l : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FF0IFC("Error while parsing data elements !\n\nError = %s" % str(e), VV0wBB)
   self.camWebIfErrorFound = True
   self.VVWYHm()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVE0eF(root)
  self["myLabel"].setText(txt, VV0vZt=VVhZGE)
  self["myBar"].setText("Last Update : %s" % FFZwup())
 def VVE0eF(self, rootElement):
  def VVxcQr(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVdX6n == self.VVn64l:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FF0IFC(status, VV9pCx)
    else          : status = FF0IFC(status, VV0wBB)
    txt += VVsYfD + "\n"
    txt += VVxcQr("Name"  , name)
    txt += VVxcQr("Description" , desc)
    txt += VVxcQr("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVxcQr("Protocol" , protocol)
    txt += VVxcQr("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FF0IFC("Yes", VV9pCx)
    else    : enabTxt = FF0IFC("No", VV0wBB)
    txt += VVsYfD + "\n"
    txt += VVxcQr("Label"  , label)
    txt += VVxcQr("Protocol" , protocol)
    txt += VVxcQr("Enabled" , enabTxt)
  return txt
 def VV9Krb(self):
  wordsDict = self.VVISMM()
  color = [ VV8mIi, VVPgsh, VV9pCx, VV0wBB, VVumHI, VVX67O]
  lines = FFOAMF("tail -n %d %s" % (100, self.VVNAMS))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVyU04 + line[:19] + VVkO2P + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVmG5f + line[ndx + 3:] + VVkO2P
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VV8mIi + line[ndx + 8 : ndx1 + 4] + VVkO2P + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVkO2P)
   elif line.startswith("----") or ">>" in line:
    line = FF0IFC(line, VV8mIi)
   txt += line + "\n"
  return txt
 def VVISMM(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFNoK6(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CC9LNq(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFi9TE(VVavIl, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVJtuN = []
  VVJtuN.append(("Backup Channels"    , "VVDype"   ))
  VVJtuN.append(("Restore Channels"    , "Restore_Channels"  ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Backup SoftCAM Files"   , "VVtt7s" ))
  VVJtuN.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVJtuN.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVJtuN.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Backup Network Settings"  , "VVcSex"   ))
  VVJtuN.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVFrOP:
   VVJtuN.append(VVImCt)
   VVJtuN.append((VVyU04 + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VVEdbk"   ))
   VVJtuN.append((VV9pCx + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VV0a2r) , "createMyIpk"   ))
   VVJtuN.append((VV9pCx + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VV0a2r) , "createMyDeb"   ))
   VVJtuN.append((VVumHI + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVJtuN.append((VVumHI + "Decode %s Crash Report"   % PLUGIN_NAME     , "VV5hdO" ))
  FFRqJR(self, VVJtuN=VVJtuN)
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FF7a1g(self["myMenu"])
  FFvDVP(self)
 def VVlQQ7(self):
  global VV7k9C
  VV7k9C = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVDype"    : self.VVDype()
   elif item == "Restore_Channels"    : self.VVNfCL("channels_backup*.tar.gz", self.VVTGvf)
   elif item == "VVtt7s"   : self.VVtt7s()
   elif item == "Restore_SoftCAM_Files"  : self.VVNfCL("softcam_backup*.tar.gz", self.VVAVZB)
   elif item == "Backup_TunerDiSEqC"   : self.VVAbrT("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVNfCL("tuner_backup*.backup", BF(self.VVWpr6, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVAbrT("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVNfCL("hotkey_*backup*.backup", BF(self.VVWpr6, "misc"))
   elif item == "VVcSex"    : self.VVcSex()
   elif item == "Restore_Network"    : self.VVNfCL("network_backup*.tar.gz", self.VV2yp0)
   elif item == "VVEdbk"     : FFAIFY(self, BF(FFItMF, self, BF(CC9LNq.VVEdbk, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVxuxk(False)
   elif item == "createMyDeb"     : self.VVxuxk(True)
   elif item == "createMyTar"     : self.VVVZzb()
   elif item == "VV5hdO"   : self.VV5hdO()
 @staticmethod
 def VVEdbk(SELF):
  OBF_Path = VVpPVM + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVpPVM, VVH1FK, VV0a2r)
   if err : FFc8qc(SELF, err)
   else : FFPt7a(SELF, txt)
  else:
   FFJJSt(SELF, OBF_Path)
 def VVxuxk(self, VVBkcb):
  OBF_Path = VVpPVM + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFc8qc(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVpPVM)
  os.system("mv -f %s %s" % (VVpPVM + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVpPVM + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVpPVM + "plugin.py"))
  self.session.openWithCallback(self.VVxuxk1, BF(CCEcg9, path=VVpPVM, VVBkcb=VVBkcb))
 def VVxuxk1(self):
  os.system("mv -f %s %s" % (VVpPVM + "OBF/main.py"  , VVpPVM))
  os.system("mv -f %s %s" % (VVpPVM + "OBF/plugin.py" , VVpPVM))
 def VV5hdO(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFc8qc(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFc8qc(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVwcFi("%s*.list" % path)
  if err:
   FFJJSt(self, path + "*.list")
   return
  srcF, err = self.VVwcFi("%s*main_final.py" % path)
  if err:
   FFJJSt(self, path + "*.final.py")
   return
  VVdLtF = []
  for f in files:
   f = os.path.basename(f)
   VVdLtF.append((f, f))
  FF0km9(self, BF(self.VVJ8vS, path, codF, srcF), VVJtuN=VVdLtF)
 def VVJ8vS(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFJJSt(self, logF)
   else     : FFItMF(self, BF(self.VVz2Hm, logF, codF, srcF))
 def VVz2Hm(self, logF, codF, srcF):
  lst  = []
  lines = FFNoK6(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFc8qc(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVJ8UU(lst, logF, newLogF)
  totSrc  = self.VVJ8UU(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFPt7a(self, txt)
 def VVwcFi(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVJ8UU(self, lst, f1, f2):
  txt = FFt4Zg(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVVZzb(self):
  VVdLtF = []
  VVdLtF.append("%s%s" % (VVpPVM, "*.py"))
  VVdLtF.append("%s%s" % (VVpPVM, "*.png"))
  VVdLtF.append("%s%s" % (VVpPVM, "*.xml"))
  VVdLtF.append("%s"  % (VVAquH))
  FFDcWB(self, VVdLtF, "%s_%s" % (PLUGIN_NAME, VVH1FK), addTimeStamp=False)
 def VVDype(self):
  path1 = VVR2Ml
  path2 = "/etc/tuxbox/"
  VVdLtF = []
  VVdLtF.append("%s%s" % (path1, "*.tv"))
  VVdLtF.append("%s%s" % (path1, "*.radio"))
  VVdLtF.append("%s%s" % (path1, "*list"))
  VVdLtF.append("%s%s" % (path1, "lamedb*"))
  VVdLtF.append("%s%s" % (path2, "*.xml"))
  FFDcWB(self, VVdLtF, "channels_backup", addTimeStamp=True)
 def VVtt7s(self):
  VVdLtF = []
  VVdLtF.append("/etc/tuxbox/config/")
  VVdLtF.append("/usr/keys/")
  VVdLtF.append("/usr/scam/")
  VVdLtF.append("/etc/CCcam.cfg")
  FFDcWB(self, VVdLtF, "softcam_backup", addTimeStamp=True)
 def VVcSex(self):
  VVdLtF = []
  VVdLtF.append("/etc/hostname")
  VVdLtF.append("/etc/default_gw")
  VVdLtF.append("/etc/resolv.conf")
  VVdLtF.append("/etc/wpa_supplicant*.conf")
  VVdLtF.append("/etc/network/interfaces")
  VVdLtF.append("/etc/enigma2/nameserversdns.conf")
  FFDcWB(self, VVdLtF, "network_backup", addTimeStamp=True)
 def VVTGvf(self, fileName=None):
  if fileName:
   FFAIFY(self, BF(self.VVR1g0, fileName), "Overwrite current channels ?")
 def VVR1g0(self, fileName):
  path = "%s%s" % (VVIlHj, fileName)
  if fileExists(path):
   VVF53i , VVYPWl = CCcNAu.VVoOKN()
   VVEE4d, VVKsFP = CCcNAu.VVWX2f()
   cmd = ""
   cmd += FFIwml("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFIwml("rm -f %s %s" % (VVYPWl, VVKsFP)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFSZ2d()
   if res == 0 : FF9xND(self, "Channels Restored.")
   else  : FFc8qc(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFJJSt(self, path)
 def VVAVZB(self, fileName=None):
  if fileName:
   FFAIFY(self, BF(self.VVYAps, fileName), "Overwrite SoftCAM files ?")
 def VVYAps(self, fileName):
  fileName = "%s%s" % (VVIlHj, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVsYfD
   note = "You may need to restart your SoftCAM."
   FF1gYG(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFugQf(note, VV8mIi), sep))
  else:
   FFJJSt(self, fileName)
 def VV2yp0(self, fileName=None):
  if fileName:
   FFAIFY(self, BF(self.VV4YVo, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VV4YVo(self, fileName):
  fileName = "%s%s" % (VVIlHj, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFjX9J(self,  cmd)
  else:
   FFJJSt(self, fileName)
 def VVNfCL(self, pattern, callBackFunction, isTuner=False):
  title = FFvK43()
  if pathExists(VVIlHj):
   myFiles = iGlob("%s%s" % (VVIlHj, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVdLtF = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVdLtF.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VV6cmu = ("Sat. List", self.VVoK5J)
    else  : VV6cmu = None
    VVPpN9 = ("Delete File", self.VVpJ0L)
    FF0km9(self, callBackFunction, title=title, VVJtuN=VVdLtF, VV6cmu=VV6cmu, VVPpN9=VVPpN9)
   else:
    FFc8qc(self, "No files found in:\n\n%s" % VVIlHj, title)
  else:
   FFc8qc(self, "Path not found:\n\n%s" % VVIlHj, title)
 def VVpJ0L(self, VVnkBoObj, path):
  FFAIFY(self, BF(self.VVWGfO, VVnkBoObj, path), "Delete this file ?\n\n%s" % path)
 def VVWGfO(self, VVnkBoObj, path):
  path = VVIlHj + path
  os.system(FFIwml("rm -f '%s'" % path))
  if fileExists(path) : FFlDiQ(VVnkBoObj, "Not deleted", 1000)
  else    : VVnkBoObj.VVd12k()
 def VVAbrT(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCbhqA()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), BF(self.VVUsVz, filePrefix))
 def VVUsVz(self, filePrefix, result, retval):
  title = FFvK43()
  if pathExists(VVIlHj):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFc8qc(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVIlHj, filePrefix, FFSGFz())
    try:
     VVdLtF = str(result.strip()).split()
     if VVdLtF:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVdLtF:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVsYfD, FF0IFC(fName, VV8mIi), VVsYfD)
       FFPt7a(self, txt, title=title, VV0vZt=VVhZGE)
      else:
       FFc8qc(self, "File creation failed!", title)
     else:
      FFc8qc(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFIwml("rm %s" % fName))
     FFc8qc(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFIwml("rm %s" % fName))
     FFc8qc(self, "Error while writing file.")
  else:
   FFc8qc(self, "Path not found:\n\n%s" % VVIlHj, title)
 def VVWpr6(self, mode, path=None):
  if path:
   path = "%s%s" % (VVIlHj, path)
   if fileExists(path):
    lines = FFNoK6(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFAIFY(self, BF(self.VVhXQP, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFmT9W(self, path, title=FFvK43())
   else:
    FFJJSt(self, path)
 def VVhXQP(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVU7IO = []
  VVU7IO.append("echo -e 'Reading current settings ...'")
  VVU7IO.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVU7IO.append("echo -e 'Preparing new settings ...'")
  VVU7IO.append(settingsLines)
  VVU7IO.append("echo -e 'Applying new settings ...'")
  VVU7IO.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFSBxT(self, VVU7IO)
 def VVoK5J(self, VVnkBoObj, path):
  if not path:
   return
  path = VVIlHj + path
  if not fileExists(path):
   FFJJSt(self, path)
   return
  txt = FFt4Zg(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVdLtF  = []
   for item in satList:
    VVdLtF.append("%s\t%s" % (item[0], FF7DLp(item[1])))
   FFPt7a(self, VVdLtF, title="  Satellites List")
  else:
   FFc8qc(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCCzDl(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFi9TE(VVavIl, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVJtuN = []
  VVJtuN.append(("Plugins Browser List"       , "VVrtuj"   ))
  VVJtuN.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVJtuN.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVJtuN.append(("Remove Packages (show all)"     , "VVmpr4sAll"   ))
  VVJtuN.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Update List of Available Packages"   , "VVbLxL"   ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Packaging Tool"        , "VVmDf4"    ))
  VVJtuN.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFRqJR(self, VVJtuN=VVJtuN)
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FF7a1g(self["myMenu"])
  FFvDVP(self)
 def VVlQQ7(self):
  global VV7k9C
  VV7k9C = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVrtuj"   : self.VVrtuj()
   elif item == "pluginsMenus"     : self.VVQDGR(0)
   elif item == "pluginsStartup"    : self.VVQDGR(1)
   elif item == "pluginsDirList"    : self.VVIbRg()
   elif item == "downloadInstallPackages"  : FFItMF(self, BF(self.VVr1G5, 0, ""))
   elif item == "VVmpr4sAll"   : FFItMF(self, BF(self.VVr1G5, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFItMF(self, BF(self.VVr1G5, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVbLxL"   : self.VVbLxL()
   elif item == "VVmDf4"    : self.VVmDf4()
   elif item == "packagesFeeds"    : self.VVdG1h()
   else          : self.close()
 def VVIbRg(self):
  extDirs  = FFuI41(VVDwGq)
  sysDirs  = FFuI41(VVuZTi)
  VVdLtF  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVdLtF.append((item, VVDwGq + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVdLtF.append((item, VVuZTi + item))
  if VVdLtF:
   VVdLtF = sorted(VVdLtF, key=lambda x: x[0].lower())
   VVgDsk = ("Package Info.", self.VV8mMu, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFBL02(self, None, header=header, VVdLtF=VVdLtF, VVGpzZ=widths, VVYOiV=28, VVgDsk=VVgDsk)
  else:
   FFc8qc(self, "Nothing found!")
 def VV8mMu(self, VV57kA, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVDwGq) : loc = "extensions"
  elif path.startswith(VVuZTi) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVyDIf(package)
  else:
   FFc8qc(self, "No info!")
 def VVdG1h(self):
  pkg = FFMkdO()
  if pkg : FFsu1t(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFa4IH(self)
 def VVrtuj(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVxcQr(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVsYfD + "\n"
    txt += VVxcQr("Number"   , str(c))
    txt += VVxcQr("Name"   , FF0IFC(str(p.name), VV8mIi))
    txt += VVxcQr("Path"  , p.path  )
    txt += VVxcQr("Description" , p.description )
    txt += VVxcQr("Icon"  , p.iconstr  )
    txt += VVxcQr("Wakeup Fnc" , p.wakeupfnc )
    txt += VVxcQr("NeedsRestart", p.needsRestart)
    txt += VVxcQr("Internal" , p.internal )
    txt += VVxcQr("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFPt7a(self, txt)
 def VVQDGR(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVdLtF = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVdLtF.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVdLtF:
   VVdLtF.sort(key=lambda x: x[0].lower())
   header  = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths  = (19  , 25 , 20  , 27   , 9  )
   FFBL02(self, None, title=title, header=header, VVdLtF=VVdLtF, VVGpzZ=widths, VVYOiV=26)
  else:
   FFc8qc(self, "Nothing Found", title=title)
 def VVbLxL(self):
  cmd = FFVZA6(VVjUDZ, "")
  if cmd : FFjX9J(self, cmd, checkNetAccess=True)
  else : FFa4IH(self)
 def VVmDf4(self):
  pkg = FFMkdO()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FF9xND(self, txt)
 def VVr1G5(self, mode, grep, VV57kA=None, title=""):
  if   mode == 0: cmd = FFVZA6(VVf6AS    , grep)
  elif mode == 1: cmd = FFVZA6(VVWA2P , grep)
  elif mode == 2: cmd = FFVZA6(VVWA2P , grep)
  if not cmd:
   FFa4IH(self)
   return
  VVMDmE = FFOAMF(cmd)
  if not VVMDmE:
   if VV57kA: VV57kA.VVDvRR()
   FFc8qc(self, "No packages found!")
   return
  elif len(VVMDmE) == 1 and VVMDmE[0] == VVBIfo:
   FFc8qc(self, VVBIfo)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVdLtF  = []
  for item in VVMDmE:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVdLtF.append((name, package, version))
  if mode > 0:
   extensions = FFOAMF("ls %s -l | grep '^d' | awk '{print $9}'" % VVDwGq)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVdLtF:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVdLtF.append((name, VVDwGq + item, "-"))
   systemPlugins = FFOAMF("ls %s -l | grep '^d' | awk '{print $9}'" % VVuZTi)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVdLtF:
      if item.lower() == row[0].lower():
       break
     else:
      VVdLtF.append((item, VVuZTi + item, "-"))
  if not VVdLtF:
   FFc8qc(self, "No packages found!")
   return
  if VV57kA:
   VVdLtF.sort(key=lambda x: x[0].lower())
   VV57kA.VV3aGD(VVdLtF, title)
  else:
   widths = (20, 50, 30)
   VVieK7 = None
   VVS9I3 = None
   if mode == 0:
    VV39uD = ("Install" , self.VVRv0u   , [])
    VVieK7 = ("Download" , self.VVpTlF   , [])
    VVS9I3 = ("Filter"  , self.VVDvxB , [])
   elif mode == 1:
    VV39uD = ("Uninstall", self.VVmpr4, [])
   elif mode == 2:
    VV39uD = ("Uninstall", self.VVmpr4, [])
    widths= (18, 57, 25)
   VVdLtF = sorted(VVdLtF, key=lambda x: x[0].lower())
   VVgDsk = ("Package Info.", self.VVHBxu, [])
   header   = ("Name" ,"Package" , "Version" )
   FFBL02(self, None, header=header, VVdLtF=VVdLtF, VVGpzZ=widths, VVYOiV=28, VV39uD=VV39uD, VVieK7=VVieK7, VVgDsk=VVgDsk, VVS9I3=VVS9I3, VVKO9Z=self.lastSelectedRow
     , VV5mP6="#22110011", VVqjLk="#22191111", VVspm3="#22191111", VVANti="#00003030", VVxA4o="#00333333")
 def VVHBxu(self, VV57kA, title, txt, colList):
  package = colList[1]
  self.VVyDIf(package)
 def VVDvxB(self, VV57kA, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVJtuN = []
  VVJtuN.append(("All Packages", "all"))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVJtuN.append(VVImCt)
  for word in words:
   VVJtuN.append((word, word))
  FF0km9(self, BF(self.VVKZMf, VV57kA), VVJtuN=VVJtuN, title="Select Filter")
 def VVKZMf(self, VV57kA, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFItMF(VV57kA, BF(self.VVr1G5, 0, grep, VV57kA, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVmpr4(self, VV57kA, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVDwGq, VVuZTi)):
   FFAIFY(self, BF(self.VVOQAk, VV57kA, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVJtuN = []
   VVJtuN.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVJtuN.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVJtuN.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FF0km9(self, BF(self.VVIrNu, VV57kA, package), VVJtuN=VVJtuN)
 def VVOQAk(self, VV57kA, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVPbWU)
  FFjX9J(self, cmd, VVxGmB=BF(self.VVlJyk, VV57kA))
 def VVIrNu(self, VV57kA, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VV6aGr
   elif item == "remove_ForceRemove"  : cmdOpt = VVHK5M
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVuLC7
   FFAIFY(self, BF(self.VV772C, VV57kA, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VV772C(self, VV57kA, package, cmdOpt):
  self.lastSelectedRow = VV57kA.VVCvzs()
  cmd = FFxvW9(cmdOpt, package)
  if cmd : FFjX9J(self, cmd, VVxGmB=BF(self.VVlJyk, VV57kA))
  else : FFa4IH(self)
 def VVlJyk(self, VV57kA):
  VV57kA.cancel()
  FFBV8r()
 def VVRv0u(self, VV57kA, title, txt, colList):
  package  = colList[1]
  VVJtuN = []
  VVJtuN.append(("Install Package"         , "install_CheckVersion" ))
  VVJtuN.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVJtuN.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VVJtuN.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVJtuN.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FF0km9(self, BF(self.VVivrn, package), VVJtuN=VVJtuN)
 def VVivrn(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVKMZF
   elif item == "install_ForceReinstall" : cmdOpt = VVuITN
   elif item == "install_ForceOverwrite" : cmdOpt = VVELFq
   elif item == "install_ForceDowngrade" : cmdOpt = VVgb0U
   elif item == "install_IgnoreDepends" : cmdOpt = VVsXhK
   FFAIFY(self, BF(self.VVRt79, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVRt79(self, package, cmdOpt):
  cmd = FFxvW9(cmdOpt, package)
  if cmd : FFjX9J(self, cmd, VVxGmB=FFBV8r, checkNetAccess=True)
  else : FFa4IH(self)
 def VVpTlF(self, VV57kA, title, txt, colList):
  package  = colList[1]
  FFAIFY(self, BF(self.VVHuMk, package), "Download Package ?\n\n%s" % package)
 def VVHuMk(self, package):
  if FFSTMp():
   cmd = FFxvW9(VVh7ay, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFugQf(success, VV9pCx))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFugQf(fail, VV0wBB))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFjX9J(self, cmd, VVLZXz=[VV0wBB, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFa4IH(self)
  else:
   FFc8qc(self, "No internet connection !")
 def VVyDIf(self, package):
  infoCmd  = FFxvW9(VVoEPD, package)
  filesCmd = FFxvW9(VVEHDi, package)
  listInstCmd = FFVZA6(VVWA2P, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFWnKF(VV8mIi)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFugQf(notInst, VVyU04))
   cmd += "else "
   cmd +=   FFnHBa("System Info", VV8mIi)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFnHBa("Related Files", VV8mIi)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFGZGa(self, cmd)
  else:
   FFa4IH(self)
class CCcNAu(Screen):
 VVePGd  = 0
 VVGkDF = 1
 VVCf0R  = 2
 VV0UDY  = 3
 VVTCFS = 4
 VVL1Rg = 5
 VV3QVo = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFi9TE(VVavIl, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVbi9v = None
  self.lastfilterUsed  = None
  VVJtuN = self.VVleUX()
  FFRqJR(self, VVJtuN=VVJtuN, title="Services/Channels")
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self["myMenu"].setList(self.VVleUX())
  FF7a1g(self["myMenu"])
  FFvDVP(self)
 def VVleUX(self):
  VVJtuN = []
  VVJtuN.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VVJtuN.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Services (Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVJtuN.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVJtuN.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVJtuN.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVJtuN.append(("Services with PIcons for the System"  , "VVHMNQ"     ))
  VVJtuN.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVJtuN.append(VVImCt)
  VVF53i, VVYPWl = CCcNAu.VVoOKN()
  if fileExists(VVF53i):
   if fileExists(VVYPWl):
    VVJtuN.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVJtuN.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVJtuN.append(("Reset Parental Control Settings"   , "VVuaPz"    ))
  VVJtuN.append(("Delete Channels with no names"   , "VVq2ej"    ))
  VVJtuN.append(('Export Services to "channels.xml"'  , "VVU7OP"      ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Reload Channels and Bouquets"    , "VVB9bb"      ))
  return VVJtuN
 def VVlQQ7(self):
  global VV7k9C
  VV7k9C = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFYJSt(self)
   elif item == "currentServiceInfo"     : FFsVRo(self, fncMode=CCSQQx.VVBt5O)
   elif item == "TranspondersStats"     : FFItMF(self, self.VVgtOy     )
   elif item == "lameDB_allChannels_with_refCode"  : FFItMF(self, self.VVbFrv )
   elif item == "lameDB_allChannels_with_tranaponder" : FFItMF(self, self.VVsI5h)
   elif item == "lameDB_allChannels_with_details"  : FFItMF(self, self.VVlQXz )
   elif item == "parentalControlChannels"    : FFItMF(self, self.VV0CEe   )
   elif item == "showHiddenChannels"     : FFItMF(self, self.VVFIMe     )
   elif item == "VVHMNQ"     : FFItMF(self, self.VVLbW1     )
   elif item == "servicesWithMissingPIcons"   : FFItMF(self, self.VVW9QC   )
   elif item == "enableHiddenChannels"     : self.VVhPbw(True)
   elif item == "disableHiddenChannels"    : self.VVhPbw(False)
   elif item == "VVuaPz"    : FFAIFY(self, self.VVuaPz, "Reset and Restart ?" )
   elif item == "VVq2ej"    : FFItMF(self, self.VVq2ej)
   elif item == "VVU7OP"      : self.VVU7OP()
   elif item == "VVB9bb"      : FFItMF(self, BF(CCcNAu.VVB9bb, self))
   else            : self.close()
 def VVU7OP(self):
  VVJtuN = []
  VVJtuN.append(("All Sat/C/T Services", "all"))
  VVJtuN.append(("--[ BOUQUETS ]" + "-" * 100, ))
  bouquets = FFKD9U()
  if bouquets:
   for item in bouquets:
    VVJtuN.append((item[0], item[1].toString()))
  FF0km9(self, self.VVK3vC, VVJtuN=VVJtuN, title="", VVz4LU=True)
 def VVK3vC(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCcNAu.VVQCf1("1:7:")
   else   : lst = FFpZCL(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFbHaq(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFgKj2(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FFPG8X(CFG.exportedTablesPath.getValue()), FFSGFz())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FF9xND(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFlDiQ(self, "No Services found !", 1500)
 @staticmethod
 def VVB9bb(SELF):
  FFSZ2d()
  FF9xND(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVbFrv(self):
  self.VVbi9v = None
  self.lastfilterUsed  = None
  self.filterObj   = CCfaXJ(self)
  VVMDmE, err = CCcNAu.VVRQtF(self, self.VVePGd)
  if VVMDmE:
   VVMDmE.sort(key=lambda x: x[0].lower())
   VVW0bm  = ("Zap"   , self.VVOofJ     , [])
   VVMg98 = (""    , self.VVgwcn   , [])
   VVgDsk = ("Options"  , self.VVJ0Ev , [])
   VVieK7 = ("Current Service", self.VV96l3 , [])
   VVS9I3 = ("Filter"   , self.VVVDum  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVQQbo  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFBL02(self, None, header=header, VVdLtF=VVMDmE, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=26, VVW0bm=VVW0bm, VVMg98=VVMg98, VVieK7=VVieK7, VVgDsk=VVgDsk, VVS9I3=VVS9I3)
 def VVsI5h(self):
  self.VVbi9v = None
  self.lastfilterUsed  = None
  self.filterObj   = CCfaXJ(self)
  VVMDmE, err = CCcNAu.VVRQtF(self, self.VVGkDF)
  if VVMDmE:
   VVMDmE.sort(key=lambda x: x[0].lower())
   VVW0bm  = ("Zap"   , self.VVOofJ      , [])
   VVMg98 = (""    , self.VVgwcn    , [])
   VVieK7 = ("Current Service", self.VV96l3  , [])
   VVgDsk = ("Options"  , self.VVNttb , [])
   VVS9I3 = ("Filter"   , self.VVw3u0  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVQQbo  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFBL02(self, None, header=header, VVdLtF=VVMDmE, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=26, VVW0bm=VVW0bm, VVMg98=VVMg98, VVieK7=VVieK7, VVgDsk=VVgDsk, VVS9I3=VVS9I3)
 def VVJ0Ev(self, VV57kA, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel  = CCZSNQ(self, VV57kA, 3)
  mSel.VV8p3R(servName, refCode, pcState, hidState)
 def VVNttb(self, VV57kA, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CCZSNQ(self, VV57kA, 3)
  mSel.VVloYE(servName, refCode)
 def VVJg53(self, VV57kA, refCode, isAddToBlackList):
  VV57kA.VVfaYe("Processing ...")
  FF1Gz0(BF(self.VVHRD4, VV57kA, [refCode], isAddToBlackList))
 def VVaQbo(self, VV57kA, isAddToBlackList):
  refCodeList = VV57kA.VVlTiC(3)
  if not refCodeList:
   FFc8qc(self, "Nothing selected", title="Change Parental-Control State")
   return
  VV57kA.VVfaYe("Processing ...")
  FF1Gz0(BF(self.VVHRD4, VV57kA, refCodeList, isAddToBlackList))
 def VVHRD4(self, VV57kA, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVLwHd, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVLwHd):
   lines = FFNoK6(VVLwHd)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVLwHd, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VV57kA.VVdcxd
   if isMulti:
    self.VVkbn8(VV57kA, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VV4b84(VV57kA, refCode)
    VV57kA.VVDvRR()
  else:
   VV57kA.VVAlHG("No changes")
 def VVd0Gz(self, VV57kA, refCode, isHide):
  title = "Change Hidden State"
  if FFmFUH(refCode):
   VV57kA.VVfaYe("Processing ...")
   ret = FFEWxD(refCode, isHide)
   if ret : FFItMF(self, BF(self.VV4b84, VV57kA, refCode))
   else : FFc8qc(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFc8qc(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VV4b84(self, VV57kA, refCode):
  VVMDmE, err = CCcNAu.VVRQtF(self, self.VVePGd, VVW1ph=[3, [refCode], False])
  done = False
  if VVMDmE:
   data = VVMDmE[0]
   if data[3] == refCode:
    done = VV57kA.VVe4HT(data)
  if not done:
   self.VVDHGk(VV57kA, VV57kA.VVsZfG(), self.VVePGd)
  VV57kA.VVDvRR()
 def VVkbn8(self, VV57kA, totRefCodes):
  VVMDmE, err = CCcNAu.VVRQtF(self, self.VVePGd, VVW1ph=self.VVbi9v)
  VV57kA.VV3aGD(VVMDmE)
  VV57kA.VVK3X1(False)
  VV57kA.VVAlHG("%d Processed" % totRefCodes)
 def VVtepu(self, VV57kA, isHide):
  refCodeList = VV57kA.VVlTiC(3)
  if not refCodeList:
   FFc8qc(self, "Nothing selected", title="Change Hidden State")
   return
  VV57kA.VVfaYe("Processing ...")
  FF1Gz0(BF(self.VV8ZUL, VV57kA, refCodeList, isHide))
 def VV8ZUL(self, VV57kA, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFEWxD(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   db = eDVBDB.getInstance()
   if db:
    db.saveServicelist()
    db.reloadServicelist()
    db.reloadBouquets()
   self.VVkbn8(VV57kA, len(refCodeList))
  else:
   VV57kA.VVAlHG("No changes")
 def VVVDum(self, VV57kA, title, txt, colList):
  self.filterObj.VVypCr(1, VV57kA, 2, BF(self.VVOn2t, VV57kA))
 def VVOn2t(self, VV57kA, item):
  self.VVsxwI(VV57kA, item, 2, self.VVePGd)
 def VVw3u0(self, VV57kA, title, txt, colList):
  self.filterObj.VVypCr(2, VV57kA, 4, BF(self.VV7Sb7, VV57kA))
 def VV7Sb7(self, VV57kA, item):
  self.VVsxwI(VV57kA, item, 4, self.VVGkDF)
 def VVZj24(self, VV57kA, title, txt, colList):
  self.filterObj.VVypCr(0, VV57kA, 4, BF(self.VVZMch, VV57kA))
 def VVZMch(self, VV57kA, item):
  self.VVsxwI(VV57kA, item, 4, self.VVCf0R)
 def VVsxwI(self, VV57kA, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VV57kA.VVIrRe(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVbi9v = None
  else:
   words, asPrefix = CCfaXJ.VVIvS9(words)
   self.VVbi9v = [col, words, asPrefix]
  if words: FFItMF(self, BF(self.VVDHGk, VV57kA, title, mode), title="Reading Services ...")
  else : FFlDiQ(VV57kA, "Incorrect filter", 2000)
 def VVDHGk(self, VV57kA, title, mode):
  VVMDmE, err = CCcNAu.VVRQtF(self, mode, VVW1ph=self.VVbi9v, VVs2Ke=False)
  if VVMDmE:
   VVMDmE.sort(key=lambda x: x[0].lower())
   VV57kA.VV3aGD(VVMDmE, title)
  else:
   VV57kA.VVDvRR()
   FFlDiQ(VV57kA, "Not found!", 1500)
 def VV1uem(self, VVdLtF, VVW0bm=None, VVMg98=None, VV39uD=None, VVieK7=None, VVgDsk=None, VVS9I3=None):
  VVieK7 = ("Current Service", self.VV96l3, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVQQbo = (LEFT  , LEFT  , CENTER, LEFT    )
  FFBL02(self, None, header=header, VVdLtF=VVdLtF, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=26, VVW0bm=VVW0bm, VVMg98=VVMg98, VV39uD=VV39uD, VVieK7=VVieK7, VVgDsk=VVgDsk, VVS9I3=VVS9I3)
 def VV96l3(self, VV57kA, title, txt, colList):
  self.VV1Jbo(VV57kA)
 def VVtH2e(self, VV57kA, title, txt, colList):
  self.VV1Jbo(VV57kA, True)
 def VV1Jbo(self, VV57kA, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VV57kA.VVaOZN(colDict, VV5kIx=True)
   else:
    VV57kA.VVYHYY(3, refCode, True)
   return
  FFc8qc(self, "Colud not read current Reference Code !")
 def VVlQXz(self):
  self.VVbi9v = None
  self.lastfilterUsed  = None
  self.filterObj   = CCfaXJ(self)
  VVMDmE, err = CCcNAu.VVRQtF(self, self.VVCf0R)
  if VVMDmE:
   VVMDmE.sort(key=lambda x: x[0].lower())
   VVMg98 = (""    , self.VVSCx4 , []      )
   VVieK7 = ("Current Service", self.VVtH2e  , []      )
   VVS9I3 = ("Filter"   , self.VVZj24   , [], "Loading Filters ..." )
   VVW0bm  = ("Zap"   , self.VVoOZc      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVQQbo  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFBL02(self, None, header=header, VVdLtF=VVMDmE, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=26, VVW0bm=VVW0bm, VVMg98=VVMg98, VVieK7=VVieK7, VVS9I3=VVS9I3)
 def VVSCx4(self, VV57kA, title, txt, colList):
  refCode  = self.VVz5G6(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFsVRo(self, fncMode=CCSQQx.VVKpAq, refCode=refCode, chName=chName, text=txt)
 def VVoOZc(self, VV57kA, title, txt, colList):
  refCode = self.VVz5G6(colList)
  FFTrMq(self, refCode)
 def VVOofJ(self, VV57kA, title, txt, colList):
  FFTrMq(self, colList[3])
 def VVz5G6(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVRQtF(SELF, mode, VVW1ph=None, VVs2Ke=True, VV1LYo=True):
  VVF53i, err = CCcNAu.VV1exK(SELF, VV1LYo)
  if err:
   return None, err
  asPrefix = False
  if VVW1ph:
   filterCol = VVW1ph[0]
   filterWords = VVW1ph[1]
   asPrefix = VVW1ph[2]
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCcNAu.VVePGd:
   blackList = None
   if fileExists(VVLwHd):
    blackList = FFNoK6(VVLwHd)
    if blackList:
     blackList = set(blackList)
  elif mode == CCcNAu.VVGkDF:
   tp = CCMZhh()
  VVQUG0, VVCEke = FFlQ76()
  tagFound  = False
  if mode in (CCcNAu.VVL1Rg, CCcNAu.VV3QVo):
   VVMDmE = {}
  else:
   VVMDmE = []
  with ioOpen(VVF53i, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = " ?"
      if len(chProv) == 0 : chProv = " ?"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FFIWN7(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCcNAu.VVCf0R:
       if sTypeInt in VVQUG0:
        STYPE = VVCEke[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVMDmE.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVMDmE.append(tRow)
       else:
        VVMDmE.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCcNAu.VVL1Rg:
        VVMDmE[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCcNAu.VV3QVo:
        VVMDmE[chName] = refCode
       elif mode == CCcNAu.VVePGd:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVMDmE.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVMDmE.append(tRow)
        else:
         VVMDmE.append(tRow)
       elif mode == CCcNAu.VVGkDF:
        if sTypeInt in VVQUG0:
         STYPE = VVCEke[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVgTRT(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVMDmE.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVMDmE.append(tRow)
        else:
         VVMDmE.append(tRow)
       elif mode == CCcNAu.VV0UDY:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVMDmE.append((chName, chProv, sat, refCode))
       elif mode == CCcNAu.VVTCFS:
        VVMDmE.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVMDmE and VVs2Ke:
   FFc8qc(SELF, "No services found!")
  return VVMDmE, ""
 def VV0CEe(self):
  if fileExists(VVLwHd):
   lines = FFNoK6(VVLwHd)
   if lines:
    newRows = []
    VVMDmE, err = CCcNAu.VVRQtF(self, self.VVTCFS)
    if VVMDmE:
     lines = set(lines)
     for item in VVMDmE:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVMDmE = newRows
      VVMDmE.sort(key=lambda x: x[0].lower())
      VVMg98 = ("", self.VVgwcn, [])
      VVW0bm = ("Zap", self.VVOofJ, [])
      self.VV1uem(VVdLtF=VVMDmE, VVW0bm=VVW0bm, VVMg98=VVMg98)
     else:
      FFPt7a(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVMDmE)))
   else:
    FF9xND(self, "No active Parental Control services.", FFvK43())
  else:
   FFJJSt(self, VVLwHd)
 def VVFIMe(self):
  VVMDmE, err = CCcNAu.VVRQtF(self, self.VV0UDY)
  if VVMDmE:
   VVMDmE.sort(key=lambda x: x[0].lower())
   VVMg98 = ("" , self.VVgwcn, [])
   VVW0bm  = ("Zap", self.VVOofJ, [])
   self.VV1uem(VVdLtF=VVMDmE, VVW0bm=VVW0bm, VVMg98=VVMg98)
  elif err:
   pass
  else:
   FF9xND(self, "No hidden services.", FFvK43())
 def VVgtOy(self):
  VVF53i, err = CCcNAu.VV1exK(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VVKU55(VVF53i)
  txt = FF0IFC("Total Transponders:\n\n", VVumHI)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FF0IFC("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVumHI)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFI2fS(item), satList.count(item))
  FFPt7a(self, txt)
 def VVKU55(self, VVF53i):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VVF53i, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVLbW1(self)   : self.VVHMNQ(True)
 def VVW9QC(self) : self.VVHMNQ(False)
 def VVHMNQ(self, isWithPIcons):
  piconsPath = CC2T9T.VVP17o()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CC2T9T.VVkxJK(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVMDmE, err = CCcNAu.VVRQtF(self, self.VVTCFS)
    if VVMDmE:
     channels = []
     for (chName, chProv, sat, refCode) in VVMDmE:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFunIf(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVMDmE)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVxcQr(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVxcQr("PIcons Path"  , piconsPath)
     txt += VVxcQr("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVxcQr("Total services" , totalServices)
     txt += VVxcQr("With PIcons"  , totalWithPIcons)
     txt += VVxcQr("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFPt7a(self, txt)
     else:
      VVMg98     = (""      , self.VVgwcn , [])
      if isWithPIcons : VVS9I3 = ("Export Current PIcon", self.VV2IiJ  , [])
      else   : VVS9I3 = None
      VVgDsk     = ("Statistics", FFPt7a, [txt])
      VVW0bm      = ("Zap", self.VVOofJ, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VV1uem(VVdLtF=channels, VVW0bm=VVW0bm, VVMg98=VVMg98, VVgDsk=VVgDsk, VVS9I3=VVS9I3)
   else:
    FFc8qc(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFc8qc(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVgwcn(self, VV57kA, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFsVRo(self, fncMode=CCSQQx.VVKpAq, refCode=refCode, chName=chName, text=txt)
 def VV2IiJ(self, VV57kA, title, txt, colList):
  png, path = CC2T9T.VVFZPz(colList[3], colList[0])
  if path:
   CC2T9T.VV3sOf(self, png, path)
 @staticmethod
 def VVoOKN():
  VVF53i  = "/etc/enigma2/lamedb"
  VVYPWl = "/etc/enigma2/lamedb.disabled"
  return VVF53i, VVYPWl
 @staticmethod
 def VVWX2f():
  VVEE4d  = "/etc/enigma2/lamedb5"
  VVKsFP = "/etc/enigma2/lamedb5.disabled"
  return VVEE4d, VVKsFP
 def VVhPbw(self, isEnable):
  VVF53i, VVYPWl = CCcNAu.VVoOKN()
  if isEnable and not fileExists(VVYPWl):
   FF9xND(self, "Aready enabled.")
  elif not isEnable and not fileExists(VVF53i):
   FFc8qc(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFAIFY(self, BF(self.VVUd9D, isEnable), "%s Hidden Channels ?" % word)
 def VVUd9D(self, isEnable):
  VVF53i , VVYPWl = CCcNAu.VVoOKN()
  VVEE4d, VVKsFP = CCcNAu.VVWX2f()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVYPWl, VVYPWl, VVF53i)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVKsFP, VVKsFP, VVEE4d)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (VVF53i  , VVF53i , VVYPWl)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (VVEE4d , VVEE4d, VVKsFP)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVYPWl, VVF53i )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVKsFP, VVEE4d)
  res = os.system(cmd)
  FFSZ2d()
  if res == 0 : FF9xND(self, "Hidden List %s" % word)
  else  : FFc8qc(self, "Error while restoring:\n\n%s" % fileName)
 def VVuaPz(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFSBxT(self, cmd)
 def VVq2ej(self):
  VVF53i, VVYPWl = CCcNAu.VVoOKN()
  if fileExists(VVF53i):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFIwml("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFNoK6(VVF53i, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFIwml("mv -f '%s' '%s'" % (tmpFile, VVF53i)))
   FFSZ2d()
   FFPt7a(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFJJSt(self, VVF53i)
 @staticmethod
 def VV1exK(SELF, VV1LYo=True):
  VVF53i, VVYPWl = CCcNAu.VVoOKN()
  if   not fileExists(VVF53i)   : err = "File not found !\n\n%s" % VVF53i
  elif not FF1PJc(SELF, VVF53i): err = "'lamedb' file is not in 'UTF-8' Encoding !\n\n%s" % VVF53i
  else         : err = ""
  if err and VV1LYo:
   FFc8qc(SELF, err)
  return VVF53i, err
 @staticmethod
 def VVQCf1(servTypes):
  VV6kmz  = eServiceCenter.getInstance()
  VVjM8v   = '%s ORDER BY name' % servTypes
  VV59Na   = eServiceReference(VVjM8v)
  VVG7CJ = VV6kmz.list(VV59Na)
  if VVG7CJ: return VVG7CJ.getContent("CN", False)
  else     : return []
class CCSQQx(Screen):
 VVBt5O  = 0
 VVF09E   = 1
 VVKqex   = 2
 VVKpAq    = 3
 VVXbSo    = 4
 VVpmbB   = 5
 VVRrXi   = 6
 VV9y9G    = 7
 VVHkWH   = 8
 VV9OPu   = 9
 VVoiHW   = 10
 VVGZow   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFi9TE(VVAK4W, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVBt5O)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FF0IFC("%s\n", VVPBk2) % VVsYfD
  self.picViewer  = None
  FFRqJR(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VV0QaO })
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVDpWe)
  self.onClose.append(self.onExit)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  self["myLabel"].VVfE6M(textOutFile="chann_info")
  if   self.fncMode == self.VVBt5O : fnc = self.VVasgs_VVBt5O
  elif self.fncMode == self.VVF09E  : fnc = self.VVasgs_VVBt5O
  elif self.fncMode == self.VVKqex  : fnc = self.VVasgs_VVBt5O
  elif self.fncMode == self.VVKpAq  : fnc = self.VVasgs_VVKpAq
  elif self.fncMode == self.VVXbSo  : fnc = self.VVasgs_VVXbSo
  elif self.fncMode == self.VVpmbB  : fnc = self.VVasgs_VVpmbB
  elif self.fncMode == self.VVRrXi  : fnc = self.VVasgs_VVRrXi
  elif self.fncMode == self.VV9y9G  : fnc = self.VVasgs_VV9y9G
  elif self.fncMode == self.VVHkWH  : fnc = self.VVasgs_VVHkWH
  elif self.fncMode == self.VV9OPu : fnc = self.VVasgs_VV9OPu
  elif self.fncMode == self.VVoiHW  : fnc = self.VVasgs_VVoiHW
  elif self.fncMode == self.VVGZow : fnc = self.VVasgs_VVGZow
  self["myLabel"].setText("\n   Reading Info ...")
  FF1Gz0(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VV7vT2()
 def VVY3U3(self, err):
  self["myLabel"].setText(err)
  FFLgZ9(self["myTitle"], "#22200000")
  FFLgZ9(self["myBody"], "#22200000")
  self["myLabel"].FFLgZ9Color("#22200000")
  self["myLabel"].VVivUS()
 def VVasgs_VVBt5O(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self)
  self.refCode = refCode
  self.VVO07A(chName)
 def VVasgs_VVKpAq(self):
  self.VVO07A(self.chName)
 def VVasgs_VVXbSo(self):
  self.VVO07A(self.chName)
 def VVasgs_VVpmbB(self):
  self.VVO07A(self.chName)
 def VVasgs_VVRrXi(self):
  self.VVO07A("Picon Info")
 def VVasgs_VV9y9G(self):
  self.VVO07A(self.chName)
 def VVasgs_VVHkWH(self):
  self.VVO07A(self.chName)
 def VVasgs_VV9OPu(self):
  self.VVO07A(self.chName)
 def VVasgs_VVoiHW(self):
  self.chUrl = self.refCode + self.callingSELF.VV9CRz(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVO07A(self.chName)
 def VVasgs_VVGZow(self):
  self.VVO07A(self.chName)
 def VVO07A(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFrHOu(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVFs82(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FF0IFC(self.VV2W7j(tUrl), VVkO2P)
  if not self.epg:
   epg = self.VV1bgA(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VViHPC(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CC2T9T.VVFZPz(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VViHPC(path)
  self.VVMZmv()
  self.VVGywj()
  self["myLabel"].setText(self.text, VV0vZt=VVXjVQ)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVivUS(minHeight=minH)
 def VVGywj(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFgKj2(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVvZGN(FFl4xc(url))
  if epg:
   self.text += "\n" + FFvvVG("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVMZmv()
 def VVMZmv(self):
  if not self.piconShown and self.picUrl:
   path, err = FFWvl5(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VViHPC(path)
    if self.piconShown and self.refCode:
     self.VVvTzn(path, self.refCode)
 def VVvTzn(self, path, refCode):
  if path and fileExists(path) and os.system(FFIwml("which ffmpeg")) == 0:
   pPath = CC2T9T.VVP17o()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
    cmd += FFIwml("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VViHPC(self, path):
  if path and fileExists(path):
   err, w, h = self.VV1Ddy(path)
   if not err:
    if h > w:
     self.VVaGp7(self["myPicF"], w, h, True)
     self.VVaGp7(self["myPic"] , w, h, False)
   self.picViewer = CCB5sW.VVxOsI(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVaGp7(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VV1Ddy(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FF8oWX(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVFs82(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FF0IFC(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVxcQr(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FF0IFC(state, VVyU04)
   txt += "State\t: %s\n" % state
  w = FFJ0c4(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFJ0c4(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVqAyL(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVxcQr(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVxcQr(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVxcQr(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVsy5I()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVJL5m()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCSQQx.VVFNfY(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FF0IFC("IPTV", VVumHI)
   txt += self.VVi7k8(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVmGaT(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCMZhh()
    tpTxt, namespace = tp.VV6lQn(refCode)
    del tp
    if tpTxt:
     txt += FF0IFC("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FF0IFC("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVxcQr(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVxcQr(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVxcQr(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVxcQr(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVxcQr(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVxcQr(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVxcQr(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVxcQr(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVxcQr(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVqAyL(info):
  if info:
   aspect = FFJ0c4(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVxcQr(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFJ0c4(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVWcAz(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVWcAz(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVsy5I(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VVJL5m(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVmGaT(self, refCode, iptvRef, chName):
  refCode = FFbKYW(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFt4Zg(VVR2Ml + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFt4Zg(VVR2Ml + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VVdLtF = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVR2Ml + item
   if fileExists(path):
    txt = FFt4Zg(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVdLtF.append(bName)
  txt = self.Sep
  if VVdLtF:
   if len(VVdLtF) == 1:
    txt += "%s\t: %s\n" % (FF0IFC("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VVdLtF[0])
   else:
    txt += FF0IFC("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VVdLtF):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VV1bgA(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVUKvO(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVUKvO(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVUKvO(event, 0)
     except:
      pass
  return epg
 def VVUKvO(self, event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCSQQx.VV9ycs(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = self.VViWUp(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FF0IFC(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FF0IFC(evNameTransl, COLOR_CONS_BRIGHT_YELLOW))
    if evTime           : txt += "Start Time\t: %s\n" % FFjsXk(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFjsXk(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FF2LS5(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FF2LS5(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FF2LS5(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FF0IFC(evShort, VVqImC)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FF0IFC(evDesc , VVqImC)
    if txt:
     txt = FF0IFC("\n%s\n%s Event:\n%s\n" % (VVsYfD, ("Current", "Next")[evNum], VVsYfD), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVi7k8(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFDfd9(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CC159n()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVX4e8(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FF0IFC("URL:", VVumHI) + "\n%s\n" % self.VV2W7j(decodedUrl)
  else:
   txt = "\n"
   txt += FF0IFC("Reference:", VVumHI) + "\n%s\n" % refCode
  return txt
 def VV2W7j(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVFrOP:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VVvZGN(self, decodedUrl):
  if not FFSTMp():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCUfgv.VVOsYy(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCUfgv.VVyKpQ(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVASeC(tDict)
   elif uType == "movie" : epg, picUrl = self.VV1eFk(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVASeC(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCUfgv.VVh28z(item, "title"    , is_base64=True )
     lang    = CCUfgv.VVh28z(item, "lang"         ).upper()
     description   = CCUfgv.VVh28z(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCUfgv.VVh28z(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCUfgv.VVh28z(item, "start_timestamp"      )
     stop_timestamp  = CCUfgv.VVh28z(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCUfgv.VVh28z(item, "stop_timestamp"       )
     now_playing   = CCUfgv.VVh28z(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVmG5f, ""
      else     : color, txt = VVyU04 , "    (CURRENT EVENT)"
      epg += FF0IFC("_" * 32 + "\n", VVPBk2)
      epg += FF0IFC("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FF0IFC(description, VVkO2P)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VV6yTh(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VV1eFk(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCUfgv.VVh28z(item, "movie_image" )
    genre  = CCUfgv.VVh28z(item, "genre"   ) or "-"
    plot  = CCUfgv.VVh28z(item, "plot"   ) or "-"
    cast  = CCUfgv.VVh28z(item, "cast"   ) or "-"
    rating  = CCUfgv.VVh28z(item, "rating"   ) or "-"
    director = CCUfgv.VVh28z(item, "director"  ) or "-"
    releasedate = CCUfgv.VVh28z(item, "releasedate" ) or "-"
    duration = CCUfgv.VVh28z(item, "duration"  ) or "-"
    try:
     lang = CCUfgv.VVh28z(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FF0IFC(cast, VVkO2P)
    epg += "Plot:\n%s"    % FF0IFC(self.VViWUp(plot), VVkO2P)
   except:
    pass
  return epg, movie_image
 def VViWUp(self, evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = self.VVA0CJ(evTxt, lang)
   return CCSQQx.VVWprr(txt).strip() or evTxt
 def VV0QaO(self):
  if VVFrOP:
   def VVxcQr(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVxcQr(n[i], v[i])
   if "chCode" in iptvRef:
    p = CC159n()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVX4e8(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVxcQr(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (VVsYfD, txt))
   FFlDiQ(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVWprr(txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VVrqW4(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CCSQQx.VV9ycs(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VV9ycs(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCSQQx.VVOpH8(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVA0CJ(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFsvs4(txt))
   txt, err = CCUfgv.VVyKpQ(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFl4xc(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VV6yTh(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
 @staticmethod
 def VVyUkt(SELF):
  if not CCycDZ.VV3e4i(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(SELF)
  err = url =  fSize = resumable = ""
  if FFHwNJ(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CC159n.VV9sR2(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CC159n.VVwzcSHeader(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FFc8qc(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCg2YR.VVBWem(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FF0IFC(" (M3U/M3U8 File)", VVkO2P)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCUd13.VVj3JV(resp) else "No"
   except requests.Timeout as e     : err = "Connection Timeout"
   except Exception as e       : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVzMl5(subj, val):
   return "%s\n%s\n\n" % (FF0IFC("%s:" % subj, COLOR_CONS_BRIGHT_YELLOW), val)
  title = "File Size"
  txt  = VVzMl5(title , fSize or "?")
  txt += VVzMl5("Name" , chName)
  txt += VVzMl5("URL" , url)
  if resumable: txt += VVzMl5("Supports Download-Resume", resumable)
  if err  : txt += FF0IFC("Error:\n", VVyU04) + err
  FFPt7a(SELF, txt, title=title)
 @staticmethod
 def VVFNfY(SELF):
  fPath, fDir, fName = CCg2YR.VV14bi(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg", "mvi"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVOpH8(event):
  genre = PR = ""
  try:
   genre  = CCSQQx.VVAUvO(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCSQQx.VVWW9M(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVWW9M(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVAUvO(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCSQQx.VVA15V()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVA15V():
  path = VVAquH + "genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFt4Zg(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFt4Zg(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
class CC159n():
 def __init__(self):
  self.VVvMdx   = ""
  self.VVMQC5    = ""
  self.VVrWpV   = ""
  self.VVPafd = ""
  self.VVm0I1  = ""
  self.VVsUMJ = 0
  self.VV3jUA    = ""
  self.VVztuX   = "#f#11ffffaa#User"
  self.VV4vjd   = "#f#11aaffff#Server"
 def VV8S7L(self, url, mac, ph1="", VV5kIx=True):
  self.VVvMdx   = ""
  self.VVMQC5    = ""
  self.VVrWpV   = ""
  self.VVPafd = ""
  self.VVm0I1  = ""
  self.VVsUMJ = 0
  self.VV3jUA    = {"s": "/server/load.php", "p": "/portal.php"}.get(ph1, "")
  host = self.VV6YSN(url)
  if not host:
   if VV5kIx:
    self.VV5kIxor("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVciW2(mac)
  if not host:
   if VV5kIx:
    self.VV5kIxor("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVvMdx = host
  self.VVMQC5  = mac
  return True
 def VV6YSN(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVciW2(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVtxDu(self):
  res, err = self.VVlsoO(self.VVj4T1())
  urlPath = "/stalker_portal"
  if "404" in err and urlPath in self.VVvMdx:
   self.VVvMdx = self.VVvMdx.replace(urlPath, "")
   res, err = self.VVlsoO(self.VVj4T1())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCUfgv.VVh28z(tDict["js"], "token")
    rand  = CCUfgv.VVh28z(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVpqcq(self, VV5kIx=True):
  if not self.VV3jUA:
   self.VV3jUA = self.VVQvka()
  err = blkMsg = FF9xNDTxt = ""
  try:
   token, rand, err = self.VVtxDu()
   if token:
    self.VVrWpV = token
    self.VVPafd = rand
    if rand:
     self.VVsUMJ = 2
    prof, retTxt = self.VV12dv(True)
    if prof:
     self.VVm0I1 = retTxt
     if "device_id mismatch" in retTxt:
      self.VVsUMJ = 3
      prof, retTxt = self.VV12dv(False)
      if retTxt:
       self.VVm0I1 = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FF9xNDTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FF9xNDTxt: tErr += "\n%s" % FF9xNDTxt
  if VV5kIx:
   self.VV5kIxor(tErr)
  return "", "", tErr
 def VVQvka(self):
  try:
   import requests
   res = requests.get("%s/c/xpcom.common.js" % self.VVvMdx, headers=CC159n.VVwzcSHeader(), stream=True, timeout=2)
   if res.ok :
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       return span.group(1)
  except:
   pass
  return ""
 def VV12dv(self, capMac):
  res, err = self.VVlsoO(self.VVXTSs(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCUfgv.VVh28z(tDict["js"], "block_%s" % word)
    FF9xNDTxt = CCUfgv.VVh28z(tDict["js"], word)
    return tDict, FF9xNDTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVXTSs(self, capMac):
  param = ""
  if self.VVm0I1 or self.VVPafd:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVMQC5.upper() if capMac else self.VVMQC5.lower(), self.VVPafd))
  return self.VVqtst() + "type=stb&action=get_profile" + param
 exec(FFwC08("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gID0gIiZhdXRoX3NlY29uZF9zdGVwPTEmaHdfdmVyc2lvbj0yLjE3LUlCLTAwJmh3X3ZlcnNpb25fMj02MiZzbj0lcyZkZXZpY2VfaWQ9JXMmZGV2aWNlX2lkMj0lcyZzaWduYXR1cmU9JXMiICUgKElkWzBdLCBJZFsxXSwgSWRbMV0sIElkWzJdKQ0KIHJldHVybiBwYXJhbSArICcmbWV0cmljcz17Im1hYyI6IiVzIiwic24iOiIlcyIsInR5cGUiOiJTVEIiLCJtb2RlbCI6Ik1BRzI1MCIsInJhbmRvbSI6IiVzIn0nICUgKElkWzNdLCBJZFswXSwgSWRbNF0pDQpkZWYgZ2V0TW9yZUF1dGhfSURzKHNlbGYsIG0sIHIpOg0KIGltcG9ydCBoYXNobGliDQogbWFjVXRmOCA9IG0uZW5jb2RlKCd1dGYtOCcpDQogcyA9IGhhc2hsaWIubWQ1KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKClbOjEzXQ0KIHJldHVybiBzLCBoYXNobGliLnNoYTI1NihtYWNVdGY4KS5oZXhkaWdlc3QoKS51cHBlcigpLCBoYXNobGliLnNoYTI1NigocyArIG0pLmVuY29kZSgndXRmLTgnKSkuaGV4ZGlnZXN0KCkudXBwZXIoKSwgbSwgcg=="))
 def VVJpSR(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVJhBV()
  if len(rows) < 10:
   rows = self.VVtPnx()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVvMdx ))
   rows.append(("MAC (from URL)" , self.VVMQC5 ))
   rows.append(("Token"   , self.VVrWpV ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VVztuX , "MAC"  , self.VVMQC5 ))
   rows.append(("2", self.VV4vjd, "Host" , self.VVvMdx ))
   rows.append(("2", self.VV4vjd, "Token" , self.VVrWpV ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVqZv3(self, isPhp=True, VV5kIx=False):
  token, profile, tErr = self.VVpqcq(VV5kIx)
  if not token:
   return "", tErr
  m3u_Url = ""
  url = self.VVMI9x()
  res, err = self.VVlsoO(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCUfgv.VVh28z(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFsvs4(span.group(2))
     pass1 = FFsvs4(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, err
 def VVJhBV(self):
  m3u_Url, err = self.VVqZv3()
  rows = []
  if m3u_Url:
   res, err = self.VVlsoO(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFjsXk(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VVztuX, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFjsXk(int(val))
      else      : val = str(val)
      rows.append(("2", self.VV4vjd, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVtPnx(self):
  token, profile, tErr = self.VVpqcq()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FF6SUc(val): val = FFwC08(val.decode("UTF-8"))
     else     : val = self.VVMQC5
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFjsXk(int(parts[1]))
      if parts[2] : ends = FFjsXk(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFjsXk(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VV9CRz(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVpqcq(VV5kIx=False)
  if not token:
   return ""
  crLinkUrl = self.VVhkns(mode, chCm, epNum, epId)
  res, err = self.VVlsoO(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCUfgv.VVh28z(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVqtst(self):
  return self.VVvMdx + (self.VV3jUA or "/server/load.php") + "?"
 def VVj4T1(self):
  return self.VVqtst() + "type=stb&action=handshake&token=&mac=%s" % self.VVMQC5
 def VVj5lv(self, mode):
  url = self.VVqtst() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVMXH5(self, catID):
  return self.VVqtst() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVBGLu(self, mode, catID, page):
  url = self.VVqtst() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VV4O7K(self, mode, searchName, page):
  return self.VVqtst() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VVM9vL(self, mode, catID):
  return self.VVqtst() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVhkns(self, mode, chCm, serCode, serId):
  url = self.VVqtst() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=false" % (mode, chCm)
  return url
 def VVMI9x(self):
  return self.VVqtst() + "type=itv&action=create_link"
 def VVhg1T(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVxbxd(catID, stID, chNum)
  query = self.VVevGA(mode, self.VV3jUA[1:2], FFkqA3(host), FFkqA3(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVevGA(self, mode, ph1, host, mac, serCode, serId, chCm):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVX4e8(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVevGA(mode, ph1, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFwC08(host)
  mac   = FFwC08(mac)
  valid = False
  if self.VV6YSN(playHost) and self.VV6YSN(host) and self.VV6YSN(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVlsoO(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CC159n.VVwzcSHeader()
   if self.VVrWpV:
    headers["Authorization"] = "Bearer %s" % self.VVrWpV
   if useCookies : cookies = {"mac": self.VVMQC5, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok :
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVqAwi(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CC159n.VVwzcSHeader(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVwzcSHeader():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVjTDo(host, mac, tType, action, keysList=[]):
  myPortal = CC159n()
  ph1 = "s"
  pref = "/portal.php" if par == "p" else "/server/load.php"
  ok = myPortal.VV8S7L(host, mac, ph1)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVpqcq(VV5kIx=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s%s?type=%s&action=%s" % (host, ph1, tType, action)
  res, err = myPortal.VVlsoO(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVIWqN(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVIWqN(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VV5kIxor(self, err, title="Portal Browser"):
  FFc8qc(self, str(err), title=title)
 def VVcFZq(self, mode):
  if   mode in ("itv"  , CCUfgv.VVA2rD , CCUfgv.VVuG2I)  : return "Live"
  elif mode in ("vod"  , CCUfgv.VVB7NO , CCUfgv.VVjCRR)  : return "VOD"
  elif mode in ("series" , CCUfgv.VVLfSL , CCUfgv.VV2uBs) : return "Series"
  else                          : return "IPTV"
 def VVKomW(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVcFZq(mode), searchName)
 def VVk6vU(self, catchup=False):
  VVJtuN = []
  VVJtuN.append(("Live"    , "live"  ))
  VVJtuN.append(("VOD"    , "vod"   ))
  VVJtuN.append(("Series"   , "series"  ))
  if catchup:
   VVJtuN.append(VVImCt)
   VVJtuN.append(("Catchup TV" , "catchup"  ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Account Info." , "accountInfo" ))
  return VVJtuN
 @staticmethod
 def VVCuCW(decodedUrl):
  m3u_Url = ""
  p = CC159n()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVX4e8(decodedUrl)
  if valid:
   ok = p.VV8S7L(host, mac, ph1, VV5kIx=False)
   if ok:
    m3u_Url, err = p.VVqZv3(isPhp=False, VV5kIx=False)
    span = iSearch(r".+ch\/(.+)_", decodedUrl, IGNORECASE)
    if span:
     m3u_Url += span.group(1)
  return m3u_Url
 @staticmethod
 def VV9sR2(decodedUrl):
  p = CC159n()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVX4e8(decodedUrl)
  if valid:
   if CC159n.VVSp1B(chCm):
    return FFl4xc(chCm)
   else:
    ok = p.VV8S7L(host, mac, ph1, VV5kIx=False)
    if ok:
     try:
      chUrl = p.VV9CRz(mode, chCm, epNum, epId)
      return FFl4xc(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VVSp1B(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
class CCytqZ(CC159n):
 def __init__(self):
  CC159n.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVSd1b(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVX4e8(decodedUrl)
  if valid:
   if self.VV8S7L(host, mac, ph1, VV5kIx=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VV8Yi1(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VV9CRz(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CC159n.VVSp1B(self.chCm):
   chUrl = FFl4xc(self.chCm)
   chUrl = FFsvs4(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
   isDirect = True
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
   isDirect = True
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVX7qC(chUrl)
  if newIptvRef:
   success = self.VV0F17(self.iptvRef, newIptvRef, isDirect)
   if passedSELF:
    FFTrMq(passedSELF, newIptvRef, VVz9ev=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFTrMq(self, newIptvRef, VVz9ev=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VVX7qC(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VV0F17(self, oldCode, newCode, isDirect):
  bPath = FFCxp0()
  if bPath:
   if isDirect:
    patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
    span = iSearch(patt, newCode, IGNORECASE)
    if span:
     newRef = span.group(1)
     newPar = span.group(2)
     lines = FFNoK6(bPath)
     for ndx, line in enumerate(lines):
      span = iSearch(patt, line, IGNORECASE)
      if span and newRef == span.group(1) and newPar == span.group(2):
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f:
        for line in lines:
         f.write(line + "\n")
       FFSZ2d()
       return True
   else:
    txt = FFt4Zg(bPath)
    if oldCode in txt:
     txt = txt.replace(oldCode, newCode)
     with open(bPath, "w") as f:
      f.write(txt)
     FFSZ2d()
     return True
  return False
class CCWa9p(CCytqZ):
 def __init__(self, passedSession):
  CCytqZ.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVVjfz, iPlayableService.evEOF: self.VV9u4K, iPlayableService.evEnd: self.VV3xh5})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVeKox)
  except:
   self.timer2.callback.append(self.VVeKox)
  self.timer2.start(3000, False)
  self.VVeKox()
 def VVeKox(self):
  if not CFG.downloadMonitor.getValue():
   self.VVGn0Y()
   return
  lst = CCUd13.VV6P55()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FFEZp1(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCUd13.VVvjcr(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin:
    self.dnldWin = self.passedSession.instantiateDialog(CC3dCB, txt, 30)
    self.dnldWin.instance.move(ePoint(30, 20))
    self.dnldWin.show()
    FF8WkH(self.dnldWin["myWinTitle"], "#440000", 1)
   else:
    self.dnldWin["myWinTitle"].setText(txt)
  elif self.dnldWin:
   self.VVGn0Y()
 def VVGn0Y(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVVjfz(self):
  self.startTime = iTime()
 def VV9u4K(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self.passedSession, isFromSession=True)
    if iptvRef and not FFHwNJ(decodedUrl):
     self.isFromEOF = True
     CCKyDd(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VV3xh5(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVCHTs)
  except:
   self.timer1.callback.append(self.VVCHTs)
  self.timer1.start(100, True)
 def VVCHTs(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVSd1b(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCVY8O.VVWmJG:
       self.isFromEOF = False
       self.VV8Yi1(self.passedSession, isFromSession=True)
class CC6QHf():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.nameTagPatt = r"\s*.{1,2}\s*[\[(|:]{1,2}\s*(.+)|\s*[\[(|:].{1,5}[\])|:](.+)|\s*(?:[^a-z]+:)*(.+)"
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.missingUtf8 = VV6ZSr and not VVv1m4
  self.adultWords  = ("adult", "aduld", "sex", "porn", "xxx", "xxi", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.adultWords2 = ("\u042d\u0440\u043e\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0435", "dla doros\u0142ych")
 def VVqFkZ(self, name,  censored=""):
  if self.missingUtf8:
   name = str(name.encode('ascii', 'replace').decode('utf-8'))
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCUfgv.VVwg0O(name):
   return CCUfgv.VVKNPx(name)
  name = self.VVYhgf(name)
  return name.strip() or name
 def VVYhgf(self, name):
  if self.removeTag:
   span = iSearch(r"^[A-Z]{2,3}\s*\|\|\s*(.+)|^[A-Z]{2,3}\s*[-|]\s*(.+)", name)
   if span:
    name = span.group(1) or span.group(2)
   else:
    span = iSearch(self.nameTagPatt, name)
    if span:
     name = (span.group(1) or span.group(2) or span.group(3)).strip()
     span = iSearch(self.nameTagPatt, name)
     if span:
      return span.group(1) or span.group(2) or span.group(3)
  return name
 def VVfZ6Y(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVYhgf(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VV97CQ(self, name):
  if self.hideAdult:
   if any(x in name.lower() for x in self.adultWords):
    return ""
   elif any(x in name.encode('ascii', 'backslashreplace').decode('utf-8').lower() for x in self.adultWords2):
    return ""
  return name.strip()
 def VV9tOp(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVUK2i(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCycDZ(CC159n):
 def __init__(self):
  CC159n.__init__(self)
 def VV4kMk(self):
  if CCycDZ.VV3e4i(self):
   FFItMF(self, self.VVBJUg, title="Searching ...")
 def VVKZuG(self, winSession, url, mac):
  if CCycDZ.VV3e4i(self):
   if self.VV8S7L(url, mac):
    FFItMF(winSession, self.VVeYnd, title="Checking Server ...")
   else:
    FFc8qc(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVBJUg(self):
  lines = self.VVjlMA(2)
  if lines:
   lines.sort()
   VVJtuN = []
   for line in lines:
    VVJtuN.append((line, line))
   OKBtnFnc  = self.VVWDHj
   VVPpN9 = ("Delete File", self.VVJu7t)
   FF0km9(self, None, title="Select Portals File", VVJtuN=VVJtuN, width=1200, OKBtnFnc=OKBtnFnc, VVPpN9=VVPpN9)
 def VVJu7t(self, VVnkBoObj, path):
  FFAIFY(self, BF(self.VVgDq0, VVnkBoObj, path), "Delete this file ?\n\n%s" % path)
 def VVgDq0(self, VVnkBoObj, path):
  os.system(FFIwml("rm -f '%s'" % path))
  if fileExists(path) : FFlDiQ(VVnkBoObj, "Not deleted", 1000)
  else    : VVnkBoObj.VVd12k()
 def VVWDHj(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = CCkHya.VVkGCD(path, self)
   if enc == -1:
    return
   self.session.open(CC5Qg8, barTheme=CC5Qg8.VVEF3W
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VVeSn9, path, enc)
       , VVOIg8 = BF(self.VVUwXu, menuInstance, path))
 def VVeSn9(self, path, enc, VVx8U3):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVx8U3.VVVu3x(totLines)
  VVx8U3.VVLA6S = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVx8U3 or VVx8U3.isCancelled:
     return
    VVx8U3.VVGACS(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VV6YSN(url)
     mac  = self.VVciW2(mac)
     if host and mac and VVx8U3:
      VVx8U3.VVLA6S.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VV6YSN(url)
      mac  = self.VVciW2(mac)
      if host and mac and not mac.startswith("AC") and VVx8U3:
       VVx8U3.VVLA6S.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVUwXu(self, menuInstance, path, VVFnA0, VVLA6S, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVLA6S:
   VV39uD  = ("Home Menu"  , FF7VFz            , [])
   VVgDsk = ("Edit File"  , BF(self.VVvCFL, path)       , [])
   VVieK7 = ("Open as M3U" , self.VVFlTS        , [])
   VVS9I3 = ("Check & Filter" , BF(self.VVYO8c, menuInstance, path), [])
   VVW0bm  = ("Select"   , self.VVKZuG_fromMacFiles      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVQQbo  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VV57kA = FFBL02(self, None, title=title, header=header, VVdLtF=VVLA6S, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=26, VVW0bm=VVW0bm, VV39uD=VV39uD, VVieK7=VVieK7, VVgDsk=VVgDsk, VVS9I3=VVS9I3, VV5mP6="#0a001122", VVqjLk="#0a001122", VVspm3="#0a001122", VVANti="#00004455", VVxA4o="#0a333333", VVVSpS="#11331100", VVxbA6=True, searchCol=1)
   if not VVFnA0:
    FFlDiQ(VV57kA, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVFnA0:
    FFc8qc(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVFlTS(self, VV57kA, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  FFItMF(VV57kA, BF(self.VVuKtD, VV57kA, host, mac), title="Checking Server ...")
 def VVuKtD(self, VV57kA, host, mac):
  p = CC159n()
  m3u_Url = ""
  ok = p.VV8S7L(host, mac, VV5kIx=False)
  err = ""
  if ok:
   m3u_Url, err = p.VVqZv3(VV5kIx=False)
  title = "Browsing M3U Server from Portal Data"
  if m3u_Url:
   self.VVGYrU(title, m3u_Url)
  else:
   FFc8qc(self, err or "No response from Server !", title=title)
 def VVKZuG_fromMacFiles(self, VV57kA, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVKZuG(VV57kA, url, mac)
 def VVvCFL(self, path, VV57kA, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCQnPl(self, path, VVOIg8=BF(self.VVcmm3, VV57kA), curRowNum=rowNum)
  else    : FFJJSt(self, path)
 def VVYO8c(self, menuInstance, path, VV57kA, title, txt, colList):
  self.session.open(CC5Qg8, barTheme=CC5Qg8.VVDgZs
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VVQuo4, VV57kA)
      , VVOIg8 = BF(self.VVGFNx, menuInstance, VV57kA, path))
 def VVQuo4(self, VV57kA, VVx8U3):
  VVx8U3.VVLA6S = []
  VVx8U3.VVVu3x(VV57kA.VVlvlo())
  for row in VV57kA.VVRk4N():
   if not VVx8U3 or VVx8U3.isCancelled:
    return
   VVx8U3.VVGACS(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VV8S7L(host, mac, VV5kIx=False):
    token, profile, tErr = self.VVpqcq(VV5kIx=False)
    if token and VVx8U3 and not VVx8U3.isCancelled:
     res, err = self.VVlsoO(self.VVj5lv("itv"))
     if res and VVx8U3 and not VVx8U3.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVx8U3.VVGACS(0, showFound=True)
       VVx8U3.VVLA6S.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVx8U3:
    return
 def VVGFNx(self, menuInstance, VV57kA, path, VVFnA0, VVLA6S, threadCounter, threadTotal, threadErr):
  if VVLA6S:
   VV57kA.close()
   menuInstance.close()
   newPath = "%s_OK_%s.txt" % (path, FFSGFz())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVLA6S:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FF0IFC(str(threadCounter), VVyU04)
    skipped = FF0IFC(str(threadTotal - threadCounter), VVyU04)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVLA6S)
   txt += "%s\n\n%s"    %  (FF0IFC("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
   FFPt7a(self, txt, title="Accessible Portals")
  elif VVFnA0:
   FFc8qc(self, "No portal access found !", title="Accessible Portals")
 def VVBewx(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFwC08(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVeYnd(self):
  token, profile, tErr = self.VVpqcq()
  if token:
   dots = "." * self.VVsUMJ
   dots += "+" if self.VV3jUA[1:2] == "p" else ""
   VVJtuN  = self.VVk6vU()
   OKBtnFnc = self.VVCkhy
   VVBLjB = ("Home Menu", FF7VFz)
   VVjEiY = ("Bookmark Server", BF(CCUfgv.VVhkMm, self, True, self.VVvMdx + "\t" + self.VVMQC5))
   FF0km9(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVMQC5, dots), VVJtuN=VVJtuN, OKBtnFnc=OKBtnFnc, VVBLjB=VVBLjB, VVjEiY=VVjEiY)
 def VVCkhy(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFItMF(menuInstance, BF(self.VVsYrb, mode), title="Reading Categories ...")
   else : FFItMF(menuInstance, BF(self.VVkeL1, menuInstance, title), title="Reading Account ...")
 def VVkeL1(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVJpSR(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVMQC5)
  VV39uD  = ("Home Menu" , FF7VFz         , [])
  VVieK7  = None
  if VVIGxe:
   VVieK7 = ("Get JS"  , BF(self.VVQIDI, self.VVvMdx), [])
  if totCols == 2:
   VVS9I3 = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVS9I3 = ("More Info.", BF(self.VVqGjb, menuInstance)  , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFBL02(self, None, title=title, width=1200, header=header, VVdLtF=rows, VVGpzZ=widths, VVYOiV=26, VV39uD=VV39uD, VVieK7=VVieK7, VVS9I3=VVS9I3, VV5mP6="#0a00292B", VVqjLk="#0a002126", VVspm3="#0a002126", VVANti="#00000000", searchCol=searchCol)
 def VVQIDI(self, url, VV57kA, title, txt, colList):
  FFItMF(VV57kA, BF(self.VVDfEQ, url), title="Getting JS ...")
 def VVDfEQ(self, url):
  txt = "// Host\t: %s\n" % url
  res, err = self.VVlsoO("%s/c/version.js" % url)
  if not err: ver = res.text
  else   : ver = "Error: %s" % err
  txt += "// Version\t: %s\n" % ver
  res, err = self.VVlsoO("%s/c/xpcom.common.js" % url)
  if not err: js = res.text
  else   : js = "Error: %s" % err
  txt += "\n%s" % js
  FFPt7a(self, txt, title="JS Info", canSaveToFile="Server_xpcom.common.js")
 def VVqGjb(self, menuInstance, VV57kA, title, txt, colList):
  VV57kA.cancel()
  FFItMF(menuInstance, BF(self.VVkeL1, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVsYrb(self, mode):
  token, profile, tErr = self.VVpqcq()
  if not token:
   return
  res, err = self.VVlsoO(self.VVj5lv(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     VVuSz1 = CC6QHf()
     chList = tDict["js"]
     for item in chList:
      Id   = CCUfgv.VVh28z(item, "id"       )
      Title  = CCUfgv.VVh28z(item, "title"      )
      censored = CCUfgv.VVh28z(item, "censored"     )
      Title = VVuSz1.VV97CQ(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVIGxe:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVcFZq(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VV5mP6, VVqjLk, VVspm3, VVANti = self.VVL6Lq(mode)
   mName = self.VVcFZq(mode)
   VVW0bm   = ("Show List"   , BF(self.VVPUtC, mode)  , [])
   VV39uD  = ("Home Menu"   , FF7VFz       , [])
   if mode in ("vod", "series"):
    VVgDsk = ("Find in %s" % mName , BF(self.VVuwKi, mode) , [])
   else:
    VVgDsk = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FFBL02(self, None, title=title, width=1200, header=header, VVdLtF=list, VVGpzZ=widths, VVYOiV=30, VV39uD=VV39uD, VVgDsk=VVgDsk, VVW0bm=VVW0bm, VV5mP6=VV5mP6, VVqjLk=VVqjLk, VVspm3=VVspm3, VVANti=VVANti)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VVm0I1:
     txt += "\n\n( %s )" % self.VVm0I1
   else:
    txt = "Could not get Categories from server!"
   FFc8qc(self, txt, title=title)
 def VVsDnn(self, mode, VV57kA, title, txt, colList):
  FFItMF(VV57kA, BF(self.VVyuZg, mode, VV57kA, title, txt, colList), title="Downloading ...")
 def VVyuZg(self, mode, VV57kA, title, txt, colList):
  token, profile, tErr = self.VVpqcq()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVlsoO(self.VVMXH5(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCUfgv.VVh28z(item, "id"    )
      actors   = CCUfgv.VVh28z(item, "actors"   )
      added   = CCUfgv.VVh28z(item, "added"   )
      age    = CCUfgv.VVh28z(item, "age"   )
      category_id  = CCUfgv.VVh28z(item, "category_id" )
      description  = CCUfgv.VVh28z(item, "description" )
      director  = CCUfgv.VVh28z(item, "director"  )
      genres_str  = CCUfgv.VVh28z(item, "genres_str"  )
      name   = CCUfgv.VVh28z(item, "name"   )
      path   = CCUfgv.VVh28z(item, "path"   )
      screenshot_uri = CCUfgv.VVh28z(item, "screenshot_uri" )
      series   = CCUfgv.VVh28z(item, "series"   )
      cmd    = CCUfgv.VVh28z(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VVW0bm  = ("Play"    , BF(self.VVlEKI, mode)       , [])
   VVMg98 = (""     , BF(self.VV2QJV, mode)     , [])
   VV39uD = ("Home Menu"   , FF7VFz            , [])
   VVieK7 = ("Download Options" , BF(self.VVFbrj, mode, "sp", seriesName) , [])
   VVgDsk = ("Options"   , BF(self.VVixac, 0, "pEp", mode, seriesName), [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVQQbo  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFBL02(self, None, title=seriesName, width=1200, header=header, VVdLtF=list, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=26, VV39uD=VV39uD, VVieK7=VVieK7, VVgDsk=VVgDsk, VVW0bm=VVW0bm, VVMg98=VVMg98, VV5mP6="#0a00292B", VVqjLk="#0a002126", VVspm3="#0a002126", VVANti="#00000000")
  else:
   FFc8qc(self, "Could not get Episodes from server!", title=seriesName)
 def VVuwKi(self, mode, VV57kA, title, txt, colList):
  VVJtuN = []
  VVJtuN.append(("Keyboard"  , "manualEntry"))
  VVJtuN.append(("From Filter" , "fromFilter"))
  FF0km9(self, BF(self.VVbUdk, VV57kA, mode), title="Input Type", VVJtuN=VVJtuN, width=400)
 def VVbUdk(self, VV57kA, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFBJqp(self, BF(self.VVV1A4, VV57kA, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCfaXJ(self)
    filterObj.VV8EPH(BF(self.VVV1A4, VV57kA, mode))
 def VVV1A4(self, VV57kA, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VVKomW(mode, searchName)
   if len(searchName) < 3:
    FFc8qc(self, "Enter at least 3 characters.", title=title)
   else:
    VVuSz1 = CC6QHf()
    if CFG.hideIptvServerAdultWords.getValue() and VVuSz1.VV9tOp([searchName]):
     FFc8qc(self, VVuSz1.VVUK2i(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VVt6qC(mode, searchName, "", searchName)
 def VVPUtC(self, mode, VV57kA, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVt6qC(mode, bName, catID, "")
 def VVt6qC(self, mode, bName, catID, searchName):
  self.session.open(CC5Qg8, barTheme=CC5Qg8.VVEF3W
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVMyiJ, mode, bName, catID, searchName)
      , VVOIg8 = BF(self.VVRxtK, mode, bName, catID, searchName))
 def VVRxtK(self, mode, bName, catID, searchName, VVFnA0, VVLA6S, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVKomW(mode, searchName)
  else   : title = "%s : %s" % (self.VVcFZq(mode), bName)
  if VVLA6S:
   VVieK7 = None
   VVgDsk = None
   if mode == "series":
    VV5mP6, VVqjLk, VVspm3, VVANti = self.VVL6Lq("series2")
    VVW0bm  = ("Episodes"   , BF(self.VVsDnn, mode)           , [])
   else:
    VV5mP6, VVqjLk, VVspm3, VVANti = self.VVL6Lq("")
    VVW0bm  = ("Play"    , BF(self.VVlEKI, mode)           , [])
    VVieK7 = ("Download Options" , BF(self.VVFbrj, mode, "vp" if mode == "vod" else "", "") , [])
    VVgDsk = ("Options"   , BF(self.VVixac, 1, "pCh", mode, bName)      , [])
   VVMg98 = (""      , BF(self.VVKXg4, mode)         , [])
   VV39uD = ("Home Menu"    , FF7VFz                , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVQQbo  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT )
   VV57kA = FFBL02(self, None, title=title, header=header, VVdLtF=VVLA6S, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=26, VV39uD=VV39uD, VVieK7=VVieK7, VVgDsk=VVgDsk, VVW0bm=VVW0bm, VVMg98=VVMg98, VV5mP6=VV5mP6, VVqjLk=VVqjLk, VVspm3=VVspm3, VVANti=VVANti, VVxbA6=True, searchCol=1)
   if not VVFnA0:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VV57kA.VVC6lz(VV57kA.VVsZfG() + tot)
    if threadErr: FFlDiQ(VV57kA, "Error while reading !", 2000)
    else  : FFlDiQ(VV57kA, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFc8qc(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFc8qc(self, "Could not get list from server !", title=title)
 def VVKXg4(self, mode, VV57kA, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFsVRo(self, fncMode=CCSQQx.VVGZow, portalHost=self.VVvMdx, portalMac=self.VVMQC5, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VV4CpV(mode, VV57kA, title, txt, colList)
 def VV2QJV(self, mode, VV57kA, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FF0IFC(colList[10], VVkO2P)
  txt += "Description:\n%s" % FF0IFC(colList[11], VVkO2P)
  self.VV4CpV(mode, VV57kA, title, txt, colList)
 def VV4CpV(self, mode, VV57kA, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVAwOU(mode, colList)
  refCode, chUrl = self.VVhg1T(self.VVvMdx, self.VVMQC5, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFsVRo(self, fncMode=CCSQQx.VVoiHW, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVMyiJ(self, mode, bName, catID, searchName, VVx8U3):
  try:
   token, profile, tErr = self.VVpqcq()
   if not token:
    return
   if VVx8U3.isCancelled:
    return
   VVx8U3.VVLA6S, total_items, max_page_items, err = self.VVEjP5(mode, catID, 1, 1, searchName)
   if VVx8U3.isCancelled:
    return
   if VVx8U3.VVLA6S and total_items > -1 and max_page_items > -1:
    VVx8U3.VVVu3x(total_items)
    VVx8U3.VVGACS(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVx8U3.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVEjP5(mode, catID, page, counter, searchName)
     if err:
      VVx8U3.VVlYn7()
     if VVx8U3.isCancelled:
      return
     if list:
      VVx8U3.VVLA6S += list
      VVx8U3.VVGACS(len(list), True)
  except:
   pass
 def VVEjP5(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VV4O7K(mode, searchName, page)
  else   : url = self.VVBGLu(mode, catID, page)
  res, err = self.VVlsoO(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVkBqh(CCUfgv.VVh28z(item, "total_items" ))
     max_page_items = self.VVkBqh(CCUfgv.VVh28z(item, "max_page_items" ))
     VVuSz1 = CC6QHf()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCUfgv.VVh28z(item, "id"    )
      name   = CCUfgv.VVh28z(item, "name"   )
      o_name   = CCUfgv.VVh28z(item, "o_name"   )
      tv_genre_id  = CCUfgv.VVh28z(item, "tv_genre_id" )
      number   = CCUfgv.VVh28z(item, "number"   ) or str(counter)
      logo   = CCUfgv.VVh28z(item, "logo"   )
      screenshot_uri = CCUfgv.VVh28z(item, "screenshot_uri" )
      cmd    = CCUfgv.VVh28z(item, "cmd"   )
      censored  = CCUfgv.VVh28z(item, "censored"  )
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       span = iSearch(r"stream=(.+)&", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
       else:
        span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVvMdx + picon).replace(sp * 2, sp)
      counter += 1
      name = VVuSz1.VVqFkZ(name, censored)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVOVe7(self, mode, bName, VV57kA, title, txt, colList):
  bNameFile = CCUfgv.VV6gQE_forBouquet(bName)
  num  = 0
  path = VVR2Ml + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVR2Ml + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   isMulti = VV57kA.VVdcxd
   for ndx, row in enumerate(VV57kA.VVRk4N()):
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVAwOU(mode, row)
    refCode, chUrl = self.VVhg1T(self.VVvMdx, self.VVMQC5, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    if not isMulti or VV57kA.VVe3Hb(ndx):
     f.write("#SERVICE %s\n"  % chUrl)
     f.write("#DESCRIPTION %s\n" % chName)
     totChange += 1
  FFLQO2(os.path.basename(path))
  self.VVuVs0(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVkBqh(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVlEKI(self, mode, VV57kA, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVAwOU(mode, colList)
  refCode, chUrl = self.VVhg1T(self.VVvMdx, self.VVMQC5, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVwg0O(chName):
   FFlDiQ(VV57kA, "This is a marker!", 300)
  else:
   FFItMF(VV57kA, BF(self.VVyOf4, mode, VV57kA, chUrl), title="Playing ...")
 def VVyOf4(self, mode, VV57kA, chUrl):
  FFTrMq(self, chUrl, VVz9ev=False)
  self.session.open(CCVY8O, portalTableParam=(self, VV57kA, mode))
 def VV7V0H(self, mode, VV57kA, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVAwOU(mode, colList)
  refCode, chUrl = self.VVhg1T(self.VVvMdx, self.VVMQC5, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVAwOU(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VV3e4i(SELF):
  try:
   import requests
   return True
  except:
   title = 'Install "Requests"'
   VVJtuN = []
   VVJtuN.append((title        , "inst" ))
   VVJtuN.append(("Update Packages then %s" % title , "updInst" ))
   FF0km9(SELF, BF(CCycDZ.VVWsT5, SELF), title='This requires Python "Requests" library', VVJtuN=VVJtuN)
   return False
 @staticmethod
 def VVWsT5(SELF, item=None):
  if item:
   from sys import version_info
   cmdUpd = FFVZA6(VVjUDZ, "")
   if cmdUpd:
    cmdInst = FFxvW9(VVKMZF, "python-requests")
    if version_info[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFjX9J(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library')
   else:
    FFa4IH(SELF)
class CCUfgv(Screen, CCycDZ):
 VV4GIM    = 0
 VVXJAd    = 1
 VVLy3r    = 2
 VV2BC8    = 3
 VVQW9U     = 4
 VVKQpl     = 5
 VVGtQE     = 6
 VVy85b     = 7
 VVWM74      = 8
 VVo6Sf     = 9
 VVd304     = 10
 VVRC8V     = 11
 VVI8AL     = 12
 VV7Hn5      = 13
 VVj9N2      = 14
 VVaoQv      = 15
 VVlzpw      = 16
 VVotvo      = 17
 VVWvYA    = 0
 VVA2rD   = 1
 VVB7NO   = 2
 VVLfSL   = 3
 VVZVZb  = 4
 VVAYGf  = 5
 VVuG2I   = 6
 VVjCRR   = 7
 VV2uBs  = 8
 VV9X38  = 9
 VVnyRU  = 10
 VVvJxJ = 0
 VVWPQC = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFi9TE(VVavIl, 1000, 1000, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.m3uOrM3u8File  = m3uOrM3u8File
  self.m3uOrM3u8BName  = ""
  self.VV57kA  = None
  self.tableTitle   = "IPTV Channels List"
  self.VVpbZSData  = {}
  self.lastFindIptvName = ""
  CCycDZ.__init__(self)
  VVJtuN = []
  VVJtuN.append(("IPTV Server Browser (from Playlists)"      , "VVpbZS_fromPlayList" ))
  VVJtuN.append(("IPTV Server Browser (from Portal List)"     , "VVpbZS_fromMac"  ))
  VVJtuN.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)" , "VVpbZS_fromM3u"  ))
  qUrl, iptvRef = self.VVWCwJ()
  if qUrl or "chCode" in iptvRef:
   VVJtuN.append(("IPTV Server Browser (from Current Channel)"    , "VVpbZS_fromCurrChan" ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("M3U/M3U8 File Browser"          , "VVpZrK"   ))
  files = self.VVLFZv()
  if files:
   VVJtuN.append(("Local IPTV Channels"          , "iptvTable_all"   ))
  if qUrl or "chCode" in iptvRef:
   VVJtuN.append(VVImCt)
   VVJtuN.append(("Update Current Bouquet EPG (from IPTV Server)"   , "refreshIptvEPG"   ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Check System Acceptable Reference Types"      , "VVcI9O"   ))
  if files:
   VVJtuN.append(("Count Available IPTV Channels"       , "VVI4KB"    ))
   VVJtuN.append(("Check Reference Codes Format"        , "VVbxT0"   ))
   VVJtuN.append(VVImCt)
   VVJtuN.append(("Share Reference with Sat./C/T (Only Matching Names)"  , "VVPJ6m" ))
   VVJtuN.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVlnuw"  ))
   VVJtuN.append(("Change ALL References to Unique Codes"     , "VVIW56" ))
   VVJtuN.append(("Change ALL References to Identical Codes"     , "VVKCsp_all" ))
  if not CCUd13.VVogwQ():
   VVJtuN.append(VVImCt)
   VVJtuN.append(("Download Manager"           , "dload_stat"    ))
  FFRqJR(self, title="IPTV", VVJtuN=VVJtuN)
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FF7a1g(self["myMenu"])
  FFvDVP(self)
  FF9Drq(self)
  if self.m3uOrM3u8File:
   self.VVjEoo(self.m3uOrM3u8File)
 def VVPNeF(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVapcJ"   : FFBJqp(self, self.VVapcJ, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VV4lIV" : FFAIFY(self, BF(FFItMF, self.VV57kA, self.VV4lIV ), "Change Current List References to Unique Codes ?" )
   elif item == "VVKCsp_rows" : FFAIFY(self, BF(FFItMF, self.VV57kA, self.VVKCsp  ), "Change Current List References to Identical Codes ?")
   elif item == "VVj2Bf"   : self.VVj2Bf(tTitle)
   elif item == "VV9moS"   : self.VV9moS(tTitle)
   elif item == "VVpbZS_fromPlayList" : FFItMF(self, self.VVBaFd, title=title)
   elif item == "VVpbZS_fromM3u"  : FFItMF(self, BF(self.VVKgxO, 0), title=title)
   elif item == "VVpbZS_fromMac"  : self.VV4kMk()
   elif item == "VVpbZS_fromCurrChan" : self.VVKZuG_fromCurrChan()
   elif item == "VVpZrK"   : self.VVpZrK()
   elif item == "iptvTable_live"   : FFItMF(self, BF(self.VVN6yu, self.VVy85b ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFItMF(self, BF(self.VVN6yu, self.VV4GIM), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VVOVr0()
   elif item == "VVI4KB"    : FFItMF(self, self.VVI4KB)
   elif item == "VVbxT0"    : FFItMF(self, self.VVbxT0)
   elif item == "VVcI9O"   : FFItMF(self, self.VVcI9O)
   elif item == "VVPJ6m"  : FFAIFY(self, BF(FFItMF, self, self.VVPJ6m ), "Continue ?")
   elif item == "VVlnuw"  : self.VVlnuw()
   elif item == "VVIW56" : FFAIFY(self, BF(FFItMF, self, self.VVIW56), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVKCsp_all" : FFAIFY(self, BF(FFItMF, self, self.VVKCsp  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "dload_stat"    : CCUd13.VVw9wz(self)
   elif item == "VVB9bb"   : FFItMF(self, BF(CCcNAu.VVB9bb, self))
 def VVpZrK(self):
  if CCycDZ.VV3e4i(self):
   FFItMF(self, BF(self.VVKgxO, 1), title="Searching ...")
 def VVlQQ7(self):
  global VV7k9C
  VV7k9C = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVPNeF(item)
 def VVN6yu(self, mode):
  VVMDmE = self.VVpF7D(mode)
  if VVMDmE:
   VVieK7 = ("Current Service", self.VVfWk5 , [])
   VVgDsk = ("Options"  , self.VVUBPV   , [])
   VVS9I3 = ("Filter"   , self.VVbi3O   , [])
   VVW0bm  = ("Play"   , BF(self.VVeXsH)  , [])
   VVMg98 = (""    , self.VVFZUR    , [])
   VVOo99 = (""    , self.VVKiDL     , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVQQbo  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFBL02(self, None, header=header, VVdLtF=VVMDmE, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=26
     , VVW0bm=VVW0bm, VVieK7=VVieK7, VVgDsk=VVgDsk, VVS9I3=VVS9I3, VVMg98=VVMg98, VVOo99=VVOo99
     , VV5mP6="#0a00292B", VVqjLk="#0a002126", VVspm3="#0a002126", VVANti="#00000000", VVxbA6=True, searchCol=1)
  else:
   if mode == self.VVy85b: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFc8qc(self, err)
 def VVKiDL(self, VV57kA, title, txt, colList):
  self.VV57kA = VV57kA
 def VVUBPV(self, VV57kA, title, txt, colList):
  VVJtuN = []
  VVJtuN.append(("Add Current List to a New Bouquet"      , "VVapcJ"  ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Change Current List References to Unique Codes"   , "VV4lIV"))
  VVJtuN.append(("Change Current List References to Identical Codes"  , "VVKCsp_rows" ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Share Reference with Satellite/C/T Service (manual entry)", "VVj2Bf"   ))
  VVJtuN.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VV9moS"   ))
  FF0km9(self, self.VVPNeF, title="IPTV Tools", VVJtuN=VVJtuN)
 def VVbi3O(self, VV57kA, title, txt, colList):
  VVJtuN = []
  VVJtuN.append(("All"         , "all"   ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Prefix of Selected Channel"   , "sameName" ))
  VVJtuN.append(("Suggest Words from Selected Channel" , "partName" ))
  VVJtuN.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Live TV"        , "live"  ))
  VVJtuN.append(("VOD"         , "vod"   ))
  VVJtuN.append(("Series"        , "series"  ))
  VVJtuN.append(("Uncategorised"      , "uncat"  ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Video"        , "video"  ))
  VVJtuN.append(("Audio"        , "audio"  ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("MKV"         , "MKV"   ))
  VVJtuN.append(("MP4"         , "MP4"   ))
  VVJtuN.append(("MP3"         , "MP3"   ))
  VVJtuN.append(("AVI"         , "AVI"   ))
  VVJtuN.append(("FLV"         , "FLV"   ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVvWaY()
  if bNames:
   bNames.sort()
   VVJtuN.append(VVImCt)
   for item in bNames:
    VVJtuN.append((item, "__b__" + item))
  filterObj = CCfaXJ(self)
  filterObj.VV377c(VVJtuN, VVJtuN, BF(self.VVKUU6, VV57kA))
 def VVKUU6(self, VV57kA, item=None):
  prefix = VV57kA.VVIrRe(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VV4GIM, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVXJAd , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVLy3r , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VV2BC8 , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVy85b  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVWM74   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVo6Sf  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVd304  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVRC8V  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVI8AL  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VV7Hn5   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVj9N2   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVaoQv   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVlzpw   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVotvo   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVGtQE  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VVQW9U  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVKQpl  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVLy3r:
   VVJtuN = []
   chName = VV57kA.VVIrRe(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVJtuN.append((item, item))
    if not VVJtuN and chName:
     VVJtuN.append((chName, chName))
    FF0km9(self, BF(self.VVuUJ6_partOfName, title), title="Words from Current Selection", VVJtuN=VVJtuN)
   else:
    VV57kA.VVAlHG("Invalid Channel Name")
  else:
   words, asPrefix = CCfaXJ.VVIvS9(words)
   if not words and mode in (self.VVQW9U, self.VVKQpl):
    FFlDiQ(self.VV57kA, "Incorrect filter", 2000)
   else:
    FFItMF(self.VV57kA, BF(self.VV19gz, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVuUJ6_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFItMF(self.VV57kA, BF(self.VV19gz, self.VVLy3r, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVKNPx(txt):
  return "#f#11ffff00#" + txt
 def VV19gz(self, mode, words, asPrefix, title):
  VVMDmE = self.VVpF7D(mode=mode, words=words, asPrefix=asPrefix)
  if VVMDmE : self.VV57kA.VV3aGD(VVMDmE, title)
  else  : self.VV57kA.VVAlHG("Not found")
 def VVpF7D(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VVMDmE = []
  files  = self.VVLFZv()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFt4Zg(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVKr5F = span.group(1)
    else : VVKr5F = ""
    VVKr5F_lCase = VVKr5F.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVwg0O(chName): chNameMod = self.VVKNPx(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVKr5F, chType, refCode, url)
     ok = False
     tUrl = FFl4xc(url).lower()
     if mode == self.VV4GIM       : ok = True
     elif mode == self.VVGtQE       : ok = True
     elif mode == self.VVRC8V:
      if CCUfgv.VVOsYy(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVI8AL:
      if CCUfgv.VVOsYy(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVy85b:
      if CCUfgv.VVOsYy(tUrl, compareType="live")  : ok = True
     elif mode == self.VVWM74:
      if CCUfgv.VVOsYy(tUrl, compareType="movie") : ok = True
     elif mode == self.VVo6Sf:
      if CCUfgv.VVOsYy(tUrl, compareType="series") : ok = True
     elif mode == self.VVd304:
      if CCUfgv.VVOsYy(tUrl, compareType="")   : ok = True
     elif mode == self.VV7Hn5:
      if CCUfgv.VVOsYy(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVj9N2:
      if CCUfgv.VVOsYy(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVaoQv:
      if CCUfgv.VVOsYy(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVlzpw:
      if CCUfgv.VVOsYy(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVotvo:
      if CCUfgv.VVOsYy(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVXJAd:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVLy3r:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VV2BC8:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VVQW9U:
      if words[0] == VVKr5F_lCase:
       ok = True
     elif mode == self.VVKQpl:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VVMDmE.append(row)
      chNum += 1
  if VVMDmE and mode == self.VVGtQE:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VVMDmE)
   for item in VVMDmE:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VVMDmE = newRows
  return VVMDmE
 def VVapcJ(self, bName):
  if bName:
   FFItMF(self.VV57kA, BF(self.VVXn5o, bName), title="Adding Channels ...")
 def VVXn5o(self, bName):
  num = 0
  path = VVR2Ml + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVR2Ml + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VV57kA.VVRk4N():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFj0Hy(row[1]))
    totChange += 1
  FFLQO2(os.path.basename(path))
  self.VVuVs0(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVlnuw(self):
  txt = "Stream Type "
  VVJtuN = []
  VVJtuN.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVJtuN.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVJtuN.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVJtuN.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVJtuN.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVJtuN.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FF0km9(self, self.VVWwjP, title="Change Reference Types to:", VVJtuN=VVJtuN)
 def VVWwjP(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVly1L("1"   )
   elif item == "RT_4097" : self.VVly1L("4097")
   elif item == "RT_5001" : self.VVly1L("5001")
   elif item == "RT_5002" : self.VVly1L("5002")
   elif item == "RT_8192" : self.VVly1L("8192")
   elif item == "RT_8193" : self.VVly1L("8193")
 def VVly1L(self, rType):
  FFAIFY(self, BF(FFItMF, self, BF(self.VVVigH, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVVigH(self, refType):
  totChange = 0
  files  = self.VVLFZv()
  if files:
   for path in files:
    txt = FFt4Zg(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFLQO2(os.path.basename(path))
  self.VVuVs0(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVI4KB(self):
  totFiles = 0
  files  = self.VVLFZv()
  if files:
   totFiles = len(files)
  totChans = 0
  VVMDmE = self.VVpF7D()
  if VVMDmE:
   totChans = len(VVMDmE)
  FFPt7a(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVbxT0(self):
  files  = self.VVLFZv()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFt4Zg(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VV9pCx
   else    : color = VVyU04
   totInvalid = FF0IFC(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FF0IFC("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFPt7a(self, txt, title="Check IPTV References")
 def VVcI9O(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVR2Ml + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFLQO2(os.path.basename(path))
  FFSZ2d()
  acceptedList = []
  VVOAVO = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVOAVO:
   VVRIuo = FFpZCL(VVOAVO)
   if VVRIuo:
    for service in VVRIuo:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVR2Ml + userBName
  bFile = VVR2Ml + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFIwml("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFIwml("rm -f '%s'" % path)
  os.system(cmd)
  FFSZ2d()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VV9pCx
    else     : res, color = "No" , VVyU04
    txt += "    %s\t: %s\n" % (item, FF0IFC(res, color))
   FFPt7a(self, txt, title=title)
  else:
   txt = FFc8qc(self, "Could not complete the test on your system!", title=title)
 def VVPJ6m(self):
  VV6j5n, err = CCcNAu.VVRQtF(self, CCcNAu.VV3QVo)
  if VV6j5n:
   totChannels = 0
   totChange = 0
   for path in self.VVLFZv():
    toSave = False
    txt = FFt4Zg(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VV6j5n.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVuVs0(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFc8qc(self, 'No channels in "lamedb" !')
 def VVIW56(self):
  files  = self.VVLFZv()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFNoK6(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVfdkr(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVuVs0(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VV4lIV(self):
  iptvRefList = []
  files  = self.VVLFZv()
  if files:
   for path in files:
    txt = FFt4Zg(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VV57kA.VVWVgX(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVfdkr(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVLFZv()
  if files:
   for path in files:
    lines = FFNoK6(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVuVs0(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVfdkr(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVKCsp(self):
  list = None
  if self.VV57kA:
   list = []
   for row in self.VV57kA.VVRk4N():
    list.append(row[4] + row[5])
  files  = self.VVLFZv()
  totChange = 0
  if files:
   for path in files:
    lines = FFNoK6(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVuVs0(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVuVs0(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFSZ2d()
   if refreshTable and self.VV57kA:
    VVMDmE = self.VVpF7D()
    if VVMDmE and self.VV57kA:
     self.VV57kA.VV3aGD(VVMDmE, self.tableTitle)
     self.VV57kA.VVAlHG(txt)
   FFPt7a(self, txt, title=title)
  else:
   FF9xND(self, "No changes.")
 def VVvWaY(self):
  files = self.VVLFZv()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with ioOpen(path, "r", encoding="utf-8") as f:
     span = iSearch(r"#NAME\s+(.*)", str(f.readline()), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    for b in FFKD9U():
     sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVLFZv(self):
  return CCUfgv.VVmLF8(self)
 @staticmethod
 def VVmLF8(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVR2Ml + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFt4Zg(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVFZUR(self, VV57kA, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFl4xc(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFsVRo(self, fncMode=CCSQQx.VV9y9G, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVEu0H(self, VV57kA, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVeXsH(self, VV57kA, title, txt, colList):
  chName, chUrl = self.VVEu0H(VV57kA, colList)
  self.VVCyRp(VV57kA, chName, chUrl, "localIptv")
 def VVTWyZ(self, mode, VV57kA, colList):
  chName, chUrl, picUrl, refCode = self.VVeX0N(mode, colList)
  return chName, chUrl
 def VV3CBB(self, mode, VV57kA, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVeX0N(mode, colList)
  self.VVCyRp(VV57kA, chName, chUrl, mode)
 def VVCyRp(self, VV57kA, chName, chUrl, playerFlag):
  chName = FFj0Hy(chName)
  if self.VVwg0O(chName):
   FFlDiQ(VV57kA, "This is a marker!", 300)
  else:
   FFItMF(VV57kA, BF(self.VVEBcr, VV57kA, chUrl, playerFlag), title="Playing ...")
 def VVEBcr(self, VV57kA, chUrl, playerFlag):
  FFTrMq(self, chUrl, VVz9ev=False)
  self.session.open(CCVY8O, portalTableParam=(self, VV57kA, playerFlag))
 @staticmethod
 def VVwg0O(chName):
  mark = ("--", "__", "==", "##",  "**", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVfWk5(self, VV57kA, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self)
  if refCode:
   bName = FFOc9w()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFbKYW(refCode, origUrl, chName) }
   VV57kA.VVaOZN_partial(colDict, VV5kIx=True)
 def VVKgxO(self, m3uMode):
  lines = self.VVjlMA(3)
  if lines:
   lines.sort()
   VVJtuN = []
   for line in lines:
    VVJtuN.append((line, line))
   if m3uMode == self.VVvJxJ:
    title = "Browse Server from M3U URLs"
    VVjEiY = ("All to Playlist", self.VVbYAI)
   else:
    title = "M3U/M3U8 File Browser"
    VVjEiY = None
   OKBtnFnc = BF(self.VVGFUi, m3uMode, title)
   VV6cmu  = ("Show Full Path", self.VVyqUF)
   VVPpN9 = ("Delete File", self.VVJu7t)
   FF0km9(self, None, title=title, VVJtuN=VVJtuN, width=1200, OKBtnFnc=OKBtnFnc, VV6cmu=VV6cmu, VVPpN9=VVPpN9, VVjEiY=VVjEiY)
 def VVyqUF(self, VVnkBoObj, url):
  FFPt7a(self, url, title="Full Path")
 def VVGFUi(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == self.VVvJxJ:
    FFItMF(menuInstance, BF(self.VV9i2u, title, path))
   else:
    FFItMF(menuInstance, BF(self.VVjEoo, path))
 def VVjEoo(self, srcPath):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFt4Zg(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  VVuSz1 = CC6QHf()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VVPbQ5(propLine, "group-title") or "-"
   if not group == "-" and VVuSz1.VVqFkZ(group):
    groups.add(group)
  VVMDmE = []
  if len(groups) > 0:
   title = "Groups"
   for group in groups:
    VVMDmE.append((group, group))
   VVMDmE.append(("ALL", ""))
   VVMDmE.sort(key=lambda x: x[0].lower())
   VVqaLK = self.VVehj0
   VVW0bm  = ("Select" , BF(self.VVvxh8, srcPath), [])
   widths   = (100  , 0)
   VVQQbo  = (LEFT  , LEFT)
   FFBL02(self, None, title=title, width= 800, header=None, VVdLtF=VVMDmE, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=30, VVW0bm=VVW0bm, VVqaLK=VVqaLK
     , VV5mP6="#11110022", VVqjLk="#11110022", VVspm3="#11110022", VVANti="#00444400")
  else:
   txt = FFt4Zg(srcPath)
   self.VVJq6Y(txt, filterGroup="")
 def VVvxh8(self, srcPath, VV57kA, title, txt, colList):
  group = colList[1]
  txt = FFt4Zg(srcPath)
  self.VVJq6Y(txt, filterGroup=group)
 def VVJq6Y(self, txt, filterGroup=""):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = "Group : %s" % (filterGroup or "ALL")
  if lst:
   self.session.open(CC5Qg8, barTheme=CC5Qg8.VVEF3W
       , titlePrefix = "Reading File Lines"
       , fncToRun  = BF(self.VV08dG, lst, filterGroup)
       , VVOIg8 = BF(self.VVPgsr, title, bName))
  else:
   self.VVsam4("No valid lines found !", title)
 def VV08dG(self, lst, filterGroup, VVx8U3):
  VVx8U3.VVLA6S = []
  VVx8U3.VVVu3x(len(lst))
  VVuSz1 = CC6QHf()
  num = 0
  for cols in lst:
   if not VVx8U3 or VVx8U3.isCancelled:
    return
   VVx8U3.VVGACS(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VVPbQ5(propLine, "tvg-logo")
   group = self.VVPbQ5(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if group and not VVuSz1.VVqFkZ(group) : skip = True
    if chName and not VVuSz1.VVqFkZ(chName): skip = True
    if not skip and VVx8U3:
     num += 1
     VVx8U3.VVLA6S.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if VVx8U3:
   VVx8U3.VVQyWe_forcedUpdate("Loading %d Channels" % len(VVx8U3.VVLA6S))
 def VVPgsr(self, title, bName, VVFnA0, VVLA6S, threadCounter, threadTotal, threadErr):
  if VVLA6S:
   VVqaLK = self.VVehj0
   VVW0bm  = ("Select"   , BF(self.VVS23T, title)    , [])
   VVMg98 = (""    , self.VV4gHS         , [])
   VVieK7 = ("Download PIcons", self.VVHVXZ        , [])
   VVgDsk = ("Options"  , BF(self.VVixac, 1, "m3Ch", "", bName) , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVQQbo  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFBL02(self, None, title=title, header=header, VVdLtF=VVLA6S, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=28, VVW0bm=VVW0bm, VVqaLK=VVqaLK, VVMg98=VVMg98, VVieK7=VVieK7, VVgDsk=VVgDsk, VVxbA6=True, searchCol=1
     , VV5mP6="#0a00192B", VVqjLk="#0a00192B", VVspm3="#0a00192B", VVANti="#00000000")
  else:
   self.VVsam4("No valid lines found !", title)
 def VVHVXZ(self, VV57kA, title, txt, colList):
  self.VVc0fn(VV57kA, "m3u/m3u8")
 def VVFGdf(self, mode, bName, VV57kA, title, txt, colList):
  bNameFile = CCUfgv.VV6gQE_forBouquet(bName)
  num  = 0
  path = VVR2Ml + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVR2Ml + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   catID = "33"
   rowNum = 0
   isMulti = VV57kA.VVdcxd
   for ndx, row in enumerate(VV57kA.VVRk4N()):
    chName = row[1].strip()
    url  = row[3].strip()
    chUrl = self.VVVhwG(rowNum, url, chName)
    rowNum += 1
    if not isMulti or VV57kA.VVe3Hb(ndx):
     f.write("#SERVICE %s\n"  % chUrl)
     f.write("#DESCRIPTION %s\n" % chName)
     totChange += 1
  FFLQO2(os.path.basename(path))
  self.VVuVs0(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVVhwG(self, rowNum, url, chName):
  refCode = self.VVpPqs(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFsvs4(url), chName)
  return chUrl
 def VVpPqs(self, rowNum, url, chName):
  span = iSearch(r"\/(\d{2,})", url, IGNORECASE)
  if span : stID = span.group(1)
  else : stID = "444"
  catID = "333"
  chNum = str(rowNum + 1)
  refCode = self.VVxbxd(catID, stID, chNum)
  return refCode
 def VVPbQ5(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVS23T(self, Title, VV57kA, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFItMF(VV57kA, BF(self.VVscPK, Title, VV57kA, colList), title="Checking Server ...")
  else:
   self.VVEDuO(VV57kA, url, chName)
 def VVscPK(self, title, VV57kA, colList):
  if not CCycDZ.VV3e4i(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CC159n.VVqAwi(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVJtuN = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCUfgv.VVQarx(url, fPath)
     VVJtuN.append((resol, fullUrl))
    if VVJtuN:
     if len(VVJtuN) > 1:
      FF0km9(self, BF(self.VVYQin, VV57kA, chName), VVJtuN=VVJtuN, title="Resolution", VVz4LU=True, VV1n4R=True)
     else:
      self.VVEDuO(VV57kA, VVJtuN[0][1], chName)
    else:
     self.VV5kIxor("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVJq6Y(txt, filterGroup="")
      return
    self.VVEDuO(VV57kA, url, chName)
   else:
    self.VVsam4("Cannot process this channel !", title)
  else:
   self.VVsam4(err, title)
 def VVYQin(self, VV57kA, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVEDuO(VV57kA, resolUrl, chName)
 def VVEDuO(self, VV57kA, url, chName):
  FFItMF(VV57kA, BF(self.VVu34Y, VV57kA, url, chName), title="Playing ...")
 def VVu34Y(self, VV57kA, url, chName):
  chUrl = self.VVVhwG(VV57kA.VVCvzs(), url, chName)
  FFTrMq(self, chUrl, VVz9ev=False)
  self.session.open(CCVY8O, portalTableParam=(self, VV57kA, "m3u/m3u8"))
 def VVjvNH(self, VV57kA, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVVhwG(VV57kA.VVCvzs(), url, chName)
  return chName, chUrl
 def VV4gHS(self, VV57kA, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFsVRo(self, fncMode=CCSQQx.VV9y9G, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVsam4(self, err, title):
  FFc8qc(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVehj0(self, VV57kA):
  if self.m3uOrM3u8File:
   self.close()
  VV57kA.cancel()
 def VVbYAI(self, VVnkBoObj, item=None):
  FFItMF(VVnkBoObj, BF(self.VVS05y, VVnkBoObj, item))
 def VVS05y(self, VVnkBoObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVnkBoObj.VVJtuN):
    path = item[1]
    if fileExists(path):
     enc = CCkHya.VVkGCD(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = self.VVLnvr(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCUfgv.VVf7fF_forOutput()
    pListF = "%sPlaylist_%s.txt" % (path, FFSGFz())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVnkBoObj.VVJtuN)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFPt7a(self, txt, title=title)
   else:
    FFc8qc(self, "Could not obtain URLs from this file list !", title=title)
 def VVBaFd(self):
  lines = self.VVjlMA(1)
  if lines:
   lines.sort()
   VVJtuN = []
   for line in lines:
    VVJtuN.append((line, line))
   OKBtnFnc  = self.VVeHqD
   VVPpN9 = ("Delete File", self.VVJu7t)
   FF0km9(self, None, title="Select Playlist File", VVJtuN=VVJtuN, width=1200, OKBtnFnc=OKBtnFnc, VVPpN9=VVPpN9)
 def VVeHqD(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFItMF(menuInstance, BF(self.VVfuKl, menuInstance, path), title="Processing File ...")
 def VVfuKl(self, VVfSsQ, path):
  enc = CCkHya.VVkGCD(path, self)
  if enc == -1:
   return
  VVMDmE = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0]
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFPG8X(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCUfgv.VVRzQH(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVMDmE:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(filter(None, [item[5], item[0]]))
     num += 1
     VVMDmE.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVMDmE:
   title = "Playlist File : %s" % os.path.basename(path)
   VVW0bm  = ("Start"    , BF(self.VVe7B0, "Playlist File")      , [])
   VV39uD = ("Home Menu"   , FF7VFz             , [])
   VVieK7 = ("Download M3U File" , self.VVza9g         , [])
   VVgDsk = ("Edit File"   , BF(self.VVFEvc, path)        , [])
   VVS9I3 = ("Check & Filter"  , BF(self.VVcMj1, VVfSsQ, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVQQbo  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFBL02(self, None, title=title, header=header, VVdLtF=VVMDmE, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=26, VVW0bm=VVW0bm, VV39uD=VV39uD, VVS9I3=VVS9I3, VVieK7=VVieK7, VVgDsk=VVgDsk, VV5mP6="#11001116", VVqjLk="#11001116", VVspm3="#11001116", VVANti="#00003635", VVxA4o="#0a333333", VVVSpS="#11331100", VVxbA6=True)
  else:
   FFc8qc(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVza9g(self, VV57kA, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFAIFY(self, BF(FFItMF, VV57kA, BF(self.VVgDfw, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVgDfw(self, title, url):
  path, err = FFWvl5(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFc8qc(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFt4Zg(path)
   if '{"user_info":{"auth":0}}' in txt:
    os.system(FFIwml("rm -f '%s'" % path))
    FFc8qc(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    os.system(FFIwml("rm -f '%s'" % path))
    FFc8qc(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCUfgv.VVf7fF_forOutput() + fName
    os.system(FFIwml("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FF9xND(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFc8qc(self, "Could not download the M3U file!", title=errTitle)
 def VVe7B0(self, Title, VV57kA, title, txt, colList):
  url = colList[6]
  FFItMF(VV57kA, BF(self.VVGYrU, Title, url), title="Checking Server ...")
 def VVFEvc(self, path, VV57kA, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCQnPl(self, path, VVOIg8=BF(self.VVcmm3, VV57kA), curRowNum=rowNum)
  else    : FFJJSt(self, path)
 def VVcmm3(self, VV57kA, fileChanged):
  if fileChanged:
   VV57kA.cancel()
 def VVj2Bf(self, title):
  curChName = self.VV57kA.VVIrRe(1)
  FFBJqp(self, BF(self.VV8fbL, title), defaultText=curChName, title=title, message="Enter Name:")
 def VV8fbL(self, title, name):
  if name:
   VV6j5n, err = CCcNAu.VVRQtF(self, CCcNAu.VVTCFS, VVs2Ke=False, VV1LYo=False)
   list = []
   if VV6j5n:
    VVuSz1 = CC6QHf()
    name = VVuSz1.VVfZ6Y(name)
    ratio = "1"
    for item in VV6j5n:
     if name in item[0].lower():
      list.append((item[0], FFNqvq(item[2]), item[3], ratio))
   if list : self.VVkK9k(list, title)
   else : FFc8qc(self, "Not found:\n\n%s" % name, title=title)
 def VV9moS(self, title):
  curChName = self.VV57kA.VVIrRe(1)
  self.session.open(CC5Qg8, barTheme=CC5Qg8.VVEF3W
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVmTKE
      , VVOIg8 = BF(self.VV91S7, title, curChName))
 def VVmTKE(self, VVx8U3):
  curChName = self.VV57kA.VVIrRe(1)
  VV6j5n, err = CCcNAu.VVRQtF(self, CCcNAu.VVL1Rg, VVs2Ke=False, VV1LYo=False)
  if not VV6j5n or not VVx8U3 or VVx8U3.isCancelled:
   return
  VVx8U3.VVLA6S = []
  VVx8U3.VVVu3x(len(VV6j5n))
  VVuSz1 = CC6QHf()
  curCh = VVuSz1.VVfZ6Y(curChName)
  for refCode in VV6j5n:
   chName, sat, inDB = VV6j5n.get(refCode, ("", "", 0))
   ratio = CC2T9T.VVVHBT(chName.lower(), curCh)
   if not VVx8U3 or VVx8U3.isCancelled:
    return
   VVx8U3.VVGACS(1, True)
   if VVx8U3 and ratio > 50:
    VVx8U3.VVLA6S.append((chName, FFNqvq(sat), refCode.replace("_", ":"), str(ratio)))
 def VV91S7(self, title, curChName, VVFnA0, VVLA6S, threadCounter, threadTotal, threadErr):
  if VVLA6S: self.VVkK9k(VVLA6S, title)
  elif VVFnA0: FFc8qc(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVkK9k(self, VVMDmE, title):
  curChName = self.VV57kA.VVIrRe(1)
  VVPcxU = self.VV57kA.VVIrRe(4)
  curUrl  = self.VV57kA.VVIrRe(5)
  VVMDmE = sorted(VVMDmE, key=lambda x: (100-int(x[3]), x[0].lower()))
  VVW0bm  = ("Share Sat/C/T Ref.", BF(self.VVL5uh, title, curChName, VVPcxU, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFBL02(self, None, title=title, header=header, VVdLtF=VVMDmE, VVGpzZ=widths, VVYOiV=26, VVW0bm=VVW0bm, VV5mP6="#0a00112B", VVqjLk="#0a001126", VVspm3="#0a001126", VVANti="#00000000")
 def VVL5uh(self, newtitle, curChName, VVPcxU, curUrl, VV57kA, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVPcxU, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFAIFY(self.VV57kA, BF(FFItMF, self.VV57kA, BF(self.VV3eBP, VV57kA, data)), ques, title=newtitle, VV1oM4=True)
 def VV3eBP(self, VV57kA, data):
  VV57kA.cancel()
  title, curChName, VVPcxU, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVPcxU = VVPcxU.strip()
  newRefCode = newRefCode.strip()
  if not VVPcxU.endswith(":") : VVPcxU += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVPcxU, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVPcxU + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVLFZv():
    txt = FFt4Zg(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFSZ2d()
    newRow = []
    for i in range(6):
     newRow.append(self.VV57kA.VVIrRe(i))
    newRow[4] = newRefCode
    done = self.VV57kA.VVe4HT(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FF1Gz0(BF(FF9xND , self, resTxt, title=title))
  elif resErr: FF1Gz0(BF(FFc8qc, self, resErr, title=title))
 def VVcMj1(self, VVfSsQ, path, VV57kA, title, txt, colList):
  self.session.open(CC5Qg8, barTheme=CC5Qg8.VVDgZs
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVz84l, VV57kA)
      , VVOIg8 = BF(self.VVIcvW, VVfSsQ, path, VV57kA))
 def VVz84l(self, VV57kA, VVx8U3):
  VVx8U3.VVVu3x(VV57kA.VVDvsh())
  VVx8U3.VVLA6S = []
  for row in VV57kA.VVRk4N():
   if not VVx8U3 or VVx8U3.isCancelled:
    return
   VVx8U3.VVGACS(1, True)
   qUrl = self.VVFaZu(self.VVWvYA, row[6])
   txt, err = self.VVyKpQ(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVh28z(item, "auth") == "0":
       VVx8U3.VVLA6S.append(qUrl)
    except:
     pass
 def VVIcvW(self, VVfSsQ, path, VV57kA, VVFnA0, VVLA6S, threadCounter, threadTotal, threadErr):
  if VVFnA0:
   list = VVLA6S
   title = "Authorized Servers"
   if list:
    totChk = VV57kA.VVDvsh()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFSGFz()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVBaFd()
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FF0IFC(str(totAuth), VV9pCx)
     txt += "%s\n\n%s"    %  (FF0IFC("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFPt7a(self, txt, title=title)
     VV57kA.close()
     VVfSsQ.close()
    else:
     FF9xND(self, "All URLs are authorized.", title=title)
   else:
    FFc8qc(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVyKpQ(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   cont = res.headers.get("Content-Type")
   if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
    return "", "Unexpected server data type ( %s )" % cont
   res = res.read().decode("UTF-8")
   if res:
    if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server !"
    else           : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVRzQH(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVOsYy(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVFaZu(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVRzQH(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVWvYA   : return "%s"            % url
  elif mode == self.VVA2rD   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVB7NO   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVLfSL  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVZVZb  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVAYGf : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVuG2I   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVjCRR    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VV2uBs  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVnyRU : return "%s&action=get_live_streams"      % url
  elif mode == self.VV9X38  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVh28z(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFjsXk(int(val))
    elif is_base64 : val = FFwC08(val)
    elif isToHHMMSS : val = FF2LS5(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VV9i2u(self, title, path):
  if fileExists(path):
   enc = CCkHya.VVkGCD(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = self.VVLnvr(line)
     if qUrl:
      break
   if qUrl : self.VVGYrU(title, qUrl)
   else : FFc8qc(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFc8qc(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVKZuG_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVWCwJ()
  if qUrl or "chCode" in iptvRef:
   p = CC159n()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVX4e8(iptvRef)
   if valid:
    self.VVKZuG(self, host, mac)
    return
   elif qUrl:
    FFItMF(self, BF(self.VVGYrU, title, qUrl), title="Checking Server ...")
    return
  FFc8qc(self, "Error in current channel URL !", title=title)
 def VVWCwJ(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self)
  qUrl = self.VVLnvr(decodedUrl)
  return qUrl, iptvRef
 def VVLnvr(self, url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVGYrU(self, title, url):
  self.VVpbZSData = {}
  qUrl = self.VVFaZu(self.VVWvYA, url)
  txt, err = self.VVyKpQ(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVpbZSData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVpbZSData["username"    ] = self.VVh28z(item, "username"        )
    self.VVpbZSData["password"    ] = self.VVh28z(item, "password"        )
    self.VVpbZSData["message"    ] = self.VVh28z(item, "message"        )
    self.VVpbZSData["auth"     ] = self.VVh28z(item, "auth"         )
    self.VVpbZSData["status"    ] = self.VVh28z(item, "status"        )
    self.VVpbZSData["exp_date"    ] = self.VVh28z(item, "exp_date"    , isDate=True )
    self.VVpbZSData["is_trial"    ] = self.VVh28z(item, "is_trial"        )
    self.VVpbZSData["active_cons"   ] = self.VVh28z(item, "active_cons"       )
    self.VVpbZSData["created_at"   ] = self.VVh28z(item, "created_at"   , isDate=True )
    self.VVpbZSData["max_connections"  ] = self.VVh28z(item, "max_connections"      )
    self.VVpbZSData["allowed_output_formats"] = self.VVh28z(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVpbZSData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVpbZSData["url"    ] = self.VVh28z(item, "url"        )
    self.VVpbZSData["port"    ] = self.VVh28z(item, "port"        )
    self.VVpbZSData["https_port"  ] = self.VVh28z(item, "https_port"      )
    self.VVpbZSData["server_protocol" ] = self.VVh28z(item, "server_protocol"     )
    self.VVpbZSData["rtmp_port"   ] = self.VVh28z(item, "rtmp_port"       )
    self.VVpbZSData["timezone"   ] = self.VVh28z(item, "timezone"       )
    self.VVpbZSData["timestamp_now"  ] = self.VVh28z(item, "timestamp_now"  , isDate=True )
    self.VVpbZSData["time_now"   ] = self.VVh28z(item, "time_now"       )
    VVJtuN  = self.VVk6vU(True)
    OKBtnFnc = self.VVpbZSOptions
    VVBLjB = ("Home Menu", FF7VFz)
    VVjEiY = ("Bookmark Server", BF(CCUfgv.VVhkMm, self, False, self.VVpbZSData["playListURL"]))
    FF0km9(self, None, title="IPTV Server Resources", VVJtuN=VVJtuN, OKBtnFnc=OKBtnFnc, VVBLjB=VVBLjB, VVjEiY=VVjEiY)
   else:
    err = "Could not get data from server !"
  if err:
   FFc8qc(self, err, title=title)
  FFlDiQ(self)
 def VVpbZSOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFItMF(menuInstance, BF(self.VVrAU2, self.VVA2rD  , title=title), title=wTxt)
   elif ref == "vod"   : FFItMF(menuInstance, BF(self.VVrAU2, self.VVB7NO  , title=title), title=wTxt)
   elif ref == "series"  : FFItMF(menuInstance, BF(self.VVrAU2, self.VVLfSL , title=title), title=wTxt)
   elif ref == "catchup"  : FFItMF(menuInstance, BF(self.VVrAU2, self.VVZVZb , title=title), title=wTxt)
   elif ref == "accountInfo" : FFItMF(menuInstance, BF(self.VVDVVi           , title=title), title=wTxt)
 def VVDVVi(self, title):
  rows = []
  for key, val in self.VVpbZSData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VV4vjd
   else:
    num, part = "1", self.VVztuX
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VV39uD  = ("Home Menu", FF7VFz, [])
  VVieK7  = None
  if VVIGxe:
   VVieK7 = ("Get JS" , BF(self.VVQIDI, "/".join(self.VVpbZSData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFBL02(self, None, title=title, width=1200, header=header, VVdLtF=rows, VVGpzZ=widths, VVYOiV=26, VV39uD=VV39uD, VVieK7=VVieK7, VV5mP6="#0a00292B", VVqjLk="#0a002126", VVspm3="#0a002126", VVANti="#00000000", searchCol=2)
 def VVZBSG(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    VVuSz1 = CC6QHf()
    if mode in (self.VVuG2I, self.VV9X38):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVh28z(item, "num"         )
      name     = self.VVh28z(item, "name"        )
      stream_id    = self.VVh28z(item, "stream_id"       )
      stream_icon    = self.VVh28z(item, "stream_icon"       )
      epg_channel_id   = self.VVh28z(item, "epg_channel_id"      )
      added     = self.VVh28z(item, "added"    , isDate=True )
      is_adult    = self.VVh28z(item, "is_adult"       )
      category_id    = self.VVh28z(item, "category_id"       )
      tv_archive    = self.VVh28z(item, "tv_archive"       )
      name = VVuSz1.VVqFkZ(name)
      if name:
       if mode == self.VVuG2I or mode == self.VV9X38 and tv_archive == "1":
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVjCRR:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVh28z(item, "num"         )
      name    = self.VVh28z(item, "name"        )
      stream_id   = self.VVh28z(item, "stream_id"       )
      stream_icon   = self.VVh28z(item, "stream_icon"       )
      added    = self.VVh28z(item, "added"    , isDate=True )
      is_adult   = self.VVh28z(item, "is_adult"       )
      category_id   = self.VVh28z(item, "category_id"       )
      container_extension = self.VVh28z(item, "container_extension"     ) or "mp4"
      name = VVuSz1.VVqFkZ(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VV2uBs:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVh28z(item, "num"        )
      name    = self.VVh28z(item, "name"       )
      series_id   = self.VVh28z(item, "series_id"      )
      cover    = self.VVh28z(item, "cover"       )
      genre    = self.VVh28z(item, "genre"       )
      episode_run_time = self.VVh28z(item, "episode_run_time"    )
      category_id   = self.VVh28z(item, "category_id"      )
      container_extension = self.VVh28z(item, "container_extension"    ) or "mp4"
      name = VVuSz1.VVqFkZ(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVrAU2(self, mode, title):
  cList, err = self.VVGIut(mode)
  if cList and mode == self.VVZVZb:
   cList = self.VVWUCh(cList)
  if err:
   FFc8qc(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VV5mP6, VVqjLk, VVspm3, VVANti = self.VVL6Lq(mode)
   mName = self.VVcFZq(mode)
   if   mode == self.VVA2rD  : fMode = self.VVuG2I
   elif mode == self.VVB7NO  : fMode = self.VVjCRR
   elif mode == self.VVLfSL : fMode = self.VV2uBs
   elif mode == self.VVZVZb : fMode = self.VV9X38
   if mode == self.VVZVZb:
    VVgDsk = None
   else:
    VVgDsk = ("Find in %s" % mName , BF(self.VVRTYX, fMode) , [])
   VVW0bm   = ("Show List"   , BF(self.VVJoz2, mode), [])
   VV39uD  = ("Home Menu"   , FF7VFz       , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFBL02(self, None, title=title, width=1200, header=header, VVdLtF=cList, VVGpzZ=widths, VVYOiV=30, VV39uD=VV39uD, VVgDsk=VVgDsk, VVW0bm=VVW0bm, VV5mP6=VV5mP6, VVqjLk=VVqjLk, VVspm3=VVspm3, VVANti=VVANti)
  else:
   FFc8qc(self, "No list from server !", title=title)
  FFlDiQ(self)
 def VVGIut(self, mode):
  qUrl  = self.VVFaZu(mode, self.VVpbZSData["playListURL"])
  txt, err = self.VVyKpQ(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    VVuSz1 = CC6QHf()
    for item in tDict:
     category_id  = self.VVh28z(item, "category_id"  )
     category_name = self.VVh28z(item, "category_name" )
     parent_id  = self.VVh28z(item, "parent_id"  )
     category_name = VVuSz1.VV97CQ(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVWUCh(self, catList):
  mode  = self.VV9X38
  qUrl  = self.VVFaZu(mode, self.VVpbZSData["playListURL"])
  txt, err = self.VVyKpQ(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVZBSG(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVJoz2(self, mode, VV57kA, title, txt, colList):
  title = colList[1]
  FFItMF(VV57kA, BF(self.VVoGa4, mode, VV57kA, title, txt, colList), title="Downloading ...")
 def VVoGa4(self, mode, VV57kA, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVcFZq(mode) + " : "+ bName
  if   mode == self.VVA2rD  : mode = self.VVuG2I
  elif mode == self.VVB7NO  : mode = self.VVjCRR
  elif mode == self.VVLfSL : mode = self.VV2uBs
  elif mode == self.VVZVZb : mode = self.VV9X38
  qUrl  = self.VVFaZu(mode, self.VVpbZSData["playListURL"], catID)
  txt, err = self.VVyKpQ(qUrl)
  list  = []
  if not err and mode in (self.VVuG2I, self.VVjCRR, self.VV2uBs, self.VV9X38):
   list, err = self.VVZBSG(mode, txt)
  if err:
   FFc8qc(self, err, title=title)
  elif list:
   VV39uD  = ("Home Menu"   , FF7VFz            , [])
   if mode in (self.VVuG2I, self.VV9X38):
    VV5mP6, VVqjLk, VVspm3, VVANti = self.VVL6Lq(mode)
    VVMg98 = (""     , BF(self.VVzzk2, mode)      , [])
    VVieK7 = ("Download Options" , BF(self.VVFbrj, mode, "", "")   , [])
    VVgDsk = ("Options"   , BF(self.VVixac, 1, "lv", mode, bName)  , [])
    if mode == self.VVuG2I:
     VVW0bm = ("Play"    , BF(self.VV3CBB, mode)       , [])
    elif mode == self.VV9X38:
     VVW0bm  = ("Programs"  , BF(self.VVJYAe_fromIptvTable, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVQQbo  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVjCRR:
    VV5mP6, VVqjLk, VVspm3, VVANti = self.VVL6Lq(mode)
    VVW0bm  = ("Play"    , BF(self.VV3CBB, mode)       , [])
    VVMg98 = (""     , BF(self.VVzzk2, mode)      , [])
    VVieK7 = ("Download Options" , BF(self.VVFbrj, mode, "v", "")   , [])
    VVgDsk = ("Options"   , BF(self.VVixac, 1, "v", mode, bName)  , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVQQbo  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VV2uBs:
    VV5mP6, VVqjLk, VVspm3, VVANti = self.VVL6Lq("series2")
    VVW0bm  = ("Show Seasons"  , BF(self.VVgVkQ, mode)       , [])
    VVMg98 = (""     , BF(self.VVJmjP, mode)     , [])
    VVieK7 = None
    VVgDsk = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVQQbo  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFBL02(self, None, title=title, header=header, VVdLtF=list, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=26, VVW0bm=VVW0bm, VV39uD=VV39uD, VVieK7=VVieK7, VVgDsk=VVgDsk, VVMg98=VVMg98, VV5mP6=VV5mP6, VVqjLk=VVqjLk, VVspm3=VVspm3, VVANti=VVANti, VVxbA6=True, searchCol=1)
  else:
   FFc8qc(self, "No Channels found !", title=title)
  FFlDiQ(self)
 def VVJYAe_fromIptvTable(self, mode, bName, VV57kA, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVpbZSData["playListURL"]
  ok_fnc  = BF(self.VVWdUl, hostUrl, chName, catId, streamId)
  FFItMF(VV57kA, BF(CCUfgv.VVJYAe, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVWdUl(self, chUrl, chName, catId, streamId, VV57kA, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCUfgv.VVRzQH(chUrl)
   chNum = "333"
   refCode = CCUfgv.VVxbxd(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFTrMq(self, chUrl, VVz9ev=False)
   self.session.open(CCVY8O)
  else:
   FFc8qc(self, "Incorrect Timestamp", pTitle)
 def VVgVkQ(self, mode, VV57kA, title, txt, colList):
  title = colList[1]
  FFItMF(VV57kA, BF(self.VVc5Wj, mode, VV57kA, title, txt, colList), title="Downloading ...")
 def VVc5Wj(self, mode, VV57kA, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVFaZu(self.VVAYGf, self.VVpbZSData["playListURL"], series_id)
  txt, err = self.VVyKpQ(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVh28z(tDict["info"], "name"   )
      category_id = self.VVh28z(tDict["info"], "category_id" )
      icon  = self.VVh28z(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      VVuSz1 = CC6QHf()
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVh28z(EP, "id"     )
        episode_num   = self.VVh28z(EP, "episode_num"   )
        epTitle    = self.VVh28z(EP, "title"     )
        container_extension = self.VVh28z(EP, "container_extension" )
        seasonNum   = self.VVh28z(EP, "season"    )
        epTitle = VVuSz1.VVqFkZ(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFc8qc(self, err, title=title)
  elif list:
   VV39uD = ("Home Menu"   , FF7VFz           , [])
   VVieK7 = ("Download Options" , BF(self.VVFbrj, mode, "s", title) , [])
   VVgDsk = ("Options"   , BF(self.VVixac, 0, "s", mode, title) , [])
   VVMg98 = (""     , BF(self.VVzzk2, mode)     , [])
   VVW0bm  = ("Play"    , BF(self.VV3CBB, mode)      , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVQQbo  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFBL02(self, None, title=title, header=header, VVdLtF=list, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=26, VV39uD=VV39uD, VVieK7=VVieK7, VVW0bm=VVW0bm, VVMg98=VVMg98, VVgDsk=VVgDsk, VV5mP6="#0a00292B", VVqjLk="#0a002126", VVspm3="#0a002126", VVANti="#00000000")
  else:
   FFc8qc(self, "No Channels found !", title=title)
  FFlDiQ(self)
 def VVRTYX(self, mode, VV57kA, title, txt, colList):
  VVJtuN = []
  VVJtuN.append(("Keyboard"  , "manualEntry"))
  VVJtuN.append(("From Filter" , "fromFilter"))
  FF0km9(self, BF(self.VVXFA0, VV57kA, mode), title="Input Type", VVJtuN=VVJtuN, width=400)
 def VVXFA0(self, VV57kA, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFBJqp(self, BF(self.VVkQRg, VV57kA, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCfaXJ(self)
    filterObj.VV8EPH(BF(self.VVkQRg, VV57kA, mode))
 def VVkQRg(self, VV57kA, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    VVuSz1 = CC6QHf()
    if CFG.hideIptvServerAdultWords.getValue() and VVuSz1.VV9tOp(words):
     FFc8qc(self, VVuSz1.VVUK2i(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CC5Qg8, barTheme=CC5Qg8.VVEF3W
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = BF(self.VVnOxW, VV57kA, mode, title, words, toFind, asPrefix, VVuSz1)
         , VVOIg8 = BF(self.VVYneD, mode, toFind, title))
   else:
    FFc8qc(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VVnOxW(self, VV57kA, mode, title, words, toFind, asPrefix, VVuSz1, VVx8U3):
  VVx8U3.VVVu3x(VV57kA.VVlvlo())
  VVx8U3.VVLA6S = []
  for row in VV57kA.VVRk4N():
   catName = row[0]
   catID = row[1]
   if not VVx8U3 or VVx8U3.isCancelled:
    return
   VVx8U3.VVGACS(1)
   VVx8U3.VVQyWe_fromIptvFind(catName)
   qUrl  = self.VVFaZu(mode, self.VVpbZSData["playListURL"], catID)
   txt, err = self.VVyKpQ(qUrl)
   if not err:
    tList, err = self.VVZBSG(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = VVuSz1.VVqFkZ(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VVuG2I:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        VVx8U3.VVLA6S.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVjCRR:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        VVx8U3.VVLA6S.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VV2uBs:
        num, name, catID, ID, genre, dur, ext, cover = item
        VVx8U3.VVLA6S.append((num, name, catID, ID, genre, catName, ext, cover))
 def VVYneD(self, mode, toFind, title, VVFnA0, VVLA6S, threadCounter, threadTotal, threadErr):
  if VVLA6S:
   title = self.VVKomW(mode, toFind)
   if mode == self.VVuG2I or mode == self.VVjCRR:
    if mode == self.VVjCRR : typ = "v"
    else          : typ = ""
    bName   = CCUfgv.VV6gQE_forBouquet(toFind)
    VVW0bm  = ("Play"     , BF(self.VV3CBB, mode)      , [])
    VVieK7 = ("Download Options" , BF(self.VVFbrj, mode, typ, "")  , [])
    VVgDsk = ("Options"   , BF(self.VVixac, 1, "fnd", mode, bName) , [])
   elif mode == self.VV2uBs:
    VVW0bm  = ("Show Seasons"  , BF(self.VVgVkQ, mode)      , [])
    VVgDsk = None
    VVieK7 = None
   VVMg98  = (""     , BF(self.VVzzk2, mode)     , [])
   VV39uD  = ("Home Menu"   , FF7VFz           , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVQQbo  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VV57kA = FFBL02(self, None, title=title, header=header, VVdLtF=VVLA6S, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=26, VVW0bm=VVW0bm, VV39uD=VV39uD, VVieK7=VVieK7, VVgDsk=VVgDsk, VVMg98=VVMg98, VV5mP6="#0a00292B", VVqjLk="#0a002126", VVspm3="#0a002126", VVANti="#00000000", VVxbA6=True, searchCol=1)
   if not VVFnA0:
    FFlDiQ(VV57kA, "Stopped" , 1000)
  else:
   if VVFnA0:
    FFc8qc(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVeX0N(self, mode, colList):
  if mode in (self.VVuG2I, self.VV9X38):
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVjCRR:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFj0Hy(chName)
  url = self.VVpbZSData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVRzQH(url)
  refCode = self.VVxbxd(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVzzk2(self, mode, VV57kA, title, txt, colList):
  FFItMF(VV57kA, BF(self.VVTDmb, mode, VV57kA, title, txt, colList))
 def VVTDmb(self, mode, VV57kA, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVeX0N(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFsVRo(self, fncMode=CCSQQx.VVHkWH, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVJmjP(self, mode, VV57kA, title, txt, colList):
  FFItMF(VV57kA, BF(self.VV78E8, mode, VV57kA, title, txt, colList))
 def VV78E8(self, mode, VV57kA, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFsVRo(self, fncMode=CCSQQx.VV9OPu, chName=name, text=txt, picUrl=Cover)
 def VVncaq(self, mode, bName, VV57kA, title, txt, colList):
  url = self.VVpbZSData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVRzQH(url)
  bNameFile = CCUfgv.VV6gQE_forBouquet(bName)
  num  = 0
  path = VVR2Ml + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVR2Ml + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   isMulti = VV57kA.VVdcxd
   for ndx, row in enumerate(VV57kA.VVRk4N()):
    chName, chUrl, picUrl, refCode = self.VVeX0N(mode, row)
    if not isMulti or VV57kA.VVe3Hb(ndx):
     f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
     f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
     totChange += 1
  FFLQO2(os.path.basename(path))
  self.VVuVs0(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVFbrj(self, mode, typ, seriesName, VV57kA, title, txt, colList):
  VVJtuN = []
  isMulti = VV57kA.VVdcxd
  tot  = VV57kA.VV400b()
  if isMulti:
   if tot < 1:
    FFlDiQ(VV57kA, "Select rows first.", 1000)
    return
   else:
    s = "s" if tot > 1 else ""
    name = "%d Selected" % tot
  else:
   s = "s"
   name = "ALL"
  VVJtuN.append(("Download %s PIcon%s" % (name, s), "dnldPicons" ))
  if typ:
   VVJtuN.append(VVImCt)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVJtuN.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVJtuN.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVJtuN.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCUd13.VVogwQ():
    VVJtuN.append(VVImCt)
    VVJtuN.append(("Download Manager"      , "dload_stat" ))
  FF0km9(self, BF(self.VVPNeF_VVZp3N, VV57kA, mode, typ, seriesName, colList), title="Download Options", VVJtuN=VVJtuN)
 def VVPNeF_VVZp3N(self, VV57kA, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVc0fn(VV57kA, mode)
   elif item == "dnldSel"  : self.VVZ2zx(VV57kA, mode, typ, colList, True)
   elif item == "addSel"  : self.VVZ2zx(VV57kA, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VV5lAn(VV57kA, mode, typ, seriesName)
   elif item == "dload_stat" : CCUd13.VVw9wz(self)
 def VVZ2zx(self, VV57kA, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVFUI0(mode, typ, colList)
  if startDnld:
   CCUd13.VVMKiE_url(self, decodedUrl)
  else:
   self.VVZp3N_FFAIFY(VV57kA, "Add to Download list", chName, [decodedUrl], startDnld)
 def VV5lAn(self, VV57kA, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VV57kA.VVRk4N():
   chName, decodedUrl = self.VVFUI0(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVZp3N_FFAIFY(VV57kA, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVZp3N_FFAIFY(self, VV57kA, title, chName, decodedUrl_list, startDnld):
  FFAIFY(self, BF(self.VVS9iC, VV57kA, decodedUrl_list, startDnld), chName, title=title)
 def VVS9iC(self, VV57kA, decodedUrl_list, startDnld):
  added, skipped = CCUd13.VVJ7yZList(decodedUrl_list)
  FFlDiQ(VV57kA, "Added", 1000)
 def VVFUI0(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVeX0N(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVAwOU(mode, colList)
   refCode, chUrl = self.VVhg1T(self.VVvMdx, self.VVMQC5, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFDfd9(chUrl)
  return chName, decodedUrl
 def VVc0fn(self, VV57kA, mode):
  if os.system(FFIwml("which ffmpeg")) == 0:
   self.session.open(CC5Qg8, barTheme=CC5Qg8.VVDgZs
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VVqGHL, VV57kA, mode)
       , VVOIg8 = self.VV9mC5)
  else:
   FFAIFY(self, BF(CCUfgv.VVw8r1, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VV9mC5(self, VVFnA0, VVLA6S, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVLA6S["proces"], VVLA6S["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVLA6S["ok"], VVLA6S["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVLA6S["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVLA6S["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVLA6S["badURL"]
  txt += "Download Failure\t: %d\n"   % VVLA6S["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVLA6S["path"]
  if not VVFnA0  : color = "#11402000"
  elif VVLA6S["err"]: color = "#11201000"
  else     : color = None
  if VVLA6S["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVLA6S["err"], txt)
  title = "PIcons Download Result"
  if not VVFnA0:
   title += "  (cancelled)"
  FFPt7a(self, txt, title=title, VVspm3=color)
 def VVqGHL(self, VV57kA, mode, VVx8U3):
  isMulti = VV57kA.VVdcxd
  if isMulti : totRows = VV57kA.VV400b()
  else  : totRows = VV57kA.VVlvlo()
  VVx8U3.VVVu3x(totRows)
  counter     = VVx8U3.counter
  maxValue    = VVx8U3.maxValue
  pPath     = CC2T9T.VVP17o()
  VVx8U3.VVLA6S = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for rowNum, row in enumerate(VV57kA.VVRk4N()):
    if VVx8U3.isCancelled:
     break
    if not isMulti or VV57kA.VVe3Hb(rowNum):
     VVx8U3.VVLA6S["proces"] += 1
     VVx8U3.VVGACS(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVAwOU(mode, row)
      refCode = CCUfgv.VVxbxd(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVpPqs(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVeX0N(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVx8U3.VVLA6S["attempt"] += 1
       path, err = FFWvl5(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        VVx8U3.VVLA6S["ok"] += 1
        if FFEZp1(path) > 0:
         cmd = ""
         if not mode == CCUfgv.VVuG2I:
          cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
         cmd += FFIwml("mv -f '%s' '%s'" % (path, pPath)) + ";"
         os.system(cmd)
        else:
         VVx8U3.VVLA6S["size0"] += 1
         os.system(FFIwml("rm -f '%s'" % path))
       elif err:
        VVx8U3.VVLA6S["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         VVx8U3.VVLA6S["err"] = err.title()
         break
      else:
       VVx8U3.VVLA6S["exist"] += 1
     else:
      VVx8U3.VVLA6S["badURL"] += 1
  except:
   pass
 @staticmethod
 def VVw8r1(SELF):
  cmd = FFxvW9(VVKMZF, "ffmpeg")
  if cmd : FFjX9J(SELF, cmd, title="Installing FFmpeg")
  else : FFa4IH(SELF)
 def VVOVr0(self):
  self.session.open(CC5Qg8, barTheme=CC5Qg8.VVDgZs
      , titlePrefix = ""
      , fncToRun  = self.VV19yF
      , VVOIg8 = self.VVQEaS)
 def VV19yF(self, VVx8U3):
  bName = FFOc9w()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVx8U3.VVLA6S = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = FFn5xE()
  if not VVx8U3 or VVx8U3.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVx8U3.VVVu3x(totCh)
   for serv in services:
    if not VVx8U3 or VVx8U3.isCancelled:
     return
    VVx8U3.VVGACS(1)
    VVx8U3.VVQyWe_fromImportEPG(totEpgOK, uChName)
    fullRef  = serv[0]
    if FFgKj2(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFDfd9(fullRef)
     span = iSearch(r"(mode=.+end=)", fullRef, IGNORECASE)
     if span:
      m3u_Url = CC159n.VVCuCW(fullRef)
      uType, uHost, uUser, uPass, uId, uChName  = CCUfgv.VVOsYy(fullRef)
      uType, uHost, uUser, uPass, uId, uChName1 = CCUfgv.VVOsYy(m3u_Url)
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCUfgv.VVOsYy(m3u_Url)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCUfgv.VVxC9H(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCSQQx.VV6yTh(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
      else:
       pass
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if VVx8U3:
     VVx8U3.VVLA6S = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVx8U3.VVLA6S = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VVQEaS(self, VVFnA0, VVLA6S, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVLA6S
  title = "IPTV EPG Import"
  if err:
   FFc8qc(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FF0IFC(str(totNotIptv), VVyU04)
    if totServErr : txt += "Server Errors\t: %s\n" % FF0IFC(str(totServErr) + t1, VVyU04)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FF0IFC(str(totInv), VVyU04)
   if not VVFnA0:
    title += "  (stopped)"
   FFPt7a(self, txt, title=title)
 @staticmethod
 def VVxC9H(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCUfgv.VVRzQH(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCUfgv.VVyKpQ(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCUfgv.VVh28z(item, "description" , is_base64=True ).replace("\n", " .. ")
    has_archive   = CCUfgv.VVh28z(item, "has_archive"      )
    lang    = CCUfgv.VVh28z(item, "lang"        ).upper()
    now_playing   = CCUfgv.VVh28z(item, "now_playing"      )
    start    = CCUfgv.VVh28z(item, "start"        )
    start_timestamp  = CCUfgv.VVh28z(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCUfgv.VVh28z(item, "start_timestamp"     )
    stop_timestamp  = CCUfgv.VVh28z(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCUfgv.VVh28z(item, "stop_timestamp"      )
    tTitle    = CCUfgv.VVh28z(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVxbxd(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCUfgv.VVaS8s(catID, MAX_4b)
  TSID = CCUfgv.VVaS8s(chNum, MAX_4b)
  ONID = CCUfgv.VVaS8s(chNum, MAX_4b)
  NS  = CCUfgv.VVaS8s(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVaS8s(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VV6gQE_forBouquet(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVL6Lq(mode):
  if   mode in ("itv"  , CCUfgv.VVA2rD)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCUfgv.VVB7NO)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCUfgv.VVLfSL) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCUfgv.VVZVZb) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCUfgv.VV9X38    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVjlMA(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVmyfR:
   excl = FFaoFr(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FFc8qc(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FFOAMF('find %s %s %s' % (path, excl, par))
  if not files:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FFc8qc(self, err)
  elif len(files) == 1 and files[0] == VVBIfo:
   FFc8qc(self, VVBIfo)
  else:
   return files
 @staticmethod
 def VVf7fF_forOutput():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FFPG8X(path)
  return "/"
 @staticmethod
 def VVJYAe(SELF, hostUrl, chName, streamId, ok_fnc):
  title = "Catchup TV Programs"
  pList, err = CCUfgv.VVxC9H(hostUrl, streamId, True)
  if err:
   FFc8qc(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VV5mP6, VVqjLk, VVspm3, VVANti = CCUfgv.VVL6Lq("")
   VV39uD = ("Home Menu" , FF7VFz, [])
   VVW0bm  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVQQbo  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFBL02(SELF, None, title="Programs for : " + chName, header=header, VVdLtF=pList, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=24, VVW0bm=VVW0bm, VV39uD=VV39uD, VV5mP6=VV5mP6, VVqjLk=VVqjLk, VVspm3=VVspm3, VVANti=VVANti)
  else:
   FFc8qc(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVQarx(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 @staticmethod
 def VVhkMm(SELF, isPortal, line, VVnkBoObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCUfgv.VVf7fF_forOutput()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFc8qc(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FF9xND(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFc8qc(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVixac(self, nameCol, source, mode, bName, VV57kA, title, txt, colList):
  isMulti = VV57kA.VVdcxd
  mSel = CCZSNQ(self, VV57kA, nameCol, addSep=False)
  title = ""
  if isMulti:
   tot = VV57kA.VV400b()
   if tot > 0:
    s = "s" if tot > 1 else ""
    title = "Add %d Service%s to Bouquet" % (tot, s)
  else:
   title = "Add ALL to Bouquet"
  if title:
   mSel.VVJtuN.append(VVImCt)
   mSel.VVJtuN.append((title        , "addToBoquet"))
  FF0km9(self, BF(self.VV7RxI, mSel, source, mode, bName, VV57kA, title, txt, colList), title="Options", VVJtuN=mSel.VVJtuN)
 def VV7RxI(self, mSelObj, source, mode, bName, VV57kA, title, txt, colList, item):
  if item:
   if   item == "multSelEnab"     : mSelObj.VV57kA.VVK3X1(True)
   elif item == "MultSelDisab"     : mSelObj.VV57kA.VVK3X1(False)
   elif item == "selectAll"     : mSelObj.VV57kA.VVjT42()
   elif item == "unselectAll"     : mSelObj.VV57kA.VVMAg1()
   elif item == "addToBoquet"     :
    if   source == "pEp" : fnc = self.VVOVe7
    elif source == "pCh" : fnc = self.VVOVe7
    elif source == "m3Ch" : fnc = self.VVFGdf
    elif source == "lv"  : fnc = self.VVncaq
    elif source == "v"  : fnc = self.VVncaq
    elif source == "s"  : fnc = self.VVncaq
    elif source == "fnd" : fnc = self.VVncaq
    else     : return
    FFItMF(VV57kA, BF(fnc, mode, bName, VV57kA, title, txt, colList), title="Adding Channels ...")
class CCKAMZ(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFi9TE(VVavIl, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVYCrF  = 0
  self.VVRcck = 1
  self.VVjqTG  = 2
  VVJtuN = []
  VVJtuN.append(("Find in All Service (from filter)" , "VVpqP3" ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Find in All (Manual Entry)"   , "VVK4hp"    ))
  VVJtuN.append(("Find in TV"       , "VV6SnF"    ))
  VVJtuN.append(("Find in Radio"      , "VVcsFw"   ))
  if self.VVtn3x():
   VVJtuN.append(VVImCt)
   VVJtuN.append(("Hide Channel: %s" % self.servName , "VVYxvy"   ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Zap History"       , "VVUZux"    ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("IPTV Tools"       , "iptv"      ))
  VVJtuN.append(("PIcons Tools"       , "PIconsTools"     ))
  VVJtuN.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FFRqJR(self, VVJtuN=VVJtuN, title=title)
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FF7a1g(self["myMenu"])
  FFvDVP(self)
  if self.isFindMode:
   self.VVNU7M(self.VVDZFa())
 def VVlQQ7(self):
  global VV7k9C
  VV7k9C = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVK4hp"    : self.VVK4hp()
   elif item == "VVpqP3" : self.VVpqP3()
   elif item == "VV6SnF"    : self.VV6SnF()
   elif item == "VVcsFw"   : self.VVcsFw()
   elif item == "VVYxvy"   : self.VVYxvy()
   elif item == "VVUZux"    : self.VVUZux()
   elif item == "iptv"       : self.session.open(CCUfgv)
   elif item == "PIconsTools"     : self.session.open(CC2T9T)
   elif item == "ChannelsTools"    : self.session.open(CCcNAu)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VV6SnF(self) : self.VVNU7M(self.VVYCrF)
 def VVcsFw(self) : self.VVNU7M(self.VVRcck)
 def VVK4hp(self) : self.VVNU7M(self.VVjqTG)
 def VVNU7M(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFBJqp(self, BF(self.VVuT80, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVpqP3(self):
  filterObj = CCfaXJ(self)
  filterObj.VV8EPH(self.VVNqNT)
 def VVNqNT(self, item):
  self.VVuT80(self.VVjqTG, item)
 def VVtn3x(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFgKj2(self.refCode)        : return False
  return True
 def VVuT80(self, mode, VVb9FE):
  FFItMF(self, BF(self.VVf1ZL, mode, VVb9FE), title="Searching ...")
 def VVf1ZL(self, mode, VVb9FE):
  if VVb9FE:
   self.findTxt = VVb9FE
   if   mode == self.VVYCrF  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVRcck : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVb9FE)
   if len(title) > 55:
    title = title[:55] + ".."
   VVMDmE = self.VVovQe(VVb9FE, servTypes)
   if self.isFindMode or mode == self.VVjqTG:
    VVMDmE += self.VVzQ0u(VVb9FE)
   if VVMDmE:
    VVMDmE.sort(key=lambda x: x[0].lower())
    VVqaLK = self.VVExf7
    VVW0bm  = ("Zap"   , self.VV8B0b    , [])
    VVieK7 = ("Current Service", self.VVc0tn , [])
    VVgDsk = ("Options"  , self.VVyuAB , [])
    VVMg98 = (""    , self.VVCK0t , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVQQbo  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFBL02(self, None, title=title, header=header, VVdLtF=VVMDmE, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=26, VVW0bm=VVW0bm, VVqaLK=VVqaLK, VVieK7=VVieK7, VVgDsk=VVgDsk, VVMg98=VVMg98)
   else:
    self.VVNU7M(self.VVDZFa())
    FF9xND(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVovQe(self, VVb9FE, servTypes):
  VVdLtF = CCcNAu.VVQCf1(servTypes)
  VVMDmE = []
  if VVdLtF:
   VVQUG0, VVCEke = FFlQ76()
   tp = CCMZhh()
   words, asPrefix = CCfaXJ.VVIvS9(VVb9FE)
   colorYellow  = CCEMYn.VVBx0G(VV8mIi)
   colorWhite  = CCEMYn.VVBx0G(VVmG5f)
   for s in VVdLtF:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFbHaq(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVQUG0:
        STYPE = VVCEke[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVgTRT(refCode)
       if not "-S" in syst:
        sat = syst
       VVMDmE.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVMDmE
 def VVzQ0u(self, VVb9FE):
  VVb9FE = VVb9FE.lower()
  VVMDmE = []
  colorYellow  = CCEMYn.VVBx0G(VV8mIi)
  colorWhite  = CCEMYn.VVBx0G(VVmG5f)
  for b in FFKD9U():
   VVKr5F  = b[0]
   VVcGRY  = b[1].toString()
   VVOAVO = eServiceReference(VVcGRY)
   VVRIuo = FFpZCL(VVOAVO)
   for service in VVRIuo:
    refCode  = service[0]
    if FFgKj2(refCode):
     servName = service[1]
     if VVb9FE in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVb9FE), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVMDmE.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVMDmE
 def VVDZFa(self):
  VVjITu = InfoBar.instance
  if VVjITu:
   VVtKZg = VVjITu.servicelist
   if VVtKZg:
    return VVtKZg.mode == 1
  return self.VVjqTG
 def VVExf7(self, VV57kA):
  self.close()
  VV57kA.cancel()
 def VV8B0b(self, VV57kA, title, txt, colList):
  FFTrMq(VV57kA, colList[2], VVz9ev=False, checkParentalControl=True)
 def VVc0tn(self, VV57kA, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(VV57kA)
  if refCode:
   VV57kA.VVYHYY(2, FFbKYW(refCode, iptvRef, chName), True)
 def VVyuAB(self, VV57kA, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CCZSNQ(self, VV57kA, 2)
  mSel.VVloYE(servName, refCode)
 def VVCK0t(self, VV57kA, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFsVRo(self, fncMode=CCSQQx.VVXbSo, refCode=refCode, chName=chName, text=txt)
 def VVYxvy(self):
  FFAIFY(self, self.VVhiD9, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVhiD9(self):
  ret = FFEWxD(self.refCode, True)
  if ret:
   self.VVbMNS()
   self.close()
  else:
   FFlDiQ(self, "Cannot change state" , 1000)
 def VVbMNS(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVLRYb()
  except:
   self.VVNOuU()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFyc8f(self, serviceRef)
 def VVKoiT(self):
  VVjITu = InfoBar.instance
  if VVjITu:
   VVtKZg = VVjITu.servicelist
   if VVtKZg:
    VVtKZg.setMode()
 def VVLRYb(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVjITu = InfoBar.instance
   if VVjITu:
    VVtKZg = VVjITu.servicelist
    if VVtKZg:
     hList = VVtKZg.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVtKZg.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVtKZg.history  = newList
       VVtKZg.history_pos = pos
 def VVNOuU(self):
  VVjITu = InfoBar.instance
  if VVjITu:
   VVtKZg = VVjITu.servicelist
   if VVtKZg:
    VVtKZg.history  = []
    VVtKZg.history_pos = 0
 def VVUZux(self):
  VVjITu = InfoBar.instance
  VVMDmE = []
  if VVjITu:
   VVtKZg = VVjITu.servicelist
   if VVtKZg:
    VVQUG0, VVCEke = FFlQ76()
    for chParams in VVtKZg.history:
     refCode = chParams[-1].toString()
     chName = FFupyT(refCode)
     isIptv = FFgKj2(refCode)
     if isIptv: sat = "-"
     else  : sat = FFbHaq(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVQUG0:
       STYPE = VVCEke[sTypeInt]
     VVMDmE.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVMDmE:
   VVW0bm  = ("Zap"   , self.VVLAei   , [])
   VVgDsk = ("Clear History" , self.VVVvmr   , [])
   VVMg98 = (""    , self.VVasgsFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVQQbo  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFBL02(self, None, title=title, header=header, VVdLtF=VVMDmE, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=28, VVW0bm=VVW0bm, VVgDsk=VVgDsk, VVMg98=VVMg98)
  else:
   FF9xND(self, "Not found", title=title)
 def VVLAei(self, VV57kA, title, txt, colList):
  FFTrMq(VV57kA, colList[3], VVz9ev=False, checkParentalControl=True)
 def VVVvmr(self, VV57kA, title, txt, colList):
  FFAIFY(self, BF(self.VVGd2A, VV57kA), "Clear Zap History ?")
 def VVGd2A(self, VV57kA):
  self.VVNOuU()
  VV57kA.cancel()
 def VVasgsFromZapHistory(self, VV57kA, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFsVRo(self, fncMode=CCSQQx.VVpmbB, refCode=refCode, chName=chName, text=txt)
class CC2T9T(Screen):
 VVjRIU   = 0
 VVtFry  = 1
 VVxtSy  = 2
 VVi3eS  = 3
 VVZh9G  = 4
 VVOeJg  = 5
 VVVFrY  = 6
 VVcCld  = 7
 VVRdEP = 8
 VV9Lcc = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFi9TE(VVoGN2, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFRqJR(self, self.Title)
  FFINW5(self["keyRed"] , "OK = Zap")
  FFINW5(self["keyGreen"] , "Current Service")
  FFINW5(self["keyYellow"], "Page Options")
  FFINW5(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CC2T9T.VVP17o()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVdLtF    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV6Xdy     ,
   "green"   : self.VVWSao    ,
   "yellow"  : self.VVbkGq     ,
   "blue"   : self.VV5xOu     ,
   "menu"   : self.VV8ibF     ,
   "info"   : self.VVasgs      ,
   "up"   : self.VV9SfV       ,
   "down"   : self.VVz7mm      ,
   "left"   : self.VV6YLz      ,
   "right"   : self.VVI6vA      ,
   "pageUp"  : BF(self.VVWdv6, True) ,
   "chanUp"  : BF(self.VVWdv6, True) ,
   "pageDown"  : BF(self.VVWdv6, False) ,
   "chanDown"  : BF(self.VVWdv6, False) ,
   "next"   : self.VVQwuu     ,
   "last"   : self.VVU1Td      ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FFmyX2(self)
  FFSrMl(self)
  FFLgZ9(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFItMF(self, BF(self.VVi5lA, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VV8ibF(self):
  if not self.isBusy:
   VVJtuN = []
   VVJtuN.append(("Statistics"           , "VVMX4F"    ))
   VVJtuN.append(VVImCt)
   VVJtuN.append(("Suggest PIcons for Current Channel"     , "VVwzM2"   ))
   VVJtuN.append(("Set to Current Channel (copy file)"     , "VVAzPu_file"  ))
   VVJtuN.append(("Set to Current Channel (as SymLink)"     , "VVAzPu_link"  ))
   VVJtuN.append(VVImCt)
   VVJtuN.append(CC2T9T.VVw0Q9())
   VVJtuN.append(VVImCt)
   if self.filterTitle == "PIcons without Channels":
    c = VVyU04
    VVJtuN.append((FF0IFC("Move Unused PIcons to a Directory", c) , "VVTFX4"  ))
    VVJtuN.append((FF0IFC("DELETE Unused PIcons", c)    , "VVZUN8" ))
    VVJtuN.append(VVImCt)
   VVJtuN.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVjzl3"  ))
   VVJtuN.append(VVImCt)
   VVJtuN += CC2T9T.VVXAbb()
   VVJtuN.append(VVImCt)
   VVJtuN.append(("RCU Keys Help"          , "VVBOuM"    ))
   FF0km9(self, self.VVPNeF, title=self.Title, VVJtuN=VVJtuN)
 def VVPNeF(self, item=None):
  if item is not None:
   if   item == "VVMX4F"     : self.VVMX4F()
   elif item == "VVwzM2"    : self.VVwzM2()
   elif item == "VVAzPu_file"   : self.VVAzPu(0)
   elif item == "VVAzPu_link"   : self.VVAzPu(1)
   elif item == "VV4btc_file"  : self.VV4btc(0)
   elif item == "VV4btc_link"  : self.VV4btc(1)
   elif item == "VVZYLD"   : self.VVZYLD()
   elif item == "VV9cyG"  : self.VV9cyG()
   elif item == "VVTFX4"    : self.VVTFX4()
   elif item == "VVZUN8"   : self.VVZUN8()
   elif item == "VVjzl3"   : self.VVjzl3()
   elif item == "VV6kpa"   : CC2T9T.VV6kpa(self)
   elif item == "VVVM2i"   : CC2T9T.VVVM2i(self)
   elif item == "findPiconBrokenSymLinks"  : CC2T9T.VVZgX1(self, True)
   elif item == "FindAllBrokenSymLinks"  : CC2T9T.VVZgX1(self, False)
   elif item == "VVBOuM"      : self.VVBOuM()
 def VVbkGq(self):
  if not self.isBusy:
   VVJtuN = []
   VVJtuN.append(("Go to First PIcon"  , "VVBJtz"  ))
   VVJtuN.append(("Go to Last PIcon"   , "VVJZyT"  ))
   VVJtuN.append(VVImCt)
   VVJtuN.append(("Sort by Channel Name"     , "sortByChan" ))
   VVJtuN.append(("Sort by File Name"  , "sortByFile" ))
   VVJtuN.append(VVImCt)
   VVJtuN.append(("Find from File List .." , "VVxalp" ))
   FF0km9(self, self.VViA3b, title=self.Title, VVJtuN=VVJtuN)
 def VViA3b(self, item=None):
  if item is not None:
   if   item == "VVBJtz"   : self.VVBJtz()
   elif item == "VVJZyT"   : self.VVJZyT()
   elif item == "sortByChan"  : self.VV97Cr(2)
   elif item == "sortByFile"  : self.VV97Cr(0)
   elif item == "VVxalp"  : self.VVxalp()
 def VVBOuM(self):
  FFsJjT(self, VVAquH + "_help_picons", "PIcons Tools (Keys Help)")
 def VV9SfV(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVJZyT()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVYL05()
 def VVz7mm(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVBJtz()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVYL05()
 def VV6YLz(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVJZyT()
  else:
   self.curCol -= 1
   self.VVYL05()
 def VVI6vA(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVBJtz()
  else:
   self.curCol += 1
   self.VVYL05()
 def VVU1Td(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVYL05(True)
 def VVQwuu(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVYL05(True)
 def VVBJtz(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVYL05(True)
 def VVJZyT(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVYL05(True)
 def VVxalp(self):
  VVJtuN = []
  for item in self.VVdLtF:
   VVJtuN.append((item[0], item[0]))
  FF0km9(self, self.VVLPuZ, title='PIcons ".png" Files', VVJtuN=VVJtuN, VVz4LU=True)
 def VVLPuZ(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVodhJ(ndx)
 def VV6Xdy(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVltX9()
   if refCode:
    FFTrMq(self, refCode)
    self.VVIcXI()
    self.VVEqW5()
 def VVWdv6(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVIcXI()
   self.VVEqW5()
  except:
   pass
 def VVWSao(self):
  if self["keyGreen"].getVisible():
   self.VVodhJ(self.curChanIndex)
 def VVodhJ(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVYL05(True)
  else:
   FFlDiQ(self, "Not found", 1000)
 def VV97Cr(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFItMF(self, BF(self.VVi5lA, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVAzPu(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVltX9()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVJtuN = []
     VVJtuN.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVJtuN.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FF0km9(self, BF(self.VVL8A7, mode, curChF, selPiconF), VVJtuN=VVJtuN, title="Current Channel PIcon (already exists)")
    else:
     self.VVL8A7(mode, curChF, selPiconF, "overwrite")
   else:
    FFc8qc(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFc8qc(self, "Could not read current channel info. !", title=title)
 def VVL8A7(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFItMF(self, BF(self.VVi5lA, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VV4btc(self, mode):
  pass
 def VVZYLD(self):
  pass
 def VV9cyG(self):
  pass
 def VVTFX4(self):
  defDir = FFPG8X(CC2T9T.VVP17o() + "picons_backup")
  os.system(FFIwml("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(BF(self.VVnPNE, defDir), BF(CCg2YR
         , mode=CCg2YR.VVkqcx, VV48AQ=CC2T9T.VVP17o()))
 def VVnPNE(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CC2T9T.VVP17o():
    FFc8qc(self, "Cannot move to same directory !", title=title)
   else:
    if not FFPG8X(path) == FFPG8X(defDir):
     self.VVS1ai(defDir)
    FFAIFY(self, BF(FFItMF, self, BF(self.VVsNz6, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVdLtF), path), title=title)
  else:
   self.VVS1ai(defDir)
 def VVsNz6(self, title, defDir, toPath):
  try:
   from shutil import move as iMove
  except:
   self.VVS1ai(defDir)
   FFc8qc(self, 'Could not load "shutil" module !', title=title)
   return
  toPath = FFPG8X(toPath)
  pPath = CC2T9T.VVP17o()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVdLtF:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVdLtF)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFPt7a(self, txt, title=title, VVspm3="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVuUJ6("all")
 def VVS1ai(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVZUN8(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVdLtF)
  s = "s" if tot > 1 else ""
  FFAIFY(self, BF(FFItMF, self, BF(self.VVXdb5, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, s), title=title)
 def VVXdb5(self, title):
  pPath = CC2T9T.VVP17o()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVdLtF:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVdLtF)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FF0IFC(str(totErr), VVyU04)
  FFPt7a(self, txt, title=title)
 def VVjzl3(self):
  lines = FFOAMF("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFAIFY(self, BF(self.VVqlMv, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VV1oM4=True)
  else:
   FF9xND(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVqlMv(self, fList):
  os.system(FFIwml("find -L '%s' -type l -delete" % self.pPath))
  FF9xND(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVasgs(self):
  FFItMF(self, self.VVYuOu)
 def VVYuOu(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVltX9()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FF0IFC("PIcon Directory:\n", VVumHI)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FFhMgk(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFhMgk(path)
   txt += FF0IFC("PIcon File:\n", VVumHI)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFOAMF(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FF0IFC("Found %d SymLink%s to this file from:\n" % (tot, s), VVumHI)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFupyT(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FF0IFC(tChName, VV9pCx)
     else  : tChName = ""
     txt += "  %s%s\n" % (FF0IFC(line, VVkO2P), tChName)
    txt += "\n"
   if chName:
    txt += FF0IFC("Channel:\n", VVumHI)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FF0IFC(chName, VV9pCx)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FF0IFC("Remarks:\n", VVumHI)
    txt += "  %s\n" % FF0IFC("Unused", VVyU04)
  else:
   txt = "No info found"
  FFsVRo(self, fncMode=CCSQQx.VVRrXi, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVltX9(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVdLtF[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFNqvq(sat)
  return fName, refCode, chName, sat, inDB
 def VVIcXI(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVdLtF):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVEqW5(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVltX9()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FF0IFC("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVumHI))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVltX9()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FF0IFC(self.curChanName, VV8mIi)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVMX4F(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VVdLtF:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FF8oWX("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFPt7a(self, txt, title=self.Title)
 def VV5xOu(self):
  if not self.isBusy:
   VVJtuN = []
   VVJtuN.append(("All"         , "all"   ))
   VVJtuN.append(VVImCt)
   VVJtuN.append(("Used by Channels"      , "used"  ))
   VVJtuN.append(("Unused PIcons"      , "unused"  ))
   VVJtuN.append(VVImCt)
   VVJtuN.append(("PIcons Files"       , "pFiles"  ))
   VVJtuN.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVJtuN.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVJtuN.append(VVImCt)
   VVJtuN.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVJtuN.append(VVImCt)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFIWN7(val)
      VVJtuN.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCfaXJ(self)
   filterObj.VV377c(VVJtuN, self.nsList, self.VVdmO5)
 def VVdmO5(self, item=None):
  if item is not None:
   self.VVuUJ6(item)
 def VVuUJ6(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVjRIU   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVtFry   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVxtSy  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVi3eS  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVZh9G  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVOeJg  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVVFrY   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVcCld   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVRdEP , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVOeJg:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFOAMF("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFlDiQ(self, "Not found", 1000)
     return
   elif mode == self.VV9Lcc:
    return
   else:
    words, asPrefix = CCfaXJ.VVIvS9(words)
   if not words and mode in (self.VVcCld, self.VVRdEP):
    FFlDiQ(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFItMF(self, BF(self.VVi5lA, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVwzM2(self):
  self.session.open(CC5Qg8, barTheme=CC5Qg8.VVEF3W
      , titlePrefix = ""
      , fncToRun  = self.VVnP0k
      , VVOIg8 = self.VVHsc3)
 def VVnP0k(self, VVx8U3):
  VV6j5n, err = CCcNAu.VVRQtF(self, CCcNAu.VVL1Rg, VVs2Ke=False, VV1LYo=False)
  files = []
  words = []
  if not VVx8U3 or VVx8U3.isCancelled:
   return
  VVx8U3.VVLA6S = []
  VVx8U3.VVVu3x(len(VV6j5n))
  if VV6j5n:
   VVuSz1 = CC6QHf()
   curCh = VVuSz1.VVfZ6Y(self.curChanName)
   for refCode in VV6j5n:
    if not VVx8U3 or VVx8U3.isCancelled:
     return
    VVx8U3.VVGACS(1, True)
    chName, sat, inDB = VV6j5n.get(refCode, ("", "", 0))
    ratio = CC2T9T.VVVHBT(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CC2T9T.VV5P0w(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       VVx8U3.VVLA6S.append(f.replace(".png", ""))
 def VVHsc3(self, VVFnA0, VVLA6S, threadCounter, threadTotal, threadErr):
  if VVLA6S:
   self.timer = eTimer()
   fnc = BF(FFItMF, self, BF(self.VVi5lA, mode=self.VV9Lcc, words=VVLA6S), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FFlDiQ(self, "Not found", 2000)
 def VVi5lA(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVOfd2(isFirstTime):
   return
  self.isBusy = True
  VV1LYo = True if isFirstTime else False
  VV6j5n, err = CCcNAu.VVRQtF(self, CCcNAu.VVL1Rg, VVs2Ke=False, VV1LYo=VV1LYo)
  if err:
   self.close()
  iptvRefList = self.VVYqXJ()
  tList = []
  for fName, fType in CC2T9T.VVkxJK(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VV6j5n:
    if fName in VV6j5n:
     chName, sat, inDB = VV6j5n.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVjRIU:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVtFry  and chName         : isAdd = True
   elif mode == self.VVxtSy and not chName        : isAdd = True
   elif mode == self.VVi3eS  and fType == 0        : isAdd = True
   elif mode == self.VVZh9G  and fType == 1        : isAdd = True
   elif mode == self.VVOeJg  and fName in words       : isAdd = True
   elif mode == self.VV9Lcc and fName in words       : isAdd = True
   elif mode == self.VVVFrY  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVcCld  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVRdEP:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVdLtF   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FFlDiQ(self)
  else:
   self.isBusy = False
   FFlDiQ(self, "Not found", 1000)
   return
  self.VVdLtF.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVIcXI()
  self.totalPIcons = len(self.VVdLtF)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVYL05(True)
 def VVOfd2(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CC2T9T.VVkxJK(self.pPath):
    if fName:
     return True
   if isFirstTime : FFc8qc(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFlDiQ(self, "Not found", 1000)
  else:
   FFc8qc(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVYqXJ(self):
  VVMDmE = {}
  files  = CCUfgv.VVmLF8(self)
  if files:
   for path in files:
    txt = FFt4Zg(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVMDmE[refCode] = item[1]
  return VVMDmE
 def VVYL05(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVHFQx = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVHFQx: self.curPage = VVHFQx
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVySuM()
  if self.curPage == VVHFQx:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVEqW5()
  filName, refCode, chName, sat, inDB = self.VVltX9()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVySuM(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVdLtF[ndx]
   fName = self.VVdLtF[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FF0IFC(chName, VV9pCx))
    else : lbl.setText("-")
   except:
    lbl.setText(FF0IFC(chName, VVPgsh))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVVHBT(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVw0Q9():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VV6kpa"   )
 @staticmethod
 def VVXAbb():
  VVJtuN = []
  VVJtuN.append(("Find SymLinks (to PIcon Directory)"   , "VVVM2i"   ))
  VVJtuN.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVJtuN.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVJtuN
 @staticmethod
 def VV6kpa(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(SELF)
  png, path = CC2T9T.VVFZPz(refCode)
  if path : CC2T9T.VV3sOf(SELF, png, path)
  else : FFc8qc(SELF, "No PIcon found for current channel in:\n\n%s" % CC2T9T.VVP17o())
 @staticmethod
 def VVVM2i(SELF):
  if VV8mIi:
   sed1 = FFugQf("->", VV8mIi)
   sed2 = FFugQf("picon", VVyU04)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVPgsh, VVmG5f)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFGZGa(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFaoFr(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVZgX1(SELF, isPIcon):
  sed1 = FFugQf("->", VVPgsh)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFugQf("picon", VVyU04)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFGZGa(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFaoFr(), grep, sed1, sed2))
 @staticmethod
 def VVkxJK(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVP17o():
  path = CFG.PIconsPath.getValue()
  return FFPG8X(path)
 @staticmethod
 def VVFZPz(refCode, chName=None):
  if FFgKj2(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFDfd9(refCode)
  allPath, fName, refCodeFile, pList = CC2T9T.VV5P0w(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VV3sOf(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFugQf("%s%s" % (dest, png), VV9pCx))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFugQf(errTxt, VV0wBB))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFsu1t(SELF, cmd)
 @staticmethod
 def VV5P0w(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CC2T9T.VVP17o()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFj0Hy(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CC6Y98():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVDrvs  = None
  self.VVgSAW = ""
  self.VVkF9N  = noService
  self.VV8NBg = 0
  self.VV6Kjh  = noService
  self.VVHgcP = 0
  self.VVxvMK  = "-"
  self.VVh2R0 = 0
  self.VVVHEn  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVSUwg(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVDrvs = frontEndStatus
     self.VVpmm4()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVpmm4(self):
  if self.VVDrvs:
   val = self.VVDrvs.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVgSAW = "%3.02f dB" % (val / 100.0)
   else         : self.VVgSAW = ""
   val = self.VVDrvs.get("tuner_signal_quality", 0) * 100 / 65536
   self.VV8NBg = int(val)
   self.VVkF9N  = "%d%%" % val
   val = self.VVDrvs.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVHgcP = int(val)
   self.VV6Kjh  = "%d%%" % val
   val = self.VVDrvs.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVxvMK  = "%d" % val
   val = int(val * 100 / 500)
   self.VVh2R0 = min(500, val)
   val = self.VVDrvs.get("tuner_locked", 0)
   if val == 1 : self.VVVHEn = "Locked"
   else  : self.VVVHEn = "Not locked"
 def VVhSz6(self)   : return self.VVgSAW
 def VVMtHV(self)   : return self.VVkF9N
 def VVAFKH(self)  : return self.VV8NBg
 def VV6xgC(self)   : return self.VV6Kjh
 def VVP6oK(self)  : return self.VVHgcP
 def VVFJhD(self)   : return self.VVxvMK
 def VV2zF9(self)  : return self.VVh2R0
 def VVhHLs(self)   : return self.VVVHEn
 def VVjfLU(self) : return self.serviceName
class CCMZhh():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVjyJs(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFIdwC(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVuIju(self.ORPOS  , mod=1   )
      self.sat2  = self.VVuIju(self.ORPOS  , mod=2   )
      self.freq  = self.VVuIju(self.FREQ  , mod=3   )
      self.sr   = self.VVuIju(self.SR   , mod=4   )
      self.inv  = self.VVuIju(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVuIju(self.POL  , self.D_POL )
      self.fec  = self.VVuIju(self.FEC  , self.D_FEC )
      self.syst  = self.VVuIju(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVuIju("modulation" , self.D_MOD )
       self.rolof = self.VVuIju("rolloff"  , self.D_ROLOF )
       self.pil = self.VVuIju("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVuIju("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVuIju("pls_code"  )
       self.iStId = self.VVuIju("is_id"   )
       self.t2PlId = self.VVuIju("t2mi_plp_id" )
       self.t2PId = self.VVuIju("t2mi_pid"  )
 def VVuIju(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFIWN7(val)
  elif mod == 2   : return FF7DLp(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VV6lQn(self, refCode):
  txt = ""
  self.VVjyJs(refCode)
  if self.data:
   def VVxcQr(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVxcQr("System"   , self.syst)
    txt += VVxcQr("Satellite"  , self.sat2)
    txt += VVxcQr("Frequency"  , self.freq)
    txt += VVxcQr("Inversion"  , self.inv)
    txt += VVxcQr("Symbol Rate"  , self.sr)
    txt += VVxcQr("Polarization" , self.pol)
    txt += VVxcQr("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVxcQr("Modulation" , self.mod)
     txt += VVxcQr("Roll-Off" , self.rolof)
     txt += VVxcQr("Pilot"  , self.pil)
     txt += VVxcQr("Input Stream", self.iStId)
     txt += VVxcQr("T2MI PLP ID" , self.t2PlId)
     txt += VVxcQr("T2MI PID" , self.t2PId)
     txt += VVxcQr("PLS Mode" , self.plsMod)
     txt += VVxcQr("PLS Code" , self.plsCod)
   else:
    txt += VVxcQr("System"   , self.txMedia)
    txt += VVxcQr("Frequency"  , self.freq)
  return txt, self.namespace
 def VVFtTj(self, refCode):
  txt = "Transpoder : ?"
  self.VVjyJs(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VVumHI + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVgTRT(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFIdwC(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVuIju(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVuIju(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVuIju(self.SYST, self.D_SYS_S)
     freq = self.VVuIju(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVuIju(self.POL , self.D_POL)
      fec = self.VVuIju(self.FEC , self.D_FEC)
      sr = self.VVuIju(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVMW5z(self, refCode):
  self.data = None
  self.VVjyJs(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCQnPl():
 def __init__(self, VVGTt8, path, VVOIg8=None, curRowNum=-1):
  self.VVGTt8  = VVGTt8
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVOIg8  = VVOIg8
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFIwml("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVYtJV(curRowNum)
  else:
   FFc8qc(self.VVGTt8, "Error while preparing edit!")
 def VVYtJV(self, curRowNum):
  VVMDmE = self.VVIWsE()
  VV39uD = None #("Delete Line" , self.deleteLine  , [])
  VVieK7 = ("Save Changes" , self.VVUCnV   , [])
  VVW0bm  = ("Edit Line"  , self.VVoBkY    , [])
  VVS9I3 = ("Line Options" , self.VVGPS5   , [])
  VVOo99 = (""    , self.VV6IaR , [])
  VVqaLK = self.VV799Z
  VVd5iM  = self.VVegJK
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVQQbo  = (CENTER  , LEFT  )
  VV57kA = FFBL02(self.VVGTt8, None, title=self.Title, header=header, VVdLtF=VVMDmE, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=26, VV39uD=VV39uD, VVieK7=VVieK7, VVW0bm=VVW0bm, VVS9I3=VVS9I3, VVqaLK=VVqaLK, VVd5iM=VVd5iM, VVOo99=VVOo99, VVxbA6=True
    , VV5mP6   = "#11001111"
    , VVqjLk   = "#11001111"
    , VVspm3   = "#11001111"
    , VVANti  = "#05333333"
    , VVxA4o  = "#00222222"
    , VVVSpS  = "#11331133"
    )
  VV57kA.VVwRuv(curRowNum)
 def VVGPS5(self, VV57kA, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VV57kA.VVDvsh()
  VVJtuN = []
  VVJtuN.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVJtuN.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVTKQh"  ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVRy6N:
   VVJtuN.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(  ("Delete Line"         , "deleteLine"   ))
  FF0km9(self.VVGTt8, BF(self.VVxHkM, VV57kA, lineNum), VVJtuN=VVJtuN, title="Line Options")
 def VVxHkM(self, VV57kA, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVVEDQ("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VV57kA)
   elif item == "VVTKQh"  : self.VVTKQh(VV57kA, lineNum)
   elif item == "copyToClipboard"  : self.VVCT6a(VV57kA, lineNum)
   elif item == "pasteFromClipboard" : self.VVwLAr(VV57kA, lineNum)
   elif item == "deleteLine"   : self.VVVEDQ("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VV57kA)
 def VVegJK(self, VV57kA):
  VV57kA.VVFPNq()
 def VV6IaR(self, VV57kA, title, txt, colList):
  if   self.insertMode == 1: VV57kA.VVZ2qE()
  elif self.insertMode == 2: VV57kA.VVzwU8()
  self.insertMode = 0
 def VVTKQh(self, VV57kA, lineNum):
  if lineNum == VV57kA.VVDvsh():
   self.insertMode = 1
   self.VVVEDQ("echo '' >> '%s'" % self.tmpFile, VV57kA)
  else:
   self.insertMode = 2
   self.VVVEDQ("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VV57kA)
 def VVCT6a(self, VV57kA, lineNum):
  global VVRy6N
  VVRy6N = FF8oWX("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VV57kA.VVAlHG("Copied to clipboard")
 def VVUCnV(self, VV57kA, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFIwml("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFIwml("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VV57kA.VVAlHG("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VV57kA.VVFPNq()
    else:
     FFc8qc(self.VVGTt8, "Cannot save file!")
   else:
    FFc8qc(self.VVGTt8, "Cannot create backup copy of original file!")
 def VV799Z(self, VV57kA):
  if self.fileChanged:
   FFAIFY(self.VVGTt8, BF(self.VVbuV9, VV57kA), "Cancel changes ?")
  else:
   finalOK = os.system(FFIwml("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVbuV9(VV57kA)
 def VVbuV9(self, VV57kA):
  VV57kA.cancel()
  os.system(FFIwml("rm -f '%s'" % self.tmpFile))
  if self.VVOIg8:
   self.VVOIg8(self.fileSaved)
 def VVoBkY(self, VV57kA, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVmG5f + "ORIGINAL TEXT:\n" + VVkO2P + lineTxt
  FFBJqp(self.VVGTt8, BF(self.VVkIlY, lineNum, VV57kA), title="File Line", defaultText=lineTxt, message=message)
 def VVkIlY(self, lineNum, VV57kA, VVLK78):
  if not VVLK78 is None:
   if VV57kA.VVDvsh() <= 1:
    self.VVVEDQ("echo %s > '%s'" % (VVLK78, self.tmpFile), VV57kA)
   else:
    self.VVf3rR(VV57kA, lineNum, VVLK78)
 def VVwLAr(self, VV57kA, lineNum):
  if lineNum == VV57kA.VVDvsh() and VV57kA.VVDvsh() == 1:
   self.VVVEDQ("echo %s >> '%s'" % (VVRy6N, self.tmpFile), VV57kA)
  else:
   self.VVf3rR(VV57kA, lineNum, VVRy6N)
 def VVf3rR(self, VV57kA, lineNum, newTxt):
  VV57kA.VVfaYe("Saving ...")
  lines = FFNoK6(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VV57kA.VVKgbz()
  VVMDmE = self.VVIWsE()
  VV57kA.VV3aGD(VVMDmE)
 def VVVEDQ(self, cmd, VV57kA):
  tCons = CCbhqA()
  tCons.ePopen(cmd, BF(self.VVJuvb, VV57kA))
  self.fileChanged = True
  VV57kA.VVKgbz()
 def VVJuvb(self, VV57kA, result, retval):
  VVMDmE = self.VVIWsE()
  VV57kA.VV3aGD(VVMDmE)
 def VVIWsE(self):
  if fileExists(self.tmpFile):
   lines = FFNoK6(self.tmpFile)
   VVMDmE = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVMDmE.append((str(ndx), line.strip()))
   if not VVMDmE:
    VVMDmE.append((str(1), ""))
   return VVMDmE
  else:
   FFJJSt(self.VVGTt8, self.tmpFile)
class CCfaXJ():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVJtuN   = []
  self.satList   = []
 def VV8EPH(self, VVOIg8):
  self.VVJtuN = []
  VVJtuN, VVnRDK = self.VV3eDQ(False, True)
  if VVJtuN:
   self.VVJtuN += VVJtuN
   self.VVRBXG(VVOIg8, VVnRDK)
 def VVypCr(self, mode, VV57kA, satCol, VVOIg8):
  VV57kA.VVfaYe("Loading Filters ...")
  self.VVJtuN = []
  self.VVJtuN.append(("All Services" , "all"))
  if mode == 1:
   self.VVJtuN.append(VVImCt)
   self.VVJtuN.append(("Parental Control", "parentalControl"))
   self.VVJtuN.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVJtuN.append(VVImCt)
   self.VVJtuN.append(("Selected Transponder"   , "selectedTP" ))
   self.VVJtuN.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVT9tj(VV57kA, satCol)
  VVJtuN, VVnRDK = self.VV3eDQ(True, False)
  if VVJtuN:
   VVJtuN.insert(0, VVImCt)
   self.VVJtuN += VVJtuN
  VV57kA.VVDvRR()
  self.VVRBXG(VVOIg8, VVnRDK)
 def VV377c(self, VVJtuN, sats, VVOIg8):
  self.VVJtuN = VVJtuN
  VVJtuN, VVnRDK = self.VV3eDQ(True, False)
  if VVJtuN:
   self.VVJtuN.append(VVImCt)
   self.VVJtuN += VVJtuN
  self.VVRBXG(VVOIg8, VVnRDK)
 def VVRBXG(self, VVOIg8, VVnRDK):
  VVPpN9 = ("Edit Filter", BF(self.VV9Fsg, VVnRDK))
  VVjEiY  = ("Filter Help", BF(self.VVHFVA, VVnRDK))
  FF0km9(self.callingSELF, BF(self.VVre9v, VVOIg8), VVJtuN=self.VVJtuN, title="Select Filter", VVPpN9=VVPpN9, VVjEiY=VVjEiY)
 def VVre9v(self, VVOIg8, item):
  if item:
   VVOIg8(item)
 def VV9Fsg(self, VVnRDK, VVnkBoObj, sel):
  if fileExists(VVnRDK) : CCQnPl(self.callingSELF, VVnRDK, VVOIg8=None)
  else       : FFJJSt(self.callingSELF, VVnRDK)
  VVnkBoObj.cancel()
 def VVHFVA(self, VVnRDK, VVnkBoObj, sel):
  FFsJjT(self.callingSELF, VVAquH + "_help_service_filter", "Service Filter")
 def VVT9tj(self, VV57kA, satColNum):
  if not self.satList:
   satList = VV57kA.VVWVgX(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFNqvq(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VVImCt)
  if self.VVJtuN:
   self.VVJtuN += self.satList
 def VV3eDQ(self, addTag, VV5kIx):
  FFg2lz()
  fileName  = "ajpanel_services_filter"
  VVnRDK = VVIlHj + fileName
  VVJtuN  = []
  if not fileExists(VVnRDK):
   os.system(FFIwml("cp -f '%s' '%s'" % (VVAquH + fileName, VVnRDK)))
  fileFound = False
  if fileExists(VVnRDK):
   fileFound = True
   lines = FFNoK6(VVnRDK)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVJtuN.append((line, "__w__" + line))
       else  : VVJtuN.append((line, line))
  if VV5kIx:
   if   not fileFound : FFJJSt(self.callingSELF , VVnRDK)
   elif not VVJtuN : FFmT9W(self.callingSELF , VVnRDK)
  return VVJtuN, VVnRDK
 @staticmethod
 def VVIvS9(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CCZSNQ():
 def __init__(self, callingSELF, VV57kA, refCodeColNum, addSep=True):
  self.callingSELF = callingSELF
  self.VV57kA = VV57kA
  self.refCodeColNum = refCodeColNum
  self.VVJtuN = []
  iMulSel = self.VV57kA.VVZ6Fh()
  if iMulSel : self.VVJtuN.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVJtuN.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VV57kA.VV400b()
  self.VVJtuN.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVJtuN.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVJtuN.append(VVImCt)
 def VVoJxR(self, servName):
  tot = self.VV57kA.VV400b()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVJtuN.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVqJYB_multi" ))
  else    : self.VVJtuN.append( ("Add to Bouquet : %s"      % servName , "VVqJYB_one" ))
 def VVloYE(self, servName, refCode):
  self.VVoJxR(servName)
  self.VVqNiM(servName, refCode)
 def VV8p3R(self, servName, refCode, pcState, hidState):
  isMulti = self.VV57kA.VVdcxd
  if isMulti:
   refCodeList = self.VV57kA.VVlTiC(3)
   if refCodeList:
    self.VVJtuN.append(("Add Selection to Parental Control"    , "parentalControl_sel_add"  ))
    self.VVJtuN.append(("Remove Selection from Parental Control"   , "parentalControl_sel_remove" ))
    self.VVJtuN.append(VVImCt)
    self.VVJtuN.append(("Add Selection to Hidden Services"    , "hiddenServices_sel_add"  ))
    self.VVJtuN.append(("Remove Selection from Hidden Services"   , "hiddenServices_sel_remove" ))
   else:
    self.VVJtuN.pop(len(self.VVJtuN) - 1)
  else:
   if pcState == "No" : self.VVJtuN.append(("Add to Parental Control"  , "parentalControl_add"   ))
   else    : self.VVJtuN.append(("Remove from Parental Control" , "parentalControl_remove"  ))
   self.VVJtuN.append(VVImCt)
   if hidState == "No" : self.VVJtuN.append(("Add to Hidden Services"  , "hiddenServices_add"   ))
   else    : self.VVJtuN.append(("Remove from Hidden Services" , "hiddenServices_remove"  ))
  self.VVJtuN.append(VVImCt)
  self.VVoJxR(servName)
  self.VVqNiM(servName, refCode)
 def VVqNiM(self, servName, refCode):
  FF0km9(self.callingSELF, BF(self.VVDsEs, servName, refCode), title="Options", VVJtuN=self.VVJtuN)
 def VVDsEs(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"     : self.VV57kA.VVK3X1(True)
   elif item == "MultSelDisab"     : self.VV57kA.VVK3X1(False)
   elif item == "selectAll"     : self.VV57kA.VVjT42()
   elif item == "unselectAll"     : self.VV57kA.VVMAg1()
   elif item == "parentalControl_add"   : self.callingSELF.VVJg53(self.VV57kA, refCode, True)
   elif item == "parentalControl_remove"  : self.callingSELF.VVJg53(self.VV57kA, refCode, False)
   elif item == "hiddenServices_add"   : self.callingSELF.VVd0Gz(self.VV57kA, refCode, True)
   elif item == "hiddenServices_remove"  : self.callingSELF.VVd0Gz(self.VV57kA, refCode, False)
   elif item == "parentalControl_sel_add"  : self.callingSELF.VVaQbo(self.VV57kA, True)
   elif item == "parentalControl_sel_remove" : self.callingSELF.VVaQbo(self.VV57kA, False)
   elif item == "hiddenServices_sel_add"  : self.callingSELF.VVtepu(self.VV57kA, True)
   elif item == "hiddenServices_sel_remove" : self.callingSELF.VVtepu(self.VV57kA, False)
   elif item == "VVqJYB_multi"  : self.VVqJYB(refCode, True)
   elif item == "VVqJYB_one"  : self.VVqJYB(refCode, False)
 def VVsxOs(self, VV57kA):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  mSel   = CCZSNQ(self, VV57kA, 3)
  mSel.VVloYE(servName, refCode)
 def VVqJYB(self, refCode, isMulti):
  bouquets = FFKD9U()
  if bouquets:
   VVJtuN = []
   for item in bouquets:
    VVJtuN.append((item[0], item[1].toString()))
   VVPpN9 = ("Create New", BF(self.VV5CRR, refCode, isMulti))
   FF0km9(self.callingSELF, BF(self.VVeuth, refCode, isMulti), VVJtuN=VVJtuN, title="Add to Bouquet", VVPpN9=VVPpN9, VVz4LU=True, VV1n4R=True)
  else:
   FFAIFY(self.callingSELF, BF(self.VVsnkz, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVeuth(self, refCode, isMulti, bName=None):
  if bName:
   FFItMF(self.VV57kA, BF(self.VVdfIB, refCode, isMulti, bName), title="Adding Channels ...")
 def VVdfIB(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVqmeh(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVjITu = InfoBar.instance
    if VVjITu:
     VVtKZg = VVjITu.servicelist
     if VVtKZg:
      mutableList = VVtKZg.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VV57kA.VVDvRR()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FF9xND(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FFc8qc(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVqmeh(self, refCode, isMulti):
  if isMulti : refCodeList = self.VV57kA.VVlTiC(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VV5CRR(self, refCode, isMulti, VVnkBoObj, path):
  self.VVsnkz(refCode, isMulti)
 def VVsnkz(self, refCode, isMulti):
  FFBJqp(self.callingSELF, BF(self.VVgdz3, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVgdz3(self, refCode, isMulti, name):
  if name:
   FFItMF(self.VV57kA, BF(self.VVbdOJ, refCode, isMulti, name), title="Adding Channels ...")
 def VVbdOJ(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVqmeh(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVjITu = InfoBar.instance
    if VVjITu:
     VVtKZg = VVjITu.servicelist
     if VVtKZg:
      try:
       VVtKZg.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVtKZg.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VV57kA.VVDvRR()
   title = "Add to Bouquet"
   if allOK: FF9xND(self.callingSELF, "Added to : %s" % name, title=title)
   else : FFc8qc(self.callingSELF, "Nothing added!", title=title)
class CCylQ9(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFi9TE(VVEcC3, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFRqJR(self)
  FFINW5(self["keyRed"]  , "Exit")
  FFINW5(self["keyGreen"]  , "Save")
  FFINW5(self["keyYellow"] , "Refresh")
  FFINW5(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVkgLT  ,
   "green"   : self.VVXUMF ,
   "yellow"  : self.VVGUkF  ,
   "blue"   : self.VVPe2Q   ,
   "up"   : self.VV9SfV    ,
   "down"   : self.VVz7mm   ,
   "left"   : self.VV6YLz   ,
   "right"   : self.VVI6vA   ,
   "cancel"  : self.VVkgLT
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVGUkF()
  self.VVeCd7()
  FFSrMl(self)
 def VVkgLT(self) : self.close(True)
 def VVzvPa(self) : self.close(False)
 def VVPe2Q(self):
  self.session.openWithCallback(self.VVqBf2, BF(CCMU6q))
 def VVqBf2(self, closeAll):
  if closeAll:
   self.close()
 def VV9SfV(self):
  self.VVVwYX(1)
 def VVz7mm(self):
  self.VVVwYX(-1)
 def VV6YLz(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVeCd7()
 def VVI6vA(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVeCd7()
 def VVVwYX(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVLZVN(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVLZVN(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVLZVN(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVVIJ8(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVVIJ8(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVeCd7(self):
  for obj in self.list:
   FFLgZ9(obj, "#11404040")
  FFLgZ9(self.list[self.index], "#11ff8000")
 def VVGUkF(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVXUMF(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCbhqA()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VV58Xa)
 def VV58Xa(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FF9xND(self, "Nothing returned from the system!")
  else:
   FF9xND(self, str(result))
class CCMU6q(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFi9TE(VV8biG, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFRqJR(self, addLabel=True)
  FFINW5(self["keyRed"]  , "Exit")
  FFINW5(self["keyGreen"]  , "Sync")
  FFINW5(self["keyYellow"] , "Refresh")
  FFINW5(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVkgLT   ,
   "green"   : self.VVaVGU  ,
   "yellow"  : self.VVoxBl ,
   "blue"   : self.VVDJRj  ,
   "cancel"  : self.VVkgLT
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVAkjg()
  self.onShow.append(self.start)
 def start(self):
  FF1Gz0(self.refresh)
  FFSrMl(self)
 def refresh(self):
  self.VVcC8o()
  self.VVnjWE(False)
 def VVkgLT(self)  : self.close(True)
 def VVDJRj(self) : self.close(False)
 def VVAkjg(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVcC8o(self):
  self.VV6re0()
  self.VV0RSB()
  self.VVn65n()
  self.VV2kFy()
 def VVoxBl(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVAkjg()
   self.VVcC8o()
   FF1Gz0(self.refresh)
 def VVaVGU(self):
  if len(self["keyGreen"].getText()) > 0:
   FFAIFY(self, self.VVADuV, "Synchronize with Internet Date/Time ?")
 def VVADuV(self):
  self.VVcC8o()
  FF1Gz0(BF(self.VVnjWE, True))
 def VV6re0(self)  : self["keyRed"].show()
 def VVpIOF(self)  : self["keyGreen"].show()
 def VVfBwN(self) : self["keyYellow"].show()
 def VVfXfx(self)  : self["keyBlue"].show()
 def VV0RSB(self)  : self["keyGreen"].hide()
 def VVn65n(self) : self["keyYellow"].hide()
 def VV2kFy(self)  : self["keyBlue"].hide()
 def VVnjWE(self, sync):
  localTime = FFZwup()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VV1RpM(server)
   if epoch_time is not None:
    ntpTime = FFjsXk(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCbhqA()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VV58Xa, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVfBwN()
  self.VVfXfx()
  if ok:
   self.VVpIOF()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VV58Xa(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVnjWE(False)
  except:
   pass
 def VV1RpM(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFSTMp():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCeBE2(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFi9TE(VVzhs8, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FFRqJR(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FF1Gz0(self.VVNl0u)
 def VVNl0u(self):
  if FFSTMp(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFLgZ9(self["myBody"], color)
   FFLgZ9(self["myLabel"], color)
  except:
   pass
class CCoR4p(Screen):
 def __init__(self, session, isFromExternal=False):
  size = CFG.signalSize.getValue()
  screenW = FFSAjK()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFi9TE(VVZvOF, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self.isFromExternal  = isFromExternal
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCoVW7(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCoVW7(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCoVW7(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CC6Y98()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFRqJR(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close      ,
   "up"  : self.VV9SfV       ,
   "down"  : self.VVz7mm      ,
   "left"  : self.VV6YLz      ,
   "right"  : self.VVI6vA      ,
   "info"  : self.VVz7V2     ,
   "epg"  : self.VVz7V2     ,
   "menu"  : self.VVBOuM      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VVZO4c, -1)  ,
   "next"  : BF(self.VVZO4c, 1)  ,
   "pageUp" : BF(self.VVoWVQ, True) ,
   "chanUp" : BF(self.VVoWVQ, True) ,
   "pageDown" : BF(self.VVoWVQ, False) ,
   "chanDown" : BF(self.VVoWVQ, False) ,
   "0"   : BF(self.VVZO4c, 0)  ,
   "1"   : BF(self.VVmwOL, pos=1) ,
   "2"   : BF(self.VVmwOL, pos=2) ,
   "3"   : BF(self.VVmwOL, pos=3) ,
   "4"   : BF(self.VVmwOL, pos=4) ,
   "5"   : BF(self.VVmwOL, pos=5) ,
   "6"   : BF(self.VVmwOL, pos=6) ,
   "7"   : BF(self.VVmwOL, pos=7) ,
   "8"   : BF(self.VVmwOL, pos=8) ,
   "9"   : BF(self.VVmwOL, pos=9) ,
  }, -1)
  self.onShown.append(self.VVDpWe)
  self.onClose.append(self.onExit)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  self.sliderSNR.VVP6Er()
  self.sliderAGC.VVP6Er()
  self.sliderBER.VVP6Er(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVmwOL()
  self.VV21iwInfo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV21iw)
  except:
   self.timer.callback.append(self.VV21iw)
  self.timer.start(500, False)
 def VV21iwInfo(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVSUwg(service)
  serviceName = self.tunerInfo.VVjfLU()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self)
  tp = CCMZhh()
  txt = tp.VVFtTj(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VV21iw(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVSUwg(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVhSz6())
   self["mySNR"].setText(self.tunerInfo.VVMtHV())
   self["myAGC"].setText(self.tunerInfo.VV6xgC())
   self["myBER"].setText(self.tunerInfo.VVFJhD())
   self.sliderSNR.VV4YTe(self.tunerInfo.VVAFKH())
   self.sliderAGC.VV4YTe(self.tunerInfo.VVP6oK())
   self.sliderBER.VV4YTe(self.tunerInfo.VV2zF9())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VV4YTe(0)
   self.sliderAGC.VV4YTe(0)
   self.sliderBER.VV4YTe(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self)
    if state and not state == "Tuned":
     FFlDiQ(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVz7V2(self):
  FFsVRo(self, fncMode=CCSQQx.VVF09E)
 def VVBOuM(self):
  FFsJjT(self, VVAquH + "_help_signal", "Signal Monitor (Keys)")
 def VV9SfV(self)  : self.VVmwOL(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVz7mm(self) : self.VVmwOL(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VV6YLz(self) : self.VVmwOL(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVI6vA(self) : self.VVmwOL(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVmwOL(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVZO4c(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FF2XXx(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVoWVQ(self, isUp):
  FFlDiQ(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VV21iwInfo()
  except:
   pass
class CCoVW7(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVP6Er(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFLgZ9(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVAquH +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFLgZ9(self.covObj, self.covColor)
   else:
    FFLgZ9(self.covObj, "#00006688")
    self.isColormode = True
  self.VV4YTe(0)
 def VV4YTe(self, val):
  val  = FF2XXx(val, self.minN, self.maxN)
  width = int(FFbZQf(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FF2XXx(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CC5Qg8(Screen):
 VVEF3W    = 0
 VVDgZs = 1
 VVpqFt = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVOIg8=None, barTheme=VVEF3W):
  ratio = self.VVlGnU(barTheme)
  self.skin, self.skinParam = FFi9TE(VVtQs4, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVOIg8 = VVOIg8
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVLA6S = None
  self.timer   = eTimer()
  self.myThread  = None
  FFRqJR(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVDpWe)
  self.onClose.append(self.onExit)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  self.VVDQxK()
  self["myProgBarVal"].setText("0%")
  FFLgZ9(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVORzs()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVORzs)
  except:
   self.timer.callback.append(self.VVORzs)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VVVu3x(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVQyWe_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVLA6S), self.counter, self.maxValue, catName)
 def VVQyWe_fromImportEPG(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVQyWe_forcedUpdate(self, title):
  self.newTitle = title
  try:
   self.VVORzs()
  except:
   pass
 def VVGACS(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VVLA6S), self.counter, self.maxValue)
  except:
   pass
 def VV2ZPN(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVQ7pK(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVlYn7(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFlDiQ(self, "Cancelling ...")
  self.isCancelled = True
  self.VVDFFe(False)
 def VVDFFe(self, isDone):
  if self.VVOIg8:
   self.VVOIg8(isDone, self.VVLA6S, self.counter, self.maxValue, self.isError)
  self.close()
 def VVORzs(self):
  val = FF2XXx(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFbZQf(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VVDFFe(True)
 def VVDQxK(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVDgZs, self.VVpqFt):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVlGnU(self, barTheme):
  if   barTheme == self.VVDgZs : return 0.7
  if   barTheme == self.VVpqFt : return 0.5
  else             : return 1
class CCbhqA(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVOIg8 = {}
  self.commandRunning = False
  self.VVBkcb  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVOIg8, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVOIg8[name] = VVOIg8
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVBkcb:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVkqrV, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVvFba , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVkqrV, name))
    self.appContainers[name].appClosed.append(BF(self.VVvFba , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVvFba(name, retval)
  return True
 def VVkqrV(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVvFba(self, name, retval):
  if not self.VVBkcb:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVOIg8[name]:
   self.VVOIg8[name](self.appResults[name], retval)
  del self.VVOIg8[name]
 def VVzH1J(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCBqjg(Screen):
 def __init__(self, session, title="", VVU7IO=None, VVVhvb=False, VVSfhJ=False, VVmwop=False, VV9ajQ=False, VVY3Iu=False, VVN4nE=False, VV0vZt=VVOM7o, VVxGmB=None, VVTgSz=False, VVLZXz=None, VV9v81="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFi9TE(VVAK4W, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFRqJR(self, addScrollLabel=True)
  if not VV9v81:
   VV9v81 = "Processing ..."
  self["myLabel"].setText("   %s" % VV9v81)
  self.VVVhvb   = VVVhvb
  self.VVSfhJ   = VVSfhJ
  self.VVmwop   = VVmwop
  self.VV9ajQ  = VV9ajQ
  self.VVY3Iu = VVY3Iu
  self.VVN4nE = VVN4nE
  self.VV0vZt   = VV0vZt
  self.VVxGmB = VVxGmB
  self.VVTgSz  = VVTgSz
  self.VVLZXz  = VVLZXz
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCbhqA()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFvK43()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVU7IO, str):
   self.VVU7IO = [VVU7IO]
  else:
   self.VVU7IO = VVU7IO
  if self.VVmwop or self.VV9ajQ:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVsYfD, VVsYfD)
   self.VVU7IO.append("echo -e '\n%s\n' %s" % (restartNote, FFugQf(restartNote, VV8mIi)))
   if self.VVmwop:
    self.VVU7IO.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVU7IO.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVY3Iu:
   FFlDiQ(self, "Processing ...")
  self.onLayoutFinish.append(self.VVmoy5)
  self.onClose.append(self.VVNHKM)
 def VVmoy5(self):
  self["myLabel"].VVfE6M(textOutFile="console" if self.enableSaveRes else "")
  if self.VVVhvb:
   self["myLabel"].VVivUS()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVWz5l()
  else:
   self.VVLmvf()
 def VVWz5l(self):
  if FFSTMp():
   self["myLabel"].setText("Processing ...")
   self.VVLmvf()
  else:
   self["myLabel"].setText(FF0IFC("\n   No connection to internet!", VVyU04))
 def VVLmvf(self):
  allOK = self.container.ePopen(self.VVU7IO[0], self.VVtxQZ, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVtxQZ("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVN4nE or self.VVmwop or self.VV9ajQ:
    self["myLabel"].setText(FFvvVG("STARTED", VV8mIi) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVLZXz:
   colorWhite = CCEMYn.VVBx0G(VVmG5f)
   color  = CCEMYn.VVBx0G(self.VVLZXz[0])
   words  = self.VVLZXz[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VV0vZt=self.VV0vZt)
 def VVtxQZ(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVU7IO):
   allOK = self.container.ePopen(self.VVU7IO[self.cmdNum], self.VVtxQZ, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVtxQZ("Cannot connect to Console!", -1)
  else:
   if self.VVY3Iu and FFM8Du(self):
    FFlDiQ(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVN4nE:
    self["myLabel"].appendText("\n" + FFvvVG("FINISHED", VV8mIi), self.VV0vZt)
   if self.VVVhvb or self.VVSfhJ:
    self["myLabel"].VVivUS()
   if self.VVxGmB is not None:
    self.VVxGmB()
   if not retval and self.VVTgSz:
    self.VVNHKM()
 def VVNHKM(self):
  if self.container.VVzH1J():
   self.container.killAll()
class CCRP7s(Screen):
 def __init__(self, session, VVU7IO=None, VVY3Iu=False):
  self.skin, self.skinParam = FFi9TE(VVAK4W, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVIlHj + "ajpanel_terminal.history"
  self.customCommandsFile = VVIlHj + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FF8oWX("pwd") or "/home/root"
  self.container   = CCbhqA()
  FFRqJR(self, addScrollLabel=True)
  FFINW5(self["keyRed"] , "Exit = Stop Command")
  FFINW5(self["keyGreen"] , "OK = History")
  FFINW5(self["keyYellow"], "Menu = Custom Cmds")
  FFINW5(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVIiCy ,
   "cancel" : self.VVzRs8  ,
   "menu"  : self.VVkTjV ,
   "last"  : self.VVMw0Y  ,
   "next"  : self.VVMw0Y  ,
   "1"   : self.VVMw0Y  ,
   "2"   : self.VVMw0Y  ,
   "3"   : self.VVMw0Y  ,
   "4"   : self.VVMw0Y  ,
   "5"   : self.VVMw0Y  ,
   "6"   : self.VVMw0Y  ,
   "7"   : self.VVMw0Y  ,
   "8"   : self.VVMw0Y  ,
   "9"   : self.VVMw0Y  ,
   "0"   : self.VVMw0Y
  })
  self.onLayoutFinish.append(self.VVDpWe)
  self.onClose.append(self.VVoUSK)
 def VVDpWe(self):
  self["myLabel"].VVfE6M(isResizable=False, textOutFile="terminal")
  FFeqjP(self["keyRed"]  , "#00ff8000")
  FFLgZ9(self["keyRed"]  , self.skinParam["titleColor"])
  FFLgZ9(self["keyGreen"]  , self.skinParam["titleColor"])
  FFLgZ9(self["keyYellow"] , self.skinParam["titleColor"])
  FFLgZ9(self["keyBlue"] , self.skinParam["titleColor"])
  self.VV7o7U(FF8oWX("date"), 5)
  result = FF8oWX("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVHv8A()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVAquH + "LinuxCommands.lst"
   newTemplate = VVAquH + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFIwml("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFIwml("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVoUSK(self):
  if self.container.VVzH1J():
   self.container.killAll()
   self.VV7o7U("Process killed\n", 4)
   self.VVHv8A()
 def VVzRs8(self):
  if self.container.VVzH1J():
   self.VVoUSK()
  else:
   FFAIFY(self, self.close, "Exit ?", VVoXTx=False)
 def VVHv8A(self):
  self.VV7o7U(self.prompt, 1)
  self["keyRed"].hide()
 def VV7o7U(self, txt, mode):
  if   mode == 1 : color = VV8mIi
  elif mode == 2 : color = VVumHI
  elif mode == 3 : color = VVmG5f
  elif mode == 4 : color = VVyU04
  elif mode == 5 : color = VVkO2P
  elif mode == 6 : color = VVPBk2
  else   : color = VVmG5f
  try:
   self["myLabel"].appendText(FF0IFC(txt, color))
  except:
   pass
 def VVgRor(self, cmd):
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VV7o7U(cmd, 2)
   self.VV7o7U("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VV7o7U(ch, 0)
   self.VV7o7U("\nor\n", 4)
   self.VV7o7U("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVHv8A()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FF0IFC(parts[0].strip(), VVumHI)
    right = FF0IFC("#" + parts[1].strip(), VVPBk2)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VV7o7U(txt, 2)
   lastLine = self.VVluE4()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVds8v(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVtxQZ, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFc8qc(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VV7o7U(data, 3)
 def VVtxQZ(self, data, retval):
  if not retval == 0:
   self.VV7o7U("Exit Code : %d\n" % retval, 4)
  self.VVHv8A()
 def VVIiCy(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVluE4() == "":
   self.VVds8v("cd /tmp")
   self.VVds8v("ls")
  VVMDmE = []
  if fileExists(self.commandHistoryFile):
   lines  = FFNoK6(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVMDmE.append((str(c), line, str(lNum)))
   self.VVUQJK(VVMDmE, title, self.commandHistoryFile, isHistory=True)
  else:
   FFJJSt(self, self.commandHistoryFile, title=title)
 def VVluE4(self):
  lastLine = FF8oWX("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVds8v(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVkTjV(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFNoK6(self.customCommandsFile)
   lastLineIsSep = False
   VVMDmE = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVMDmE.append((str(c), line, str(lNum)))
   self.VVUQJK(VVMDmE, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFJJSt(self, self.customCommandsFile, title=title)
 def VVUQJK(self, VVMDmE, title, filePath=None, isHistory=False):
  if VVMDmE:
   VVANti = "#05333333"
   if isHistory: VV5mP6 = VVqjLk = VVspm3 = "#11000020"
   else  : VV5mP6 = VVqjLk = VVspm3 = "#06002020"
   VVgDsk = VVS9I3 = None
   VVW0bm   = ("Send"   , self.VVNvdw     , [])
   VVieK7  = ("Modify & Send" , self.VV3Bhv     , [])
   if isHistory:
    VVgDsk = ("Clear History" , self.VVf7oc     , [])
   elif filePath:
    VVS9I3 = ("Edit File"  , BF(self.VVEr2E, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVQQbo     = (CENTER  , LEFT   , CENTER )
   FFBL02(self, None, title=title, header=header, VVdLtF=VVMDmE, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=26, VVW0bm=VVW0bm, VVieK7=VVieK7, VVgDsk=VVgDsk, VVS9I3=VVS9I3, VVxbA6=True
     , VV5mP6   = VV5mP6
     , VVqjLk   = VVqjLk
     , VVspm3   = VVspm3
     , VV5F0B  = "#05ffff00"
     , VVANti  = VVANti
    )
  else:
   FFmT9W(self, filePath, title=title)
 def VVNvdw(self, VV57kA, title, txt, colList):
  cmd = colList[1].strip()
  VV57kA.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VV7o7U("\n%s\n" % cmd, 6)
   self.VV7o7U(self.prompt, 1)
  else:
   self.VVgRor(cmd)
 def VV3Bhv(self, VV57kA, title, txt, colList):
  cmd = colList[1]
  self.VVlJ4x(VV57kA, cmd)
 def VVf7oc(self, VV57kA, title, txt, colList):
  FFAIFY(self, BF(self.VVla5H, VV57kA), "Reset History File ?", title="Command History")
 def VVla5H(self, VV57kA):
  os.system(FFIwml("echo '' > %s" % self.commandHistoryFile))
  VV57kA.cancel()
 def VVEr2E(self, filePath, VV57kA, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCQnPl(self, filePath, VVOIg8=BF(self.VVgSzi, VV57kA), curRowNum=rowNum)
  else     : FFJJSt(self, filePath)
 def VVgSzi(self, VV57kA, fileChanged):
  if fileChanged:
   VV57kA.cancel()
   FF1Gz0(self.VVkTjV)
 def VVMw0Y(self):
  self.VVlJ4x(None, self.lastCommand)
 def VVlJ4x(self, VV57kA, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFBJqp(self, BF(self.VVGAps, VV57kA), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVGAps(self, VV57kA, cmd):
  if cmd and len(cmd) > 0:
   self.VVgRor(cmd)
   if VV57kA:
    VV57kA.cancel()
class CC7eE6(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVLK78="", VV2fBh=False, VVBekR=False, isTrimEnds=True):
  self.skin, self.skinParam = FFi9TE(VVysq6, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFRqJR(self, title, addLabel=True)
  FFINW5(self["keyRed"] , "Up/Down = Change")
  FFINW5(self["keyGreen"] , "Overwrite")
  FFINW5(self["keyYellow"], "Pick Key Map")
  FFINW5(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVBekR   = VVBekR
  self.VV2fBh  = VV2fBh
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVLK78, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVUiJj    ,
   "green"    : self.VVnF9g  ,
   "yellow"   : self.VV3JHM    ,
   "blue"    : self.VVZBfa   ,
   "menu"    : self.VVWhl4   ,
   "cancel"   : self.cancel     ,
   "up"    : BF(self.VVePfq, True)  ,
   "down"    : BF(self.VVePfq, False) ,
   "left"    : self.VVoi4I     ,
   "right"    : self.VV8YXG     ,
   "home"    : self.VV13uq     ,
   "end"    : self.VVRmhF     ,
   "next"    : self.VVgvT1    ,
   "last"    : self.VVp9xl    ,
   "deleteForward"  : self.VVgvT1    ,
   "deleteBackward" : self.VVp9xl    ,
   "tab"    : self.VVbd1d     ,
   "toggleOverwrite" : self.VVnF9g  ,
   "0"     : self.VV2m7Q   ,
   "1"     : self.VV2m7Q   ,
   "2"     : self.VV2m7Q   ,
   "3"     : self.VV2m7Q   ,
   "4"     : self.VV2m7Q   ,
   "5"     : self.VV2m7Q   ,
   "6"     : self.VV2m7Q   ,
   "7"     : self.VV2m7Q   ,
   "8"     : self.VV2m7Q   ,
   "9"     : self.VV2m7Q
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVHr3H()
  self.onShown.append(self.VVDpWe)
  self.onClose.append(self.onExit)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FFmyX2(self)
  self["myLabel"].setText(self.message)
  self.VV9glK()
  if self.VV2fBh : self.VVnF9g()
  else    : self.VV9qqL()
  FFSrMl(self)
  FFLgZ9(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVQwFN)
  except:
   self.timer.callback.append(self.VVQwFN)
 def onExit(self):
  self.timer.stop()
 def VVUiJj(self):
  self.VVKnyU()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVKnyU()
  self.close(None)
 def VVWhl4(self):
  VVJtuN = []
  VVJtuN.append(("Home"         , "home"    ))
  VVJtuN.append(("End"         , "end"     ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Clear All"       , "clearAll"   ))
  VVJtuN.append(("Clear To Home"      , "clearToHome"   ))
  VVJtuN.append(("Clear To End"       , "clearToEnd"   ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVRy6N:
   VVJtuN.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("To Capital Letters"     , "toCapital"   ))
  VVJtuN.append(("To Small Letters"      , "toSmall"    ))
  FF0km9(self, self.VV54j5, title="Edit Options", VVJtuN=VVJtuN)
 def VV54j5(self, item=None):
  if item is not None:
   if   item == "home"     : self.VV13uq()
   elif item == "end"     : self.VVRmhF()
   elif item == "clearAll"    : self.VVnqPR()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VV13uq()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVRy6N
    VVRy6N = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVRy6N)
    self.VV13uq()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVQwFN(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVnF9g(self):
  self["myInput"].toggleOverwrite()
  self.VV9qqL()
 def VV3JHM(self):
  self.session.openWithCallback(self.VVQUy3, BF(CCeZky, mode=self.charMode, VVBekR=self.VVBekR))
 def VVQUy3(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VV9glK()
 def VV9qqL(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVHr3H(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVKnyU(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVoVpx(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVoi4I(self)     : self.VVzE6H(self["myInput"].left)
 def VV8YXG(self)     : self.VVzE6H(self["myInput"].right)
 def VVgvT1(self)     : self.VVzE6H(self["myInput"].delete)
 def VV13uq(self)     : self.VVzE6H(self["myInput"].home)
 def VVRmhF(self)     : self.VVzE6H(self["myInput"].end)
 def VVp9xl(self)    : self.VVzE6H(self["myInput"].deleteBackward)
 def VVbd1d(self)     : self.VVzE6H(self["myInput"].tab)
 def VVnqPR(self)     : self["myInput"].setText("")
 def VVzE6H(self, fnc):
  fnc()
  self.VVQwFN()
 def VV2m7Q(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVoVpx(newChar, overwrite)
   self.VVMqQo(newChar, self["myInput"].mapping[number])
 def VVePfq(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCeZky.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCeZky.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVoVpx(newChar, True)
   for group in groups:
    if newChar in group:
     self.VVMqQo(newChar, group)
     break
 def VVMqQo(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVmG5f:
    group = VVkO2P + group.replace(newChar, FF0IFC(newChar, VVmG5f, VVkO2P))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVZBfa(self):
  if self.VVBekR : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VV9glK()
 def VV9glK(self):
  self["myInput"].mapping = CCeZky.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCeZky.RCU_MAP_TITLES[self.charMode])
class CCeZky(Screen):
 VVhR3E  = 0
 VVZfNC  = 1
 VVptvp  = 2
 VVIR00  = 3
 VVprS9 = 4
 VV41Si = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols , arabic_nums1, arabic1)
       , ( symbols , arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A", u"\u0628")
       , (u"\u0647", u"\u062A")
       )
 def __init__(self, session, mode=VVhR3E, VVBekR=False):
  self.skin, self.skinParam = FFi9TE(VVEZH2, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVBekR  = VVBekR
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFRqJR(self, title=self.Title)
  FFINW5(self["keyRed"] ,"OK = Select")
  FFINW5(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV3dkq    ,
   "cancel" : self.cancel     ,
   "last"  : BF(self.VVRYCM, -1) ,
   "next"  : BF(self.VVRYCM, +1) ,
   "left"  : BF(self.VVRYCM, -1) ,
   "right"  : BF(self.VVRYCM, +1) ,
  }, -1)
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FFLgZ9(self["keyRed"], "#11222222")
  FFLgZ9(self["keyGreen"], "#11222222")
  self.VVOGfV()
 def VVOGfV(self):
  self.VV5zvJ()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VV5zvJ(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVRYCM(self, direction):
  if self.VVBekR : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVOGfV()
 def VV3dkq(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CChxgF(Screen):
 def __init__(self, session, title="", message="", VV0vZt=VVOM7o, VV5QWZ=False, VVspm3=None, VVYOiV=30, canSaveToFile=""):
  self.skin, self.skinParam = FFi9TE(VVAK4W, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVYOiV)
  self.session   = session
  FFRqJR(self, title, addScrollLabel=True)
  self.VV0vZt   = VV0vZt
  self.VV5QWZ   = VV5QWZ
  self.VVspm3   = VVspm3
  self.canSaveToFile  = canSaveToFile
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  self["myLabel"].VVfE6M(VV5QWZ=self.VV5QWZ, textOutFile=self.canSaveToFile)
  self["myLabel"].setText(self.message, self.VV0vZt)
  if self.VVspm3:
   FFLgZ9(self["myBody"], self.VVspm3)
   FFLgZ9(self["myLabel"], self.VVspm3)
   FF8q6B(self["myLabel"], self.VVspm3)
  self["myLabel"].VVivUS()
class CCGSN2(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFi9TE(VV15d1, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFRqJR(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FFLtUd(self["errPic"], "err")
class CC3dCB(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFi9TE(VVpEAW, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FFRqJR(self, " ", addCloser=True)
class CCKyDd():
 def __init__(self, session, txt, timeout=1500):
  self.win = session.instantiateDialog(CC3dCB, txt, 24)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  FF8WkH(self.win["myWinTitle"], "#440000", 2)
  self.session = session
  self.timer  = eTimer()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVPmEn)
  except:
   self.timer.callback.append(self.VVPmEn)
  self.timer.start(timeout, True)
 def VVPmEn(self):
  self.session.deleteDialog(self.win)
class CCUd13():
 VV8cJA    = 0
 VVLW5u  = 1
 VVwMCt   = ""
 VVPNV4    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VV57kA   = None
  self.timer     = eTimer()
  self.VVtPsC   = 0
  self.VV8Gdb  = 1
  self.VVeKL4  = 2
  self.VVSRqS   = 3
  self.VVo4tQ   = 4
  VVMDmE = self.VVhEHC()
  if VVMDmE:
   self.VV57kA = self.VVvM0K(VVMDmE)
  if not VVMDmE and mode == self.VV8cJA:
   self.VV5kIxor("Download list is empty !")
   self.cancel()
  if mode == self.VVLW5u:
   FFItMF(self.VV57kA or self.SELF, BF(self.VVZPFk, startDnld, decodedUrl), title="Checking Server ...")
  self.VVnCui(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVnCui)
  except:
   self.timer.callback.append(self.VVnCui)
  self.timer.start(1000, False)
 def VVvM0K(self, VVMDmE):
  VVMDmE.sort(key=lambda x: int(x[0]))
  VVqaLK = self.VV1bAI
  VVW0bm  = ("Play"  , self.VVT455 , [])
  VVMg98 = (""   , self.VVuL1A  , [])
  VV39uD = ("Stop"  , self.VVrms9  , [])
  VVieK7 = ("Resume"  , self.VVLA5D , [])
  VVgDsk = ("Options" , self.VV8ibF  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVQQbo  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFBL02(self.SELF, None, title=self.Title, header=header, VVdLtF=VVMDmE, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=26, VVW0bm=VVW0bm, VVMg98=VVMg98, VVqaLK=VVqaLK, VV39uD=VV39uD, VVieK7=VVieK7, VVgDsk=VVgDsk, VVqjLk="#11110011", VV5mP6="#11220022", VVspm3="#11110011", VV5F0B="#00ffff00", VVANti="#00223025", VVxA4o="#0a333333", VVVSpS="#0a400040", VVxbA6=True, searchCol=1)
 def VVhEHC(self):
  lines = CCUd13.VV4dDZ()
  VVMDmE = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",")
     left  = parts[0].strip()
     decodedUrl = ",".join(parts[1:]).strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVra0u(decodedUrl)
      if fName:
       if   FFEdRO(decodedUrl) : sType = "Movie"
       elif FFMDjw(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVmWrC(decodedUrl, fName)
       if size > -1: sizeTxt = CCg2YR.VVBWem(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVMDmE.append((str(len(VVMDmE) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVMDmE
 def VVZpg5(self):
  VVMDmE = self.VVhEHC()
  if VVMDmE:
   if self.VV57kA : self.VV57kA.VV3aGD(VVMDmE, VVAkjgMsg=False)
   else     : self.VV57kA = self.VVvM0K(VVMDmE)
  else:
   self.cancel()
 def VVnCui(self, force=False):
  if self.VV57kA:
   thrListUrls = self.VVrWtK()
   VVMDmE = []
   changed = False
   for ndx, row in enumerate(self.VV57kA.VVRk4N()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVtPsC
    if m3u8Log:
     percent = CCUd13.VVvjcr(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVSRqS , "%.2f %%" % percent
      else   : flag, progr = self.VVo4tQ , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFEZp1(mPath)
     if curSize > -1:
      fSize = CCg2YR.VVBWem(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCg2YR.VVBWem(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFEZp1(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVSRqS , "%.2f %%" % percent
       else   : flag, progr = self.VVo4tQ , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCg2YR.VVBWem(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VVeKL4
     if m3u8Log :
      if not speed and not force : flag = self.VV8Gdb
      elif curSize == -1   : self.VV4D4e(False)
    elif flag == self.VVtPsC  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVtPsC  : color2 = "#f#00555555#"
    elif flag == self.VV8Gdb : color2 = "#f#0000FFFF#"
    elif flag == self.VVeKL4 : color2 = "#f#0000FFFF#"
    elif flag == self.VVSRqS  : color2 = "#f#00FF8000#"
    elif flag == self.VVo4tQ  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVQ8E3(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVMDmE.append(row)
   if changed or force:
    self.VV57kA.VV3aGD(VVMDmE, VVAkjgMsg=False)
 def VVQ8E3(self, flag):
  tDict = self.VVzIdb()
  return tDict.get(flag, "?")
 def VVFJ1I(self, state):
  for flag, txt in self.VVzIdb().items():
   if txt == state:
    return flag
  return -1
 def VVzIdb(self):
  return { self.VVtPsC: "Not started", self.VV8Gdb: "Connecting", self.VVeKL4: "Downloading", self.VVSRqS: "Stopped", self.VVo4tQ: "Completed" }
 def VV3TEh(self, title):
  colList = self.VV57kA.VVOvKg()
  path = colList[6]
  url  = colList[8]
  if self.VVcqpk() : self.VV5kIxor("Cannot delete !\n\nFile is downloading.")
  else      : FFAIFY(self.SELF, BF(self.VV7zbW, path, url), "Delete ?\n\n%s" % path, title=title)
 def VV7zbW(self, path, url):
  m3u8Log = self.VV57kA.VVOvKg()[12].strip()
  if m3u8Log : os.system(FFIwml("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFIwml("rm -r '%s'" % path))
  self.VV6tEp(False)
  self.VVZpg5()
 def VV6tEp(self, VV5kIx=True):
  if self.VVcqpk():
   FFlDiQ(self.VV57kA, self.VVQ8E3(self.VVeKL4), 500)
  else:
   colList  = self.VV57kA.VVOvKg()
   state  = colList[4].strip()
   decodedUrl = colList[9].strip()
   if self.VVFJ1I(state) in (self.VVtPsC, self.VVo4tQ, self.VVSRqS):
    lines = CCUd13.VV4dDZ()
    newLines = []
    found = False
    for line in lines:
     if CCUd13.VVG6p4(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVUb8f(newLines)
     self.VVZpg5()
     FFlDiQ(self.VV57kA, "Removed.", 1000)
    else:
     FFlDiQ(self.VV57kA, "Not found.", 1000)
   elif VV5kIx:
    self.VV5kIxor("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVqArf(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFAIFY(self.SELF, BF(self.VVtFl5, flag), ques, title=title)
 def VVtFl5(self, flag):
  list = []
  for ndx, row in enumerate(self.VV57kA.VVRk4N()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVFJ1I(state)
   if   flag == flagVal == self.VVo4tQ: list.append(decodedUrl)
   elif flag == flagVal == self.VVtPsC : list.append(decodedUrl)
  lines = CCUd13.VV4dDZ()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVUb8f(newLines)
   self.VVZpg5()
   FFlDiQ(self.VV57kA, "%d removed." % totRem, 1000)
  else:
   FFlDiQ(self.VV57kA, "Not found.", 1000)
 def VVRb76(self):
  colList  = self.VV57kA.VVOvKg()
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFlDiQ(self.VV57kA, "Poster exists", 1500)
  else    : FFItMF(self.VV57kA, BF(self.VV6exO, decodedUrl, path, png), title="Checking Server ...")
 def VV6exO(self, decodedUrl, path, png):
  err = self.VVFzIn(decodedUrl, path, png)
  if err:
   FFc8qc(self.SELF, err, title="Poster Download")
 def VVFzIn(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CC159n.VV9sR2(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCUfgv.VVOsYy(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCUfgv.VVyKpQ(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCUfgv.VVh28z(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFWvl5(pUrl, "ajpanel_tmp%s", timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   os.system(FFIwml("mv -f '%s' '%s'" % (tPath, png)))
   CCDjKX.VV9Hrp(self.SELF, VVrVOq=png, showGrnMsg="Downloaded")
   return ""
 def VVuL1A(self, VV57kA, title, txt, colList):
  def VVzMl5(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVxcQr(key, val) : return "\n%s:\n%s\n" % (FF0IFC(key, COLOR_CONS_BRIGHT_YELLOW), val.strip())
  heads  = self.VV57kA.VVHop3()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVzMl5(heads[i]  , CCg2YR.VVBWem(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVzMl5("Downloaded" , CCg2YR.VVBWem(int(curSize), mode=0))
   else:
    txt += VVzMl5(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVxcQr(heads[i], colList[i])
  FFPt7a(self.SELF, txt, title=title)
 def VVT455(self, VV57kA, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCg2YR.VV80Di(self.SELF, path)
  else    : FFlDiQ(self.VV57kA, "File not found", 1000)
 def VV1bAI(self, VV57kA):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VV57kA:
   self.VV57kA.cancel()
  del self
 def VV8ibF(self, VV57kA, title, txt, colList):
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVJtuN = []
  VVJtuN.append(("Remove current row"      , "VV6tEp"  ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(('Remove all "Completed"'     , "remFinished"    ))
  VVJtuN.append(('Remove all "Not started"'     , "remPending"    ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Delete the file (and remove from list)" , "VV3TEh" ))
  if FFEdRO(decodedUrl):
   VVJtuN.append(VVImCt)
   VVJtuN.append(("Download Movie Poster (from server)" , "VVRb76"   ))
  VVJtuN.append(VVImCt)
  VVJtuN.append((resumeTxt + " Auto Resume"     , "VVZV5s"  ))
  VVJtuN.append((showMonitor + " On-screen Monitor"   , "toggleMonitor"   ))
  FF0km9(self.SELF, self.VVPhII, VVJtuN=VVJtuN, title=self.Title, VVz4LU=True, VV1n4R=True)
 def VVPhII(self, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VV6tEp"  : self.VV6tEp()
   elif ref == "remFinished"   : self.VVqArf(self.VVo4tQ, txt)
   elif ref == "remPending"   : self.VVqArf(self.VVtPsC, txt)
   elif ref == "VV3TEh" : self.VV3TEh(txt)
   elif ref == "VVRb76"  : self.VVRb76()
   elif ref == "VVZV5s"  :
    CFG.downloadAutoResume.setValue(not CFG.downloadAutoResume.getValue())
    CFG.downloadAutoResume.save()
    configfile.save()
   elif ref == "toggleMonitor"   :
    CFG.downloadMonitor.setValue(not CFG.downloadMonitor.getValue())
    CFG.downloadMonitor.save()
    configfile.save()
 def VVZPFk(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CC159n.VV9sR2(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VV5kIxor("Could not get download link !\n\nTry again later.")
     return
  for line in CCUd13.VV4dDZ():
   if CCUd13.VVG6p4(decodedUrl, line):
    self.VVQXYk(decodedUrl)
    FF1Gz0(BF(FFlDiQ, self.VV57kA, "Already listed !", 2000))
    break
  else:
   params = self.VVb124(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VV5kIxor(params[0])
   elif len(params) == 2:
    FFAIFY(self.SELF, BF(self.VVPYbz, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCg2YR.VVBWem(fSize)
    FFAIFY(self.SELF, BF(self.VVe7PS, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVe7PS(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCUd13.VVmoyK(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVZpg5()
  if self.VV57kA:
   self.VV57kA.VVzwU8()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCUd13.VVPNV4, path, decodedUrl)
   self.VVueqR(threadName, url, decodedUrl, path, resp)
 def VVQXYk(self, decodedUrl):
  for ndx, row in enumerate(self.VV57kA.VVRk4N()):
   decodedUrl2 = row[9].strip()
   if decodedUrl == decodedUrl2 and self.VV57kA:
    self.VV57kA.VVRvKN(ndx)
    break
 def VVb124(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVra0u(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVmWrC(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CC159n.VV9sR2(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CC159n.VVwzcSHeader()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCUd13.VVj3JV(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCUd13.VV2RPj(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVPYbz(self, resp, decodedUrl):
  if not os.system(FFIwml("which ffmpeg")) == 0:
   FFAIFY(self.SELF, BF(CCUfgv.VVw8r1, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVra0u(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVksyj(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFAIFY(self.SELF, BF(self.VVZjc8, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVZjc8(rTxt, rUrl)
  else:
   self.VV5kIxor("Cannot process m3u8 file !")
 def VVksyj(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVJtuN = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCUfgv.VVQarx(rUrl, fPath)
   VVJtuN.append((resol, fullUrl))
  if VVJtuN:
   FF0km9(self.SELF, self.VVo7Kv, VVJtuN=VVJtuN, title="Resolution", VVz4LU=True, VV1n4R=True)
  else:
   self.VV5kIxor("Cannot get Resolutions list from server !")
 def VVo7Kv(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFAIFY(self.SELF, BF(FF1Gz0, BF(self.VVtAKM, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FF1Gz0(BF(self.VVtAKM, resolUrl))
 def VVtAKM(self, resolUrl):
  txt, err = CC159n.VVqAwi(resolUrl)
  if err : self.VV5kIxor(err)
  else : self.VVZjc8(txt, resolUrl)
 def VVsVxr(self, logF, decodedUrl):
  found = False
  lines = CCUd13.VV4dDZ()
  with open(CCUd13.VVmoyK(), "w") as f:
   for line in lines:
    if CCUd13.VVG6p4(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCUd13.VVmoyK(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVZpg5()
  if self.VV57kA:
   self.VV57kA.VVzwU8()
 def VVZjc8(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCUfgv.VVQarx(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VV5kIxor("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVsVxr(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFIwml("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCUd13.VVPNV4, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVvjcr(dnldLog):
  if fileExists(dnldLog):
   dur = CCUd13.VVLYxw(dnldLog)
   if dur > -1:
    tim = CCUd13.VVgd21(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVLYxw(dnldLog):
  lines = FFOAMF("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVgd21(dnldLog):
  lines = FFOAMF("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVmWrC(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFMDjw(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFIwml("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVueqR(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VV57kA.VVOvKg()[7].strip())
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VVQ4aI, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVQ4aI(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVwMCt == path:
       break
     else:
      break
  except:
   return
  if CCUd13.VVwMCt:
   CCUd13.VVwMCt = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFEZp1(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVb124(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVQ4aI(url, decodedUrl, path, resp, totFileSize, True)
 def VVrms9(self, VV57kA, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVAoNk() : FFlDiQ(self.VV57kA, self.VVQ8E3(self.VVo4tQ), 500)
  elif not self.VVcqpk() : FFlDiQ(self.VV57kA, self.VVQ8E3(self.VVSRqS), 500)
  elif m3u8Log      : FFAIFY(self.SELF, self.VV4D4e, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVrWtK():
    CCUd13.VVwMCt = colList[6]
    FFlDiQ(self.VV57kA, "Stopping ...", 1000)
   else:
    FFlDiQ(self.VV57kA, "Stopped", 500)
 def VV4D4e(self, withMsg=True):
  if withMsg:
   FFlDiQ(self.VV57kA, "Stopping ...", 1000)
  os.system(FFIwml("killall -INT ffmpeg"))
 def VVLA5D(self, *args):
  if   self.VVAoNk() : FFlDiQ(self.VV57kA, self.VVQ8E3(self.VVo4tQ) , 500)
  elif self.VVcqpk() : FFlDiQ(self.VV57kA, self.VVQ8E3(self.VVeKL4), 500)
  else:
   resume = False
   m3u8Log = self.VV57kA.VVOvKg()[12].strip()
   if m3u8Log:
    if fileExists(m3u8Log) : FFAIFY(self.SELF, BF(self.VVjdOR, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVGeEg():
    resume = True
   if resume: FFItMF(self.VV57kA, BF(self.VVd2T9), title="Checking Server ...")
   else  : FFlDiQ(self.VV57kA, "Cannot resume !", 500)
 def VVjdOR(self, m3u8Log):
  os.system(FFIwml("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FFItMF(self.VV57kA, BF(self.VVd2T9), title="Checking Server ...")
 def VVd2T9(self):
  colList  = self.VV57kA.VVOvKg()
  path  = colList[6].strip()
  size  = colList[7].strip()
  decodedUrl = colList[9].strip()
  if "j.php" in decodedUrl:
   url = CC159n.VV9sR2(decodedUrl)
   if url:
    decodedUrl = self.VVgREO(decodedUrl, url)
   else:
    self.VV5kIxor("Could not get download link !\n\nTry again later.")
    return
  curSize = FFEZp1(path)
  params = self.VVb124(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VV5kIxor(params[0])
   return
  elif len(params) == 2:
   self.VVPYbz(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVgREO(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCUd13.VVPNV4, path, decodedUrl)
  if resumable: self.VVueqR(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VV5kIxor("Cannot resume from server !")
 def VVra0u(self, decodedUrl):
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(http:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   x = decodedUrl.find("&mode")
   if x > -1: url = decodedUrl[:x]
   fName = ".mp4"
   x = decodedUrl.find("&end=")
   if x > -1: chName = decodedUrl[x+5:]
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + ".mp4"
     fixName = False
     ok  = True
   if not ok and FFHwNJ(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + ".mp4"
     fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    fName =  mix.split(":")[0]
    chName = ":".join(mix.split(":")[1:])
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VV5kIxor(self, txt):
  FFc8qc(self.SELF, txt, title=self.Title)
 def VVrWtK(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCUd13.VVPNV4, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VVcqpk(self):
  decodedUrl = self.VV57kA.VVOvKg()[9].strip()
  return decodedUrl in self.VVrWtK()
 def VVAoNk(self):
  colList = self.VV57kA.VVOvKg()
  path = colList[6].strip()
  size = colList[7].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFEZp1(path)) == size
 def VVGeEg(self):
  colList = self.VV57kA.VVOvKg()
  path = colList[6].strip()
  size = int(colList[7].strip())
  curSize = FFEZp1(path)
  if curSize > -1:
   size -= curSize
  err = CCUd13.VV2RPj(size)
  if err:
   FFc8qc(self.SELF, err, title=self.Title)
   return False
  return True
 def VVUb8f(self, list):
  with open(CCUd13.VVmoyK(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVgREO(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCUd13.VV4dDZ()
  url = decodedUrl
  with open(CCUd13.VVmoyK(), "w") as f:
   for line in lines:
    if CCUd13.VVG6p4(decodedUrl, line):
     parts = line.split(",")
     oldUrl = ",".join(parts[1:]).strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVZpg5()
  return url
 @staticmethod
 def VV4dDZ():
  list = []
  if fileExists(CCUd13.VVmoyK()):
   for line in FFNoK6(CCUd13.VVmoyK()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVG6p4(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VV2RPj(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCg2YR.VVQ9JD(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCg2YR.VVBWem(size), CCg2YR.VVBWem(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVN89X(SELF):
  tot = CCUd13.VVbbtb()
  if tot:
   FFc8qc(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVbbtb():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCUd13.VVPNV4):
    c += 1
  return c
 @staticmethod
 def VV6P55():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCUd13.VVPNV4, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VVogwQ():
  return len(CCUd13.VV4dDZ()) == 0
 @staticmethod
 def VVo3yJ():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVXo1Q():
  mPoints = CCUd13.VVo3yJ()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFIwml("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVmoyK():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVw9wz(SELF):
  CCUd13.VV4RZT(SELF, CCUd13.VV8cJA)
 @staticmethod
 def VVMKiE_cur(SELF):
  CCUd13.VV4RZT(SELF, CCUd13.VVLW5u, startDnld=True)
 @staticmethod
 def VVMKiE_url(SELF, url):
  CCUd13.VV4RZT(SELF, CCUd13.VVLW5u, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVJ7yZCurrent(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(SELF)
  added, skipped = CCUd13.VVJ7yZList([decodedUrl])
  FFlDiQ(SELF, "Added", 1000)
 @staticmethod
 def VVJ7yZList(list):
  added = skipped = 0
  for line in CCUd13.VV4dDZ():
   for ndx, url in enumerate(list):
    if url and CCUd13.VVG6p4(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCUd13.VVmoyK(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VV4RZT(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCycDZ.VV3e4i(SELF):
   return
  if mode == CCUd13.VV8cJA and CCUd13.VVogwQ():
   FFc8qc(SELF, "Download list is empty !", title=title)
  else:
   inst = CCUd13(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVj3JV(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCVY8O(Screen, CCytqZ):
 VVWmJG = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False, enableDownloadMenu=True):
  self.skin, self.skinParam = FFi9TE(VV377I, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCytqZ.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  self.SubtWin    = None
  FFRqJR(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVhGze())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVlQQ7       ,
   "info"  : self.VVz7V2      ,
   "epg"  : self.VVz7V2      ,
   "menu"  : self.VVXfFk     ,
   "cancel" : self.cancel       ,
   "blue"  : self.VVR4Ao      ,
   "green"  : self.VVKGEt  ,
   "yellow" : self.VVVCeX ,
   "left"  : BF(self.VV36W4, -1)    ,
   "right"  : BF(self.VV36W4,  1)    ,
   "play"  : self.VVOEN9      ,
   "pause"  : self.VVOEN9      ,
   "playPause" : self.VVOEN9      ,
   "stop"  : self.VVOEN9      ,
   "rewind" : self.VVmedP      ,
   "forward" : self.VVJv2m      ,
   "rewindDm" : self.VVmedP      ,
   "forwardDm" : self.VVJv2m      ,
   "last"  : self.VVTLB1      ,
   "next"  : self.VV4D3o      ,
   "pageUp" : BF(self.VVI7Tx, True)  ,
   "pageDown" : BF(self.VVI7Tx, False)  ,
   "chanUp" : BF(self.VVI7Tx, True)  ,
   "chanDown" : BF(self.VVI7Tx, False)  ,
   "up"  : BF(self.VVI7Tx, True)  ,
   "down"  : BF(self.VVI7Tx, False)  ,
   "audio"  : BF(self.VVzL2y, True)  ,
   "subtitle" : BF(self.VVzL2y, False)  ,
   "0"   : BF(self.VVFN09 , 10)   ,
   "1"   : BF(self.VVFN09 , 1)   ,
   "2"   : BF(self.VVFN09 , 2)   ,
   "3"   : BF(self.VVFN09 , 3)   ,
   "4"   : BF(self.VVFN09 , 4)   ,
   "5"   : BF(self.VVFN09 , 5)   ,
   "6"   : BF(self.VVFN09 , 6)   ,
   "7"   : BF(self.VVFN09 , 7)   ,
   "8"   : BF(self.VVFN09 , 8)   ,
   "9"   : BF(self.VVFN09 , 9)
  }, -1)
  self.onShown.append(self.VVDpWe)
  self.onClose.append(self.onExit)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FFmyX2(self)
  if not CCVY8O.VVWmJG:
   CCVY8O.VVWmJG = self
  else:
   self.close()
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFLtUd(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFLtUd(self["myPlayRpt"], "rpt")
  self.VVGags()
  self.instance.move(ePoint(40, 40))
  self.VVfh10(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVZBwg)
  except:
   self.timer.callback.append(self.VVZBwg)
  self.timer.start(250, False)
  self.VVZBwg("Checking ...")
  self.VVtw8W()
 def VVKGEt(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self)
  self.lastSubtitle = CCVm2X.VVskqq()
  if "chCode" in iptvRef:
   if CCycDZ.VV3e4i(self):
    self.VVtw8W(True)
  else:
   self.VVZBwg("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVGags(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  color = "#1100202a"
  if "chCode" in origUrl:
   if "get_download_link" in origUrl: color = "#1120101a"
   else        : color = "#1120002a"
  FFLgZ9(self["myTitle"], color)
 def VVXfFk(self):
  if self.SubtWin:
   self.SubtWin.VVVDWN()
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self)
  VVJtuN = []
  if self.isFromExternal:
   VVJtuN.append(("IPTV Menu"     , "iptv"  ))
   VVJtuN.append(VVImCt)
  if FFgKj2(iptvRef) and not "&end=" in decodedUrl and not FFHwNJ(decodedUrl):
   uType, uHost, uUser, uPass, uId, uChName = CCUfgv.VVOsYy(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVJtuN.append(("Catchup Programs"   , "catchup"  ))
    VVJtuN.append(VVImCt)
  VVJtuN.append(("Stop Current Service"    , "stop"  ))
  VVJtuN.append(("Restart Current Service"   , "restart"  ))
  VVJtuN.append(VVImCt)
  FFEdROSeries = FFHwNJ(decodedUrl)
  if FFEdROSeries:
   VVJtuN.append(("File Size"     , "fileSize" ))
   VVJtuN.append(VVImCt)
  if self.enableDownloadMenu:
   addSep = False
   if FFgKj2(iptvRef) and FFEdROSeries:
    VVJtuN.append(("Start Download"   , "dload_cur" ))
    VVJtuN.append(("Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCUd13.VVogwQ():
    VVJtuN.append(("Download Manager"   , "dload_stat" ))
    addSep = True
   if addSep:
    VVJtuN.append(VVImCt)
  fPath, fDir, fName = CCg2YR.VV14bi(self)
  if fPath:
   if not CCg2YR.VVXhWl:
    VVJtuN.append((VV8mIi + "Open path in File Manager", "VVhzpE" ))
   VVJtuN.append((VV8mIi + 'Add to "My Movies" Bouquet' , "VVpxwt" ))
   VVJtuN.append(("%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVKYlc" ))
   VVJtuN.append(VVImCt)
  enabl = False
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCVY8O.VVKYDg(self)
  if posVal and durVal:
   enabl = True
  else:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCSQQx.VVrqW4(self)
   enabl = evName and evTime and evDur
  if enabl:
   VVJtuN.append((VV8mIi + "Start Subtitle"    , "VVrXbS"  ))
   VVJtuN.append(VVImCt)
  if CFG.playerPos.getValue() : VVJtuN.append(("Move Bar to Bottom"  , "botm"    ))
  else      : VVJtuN.append(("Move Bar to Top"  , "top"     ))
  if not iptvRef:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv and not serv.getPath():
    VVJtuN.append((FF0IFC("Signal Monitor", COLOR_CONS_BRIGHT_YELLOW), "sigMon"  ))
  VVJtuN.append(("Help"             , "help"    ))
  FF0km9(self, self.VVqbvw, VVJtuN=VVJtuN, width=550, title="Options")
 def VVqbvw(self, item=None):
  if item:
   if item == "iptv"     : self.VVVoOo()
   elif item == "catchup"    : self.VVVCeX()
   elif item == "stop"     : self.VVnNEq(0)
   elif item == "restart"    : self.VVnNEq(1)
   elif item == "fileSize"    : FFItMF(self, BF(CCSQQx.VVyUkt, self), title="Checking Server")
   elif item == "dload_cur"   : CCUd13.VVMKiE_cur(self)
   elif item == "addToDload"   : CCUd13.VVJ7yZCurrent(self)
   elif item == "dload_stat"   : CCUd13.VVw9wz(self)
   elif item == "VVhzpE" : self.VVhzpE()
   elif item == "VVpxwt" : FFItMF(self, self.VVpxwt)
   elif item == "VVrXbS"  : self.VVrXbS(CCVm2X.VVVuAB)
   elif item == "VVKYlc"  : self.VVKYlc()
   elif item == "botm"     : self.VVfh10(0)
   elif item == "top"     : self.VVfh10(1)
   elif item == "sigMon"    : self.VV2tJV()
   elif item == "help"     : FFsJjT(self, VVAquH + "_help_player", "Player Controller (Keys)")
 def onExit(self):
  self.timer.stop()
  CCVY8O.VVWmJG = None
  self.VVazXl()
 def VViE69(self):
  if CCVY8O.VVWmJG:
   self.session.open(CCVY8O, enableZapping= False, enableDownloadMenu=False)
  self.close()
 def VVhzpE(self):
  self.session.open(CCg2YR, gotoMovie=True)
  self.VViE69()
 def VVVoOo(self):
  self.session.open(CCUfgv)
  self.VViE69()
 def VVnNEq(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.close()
   elif typ == 1:
    self.VVZBwg("Restarting Service ...")
    FF1Gz0(BF(self.VVqik4, serv))
 def VVqik4(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self)
  if "&end=" in decodedUrl: BF(self.VVtw8W, True)
  else     : self.session.nav.playService(serv)
 def VVpxwt(self):
  title = "Add Movie to Bouquet"
  bName = "My Movies"
  path  = VVR2Ml + "userbouquet.my_local_movies.tv"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self)
  fPath, fDir, fName = CCg2YR.VV14bi(self)
  if not fPath or not chName:
   FFc8qc(self, "Cannot read Path or Channel Name", title=title)
   return
  isNew = False
  if not fileExists(path):
   isNew = True
   with open(path, "w") as f:
    f.write("#NAME %s\n" % bName)
  catID, stID, chNum = "1638", "6", "6"
  refCode = CCUfgv.VVxbxd(catID, stID, chNum)
  if not isNew:
   fTxt = FFt4Zg(path)
   chUrl_noRef = "%s:%s" % (fPath, chName)
   if chUrl_noRef in fTxt:
    FFc8qc(self, "Already added to bouquet:\n\n%s" % bName, title=title)
    return
   for ns in range(1, 65535 - 1):
    catID, stID, chNum = "1638", str(ns), "6"
    refCode = CCUfgv.VVxbxd(catID, stID, chNum)
    if not refCode in fTxt:
     break
   else:
    FFc8qc(self, "Cannot create a unique Reference Code", title=title)
    return
  if refCode and fPath and chName:
   chUrl = "%s%s:%s" % (refCode, fPath, chName)
   with open(path, "a") as f:
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
   piconOk = self.VVJQc9(refCode)
   FFLQO2(os.path.basename(path))
   FFSZ2d()
   FF9xND(self, "Added to bouquet:\n\n%s" % bName, title=title + (" (with PIcon)" if piconOk else ""))
  else:
   FFc8qc(self, "Cannot create a unique Reference Code", title=title)
   return
 def VVKYlc(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCVY8O.VVKYDg(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVZBwg(txt, highlight=ok)
 def VVrXbS(self, mode, useSubtFile=""):
  self.hide()
  self.SubtWin = self.session.instantiateDialog(CCVm2X, mode=mode, endCallback=self.VVy5Ic)
  self.SubtWin.show()
  self.SubtWin.VVR4Y9(useSubtFile)
 def VVy5Ic(self, err):
  if err:
   if err == "noResume": self.VVazXl(False)
   else    : self.VVazXl(True)
   if   err == "noResume" : return
   if   err == "noErr"  : return
   elif err == "noAutoSrt" : CCVm2X.VV6VRe(self, self.VVQJsP)
   else      : FFlDiQ(self, err, 2000)
 def VVQJsP(self, path):
  if path:
   self.VVrXbS(CCVm2X.VVVuAB, useSubtFile=path)
 def VVJQc9(self, refCode):
  fPath, fDir, fName, picFile = CCSQQx.VVFNfY(self)
  pPath = CC2T9T.VVP17o()
  if fileExists(pPath) and pathExists(picFile):
   pFile = refCode.replace(":", "_").strip("_") + ".png"
   dest = os.path.join(pPath, pFile)
   os.system(FFIwml("cp -f '%s' '%s'" % (picFile, dest)))
   os.system(FFIwml("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (dest, dest)))
   return True
  return False
 def VVfh10(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VV2tJV(self):
  self.session.open(CCoR4p)
  self.close()
 def VVlQQ7(self):
  if self.isManualSeek:
   self.VVgkdY()
   self.VVq7U7(self.manualSeekPts)
  else:
   if self.shown:
    self.hide()
    self.VVrXbS(CCVm2X.VVj3qa)
   else:
    self.VVazXl()
 def VVazXl(self, showBar=True):
  if self.SubtWin:
   self.session.deleteDialog(self.SubtWin)
   self.SubtWin = None
  if showBar:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVgkdY()
  elif self.SubtWin : self.VVazXl()
  else    : self.close()
 def VVz7V2(self):
  if self.SubtWin:
   self.SubtWin.VVag9x("noErr")
  FFsVRo(self, fncMode=CCSQQx.VVKqex)
 def VVOEN9(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VVZBwg("Toggling Play/Pause ...")
 def VVgkdY(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VV36W4(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCVY8O.VVKYDg(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVhCON()
   else:
    self.manualSeekSec += direc * self.VVhCON()
    self.manualSeekSec = FF2XXx(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFbZQf(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FF2LS5(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVFN09(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVhGze())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVZBwg("Changed Seek Time to : %d%s" % (val, self.VVJ9HG()))
 def VVhGze(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVJ9HG())
 def VVJ9HG(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VV0Jbz(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVhCON(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVZBwg(self, stateTxt="", highlight=False):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFrHOu(self, addInfoObj=True)
  fr = res = ""
  if info:
   w = FFJ0c4(info, iServiceInformation.sVideoWidth) or -1
   h = FFJ0c4(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFJ0c4(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CCSQQx.VVqAyL(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCVY8O.VVKYDg(self)
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FF2XXx(percVal, 0, 100)
    width = int(FFbZQf(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not posTxt: self["myPlayPos"].setText("")
  if not remTxt: self["myPlayRem"].setText("")
  if not durTxt:
   if   prov : txt = prov
   elif posTxt : txt = ">>>>"
   else  : txt = "...."
   self["myPlayVal"].setText(txt)
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText("")
   FFLgZ9(self["myPlayBarBG"], "#1100202a")
   self["myPlayBarF"].hide()
  else:
   FFLgZ9(self["myPlayBarBG"], "#11000000")
   self["myPlayBarF"].show()
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VV45Ej() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   if highlight: FFeqjP(self["myPlayMsg"], "#0000ffff")
   else  : FFeqjP(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   self["myPlayMsg"].setText("-" if decodedUrl else FFbHaq(refCode, True))
   FFeqjP(self["myPlayMsg"], "#00ff8066")
  tot = CCUd13.VVbbtb()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVHkpc()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VVq7U7(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CCVm2X.VVUaQM(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVTLB1()
  state = self.VVu5XZ()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFeqjP(self["myPlayMsg"], "#0000ff00")
  else     : FFeqjP(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 @staticmethod
 def VVKYDg(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FF2LS5(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FF2LS5(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FF2LS5(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVHkpc(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVR4Ao(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VV45Ej()
   if cList:
    VVJtuN = []
    for pts, what in cList:
     txt = FF2LS5(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVJtuN.append((txt, pts))
    FF0km9(self, self.VVNyai, VVJtuN=VVJtuN, title="Cut List")
   else:
    self.VVZBwg("No Cut-List for this channel !")
 def VVNyai(self, item=None):
  if item:
   self.VVq7U7(item)
 def VV45Ej(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVJv2m(self) : self.VVMxEk(1)
 def VVmedP(self) : self.VVMxEk(-1)
 def VVMxEk(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCVY8O.VVKYDg(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVhCON() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VV0Jbz())
    self.VVZBwg(txt)
  except:
   self.VVZBwg("Cannot jump")
 def VVq7U7(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVZBwg("Changing Time ...")
 def VVTLB1(self):
  self.VVnNEq(1)
  self.VVZBwg("Replaying ...")
  self.VVgkdY()
 def VV4D3o(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCVY8O.VVKYDg(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVZBwg("Jumping to end ...")
  except:
   pass
 def VVu5XZ(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVI7Tx(self, isUp):
  if self.enableZapping:
   self.VVZBwg("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVgkdY()
   if self.portalTableParam:
    FF1Gz0(BF(self.VVgDA5, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self)
    if "/timeshift/" in decodedUrl:
     self.VVZBwg("Cannot Zap Catcup TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVQDGk()
 def VVQDGk(self):
  self.lastPlayPos = 0
  self.VVGags()
  self.VVtw8W()
 def VVgDA5(self, isUp):
  CCUfgv_inatance, VV57kA, mode = self.portalTableParam
  if isUp : VV57kA.VVT0U6()
  else : VV57kA.VVEMg9()
  colList = VV57kA.VVOvKg()
  if mode == "localIptv":
   chName, chUrl = CCUfgv_inatance.VVEu0H(VV57kA, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCUfgv_inatance.VVjvNH(VV57kA, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCUfgv_inatance.VVTWyZ(mode, VV57kA, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCUfgv_inatance.VV7V0H(mode, VV57kA, colList)
  else:
   self.VVZBwg("Cannot Zap")
   return
  FFTrMq(self, chUrl, VVz9ev=False)
  self.VVQDGk()
 def VVtw8W(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCVY8O.VVKYDg(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self)
   if not self.VVSd1b(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVZBwg("Refreshing Portal")
   FF1Gz0(self.VVbmcA)
  except:
   pass
 def VVbmcA(self):
  self.restoreLastPlayPos = self.VV8Yi1()
 def VVVCeX(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self)
  if not decodedUrl or FFHwNJ(decodedUrl):
   self.VVZBwg("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCUfgv.VVOsYy(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVZBwg("Reading Program List ...")
   ok_fnc = BF(self.VVTkEk, refCode, chName, streamId, uHost, uUser, uPass)
   FF1Gz0(BF(CCUfgv.VVJYAe, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVZBwg("Cannot process this channel")
 def VVTkEk(self, refCode, chName, streamId, uHost, uUser, uPass, VV57kA, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VV57kA.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVZBwg("Changing Program ...")
   FF1Gz0(BF(self.VVqGe2, chUrl))
  else:
   self.VVZBwg("Incorrect Timestamp !")
 def VVqGe2(self, chUrl):
   FFTrMq(self, chUrl, VVz9ev=False)
   self.lastPlayPos = 0
   self.VVGags()
 def VVzL2y(self, isAudio):
  try:
   VVjITu = InfoBar.instance
   if VVjITu:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVjITu)
    else  : self.session.open(SubtitleSelection, VVjITu)
  except:
   pass
class CCqZnf(Screen):
 def __init__(self, session, title="", VVbzEY="Continue?", VVoXTx=True, VV1oM4=False):
  self.skin, self.skinParam = FFi9TE(VVy8KX, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVbzEY = VVbzEY
  self.VV1oM4 = VV1oM4
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVoXTx : VVJtuN = [no , yes]
  else   : VVJtuN = [yes, no ]
  FFRqJR(self, title, VVJtuN=VVJtuN, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVlQQ7 ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVbzEY)
  if self.VV1oM4:
   self["myLabel"].instance.setHAlign(0)
  self.VVseay()
  FF7a1g(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFapvt(self["myMenu"])
  FFZtqU(self, self["myMenu"])
 def VVlQQ7(self):
  item = FF3aN3(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVseay(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CC37eN(Screen):
 def __init__(self, session, title="", VVJtuN=None, width=1000, height=0, OKBtnFnc=None, VVBLjB=None, VV6cmu=None, VVPpN9=None, VVjEiY=None, VVz4LU=False, VV1n4R=False):
  if height == 0: height = 850
  self.skin, self.skinParam = FFi9TE(VVavIl, width, height, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVJtuN   = VVJtuN
  self.OKBtnFnc   = OKBtnFnc
  self.VVBLjB   = VVBLjB
  self.VV6cmu  = VV6cmu
  self.VVPpN9  = VVPpN9
  self.VVjEiY   = VVjEiY
  self.VVz4LU  = VVz4LU
  self.VV1n4R  = VV1n4R
  FFRqJR(self, title, VVJtuN=VVJtuN)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVlQQ7          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVfIgp         ,
   "green"  : self.VVvFEW         ,
   "yellow" : self.VVYaNa         ,
   "blue"  : self.VVa11V         ,
   "pageUp" : self.VVwNyN       ,
   "chanUp" : self.VVwNyN       ,
   "pageDown" : self.VVEDmG        ,
   "chanDown" : self.VVEDmG
  }, -1)
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FF7a1g(self["myMenu"])
  FFvDVP(self)
  self.VVuo0z(self["keyRed"]  , self.VVBLjB )
  self.VVuo0z(self["keyGreen"] , self.VV6cmu )
  self.VVuo0z(self["keyYellow"] , self.VVPpN9 )
  self.VVuo0z(self["keyBlue"]  , self.VVjEiY )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFSrMl(self)
 def VVuo0z(self, btnObj, btnFnc):
  if btnFnc:
   FFINW5(btnObj, btnFnc[0])
 def VVlQQ7(self):
  item = FF3aN3(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVz4LU: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVfIgp(self)  : self.VVzE6H(self.VVBLjB)
 def VVvFEW(self) : self.VVzE6H(self.VV6cmu)
 def VVYaNa(self) : self.VVzE6H(self.VVPpN9)
 def VVa11V(self) : self.VVzE6H(self.VVjEiY)
 def VVzE6H(self, btnFnc):
  if btnFnc:
   item = FF3aN3(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VV1n4R:
    self.cancel()
 def VVd12k(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVJtuN = self["myMenu"].list
  VVJtuN.pop(ndx)
  if len(VVJtuN) > 0: self["myMenu"].setList(VVJtuN)
  else    : self.close()
 def VVG4iE(self, VVJtuN):
  if len(VVJtuN) > 0:
   newList = []
   for item in VVJtuN:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVigtQ(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVwNyN(self):
  self["myMenu"].moveToIndex(0)
 def VVEDmG(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCbz99(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VVdLtF=None, VVQQbo=None, VVGpzZ=None, VVYOiV=26, VVxbA6=False, VVW0bm=None, VVMg98=None, VV39uD=None, VVieK7=None, VVgDsk=None, VVS9I3=None, VVd5iM=None, VVOo99=None, VVqaLK=None, VVKO9Z=-1, VVBMOB=False, searchCol=0, VV5mP6=None, VVqjLk=None, VV2Y9A="#00dddddd", VVspm3="#11002233", VV5F0B="#00ff8833", VVANti="#11111111", VVxA4o="#0a555555", VVwE8v="#0affffff", VVVSpS="#11552200", VVus9Y="#0055ff55"):
  self.skin, self.skinParam = FFi9TE(VV3A9p, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFRqJR(self, title)
  self.header     = header
  self.VVdLtF     = VVdLtF
  self.totalCols    = len(VVdLtF[0])
  self.VVt7nK   = 0
  self.lastSortModeIsReverese = False
  self.VVxbA6   = VVxbA6
  self.VVHIXj   = 0.01
  self.VVTZUn   = 0.02
  self.VVORdr = 0.03
  self.VV1Xci  = 1
  self.VVGpzZ = VVGpzZ
  self.colWidthPixels   = []
  self.VVW0bm   = VVW0bm
  self.OKButtonObj   = None
  self.VVMg98   = VVMg98
  self.VV39uD   = VV39uD
  self.VVieK7   = VVieK7
  self.VVgDsk  = VVgDsk
  self.VVS9I3   = VVS9I3
  self.VVd5iM    = VVd5iM
  self.VVOo99   = VVOo99
  self.tableRefreshCB   = None
  self.VVqaLK  = VVqaLK
  self.VVKO9Z    = VVKO9Z
  self.VVBMOB   = VVBMOB
  self.searchCol    = searchCol
  self.VVQQbo    = VVQQbo
  self.keyPressed    = -1
  self.VVYOiV    = FFI6li(VVYOiV)
  self.VV2awD    = FFDISy(self.VVYOiV, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VV5mP6    = VV5mP6
  self.VVqjLk      = VVqjLk
  self.VV2Y9A    = FFBQBk(VV2Y9A)
  self.VVspm3    = FFBQBk(VVspm3)
  self.VV5F0B    = FFBQBk(VV5F0B)
  self.VVANti    = FFBQBk(VVANti)
  self.VVxA4o   = FFBQBk(VVxA4o)
  self.VVwE8v    = FFBQBk(VVwE8v)
  self.VVVSpS    = FFBQBk(VVVSpS)
  self.VVus9Y   = FFBQBk(VVus9Y)
  self.VVdcxd  = False
  self.selectedItems   = 0
  self.VV1WM9   = FFBQBk("#01fefe01")
  self.VVA5Gc   = FFBQBk("#11400040")
  self.VV7mdR  = self.VV1WM9
  self.VV6NHa  = self.VVANti
  if self.VVBMOB:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVfAHN  ,
   "red"   : self.VV1NQZ  ,
   "green"   : self.VVaTam ,
   "yellow"  : self.VV6EXb ,
   "blue"   : self.VVKBpY  ,
   "menu"   : self.VVH04M ,
   "info"   : self.VV9bsY  ,
   "cancel"  : self.VV4BQR  ,
   "up"   : self.VVEMg9    ,
   "down"   : self.VVT0U6  ,
   "left"   : self.VVU1Td   ,
   "right"   : self.VVQwuu  ,
   "pageUp"  : self.VV3uGP  ,
   "chanUp"  : self.VV3uGP  ,
   "pageDown"  : self.VVzwU8  ,
   "chanDown"  : self.VVzwU8
  }, -1)
  FFsWyR(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FFmyX2(self)
  try:
   self.VVzHxa()
  except Exception as err:
   FFc8qc(self, str(err))
   self.close(None)
 def VVzHxa(self):
  FFSrMl(self)
  if self.VV5mP6:
   FFLgZ9(self["myTitle"], self.VV5mP6)
  if self.VVqjLk:
   FFLgZ9(self["myBody"] , self.VVqjLk)
   FFLgZ9(self["myTableH"] , self.VVqjLk)
   FFLgZ9(self["myTable"] , self.VVqjLk)
   FFLgZ9(self["myBar"]  , self.VVqjLk)
  self.VVuo0z(self.VV39uD  , self["keyRed"])
  self.VVuo0z(self.VVieK7  , self["keyGreen"])
  self.VVuo0z(self.VVgDsk , self["keyYellow"])
  self.VVuo0z(self.VVS9I3  , self["keyBlue"])
  if self.VVW0bm:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVW0bm[0])
    FFLgZ9(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VV2awD)
  self["myTableH"].l.setFont(0, gFont(VVUA23, self.VVYOiV))
  self["myTable"].l.setItemHeight(self.VV2awD)
  self["myTable"].l.setFont(0, gFont(VVUA23, self.VVYOiV))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VV2awD)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VV2awD))
   self["myTable"].instance.resize(eSize(*(w, h - self.VV2awD)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VV2awD
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VV2awD * len(self.VVdLtF) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVGpzZ:
   self.VVGpzZ = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVGpzZ)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVQQbo:
   self.VVQQbo = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVQQbo
   self.VVQQbo = []
   for item in tmpList:
    self.VVQQbo.append(item | RT_VALIGN_CENTER)
  self.VVWg9X()
  if self.VVd5iM:
   self.VVd5iM(self)
 def VVuo0z(self, btnFnc, btn):
  if btnFnc : FFINW5(btn, btnFnc[0])
  else  : FFINW5(btn, "")
 def VVhnWM(self, waitTxt):
  FFItMF(self, self.VVWg9X, title=waitTxt)
 def VVWg9X(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVlh49(0, self.header, self.VVwE8v, self.VVVSpS, self.VVwE8v, self.VVVSpS, self.VVus9Y)])
   rows = []
   for c, row in enumerate(self.VVdLtF):
    rows.append(self.VVlh49(c, row, self.VV2Y9A, self.VVspm3, self.VV5F0B, self.VVANti, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVKO9Z > -1:
    self["myTable"].moveToIndex(self.VVKO9Z )
   self.VVovmZ()
   if self.VVBMOB:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VV2awD * len(self.VVdLtF)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVOo99:
    self.VVzE6H(self.VVOo99, None)
   if self.tableRefreshCB:
    self.VVzE6H(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFc8qc(self, str(err))
    self.close()
   except:
    pass
 def VVlh49(self, keyIndex, columns, VV2Y9A, VVspm3, VV5F0B, VVANti, VVus9Y):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVus9Y and ndx == self.VVt7nK : textColor = VVus9Y
   else           : textColor = VV2Y9A
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFBQBk(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVspm3 = c
    entry = span.group(3)
   if self.VVQQbo[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VV2awD)
           , font   = 0
           , flags   = self.VVQQbo[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVspm3
           , color_sel  = VV5F0B
           , backcolor_sel = VVANti
           , border_width = 1
           , border_color = self.VVxA4o
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VV9bsY(self):
  rowData = self.VVY8nx()
  if rowData:
   title, txt, colList = rowData
   if self.VVMg98:
    fnc  = self.VVMg98[1]
    params = self.VVMg98[2]
    fnc(self, title, txt, colList)
   else:
    FFPt7a(self, txt, title)
 def VVfAHN(self):
  if   self.VVdcxd : self.VVuROp(self.VVCvzs(), mode=2)
  elif self.VVW0bm  : self.VVzE6H(self.VVW0bm, None)
  else      : self.VV9bsY()
 def VV1NQZ(self) : self.VVzE6H(self.VV39uD , self["keyRed"])
 def VVaTam(self) : self.VVzE6H(self.VVieK7 , self["keyGreen"])
 def VV6EXb(self): self.VVzE6H(self.VVgDsk , self["keyYellow"])
 def VVKBpY(self) : self.VVzE6H(self.VVS9I3 , self["keyBlue"])
 def VVzE6H(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFlDiQ(self, buttonFnc[3])
    FF1Gz0(BF(self.VVHG6p, buttonFnc))
   else:
    self.VVHG6p(buttonFnc)
 def VVHG6p(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVY8nx()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVuROp(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VVdLtF[ndx]
   isSelected = row[1][9] == self.VV1WM9
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVlh49(ndx, item, self.VV2Y9A, self.VVspm3, self.VV5F0B, self.VVANti, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVlh49(ndx, item, self.VV1WM9, self.VVA5Gc, self.VV7mdR, self.VV6NHa, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVovmZ()
 def VVjT42(self):
  FFItMF(self, self.VVXoFF, title="Selecting all ...")
 def VVXoFF(self):
  self.VVK3X1(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VV1WM9
   if not isSelected:
    item = self.VVdLtF[ndx]
    newRow = self.VVlh49(ndx, item, self.VV1WM9, self.VVA5Gc, self.VV7mdR, self.VV6NHa, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVovmZ()
  self.VVIkzm()
 def VVMAg1(self):
  FFItMF(self, self.VVuB95, title="Unselecting all ...")
 def VVuB95(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VV1WM9:
    item = self.VVdLtF[ndx]
    newRow = self.VVlh49(ndx, item, self.VV2Y9A, self.VVspm3, self.VV5F0B, self.VVANti, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVovmZ()
  self.VVIkzm()
 def VVIkzm(self):
  self.hide()
  self.show()
 def VVY8nx(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVGpzZ[i] > 1 or self.VVGpzZ[i] == self.VVHIXj or self.VVGpzZ[i] == self.VVORdr:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VVdLtF))
   return rowNum, txt, colList
  else:
   return None
 def VV4BQR(self):
  if self.VVqaLK : self.VVqaLK(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVsZfG(self):
  return self["myTitle"].getText().strip()
 def VVHop3(self):
  return self.header
 def VVC6lz(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVfaYe(self, txt):
  FFlDiQ(self, txt)
 def VVAlHG(self, txt):
  FFlDiQ(self, txt, 1000)
 def VVDvRR(self):
  FFlDiQ(self)
 def VVoyIP(self, fnc):
  self["myTable"].onSelectionChanged.append(fnc)
 def VVDvsh(self):
  return len(self.VVdLtF)
 def VVKgbz(self): self["keyGreen"].show()
 def VVFPNq(self): self["keyGreen"].hide()
 def VVCvzs(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVlvlo(self):
  return len(self["myTable"].list)
 def VVK3X1(self, isOn):
  self.VVdcxd = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu"].hide()
   if self.VVS9I3: self["keyBlue"].hide()
   if self.VVW0bm and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVS9I3: self["keyBlue"].show()
   if self.VVW0bm and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVW0bm[0])
   self.VVMAg1()
  FFLgZ9(self["myTitle"], color)
  FFLgZ9(self["myBar"]  , color)
 def VVZ6Fh(self):
  return self.VVdcxd
 def VV400b(self):
  return self.selectedItems
 def VVwRuv(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VVovmZ()
 def VVZ2qE(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVovmZ()
 def VVal2A(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VVdLtF:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVxNTD(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVDvsh()
  txt += FFvvVG("Total Unique Items", VVyU04)
  for i in range(self.totalCols):
   if self.VVGpzZ[i - 1] > 1 or self.VVGpzZ[i - 1] == self.VVHIXj or self.VVGpzZ[i - 1] == self.VVORdr:
    name, tot = self.VVal2A(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFPt7a(self, txt)
 def VVIrRe(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVOvKg(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VV3aGD(self, newList, newTitle="", VVAkjgMsg=True, tableRefreshCB=None):
  if newList:
   self.VVdLtF = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   if self.VVxbA6 and self.VVt7nK == 0:
    self.VVdLtF = sorted(self.VVdLtF, key=lambda x: int(x[self.VVt7nK])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VVdLtF = sorted(self.VVdLtF, key=lambda x: x[self.VVt7nK].lower(), reverse=self.lastSortModeIsReverese)
   if VVAkjgMsg : self.VVhnWM("Refreshing ...")
   else   : self.VVWg9X()
   if newTitle:
    self.VVC6lz(newTitle)
  else:
   FFc8qc(self, "Cannot refresh list")
   self.cancel()
 def VVe4HT(self, data):
  ndx = self.VVCvzs()
  newRow = self.VVlh49(ndx, data, self.VV2Y9A, self.VVspm3, self.VV5F0B, self.VVANti, None)
  if newRow:
   self.VVdLtF[ndx] = data
   self["myTable"].list[ndx] = newRow
   self.VVovmZ()
   return True
  else:
   return False
 def VVYHYY(self, colNum, textToFind, VV5kIx=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVovmZ()
    break
  else:
   if VV5kIx:
    FFlDiQ(self, "Not found", 1000)
 def VVaOZN(self, colDict, VV5kIx=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVovmZ()
    return
  if VV5kIx:
   FFlDiQ(self, "Not found", 1000)
 def VVaOZN_partial(self, colDict, VV5kIx=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVovmZ()
    return
  if VV5kIx:
   FFlDiQ(self, "Not found", 1000)
 def VVWVgX(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVlTiC(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VV1WM9:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVe3Hb(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VV1WM9: return True
  else        : return False
 def VVRk4N(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVH04M(self):
  if not self["keyMenu"].getVisible() or self.VVBMOB:
   return
  VVJtuN = []
  VVJtuN.append(("Table Statistcis"             , "tableStat"  ))
  VVJtuN.append(VVImCt)
  VVJtuN.append((FF0IFC("Export Table to .html"     , VVyU04) , "VVMc8p" ))
  VVJtuN.append((FF0IFC("Export Table to .csv"     , VVyU04) , "VVfTxH" ))
  VVJtuN.append((FF0IFC("Export Table to .txt (Tab Separated)", VVyU04) , "VVQQDx" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVGpzZ[i] > 1 or self.VVGpzZ[i] == self.VVTZUn:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVJtuN.append(VVImCt)
   if tot == 1 : VVJtuN.append(("Sort", sList[0][1]))
   else  : VVJtuN += sList
  FF0km9(self, self.VVN9iB, VVJtuN=VVJtuN, title=self.VVsZfG())
 def VVN9iB(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVxNTD()
   elif item == "VVMc8p": FFItMF(self, self.VVMc8p, title=title)
   elif item == "VVfTxH" : FFItMF(self, self.VVfTxH , title=title)
   elif item == "VVQQDx" : FFItMF(self, self.VVQQDx , title=title)
   else:
    isReversed = False
    if self.VVt7nK == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVxbA6 and item == 0:
     self.VVdLtF = sorted(self.VVdLtF, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VVdLtF = sorted(self.VVdLtF, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVt7nK = item
    self.VVhnWM("Sorting ...")
 def VVEMg9(self):
  self["myTable"].up()
  self.VVovmZ()
 def VVT0U6(self):
  self["myTable"].down()
  self.VVovmZ()
 def VVU1Td(self):
  self["myTable"].pageUp()
  self.VVovmZ()
 def VVQwuu(self):
  self["myTable"].pageDown()
  self.VVovmZ()
 def VV3uGP(self):
  self["myTable"].moveToIndex(0)
  self.VVovmZ()
 def VVzwU8(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVovmZ()
 def VVRvKN(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVovmZ()
 def VVQQDx(self):
  expFile = self.VVQRSm() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVHv5J()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VVdLtF:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVGpzZ[ndx] > self.VV1Xci or self.VVGpzZ[ndx] == self.VVORdr:
      col = self.VV6Uvo(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVmhza(expFile)
 def VVfTxH(self):
  expFile = self.VVQRSm() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVHv5J()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VVdLtF:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVGpzZ[ndx] > self.VV1Xci or self.VVGpzZ[ndx] == self.VVORdr:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VV6Uvo(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVmhza(expFile)
 def VVMc8p(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVsZfG(), PLUGIN_NAME, VVH1FK)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVsZfG()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVHv5J()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVGpzZ:
   colgroup += '   <colgroup>'
   for w in self.VVGpzZ:
    if w > self.VV1Xci or w == self.VVORdr:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVQRSm() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VVdLtF:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVGpzZ[ndx] > self.VV1Xci or self.VVGpzZ[ndx] == self.VVORdr:
      col = self.VV6Uvo(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVmhza(expFile)
 def VVHv5J(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVGpzZ[ndx] > self.VV1Xci or self.VVGpzZ[ndx] == self.VVORdr:
     newRow.append(col.strip())
  return newRow
 def VV6Uvo(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFj0Hy(col)
 def VVQRSm(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVsZfG())
  fileName = fileName.replace("__", "_")
  path  = FFPG8X(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFSGFz()
  return expFile
 def VVmhza(self, expFile):
  FF9xND(self, "File exported to:\n\n%s" % expFile, title=self.VVsZfG())
 def VVovmZ(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCB5sW():
 def __init__(self, pixmapObj, picPath):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
 def VV2USr(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVHpak)
    except:
     self.picLoad.PictureData.get().append(self.VVHpak)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, "#2200002a"])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVHpak(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    self.pixmapObj.instance.setPixmap(ptr)
 def VV7vT2(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVxOsI(pixmapObj, path):
  cl = CCB5sW(pixmapObj, path)
  ok = cl.VV2USr()
  if ok: return cl
  else : return None
class CCDjKX(Screen):
 def __init__(self, session, title="", VVrVOq=None, showGrnMsg=""):
  self.skin, self.skinParam = FFi9TE(VVRLnl, 1400, 800, 30, 40, 20, "#22000060", "#2200002a", 30)
  if not title:
   title = os.path.basename(VVrVOq),
  self.session = session
  FFRqJR(self, title, addCloser=True)
  self["myPic"]  = Pixmap()
  self.VVrVOq = VVrVOq
  self.showGrnMsg  = showGrnMsg
  self.picViewer  = None
  self.onShown.append(self.VVDpWe)
  self.onClose.append(self.onExit)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  self.picViewer = CCB5sW.VVxOsI(self["myPic"], self.VVrVOq)
  if self.picViewer:
   if self.showGrnMsg:
    FFlDiQ(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFc8qc(self, "Cannot view picture file:\n\n%s" % self.VVrVOq)
   self.close()
 def onExit(self):
  if self.picViewer:
   self.picViewer.VV7vT2()
 @staticmethod
 def VV9Hrp(SELF, VVrVOq, title="", showGrnMsg=""):
  SELF.session.open(BF(CCDjKX, title=title, VVrVOq=VVrVOq, showGrnMsg=showGrnMsg))
class CCL50P(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFi9TE(VVtpeW, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 26, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFRqJR(self, title=self.Title)
  FFINW5(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Signal & Player Cotroller Hotkey"       , CFG.hotkey_signal    ))
  if VVkw26:
   lst.append(getConfigListEntry("EPG Translation Language"        , CFG.epgLanguage    ))
  if VV6ZSr:
   lst.append(getConfigListEntry("Force UTF-8 Encoding (only OpenVision Python-3.10.2+)" , CFG.forceUtf8Encoding   ))
  lst.append(getConfigListEntry(VVsYfD *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type"         , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Movie/Series Download Path"         , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(VVsYfD *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(VVsYfD *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB)"        , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons"            , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVs8ZA()
  self.onShown.append(self.VVDpWe)
 def VVs8ZA(self):
  kList = {
    "ok"  : self.VVlQQ7    ,
    "green"  : self.VVemqo   ,
    "menu"  : self.VVhGlY  ,
    "cancel" : self.VV19Yc  ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VVG9rJ, 0)
     kList["chanDown"] = BF(self["config"].VVG9rJ, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FFmyX2(self)
  FF7a1g(self["config"])
  FFvDVP(self, self["config"])
  FFSrMl(self)
 def VVlQQ7(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsMode   : self.VVYbni()
   elif item == CFG.MovieDownloadPath   : self.VVJDgI(item, self["config"].getCurrent()[0])
   elif item == CFG.PIconsPath    : self.VV6sEz(item)
   elif item == CFG.backupPath    : self.VV6sEz(item)
   elif item == CFG.packageOutputPath  : self.VV6sEz(item)
   elif item == CFG.downloadedPackagesPath : self.VV6sEz(item)
   elif item == CFG.exportedTablesPath  : self.VV6sEz(item)
   elif item == CFG.exportedPIconsPath  : self.VV6sEz(item)
 def VVJDgI(self, item, title):
  tot = CCUd13.VVbbtb()
  if tot : FFc8qc(self, "Cannot change while downloading.", title=title)
  else : self.VV6sEz(item)
 def VVYbni(self):
  VVJtuN = []
  VVJtuN.append(("Auto Find" , "auto"))
  VVJtuN.append(("Custom Path" , "cust"))
  FF0km9(self, self.VVZmWx, VVJtuN=VVJtuN, title="IPTV Hosts Files Path")
 def VVZmWx(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVmyfR)
   elif item == "cust":
    VVMDmE = self.VVPejg()
    if VVMDmE : self.VVvYvl(VVMDmE)
    else  : self.session.openWithCallback(self.VVLTYf, BF(CCg2YR, mode=CCg2YR.VVkqcx, VV48AQ="/"))
 def VVvYvl(self, VVMDmE):
  VVqaLK = self.VVCu4C
  VV39uD = ("Remove"  , self.VVkbRi , [])
  VVgDsk = ("Add "  , self.VVImpz, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VVQQbo  = (LEFT   , LEFT  )
  FFBL02(self, None, title="IPTV Hosts Search Paths", header=header, VVdLtF=VVMDmE, width=1200, height=700, VVQQbo=VVQQbo, VVGpzZ=widths, VVYOiV=26, VVqaLK=VVqaLK, VV39uD=VV39uD, VVgDsk=VVgDsk
    , VVqjLk="#11110000", VV5mP6="#11220000", VVspm3="#11110011", VV5F0B="#00ffff00", VVANti="#00223025", VVxA4o="#0a333333", VVVSpS="#0a400040")
 def VVCu4C(self, VV57kA):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VVbioR)
  VV57kA.cancel()
 def VVLTYf(self, path):
  if path:
   CFG.iptvHostsDirs.setValue(FFPG8X(path.strip()))
   self.VVZHx9()
   VVMDmE = self.VVPejg()
   if VVMDmE : self.VVvYvl(VVMDmE)
   else  : FFlDiQ(self, "Cannot add dir", 1500)
 def VVFHqv(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVmyfR:
   return []
  return lst
 def VVPejg(self):
  lst = self.VVFHqv()
  if lst:
   VVMDmE = []
   for Dir in lst:
    VVMDmE.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVMDmE.sort(key=lambda x: x[0].lower())
   return VVMDmE
  else:
   return []
 def VVImpz(self, VV57kA, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VValmv, VV57kA)
         , BF(CCg2YR, mode=CCg2YR.VVkqcx, VV48AQ=sDir))
 def VValmv(self, VV57kA, path):
  if path:
   path = FFPG8X(path.strip())
   if self.VVPcXS(VV57kA, path):
    FFlDiQ(VV57kA, "Already added", 1500)
   else:
    lst = self.VVFHqv()
    lst.append(path)
    CFG.iptvHostsDirs.setValue(",".join(lst))
    self.VVZHx9()
    VVMDmE = self.VVPejg()
    VV57kA.VV3aGD(VVMDmE, tableRefreshCB=BF(self.VVin24, path))
 def VVin24(self, path, VV57kA, title, txt, colList):
  self.VVPcXS(VV57kA, path)
 def VVPcXS(self, VV57kA, path):
  for ndx, row in enumerate(VV57kA.VVRk4N()):
   if row[0].strip() == path.strip():
    VV57kA.VVRvKN(ndx)
    return True
  return False
 def VVkbRi(self, VV57kA, title, txt, colList):
  path = colList[0]
  FFAIFY(self, BF(self.VVtpOQ, VV57kA), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VVtpOQ(self, VV57kA):
  row = VV57kA.VVOvKg()
  path, rem = row[0].strip(), row[1].strip()
  VVMDmE = []
  lst = []
  for ndx, row in enumerate(VV57kA.VVRk4N()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVMDmE.append((tPath, tRem))
  if len(VVMDmE) > 0:
   CFG.iptvHostsDirs.setValue(",".join(lst))
   self.VVZHx9()
   VV57kA.VV3aGD(VVMDmE)
   FFlDiQ(VV57kA, "Deleted", 1500)
  else:
   CFG.iptvHostsMode.setValue(VVmyfR)
   CFG.iptvHostsMode.save()
   CFG.iptvHostsDirs.setValue("")
   self.VVZHx9()
   VV57kA.cancel()
   FF1Gz0(BF(FFlDiQ, self, "Changed to Auto-Find", 1500))
 def VVZHx9(self):
  CFG.iptvHostsDirs.save()
  configfile.save()
 def VV6sEz(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VVkebV, configObj)
         , BF(CCg2YR, mode=CCg2YR.VVkqcx, VV48AQ=sDir))
 def VVkebV(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VV19Yc(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFAIFY(self, self.VVemqo, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVemqo(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVmML7()
  self.VVFjTf()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVFjTf(self):
  CCkHya.VVy5CU()
 def VVhGlY(self):
  VVJtuN = []
  VVJtuN.append(("Use Backup directory in all other paths"      , "VVQdJd"   ))
  VVJtuN.append(("Reset all to default (including File Manager bookmarks)"  , "VVo3K9"   ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Backup %s Settings" % PLUGIN_NAME        , "VVwEcs"  ))
  VVJtuN.append(("Restore %s Settings" % PLUGIN_NAME       , "VVZV78"  ))
  if fileExists(VVIlHj + VVkD8W):
   VVJtuN.append(VVImCt)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVJtuN.append(('%s Checking for Update' % txt1       , txt2     ))
   VVJtuN.append(("Reinstall %s" % PLUGIN_NAME        , "VV2LNR"  ))
   VVJtuN.append(("Update %s" % PLUGIN_NAME        , "VVwtdX"   ))
  FF0km9(self, self.VVndcV, VVJtuN=VVJtuN, title="Config. Options")
 def VVndcV(self, item=None):
  if item:
   if   item == "VVQdJd"  : FFAIFY(self, self.VVQdJd , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVo3K9"  : FFAIFY(self, self.VVo3K9, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCEMYn)
   elif item == "VVwEcs" : self.VVwEcs()
   elif item == "VVZV78" : FFItMF(self, self.VVZV78, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVlT6u(True)
   elif item == "disableChkUpdate" : self.VVlT6u(False)
   elif item == "VV2LNR" : FFItMF(self, self.VV2LNR , "Checking Server ...")
   elif item == "VVwtdX"  : FFItMF(self, self.VVwtdX  , "Checking Server ...")
 def VVwEcs(self):
  path = "%sajpanel_settings_%s" % (VVIlHj, FFSGFz())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FF9xND(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVZV78(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFOAMF("find / %s -iname '%s*' | grep %s" % (FFaoFr(1), name, name))
  if lines:
   lines.sort()
   VVJtuN = []
   for line in lines:
    VVJtuN.append((line, line))
   FF0km9(self, BF(self.VVnFVp, title), title=title, VVJtuN=VVJtuN, width=1200)
  else:
   FFc8qc(self, "No settings files found !", title=title)
 def VVnFVp(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFNoK6(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVmML7()
    FFg2lz()
   else:
    FFJJSt(SELF, path, title=title)
 def VVlT6u(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVQdJd(self):
  newPath = FFPG8X(VVIlHj)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVmML7()
 @staticmethod
 def VV4KAW():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVo3K9(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.EventsInfoMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.epgLanguage.setValue("off")
  CFG.forceUtf8Encoding.setValue(True)
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.autoResetFrozenIptvChan.setValue(True)
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.iptvHostsMode.setValue(VVmyfR)
  CFG.iptvHostsDirs.setValue("")
  CFG.MovieDownloadPath.setValue(CCUd13.VVXo1Q())
  CFG.PIconsPath.setValue(VVEF2M)
  CFG.backupPath.setValue(CCL50P.VV4KAW())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVmML7()
  self.close()
 def VVmML7(self):
  configfile.save()
  global VVIlHj
  VVIlHj = CFG.backupPath.getValue()
  FFvVDz()
 def VVwtdX(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VV7F3h(title)
  if webVer:
   FFAIFY(self, BF(FFItMF, self, BF(self.VVLH3T, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VV2LNR(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VV7F3h(title, True)
  if webVer:
   FFAIFY(self, BF(FFItMF, self, BF(self.VVLH3T, webVer, title, True)), "Install and Restart ?", title=title)
 def VVLH3T(self, webVer, title, isReinst=False):
  url = self.VV05Yk(self, title)
  if url:
   VVBkcb = FFMkdO() == "dpkg"
   if VVBkcb == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVBkcb else "ipk")
   path, err = FFWvl5(url + fName, fName, timeout=2)
   if path:
    if isReinst : cmd = FFxvW9(VVuITN, path)
    else  : cmd = FFxvW9(VVELFq, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFjX9J(self, cmd)
    else:
     FFa4IH(self, title=title)
   else:
    FFc8qc(self, err, title=title)
 def VV7F3h(self, title, anyVer=False):
  url = self.VV05Yk(self, title)
  if not url:
   return ""
  path, err = FFWvl5(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFc8qc(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFt4Zg(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFc8qc(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVH1FK.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFOAMF(cmd)
   if list and curVer == list[0]:
    return webVer
  FF9xND(self, FF0IFC("No update required.", VV9pCx) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VV05Yk(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVIlHj + VVkD8W
  if fileExists(path):
   span = iSearch(r"(http.+)", FFt4Zg(path), IGNORECASE)
   if span : url = FFPG8X(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFc8qc(SELF, err, title)
  return url
 @staticmethod
 def VVibJy(url):
  path, err = FFWvl5(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFt4Zg(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVH1FK.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFOAMF(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCEMYn(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFi9TE(VVu0m7, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVNyZj
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFRqJR(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVQfQB("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVQfQB("\c00888888", i) + sp + "GREY\n"
   txt += self.VVQfQB("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVQfQB("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVQfQB("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVQfQB("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVQfQB("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVQfQB("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVQfQB("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVQfQB("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVQfQB("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVQfQB("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVlQQ7 ,
   "green"   : self.VVlQQ7 ,
   "left"   : self.VV6YLz ,
   "right"   : self.VVI6vA ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  self.VVspW1()
 def VVlQQ7(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFAIFY(self, self.VVNOcb, "Change to : %s" % txt, title=self.Title)
 def VVNOcb(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVNyZj
  VVNyZj = self.cursorPos
  self.VVf20T()
  self.close()
 def VV6YLz(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVspW1()
 def VVI6vA(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVspW1()
 def VVspW1(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVQfQB(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVBx0G(color):
  if VV8mIi: return "\\" + color
  else    : return ""
 @staticmethod
 def VVf20T():
  global VVPBk2, VVkO2P, VV0wBB, VVyU04, VVX67O, VV5GFt, VV9pCx, VV8mIi, COLOR_CONS_BRIGHT_YELLOW, VVumHI, VVqImC, VVPgsh, VVmG5f
  VVmG5f   = CCEMYn.VVQfQB("\c00FFFFFF", VVNyZj)
  VVkO2P    = CCEMYn.VVQfQB("\c00888888", VVNyZj)
  VVPBk2  = CCEMYn.VVQfQB("\c005A5A5A", VVNyZj)
  VV5GFt    = CCEMYn.VVQfQB("\c00FF0000", VVNyZj)
  VV0wBB   = CCEMYn.VVQfQB("\c00FF5000", VVNyZj)
  VV8mIi   = CCEMYn.VVQfQB("\c00FFFF00", VVNyZj)
  COLOR_CONS_BRIGHT_YELLOW = CCEMYn.VVQfQB("\c00FFFFAA", VVNyZj)
  VV9pCx   = CCEMYn.VVQfQB("\c0000FF00", VVNyZj)
  VVX67O    = CCEMYn.VVQfQB("\c000066FF", VVNyZj)
  VVumHI    = CCEMYn.VVQfQB("\c0000FFFF", VVNyZj)
  VVqImC  = CCEMYn.VVQfQB("\c00DSFFFF", VVNyZj)  #
  VVPgsh   = CCEMYn.VVQfQB("\c00FA55E7", VVNyZj)
  VVyU04    = CCEMYn.VVQfQB("\c00FF8F5F", VVNyZj)
CCEMYn.VVf20T()
class CCEcg9(Screen):
 def __init__(self, session, path, VVBkcb):
  self.skin, self.skinParam = FFi9TE(VV8biG, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVDRRF   = path
  self.VV3Jnb   = ""
  self.VVcTyJ   = ""
  self.VVBkcb    = VVBkcb
  self.VVGPhn    = ""
  self.VVxu4K  = ""
  self.VVAoNt    = False
  self.VVPjI9  = False
  self.postInstAcion   = 0
  self.VV9ZQn  = "enigma2-plugin-extensions"
  self.VVs8OC  = "enigma2-plugin-systemplugins"
  self.VVt61V = "enigma2"
  self.VVaJCG  = 0
  self.VV2ebE  = 1
  self.VV3jFi  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVMHZL = "DEBIAN"
  else        : self.VVMHZL = "CONTROL"
  self.controlPath = self.Path + self.VVMHZL
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVBkcb:
   self.packageExt  = ".deb"
   self.VVspm3  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVspm3  = "#11001020"
  FFRqJR(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFINW5(self["keyRed"] , "Create")
  FFINW5(self["keyGreen"] , "Post Install")
  FFINW5(self["keyYellow"], "Installation Path")
  FFINW5(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVXpTz  ,
   "green"   : self.VVYIJo ,
   "yellow"  : self.VVhExB  ,
   "blue"   : self.VVDuRe  ,
   "cancel"  : self.VVkgLT
  }, -1)
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FFSrMl(self)
  if self.VVspm3:
   FFLgZ9(self["myBody"], self.VVspm3)
   FFLgZ9(self["myLabel"], self.VVspm3)
  self.VVzKwk(True)
  self.VVasgs(True)
 def VVasgs(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVUVdT()
  if isFirstTime:
   if   package.startswith(self.VV9ZQn) : self.VVDRRF = VVDwGq + self.VVGPhn + "/"
   elif package.startswith(self.VVs8OC) : self.VVDRRF = VVuZTi + self.VVGPhn + "/"
   else            : self.VVDRRF = self.Path
  if self.VVAoNt : myColor = VVyU04
  else    : myColor = VVmG5f
  txt  = ""
  txt += "Source Path\t: %s\n" % FF0IFC(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FF0IFC(self.VVDRRF, VV8mIi)
  if self.VVcTyJ : txt += "Package File\t: %s\n" % FF0IFC(self.VVcTyJ, VVkO2P)
  elif errTxt   : txt += "Warning\t: %s\n"  % FF0IFC("Check Control File fields : %s" % errTxt, VV0wBB)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FF0IFC("Restart GUI", VVyU04)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FF0IFC("Reboot Device", VVyU04)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FF0IFC("Post Install", VV9pCx), act)
  if not errTxt and VV0wBB in controlInfo:
   txt += "Warning\t: %s\n" % FF0IFC("Errors in control file may affect the result package.", VV0wBB)
  txt += "\nControl File\t: %s\n" % FF0IFC(self.controlFile, VVkO2P)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVYIJo(self):
  VVJtuN = []
  VVJtuN.append(("No Action"    , "noAction"  ))
  VVJtuN.append(("Restart GUI"    , "VVmwop"  ))
  VVJtuN.append(("Reboot Device"   , "rebootDev"  ))
  FF0km9(self, self.VVQ9sH, title="Package Installation Option (after completing installation)", VVJtuN=VVJtuN)
 def VVQ9sH(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVmwop"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVzKwk(False)
   self.VVasgs()
 def VVhExB(self):
  rootPath = FF0IFC("/%s/" % self.VVGPhn, VVPBk2)
  VVJtuN = []
  VVJtuN.append(("Current Path"        , "toCurrent"  ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Extension Path"       , "toExtensions" ))
  VVJtuN.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVJtuN.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FF0km9(self, self.VVXQwv, title="Installation Path", VVJtuN=VVJtuN)
 def VVXQwv(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVhqaE(FFmhI7(self.Path, True))
   elif item == "toExtensions"  : self.VVhqaE(VVDwGq)
   elif item == "toSystemPlugins" : self.VVhqaE(VVuZTi)
   elif item == "toRootPath"  : self.VVhqaE("/")
   elif item == "toRoot"   : self.VVhqaE("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVOiB6, BF(CCg2YR, mode=CCg2YR.VVkqcx, VV48AQ=VVIlHj))
 def VVOiB6(self, path):
  if len(path) > 0:
   self.VVhqaE(path)
 def VVhqaE(self, parent, withPackageName=True):
  if withPackageName : self.VVDRRF = parent + self.VVGPhn + "/"
  else    : self.VVDRRF = "/"
  mode = self.VVZ1Ka()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVfJE8(mode), self.controlFile))
  self.VVasgs()
 def VVDuRe(self):
  if fileExists(self.controlFile):
   lines = FFNoK6(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFBJqp(self, self.VVyNdG, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFc8qc(self, "Version not found or incorrectly set !")
  else:
   FFJJSt(self, self.controlFile)
 def VVyNdG(self, VVLK78):
  if VVLK78:
   version, color = self.VVo3Y5(VVLK78, False)
   if color == VVumHI:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVLK78, self.controlFile))
    self.VVasgs()
   else:
    FFc8qc(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVkgLT(self):
  if self.newControlPath:
   if self.VVAoNt:
    self.VVZzUj()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FF0IFC(self.newControlPath, VVkO2P)
    txt += FF0IFC("Do you want to keep these files ?", VV8mIi)
    FFAIFY(self, self.close, txt, callBack_No=self.VVZzUj, title="Create Package", VV1oM4=True)
  else:
   self.close()
 def VVZzUj(self):
  os.system(FFIwml("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVfJE8(self, mode):
  if   mode == self.VV2ebE : prefix = self.VV9ZQn
  elif mode == self.VV3jFi : prefix = self.VVs8OC
  else        : prefix = self.VVt61V
  return prefix + "-" + self.VVxu4K
 def VVZ1Ka(self):
  if   self.VVDRRF.startswith(VVDwGq) : return self.VV2ebE
  elif self.VVDRRF.startswith(VVuZTi) : return self.VV3jFi
  else            : return self.VVaJCG
 def VVzKwk(self, isFirstTime):
  self.VVGPhn   = os.path.basename(os.path.normpath(self.Path))
  self.VVGPhn   = "_".join(self.VVGPhn.split())
  self.VVxu4K = self.VVGPhn.lower()
  self.VVAoNt = self.VVxu4K == VVJV84.lower()
  if self.VVAoNt and self.VVxu4K.endswith("ajpan"):
   self.VVxu4K += "el"
  if self.VVAoNt : self.VV3Jnb = VVIlHj
  else    : self.VV3Jnb = CFG.packageOutputPath.getValue()
  self.VV3Jnb = FFPG8X(self.VV3Jnb)
  if not pathExists(self.controlPath):
   os.system(FFIwml("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVAoNt : t = PLUGIN_NAME
  else    : t = self.VVGPhn
  self.VVa03x(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVpPVM.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVAoNt : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVa03x(self.postrmFile, txt)
  if self.VVAoNt:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVH1FK)
   self.VVa03x(self.preinstFile, txt)
  else:
   self.VVa03x(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVGPhn)
  mode = self.VVZ1Ka()
  if isFirstTime and not mode == self.VVaJCG:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVsYfD
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVa03x(self.postinstFile, txt, VV2fBh=True)
  os.system(FFIwml("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVAoNt : version, descripton, maintainer = VVH1FK , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVGPhn , self.VVGPhn
   txt = ""
   txt += "Package: %s\n"  % self.VVfJE8(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVa03x(self, path, lines, VV2fBh=False):
  if not fileExists(path) or VV2fBh:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVUVdT(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFNoK6(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FF0IFC(line, VV0wBB)
     elif not line.startswith(" ")    : line = FF0IFC(line, VV0wBB)
     else          : line = FF0IFC(line, VVumHI)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVumHI
   else   : color = VV0wBB
   descr = FF0IFC(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VV0wBB
     elif line.startswith((" ", "\t")) : color = VV0wBB
     elif line.startswith("#")   : color = VVkO2P
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVo3Y5(val, True)
      elif key == "Version"  : version, color = self.VVo3Y5(val, False)
      elif key == "Maintainer" : maint  , color = val, VVumHI
      elif key == "Architecture" : arch  , color = val, VVumHI
      else:
       color = VVumHI
      if not key == "OE" and not key.istitle():
       color = VV0wBB
     else:
      color = VVyU04
     txt += FF0IFC(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVcTyJ = self.VV3Jnb + packageName
   self.VVPjI9 = True
   errTxt = ""
  else:
   self.VVcTyJ  = ""
   self.VVPjI9 = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVo3Y5(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVumHI
  else          : return val, VV0wBB
 def VVXpTz(self):
  if not self.VVPjI9:
   FFc8qc(self, "Please fix Control File errors first.")
   return
  if self.VVBkcb: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFmhI7(self.VVDRRF, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVGPhn
  symlinkTo  = FFbHHt(self.Path)
  dataDir   = self.VVDRRF.rstrip("/")
  removePorjDir = FFIwml("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFIwml("rm -f '%s'" % self.VVcTyJ) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFRopk()
  if self.VVBkcb:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFHvxv("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVAoNt:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVDRRF == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVMHZL)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVcTyJ, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVcTyJ
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVcTyJ, FFugQf(result  , VV9pCx))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVDRRF, FFugQf(instPath, VVumHI))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFugQf(failed, VV0wBB))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFjX9J(self, cmd)
class CCg2YR(Screen):
 VV9i9a   = 0
 VVkqcx  = 1
 VVF4l0 = 20
 VVXhWl  = None
 def __init__(self, session, VV48AQ="/", mode=VV9i9a, VVz9yq="Select", VVYOiV=30, gotoMovie=False):
  self.skin, self.skinParam = FFi9TE(VVavIl, 1400, 920, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFRqJR(self)
  FFINW5(self["keyRed"] , "Exit")
  FFINW5(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVz9yq = VVz9yq
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  CCg2YR.VVXhWl = self
  if   self.gotoMovie        : VVL4WQ, self.VV48AQ = True , CCg2YR.VV14bi(self)[1] or "/"
  elif self.mode == self.VV9i9a  : VVL4WQ, self.VV48AQ = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVkqcx : VVL4WQ, self.VV48AQ = False, VV48AQ
  else           : VVL4WQ, self.VV48AQ = True , VV48AQ
  self.VV48AQ = FFPG8X(self.VV48AQ)
  self["myMenu"] = CCwVVa(  directory   = "/"
         , VVL4WQ   = VVL4WQ
         , VV1ZgK = True
         , VVFOvk   = self.skinParam["width"]
         , VVYOiV   = self.skinParam["bodyFontSize"]
         , VV2awD  = self.skinParam["bodyLineH"]
         , VVvoj1  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVlQQ7      ,
   "red"    : self.VV2v9C     ,
   "green"    : self.VVTP7M    ,
   "yellow"   : self.VVD0ep   ,
   "blue"    : self.VVNBV2   ,
   "menu"    : self.VVKBkU    ,
   "info"    : self.VVGCJD    ,
   "cancel"   : self.VVFZSu     ,
   "pageUp"   : self.VVFZSu     ,
   "chanUp"   : self.VVFZSu
  }, -1)
  FFsWyR(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVeCd7)
 def onExit(self):
  CCg2YR.VVXhWl = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVeCd7)
  FFmyX2(self)
  FF7a1g(self["myMenu"], bg="#06003333")
  FFSrMl(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode == self.VVkqcx:
   FFINW5(self["keyGreen"], self.VVz9yq)
   color = "#22000022"
   FFLgZ9(self["myBody"], color)
   FFLgZ9(self["myMenu"], color)
   color = "#22220000"
   FFLgZ9(self["myTitle"], color)
   FFLgZ9(self["myBar"], color)
  self.VVeCd7()
  if self.VVAnoX(self.VV48AQ) > self.bigDirSize:
   FFlDiQ(self, "Changing directory...")
   FF1Gz0(self.VVSfik)
  else:
   self.VVSfik()
 def VVSfik(self):
  self["myMenu"].VVOTBD(self.VV48AQ)
  if self.gotoMovie:
   self.VVyC1r(chDir=False)
 def VVRvKN(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVHowm(self):
  self["myMenu"].refresh()
  FFBV8r()
 def VVAnoX(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VVlQQ7(self):
  if self["myMenu"].VVyCcH():
   path = self.VVt7cQ(self.VVnkBo())
   if self.VVAnoX(path) > self.bigDirSize:
    FFlDiQ(self, "Changing directory...")
    FF1Gz0(self.VVxWcK)
   else:
    self.VVxWcK()
  else:
   self.VVVNEQ()
 def VVxWcK(self):
  self["myMenu"].descent()
  self.VVeCd7()
 def VVFZSu(self):
  if self["myMenu"].VV5gBY():
   self["myMenu"].moveToIndex(0)
   self.VVxWcK()
 def VV2v9C(self):
  if not FFM8Du(self):
   self.close("")
 def VVTP7M(self):
  if self.mode == self.VVkqcx:
   path = self.VVt7cQ(self.VVnkBo())
   self.close(path)
 def VVGCJD(self):
  FFItMF(self, self.VVCjca, title="Calculating size ...")
 def VVCjca(self):
  path = self.VVt7cQ(self.VVnkBo())
  param = self.VVkSBy(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FF8oWX("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCg2YR.VVFDJw(path)
     freeSize = CCg2YR.VVQ9JD(path)
     size = totSize - freeSize
     totSize  = CCg2YR.VVBWem(totSize)
     freeSize = CCg2YR.VVBWem(freeSize)
    else:
     size = FF8oWX("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CCg2YR.VVBWem(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FF0IFC(pathTxt, VVyU04) + "\n"
   if slBroken : fileTime = self.VVov4H(path)
   else  : fileTime = self.VVIPSD(path)
   def VVzMl5(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVzMl5("Path"    , pathTxt)
   txt += VVzMl5("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVzMl5("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVzMl5("Total Size"   , "%s" % totSize)
    txt += VVzMl5("Used Size"   , "%s" % usedSize)
    txt += VVzMl5("Free Size"   , "%s" % freeSize)
   else:
    txt += VVzMl5("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVzMl5("Owner"    , owner)
   txt += VVzMl5("Group"    , group)
   txt += VVzMl5("Perm. (User)"  , permUser)
   txt += VVzMl5("Perm. (Group)"  , permGroup)
   txt += VVzMl5("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVzMl5("Perm. (Ext.)" , permExtra)
   txt += VVzMl5("iNode"    , iNode)
   txt += VVzMl5("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVsYfD, VVsYfD)
    txt += hLinkedFiles
   txt += self.VV4Mup(path)
  else:
   FFc8qc(self, "Cannot access information !")
  if len(txt) > 0:
   FFPt7a(self, txt)
 def VVkSBy(self, path):
  path = path.strip()
  path = FFbHHt(path)
  result = FF8oWX("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVa7Y0(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVa7Y0(perm, 1, 4)
   permGroup = VVa7Y0(perm, 4, 7)
   permOther = VVa7Y0(perm, 7, 10)
   permExtra = VVa7Y0(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFJoh0("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VV4Mup(self, path):
  txt  = ""
  res  = FF8oWX("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FF0IFC("File Attributes:", VVPgsh), txt)
  return txt
 def VVIPSD(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFjsXk(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFjsXk(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFjsXk(os.path.getctime(path))
  return txt
 def VVov4H(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FF8oWX("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FF8oWX("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FF8oWX("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVt7cQ(self, currentSel):
  currentDir  = self["myMenu"].VV5gBY()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVyCcH():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVnkBo(self):
  return self["myMenu"].getSelection()[0]
 def VVeCd7(self):
  FFlDiQ(self)
  path = self.VVt7cQ(self.VVnkBo())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VVdLtF = self.VV6gtc()
  if VVdLtF and len(VVdLtF) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VVg6u7(path)
  if self.mode == self.VV9i9a and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
 def VVg6u7(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVaQqv(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVKBkU(self):
  if self.mode == self.VV9i9a:
   path  = self.VVt7cQ(self.VVnkBo())
   isDir  = os.path.isdir(path)
   VVJtuN = []
   VVJtuN.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVWcJO(path):
     sepShown = True
     VVJtuN.append(VVImCt)
     VVJtuN.append( (VVyU04 + "Archiving / Packaging"      , "VVO8BR"  ))
    if self.VVTTYw(path):
     if not sepShown:
      VVJtuN.append(VVImCt)
     VVJtuN.append( (VVyU04 + "Read Backup information"     , "VVqA1t"  ))
     VVJtuN.append( (VVyU04 + "Compress Octagon Image (to zip File)"  , "VVV60N" ))
   elif os.path.isfile(path):
    selFile = self.VVnkBo()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar")) : VVJtuN.extend(self.VVM7mW(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVJtuN.extend(self.VVNDUM(True))
    elif selFile.endswith(".m3u")              : VVJtuN.extend(self.VVCIOq(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FFBLii(path):
     VVJtuN.append(VVImCt)
     VVJtuN.append((VVyU04 + "View"     , "textView_def" ))
     VVJtuN.append((VVyU04 + "View (Select Encoder)" , "textView_enc" ))
     VVJtuN.append((VVyU04 + "Edit"     , "text_Edit"  ))
    if len(txt) > 0:
     VVJtuN.append(VVImCt)
     VVJtuN.append(   (VVyU04 + txt      , "VVVNEQ"  ))
   VVJtuN.append(VVImCt)
   VVJtuN.append(     ("Create SymLink"       , "VVd1Gt" ))
   if not self.VVWcJO(path):
    VVJtuN.append(   ("Rename"          , "VVV3ob" ))
    VVJtuN.append(   ("Copy"           , "copyFileOrDir" ))
    VVJtuN.append(   ("Move"           , "moveFileOrDir" ))
    VVJtuN.append(   ("DELETE"          , "VVR4RO" ))
    if fileExists(path):
     VVJtuN.append(VVImCt)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVJtuN.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVJtuN.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVJtuN.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVJtuN.append(VVImCt)
   VVJtuN.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVJtuN.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCg2YR.VV14bi(self)
   if fPath:
    VVJtuN.append(VVImCt)
    VVJtuN.append(   (VV8mIi + "Go to current movie"  , "VVyC1r"))
   VVJtuN.append(VVImCt)
   VVJtuN.append(    ("Set current directory as \"Startup Path\"" , "VVKmtI" ))
   FF0km9(self, self.VV1faO, title="Options", VVJtuN=VVJtuN)
 def VV1faO(self, item=None):
  if self.mode == self.VV9i9a:
   if item is not None:
    path = self.VVt7cQ(self.VVnkBo())
    selFile = self.VVnkBo()
    if   item == "properties"    : self.VVGCJD()
    elif item == "VVO8BR"  : self.VVO8BR(path)
    elif item == "VVqA1t"  : self.VVqA1t(path)
    elif item == "VVV60N" : self.VVV60N(path)
    elif item.startswith("extract_")  : self.VVfJQI(path, selFile, item)
    elif item.startswith("script_")   : self.VVlmUF(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVPNeFItem_m3u(path, selFile, item)
    elif item.startswith("textView_def") : FFMnHX(self, path)
    elif item.startswith("textView_enc") : self.VVzmFF(path)
    elif item.startswith("text_Edit")  : FFItMF(self, BF(CCQnPl, self, path), title="Opening File ...")
    elif item == "chmod644"     : self.VVMyX6(path, selFile, "644")
    elif item == "chmod755"     : self.VVMyX6(path, selFile, "755")
    elif item == "chmod777"     : self.VVMyX6(path, selFile, "777")
    elif item == "VVd1Gt"   : self.VVd1Gt(path, selFile)
    elif item == "VVV3ob"   : self.VVV3ob(path, selFile)
    elif item == "copyFileOrDir"   : self.VV4hxr(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VV4hxr(path, selFile, True)
    elif item == "VVR4RO"   : self.VVR4RO(path, selFile)
    elif item == "createNewFile"   : self.VV2emb(path, True)
    elif item == "createNewDir"    : self.VV2emb(path, False)
    elif item == "VVyC1r"   : self.VVyC1r()
    elif item == "VVKmtI"   : self.VVKmtI(path)
    elif item == "VVVNEQ"    : self.VVVNEQ()
    else         : self.close()
 def VVVNEQ(self):
  selFile = self.VVnkBo()
  path  = self.VVt7cQ(selFile)
  if os.path.isfile(path):
   VVU7IO = []
   category = self["myMenu"].VVONxo(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VV60h2(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : CCDjKX.VV9Hrp(self, path)
   elif category == "txt"         : FFMnHX(self, path)
   elif category in ("tar", "zip", "rar")     : self.VVXero(path, selFile)
   elif category == "scr"         : self.VV0P9h(path, selFile)
   elif category == "m3u"         : self.VVZ84m(path, selFile)
   elif category in ("ipk", "deb")       : self.VVNm7A(path, selFile)
   elif category == "mus"         : self.VV80Di(self, path)
   elif category == "mov"         : self.VV80Di(self, path)
   elif not FFBLii(path)        : FFMnHX(self, path)
 def VVD0ep(self):
  path = self.VVt7cQ(self.VVnkBo())
  action = self.VVg6u7(path)
  if action == 1:
   self.VVIwz9(path)
   FFlDiQ(self, "Added", 500)
  elif action == -1:
   self.VVDdhh(path)
   FFlDiQ(self, "Removed", 500)
  self.VVg6u7(path)
 def VVIwz9(self, path):
  VVdLtF = self.VV6gtc()
  if not VVdLtF:
   VVdLtF = []
  if len(VVdLtF) >= self.VVF4l0:
   FFc8qc(SELF, "Max bookmarks reached (max=%d)." % self.VVF4l0)
  elif not path in VVdLtF:
   VVdLtF = [path] + VVdLtF
   self.VVPYOc(VVdLtF)
 def VVNBV2(self):
  VVdLtF = self.VV6gtc()
  if VVdLtF:
   newList = []
   for line in VVdLtF:
    newList.append((line, line))
   VVBLjB  = ("Delete"  , self.VVZWto )
   VVPpN9 = ("Move Up"   , self.VVbrPZ )
   VVjEiY  = ("Move Down" , self.VVpETF )
   self.bookmarkMenu = FF0km9(self, self.VVe4VY, title="Bookmarks", VVJtuN=newList, VVBLjB=VVBLjB, VVPpN9=VVPpN9, VVjEiY=VVjEiY)
 def VVZWto(self, VVnkBoObj, path):
  if self.bookmarkMenu:
   VVdLtF = self.VVDdhh(path)
   self.bookmarkMenu.VVG4iE(VVdLtF)
 def VVbrPZ(self, VVnkBoObj, path):
  if self.bookmarkMenu:
   VVdLtF = self.bookmarkMenu.VVigtQ(True)
   if VVdLtF:
    self.VVPYOc(VVdLtF)
 def VVpETF(self, VVnkBoObj, path):
  if self.bookmarkMenu:
   VVdLtF = self.bookmarkMenu.VVigtQ(False)
   if VVdLtF:
    self.VVPYOc(VVdLtF)
 def VVe4VY(self, folder=None):
  if folder:
   folder = FFPG8X(folder)
   self["myMenu"].VVOTBD(folder)
   self["myMenu"].moveToIndex(0)
  self.VVeCd7()
 def VV6gtc(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVaQqv(self, path):
  VVdLtF = self.VV6gtc()
  if VVdLtF and path in VVdLtF:
   return True
  else:
   return False
 def VVw2JA(self):
  if VV6gtc():
   return True
  else:
   return False
 def VVPYOc(self, VVdLtF):
  line = ",".join(VVdLtF)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVDdhh(self, path):
  VVdLtF = self.VV6gtc()
  if VVdLtF:
   while path in VVdLtF:
    VVdLtF.remove(path)
   self.VVPYOc(VVdLtF)
   return VVdLtF
 def VVyC1r(self, chDir=True):
  fPath, fDir, fName = CCg2YR.VV14bi(self)
  if fPath:
   if chDir:
    self["myMenu"].VVOTBD(fDir)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFlDiQ(self, "Not found", 1000)
 def VVKmtI(self, path):
  if not os.path.isdir(path):
   path = FFmhI7(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VV60h2(self, selFile, VVbzEY, command):
  FFAIFY(self, BF(FFjX9J, self, command, VVxGmB=self.VVHowm), "%s\n\n%s" % (VVbzEY, selFile))
 def VVM7mW(self, path, calledFromMenu):
  destPath = self.VVcjLT(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVJtuN = []
  if calledFromMenu:
   VVJtuN.append(VVImCt)
   color = VVyU04
  else:
   color = ""
  VVJtuN.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVJtuN.append(VVImCt)
  VVJtuN.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVJtuN.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVJtuN.append((color + "Extract Here"            , "extract_here"  ))
  if VVFrOP and path.endswith(".tar.gz"):
   VVJtuN.append(VVImCt)
   VVJtuN.append((color + 'Convert to ".ipk" Package' , "VVRsJd"  ))
   VVJtuN.append((color + 'Convert to ".deb" Package' , "VVRixx"  ))
  return VVJtuN
 def VVXero(self, path, selFile):
  FF0km9(self, BF(self.VVfJQI, path, selFile), title="Compressed File Options", VVJtuN=self.VVM7mW(path, False))
 def VVfJQI(self, path, selFile, item=None):
  if item is not None:
   parent  = FFmhI7(path, False)
   destPath = self.VVcjLT(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVsYfD
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFHvxv("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFHvxv("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVsYfD, VVsYfD)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFGZGa(self, cmd)
   elif path.endswith(".zip"):
    self.VVFUrf(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif path.endswith(".rar"):
    self.VVdsgR(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFIwml("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VV60h2(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VV60h2(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFmhI7(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VV60h2(selFile, "Extract Here ?"      , cmd)
   elif item == "VVRsJd" : self.VVRsJd(path)
   elif item == "VVRixx" : self.VVRixx(path)
 def VVcjLT(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVFUrf(self, item, path, parent, destPath, VVbzEY):
  FFAIFY(self, BF(self.VVDIWE, item, path, parent, destPath), VVbzEY)
 def VVDIWE(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVsYfD
  cmd  = FFHvxv("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFugQf(destPath, VV9pCx))
  cmd +=   sep
  cmd += "fi;"
  FF1gYG(self, cmd, VVxGmB=self.VVHowm)
 def VVdsgR(self, item, path, parent, destPath, VVbzEY):
  FFAIFY(self, BF(self.VVN98r, item, path, parent, destPath), VVbzEY)
 def VVN98r(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFPG8X(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVsYfD
  cmd  = FFHvxv("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFugQf(destPath, VV9pCx))
  cmd +=   sep
  cmd += "fi;"
  FF1gYG(self, cmd, VVxGmB=self.VVHowm)
 def VVNDUM(self, addSep=False):
  VVJtuN = []
  if addSep:
   VVJtuN.append(VVImCt)
  VVJtuN.append((VVyU04 + "View Script File"  , "script_View"  ))
  VVJtuN.append((VVyU04 + "Execute Script File" , "script_Execute" ))
  VVJtuN.append((VVyU04 + "Edit"     , "script_Edit" ))
  return VVJtuN
 def VV0P9h(self, path, selFile):
  FF0km9(self, BF(self.VVlmUF, path, selFile), title="Script File Options", VVJtuN=self.VVNDUM())
 def VVlmUF(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFMnHX(self, path)
   elif item == "script_Execute" : self.VV60h2(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCQnPl(self, path)
 def VVCIOq(self, addSep=False):
  VVJtuN = []
  if addSep:
   VVJtuN.append(VVImCt)
  VVJtuN.append((VVyU04 + "Browse IPTV Channels"  , "m3u_Browse" ))
  VVJtuN.append((VVyU04 + "Edit"      , "m3u_Edit" ))
  VVJtuN.append((VVyU04 + "View"      , "m3u_View" ))
  return VVJtuN
 def VVZ84m(self, path, selFile):
  FF0km9(self, BF(self.VVPNeFItem_m3u, path, selFile), title="M3U/M3U8 File Options", VVJtuN=self.VVCIOq())
 def VVPNeFItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFItMF(self, BF(self.session.open, CCUfgv, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCQnPl(self, path)
   elif item == "m3u_View"  : FFMnHX(self, path)
 def VVzmFF(self, path):
  if fileExists(path) : FFItMF(self, BF(CCkHya.VV8Gsw, self, path, BF(self.VVgVi3, path), defEnc=None), title="Loading Codecs ...", clearMsg=False)
  else    : FFJJSt(self, path)
 def VVgVi3(self, path, item=None):
  if item:
   FFMnHX(self, path, encLst=item)
 def VVMyX6(self, path, selFile, newChmod):
  FFAIFY(self, BF(self.VVO4Bi, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVO4Bi(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVPbWU)
  result = FF8oWX(cmd)
  if result == "Successful" : FF9xND(self, result)
  else      : FFc8qc(self, result)
 def VVd1Gt(self, path, selFile):
  parent = FFmhI7(path, False)
  self.session.openWithCallback(self.VVKqhq, BF(CCg2YR, mode=CCg2YR.VVkqcx, VV48AQ=parent, VVz9yq="Create Symlink here"))
 def VVKqhq(self, newPath):
  if len(newPath) > 0:
   target = self.VVt7cQ(self.VVnkBo())
   target = FFbHHt(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFPG8X(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFc8qc(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFAIFY(self, BF(self.VV9YXo, target, link), "Create Soft Link ?\n\n%s" % txt, VV1oM4=True)
 def VV9YXo(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVPbWU)
  result = FF8oWX(cmd)
  if result == "Successful" : FF9xND(self, result)
  else      : FFc8qc(self, result)
 def VVV3ob(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFBJqp(self, BF(self.VV7mVt, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VV7mVt(self, path, selFile, VVLK78):
  if VVLK78:
   parent = FFmhI7(path, True)
   if os.path.isdir(path):
    path = FFbHHt(path)
   newName = parent + VVLK78
   cmd = "mv '%s' '%s' %s" % (path, newName, VVPbWU)
   if VVLK78:
    if selFile != VVLK78:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFAIFY(self, BF(self.VV7LXG, cmd), message, title="Rename file?")
    else:
     FFc8qc(self, "Cannot use same name!", title="Rename")
 def VV7LXG(self, cmd):
  result = FF8oWX(cmd)
  if "Fail" in result:
   FFc8qc(self, result)
  self.VVHowm()
 def VV4hxr(self, path, selFile, isMove):
  if isMove : VVz9yq = "Move to here"
  else  : VVz9yq = "Copy to here"
  parent = FFmhI7(path, False)
  self.session.openWithCallback(BF(self.VVL1jQ, isMove, path, selFile)
         , BF(CCg2YR, mode=CCg2YR.VVkqcx, VV48AQ=parent, VVz9yq=VVz9yq))
 def VVL1jQ(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFbHHt(path)
   newPath = FFPG8X(newPath)
   dest = newPath + lastPart
   if os.path.isdir(path) and os.path.isdir(dest):
    if isMove:
     FFc8qc(self, 'Same directory already exists:\n\n%s\n\n( Try to copy then delete the source )' % dest)
     return
    else:
     dest = newPath
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFAIFY(self, BF(FFsu1t, self, cmd, VVxGmB=self.VVHowm), txt, VV1oM4=True)
   else:
    FFc8qc(self, "Cannot %s to same directory !" % action.lower())
 def VVR4RO(self, path, fileName):
  path = FFbHHt(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFAIFY(self, BF(self.VVAndV, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVAndV(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VVHowm()
 def VVWcJO(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVIGxe and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VV2emb(self, path, isFile):
  dirName = FFPG8X(os.path.dirname(path))
  if isFile : objName, VVLK78 = "File"  , self.edited_newFile
  else  : objName, VVLK78 = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFBJqp(self, BF(self.VVW3CY, dirName, isFile, title), title=title, defaultText=VVLK78, message="Enter %s Name:" % objName)
 def VVW3CY(self, dirName, isFile, title, VVLK78):
  if VVLK78:
   if isFile : self.edited_newFile = VVLK78
   else  : self.edited_newDir  = VVLK78
   path = dirName + VVLK78
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVPbWU)
    else  : cmd = "mkdir '%s' %s" % (path, VVPbWU)
    result = FF8oWX(cmd)
    if "Fail" in result:
     FFc8qc(self, result)
    self.VVHowm()
   else:
    FFc8qc(self, "Name already exists !\n\n%s" % path, title)
 def VVNm7A(self, path, selFile):
  VVJtuN = []
  VVJtuN.append(("List Package Files"          , "VVUqfa"     ))
  VVJtuN.append(("Package Information"          , "VVq9qA"     ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Install Package"           , "VVeupV_CheckVersion" ))
  VVJtuN.append(("Install Package (force reinstall)"      , "VVeupV_ForceReinstall" ))
  VVJtuN.append(("Install Package (force overwrite)"      , "VVeupV_ForceOverwrite" ))
  VVJtuN.append(("Install Package (force downgrade)"      , "VVeupV_ForceDowngrade" ))
  VVJtuN.append(("Install Package (ignore failed dependencies)"    , "VVeupV_IgnoreDepends" ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Remove Related Package"         , "VVVgE8_ExistingPackage" ))
  VVJtuN.append(("Remove Related Package (force remove)"     , "VVVgE8_ForceRemove"  ))
  VVJtuN.append(("Remove Related Package (ignore failed dependencies)"  , "VVVgE8_IgnoreDepends" ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Extract Files"           , "VV7omo"     ))
  VVJtuN.append(("Unbuild Package"           , "VVOmYi"     ))
  FF0km9(self, BF(self.VVHmDV, path, selFile), VVJtuN=VVJtuN)
 def VVHmDV(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVUqfa"      : self.VVUqfa(path, selFile)
   elif item == "VVq9qA"      : self.VVq9qA(path)
   elif item == "VVeupV_CheckVersion"  : self.VVeupV(path, selFile, VVKMZF     )
   elif item == "VVeupV_ForceReinstall" : self.VVeupV(path, selFile, VVuITN )
   elif item == "VVeupV_ForceOverwrite" : self.VVeupV(path, selFile, VVELFq )
   elif item == "VVeupV_ForceDowngrade" : self.VVeupV(path, selFile, VVgb0U )
   elif item == "VVeupV_IgnoreDepends" : self.VVeupV(path, selFile, VVsXhK )
   elif item == "VVVgE8_ExistingPackage" : self.VVVgE8(path, selFile, VV6aGr     )
   elif item == "VVVgE8_ForceRemove"  : self.VVVgE8(path, selFile, VVHK5M  )
   elif item == "VVVgE8_IgnoreDepends"  : self.VVVgE8(path, selFile, VVuLC7 )
   elif item == "VV7omo"     : self.VV7omo(path, selFile)
   elif item == "VVOmYi"     : self.VVOmYi(path, selFile)
   else           : self.close()
 def VVUqfa(self, path, selFile):
  if FF0sBI("ar") : cmd = "allOK='1';"
  else    : cmd  = FFRopk()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVsYfD, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVsYfD, VVsYfD)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFn50K(self, cmd, VVxGmB=self.VVHowm)
 def VV7omo(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFmhI7(path, True) + selFile[:-4]
  cmd  =  FFRopk()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFIwml("mkdir '%s'" % dest) + ";"
  cmd +=    FFIwml("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFugQf(dest, VV9pCx))
  cmd += "fi;"
  FFjX9J(self, cmd, VVxGmB=self.VVHowm)
 def VVOmYi(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVSHVP = os.path.splitext(path)[0]
  else        : VVSHVP = path + "_"
  if path.endswith(".deb")   : VVMHZL = "DEBIAN"
  else        : VVMHZL = "CONTROL"
  cmd  = FFRopk()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVSHVP, FFnQME())
  cmd += "  mkdir '%s';"    % VVSHVP
  cmd += "  CONTPATH='%s/%s';"  % (VVSHVP, VVMHZL)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVSHVP
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVSHVP, VVSHVP)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVSHVP
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVSHVP, VVSHVP)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVSHVP
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVSHVP
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVSHVP, FFugQf(VVSHVP, VV9pCx))
  cmd += "fi;"
  FFjX9J(self, cmd, VVxGmB=self.VVHowm)
 def VVq9qA(self, path):
  listCmd  = FFVZA6(VVWA2P, "")
  infoCmd  = FFxvW9(VVoEPD , "")
  filesCmd = FFxvW9(VVEHDi, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFWnKF(VV8mIi)
   notInst = "Package not installed."
   cmd  = FFnHBa("File Info", VV8mIi)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFnHBa("System Info", VV8mIi)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFugQf(notInst, VVyU04))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFnHBa("Related Files", VV8mIi)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFGZGa(self, cmd)
  else:
   FFa4IH(self)
 def VVeupV(self, path, selFile, cmdOpt):
  cmd = FFxvW9(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFAIFY(self, BF(FFjX9J, self, cmd, VVxGmB=FFBV8r), "Install Package ?\n\n%s" % selFile)
  else:
   FFa4IH(self)
 def VVVgE8(self, path, selFile, cmdOpt):
  listCmd  = FFVZA6(VVWA2P, "")
  infoCmd  = FFxvW9(VVoEPD, "")
  instRemCmd = FFxvW9(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFugQf(errTxt, VVyU04))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFugQf(cannotTxt, VVyU04))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFugQf(tryTxt, VVyU04))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFAIFY(self, BF(FFjX9J, self, cmd, VVxGmB=FFBV8r), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFa4IH(self)
 def VV1dZJ(self, path):
  hostName = FF8oWX("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVTTYw(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VV1dZJ(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVO8BR(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVJtuN = []
  VVJtuN.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVJtuN.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVJtuN.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVJtuN.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVJtuN.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVJtuN.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVJtuN.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVJtuN.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVJtuN.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVJtuN.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FF0km9(self, BF(self.VVxfwo, path), VVJtuN=VVJtuN)
 def VVxfwo(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVANjM(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVANjM(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVANjM(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVANjM(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVANjM(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVANjM(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVANjM(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVANjM(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVANjM(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVANjM(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVX5Yz(path, False)
   elif item == "convertDirToDeb"   : self.VVX5Yz(path, True)
   else         : self.close()
 def VVX5Yz(self, path, VVBkcb):
  self.session.openWithCallback(self.VVHowm, BF(CCEcg9, path=path, VVBkcb=VVBkcb))
 def VVANjM(self, path, fileExt, preserveDirStruct):
  parent  = FFmhI7(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFHvxv("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFHvxv("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFHvxv("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVsYfD
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFIwml("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FFugQf(resultFile, VV9pCx))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FFugQf(failed, VV0wBB))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFn50K(self, cmd, VVxGmB=self.VVHowm)
 def VVqA1t(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFMnHX(self, versionFile)
 def VVV60N(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VV1dZJ(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFc8qc(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFNoK6(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFmhI7(path, False)
  VVSHVP = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FFugQf(errCmd, VV0wBB))
  installCmd = FFxvW9(VVKMZF , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VVSHVP, VVSHVP)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VVSHVP
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VVSHVP
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VVSHVP, VVSHVP)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFjX9J(self, cmd, VVxGmB=self.VVHowm)
 def VVRsJd(self, path):
  FFc8qc(self, "Under Construction.")
 def VVRixx(self, path):
  FFc8qc(self, "Under Construction.")
 @staticmethod
 def VV80Di(SELF, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   SELF.session.open(CCVY8O, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VV14bi(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFPG8X(fDir), fName
  return "", "", ""
 @staticmethod
 def VVFDJw(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVQ9JD(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVBWem(size, mode=0):
  txt = CCg2YR.VVFsBp(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVFsBp(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
class CCwVVa(MenuList):
 def __init__(self, VV1ZgK=False, directory="/", VVtCV9=True, VVL4WQ=True, VVfflQ=True, VVrsN4=None, VVKB7G=False, VVD7Dy=False, VVrdOF=False, isTop=False, VVU7WB=None, VVFOvk=1000, VVYOiV=30, VV2awD=30, VVvoj1="#00000000"):
  MenuList.__init__(self, list, VV1ZgK, eListboxPythonMultiContent)
  self.VVtCV9  = VVtCV9
  self.VVL4WQ    = VVL4WQ
  self.VVfflQ  = VVfflQ
  self.VVrsN4  = VVrsN4
  self.VVKB7G   = VVKB7G
  self.VVD7Dy   = VVD7Dy or []
  self.VVrdOF   = VVrdOF or []
  self.isTop     = isTop
  self.additional_extensions = VVU7WB
  self.VVFOvk    = VVFOvk
  self.VVYOiV    = VVYOiV
  self.VV2awD    = VV2awD
  self.pngBGColor    = FFBQBk(VVvoj1)
  self.EXTENSIONS    = self.VVbngn()
  self.VV6kmz   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVUA23, self.VVYOiV))
  self.l.setItemHeight(self.VV2awD)
  self.png_mem   = self.VVkfZk("mem")
  self.png_usb   = self.VVkfZk("usb")
  self.png_fil   = self.VVkfZk("fil")
  self.png_dir   = self.VVkfZk("dir")
  self.png_dirup   = self.VVkfZk("dirup")
  self.png_srv   = self.VVkfZk("srv")
  self.png_slwfil   = self.VVkfZk("slwfil")
  self.png_slbfil   = self.VVkfZk("slbfil")
  self.png_slwdir   = self.VVkfZk("slwdir")
  self.VVyJna()
  self.VVOTBD(directory)
 def VVkfZk(self, category):
  return LoadPixmap("%s%s.png" % (VVAquH, category), getDesktop(0))
 def VVbngn(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "rar" : "rar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u" ,
   "m3u8" : "m3u"
  }
 def VVaZaT(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFbHHt(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FF0IFC(" -> " , VV8mIi) + FF0IFC(os.readlink(path), VV9pCx)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VV2awD + 10, 0, self.VVFOvk, self.VV2awD, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VV45da: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV2awD-4, self.VV2awD-4, png, self.pngBGColor, self.pngBGColor, VV45da))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV2awD-4, self.VV2awD-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVONxo(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVyJna(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVJMfM(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVEPBo(self, file):
  if os.path.realpath(file) == file:
   return self.VVJMfM(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVJMfM(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVJMfM(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVHaBB(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VV6kmz.info(l[0][0]).getEvent(l[0][0])
 def VVhd24(self):
  return self.list
 def VVHwdw(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVOTBD(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVfflQ:
    self.current_mountpoint = self.VVEPBo(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVfflQ:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVrdOF and not self.VVHwdw(path, self.VVD7Dy):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVaZaT(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVKB7G:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VV6kmz = eServiceCenter.getInstance()
   list = VV6kmz.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVtCV9 and not self.isTop:
   if directory == self.current_mountpoint and self.VVfflQ:
    self.list.append(self.VVaZaT(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVrdOF and self.VVJMfM(directory) in self.VVrdOF):
    self.list.append(self.VVaZaT(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVtCV9:
   for x in directories:
    if not (self.VVrdOF and self.VVJMfM(x) in self.VVrdOF) and not self.VVHwdw(x, self.VVD7Dy):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVaZaT(name = name, absolute = x, isDir = True, png = png))
  if self.VVL4WQ:
   for x in files:
    if self.VVKB7G:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FF0IFC(" -> " , VV8mIi) + FF0IFC(target, VV9pCx)
       else:
        png = self.png_slbfil
        name += FF0IFC(" -> " , VV8mIi) + FF0IFC(target, VV0wBB)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVONxo(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVAquH, category))
    if (self.VVrsN4 is None) or iCompile(self.VVrsN4).search(path):
     self.list.append(self.VVaZaT(name = name, absolute = x , isDir = False, png = png))
  if self.VVfflQ and len(self.list) == 0:
   self.list.append(self.VVaZaT(name = FF0IFC("No USB connected", VVkO2P), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VV5gBY(self):
  return self.current_directory
 def VVyCcH(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVOTBD(self.getSelection()[0], select = self.current_directory)
 def VVA8YK(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVW3CJ(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVpfrw)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVpfrw)
 def refresh(self):
  self.VVOTBD(self.current_directory, self.VVA8YK())
 def VVpfrw(self, action, device):
  self.VVyJna()
  if self.current_directory is None:
   self.refresh()
class CCPSxo(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FFi9TE(VV40Wa, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVdLtF   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVrs6b(defFG, "#00FFFFFF")
  self.defBG   = self.VVrs6b(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFRqJR(self, self.Title)
  self["keyRed"].show()
  FFINW5(self["keyGreen"] , "< > Transp.")
  FFINW5(self["keyYellow"], "Foreground")
  FFINW5(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV9OUW     ,
   "yellow"  : BF(self.VVZ5KO, False)  ,
   "blue"   : BF(self.VVZ5KO, True)  ,
   "up"   : self.VV9SfV       ,
   "down"   : self.VVz7mm      ,
   "left"   : self.VV6YLz      ,
   "right"   : self.VVI6vA      ,
   "last"   : BF(self.VVdVeX, -5) ,
   "next"   : BF(self.VVdVeX, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFLgZ9(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFLgZ9(self["keyRed"] , c)
  FFLgZ9(self["keyGreen"] , c)
  self.VV96Vp()
  self.VVfMLa()
  FFeqjP(self["myColorTst"], self.defFG)
  FFLgZ9(self["myColorTst"], self.defBG)
 def VVrs6b(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVfMLa(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VV3NZT(0, 0)
     return
 def VV9OUW(self):
  self.close(self.defFG, self.defBG)
 def VV9SfV(self): self.VV3NZT(-1, 0)
 def VVz7mm(self): self.VV3NZT(1, 0)
 def VV6YLz(self): self.VV3NZT(0, -1)
 def VVI6vA(self): self.VV3NZT(0, 1)
 def VV3NZT(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VV8HF3()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVkrOf()
 def VV96Vp(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVkrOf(self):
  color = self.VV8HF3()
  if self.isBgMode: FFLgZ9(self["myColorTst"], color)
  else   : FFeqjP(self["myColorTst"], color)
 def VVZ5KO(self, isBg):
  self.isBgMode = isBg
  self.VV96Vp()
  self.VVfMLa()
 def VVdVeX(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VV3NZT(0, 0)
 def VVhKi5(self):
  return hex(self.transp)[2:].zfill(2)
 def VV8HF3(self):
  return ("#%s%s" % (self.VVhKi5(), self.colors[self.curRow][self.curCol])).upper()
class CCVm2X(Screen):
 VVVuAB  = 0
 VVj3qa = 1
 def __init__(self, session, mode, endCallback):
  self.session  = session
  margin    = 50
  screenSize   = FFSAjK()
  w     = int(screenSize[0] - margin)
  h     = int(screenSize[1] / 2.0)
  self.skin, self.skinParam = FFi9TE(WINDOW_SUBTITLE, w, h, 35, 20, 30, "#ff000000", "#ff000000", 60, titleSep=False)
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.currentIndex  = -1
  self.subtitleMode  = mode
  self.defaultY   = 0
  self.endCallback  = endCallback
  FFRqJR(self)
  self["myTitle"].hide()
  self["mySubtFr"] = Label()
  self["mySubtFr"].hide()
  for i in range(3):
   self["mySubt%d" % i] = Label()
  self.onClose.append(self.VVag9x)
 def VVR4Y9(self, path=""):
  if path :
   self.VVFrQs()
   FFItMF(self, BF(self.VVGWwy, path), title="Checking file ...", clearMsg=False)
  else:
   self.VVGWwy()
 def VVGWwy(self, path=""):
  if path:
   subtList, err = self.VVd8wv(path)
   if err    : self.VVag9x(err)
   elif not subtList : self.VVag9x("Invalid srt file")
   else    :
    self.subtList = subtList
    self.VVkZMF()
  else:
   if self.VVRxHH():
    self.VVkZMF()
   elif self.subtitleMode == CCVm2X.VVj3qa:
    self.VVag9x("noResume")
   else:
    if self.VVMUS4(): self.VVkZMF()
    else         : self.VVag9x("noAutoSrt")
 def VVkZMF(self):
  CCVm2X.VVUaQM(None)
  FFlDiQ(self, "Subtitle started", 1000, isGrn=True)
  self.VVFrQs()
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVQuTI)
  except:
   self.timerUpdate.callback.append(self.VVQuTI)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVZ8Ni)
  except:
   self.timerEndText.callback.append(self.VVZ8Ni)
  self.VVzvx8(True)
 def VVag9x(self, res=""):
  self.timerUpdate.stop()
  self.timerEndText.stop()
  self.VVzvx8(False)
  self.endCallback(res)
 def VVzvx8(self, isAdd):
  lst = [CFG.subtDelaySec, CFG.subtBGTransp, CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextSize, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtShadowSize, CFG.subtVerticalPos]
  notifier = self.VVFrQs
  for item in lst:
   if isAdd:
    item.addNotifier(notifier, initial_call=False)
   else:
    try:
     item.removeNotifier(notifier)
    except:
     try:
      notifier in item.notifiers and item.notifiers.remove(notifier)
      notifier in item.notifiers_final and item.notifiers_final.remove(notifier)
     except:
      pass
 def VVRxHH(self):
  path = self.VVQG39()
  if path:
   if fileExists(path):
    lines = FFNoK6(path)
    srt = delay = enc = ""
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : srtPath = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay   = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc   = line.split("=")[1].strip()
    if srtPath and fileExists(srtPath):
     subtList, err = self.VVd8wv(srtPath, enc)
     if subtList:
      self.lastSubtEnc = enc
      self.subtList = subtList
      try:
       CFG.subtDelaySec.setValue(int(delay))
      except:
       pass
      return True
  return False
 def VVMUS4(self):
  bestSrt, bestRatio = CCVm2X.VVozpy(self)
  if bestSrt and bestRatio > 40:
   subtList, err = self.VVd8wv(bestSrt)
   if subtList:
    self.subtList = subtList
    return True
  return False
 def VVVDWN(self):
  VVJtuN = []
  if self.lastSubtFile:
   VVJtuN.append(("Settings"       , "setting" ))
   VVJtuN.append(("Change Subtitle File Encoding" , "enc"  ))
   VVJtuN.append(("Disable Current Subtitle"   , "disab" ))
   VVJtuN.append(VVImCt)
  VVJtuN.append(("Find all srt file"     , "findSrt" ))
  lst = CCVm2X.VVtgLt(self)
  if lst:
   VVJtuN.append(VVImCt)
   for item in lst:
    fName = os.path.basename(item)
    if self.lastSubtFile == item:
     fName = FF0IFC(fName, VV9pCx)
    VVJtuN.append((fName, item))
  OKBtnFnc = self.VV4kK6
  win = FF0km9(self, self.VV4kK6, VVJtuN=VVJtuN, width=600, title="Subtitle Options", OKBtnFnc=OKBtnFnc)
  win.instance.move(ePoint(40, 40))
 def VV4kK6(self, item=None):
  if item:
   menuInstance, txt, ref, ndx = item
   if ref == "setting":
    self["mySubtFr"].show()
    self.session.openWithCallback(self.VVy9b9, CC4LtG)
   elif ref == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile):
     FFItMF(menuInstance, BF(CCkHya.VV8Gsw, menuInstance, self.lastSubtFile, self.VVK0GA, defEnc=self.lastSubtEnc, pos=1), title="Loading Codecs ...", clearMsg=False)
    else:
     FFlDiQ(menuInstance, "SRT File error", 1000)
   elif ref == "disab":
    path = self.VVQG39()
    os.system(FFIwml("rm -f '%s'" % path))
    self.VVag9x("noErr")
   elif ref == "findSrt":
    CCVm2X.VV6VRe(self, self.VVsBLZ, defSrt=self.lastSubtFile, pos=1)
   else:
    self.VVsBLZ(ref)
 def VVy9b9(self, res):
  self["mySubtFr"].hide()
  if res:
   self.VVAN2a()
   self.VVFrQs()
 def VVFrQs(self, configElement=None):
  fnt = CFG.subtTextFont.getValue()
  if not fnt in FFHGPv():
   fnt = VVUA23
  lineH = 0
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFeqjP(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    inst.setHAlign(int(CFG.subtTextAlign.getValue()))
    bg = int(FFbZQf(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
    for i in range(3):
     FFLgZ9(self["mySubt%d" % i], "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    inst.setNoWrap(True)
    lineH = FFDISy(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    inst.move(ePoint(int(inst.position().x()), int(lineH * i + 1)))
  except:
   pass
  try:
   height = lineH * 3 + 2
   if not self.defaultY:
    self.defaultY = int(getDesktop(0).size().height() - height - self.skinParam["marginTop"])
   if lineH:
    self.instance.resize(eSize(*(int(self.instance.size().width()), height)))
   y = int(self.defaultY + CFG.subtVerticalPos.getValue())
   y = min(y, getDesktop(0).size().height() - height - 5)
   self.instance.move(ePoint(int(self.instance.position().x()), int(y)))
   inst = self["myInfoFrame"].instance
   inst.move(ePoint(int(inst.position().x()), 2))
   inst = self["myInfoBody"].instance
   inst.move(ePoint(int(inst.position().x()), 4))
  except:
   pass
 def VVsBLZ(self, path, enc=None):
  self.timerUpdate.stop()
  subtList, err = self.VVd8wv(path, enc)
  if err    : FFlDiQ(self, err, 2000)
  elif not subtList : FFlDiQ(self, "Invalid SRT file", 2000)
  else    :
   self.subtList  = subtList
   self.lastSubtInfo = ""
   self.lastSubtEnc = ""
   self.currentIndex = 0
   CFG.subtDelaySec.setValue(0)
   for i in range(3):
    FFeqjP(self["mySubt%d" % i], "#ffffff")
    self["mySubt%d" % i].setText("")
   FFlDiQ(self, "Subtitle started", 1000, isGrn=True)
  self.timerUpdate.start(500, False)
 def VVK0GA(self, item=None):
  if item:
   self.VVsBLZ(self.lastSubtFile, item)
 @staticmethod
 def VVtgLt(SELF):
  fPath, fDir, fName = CCg2YR.VV14bi(SELF)
  if pathExists(fDir):
   files = iGlob("%s*.srt" % fDir)
   if files:
    return files
  return []
 @staticmethod
 def VVozpy(SELF):
  bestSrt = ""
  bestRatio = 0
  fPath, fDir, fName = CCg2YR.VV14bi(SELF)
  if fName:
   movName = os.path.splitext(fName)[0].lower()
   files = CCVm2X.VVtgLt(SELF)
   for path in files:
    fName = os.path.basename(path)
    fName = os.path.splitext(fName)[0]
    ratio = CC2T9T.VVVHBT(movName.lower(), fName.lower())
    if ratio > bestRatio:
     bestRatio = ratio
     bestSrt = path
  return bestSrt, bestRatio
 def VVWHxy(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVd8wv(self, path, enc=None):
  if not fileExists(path):
   return [], "File not found"
  if (FFEZp1(path) > 1024 * 700):
   return [], "File too big"
  capNum = frmSec = toSec = bold = italic = under = 0
  color  = ""
  subtLines = []
  subtList = []
  capFound = False
  lines  = FFNoK6(path, encLst=enc if enc else None)
  for line in lines:
   line = line.strip()
   if line:
    if not capFound and line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVWHxy(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      subtLines.append((line.strip(), color, bold, italic, under))
   else:
    if (toSec - frmSec) > 0:
     subtList.append((capNum, frmSec, toSec, subtLines))
    capFound = False
    subtLines = []
    color = ""
    capNum = frmSec = toSec = bold = italic = under = 0
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVAN2a()
  return subtList, ""
 def VVAN2a(self):
  path = self.VVQG39()
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVQG39(self):
  fPath, fDir, fName = CCg2YR.VV14bi(self)
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFrHOu(self)
   if iptvRef: fPath = "/tmp/" + chName
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCSQQx.VVrqW4(self)
   if evName and evTime and evDur: fPath = "/tmp/" + evName
  if fPath: return fPath + ".ajp"
  else : return ""
 def VVQuTI(self):
  posVal = self.VV235b()
  self.VVQww8(posVal)
  if self.currentIndex == -2:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[self.currentIndex]
   if not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVZ8Ni()
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
     txtDur = int(toSec * 1000 - frmSec * 1000)
     if txtDur > 0:
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        line = line.replace(u"\u202A", "")
        line = line.replace(u"\u202B", "")
        line = line.replace(u"\u202C", "")
        line = str(line)
        if newColor:
         FFeqjP(self["mySubt%d" % ndx], newColor)
        self["mySubt%d" % ndx].setText(line)
        self["mySubt%d" % ndx].show()
        inst = self["mySubt%d" % ndx].instance
        w   = inst.calculateSize().width() + 50
        cntH = int((getDesktop(0).size().width() - w) / 2.0)
        inst.resize(eSize(*(w, inst.size().height())))
        inst.move(ePoint(cntH, int(inst.position().y())))
      self.timerEndText.start(txtDur, True)
 def VV235b(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCVY8O.VVKYDg(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCSQQx.VVrqW4(self)
   if evTime and evDur:
    posVal = iTime() - evTime
  return posVal
 def VVQww8(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     self.currentIndex = ndx
     return
  self.currentIndex = -2
 def VVZ8Ni(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFeqjP(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 @staticmethod
 def VV6VRe(SELF, cbFnc, defSrt="", pos=0):
  FFItMF(SELF, BF(CCVm2X.VVHPDy, SELF, cbFnc, defSrt, pos), title="Searching for srt files", clearMsg=False)
 @staticmethod
 def VVHPDy(SELF, cbFnc, defSrt="", pos=0):
  FFlDiQ(SELF)
  lines = FFOAMF('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFaoFr(1)))
  if lines:
   lines.sort()
   VVJtuN = []
   for item in lines:
    VVJtuN.append(((VV9pCx if defSrt == item else "") + item, item))
   VV6cmu = ("Show Full Path", CCVm2X.VVyqUF)
   win = FF0km9(SELF, BF(CCVm2X.VV9YVp, cbFnc), title="Subtitle Files", VVJtuN=VVJtuN, width=1200, height=500 if pos == 1 else 900, VV6cmu=VV6cmu)
   if pos == 1:
    win.instance.move(ePoint(40, 40))
  else:
   FFlDiQ(SELF, "No srt files found !", 2000)
 @staticmethod
 def VVyqUF(VVnkBoObj, path):
  FFPt7a(VVnkBoObj, path, title="Full Path")
 @staticmethod
 def VV9YVp(cbFnc, item):
  if item:
   cbFnc(item)
 @staticmethod
 def VV2hll():
  c = s = m = h = 0
  with open(VVIlHj + "AJPanel_test.srt", "w") as f:
   for i in range(1, 5401):
    s += 2
    if s >= 60:
     s = 0
     m += 1
     if m >= 60:
      m = 0
      h += 1
    if i < 6:
     txt  = '<font color="#ffff00">Created by AJPanel</font>\n'
     txt += '<font color="#00ffff">Testing Subtitle Files</font>\n'
     txt += '<font color="#00ff00">Line - %d</font>\n\n' % i
    else:
     txt = '<font color="#ffffbb">Subtitle Line - %d</font>\n\n' % i
    f.write("%d\n" % i)
    f.write("%02d:%02d:%02d,001 --> %02d:%02d:%02d,001\n" % (h, m, s, h, m, s+1))
    f.write(txt)
 @staticmethod
 def VVskqq():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVUaQM(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CCVm2X.VV2SEt()
 @staticmethod
 def VV2SEt():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CC4LtG(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFi9TE(VVtpeW, 700, 600, 40, 30, 10, "#11331010", "#11442020", 28, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "Subtitle Settings"
  FFRqJR(self, title=self.Title)
  FFINW5(self["keyRed"] , "Exit")
  FFINW5(self["keyGreen"] , "Save")
  FFINW5(self["keyYellow"], "Reset")
  self.confList = []
  self.confList.append(getConfigListEntry("Delay (current movie)"  , CFG.subtDelaySec  ))
  self.confList.append(getConfigListEntry(VVsYfD *2      ,       ))
  self.confList.append(getConfigListEntry("Background Transparency %" , CFG.subtBGTransp  ))
  self.confList.append(getConfigListEntry("Text Color"    , CFG.subtTextFg  ))
  self.confList.append(getConfigListEntry("Text Font"     , CFG.subtTextFont  ))
  self.confList.append(getConfigListEntry("Text Size"     , CFG.subtTextSize  ))
  self.confList.append(getConfigListEntry("Alignment"     , CFG.subtTextAlign  ))
  self.confList.append(getConfigListEntry("Shadow Color"    , CFG.subtShadowColor ))
  self.confList.append(getConfigListEntry("Shadow Size"    , CFG.subtShadowSize ))
  self.confList.append(getConfigListEntry(VVsYfD *2      ,       ))
  self.confList.append(getConfigListEntry("Vertical Pos"    , CFG.subtVerticalPos ))
  ConfigListScreen.__init__(self, self.confList, session)
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VV19Yc  ,
   "green"   : self.VVemqo   ,
   "yellow"  : self.VVseuu ,
   "menu"   : self.VV1aPd ,
   "cancel"  : self.VV19Yc
  }, -1)
  self.onShown.append(self.VVDpWe)
 def VVDpWe(self):
  self.onShown.remove(self.VVDpWe)
  FFmyX2(self)
  FF7a1g(self["config"])
  FFvDVP(self, self["config"])
  FFSrMl(self)
  self.instance.move(ePoint(40, 40))
 def VV1aPd(self):
  VVJtuN = []
  VVJtuN.append(("Reset Delay"    , "resetDel" ))
  VVJtuN.append(("Reset Subtitle Settings" , "resetAll" ))
  win = FF0km9(self, self.VVZhK6, VVJtuN=VVJtuN, title="Subtitle Settings Option", width=600)
  win.instance.move(ePoint(40, 40))
 def VVZhK6(self, item=None):
  if item:
   if   item == "resetDel"  : CFG.subtDelaySec.setValue(0)
   elif item == "resetAll"  : self.VVseuu()
 def VV19Yc(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFAIFY(self, self.VVemqo, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVemqo(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  configfile.save()
  self.close(True)
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close(False)
 def VVseuu(self):
  FFAIFY(self, self.VVo3K9, "Reset Subtitle Settings to default ?", title="Subtitle Settings")
 def VVo3K9(self):
  CFG.subtDelaySec.setValue(0)
  CFG.subtBGTransp.setValue(100)
  CFG.subtTextFg.setValue("srt")
  CFG.subtTextFont.setValue(VVUA23)
  CFG.subtTextSize.setValue(50)
  CFG.subtTextAlign.setValue("1")
  CFG.subtShadowColor.setValue("#000080")
  CFG.subtShadowSize.setValue(5)
  CFG.subtVerticalPos.setValue(0)
  self.VVemqo()
class CCvJ2g(ScrollLabel):
 def __init__(self, parentSELF, text="", VV0nDE=True):
  ScrollLabel.__init__(self, text)
  self.VV0nDE   = VV0nDE
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VV2y61  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVYOiV    = None
  self.parentW    = None
  self.parentH    = None
  self.firstTime    = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VVX1h2 ,
   "green"   : self.VVrgjU ,
   "yellow"  : self.VVIc3n ,
   "blue"   : self.VVLeE8 ,
   "up"   : self.pageUp   ,
   "down"   : self.pageDown   ,
   "left"   : self.pageUp   ,
   "right"   : self.pageDown   ,
   "last"   : BF(self.VVJ5DQ, 0) ,
   "0"    : BF(self.VVJ5DQ, 1) ,
   "next"   : BF(self.VVJ5DQ, 2) ,
   "pageUp"  : self.VV4JxN   ,
   "chanUp"  : self.VV4JxN   ,
   "pageDown"  : self.VVHFQx   ,
   "chanDown"  : self.VVHFQx
  }, -1)
 def VVfE6M(self, isResizable=True, VV5QWZ=False, textOutFile=""):
  self.textOutFile = textOutFile
  FFeqjP(self.parentSELF["keyRedTop"], "#0055FF55" if textOutFile else "#00FFFFFF" )
  FFLgZ9(self.parentSELF["keyRedTop"], "#113A5365")
  FFSrMl(self.parentSELF, True)
  self.isResizable = isResizable
  if VV5QWZ:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVYOiV  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFLgZ9(self, color)
 def FFLgZ9Color(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  lineheight  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  lines   = int(self.long_text.size().height() / lineheight)
  margin   = int(lineheight / 6)
  self.pageHeight = int(lines * lineheight)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  self.setText(self.message)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VV2y61 - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVmyP4()
 def pageUp(self):
  if self.VV2y61 > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VV2y61 > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VV4JxN(self):
  self.setPos(0)
 def VVHFQx(self):
  self.setPos(self.VV2y61-self.pageHeight)
 def VVYtJU(self):
  return self.VV2y61 <= self.pageHeight or self.curPos == self.VV2y61 - self.pageHeight
 def getText(self):
  return self.message
 def VVmyP4(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VV2y61, 3))
   start = int((100 - vis) * self.curPos / (self.VV2y61 - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VV0vZt=VVOM7o):
  old_VVYtJU = self.VVYtJU()
  self.message = str(text)
  if self.pageHeight:
   self.long_text.setText(self.message)
   self.VV2y61 = self.long_text.calculateSize().height()
   if self.VV0nDE and self.VV2y61 > self.pageHeight:
    self.scrollbar.show()
    self.VVmyP4()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VV2y61))
   if   VV0vZt == VVXjVQ: self.setPos(0)
   elif VV0vZt == VVhZGE : self.VVHFQx()
   elif old_VVYtJU    : self.VVHFQx()
   if self.firstTime and len(self.message) > 0:
    self.firstTime = False
    self.setText(self.message, VV0vZt=VV0vZt)
 def appendText(self, text, VV0vZt=VVhZGE):
  self.setText(self.message + str(text), VV0vZt=VV0vZt)
 def VVIc3n(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VV3EDR(size)
 def VVLeE8(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VV3EDR(size)
 def VVrgjU(self):
  self.VV3EDR(self.VVYOiV)
 def VV3EDR(self, VVYOiV):
  self.long_text.setFont(gFont(self.fontFamily, VVYOiV))
  self.setText(self.message, VV0vZt=VVOM7o)
  self.VVivUS(calledFromFontSizer=True)
 def VVJ5DQ(self, align):
  self.long_text.setHAlign(align)
 def VVX1h2(self):
  VVJtuN = []
  VVJtuN.append(("%s Wrapping" % ("Enable" if self.long_text.getNoWrap() else "Disable"), "wrap" ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Align Left"  , "left" ))
  VVJtuN.append(("Align Center"  , "center" ))
  VVJtuN.append(("Align Right"  , "right" ))
  if self.textOutFile:
   VVJtuN.append(VVImCt)
   VVJtuN.append((FF0IFC("Save to File", COLOR_CONS_BRIGHT_YELLOW), "save" ))
  VVJtuN.append(VVImCt)
  VVJtuN.append(("Keys (Shortcuts)" , "help" ))
  FF0km9(self.parentSELF, self.VV6wtX, VVJtuN=VVJtuN, title="Text Option", width=500)
 def VV6wtX(self, item=None):
  if item:
   if   item == "wrap"  : self.long_text.setNoWrap(not self.long_text.getNoWrap())
   elif item == "left"  : self.VVJ5DQ(0)
   elif item == "center" : self.VVJ5DQ(1)
   elif item == "right" : self.VVJ5DQ(2)
   elif item == "save"  : self.VVRfnc()
   elif item == "help"  : FFsJjT(self.parentSELF, VVAquH + "_help_txt", "Player Controller (Keys)")
 def VVRfnc(self):
  title = "%s Log File" % self.textOutFile.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FFPG8X(expPath), self.textOutFile, FFSGFz())
   with open(outF, "w") as f:
    f.write(FFj0Hy(self.message))
   FF9xND(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FFc8qc(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVivUS(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VV2y61 > 0 and self.pageHeight > 0:
   if self.VV2y61 < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VV2y61
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
