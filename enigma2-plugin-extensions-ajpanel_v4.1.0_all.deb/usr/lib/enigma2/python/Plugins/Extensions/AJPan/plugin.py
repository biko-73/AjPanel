import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigInteger, ConfigSubList
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVCmca   = "v4.1.0"
VVc3xP    = "17-02-2022"
EASY_MODE    = 0
VVHb92   = 0
VVo2cx   = 0
VVniGc  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVVbI9  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VV28Xc    = "/media/usb/"
VVqnEO    = "/usr/share/enigma2/picon/"
VVRcPg   = "/etc/enigma2/"
VVqypm  = "ajpanel_update_url"
VVKKIV   = "AJPan"
VVDYiT    = "AUTO FIND"
VV05kR    = ""
VVScB1    = "Regular"
VVVVdp      = "-" * 80
VVQP0R    = ("-" * 100, )
VVlddb    = ""
VVVFG3   = " && echo 'Successful' || echo 'Failed!'"
VVnITz    = []
VVRXzX  = "Cannot continue (No Enough Memory) !"
VVGrzI   = (None, "utf-8", "ISO8859-15", "ISO8859-7", "ISO8859-5", "ISO6937", "windows-1250", "windows-1252", "unicode_escape")
VV6ebU  = False
VVYe7k  = False
VVJHhL = False
VVdurn     = 0
VVbkAQ    = 1
VVkVBr    = 2
VVuG99   = 3
VVwVAl    = 4
VVpaEC    = 5
VVJcJi = 6
VVRHuj = 7
VVTT2a  = 8
VVwPKP   = 9
VVrzGb   = 10
VVR7Yu   = 11
VVsfmu  = 12
VVAO8R  = 13
VVCpbF    = 14
VVH8Wc   = 15
VVg91n   = 16
VVPlj3    = 17
VVe2F2  = 18
VViwcG  = 15
VVbDZJ   = 0
VVqUZV   = 1
VV0v5h   = 2
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices = [ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices = [ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices = [ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices = [ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=False)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsPath    = ConfigDirectory(default=VVDYiT, visible_width=51)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=51)
CFG.PIconsPath     = ConfigDirectory(default=VVqnEO, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VV28Xc, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
def FFOGjf():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVhmBe  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVUj2s = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVhmBe  : return 0
  elif VVUj2s : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVmQyS = FFOGjf()
VV0ESq = VV6AHZ = VVhgxA = VVKSBp = VVVBxF = VVqcuH = VVOn4X = VVHuTi = COLOR_CONS_BRIGHT_YELLOW = VVj8eg = VVUDe3 = VVWdSD = VVMNP0 = ""
def FF1ba8()  : return FFTj2R()
def FFUBQ1(*args) : FFSO0h(True , *args)
def FFWnE7(*args): FFSO0h(False, *args)
def FFSO0h(addSep=True, *args):
 if VVHb92:
  txt  = (">>>> %s\n" % VVVVdp) if addSep else ""
  txt += ">>>> %s" % " , ".join(map(str, args))
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFA7py(txt, isAppend=True, ignoreErr=False):
 if VVHb92:
  tm = FFxnvp()
  err = ""
  if not ignoreErr:
   err = FFTj2R()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFUBQ1(err)
  FFUBQ1("Output Log File : %s" % fileName)
def FFTj2R():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFxnvp()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except Exception as e:
  return "Cannot Trace !"
VVnITz = []
def FFGbn6(win):
 global VVnITz
 if not win in VVnITz:
  VVnITz.append(win)
def FF0lEm(*args):
 global VVnITz
 for win in VVnITz:
  try:
   win.close()
  except:
   pass
 VVnITz = []
def FFEW2B():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVql7p = FFEW2B()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFeEy7()     : return PluginDescriptor(fnc=FFN1vA, where=[PluginDescriptor.WHERE_SESSIONSTART] , needsRestart=True   , description="AJPanel Startup")
def FFlXrU()      : return getDescriptor(FFvkDa   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFxolP()       : return getDescriptor(FFrzOd  , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFrCER()   : return getDescriptor(FF6kN4 , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFjlzR(): return getDescriptor(FFBeyQ , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player"  , descr="Signal Monitor / Player")
def FFTlvD()  : return getDescriptor(FFA7UQ  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV"     , descr="IPTV Menu")
def FF1g16()     : return getDescriptor(FFC7mq , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info."    , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFlXrU() , FFxolP() , FFeEy7() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFrCER())
  result.append(FFjlzR())
  result.append(FFTlvD())
 if CFG.EventsInfoMenu.getValue():
  result.append(FF1g16())
 return result
def FFN1vA(reason, **kwargs):
 if reason == 0:
  FF1iFX()
  if "session" in kwargs:
   session = kwargs["session"]
   FF0J1D(session)
   CCGPmc(session)
def FFrzOd(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFvkDa, PLUGIN_NAME, 45)]
 else:
  return []
def FFvkDa(session, **kwargs):
 session.open(Main_Menu)
def FF6kN4(session, **kwargs):
 session.open(CCt0KP)
def FFBeyQ(session, **kwargs):
 FFTcUC(session, isFromSession=True)
def FFA7UQ(session, **kwargs):
 session.open(CCvDyD)
def FFC7mq(session, **kwargs):
 session.open(CCazlH, fncMode=CCazlH.VVNRD9)
def FFF71p():
 FFNCV7(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFrCER(), FFjlzR(), FFTlvD() ])
 FFNCV7(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FF1g16() ])
def FFNCV7(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VVNNwQ = None
def FF1iFX():
 try:
  global VVNNwQ
  if VVNNwQ is None:
   VVNNwQ    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFqoEA
  ChannelContextMenu.FF4wlk = FF4wlk
 except:
  pass
def FFqoEA(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVNNwQ(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FF4wlk, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FF4wlk, title1, csel, isFind=True))))
def FF4wlk(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFRWNl(refCode)
 except:
  pass
 self.session.open(boundFunction(CCpBza, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FF0J1D(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FFxa3y, session, "lok")
 hk.actions['longCancel'] = boundFunction(FFxa3y, session, "lesc")
 hk.actions['longRed']  = boundFunction(FFxa3y, session, "lred")
def FFxa3y(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFTcUC(session, isFromSession=True)
def FF4gq5(SELF, title="", addLabel=False, addScrollLabel=False, VVVLxj=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFST5G()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CC22AG(SELF)
 if VVVLxj:
  SELF["myMenu"] = MenuList(VVVLxj)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VV13Bz        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFC67T(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FFh7kj, SELF, "0") ,
  "1"    : boundFunction(FFh7kj, SELF, "1") ,
  "2"    : boundFunction(FFh7kj, SELF, "2") ,
  "3"    : boundFunction(FFh7kj, SELF, "3") ,
  "4"    : boundFunction(FFh7kj, SELF, "4") ,
  "5"    : boundFunction(FFh7kj, SELF, "5") ,
  "6"    : boundFunction(FFh7kj, SELF, "6") ,
  "7"    : boundFunction(FFh7kj, SELF, "7") ,
  "8"    : boundFunction(FFh7kj, SELF, "8") ,
  "9"    : boundFunction(FFh7kj, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FFcFyh, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFh7kj(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVMNP0:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVMNP0 + SELF.keyPressed + VV6AHZ)
    txt = VV6AHZ + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFlf8A(SELF, txt)
def FFcFyh(SELF, tableObj, colNum):
 FFlf8A(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     SELF.VVlvF6(i)
     break
 except:
  pass
def FFCJux(SELF, setMenuAction=True):
 if setMenuAction:
  global VVlddb
  VVlddb = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFST5G():
 return ("  %s" % VVlddb)
def FFoPjD(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FF9jRB(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFtJYq(color):
 return parseColor(color).argb()
def FFhU57(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFXT3k(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFcIX7(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFFHM5(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVMNP0)
 else:
  return ""
def FFSH61(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVVVdp, word, VVVVdp, VVMNP0)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVVVdp, word, VVVVdp)
def FFejnb(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVMNP0
def FFM12k(color):
 if color: return "echo -e '%s' %s;" % (VVVVdp, FFFHM5(VVVVdp, VVHuTi))
 else : return "echo -e '%s';" % VVVVdp
def FFic6i(title, color):
 title = "%s\n%s\n%s\n" % (VVVVdp, title, VVVVdp)
 return FFejnb(title, color)
def FFRtL9(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFJ0hY(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFiJN6(callBackFunction):
 tCons = CCsmtD()
 tCons.ePopen("echo", boundFunction(FFw7o1, callBackFunction))
def FFw7o1(callBackFunction, result, retval):
 callBackFunction()
def FF6Ue4(SELF, fnc, title="Processing ...", clearMsg=True):
 FFlf8A(SELF, title)
 tCons = CCsmtD()
 tCons.ePopen("echo", boundFunction(FFWzNA, SELF, fnc, clearMsg))
def FFWzNA(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFlf8A(SELF)
def FFuq8j(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVRXzX
  else       : return ""
def FFstFz(cmd):
 txt = FFuq8j(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFdBZy(cmd):
 lines = FFstFz(cmd)
 if lines: return lines[0]
 else : return ""
def FFHLTb(SELF, cmd):
 lines = FFstFz(cmd)
 VV5tha = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VV5tha.append((key, val))
  elif line:
   VV5tha.append((line, ""))
 if VV5tha:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFoSxq(SELF, None, header=header, VVprx2=VV5tha, VVADeP=widths, VVKTEW=28)
 else:
  FFtCAF(SELF, cmd)
def FFtCAF(    SELF, cmd, **kwargs): SELF.session.open(CCJsEA, VVsr3H=cmd, VVQNIQ=True, VVaC8s=VVqUZV, **kwargs)
def FFcuYL(  SELF, cmd, **kwargs): SELF.session.open(CCJsEA, VVsr3H=cmd, **kwargs)
def FFzH9C(   SELF, cmd, **kwargs): SELF.session.open(CCJsEA, VVsr3H=cmd, VVgxgF=True, VVnx8l=True, VVaC8s=VVqUZV, **kwargs)
def FFp6Bw(  SELF, cmd, **kwargs): SELF.session.open(CCJsEA, VVsr3H=cmd, VVgxgF=True, VVnx8l=True, VVaC8s=VV0v5h, **kwargs)
def FFyzyQ(  SELF, cmd, **kwargs): SELF.session.open(CCJsEA, VVsr3H=cmd, VVOgd3=True , **kwargs)
def FFmpav( SELF, cmd, **kwargs): SELF.session.open(CCJsEA, VVsr3H=cmd, VVCC07=True   , **kwargs)
def FF7rMy( SELF, cmd, **kwargs): SELF.session.open(CCJsEA, VVsr3H=cmd, VVY5OA=True  , **kwargs)
def FFnz2p(cmd):
 return cmd + " > /dev/null 2>&1"
def FFtHUh():
 return " > /dev/null 2>&1"
def FFJOWP(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFpWOv(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFHjh8():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFdBZy(cmd)
VVG8HC     = 0
VVU1lA      = 1
VVcBD8   = 2
VVsFnD      = 3
VVGWxm      = 4
VVM2ju     = 5
VVH8bp     = 6
VVcW3p = 7
VVZZd5 = 8
VVMYqO = 9
VVdufl  = 10
VVW7Es     = 11
VVBvxk  = 12
VV6BU1  = 13
def FF6GOT(parmNum, grepTxt):
 if   parmNum == VVG8HC  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVU1lA   : param = ["list"   , "apt list" ]
 elif parmNum == VVcBD8: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFHjh8()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFvshm(parmNum, package):
 if   parmNum == VVsFnD      : param = ["info"      , "apt show"         ]
 elif parmNum == VVGWxm      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVM2ju     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVH8bp     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVcW3p : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVZZd5 : param = ["install --force-overwrite" , "dpkg -i --force-overwrite -y"    ]
 elif parmNum == VVMYqO : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVdufl  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVW7Es     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVBvxk  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VV6BU1  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFHjh8()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFdtOa():
 result = FFdBZy("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFvshm(VVH8bp , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFnz2p("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFnz2p("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFFHM5(failed1, VVHuTi))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFFHM5(failed2, VVHuTi))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFFHM5(failed3, VVhgxA))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFrytY(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFvshm(VVH8bp , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFnz2p("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFFHM5(failed1, VVHuTi))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFFHM5(failed2, VVhgxA))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFtswK(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFnz2p('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFnz2p("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFb1Rx(path, maxSize=-1):
 txt = ""
 for enc in VVGrzI:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FF3tpP(path, keepends=False, maxSize=-1):
 lines = FFb1Rx(path, maxSize)
 return lines.splitlines(keepends)
def FFM8So(SELF, path):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFS6ZV(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FF3tpP(path, maxSize=maxSize)
  if lines: FFItCL(SELF, lines, title=title, VVaC8s=VVqUZV)
  else : FFAqRk(SELF, path, title=title)
 else:
  FFPX6L(SELF, path, title)
def FFRzLG(SELF, path, title):
 if fileExists(path):
  txt = FFb1Rx(path)
  txt = txt.replace("#W#", VVMNP0)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VV6AHZ)
  txt = txt.replace("#C#", VVj8eg)
  txt = txt.replace("#P#", VVKSBp)
  FFItCL(SELF, txt, title=title)
 else:
  FFPX6L(SELF, path, title)
def FFoqLf(path, SELF=None):
 txt = ""
 for enc in VVGrzI:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     pass
   return enc
  except:
   pass
 if SELF:
  FFsqiC(SELF, "Cannot detect file encoding for:\n\n%s" % path)
 return -1
def FFbOjF(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FFeDaV(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFdafY(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFSw9u(parent)
 else    : return FFPM3Z(parent)
def FFS6ZV(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFSw9u(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFPM3Z(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFb0l6():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVniGc)
 paths.append(VVniGc.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFeDaV(ba)
 for p in list:
  p = ba + p + VVniGc
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVKKIV, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVniGc, VVKKIV , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVDrFQ, VVMPsf = FFb0l6()
def FFqwad():
 def VV7k2Y(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 iPath = CFG.iptvHostsPath.getValue()
 if not iPath == VVDYiT and not pathExists(iPath):
  CFG.iptvHostsPath.setValue(VVDYiT)
  CFG.iptvHostsPath.save()
  oldIptvHostsPath = VVDYiT
 else:
  oldIptvHostsPath = ""
 oldMovieDownloadPath = VV7k2Y(CFG.MovieDownloadPath, CC5fZh.VVaDhR())
 VVSq9G   = VV7k2Y(CFG.backupPath, CCRbRI.VVg4NP())
 VVv8cL   = VV7k2Y(CFG.downloadedPackagesPath, t)
 VV088V  = VV7k2Y(CFG.exportedTablesPath, t)
 VVtZut  = VV7k2Y(CFG.exportedPIconsPath, t)
 VV1GkZ   = VV7k2Y(CFG.packageOutputPath, t)
 global VV28Xc
 VV28Xc = FFSw9u(CFG.backupPath.getValue())
 if VVSq9G or VV1GkZ or VVv8cL or VV088V or VVtZut or oldIptvHostsPath or oldMovieDownloadPath:
  configfile.save()
 return VVSq9G, VV1GkZ, VVv8cL, VV088V, VVtZut, oldIptvHostsPath, oldMovieDownloadPath
def FF5GXI(path):
 path = FFPM3Z(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFlNqM(SELF, pathList, tarFileName, addTimeStamp=True):
 VVprx2 = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVprx2.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVprx2.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVprx2.append(path)
 if not VVprx2:
  FFsqiC(SELF, "Files not found!")
 elif not pathExists(VV28Xc):
  FFsqiC(SELF, "Path not found!\n\n%s" % VV28Xc)
 else:
  VVpiiC = FFSw9u(VV28Xc)
  tarFileName = "%s%s" % (VVpiiC, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFYjSS())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVprx2:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVVVdp
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFFHM5(tarFileName, VVOn4X))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFFHM5(failed, VVOn4X))
  cmd += "fi;"
  cmd +=  sep
  FFcuYL(SELF, cmd)
def FFNG0p(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FF0Ius(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FF0Ius(SELF["keyInfo"], "info")
def FF0Ius(barObj, fName):
 path = "%s%s%s" % (VVMPsf, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFC4fv(SELF, title, VVRA9l, showGrnMsg=""):
 SELF.session.open(boundFunction(CCcI13, title=title, VVRA9l=VVRA9l, showGrnMsg=showGrnMsg))
def FFpFKd(labelObj, VVRA9l):
 if VVRA9l and fileExists(VVRA9l):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VVdZHy(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VVdZHy)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VVRA9l)
   return True
  except:
   pass
 return False
def FFv6gW(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFq77s(satNum)
  return satName
def FFq77s(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFT3eZ(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFv6gW(val)
  else  : sat = FFq77s(val)
 return sat
def FF08Wi(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFv6gW(num)
 except:
  pass
 return sat
def FFnBvn(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFiUIe(SELF, isFromSession=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFodTd(info, iServiceInformation.sServiceref)
   prov = FFodTd(info, iServiceInformation.sProvider)
   state = str(FFodTd(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FF0mkS(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FF7COR(refCode)
 return info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFodTd(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFcakO(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFRWNl(refCode):
 info = FFMfdA(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFYly1(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FF0JTY(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFMfdA(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VV6MwM = eServiceCenter.getInstance()
  if VV6MwM:
   info = VV6MwM.info(service)
 return info
def FFIFfg(SELF, refCode, VVb10q=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  FFrEAI(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVb10q:
   FFTcUC(SELF, isFromSession)
 try:
  VVWP6Z = InfoBar.instance
  if VVWP6Z:
   VVHj5Y = VVWP6Z.servicelist
   if VVHj5Y:
    servRef = eServiceReference(refCode)
    VVHj5Y.saveChannel(servRef)
 except:
  pass
def FFrEAI(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCe8Ax()
    if pr.VVyx1g(refCode, chName, decodedUrl, iptvRef):
     pr.VVQv5i(SELF, isFromSession)
def FF0mkS(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFSZwx(url): return any(x in url for x in ("/movie/", "/series/", "mode=vod", "mode=series"))
def FFATna(url)  : return any(x in url for x in ("/movie/", "mode=vod"))
def FFHCdb(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FF7COR(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFzKg9(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFO7ny(userBfile):
 txt = ""
 bFile = VVRcPg + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVRcPg + userBfile):
  fTxt = FFb1Rx(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFdBZy('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
 return
def FFzKg9(url):
 if iUnquote : return iUnquote(url)
 else  : return url
def FFvOlg(url):
 if iQuote : return iQuote(url)
 else  : return url
def FFsF46(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFPPp4(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFysfs(txt):
 try:
  return FFsF46(FFPPp4(txt)) == txt
 except:
  return False
def FFTcUC(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(SELF, isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCwb6Z, isFromExternal=isFromSession)
 else      : FFnyDn(session, reopen=True, isFromExternal=isFromSession)
def FFnyDn(session, reopen=False, isFromExternal=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFnyDn, session, isFromExternal=isFromExternal), boundFunction(CCcdYk, isFromExternal=isFromExternal))
  except:
   try:
    FFllpT(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFmiFT(refCode):
 tp = CC1kFd()
 if tp.VV99B8(refCode) : return True
 else        : return False
def FF6N2d(refCode, isHide):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFOdGC():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FFGqYY():
 VVWP6Z = InfoBar.instance
 if VVWP6Z:
  VVHj5Y = VVWP6Z.servicelist
  if VVHj5Y:
   return VVHj5Y.getBouquetList()
 return None
def FFfmhs():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFFJXz():
 path = FFfmhs()
 if path:
  txt = FFb1Rx(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FFvn2n():
 return FFkzTC(InfoBar.instance.servicelist.getRoot())
def FFkzTC(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VV6MwM = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VV6MwM.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FFNdBc():
 VVtyZP = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVLWAE = list(VVtyZP)
 return VVLWAE, VVtyZP
def FFAMk4():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFUqoS(session, VVMmWf):
 VVpEHS, VVh1GO, VV0cjb, camCommand = FFyiEG()
 if VVh1GO:
  runLog = False
  if   VVMmWf == CCvDbe.VVD0vG : runLog = True
  elif VVMmWf == CCvDbe.VVj2jx : runLog = True
  elif not VV0cjb          : FFllpT(session, message="SoftCam not started yet!")
  elif fileExists(VV0cjb)        : runLog = True
  else             : FFllpT(session, message="File not found !\n\n%s" % VV0cjb)
  if runLog:
   session.open(boundFunction(CCvDbe, VVpEHS=VVpEHS, VVh1GO=VVh1GO, VV0cjb=VV0cjb, VVMmWf=VVMmWf))
 else:
  FFllpT(session, message="No active OSCam/NCam found !", title="Live Log")
def FFyiEG():
 VVpEHS = "/etc/tuxbox/config/"
 VVh1GO = None
 VV0cjb  = None
 camCommand = FFdBZy("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVh1GO = "oscam"
 elif "ncam"  in camCommand : VVh1GO = "ncam"
 if VVh1GO:
  path = FFdBZy(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFSw9u(path)
  if pathExists(path):
   VVpEHS = path
  tFile = VVpEHS + VVh1GO + ".conf"
  tFile = FFdBZy("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VV0cjb = tFile
 return VVpEHS, VVh1GO, VV0cjb, camCommand
def FFh92T(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFhOq2():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFYjSS():
 return FFhOq2().replace(" ", "_").replace("-", "").replace(":", "")
def FFqFgA(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFxnvp():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFiBrv(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCvDyD.VV3VMw(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCvDyD.VV7v6Z_forBouquet(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFnz2p("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFvpqG(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFfgAB(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
VVP797 = 0
def FFTEkm():
 global VVP797
 VVP797 = iTime()
def FF5nLk():
 FFUBQ1(">>>>>> Elapsed\t: {:.6f} seconds".format(iTime() - VVP797).rstrip("0").rstrip("."))
def FFEf0P(SELF, message, title=""):
 SELF.session.open(boundFunction(CCHGvY, title=title, message=message, VVkjQ1=True))
def FFItCL(SELF, message, title="", VVaC8s=VVqUZV, **kwargs):
 SELF.session.open(boundFunction(CCHGvY, title=title, message=message, VVaC8s=VVaC8s, **kwargs))
def FFsqiC(SELF, message, title="")  : FFllpT(SELF.session, message, title)
def FFPX6L(SELF, path, title="") : FFllpT(SELF.session, "File not found !\n\n%s" % path, title)
def FFAqRk(SELF, path, title="") : FFllpT(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFEmMJ(SELF, title="")  : FFllpT(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFllpT(session, message, title="") : session.open(boundFunction(CCZ1lm, title=title, message=message))
def FFD8qa(SELF, VVNtvf, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVNtvf, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVNtvf, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVNtvf, boundFunction(CCWwJA, title=title, message=message, VVd6Iw=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFsqiC(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFmhMd(SELF, callBack_Yes, VVQQbK, callBack_No=None, title="", VVCf1C=False, VVb7kN=True):
 SELF.session.openWithCallback(boundFunction(FFKdbL, callBack_Yes, callBack_No)
        , boundFunction(CCBOvL, title=title, VVQQbK=VVQQbK, VVb7kN=VVb7kN, VVCf1C=VVCf1C))
def FFKdbL(callBack_Yes, callBack_No, FFmhMded):
 if FFmhMded : callBack_Yes()
 elif callBack_No: callBack_No()
def FFlf8A(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFXT3k(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFo3kA(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFNrW1(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VV62Tm = eTimer()
def FFo3kA(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFY1B6, SELF))
 fnc = boundFunction(FFY1B6, SELF)
 try:
  t = VV62Tm.timeout.connect(fnc)
 except:
  VV62Tm.callback.append(fnc)
 VV62Tm.start(milliSeconds, 1)
def FFY1B6(SELF):
 VV62Tm.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFoSxq(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CC3Jxs, **kwargs))
  else   : win = SELF.session.open(boundFunction(CC3Jxs, **kwargs))
  FFGbn6(win)
  return win
 except:
  return None
def FFfsxJ(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCfSoV, **kwargs))
 FFGbn6(win)
 return win
def FFULTs(SELF, **kwargs):
 SELF.session.open(CCazlH, **kwargs)
def FFVXe6(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFIs9D(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVScB1, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFqAhz(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFIs9D(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFkUUP():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFVEnx(VVKTEW):
 screenSize  = FFkUUP()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVKTEW)
 return bodyFontSize
def FFpBBD(VVKTEW, extraSpace):
 font = gFont(VVScB1, VVKTEW)
 VV3yZU = fontRenderClass.getInstance().getLineHeight(font) or (VVKTEW * 1.25)
 return int(VV3yZU + VV3yZU * extraSpace)
def FFDRJf(fontName):
 fList = None
 try:
  from enigma import getFontFaces
  fList = getFontFaces()
 except:
  try:
   from skin import getFontFaces
   fList = getFontFaces()
  except:
   pass
 if fList and fontName in fList : return fontName
 else       : return VVScB1
def FFO5bN(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFkUUP()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * VViwcG)
 bodyFontStr  = 'font="%s;%d"' % (VVScB1, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFpBBD(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVScB1, titleFontSize, alignLeftCenter)
 if winType == VVdurn or winType == VVbkAQ:
  if winType == VVbkAQ : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVe2F2:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == VVCpbF:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FFEf0PL = b2Left2 + timeW + marginLeft
  FFEf0PW = b2Left3 - marginLeft - FFEf0PL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FFEf0PL  , b2Top, FFEf0PW , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="1000" alphatest="blend" />' % (0, top, sz, sz)
 elif winType == VVH8Wc:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVwVAl:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVkVBr:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVuG99:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVScB1, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVScB1, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVrzGb:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFEf0PH = int(bodyH * 0.5)
  inpTop = bodyTop + FFEf0PH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFEf0PH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVScB1, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVScB1, mapF, alignCenter)
 elif winType == VVR7Yu:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVsfmu:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVScB1, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVg91n:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVScB1, fontH, alignCenter)
 elif winType == VVAO8R:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVScB1, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVScB1, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVScB1, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVPlj3:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 else:
  if   winType == VVRHuj : align = alignLeftCenter
  elif winType == VVJcJi : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVwPKP:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VVpaEC:
   moreParams = ""
  else:
   fontStr = bodyFontStr
   if usefixedFont and winType == VVJcJi:
    fontStr = 'font="%s;%d"' % (FFDRJf("Fixed"), bodyFontSize)
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" %s %s ' % (bodyColor, fontStr, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVKTEW = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVScB1, VVKTEW, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VV1z5Z = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVScB1, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VV1z5Z[i], VVScB1, barFont, alignCenter)
   left += btnW + gap
 if winType == VVJcJi:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VV1z5Z = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VV1z5Z[i], VVScB1, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFO5bN(VVdurn, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.hiddenMenuPass = ""
  self.themsList  = []
  VVVLxj = []
  if VVo2cx:
   VVVLxj.append(("-- MY TEST --"    , "myTest"   ))
  VVVLxj.append(("  File Manager"     , "FileManager"  ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("  Services/Channels"    , "ChannelsTools" ))
  VVVLxj.append(("  IPTV"       , "IptvTools"  ))
  VVVLxj.append(("  PIcons"       , "PIconsTools"  ))
  VVVLxj.append(("  SoftCam"      , "SoftCam"   ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("  Plugins"      , "PluginsTools" ))
  VVVLxj.append(("  Terminal"      , "Terminal"  ))
  VVVLxj.append(("  Backup & Restore"    , "BackupRestore" ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("  Date/Time"      , "Date_Time"  ))
  VVVLxj.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVVLxj)
  FF4gq5(self, VVVLxj=VVVLxj)
  FFoPjD(self["keyRed"] , "Exit")
  FFoPjD(self["keyGreen"] , "Settings")
  FFoPjD(self["keyYellow"], "Dev. Info.")
  FFoPjD(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VVE6zg       ,
   "yellow"  : self.VVrSLl       ,
   "blue"   : self.VVCgnR       ,
   "info"   : self.VVCgnR       ,
   "last"   : self.VVdSVh      ,
   "next"   : self.VV0D7H       ,
   "menu"   : self.VVYmIo     ,
   "0"    : boundFunction(self.VVmbkI, 0) ,
   "1"    : boundFunction(self.VVTTmg, 1)   ,
   "2"    : boundFunction(self.VVTTmg, 2)   ,
   "3"    : boundFunction(self.VVTTmg, 3)   ,
   "4"    : boundFunction(self.VVTTmg, 4)   ,
   "5"    : boundFunction(self.VVTTmg, 5)   ,
   "6"    : boundFunction(self.VVTTmg, 6)   ,
   "7"    : boundFunction(self.VVTTmg, 7)   ,
   "8"    : boundFunction(self.VVTTmg, 8)   ,
   "9"    : boundFunction(self.VVTTmg, 9)
  })
  self.onShown.append(self.VV0NuP)
  self.onClose.append(self.onExit)
  global VV6ebU, VVYe7k, VVJHhL
  VV6ebU = VVYe7k = VVJHhL = False
 def VV13Bz(self):
  item = FFCJux(self)
  self.VVTTmg(item)
 def VVTTmg(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVyDaK()
   elif item in ("FileManager"  , 1) : self.session.open(CCt0KP)
   elif item in ("ChannelsTools" , 2) : self.session.open(CC7tYb)
   elif item in ("IptvTools"  , 3) : self.session.open(CCvDyD)
   elif item in ("PIconsTools"  , 4) : self.VVmhr0()
   elif item in ("SoftCam"   , 5) : self.session.open(CCQIob)
   elif item in ("PluginsTools" , 6) : self.session.open(CCBevQ)
   elif item in ("Terminal"  , 7) : self.session.open(CCEXpU)
   elif item in ("BackupRestore" , 8) : self.session.open(CCoCPC)
   elif item in ("Date_Time"  , 9) : self.session.open(CCkNaI)
   elif item in ("CheckInternet" , 10) : self.session.open(CCGriq)
   else         : self.close()
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  FFRtL9(self["myMenu"])
  FFqAhz(self)
  FFVXe6(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVCmca)
  self["myTitle"].setText(title)
  VVSq9G, VV1GkZ, VVv8cL, VV088V, VVtZut, oldIptvHostsPath, oldMovieDownloadPath = FFqwad()
  self.VVlR7d()
  if VVSq9G or VV1GkZ or VVv8cL or VV088V or VVtZut or oldIptvHostsPath or oldMovieDownloadPath:
   VVGYYE = lambda path, subj: "%s:\n%s\n\n" % (subj, FFejnb(path, VVhgxA)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVGYYE(oldIptvHostsPath  , "IPTV Hosts Files Path"   )
   txt += VVGYYE(VVSq9G   , "Backup/Restore Path"    )
   txt += VVGYYE(VV1GkZ  , "Created Package Files (IPK/DEB)" )
   txt += VVGYYE(VVv8cL  , "Download Packages (from feeds)" )
   txt += VVGYYE(VV088V , "Exported Tables"     )
   txt += VVGYYE(VVtZut , "Exported PIcons"     )
   txt += VVGYYE(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFItCL(self, txt, title="Settings Paths")
  if (EASY_MODE or VVHb92 or VVo2cx):
   FFXT3k(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFlf8A(self, "Welcome", 300)
  FFiJN6(boundFunction(self.VV3dzs, title))
 def VV3dzs(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCRbRI.VVpSLp()
   if url:
    newWebVer = CCRbRI.VVFIhI(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFnz2p("rm /tmp/ajpanel*"))
  global VV6ebU, VVYe7k, VVJHhL
  VV6ebU = VVYe7k = VVJHhL = False
 def VVmbkI(self, digit):
  self.hiddenMenuPass += str(digit)
  ln = len(self.hiddenMenuPass)
  global VV6ebU, VVJHhL
  if ln == 4:
   if self.hiddenMenuPass == "0" * ln:
    VV6ebU = True
    FFXT3k(self["myTitle"], "#800080")
   else:
    self.hiddenMenuPass = "x"
  elif self.hiddenMenuPass == "0" * ln:
   VVJHhL = True
 def VV0D7H(self):
  self.hiddenMenuPass += ">"
  if self.hiddenMenuPass == "0" * 4 + ">" * 2:
   global VVYe7k
   VVYe7k = True
   FFXT3k(self["myTitle"], "#dd5588")
 def VVdSVh(self):
  self.hiddenMenuPass += "<"
  if self.hiddenMenuPass == "0" * 4 + "<" * 2:
   ok = False
   fnt = "ae_AlMateen.ttf"
   fontFile = "/usr/share/fonts/%s" % fnt
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    try:
     addFont(fontFile, fontName, 100, True)
     ok = True
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      ok = True
     except:
      pass
   if ok: txt = 'Added Font: "%s"' % fnt
   else : txt = '"%s" Not Found' % fnt
   FFlf8A(self, txt, 2000, isGrn=ok)
 def VVmhr0(self):
  found = False
  pPath = CCfUPK.VVIatH()
  if pathExists(pPath):
   for fName, fType in CCfUPK.VVSltG(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCfUPK)
  else:
   VVVLxj = []
   VVVLxj.append(("PIcons Manager" , "CCfUPK" ))
   VVVLxj.append(VVQP0R)
   VVVLxj.append(CCfUPK.VVBDSS())
   VVVLxj.append(VVQP0R)
   VVVLxj += CCfUPK.VVUDLs()
   FFfsxJ(self, self.VVftal, VVVLxj=VVVLxj)
 def VVftal(self, item=None):
  if item:
   if   item == "CCfUPK"   : self.session.open(CCfUPK)
   elif item == "VVAJkA"  : CCfUPK.VVAJkA(self)
   elif item == "VVeTaZ"  : CCfUPK.VVeTaZ(self)
   elif item == "findPiconBrokenSymLinks" : CCfUPK.VVIHQd(self, True)
   elif item == "FindAllBrokenSymLinks" : CCfUPK.VVIHQd(self, False)
 def VVE6zg(self):
  self.session.open(CCRbRI)
 def VVrSLl(self):
  self.session.open(CCLkVB)
 def VVCgnR(self):
  changeLogFile = VVMPsf + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FF3tpP(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFejnb("\n%s\n%s\n%s" % (VVVVdp, line, VVVVdp), VVKSBp, VVMNP0)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FFejnb(line, VV6AHZ, VVMNP0)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFItCL(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VVCmca), VVKTEW=26)
 def VVYmIo(self):
  VVVLxj = []
  VVVLxj.append(("Title Colors"   , "title" ))
  VVVLxj.append(("Menu Area Colors"  , "body" ))
  VVVLxj.append(("Menu Pointer Colors" , "cursor" ))
  VVVLxj.append(("Bottom Bar Colors" , "bar"  ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Reset Colors"   , "reset" ))
  title = "Main Menu Colors"
  FFfsxJ(self, boundFunction(self.VV4d3p, title), VVVLxj=VVVLxj, width=500, title=title)
 def VV4d3p(self, title, item=None):
  if item:
   if item == "reset":
    FFmhMd(self, self.VV0w0B, "Reset to default colors ?", title=title)
   else:
    tDict = self.VVNsID()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VVtd2L, tDict, item), CCvrN6, defFG=fg, defBG=bg)
 def VVG0wj(self):
  return VV28Xc + "ajpanel_colors"
 def VVNsID(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVG0wj()
  if fileExists(p):
   txt = FFb1Rx(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVtd2L(self, tDict, item, fg, bg):
  if fg:
   self.VVDfBc(item, fg)
   self.VVkrMN(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVhJ7y(tDict)
 def VVhJ7y(self, tDict):
   p = self.VVG0wj()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVDfBc(self, item, fg):
  if   item == "title" : FFhU57(self["myTitle"], fg)
  elif item == "body"  :
   FFhU57(self["myMenu"], fg)
   FFhU57(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFXT3k(self["myBar"], fg)
   FFhU57(self["keyRed"], fg)
   FFhU57(self["keyGreen"], fg)
   FFhU57(self["keyYellow"], fg)
   FFhU57(self["keyBlue"], fg)
 def VVkrMN(self, item, bg):
  if   item == "title" : FFXT3k(self["myTitle"], bg)
  elif item == "body"  :
   FFXT3k(self["myMenu"], bg)
   FFXT3k(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFXT3k(self["myBar"], bg)
 def VV0w0B(self):
  os.system(FFnz2p("rm %s" % self.VVG0wj()))
  self.close()
 def VVlR7d(self):
  tDict = self.VVNsID()
  self.VV6o3b(tDict, "title")
  self.VV6o3b(tDict, "body")
  self.VV6o3b(tDict, "cursor")
  self.VV6o3b(tDict, "bar")
 def VV6o3b(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVDfBc(name, fg)
  if bg: self.VVkrMN(name, bg)
 def VVyDaK(self):
  pass
class CCLkVB(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFO5bN(VVdurn, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVVLxj = []
  VVVLxj.append(("Settings File"        , "SettingsFile"   ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Box Info"          , "VV9AOB"    ))
  VVVLxj.append(("Tuners Info"         , "VVFJfT"   ))
  VVVLxj.append(("Python Version"        , "VVaqpV"   ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Screen Size"         , "ScreenSize"    ))
  VVVLxj.append(("Locale"          , "Locale"     ))
  VVVLxj.append(("Processor"         , "Processor"    ))
  VVVLxj.append(("Operating System"        , "OperatingSystem"   ))
  VVVLxj.append(("Drivers"          , "drivers"     ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("System Users"         , "SystemUsers"    ))
  VVVLxj.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVVLxj.append(("Uptime"          , "Uptime"     ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Host Name"         , "HostName"    ))
  VVVLxj.append(("MAC Address"         , "MACAddress"    ))
  VVVLxj.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVVLxj.append(("Network Status"        , "NetworkStatus"   ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Disk Usage"         , "VVBnhq"    ))
  VVVLxj.append(("Mount Points"         , "MountPoints"    ))
  VVVLxj.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVVLxj.append(("USB Devices"         , "USB_Devices"    ))
  VVVLxj.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVVLxj.append(("Directory Size"        , "DirectorySize"   ))
  VVVLxj.append(("Memory"          , "Memory"     ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVVLxj.append(("Running Processes"       , "RunningProcesses"  ))
  VVVLxj.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FF4gq5(self, VVVLxj=VVVLxj, title="Device Information")
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  FFRtL9(self["myMenu"])
  FFqAhz(self)
 def VV13Bz(self):
  global VVlddb
  VVlddb = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCXF0G)
   elif item == "VV9AOB"    : self.VV9AOB()
   elif item == "VVFJfT"   : self.VVFJfT()
   elif item == "VVaqpV"   : self.VVaqpV()
   elif item == "ScreenSize"    : FFItCL(self, "Width\t: %s\nHeight\t: %s" % (FFkUUP()[0], FFkUUP()[1]))
   elif item == "Locale"     : self.VVBAub()
   elif item == "Processor"    : self.VVihn9()
   elif item == "OperatingSystem"   : FFtCAF(self, "uname -a"        )
   elif item == "drivers"     : self.VVYLOi()
   elif item == "SystemUsers"    : FFtCAF(self, "id"          )
   elif item == "LoggedInUsers"   : FFtCAF(self, "who -a"         )
   elif item == "Uptime"     : FFtCAF(self, "uptime"         )
   elif item == "HostName"     : FFtCAF(self, "hostname"        )
   elif item == "MACAddress"    : self.VVL5R7()
   elif item == "NetworkConfiguration"  : FFtCAF(self, "ifconfig %s %s" % (FFFHM5("HWaddr", VVWdSD), FFFHM5("addr:", VVHuTi)))
   elif item == "NetworkStatus"   : FFtCAF(self, "netstat -tulpn"       )
   elif item == "VVBnhq"    : self.VVBnhq()
   elif item == "MountPoints"    : FFtCAF(self, "mount %s" % (FFFHM5(" on ", VVHuTi)))
   elif item == "FileSystemTable"   : FFtCAF(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFtCAF(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFtCAF(self, "blkid"         )
   elif item == "DirectorySize"   : FFtCAF(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVwgWU="Reading size ...")
   elif item == "Memory"     : FFtCAF(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVpOE8()
   elif item == "RunningProcesses"   : FFtCAF(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFtCAF(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VV4AxL()
   else         : self.close()
 def VVL5R7(self):
  res = FFuq8j("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFItCL(self, txt)
  else:
   FFtCAF(self, "ip link")
 def VVDniX(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFstFz(cmd)
  return lines
 def VVm7Ok(self, lines, headerRepl, widths, VVOhM5):
  VV5tha = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VV5tha.append(parts)
  if VV5tha and len(header) == len(widths):
   VV5tha.sort(key=lambda x: x[0].lower())
   FFoSxq(self, None, header=header, VVprx2=VV5tha, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=28, VVgnNM=True)
   return True
  else:
   return False
 def VVBnhq(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VVDniX(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVOhM5 = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VVm7Ok(lines, headerRepl, widths, VVOhM5)
  if not allOK:
   lines = FFstFz(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFPM3Z(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVOn4X:
     note = "\n%s" % FFejnb("Green = Mounted Partitions", VVOn4X)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVHuTi
     elif line.endswith(mountList) : color = VVOn4X
     else       : color = VV6AHZ
     txt += FFejnb(line, color) + "\n"
    FFItCL(self, txt + note)
   else:
    FFsqiC(self, "Not data from system !")
 def VVpOE8(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVDniX(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVOhM5 = (LEFT , CENTER, LEFT )
  allOK = self.VVm7Ok(lines, headerRepl, widths, VVOhM5)
  if not allOK:
   FFtCAF(self, cmd)
 def VVBAub(self):
  from locale import getdefaultlocale
  loc = getdefaultlocale()
  FFItCL(self, "Language\t: %s\nEncoding\t: %s" % (loc[0], loc[1]))
 def VVYLOi(self):
  cmd = FF6GOT(VVcBD8, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFtCAF(self, cmd)
  else : FFEmMJ(self)
 def VVihn9(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFtCAF(self, cmd)
 def VV4AxL(self):
  cmd = FF6GOT(VVU1lA, "| grep secondstage")
  if cmd : FFtCAF(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFEmMJ(self)
 def VV9AOB(self):
  c = VVOn4X
  VVprx2 = []
  VVprx2.append((FFejnb("Box Type"  , c), FFejnb(self.VV1iX7("boxtype").upper(), c)))
  VVprx2.append((FFejnb("Board Version", c), FFejnb(self.VV1iX7("board_revision") , c)))
  VVprx2.append((FFejnb("Chipset"  , c), FFejnb(self.VV1iX7("chipset")  , c)))
  VVprx2.append((FFejnb("S/N"   , c), FFejnb(self.VV1iX7("sn")    , c)))
  VVprx2.append((FFejnb("Version"  , c), FFejnb(self.VV1iX7("version")  , c)))
  VVV417   = []
  VVg6K0 = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVg6K0 = SystemInfo[key]
     else:
      VVV417.append((FFejnb(str(key), VVj8eg), FFejnb(str(SystemInfo[key]), VVj8eg)))
  except:
   pass
  if VVg6K0:
   VVYeYd = self.VVJe4L(VVg6K0)
   if VVYeYd:
    VVYeYd.sort(key=lambda x: x[0].lower())
    VVprx2 += VVYeYd
  if VVV417:
   VVV417.sort(key=lambda x: x[0].lower())
   VVprx2 += VVV417
  if VVprx2:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFoSxq(self, None, header=header, VVprx2=VVprx2, VVADeP=widths, VVKTEW=28, VVgnNM=True)
  else:
   FFItCL(self, "Could not read info!")
 def VV1iX7(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FF3tpP(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVJe4L(self, mbDict):
  try:
   mbList = list(mbDict)
   VVprx2 = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVprx2.append((FFejnb(subject, VVHuTi), FFejnb(value, VVHuTi)))
  except:
   pass
  return VVprx2
 def VVFJfT(self):
  txt = self.VVWO6D("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVWO6D("/proc/bus/nim_sockets")
  if not txt: txt = self.VVe4Xb()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFItCL(self, txt)
 def VVe4Xb(self):
  txt = ""
  VVGYYE = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVGYYE("Slot Name" , slot.getSlotName())
     txt += FFejnb(slotName, VVHuTi)
     txt += VVGYYE("Description"  , slot.getFullDescription())
     txt += VVGYYE("Frontend ID"  , slot.frontend_id)
     txt += VVGYYE("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVWO6D(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FF3tpP(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFejnb(line, VVHuTi)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVaqpV(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFItCL(self, txt)
class CCXF0G(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFO5bN(VVdurn, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVVLxj = []
  VVVLxj.append(("Settings (All)"   , "Settings_All"   ))
  VVVLxj.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  if VVYe7k:
   VVVLxj.append(("Settings (FHDG-17)" , "Settings_FHDG_17"  ))
  VVVLxj.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVVLxj.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVVLxj.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVVLxj.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVVLxj.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FF4gq5(self, VVVLxj=VVVLxj)
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  FFRtL9(self["myMenu"])
  FFqAhz(self)
 def VV13Bz(self):
  global VVlddb
  VVlddb = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFtCAF(self, cmd                )
   elif item == "Settings_HotKeys"   : FFtCAF(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFtCAF(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFtCAF(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFtCAF(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFtCAF(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFtCAF(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFtCAF(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCQIob(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFO5bN(VVdurn, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVpEHS, VVh1GO, VV0cjb, camCommand = FFyiEG()
  self.VVh1GO = VVh1GO
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVVLxj = []
  VVVLxj.append(("OSCam Files"        , "OSCamFiles"  ))
  VVVLxj.append(("NCam Files"        , "NCamFiles"  ))
  VVVLxj.append(("CCcam Files"        , "CCcamFiles"  ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVVLxj.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVVLxj.append(VVQP0R)
  if VVh1GO:
   if   "oscam" in VVh1GO : camName = "OSCam"
   elif "ncam"  in VVh1GO : camName = "NCam"
   VVVLxj.append((camName + " Info."      , "camInfo"   ))
   VVVLxj.append((camName + " Live Status"    , "camLiveStatus" ))
   VVVLxj.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVVLxj.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVVLxj.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FF4gq5(self, VVVLxj=VVVLxj)
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  FFRtL9(self["myMenu"])
  FFqAhz(self)
 def VV13Bz(self):
  global VVlddb
  VVlddb = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCt2fq, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCt2fq, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCt2fq, "cccam"))
   elif item == "OSCamReaders"  : self.VVnviG("os")
   elif item == "NSCamReaders"  : self.VVnviG("n")
   elif item == "camInfo"   : FFHLTb(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFUqoS(self.session, CCvDbe.VVD0vG)
   elif item == "camLiveReaders" : FFUqoS(self.session, CCvDbe.VVj2jx)
   elif item == "camLiveLog"  : FFUqoS(self.session, CCvDbe.VVEtGz)
   else       : self.close()
 def VVnviG(self, camPrefix):
  VV5tha = self.VVEgvD(camPrefix)
  if VV5tha:
   VV5tha.sort(key=lambda x: int(x[0]))
   if self.VVh1GO and self.VVh1GO.startswith(camPrefix):
    VVgwCo = ("Toggle State", self.VVGDkz, [camPrefix], "Changing State ...")
   else:
    VVgwCo = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVOhM5  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFoSxq(self, None, header=header, VVprx2=VV5tha, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=26, VVgwCo=VVgwCo, VV13Vm=True)
 def VVEgvD(self, camPrefix):
  readersFile = self.VVpEHS + camPrefix + "cam.server"
  VV5tha = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FF3tpP(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VV5tha.append((str(len(VV5tha) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VV5tha:
    FFsqiC(self, "No readers found !")
  else:
   FFPX6L(self, readersFile)
  return VV5tha
 def VVGDkz(self, VVV80v, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVpEHS, camPrefix)
  readerState  = VVV80v.VVRcVo(1)
  readerLabel  = VVV80v.VVRcVo(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCQIob.VVc6CO(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVV80v.VV8Hdn()
    FFsqiC(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VV5tha = self.VVEgvD(camPrefix)
   if VV5tha:
    VVV80v.VVnbpo(VV5tha)
 @staticmethod
 def VVc6CO(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FF3tpP(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFsqiC(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFsqiC(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFPX6L(SELF, confFile)
   return None
  if not iRequest:
   FFsqiC(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FFsqiC(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FFsqiC(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCt2fq(Screen):
 def __init__(self, VVOkCj, session, args=0):
  self.skin, self.skinParam = FFO5bN(VVdurn, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVpEHS, VVh1GO, VV0cjb, camCommand = FFyiEG()
  if   VVOkCj == "ncam" : self.prefix = "n"
  elif VVOkCj == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVVLxj = []
  if self.prefix == "":
   VVVLxj.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVVLxj.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVVLxj.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVVLxj.append(("constant.cw"         , "x_constant_cw" ))
   VVVLxj.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVVLxj.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVVLxj.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVVLxj.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVVLxj.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVVLxj.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVVLxj.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVVLxj.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVVLxj.append(VVQP0R)
   VVVLxj.append(("SoftCam.Key"         , "x_SoftCam_Key" ))
   VVVLxj.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVVLxj.append(VVQP0R)
   VVVLxj.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVVLxj.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVVLxj.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FF4gq5(self, VVVLxj=VVVLxj)
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  FFRtL9(self["myMenu"])
  FFqAhz(self)
 def VV13Bz(self):
  global VVlddb
  VVlddb = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFM8So(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFM8So(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFM8So(self, self.VVpEHS + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFM8So(self, self.VVpEHS + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVJ803("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVJ803("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVJ803("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVJ803("cam.provid"        )
   elif item == "x_cam_server"  : self.VVJ803("cam.server"        )
   elif item == "x_cam_services" : self.VVJ803("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVJ803("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVJ803("cam.user"        )
   elif item == "x_VVVVdp"   : pass
   elif item == "x_SoftCam_Key" : FFM8So(self, self.VVpEHS + "SoftCam.Key"   )
   elif item == "x_CCcam_cfg"  : FFM8So(self, self.VVpEHS + "CCcam.cfg"    )
   elif item == "x_VVVVdp"   : pass
   elif item == "x_cam_log"  : FFM8So(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFM8So(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFM8So(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVJ803(self, fileName):
  FFM8So(self, self.VVpEHS + self.prefix + fileName)
class CCvDbe(Screen):
 VVD0vG  = 0
 VVj2jx = 1
 VVEtGz = 2
 def __init__(self, session, VVpEHS="", VVh1GO="", VV0cjb="", VVMmWf=VVD0vG):
  self.skin, self.skinParam = FFO5bN(VVJcJi, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VV0cjb   = VV0cjb
  self.VVMmWf  = VVMmWf
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVpEHS + VVh1GO + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVh1GO : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVpEHS, self.camPrefix)
  if self.VVMmWf == self.VVD0vG:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVMmWf == self.VVj2jx:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FF4gq5(self, self.Title, addScrollLabel=True)
  FFoPjD(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVa5NO
  self.onShown.append(self.VV0NuP)
  self.onClose.append(self.onExit)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  self["myLabel"].VVtkCY(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFVXe6(self)
  self.VVa5NO()
 def onExit(self):
  self.timer.stop()
 def VVwKOL(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVPQyE)
  except:
   self.timer.callback.append(self.VVPQyE)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFlf8A(self, "Started", 1000)
 def VVEBIu(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVPQyE)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFlf8A(self, "Stopped", 1000)
 def VVa5NO(self):
  if self.timerRunning:
   self.VVEBIu()
  else:
   self.VVwKOL()
   if self.VVMmWf == self.VVD0vG or self.VVMmWf == self.VVj2jx:
    if self.VVMmWf == self.VVD0vG : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCQIob.VVc6CO(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFiJN6(self.VVGLae)
    else:
     self.close()
   else:
    self.VVLebR()
 def VVPQyE(self):
  if self.timerRunning:
   if   self.VVMmWf == self.VVD0vG : self.VVSHEZ()
   elif self.VVMmWf == self.VVj2jx : self.VVSHEZ()
   else            : self.VVLebR()
 def VVLebR(self):
  if fileExists(self.VV0cjb):
   fTime = FFh92T(os.path.getmtime(self.VV0cjb))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVF3OS(), VVaC8s=VV0v5h)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VV0cjb)
 def VVGLae(self):
  self.VVSHEZ()
 def VVSHEZ(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFejnb("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVKSBp))
   self.camWebIfErrorFound = True
   self.VVEBIu()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVMmWf == self.VVD0vG : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFejnb("Error while parsing data elements !\n\nError = %s" % str(e), VVhgxA)
   self.camWebIfErrorFound = True
   self.VVEBIu()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVnkGg(root)
  self["myLabel"].setText(txt, VVaC8s=VV0v5h)
  self["myBar"].setText("Last Update : %s" % FFhOq2())
 def VVnkGg(self, rootElement):
  def VVGYYE(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVMmWf == self.VVD0vG:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFejnb(status, VVOn4X)
    else          : status = FFejnb(status, VVhgxA)
    txt += VVVVdp + "\n"
    txt += VVGYYE("Name"  , name)
    txt += VVGYYE("Description" , desc)
    txt += VVGYYE("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVGYYE("Protocol" , protocol)
    txt += VVGYYE("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFejnb("Yes", VVOn4X)
    else    : enabTxt = FFejnb("No", VVhgxA)
    txt += VVVVdp + "\n"
    txt += VVGYYE("Label"  , label)
    txt += VVGYYE("Protocol" , protocol)
    txt += VVGYYE("Enabled" , enabTxt)
  return txt
 def VVF3OS(self):
  wordsDict = self.VVDBYK()
  color = [ VVHuTi, VVWdSD, VVOn4X, VVhgxA, VVj8eg, VVVBxF]
  lines = FFstFz("tail -n %d %s" % (100, self.VV0cjb))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVKSBp + line[:19] + VV6AHZ + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVMNP0 + line[ndx + 3:] + VV6AHZ
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVHuTi + line[ndx + 8 : ndx1 + 4] + VV6AHZ + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VV6AHZ)
   elif line.startswith("----") or ">>" in line:
    line = FFejnb(line, VVHuTi)
   txt += line + "\n"
  return txt
 def VVDBYK(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FF3tpP(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCoCPC(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFO5bN(VVdurn, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVVLxj = []
  VVVLxj.append(("Backup Channels"    , "VV145D"   ))
  VVVLxj.append(("Restore Channels"    , "Restore_Channels"  ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Backup SoftCAM Files"   , "VVfyZs" ))
  VVVLxj.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVVLxj.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVVLxj.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Backup Network Settings"  , "VVnpn1"   ))
  VVVLxj.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVYe7k:
   VVVLxj.append(VVQP0R)
   VVVLxj.append((VVKSBp + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VV1nan"   ))
   VVVLxj.append((VVOn4X + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVc3xP) , "createMyIpk"   ))
   VVVLxj.append((VVOn4X + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVc3xP) , "createMyDeb"   ))
   VVVLxj.append((VVj8eg + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVVLxj.append((VVj8eg + "Decode %s Crash Report"   % PLUGIN_NAME     , "VVYg1o" ))
  FF4gq5(self, VVVLxj=VVVLxj)
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  FFRtL9(self["myMenu"])
  FFqAhz(self)
 def VV13Bz(self):
  global VVlddb
  VVlddb = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VV145D"    : self.VV145D()
   elif item == "Restore_Channels"    : self.VVCi0b("channels_backup*.tar.gz", self.VVg9dS)
   elif item == "VVfyZs"   : self.VVfyZs()
   elif item == "Restore_SoftCAM_Files"  : self.VVCi0b("softcam_backup*.tar.gz", self.VVFhjP)
   elif item == "Backup_TunerDiSEqC"   : self.VVlOE7("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVCi0b("tuner_backup*.backup", boundFunction(self.VVOwBk, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVlOE7("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVCi0b("hotkey_*backup*.backup", boundFunction(self.VVOwBk, "misc"))
   elif item == "VVnpn1"    : self.VVnpn1()
   elif item == "Restore_Network"    : self.VVCi0b("network_backup*.tar.gz", self.VVRmIs)
   elif item == "VV1nan"     : FFmhMd(self, boundFunction(FF6Ue4, self, boundFunction(CCoCPC.VV1nan, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVDchS(False)
   elif item == "createMyDeb"     : self.VVDchS(True)
   elif item == "createMyTar"     : self.VVowLS()
   elif item == "VVYg1o"   : self.VVYg1o()
 @staticmethod
 def VV1nan(SELF):
  OBF_Path = VVDrFQ + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVDrFQ, VVCmca, VVc3xP)
   if err : FFsqiC(SELF, err)
   else : FFItCL(SELF, txt)
  else:
   FFPX6L(SELF, OBF_Path)
 def VVDchS(self, VVq4bA):
  OBF_Path = VVDrFQ + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFsqiC(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVDrFQ)
  os.system("mv -f %s %s" % (VVDrFQ + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVDrFQ + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVDrFQ + "plugin.py"))
  self.session.openWithCallback(self.VVDchS1, boundFunction(CCDu6G, path=VVDrFQ, VVq4bA=VVq4bA))
 def VVDchS1(self):
  os.system("mv -f %s %s" % (VVDrFQ + "OBF/main.py"  , VVDrFQ))
  os.system("mv -f %s %s" % (VVDrFQ + "OBF/plugin.py" , VVDrFQ))
 def VVYg1o(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFsqiC(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFsqiC(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVPS48("%s*.list" % path)
  if err:
   FFPX6L(self, path + "*.list")
   return
  srcF, err = self.VVPS48("%s*main_final.py" % path)
  if err:
   FFPX6L(self, path + "*.final.py")
   return
  VVprx2 = []
  for f in files:
   f = os.path.basename(f)
   VVprx2.append((f, f))
  FFfsxJ(self, boundFunction(self.VVRAaf, path, codF, srcF), VVVLxj=VVprx2)
 def VVRAaf(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFPX6L(self, logF)
   else     : FF6Ue4(self, boundFunction(self.VVJGk2, logF, codF, srcF))
 def VVJGk2(self, logF, codF, srcF):
  lst  = []
  lines = FF3tpP(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFsqiC(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVezT4(lst, logF, newLogF)
  totSrc  = self.VVezT4(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFItCL(self, txt)
 def VVPS48(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVezT4(self, lst, f1, f2):
  txt = FFb1Rx(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVowLS(self):
  VVprx2 = []
  VVprx2.append("%s%s" % (VVDrFQ, "*.py"))
  VVprx2.append("%s%s" % (VVDrFQ, "*.png"))
  VVprx2.append("%s%s" % (VVDrFQ, "*.xml"))
  VVprx2.append("%s"  % (VVMPsf))
  FFlNqM(self, VVprx2, "%s_%s" % (PLUGIN_NAME, VVCmca), addTimeStamp=False)
 def VV145D(self):
  path1 = VVRcPg
  path2 = "/etc/tuxbox/"
  VVprx2 = []
  VVprx2.append("%s%s" % (path1, "*.tv"))
  VVprx2.append("%s%s" % (path1, "*.radio"))
  VVprx2.append("%s%s" % (path1, "*list"))
  VVprx2.append("%s%s" % (path1, "lamedb*"))
  VVprx2.append("%s%s" % (path2, "*.xml"))
  FFlNqM(self, VVprx2, "channels_backup", addTimeStamp=True)
 def VVfyZs(self):
  VVprx2 = []
  VVprx2.append("/etc/tuxbox/config/")
  VVprx2.append("/usr/keys/")
  VVprx2.append("/usr/scam/")
  VVprx2.append("/etc/CCcam.cfg")
  FFlNqM(self, VVprx2, "softcam_backup", addTimeStamp=True)
 def VVnpn1(self):
  VVprx2 = []
  VVprx2.append("/etc/hostname")
  VVprx2.append("/etc/default_gw")
  VVprx2.append("/etc/resolv.conf")
  VVprx2.append("/etc/wpa_supplicant*.conf")
  VVprx2.append("/etc/network/interfaces")
  VVprx2.append("/etc/enigma2/nameserversdns.conf")
  FFlNqM(self, VVprx2, "network_backup", addTimeStamp=True)
 def VVg9dS(self, fileName):
  if fileName:
   FFmhMd(self, boundFunction(self.VVT593, fileName), "Overwrite current channels ?")
 def VVT593(self, fileName):
  path = "%s%s" % (VV28Xc, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CC7tYb.VVE02m()
   lamedb5File, diabled5File = CC7tYb.VVMFbG()
   cmd = ""
   cmd += FFnz2p("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFnz2p("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFOdGC()
   if res == 0 : FFEf0P(self, "Channels Restored.")
   else  : FFsqiC(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFPX6L(self, path)
 def VVFhjP(self, fileName):
  if fileName:
   FFmhMd(self, boundFunction(self.VVQc6j, fileName), "Overwrite SoftCAM files ?")
 def VVQc6j(self, fileName):
  fileName = "%s%s" % (VV28Xc, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVVVdp
   note = "You may need to restart your SoftCAM."
   FFp6Bw(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFFHM5(note, VVHuTi), sep))
  else:
   FFPX6L(self, fileName)
 def VVRmIs(self, fileName):
  if fileName:
   FFmhMd(self, boundFunction(self.VVitjj, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVitjj(self, fileName):
  fileName = "%s%s" % (VV28Xc, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFyzyQ(self,  cmd)
  else:
   FFPX6L(self, fileName)
 def VVCi0b(self, pattern, callBackFunction, isTuner=False):
  title = FFST5G()
  if pathExists(VV28Xc):
   myFiles = iGlob("%s%s" % (VV28Xc, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVprx2 = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVprx2.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VV8yYG = ("Sat. List", self.VVFnkh)
    else  : VV8yYG = None
    VVFM2s = ("Delete File", boundFunction(self.VVb7hw, boundFunction(self.VVCi0b, pattern, callBackFunction, isTuner)))
    FFfsxJ(self, callBackFunction, title=title, VVVLxj=VVprx2, VV8yYG=VV8yYG, VVFM2s=VVFM2s)
   else:
    FFsqiC(self, "No files found in:\n\n%s" % VV28Xc, title)
  else:
   FFsqiC(self, "Path not found:\n\n%s" % VV28Xc, title)
 def VVb7hw(self, cbFnc, VVVpUgObj, path):
  FFmhMd(self, boundFunction(self.VV2ozf, cbFnc, VVVpUgObj, path), "Delete this file ?\n\n%s" % path)
 def VV2ozf(self, cbFnc, VVVpUgObj, path):
  os.system(FFnz2p("rm -f '%s%s'" % (VV28Xc, path)))
  cbFnc()
  VVVpUgObj.cancel()
 def VVlOE7(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCsmtD()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VVbmvl, filePrefix))
 def VVbmvl(self, filePrefix, result, retval):
  title = FFST5G()
  if pathExists(VV28Xc):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFsqiC(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VV28Xc, filePrefix, FFYjSS())
    try:
     VVprx2 = str(result.strip()).split()
     if VVprx2:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVprx2:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVVVdp, FFejnb(fName, VVHuTi), VVVVdp)
       FFItCL(self, txt, title=title, VVaC8s=VV0v5h)
      else:
       FFsqiC(self, "File creation failed!", title)
     else:
      FFsqiC(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFnz2p("rm %s" % fName))
     FFsqiC(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFnz2p("rm %s" % fName))
     FFsqiC(self, "Error while writing file.")
  else:
   FFsqiC(self, "Path not found:\n\n%s" % VV28Xc, title)
 def VVOwBk(self, mode, path):
  if path:
   path = "%s%s" % (VV28Xc, path)
   if fileExists(path):
    lines = FF3tpP(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFmhMd(self, boundFunction(self.VVQvCB, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFAqRk(self, path, title=FFST5G())
   else:
    FFPX6L(self, path)
 def VVQvCB(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVsr3H = []
  VVsr3H.append("echo -e 'Reading current settings ...'")
  VVsr3H.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVsr3H.append("echo -e 'Preparing new settings ...'")
  VVsr3H.append(settingsLines)
  VVsr3H.append("echo -e 'Applying new settings ...'")
  VVsr3H.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FF7rMy(self, VVsr3H)
 def VVFnkh(self, VVVpUgObj, path):
  if not path:
   return
  path = VV28Xc + path
  if not fileExists(path):
   FFPX6L(self, path)
   return
  txt = FFb1Rx(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVprx2  = []
   for item in satList:
    VVprx2.append("%s\t%s" % (item[0], FFv6gW(item[1])))
   FFItCL(self, VVprx2, title="  Satellites List")
  else:
   FFsqiC(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCBevQ(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFO5bN(VVdurn, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVVLxj = []
  VVVLxj.append(("Plugins Browser List"       , "VVCwZE"   ))
  VVVLxj.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVVLxj.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVVLxj.append(("Remove Packages (show all)"     , "VVrhhdsAll"   ))
  VVVLxj.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Update List of Available Packages"   , "VVqQk9"   ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Packaging Tool"        , "VVbzmj"    ))
  VVVLxj.append(("Packages Feeds"        , "packagesFeeds"    ))
  FF4gq5(self, VVVLxj=VVVLxj)
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  FFRtL9(self["myMenu"])
  FFqAhz(self)
 def VV13Bz(self):
  global VVlddb
  VVlddb = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVCwZE"   : self.VVCwZE()
   elif item == "pluginsMenus"     : self.VVfUuz(0)
   elif item == "pluginsStartup"    : self.VVfUuz(1)
   elif item == "pluginsDirList"    : self.VVS1kb()
   elif item == "downloadInstallPackages"  : FF6Ue4(self, boundFunction(self.VVoII0, 0, ""))
   elif item == "VVrhhdsAll"   : FF6Ue4(self, boundFunction(self.VVoII0, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FF6Ue4(self, boundFunction(self.VVoII0, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVqQk9"   : self.VVqQk9()
   elif item == "VVbzmj"    : self.VVbzmj()
   elif item == "packagesFeeds"    : self.VVQrMC()
   else          : self.close()
 def VVS1kb(self):
  extDirs  = FFeDaV(VVniGc)
  sysDirs  = FFeDaV(VVVbI9)
  VVprx2  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVprx2.append((item, VVniGc + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVprx2.append((item, VVVbI9 + item))
  if VVprx2:
   VVprx2 = sorted(VVprx2, key=lambda x: x[0].lower())
   VV3VnJ = ("Package Info.", self.VVAEh7, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFoSxq(self, None, header=header, VVprx2=VVprx2, VVADeP=widths, VVKTEW=28, VV3VnJ=VV3VnJ)
  else:
   FFsqiC(self, "Nothing found!")
 def VVAEh7(self, VVV80v, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVniGc) : loc = "extensions"
  elif path.startswith(VVVbI9) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVCZRi(package)
  else:
   FFsqiC(self, "No info!")
 def VVQrMC(self):
  pkg = FFHjh8()
  if pkg : FFtCAF(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFEmMJ(self)
 def VVCwZE(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVGYYE(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVVVdp + "\n"
    txt += VVGYYE("Number"   , str(c))
    txt += VVGYYE("Name"   , FFejnb(str(p.name), VVHuTi))
    txt += VVGYYE("Path"  , p.path  )
    txt += VVGYYE("Description" , p.description )
    txt += VVGYYE("Icon"  , p.iconstr  )
    txt += VVGYYE("Wakeup Fnc" , p.wakeupfnc )
    txt += VVGYYE("NeedsRestart", p.needsRestart)
    txt += VVGYYE("Internal" , p.internal )
    txt += VVGYYE("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFItCL(self, txt)
 def VVfUuz(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVprx2 = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVprx2.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVprx2:
   VVprx2.sort(key=lambda x: x[0].lower())
   header  = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths  = (19  , 25 , 20  , 27   , 9  )
   FFoSxq(self, None, title=title, header=header, VVprx2=VVprx2, VVADeP=widths, VVKTEW=26)
  else:
   FFsqiC(self, "Nothing Found", title=title)
 def VVqQk9(self):
  cmd = FF6GOT(VVG8HC, "")
  if cmd : FFyzyQ(self, cmd, checkNetAccess=True)
  else : FFEmMJ(self)
 def VVbzmj(self):
  pkg = FFHjh8()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFEf0P(self, txt)
 def VVoII0(self, mode, grep, VVV80v=None, title=""):
  if   mode == 0: cmd = FF6GOT(VVU1lA    , grep)
  elif mode == 1: cmd = FF6GOT(VVcBD8 , grep)
  elif mode == 2: cmd = FF6GOT(VVcBD8 , grep)
  if not cmd:
   FFEmMJ(self)
   return
  VV5tha = FFstFz(cmd)
  if not VV5tha:
   if VVV80v: VVV80v.VV8Hdn()
   FFsqiC(self, "No packages found!")
   return
  elif len(VV5tha) == 1 and VV5tha[0] == VVRXzX:
   FFsqiC(self, VVRXzX)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVprx2  = []
  for item in VV5tha:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVprx2.append((name, package, version))
  if mode > 0:
   extensions = FFstFz("ls %s -l | grep '^d' | awk '{print $9}'" % VVniGc)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVprx2:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVprx2.append((name, VVniGc + item, "-"))
   systemPlugins = FFstFz("ls %s -l | grep '^d' | awk '{print $9}'" % VVVbI9)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVprx2:
      if item.lower() == row[0].lower():
       break
     else:
      VVprx2.append((item, VVVbI9 + item, "-"))
  if not VVprx2:
   FFsqiC(self, "No packages found!")
   return
  if VVV80v:
   VVprx2.sort(key=lambda x: x[0].lower())
   VVV80v.VVnbpo(VVprx2, title)
  else:
   widths = (20, 50, 30)
   VVgwCo = None
   VVa6E6 = None
   if mode == 0:
    VV5eNi = ("Install" , self.VV7bAa   , [])
    VVgwCo = ("Download" , self.VVSAg1   , [])
    VVa6E6 = ("Filter"  , self.VVXkCm , [])
   elif mode == 1:
    VV5eNi = ("Uninstall", self.VVrhhd, [])
   elif mode == 2:
    VV5eNi = ("Uninstall", self.VVrhhd, [])
    widths= (18, 57, 25)
   VVprx2 = sorted(VVprx2, key=lambda x: x[0].lower())
   VV3VnJ = ("Package Info.", self.VVt1Aw, [])
   header   = ("Name" ,"Package" , "Version" )
   FFoSxq(self, None, header=header, VVprx2=VVprx2, VVADeP=widths, VVKTEW=28, VV5eNi=VV5eNi, VVgwCo=VVgwCo, VV3VnJ=VV3VnJ, VVa6E6=VVa6E6, VVzjB3=self.lastSelectedRow
     , VVkTTr="#22110011", VVDVtL="#22191111", VV1z5Z="#22191111", VVps2K="#00003030", VVNERz="#00333333")
 def VVt1Aw(self, VVV80v, title, txt, colList):
  package = colList[1]
  self.VVCZRi(package)
 def VVXkCm(self, VVV80v, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVVLxj = []
  VVVLxj.append(("All Packages", "all"))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVVLxj.append(VVQP0R)
  for word in words:
   VVVLxj.append((word, word))
  FFfsxJ(self, boundFunction(self.VVnxt5, VVV80v), VVVLxj=VVVLxj, title="Select Filter")
 def VVnxt5(self, VVV80v, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FF6Ue4(VVV80v, boundFunction(self.VVoII0, 0, grep, VVV80v, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVrhhd(self, VVV80v, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVniGc, VVVbI9)):
   FFmhMd(self, boundFunction(self.VVg3G0, VVV80v, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVVLxj = []
   VVVLxj.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVVLxj.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVVLxj.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFfsxJ(self, boundFunction(self.VV7XiC, VVV80v, package), VVVLxj=VVVLxj)
 def VVg3G0(self, VVV80v, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVVFG3)
  FFyzyQ(self, cmd, VVPF19=boundFunction(self.VVuiVJ, VVV80v))
 def VV7XiC(self, VVV80v, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVW7Es
   elif item == "remove_ForceRemove"  : cmdOpt = VVBvxk
   elif item == "remove_IgnoreDepends"  : cmdOpt = VV6BU1
   FFmhMd(self, boundFunction(self.VV40og, VVV80v, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VV40og(self, VVV80v, package, cmdOpt):
  self.lastSelectedRow = VVV80v.VVDRvM()
  cmd = FFvshm(cmdOpt, package)
  if cmd : FFyzyQ(self, cmd, VVPF19=boundFunction(self.VVuiVJ, VVV80v))
  else : FFEmMJ(self)
 def VVuiVJ(self, VVV80v):
  VVV80v.cancel()
  FFAMk4()
 def VV7bAa(self, VVV80v, title, txt, colList):
  package  = colList[1]
  VVVLxj = []
  VVVLxj.append(("Install Package"         , "install_CheckVersion" ))
  VVVLxj.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVVLxj.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VVVLxj.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVVLxj.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFfsxJ(self, boundFunction(self.VVcRsb, package), VVVLxj=VVVLxj)
 def VVcRsb(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVH8bp
   elif item == "install_ForceReinstall" : cmdOpt = VVcW3p
   elif item == "install_ForceOverwrite" : cmdOpt = VVZZd5
   elif item == "install_ForceDowngrade" : cmdOpt = VVMYqO
   elif item == "install_IgnoreDepends" : cmdOpt = VVdufl
   FFmhMd(self, boundFunction(self.VVMrop, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVMrop(self, package, cmdOpt):
  cmd = FFvshm(cmdOpt, package)
  if cmd : FFyzyQ(self, cmd, VVPF19=FFAMk4, checkNetAccess=True)
  else : FFEmMJ(self)
 def VVSAg1(self, VVV80v, title, txt, colList):
  package  = colList[1]
  FFmhMd(self, boundFunction(self.VV5frK, package), "Download Package ?\n\n%s" % package)
 def VV5frK(self, package):
  if FFtswK():
   cmd = FFvshm(VVM2ju, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFFHM5(success, VVOn4X))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFFHM5(fail, VVhgxA))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFyzyQ(self, cmd, VVC5bj=[VVhgxA, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFEmMJ(self)
  else:
   FFsqiC(self, "No internet connection !")
 def VVCZRi(self, package):
  infoCmd  = FFvshm(VVsFnD, package)
  filesCmd = FFvshm(VVGWxm, package)
  listInstCmd = FF6GOT(VVcBD8, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFM12k(VVHuTi)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFFHM5(notInst, VVKSBp))
   cmd += "else "
   cmd +=   FFSH61("System Info", VVHuTi)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFSH61("Related Files", VVHuTi)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFzH9C(self, cmd)
  else:
   FFEmMJ(self)
class CC7tYb(Screen):
 VVvCwT  = 0
 VVZRzr = 1
 VVZ63o  = 2
 VVO2tu  = 3
 VVzkrP = 4
 VV8Mbm = 5
 VVzq6L = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFO5bN(VVdurn, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVwG7b = None
  self.lastfilterUsed  = None
  VVVLxj = self.VVbT6T()
  FF4gq5(self, VVVLxj=VVVLxj, title="Services/Channels")
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self["myMenu"].setList(self.VVbT6T())
  FFRtL9(self["myMenu"])
  FFqAhz(self)
 def VVbT6T(self):
  VVVLxj = []
  VVVLxj.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VVVLxj.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Services (Reference)"      , "lameDB_allChannels_with_refCode"  ))
  VVVLxj.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVVLxj.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVVLxj.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVVLxj.append(("Services with PIcons for the System"  , "VVxg4X"     ))
  VVVLxj.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVVLxj.append(VVQP0R)
  lamedbFile, disabledFile = CC7tYb.VVE02m()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVVLxj.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVVLxj.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVVLxj.append(("Reset Parental Control Settings"   , "VVBIin"    ))
  VVVLxj.append(("Delete Channels with no names"   , "VVidlM"    ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Reload Channels and Bouquets"    , "VVCSRu"      ))
  return VVVLxj
 def VV13Bz(self):
  global VVlddb
  VVlddb = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFTcUC(self)
   elif item == "currentServiceInfo"     : FFULTs(self, fncMode=CCazlH.VVNRD9)
   elif item == "TranspondersStats"     : FF6Ue4(self, self.VVRXt6     )
   elif item == "lameDB_allChannels_with_refCode"  : FF6Ue4(self, self.VVPuej )
   elif item == "lameDB_allChannels_with_tranaponder" : FF6Ue4(self, self.VVBZsD)
   elif item == "lameDB_allChannels_with_details"  : FF6Ue4(self, self.VV5SSm )
   elif item == "parentalControlChannels"    : FF6Ue4(self, self.VVhYyT   )
   elif item == "showHiddenChannels"     : FF6Ue4(self, self.VVEJV7     )
   elif item == "VVxg4X"     : FF6Ue4(self, self.VVCfIP     )
   elif item == "servicesWithMissingPIcons"   : FF6Ue4(self, self.VVGef9   )
   elif item == "enableHiddenChannels"     : self.VVc0cQ(True)
   elif item == "disableHiddenChannels"    : self.VVc0cQ(False)
   elif item == "VVBIin"    : FFmhMd(self, self.VVBIin, "Reset and Restart ?" )
   elif item == "VVidlM"    : FF6Ue4(self, self.VVidlM)
   elif item == "VVCSRu"      : FF6Ue4(self, boundFunction(CC7tYb.VVCSRu, self))
   else            : self.close()
 @staticmethod
 def VVCSRu(SELF):
  FFOdGC()
  FFEf0P(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVPuej(self):
  self.VVwG7b = None
  self.lastfilterUsed  = None
  self.filterObj   = CCicDe(self)
  VV5tha = CC7tYb.VVVqOu(self, self.VVvCwT)
  if VV5tha:
   VV5tha.sort(key=lambda x: x[0].lower())
   VV0k9j  = ("Zap"   , self.VV4ax0     , [])
   VVEgOz = (""    , self.VVIwCh   , [])
   VV3VnJ = ("Options"  , self.VVYsoh , [])
   VVgwCo = ("Current Service", self.VVrKql , [])
   VVa6E6 = ("Filter"   , self.VVH8xh  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVOhM5  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFoSxq(self, None, header=header, VVprx2=VV5tha, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=26, VV0k9j=VV0k9j, VVEgOz=VVEgOz, VVgwCo=VVgwCo, VV3VnJ=VV3VnJ, VVa6E6=VVa6E6)
 def VVBZsD(self):
  self.VVwG7b = None
  self.lastfilterUsed  = None
  self.filterObj   = CCicDe(self)
  VV5tha = CC7tYb.VVVqOu(self, self.VVZRzr)
  if VV5tha:
   VV5tha.sort(key=lambda x: x[0].lower())
   VV0k9j  = ("Zap"   , self.VV4ax0      , [])
   VVEgOz = (""    , self.VVIwCh    , [])
   VVgwCo = ("Current Service", self.VVrKql  , [])
   VV3VnJ = ("Options"  , self.VVsBQs , [])
   VVa6E6 = ("Filter"   , self.VVMfI1  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVOhM5  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFoSxq(self, None, header=header, VVprx2=VV5tha, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=26, VV0k9j=VV0k9j, VVEgOz=VVEgOz, VVgwCo=VVgwCo, VV3VnJ=VV3VnJ, VVa6E6=VVa6E6)
 def VVYsoh(self, VVV80v, title, txt, colList):
  servName = colList[0]
  refCode  = colList[3]
  pcState  = colList[4]
  hidState = colList[5]
  mSel  = CClNKv(self, VVV80v, 3)
  mSel.VVAw0c(servName, refCode, pcState, hidState)
 def VVsBQs(self, VVV80v, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CClNKv(self, VVV80v, 3)
  mSel.VVKu0N(servName, refCode)
 def VVRZZS(self, VVV80v, refCode, isAddToBlackList):
  self.VVwG7b = None
  self.lastfilterUsed  = None
  VVV80v.VVWc3V("Changing state ...")
  path = "/etc/enigma2/blacklist"
  if not fileExists(path):
   os.system("echo '' > %s" % path)
  if fileExists(path):
   if not refCode.endswith(":"):
    refCode += ":"
   if isAddToBlackList :
    os.system("sed -i '/%s/d' %s" % (refCode, path))
    os.system("echo '%s' >> %s" % (refCode, path))
   else:
    os.system("sed -i '/%s/d' %s" % (refCode, path))
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   if refCode.endswith(":"):
    refCode = refCode[:-1]
   FF6Ue4(self, boundFunction(self.VVFUv2, VVV80v, refCode))
  else:
   FFPX6L(self, path)
 def VVoDXN(self, VVV80v, refCode, isHide):
  self.VVwG7b = None
  self.lastfilterUsed  = None
  VVV80v.VVWc3V("Changing state ...")
  if FFmiFT(refCode):
   ret = FF6N2d(refCode, isHide)
   if ret : FF6Ue4(self, boundFunction(self.VVFUv2, VVV80v, refCode))
   else : FFsqiC(self, "Cannot Hide/Unhide this channel.")
  else:
   FFsqiC(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)")
 def VVFUv2(self, VVV80v, refCode):
  VV5tha = CC7tYb.VVVqOu(self, self.VVvCwT, VVVgpg=[3, [refCode], False])
  done = False
  if VV5tha:
   data = VV5tha[0]
   if data[3] == refCode:
    done = VVV80v.VV5whV(data)
  if not done:
   self.VVDilZ(VVV80v, VVV80v.VVpfHE(), self.VVvCwT)
  VVV80v.VV8Hdn()
 def VVH8xh(self, VVV80v, title, txt, colList):
  self.filterObj.VVqI2T(1, VVV80v, 2, boundFunction(self.VVRnp8, VVV80v))
 def VVRnp8(self, VVV80v, item):
  self.VVMXc9(VVV80v, item, 2, self.VVvCwT)
 def VVMfI1(self, VVV80v, title, txt, colList):
  self.filterObj.VVqI2T(2, VVV80v, 4, boundFunction(self.VVr0o5, VVV80v))
 def VVr0o5(self, VVV80v, item):
  self.VVMXc9(VVV80v, item, 4, self.VVZRzr)
 def VVj5Wz(self, VVV80v, title, txt, colList):
  self.filterObj.VVqI2T(0, VVV80v, 4, boundFunction(self.VVEfEQ, VVV80v))
 def VVEfEQ(self, VVV80v, item):
  self.VVMXc9(VVV80v, item, 4, self.VVZ63o)
 def VVMXc9(self, VVV80v, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVV80v.VVRcVo(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVwG7b = None
  else:
   words, asPrefix = CCicDe.VVDnY4(words)
   self.VVwG7b = [col, words, asPrefix]
  if words: FF6Ue4(self, boundFunction(self.VVDilZ, VVV80v, title, mode), title="Reading Services ...")
  else : FFlf8A(VVV80v, "Incorrect filter", 2000)
 def VVDilZ(self, VVV80v, title, mode):
  VV5tha = CC7tYb.VVVqOu(self, mode, VVVgpg=self.VVwG7b, VVtwCC=False)
  if VV5tha:
   VV5tha.sort(key=lambda x: x[0].lower())
   VVV80v.VVnbpo(VV5tha, title)
  else:
   VVV80v.VV8Hdn()
   FFlf8A(VVV80v, "Not found!", 1500)
 def VVLbjb(self, VVprx2, VV0k9j=None, VVEgOz=None, VV5eNi=None, VVgwCo=None, VV3VnJ=None, VVa6E6=None):
  VVgwCo = ("Current Service", self.VVrKql, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVOhM5 = (LEFT  , LEFT  , CENTER, LEFT    )
  FFoSxq(self, None, header=header, VVprx2=VVprx2, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=26, VV0k9j=VV0k9j, VVEgOz=VVEgOz, VV5eNi=VV5eNi, VVgwCo=VVgwCo, VV3VnJ=VV3VnJ, VVa6E6=VVa6E6)
 def VVrKql(self, VVV80v, title, txt, colList):
  self.VVI7kw(VVV80v)
 def VVve8J(self, VVV80v, title, txt, colList):
  self.VVI7kw(VVV80v, True)
 def VVI7kw(self, VVV80v, isFromDetails=False):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self)
  if refCode:
   if isFromDetails:
    chName  = info.getName()
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVV80v.VVH29i(colDict, VVPeMj=True)
   else:
    VVV80v.VVBR6e(3, refCode, True)
   return
  FFsqiC(self, "Colud not read current Reference Code !")
 def VV5SSm(self):
  self.VVwG7b = None
  self.lastfilterUsed  = None
  self.filterObj   = CCicDe(self)
  VV5tha = CC7tYb.VVVqOu(self, self.VVZ63o)
  if VV5tha:
   VV5tha.sort(key=lambda x: x[0].lower())
   VVEgOz = (""    , self.VV8asn , []      )
   VVgwCo = ("Current Service", self.VVve8J  , []      )
   VVa6E6 = ("Filter"   , self.VVj5Wz   , [], "Loading Filters ..." )
   VV0k9j  = ("Zap"   , self.VVPff7      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVOhM5  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFoSxq(self, None, header=header, VVprx2=VV5tha, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=26, VV0k9j=VV0k9j, VVEgOz=VVEgOz, VVgwCo=VVgwCo, VVa6E6=VVa6E6)
 def VV8asn(self, VVV80v, title, txt, colList):
  refCode  = self.VVvezW(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFULTs(self, fncMode=CCazlH.VVi2Qh, refCode=refCode, chName=chName, text=txt)
 def VVPff7(self, VVV80v, title, txt, colList):
  refCode = self.VVvezW(colList)
  FFIFfg(self, refCode)
 def VV4ax0(self, VVV80v, title, txt, colList):
  FFIFfg(self, colList[3])
 def VVvezW(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVVqOu(SELF, mode, VVVgpg=None, VVtwCC=True, VV2Adh=True):
  lamedbFile, disabledFile = CC7tYb.VVE02m()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVVgpg:
    filterCol = VVVgpg[0]
    filterWords = VVVgpg[1]
    asPrefix = VVVgpg[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CC7tYb.VVvCwT:
    blackList = None
    path = "/etc/enigma2/blacklist"
    if fileExists(path):
     blackList = FF3tpP(path)
     if blackList:
      blackList = set(blackList)
   elif mode == CC7tYb.VVZRzr:
    tp = CC1kFd()
   VVLWAE, VVtyZP = FFNdBc()
   tagFound  = False
   if mode in (CC7tYb.VV8Mbm, CC7tYb.VVzq6L):
    VV5tha = {}
   else:
    VV5tha = []
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFq77s(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CC7tYb.VVZ63o:
        if sTypeInt in VVLWAE:
         STYPE = VVtyZP[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VV5tha.append(tRow)
         elif any(x in tmp for x in filterWords)    : VV5tha.append(tRow)
        else:
         VV5tha.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CC7tYb.VV8Mbm:
         VV5tha[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CC7tYb.VVzq6L:
         VV5tha[chName] = refCode
        elif mode == CC7tYb.VVvCwT:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VV5tha.append(tRow)
          elif any(x in tmp for x in filterWords)    : VV5tha.append(tRow)
         else:
          VV5tha.append(tRow)
        elif mode == CC7tYb.VVZRzr:
         if sTypeInt in VVLWAE:
          STYPE = VVtyZP[sTypeInt]
         freq, pol, fec, sr, syst = tp.VVgI7x(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VV5tha.append(tRow)
          elif any(x in tmp for x in filterWords)    : VV5tha.append(tRow)
         else:
          VV5tha.append(tRow)
        elif mode == CC7tYb.VVO2tu:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VV5tha.append((chName, chProv, sat, refCode))
        elif mode == CC7tYb.VVzkrP:
         VV5tha.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VV5tha and VVtwCC:
    FFsqiC(SELF, "No services found!")
   return VV5tha
  else:
   if VV2Adh:
    FFPX6L(SELF, lamedbFile)
   return None
 def VVhYyT(self):
  path = "/etc/enigma2/blacklist"
  if fileExists(path):
   lines = FF3tpP(path)
   if lines:
    newRows  = []
    VV5tha = CC7tYb.VVVqOu(self, self.VVzkrP)
    if VV5tha:
     lines = set(lines)
     for item in VV5tha:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VV5tha = newRows
      VV5tha.sort(key=lambda x: x[0].lower())
      VVEgOz = ("", self.VVIwCh, [])
      VV0k9j = ("Zap", self.VV4ax0, [])
      self.VVLbjb(VVprx2=VV5tha, VV0k9j=VV0k9j, VVEgOz=VVEgOz)
     else:
      FFItCL(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VV5tha)))
   else:
    FFEf0P(self, "No active Parental Control services.", FFST5G())
  else:
   FFPX6L(self, path)
 def VVEJV7(self):
  VV5tha = CC7tYb.VVVqOu(self, self.VVO2tu)
  if VV5tha:
   VV5tha.sort(key=lambda x: x[0].lower())
   VVEgOz = ("" , self.VVIwCh, [])
   VV0k9j  = ("Zap", self.VV4ax0, [])
   self.VVLbjb(VVprx2=VV5tha, VV0k9j=VV0k9j, VVEgOz=VVEgOz)
  else:
   FFEf0P(self, "No hidden services.", FFST5G())
 def VVRXt6(self):
  totT, totC, totA, totS, totS2, satList = self.VVoOTS()
  txt = FFejnb("Total Transponders:\n\n", VVj8eg)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFejnb("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVj8eg)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFnBvn(item), satList.count(item))
  FFItCL(self, txt)
 def VVoOTS(self):
  lamedbFile, disabledFile = CC7tYb.VVE02m()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFPX6L(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VVCfIP(self)   : self.VVxg4X(True)
 def VVGef9(self) : self.VVxg4X(False)
 def VVxg4X(self, isWithPIcons):
  piconsPath = CCfUPK.VVIatH()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCfUPK.VVSltG(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VV5tha = CC7tYb.VVVqOu(self, self.VVzkrP)
    if VV5tha:
     channels = []
     for (chName, chProv, sat, refCode) in VV5tha:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FF0JTY(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VV5tha)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVGYYE(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVGYYE("PIcons Path"  , piconsPath)
     txt += VVGYYE("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVGYYE("Total services" , totalServices)
     txt += VVGYYE("With PIcons"  , totalWithPIcons)
     txt += VVGYYE("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFItCL(self, txt)
     else:
      VVEgOz     = (""      , self.VVIwCh , [])
      if isWithPIcons : VVa6E6 = ("Export Current PIcon", self.VV93SJ  , [])
      else   : VVa6E6 = None
      VV3VnJ     = ("Statistics", FFItCL, [txt])
      VV0k9j      = ("Zap", self.VV4ax0, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVLbjb(VVprx2=channels, VV0k9j=VV0k9j, VVEgOz=VVEgOz, VV3VnJ=VV3VnJ, VVa6E6=VVa6E6)
   else:
    FFsqiC(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFsqiC(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVIwCh(self, VVV80v, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFULTs(self, fncMode=CCazlH.VVi2Qh, refCode=refCode, chName=chName, text=txt)
 def VV93SJ(self, VVV80v, title, txt, colList):
  png, path = CCfUPK.VV2fvd(colList[3], colList[0])
  if path:
   CCfUPK.VVIpaH(self, png, path)
 @staticmethod
 def VVE02m():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVMFbG():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVc0cQ(self, isEnable):
  lamedbFile, disabledFile = CC7tYb.VVE02m()
  if isEnable and not fileExists(disabledFile):
   FFEf0P(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FFsqiC(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFmhMd(self, boundFunction(self.VVZEwh, isEnable), "%s Hidden Channels ?" % word)
 def VVZEwh(self, isEnable):
  lamedbFile , disabledFile = CC7tYb.VVE02m()
  lamedb5File, diabled5File = CC7tYb.VVMFbG()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FFOdGC()
  if res == 0 : FFEf0P(self, "Hidden List %s" % word)
  else  : FFsqiC(self, "Error while restoring:\n\n%s" % fileName)
 def VVBIin(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FF7rMy(self, cmd)
 def VVidlM(self):
  lamedbFile, disabledFile = CC7tYb.VVE02m()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFnz2p("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FF3tpP(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFnz2p("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FFOdGC()
   FFItCL(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFPX6L(self, lamedbFile)
class CCazlH(Screen):
 VVNRD9  = 0
 VVypMs   = 1
 VVOecd   = 2
 VVi2Qh    = 3
 VVNoHS    = 4
 VVvfXZ   = 5
 VV9X1w   = 6
 VV0FAc    = 7
 VVcngu   = 8
 VVaGUQ   = 9
 VVwCPx   = 10
 VVG0Sz   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFO5bN(VVJcJi, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVNRD9)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFejnb("%s\n", VV0ESq) % VVVVdp
  FF4gq5(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVN1eP })
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  self["myLabel"].VVtkCY(textOutFile="chann_info")
  if   self.fncMode == self.VVNRD9 : fnc = self.VVr8jL_VVNRD9
  elif self.fncMode == self.VVypMs  : fnc = self.VVr8jL_VVNRD9
  elif self.fncMode == self.VVOecd  : fnc = self.VVr8jL_VVNRD9
  elif self.fncMode == self.VVi2Qh  : fnc = self.VVr8jL_VVi2Qh
  elif self.fncMode == self.VVNoHS  : fnc = self.VVr8jL_VVNoHS
  elif self.fncMode == self.VVvfXZ  : fnc = self.VVr8jL_VVvfXZ
  elif self.fncMode == self.VV9X1w  : fnc = self.VVr8jL_VV9X1w
  elif self.fncMode == self.VV0FAc  : fnc = self.VVr8jL_VV0FAc
  elif self.fncMode == self.VVcngu  : fnc = self.VVr8jL_VVcngu
  elif self.fncMode == self.VVaGUQ : fnc = self.VVr8jL_VVaGUQ
  elif self.fncMode == self.VVwCPx  : fnc = self.VVr8jL_VVwCPx
  elif self.fncMode == self.VVG0Sz : fnc = self.VVr8jL_VVG0Sz
  self["myLabel"].setText("\n   Reading Info ...")
  FFiJN6(fnc)
 def VVNDZl(self, err):
  self["myLabel"].setText(err)
  FFXT3k(self["myTitle"], "#22200000")
  FFXT3k(self["myBody"], "#22200000")
  self["myLabel"].FFXT3kColor("#22200000")
  self["myLabel"].VVzhnR()
 def VVr8jL_VVNRD9(self):
  try:
   dum = self.session
  except:
   return
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self)
  self.refCode = refCode
  self.VVKZsP(chName)
 def VVr8jL_VVi2Qh(self):
  self.VVKZsP(self.chName)
 def VVr8jL_VVNoHS(self):
  self.VVKZsP(self.chName)
 def VVr8jL_VVvfXZ(self):
  self.VVKZsP(self.chName)
 def VVr8jL_VV9X1w(self):
  self.VVKZsP("Picon Info")
 def VVr8jL_VV0FAc(self):
  self.VVKZsP(self.chName)
 def VVr8jL_VVcngu(self):
  self.VVKZsP(self.chName)
 def VVr8jL_VVaGUQ(self):
  self.VVKZsP(self.chName)
 def VVr8jL_VVwCPx(self):
  self.chUrl = self.refCode + self.callingSELF.VVXysD(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVKZsP(self.chName)
 def VVr8jL_VVG0Sz(self):
  self.VVKZsP(self.chName)
 def VVKZsP(self, title):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVIsgP(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFejnb(self.VVWGS2(tUrl), VV6AHZ)
  if not self.epg:
   epg = self.VVAwBx(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVx9pv(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCfUPK.VV2fvd(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVx9pv(path)
  self.VV1Y3K()
  self.VVPzW1()
  self["myLabel"].setText(self.text, VVaC8s=VVqUZV)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVzhnR(minHeight=minH)
 def VVPzW1(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FF0mkS(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVnIvo(FFzKg9(url))
  if epg:
   self.text += "\n" + FFic6i("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VV1Y3K()
 def VV1Y3K(self):
  if not self.piconShown and self.picUrl:
   path, err = FFiBrv(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVx9pv(path)
    if self.piconShown and self.refCode:
     self.VVa3nH(path, self.refCode)
 def VVa3nH(self, path, refCode):
  if path and fileExists(path) and os.system(FFnz2p("which ffmpeg")) == 0:
   pPath = CCfUPK.VVIatH()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
    cmd += FFnz2p("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVx9pv(self, path):
  if path and fileExists(path):
   err, w, h = self.VV6xVP(path)
   if not err:
    if h > w:
     self.VVqrOb(self["myPicF"], w, h, True)
     self.VVqrOb(self["myPic"] , w, h, False)
   allOK = FFpFKd(self["myPic"], path)
   if allOK:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVqrOb(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VV6xVP(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFdBZy(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVIsgP(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFejnb(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVGYYE(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFejnb(state, VVKSBp)
   txt += "State\t: %s\n" % state
  w = FFodTd(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFodTd(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVq4uw(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVGYYE(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVGYYE(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVGYYE(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVoL8C()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVZSAE()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = self.VV4H8K()
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFejnb("IPTV", VVj8eg)
   txt += self.VVr7CM(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVX7Cv(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CC1kFd()
    tpTxt, namespace = tp.VV1qQf(refCode)
    del tp
    if tpTxt:
     txt += FFejnb("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFejnb("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVGYYE(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVGYYE(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVGYYE(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVGYYE(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVGYYE(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVGYYE(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVGYYE(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVGYYE(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVGYYE(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVq4uw(info):
  if info:
   aspect = FFodTd(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVGYYE(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFodTd(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVqgic(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VV4H8K(self):
  fPath, fDir, fName = CCt0KP.VVU7Qg(self)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg", "mvi"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 def VVqgic(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVoL8C(self):
  try:
   service = self.session.nav.getCurrentService()
   audio = service and service.audioTracks()
   return audio and audio.getNumberOfTracks() or 0
  except:
   pass
  return -1
 def VVZSAE(self):
  try:
   service   = self.session.nav.getCurrentService()
   subtitle  = service and service.subtitle()
   subtitlelist = subtitle and subtitle.getSubtitleList()
   return len(subtitlelist)
  except:
   pass
  return -1
 def VVX7Cv(self, refCode, iptvRef, chName):
  refCode = FFcakO(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFb1Rx(VVRcPg + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFb1Rx(VVRcPg + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VVprx2 = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVRcPg + item
   if fileExists(path):
    txt = FFb1Rx(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVprx2.append(bName)
  txt = self.Sep
  if VVprx2:
   if len(VVprx2) == 1:
    txt += "%s\t: %s\n" % (FFejnb("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VVprx2[0])
   else:
    txt += FFejnb("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VVprx2):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVAwBx(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVj78y(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVj78y(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVj78y(event, 0)
     except:
      pass
  return epg
 def VVj78y(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName().strip()    or ""
   evTime = event.getBeginTime()      or ""
   evDur = event.getDuration()      or ""
   evShort = event.getShortDescription() .strip() or ""
   evDesc = event.getExtendedDescription().strip() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = self.VVkIwt(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FFejnb(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FFejnb(evNameTransl, COLOR_CONS_BRIGHT_YELLOW))
    if evTime           : txt += "Start Time\t: %s\n" % FFh92T(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFh92T(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFqFgA(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFqFgA(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFqFgA(evTime - now)
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFejnb(evShort, VVUDe3)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFejnb(evDesc , VVUDe3)
    if txt:
     txt = FFejnb("\n%s\n%s Event:\n%s\n" % (VVVVdp, ("Current", "Next")[evNum], VVVVdp), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVr7CM(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FF7COR(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCk6BG()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVnA3J(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFejnb("URL:", VVj8eg) + "\n%s\n" % self.VVWGS2(decodedUrl)
  else:
   txt = "\n"
   txt += FFejnb("Reference:", VVj8eg) + "\n%s\n" % refCode
  return txt
 def VVWGS2(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVYe7k:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VVnIvo(self, decodedUrl):
  if not FFtswK():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCvDyD.VV3VMw(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCvDyD.VVSJvq(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVyL5M(tDict)
   elif uType == "movie" : epg, picUrl = self.VVXgZD(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVyL5M(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCvDyD.VVZ0n9(item, "title"    , is_base64=True )
     lang    = CCvDyD.VVZ0n9(item, "lang"         ).upper()
     description   = CCvDyD.VVZ0n9(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCvDyD.VVZ0n9(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCvDyD.VVZ0n9(item, "start_timestamp"      )
     stop_timestamp  = CCvDyD.VVZ0n9(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCvDyD.VVZ0n9(item, "stop_timestamp"       )
     now_playing   = CCvDyD.VVZ0n9(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVMNP0, ""
      else     : color, txt = VVKSBp , "    (CURRENT EVENT)"
      epg += FFejnb("_" * 32 + "\n", VV0ESq)
      epg += FFejnb("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFejnb(description, VV6AHZ)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVm3s9(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VVXgZD(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCvDyD.VVZ0n9(item, "movie_image" )
    genre  = CCvDyD.VVZ0n9(item, "genre"   ) or "-"
    plot  = CCvDyD.VVZ0n9(item, "plot"   ) or "-"
    cast  = CCvDyD.VVZ0n9(item, "cast"   ) or "-"
    rating  = CCvDyD.VVZ0n9(item, "rating"   ) or "-"
    director = CCvDyD.VVZ0n9(item, "director"  ) or "-"
    releasedate = CCvDyD.VVZ0n9(item, "releasedate" ) or "-"
    duration = CCvDyD.VVZ0n9(item, "duration"  ) or "-"
    try:
     lang = CCvDyD.VVZ0n9(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFejnb(cast, VV6AHZ)
    epg += "Plot:\n%s"    % FFejnb(self.VVkIwt(plot), VV6AHZ)
   except:
    pass
  return epg, movie_image
 def VVkIwt(self, evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = self.VVqtH4(evTxt, lang)
   return CCazlH.VVtLUj(txt).strip() or evTxt
 @staticmethod
 def VVtLUj(txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VVqtH4(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFvOlg(txt))
   txt, err = CCvDyD.VVSJvq(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFzKg9(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVm3s9(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
 @staticmethod
 def VVYLrY(SELF):
  if not CCPIXA.VV0lgC(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(SELF)
  err = url =  fSize = resumable = ""
  if FFSZwx(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCk6BG.VVv2o9(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCk6BG.VVd5QDHeader(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FFsqiC(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCt0KP.VVnUtG(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFejnb(" (M3U/M3U8 File)", VV6AHZ)
    else:
     fSize = "No info. from server. Try again later."
    hResume = resp.headers.get("Accept-Ranges" , "")
    if hResume:
     if not hResume == "none": resumable = "Yes"
     else     : resumable = "No"
   except requests.Timeout as e     : err = "Connection Timeout"
   except Exception as e       : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVN08k(subj, val):
   return "%s\n%s\n\n" % (FFejnb("%s:" % subj, COLOR_CONS_BRIGHT_YELLOW), val)
  title = "File Size"
  txt  = VVN08k(title , fSize or "?")
  txt += VVN08k("Name" , chName)
  txt += VVN08k("URL" , url)
  if resumable: txt += VVN08k("Supports Download-Resume", resumable)
  if err  : txt += FFejnb("Error:\n", VVKSBp) + err
  FFItCL(SELF, txt, title=title)
 def VVN1eP(self):
  if VVYe7k:
   def VVGYYE(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self)
   n = ("info" , "refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (info , refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVGYYE(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCk6BG()
    valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVnA3J(decodedUrl)
    n = ("valid", "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVGYYE(n[i], v[i])
   with open("/tmp/ajp_channel_details", "a") as f:
    f.write("%s\n%s\n" % (VVVVdp, txt))
   FFlf8A(self, "Saved to:", 1000)
class CCk6BG():
 def __init__(self):
  self.VVynMQ  = ""
  self.VV89kz   = ""
  self.VVgnGu  = ""
  self.colored_user  = "#f#11ffffaa#User"
  self.colored_server  = "#f#11aaffff#Server"
 def VV4GkT(self, url, mac, VVPeMj=True):
  self.VVynMQ = ""
  self.VV89kz  = ""
  self.VVgnGu = ""
  host = self.VVQ9Kx(url)
  if not host:
   if VVPeMj:
    self.VVPeMjor("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVIB1O(mac)
  if not host:
   if VVPeMj:
    self.VVPeMjor("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVynMQ = host
  self.VV89kz  = mac
  self.VVgnGu = ""
  return True
 def VV3tPE(self):
  res, err = self.VVcssN(self.VVynMQ, useCookies=False)
  if err:
   self.VVPeMjor(err, "Connect to Portal")
   return False
  if (res.status_code == 301):
   title = "Redirection"
   newUrl = res.headers['location']
   res, err = self.VVcssN(newUrl, res.cookies)
   if err:
    self.VVPeMjor(err, "URL Redirection")
    return False
   else:
    host = self.VVQ9Kx(newUrl)
    if not host:
     self.VVPeMjor("Incorrect Redirection-URL Format !\n\n%s" % newUrl)
     return False
    self.VVynMQ = host
  token, profile, tErr = self.VVqelk()
  if not token:
   return False
  return True
 def VVQ9Kx(self, url):
  ndx = url.lower().find("mac=")
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  if url.lower().endswith("/stalker_portal"): url = url[:-15]
  return url
 def VVIB1O(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVqelk(self, VVPeMj=True):
  err = ""
  try:
   token, err = self.VVwxP7()
   if token:
    self.VVgnGu = token
    return token, self.VVjIFX(), ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if VVPeMj:
   self.VVPeMjor(tErr)
  return "", "", tErr
 def VVwxP7(self):
  res, err = self.VVcssN(self.VVDhD4())
  if not err:
   try:
    tDict = jLoads(res.text)
    token = CCvDyD.VVZ0n9(tDict["js"], "token")
    return token.strip(), ""
   except:
    pass
  return "", err
 def VVjIFX(self):
  res, err = self.VVcssN(self.VVp82i())
  if not err:
   try:
    profJson = jLoads(res.text)
    return profJson
   except:
    pass
  return ""
 def VVtDGV(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVE7w0()
  if len(rows) < 10:
   rows = self.VV6AWD()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVynMQ ))
   rows.append(("MAC (from URL)" , self.VV89kz ))
   rows.append(("Token"   , self.VVgnGu ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VV89kz ))
   rows.append(("2", self.colored_server, "Host" , self.VVynMQ ))
   rows.append(("2", self.colored_server, "Token" , self.VVgnGu ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVGUew(self, isPhp=True, VVPeMj=False):
  token, profile, tErr = self.VVqelk(VVPeMj)
  if not token:
   return "", tErr
  m3u_Url = ""
  url = self.VVWxtj()
  res, err = self.VVcssN(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCvDyD.VVZ0n9(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFvOlg(span.group(2))
     pass1 = FFvOlg(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, err
 def VVE7w0(self):
  m3u_Url, err = self.VVGUew()
  rows = []
  if m3u_Url:
   res, err = self.VVcssN(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFh92T(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFh92T(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VV6AWD(self):
  token, profile, tErr = self.VVqelk()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFysfs(val): val = FFPPp4(val.decode("UTF-8"))
     else     : val = self.VV89kz
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFh92T(int(parts[1]))
      if parts[2] : ends = FFh92T(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFh92T(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVXysD(self, mode, chCm, epNum, epId):
  crLinkUrl = self.VVNwK4(mode, chCm, epNum, epId)
  token, profile, tErr = self.VVqelk(VVPeMj=False)
  if not token:
   return ""
  res, err = self.VVcssN(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCvDyD.VVZ0n9(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  return chUrl
 def VVdNwp(self):
  return self.VVynMQ + "/server/load.php?"
 def VVDhD4(self):
  return self.VVdNwp() + "type=stb&action=handshake&token=&mac=%s" % self.VV89kz
 def VVp82i(self):
  return self.VVdNwp() + "type=stb&action=get_profile"
 def VViIAM(self, mode):
  url = self.VVdNwp() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVhF0L(self, catID):
  return self.VVdNwp() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVzzNw(self, mode, catID, page):
  url = self.VVdNwp() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "series" : url += "category=%s" % catID
  else    : url += "genre=%s&force_ch_link_check=" % catID
  return url
 def VVfWPu(self, mode, searchName, page):
  return self.VVdNwp() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VVT8QF(self, mode, catID):
  return self.VVdNwp() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVNwK4(self, mode, chCm, serCode, serId):
  url = self.VVdNwp() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVWxtj(self):
  return self.VVdNwp() + "type=itv&action=create_link"
 def VVnfuc(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVhAn0(catID, stID, chNum)
  query = self.VVguEn(mode, FFsF46(host), FFsF46(mac), serCode, serId, chCm)
  chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVguEn(self, mode, host, mac, serCode, serId, chCm):
  query = "mode=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVnA3J(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVguEn(mode, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFPPp4(host)
  mac   = FFPPp4(mac)
  valid = False
  if self.VVQ9Kx(playHost) and self.VVQ9Kx(host) and self.VVQ9Kx(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVcssN(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCk6BG.VVd5QDHeader()
   if self.VVgnGu:
    headers["Authorization"] = "Bearer %s" % self.VVgnGu
   if useCookies : cookies = {"mac": self.VV89kz, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok: return res, ""
   else  : err = "Err-%d : %s" % (res.status_code, res.reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVwCgh(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCk6BG.VVd5QDHeader(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVd5QDHeader():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVJERM(host, mac, tType, action, keysList=[]):
  myPortal = CCk6BG()
  ok = myPortal.VV4GkT(host, mac)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVqelk(VVPeMj=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s/server/load.php?type=%s&action=%s" % (host, tType, action)
  res, err = myPortal.VVcssN(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VV1gW8(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VV1gW8(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVPeMjor(self, err, title="Portal Browser"):
  FFsqiC(self, str(err), title=title)
 def VVVRGT(self, mode):
  if   mode in ("itv"  , CCvDyD.VVHG1p , CCvDyD.VVmSaS)  : return "Live"
  elif mode in ("vod"  , CCvDyD.VVwgVe , CCvDyD.VVGamb)  : return "VOD"
  elif mode in ("series" , CCvDyD.VVcyAE , CCvDyD.VVAbJ6) : return "Series"
  else                          : return "IPTV"
 def VVPM5r(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVVRGT(mode), searchName)
 def VVXeT7(self, catchup=False):
  VVVLxj = []
  VVVLxj.append(("Live"    , "live"  ))
  VVVLxj.append(("VOD"    , "vod"   ))
  VVVLxj.append(("Series"   , "series"  ))
  if catchup:
   VVVLxj.append(VVQP0R)
   VVVLxj.append(("Catchup TV" , "catchup"  ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Account Info." , "accountInfo" ))
  return VVVLxj
 @staticmethod
 def VVqUEx(decodedUrl):
  m3u_Url = ""
  p = CCk6BG()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVnA3J(decodedUrl)
  if valid:
   ok = p.VV4GkT(host, mac, VVPeMj=False)
   if ok:
    m3u_Url, err = p.VVGUew(isPhp=False, VVPeMj=False)
    span = iSearch(r".+ch\/(.+)_", decodedUrl, IGNORECASE)
    if span:
     m3u_Url += span.group(1)
  return m3u_Url
 @staticmethod
 def VVv2o9(decodedUrl):
  p = CCk6BG()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVnA3J(decodedUrl)
  if valid:
   ok = p.VV4GkT(host, mac, VVPeMj=False)
   if ok:
    try:
     chUrl = p.VVXysD(mode, chCm, epNum, epId)
     return FFzKg9(chUrl)
    except Exception as e:
     pass
  return ""
class CCe8Ax(CCk6BG):
 def __init__(self):
  CCk6BG.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVyx1g(self, refCode, chName, decodedUrl, iptvRef):
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVnA3J(decodedUrl)
  if valid:
   if self.VV4GkT(host, mac, VVPeMj=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVQv5i(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVXysD(self.mode, self.chCm, self.epNum, self.epId)
  except:
   pass
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = self.refCode + chUrl.strip() + ":" + self.chName
  newIptvRef = self.VVADAv(chUrl)
  if newIptvRef:
   success = self.VVzbXg(self.iptvRef, newIptvRef)
   if passedSELF:
    FFIFfg(passedSELF, newIptvRef, VVb10q=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFIFfg(self, newIptvRef, VVb10q=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VVADAv(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVzbXg(self, oldCode, newCode):
  bPath = FFfmhs()
  if bPath:
   txt = FFb1Rx(bPath)
   if oldCode in txt:
    txt = txt.replace(oldCode, newCode)
    with open(bPath, "w") as f:
     f.write(txt)
    FFOdGC()
    return True
  return False
class CCGPmc(CCe8Ax):
 def __init__(self, passedSession):
  CCe8Ax.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.starttime  = iTime()
  self.timer1   = eTimer()
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVPt6F, iPlayableService.evEOF: self.VVf3u3, iPlayableService.evEnd: self.VVILtB})
  except:
   pass
 def VVPt6F(self):
  self.starttime = iTime()
 def VVf3u3(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.starttime) > 2:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self.passedSession, isFromSession=True)
    if iptvRef and not FFSZwx(decodedUrl):
     CCpYFz(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
 def VVILtB(self):
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVyS5D)
  except:
   self.timer1.callback.append(self.VVyS5D)
  self.timer1.start(100, True)
 def VVyS5D(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self.passedSession, isFromSession=True)
  valid = False
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if not ref == self.lastRef:
     valid = self.VVyx1g(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if not CCwb6Z.VVDGB5:
       self.VVQv5i(self.passedSession, isFromSession=True)
class CCfOPf():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.adultWords  = ("adult", "sex", "porn", "xxx", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.nameTagPatt = r"\s*[(|:].*[)|:](.+)|\s*(?:[^a-z]+:)*(.+)"
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
 def VVnLmr(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCvDyD.VVM6KE(name):
   return CCvDyD.VV5NS4(name)
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    name = span.group(1) or span.group(2)
  return name.strip() or name
 def VV6boC(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  span = iSearch(self.nameTagPatt, name)
  if span:
   name = span.group(1) or span.group(2)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVYXR2(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  else:
   return name.strip()
 def VVyKwD(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVk9gU(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCPIXA(CCk6BG):
 def __init__(self):
  CCk6BG.__init__(self)
 def VVzQ6U(self):
  if CCPIXA.VV0lgC(self):
   FF6Ue4(self, self.VVoU3s, title="Searching ...")
 def VVwShq(self, winSession, url, mac):
  if CCPIXA.VV0lgC(self):
   if self.VV4GkT(url, mac):
    FF6Ue4(winSession, self.VVUwhM, title="Checking Server ...")
   else:
    FFsqiC(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVoU3s(self):
  path = CCvDyD.VVBfHn()
  lines = FFstFz('find %s %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % (path, FFpWOv(1)))
  if lines:
   lines.sort()
   VVVLxj = []
   for line in lines:
    VVVLxj.append((line, line))
   OKBtnFnc = self.VVqbat
   VVFM2s = ("Delete File", boundFunction(self.VV5UV4, boundFunction(FF6Ue4, self, self.VVoU3s, title="Searching ...")))
   FFfsxJ(self, None, title="Select Portals File", VVVLxj=VVVLxj, width=1200, OKBtnFnc=OKBtnFnc, VVFM2s=VVFM2s)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFsqiC(self, 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt)
 def VV5UV4(self, cbFnc, VVVpUgObj, path):
  FFmhMd(self, boundFunction(self.VV4QAL, cbFnc, VVVpUgObj, path), "Delete this file ?\n\n%s" % path)
 def VV4QAL(self, cbFnc, VVVpUgObj, path):
  os.system(FFnz2p("rm -f '%s'" % path))
  VVVpUgObj.cancel()
  cbFnc()
 def VVqbat(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = FFoqLf(path, self)
   if enc == -1:
    return
   self.session.open(CCdrie, barTheme=CCdrie.VV5tD6
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VVf0hn, path, enc)
       , VVNtvf = boundFunction(self.VV4G0g, menuInstance, path))
 def VVf0hn(self, path, enc, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  progBarObj.VVQkW1(totLines)
  progBarObj.VV86go = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVeaD2(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip() or "-"
     host = self.VVQ9Kx(url)
     mac  = self.VVIB1O(mac)
     if host and mac and progBarObj:
      progBarObj.VV86go.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip() or "-"
      host = self.VVQ9Kx(url)
      mac  = self.VVIB1O(mac)
      if host and mac and not mac.startswith("AC") and progBarObj:
       progBarObj.VV86go.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VV4G0g(self, menuInstance, path, VV0mDv, VV86go, threadCounter, threadTotal, threadErr):
  title = "Portals List File"
  if VV86go:
   VV5eNi  = ("Home Menu", FF0lEm, [])
   VVa6E6  = None #("Check & Filter" , boundFunction(self.filterPortalAuthorizedServers, path), [])
   VV3VnJ = ("Edit File" , boundFunction(self.VVPgSg, path) , [])
   VVgwCo = ("Open as M3U", self.VViXkM     , [])
   VV0k9j  = ("Select"  , self.VVwShq_fromMacFiles   , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVOhM5  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVV80v = FFoSxq(self, None, title=title, header=header, VVprx2=VV86go, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=26, VV0k9j=VV0k9j, VV5eNi=VV5eNi, VVgwCo=VVgwCo, VV3VnJ=VV3VnJ, VVa6E6=VVa6E6, VVkTTr="#0a001122", VVDVtL="#0a001122", VV1z5Z="#0a001122", VVps2K="#00004455", VVNERz="#0a333333", VVJsTV="#11331100", VV13Vm=True, searchCol=1)
   if not VV0mDv:
    FFlf8A(VVV80v, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VV0mDv:
    FFsqiC(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VViXkM(self, VVV80v, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  FF6Ue4(VVV80v, boundFunction(self.VVOChr, VVV80v, host, mac), title="Checking Server ...")
 def VVOChr(self, VVV80v, host, mac):
  p = CCk6BG()
  m3u_Url = ""
  ok = p.VV4GkT(host, mac, VVPeMj=False)
  err = ""
  if ok:
   m3u_Url, err = p.VVGUew(VVPeMj=False)
  title = "Browsing M3U Server from Portal Data"
  if m3u_Url:
   self.VVZyl6(title, m3u_Url)
  else:
   FFsqiC(self, err or "No response from Server !", title=title)
 def VVwShq_fromMacFiles(self, VVV80v, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVwShq(VVV80v, url, mac)
 def VVPgSg(self, path, VVV80v, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCj5OR(self, path, VVNtvf=boundFunction(self.VVXUeM, VVV80v), curRowNum=rowNum)
  else    : FFPX6L(self, path)
 def VVpwEK(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFPPp4(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVUwhM(self):
  if self.VV3tPE():
   VVVLxj  = self.VVXeT7()
   OKBtnFnc = self.VVB1sc
   VV123e = ("Home Menu", FF0lEm)
   FFfsxJ(self, None, title="Portal Resources (MAC=%s)" % self.VV89kz, VVVLxj=VVVLxj, OKBtnFnc=OKBtnFnc, VV123e=VV123e)
 def VVB1sc(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FF6Ue4(menuInstance, boundFunction(self.VVz1ec, mode), title="Reading Categories ...")
   else : FF6Ue4(menuInstance, boundFunction(self.VVECIw, menuInstance, title), title="Reading Account ...")
 def VVECIw(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVtDGV(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VV89kz)
  VV5eNi  = ("Home Menu" , FF0lEm, [])
  if totCols == 2:
   VVa6E6 = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
   VVa6E6 = ("More Info.", boundFunction(self.VVbELW, menuInstance) , [])
  FFoSxq(self, None, title=title, width=1200, header=header, VVprx2=rows, VVADeP=widths, VVKTEW=26, VV5eNi=VV5eNi, VVa6E6=VVa6E6, VVkTTr="#0a00292B", VVDVtL="#0a002126", VV1z5Z="#0a002126", VVps2K="#00000000", searchCol=searchCol)
 def VVbELW(self, menuInstance, VVV80v, title, txt, colList):
  VVV80v.cancel()
  FF6Ue4(menuInstance, boundFunction(self.VVECIw, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVz1ec(self, mode):
  token, profile, tErr = self.VVqelk()
  if not token:
   return
  res, err = self.VVcssN(self.VViIAM(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CCfOPf()
     chList = tDict["js"]
     for item in chList:
      Id   = CCvDyD.VVZ0n9(item, "id"       )
      Title  = CCvDyD.VVZ0n9(item, "title"      )
      censored = CCvDyD.VVZ0n9(item, "censored"     )
      Title = processChanName.VVYXR2(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VV6ebU:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVVRGT(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVkTTr, VVDVtL, VV1z5Z, VVps2K = self.VVpPTW(mode)
   mName = self.VVVRGT(mode)
   VV0k9j   = ("Show List"   , boundFunction(self.VVORay, mode) , [])
   VV5eNi  = ("Home Menu"   , FF0lEm         , [])
   if mode in ("vod", "series"):
    VV3VnJ = ("Find in %s" % mName , boundFunction(self.VVtHTV, mode), [])
   else:
    VV3VnJ = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FFoSxq(self, None, title=title, width=1200, header=header, VVprx2=list, VVADeP=widths, VVKTEW=30, VV5eNi=VV5eNi, VV3VnJ=VV3VnJ, VV0k9j=VV0k9j, VVkTTr=VVkTTr, VVDVtL=VVDVtL, VV1z5Z=VV1z5Z, VVps2K=VVps2K)
  else:
   FFsqiC(self, "Could not get Categories from server!", title=title)
 def VV2bmc(self, mode, VVV80v, title, txt, colList):
  FF6Ue4(VVV80v, boundFunction(self.VVggyD, mode, VVV80v, title, txt, colList), title="Downloading ...")
 def VVggyD(self, mode, VVV80v, title, txt, colList):
  token, profile, tErr = self.VVqelk()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVcssN(self.VVhF0L(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCvDyD.VVZ0n9(item, "id"    )
      actors   = CCvDyD.VVZ0n9(item, "actors"   )
      added   = CCvDyD.VVZ0n9(item, "added"   )
      age    = CCvDyD.VVZ0n9(item, "age"   )
      category_id  = CCvDyD.VVZ0n9(item, "category_id" )
      description  = CCvDyD.VVZ0n9(item, "description" )
      director  = CCvDyD.VVZ0n9(item, "director"  )
      genres_str  = CCvDyD.VVZ0n9(item, "genres_str"  )
      name   = CCvDyD.VVZ0n9(item, "name"   )
      path   = CCvDyD.VVZ0n9(item, "path"   )
      screenshot_uri = CCvDyD.VVZ0n9(item, "screenshot_uri" )
      series   = CCvDyD.VVZ0n9(item, "series"   )
      cmd    = CCvDyD.VVZ0n9(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VV0k9j  = ("Play"    , boundFunction(self.VVPUGI, mode)       , [])
   VVEgOz = (""     , boundFunction(self.VVkysN, mode)     , [])
   VV5eNi = ("Home Menu"   , FF0lEm               , [])
   VVgwCo = ("Download Options" , boundFunction(self.VVaKT3, mode, "sp", seriesName) , [])
   VV3VnJ = ("Add ALL to Bouquet" , boundFunction(self.VVLbvE, mode, seriesName)  , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVOhM5  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFoSxq(self, None, title=seriesName, width=1200, header=header, VVprx2=list, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=26, VV5eNi=VV5eNi, VVgwCo=VVgwCo, VV3VnJ=VV3VnJ, VV0k9j=VV0k9j, VVEgOz=VVEgOz, VVkTTr="#0a00292B", VVDVtL="#0a002126", VV1z5Z="#0a002126", VVps2K="#00000000")
  else:
   FFsqiC(self, "Could not get Episodes from server!", title=seriesName)
 def VVtHTV(self, mode, VVV80v, title, txt, colList):
  VVVLxj = []
  VVVLxj.append(("Keyboard"  , "manualEntry"))
  VVVLxj.append(("From Filter" , "fromFilter"))
  FFfsxJ(self, boundFunction(self.VVDeOR, VVV80v, mode), title="Input Type", VVVLxj=VVVLxj, width=400)
 def VVDeOR(self, VVV80v, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFD8qa(self, boundFunction(self.VVajHR, VVV80v, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCicDe(self)
    filterObj.VVIfac(boundFunction(self.VVajHR, VVV80v, mode))
 def VVajHR(self, VVV80v, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VVPM5r(mode, searchName)
   if len(searchName) < 3:
    FFsqiC(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CCfOPf()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVyKwD([searchName]):
     FFsqiC(self, processChanName.VVk9gU(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VVw7VE(mode, searchName, "", searchName)
 def VVORay(self, mode, VVV80v, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVw7VE(mode, bName, catID, "")
 def VVw7VE(self, mode, bName, catID, searchName):
  self.session.open(CCdrie, barTheme=CCdrie.VV5tD6
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVD1fD, mode, bName, catID, searchName)
      , VVNtvf = boundFunction(self.VVcDa7, mode, bName, catID, searchName))
 def VVcDa7(self, mode, bName, catID, searchName, VV0mDv, VV86go, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVPM5r(mode, searchName)
  else   : title = "%s : %s" % (self.VVVRGT(mode), bName)
  if VV86go:
   VVgwCo = None
   VV3VnJ = None
   if mode == "series":
    VVkTTr, VVDVtL, VV1z5Z, VVps2K = self.VVpPTW("series2")
    VV0k9j  = ("Episodes", boundFunction(self.VV2bmc, mode) , [])
   else:
    VVkTTr, VVDVtL, VV1z5Z, VVps2K = self.VVpPTW("")
    VV0k9j  = ("Play"    , boundFunction(self.VVPUGI, mode)           , [])
    VV3VnJ = ("Add ALL to Bouquet" , boundFunction(self.VVLbvE, mode, bName)       , [])
    VVgwCo = ("Download Options" , boundFunction(self.VVaKT3, mode, "vp" if mode == "vod" else "", "") , [])
   VVEgOz = (""      , boundFunction(self.VVnNL7, mode)          , [])
   VV5eNi = ("Home Menu"    , FF0lEm                   , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVOhM5  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , CENTER)
   VVV80v = FFoSxq(self, None, title=title, header=header, VVprx2=VV86go, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=26, VV5eNi=VV5eNi, VVgwCo=VVgwCo, VV3VnJ=VV3VnJ, VV0k9j=VV0k9j, VVEgOz=VVEgOz, VVkTTr=VVkTTr, VVDVtL=VVDVtL, VV1z5Z=VV1z5Z, VVps2K=VVps2K, VV13Vm=True, searchCol=1)
   if not VV0mDv:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVV80v.VVdQQD(VVV80v.VVpfHE() + tot)
    if threadErr: FFlf8A(VVV80v, "Error while reading !", 2000)
    else  : FFlf8A(VVV80v, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFsqiC(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFsqiC(self, "Could not get list from server !", title=title)
 def VVnNL7(self, mode, VVV80v, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFULTs(self, fncMode=CCazlH.VVG0Sz, portalHost=self.VVynMQ, portalMac=self.VV89kz, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVLa8l(mode, VVV80v, title, txt, colList)
 def VVkysN(self, mode, VVV80v, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFejnb(colList[10], VV6AHZ)
  txt += "Description:\n%s" % FFejnb(colList[11], VV6AHZ)
  self.VVLa8l(mode, VVV80v, title, txt, colList)
 def VVLa8l(self, mode, VVV80v, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV2feX(mode, colList)
  refCode, chUrl = self.VVnfuc(self.VVynMQ, self.VV89kz, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFULTs(self, fncMode=CCazlH.VVwCPx, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVD1fD(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile, tErr = self.VVqelk()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VV86go, total_items, max_page_items, err = self.VVN59m(mode, catID, 1, 1, searchName)
   if progBarObj.isCancelled:
    return
   if progBarObj.VV86go and total_items > -1 and max_page_items > -1:
    progBarObj.VVQkW1(total_items)
    progBarObj.VVeaD2(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVN59m(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VVW1q3()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VV86go += list
      progBarObj.VVeaD2(len(list), True)
  except:
   pass
 def VVN59m(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVfWPu(mode, searchName, page)
  else   : url = self.VVzzNw(mode, catID, page)
  res, err = self.VVcssN(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVpxF9(CCvDyD.VVZ0n9(item, "total_items" ))
     max_page_items = self.VVpxF9(CCvDyD.VVZ0n9(item, "max_page_items" ))
     processChanName = CCfOPf()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCvDyD.VVZ0n9(item, "id"    )
      name   = CCvDyD.VVZ0n9(item, "name"   )
      tv_genre_id  = CCvDyD.VVZ0n9(item, "tv_genre_id" )
      number   = CCvDyD.VVZ0n9(item, "number"   ) or str(counter)
      logo   = CCvDyD.VVZ0n9(item, "logo"   )
      screenshot_uri = CCvDyD.VVZ0n9(item, "screenshot_uri" )
      cmd    = CCvDyD.VVZ0n9(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      if mode == "itv" and not cmdStr in cmd:
       span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
      picon   = logo or screenshot_uri
      counter += 1
      name = processChanName.VVnLmr(name)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVLbvE(self, mode, bName, VVV80v, title, txt, colList):
  FF6Ue4(VVV80v, boundFunction(self.VVgL8v, mode, bName, VVV80v, title, txt, colList), title="Adding Channels ...")
 def VVgL8v(self, mode, bName, VVV80v, title, txt, colList):
  bNameFile = CCvDyD.VV7v6Z_forBouquet(bName)
  num  = 0
  path = VVRcPg + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVRcPg + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVV80v.VVSUDw():
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV2feX(mode, row)
    refCode, chUrl = self.VVnfuc(self.VVynMQ, self.VV89kz, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
    totChange += 1
  FFO7ny(os.path.basename(path))
  self.VVmBIu(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVpxF9(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVPUGI(self, mode, VVV80v, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV2feX(mode, colList)
  refCode, chUrl = self.VVnfuc(self.VVynMQ, self.VV89kz, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVM6KE(chName):
   FFlf8A(VVV80v, "This is a marker!", 300)
  else:
   FF6Ue4(VVV80v, boundFunction(self.VVS0R5, mode, VVV80v, chUrl), title="Playing ...")
 def VVS0R5(self, mode, VVV80v, chUrl):
  FFIFfg(self, chUrl, VVb10q=False)
  self.session.open(CCwb6Z, portalTableParam=(self, VVV80v, mode))
 def VVbRZt(self, mode, VVV80v, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV2feX(mode, colList)
  refCode, chUrl = self.VVnfuc(self.VVynMQ, self.VV89kz, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VV2feX(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VV0lgC(SELF):
  try:
   import requests
   return True
  except:
   FFmhMd(SELF, boundFunction(CCPIXA.VVjGUv, SELF), 'This requires the library "Requests".\n\nInstall it now ?')
   return False
 @staticmethod
 def VVjGUv(SELF):
  from sys import version_info
  cmdUpd = FF6GOT(VVG8HC, "")
  if cmdUpd:
   cmdInst = FFvshm(VVH8bp, "python-requests")
   if version_info[0] >= 3:
    cmdInst = cmdInst.replace("python-", "python3-")
   cmd = cmdUpd + " && " + cmdInst
   FFyzyQ(SELF, cmd, checkNetAccess=True, title="Installing Requests Library")
  else:
   FFEmMJ(SELF)
class CCvDyD(Screen, CCPIXA):
 VVFxtA    = 0
 VVpHZk    = 1
 VVaLnw    = 2
 VVpxDL    = 3
 VValCO     = 4
 VV2eJM     = 5
 VVGYCW     = 6
 VVOLWA     = 7
 VVjmui      = 8
 VVrjAL     = 9
 VVGr3r     = 10
 VVlqNA     = 11
 VV7gCS     = 12
 VVqd7M      = 13
 VVwtSM      = 14
 VVH0Ug      = 15
 VVotNJ      = 16
 VVDrou      = 17
 VV2y1R    = 0
 VVHG1p   = 1
 VVwgVe   = 2
 VVcyAE   = 3
 VVzAZQ  = 4
 VVDQVF  = 5
 VVmSaS   = 6
 VVGamb   = 7
 VVAbJ6  = 8
 VVSyZu  = 9
 VViwNn  = 10
 VVs8bI = 0
 VVKQIw = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFO5bN(VVdurn, 1000, 1000, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.m3uOrM3u8File  = m3uOrM3u8File
  self.m3uOrM3u8BName  = ""
  self.VVV80v  = None
  self.tableTitle   = "IPTV Channels List"
  self.VVjAfdData  = {}
  self.lastFindIptvName = ""
  CCPIXA.__init__(self)
  VVVLxj= self.VVrhW7()
  FF4gq5(self, title="IPTV", VVVLxj=VVVLxj)
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  FFRtL9(self["myMenu"])
  FFqAhz(self)
  FFGbn6(self)
  if self.m3uOrM3u8File:
   self.VVquoT(self.m3uOrM3u8File)
 def VVrhW7(self):
  files = self.VVvEmR()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"        , "VVjAfd_fromPlayList" ))
  tList.append(("IPTV Server Browser (from Portal List)"        , "VVjAfd_fromMac"  ))
  tList.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)"    , "VVjAfd_fromM3u"  ))
  qUrl, iptvRef = self.VVa2zU()
  if qUrl:
   tList.append(("IPTV Server Browser (from Current Channel)"      , "VVjAfd_fromCurrChan" ))
  VVVLxj = []
  if files:
   if self.VVV80v:
    VVVLxj.append(("Add Current List to a New Bouquet"      , "VVcpEr"  ))
    VVVLxj.append(VVQP0R)
    VVVLxj.append(("Change Current List References to Unique Codes"   , "VVFaa6"))
    VVVLxj.append(("Change Current List References to Identical Codes"  , "VVjJ2C_rows" ))
    VVVLxj.append(VVQP0R)
    VVVLxj.append(("Share Reference with Satellite/C/T Service (manual entry)", "VVMIBS"   ))
    VVVLxj.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VVnrn9"   ))
   else:
    VVVLxj += tList
    VVVLxj.append(VVQP0R)
    VVVLxj.append(("M3U/M3U8 Channels Browser"        , "VVkkcO"   ))
    VVVLxj.append(("Local IPTV Channels"          , "iptvTable_all"   ))
    if qUrl:
     VVVLxj.append(VVQP0R)
     VVVLxj.append(("Update Current Bouquet EPG (from IPTV Server)"  , "refreshIptvEPG"   ))
    VVVLxj.append(VVQP0R)
    VVVLxj.append(("Count Available IPTV Channels"       , "VVa0ej"    ))
    VVVLxj.append(("Check Reference Codes Format"        , "VVg1yj"   ))
    VVVLxj.append(("Check System Acceptable Reference Types"     , "VVw1IA"   ))
    VVVLxj.append(VVQP0R)
    VVVLxj.append(("Share Reference with Sat./C/T (Only Matching Names)"  , "VVNGd2" ))
    VVVLxj.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VV3qP3"  ))
    VVVLxj.append(("Change ALL References to Unique Codes"     , "VV4JLS" ))
    VVVLxj.append(("Change ALL References to Identical Codes"     , "VVjJ2C_all" ))
  if not self.VVV80v:
   if not files:
    VVVLxj += tList
   if not CC5fZh.VVCMkz():
    VVVLxj.append(VVQP0R)
    VVVLxj.append(("Download Manager"           , "dload_stat"    ))
  return VVVLxj
 def VVTTmg(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVcpEr"   : FFD8qa(self, self.VVcpEr, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVFaa6" : FFmhMd(self, boundFunction(FF6Ue4, self.VVV80v, self.VVFaa6 ), "Change Current List References to Unique Codes ?")
   elif item == "VVjJ2C_rows" : FFmhMd(self, boundFunction(FF6Ue4, self.VVV80v, self.VVjJ2C   ), "Change Current List References to Identical Codes ?")
   elif item == "VVMIBS"   : self.VVMIBS(tTitle)
   elif item == "VVnrn9"   : self.VVnrn9(tTitle)
   elif item == "VVjAfd_fromPlayList" : FF6Ue4(self, self.VVbBTK, title=title)
   elif item == "VVjAfd_fromM3u"  : FF6Ue4(self, boundFunction(self.VVCTSv, 0), title=title)
   elif item == "VVjAfd_fromMac"  : self.VVzQ6U()
   elif item == "VVjAfd_fromCurrChan" : self.VVwShq_fromCurrChan()
   elif item == "VVkkcO"   : self.VVkkcO()
   elif item == "iptvTable_live"   : FF6Ue4(self, boundFunction(self.VV6QVb, self.VVOLWA ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FF6Ue4(self, boundFunction(self.VV6QVb, self.VVFxtA) , title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VVNaM4()
   elif item == "VVa0ej"    : FF6Ue4(self, self.VVa0ej)
   elif item == "VVg1yj"    : FF6Ue4(self, self.VVg1yj)
   elif item == "VVw1IA"   : FF6Ue4(self, self.VVw1IA)
   elif item == "VVNGd2"  : FFmhMd(self, boundFunction(FF6Ue4, self, self.VVNGd2 ), "Continue ?")
   elif item == "VV3qP3"  : self.VV3qP3()
   elif item == "VV4JLS" : FFmhMd(self, boundFunction(FF6Ue4, self, self.VV4JLS ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVjJ2C_all" : FFmhMd(self, boundFunction(FF6Ue4, self, self.VVjJ2C  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "dload_stat"    : CC5fZh.VVPI3i(self)
   elif item == "VVCSRu"   : FF6Ue4(self, boundFunction(CC7tYb.VVCSRu, self))
 def VVkkcO(self):
  if CCPIXA.VV0lgC(self):
   FF6Ue4(self, boundFunction(self.VVCTSv, 1), title="Searching ...")
 def VV13Bz(self):
  global VVlddb
  VVlddb = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVTTmg(item)
 def VV6QVb(self, mode):
  VV5tha = self.VVN5FY(mode)
  if VV5tha:
   VVgwCo = ("Current Service", self.VVj0yf  , [])
   VV3VnJ = ("Options"  , self.VV8GP3    , [])
   VVa6E6 = ("Filter"   , self.VVpErx    , [])
   VV0k9j  = ("Play"   , boundFunction(self.VVP4aV) , [])
   VVEgOz = (""    , self.VVhPXL     , [])
   VVITUu = (""    , self.VVmSfD      , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVOhM5  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFoSxq(self, None, header=header, VVprx2=VV5tha, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=26
     , VV0k9j=VV0k9j, VVgwCo=VVgwCo, VV3VnJ=VV3VnJ, VVa6E6=VVa6E6, VVEgOz=VVEgOz, VVITUu=VVITUu
     , VVkTTr="#0a00292B", VVDVtL="#0a002126", VV1z5Z="#0a002126", VVps2K="#00000000", VV13Vm=True, searchCol=1)
  else:
   if mode == self.VVOLWA: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFsqiC(self, err)
 def VVmSfD(self, VVV80v, title, txt, colList):
  self.VVV80v = VVV80v
 def VV8GP3(self, VVV80v, title, txt, colList):
  VVVLxj= self.VVrhW7()
  FFfsxJ(self, self.VVTTmg, title="IPTV Tools", VVVLxj=VVVLxj)
 def VVpErx(self, VVV80v, title, txt, colList):
  VVVLxj = []
  VVVLxj.append(("All"         , "all"   ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Prefix of Selected Channel"   , "sameName" ))
  VVVLxj.append(("Suggest Words from Selected Channel" , "partName" ))
  VVVLxj.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Live TV"        , "live"  ))
  VVVLxj.append(("VOD"         , "vod"   ))
  VVVLxj.append(("Series"        , "series"  ))
  VVVLxj.append(("Uncategorised"      , "uncat"  ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Video"        , "video"  ))
  VVVLxj.append(("Audio"        , "audio"  ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("MKV"         , "MKV"   ))
  VVVLxj.append(("MP4"         , "MP4"   ))
  VVVLxj.append(("MP3"         , "MP3"   ))
  VVVLxj.append(("AVI"         , "AVI"   ))
  VVVLxj.append(("FLV"         , "FLV"   ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VV4rcR()
  if bNames:
   bNames.sort()
   VVVLxj.append(VVQP0R)
   for item in bNames:
    VVVLxj.append((item, "__b__" + item))
  filterObj = CCicDe(self)
  filterObj.VVMxGo(VVVLxj, VVVLxj, boundFunction(self.VVVV1F, VVV80v))
 def VVVV1F(self, VVV80v, item=None):
  prefix = VVV80v.VVRcVo(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVFxtA, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVpHZk , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVaLnw , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVpxDL , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVOLWA  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVjmui   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVrjAL  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVGr3r  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVlqNA  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VV7gCS  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVqd7M   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVwtSM   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVH0Ug   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVotNJ   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVDrou   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVGYCW  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VValCO  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VV2eJM  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVaLnw:
   VVVLxj = []
   chName = VVV80v.VVRcVo(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVVLxj.append((item, item))
    if not VVVLxj and chName:
     VVVLxj.append((chName, chName))
    FFfsxJ(self, boundFunction(self.VVsFQ3_partOfName, title), title="Words from Current Selection", VVVLxj=VVVLxj)
   else:
    VVV80v.VVFMww("Invalid Channel Name")
  else:
   words, asPrefix = CCicDe.VVDnY4(words)
   if not words and mode in (self.VValCO, self.VV2eJM):
    FFlf8A(self.VVV80v, "Incorrect filter", 2000)
   else:
    FF6Ue4(self.VVV80v, boundFunction(self.VVC4Fy, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVsFQ3_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FF6Ue4(self.VVV80v, boundFunction(self.VVC4Fy, self.VVaLnw, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VV5NS4(txt):
  return "#f#11ffff00#" + txt
 def VVC4Fy(self, mode, words, asPrefix, title):
  VV5tha = self.VVN5FY(mode=mode, words=words, asPrefix=asPrefix)
  if VV5tha : self.VVV80v.VVnbpo(VV5tha, title)
  else  : self.VVV80v.VVFMww("Not found")
 def VVN5FY(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VV5tha = []
  files  = self.VVvEmR()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFb1Rx(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVZ6pB = span.group(1)
    else : VVZ6pB = ""
    VVZ6pB_lCase = VVZ6pB.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVM6KE(chName): chNameMod = self.VV5NS4(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVZ6pB, chType, refCode, url)
     ok = False
     tUrl = FFzKg9(url).lower()
     if mode == self.VVFxtA       : ok = True
     elif mode == self.VVGYCW       : ok = True
     elif mode == self.VVlqNA:
      if CCvDyD.VV3VMw(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VV7gCS:
      if CCvDyD.VV3VMw(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVOLWA:
      if CCvDyD.VV3VMw(tUrl, compareType="live")  : ok = True
     elif mode == self.VVjmui:
      if CCvDyD.VV3VMw(tUrl, compareType="movie") : ok = True
     elif mode == self.VVrjAL:
      if CCvDyD.VV3VMw(tUrl, compareType="series") : ok = True
     elif mode == self.VVGr3r:
      if CCvDyD.VV3VMw(tUrl, compareType="")   : ok = True
     elif mode == self.VVqd7M:
      if CCvDyD.VV3VMw(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVwtSM:
      if CCvDyD.VV3VMw(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVH0Ug:
      if CCvDyD.VV3VMw(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVotNJ:
      if CCvDyD.VV3VMw(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVDrou:
      if CCvDyD.VV3VMw(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVpHZk:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVaLnw:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVpxDL:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VValCO:
      if words[0] == VVZ6pB_lCase:
       ok = True
     elif mode == self.VV2eJM:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VV5tha.append(row)
      chNum += 1
  if VV5tha and mode == self.VVGYCW:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VV5tha)
   for item in VV5tha:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VV5tha = newRows
  return VV5tha
 def VVcpEr(self, bName):
  if bName:
   FF6Ue4(self.VVV80v, boundFunction(self.VVvMcd, bName), title="Adding Channels ...")
 def VVvMcd(self, bName):
  num = 0
  path = VVRcPg + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVRcPg + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVV80v.VVSUDw():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FF9jRB(row[1]))
    totChange += 1
  FFO7ny(os.path.basename(path))
  self.VVmBIu(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VV3qP3(self):
  txt = "Stream Type "
  VVVLxj = []
  VVVLxj.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVVLxj.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVVLxj.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVVLxj.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVVLxj.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVVLxj.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFfsxJ(self, self.VVGGUU, title="Change Reference Types to:", VVVLxj=VVVLxj)
 def VVGGUU(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVv0KG("1"   )
   elif item == "RT_4097" : self.VVv0KG("4097")
   elif item == "RT_5001" : self.VVv0KG("5001")
   elif item == "RT_5002" : self.VVv0KG("5002")
   elif item == "RT_8192" : self.VVv0KG("8192")
   elif item == "RT_8193" : self.VVv0KG("8193")
 def VVv0KG(self, rType):
  FFmhMd(self, boundFunction(FF6Ue4, self, boundFunction(self.VVpay0, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVpay0(self, refType):
  totChange = 0
  files  = self.VVvEmR()
  if files:
   for path in files:
    txt = FFb1Rx(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFO7ny(os.path.basename(path))
  self.VVmBIu(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVa0ej(self):
  totFiles = 0
  files  = self.VVvEmR()
  if files:
   totFiles = len(files)
  totChans = 0
  VV5tha = self.VVN5FY()
  if VV5tha:
   totChans = len(VV5tha)
  FFItCL(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVg1yj(self):
  files  = self.VVvEmR()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFb1Rx(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVOn4X
   else    : color = VVKSBp
   totInvalid = FFejnb(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFejnb("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFItCL(self, txt, title="Check IPTV References")
 def VVw1IA(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVRcPg + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFO7ny(os.path.basename(path))
  FFOdGC()
  acceptedList = []
  VVyW8I = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVyW8I:
   VVlNoi = FFkzTC(VVyW8I)
   if VVlNoi:
    for service in VVlNoi:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVRcPg + userBName
  bFile = VVRcPg + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFnz2p("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFnz2p("rm -f '%s'" % path)
  os.system(cmd)
  FFOdGC()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVOn4X
    else     : res, color = "No" , VVKSBp
    txt += "    %s\t: %s\n" % (item, FFejnb(res, color))
   FFItCL(self, txt, title=title)
  else:
   txt = FFsqiC(self, "Could not complete the test on your system!", title=title)
 def VVNGd2(self):
  lameDbChans = CC7tYb.VVVqOu(self, CC7tYb.VVzq6L)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVvEmR():
    toSave = False
    txt = FFb1Rx(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVmBIu(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFsqiC(self, 'No channels in "lamedb" !')
 def VV4JLS(self):
  files  = self.VVvEmR()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FF3tpP(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVHgeA(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVmBIu(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVFaa6(self):
  iptvRefList = []
  files  = self.VVvEmR()
  if files:
   for path in files:
    txt = FFb1Rx(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVV80v.VVbJ8P(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVHgeA(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVvEmR()
  if files:
   for path in files:
    lines = FF3tpP(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVmBIu(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVHgeA(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVjJ2C(self):
  list = None
  if self.VVV80v:
   list = []
   for row in self.VVV80v.VVSUDw():
    list.append(row[4] + row[5])
  files  = self.VVvEmR()
  totChange = 0
  if files:
   for path in files:
    lines = FF3tpP(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVmBIu(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVmBIu(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFOdGC()
   if refreshTable and self.VVV80v:
    VV5tha = self.VVN5FY()
    if VV5tha and self.VVV80v:
     self.VVV80v.VVnbpo(VV5tha, self.tableTitle)
     self.VVV80v.VVFMww(txt)
   FFItCL(self, txt, title=title)
  else:
   FFEf0P(self, "No changes.")
 def VV4rcR(self):
  files = self.VVvEmR()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with open(path, "r") as f:
     span = iSearch(r"#NAME\s+(.*)", f.readline(), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VVw19Z = FFGqYY()
    if VVw19Z:
     for b in VVw19Z:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVvEmR(self):
  return CCvDyD.VVuQqZ(self)
 @staticmethod
 def VVuQqZ(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVRcPg + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFb1Rx(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVhPXL(self, VVV80v, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFzKg9(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFULTs(self, fncMode=CCazlH.VV0FAc, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VV8nYY(self, VVV80v, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVP4aV(self, VVV80v, title, txt, colList):
  chName, chUrl = self.VV8nYY(VVV80v, colList)
  self.VVK9hI(VVV80v, chName, chUrl, "localIptv")
 def VViEA6(self, mode, VVV80v, colList):
  chName, chUrl, picUrl, refCode = self.VVXUdN(mode, colList)
  return chName, chUrl
 def VVzZQ4(self, mode, VVV80v, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVXUdN(mode, colList)
  self.VVK9hI(VVV80v, chName, chUrl, mode)
 def VVK9hI(self, VVV80v, chName, chUrl, playerFlag):
  chName = FF9jRB(chName)
  if self.VVM6KE(chName):
   FFlf8A(VVV80v, "This is a marker!", 300)
  else:
   FF6Ue4(VVV80v, boundFunction(self.VV4Qt5, VVV80v, chUrl, playerFlag), title="Playing ...")
 def VV4Qt5(self, VVV80v, chUrl, playerFlag):
  FFIFfg(self, chUrl, VVb10q=False)
  self.session.open(CCwb6Z, portalTableParam=(self, VVV80v, playerFlag))
 @staticmethod
 def VVM6KE(chName):
  mark = ("--", "__", "==", "##", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVj0yf(self, VVV80v, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self)
  if refCode:
   bName = FFFJXz()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFcakO(refCode, origUrl, chName) }
   VVV80v.VVH29i_partial(colDict, VVPeMj=True)
 def VVCTSv(self, m3uMode):
  path = CCvDyD.VVBfHn()
  lines = FFstFz("find %s %s -iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'" % (path, FFpWOv(1)))
  if lines:
   lines.sort()
   VVVLxj = []
   for line in lines:
    VVVLxj.append((line, line))
   if m3uMode == self.VVs8bI:
    title = "Browse Server from M3U URLs"
    VVtOG5 = ("All to Playlist", self.VVGAMc)
   else:
    title = "M3U/M3U8 Channels Browser"
    VVtOG5 = None
   OKBtnFnc = boundFunction(self.VVeUOt, m3uMode, title)
   VV8yYG = ("Show Full Path", self.VVJUBv)
   VVFM2s = ("Delete File", boundFunction(self.VV5UV4, boundFunction(FF6Ue4, self, boundFunction(self.VVCTSv, m3uMode), title="Searching ...")))
   FFfsxJ(self, None, title=title, VVVLxj=VVVLxj, width=1200, OKBtnFnc=OKBtnFnc, VV8yYG=VV8yYG, VVFM2s=VVFM2s, VVtOG5=VVtOG5)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n\n%s" % path
   FFsqiC(self, 'No ".m3u" files found %s' % txt)
 def VVJUBv(self, VVVpUgObj, url):
  FFItCL(self, url, title="Full Path")
 def VVeUOt(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == self.VVs8bI:
    FF6Ue4(menuInstance, boundFunction(self.VV1rV9, title, path))
   else:
    FF6Ue4(menuInstance, boundFunction(self.VVquoT, path))
 def VVquoT(self, srcPath):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFb1Rx(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  processChanName = CCfOPf()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VVtCbD(propLine, "group-title") or "-"
   if not group == "-" and processChanName.VVnLmr(group):
    groups.add(group)
  VV5tha = []
  if len(groups) > 0:
   title = "Groups"
   for group in groups:
    VV5tha.append((group, group))
   VV5tha.append(("ALL", ""))
   VV5tha.sort(key=lambda x: x[0].lower())
   VVjFfT = self.VVouOF
   VV0k9j  = ("Select" , boundFunction(self.VVEIuI, srcPath), [])
   widths   = (100  , 0)
   VVOhM5  = (LEFT  , LEFT)
   FFoSxq(self, None, title=title, width= 800, header=None, VVprx2=VV5tha, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=30, VV0k9j=VV0k9j, VVjFfT=VVjFfT
     , VVkTTr="#11110022", VVDVtL="#11110022", VV1z5Z="#11110022", VVps2K="#00444400")
  else:
   txt = FFb1Rx(srcPath)
   self.VVeK7s(txt, filterGroup="")
 def VVEIuI(self, srcPath, VVV80v, title, txt, colList):
  group = colList[1]
  txt = FFb1Rx(srcPath)
  self.VVeK7s(txt, filterGroup=group)
 def VVeK7s(self, txt, filterGroup=""):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = "Group : %s" % (filterGroup or "ALL")
  if lst:
   self.session.open(CCdrie, barTheme=CCdrie.VV5tD6
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VVVjGF, lst, filterGroup)
       , VVNtvf = boundFunction(self.VVRExs, title, bName))
  else:
   self.VVK8a5("No valid lines found !", title)
 def VVVjGF(self, lst, filterGroup, progBarObj):
  progBarObj.VV86go = []
  progBarObj.VVQkW1(len(lst))
  processChanName = CCfOPf()
  num = 0
  for cols in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVeaD2(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VVtCbD(propLine, "tvg-logo")
   group = self.VVtCbD(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if group and not processChanName.VVnLmr(group) : skip = True
    if chName and not processChanName.VVnLmr(chName): skip = True
    if not skip and progBarObj:
     num += 1
     progBarObj.VV86go.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if progBarObj:
   progBarObj.VVoRkl_forcedUpdate("Loading %d Channels" % len(progBarObj.VV86go))
 def VVRExs(self, title, bName, VV0mDv, VV86go, threadCounter, threadTotal, threadErr):
  if VV86go:
   VVjFfT = self.VVouOF
   VV0k9j  = ("Select"    , boundFunction(self.VVp1Qf, title) , [])
   VVEgOz = (""     , self.VV6Zlk         , [])
   VVgwCo = ("Download PIcons" , self.VVhdbu        , [])
   VV3VnJ = ("Add ALL to Bouquet" , boundFunction(self.VVTsuk, bName) , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVOhM5  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFoSxq(self, None, title=title, header=header, VVprx2=VV86go, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=28, VV0k9j=VV0k9j, VVjFfT=VVjFfT, VVEgOz=VVEgOz, VVgwCo=VVgwCo, VV3VnJ=VV3VnJ, VV13Vm=True, searchCol=1
     , VVkTTr="#0a00192B", VVDVtL="#0a00192B", VV1z5Z="#0a00192B", VVps2K="#00000000")
  else:
   self.VVK8a5("No valid lines found !", title)
 def VVhdbu(self, VVV80v, title, txt, colList):
  self.VVUIfm(VVV80v, "m3u/m3u8")
 def VVTsuk(self, bName, VVV80v, title, txt, colList):
  FF6Ue4(VVV80v, boundFunction(self.VVbaN7, bName, VVV80v), title="Adding Channels ...")
 def VVbaN7(self, bName, VVV80v):
  bNameFile = CCvDyD.VV7v6Z_forBouquet(bName)
  num  = 0
  path = VVRcPg + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVRcPg + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   catID = "33"
   rowNum = 0
   for row in VVV80v.VVSUDw():
    chName = row[1].strip()
    url  = row[3].strip()
    chUrl = self.VVkfak(rowNum, url, chName)
    rowNum += 1
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
    totChange += 1
  FFO7ny(os.path.basename(path))
  self.VVmBIu(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVkfak(self, rowNum, url, chName):
  refCode = self.VVb22U(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFvOlg(url), chName)
  return chUrl
 def VVb22U(self, rowNum, url, chName):
  span = iSearch(r"\/(\d{2,})", url, IGNORECASE)
  if span : stID = span.group(1)
  else : stID = "444"
  catID = "333"
  chNum = str(rowNum + 1)
  refCode = self.VVhAn0(catID, stID, chNum)
  return refCode
 def VVtCbD(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVp1Qf(self, Title, VVV80v, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FF6Ue4(VVV80v, boundFunction(self.VVNwAb, Title, VVV80v, colList), title="Checking Server ...")
  else:
   self.VV9EpD(VVV80v, url, chName)
 def VVNwAb(self, title, VVV80v, colList):
  if not CCPIXA.VV0lgC(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCk6BG.VVwCgh(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVVLxj = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCvDyD.VVpWHe(url, fPath)
     VVVLxj.append((resol, fullUrl))
    if VVVLxj:
     if len(VVVLxj) > 1:
      FFfsxJ(self, boundFunction(self.VVUQlD, VVV80v, chName), VVVLxj=VVVLxj, title="Resolution", VVZFmG=True, VVoQKF=True)
     else:
      self.VV9EpD(VVV80v, VVVLxj[0][1], chName)
    else:
     self.VVPeMjor("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVeK7s(txt, filterGroup="")
      return
    self.VV9EpD(VVV80v, url, chName)
   else:
    self.VVK8a5("Cannot process this channel !", title)
  else:
   self.VVK8a5(err, title)
 def VVUQlD(self, VVV80v, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VV9EpD(VVV80v, resolUrl, chName)
 def VV9EpD(self, VVV80v, url, chName):
  FF6Ue4(VVV80v, boundFunction(self.VVl1kd, VVV80v, url, chName), title="Playing ...")
 def VVl1kd(self, VVV80v, url, chName):
  chUrl = self.VVkfak(VVV80v.VVDRvM(), url, chName)
  FFIFfg(self, chUrl, VVb10q=False)
  self.session.open(CCwb6Z, portalTableParam=(self, VVV80v, "m3u/m3u8"))
 def VVCxbt(self, VVV80v, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVkfak(VVV80v.VVDRvM(), url, chName)
  return chName, chUrl
 def VV6Zlk(self, VVV80v, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFULTs(self, fncMode=CCazlH.VV0FAc, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVK8a5(self, err, title):
  FFsqiC(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVouOF(self, VVV80v):
  if self.m3uOrM3u8File:
   self.close()
  VVV80v.cancel()
 def VVGAMc(self, VVVpUgObj, item=None):
  FF6Ue4(VVVpUgObj, boundFunction(self.VVcYXt, VVVpUgObj, item))
 def VVcYXt(self, VVVpUgObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVVpUgObj.VVVLxj):
    path = item[1]
    if fileExists(path):
     enc = FFoqLf(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = self.VVbxBz(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCvDyD.VVBfHn(orExportPath=True)
    pListF = "%sPlaylist_%s.txt" % (path, FFYjSS())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVVpUgObj.VVVLxj)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFItCL(self, txt, title=title)
   else:
    FFsqiC(self, "Could not obtain URLs from this file list !", title=title)
 def VVbBTK(self):
  path = CCvDyD.VVBfHn()
  lines = FFstFz('find %s %s -iname "*playlist*" | grep -i ".txt"' % (path, FFpWOv(1)))
  if lines:
   lines.sort()
   VVVLxj = []
   for line in lines:
    VVVLxj.append((line, line))
   OKBtnFnc = self.VVYIMS
   VVFM2s = ("Delete File", boundFunction(self.VV5UV4, boundFunction(FF6Ue4, self, self.VVbBTK, title="Searching ...")))
   FFfsxJ(self, None, title="Select Playlist File", VVVLxj=VVVLxj, width=1200, OKBtnFnc=OKBtnFnc, VVFM2s=VVFM2s)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFsqiC(self, 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt)
 def VVYIMS(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FF6Ue4(menuInstance, boundFunction(self.VVaBC5, menuInstance, path), title="Processing File ...")
 def VVaBC5(self, fileMenuInstance, path):
  enc = FFoqLf(path, self)
  if enc == -1:
   return
  VV5tha = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0]
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFSw9u(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCvDyD.VVwGnb(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VV5tha:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(filter(None, [item[5], item[0]]))
     num += 1
     VV5tha.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VV5tha:
   title = "Playlist File"
   VV0k9j  = ("Start"    , boundFunction(self.VVCw5q, title)  , [])
   VV5eNi = ("Home Menu"   , FF0lEm         , [])
   VVgwCo = ("Download M3U File" , self.VVBR8Y     , [])
   VV3VnJ = ("Edit File"   , boundFunction(self.VVLbWY, path) , [])
   VVa6E6 = ("Check & Filter"  , boundFunction(self.VVpwjw, fileMenuInstance, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVOhM5  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFoSxq(self, None, title=title, header=header, VVprx2=VV5tha, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=26, VV0k9j=VV0k9j, VV5eNi=VV5eNi, VVa6E6=VVa6E6, VVgwCo=VVgwCo, VV3VnJ=VV3VnJ, VVkTTr="#11001116", VVDVtL="#11001116", VV1z5Z="#11001116", VVps2K="#00003635", VVNERz="#0a333333", VVJsTV="#11331100", VV13Vm=True)
  else:
   FFsqiC(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVBR8Y(self, VVV80v, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFmhMd(self, boundFunction(FF6Ue4, VVV80v, boundFunction(self.VVCdkF, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVCdkF(self, title, url):
  path, err = FFiBrv(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFsqiC(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFb1Rx(path)
   if '{"user_info":{"auth":0}}' in txt:
    os.system(FFnz2p("rm -f '%s'" % path))
    FFsqiC(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    os.system(FFnz2p("rm -f '%s'" % path))
    FFsqiC(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCvDyD.VVBfHn(orExportPath=True) + fName
    os.system(FFnz2p("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FFEf0P(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFsqiC(self, "Could not download the M3U file!", title=errTitle)
 def VVCw5q(self, Title, VVV80v, title, txt, colList):
  url = colList[6]
  FF6Ue4(VVV80v, boundFunction(self.VVZyl6, Title, url), title="Checking Server ...")
 def VVLbWY(self, path, VVV80v, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCj5OR(self, path, VVNtvf=boundFunction(self.VVXUeM, VVV80v), curRowNum=rowNum)
  else    : FFPX6L(self, path)
 def VVXUeM(self, VVV80v, fileChanged):
  if fileChanged:
   VVV80v.cancel()
 def VVMIBS(self, title):
  curChName = self.VVV80v.VVRcVo(1)
  FFD8qa(self, boundFunction(self.VVqFBA, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVqFBA(self, title, name):
  if name:
   lameDbChans = CC7tYb.VVVqOu(self, CC7tYb.VVzkrP, VVtwCC=False, VV2Adh=False)
   list = []
   if lameDbChans:
    processChanName = CCfOPf()
    name = processChanName.VV6boC(name)
    ratio = "1"
    for item in lameDbChans:
     if name in item[0].lower():
      list.append((item[0], FF08Wi(item[2]), item[3], ratio))
   if list : self.VVVjeB(list, title)
   else : FFsqiC(self, "Not found:\n\n%s" % name, title=title)
 def VVnrn9(self, title):
  curChName = self.VVV80v.VVRcVo(1)
  self.session.open(CCdrie, barTheme=CCdrie.VV5tD6
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VV0m9J
      , VVNtvf = boundFunction(self.VVxWsS, title, curChName))
 def VV0m9J(self, progBarObj):
  curChName = self.VVV80v.VVRcVo(1)
  lameDbChans = CC7tYb.VVVqOu(self, CC7tYb.VV8Mbm, VVtwCC=False, VV2Adh=False)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VV86go = []
  progBarObj.VVQkW1(len(lameDbChans))
  processChanName = CCfOPf()
  curCh = processChanName.VV6boC(curChName)
  for refCode in lameDbChans:
   chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
   ratio = CCfUPK.VVlwQm(chName.lower(), curCh)
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVeaD2(1, True)
   if progBarObj and ratio > 50:
    progBarObj.VV86go.append((chName, FF08Wi(sat), refCode.replace("_", ":"), str(ratio)))
 def VVxWsS(self, title, curChName, VV0mDv, VV86go, threadCounter, threadTotal, threadErr):
  if VV86go: self.VVVjeB(VV86go, title)
  elif VV0mDv: FFsqiC(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVVjeB(self, VV5tha, title):
  curChName = self.VVV80v.VVRcVo(1)
  curRefCode = self.VVV80v.VVRcVo(4)
  curUrl  = self.VVV80v.VVRcVo(5)
  VV5tha = sorted(VV5tha, key=lambda x: (100-int(x[3]), x[0].lower()))
  VV0k9j  = ("Share Sat/C/T Ref.", boundFunction(self.VVMR9e, title, curChName, curRefCode, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFoSxq(self, None, title=title, header=header, VVprx2=VV5tha, VVADeP=widths, VVKTEW=26, VV0k9j=VV0k9j, VVkTTr="#0a00112B", VVDVtL="#0a001126", VV1z5Z="#0a001126", VVps2K="#00000000")
 def VVMR9e(self, newtitle, curChName, curRefCode, curUrl, VVV80v, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFmhMd(self.VVV80v, boundFunction(FF6Ue4, self.VVV80v, boundFunction(self.VVjmCZ, VVV80v, data)), ques, title=newtitle, VVCf1C=True)
 def VVjmCZ(self, VVV80v, data):
  VVV80v.cancel()
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVvEmR():
    txt = FFb1Rx(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFOdGC()
    newRow = []
    for i in range(6):
     newRow.append(self.VVV80v.VVRcVo(i))
    newRow[4] = newRefCode
    done = self.VVV80v.VV5whV(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFiJN6(boundFunction(FFEf0P , self, resTxt, title=title))
  elif resErr: FFiJN6(boundFunction(FFsqiC , self, resErr, title=title))
 def VVpwjw(self, fileMenuInstance, path, VVV80v, title, txt, colList):
  self.session.open(CCdrie, barTheme=CCdrie.VV5tD6
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VVPqdO, VVV80v)
      , VVNtvf = boundFunction(self.VVznQI, fileMenuInstance, path, VVV80v))
 def VVPqdO(self, VVV80v, progBarObj):
  progBarObj.VVQkW1(VVV80v.VV9s1N())
  progBarObj.VV86go = []
  for row in VVV80v.VVSUDw():
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVeaD2(1, True)
   qUrl = self.VViw6G(self.VV2y1R, row[6])
   txt, err = self.VVSJvq(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVZ0n9(item, "auth") == "0":
       progBarObj.VV86go.append(qUrl)
    except:
     pass
 def VVznQI(self, fileMenuInstance, path, VVV80v, VV0mDv, VV86go, threadCounter, threadTotal, threadErr):
  if VV0mDv:
   list = VV86go
   title = "Authorized Servers"
   if list:
    totChk = VVV80v.VV9s1N()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFYjSS()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVbBTK()
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFejnb(str(totAuth), VVOn4X)
     txt += "%s\n\n%s"    %  (FFejnb("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFItCL(self, txt, title=title)
     VVV80v.close()
     fileMenuInstance.close()
    else:
     FFEf0P(self, "All URLs are authorized.", title=title)
   else:
    FFsqiC(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVSJvq(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   res = res.read().decode("UTF-8")
   if res:
    if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server !"
    else           : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVwGnb(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VV3VMw(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VViw6G(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVwGnb(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VV2y1R   : return "%s"            % url
  elif mode == self.VVHG1p   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVwgVe   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVcyAE  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVzAZQ  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVDQVF : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVmSaS   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVGamb    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVAbJ6  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VViwNn : return "%s&action=get_live_streams"      % url
  elif mode == self.VVSyZu  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVZ0n9(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFh92T(int(val))
    elif is_base64 : val = FFPPp4(val)
    elif isToHHMMSS : val = FFqFgA(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VV1rV9(self, title, path):
  if fileExists(path):
   enc = FFoqLf(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = self.VVbxBz(line)
     if qUrl:
      break
   if qUrl : self.VVZyl6(title, qUrl)
   else : FFsqiC(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFsqiC(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVwShq_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVa2zU()
  if qUrl:
   host, mac, isPortalUrl = self.VVpwEK(iptvRef)
   if isPortalUrl:
    if host and mac : self.VVwShq(self, host, mac)
    else   : FFsqiC(self, "Error in current channel URL/MAC !", title=title)
   else:
    FF6Ue4(self, boundFunction(self.VVZyl6, title, qUrl), title="Checking Server ...")
  else:
   FFsqiC(self, "Error in current channel URL !", title=title)
 def VVa2zU(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self)
  qUrl = self.VVbxBz(decodedUrl)
  return qUrl, iptvRef
 def VVbxBz(self, url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) >= 2 : return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else    : return ""
 def VVZyl6(self, title, url):
  self.VVjAfdData = {}
  qUrl = self.VViw6G(self.VV2y1R, url)
  txt, err = self.VVSJvq(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVjAfdData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVjAfdData["username"    ] = self.VVZ0n9(item, "username"        )
    self.VVjAfdData["password"    ] = self.VVZ0n9(item, "password"        )
    self.VVjAfdData["message"    ] = self.VVZ0n9(item, "message"        )
    self.VVjAfdData["auth"     ] = self.VVZ0n9(item, "auth"         )
    self.VVjAfdData["status"    ] = self.VVZ0n9(item, "status"        )
    self.VVjAfdData["exp_date"    ] = self.VVZ0n9(item, "exp_date"    , isDate=True )
    self.VVjAfdData["is_trial"    ] = self.VVZ0n9(item, "is_trial"        )
    self.VVjAfdData["active_cons"   ] = self.VVZ0n9(item, "active_cons"       )
    self.VVjAfdData["created_at"   ] = self.VVZ0n9(item, "created_at"   , isDate=True )
    self.VVjAfdData["max_connections"  ] = self.VVZ0n9(item, "max_connections"      )
    self.VVjAfdData["allowed_output_formats"] = self.VVZ0n9(item, "allowed_output_formats"    )
    lst = []
    key = "allowed_output_formats"
    if key in item:
     for item in item[key]:
      lst.append(str(item))
     self.VVjAfdData[key] = lst
    item = tDict["server_info"]
    self.VVjAfdData["url"    ] = self.VVZ0n9(item, "url"        )
    self.VVjAfdData["port"    ] = self.VVZ0n9(item, "port"        )
    self.VVjAfdData["https_port"  ] = self.VVZ0n9(item, "https_port"      )
    self.VVjAfdData["server_protocol" ] = self.VVZ0n9(item, "server_protocol"     )
    self.VVjAfdData["rtmp_port"   ] = self.VVZ0n9(item, "rtmp_port"       )
    self.VVjAfdData["timezone"   ] = self.VVZ0n9(item, "timezone"       )
    self.VVjAfdData["timestamp_now"  ] = self.VVZ0n9(item, "timestamp_now"  , isDate=True )
    self.VVjAfdData["time_now"   ] = self.VVZ0n9(item, "time_now"       )
    VVVLxj  = self.VVXeT7(True)
    OKBtnFnc = self.VVjAfdOptions
    VV123e = ("Home Menu", FF0lEm)
    FFfsxJ(self, None, title="IPTV Server Resources", VVVLxj=VVVLxj, OKBtnFnc=OKBtnFnc, VV123e=VV123e)
   else:
    err = "Could not get data from server !"
  if err:
   FFsqiC(self, err, title=title)
  FFlf8A(self)
 def VVjAfdOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FF6Ue4(menuInstance, boundFunction(self.VVDM14, self.VVHG1p  , title=title), title=wTxt)
   elif ref == "vod"   : FF6Ue4(menuInstance, boundFunction(self.VVDM14, self.VVwgVe  , title=title), title=wTxt)
   elif ref == "series"  : FF6Ue4(menuInstance, boundFunction(self.VVDM14, self.VVcyAE , title=title), title=wTxt)
   elif ref == "catchup"  : FF6Ue4(menuInstance, boundFunction(self.VVDM14, self.VVzAZQ , title=title), title=wTxt)
   elif ref == "accountInfo" : FF6Ue4(menuInstance, boundFunction(self.VVf5Cu           , title=title), title=wTxt)
 def VVf5Cu(self, title):
  rows = []
  for key, val in self.VVjAfdData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VV5eNi = ("Home Menu", FF0lEm, [])
  header   = ("Num", "User/Server" , "Subject" , "Value" )
  widths   = (0 , 15   , 35  , 50  )
  FFoSxq(self, None, title=title, width=1200, header=header, VVprx2=rows, VVADeP=widths, VVKTEW=26, VV5eNi=VV5eNi, VVkTTr="#0a00292B", VVDVtL="#0a002126", VV1z5Z="#0a002126", VVps2K="#00000000", searchCol=2)
 def VVARhT(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CCfOPf()
    if mode in (self.VVmSaS, self.VVSyZu):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVZ0n9(item, "num"         )
      name     = self.VVZ0n9(item, "name"        )
      stream_id    = self.VVZ0n9(item, "stream_id"       )
      stream_icon    = self.VVZ0n9(item, "stream_icon"       )
      epg_channel_id   = self.VVZ0n9(item, "epg_channel_id"      )
      added     = self.VVZ0n9(item, "added"    , isDate=True )
      is_adult    = self.VVZ0n9(item, "is_adult"       )
      category_id    = self.VVZ0n9(item, "category_id"       )
      tv_archive    = self.VVZ0n9(item, "tv_archive"       )
      name = processChanName.VVnLmr(name)
      if name:
       if mode == self.VVmSaS or mode == self.VVSyZu and tv_archive == "1":
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVGamb:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVZ0n9(item, "num"         )
      name    = self.VVZ0n9(item, "name"        )
      stream_id   = self.VVZ0n9(item, "stream_id"       )
      stream_icon   = self.VVZ0n9(item, "stream_icon"       )
      added    = self.VVZ0n9(item, "added"    , isDate=True )
      is_adult   = self.VVZ0n9(item, "is_adult"       )
      category_id   = self.VVZ0n9(item, "category_id"       )
      container_extension = self.VVZ0n9(item, "container_extension"     ) or "mp4"
      name = processChanName.VVnLmr(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVAbJ6:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVZ0n9(item, "num"        )
      name    = self.VVZ0n9(item, "name"       )
      series_id   = self.VVZ0n9(item, "series_id"      )
      cover    = self.VVZ0n9(item, "cover"       )
      genre    = self.VVZ0n9(item, "genre"       )
      episode_run_time = self.VVZ0n9(item, "episode_run_time"    )
      category_id   = self.VVZ0n9(item, "category_id"      )
      container_extension = self.VVZ0n9(item, "container_extension"    ) or "mp4"
      name = processChanName.VVnLmr(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVDM14(self, mode, title):
  cList, err = self.VVpCkC(mode)
  if cList and mode == self.VVzAZQ:
   cList = self.VVL5Bn(cList)
  if err:
   FFsqiC(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVkTTr, VVDVtL, VV1z5Z, VVps2K = self.VVpPTW(mode)
   mName = self.VVVRGT(mode)
   if   mode == self.VVHG1p  : fMode = self.VVmSaS
   elif mode == self.VVwgVe  : fMode = self.VVGamb
   elif mode == self.VVcyAE : fMode = self.VVAbJ6
   elif mode == self.VVzAZQ : fMode = self.VVSyZu
   if mode == self.VVzAZQ:
    VV3VnJ = None
   else:
    VV3VnJ = ("Find in %s" % mName , boundFunction(self.VVWbvi, fMode) , [])
   VV0k9j   = ("Show List"   , boundFunction(self.VVjMoX, mode) , [])
   VV5eNi  = ("Home Menu"   , FF0lEm          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFoSxq(self, None, title=title, width=1200, header=header, VVprx2=cList, VVADeP=widths, VVKTEW=30, VV5eNi=VV5eNi, VV3VnJ=VV3VnJ, VV0k9j=VV0k9j, VVkTTr=VVkTTr, VVDVtL=VVDVtL, VV1z5Z=VV1z5Z, VVps2K=VVps2K)
  else:
   FFsqiC(self, "No list from server !", title=title)
  FFlf8A(self)
 def VVpCkC(self, mode):
  qUrl  = self.VViw6G(mode, self.VVjAfdData["playListURL"])
  txt, err = self.VVSJvq(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    processChanName = CCfOPf()
    for item in tDict:
     category_id  = self.VVZ0n9(item, "category_id"  )
     category_name = self.VVZ0n9(item, "category_name" )
     parent_id  = self.VVZ0n9(item, "parent_id"  )
     category_name = processChanName.VVYXR2(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVL5Bn(self, catList):
  mode  = self.VVSyZu
  qUrl  = self.VViw6G(mode, self.VVjAfdData["playListURL"])
  txt, err = self.VVSJvq(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVARhT(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVjMoX(self, mode, VVV80v, title, txt, colList):
  title = colList[1]
  FF6Ue4(VVV80v, boundFunction(self.VV99Cn, mode, VVV80v, title, txt, colList), title="Downloading ...")
 def VV99Cn(self, mode, VVV80v, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVVRGT(mode) + " : "+ bName
  if   mode == self.VVHG1p  : mode = self.VVmSaS
  elif mode == self.VVwgVe  : mode = self.VVGamb
  elif mode == self.VVcyAE : mode = self.VVAbJ6
  elif mode == self.VVzAZQ : mode = self.VVSyZu
  qUrl  = self.VViw6G(mode, self.VVjAfdData["playListURL"], catID)
  txt, err = self.VVSJvq(qUrl)
  list  = []
  if not err and mode in (self.VVmSaS, self.VVGamb, self.VVAbJ6, self.VVSyZu):
   list, err = self.VVARhT(mode, txt)
  if err:
   FFsqiC(self, err, title=title)
  elif list:
   VV5eNi  = ("Home Menu"   , FF0lEm             , [])
   if mode in (self.VVmSaS, self.VVSyZu):
    VVkTTr, VVDVtL, VV1z5Z, VVps2K = self.VVpPTW(mode)
    VVEgOz = (""     , boundFunction(self.VVd4ke, mode)     , [])
    VVgwCo = ("Download Options" , boundFunction(self.VVaKT3, mode, "", "")  , [])
    VV3VnJ = ("Add ALL to Bouquet" , boundFunction(self.VVTJEt, mode, bName)  , [])
    if mode == self.VVmSaS:
     VV0k9j = ("Play"    , boundFunction(self.VVzZQ4, mode)     , [])
    elif mode == self.VVSyZu:
     VV0k9j  = ("Programs", boundFunction(self.VVW2FE_fromIptvTable, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVOhM5  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVGamb:
    VVkTTr, VVDVtL, VV1z5Z, VVps2K = self.VVpPTW(mode)
    VV0k9j  = ("Play"    , boundFunction(self.VVzZQ4, mode)    , [])
    VVEgOz = (""     , boundFunction(self.VVd4ke, mode)    , [])
    VVgwCo = ("Download Options" , boundFunction(self.VVaKT3, mode, "v", ""), [])
    VV3VnJ = ("Add ALL to Bouquet" , boundFunction(self.VVTJEt, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVOhM5  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVAbJ6:
    VVkTTr, VVDVtL, VV1z5Z, VVps2K = self.VVpPTW("series2")
    VV0k9j  = ("Show Seasons", boundFunction(self.VVx2L2, mode) , [])
    VVEgOz = ("", boundFunction(self.VVepRX, mode)  , [])
    VVgwCo = None
    VV3VnJ = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVOhM5  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFoSxq(self, None, title=title, header=header, VVprx2=list, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=26, VV0k9j=VV0k9j, VV5eNi=VV5eNi, VVgwCo=VVgwCo, VV3VnJ=VV3VnJ, VVEgOz=VVEgOz, VVkTTr=VVkTTr, VVDVtL=VVDVtL, VV1z5Z=VV1z5Z, VVps2K=VVps2K, VV13Vm=True, searchCol=1)
  else:
   FFsqiC(self, "No Channels found !", title=title)
  FFlf8A(self)
 def VVW2FE_fromIptvTable(self, mode, bName, VVV80v, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVjAfdData["playListURL"]
  ok_fnc  = boundFunction(self.VVZNEA, hostUrl, chName, catId, streamId)
  FF6Ue4(VVV80v, boundFunction(CCvDyD.VVW2FE, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVZNEA(self, chUrl, chName, catId, streamId, VVV80v, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCvDyD.VVwGnb(chUrl)
   chNum = "333"
   refCode = CCvDyD.VVhAn0(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFIFfg(self, chUrl, VVb10q=False)
   self.session.open(CCwb6Z)
  else:
   FFsqiC(self, "Incorrect Timestamp", pTitle)
 def VVx2L2(self, mode, VVV80v, title, txt, colList):
  title = colList[1]
  FF6Ue4(VVV80v, boundFunction(self.VVMmVp, mode, VVV80v, title, txt, colList), title="Downloading ...")
 def VVMmVp(self, mode, VVV80v, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VViw6G(self.VVDQVF, self.VVjAfdData["playListURL"], series_id)
  txt, err = self.VVSJvq(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVZ0n9(tDict["info"], "name"   )
      category_id = self.VVZ0n9(tDict["info"], "category_id" )
      icon  = self.VVZ0n9(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVZ0n9(EP, "id"     )
        episode_num   = self.VVZ0n9(EP, "episode_num"   )
        epTitle    = self.VVZ0n9(EP, "title"     )
        container_extension = self.VVZ0n9(EP, "container_extension" )
        seasonNum   = self.VVZ0n9(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFsqiC(self, err, title=title)
  elif list:
   VV5eNi = ("Home Menu"   , FF0lEm             , [])
   VVgwCo = ("Download Options" , boundFunction(self.VVaKT3, mode, "s", title) , [])
   VV3VnJ = ("Add ALL to Bouquet" , boundFunction(self.VVTJEt, mode, title)  , [])
   VVEgOz = (""     , boundFunction(self.VVd4ke, mode)     , [])
   VV0k9j  = ("Play"    , boundFunction(self.VVzZQ4, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVOhM5  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFoSxq(self, None, title=title, header=header, VVprx2=list, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=26, VV5eNi=VV5eNi, VVgwCo=VVgwCo, VV0k9j=VV0k9j, VVEgOz=VVEgOz, VV3VnJ=VV3VnJ, VVkTTr="#0a00292B", VVDVtL="#0a002126", VV1z5Z="#0a002126", VVps2K="#00000000")
  else:
   FFsqiC(self, "No Channels found !", title=title)
  FFlf8A(self)
 def VVWbvi(self, mode, VVV80v, title, txt, colList):
  VVVLxj = []
  VVVLxj.append(("Keyboard"  , "manualEntry"))
  VVVLxj.append(("From Filter" , "fromFilter"))
  FFfsxJ(self, boundFunction(self.VV21mw, VVV80v, mode), title="Input Type", VVVLxj=VVVLxj, width=400)
 def VV21mw(self, VVV80v, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFD8qa(self, boundFunction(self.VVoyrz, VVV80v, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCicDe(self)
    filterObj.VVIfac(boundFunction(self.VVoyrz, VVV80v, mode))
 def VVoyrz(self, VVV80v, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CCfOPf()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVyKwD(words):
     FFsqiC(self, processChanName.VVk9gU(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CCdrie, barTheme=CCdrie.VV5tD6
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VVTHKe, VVV80v, mode, title, words, toFind, asPrefix, processChanName)
         , VVNtvf = boundFunction(self.VVdahb, mode, toFind, title))
   else:
    FFsqiC(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VVTHKe(self, VVV80v, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVQkW1(VVV80v.VVIKdD())
  progBarObj.VV86go = []
  for row in VVV80v.VVSUDw():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVeaD2(1)
   progBarObj.VVoRkl_fromIptvFind(catName)
   qUrl  = self.VViw6G(mode, self.VVjAfdData["playListURL"], catID)
   txt, err = self.VVSJvq(qUrl)
   if not err:
    tList, err = self.VVARhT(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VVnLmr(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VVmSaS:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VV86go.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVGamb:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VV86go.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVAbJ6:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VV86go.append((num, name, catID, ID, genre, catName, ext, cover))
 def VVdahb(self, mode, toFind, title, VV0mDv, VV86go, threadCounter, threadTotal, threadErr):
  if VV86go:
   title = self.VVPM5r(mode, toFind)
   if mode == self.VVmSaS or mode == self.VVGamb:
    if mode == self.VVGamb : typ = "v"
    else          : typ = ""
    bName   = CCvDyD.VV7v6Z_forBouquet(toFind)
    VV0k9j  = ("Play"     , boundFunction(self.VVzZQ4, mode)    , [])
    VVgwCo = ("Download Options" , boundFunction(self.VVaKT3, mode, typ, ""), [])
    VV3VnJ = ("Add ALL to Bouquet" , boundFunction(self.VVTJEt, mode, bName) , [])
   elif mode == self.VVAbJ6:
    VV0k9j  = ("Show Seasons"  , boundFunction(self.VVx2L2, mode)    , [])
    VV3VnJ = None
    VVgwCo = None
   VVEgOz  = (""     , boundFunction(self.VVd4ke, mode)    , [])
   VV5eNi  = ("Home Menu"   , FF0lEm            , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVOhM5  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVV80v = FFoSxq(self, None, title=title, header=header, VVprx2=VV86go, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=26, VV0k9j=VV0k9j, VV5eNi=VV5eNi, VVgwCo=VVgwCo, VV3VnJ=VV3VnJ, VVEgOz=VVEgOz, VVkTTr="#0a00292B", VVDVtL="#0a002126", VV1z5Z="#0a002126", VVps2K="#00000000", VV13Vm=True, searchCol=1)
   if not VV0mDv:
    FFlf8A(VVV80v, "Stopped" , 1000)
  else:
   if VV0mDv:
    FFsqiC(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVXUdN(self, mode, colList):
  if mode in (self.VVmSaS, self.VVSyZu):
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVGamb:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FF9jRB(chName)
  url = self.VVjAfdData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVwGnb(url)
  refCode = self.VVhAn0(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVd4ke(self, mode, VVV80v, title, txt, colList):
  FF6Ue4(VVV80v, boundFunction(self.VVj2A3, mode, VVV80v, title, txt, colList))
 def VVj2A3(self, mode, VVV80v, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVXUdN(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFULTs(self, fncMode=CCazlH.VVcngu, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVepRX(self, mode, VVV80v, title, txt, colList):
  FF6Ue4(VVV80v, boundFunction(self.VVCtxR, mode, VVV80v, title, txt, colList))
 def VVCtxR(self, mode, VVV80v, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFULTs(self, fncMode=CCazlH.VVaGUQ, chName=name, text=txt, picUrl=Cover)
 def VVTJEt(self, mode, bName, VVV80v, title, txt, colList):
  FF6Ue4(VVV80v, boundFunction(self.VVjZ7I, mode, bName, VVV80v, title, txt, colList), title="Adding Channels ...")
 def VVjZ7I(self, mode, bName, VVV80v, title, txt, colList):
  url = self.VVjAfdData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVwGnb(url)
  bNameFile = CCvDyD.VV7v6Z_forBouquet(bName)
  num  = 0
  path = VVRcPg + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVRcPg + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVV80v.VVSUDw():
    chName, chUrl, picUrl, refCode = self.VVXUdN(mode, row)
    f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
    f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
    totChange += 1
  FFO7ny(os.path.basename(path))
  self.VVmBIu(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVaKT3(self, mode, typ, seriesName, VVV80v, title, txt, colList):
  VVVLxj = []
  VVVLxj.append(("Download all PIcons"       , "dnldPicons" ))
  if typ:
   VVVLxj.append(VVQP0R)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVVLxj.append(("Download Selected %s" % tName    , "dnldSel"  ))
   VVVLxj.append(("Add Selected %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVVLxj.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CC5fZh.VVCMkz():
    VVVLxj.append(VVQP0R)
    VVVLxj.append(("Download Manager"      , "dload_stat" ))
  FFfsxJ(self, boundFunction(self.VVTTmg_VVaZS8, VVV80v, mode, typ, seriesName, colList), title="Download Options", VVVLxj=VVVLxj)
 def VVTTmg_VVaZS8(self, VVV80v, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVUIfm(VVV80v, mode)
   elif item == "dnldSel"  : self.VVYZ1s(VVV80v, mode, typ, colList, True)
   elif item == "addSel"  : self.VVYZ1s(VVV80v, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVNFJA(VVV80v, mode, typ, seriesName)
   elif item == "dload_stat" : CC5fZh.VVPI3i(self)
 def VVYZ1s(self, VVV80v, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVIHN6(mode, typ, colList)
  if startDnld:
   CC5fZh.VVt6Ar_url(self, decodedUrl)
  else:
   self.VVaZS8_FFmhMd(VVV80v, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVNFJA(self, VVV80v, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVV80v.VVSUDw():
   chName, decodedUrl = self.VVIHN6(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVaZS8_FFmhMd(VVV80v, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVaZS8_FFmhMd(self, VVV80v, title, chName, decodedUrl_list, startDnld):
  FFmhMd(self, boundFunction(self.VVCoW3, VVV80v, decodedUrl_list, startDnld), chName, title=title)
 def VVCoW3(self, VVV80v, decodedUrl_list, startDnld):
  added, skipped = CC5fZh.VVjpN9List(decodedUrl_list)
  FFlf8A(VVV80v, "Added", 1000)
 def VVIHN6(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVXUdN(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV2feX(mode, colList)
   refCode, chUrl = self.VVnfuc(self.VVynMQ, self.VV89kz, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FF7COR(chUrl)
  return chName, decodedUrl
 def VVUIfm(self, VVV80v, mode):
  if os.system(FFnz2p("which ffmpeg")) == 0:
   self.session.open(CCdrie, barTheme=CCdrie.VVFqXe
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VV5qPy, VVV80v, mode)
       , VVNtvf = self.VV6Pjr)
  else:
   FFmhMd(self, boundFunction(CCvDyD.VVJJv3, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VV6Pjr(self, VV0mDv, VV86go, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VV86go["proces"], VV86go["total"])
  txt += "Download Success\t: %d of %s\n"  % (VV86go["ok"], VV86go["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VV86go["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VV86go["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VV86go["badURL"]
  txt += "Download Failure\t: %d\n"   % VV86go["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VV86go["path"]
  if not VV0mDv  : color = "#11402000"
  elif VV86go["err"]: color = "#11201000"
  else     : color = None
  if VV86go["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VV86go["err"], txt)
  title = "PIcons Download Result"
  if not VV0mDv:
   title += "  (cancelled)"
  FFItCL(self, txt, title=title, VV1z5Z=color)
 def VV5qPy(self, VVV80v, mode, progBarObj):
  totRows = VVV80v.VVIKdD()
  progBarObj.VVQkW1(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CCfUPK.VVIatH()
  progBarObj.VV86go = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for rowNum, row in enumerate(VVV80v.VVSUDw()):
    if progBarObj.isCancelled:
     break
    progBarObj.VV86go["proces"] += 1
    progBarObj.VVeaD2(1)
    if mode in ("itv", "vod", "series"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV2feX(mode, row)
     refCode = CCvDyD.VVhAn0(catID, stID, chNum)
    elif mode == "m3u/m3u8":
     chName = row[1].strip()
     url  = row[3].strip()
     picUrl = row[4].strip()
     refCode = self.VVb22U(rowNum, url, chName)
    else:
     chName, chUrl, picUrl, refCode = self.VVXUdN(mode, row)
    if picUrl:
     picon = refCode.replace(":", "_").rstrip("_") + ".png"
     if not fileExists(pPath + picon):
      progBarObj.VV86go["attempt"] += 1
      path, err = FFiBrv(picUrl, picon, timeout=1, mustBeImage=True)
      if path:
       progBarObj.VV86go["ok"] += 1
       if FFS6ZV(path) > 0:
        cmd = ""
        if not mode == CCvDyD.VVmSaS:
         cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
        cmd += FFnz2p("mv -f '%s' '%s'" % (path, pPath)) + ";"
        os.system(cmd)
       else:
        progBarObj.VV86go["size0"] += 1
        os.system(FFnz2p("rm -f '%s'" % path))
      elif err:
       progBarObj.VV86go["fail"] += 1
       if any(x in err.lower() for x in ("time-out", "unauthorized")):
        progBarObj.VV86go["err"] = err.title()
        break
     else:
      progBarObj.VV86go["exist"] += 1
    else:
     progBarObj.VV86go["badURL"] += 1
  except:
   pass
 @staticmethod
 def VVJJv3(SELF):
  cmd = FFvshm(VVH8bp, "ffmpeg")
  if cmd : FFyzyQ(SELF, cmd, title="Installing FFmpeg")
  else : FFEmMJ(SELF)
 def VVNaM4(self):
  self.session.open(CCdrie, barTheme=CCdrie.VVFqXe
      , titlePrefix = ""
      , fncToRun  = self.VV5Vtw
      , VVNtvf = self.VVXuhS)
 def VV5Vtw(self, progBarObj):
  bName = FFFJXz()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  progBarObj.VV86go = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = FFvn2n()
  if not progBarObj or progBarObj.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   progBarObj.VVQkW1(totCh)
   for serv in services:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVeaD2(1)
    progBarObj.VVoRkl_fromImportEPG(totEpgOK, uChName)
    fullRef  = serv[0]
    if FF0mkS(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FF7COR(fullRef)
     span = iSearch(r"(mode=.+end=)", fullRef, IGNORECASE)
     if span:
      m3u_Url = CCk6BG.VVqUEx(fullRef)
      uType, uHost, uUser, uPass, uId, uChName  = CCvDyD.VV3VMw(fullRef)
      uType, uHost, uUser, uPass, uId, uChName1 = CCvDyD.VV3VMw(m3u_Url)
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCvDyD.VV3VMw(m3u_Url)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCvDyD.VVNKAr(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCazlH.VVm3s9(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
      else:
       pass
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if progBarObj:
     progBarObj.VV86go = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   progBarObj.VV86go = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VVXuhS(self, VV0mDv, VV86go, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VV86go
  title = "IPTV EPG Import"
  if err:
   FFsqiC(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFejnb(str(totNotIptv), VVKSBp)
    if totServErr : txt += "Server Errors\t: %s\n" % FFejnb(str(totServErr) + t1, VVKSBp)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFejnb(str(totInv), VVKSBp)
   if not VV0mDv:
    title += "  (stopped)"
   FFItCL(self, txt, title=title)
 @staticmethod
 def VVNKAr(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCvDyD.VVwGnb(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCvDyD.VVSJvq(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCvDyD.VVZ0n9(item, "description" , is_base64=True ).replace("\n", " .. ")
    has_archive   = CCvDyD.VVZ0n9(item, "has_archive"      )
    lang    = CCvDyD.VVZ0n9(item, "lang"        ).upper()
    now_playing   = CCvDyD.VVZ0n9(item, "now_playing"      )
    start    = CCvDyD.VVZ0n9(item, "start"        )
    start_timestamp  = CCvDyD.VVZ0n9(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCvDyD.VVZ0n9(item, "start_timestamp"     )
    stop_timestamp  = CCvDyD.VVZ0n9(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCvDyD.VVZ0n9(item, "stop_timestamp"      )
    tTitle    = CCvDyD.VVZ0n9(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVhAn0(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCvDyD.VVKVmA(catID, MAX_4b)
  TSID = CCvDyD.VVKVmA(chNum, MAX_4b)
  ONID = CCvDyD.VVKVmA(chNum, MAX_4b)
  NS  = CCvDyD.VVKVmA(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVKVmA(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VV7v6Z_forBouquet(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVpPTW(mode):
  if   mode in ("itv"  , CCvDyD.VVHG1p)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCvDyD.VVwgVe)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCvDyD.VVcyAE) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCvDyD.VVzAZQ) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCvDyD.VVSyZu    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 @staticmethod
 def VVBfHn(orExportPath=False):
  path = CFG.iptvHostsPath.getValue()
  if not pathExists(path) or path == VVDYiT:
   if orExportPath : path = CFG.exportedTablesPath.getValue()
   else   : path ="/"
  return FFSw9u(path)
 @staticmethod
 def VVW2FE(SELF, hostUrl, chName, streamId, ok_fnc):
  title = "Catchup TV Programs"
  pList, err = CCvDyD.VVNKAr(hostUrl, streamId, True)
  if err:
   FFsqiC(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVkTTr, VVDVtL, VV1z5Z, VVps2K = CCvDyD.VVpPTW("")
   VV5eNi = ("Home Menu" , FF0lEm, [])
   VV0k9j  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVOhM5  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFoSxq(SELF, None, title="Programs for : " + chName, header=header, VVprx2=pList, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=24, VV0k9j=VV0k9j, VV5eNi=VV5eNi, VVkTTr=VVkTTr, VVDVtL=VVDVtL, VV1z5Z=VV1z5Z, VVps2K=VVps2K)
  else:
   FFsqiC(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVpWHe(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
class CCpBza(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFO5bN(VVdurn, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVEUEV  = 0
  self.VVV6hY = 1
  self.VVi7TK  = 2
  VVVLxj = []
  VVVLxj.append(("Find in All Service (from filter)" , "VVfw1f" ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Find in All (Manual Entry)"   , "VV6YUz"    ))
  VVVLxj.append(("Find in TV"       , "VV12I6"    ))
  VVVLxj.append(("Find in Radio"      , "VVPveb"   ))
  if self.VVedyX():
   VVVLxj.append(VVQP0R)
   VVVLxj.append(("Hide Channel: %s" % self.servName , "VVyNCn"   ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Zap History"       , "VV7UsK"    ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("IPTV Tools"       , "iptv"      ))
  VVVLxj.append(("PIcons Tools"       , "PIconsTools"     ))
  VVVLxj.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FF4gq5(self, VVVLxj=VVVLxj, title=title)
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  FFRtL9(self["myMenu"])
  FFqAhz(self)
  if self.isFindMode:
   self.VVUyP2(self.VViku6())
 def VV13Bz(self):
  global VVlddb
  VVlddb = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VV6YUz"    : self.VV6YUz()
   elif item == "VVfw1f" : self.VVfw1f()
   elif item == "VV12I6"    : self.VV12I6()
   elif item == "VVPveb"   : self.VVPveb()
   elif item == "VVyNCn"   : self.VVyNCn()
   elif item == "VV7UsK"    : self.VV7UsK()
   elif item == "iptv"       : self.session.open(CCvDyD)
   elif item == "PIconsTools"     : self.session.open(CCfUPK)
   elif item == "ChannelsTools"    : self.session.open(CC7tYb)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VV12I6(self) : self.VVUyP2(self.VVEUEV)
 def VVPveb(self) : self.VVUyP2(self.VVV6hY)
 def VV6YUz(self) : self.VVUyP2(self.VVi7TK)
 def VVUyP2(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFD8qa(self, boundFunction(self.VV5aha, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVfw1f(self):
  filterObj = CCicDe(self)
  filterObj.VVIfac(self.VVDVOp)
 def VVDVOp(self, item):
  self.VV5aha(self.VVi7TK, item)
 def VVedyX(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FF0mkS(self.refCode)        : return False
  return True
 def VV5aha(self, mode, VV2yGm):
  FF6Ue4(self, boundFunction(self.VVgyMK, mode, VV2yGm), title="Searching ...")
 def VVgyMK(self, mode, VV2yGm):
  if VV2yGm:
   self.findTxt = VV2yGm
   if   mode == self.VVEUEV  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVV6hY : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VV2yGm)
   if len(title) > 55:
    title = title[:55] + ".."
   VV5tha = self.VV180d(VV2yGm, servTypes)
   if self.isFindMode or mode == self.VVi7TK:
    VV5tha += self.VVQhBS(VV2yGm)
   if VV5tha:
    VV5tha.sort(key=lambda x: x[0].lower())
    VVjFfT = self.VVhUGv
    VV0k9j  = ("Zap"   , self.VVjZAD    , [])
    VVgwCo = ("Current Service", self.VVXIMD , [])
    VV3VnJ = ("Options"  , self.VVjR1N , [])
    VVEgOz = (""    , self.VVLgai , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVOhM5  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFoSxq(self, None, title=title, header=header, VVprx2=VV5tha, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=26, VV0k9j=VV0k9j, VVjFfT=VVjFfT, VVgwCo=VVgwCo, VV3VnJ=VV3VnJ, VVEgOz=VVEgOz)
   else:
    self.VVUyP2(self.VViku6())
    FFEf0P(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VV180d(self, VV2yGm, servTypes):
  VV6MwM  = eServiceCenter.getInstance()
  VVINd6   = '%s ORDER BY name' % servTypes
  VVDPo7   = eServiceReference(VVINd6)
  VVFV3m = VV6MwM.list(VVDPo7)
  if VVFV3m: VVprx2 = VVFV3m.getContent("CN", False)
  else     : VVprx2 = None
  VV5tha = []
  if VVprx2:
   VVLWAE, VVtyZP = FFNdBc()
   tp   = CC1kFd()
   words, asPrefix = CCicDe.VVDnY4(VV2yGm)
   colorYellow  = CCBmjq.VVLBCX(VVHuTi)
   colorWhite  = CCBmjq.VVLBCX(VVMNP0)
   for s in VVprx2:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFT3eZ(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVLWAE:
        STYPE = VVtyZP[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVgI7x(refCode)
       if not "-S" in syst:
        sat = syst
       VV5tha.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VV5tha
 def VVQhBS(self, VV2yGm):
  VV2yGm = VV2yGm.lower()
  VVw19Z = FFGqYY()
  VV5tha = []
  colorYellow  = CCBmjq.VVLBCX(VVHuTi)
  colorWhite  = CCBmjq.VVLBCX(VVMNP0)
  if VVw19Z:
   for b in VVw19Z:
    VVZ6pB  = b[0]
    VV6KrX  = b[1].toString()
    VVyW8I = eServiceReference(VV6KrX)
    VVlNoi = FFkzTC(VVyW8I)
    for service in VVlNoi:
     refCode  = service[0]
     if FF0mkS(refCode):
      servName = service[1]
      if VV2yGm in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VV2yGm), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VV5tha.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VV5tha
 def VViku6(self):
  VVWP6Z = InfoBar.instance
  if VVWP6Z:
   VVHj5Y = VVWP6Z.servicelist
   if VVHj5Y:
    return VVHj5Y.mode == 1
  return self.VVi7TK
 def VVhUGv(self, VVV80v):
  self.close()
  VVV80v.cancel()
 def VVjZAD(self, VVV80v, title, txt, colList):
  FFIFfg(VVV80v, colList[2], VVb10q=False, checkParentalControl=True)
 def VVXIMD(self, VVV80v, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(VVV80v)
  if refCode:
   VVV80v.VVBR6e(2, FFcakO(refCode, iptvRef, chName), True)
 def VVjR1N(self, VVV80v, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CClNKv(self, VVV80v, 2)
  mSel.VVKu0N(servName, refCode)
 def VVLgai(self, VVV80v, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFULTs(self, fncMode=CCazlH.VVNoHS, refCode=refCode, chName=chName, text=txt)
 def VVyNCn(self):
  FFmhMd(self, self.VV0EX5, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VV0EX5(self):
  ret = FF6N2d(self.refCode, True)
  if ret:
   self.VVou4p()
   self.close()
  else:
   FFlf8A(self, "Cannot change state" , 1000)
 def VVou4p(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVInda()
  except:
   self.VVlJtA()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFrEAI(self, serviceRef)
 def VV7hRn(self):
  VVWP6Z = InfoBar.instance
  if VVWP6Z:
   VVHj5Y = VVWP6Z.servicelist
   if VVHj5Y:
    VVHj5Y.setMode()
 def VVInda(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVWP6Z = InfoBar.instance
   if VVWP6Z:
    VVHj5Y = VVWP6Z.servicelist
    if VVHj5Y:
     hList = VVHj5Y.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVHj5Y.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVHj5Y.history  = newList
       VVHj5Y.history_pos = pos
 def VVlJtA(self):
  VVWP6Z = InfoBar.instance
  if VVWP6Z:
   VVHj5Y = VVWP6Z.servicelist
   if VVHj5Y:
    VVHj5Y.history  = []
    VVHj5Y.history_pos = 0
 def VV7UsK(self):
  VVWP6Z = InfoBar.instance
  VV5tha = []
  if VVWP6Z:
   VVHj5Y = VVWP6Z.servicelist
   if VVHj5Y:
    VVLWAE, VVtyZP = FFNdBc()
    for chParams in VVHj5Y.history:
     refCode = chParams[-1].toString()
     chName = FFRWNl(refCode)
     isIptv = FF0mkS(refCode)
     if isIptv: sat = "-"
     else  : sat = FFT3eZ(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVLWAE:
       STYPE = VVtyZP[sTypeInt]
     VV5tha.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VV5tha:
   VV0k9j  = ("Zap"   , self.VVfzP6   , [])
   VV3VnJ = ("Clear History" , self.VVMqrh   , [])
   VVEgOz = (""    , self.VVr8jLFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVOhM5  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFoSxq(self, None, title=title, header=header, VVprx2=VV5tha, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=28, VV0k9j=VV0k9j, VV3VnJ=VV3VnJ, VVEgOz=VVEgOz)
  else:
   FFEf0P(self, "Not found", title=title)
 def VVfzP6(self, VVV80v, title, txt, colList):
  FFIFfg(VVV80v, colList[3], VVb10q=False, checkParentalControl=True)
 def VVMqrh(self, VVV80v, title, txt, colList):
  FFmhMd(self, boundFunction(self.VV73Vv, VVV80v), "Clear Zap History ?")
 def VV73Vv(self, VVV80v):
  self.VVlJtA()
  VVV80v.cancel()
 def VVr8jLFromZapHistory(self, VVV80v, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFULTs(self, fncMode=CCazlH.VVvfXZ, refCode=refCode, chName=chName, text=txt)
class CCfUPK(Screen):
 VVNVq6   = 0
 VVG6BU  = 1
 VVC3wX  = 2
 VVkg6i  = 3
 VVRsnY  = 4
 VVdEDw  = 5
 VVzUuq  = 6
 VVeJaf  = 7
 VViC87 = 8
 VVjNJW = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFO5bN(VVAO8R, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FF4gq5(self, self.Title)
  FFoPjD(self["keyRed"] , "OK = Zap")
  FFoPjD(self["keyGreen"] , "Current Service")
  FFoPjD(self["keyYellow"], "Page Options")
  FFoPjD(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCfUPK.VVIatH()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVprx2    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVOpE5        ,
   "green"   : self.VVCc8D       ,
   "yellow"  : self.VVJGPj        ,
   "blue"   : self.VVQQ0X        ,
   "menu"   : self.VViq07        ,
   "info"   : self.VVr8jL         ,
   "up"   : self.VV8dvU          ,
   "down"   : self.VV01GK         ,
   "left"   : self.VVA8pr         ,
   "right"   : self.VVUCwC         ,
   "pageUp"  : boundFunction(self.VVMfWB, True) ,
   "chanUp"  : boundFunction(self.VVMfWB, True) ,
   "pageDown"  : boundFunction(self.VVMfWB, False) ,
   "chanDown"  : boundFunction(self.VVMfWB, False) ,
   "next"   : self.VVY9be        ,
   "last"   : self.VVwijv         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  FFNG0p(self)
  FFVXe6(self)
  FFXT3k(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FF6Ue4(self, boundFunction(self.VVRDMD, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VViq07(self):
  if not self.isBusy:
   VVVLxj = []
   VVVLxj.append(("Statistics"           , "VV1dE5"    ))
   VVVLxj.append(VVQP0R)
   VVVLxj.append(("Suggest PIcons for Current Channel"     , "VVskQF"   ))
   VVVLxj.append(("Set to Current Channel (copy file)"     , "VVot5z_file"  ))
   VVVLxj.append(("Set to Current Channel (as SymLink)"     , "VVot5z_link"  ))
   VVVLxj.append(VVQP0R)
   VVVLxj.append(CCfUPK.VVBDSS())
   VVVLxj.append(VVQP0R)
   if self.filterTitle == "PIcons without Channels":
    c = VVKSBp
    VVVLxj.append((FFejnb("Move Unused PIcons to a Directory", c) , "VVx0QI"  ))
    VVVLxj.append((FFejnb("DELETE Unused PIcons", c)    , "VVKFi4" ))
    VVVLxj.append(VVQP0R)
   VVVLxj.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVlPZw"  ))
   VVVLxj.append(VVQP0R)
   VVVLxj += CCfUPK.VVUDLs()
   VVVLxj.append(VVQP0R)
   VVVLxj.append(("RCU Keys Help"          , "VVD7Js"    ))
   FFfsxJ(self, self.VVTTmg, title=self.Title, VVVLxj=VVVLxj)
 def VVTTmg(self, item=None):
  if item is not None:
   if   item == "VV1dE5"     : self.VV1dE5()
   elif item == "VVskQF"    : self.VVskQF()
   elif item == "VVot5z_file"   : self.VVot5z(0)
   elif item == "VVot5z_link"   : self.VVot5z(1)
   elif item == "VVhREw_file"  : self.VVhREw(0)
   elif item == "VVhREw_link"  : self.VVhREw(1)
   elif item == "VVpzyy"   : self.VVpzyy()
   elif item == "VViOHr"  : self.VViOHr()
   elif item == "VVx0QI"    : self.VVx0QI()
   elif item == "VVKFi4"   : self.VVKFi4()
   elif item == "VVlPZw"   : self.VVlPZw()
   elif item == "VVAJkA"   : CCfUPK.VVAJkA(self)
   elif item == "VVeTaZ"   : CCfUPK.VVeTaZ(self)
   elif item == "findPiconBrokenSymLinks"  : CCfUPK.VVIHQd(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCfUPK.VVIHQd(self, False)
   elif item == "VVD7Js"      : self.VVD7Js()
 def VVJGPj(self):
  if not self.isBusy:
   VVVLxj = []
   VVVLxj.append(("Go to First PIcon"  , "VVtgqg"  ))
   VVVLxj.append(("Go to Last PIcon"   , "VVi4Y1"  ))
   VVVLxj.append(VVQP0R)
   VVVLxj.append(("Sort by Channel Name"     , "sortByChan" ))
   VVVLxj.append(("Sort by File Name"  , "sortByFile" ))
   VVVLxj.append(VVQP0R)
   VVVLxj.append(("Find from File List .." , "VVvoMf" ))
   FFfsxJ(self, self.VVFUaB, title=self.Title, VVVLxj=VVVLxj)
 def VVFUaB(self, item=None):
  if item is not None:
   if   item == "VVtgqg"   : self.VVtgqg()
   elif item == "VVi4Y1"   : self.VVi4Y1()
   elif item == "sortByChan"  : self.VVc5Ps(2)
   elif item == "sortByFile"  : self.VVc5Ps(0)
   elif item == "VVvoMf"  : self.VVvoMf()
 def VVD7Js(self):
  FFRzLG(self, VVMPsf + "_help_picons", "PIcons Manager (Keys Help)")
 def VV8dvU(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVi4Y1()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVv32c()
 def VV01GK(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVtgqg()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVv32c()
 def VVA8pr(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVi4Y1()
  else:
   self.curCol -= 1
   self.VVv32c()
 def VVUCwC(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVtgqg()
  else:
   self.curCol += 1
   self.VVv32c()
 def VVwijv(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVv32c(True)
 def VVY9be(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVv32c(True)
 def VVtgqg(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVv32c(True)
 def VVi4Y1(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVv32c(True)
 def VVvoMf(self):
  VVVLxj = []
  for item in self.VVprx2:
   VVVLxj.append((item[0], item[0]))
  FFfsxJ(self, self.VVUow4, title='PIcons ".png" Files', VVVLxj=VVVLxj, VVZFmG=True)
 def VVUow4(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVnMD7(ndx)
 def VVOpE5(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVegMJ()
   if refCode:
    FFIFfg(self, refCode)
    self.VVTc3h()
    self.VVSLSF()
 def VVMfWB(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVTc3h()
   self.VVSLSF()
  except:
   pass
 def VVCc8D(self):
  if self["keyGreen"].getVisible():
   self.VVnMD7(self.curChanIndex)
 def VVnMD7(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVv32c(True)
  else:
   FFlf8A(self, "Not found", 1000)
 def VVc5Ps(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FF6Ue4(self, boundFunction(self.VVRDMD, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVot5z(self, mode):
  title = "Change Current Channel PIcon"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVegMJ()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVVLxj = []
     VVVLxj.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVVLxj.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFfsxJ(self, boundFunction(self.VVNJVx, mode, curChF, selPiconF), VVVLxj=VVVLxj, title="Current Channel PIcon (already exists)")
    else:
     self.VVNJVx(mode, curChF, selPiconF, "overwrite")
   else:
    FFsqiC(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFsqiC(self, "Could not read current channel info. !", title=title)
 def VVNJVx(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FF6Ue4(self, boundFunction(self.VVRDMD, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVhREw(self, mode):
  pass
 def VVpzyy(self):
  pass
 def VViOHr(self):
  pass
 def VVx0QI(self):
  defDir = FFSw9u(CCfUPK.VVIatH() + "picons_backup")
  os.system(FFnz2p("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(boundFunction(self.VVZVRh, defDir), boundFunction(CCt0KP
         , mode=CCt0KP.VVAn9X, VVFaGg=CCfUPK.VVIatH()))
 def VVZVRh(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCfUPK.VVIatH():
    FFsqiC(self, "Cannot move to same directory !", title=title)
   else:
    if not FFSw9u(path) == FFSw9u(defDir):
     self.VVklWM(defDir)
    FFmhMd(self, boundFunction(FF6Ue4, self, boundFunction(self.VV6OFh, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVprx2), path), title=title)
  else:
   self.VVklWM(defDir)
 def VV6OFh(self, title, defDir, toPath):
  try:
   from shutil import move as iMove
  except:
   self.VVklWM(defDir)
   FFsqiC(self, 'Could not load "shutil" module !', title=title)
   return
  toPath = FFSw9u(toPath)
  pPath = CCfUPK.VVIatH()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVprx2:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVprx2)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFItCL(self, txt, title=title, VV1z5Z="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVsFQ3("all")
 def VVklWM(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVKFi4(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVprx2)
  s = "s" if tot > 1 else ""
  FFmhMd(self, boundFunction(FF6Ue4, self, boundFunction(self.VVy519, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, s), title=title)
 def VVy519(self, title):
  pPath = CCfUPK.VVIatH()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVprx2:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVprx2)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFejnb(str(totErr), VVKSBp)
  FFItCL(self, txt, title=title)
 def VVlPZw(self):
  lines = FFstFz("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFmhMd(self, boundFunction(self.VVjaEq, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVCf1C=True)
  else:
   FFEf0P(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVjaEq(self, fList):
  os.system(FFnz2p("find -L '%s' -type l -delete" % self.pPath))
  FFEf0P(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVr8jL(self):
  FF6Ue4(self, self.VV6zSt)
 def VV6zSt(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVegMJ()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFejnb("PIcon Directory:\n", VVj8eg)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FF5GXI(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FF5GXI(path)
   txt += FFejnb("PIcon File:\n", VVj8eg)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFstFz(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFejnb("Found %d SymLink%s to this file from:\n" % (tot, s), VVj8eg)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFRWNl(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFejnb(tChName, VVOn4X)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFejnb(line, VV6AHZ), tChName)
    txt += "\n"
   if chName:
    txt += FFejnb("Channel:\n", VVj8eg)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFejnb(chName, VVOn4X)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFejnb("Remarks:\n", VVj8eg)
    txt += "  %s\n" % FFejnb("Unused", VVKSBp)
  else:
   txt = "No info found"
  FFULTs(self, fncMode=CCazlH.VV9X1w, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVegMJ(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVprx2[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FF08Wi(sat)
  return fName, refCode, chName, sat, inDB
 def VVTc3h(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVprx2):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVSLSF(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVegMJ()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFejnb("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVj8eg))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVegMJ()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFejnb(self.curChanName, VVHuTi)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VV1dE5(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VVprx2:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFdBZy("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFItCL(self, txt, title=self.Title)
 def VVQQ0X(self):
  if not self.isBusy:
   VVVLxj = []
   VVVLxj.append(("All"         , "all"   ))
   VVVLxj.append(VVQP0R)
   VVVLxj.append(("Used by Channels"      , "used"  ))
   VVVLxj.append(("Unused PIcons"      , "unused"  ))
   VVVLxj.append(VVQP0R)
   VVVLxj.append(("PIcons Files"       , "pFiles"  ))
   VVVLxj.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVVLxj.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVVLxj.append(VVQP0R)
   VVVLxj.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVVLxj.append(VVQP0R)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFq77s(val)
      VVVLxj.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCicDe(self)
   filterObj.VVMxGo(VVVLxj, self.nsList, self.VVrRim)
 def VVrRim(self, item=None):
  if item is not None:
   self.VVsFQ3(item)
 def VVsFQ3(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVNVq6   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVG6BU   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVC3wX  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVkg6i  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVRsnY  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVdEDw  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVzUuq   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVeJaf   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VViC87 , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVdEDw:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFstFz("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFlf8A(self, "Not found", 1000)
     return
   elif mode == self.VVjNJW:
    return
   else:
    words, asPrefix = CCicDe.VVDnY4(words)
   if not words and mode in (self.VVeJaf, self.VViC87):
    FFlf8A(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FF6Ue4(self, boundFunction(self.VVRDMD, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVskQF(self):
  self.session.open(CCdrie, barTheme=CCdrie.VV5tD6
      , titlePrefix = ""
      , fncToRun  = self.VVjPoL
      , VVNtvf = self.VVBxx8)
 def VVjPoL(self, progBarObj):
  lameDbChans = CC7tYb.VVVqOu(self, CC7tYb.VV8Mbm, VVtwCC=False, VV2Adh=False)
  files = []
  words = []
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VV86go = []
  progBarObj.VVQkW1(len(lameDbChans))
  if lameDbChans:
   processChanName = CCfOPf()
   curCh = processChanName.VV6boC(self.curChanName)
   for refCode in lameDbChans:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVeaD2(1, True)
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCfUPK.VVlwQm(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCfUPK.VVzgnH(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       progBarObj.VV86go.append(f.replace(".png", ""))
 def VVBxx8(self, VV0mDv, VV86go, threadCounter, threadTotal, threadErr):
  if VV86go:
   self.timer = eTimer()
   fnc = boundFunction(FF6Ue4, self, boundFunction(self.VVRDMD, mode=self.VVjNJW, words=VV86go), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FFlf8A(self, "Not found", 2000)
 def VVRDMD(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVOQmR(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CC7tYb.VVVqOu(self, CC7tYb.VV8Mbm, VVtwCC=False, VV2Adh=False)
  iptvRefList = self.VVfre1()
  tList = []
  for fName, fType in CCfUPK.VVSltG(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVNVq6:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVG6BU  and chName         : isAdd = True
   elif mode == self.VVC3wX and not chName        : isAdd = True
   elif mode == self.VVkg6i  and fType == 0        : isAdd = True
   elif mode == self.VVRsnY  and fType == 1        : isAdd = True
   elif mode == self.VVdEDw  and fName in words       : isAdd = True
   elif mode == self.VVjNJW and fName in words       : isAdd = True
   elif mode == self.VVzUuq  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVeJaf  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VViC87:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVprx2   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FFlf8A(self)
  else:
   self.isBusy = False
   FFlf8A(self, "Not found", 1000)
   return
  self.VVprx2.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVTc3h()
  self.totalPIcons = len(self.VVprx2)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVv32c(True)
 def VVOQmR(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCfUPK.VVSltG(self.pPath):
    if fName:
     return True
   if isFirstTime : FFsqiC(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFlf8A(self, "Not found", 1000)
  else:
   FFsqiC(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVfre1(self):
  VV5tha = {}
  files  = CCvDyD.VVuQqZ(self)
  if files:
   for path in files:
    txt = FFb1Rx(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VV5tha[refCode] = item[1]
  return VV5tha
 def VVv32c(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VV5hB9 = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VV5hB9: self.curPage = VV5hB9
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVdbNn()
  if self.curPage == VV5hB9:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVSLSF()
  filName, refCode, chName, sat, inDB = self.VVegMJ()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVdbNn(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVprx2[ndx]
   fName = self.VVprx2[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFejnb(chName, VVOn4X))
    else : lbl.setText("-")
   except:
    lbl.setText(FFejnb(chName, VVWdSD))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVlwQm(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVBDSS():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVAJkA"   )
 @staticmethod
 def VVUDLs():
  VVVLxj = []
  VVVLxj.append(("Find SymLinks (to PIcon Directory)"   , "VVeTaZ"   ))
  VVVLxj.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVVLxj.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVVLxj
 @staticmethod
 def VVAJkA(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(SELF)
  png, path = CCfUPK.VV2fvd(refCode)
  if path : CCfUPK.VVIpaH(SELF, png, path)
  else : FFsqiC(SELF, "No PIcon found for current channel in:\n\n%s" % CCfUPK.VVIatH())
 @staticmethod
 def VVeTaZ(SELF):
  if VVHuTi:
   sed1 = FFFHM5("->", VVHuTi)
   sed2 = FFFHM5("picon", VVKSBp)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVWdSD, VVMNP0)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFzH9C(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFpWOv(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVIHQd(SELF, isPIcon):
  sed1 = FFFHM5("->", VVWdSD)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFFHM5("picon", VVKSBp)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFzH9C(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFpWOv(), grep, sed1, sed2))
 @staticmethod
 def VVSltG(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVIatH():
  path = CFG.PIconsPath.getValue()
  return FFSw9u(path)
 @staticmethod
 def VV2fvd(refCode, chName=None):
  if FF0mkS(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FF7COR(refCode)
  allPath, fName, refCodeFile, pList = CCfUPK.VVzgnH(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVIpaH(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFFHM5("%s%s" % (dest, png), VVOn4X))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFFHM5(errTxt, VVhgxA))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFtCAF(SELF, cmd)
 @staticmethod
 def VVzgnH(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCfUPK.VVIatH()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FF9jRB(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCygxn():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVZeAD  = None
  self.VVFsY2 = ""
  self.VVRq68  = noService
  self.VVcbKI = 0
  self.VV94J3  = noService
  self.VVfGa0 = 0
  self.VVMey3  = "-"
  self.VVeIeY = 0
  self.VVSxtt  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVrbNB(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVZeAD = frontEndStatus
     self.VVrL2a()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVrL2a(self):
  if self.VVZeAD:
   val = self.VVZeAD.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVFsY2 = "%3.02f dB" % (val / 100.0)
   else         : self.VVFsY2 = ""
   val = self.VVZeAD.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVcbKI = int(val)
   self.VVRq68  = "%d%%" % val
   val = self.VVZeAD.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVfGa0 = int(val)
   self.VV94J3  = "%d%%" % val
   val = self.VVZeAD.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVMey3  = "%d" % val
   val = int(val * 100 / 500)
   self.VVeIeY = min(500, val)
   val = self.VVZeAD.get("tuner_locked", 0)
   if val == 1 : self.VVSxtt = "Locked"
   else  : self.VVSxtt = "Not locked"
 def VV4F5Y(self)   : return self.VVFsY2
 def VVvTEv(self)   : return self.VVRq68
 def VVSaKM(self)  : return self.VVcbKI
 def VVgVcO(self)   : return self.VV94J3
 def VVDlij(self)  : return self.VVfGa0
 def VVqhwW(self)   : return self.VVMey3
 def VVVPTK(self)  : return self.VVeIeY
 def VVHYHY(self)   : return self.VVSxtt
 def VVH1vK(self) : return self.serviceName
class CC1kFd():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVT2MF(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFYly1(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VV2mcE(self.ORPOS  , mod=1   )
      self.sat2  = self.VV2mcE(self.ORPOS  , mod=2   )
      self.freq  = self.VV2mcE(self.FREQ  , mod=3   )
      self.sr   = self.VV2mcE(self.SR   , mod=4   )
      self.inv  = self.VV2mcE(self.INV  , self.D_PIL_INV)
      self.pol  = self.VV2mcE(self.POL  , self.D_POL )
      self.fec  = self.VV2mcE(self.FEC  , self.D_FEC )
      self.syst  = self.VV2mcE(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VV2mcE("modulation" , self.D_MOD )
       self.rolof = self.VV2mcE("rolloff"  , self.D_ROLOF )
       self.pil = self.VV2mcE("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VV2mcE("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VV2mcE("pls_code"  )
       self.iStId = self.VV2mcE("is_id"   )
       self.t2PlId = self.VV2mcE("t2mi_plp_id" )
       self.t2PId = self.VV2mcE("t2mi_pid"  )
 def VV2mcE(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFq77s(val)
  elif mod == 2   : return FFv6gW(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VV1qQf(self, refCode):
  txt = ""
  self.VVT2MF(refCode)
  if self.data:
   def VVGYYE(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVGYYE("System"   , self.syst)
    txt += VVGYYE("Satellite"  , self.sat2)
    txt += VVGYYE("Frequency"  , self.freq)
    txt += VVGYYE("Inversion"  , self.inv)
    txt += VVGYYE("Symbol Rate"  , self.sr)
    txt += VVGYYE("Polarization" , self.pol)
    txt += VVGYYE("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVGYYE("Modulation" , self.mod)
     txt += VVGYYE("Roll-Off" , self.rolof)
     txt += VVGYYE("Pilot"  , self.pil)
     txt += VVGYYE("Input Stream", self.iStId)
     txt += VVGYYE("T2MI PLP ID" , self.t2PlId)
     txt += VVGYYE("T2MI PID" , self.t2PId)
     txt += VVGYYE("PLS Mode" , self.plsMod)
     txt += VVGYYE("PLS Code" , self.plsCod)
   else:
    txt += VVGYYE("System"   , self.txMedia)
    txt += VVGYYE("Frequency"  , self.freq)
  return txt, self.namespace
 def VVw2cK(self, refCode):
  txt = "Transpoder : ?"
  self.VVT2MF(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VVj8eg + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVgI7x(self, refCode):
  self.data = None
  servRef = eServiceReference(refCode)
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFYly1(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VV2mcE(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VV2mcE(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VV2mcE(self.SYST, self.D_SYS_S)
     freq = self.VV2mcE(self.FREQ , mod=3  )
     if isSat:
      pol = self.VV2mcE(self.POL , self.D_POL)
      fec = self.VV2mcE(self.FEC , self.D_FEC)
      sr = self.VV2mcE(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VV99B8(self, refCode):
  self.data = None
  self.VVT2MF(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCj5OR():
 def __init__(self, VVJpBP, path, VVNtvf=None, curRowNum=-1):
  self.VVJpBP  = VVJpBP
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVNtvf  = VVNtvf
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFnz2p("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VV6qRR(curRowNum)
  else:
   FFsqiC(self.VVJpBP, "Error while preparing edit!")
 def VV6qRR(self, curRowNum):
  VV5tha = self.VVeRhW()
  VV5eNi = None #("Delete Line" , self.deleteLine  , [])
  VVgwCo = ("Save Changes" , self.VVPbmK   , [])
  VV0k9j  = ("Edit Line"  , self.VVpBYe    , [])
  VVa6E6 = ("Line Options" , self.VVh5Ub   , [])
  VVITUu = (""    , self.VVIzqp , [])
  VVjFfT = self.VVb4J9
  VV9oqL  = self.VVoI1Y
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVOhM5  = (CENTER  , LEFT  )
  VVV80v = FFoSxq(self.VVJpBP, None, title=self.Title, header=header, VVprx2=VV5tha, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=26, VV5eNi=VV5eNi, VVgwCo=VVgwCo, VV0k9j=VV0k9j, VVa6E6=VVa6E6, VVjFfT=VVjFfT, VV9oqL=VV9oqL, VVITUu=VVITUu, VV13Vm=True
    , VVkTTr   = "#11001111"
    , VVDVtL   = "#11001111"
    , VV1z5Z   = "#11001111"
    , VVps2K  = "#05333333"
    , VVNERz  = "#00222222"
    , VVJsTV  = "#11331133"
    )
  VVV80v.VVV5xQ(curRowNum)
 def VVh5Ub(self, VVV80v, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVV80v.VV9s1N()
  VVVLxj = []
  VVVLxj.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVVLxj.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVtNzw"  ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VV05kR:
   VVVLxj.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(  ("Delete Line"         , "deleteLine"   ))
  FFfsxJ(self.VVJpBP, boundFunction(self.VVsXrq, VVV80v, lineNum), VVVLxj=VVVLxj, title="Line Options")
 def VVsXrq(self, VVV80v, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VV58wT("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVV80v)
   elif item == "VVtNzw"  : self.VVtNzw(VVV80v, lineNum)
   elif item == "copyToClipboard"  : self.VVWjTG(VVV80v, lineNum)
   elif item == "pasteFromClipboard" : self.VVKM8L(VVV80v, lineNum)
   elif item == "deleteLine"   : self.VV58wT("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVV80v)
 def VVoI1Y(self, VVV80v):
  VVV80v.VVVSaO()
 def VVIzqp(self, VVV80v, title, txt, colList):
  if   self.insertMode == 1: VVV80v.VVa4bm()
  elif self.insertMode == 2: VVV80v.VVMEyz()
  self.insertMode = 0
 def VVtNzw(self, VVV80v, lineNum):
  if lineNum == VVV80v.VV9s1N():
   self.insertMode = 1
   self.VV58wT("echo '' >> '%s'" % self.tmpFile, VVV80v)
  else:
   self.insertMode = 2
   self.VV58wT("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVV80v)
 def VVWjTG(self, VVV80v, lineNum):
  global VV05kR
  VV05kR = FFdBZy("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVV80v.VVFMww("Copied to clipboard")
 def VVPbmK(self, VVV80v, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFnz2p("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFnz2p("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVV80v.VVFMww("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVV80v.VVVSaO()
    else:
     FFsqiC(self.VVJpBP, "Cannot save file!")
   else:
    FFsqiC(self.VVJpBP, "Cannot create backup copy of original file!")
 def VVb4J9(self, VVV80v):
  if self.fileChanged:
   FFmhMd(self.VVJpBP, boundFunction(self.VV9EMq, VVV80v), "Cancel changes ?")
  else:
   finalOK = os.system(FFnz2p("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VV9EMq(VVV80v)
 def VV9EMq(self, VVV80v):
  VVV80v.cancel()
  os.system(FFnz2p("rm -f '%s'" % self.tmpFile))
  if self.VVNtvf:
   self.VVNtvf(self.fileSaved)
 def VVpBYe(self, VVV80v, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVMNP0 + "ORIGINAL TEXT:\n" + VV6AHZ + lineTxt
  FFD8qa(self.VVJpBP, boundFunction(self.VVHNJg, lineNum, VVV80v), title="File Line", defaultText=lineTxt, message=message)
 def VVHNJg(self, lineNum, VVV80v, VVd6Iw):
  if not VVd6Iw is None:
   if VVV80v.VV9s1N() <= 1:
    self.VV58wT("echo %s > '%s'" % (VVd6Iw, self.tmpFile), VVV80v)
   else:
    self.VVLzo5(VVV80v, lineNum, VVd6Iw)
 def VVKM8L(self, VVV80v, lineNum):
  if lineNum == VVV80v.VV9s1N() and VVV80v.VV9s1N() == 1:
   self.VV58wT("echo %s >> '%s'" % (VV05kR, self.tmpFile), VVV80v)
  else:
   self.VVLzo5(VVV80v, lineNum, VV05kR)
 def VVLzo5(self, VVV80v, lineNum, newTxt):
  VVV80v.VVWc3V("Saving ...")
  lines = FF3tpP(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVV80v.VVXQXY()
  VV5tha = self.VVeRhW()
  VVV80v.VVnbpo(VV5tha)
 def VV58wT(self, cmd, VVV80v):
  tCons = CCsmtD()
  tCons.ePopen(cmd, boundFunction(self.VV9ABS, VVV80v))
  self.fileChanged = True
  VVV80v.VVXQXY()
 def VV9ABS(self, VVV80v, result, retval):
  VV5tha = self.VVeRhW()
  VVV80v.VVnbpo(VV5tha)
 def VVeRhW(self):
  if fileExists(self.tmpFile):
   lines = FF3tpP(self.tmpFile)
   VV5tha = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VV5tha.append((str(ndx), line.strip()))
   if not VV5tha:
    VV5tha.append((str(1), ""))
   return VV5tha
  else:
   FFPX6L(self.VVJpBP, self.tmpFile)
class CCicDe():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVVLxj   = []
  self.satList   = []
 def VVIfac(self, VVNtvf):
  self.VVVLxj = []
  VVVLxj, VVWi7m = self.VVuLWh(False, True)
  if VVVLxj:
   self.VVVLxj += VVVLxj
   self.VVUeFA(VVNtvf, VVWi7m)
 def VVqI2T(self, mode, VVV80v, satCol, VVNtvf):
  VVV80v.VVWc3V("Loading Filters ...")
  self.VVVLxj = []
  self.VVVLxj.append(("All Services" , "all"))
  if mode == 1:
   self.VVVLxj.append(VVQP0R)
   self.VVVLxj.append(("Parental Control", "parentalControl"))
   self.VVVLxj.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVVLxj.append(VVQP0R)
   self.VVVLxj.append(("Selected Transponder"   , "selectedTP" ))
   self.VVVLxj.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VV5a9l(VVV80v, satCol)
  VVVLxj, VVWi7m = self.VVuLWh(True, False)
  if VVVLxj:
   VVVLxj.insert(0, VVQP0R)
   self.VVVLxj += VVVLxj
  VVV80v.VV8Hdn()
  self.VVUeFA(VVNtvf, VVWi7m)
 def VVMxGo(self, VVVLxj, sats, VVNtvf):
  self.VVVLxj = VVVLxj
  VVVLxj, VVWi7m = self.VVuLWh(True, False)
  if VVVLxj:
   self.VVVLxj.append(VVQP0R)
   self.VVVLxj += VVVLxj
  self.VVUeFA(VVNtvf, VVWi7m)
 def VVUeFA(self, VVNtvf, VVWi7m):
  VVFM2s = ("Edit Filter", boundFunction(self.VVMVnX, VVWi7m))
  VVtOG5  = ("Filter Help", boundFunction(self.VVaq9d, VVWi7m))
  FFfsxJ(self.callingSELF, boundFunction(self.VVoJiH, VVNtvf), VVVLxj=self.VVVLxj, title="Select Filter", VVFM2s=VVFM2s, VVtOG5=VVtOG5)
 def VVoJiH(self, VVNtvf, item):
  if item:
   VVNtvf(item)
 def VVMVnX(self, VVWi7m, VVVpUgObj, sel):
  if fileExists(VVWi7m) : CCj5OR(self.callingSELF, VVWi7m, VVNtvf=None)
  else       : FFPX6L(self.callingSELF, VVWi7m)
  VVVpUgObj.cancel()
 def VVaq9d(self, VVWi7m, VVVpUgObj, sel):
  FFRzLG(self.callingSELF, VVMPsf + "_help_service_filter", "Service Filter")
 def VV5a9l(self, VVV80v, satColNum):
  if not self.satList:
   satList = VVV80v.VVbJ8P(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FF08Wi(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VVQP0R)
  if self.VVVLxj:
   self.VVVLxj += self.satList
 def VVuLWh(self, addTag, VVPeMj):
  FFqwad()
  fileName  = "ajpanel_services_filter"
  VVWi7m = VV28Xc + fileName
  VVVLxj  = []
  if not fileExists(VVWi7m):
   os.system(FFnz2p("cp -f '%s' '%s'" % (VVMPsf + fileName, VVWi7m)))
  fileFound = False
  if fileExists(VVWi7m):
   fileFound = True
   lines = FF3tpP(VVWi7m)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVVLxj.append((line, "__w__" + line))
       else  : VVVLxj.append((line, line))
  if VVPeMj:
   if   not fileFound : FFPX6L(self.callingSELF , VVWi7m)
   elif not VVVLxj : FFAqRk(self.callingSELF , VVWi7m)
  return VVVLxj, VVWi7m
 @staticmethod
 def VVDnY4(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CClNKv():
 def __init__(self, callingSELF, VVV80v, refCodeColNum):
  self.callingSELF = callingSELF
  self.VVV80v = VVV80v
  self.refCodeColNum = refCodeColNum
  self.VVVLxj = []
  iMulSel = self.VVV80v.VVzmAO()
  if iMulSel : self.VVVLxj.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVVLxj.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVV80v.VVTiyK()
  self.VVVLxj.append(    ("Select all"    , "selectAll"  ))
  if tot > 0:
   self.VVVLxj.append(   ("Unselect all"    , "unselectAll"  ))
  self.VVVLxj.append(VVQP0R)
 def VVKu0N(self, servName, refCode):
  tot = self.VVV80v.VVTiyK()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVVLxj.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VV2zcB_multi" ))
  else    : self.VVVLxj.append( ("Add to Bouquet : %s"      % servName , "VV2zcB_one" ))
  self.VVSpWN(servName, refCode)
 def VVAw0c(self, servName, refCode, pcState, hidState):
  self.VVVLxj = []
  if pcState == "No" : self.VVVLxj.append(("Add to Parental Control"  , "parentalControl_add"  ))
  else    : self.VVVLxj.append(("Remove from Parental Control" , "parentalControl_remove" ))
  if hidState == "No" : self.VVVLxj.append(("Add to Hidden Services"  , "hiddenServices_add"  ))
  else    : self.VVVLxj.append(("Remove from Hidden Services" , "hiddenServices_remove" ))
  self.VVSpWN(servName, refCode)
 def VVSpWN(self, servName, refCode):
  FFfsxJ(self.callingSELF, boundFunction(self.VVuJUf, servName, refCode), title="Options", VVVLxj=self.VVVLxj)
 def VVuJUf(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"    : self.VVV80v.VVkme0(True)
   elif item == "MultSelDisab"    : self.VVV80v.VVkme0(False)
   elif item == "selectAll"    : self.VVV80v.VVf2R7()
   elif item == "unselectAll"    : self.VVV80v.VVNkWH()
   elif item == "parentalControl_add"  : self.callingSELF.VVRZZS(self.VVV80v, refCode, True)
   elif item == "parentalControl_remove" : self.callingSELF.VVRZZS(self.VVV80v, refCode, False)
   elif item == "hiddenServices_add"  : self.callingSELF.VVoDXN(self.VVV80v, refCode, True)
   elif item == "hiddenServices_remove" : self.callingSELF.VVoDXN(self.VVV80v, refCode, False)
   elif item == "VV2zcB_multi" : self.VV2zcB(refCode, True)
   elif item == "VV2zcB_one" : self.VV2zcB(refCode, False)
 def VV2zcB(self, refCode, isMulti):
  bouquets = FFGqYY()
  if bouquets:
   VVVLxj = []
   for item in bouquets:
    VVVLxj.append((item[0], item[1].toString()))
   VVFM2s = ("Create New", boundFunction(self.VVMuLa, refCode, isMulti))
   FFfsxJ(self.callingSELF, boundFunction(self.VVHC4q, refCode, isMulti), VVVLxj=VVVLxj, title="Add to Bouquet", VVFM2s=VVFM2s, VVZFmG=True, VVoQKF=True)
  else:
   FFmhMd(self.callingSELF, boundFunction(self.VVxOrm, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVHC4q(self, refCode, isMulti, bName=None):
  if bName:
   FF6Ue4(self.VVV80v, boundFunction(self.VVAYVT, refCode, isMulti, bName), title="Adding Channels ...")
 def VVAYVT(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVwGBa(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVWP6Z = InfoBar.instance
    if VVWP6Z:
     VVHj5Y = VVWP6Z.servicelist
     if VVHj5Y:
      mutableList = VVHj5Y.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVV80v.VV8Hdn()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFEf0P(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FFsqiC(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVwGBa(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVV80v.VV2E7Y(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VVMuLa(self, refCode, isMulti, VVVpUgObj, path):
  self.VVxOrm(refCode, isMulti)
 def VVxOrm(self, refCode, isMulti):
  FFD8qa(self.callingSELF, boundFunction(self.VVdNLd, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVdNLd(self, refCode, isMulti, name):
  if name:
   FF6Ue4(self.VVV80v, boundFunction(self.VVz3Jv, refCode, isMulti, name), title="Adding Channels ...")
 def VVz3Jv(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVwGBa(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVWP6Z = InfoBar.instance
    if VVWP6Z:
     VVHj5Y = VVWP6Z.servicelist
     if VVHj5Y:
      try:
       VVHj5Y.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVHj5Y.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVV80v.VV8Hdn()
   title = "Add to Bouquet"
   if allOK: FFEf0P(self.callingSELF, "Added to : %s" % name, title=title)
   else : FFsqiC(self.callingSELF, "Nothing added!", title=title)
class CCkNaI(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFO5bN(VVuG99, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF4gq5(self)
  FFoPjD(self["keyRed"]  , "Exit")
  FFoPjD(self["keyGreen"]  , "Save")
  FFoPjD(self["keyYellow"] , "Refresh")
  FFoPjD(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVDgml  ,
   "green"   : self.VVD3jP ,
   "yellow"  : self.VV8aaF  ,
   "blue"   : self.VVXbco   ,
   "up"   : self.VV8dvU    ,
   "down"   : self.VV01GK   ,
   "left"   : self.VVA8pr   ,
   "right"   : self.VVUCwC   ,
   "cancel"  : self.VVDgml
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VV8aaF()
  self.VVwa6F()
  FFVXe6(self)
 def VVDgml(self) : self.close(True)
 def VVxDCH(self) : self.close(False)
 def VVXbco(self):
  self.session.openWithCallback(self.VV0VyO, boundFunction(CC6Nf8))
 def VV0VyO(self, closeAll):
  if closeAll:
   self.close()
 def VV8dvU(self):
  self.VVRrG4(1)
 def VV01GK(self):
  self.VVRrG4(-1)
 def VVA8pr(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVwa6F()
 def VVUCwC(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVwa6F()
 def VVRrG4(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VV6UMc(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VV6UMc(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VV6UMc(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VV9slZ(year)):
   days += 1 #29 days in a leap year February
  return days
 def VV9slZ(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVwa6F(self):
  for obj in self.list:
   FFXT3k(obj, "#11404040")
  FFXT3k(self.list[self.index], "#11ff8000")
 def VV8aaF(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVD3jP(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCsmtD()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVH4mZ)
 def VVH4mZ(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFEf0P(self, "Nothing returned from the system!")
  else:
   FFEf0P(self, str(result))
class CC6Nf8(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFO5bN(VVRHuj, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF4gq5(self, addLabel=True)
  FFoPjD(self["keyRed"]  , "Exit")
  FFoPjD(self["keyGreen"]  , "Sync")
  FFoPjD(self["keyYellow"] , "Refresh")
  FFoPjD(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVDgml   ,
   "green"   : self.VV352a  ,
   "yellow"  : self.VVLgYg ,
   "blue"   : self.VVLcy1  ,
   "cancel"  : self.VVDgml
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVAnAY()
  self.onShow.append(self.start)
 def start(self):
  FFiJN6(self.refresh)
  FFVXe6(self)
 def refresh(self):
  self.VVVB6u()
  self.VVkRHR(False)
 def VVDgml(self)  : self.close(True)
 def VVLcy1(self) : self.close(False)
 def VVAnAY(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVVB6u(self):
  self.VVYT5u()
  self.VVv33w()
  self.VVsKH6()
  self.VVCBQa()
 def VVLgYg(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVAnAY()
   self.VVVB6u()
   FFiJN6(self.refresh)
 def VV352a(self):
  if len(self["keyGreen"].getText()) > 0:
   FFmhMd(self, self.VVhjUo, "Synchronize with Internet Date/Time ?")
 def VVhjUo(self):
  self.VVVB6u()
  FFiJN6(boundFunction(self.VVkRHR, True))
 def VVYT5u(self)  : self["keyRed"].show()
 def VVRwTr(self)  : self["keyGreen"].show()
 def VVs3Jx(self) : self["keyYellow"].show()
 def VV6LL9(self)  : self["keyBlue"].show()
 def VVv33w(self)  : self["keyGreen"].hide()
 def VVsKH6(self) : self["keyYellow"].hide()
 def VVCBQa(self)  : self["keyBlue"].hide()
 def VVkRHR(self, sync):
  localTime = FFhOq2()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVNn3K(server)
   if epoch_time is not None:
    ntpTime = FFh92T(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCsmtD()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVH4mZ, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVs3Jx()
  self.VV6LL9()
  if ok:
   self.VVRwTr()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVH4mZ(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVkRHR(False)
  except:
   pass
 def VVNn3K(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFtswK():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCGriq(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFO5bN(VVTT2a, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FF4gq5(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  FFiJN6(self.VVTaZn)
 def VVTaZn(self):
  if FFtswK(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFXT3k(self["myBody"], color)
   FFXT3k(self["myLabel"], color)
  except:
   pass
class CCcdYk(Screen):
 def __init__(self, session, isFromExternal=False):
  size = CFG.signalSize.getValue()
  screenW = FFkUUP()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFO5bN(VVsfmu, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self.isFromExternal  = isFromExternal
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCUqx2(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCUqx2(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCUqx2(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCygxn()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FF4gq5(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VV8dvU          ,
   "down"  : self.VV01GK         ,
   "left"  : self.VVA8pr         ,
   "right"  : self.VVUCwC         ,
   "info"  : self.VVm8dI        ,
   "epg"  : self.VVm8dI        ,
   "menu"  : self.VVD7Js         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "blue"  : self.VVnGgs       ,
   "last"  : boundFunction(self.VVnCbK, -1)  ,
   "next"  : boundFunction(self.VVnCbK, 1)  ,
   "pageUp" : boundFunction(self.VVKmtz, True) ,
   "chanUp" : boundFunction(self.VVKmtz, True) ,
   "pageDown" : boundFunction(self.VVKmtz, False) ,
   "chanDown" : boundFunction(self.VVKmtz, False) ,
   "0"   : boundFunction(self.VVnCbK, 0)  ,
   "1"   : boundFunction(self.VVkfs3, pos=1) ,
   "2"   : boundFunction(self.VVkfs3, pos=2) ,
   "3"   : boundFunction(self.VVkfs3, pos=3) ,
   "4"   : boundFunction(self.VVkfs3, pos=4) ,
   "5"   : boundFunction(self.VVkfs3, pos=5) ,
   "6"   : boundFunction(self.VVkfs3, pos=6) ,
   "7"   : boundFunction(self.VVkfs3, pos=7) ,
   "8"   : boundFunction(self.VVkfs3, pos=8) ,
   "9"   : boundFunction(self.VVkfs3, pos=9) ,
  }, -1)
  self.onShown.append(self.VV0NuP)
  self.onClose.append(self.onExit)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  self.sliderSNR.VVvjsa()
  self.sliderAGC.VVvjsa()
  self.sliderBER.VVvjsa(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVkfs3()
  self.VVZZDFInfo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVZZDF)
  except:
   self.timer.callback.append(self.VVZZDF)
  self.timer.start(500, False)
 def VVZZDFInfo(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVrbNB(service)
  serviceName = self.tunerInfo.VVH1vK()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self)
  tp = CC1kFd()
  txt = tp.VVw2cK(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVZZDF(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVrbNB(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VV4F5Y())
   self["mySNR"].setText(self.tunerInfo.VVvTEv())
   self["myAGC"].setText(self.tunerInfo.VVgVcO())
   self["myBER"].setText(self.tunerInfo.VVqhwW())
   self.sliderSNR.VVYxJA(self.tunerInfo.VVSaKM())
   self.sliderAGC.VVYxJA(self.tunerInfo.VVDlij())
   self.sliderBER.VVYxJA(self.tunerInfo.VVVPTK())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVYxJA(0)
   self.sliderAGC.VVYxJA(0)
   self.sliderBER.VVYxJA(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self)
    if state and not state == "Tuned":
     FFlf8A(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVm8dI(self):
  FFULTs(self, fncMode=CCazlH.VVypMs)
 def VVD7Js(self):
  FFRzLG(self, VVMPsf + "_help_signal", "Signal Monitor (Keys)")
 def VVnGgs(self):
  self.session.open(CCwb6Z, isFromExternal=self.isFromExternal)
  self.close()
 def VV8dvU(self)  : self.VVkfs3(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VV01GK(self) : self.VVkfs3(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVA8pr(self) : self.VVkfs3(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVUCwC(self) : self.VVkfs3(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVkfs3(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVnCbK(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFvpqG(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVKmtz(self, isUp):
  FFlf8A(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVZZDFInfo()
  except:
   pass
class CCUqx2(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVvjsa(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFXT3k(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVMPsf +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFXT3k(self.covObj, self.covColor)
   else:
    FFXT3k(self.covObj, "#00006688")
    self.isColormode = True
  self.VVYxJA(0)
 def VVYxJA(self, val):
  val  = FFvpqG(val, self.minN, self.maxN)
  width = int(FFfgAB(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFvpqG(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCdrie(Screen):
 VV5tD6    = 0
 VVFqXe = 1
 VVxHAz = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVNtvf=None, barTheme=VV5tD6):
  ratio = self.VVkxYk(barTheme)
  self.skin, self.skinParam = FFO5bN(VVg91n, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVNtvf = VVNtvf
  self.isCancelled = False
  self.isError  = False
  self.curValue  = 0
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VV86go = None
  self.timer   = eTimer()
  self.myThread  = None
  FF4gq5(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VV0NuP)
  self.onClose.append(self.onExit)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  self.VVpm8g()
  self["myProgBarVal"].setText("0%")
  FFXT3k(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VV2Zjd()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV2Zjd)
  except:
   self.timer.callback.append(self.VV2Zjd)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def VVQkW1(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVoRkl_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VV86go), self.counter, self.maxValue, catName)
 def VVoRkl_fromImportEPG(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVoRkl_forcedUpdate(self, title):
  self.newTitle = title
  try:
   self.VV2Zjd()
  except:
   pass
 def VVeaD2(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VV86go), self.counter, self.maxValue)
  except:
   pass
 def VVU4TO(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVXE6d(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVW1q3(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFlf8A(self, "Cancelling ...")
  self.isCancelled = True
  self.VVklE7(False)
 def VVklE7(self, isDone):
  if self.VVNtvf:
   self.VVNtvf(isDone, self.VV86go, self.counter, self.maxValue, self.isError)
  self.close()
 def VV2Zjd(self):
  val = FFvpqG(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFfgAB(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VVklE7(True)
 def VVpm8g(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVFqXe, self.VVxHAz):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVkxYk(self, barTheme):
  if   barTheme == self.VVFqXe : return 0.7
  if   barTheme == self.VVxHAz : return 0.5
  else             : return 1
class CCsmtD(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVNtvf = {}
  self.commandRunning = False
  self.VVq4bA  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVNtvf, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVNtvf[name] = VVNtvf
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVq4bA:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVvezy, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVKtEF , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVvezy, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVKtEF , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVKtEF(name, retval)
  return True
 def VVvezy(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVKtEF(self, name, retval):
  if not self.VVq4bA:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVNtvf[name]:
   self.VVNtvf[name](self.appResults[name], retval)
  del self.VVNtvf[name]
 def VVMr6M(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCJsEA(Screen):
 def __init__(self, session, title="", VVsr3H=None, VVQNIQ=False, VVnx8l=False, VVCC07=False, VVY5OA=False, VVgxgF=False, VVOgd3=False, VVaC8s=VVbDZJ, VVPF19=None, VVYZNS=False, VVC5bj=None, VVwgWU="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFO5bN(VVJcJi, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FF4gq5(self, addScrollLabel=True)
  if not VVwgWU:
   VVwgWU = "Processing ..."
  self["myLabel"].setText("   %s" % VVwgWU)
  self.VVQNIQ   = VVQNIQ
  self.VVnx8l   = VVnx8l
  self.VVCC07   = VVCC07
  self.VVY5OA  = VVY5OA
  self.VVgxgF = VVgxgF
  self.VVOgd3 = VVOgd3
  self.VVaC8s   = VVaC8s
  self.VVPF19 = VVPF19
  self.VVYZNS  = VVYZNS
  self.VVC5bj  = VVC5bj
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCsmtD()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFST5G()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVsr3H, str):
   self.VVsr3H = [VVsr3H]
  else:
   self.VVsr3H = VVsr3H
  if self.VVCC07 or self.VVY5OA:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVVVdp, VVVVdp)
   self.VVsr3H.append("echo -e '\n%s\n' %s" % (restartNote, FFFHM5(restartNote, VVHuTi)))
   if self.VVCC07:
    self.VVsr3H.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVsr3H.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVgxgF:
   FFlf8A(self, "Processing ...")
  self.onLayoutFinish.append(self.VVTrWq)
  self.onClose.append(self.VVOWY4)
 def VVTrWq(self):
  self["myLabel"].VVtkCY(textOutFile="console" if self.enableSaveRes else "")
  if self.VVQNIQ:
   self["myLabel"].VVzhnR()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVLLz7()
  else:
   self.VVgWKx()
 def VVLLz7(self):
  if FFtswK():
   self["myLabel"].setText("Processing ...")
   self.VVgWKx()
  else:
   self["myLabel"].setText(FFejnb("\n   No connection to internet!", VVKSBp))
 def VVgWKx(self):
  allOK = self.container.ePopen(self.VVsr3H[0], self.VVjR5i, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVjR5i("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVOgd3 or self.VVCC07 or self.VVY5OA:
    self["myLabel"].setText(FFic6i("STARTED", VVHuTi) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVC5bj:
   colorWhite = CCBmjq.VVLBCX(VVMNP0)
   color  = CCBmjq.VVLBCX(self.VVC5bj[0])
   words  = self.VVC5bj[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVaC8s=self.VVaC8s)
 def VVjR5i(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVsr3H):
   allOK = self.container.ePopen(self.VVsr3H[self.cmdNum], self.VVjR5i, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVjR5i("Cannot connect to Console!", -1)
  else:
   if self.VVgxgF and FFNrW1(self):
    FFlf8A(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVOgd3:
    self["myLabel"].appendText("\n" + FFic6i("FINISHED", VVHuTi), self.VVaC8s)
   if self.VVQNIQ or self.VVnx8l:
    self["myLabel"].VVzhnR()
   if self.VVPF19 is not None:
    self.VVPF19()
   if not retval and self.VVYZNS:
    self.VVOWY4()
 def VVOWY4(self):
  if self.container.VVMr6M():
   self.container.killAll()
class CCEXpU(Screen):
 def __init__(self, session, VVsr3H=None, VVgxgF=False):
  self.skin, self.skinParam = FFO5bN(VVJcJi, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VV28Xc + "ajpanel_terminal.history"
  self.customCommandsFile = VV28Xc + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFdBZy("pwd") or "/home/root"
  self.container   = CCsmtD()
  FF4gq5(self, addScrollLabel=True)
  FFoPjD(self["keyRed"] , "Exit = Stop Command")
  FFoPjD(self["keyGreen"] , "OK = History")
  FFoPjD(self["keyYellow"], "Menu = Custom Cmds")
  FFoPjD(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVCNuo ,
   "cancel" : self.VV2PFk  ,
   "menu"  : self.VV0KJ5 ,
   "last"  : self.VVmVzs  ,
   "next"  : self.VVmVzs  ,
   "1"   : self.VVmVzs  ,
   "2"   : self.VVmVzs  ,
   "3"   : self.VVmVzs  ,
   "4"   : self.VVmVzs  ,
   "5"   : self.VVmVzs  ,
   "6"   : self.VVmVzs  ,
   "7"   : self.VVmVzs  ,
   "8"   : self.VVmVzs  ,
   "9"   : self.VVmVzs  ,
   "0"   : self.VVmVzs
  })
  self.onLayoutFinish.append(self.VV0NuP)
  self.onClose.append(self.VV3eYB)
 def VV0NuP(self):
  self["myLabel"].VVtkCY(isResizable=False, textOutFile="terminal")
  FFhU57(self["keyRed"]  , "#00ff8000")
  FFXT3k(self["keyRed"]  , self.skinParam["titleColor"])
  FFXT3k(self["keyGreen"]  , self.skinParam["titleColor"])
  FFXT3k(self["keyYellow"] , self.skinParam["titleColor"])
  FFXT3k(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVGoVy(FFdBZy("date"), 5)
  result = FFdBZy("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVzK7e()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVMPsf + "LinuxCommands.lst"
   newTemplate = VVMPsf + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFnz2p("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFnz2p("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VV3eYB(self):
  if self.container.VVMr6M():
   self.container.killAll()
   self.VVGoVy("Process killed\n", 4)
   self.VVzK7e()
 def VV2PFk(self):
  if self.container.VVMr6M():
   self.VV3eYB()
  else:
   FFmhMd(self, self.close, "Exit ?", VVb7kN=False)
 def VVzK7e(self):
  self.VVGoVy(self.prompt, 1)
  self["keyRed"].hide()
 def VVGoVy(self, txt, mode):
  if   mode == 1 : color = VVHuTi
  elif mode == 2 : color = VVj8eg
  elif mode == 3 : color = VVMNP0
  elif mode == 4 : color = VVKSBp
  elif mode == 5 : color = VV6AHZ
  elif mode == 6 : color = VV0ESq
  else   : color = VVMNP0
  try:
   self["myLabel"].appendText(FFejnb(txt, color))
  except:
   pass
 def VVfxdM(self, cmd):
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVGoVy(cmd, 2)
   self.VVGoVy("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVGoVy(ch, 0)
   self.VVGoVy("\nor\n", 4)
   self.VVGoVy("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVzK7e()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFejnb(parts[0].strip(), VVj8eg)
    right = FFejnb("#" + parts[1].strip(), VV0ESq)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVGoVy(txt, 2)
   lastLine = self.VV8TcG()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVSCnY(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVjR5i, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFsqiC(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVGoVy(data, 3)
 def VVjR5i(self, data, retval):
  if not retval == 0:
   self.VVGoVy("Exit Code : %d\n" % retval, 4)
  self.VVzK7e()
 def VVCNuo(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VV8TcG() == "":
   self.VVSCnY("cd /tmp")
   self.VVSCnY("ls")
  VV5tha = []
  if fileExists(self.commandHistoryFile):
   lines  = FF3tpP(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VV5tha.append((str(c), line, str(lNum)))
   self.VVaQXH(VV5tha, title, self.commandHistoryFile, isHistory=True)
  else:
   FFPX6L(self, self.commandHistoryFile, title=title)
 def VV8TcG(self):
  lastLine = FFdBZy("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVSCnY(self, cmd):
  os.system("echo '%s' >> %s" % (cmd, self.commandHistoryFile))
 def VV0KJ5(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FF3tpP(self.customCommandsFile)
   lastLineIsSep = False
   VV5tha = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VV5tha.append((str(c), line, str(lNum)))
   self.VVaQXH(VV5tha, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFPX6L(self, self.customCommandsFile, title=title)
 def VVaQXH(self, VV5tha, title, filePath=None, isHistory=False):
  if VV5tha:
   VVps2K = "#05333333"
   if isHistory: VVkTTr = VVDVtL = VV1z5Z = "#11000020"
   else  : VVkTTr = VVDVtL = VV1z5Z = "#06002020"
   VV3VnJ = VVa6E6 = None
   VV0k9j   = ("Send"   , self.VVF9ug        , [])
   VVgwCo  = ("Modify & Send" , self.VVrT3P        , [])
   if isHistory:
    VV3VnJ = ("Clear History" , self.VVVULu        , [])
   elif filePath:
    VVa6E6 = ("Edit File"  , boundFunction(self.VV70TD, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVOhM5     = (CENTER  , LEFT   , CENTER )
   FFoSxq(self, None, title=title, header=header, VVprx2=VV5tha, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=26, VV0k9j=VV0k9j, VVgwCo=VVgwCo, VV3VnJ=VV3VnJ, VVa6E6=VVa6E6, VV13Vm=True
     , VVkTTr   = VVkTTr
     , VVDVtL   = VVDVtL
     , VV1z5Z   = VV1z5Z
     , VVfHXr  = "#05ffff00"
     , VVps2K  = VVps2K
    )
  else:
   FFAqRk(self, filePath, title=title)
 def VVF9ug(self, VVV80v, title, txt, colList):
  cmd = colList[1].strip()
  VVV80v.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVGoVy("\n%s\n" % cmd, 6)
   self.VVGoVy(self.prompt, 1)
  else:
   self.VVfxdM(cmd)
 def VVrT3P(self, VVV80v, title, txt, colList):
  cmd = colList[1]
  self.VVytz2(VVV80v, cmd)
 def VVVULu(self, VVV80v, title, txt, colList):
  FFmhMd(self, boundFunction(self.VVUOU0, VVV80v), "Reset History File ?", title="Command History")
 def VVUOU0(self, VVV80v):
  os.system(FFnz2p("echo '' > %s" % self.commandHistoryFile))
  VVV80v.cancel()
 def VV70TD(self, filePath, VVV80v, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCj5OR(self, filePath, VVNtvf=boundFunction(self.VV92A1, VVV80v), curRowNum=rowNum)
  else     : FFPX6L(self, filePath)
 def VV92A1(self, VVV80v, fileChanged):
  if fileChanged:
   VVV80v.cancel()
   FFiJN6(self.VV0KJ5)
 def VVmVzs(self):
  self.VVytz2(None, self.lastCommand)
 def VVytz2(self, VVV80v, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFD8qa(self, boundFunction(self.VVoVXX, VVV80v), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVoVXX(self, VVV80v, cmd):
  if cmd and len(cmd) > 0:
   self.VVfxdM(cmd)
   if VVV80v:
    VVV80v.cancel()
class CCWwJA(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVd6Iw="", VVa8yN=False, VVCJs6=False, isTrimEnds=True):
  self.skin, self.skinParam = FFO5bN(VVrzGb, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FF4gq5(self, title, addLabel=True)
  FFoPjD(self["keyRed"] , "Up/Down = Change")
  FFoPjD(self["keyGreen"] , "Overwrite")
  FFoPjD(self["keyYellow"], "Pick Key Map")
  FFoPjD(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVCJs6   = VVCJs6
  self.VVa8yN  = VVa8yN
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVd6Iw, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVTH7N      ,
   "green"    : self.VVgoRD    ,
   "yellow"   : self.VV5jeB      ,
   "blue"    : self.VVHNhY     ,
   "menu"    : self.VVsA5h     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVujVE, True) ,
   "down"    : boundFunction(self.VVujVE, False) ,
   "left"    : self.VVBbbZ       ,
   "right"    : self.VVCNgH       ,
   "home"    : self.VVFxk2       ,
   "end"    : self.VVbq6a       ,
   "next"    : self.VVEoD7      ,
   "last"    : self.VV3KkW      ,
   "deleteForward"  : self.VVEoD7      ,
   "deleteBackward" : self.VV3KkW      ,
   "tab"    : self.VVIdwO       ,
   "toggleOverwrite" : self.VVgoRD    ,
   "0"     : self.VV8M5Y     ,
   "1"     : self.VV8M5Y     ,
   "2"     : self.VV8M5Y     ,
   "3"     : self.VV8M5Y     ,
   "4"     : self.VV8M5Y     ,
   "5"     : self.VV8M5Y     ,
   "6"     : self.VV8M5Y     ,
   "7"     : self.VV8M5Y     ,
   "8"     : self.VV8M5Y     ,
   "9"     : self.VV8M5Y
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVtaP8()
  self.onShown.append(self.VV0NuP)
  self.onClose.append(self.onExit)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  FFNG0p(self)
  self["myLabel"].setText(self.message)
  self.VVkkRA()
  if self.VVa8yN : self.VVgoRD()
  else    : self.VVAKcv()
  FFVXe6(self)
  FFXT3k(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVuBZb)
  except:
   self.timer.callback.append(self.VVuBZb)
 def onExit(self):
  self.timer.stop()
 def VVTH7N(self):
  self.VVVUtq()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVVUtq()
  self.close(None)
 def VVsA5h(self):
  VVVLxj = []
  VVVLxj.append(("Home"         , "home"    ))
  VVVLxj.append(("End"         , "end"     ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Clear All"       , "clearAll"   ))
  VVVLxj.append(("Clear To Home"      , "clearToHome"   ))
  VVVLxj.append(("Clear To End"       , "clearToEnd"   ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VV05kR:
   VVVLxj.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("To Capital Letters"     , "toCapital"   ))
  VVVLxj.append(("To Small Letters"      , "toSmall"    ))
  FFfsxJ(self, self.VVqpcs, title="Edit Options", VVVLxj=VVVLxj)
 def VVqpcs(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVFxk2()
   elif item == "end"     : self.VVbq6a()
   elif item == "clearAll"    : self.VVCIOA()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVFxk2()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VV05kR
    VV05kR = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VV05kR)
    self.VVFxk2()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVuBZb(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVgoRD(self):
  self["myInput"].toggleOverwrite()
  self.VVAKcv()
 def VV5jeB(self):
  self.session.openWithCallback(self.VVN5qk, boundFunction(CCG4kx, mode=self.charMode, VVCJs6=self.VVCJs6))
 def VVN5qk(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVkkRA()
 def VVAKcv(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVtaP8(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVVUtq(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVRL1T(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVBbbZ(self)     : self.VVkJ5C(self["myInput"].left)
 def VVCNgH(self)     : self.VVkJ5C(self["myInput"].right)
 def VVEoD7(self)     : self.VVkJ5C(self["myInput"].delete)
 def VVFxk2(self)     : self.VVkJ5C(self["myInput"].home)
 def VVbq6a(self)     : self.VVkJ5C(self["myInput"].end)
 def VV3KkW(self)    : self.VVkJ5C(self["myInput"].deleteBackward)
 def VVIdwO(self)     : self.VVkJ5C(self["myInput"].tab)
 def VVCIOA(self)     : self["myInput"].setText("")
 def VVkJ5C(self, fnc):
  fnc()
  self.VVuBZb()
 def VV8M5Y(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVRL1T(newChar, overwrite)
   self.VVU0OU(newChar, self["myInput"].mapping[number])
 def VVujVE(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCG4kx.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCG4kx.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVRL1T(newChar, True)
   for group in groups:
    if newChar in group:
     self.VVU0OU(newChar, group)
     break
 def VVU0OU(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVMNP0:
    group = VV6AHZ + group.replace(newChar, FFejnb(newChar, VVMNP0, VV6AHZ))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVHNhY(self):
  if self.VVCJs6 : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVkkRA()
 def VVkkRA(self):
  self["myInput"].mapping = CCG4kx.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCG4kx.RCU_MAP_TITLES[self.charMode])
class CCG4kx(Screen):
 VVwTDm  = 0
 VVxhiB  = 1
 VVXkxC  = 2
 VV1vWo  = 3
 VV0CLl = 4
 VVnIee = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols, arabic_nums1, arabic1)
       , ( symbols, arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A" , u"\u0628")
       , (u"\u0647" , u"\u062A")
       )
 def __init__(self, session, mode=VVwTDm, VVCJs6=False):
  self.skin, self.skinParam = FFO5bN(VVR7Yu, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVCJs6  = VVCJs6
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FF4gq5(self, title=self.Title)
  FFoPjD(self["keyRed"] ,"OK = Select")
  FFoPjD(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVlFv3     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVAdL0, -1) ,
   "next"  : boundFunction(self.VVAdL0, +1) ,
   "left"  : boundFunction(self.VVAdL0, -1) ,
   "right"  : boundFunction(self.VVAdL0, +1) ,
  }, -1)
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  FFXT3k(self["keyRed"], "#11222222")
  FFXT3k(self["keyGreen"], "#11222222")
  self.VVz8Xi()
 def VVz8Xi(self):
  self.VVdqzU()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVdqzU(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVAdL0(self, direction):
  if self.VVCJs6 : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVz8Xi()
 def VVlFv3(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCHGvY(Screen):
 def __init__(self, session, title="", message="", VVaC8s=VVbDZJ, VVkjQ1=False, VV1z5Z=None, VVKTEW=30):
  self.skin, self.skinParam = FFO5bN(VVJcJi, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVKTEW)
  self.session   = session
  FF4gq5(self, title, addScrollLabel=True)
  self.VVaC8s   = VVaC8s
  self.VVkjQ1   = VVkjQ1
  self.VV1z5Z   = VV1z5Z
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  self["myLabel"].VVtkCY(VVkjQ1=self.VVkjQ1)
  self["myLabel"].setText(self.message, self.VVaC8s)
  if self.VV1z5Z:
   FFXT3k(self["myBody"], self.VV1z5Z)
   FFXT3k(self["myLabel"], self.VV1z5Z)
   FFcIX7(self["myLabel"], self.VV1z5Z)
  self["myLabel"].VVzhnR()
class CCZ1lm(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFO5bN(VVwPKP, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FF4gq5(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  FF0Ius(self["errPic"], "err")
class CCKxAM(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FFO5bN(VVe2F2, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", 20)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FF4gq5(self, " ", addCloser=True)
class CCpYFz():
 def __init__(self, tSession, txt):
  self.win = tSession.instantiateDialog(CCKxAM, txt)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  self.timer   = eTimer()
  self.timerCounter = 0
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV1FmQ)
  except:
   self.timer.callback.append(self.VV1FmQ)
  self.timer.start(100, False)
 def VV1FmQ(self):
  self.timerCounter += 1
  if self.timerCounter > 15:
   self.timer.stop()
   self.win.hide()
class CC5fZh():
 VVBmpP    = 0
 VV5EO8  = 1
 VVilKV   = ""
 VVoSOs    = "ajpDownload"
 VVDrpe    = "/home/root/ajpanel_downloads"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVV80v   = None
  self.timer     = eTimer()
  self.VVCbWD   = 0
  self.VV7cU3  = 1
  self.VVZeHv  = 2
  self.VVBTUq   = 3
  self.VVrNgS   = 4
  VV5tha = self.VVWvSP()
  if VV5tha:
   self.VVV80v = self.VVflSJ(VV5tha)
  if not VV5tha and mode == self.VVBmpP:
   self.VVPeMjor("Download list is empty !")
   self.cancel()
  if mode == self.VV5EO8:
   FF6Ue4(self.VVV80v or self.SELF, boundFunction(self.VVGBkV, startDnld, decodedUrl), title="Checking Server ...")
  self.VVGWz1(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVGWz1)
  except:
   self.timer.callback.append(self.VVGWz1)
  self.timer.start(1000, False)
 def VVflSJ(self, VV5tha):
  VV5tha.sort(key=lambda x: int(x[0]))
  VVjFfT = self.VVJGOX
  VV0k9j  = ("Play"  , self.VV60i8 , [])
  VVEgOz = (""   , self.VVWFgy  , [])
  VV5eNi = ("Stop"  , self.VVPQ5u  , [])
  VVgwCo = ("Resume"  , self.VV3BTI , [])
  VV3VnJ = ("Options" , self.VViq07  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVOhM5  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFoSxq(self.SELF, None, title=self.Title, header=header, VVprx2=VV5tha, VVOhM5=VVOhM5, VVADeP=widths, VVKTEW=26, VV0k9j=VV0k9j, VVEgOz=VVEgOz, VVjFfT=VVjFfT, VV5eNi=VV5eNi, VVgwCo=VVgwCo, VV3VnJ=VV3VnJ, VVDVtL="#11110011", VVkTTr="#11220022", VV1z5Z="#11110011", VVfHXr="#00ffff00", VVps2K="#00223025", VVNERz="#0a333333", VVJsTV="#0a400040", VV13Vm=True, searchCol=1)
 def VVWvSP(self):
  lines = CC5fZh.VVShtz()
  VV5tha = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",")
     left  = parts[0].strip()
     decodedUrl = ",".join(parts[1:]).strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVNWlY(decodedUrl)
      if fName:
       if   FFATna(decodedUrl) : sType = "Movie"
       elif FFHCdb(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVUHXY(decodedUrl, fName)
       if size > -1: sizeTxt = CCt0KP.VVnUtG(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VV5tha.append((str(len(VV5tha) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VV5tha
 def VVUepa(self):
  VV5tha = self.VVWvSP()
  if VV5tha:
   if self.VVV80v : self.VVV80v.VVnbpo(VV5tha, VVAnAYMsg=False)
   else     : self.VVV80v = self.VVflSJ(VV5tha)
  else:
   self.cancel()
 def VVGWz1(self, force=False):
  if self.VVV80v:
   thrList = self.VVp9l9()
   VV5tha = []
   changed = False
   for ndx, row in enumerate(self.VVV80v.VVSUDw()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVCbWD
    if m3u8Log:
     percent = self.VV7j1Z(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVBTUq , "%.2f %%" % percent
      else   : flag, progr = self.VVrNgS , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFS6ZV(mPath)
     if curSize > -1:
      fSize = CCt0KP.VVnUtG(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCt0KP.VVnUtG(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFS6ZV(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVBTUq , "%.2f %%" % percent
       else   : flag, progr = self.VVrNgS , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCt0KP.VVnUtG(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrList:
     flag = self.VVZeHv
     if m3u8Log :
      if not speed and not force : flag = self.VV7cU3
      elif curSize == -1   : self.VVSoLa(False)
    elif flag == self.VVCbWD  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVCbWD  : color2 = "#f#00555555#"
    elif flag == self.VV7cU3 : color2 = "#f#0000FFFF#"
    elif flag == self.VVZeHv : color2 = "#f#0000FFFF#"
    elif flag == self.VVBTUq  : color2 = "#f#00FF8000#"
    elif flag == self.VVrNgS  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VV5Idi(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VV5tha.append(row)
   if changed or force:
    self.VVV80v.VVnbpo(VV5tha, VVAnAYMsg=False)
 def VV5Idi(self, flag):
  tDict = self.VViMH9()
  return tDict.get(flag, "?")
 def VVQA0G(self, state):
  for flag, txt in self.VViMH9().items():
   if txt == state:
    return flag
  return -1
 def VViMH9(self):
  return { self.VVCbWD: "Not started", self.VV7cU3: "Connecting", self.VVZeHv: "Downloading", self.VVBTUq: "Stopped", self.VVrNgS: "Completed" }
 def VVKkBg(self, title):
  colList = self.VVV80v.VVmoGA()
  path = colList[6]
  url  = colList[8]
  if self.VVDtm1() : self.VVPeMjor("Cannot delete !\n\nFile is downloading.")
  else      : FFmhMd(self.SELF, boundFunction(self.VV7FBu, path, url), "Delete ?\n\n%s" % path, title=title)
 def VV7FBu(self, path, url):
  m3u8Log = self.VVV80v.VVmoGA()[12].strip()
  if m3u8Log : os.system(FFnz2p("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFnz2p("rm -r '%s'" % path))
  self.VVVIgz()
  self.VVUepa()
 def VVVIgz(self):
  if self.VVDtm1():
   FFlf8A(self.VVV80v, self.VV5Idi(self.VVZeHv), 500)
  else:
   colList  = self.VVV80v.VVmoGA()
   state  = colList[4].strip()
   decodedUrl = colList[9].strip()
   if self.VVQA0G(state) in (self.VVCbWD, self.VVrNgS):
    lines = CC5fZh.VVShtz()
    newLines = []
    found = False
    for line in lines:
     if CC5fZh.VVeAdi(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVOJji(newLines)
     self.VVUepa()
     FFlf8A(self.VVV80v, "Removed.", 1000)
    else:
     FFlf8A(self.VVV80v, "Not found.", 1000)
   else:
    self.VVPeMjor("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVAJq2(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFmhMd(self.SELF, boundFunction(self.VVU20H, flag), ques, title=title)
 def VVU20H(self, flag):
  list = []
  for ndx, row in enumerate(self.VVV80v.VVSUDw()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVQA0G(state)
   if   flag == flagVal == self.VVrNgS: list.append(decodedUrl)
   elif flag == flagVal == self.VVCbWD : list.append(decodedUrl)
  lines = CC5fZh.VVShtz()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVOJji(newLines)
   self.VVUepa()
   FFlf8A(self.VVV80v, "%d removed." % totRem, 1000)
  else:
   FFlf8A(self.VVV80v, "Not found.", 1000)
 def VV5zlX(self):
  colList  = self.VVV80v.VVmoGA()
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFlf8A(self.VVV80v, "Poster exists", 1500)
  else    : FF6Ue4(self.VVV80v, boundFunction(self.VVrZqp, decodedUrl, path, png), title="Checking Server ...")
 def VVrZqp(self, decodedUrl, path, png):
  err = self.VVMiaL(decodedUrl, path, png)
  if err:
   FFsqiC(self.SELF, err, title="Poster Download")
 def VVMiaL(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCk6BG.VVv2o9(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCvDyD.VV3VMw(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCvDyD.VVSJvq(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCvDyD.VVZ0n9(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if pUrl:
   ext = os.path.splitext(pUrl)[1] or ".png"
   tPath, err = FFiBrv(pUrl, "ajpanel_tmp%s", timeout=2, mustBeImage=True)
   if err:
    return "Cannot download poster !\n\n%s" % err
   else:
    png = "%s%s" % (os.path.splitext(path)[0], ext)
    os.system(FFnz2p("mv -f '%s' '%s'" % (tPath, png)))
    FFC4fv(self.SELF, title=os.path.basename(png), VVRA9l=png, showGrnMsg="Downloaded")
  else:
   return "Cannot get Poster URL !\n\n%s" % err
  return ""
 def VVWFgy(self, VVV80v, title, txt, colList):
  def VVN08k(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVGYYE(key, val) : return "\n%s:\n%s\n" % (FFejnb(key, COLOR_CONS_BRIGHT_YELLOW), val.strip())
  heads  = self.VVV80v.VVS6aX()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVN08k(heads[i]  , CCt0KP.VVnUtG(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVN08k("Downloaded" , CCt0KP.VVnUtG(int(curSize), mode=0))
   else:
    txt += VVN08k(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVGYYE(heads[i], colList[i])
  FFItCL(self.SELF, txt, title=title)
 def VV60i8(self, VVV80v, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCt0KP.VVr5qG(self.SELF, path)
  else    : FFlf8A(self.VVV80v, "File not found", 1000)
 def VVJGOX(self, VVV80v):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVV80v:
   self.VVV80v.cancel()
  del self
 def VViq07(self, VVV80v, title, txt, colList):
  decodedUrl = colList[9].strip()
  if CFG.downloadAutoResume.getValue(): resumeTxt = "Disable"
  else        : resumeTxt = "Enable"
  VVVLxj = []
  VVVLxj.append(("Remove current row"      , "VVVIgz"  ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(('Remove all "Completed"'     , "remFinished"    ))
  VVVLxj.append(('Remove all "Not started"'     , "remPending"    ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Delete the file (and remove from list)" , "VVKkBg" ))
  if FFATna(decodedUrl):
   VVVLxj.append(VVQP0R)
   VVVLxj.append(("Download Movie Poster (from server)" , "VV5zlX"   ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append((resumeTxt + " Auto Resume"     , "VVx598"  ))
  FFfsxJ(self.SELF, self.VVIb9M, VVVLxj=VVVLxj, title=self.Title, VVZFmG=True, VVoQKF=True)
 def VVIb9M(self, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVVIgz"  : self.VVVIgz()
   elif ref == "remFinished"   : self.VVAJq2(self.VVrNgS, txt)
   elif ref == "remPending"   : self.VVAJq2(self.VVCbWD, txt)
   elif ref == "VVKkBg" : self.VVKkBg(txt)
   elif ref == "VV5zlX"  : self.VV5zlX()
   elif ref == "VVx598"  : self.VVx598()
 def VVGBkV(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCk6BG.VVv2o9(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVPeMjor("Could not get download link !\n\nTry again later.")
     return
  for line in CC5fZh.VVShtz():
   if CC5fZh.VVeAdi(decodedUrl, line):
    self.VVabXP(decodedUrl)
    FFiJN6(boundFunction(FFlf8A, self.VVV80v, "Already listed !", 2000))
    break
  else:
   params = self.VV33D7(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVPeMjor(params[0])
   elif len(params) == 2:
    self.VVSlKm(params[0], decodedUrl)
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCt0KP.VVnUtG(fSize)
    FFmhMd(self.SELF, boundFunction(self.VVVrAy, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVVrAy(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CC5fZh.VVDrpe, "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVUepa()
  if self.VVV80v:
   self.VVV80v.VVMEyz()
  if startDnld:
   threadName = self.VVoSOs + decodedUrl
   self.VVkTDb(threadName, url, decodedUrl, path, resp)
 def VVabXP(self, decodedUrl):
  for ndx, row in enumerate(self.VVV80v.VVSUDw()):
   decodedUrl2 = row[9].strip()
   if decodedUrl == decodedUrl2 and self.VVV80v:
    self.VVV80v.VVlvF6(ndx)
    break
 def VV33D7(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVNWlY(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVUHXY(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCk6BG.VVv2o9(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCk6BG.VVd5QDHeader()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head["Content-Length"]
   cType = head["Content-Type"]
   if not "video" in cType:
    if resp.url.endswith(".m3u8"):
     return [resp, 1]
    else:
     return ["Cannot download this video !\n\nNot allowed by server."]
   if "Accept-Ranges" in head:
    resume = head["Accept-Ranges"]
    if not resume == "none":
     resumable = True
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  err = CC5fZh.VVO25u(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVSlKm(self, resp, decodedUrl):
  if not os.system(FFnz2p("which ffmpeg")) == 0:
   FFmhMd(self.SELF, boundFunction(CCvDyD.VVJJv3, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVNWlY(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VV0dFd(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFmhMd(self.SELF, boundFunction(self.VVp3Bc, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVp3Bc(rTxt, rUrl)
  else:
   self.VVPeMjor("Cannot process m3u8 file !")
 def VV0dFd(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVVLxj = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCvDyD.VVpWHe(rUrl, fPath)
   VVVLxj.append((resol, fullUrl))
  if VVVLxj:
   FFfsxJ(self.SELF, self.VVSeyj, VVVLxj=VVVLxj, title="Resolution", VVZFmG=True, VVoQKF=True)
  else:
   self.VVPeMjor("Cannot get Resolutions list from server !")
 def VVSeyj(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFmhMd(self.SELF, boundFunction(FFiJN6, boundFunction(self.VVtc0n, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFiJN6(boundFunction(self.VVtc0n, resolUrl))
 def VVtc0n(self, resolUrl):
  txt, err = CCk6BG.VVwCgh(resolUrl)
  if err : self.VVPeMjor(err)
  else : self.VVp3Bc(txt, resolUrl)
 def VVaxr6(self, logF, decodedUrl):
  found = False
  lines = CC5fZh.VVShtz()
  with open(CC5fZh.VVDrpe, "w") as f:
   for line in lines:
    if CC5fZh.VVeAdi(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CC5fZh.VVDrpe, "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVUepa()
 def VVp3Bc(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCvDyD.VVpWHe(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVPeMjor("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVaxr6(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFnz2p("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = self.VVoSOs + decodedUrl
  myThread = iThread(name=threadName, target=boundFunction(os.system, cmd))
  myThread.start()
 def VV7j1Z(self, dnldLog):
  if fileExists(dnldLog):
   dur = self.VVjO0k(dnldLog)
   if dur > -1:
    tim = self.VVggAq(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 def VVjO0k(self, dnldLog):
  lines = FFstFz("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVggAq(self, dnldLog):
  lines = FFstFz("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVUHXY(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFHCdb(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFnz2p("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVkTDb(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVV80v.VVmoGA()[7].strip())
  myThread = iThread(name=threadName, target=boundFunction(self.VV3cul, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VV3cul(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if CC5fZh.VVilKV == path:
       break
     else:
      break
  except:
   return
  if CC5fZh.VVilKV:
   CC5fZh.VVilKV = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFS6ZV(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VV33D7(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VV3cul(url, decodedUrl, path, resp, totFileSize, True)
 def VVPQ5u(self, VVV80v, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVUzZR() : FFlf8A(self.VVV80v, self.VV5Idi(self.VVrNgS), 500)
  elif not self.VVDtm1() : FFlf8A(self.VVV80v, self.VV5Idi(self.VVBTUq), 500)
  elif m3u8Log      : FFmhMd(self.SELF, self.VVSoLa, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVp9l9():
    CC5fZh.VVilKV = colList[6]
    FFlf8A(self.VVV80v, "Stopping ...", 1000)
   else:
    FFlf8A(self.VVV80v, "Stopped", 500)
 def VVSoLa(self, withMsg=True):
  if withMsg:
   FFlf8A(self.VVV80v, "Stopping ...", 1000)
  os.system(FFnz2p("killall -INT ffmpeg"))
 def VVx598(self):
  CFG.downloadAutoResume.setValue(not CFG.downloadAutoResume.getValue())
  CFG.downloadAutoResume.save()
  configfile.save()
 def VV3BTI(self, *args):
  if   self.VVUzZR() : FFlf8A(self.VVV80v, self.VV5Idi(self.VVrNgS) , 500)
  elif self.VVDtm1() : FFlf8A(self.VVV80v, self.VV5Idi(self.VVZeHv), 500)
  else:
   resume = False
   m3u8Log = self.VVV80v.VVmoGA()[12].strip()
   if m3u8Log:
    if fileExists(m3u8Log) : FFmhMd(self.SELF, boundFunction(self.VVcoat, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VV5H7K():
    resume = True
   if resume: FF6Ue4(self.VVV80v, boundFunction(self.VVVMFD), title="Checking Server ...")
   else  : FFlf8A(self.VVV80v, "Cannot resume !", 500)
 def VVcoat(self, m3u8Log):
  os.system(FFnz2p("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FF6Ue4(self.VVV80v, boundFunction(self.VVVMFD), title="Checking Server ...")
 def VVVMFD(self):
  colList  = self.VVV80v.VVmoGA()
  path  = colList[6].strip()
  size  = colList[7].strip()
  decodedUrl = colList[9].strip()
  if "j.php" in decodedUrl:
   url = CCk6BG.VVv2o9(decodedUrl)
   if url:
    decodedUrl = self.VVWZM2(decodedUrl, url)
   else:
    self.VVPeMjor("Could not get download link !\n\nTry again later.")
    return
  curSize = FFS6ZV(path)
  params = self.VV33D7(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVPeMjor(params[0])
   return
  elif len(params) == 2:
   self.VVSlKm(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVWZM2(decodedUrl, url, fSize)
  threadName = self.VVoSOs + decodedUrl
  if resumable: self.VVkTDb(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVPeMjor("Cannot resume from server !")
 def VVNWlY(self, decodedUrl):
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(http:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   x = decodedUrl.find("&mode")
   if x > -1: url = decodedUrl[:x]
   fName = ".mp4"
   x = decodedUrl.find("&end=")
   if x > -1: chName = decodedUrl[x+5:]
  if url and fName and chName:
   mix  = fName + chName
   fName =  mix.split(":")[0]
   chName = ":".join(mix.split(":")[1:])
   fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
   url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVPeMjor(self, txt):
  FFsqiC(self.SELF, txt, title=self.Title)
 def VVp9l9(self):
  thrList = []
  for thr in iEnumerate():
   if self.VVoSOs in thr.name:
    thrList.append(thr.name.replace(self.VVoSOs, ""))
  return thrList
 def VVDtm1(self):
  decodedUrl = self.VVV80v.VVmoGA()[9].strip()
  return decodedUrl in self.VVp9l9()
 def VVUzZR(self):
  colList = self.VVV80v.VVmoGA()
  path = colList[6].strip()
  size = colList[7].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFS6ZV(path)) == size
 def VV5H7K(self):
  colList = self.VVV80v.VVmoGA()
  path = colList[6].strip()
  size = int(colList[7].strip())
  curSize = FFS6ZV(path)
  if curSize > -1:
   size -= curSize
  err = CC5fZh.VVO25u(size)
  if err:
   FFsqiC(self.SELF, err, title=self.Title)
   return False
  return True
 def VVOJji(self, list):
  with open(CC5fZh.VVDrpe, "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVWZM2(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CC5fZh.VVShtz()
  url = decodedUrl
  with open(CC5fZh.VVDrpe, "w") as f:
   for line in lines:
    if CC5fZh.VVeAdi(decodedUrl, line):
     parts = line.split(",")
     oldUrl = ",".join(parts[1:]).strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVUepa()
  return url
 @staticmethod
 def VVShtz():
  list = []
  if fileExists(CC5fZh.VVDrpe):
   for line in FF3tpP(CC5fZh.VVDrpe):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVeAdi(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVO25u(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCt0KP.VVgx5r(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCt0KP.VVnUtG(size), CCt0KP.VVnUtG(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVQf9p(SELF):
  tot = CC5fZh.VV862u()
  if tot:
   FFsqiC(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VV862u():
  c = 0
  for thread in iEnumerate():
   if thread.name.startswith(CC5fZh.VVoSOs):
    c += 1
  return c
 @staticmethod
 def VVCMkz():
  return len(CC5fZh.VVShtz()) == 0
 @staticmethod
 def VV5LuL():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVaDhR():
  mPoints = CC5fZh.VV5LuL()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFnz2p("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVPI3i(SELF):
  CC5fZh.VVrz1I(SELF, CC5fZh.VVBmpP)
 @staticmethod
 def VVt6Ar_cur(SELF):
  CC5fZh.VVrz1I(SELF, CC5fZh.VV5EO8, startDnld=True)
 @staticmethod
 def VVt6Ar_url(SELF, url):
  CC5fZh.VVrz1I(SELF, CC5fZh.VV5EO8, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVjpN9Current(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(SELF)
  added, skipped = CC5fZh.VVjpN9List([decodedUrl])
  FFlf8A(SELF, "Added", 1000)
 @staticmethod
 def VVjpN9List(list):
  added = skipped = 0
  for line in CC5fZh.VVShtz():
   for ndx, url in enumerate(list):
    if url and CC5fZh.VVeAdi(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CC5fZh.VVDrpe, "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVrz1I(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCPIXA.VV0lgC(SELF):
   return
  if mode == CC5fZh.VVBmpP and CC5fZh.VVCMkz():
   FFsqiC(SELF, "Download list is empty !", title=title)
  else:
   inst = CC5fZh(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
class CCwb6Z(Screen, CCe8Ax):
 VVDGB5 = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False, enableDownloadMenu=True):
  self.skin, self.skinParam = FFO5bN(VVCpbF, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCe8Ax.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  FF4gq5(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VV9xha())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayDnld"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV13Bz         ,
   "info"  : self.VVm8dI        ,
   "epg"  : self.VVm8dI        ,
   "menu"  : self.VVuzSz       ,
   "cancel" : self.cancel         ,
   "blue"  : self.VV56Cs        ,
   "green"  : self.VV2Jlk    ,
   "yellow" : self.VV891q   ,
   "left"  : boundFunction(self.VVJAPd, -1)   ,
   "right"  : boundFunction(self.VVJAPd,  1)   ,
   "play"  : self.VVBEJK        ,
   "pause"  : self.VVBEJK        ,
   "playPause" : self.VVBEJK        ,
   "stop"  : self.VVBEJK        ,
   "rewind" : self.VVLGA9        ,
   "forward" : self.VVb6uY        ,
   "rewindDm" : self.VVLGA9        ,
   "forwardDm" : self.VVb6uY        ,
   "last"  : boundFunction(self.VVDG8G, 0)    ,
   "next"  : self.VVvxmO        ,
   "pageUp" : boundFunction(self.VVaCF6, True) ,
   "pageDown" : boundFunction(self.VVaCF6, False) ,
   "chanUp" : boundFunction(self.VVaCF6, True) ,
   "chanDown" : boundFunction(self.VVaCF6, False) ,
   "up"  : boundFunction(self.VVaCF6, True) ,
   "down"  : boundFunction(self.VVaCF6, False) ,
   "audio"  : boundFunction(self.VV6Chz, True) ,
   "subtitle" : boundFunction(self.VV6Chz, False) ,
   "0"   : boundFunction(self.VVAuYH , 10)  ,
   "1"   : boundFunction(self.VVAuYH , 1)  ,
   "2"   : boundFunction(self.VVAuYH , 2)  ,
   "3"   : boundFunction(self.VVAuYH , 3)  ,
   "4"   : boundFunction(self.VVAuYH , 4)  ,
   "5"   : boundFunction(self.VVAuYH , 5)  ,
   "6"   : boundFunction(self.VVAuYH , 6)  ,
   "7"   : boundFunction(self.VVAuYH , 7)  ,
   "8"   : boundFunction(self.VVAuYH , 8)  ,
   "9"   : boundFunction(self.VVAuYH , 9)
  }, -1)
  self.onShown.append(self.VV0NuP)
  self.onClose.append(self.onExit)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  FFNG0p(self)
  if not CCwb6Z.VVDGB5:
   CCwb6Z.VVDGB5 = self
  else:
   self.close()
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  self["myPlayDnld"].instance.move(ePoint(int(left - self.skinParam["titleH"]), int(top)))
  self["myPlayDnld"].hide()
  FF0Ius(self["myPlayDnld"], "dnld")
  self.VVafuH()
  self.instance.move(ePoint(40, 40))
  self.VVm1Ut(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVnppU)
  except:
   self.timer.callback.append(self.VVnppU)
  self.timer.start(250, False)
  self.VVnppU("Checking ...")
  self.VVrAHT()
 def VV2Jlk(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self)
  if "chCode" in iptvRef:
   if CCPIXA.VV0lgC(self):
    self.VVrAHT(True)
 def VVafuH(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl:
   color = "#1120002a"
   self["myPlayGrn"].show()
  else:
   color = "#1100202a"
   self["myPlayGrn"].hide()
  FFXT3k(self["myTitle"], color)
 def VVuzSz(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self)
  VVVLxj = []
  if self.isFromExternal:
   VVVLxj.append(("IPTV Menu"     , "iptv"  ))
   VVVLxj.append(VVQP0R)
  if FF0mkS(iptvRef) and not "&end=" in decodedUrl and not FFSZwx(decodedUrl):
   uType, uHost, uUser, uPass, uId, uChName = CCvDyD.VV3VMw(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVVLxj.append(("Catchup Programs"   , "catchup"  ))
    VVVLxj.append(VVQP0R)
  VVVLxj.append(("Stop Current Service"    , "stop"  ))
  VVVLxj.append(("Restart Current Service"   , "restart"  ))
  VVVLxj.append(VVQP0R)
  FFATnaSeries = FFSZwx(decodedUrl)
  if FFATnaSeries:
   VVVLxj.append(("File Size"     , "fileSize" ))
   VVVLxj.append(VVQP0R)
  if self.enableDownloadMenu:
   addSep = False
   if FF0mkS(iptvRef) and FFATnaSeries:
    VVVLxj.append(("Start Download"   , "dload_cur" ))
    VVVLxj.append(("Add to Download List"  , "addToDload" ))
    addSep = True
   if not CC5fZh.VVCMkz():
    VVVLxj.append(("Download Manager"   , "dload_stat" ))
    addSep = True
   if addSep:
    VVVLxj.append(VVQP0R)
  if not CCt0KP.VVdwLP:
   fPath, fDir, fName = CCt0KP.VVU7Qg(self)
   if fPath:
    VVVLxj.append((VVHuTi + "Open path in File Manager", "VVTdtc"))
    VVVLxj.append(VVQP0R)
  VVVLxj.append(("Move to Top"      , "top"   ))
  VVVLxj.append(("Move to Bottom"     , "botm"  ))
  VVVLxj.append(("Help"        , "help"  ))
  FFfsxJ(self, self.VVOgLS, VVVLxj=VVVLxj, width=550, title="Options")
 def VVOgLS(self, item=None):
  if item:
   if item == "iptv"    : self.VVal6o()
   elif item == "catchup"   : self.VV891q()
   elif item == "stop"    : self.VV9nzH(0)
   elif item == "restart"   : self.VV9nzH(1)
   elif item == "fileSize"   : FF6Ue4(self, boundFunction(CCazlH.VVYLrY, self), title="Checking Server")
   elif item == "dload_cur"  : CC5fZh.VVt6Ar_cur(self)
   elif item == "addToDload"  : CC5fZh.VVjpN9Current(self)
   elif item == "dload_stat"  : CC5fZh.VVPI3i(self)
   elif item == "VVTdtc": self.VVTdtc()
   elif item == "botm"    : self.VVm1Ut(0)
   elif item == "top"    : self.VVm1Ut(1)
   elif item == "help"    : FFRzLG(self, VVMPsf + "_help_player", "Player Controller (Keys)")
 def onExit(self):
  self.timer.stop()
  CCwb6Z.VVDGB5 = None
 def VVHg1D(self):
  if CCwb6Z.VVDGB5:
   self.session.open(CCwb6Z, enableZapping= False, enableDownloadMenu=False)
  self.close()
 def VVTdtc(self):
  self.session.open(CCt0KP, gotoMovie=True)
  self.VVHg1D()
 def VVal6o(self):
  self.session.open(CCvDyD)
  self.VVHg1D()
 def VV9nzH(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.close()
   elif typ == 1:
    self.VVnppU("Restarting Service ...")
    FFiJN6(boundFunction(self.VVgU3S, serv))
 def VVgU3S(self, serv):
  self.session.nav.stopService()
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self)
  if "&end=" in decodedUrl: boundFunction(self.VVrAHT, True)
  else     : self.session.nav.playService(serv)
 def VVm1Ut(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VV13Bz(self):
  if self.isManualSeek:
   self.VViANv()
   self.VVDG8G(self.manualSeekPts)
  else:
   if self.shown: self.hide()
   else   : self.show()
 def cancel(self):
  if self.isManualSeek:
   self.VViANv()
  else:
   self.close()
 def VVm8dI(self):
  FFULTs(self, fncMode=CCazlH.VVOecd)
 def VVBEJK(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except Exception as e:
   pass
  self.VVnppU("Toggling Play/Pause ...")
 def VViANv(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVJAPd(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVi14U()
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.jumpMinutes * 60.0
   else:
    self.manualSeekSec += direc * self.jumpMinutes * 60.0
    self.manualSeekSec = FFvpqG(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFfgAB(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFqFgA(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVAuYH(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   FFoPjD(self["myPlayJmp"], self.VV9xha())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVnppU("Changed Jump Minutes to : %d" % val)
 def VV9xha(self):
  return "Jump:%dm" % self.jumpMinutes
 def VVnppU(self, stateTxt="", highlight=False):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self)
  fr = res = ""
  if info:
   w = FFodTd(info, iServiceInformation.sVideoWidth) or -1
   h = FFodTd(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFodTd(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CCazlH.VVq4uw(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVi14U()
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FFvpqG(percVal, 0, 100)
    width = int(FFfgAB(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not posTxt: self["myPlayPos"].setText("")
  if not remTxt: self["myPlayRem"].setText("")
  if not durTxt:
   if   prov : txt = prov
   elif posTxt : txt = ">>>>"
   else  : txt = "...."
   self["myPlayVal"].setText(txt)
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText("")
   FFXT3k(self["myPlayBarBG"], "#1100202a")
   self["myPlayBarF"].hide()
  else:
   FFXT3k(self["myPlayBarBG"], "#11000000")
   self["myPlayBarF"].show()
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VVXWLS() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   if highlight: FFhU57(self["myPlayMsg"], "#0000ffff")
   else  : FFhU57(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   self["myPlayMsg"].setText("-" if decodedUrl else FFT3eZ(refCode, True))
   FFhU57(self["myPlayMsg"], "#00ff8066")
  tot = CC5fZh.VV862u()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVpckz()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VVDG8G(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
  state = self.VVU9xz()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFhU57(self["myPlayMsg"], "#0000ff00")
  else     : FFhU57(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVi14U(self):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = self.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFqFgA(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFqFgA(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal
      remTxt = FFqFgA(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVpckz(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VV56Cs(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VVXWLS()
   if cList:
    VVVLxj = []
    for pts, what in cList:
     txt = FFqFgA(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVVLxj.append((txt, pts))
    FFfsxJ(self, self.VVfXsW, VVVLxj=VVVLxj, title="Cut List")
   else:
    self.VVnppU("No Cut-List for this channel !")
 def VVfXsW(self, item=None):
  if item:
   self.VVDG8G(item)
 def VVXWLS(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVb6uY(self) : self.VVAibw(self.jumpMinutes)
 def VVLGA9(self) : self.VVAibw(-self.jumpMinutes)
 def VVAibw(self, mins):
  try:
   inst = InfoBar.instance
   inst.doSeekRelative(mins * 60 * 90000)
   inst.hide()
   if   mins > 0 : self.VVnppU("Forawrd (%d min) ..." % self.jumpMinutes)
   elif mins < 0 : self.VVnppU("Rewind (%d min) ..." % self.jumpMinutes)
  except:
   self.VVnppU("Cannot jump")
 def VVUyXc(self):
  InfoBar.instance.VVUyXc()
 def VVDG8G(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVnppU("Changing Time ...")
 def VVvxmO(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVi14U()
   if durVal > 0:
    pts = int(durVal * 60 * 90000)
    InfoBar.instance.doSeek(pts)
    self.VVnppU("Jumping to end ...")
  except:
   pass
 def VVU9xz(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVaCF6(self, isUp):
  if self.enableZapping:
   self.VVnppU("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VViANv()
   if self.portalTableParam:
    FFiJN6(boundFunction(self.VVljHm, isUp))
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self)
    if "/timeshift/" in decodedUrl:
     self.VVnppU("Cannot Zap Catcup TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VV7s6z()
 def VV7s6z(self):
  self.lastPlayPos = 0
  self.VVafuH()
  self.VVrAHT()
 def VVljHm(self, isUp):
  CCvDyD_inatance, VVV80v, mode = self.portalTableParam
  if isUp : VVV80v.VVhuBb()
  else : VVV80v.VVbMto()
  colList = VVV80v.VVmoGA()
  if mode == "localIptv":
   chName, chUrl = CCvDyD_inatance.VV8nYY(VVV80v, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCvDyD_inatance.VVCxbt(VVV80v, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCvDyD_inatance.VViEA6(mode, VVV80v, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCvDyD_inatance.VVbRZt(mode, VVV80v, colList)
  else:
   self.VVnppU("Cannot Zap")
   return
  FFIFfg(self, chUrl, VVb10q=False)
  self.VV7s6z()
 def VVrAHT(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVi14U()
    if posTxt:
     return
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self)
   if not self.VVyx1g(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVnppU("Refreshing Portal")
   FFiJN6(self.VVvl8c)
  except:
   pass
 def VVvl8c(self):
  self.restoreLastPlayPos = self.VVQv5i()
 def VV891q(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiUIe(self)
  if not decodedUrl or FFSZwx(decodedUrl):
   self.VVnppU("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCvDyD.VV3VMw(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVnppU("Reading Program List ...")
   ok_fnc = boundFunction(self.VVtKLv, refCode, chName, streamId, uHost, uUser, uPass)
   FFiJN6(boundFunction(CCvDyD.VVW2FE, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVnppU("Cannot process this channel")
 def VVtKLv(self, refCode, chName, streamId, uHost, uUser, uPass, VVV80v, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVV80v.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVnppU("Changing Program ...")
   FFiJN6(boundFunction(self.VV7Mld, chUrl))
  else:
   self.VVnppU("Incorrect Timestamp !")
 def VV7Mld(self, chUrl):
   FFIFfg(self, chUrl, VVb10q=False)
   self.lastPlayPos = 0
   self.VVafuH()
 def VV6Chz(self, isAudio):
  try:
   VVWP6Z = InfoBar.instance
   if VVWP6Z:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVWP6Z)
    else  : self.session.open(SubtitleSelection, VVWP6Z)
  except:
   pass
class CCBOvL(Screen):
 def __init__(self, session, title="", VVQQbK="Continue?", VVb7kN=True, VVCf1C=False):
  self.skin, self.skinParam = FFO5bN(VVwVAl, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVQQbK = VVQQbK
  self.VVCf1C = VVCf1C
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVb7kN : VVVLxj = [no , yes]
  else   : VVVLxj = [yes, no ]
  FF4gq5(self, title, VVVLxj=VVVLxj, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV13Bz ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVQQbK)
  if self.VVCf1C:
   self["myLabel"].instance.setHAlign(0)
  self.VVSAvy()
  FFRtL9(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFJ0hY(self["myMenu"])
  FFIs9D(self, self["myMenu"])
 def VV13Bz(self):
  item = FFCJux(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVSAvy(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCfSoV(Screen):
 def __init__(self, session, title="", VVVLxj=None, width=1000, OKBtnFnc=None, VV123e=None, VV8yYG=None, VVFM2s=None, VVtOG5=None, VVZFmG=False, VVoQKF=False):
  self.skin, self.skinParam = FFO5bN(VVdurn, width, 850, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVVLxj   = VVVLxj
  self.OKBtnFnc   = OKBtnFnc
  self.VV123e   = VV123e
  self.VV8yYG  = VV8yYG
  self.VVFM2s  = VVFM2s
  self.VVtOG5   = VVtOG5
  self.VVZFmG  = VVZFmG
  self.VVoQKF  = VVoQKF
  FF4gq5(self, title, VVVLxj=VVVLxj)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV13Bz          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVT5aq         ,
   "green"  : self.VVcDKA         ,
   "yellow" : self.VV1FXS         ,
   "blue"  : self.VVIxkm         ,
   "pageUp" : self.VVNKDW       ,
   "chanUp" : self.VVNKDW       ,
   "pageDown" : self.VV4Uaa        ,
   "chanDown" : self.VV4Uaa
  }, -1)
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  FFRtL9(self["myMenu"])
  FFqAhz(self)
  self.VVXXr5(self["keyRed"]  , self.VV123e )
  self.VVXXr5(self["keyGreen"] , self.VV8yYG )
  self.VVXXr5(self["keyYellow"] , self.VVFM2s )
  self.VVXXr5(self["keyBlue"]  , self.VVtOG5 )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFVXe6(self)
 def VVXXr5(self, btnObj, btnFnc):
  if btnFnc:
   FFoPjD(btnObj, btnFnc[0])
 def VV13Bz(self):
  item = FFCJux(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVZFmG: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVT5aq(self)  : self.VVkJ5C(self.VV123e)
 def VVcDKA(self) : self.VVkJ5C(self.VV8yYG)
 def VV1FXS(self) : self.VVkJ5C(self.VVFM2s)
 def VVIxkm(self) : self.VVkJ5C(self.VVtOG5)
 def VVkJ5C(self, btnFnc):
  if btnFnc:
   item = FFCJux(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVoQKF:
    self.cancel()
 def VVCD45(self, VVVLxj):
  if len(VVVLxj) > 0:
   newList = []
   for item in VVVLxj:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VV3Tp4(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVNKDW(self):
  self["myMenu"].moveToIndex(0)
 def VV4Uaa(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CC3Jxs(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VVprx2=None, VVOhM5=None, VVADeP=None, VVKTEW=26, VV13Vm=False, VV0k9j=None, VVEgOz=None, VV5eNi=None, VVgwCo=None, VV3VnJ=None, VVa6E6=None, VV9oqL=None, VVITUu=None, VVjFfT=None, VVzjB3=-1, VVgnNM=False, searchCol=0, VVkTTr=None, VVDVtL=None, VVSir0="#00dddddd", VV1z5Z="#11002233", VVfHXr="#00ff8833", VVps2K="#11111111", VVNERz="#0a555555", VVgDQG="#0affffff", VVJsTV="#11552200", VV1pSB="#0055ff55"):
  self.skin, self.skinParam = FFO5bN(VVkVBr, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FF4gq5(self, title)
  self.header     = header
  self.VVprx2     = VVprx2
  self.totalCols    = len(VVprx2[0])
  self.VVy7PI   = 0
  self.lastSortModeIsReverese = False
  self.VV13Vm   = VV13Vm
  self.VVz0gt   = 0.01
  self.VVWxUn   = 0.02
  self.VVET9T = 0.03
  self.VV9X1a  = 1
  self.VVADeP = VVADeP
  self.colWidthPixels   = []
  self.VV0k9j   = VV0k9j
  self.OKButtonObj   = None
  self.VVEgOz   = VVEgOz
  self.VV5eNi   = VV5eNi
  self.VVgwCo   = VVgwCo
  self.VV3VnJ  = VV3VnJ
  self.VVa6E6   = VVa6E6
  self.VV9oqL    = VV9oqL
  self.VVITUu   = VVITUu
  self.VVjFfT  = VVjFfT
  self.VVzjB3    = VVzjB3
  self.VVgnNM   = VVgnNM
  self.searchCol    = searchCol
  self.VVOhM5    = VVOhM5
  self.keyPressed    = -1
  self.VVKTEW    = FFVEnx(VVKTEW)
  self.VV3yZU    = FFpBBD(self.VVKTEW, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVkTTr    = VVkTTr
  self.VVDVtL      = VVDVtL
  self.VVSir0    = FFtJYq(VVSir0)
  self.VV1z5Z    = FFtJYq(VV1z5Z)
  self.VVfHXr    = FFtJYq(VVfHXr)
  self.VVps2K    = FFtJYq(VVps2K)
  self.VVNERz   = FFtJYq(VVNERz)
  self.VVgDQG    = FFtJYq(VVgDQG)
  self.VVJsTV    = FFtJYq(VVJsTV)
  self.VV1pSB   = FFtJYq(VV1pSB)
  self.VVKWxm  = False
  self.selectedItems   = 0
  self.VVqQ7Z   = FFtJYq("#01fefe01")
  self.VVVCGP   = FFtJYq("#11400040")
  self.VVsxDE  = self.VVqQ7Z
  self.VVQOR2  = self.VVps2K
  if self.VVgnNM:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVDjuK  ,
   "red"   : self.VVmL8c  ,
   "green"   : self.VVl5AZ ,
   "yellow"  : self.VVHLF6 ,
   "blue"   : self.VVsMZm  ,
   "menu"   : self.VVYIt5 ,
   "info"   : self.VVVSOy  ,
   "cancel"  : self.VVZMGY  ,
   "up"   : self.VVbMto    ,
   "down"   : self.VVhuBb  ,
   "left"   : self.VVwijv   ,
   "right"   : self.VVY9be  ,
   "pageUp"  : self.VVDueM  ,
   "chanUp"  : self.VVDueM  ,
   "pageDown"  : self.VVMEyz  ,
   "chanDown"  : self.VVMEyz
  }, -1)
  FFC67T(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  FFNG0p(self)
  try:
   self.VVfTXh()
  except Exception as err:
   FFsqiC(self, str(err))
   self.close(None)
 def VVfTXh(self):
  FFVXe6(self)
  if self.VVkTTr:
   FFXT3k(self["myTitle"], self.VVkTTr)
  if self.VVDVtL:
   FFXT3k(self["myBody"] , self.VVDVtL)
   FFXT3k(self["myTableH"] , self.VVDVtL)
   FFXT3k(self["myTable"] , self.VVDVtL)
   FFXT3k(self["myBar"]  , self.VVDVtL)
  self.VVXXr5(self.VV5eNi  , self["keyRed"])
  self.VVXXr5(self.VVgwCo  , self["keyGreen"])
  self.VVXXr5(self.VV3VnJ , self["keyYellow"])
  self.VVXXr5(self.VVa6E6  , self["keyBlue"])
  if self.VV0k9j:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VV0k9j[0])
    FFXT3k(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VV3yZU)
  self["myTableH"].l.setFont(0, gFont(VVScB1, self.VVKTEW))
  self["myTable"].l.setItemHeight(self.VV3yZU)
  self["myTable"].l.setFont(0, gFont(VVScB1, self.VVKTEW))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VV3yZU)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VV3yZU))
   self["myTable"].instance.resize(eSize(*(w, h - self.VV3yZU)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VV3yZU
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VV3yZU * len(self.VVprx2) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVADeP:
   self.VVADeP = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVADeP)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVOhM5:
   self.VVOhM5 = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVOhM5
   self.VVOhM5 = []
   for item in tmpList:
    self.VVOhM5.append(item | RT_VALIGN_CENTER)
  self.VVER5k()
  if self.VV9oqL:
   self.VV9oqL(self)
 def VVXXr5(self, btnFnc, btn):
  if btnFnc : FFoPjD(btn, btnFnc[0])
  else  : FFoPjD(btn, "")
 def VVJzEk(self, waitTxt):
  FF6Ue4(self, self.VVER5k, title=waitTxt)
 def VVER5k(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVsZeK(0, self.header, self.VVgDQG, self.VVJsTV, self.VVgDQG, self.VVJsTV, self.VV1pSB)])
   rows = []
   for c, row in enumerate(self.VVprx2):
    rows.append(self.VVsZeK(c, row, self.VVSir0, self.VV1z5Z, self.VVfHXr, self.VVps2K, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVzjB3 > -1:
    self["myTable"].moveToIndex(self.VVzjB3 )
   self.VV5gHi()
   if self.VVgnNM:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VV3yZU * len(self.VVprx2)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVITUu:
    self.VVkJ5C(self.VVITUu, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFsqiC(self, str(err))
    self.close()
   except:
    pass
 def VVsZeK(self, keyIndex, columns, VVSir0, VV1z5Z, VVfHXr, VVps2K, VV1pSB):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VV1pSB and ndx == self.VVy7PI : textColor = VV1pSB
   else           : textColor = VVSir0
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFtJYq(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VV1z5Z = c
    entry = span.group(3)
   if self.VVOhM5[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VV3yZU)
           , font   = 0
           , flags   = self.VVOhM5[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VV1z5Z
           , color_sel  = VVfHXr
           , backcolor_sel = VVps2K
           , border_width = 1
           , border_color = self.VVNERz
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVVSOy(self):
  rowData = self.VVB1h5()
  if rowData:
   title, txt, colList = rowData
   if self.VVEgOz:
    fnc  = self.VVEgOz[1]
    params = self.VVEgOz[2]
    fnc(self, title, txt, colList)
   else:
    FFItCL(self, txt, title)
 def VVDjuK(self):
  if   self.VVKWxm : self.VVhBAE(self.VVDRvM(), mode=2)
  elif self.VV0k9j  : self.VVkJ5C(self.VV0k9j, None)
  else      : self.VVVSOy()
 def VVmL8c(self) : self.VVkJ5C(self.VV5eNi , self["keyRed"])
 def VVl5AZ(self) : self.VVkJ5C(self.VVgwCo , self["keyGreen"])
 def VVHLF6(self): self.VVkJ5C(self.VV3VnJ , self["keyYellow"])
 def VVsMZm(self) : self.VVkJ5C(self.VVa6E6 , self["keyBlue"])
 def VVkJ5C(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFlf8A(self, buttonFnc[3])
    FFiJN6(boundFunction(self.VV016p, buttonFnc))
   else:
    self.VV016p(buttonFnc)
 def VV016p(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVB1h5()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVhBAE(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VVprx2[ndx]
   isSelected = row[1][9] == self.VVqQ7Z
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVsZeK(ndx, item, self.VVSir0, self.VV1z5Z, self.VVfHXr, self.VVps2K, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVsZeK(ndx, item, self.VVqQ7Z, self.VVVCGP, self.VVsxDE, self.VVQOR2, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VV5gHi()
 def VVf2R7(self):
  FF6Ue4(self, self.VV2pm8, title="Selecting all ...")
 def VV2pm8(self):
  self.VVkme0(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVqQ7Z
   if not isSelected:
    item = self.VVprx2[ndx]
    newRow = self.VVsZeK(ndx, item, self.VVqQ7Z, self.VVVCGP, self.VVsxDE, self.VVQOR2, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VV5gHi()
  self.VVuNx4()
 def VVNkWH(self):
  FF6Ue4(self, self.VVt3Yh, title="Unselecting all ...")
 def VVt3Yh(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVqQ7Z:
    item = self.VVprx2[ndx]
    newRow = self.VVsZeK(ndx, item, self.VVSir0, self.VV1z5Z, self.VVfHXr, self.VVps2K, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VV5gHi()
  self.VVuNx4()
 def VVuNx4(self):
  self.hide()
  self.show()
 def VVB1h5(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVADeP[i] > 1 or self.VVADeP[i] == self.VVz0gt or self.VVADeP[i] == self.VVET9T:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VVprx2))
   return rowNum, txt, colList
  else:
   return None
 def VVZMGY(self):
  if self.VVjFfT : self.VVjFfT(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVpfHE(self):
  return self["myTitle"].getText().strip()
 def VVS6aX(self):
  return self.header
 def VVdQQD(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVWc3V(self, txt):
  FFlf8A(self, txt)
 def VVFMww(self, txt):
  FFlf8A(self, txt, 1000)
 def VV8Hdn(self):
  FFlf8A(self)
 def VV9s1N(self):
  return len(self.VVprx2)
 def VVXQXY(self): self["keyGreen"].show()
 def VVVSaO(self): self["keyGreen"].hide()
 def VVDRvM(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVIKdD(self):
  return len(self["myTable"].list)
 def VVkme0(self, isOn):
  self.VVKWxm = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu"].hide()
   if self.VVa6E6: self["keyBlue"].hide()
   if self.VV0k9j and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVa6E6: self["keyBlue"].show()
   if self.VV0k9j and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VV0k9j[0])
   self.VVNkWH()
  FFXT3k(self["myTitle"], color)
  FFXT3k(self["myBar"]  , color)
 def VVzmAO(self):
  return self.VVKWxm
 def VVTiyK(self):
  return self.selectedItems
 def VVV5xQ(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VV5gHi()
 def VVa4bm(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VV5gHi()
 def VV0Rxr(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VVprx2:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVIiNJ(self):
  txt  = "Total Rows\t: %d\n\n" % self.VV9s1N()
  txt += FFic6i("Total Unique Items", VVKSBp)
  for i in range(self.totalCols):
   if self.VVADeP[i - 1] > 1 or self.VVADeP[i - 1] == self.VVz0gt or self.VVADeP[i - 1] == self.VVET9T:
    name, tot = self.VV0Rxr(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFItCL(self, txt)
 def VVRcVo(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVmoGA(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVnbpo(self, newList, newTitle="", VVAnAYMsg=True):
  if newList:
   self.VVprx2 = newList
   if self.VV13Vm and self.VVy7PI == 0:
    self.VVprx2 = sorted(self.VVprx2, key=lambda x: int(x[self.VVy7PI])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VVprx2 = sorted(self.VVprx2, key=lambda x: x[self.VVy7PI].lower(), reverse=self.lastSortModeIsReverese)
   if VVAnAYMsg : self.VVJzEk("Refreshing ...")
   else   : self.VVER5k()
   if newTitle:
    self.VVdQQD(newTitle)
  else:
   FFsqiC(self, "Cannot refresh list")
   self.cancel()
 def VV5whV(self, data):
  ndx = self.VVDRvM()
  newRow = self.VVsZeK(ndx, data, self.VVSir0, self.VV1z5Z, self.VVfHXr, self.VVps2K, None)
  if newRow:
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VV5gHi()
   return True
  else:
   return False
 def VVBR6e(self, colNum, textToFind, VVPeMj=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VV5gHi()
    break
  else:
   if VVPeMj:
    FFlf8A(self, "Not found", 1000)
 def VVH29i(self, colDict, VVPeMj=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VV5gHi()
    return
  if VVPeMj:
   FFlf8A(self, "Not found", 1000)
 def VVH29i_partial(self, colDict, VVPeMj=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VV5gHi()
    return
  if VVPeMj:
   FFlf8A(self, "Not found", 1000)
 def VVbJ8P(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VV2E7Y(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVqQ7Z:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVSUDw(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVYIt5(self):
  if not self["keyMenu"].getVisible() or self.VVgnNM:
   return
  VVVLxj = []
  VVVLxj.append(("Table Statistcis"             , "tableStat"  ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append((FFejnb("Export Table to .html"     , VVKSBp) , "VV3CBy" ))
  VVVLxj.append((FFejnb("Export Table to .csv"     , VVKSBp) , "VVIBOR" ))
  VVVLxj.append((FFejnb("Export Table to .txt (Tab Separated)", VVKSBp) , "VVELSE" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVADeP[i] > 1 or self.VVADeP[i] == self.VVWxUn:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVVLxj.append(VVQP0R)
   if tot == 1 : VVVLxj.append(("Sort", sList[0][1]))
   else  : VVVLxj += sList
  FFfsxJ(self, self.VVeche, VVVLxj=VVVLxj, title=self.VVpfHE())
 def VVeche(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVIiNJ()
   elif item == "VV3CBy": FF6Ue4(self, self.VV3CBy, title=title)
   elif item == "VVIBOR" : FF6Ue4(self, self.VVIBOR , title=title)
   elif item == "VVELSE" : FF6Ue4(self, self.VVELSE , title=title)
   else:
    isReversed = False
    if self.VVy7PI == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VV13Vm and item == 0:
     self.VVprx2 = sorted(self.VVprx2, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VVprx2 = sorted(self.VVprx2, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVy7PI = item
    self.VVJzEk("Sorting ...")
 def VVbMto(self):
  self["myTable"].up()
  self.VV5gHi()
 def VVhuBb(self):
  self["myTable"].down()
  self.VV5gHi()
 def VVwijv(self):
  self["myTable"].pageUp()
  self.VV5gHi()
 def VVY9be(self):
  self["myTable"].pageDown()
  self.VV5gHi()
 def VVDueM(self):
  self["myTable"].moveToIndex(0)
  self.VV5gHi()
 def VVMEyz(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VV5gHi()
 def VVlvF6(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VV5gHi()
 def VVELSE(self):
  expFile = self.VVo92j() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVk7IY()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VVprx2:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVADeP[ndx] > self.VV9X1a or self.VVADeP[ndx] == self.VVET9T:
      col = self.VVP9eY(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVVPYv(expFile)
 def VVIBOR(self):
  expFile = self.VVo92j() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVk7IY()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VVprx2:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVADeP[ndx] > self.VV9X1a or self.VVADeP[ndx] == self.VVET9T:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVP9eY(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVVPYv(expFile)
 def VV3CBy(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVpfHE(), PLUGIN_NAME, VVCmca)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVpfHE()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVk7IY()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVADeP:
   colgroup += '   <colgroup>'
   for w in self.VVADeP:
    if w > self.VV9X1a or w == self.VVET9T:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVo92j() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VVprx2:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVADeP[ndx] > self.VV9X1a or self.VVADeP[ndx] == self.VVET9T:
      col = self.VVP9eY(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVVPYv(expFile)
 def VVk7IY(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVADeP[ndx] > self.VV9X1a or self.VVADeP[ndx] == self.VVET9T:
     newRow.append(col.strip())
  return newRow
 def VVP9eY(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FF9jRB(col)
 def VVo92j(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVpfHE())
  fileName = fileName.replace("__", "_")
  path  = FFSw9u(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFYjSS()
  return expFile
 def VVVPYv(self, expFile):
  FFEf0P(self, "File exported to:\n\n%s" % expFile, title=self.VVpfHE())
 def VV5gHi(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCcI13(Screen):
 def __init__(self, session, title="", VVRA9l=None, showGrnMsg=""):
  self.skin, self.skinParam = FFO5bN(VVpaEC, 1400, 800, 30, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FF4gq5(self, title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VVRA9l = VVRA9l
  self.showGrnMsg  = showGrnMsg
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  allOK = FFpFKd(self["myLabel"], self.VVRA9l)
  if allOK:
   if self.showGrnMsg:
    FFlf8A(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFsqiC(self, "Cannot view picture file:\n\n%s" % self.VVRA9l)
   self.close()
class CCRbRI(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFO5bN(VVbkAQ, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 26, barHeight=40, topRightBtns=1)
  self.session  = session
  FF4gq5(self)
  FFoPjD(self["keyGreen"], "Save")
  self.VVprx2 = []
  self.VVprx2.append(getConfigListEntry("Show in Main Menu"          , CFG.showInMainMenu   ))
  self.VVprx2.append(getConfigListEntry("Show in Extensions Menu"         , CFG.showInExtensionMenu  ))
  self.VVprx2.append(getConfigListEntry("Show in Channel List Context Menu"      , CFG.showInChannelListMenu  ))
  self.VVprx2.append(getConfigListEntry("Show in Events Info Menu"        , CFG.EventsInfoMenu   ))
  self.VVprx2.append(getConfigListEntry("Input Type"            , CFG.keyboard     ))
  self.VVprx2.append(getConfigListEntry("Signal & Player Cotroller Hotkey"      , CFG.hotkey_signal    ))
  if VVJHhL:
   self.VVprx2.append(getConfigListEntry("EPG Translation Language"       , CFG.epgLanguage    ))
  self.VVprx2.append(getConfigListEntry(VVVVdp *2             ,         ))
  self.VVprx2.append(getConfigListEntry("Default IPTV Reference Type"        , CFG.iptvAddToBouquetRefType ))
  self.VVprx2.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"  , CFG.autoResetFrozenIptvChan ))
  self.VVprx2.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"     , CFG.hideIptvServerAdultWords ))
  self.VVprx2.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"  , CFG.hideIptvServerChannPrefix ))
  self.VVprx2.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"   , CFG.iptvHostsPath    ))
  self.VVprx2.append(getConfigListEntry("Movie/Series Download Path"        , CFG.MovieDownloadPath   ))
  self.VVprx2.append(getConfigListEntry(VVVVdp *2             ,         ))
  self.VVprx2.append(getConfigListEntry("PIcons Path"            , CFG.PIconsPath    ))
  self.VVprx2.append(getConfigListEntry(VVVVdp *2             ,         ))
  self.VVprx2.append(getConfigListEntry("Backup/Restore Path"          , CFG.backupPath    ))
  self.VVprx2.append(getConfigListEntry("Created Package Files (IPK/DEB)"       , CFG.packageOutputPath   ))
  self.VVprx2.append(getConfigListEntry("Downloaded Packages (from feeds)"      , CFG.downloadedPackagesPath ))
  self.VVprx2.append(getConfigListEntry("Exported Tables"           , CFG.exportedTablesPath  ))
  self.VVprx2.append(getConfigListEntry("Exported PIcons"           , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, self.VVprx2, session)
  self["setupActions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard", "OkCancelActions"],
  {
   "ok"  : self.VV13Bz   ,
   "OK"  : self.VV13Bz   ,
   "green"  : self.VVdAdJ  ,
   "menu"  : self.VVPagr ,
   "cancel" : self.VV4FCY
  }, -1)
  self.titleText = "  Settings"
  self["myTitle"].setText(self.titleText)
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  FFNG0p(self)
  FFRtL9(self["config"])
  FFqAhz(self,  self["config"])
  FFVXe6(self)
 def VV13Bz(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsPath   : self.VVEuDy()
   elif item == CFG.MovieDownloadPath   : self.VVum2z(item, self["config"].getCurrent()[0])
   elif item == CFG.PIconsPath    : self.VVwDba(item)
   elif item == CFG.backupPath    : self.VVwDba(item)
   elif item == CFG.packageOutputPath  : self.VVwDba(item)
   elif item == CFG.downloadedPackagesPath : self.VVwDba(item)
   elif item == CFG.exportedTablesPath  : self.VVwDba(item)
   elif item == CFG.exportedPIconsPath  : self.VVwDba(item)
 def VVum2z(self, item, title):
  tot = CC5fZh.VV862u()
  if tot : FFsqiC(self, "Cannot change while downloading.", title=title)
  else : self.VVwDba(item)
 def VVEuDy(self):
  VVVLxj = []
  VVVLxj.append(("Auto Find" , "auto"))
  VVVLxj.append(("Custom Path" , "path"))
  FFfsxJ(self, self.VVQoq1, VVVLxj=VVVLxj, title="IPTV Hosts Files Path")
 def VVQoq1(self, item=None):
  if item:
   if   item == "auto": CFG.iptvHostsPath.setValue(VVDYiT)
   elif item == "path": self.VVwDba(CFG.iptvHostsPath)
 def VVwDba(self, configObj):
  sDir = configObj.getValue()
  if sDir == VVDYiT:
   sDir = "/"
  self.session.openWithCallback(boundFunction(self.VVMuov, configObj)
         , boundFunction(CCt0KP, mode=CCt0KP.VVAn9X, VVFaGg=sDir))
 def VVMuov(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VV4FCY(self):
  if CFG.showInMainMenu.isChanged()    or \
   CFG.showInExtensionMenu.isChanged()   or \
   CFG.showInChannelListMenu.isChanged()  or \
   CFG.EventsInfoMenu.isChanged()    or \
   CFG.keyboard.isChanged()     or \
   CFG.hotkey_signal.isChanged()    or \
   CFG.epgLanguage.isChanged()     or \
   CFG.iptvAddToBouquetRefType.isChanged()  or \
   CFG.autoResetFrozenIptvChan.isChanged()  or \
   CFG.hideIptvServerAdultWords.isChanged() or \
   CFG.hideIptvServerChannPrefix.isChanged() or \
   CFG.iptvHostsPath.isChanged()    or \
   CFG.MovieDownloadPath.isChanged()   or \
   CFG.PIconsPath.isChanged()     or \
   CFG.backupPath.isChanged()     or \
   CFG.packageOutputPath.isChanged()   or \
   CFG.downloadedPackagesPath.isChanged()  or \
   CFG.exportedTablesPath.isChanged()   or \
   CFG.exportedPIconsPath.isChanged():
    FFmhMd(self, self.VVdAdJ, "Save Changes ?", callBack_No=self.cancel)
  else:
   self.cancel()
 def VVdAdJ(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVXtln()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVPagr(self):
  VVVLxj = []
  VVVLxj.append(("Use Backup directory in all other paths"      , "VVAKoT"   ))
  VVVLxj.append(("Reset all to default (including File Manager bookmarks)"  , "VVxSf1"   ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Backup %s Settings" % PLUGIN_NAME        , "VVuwEk"  ))
  VVVLxj.append(("Restore %s Settings" % PLUGIN_NAME       , "VV0Pdh"  ))
  if fileExists(VV28Xc + VVqypm):
   VVVLxj.append(VVQP0R)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVVLxj.append(('%s Checking for Update' % txt1       , txt2     ))
   VVVLxj.append(("Reinstall %s" % PLUGIN_NAME        , "VVZd19"  ))
   VVVLxj.append(("Update %s" % PLUGIN_NAME        , "VVH9wb"   ))
  FFfsxJ(self, self.VViNYG, VVVLxj=VVVLxj, title="Config. Options")
 def VViNYG(self, item=None):
  if item:
   if   item == "VVAKoT"  : FFmhMd(self, self.VVAKoT , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVxSf1"  : FFmhMd(self, self.VVxSf1, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCBmjq)
   elif item == "VVuwEk" : self.VVuwEk()
   elif item == "VV0Pdh" : FF6Ue4(self, self.VV0Pdh, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVluoh(True)
   elif item == "disableChkUpdate" : self.VVluoh(False)
   elif item == "VVZd19" : FF6Ue4(self, self.VVZd19 , "Checking Server ...")
   elif item == "VVH9wb"  : FF6Ue4(self, self.VVH9wb  , "Checking Server ...")
 def VVuwEk(self):
  path = "%sajpanel_settings_%s" % (VV28Xc, FFYjSS())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFEf0P(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VV0Pdh(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFstFz("find / %s -iname '%s*' | grep %s" % (FFpWOv(1), name, name))
  if lines:
   lines.sort()
   VVVLxj = []
   for line in lines:
    VVVLxj.append((line, line))
   FFfsxJ(self, boundFunction(self.VVrFk1, title), title=title, VVVLxj=VVVLxj, width=1200)
  else:
   FFsqiC(self, "No settings files found !", title=title)
 def VVrFk1(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FF3tpP(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVXtln()
    FFqwad()
   else:
    FFPX6L(SELF, path, title=title)
 def VVluoh(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVAKoT(self):
  newPath = FFSw9u(VV28Xc)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVXtln()
 @staticmethod
 def VVg4NP():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVxSf1(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.EventsInfoMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.epgLanguage.setValue("off")
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.autoResetFrozenIptvChan.setValue(False)
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.iptvHostsPath.setValue(VVDYiT)
  CFG.MovieDownloadPath.setValue(CC5fZh.VVaDhR())
  CFG.PIconsPath.setValue(VVqnEO)
  CFG.backupPath.setValue(CCRbRI.VVg4NP())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  CFG.showInMainMenu.save()
  CFG.showInExtensionMenu.save()
  CFG.showInChannelListMenu.save()
  CFG.EventsInfoMenu.save()
  CFG.keyboard.save()
  CFG.hotkey_signal.save()
  CFG.epgLanguage.save()
  CFG.iptvAddToBouquetRefType.save()
  CFG.autoResetFrozenIptvChan.save()
  CFG.hideIptvServerAdultWords.save()
  CFG.hideIptvServerChannPrefix.save()
  CFG.iptvHostsPath.save()
  CFG.MovieDownloadPath.save()
  CFG.PIconsPath.save()
  CFG.backupPath.save()
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  CFG.browserStartPath.save()
  CFG.browserBookmarks.save()
  self.VVXtln()
  self.close()
 def VVXtln(self):
  configfile.save()
  global VV28Xc
  VV28Xc = CFG.backupPath.getValue()
  FFF71p()
 def VVH9wb(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVNTIu(title)
  if webVer:
   FFmhMd(self, boundFunction(FF6Ue4, self, boundFunction(self.VVxigh, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVZd19(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVNTIu(title, True)
  if webVer:
   FFmhMd(self, boundFunction(FF6Ue4, self, boundFunction(self.VVxigh, webVer, title)), "Install and Restart ?", title=title)
 def VVxigh(self, webVer, title):
  url = self.VVpSLp(self, title)
  if url:
   VVq4bA = FFHjh8() == "dpkg"
   if VVq4bA == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVq4bA else "ipk")
   path, err = FFiBrv(url + fName, fName, timeout=2)
   if path:
    cmd = FFvshm(VVcW3p, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFyzyQ(self, cmd)
    else:
     FFEmMJ(self, title=title)
   else:
    FFsqiC(self, err, title=title)
 def VVNTIu(self, title, anyVer=False):
  url = self.VVpSLp(self, title)
  if not url:
   return ""
  path, err = FFiBrv(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFsqiC(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFb1Rx(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFsqiC(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVCmca.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFstFz(cmd)
   if list and curVer == list[0]:
    return webVer
  FFEf0P(self, FFejnb("No update required.", VVOn4X) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVpSLp(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VV28Xc + VVqypm
  if fileExists(path):
   span = iSearch(r"(http.+)", FFb1Rx(path), IGNORECASE)
   if span : url = FFSw9u(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFsqiC(SELF, err, title)
  return url
 @staticmethod
 def VVFIhI(url):
  path, err = FFiBrv(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFb1Rx(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVCmca.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFstFz(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCBmjq(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFO5bN(VVH8Wc, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVmQyS
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FF4gq5(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVLqfl("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVLqfl("\c00888888", i) + sp + "GREY\n"
   txt += self.VVLqfl("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVLqfl("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVLqfl("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVLqfl("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVLqfl("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVLqfl("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVLqfl("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVLqfl("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVLqfl("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVLqfl("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV13Bz ,
   "green"   : self.VV13Bz ,
   "left"   : self.VVA8pr ,
   "right"   : self.VVUCwC ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  self.VVzfwz()
 def VV13Bz(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFmhMd(self, self.VV61N0, "Change to : %s" % txt, title=self.Title)
 def VV61N0(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVmQyS
  VVmQyS = self.cursorPos
  self.VVIwsj()
  self.close()
 def VVA8pr(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVzfwz()
 def VVUCwC(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVzfwz()
 def VVzfwz(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVLqfl(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVLBCX(color):
  if VVHuTi: return "\\" + color
  else    : return ""
 @staticmethod
 def VVIwsj():
  global VV0ESq, VV6AHZ, VVhgxA, VVKSBp, VVVBxF, VVqcuH, VVOn4X, VVHuTi, COLOR_CONS_BRIGHT_YELLOW, VVj8eg, VVUDe3, VVWdSD, VVMNP0
  VVMNP0   = CCBmjq.VVLqfl("\c00FFFFFF", VVmQyS)
  VV6AHZ    = CCBmjq.VVLqfl("\c00888888", VVmQyS)
  VV0ESq  = CCBmjq.VVLqfl("\c005A5A5A", VVmQyS)
  VVqcuH    = CCBmjq.VVLqfl("\c00FF0000", VVmQyS)
  VVhgxA   = CCBmjq.VVLqfl("\c00FF5000", VVmQyS)
  VVHuTi   = CCBmjq.VVLqfl("\c00FFFF00", VVmQyS)
  COLOR_CONS_BRIGHT_YELLOW = CCBmjq.VVLqfl("\c00FFFFAA", VVmQyS)
  VVOn4X   = CCBmjq.VVLqfl("\c0000FF00", VVmQyS)
  VVVBxF    = CCBmjq.VVLqfl("\c000066FF", VVmQyS)
  VVj8eg    = CCBmjq.VVLqfl("\c0000FFFF", VVmQyS)
  VVUDe3  = CCBmjq.VVLqfl("\c00DSFFFF", VVmQyS)  #
  VVWdSD   = CCBmjq.VVLqfl("\c00FA55E7", VVmQyS)
  VVKSBp    = CCBmjq.VVLqfl("\c00FF8F5F", VVmQyS)
CCBmjq.VVIwsj()
class CCDu6G(Screen):
 def __init__(self, session, path, VVq4bA):
  self.skin, self.skinParam = FFO5bN(VVRHuj, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVavil   = path
  self.VVhrVz   = ""
  self.VVvMsB   = ""
  self.VVq4bA    = VVq4bA
  self.VV8tB7    = ""
  self.VVnAXe  = ""
  self.VVeRHx    = False
  self.VVS6vT  = False
  self.postInstAcion   = 0
  self.VVCXtf  = "enigma2-plugin-extensions"
  self.VVLG6Z  = "enigma2-plugin-systemplugins"
  self.VVkbeq = "enigma2"
  self.VVGG10  = 0
  self.VV4F3O  = 1
  self.VVNhRi  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVQi1J = "DEBIAN"
  else        : self.VVQi1J = "CONTROL"
  self.controlPath = self.Path + self.VVQi1J
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVq4bA:
   self.packageExt  = ".deb"
   self.VV1z5Z  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VV1z5Z  = "#11001020"
  FF4gq5(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFoPjD(self["keyRed"] , "Create")
  FFoPjD(self["keyGreen"] , "Post Install")
  FFoPjD(self["keyYellow"], "Installation Path")
  FFoPjD(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVsLOQ  ,
   "green"   : self.VVNv1I ,
   "yellow"  : self.VVpTCk  ,
   "blue"   : self.VVxmnK  ,
   "cancel"  : self.VVDgml
  }, -1)
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  FFVXe6(self)
  if self.VV1z5Z:
   FFXT3k(self["myBody"], self.VV1z5Z)
   FFXT3k(self["myLabel"], self.VV1z5Z)
  self.VV0sWq(True)
  self.VVr8jL(True)
 def VVr8jL(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVoLe2()
  if isFirstTime:
   if   package.startswith(self.VVCXtf) : self.VVavil = VVniGc + self.VV8tB7 + "/"
   elif package.startswith(self.VVLG6Z) : self.VVavil = VVVbI9 + self.VV8tB7 + "/"
   else            : self.VVavil = self.Path
  if self.VVeRHx : myColor = VVKSBp
  else    : myColor = VVMNP0
  txt  = ""
  txt += "Source Path\t: %s\n" % FFejnb(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFejnb(self.VVavil, VVHuTi)
  if self.VVvMsB : txt += "Package File\t: %s\n" % FFejnb(self.VVvMsB, VV6AHZ)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFejnb("Check Control File fields : %s" % errTxt, VVhgxA)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFejnb("Restart GUI", VVKSBp)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFejnb("Reboot Device", VVKSBp)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FFejnb("Post Install", VVOn4X), act)
  if not errTxt and VVhgxA in controlInfo:
   txt += "Warning\t: %s\n" % FFejnb("Errors in control file may affect the result package.", VVhgxA)
  txt += "\nControl File\t: %s\n" % FFejnb(self.controlFile, VV6AHZ)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVNv1I(self):
  VVVLxj = []
  VVVLxj.append(("No Action"    , "noAction"  ))
  VVVLxj.append(("Restart GUI"    , "VVCC07"  ))
  VVVLxj.append(("Reboot Device"   , "rebootDev"  ))
  FFfsxJ(self, self.VVvnT4, title="Package Installation Option (after completing installation)", VVVLxj=VVVLxj)
 def VVvnT4(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVCC07"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VV0sWq(False)
   self.VVr8jL()
 def VVpTCk(self):
  rootPath = FFejnb("/%s/" % self.VV8tB7, VV0ESq)
  VVVLxj = []
  VVVLxj.append(("Current Path"        , "toCurrent"  ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Extension Path"       , "toExtensions" ))
  VVVLxj.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVVLxj.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFfsxJ(self, self.VVLHxx, title="Installation Path", VVVLxj=VVVLxj)
 def VVLHxx(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVzuxb(FFdafY(self.Path, True))
   elif item == "toExtensions"  : self.VVzuxb(VVniGc)
   elif item == "toSystemPlugins" : self.VVzuxb(VVVbI9)
   elif item == "toRootPath"  : self.VVzuxb("/")
   elif item == "toRoot"   : self.VVzuxb("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VV7zxs, boundFunction(CCt0KP, mode=CCt0KP.VVAn9X, VVFaGg=VV28Xc))
 def VV7zxs(self, path):
  if len(path) > 0:
   self.VVzuxb(path)
 def VVzuxb(self, parent, withPackageName=True):
  if withPackageName : self.VVavil = parent + self.VV8tB7 + "/"
  else    : self.VVavil = "/"
  mode = self.VVYY5Q()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVMtWW(mode), self.controlFile))
  self.VVr8jL()
 def VVxmnK(self):
  if fileExists(self.controlFile):
   lines = FF3tpP(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFD8qa(self, self.VVxcH4, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFsqiC(self, "Version not found or incorrectly set !")
  else:
   FFPX6L(self, self.controlFile)
 def VVxcH4(self, VVd6Iw):
  if VVd6Iw:
   version, color = self.VV0iuZ(VVd6Iw, False)
   if color == VVj8eg:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVd6Iw, self.controlFile))
    self.VVr8jL()
   else:
    FFsqiC(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVDgml(self):
  if self.newControlPath:
   if self.VVeRHx:
    self.VV8Hy3()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFejnb(self.newControlPath, VV6AHZ)
    txt += FFejnb("Do you want to keep these files ?", VVHuTi)
    FFmhMd(self, self.close, txt, callBack_No=self.VV8Hy3, title="Create Package", VVCf1C=True)
  else:
   self.close()
 def VV8Hy3(self):
  os.system(FFnz2p("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVMtWW(self, mode):
  if   mode == self.VV4F3O : prefix = self.VVCXtf
  elif mode == self.VVNhRi : prefix = self.VVLG6Z
  else        : prefix = self.VVkbeq
  return prefix + "-" + self.VVnAXe
 def VVYY5Q(self):
  if   self.VVavil.startswith(VVniGc) : return self.VV4F3O
  elif self.VVavil.startswith(VVVbI9) : return self.VVNhRi
  else            : return self.VVGG10
 def VV0sWq(self, isFirstTime):
  self.VV8tB7   = os.path.basename(os.path.normpath(self.Path))
  self.VV8tB7   = "_".join(self.VV8tB7.split())
  self.VVnAXe = self.VV8tB7.lower()
  self.VVeRHx = self.VVnAXe == VVKKIV.lower()
  if self.VVeRHx and self.VVnAXe.endswith("ajpan"):
   self.VVnAXe += "el"
  if self.VVeRHx : self.VVhrVz = VV28Xc
  else    : self.VVhrVz = CFG.packageOutputPath.getValue()
  self.VVhrVz = FFSw9u(self.VVhrVz)
  if not pathExists(self.controlPath):
   os.system(FFnz2p("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVeRHx : t = PLUGIN_NAME
  else    : t = self.VV8tB7
  self.VVRbUm(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVDrFQ.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVeRHx : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVRbUm(self.postrmFile, txt)
  if self.VVeRHx:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVCmca)
   self.VVRbUm(self.preinstFile, txt)
  else:
   self.VVRbUm(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VV8tB7)
  mode = self.VVYY5Q()
  if isFirstTime and not mode == self.VVGG10:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVVVdp
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVRbUm(self.postinstFile, txt, VVa8yN=True)
  os.system(FFnz2p("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVeRHx : version, descripton, maintainer = VVCmca , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VV8tB7 , self.VV8tB7
   txt = ""
   txt += "Package: %s\n"  % self.VVMtWW(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVRbUm(self, path, lines, VVa8yN=False):
  if not fileExists(path) or VVa8yN:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVoLe2(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FF3tpP(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFejnb(line, VVhgxA)
     elif not line.startswith(" ")    : line = FFejnb(line, VVhgxA)
     else          : line = FFejnb(line, VVj8eg)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVj8eg
   else   : color = VVhgxA
   descr = FFejnb(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVhgxA
     elif line.startswith((" ", "\t")) : color = VVhgxA
     elif line.startswith("#")   : color = VV6AHZ
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VV0iuZ(val, True)
      elif key == "Version"  : version, color = self.VV0iuZ(val, False)
      elif key == "Maintainer" : maint  , color = val, VVj8eg
      elif key == "Architecture" : arch  , color = val, VVj8eg
      else:
       color = VVj8eg
      if not key == "OE" and not key.istitle():
       color = VVhgxA
     else:
      color = VVKSBp
     txt += FFejnb(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVvMsB = self.VVhrVz + packageName
   self.VVS6vT = True
   errTxt = ""
  else:
   self.VVvMsB  = ""
   self.VVS6vT = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VV0iuZ(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVj8eg
  else          : return val, VVhgxA
 def VVsLOQ(self):
  if not self.VVS6vT:
   FFsqiC(self, "Please fix Control File errors first.")
   return
  if self.VVq4bA: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFdafY(self.VVavil, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VV8tB7
  symlinkTo  = FFPM3Z(self.Path)
  dataDir   = self.VVavil.rstrip("/")
  removePorjDir = FFnz2p("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFnz2p("rm -f '%s'" % self.VVvMsB) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFdtOa()
  if self.VVq4bA:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFrytY("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVeRHx:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVavil == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVQi1J)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVvMsB, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVvMsB
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVvMsB, FFFHM5(result  , VVOn4X))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVavil, FFFHM5(instPath, VVj8eg))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFFHM5(failed, VVhgxA))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFyzyQ(self, cmd)
class CCt0KP(Screen):
 VV7Yau   = 0
 VVAn9X  = 1
 VVPsXC = 20
 VVdwLP  = None
 def __init__(self, session, VVFaGg="/", mode=VV7Yau, VV2sjb="Select", VVKTEW=30, gotoMovie=False):
  self.skin, self.skinParam = FFO5bN(VVdurn, 1400, 920, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FF4gq5(self)
  FFoPjD(self["keyRed"] , "Exit")
  FFoPjD(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VV2sjb = VV2sjb
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  CCt0KP.VVdwLP = self
  if   self.gotoMovie        : VVPIq1, self.VVFaGg = True , CCt0KP.VVU7Qg(self)[1] or "/"
  elif self.mode == self.VV7Yau  : VVPIq1, self.VVFaGg = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVAn9X : VVPIq1, self.VVFaGg = False, VVFaGg
  else           : VVPIq1, self.VVFaGg = True , VVFaGg
  self.VVFaGg = FFSw9u(self.VVFaGg)
  self["myMenu"] = CC0JlM(  directory   = "/"
         , VVPIq1   = VVPIq1
         , VVUOuL = True
         , VVxaa4   = self.skinParam["width"]
         , VVKTEW   = self.skinParam["bodyFontSize"]
         , VV3yZU  = self.skinParam["bodyLineH"]
         , VVfLOs  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VV13Bz      ,
   "red"    : self.VVNTlt     ,
   "green"    : self.VVPRQY    ,
   "yellow"   : self.VVEpcO   ,
   "blue"    : self.VVMwTg   ,
   "menu"    : self.VV4g5z    ,
   "info"    : self.VVM4CU    ,
   "cancel"   : self.VV2a0b     ,
   "pageUp"   : self.VV2a0b     ,
   "chanUp"   : self.VV2a0b
  }, -1)
  FFC67T(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVwa6F)
 def onExit(self):
  CCt0KP.VVdwLP = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVwa6F)
  FFNG0p(self)
  FFRtL9(self["myMenu"], bg="#06003333")
  FFVXe6(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode == self.VVAn9X:
   FFoPjD(self["keyGreen"], self.VV2sjb)
   color = "#22000022"
   FFXT3k(self["myBody"], color)
   FFXT3k(self["myMenu"], color)
   color = "#22220000"
   FFXT3k(self["myTitle"], color)
   FFXT3k(self["myBar"], color)
  self.VVwa6F()
  if self.VVKERc(self.VVFaGg) > self.bigDirSize:
   FFlf8A(self, "Changing directory...")
   FFiJN6(self.VV2CcX)
  else:
   self.VV2CcX()
 def VV2CcX(self):
  self["myMenu"].VV0tvt(self.VVFaGg)
  if self.gotoMovie:
   self.VVYhl8(chDir=False)
 def VVlvF6(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVN4PU(self):
  self["myMenu"].refresh()
  FFAMk4()
 def VVKERc(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VV13Bz(self):
  if self["myMenu"].VVdH4o():
   path = self.VV0RIm(self.VVVpUg())
   if self.VVKERc(path) > self.bigDirSize:
    FFlf8A(self, "Changing directory...")
    FFiJN6(self.VVVOPK)
   else:
    self.VVVOPK()
  else:
   self.VVYJwx()
 def VVVOPK(self):
  self["myMenu"].descent()
  self.VVwa6F()
 def VV2a0b(self):
  if self["myMenu"].VVohmf():
   self["myMenu"].moveToIndex(0)
   self.VVVOPK()
 def VVNTlt(self):
  if not FFNrW1(self):
   self.close("")
 def VVPRQY(self):
  if self.mode == self.VVAn9X:
   path = self.VV0RIm(self.VVVpUg())
   self.close(path)
 def VVM4CU(self):
  FF6Ue4(self, self.VVVIq5, title="Calculating size ...")
 def VVVIq5(self):
  path = self.VV0RIm(self.VVVpUg())
  param = self.VVC6uY(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFdBZy("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCt0KP.VVwSZ5(path)
     freeSize = CCt0KP.VVgx5r(path)
     size = totSize - freeSize
     totSize  = CCt0KP.VVnUtG(totSize)
     freeSize = CCt0KP.VVnUtG(freeSize)
    else:
     size = FFdBZy("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CCt0KP.VVnUtG(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFejnb(pathTxt, VVKSBp) + "\n"
   if slBroken : fileTime = self.VVEPfc(path)
   else  : fileTime = self.VVyIHw(path)
   def VVN08k(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVN08k("Path"    , pathTxt)
   txt += VVN08k("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVN08k("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVN08k("Total Size"   , "%s" % totSize)
    txt += VVN08k("Used Size"   , "%s" % usedSize)
    txt += VVN08k("Free Size"   , "%s" % freeSize)
   else:
    txt += VVN08k("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVN08k("Owner"    , owner)
   txt += VVN08k("Group"    , group)
   txt += VVN08k("Perm. (User)"  , permUser)
   txt += VVN08k("Perm. (Group)"  , permGroup)
   txt += VVN08k("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVN08k("Perm. (Ext.)" , permExtra)
   txt += VVN08k("iNode"    , iNode)
   txt += VVN08k("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVVVdp, VVVVdp)
    txt += hLinkedFiles
   txt += self.VV86Q1(path)
  else:
   FFsqiC(self, "Cannot access information !")
  if len(txt) > 0:
   FFItCL(self, txt)
 def VVC6uY(self, path):
  path = path.strip()
  path = FFPM3Z(path)
  result = FFdBZy("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVAYBe(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVAYBe(perm, 1, 4)
   permGroup = VVAYBe(perm, 4, 7)
   permOther = VVAYBe(perm, 7, 10)
   permExtra = VVAYBe(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFuq8j("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VV86Q1(self, path):
  txt  = ""
  res  = FFdBZy("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFejnb("File Attributes:", VVWdSD), txt)
  return txt
 def VVyIHw(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFh92T(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFh92T(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFh92T(os.path.getctime(path))
  return txt
 def VVEPfc(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFdBZy("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFdBZy("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFdBZy("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VV0RIm(self, currentSel):
  currentDir  = self["myMenu"].VVohmf()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVdH4o():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVVpUg(self):
  return self["myMenu"].getSelection()[0]
 def VVwa6F(self):
  FFlf8A(self)
  path = self.VV0RIm(self.VVVpUg())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VVprx2 = self.VV8BLO()
  if VVprx2 and len(VVprx2) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VV9WAk(path)
  if self.mode == self.VV7Yau and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
 def VV9WAk(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVUD2t(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VV4g5z(self):
  if self.mode == self.VV7Yau:
   path  = self.VV0RIm(self.VVVpUg())
   isDir  = os.path.isdir(path)
   VVVLxj = []
   VVVLxj.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVJTex(path):
     sepShown = True
     VVVLxj.append(VVQP0R)
     VVVLxj.append( (VVKSBp + "Archiving / Packaging"      , "VVotXW"  ))
    if self.VV1nq6(path):
     if not sepShown:
      VVVLxj.append(VVQP0R)
     VVVLxj.append( (VVKSBp + "Read Backup information"     , "VV9w3P"  ))
     VVVLxj.append( (VVKSBp + "Compress Octagon Image (to zip File)"  , "VVg7mY" ))
   elif os.path.isfile(path):
    selFile = self.VVVpUg()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar")) : VVVLxj.extend(self.VVl79T(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVVLxj.extend(self.VV4qH9(True))
    elif selFile.endswith(".m3u")              : VVVLxj.extend(self.VVKJ9S(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FFbOjF(path):
     VVVLxj.append(VVQP0R)
     VVVLxj.append((VVKSBp + "View" , "text_View" ))
     VVVLxj.append((VVKSBp + "Edit" , "text_Edit" ))
    if len(txt) > 0:
     VVVLxj.append(VVQP0R)
     VVVLxj.append(   (VVKSBp + txt      , "VVYJwx"  ))
   VVVLxj.append(VVQP0R)
   VVVLxj.append(     ("Create SymLink"       , "VVESZK" ))
   if not self.VVJTex(path):
    VVVLxj.append(   ("Rename"          , "VVlEsI" ))
    VVVLxj.append(   ("Copy"           , "copyFileOrDir" ))
    VVVLxj.append(   ("Move"           , "moveFileOrDir" ))
    VVVLxj.append(   ("DELETE"          , "VVOta2" ))
    if fileExists(path):
     VVVLxj.append(VVQP0R)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVVLxj.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVVLxj.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVVLxj.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVVLxj.append(VVQP0R)
   VVVLxj.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVVLxj.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCt0KP.VVU7Qg(self)
   if fPath:
    VVVLxj.append(VVQP0R)
    VVVLxj.append(   (VVHuTi + "Go to current movie"  , "VVYhl8"))
   VVVLxj.append(VVQP0R)
   VVVLxj.append(    ("Set current directory as \"Startup Path\"" , "VVF1YB" ))
   FFfsxJ(self, self.VVZGkL, title="Options", VVVLxj=VVVLxj)
 def VVZGkL(self, item=None):
  if self.mode == self.VV7Yau:
   if item is not None:
    path = self.VV0RIm(self.VVVpUg())
    selFile = self.VVVpUg()
    if   item == "properties"    : self.VVM4CU()
    elif item == "VVotXW"  : self.VVotXW(path)
    elif item == "VV9w3P"  : self.VV9w3P(path)
    elif item == "VVg7mY" : self.VVg7mY(path)
    elif item.startswith("extract_")  : self.VVjOpc(path, selFile, item)
    elif item.startswith("script_")   : self.VVtCZC(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVTTmgItem_m3u(path, selFile, item)
    elif item.startswith("text_View")  : FFM8So(self, path)
    elif item.startswith("text_Edit")  : CCj5OR(self, path)
    elif item == "chmod644"     : self.VVgerV(path, selFile, "644")
    elif item == "chmod755"     : self.VVgerV(path, selFile, "755")
    elif item == "chmod777"     : self.VVgerV(path, selFile, "777")
    elif item == "VVESZK"   : self.VVESZK(path, selFile)
    elif item == "VVlEsI"   : self.VVlEsI(path, selFile)
    elif item == "copyFileOrDir"   : self.VVV4Mv(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVV4Mv(path, selFile, True)
    elif item == "VVOta2"   : self.VVOta2(path, selFile)
    elif item == "createNewFile"   : self.VVHZtD(path, True)
    elif item == "createNewDir"    : self.VVHZtD(path, False)
    elif item == "VVYhl8"   : self.VVYhl8()
    elif item == "VVF1YB"   : self.VVF1YB(path)
    elif item == "VVYJwx"    : self.VVYJwx()
    else         : self.close()
 def VVYJwx(self):
  selFile = self.VVVpUg()
  path  = self.VV0RIm(selFile)
  if os.path.isfile(path):
   VVsr3H = []
   category = self["myMenu"].VVdUcO(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVrxfJ(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FFC4fv(self, selFile, path)
   elif category == "txt"         : FFM8So(self, path)
   elif category in ("tar", "zip", "rar")     : self.VV66y5(path, selFile)
   elif category == "scr"         : self.VVYARv(path, selFile)
   elif category == "m3u"         : self.VV34aX(path, selFile)
   elif category in ("ipk", "deb")       : self.VVLCn8(path, selFile)
   elif category == "mus"         : self.VVr5qG(self, path)
   elif category == "mov"         : self.VVr5qG(self, path)
   elif not FFbOjF(path)        : FFM8So(self, path)
 def VVEpcO(self):
  path = self.VV0RIm(self.VVVpUg())
  action = self.VV9WAk(path)
  if action == 1:
   self.VV1pyV(path)
   FFlf8A(self, "Added", 500)
  elif action == -1:
   self.VVZuSD(path)
   FFlf8A(self, "Removed", 500)
  self.VV9WAk(path)
 def VV1pyV(self, path):
  VVprx2 = self.VV8BLO()
  if not VVprx2:
   VVprx2 = []
  if len(VVprx2) >= self.VVPsXC:
   FFsqiC(SELF, "Max bookmarks reached (max=%d)." % self.VVPsXC)
  elif not path in VVprx2:
   VVprx2 = [path] + VVprx2
   self.VVy016(VVprx2)
 def VVMwTg(self):
  VVprx2 = self.VV8BLO()
  if VVprx2:
   newList = []
   for line in VVprx2:
    newList.append((line, line))
   VV123e  = ("Delete"  , self.VV74O3 )
   VVFM2s = ("Move Up"   , self.VVPJE0 )
   VVtOG5  = ("Move Down" , self.VVXrMX )
   self.bookmarkMenu = FFfsxJ(self, self.VVr2qd, title="Bookmarks", VVVLxj=newList, VV123e=VV123e, VVFM2s=VVFM2s, VVtOG5=VVtOG5)
 def VV74O3(self, VVVpUgObj, path):
  if self.bookmarkMenu:
   VVprx2 = self.VVZuSD(path)
   self.bookmarkMenu.VVCD45(VVprx2)
 def VVPJE0(self, VVVpUgObj, path):
  if self.bookmarkMenu:
   VVprx2 = self.bookmarkMenu.VV3Tp4(True)
   if VVprx2:
    self.VVy016(VVprx2)
 def VVXrMX(self, VVVpUgObj, path):
  if self.bookmarkMenu:
   VVprx2 = self.bookmarkMenu.VV3Tp4(False)
   if VVprx2:
    self.VVy016(VVprx2)
 def VVr2qd(self, folder=None):
  if folder:
   folder = FFSw9u(folder)
   self["myMenu"].VV0tvt(folder)
   self["myMenu"].moveToIndex(0)
  self.VVwa6F()
 def VV8BLO(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVUD2t(self, path):
  VVprx2 = self.VV8BLO()
  if VVprx2 and path in VVprx2:
   return True
  else:
   return False
 def VVqd1A(self):
  if VV8BLO():
   return True
  else:
   return False
 def VVy016(self, VVprx2):
  line = ",".join(VVprx2)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVZuSD(self, path):
  VVprx2 = self.VV8BLO()
  if VVprx2:
   while path in VVprx2:
    VVprx2.remove(path)
   self.VVy016(VVprx2)
   return VVprx2
 def VVYhl8(self, chDir=True):
  fPath, fDir, fName = CCt0KP.VVU7Qg(self)
  if fPath:
   if chDir:
    self["myMenu"].VV0tvt(fDir)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFlf8A(self, "Not found", 1000)
 def VVF1YB(self, path):
  if not os.path.isdir(path):
   path = FFdafY(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVrxfJ(self, selFile, VVQQbK, command):
  FFmhMd(self, boundFunction(FFyzyQ, self, command, VVPF19=self.VVN4PU), "%s\n\n%s" % (VVQQbK, selFile))
 def VVl79T(self, path, calledFromMenu):
  destPath = self.VVBgH2(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVVLxj = []
  if calledFromMenu:
   VVVLxj.append(VVQP0R)
   color = VVKSBp
  else:
   color = ""
  VVVLxj.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVVLxj.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVVLxj.append((color + "Extract Here"            , "extract_here"  ))
  if VVYe7k and path.endswith(".tar.gz"):
   VVVLxj.append(VVQP0R)
   VVVLxj.append((color + 'Convert to ".ipk" Package' , "VVeN1r"  ))
   VVVLxj.append((color + 'Convert to ".deb" Package' , "VVTPdL"  ))
  return VVVLxj
 def VV66y5(self, path, selFile):
  FFfsxJ(self, boundFunction(self.VVjOpc, path, selFile), title="Compressed File Options", VVVLxj=self.VVl79T(path, False))
 def VVjOpc(self, path, selFile, item=None):
  if item is not None:
   parent  = FFdafY(path, False)
   destPath = self.VVBgH2(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVVVdp
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFrytY("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFrytY("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVVVdp, VVVVdp)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFzH9C(self, cmd)
   elif path.endswith(".zip"):
    self.VVhAC9(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif path.endswith(".rar"):
    self.VVS2mk(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFnz2p("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVrxfJ(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVrxfJ(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFdafY(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVrxfJ(selFile, "Extract Here ?"      , cmd)
   elif item == "VVeN1r" : self.VVeN1r(path)
   elif item == "VVTPdL" : self.VVTPdL(path)
 def VVBgH2(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVhAC9(self, item, path, parent, destPath, VVQQbK):
  FFmhMd(self, boundFunction(self.VV8TFM, item, path, parent, destPath), VVQQbK)
 def VV8TFM(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVVVdp
  cmd  = FFrytY("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFFHM5(destPath, VVOn4X))
  cmd +=   sep
  cmd += "fi;"
  FFp6Bw(self, cmd, VVPF19=self.VVN4PU)
 def VVS2mk(self, item, path, parent, destPath, VVQQbK):
  FFmhMd(self, boundFunction(self.VV6I6S, item, path, parent, destPath), VVQQbK)
 def VV6I6S(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFSw9u(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVVVdp
  cmd  = FFrytY("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFFHM5(destPath, VVOn4X))
  cmd +=   sep
  cmd += "fi;"
  FFp6Bw(self, cmd, VVPF19=self.VVN4PU)
 def VV4qH9(self, addSep=False):
  VVVLxj = []
  if addSep:
   VVVLxj.append(VVQP0R)
  VVVLxj.append((VVKSBp + "View Script File"  , "script_View"  ))
  VVVLxj.append((VVKSBp + "Execute Script File" , "script_Execute" ))
  VVVLxj.append((VVKSBp + "Edit"     , "script_Edit" ))
  return VVVLxj
 def VVYARv(self, path, selFile):
  FFfsxJ(self, boundFunction(self.VVtCZC, path, selFile), title="Script File Options", VVVLxj=self.VV4qH9())
 def VVtCZC(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFM8So(self, path)
   elif item == "script_Execute" : self.VVrxfJ(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCj5OR(self, path)
 def VVKJ9S(self, addSep=False):
  VVVLxj = []
  if addSep:
   VVVLxj.append(VVQP0R)
  VVVLxj.append((VVKSBp + "Browse IPTV Channels"  , "m3u_Browse" ))
  VVVLxj.append((VVKSBp + "Edit"      , "m3u_Edit" ))
  VVVLxj.append((VVKSBp + "View"      , "m3u_View" ))
  return VVVLxj
 def VV34aX(self, path, selFile):
  FFfsxJ(self, boundFunction(self.VVTTmgItem_m3u, path, selFile), title="M3U/M3U8 File Options", VVVLxj=self.VVKJ9S())
 def VVTTmgItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FF6Ue4(self, boundFunction(self.session.open, CCvDyD, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCj5OR(self, path)
   elif item == "m3u_View"  : FFM8So(self, path)
 def VVgerV(self, path, selFile, newChmod):
  FFmhMd(self, boundFunction(self.VVUdA5, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVUdA5(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVVFG3)
  result = FFdBZy(cmd)
  if result == "Successful" : FFEf0P(self, result)
  else      : FFsqiC(self, result)
 def VVESZK(self, path, selFile):
  parent = FFdafY(path, False)
  self.session.openWithCallback(self.VVDxdW, boundFunction(CCt0KP, mode=CCt0KP.VVAn9X, VVFaGg=parent, VV2sjb="Create Symlink here"))
 def VVDxdW(self, newPath):
  if len(newPath) > 0:
   target = self.VV0RIm(self.VVVpUg())
   target = FFPM3Z(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFSw9u(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFsqiC(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFmhMd(self, boundFunction(self.VVS0Xk, target, link), "Create Soft Link ?\n\n%s" % txt, VVCf1C=True)
 def VVS0Xk(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVVFG3)
  result = FFdBZy(cmd)
  if result == "Successful" : FFEf0P(self, result)
  else      : FFsqiC(self, result)
 def VVlEsI(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFD8qa(self, boundFunction(self.VV9Kg5, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VV9Kg5(self, path, selFile, VVd6Iw):
  if VVd6Iw:
   parent = FFdafY(path, True)
   if os.path.isdir(path):
    path = FFPM3Z(path)
   newName = parent + VVd6Iw
   cmd = "mv '%s' '%s' %s" % (path, newName, VVVFG3)
   if VVd6Iw:
    if selFile != VVd6Iw:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFmhMd(self, boundFunction(self.VVAobq, cmd), message, title="Rename file?")
    else:
     FFsqiC(self, "Cannot use same name!", title="Rename")
 def VVAobq(self, cmd):
  result = FFdBZy(cmd)
  if "Fail" in result:
   FFsqiC(self, result)
  self.VVN4PU()
 def VVV4Mv(self, path, selFile, isMove):
  if isMove : VV2sjb = "Move to here"
  else  : VV2sjb = "Copy to here"
  parent = FFdafY(path, False)
  self.session.openWithCallback(boundFunction(self.VVhTuH, isMove, path, selFile)
         , boundFunction(CCt0KP, mode=CCt0KP.VVAn9X, VVFaGg=parent, VV2sjb=VV2sjb))
 def VVhTuH(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFPM3Z(path)
   newPath = FFSw9u(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFmhMd(self, boundFunction(FFtCAF, self, cmd, VVPF19=self.VVN4PU), txt, VVCf1C=True)
   else:
    FFsqiC(self, "Cannot %s to same directory !" % action.lower())
 def VVOta2(self, path, fileName):
  path = FFPM3Z(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFmhMd(self, boundFunction(self.VVauoX, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVauoX(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VVN4PU()
 def VVJTex(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VV6ebU and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVHZtD(self, path, isFile):
  dirName = FFSw9u(os.path.dirname(path))
  if isFile : objName, VVd6Iw = "File"  , self.edited_newFile
  else  : objName, VVd6Iw = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFD8qa(self, boundFunction(self.VVSd5m, dirName, isFile, title), title=title, defaultText=VVd6Iw, message="Enter %s Name:" % objName)
 def VVSd5m(self, dirName, isFile, title, VVd6Iw):
  if VVd6Iw:
   if isFile : self.edited_newFile = VVd6Iw
   else  : self.edited_newDir  = VVd6Iw
   path = dirName + VVd6Iw
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVVFG3)
    else  : cmd = "mkdir '%s' %s" % (path, VVVFG3)
    result = FFdBZy(cmd)
    if "Fail" in result:
     FFsqiC(self, result)
    self.VVN4PU()
   else:
    FFsqiC(self, "Name already exists !\n\n%s" % path, title)
 def VVLCn8(self, path, selFile):
  VVVLxj = []
  VVVLxj.append(("List Package Files"          , "VVakf3"     ))
  VVVLxj.append(("Package Information"          , "VVb3wT"     ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Install Package"           , "VV7dkI_CheckVersion" ))
  VVVLxj.append(("Install Package (force reinstall)"      , "VV7dkI_ForceReinstall" ))
  VVVLxj.append(("Install Package (force overwrite)"      , "VV7dkI_ForceOverwrite" ))
  VVVLxj.append(("Install Package (force downgrade)"      , "VV7dkI_ForceDowngrade" ))
  VVVLxj.append(("Install Package (ignore failed dependencies)"    , "VV7dkI_IgnoreDepends" ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Remove Related Package"         , "VVvyMU_ExistingPackage" ))
  VVVLxj.append(("Remove Related Package (force remove)"     , "VVvyMU_ForceRemove"  ))
  VVVLxj.append(("Remove Related Package (ignore failed dependencies)"  , "VVvyMU_IgnoreDepends" ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("Extract Files"           , "VVqEr0"     ))
  VVVLxj.append(("Unbuild Package"           , "VVuW6T"     ))
  FFfsxJ(self, boundFunction(self.VVBRR3, path, selFile), VVVLxj=VVVLxj)
 def VVBRR3(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVakf3"      : self.VVakf3(path, selFile)
   elif item == "VVb3wT"      : self.VVb3wT(path)
   elif item == "VV7dkI_CheckVersion"  : self.VV7dkI(path, selFile, VVH8bp     )
   elif item == "VV7dkI_ForceReinstall" : self.VV7dkI(path, selFile, VVcW3p )
   elif item == "VV7dkI_ForceOverwrite" : self.VV7dkI(path, selFile, VVZZd5 )
   elif item == "VV7dkI_ForceDowngrade" : self.VV7dkI(path, selFile, VVMYqO )
   elif item == "VV7dkI_IgnoreDepends" : self.VV7dkI(path, selFile, VVdufl )
   elif item == "VVvyMU_ExistingPackage" : self.VVvyMU(path, selFile, VVW7Es     )
   elif item == "VVvyMU_ForceRemove"  : self.VVvyMU(path, selFile, VVBvxk  )
   elif item == "VVvyMU_IgnoreDepends"  : self.VVvyMU(path, selFile, VV6BU1 )
   elif item == "VVqEr0"     : self.VVqEr0(path, selFile)
   elif item == "VVuW6T"     : self.VVuW6T(path, selFile)
   else           : self.close()
 def VVakf3(self, path, selFile):
  if FFJOWP("ar") : cmd = "allOK='1';"
  else    : cmd  = FFdtOa()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVVVdp, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVVVdp, VVVVdp)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFcuYL(self, cmd, VVPF19=self.VVN4PU)
 def VVqEr0(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFdafY(path, True) + selFile[:-4]
  cmd  =  FFdtOa()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFnz2p("mkdir '%s'" % dest) + ";"
  cmd +=    FFnz2p("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFFHM5(dest, VVOn4X))
  cmd += "fi;"
  FFyzyQ(self, cmd, VVPF19=self.VVN4PU)
 def VVuW6T(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVpiiC = os.path.splitext(path)[0]
  else        : VVpiiC = path + "_"
  if path.endswith(".deb")   : VVQi1J = "DEBIAN"
  else        : VVQi1J = "CONTROL"
  cmd  = FFdtOa()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVpiiC, FFtHUh())
  cmd += "  mkdir '%s';"    % VVpiiC
  cmd += "  CONTPATH='%s/%s';"  % (VVpiiC, VVQi1J)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVpiiC
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVpiiC, VVpiiC)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVpiiC
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVpiiC, VVpiiC)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVpiiC
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVpiiC
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVpiiC, FFFHM5(VVpiiC, VVOn4X))
  cmd += "fi;"
  FFyzyQ(self, cmd, VVPF19=self.VVN4PU)
 def VVb3wT(self, path):
  listCmd  = FF6GOT(VVcBD8, "")
  infoCmd  = FFvshm(VVsFnD , "")
  filesCmd = FFvshm(VVGWxm, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFM12k(VVHuTi)
   notInst = "Package not installed."
   cmd  = FFSH61("File Info", VVHuTi)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFSH61("System Info", VVHuTi)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFFHM5(notInst, VVKSBp))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFSH61("Related Files", VVHuTi)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFzH9C(self, cmd)
  else:
   FFEmMJ(self)
 def VV7dkI(self, path, selFile, cmdOpt):
  cmd = FFvshm(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFmhMd(self, boundFunction(FFyzyQ, self, cmd, VVPF19=FFAMk4), "Install Package ?\n\n%s" % selFile)
  else:
   FFEmMJ(self)
 def VVvyMU(self, path, selFile, cmdOpt):
  listCmd  = FF6GOT(VVcBD8, "")
  infoCmd  = FFvshm(VVsFnD, "")
  instRemCmd = FFvshm(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFFHM5(errTxt, VVKSBp))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFFHM5(cannotTxt, VVKSBp))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFFHM5(tryTxt, VVKSBp))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFmhMd(self, boundFunction(FFyzyQ, self, cmd, VVPF19=FFAMk4), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFEmMJ(self)
 def VVzLyQ(self, path):
  hostName = FFdBZy("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VV1nq6(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVzLyQ(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVotXW(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVVLxj = []
  VVVLxj.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVVLxj.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVVLxj.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVVLxj.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVVLxj.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVVLxj.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVVLxj.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVVLxj.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVVLxj.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVVLxj.append(VVQP0R)
  VVVLxj.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVVLxj.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FFfsxJ(self, boundFunction(self.VVJ3bM, path), VVVLxj=VVVLxj)
 def VVJ3bM(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VV7kv9(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VV7kv9(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VV7kv9(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VV7kv9(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VV7kv9(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VV7kv9(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VV7kv9(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VV7kv9(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VV7kv9(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VV7kv9(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVG9sY(path, False)
   elif item == "convertDirToDeb"   : self.VVG9sY(path, True)
   else         : self.close()
 def VVG9sY(self, path, VVq4bA):
  self.session.openWithCallback(self.VVN4PU, boundFunction(CCDu6G, path=path, VVq4bA=VVq4bA))
 def VV7kv9(self, path, fileExt, preserveDirStruct):
  parent  = FFdafY(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFrytY("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFrytY("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFrytY("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVVVdp
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFnz2p("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FFFHM5(resultFile, VVOn4X))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FFFHM5(failed, VVhgxA))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFcuYL(self, cmd, VVPF19=self.VVN4PU)
 def VV9w3P(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFM8So(self, versionFile)
 def VVg7mY(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVzLyQ(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFsqiC(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FF3tpP(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFdafY(path, False)
  VVpiiC = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FFFHM5(errCmd, VVhgxA))
  installCmd = FFvshm(VVH8bp , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VVpiiC, VVpiiC)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VVpiiC
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VVpiiC
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VVpiiC, VVpiiC)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFyzyQ(self, cmd, VVPF19=self.VVN4PU)
 def VVeN1r(self, path):
  FFsqiC(self, "Under Construction.")
 def VVTPdL(self, path):
  FFsqiC(self, "Under Construction.")
 @staticmethod
 def VVr5qG(SELF, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   SELF.session.open(CCwb6Z, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVU7Qg(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFSw9u(fDir), fName
  return "", "", ""
 @staticmethod
 def VVwSZ5(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVgx5r(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVnUtG(size, mode=0):
  txt = CCt0KP.VVBcjS(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVBcjS(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
class CC0JlM(MenuList):
 def __init__(self, VVUOuL=False, directory="/", VVMQEs=True, VVPIq1=True, VV3ywr=True, VVUEwe=None, VVrR0S=False, VVvK6s=False, VV31IG=False, isTop=False, VVx9pm=None, VVxaa4=1000, VVKTEW=30, VV3yZU=30, VVfLOs="#00000000"):
  MenuList.__init__(self, list, VVUOuL, eListboxPythonMultiContent)
  self.VVMQEs  = VVMQEs
  self.VVPIq1    = VVPIq1
  self.VV3ywr  = VV3ywr
  self.VVUEwe  = VVUEwe
  self.VVrR0S   = VVrR0S
  self.VVvK6s   = VVvK6s or []
  self.VV31IG   = VV31IG or []
  self.isTop     = isTop
  self.additional_extensions = VVx9pm
  self.VVxaa4    = VVxaa4
  self.VVKTEW    = VVKTEW
  self.VV3yZU    = VV3yZU
  self.pngBGColor    = FFtJYq(VVfLOs)
  self.EXTENSIONS    = self.VV0266()
  self.VV6MwM   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVScB1, self.VVKTEW))
  self.l.setItemHeight(self.VV3yZU)
  self.png_mem   = self.VVEeef("mem")
  self.png_usb   = self.VVEeef("usb")
  self.png_fil   = self.VVEeef("fil")
  self.png_dir   = self.VVEeef("dir")
  self.png_dirup   = self.VVEeef("dirup")
  self.png_srv   = self.VVEeef("srv")
  self.png_slwfil   = self.VVEeef("slwfil")
  self.png_slbfil   = self.VVEeef("slbfil")
  self.png_slwdir   = self.VVEeef("slwdir")
  self.VVZcow()
  self.VV0tvt(directory)
 def VVEeef(self, category):
  return LoadPixmap("%s%s.png" % (VVMPsf, category), getDesktop(0))
 def VV0266(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "rar" : "rar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u" ,
   "m3u8" : "m3u"
  }
 def VVZRYk(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFPM3Z(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFejnb(" -> " , VVHuTi) + FFejnb(os.readlink(path), VVOn4X)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VV3yZU + 10, 0, self.VVxaa4, self.VV3yZU, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVql7p: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV3yZU-4, self.VV3yZU-4, png, self.pngBGColor, self.pngBGColor, VVql7p))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV3yZU-4, self.VV3yZU-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVdUcO(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVZcow(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVEHQD(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVSVu7(self, file):
  if os.path.realpath(file) == file:
   return self.VVEHQD(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVEHQD(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVEHQD(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVYefb(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VV6MwM.info(l[0][0]).getEvent(l[0][0])
 def VVXBZJ(self):
  return self.list
 def VVfYE2(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VV0tvt(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VV3ywr:
    self.current_mountpoint = self.VVSVu7(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VV3ywr:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VV31IG and not self.VVfYE2(path, self.VVvK6s):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVZRYk(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVrR0S:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VV6MwM = eServiceCenter.getInstance()
   list = VV6MwM.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVMQEs and not self.isTop:
   if directory == self.current_mountpoint and self.VV3ywr:
    self.list.append(self.VVZRYk(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VV31IG and self.VVEHQD(directory) in self.VV31IG):
    self.list.append(self.VVZRYk(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVMQEs:
   for x in directories:
    if not (self.VV31IG and self.VVEHQD(x) in self.VV31IG) and not self.VVfYE2(x, self.VVvK6s):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVZRYk(name = name, absolute = x, isDir = True, png = png))
  if self.VVPIq1:
   for x in files:
    if self.VVrR0S:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFejnb(" -> " , VVHuTi) + FFejnb(target, VVOn4X)
       else:
        png = self.png_slbfil
        name += FFejnb(" -> " , VVHuTi) + FFejnb(target, VVhgxA)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVdUcO(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVMPsf, category))
    if (self.VVUEwe is None) or iCompile(self.VVUEwe).search(path):
     self.list.append(self.VVZRYk(name = name, absolute = x , isDir = False, png = png))
  if self.VV3ywr and len(self.list) == 0:
   self.list.append(self.VVZRYk(name = FFejnb("No USB connected", VV6AHZ), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVohmf(self):
  return self.current_directory
 def VVdH4o(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VV0tvt(self.getSelection()[0], select = self.current_directory)
 def VVY7Xj(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVnAe9(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVYqUz)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVYqUz)
 def refresh(self):
  self.VV0tvt(self.current_directory, self.VVY7Xj())
 def VVYqUz(self, action, device):
  self.VVZcow()
  if self.current_directory is None:
   self.refresh()
class CCvrN6(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FFO5bN(VVPlj3, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVprx2   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVjAhg(defFG, "#00FFFFFF")
  self.defBG   = self.VVjAhg(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FF4gq5(self, self.Title)
  self["keyRed"].show()
  FFoPjD(self["keyGreen"] , "< > Transp.")
  FFoPjD(self["keyYellow"], "Foreground")
  FFoPjD(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV6Ezk        ,
   "yellow"   : boundFunction(self.VVfPVp, False)  ,
   "blue"   : boundFunction(self.VVfPVp, True)  ,
   "up"   : self.VV8dvU          ,
   "down"   : self.VV01GK         ,
   "left"   : self.VVA8pr         ,
   "right"   : self.VVUCwC         ,
   "last"   : boundFunction(self.VVey0z, -5) ,
   "next"   : boundFunction(self.VVey0z, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VV0NuP)
 def VV0NuP(self):
  self.onShown.remove(self.VV0NuP)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFXT3k(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFXT3k(self["keyRed"] , c)
  FFXT3k(self["keyGreen"] , c)
  self.VVKNra()
  self.VV5cUG()
  FFhU57(self["myColorTst"], self.defFG)
  FFXT3k(self["myColorTst"], self.defBG)
 def VVjAhg(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VV5cUG(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VV8nGr(0, 0)
     return
 def VV6Ezk(self):
  self.close(self.defFG, self.defBG)
 def VV8dvU(self): self.VV8nGr(-1, 0)
 def VV01GK(self): self.VV8nGr(1, 0)
 def VVA8pr(self): self.VV8nGr(0, -1)
 def VVUCwC(self): self.VV8nGr(0, 1)
 def VV8nGr(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVDucu()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVbPXU()
 def VVKNra(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVbPXU(self):
  color = self.VVDucu()
  if self.isBgMode: FFXT3k(self["myColorTst"], color)
  else   : FFhU57(self["myColorTst"], color)
 def VVfPVp(self, isBg):
  self.isBgMode = isBg
  self.VVKNra()
  self.VV5cUG()
 def VVey0z(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VV8nGr(0, 0)
 def VVVRSy(self):
  return hex(self.transp)[2:].zfill(2)
 def VVDucu(self):
  return ("#%s%s" % (self.VVVRSy(), self.colors[self.curRow][self.curCol])).upper()
class CC22AG(ScrollLabel):
 def __init__(self, parentSELF, text="", VVGcaZ=True):
  ScrollLabel.__init__(self, text)
  self.VVGcaZ=VVGcaZ
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVIcGZ  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVKTEW    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close   ,
   "cancel"  : parentSELF.close   ,
   "red"   : self.VVyBmm   ,
   "green"   : self.VVMlAN  ,
   "yellow"  : self.VVRkAG  ,
   "blue"   : self.VVgRKY  ,
   "up"   : self.pageUp    ,
   "down"   : self.pageDown    ,
   "left"   : self.pageUp    ,
   "right"   : self.pageDown    ,
   "pageUp"  : self.VVrxO0    ,
   "chanUp"  : self.VVrxO0    ,
   "pageDown"  : self.VV5hB9    ,
   "chanDown"  : self.VV5hB9
  }, -1)
 def VVtkCY(self, isResizable=True, VVkjQ1=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FFVXe6(self.parentSELF, True)
  self.isResizable = isResizable
  if VVkjQ1:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVKTEW  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFXT3k(self, color)
 def FFXT3kColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVIcGZ - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VV2t92()
 def pageUp(self):
  if self.VVIcGZ > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVIcGZ > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVrxO0(self):
  self.setPos(0)
 def VV5hB9(self):
  self.setPos(self.VVIcGZ-self.pageHeight)
 def VV7I0j(self):
  return self.VVIcGZ <= self.pageHeight or self.curPos == self.VVIcGZ - self.pageHeight
 def VV2t92(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVIcGZ, 3))
   start = int((100 - vis) * self.curPos / (self.VVIcGZ - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVaC8s=VVbDZJ):
  old_VV7I0j = self.VV7I0j()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VVIcGZ = self.long_text.calculateSize().height()
   if self.VVGcaZ and self.VVIcGZ > self.pageHeight:
    self.scrollbar.show()
    self.VV2t92()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVIcGZ))
   if   VVaC8s == VVqUZV: self.setPos(0)
   elif VVaC8s == VV0v5h : self.VV5hB9()
   elif old_VV7I0j    : self.VV5hB9()
 def appendText(self, text, VVaC8s=VV0v5h):
  self.setText(self.message + str(text), VVaC8s)
 def VVRkAG(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVC4Ut(size)
 def VVgRKY(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVC4Ut(size)
 def VVMlAN(self):
  self.VVC4Ut(self.VVKTEW)
 def VVC4Ut(self, VVKTEW):
  self.long_text.setFont(gFont(self.fontFamily, VVKTEW))
  self.setText(self.message, VVaC8s=VVbDZJ)
  self.VVzhnR(calledFromFontSizer=True)
 def VVyBmm(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FFSw9u(expPath), self.textOutFile, FFYjSS())
    with open(outF, "w") as f:
     f.write(FF9jRB(self.message))
    FFEf0P(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FFsqiC(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVzhnR(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVIcGZ > 0 and self.pageHeight > 0:
   if self.VVIcGZ < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVIcGZ
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
