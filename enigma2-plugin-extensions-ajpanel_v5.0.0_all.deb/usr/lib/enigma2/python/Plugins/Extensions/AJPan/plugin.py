import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVvN9W   = "v5.0.0"
VV6U4P    = "20-04-2022"
EASY_MODE    = 0
VVR1Rz   = 0
VVjGHG   = 0
VVGWw1  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVIJZ6  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVXukQ    = "/media/usb/"
VVo91x    = "/usr/share/enigma2/picon/"
VVkenr = "/etc/enigma2/blacklist"
VVF0QF   = "/etc/enigma2/"
VVD4XV  = "ajpanel_update_url"
VVKo9M   = "AJPan"
VVKvlq    = "AUTO FIND"
VVPKgK    = ""
VVTpI8    = "Regular"
VVBOaW      = "-" * 80
VV15MX    = ("-" * 100, )
VV10fA    = ""
VVvn2k   = " && echo 'Successful' || echo 'Failed!'"
VVCg3N    = []
VVVrHS  = "Cannot continue (No Enough Memory) !"
VVxotg  = False
VVHIEW  = False
VV7sfd = False
VVTY88     = 0
VVWC5J    = 1
VVRYc1    = 2
VVbAWV   = 3
VVTlN4    = 4
VVFRD7    = 5
VVEzHn = 6
VVe0b2 = 7
VVQs0x  = 8
VVWuPu   = 9
VV8F6y   = 10
VVjgl4   = 11
VVF8vd  = 12
VV8VQv  = 13
VVmtqj    = 14
VV7QkT   = 15
VVIjGQ   = 16
VVVX7e    = 17
WINDOW_SUBTITLE    = 18
VVN0gV  = 19
VV34ku   = 0
VVFRw7   = 1
VVtm8Y   = 2
def FFqAsU():
 fList = None
 try:
  from enigma import getFontFaces
  return set(getFontFaces())
 except:
  try:
   from skin import getFontFaces
   return set(getFontFaces())
  except:
   pass
 return [VVTpI8]
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices=[ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.forceUtf8Encoding   = ConfigYesNo(default=True)
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsPath    = ConfigDirectory(default=VVKvlq, visible_width=51)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=51)
CFG.PIconsPath     = ConfigDirectory(default=VVo91x, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVXukQ, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
tmp = [("srt", "From SRT File"), ("#FFFFFF", "White"), ("#C0C0C0", "Silver"), ("#808080", "Gray"), ("#000000", "Black"), ("#FF0000", "Red"), ("#800000", "Maroon"), ("#FFFF00", "Yellow"), ("#808000", "Olive"), ("#00FF00", "Lime"), ("#008000", "Green"), ("#00FFFF", "Aqua"), ("#008080", "Teal"), ("#0000FF", "Blue"), ("#000080", "Navy"), ("#FF00FF", "Fuchsia"), ("#800080", "Purple")]
CFG.subtDelay     = ConfigSelection(default="0.0", choices=[ (str(x/10.0),  str(x/10.0)) for x in range(-600, 600, 5) ])
CFG.subtTextFg     = ConfigSelection(default="srt", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVTpI8, choices=[ (x,  x) for x in FFqAsU() ])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=80, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[ ("0", "Left"), ("1", "Center"), ("2", "Right") ])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=0, stepwidth=10, min=-140, max=140, wraparound=False)
del tmp
def FFNMSD():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVKG6j  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVqTnA = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVKG6j  : return 0
  elif VVqTnA : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVrHz1 = FFNMSD()
VVf4dJ = VVcDYh = VVf5u2 = VVd9bM = VVjqbJ = VVNYnt = VVUnli = VVAjxB = COLOR_CONS_BRIGHT_YELLOW = VVxzLQ = VVVd7L = VVB0Mu = VVX9gW = ""
def FFXc2x()  : return FFEjkV()
def FFRi4I(*args) : FF7Ged(True , True , *args)
def FFAkbZ(*args): FF7Ged(False, True , *args)
def FF5d74(*args): FF7Ged(True, False, *args)
def FF7Ged(addSep=True, oneLine=True, *args):
 if VVR1Rz:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if oneLine:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  else:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item:
      txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FF0kYt(txt, isAppend=True, ignoreErr=False):
 if VVR1Rz:
  tm = FF8yLl()
  err = ""
  if not ignoreErr:
   err = FFEjkV()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFRi4I(err)
  FFRi4I("Output Log File : %s" % fileName)
def FFEjkV():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FF8yLl()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except Exception as e:
  return "Cannot Trace !"
def FFhpMF():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVCg3N = []
def FF64m1(win):
 global VVCg3N
 if not win in VVCg3N:
  VVCg3N.append(win)
def FFurHP(*args):
 global VVCg3N
 for win in VVCg3N:
  try:
   win.close()
  except:
   pass
 VVCg3N = []
def FFfCiM():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVOy8a = FFfCiM()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFPPhz()     : return PluginDescriptor(fnc=FFbNSR, where=[PluginDescriptor.WHERE_SESSIONSTART] , needsRestart=True   , description="AJPanel Startup")
def FFZFyi()      : return getDescriptor(FFaOt5   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFE6Ld()       : return getDescriptor(FFX5zy  , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FF9rgk()   : return getDescriptor(FFCBsR , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFSRWj(): return getDescriptor(FFUKcD , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player"  , descr="Signal Monitor / Player")
def FFoL6w()  : return getDescriptor(FFmEpN  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV"     , descr="IPTV Menu")
def FFQqU6()     : return getDescriptor(FFjVB8 , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info."    , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFZFyi() , FFE6Ld() , FFPPhz() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FF9rgk())
  result.append(FFSRWj())
  result.append(FFoL6w())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFQqU6())
 return result
def FFbNSR(reason, **kwargs):
 if reason == 0:
  FFOJbf()
  if "session" in kwargs:
   session = kwargs["session"]
   FFFANC(session)
   CCwlrn(session)
  CC4HXa.VV3qmI()
def FFX5zy(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFaOt5, PLUGIN_NAME, 45)]
 else:
  return []
def FFaOt5(session, **kwargs):
 session.open(Main_Menu)
def FFCBsR(session, **kwargs):
 session.open(CCin0f)
def FFUKcD(session, **kwargs):
 FFezN6(session, isFromSession=True)
def FFmEpN(session, **kwargs):
 session.open(CCFXWw)
def FFjVB8(session, **kwargs):
 session.open(CCkvvO, fncMode=CCkvvO.VVaJZ6)
def FFJ3AK():
 FFJeHS(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FF9rgk(), FFSRWj(), FFoL6w() ])
 FFJeHS(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFQqU6() ])
def FFJeHS(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VV2J97 = None
def FFOJbf():
 try:
  global VV2J97
  if VV2J97 is None:
   VV2J97    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFNs07
  ChannelContextMenu.FFaSns = FFaSns
 except:
  pass
def FFNs07(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VV2J97(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFaSns, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFaSns, title1, csel, isFind=True))))
def FFaSns(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFYXgN(refCode)
 except:
  pass
 self.session.open(boundFunction(CC2t4f, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFFANC(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FFM04d, session, "lok")
 hk.actions['longCancel'] = boundFunction(FFM04d, session, "lesc")
 hk.actions['longRed']  = boundFunction(FFM04d, session, "lred")
def FFM04d(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFezN6(session, isFromSession=True)
def FFyutK(SELF, title="", addLabel=False, addScrollLabel=False, VV23GK=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFlC9C()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCHFVK(SELF)
 if VV23GK:
  SELF["myMenu"] = MenuList(VV23GK)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVNPMZ        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFffd6(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FFSiZ8, SELF, "0") ,
  "1"    : boundFunction(FFSiZ8, SELF, "1") ,
  "2"    : boundFunction(FFSiZ8, SELF, "2") ,
  "3"    : boundFunction(FFSiZ8, SELF, "3") ,
  "4"    : boundFunction(FFSiZ8, SELF, "4") ,
  "5"    : boundFunction(FFSiZ8, SELF, "5") ,
  "6"    : boundFunction(FFSiZ8, SELF, "6") ,
  "7"    : boundFunction(FFSiZ8, SELF, "7") ,
  "8"    : boundFunction(FFSiZ8, SELF, "8") ,
  "9"    : boundFunction(FFSiZ8, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FF0SNe, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFSiZ8(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVX9gW:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVX9gW + SELF.keyPressed + VVcDYh)
    txt = VVcDYh + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FF6E92(SELF, txt)
def FF0SNe(SELF, tableObj, colNum):
 FF6E92(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     SELF.VVP2LA(i)
     break
 except:
  pass
def FFrrou(SELF, setMenuAction=True):
 if setMenuAction:
  global VV10fA
  VV10fA = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFlC9C():
 return ("  %s" % VV10fA)
def FFdk5e(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFjaTr(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFeFJJ(color):
 return parseColor(color).argb()
def FFE31q(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FF6nEU(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFiCqD(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FF7UqE(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVX9gW)
 else:
  return ""
def FFpdcU(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVBOaW, word, VVBOaW, VVX9gW)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVBOaW, word, VVBOaW)
def FFhqic(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVX9gW
def FFtiGW(color):
 if color: return "echo -e '%s' %s;" % (VVBOaW, FF7UqE(VVBOaW, VVAjxB))
 else : return "echo -e '%s';" % VVBOaW
def FFJKjn(title, color):
 title = "%s\n%s\n%s\n" % (VVBOaW, title, VVBOaW)
 return FFhqic(title, color)
def FFTEKh(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFOTtB(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFRXLV(callBackFunction):
 tCons = CCPLjr()
 tCons.ePopen("echo", boundFunction(FF7kjQ, callBackFunction))
def FF7kjQ(callBackFunction, result, retval):
 callBackFunction()
def FFshid(SELF, fnc, title="Processing ...", clearMsg=True):
 FF6E92(SELF, title)
 tCons = CCPLjr()
 tCons.ePopen("echo", boundFunction(FFu4vk, SELF, fnc, clearMsg))
def FFu4vk(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FF6E92(SELF)
def FF6bpX(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVVrHS
  else       : return ""
def FFIx6K(cmd):
 txt = FF6bpX(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFjgvE(cmd):
 lines = FFIx6K(cmd)
 if lines: return lines[0]
 else : return ""
def FFg8nF(SELF, cmd):
 lines = FFIx6K(cmd)
 VVKG2e = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVKG2e.append((key, val))
  elif line:
   VVKG2e.append((line, ""))
 if VVKG2e:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFMNGj(SELF, None, header=header, VVYDUR=VVKG2e, VV5EM1=widths, VVzOAn=28)
 else:
  FFpzYC(SELF, cmd)
def FFpzYC(    SELF, cmd, **kwargs): SELF.session.open(CC88Hn, VVSgRh=cmd, VVp2W4=True, VViQnE=VVFRw7, **kwargs)
def FFfxIt(  SELF, cmd, **kwargs): SELF.session.open(CC88Hn, VVSgRh=cmd, **kwargs)
def FFeXoK(   SELF, cmd, **kwargs): SELF.session.open(CC88Hn, VVSgRh=cmd, VV5wRI=True, VVHeV2=True, VViQnE=VVFRw7, **kwargs)
def FFP4rI(  SELF, cmd, **kwargs): SELF.session.open(CC88Hn, VVSgRh=cmd, VV5wRI=True, VVHeV2=True, VViQnE=VVtm8Y, **kwargs)
def FFmkwf(  SELF, cmd, **kwargs): SELF.session.open(CC88Hn, VVSgRh=cmd, VVmd2W=True , **kwargs)
def FFGzz3( SELF, cmd, **kwargs): SELF.session.open(CC88Hn, VVSgRh=cmd, VV6ZeF=True   , **kwargs)
def FFCEYQ( SELF, cmd, **kwargs): SELF.session.open(CC88Hn, VVSgRh=cmd, VVO6LD=True  , **kwargs)
def FFrWND(cmd):
 return cmd + " > /dev/null 2>&1"
def FFZIFv():
 return " > /dev/null 2>&1"
def FFH7pp(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FF2qZL(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFqGXf():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFjgvE(cmd)
VVqLEj     = 0
VVpYaJ      = 1
VVPYPU   = 2
VVmFmC      = 3
VVHtxt      = 4
VVeFMm     = 5
VV5wtI     = 6
VVqCt4 = 7
VViGNM = 8
VVNwcc = 9
VVHGsQ  = 10
VVYc7m     = 11
VV5RQp  = 12
VVNmfE  = 13
def FF6WlR(parmNum, grepTxt):
 if   parmNum == VVqLEj  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVpYaJ   : param = ["list"   , "apt list" ]
 elif parmNum == VVPYPU: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFqGXf()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFHppj(parmNum, package):
 if   parmNum == VVmFmC      : param = ["info"      , "apt show"         ]
 elif parmNum == VVHtxt      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVeFMm     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VV5wtI     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVqCt4 : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VViGNM : param = ["install --force-overwrite" , "dpkg -i --force-overwrite -y"    ]
 elif parmNum == VVNwcc : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVHGsQ  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVYc7m     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VV5RQp  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVNmfE  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFqGXf()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFuJQY():
 result = FFjgvE("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFHppj(VV5wtI , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFrWND("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFrWND("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FF7UqE(failed1, VVAjxB))
   cmd += "  echo -e '%s' %s;"  % (failed2, FF7UqE(failed2, VVAjxB))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FF7UqE(failed3, VVf5u2))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FF5kV1(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFHppj(VV5wtI , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFrWND("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FF7UqE(failed1, VVAjxB))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FF7UqE(failed2, VVf5u2))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFkdJ5(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFrWND('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFrWND("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFp1Ek(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CC4HXa.VVgj2R()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FF8ZwU(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFp1Ek(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFwdI3(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFHtxR(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFp1Ek(path, maxSize=maxSize, encLst=encLst)
  if lines: FF9Qkx(SELF, lines, title=title, VViQnE=VVFRw7)
  else : FF8yum(SELF, path, title=title)
 else:
  FFxtzL(SELF, path, title)
def FFiYdB(SELF, path, title):
 if fileExists(path):
  txt = FFp1Ek(path)
  txt = txt.replace("#W#", VVX9gW)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVcDYh)
  txt = txt.replace("#C#", VVxzLQ)
  txt = txt.replace("#P#", VVd9bM)
  FF9Qkx(SELF, txt, title=title)
 else:
  FFxtzL(SELF, path, title)
def FFguZp(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FFggiK(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFL9q7(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFr9AH(parent)
 else    : return FFzC0I(parent)
def FFHtxR(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFr9AH(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFzC0I(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFKO9s():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVGWw1)
 paths.append(VVGWw1.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFggiK(ba)
 for p in list:
  p = ba + p + VVGWw1
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVKo9M, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVGWw1, VVKo9M , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVbN0T, VVBZq2 = FFKO9s()
def FFsIwZ():
 def VVecss(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 iPath = CFG.iptvHostsPath.getValue()
 if not iPath == VVKvlq and not pathExists(iPath):
  CFG.iptvHostsPath.setValue(VVKvlq)
  CFG.iptvHostsPath.save()
  oldIptvHostsPath = VVKvlq
 else:
  oldIptvHostsPath = ""
 oldMovieDownloadPath = VVecss(CFG.MovieDownloadPath, CCe2k3.VV5Eqs())
 VVjo6r   = VVecss(CFG.backupPath, CCftrN.VVoqEA())
 VVabOm   = VVecss(CFG.downloadedPackagesPath, t)
 VVy8yb  = VVecss(CFG.exportedTablesPath, t)
 VV6DBW  = VVecss(CFG.exportedPIconsPath, t)
 VVp0rM   = VVecss(CFG.packageOutputPath, t)
 global VVXukQ
 VVXukQ = FFr9AH(CFG.backupPath.getValue())
 if VVjo6r or VVp0rM or VVabOm or VVy8yb or VV6DBW or oldIptvHostsPath or oldMovieDownloadPath:
  configfile.save()
 return VVjo6r, VVp0rM, VVabOm, VVy8yb, VV6DBW, oldIptvHostsPath, oldMovieDownloadPath
def FFmr53(path):
 path = FFzC0I(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFQFQZ(SELF, pathList, tarFileName, addTimeStamp=True):
 VVYDUR = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVYDUR.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVYDUR.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVYDUR.append(path)
 if not VVYDUR:
  FFf3zP(SELF, "Files not found!")
 elif not pathExists(VVXukQ):
  FFf3zP(SELF, "Path not found!\n\n%s" % VVXukQ)
 else:
  VVpnzJ = FFr9AH(VVXukQ)
  tarFileName = "%s%s" % (VVpnzJ, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FF4Auk())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVYDUR:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVBOaW
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FF7UqE(tarFileName, VVUnli))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FF7UqE(failed, VVUnli))
  cmd += "fi;"
  cmd +=  sep
  FFfxIt(SELF, cmd)
def FFDx5r(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFbjWp(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFbjWp(SELF["keyInfo"], "info")
def FFbjWp(barObj, fName):
 path = "%s%s%s" % (VVBZq2, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFY2ZZ(SELF, title, VV5cQF, showGrnMsg=""):
 SELF.session.open(boundFunction(CCw8PJ, title=title, VV5cQF=VV5cQF, showGrnMsg=showGrnMsg))
def FFRJ4c(labelObj, VV5cQF):
 if VV5cQF and fileExists(VV5cQF):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VVSBrS(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VVSBrS)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VV5cQF)
   return True
  except:
   pass
 return False
def FFjHtS(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FF3j6k(satNum)
  return satName
def FF3j6k(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FF3fRh(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFjHtS(val)
  else  : sat = FF3j6k(val)
 return sat
def FFFD0p(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFjHtS(num)
 except:
  pass
 return sat
def FFWw3B(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFgUBe(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FF7eDN(info, iServiceInformation.sServiceref)
   prov = FF7eDN(info, iServiceInformation.sProvider)
   state = str(FF7eDN(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFzYwA(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFz3ec(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FF7eDN(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFdrTi(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFYXgN(refCode):
 info = FFqVul(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFqYNr(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFfFnU(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFqVul(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVXeyN = eServiceCenter.getInstance()
  if VVXeyN:
   info = VVXeyN.info(service)
 return info
def FFjNnf(SELF, refCode, VVOpaL=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  FFUl3V(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVOpaL:
   FFezN6(SELF, isFromSession)
 try:
  VVKFsj = InfoBar.instance
  if VVKFsj:
   VV0yB9 = VVKFsj.servicelist
   if VV0yB9:
    servRef = eServiceReference(refCode)
    VV0yB9.saveChannel(servRef)
 except:
  pass
def FFUl3V(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCNVFP()
    if pr.VVBwLw(refCode, chName, decodedUrl, iptvRef):
     pr.VVp7S6(SELF, isFromSession)
def FFzYwA(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFk8k1(url): return any(x in url for x in ("/movie/", "/series/", "mode=vod", "mode=series"))
def FF8rbS(url)  : return any(x in url for x in ("/movie/", "mode=vod"))
def FFBooI(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FFz3ec(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFIl0q(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFodem(userBfile):
 txt = ""
 bFile = VVF0QF + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVF0QF + userBfile):
  fTxt = FFp1Ek(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFjgvE('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
def FFIl0q(url):
 if iUnquote : return iUnquote(url)
 else  : return url
def FFuUoF(url):
 if iQuote : return iQuote(url)
 else  : return url
def FFYW6B(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFPO3d(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFFbmD(txt):
 try:
  return FFYW6B(FFPO3d(txt)) == txt
 except:
  return False
def FFezN6(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CC9pOJ, isFromExternal=isFromSession)
 else      : FFOi8d(session, reopen=True, isFromExternal=isFromSession)
def FFOi8d(session, reopen=False, isFromExternal=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFOi8d, session, isFromExternal=isFromExternal), boundFunction(CC1sBo, isFromExternal=isFromExternal))
  except:
   try:
    FFv3q1(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFeWHD(refCode):
 tp = CCqMXo()
 if tp.VVTNDX(refCode) : return True
 else        : return False
def FFnI4b(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFVeqY():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FF1HUL():
 VVKFsj = InfoBar.instance
 if VVKFsj:
  VV0yB9 = VVKFsj.servicelist
  if VV0yB9:
   return VV0yB9.getBouquetList()
 return None
def FFjqQJ():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFw4PJ():
 path = FFjqQJ()
 if path:
  txt = FFp1Ek(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FFe78W():
 return FFho3z(InfoBar.instance.servicelist.getRoot())
def FFho3z(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVXeyN = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVXeyN.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FFCiCm():
 VVIZdu = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVkKMa = list(VVIZdu)
 return VVkKMa, VVIZdu
def FFtnUh():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFmnsU(session, VVvpuH):
 VVj2Vh, VVqOlG, VVXX9n, camCommand = FFKnms()
 if VVqOlG:
  runLog = False
  if   VVvpuH == CC0SGr.VVJsvb : runLog = True
  elif VVvpuH == CC0SGr.VVQnSE : runLog = True
  elif not VVXX9n          : FFv3q1(session, message="SoftCam not started yet!")
  elif fileExists(VVXX9n)        : runLog = True
  else             : FFv3q1(session, message="File not found !\n\n%s" % VVXX9n)
  if runLog:
   session.open(boundFunction(CC0SGr, VVj2Vh=VVj2Vh, VVqOlG=VVqOlG, VVXX9n=VVXX9n, VVvpuH=VVvpuH))
 else:
  FFv3q1(session, message="No active OSCam/NCam found !", title="Live Log")
def FFKnms():
 VVj2Vh = "/etc/tuxbox/config/"
 VVqOlG = None
 VVXX9n  = None
 camCommand = FFjgvE("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVqOlG = "oscam"
 elif "ncam"  in camCommand : VVqOlG = "ncam"
 if VVqOlG:
  path = FFjgvE(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFr9AH(path)
  if pathExists(path):
   VVj2Vh = path
  tFile = VVj2Vh + VVqOlG + ".conf"
  tFile = FFjgvE("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVXX9n = tFile
 return VVj2Vh, VVqOlG, VVXX9n, camCommand
def FFXQPO(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFqkDy():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FF4Auk():
 return FFqkDy().replace(" ", "_").replace("-", "").replace(":", "")
def FFN2Gj(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FF8yLl():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FF2QcO(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCFXWw.VVdr9M(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCFXWw.VVuSjW_forBouquet(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFrWND("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFKZ30(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFqpoV(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
VVrlhF = 0
def FFCHKQ():
 global VVrlhF
 VVrlhF = iTime()
def FF1G1h():
 FFRi4I(">>>>>> Elapsed\t: {:.6f} seconds".format(iTime() - VVrlhF).rstrip("0").rstrip("."))
def FFTVfn(SELF, message, title=""):
 SELF.session.open(boundFunction(CCYqdb, title=title, message=message, VVin2T=True))
def FF9Qkx(SELF, message, title="", VViQnE=VVFRw7, **kwargs):
 SELF.session.open(boundFunction(CCYqdb, title=title, message=message, VViQnE=VViQnE, **kwargs))
def FFf3zP(SELF, message, title="")  : FFv3q1(SELF.session, message, title)
def FFxtzL(SELF, path, title="") : FFv3q1(SELF.session, "File not found !\n\n%s" % path, title)
def FF8yum(SELF, path, title="") : FFv3q1(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFywk7(SELF, title="")  : FFv3q1(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFv3q1(session, message, title="") : session.open(boundFunction(CCu2tz, title=title, message=message))
def FFnG6g(SELF, VVRMfQ, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVRMfQ, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVRMfQ, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVRMfQ, boundFunction(CCBg2X, title=title, message=message, VVZ6mF=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFf3zP(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFCKL0(SELF, callBack_Yes, VVoTby, callBack_No=None, title="", VVCyqa=False, VVYAYv=True):
 SELF.session.openWithCallback(boundFunction(FFMowB, callBack_Yes, callBack_No)
        , boundFunction(CCWmhj, title=title, VVoTby=VVoTby, VVYAYv=VVYAYv, VVCyqa=VVCyqa))
def FFMowB(callBack_Yes, callBack_No, FFCKL0ed):
 if FFCKL0ed : callBack_Yes()
 elif callBack_No: callBack_No()
def FF6E92(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FF6nEU(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FF6ada(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFuEE1(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVYBmM = eTimer()
def FF6ada(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FF9ceQ, SELF))
 fnc = boundFunction(FF9ceQ, SELF)
 try:
  t = VVYBmM.timeout.connect(fnc)
 except:
  VVYBmM.callback.append(fnc)
 VVYBmM.start(milliSeconds, 1)
def FF9ceQ(SELF):
 VVYBmM.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFMNGj(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCr4It, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCr4It, **kwargs))
  FF64m1(win)
  return win
 except:
  return None
def FFdX2v(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCQxIB, **kwargs))
 FF64m1(win)
 return win
def FFMw5O(SELF, **kwargs):
 SELF.session.open(CCkvvO, **kwargs)
def FF22W2(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFtYxN(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVTpI8, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFm42V(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFtYxN(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFx23H():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFyq7C(VVzOAn):
 screenSize  = FFx23H()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVzOAn)
 return bodyFontSize
def FFMWzO(VVzOAn, extraSpace):
 font = gFont(VVTpI8, VVzOAn)
 VVtEei = fontRenderClass.getInstance().getLineHeight(font) or (VVzOAn * 1.25)
 return int(VVtEei + VVtEei * extraSpace)
def FFSDka(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFx23H()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVTpI8, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFMWzO(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVTpI8, titleFontSize, alignLeftCenter)
 if winType == VVTY88 or winType == VVWC5J:
  if winType == VVWC5J : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVN0gV:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == WINDOW_SUBTITLE:
  lineH = int((height - 8) / 3.0)
  top = 2
  tmp += '<widget name="mySubtFr" position="0,0" size="%d,%d" zPosition="10" backgroundColor="#00FFFF00" />' % (width, height)
  for i in range(3):
   tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="11" foregroundColor="#ffffff" shadowColor="#555555" shadowOffset="-2,-2" backgroundColor="#ff000000" %s %s />' % (i, top + 2, width - 2, lineH - 2, bodyFontStr, alignCenter)
   top += lineH
 elif winType == VVmtqj:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FFTVfnL = b2Left2 + timeW + marginLeft
  FFTVfnW = b2Left3 - marginLeft - FFTVfnL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FFTVfnL  , b2Top, FFTVfnW , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
 elif winType == VV7QkT:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVTlN4:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVRYc1:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVbAWV:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVTpI8, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVTpI8, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VV8F6y:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFTVfnH = int(bodyH * 0.5)
  inpTop = bodyTop + FFTVfnH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFTVfnH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVTpI8, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVTpI8, mapF, alignCenter)
 elif winType == VVjgl4:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVF8vd:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVTpI8, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVIjGQ:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVTpI8, fontH, alignCenter)
 elif winType == VV8VQv:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVTpI8, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVTpI8, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVTpI8, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVVX7e:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 else:
  if   winType == VVe0b2 : align = alignLeftCenter
  elif winType == VVEzHn : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVWuPu:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VVFRD7:
   moreParams = ""
  else:
   fontName = VVTpI8
   if usefixedFont and winType == VVEzHn:
    fnt = "Fixed"
    if fnt in FFqAsU():
     fontName = "Fixed"
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVzOAn = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVTpI8, VVzOAn, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVwsQj = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVTpI8, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVwsQj[i], VVTpI8, barFont, alignCenter)
   left += btnW + gap
 if winType == VVEzHn:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVwsQj = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVwsQj[i], VVTpI8, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFSDka(VVTY88, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.VVUuL8 = ""
  self.themsList  = []
  VV23GK = []
  if VVjGHG:
   VV23GK.append(("-- MY TEST --"    , "myTest"   ))
  VV23GK.append(("  File Manager"     , "FileManager"  ))
  VV23GK.append(VV15MX)
  VV23GK.append(("  Services/Channels"    , "ChannelsTools" ))
  VV23GK.append(("  IPTV"       , "IptvTools"  ))
  VV23GK.append(("  PIcons"       , "PIconsTools"  ))
  VV23GK.append(("  SoftCam"      , "SoftCam"   ))
  VV23GK.append(VV15MX)
  VV23GK.append(("  Plugins"      , "PluginsTools" ))
  VV23GK.append(("  Terminal"      , "Terminal"  ))
  VV23GK.append(("  Backup & Restore"    , "BackupRestore" ))
  VV23GK.append(VV15MX)
  VV23GK.append(("  Date/Time"      , "Date_Time"  ))
  VV23GK.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VV23GK)
  FFyutK(self, VV23GK=VV23GK)
  FFdk5e(self["keyRed"] , "Exit")
  FFdk5e(self["keyGreen"] , "Settings")
  FFdk5e(self["keyYellow"], "Dev. Info.")
  FFdk5e(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VVvovF       ,
   "yellow"  : self.VV27iv       ,
   "blue"   : self.VV3TpX       ,
   "info"   : self.VV3TpX       ,
   "next"   : self.VVc7Go       ,
   "menu"   : self.VVrFem     ,
   "text"   : self.VVOwIH      ,
   "0"    : boundFunction(self.VVp6Lw, 0) ,
   "1"    : boundFunction(self.VVVYXc, 1)   ,
   "2"    : boundFunction(self.VVVYXc, 2)   ,
   "3"    : boundFunction(self.VVVYXc, 3)   ,
   "4"    : boundFunction(self.VVVYXc, 4)   ,
   "5"    : boundFunction(self.VVVYXc, 5)   ,
   "6"    : boundFunction(self.VVVYXc, 6)   ,
   "7"    : boundFunction(self.VVVYXc, 7)   ,
   "8"    : boundFunction(self.VVVYXc, 8)   ,
   "9"    : boundFunction(self.VVVYXc, 9)
  })
  self.onShown.append(self.VVSdHz)
  self.onClose.append(self.onExit)
  global VVxotg, VVHIEW, VV7sfd
  VVxotg = VVHIEW = VV7sfd = False
 def VVNPMZ(self):
  item = FFrrou(self)
  self.VVVYXc(item)
 def VVVYXc(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVgnAm()
   elif item in ("FileManager"  , 1) : self.session.open(CCin0f)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCLPQZ)
   elif item in ("IptvTools"  , 3) : self.session.open(CCFXWw)
   elif item in ("PIconsTools"  , 4) : self.VVrvbh()
   elif item in ("SoftCam"   , 5) : self.session.open(CCPP6E)
   elif item in ("PluginsTools" , 6) : self.session.open(CC2WA3)
   elif item in ("Terminal"  , 7) : self.session.open(CC1Js8)
   elif item in ("BackupRestore" , 8) : self.session.open(CC4ptf)
   elif item in ("Date_Time"  , 9) : self.session.open(CCkRwU)
   elif item in ("CheckInternet" , 10) : self.session.open(CCJDAS)
   else         : self.close()
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FFTEKh(self["myMenu"])
  FFm42V(self)
  FF22W2(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVvN9W)
  self["myTitle"].setText(title)
  VVjo6r, VVp0rM, VVabOm, VVy8yb, VV6DBW, oldIptvHostsPath, oldMovieDownloadPath = FFsIwZ()
  self.VV99LU()
  if VVjo6r or VVp0rM or VVabOm or VVy8yb or VV6DBW or oldIptvHostsPath or oldMovieDownloadPath:
   VVXwkx = lambda path, subj: "%s:\n%s\n\n" % (subj, FFhqic(path, VVf5u2)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVXwkx(oldIptvHostsPath  , "IPTV Hosts Files Path"   )
   txt += VVXwkx(VVjo6r   , "Backup/Restore Path"    )
   txt += VVXwkx(VVp0rM  , "Created Package Files (IPK/DEB)" )
   txt += VVXwkx(VVabOm  , "Download Packages (from feeds)" )
   txt += VVXwkx(VVy8yb , "Exported Tables"     )
   txt += VVXwkx(VV6DBW , "Exported PIcons"     )
   txt += VVXwkx(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FF9Qkx(self, txt, title="Settings Paths")
  if (EASY_MODE or VVR1Rz or VVjGHG):
   FF6nEU(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FF6E92(self, "Welcome", 300)
  FFRXLV(boundFunction(self.VVB2cp, title))
 def VVB2cp(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCftrN.VV1lbJ()
   if url:
    newWebVer = CCftrN.VVvnK3(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFrWND("rm /tmp/ajpanel*"))
  global VVxotg, VVHIEW, VV7sfd
  VVxotg = VVHIEW = VV7sfd = False
 def VVp6Lw(self, digit):
  self.VVUuL8 += str(digit)
  ln = len(self.VVUuL8)
  global VVxotg, VV7sfd
  if ln == 4:
   if self.VVUuL8 == "0" * ln:
    VVxotg = True
    FF6nEU(self["myTitle"], "#800080")
   else:
    self.VVUuL8 = "x"
  elif self.VVUuL8 == "0" * 8:
   VV7sfd = True
 def VVc7Go(self):
  self.VVUuL8 += ">"
  if self.VVUuL8 == "0" * 4 + ">" * 2:
   global VVHIEW
   VVHIEW = True
   FF6nEU(self["myTitle"], "#dd5588")
 def VVOwIH(self):
  if self.VVUuL8 == "0" * 4:
   ok = False
   fnt = "ae_AlMateen.ttf"
   fontFile = "/usr/share/fonts/%s" % fnt
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    try:
     addFont(fontFile, fontName, 100, True)
     ok = True
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      ok = True
     except:
      pass
   if ok: txt = 'Added Font: "%s"' % fnt
   else : txt = '"%s" Not Found' % fnt
   FF6E92(self, txt, 2000, isGrn=ok)
 def VVrvbh(self):
  found = False
  pPath = CCkYaA.VVN8ry()
  if pathExists(pPath):
   for fName, fType in CCkYaA.VVDH7b(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCkYaA)
  else:
   VV23GK = []
   VV23GK.append(("PIcons Manager" , "CCkYaA" ))
   VV23GK.append(VV15MX)
   VV23GK.append(CCkYaA.VVK1fm())
   VV23GK.append(VV15MX)
   VV23GK += CCkYaA.VV7ySE()
   FFdX2v(self, self.VVh0DH, VV23GK=VV23GK)
 def VVh0DH(self, item=None):
  if item:
   if   item == "CCkYaA"   : self.session.open(CCkYaA)
   elif item == "VVFJIL"  : CCkYaA.VVFJIL(self)
   elif item == "VVxrPL"  : CCkYaA.VVxrPL(self)
   elif item == "findPiconBrokenSymLinks" : CCkYaA.VVtT2k(self, True)
   elif item == "FindAllBrokenSymLinks" : CCkYaA.VVtT2k(self, False)
 def VVvovF(self):
  self.session.open(CCftrN)
 def VV27iv(self):
  self.session.open(CCq5DM)
 def VV3TpX(self):
  changeLogFile = VVBZq2 + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FF8ZwU(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFhqic("\n%s\n%s\n%s" % (VVBOaW, line, VVBOaW), VVd9bM, VVX9gW)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FFhqic(line, VVcDYh, VVX9gW)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FF9Qkx(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VVvN9W), VVzOAn=26)
 def VVrFem(self):
  VV23GK = []
  VV23GK.append(("Title Colors"   , "title" ))
  VV23GK.append(("Menu Area Colors"  , "body" ))
  VV23GK.append(("Menu Pointer Colors" , "cursor" ))
  VV23GK.append(("Bottom Bar Colors" , "bar"  ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Reset Colors"   , "reset" ))
  title = "Main Menu Colors"
  FFdX2v(self, boundFunction(self.VVokJx, title), VV23GK=VV23GK, width=500, title=title)
 def VVokJx(self, title, item=None):
  if item:
   if item == "reset":
    FFCKL0(self, self.VVxapV, "Reset to default colors ?", title=title)
   else:
    tDict = self.VV16dh()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VVuInZ, tDict, item), CCsThb, defFG=fg, defBG=bg)
 def VVLbdb(self):
  return VVXukQ + "ajpanel_colors"
 def VV16dh(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVLbdb()
  if fileExists(p):
   txt = FFp1Ek(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVuInZ(self, tDict, item, fg, bg):
  if fg:
   self.VVVlt3(item, fg)
   self.VVHBfr(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVoRoJ(tDict)
 def VVoRoJ(self, tDict):
   p = self.VVLbdb()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVVlt3(self, item, fg):
  if   item == "title" : FFE31q(self["myTitle"], fg)
  elif item == "body"  :
   FFE31q(self["myMenu"], fg)
   FFE31q(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FF6nEU(self["myBar"], fg)
   FFE31q(self["keyRed"], fg)
   FFE31q(self["keyGreen"], fg)
   FFE31q(self["keyYellow"], fg)
   FFE31q(self["keyBlue"], fg)
 def VVHBfr(self, item, bg):
  if   item == "title" : FF6nEU(self["myTitle"], bg)
  elif item == "body"  :
   FF6nEU(self["myMenu"], bg)
   FF6nEU(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FF6nEU(self["myBar"], bg)
 def VVxapV(self):
  os.system(FFrWND("rm %s" % self.VVLbdb()))
  self.close()
 def VV99LU(self):
  tDict = self.VV16dh()
  self.VVK4C2(tDict, "title")
  self.VVK4C2(tDict, "body")
  self.VVK4C2(tDict, "cursor")
  self.VVK4C2(tDict, "bar")
 def VVK4C2(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVVlt3(name, fg)
  if bg: self.VVHBfr(name, bg)
 def VVgnAm(self):
  FFezN6(self)
class CC4HXa():
 @staticmethod
 def VVgj2R():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VV3qmI(isApply=False):
  global VVPpML, VVgpZu
  VVPpML  = True
  VVgpZu = CC4HXa.VVPHtZ()
  CC4HXa.VVp6xy()
 def VVp6xy():
  if VVgpZu:
   global VVPpML
   if CFG.forceUtf8Encoding.getValue():
    if CC4HXa.VVhUTI() : VVPpML = True
    else        : VVPpML = False
   else:
    CC4HXa.VVWKKz()
    VVPpML = False
 @staticmethod
 def VVPHtZ(isApply=False):
  from sys import version_info
  if version_info[0] >= 3 and version_info[1] >= 10:
   path = "/etc/issue"
   if fileExists(path):
    path = "/etc/issue"
    if fileExists(path):
     txt = FFp1Ek(path)
     span = iSearch(r"open.?vision", txt, IGNORECASE)
     if span:
      return True
  return False
 @staticmethod
 def VVhUTI():
  import locale
  enc = locale.getdefaultlocale()[1]
  span = iSearch(r"UTF.?8", enc, IGNORECASE)
  if not span:
   try:
    import locale
    return locale.setlocale(locale.LC_ALL, "en_GB.UTF-8")
   except:
    pass
  return None
 @staticmethod
 def VVWKKz():
  try:
   import locale
   return locale.setlocale(locale.LC_ALL, "")
  except:
   return None
 @staticmethod
 def VVh0M1(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFMNGj(SELF, None, VVYDUR=lst, VVzOAn=30, VV5Y0Y=True)
 @staticmethod
 def VVhXg3(path, SELF=None):
  for enc in CC4HXa.VVgj2R():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFf3zP(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVh3JB(SELF, path, cbFnc, defEnc="", pos=0):
  FF6E92(SELF)
  lst = CC4HXa.VV9kry(path)
  if lst:
   VV23GK = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if defEnc == enc:
     txt = FFhqic(txt, VVUnli)
    VV23GK.append((txt, enc))
   win = FFdX2v(SELF, cbFnc, title="Select Encoding", VV23GK=VV23GK, width=900, height=500 if pos == 1 else 0)
   if pos == 1:
    win.instance.move(ePoint(40, 40))
  else:
   FF6E92(SELF, "No proper encoding", 2000)
 @staticmethod
 def VV9kry(path):
  encLst = []
  cPath = VVBZq2 + "codecs"
  if fileExists(cPath):
   lines = FF8ZwU(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CC4HXa.VVgj2R())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    try:
     with ioOpen(path, "r", encoding=enc) as f:
      for line in f:
       pass
     lst.append((item[0], enc))
    except:
     pass
  return lst
class CCq5DM(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFSDka(VVTY88, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VV23GK = []
  VV23GK.append(("Settings File"        , "SettingsFile"   ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Box Info"          , "VV8Hu2"    ))
  VV23GK.append(("Tuners Info"         , "VVB4b3"   ))
  VV23GK.append(("Python Version"        , "VVbEYj"   ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Screen Size"         , "ScreenSize"    ))
  VV23GK.append(("Language/Locale"        , "Locale"     ))
  VV23GK.append(("Processor"         , "Processor"    ))
  VV23GK.append(("Operating System"        , "OperatingSystem"   ))
  VV23GK.append(("Drivers"          , "drivers"     ))
  VV23GK.append(VV15MX)
  VV23GK.append(("System Users"         , "SystemUsers"    ))
  VV23GK.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VV23GK.append(("Uptime"          , "Uptime"     ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Host Name"         , "HostName"    ))
  VV23GK.append(("MAC Address"         , "MACAddress"    ))
  VV23GK.append(("Network Configuration"      , "NetworkConfiguration" ))
  VV23GK.append(("Network Status"        , "NetworkStatus"   ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Disk Usage"         , "VVOKWH"    ))
  VV23GK.append(("Mount Points"         , "MountPoints"    ))
  VV23GK.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VV23GK.append(("USB Devices"         , "USB_Devices"    ))
  VV23GK.append(("List Block-Devices"       , "listBlockDevices"  ))
  VV23GK.append(("Directory Size"        , "DirectorySize"   ))
  VV23GK.append(("Memory"          , "Memory"     ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VV23GK.append(("Running Processes"       , "RunningProcesses"  ))
  VV23GK.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFyutK(self, VV23GK=VV23GK, title="Device Information")
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FFTEKh(self["myMenu"])
  FFm42V(self)
 def VVNPMZ(self):
  global VV10fA
  VV10fA = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CC2VeK)
   elif item == "VV8Hu2"    : self.VV8Hu2()
   elif item == "VVB4b3"   : self.VVB4b3()
   elif item == "VVbEYj"   : self.VVbEYj()
   elif item == "ScreenSize"    : FF9Qkx(self, "Width\t: %s\nHeight\t: %s" % (FFx23H()[0], FFx23H()[1]))
   elif item == "Locale"     : CC4HXa.VVh0M1(self)
   elif item == "Processor"    : self.VVvpzL()
   elif item == "OperatingSystem"   : FFpzYC(self, "uname -a"        )
   elif item == "drivers"     : self.VV6l1X()
   elif item == "SystemUsers"    : FFpzYC(self, "id"          )
   elif item == "LoggedInUsers"   : FFpzYC(self, "who -a"         )
   elif item == "Uptime"     : FFpzYC(self, "uptime"         )
   elif item == "HostName"     : FFpzYC(self, "hostname"        )
   elif item == "MACAddress"    : self.VVtQMT()
   elif item == "NetworkConfiguration"  : FFpzYC(self, "ifconfig %s %s" % (FF7UqE("HWaddr", VVB0Mu), FF7UqE("addr:", VVAjxB)))
   elif item == "NetworkStatus"   : FFpzYC(self, "netstat -tulpn"       )
   elif item == "VVOKWH"    : self.VVOKWH()
   elif item == "MountPoints"    : FFpzYC(self, "mount %s" % (FF7UqE(" on ", VVAjxB)))
   elif item == "FileSystemTable"   : FFpzYC(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFpzYC(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFpzYC(self, "blkid"         )
   elif item == "DirectorySize"   : FFpzYC(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VV2i7R="Reading size ...")
   elif item == "Memory"     : FFpzYC(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVSHDf()
   elif item == "RunningProcesses"   : FFpzYC(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFpzYC(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVQLJ6()
   else         : self.close()
 def VVtQMT(self):
  res = FF6bpX("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FF9Qkx(self, txt)
  else:
   FFpzYC(self, "ip link")
 def VVuubJ(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFIx6K(cmd)
  return lines
 def VVoJdB(self, lines, headerRepl, widths, VVbtsV):
  VVKG2e = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVKG2e.append(parts)
  if VVKG2e and len(header) == len(widths):
   VVKG2e.sort(key=lambda x: x[0].lower())
   FFMNGj(self, None, header=header, VVYDUR=VVKG2e, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=28, VV5Y0Y=True)
   return True
  else:
   return False
 def VVOKWH(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VVuubJ(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVbtsV = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VVoJdB(lines, headerRepl, widths, VVbtsV)
  if not allOK:
   lines = FFIx6K(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFzC0I(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVUnli:
     note = "\n%s" % FFhqic("Green = Mounted Partitions", VVUnli)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVAjxB
     elif line.endswith(mountList) : color = VVUnli
     else       : color = VVcDYh
     txt += FFhqic(line, color) + "\n"
    FF9Qkx(self, txt + note)
   else:
    FFf3zP(self, "Not data from system !")
 def VVSHDf(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVuubJ(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVbtsV = (LEFT , CENTER, LEFT )
  allOK = self.VVoJdB(lines, headerRepl, widths, VVbtsV)
  if not allOK:
   FFpzYC(self, cmd)
 def VV6l1X(self):
  cmd = FF6WlR(VVPYPU, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFpzYC(self, cmd)
  else : FFywk7(self)
 def VVvpzL(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFpzYC(self, cmd)
 def VVQLJ6(self):
  cmd = FF6WlR(VVpYaJ, "| grep secondstage")
  if cmd : FFpzYC(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFywk7(self)
 def VV8Hu2(self):
  c = VVUnli
  VVYDUR = []
  VVYDUR.append((FFhqic("Box Type"  , c), FFhqic(self.VVgpsz("boxtype").upper(), c)))
  VVYDUR.append((FFhqic("Board Version", c), FFhqic(self.VVgpsz("board_revision") , c)))
  VVYDUR.append((FFhqic("Chipset"  , c), FFhqic(self.VVgpsz("chipset")  , c)))
  VVYDUR.append((FFhqic("S/N"   , c), FFhqic(self.VVgpsz("sn")    , c)))
  VVYDUR.append((FFhqic("Version"  , c), FFhqic(self.VVgpsz("version")  , c)))
  VVODpc   = []
  VVf892 = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVf892 = SystemInfo[key]
     else:
      VVODpc.append((FFhqic(str(key), VVxzLQ), FFhqic(str(SystemInfo[key]), VVxzLQ)))
  except:
   pass
  if VVf892:
   VV1Duk = self.VVKQa3(VVf892)
   if VV1Duk:
    VV1Duk.sort(key=lambda x: x[0].lower())
    VVYDUR += VV1Duk
  if VVODpc:
   VVODpc.sort(key=lambda x: x[0].lower())
   VVYDUR += VVODpc
  if VVYDUR:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFMNGj(self, None, header=header, VVYDUR=VVYDUR, VV5EM1=widths, VVzOAn=28, VV5Y0Y=True)
  else:
   FF9Qkx(self, "Could not read info!")
 def VVgpsz(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FF8ZwU(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVKQa3(self, mbDict):
  try:
   mbList = list(mbDict)
   VVYDUR = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVYDUR.append((FFhqic(subject, VVAjxB), FFhqic(value, VVAjxB)))
  except:
   pass
  return VVYDUR
 def VVB4b3(self):
  txt = self.VVanA5("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVanA5("/proc/bus/nim_sockets")
  if not txt: txt = self.VVcuES()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FF9Qkx(self, txt)
 def VVcuES(self):
  txt = ""
  VVXwkx = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVXwkx("Slot Name" , slot.getSlotName())
     txt += FFhqic(slotName, VVAjxB)
     txt += VVXwkx("Description"  , slot.getFullDescription())
     txt += VVXwkx("Frontend ID"  , slot.frontend_id)
     txt += VVXwkx("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVanA5(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FF8ZwU(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFhqic(line, VVAjxB)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVbEYj(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FF9Qkx(self, txt)
class CC2VeK(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFSDka(VVTY88, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VV23GK = []
  VV23GK.append(("Settings (All)"   , "Settings_All"   ))
  VV23GK.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  if VVHIEW:
   VV23GK.append(("Settings (FHDG-17)" , "Settings_FHDG_17"  ))
  VV23GK.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VV23GK.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VV23GK.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VV23GK.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VV23GK.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFyutK(self, VV23GK=VV23GK)
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FFTEKh(self["myMenu"])
  FFm42V(self)
 def VVNPMZ(self):
  global VV10fA
  VV10fA = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFpzYC(self, cmd                )
   elif item == "Settings_HotKeys"   : FFpzYC(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFpzYC(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFpzYC(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFpzYC(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFpzYC(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFpzYC(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFpzYC(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCPP6E(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFSDka(VVTY88, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVj2Vh, VVqOlG, VVXX9n, camCommand = FFKnms()
  self.VVqOlG = VVqOlG
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VV23GK = []
  VV23GK.append(("OSCam Files"        , "OSCamFiles"  ))
  VV23GK.append(("NCam Files"        , "NCamFiles"  ))
  VV23GK.append(("CCcam Files"        , "CCcamFiles"  ))
  VV23GK.append(VV15MX)
  VV23GK.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VV23GK.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VV23GK.append(VV15MX)
  if VVqOlG:
   if   "oscam" in VVqOlG : camName = "OSCam"
   elif "ncam"  in VVqOlG : camName = "NCam"
   VV23GK.append((camName + " Info."      , "camInfo"   ))
   VV23GK.append((camName + " Live Status"    , "camLiveStatus" ))
   VV23GK.append((camName + " Live Readers"    , "camLiveReaders" ))
   VV23GK.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VV23GK.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFyutK(self, VV23GK=VV23GK)
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FFTEKh(self["myMenu"])
  FFm42V(self)
 def VVNPMZ(self):
  global VV10fA
  VV10fA = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCoDqi, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCoDqi, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCoDqi, "cccam"))
   elif item == "OSCamReaders"  : self.VVSq82("os")
   elif item == "NSCamReaders"  : self.VVSq82("n")
   elif item == "camInfo"   : FFg8nF(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFmnsU(self.session, CC0SGr.VVJsvb)
   elif item == "camLiveReaders" : FFmnsU(self.session, CC0SGr.VVQnSE)
   elif item == "camLiveLog"  : FFmnsU(self.session, CC0SGr.VV6m6X)
   else       : self.close()
 def VVSq82(self, camPrefix):
  VVKG2e = self.VV7NeS(camPrefix)
  if VVKG2e:
   VVKG2e.sort(key=lambda x: int(x[0]))
   if self.VVqOlG and self.VVqOlG.startswith(camPrefix):
    VVtony = ("Toggle State", self.VVjmFr, [camPrefix], "Changing State ...")
   else:
    VVtony = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVbtsV  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFMNGj(self, None, header=header, VVYDUR=VVKG2e, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=26, VVtony=VVtony, VViKTA=True)
 def VV7NeS(self, camPrefix):
  readersFile = self.VVj2Vh + camPrefix + "cam.server"
  VVKG2e = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FF8ZwU(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVKG2e.append((str(len(VVKG2e) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVKG2e:
    FFf3zP(self, "No readers found !")
  else:
   FFxtzL(self, readersFile)
  return VVKG2e
 def VVjmFr(self, VVapBp, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVj2Vh, camPrefix)
  readerState  = VVapBp.VVTj1i(1)
  readerLabel  = VVapBp.VVTj1i(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCPP6E.VVxnEM(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVapBp.VVP0Av()
    FFf3zP(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVKG2e = self.VV7NeS(camPrefix)
   if VVKG2e:
    VVapBp.VVs7In(VVKG2e)
 @staticmethod
 def VVxnEM(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FF8ZwU(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFf3zP(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFf3zP(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFxtzL(SELF, confFile)
   return None
  if not iRequest:
   FFf3zP(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FFf3zP(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FFf3zP(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCoDqi(Screen):
 def __init__(self, VVfuNs, session, args=0):
  self.skin, self.skinParam = FFSDka(VVTY88, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVj2Vh, VVqOlG, VVXX9n, camCommand = FFKnms()
  if   VVfuNs == "ncam" : self.prefix = "n"
  elif VVfuNs == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VV23GK = []
  if self.prefix == "":
   VV23GK.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VV23GK.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VV23GK.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VV23GK.append(("constant.cw"         , "x_constant_cw" ))
   VV23GK.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VV23GK.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VV23GK.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VV23GK.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VV23GK.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VV23GK.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VV23GK.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VV23GK.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VV23GK.append(VV15MX)
   VV23GK.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VV23GK.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VV23GK.append(VV15MX)
   VV23GK.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VV23GK.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VV23GK.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFyutK(self, VV23GK=VV23GK)
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FFTEKh(self["myMenu"])
  FFm42V(self)
 def VVNPMZ(self):
  global VV10fA
  VV10fA = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFwdI3(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFwdI3(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFwdI3(self, self.VVj2Vh + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFwdI3(self, self.VVj2Vh + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVdNf9("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVdNf9("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVdNf9("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVdNf9("cam.provid"        )
   elif item == "x_cam_server"  : self.VVdNf9("cam.server"        )
   elif item == "x_cam_services" : self.VVdNf9("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVdNf9("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVdNf9("cam.user"        )
   elif item == "x_VVBOaW"   : pass
   elif item == "x_SoftCam_Key" : self.VVqwb5()
   elif item == "x_CCcam_cfg"  : FFwdI3(self, self.VVj2Vh + "CCcam.cfg"    )
   elif item == "x_VVBOaW"   : pass
   elif item == "x_cam_log"  : FFwdI3(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFwdI3(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFwdI3(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVdNf9(self, fileName):
  FFwdI3(self, self.VVj2Vh + self.prefix + fileName)
 def VVqwb5(self):
  path = self.VVj2Vh + "SoftCam.Key"
  if fileExists(path) : FFwdI3(self, path)
  else    : FFwdI3(self, path.replace(".Key", ".key"))
class CC0SGr(Screen):
 VVJsvb  = 0
 VVQnSE = 1
 VV6m6X = 2
 def __init__(self, session, VVj2Vh="", VVqOlG="", VVXX9n="", VVvpuH=VVJsvb):
  self.skin, self.skinParam = FFSDka(VVEzHn, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVXX9n   = VVXX9n
  self.VVvpuH  = VVvpuH
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVj2Vh + VVqOlG + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVqOlG : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVj2Vh, self.camPrefix)
  if self.VVvpuH == self.VVJsvb:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVvpuH == self.VVQnSE:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFyutK(self, self.Title, addScrollLabel=True)
  FFdk5e(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVBdG5
  self.onShown.append(self.VVSdHz)
  self.onClose.append(self.onExit)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  self["myLabel"].VVi2rz(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FF22W2(self)
  self.VVBdG5()
 def onExit(self):
  self.timer.stop()
 def VVyX1s(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVdmdc)
  except:
   self.timer.callback.append(self.VVdmdc)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FF6E92(self, "Started", 1000)
 def VVrjEY(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVdmdc)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FF6E92(self, "Stopped", 1000)
 def VVBdG5(self):
  if self.timerRunning:
   self.VVrjEY()
  else:
   self.VVyX1s()
   if self.VVvpuH == self.VVJsvb or self.VVvpuH == self.VVQnSE:
    if self.VVvpuH == self.VVJsvb : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCPP6E.VVxnEM(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFRXLV(self.VVSQ5A)
    else:
     self.close()
   else:
    self.VVsdAR()
 def VVdmdc(self):
  if self.timerRunning:
   if   self.VVvpuH == self.VVJsvb : self.VVyGaE()
   elif self.VVvpuH == self.VVQnSE : self.VVyGaE()
   else            : self.VVsdAR()
 def VVsdAR(self):
  if fileExists(self.VVXX9n):
   fTime = FFXQPO(os.path.getmtime(self.VVXX9n))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VV2Nti(), VViQnE=VVtm8Y)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVXX9n)
 def VVSQ5A(self):
  self.VVyGaE()
 def VVyGaE(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFhqic("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVd9bM))
   self.camWebIfErrorFound = True
   self.VVrjEY()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVvpuH == self.VVJsvb : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFhqic("Error while parsing data elements !\n\nError = %s" % str(e), VVf5u2)
   self.camWebIfErrorFound = True
   self.VVrjEY()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVk0l6(root)
  self["myLabel"].setText(txt, VViQnE=VVtm8Y)
  self["myBar"].setText("Last Update : %s" % FFqkDy())
 def VVk0l6(self, rootElement):
  def VVXwkx(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVvpuH == self.VVJsvb:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFhqic(status, VVUnli)
    else          : status = FFhqic(status, VVf5u2)
    txt += VVBOaW + "\n"
    txt += VVXwkx("Name"  , name)
    txt += VVXwkx("Description" , desc)
    txt += VVXwkx("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVXwkx("Protocol" , protocol)
    txt += VVXwkx("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFhqic("Yes", VVUnli)
    else    : enabTxt = FFhqic("No", VVf5u2)
    txt += VVBOaW + "\n"
    txt += VVXwkx("Label"  , label)
    txt += VVXwkx("Protocol" , protocol)
    txt += VVXwkx("Enabled" , enabTxt)
  return txt
 def VV2Nti(self):
  wordsDict = self.VVwtKG()
  color = [ VVAjxB, VVB0Mu, VVUnli, VVf5u2, VVxzLQ, VVjqbJ]
  lines = FFIx6K("tail -n %d %s" % (100, self.VVXX9n))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVd9bM + line[:19] + VVcDYh + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVX9gW + line[ndx + 3:] + VVcDYh
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVAjxB + line[ndx + 8 : ndx1 + 4] + VVcDYh + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVcDYh)
   elif line.startswith("----") or ">>" in line:
    line = FFhqic(line, VVAjxB)
   txt += line + "\n"
  return txt
 def VVwtKG(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FF8ZwU(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CC4ptf(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFSDka(VVTY88, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VV23GK = []
  VV23GK.append(("Backup Channels"    , "VV3kuZ"   ))
  VV23GK.append(("Restore Channels"    , "Restore_Channels"  ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Backup SoftCAM Files"   , "VVXFck" ))
  VV23GK.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VV23GK.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VV23GK.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Backup Network Settings"  , "VVIIr6"   ))
  VV23GK.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVHIEW:
   VV23GK.append(VV15MX)
   VV23GK.append((VVd9bM + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VVbje6"   ))
   VV23GK.append((VVUnli + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VV6U4P) , "createMyIpk"   ))
   VV23GK.append((VVUnli + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VV6U4P) , "createMyDeb"   ))
   VV23GK.append((VVxzLQ + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VV23GK.append((VVxzLQ + "Decode %s Crash Report"   % PLUGIN_NAME     , "VVmqkb" ))
  FFyutK(self, VV23GK=VV23GK)
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FFTEKh(self["myMenu"])
  FFm42V(self)
 def VVNPMZ(self):
  global VV10fA
  VV10fA = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VV3kuZ"    : self.VV3kuZ()
   elif item == "Restore_Channels"    : self.VVowv7("channels_backup*.tar.gz", self.VV1WS9)
   elif item == "VVXFck"   : self.VVXFck()
   elif item == "Restore_SoftCAM_Files"  : self.VVowv7("softcam_backup*.tar.gz", self.VVgLfL)
   elif item == "Backup_TunerDiSEqC"   : self.VVi2NO("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVowv7("tuner_backup*.backup", boundFunction(self.VVrinO, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVi2NO("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVowv7("hotkey_*backup*.backup", boundFunction(self.VVrinO, "misc"))
   elif item == "VVIIr6"    : self.VVIIr6()
   elif item == "Restore_Network"    : self.VVowv7("network_backup*.tar.gz", self.VVQ2Kn)
   elif item == "VVbje6"     : FFCKL0(self, boundFunction(FFshid, self, boundFunction(CC4ptf.VVbje6, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVwXV5(False)
   elif item == "createMyDeb"     : self.VVwXV5(True)
   elif item == "createMyTar"     : self.VVCfDn()
   elif item == "VVmqkb"   : self.VVmqkb()
 @staticmethod
 def VVbje6(SELF):
  OBF_Path = VVbN0T + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVbN0T, VVvN9W, VV6U4P)
   if err : FFf3zP(SELF, err)
   else : FF9Qkx(SELF, txt)
  else:
   FFxtzL(SELF, OBF_Path)
 def VVwXV5(self, VVPf2H):
  OBF_Path = VVbN0T + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFf3zP(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVbN0T)
  os.system("mv -f %s %s" % (VVbN0T + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVbN0T + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVbN0T + "plugin.py"))
  self.session.openWithCallback(self.VVwXV51, boundFunction(CCp1zl, path=VVbN0T, VVPf2H=VVPf2H))
 def VVwXV51(self):
  os.system("mv -f %s %s" % (VVbN0T + "OBF/main.py"  , VVbN0T))
  os.system("mv -f %s %s" % (VVbN0T + "OBF/plugin.py" , VVbN0T))
 def VVmqkb(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFf3zP(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFf3zP(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVfvDv("%s*.list" % path)
  if err:
   FFxtzL(self, path + "*.list")
   return
  srcF, err = self.VVfvDv("%s*main_final.py" % path)
  if err:
   FFxtzL(self, path + "*.final.py")
   return
  VVYDUR = []
  for f in files:
   f = os.path.basename(f)
   VVYDUR.append((f, f))
  FFdX2v(self, boundFunction(self.VVzkiA, path, codF, srcF), VV23GK=VVYDUR)
 def VVzkiA(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFxtzL(self, logF)
   else     : FFshid(self, boundFunction(self.VV1hNd, logF, codF, srcF))
 def VV1hNd(self, logF, codF, srcF):
  lst  = []
  lines = FF8ZwU(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFf3zP(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVI1yp(lst, logF, newLogF)
  totSrc  = self.VVI1yp(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FF9Qkx(self, txt)
 def VVfvDv(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVI1yp(self, lst, f1, f2):
  txt = FFp1Ek(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVCfDn(self):
  VVYDUR = []
  VVYDUR.append("%s%s" % (VVbN0T, "*.py"))
  VVYDUR.append("%s%s" % (VVbN0T, "*.png"))
  VVYDUR.append("%s%s" % (VVbN0T, "*.xml"))
  VVYDUR.append("%s"  % (VVBZq2))
  FFQFQZ(self, VVYDUR, "%s_%s" % (PLUGIN_NAME, VVvN9W), addTimeStamp=False)
 def VV3kuZ(self):
  path1 = VVF0QF
  path2 = "/etc/tuxbox/"
  VVYDUR = []
  VVYDUR.append("%s%s" % (path1, "*.tv"))
  VVYDUR.append("%s%s" % (path1, "*.radio"))
  VVYDUR.append("%s%s" % (path1, "*list"))
  VVYDUR.append("%s%s" % (path1, "lamedb*"))
  VVYDUR.append("%s%s" % (path2, "*.xml"))
  FFQFQZ(self, VVYDUR, "channels_backup", addTimeStamp=True)
 def VVXFck(self):
  VVYDUR = []
  VVYDUR.append("/etc/tuxbox/config/")
  VVYDUR.append("/usr/keys/")
  VVYDUR.append("/usr/scam/")
  VVYDUR.append("/etc/CCcam.cfg")
  FFQFQZ(self, VVYDUR, "softcam_backup", addTimeStamp=True)
 def VVIIr6(self):
  VVYDUR = []
  VVYDUR.append("/etc/hostname")
  VVYDUR.append("/etc/default_gw")
  VVYDUR.append("/etc/resolv.conf")
  VVYDUR.append("/etc/wpa_supplicant*.conf")
  VVYDUR.append("/etc/network/interfaces")
  VVYDUR.append("/etc/enigma2/nameserversdns.conf")
  FFQFQZ(self, VVYDUR, "network_backup", addTimeStamp=True)
 def VV1WS9(self, fileName=None):
  if fileName:
   FFCKL0(self, boundFunction(self.VV5xap, fileName), "Overwrite current channels ?")
 def VV5xap(self, fileName):
  path = "%s%s" % (VVXukQ, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCLPQZ.VVvMdL()
   lamedb5File, diabled5File = CCLPQZ.VVtBe0()
   cmd = ""
   cmd += FFrWND("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFrWND("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFVeqY()
   if res == 0 : FFTVfn(self, "Channels Restored.")
   else  : FFf3zP(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFxtzL(self, path)
 def VVgLfL(self, fileName=None):
  if fileName:
   FFCKL0(self, boundFunction(self.VV0ozR, fileName), "Overwrite SoftCAM files ?")
 def VV0ozR(self, fileName):
  fileName = "%s%s" % (VVXukQ, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVBOaW
   note = "You may need to restart your SoftCAM."
   FFP4rI(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FF7UqE(note, VVAjxB), sep))
  else:
   FFxtzL(self, fileName)
 def VVQ2Kn(self, fileName=None):
  if fileName:
   FFCKL0(self, boundFunction(self.VVt4k2, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVt4k2(self, fileName):
  fileName = "%s%s" % (VVXukQ, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFmkwf(self,  cmd)
  else:
   FFxtzL(self, fileName)
 def VVowv7(self, pattern, callBackFunction, isTuner=False):
  title = FFlC9C()
  if pathExists(VVXukQ):
   myFiles = iGlob("%s%s" % (VVXukQ, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVYDUR = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVYDUR.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVwqMz = ("Sat. List", self.VVDdrm)
    else  : VVwqMz = None
    VVrMQs = ("Delete File", self.VVUaxB)
    FFdX2v(self, callBackFunction, title=title, VV23GK=VVYDUR, VVwqMz=VVwqMz, VVrMQs=VVrMQs)
   else:
    FFf3zP(self, "No files found in:\n\n%s" % VVXukQ, title)
  else:
   FFf3zP(self, "Path not found:\n\n%s" % VVXukQ, title)
 def VVUaxB(self, VVoYT0Obj, path):
  FFCKL0(self, boundFunction(self.VVE0xJ, VVoYT0Obj, path), "Delete this file ?\n\n%s" % path)
 def VVE0xJ(self, VVoYT0Obj, path):
  path = VVXukQ + path
  os.system(FFrWND("rm -f '%s'" % path))
  if fileExists(path) : FF6E92(VVoYT0Obj, "Not deleted", 1000)
  else    : VVoYT0Obj.VV7n8k()
 def VVi2NO(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCPLjr()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VVn7qd, filePrefix))
 def VVn7qd(self, filePrefix, result, retval):
  title = FFlC9C()
  if pathExists(VVXukQ):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFf3zP(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVXukQ, filePrefix, FF4Auk())
    try:
     VVYDUR = str(result.strip()).split()
     if VVYDUR:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVYDUR:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVBOaW, FFhqic(fName, VVAjxB), VVBOaW)
       FF9Qkx(self, txt, title=title, VViQnE=VVtm8Y)
      else:
       FFf3zP(self, "File creation failed!", title)
     else:
      FFf3zP(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFrWND("rm %s" % fName))
     FFf3zP(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFrWND("rm %s" % fName))
     FFf3zP(self, "Error while writing file.")
  else:
   FFf3zP(self, "Path not found:\n\n%s" % VVXukQ, title)
 def VVrinO(self, mode, path=None):
  if path:
   path = "%s%s" % (VVXukQ, path)
   if fileExists(path):
    lines = FF8ZwU(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFCKL0(self, boundFunction(self.VVczsK, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FF8yum(self, path, title=FFlC9C())
   else:
    FFxtzL(self, path)
 def VVczsK(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVSgRh = []
  VVSgRh.append("echo -e 'Reading current settings ...'")
  VVSgRh.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVSgRh.append("echo -e 'Preparing new settings ...'")
  VVSgRh.append(settingsLines)
  VVSgRh.append("echo -e 'Applying new settings ...'")
  VVSgRh.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFCEYQ(self, VVSgRh)
 def VVDdrm(self, VVoYT0Obj, path):
  if not path:
   return
  path = VVXukQ + path
  if not fileExists(path):
   FFxtzL(self, path)
   return
  txt = FFp1Ek(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVYDUR  = []
   for item in satList:
    VVYDUR.append("%s\t%s" % (item[0], FFjHtS(item[1])))
   FF9Qkx(self, VVYDUR, title="  Satellites List")
  else:
   FFf3zP(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CC2WA3(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFSDka(VVTY88, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VV23GK = []
  VV23GK.append(("Plugins Browser List"       , "VV8zjW"   ))
  VV23GK.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VV23GK.append(("Startup Plugins"        , "pluginsStartup"    ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VV23GK.append(("Remove Packages (show all)"     , "VVuHUCsAll"   ))
  VV23GK.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Update List of Available Packages"   , "VVnTY0"   ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Packaging Tool"        , "VVMdMv"    ))
  VV23GK.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFyutK(self, VV23GK=VV23GK)
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FFTEKh(self["myMenu"])
  FFm42V(self)
 def VVNPMZ(self):
  global VV10fA
  VV10fA = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VV8zjW"   : self.VV8zjW()
   elif item == "pluginsMenus"     : self.VV4Tbr(0)
   elif item == "pluginsStartup"    : self.VV4Tbr(1)
   elif item == "pluginsDirList"    : self.VVJGe0()
   elif item == "downloadInstallPackages"  : FFshid(self, boundFunction(self.VVNpYf, 0, ""))
   elif item == "VVuHUCsAll"   : FFshid(self, boundFunction(self.VVNpYf, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFshid(self, boundFunction(self.VVNpYf, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVnTY0"   : self.VVnTY0()
   elif item == "VVMdMv"    : self.VVMdMv()
   elif item == "packagesFeeds"    : self.VVjrjJ()
   else          : self.close()
 def VVJGe0(self):
  extDirs  = FFggiK(VVGWw1)
  sysDirs  = FFggiK(VVIJZ6)
  VVYDUR  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVYDUR.append((item, VVGWw1 + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVYDUR.append((item, VVIJZ6 + item))
  if VVYDUR:
   VVYDUR = sorted(VVYDUR, key=lambda x: x[0].lower())
   VVKCEj = ("Package Info.", self.VVZXH8, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFMNGj(self, None, header=header, VVYDUR=VVYDUR, VV5EM1=widths, VVzOAn=28, VVKCEj=VVKCEj)
  else:
   FFf3zP(self, "Nothing found!")
 def VVZXH8(self, VVapBp, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVGWw1) : loc = "extensions"
  elif path.startswith(VVIJZ6) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VV4ksy(package)
  else:
   FFf3zP(self, "No info!")
 def VVjrjJ(self):
  pkg = FFqGXf()
  if pkg : FFpzYC(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFywk7(self)
 def VV8zjW(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVXwkx(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVBOaW + "\n"
    txt += VVXwkx("Number"   , str(c))
    txt += VVXwkx("Name"   , FFhqic(str(p.name), VVAjxB))
    txt += VVXwkx("Path"  , p.path  )
    txt += VVXwkx("Description" , p.description )
    txt += VVXwkx("Icon"  , p.iconstr  )
    txt += VVXwkx("Wakeup Fnc" , p.wakeupfnc )
    txt += VVXwkx("NeedsRestart", p.needsRestart)
    txt += VVXwkx("Internal" , p.internal )
    txt += VVXwkx("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FF9Qkx(self, txt)
 def VV4Tbr(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVYDUR = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVYDUR.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVYDUR:
   VVYDUR.sort(key=lambda x: x[0].lower())
   header  = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths  = (19  , 25 , 20  , 27   , 9  )
   FFMNGj(self, None, title=title, header=header, VVYDUR=VVYDUR, VV5EM1=widths, VVzOAn=26)
  else:
   FFf3zP(self, "Nothing Found", title=title)
 def VVnTY0(self):
  cmd = FF6WlR(VVqLEj, "")
  if cmd : FFmkwf(self, cmd, checkNetAccess=True)
  else : FFywk7(self)
 def VVMdMv(self):
  pkg = FFqGXf()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFTVfn(self, txt)
 def VVNpYf(self, mode, grep, VVapBp=None, title=""):
  if   mode == 0: cmd = FF6WlR(VVpYaJ    , grep)
  elif mode == 1: cmd = FF6WlR(VVPYPU , grep)
  elif mode == 2: cmd = FF6WlR(VVPYPU , grep)
  if not cmd:
   FFywk7(self)
   return
  VVKG2e = FFIx6K(cmd)
  if not VVKG2e:
   if VVapBp: VVapBp.VVP0Av()
   FFf3zP(self, "No packages found!")
   return
  elif len(VVKG2e) == 1 and VVKG2e[0] == VVVrHS:
   FFf3zP(self, VVVrHS)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVYDUR  = []
  for item in VVKG2e:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVYDUR.append((name, package, version))
  if mode > 0:
   extensions = FFIx6K("ls %s -l | grep '^d' | awk '{print $9}'" % VVGWw1)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVYDUR:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVYDUR.append((name, VVGWw1 + item, "-"))
   systemPlugins = FFIx6K("ls %s -l | grep '^d' | awk '{print $9}'" % VVIJZ6)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVYDUR:
      if item.lower() == row[0].lower():
       break
     else:
      VVYDUR.append((item, VVIJZ6 + item, "-"))
  if not VVYDUR:
   FFf3zP(self, "No packages found!")
   return
  if VVapBp:
   VVYDUR.sort(key=lambda x: x[0].lower())
   VVapBp.VVs7In(VVYDUR, title)
  else:
   widths = (20, 50, 30)
   VVtony = None
   VVwFPr = None
   if mode == 0:
    VVCAcJ = ("Install" , self.VVYQAK   , [])
    VVtony = ("Download" , self.VVax5C   , [])
    VVwFPr = ("Filter"  , self.VVyqPL , [])
   elif mode == 1:
    VVCAcJ = ("Uninstall", self.VVuHUC, [])
   elif mode == 2:
    VVCAcJ = ("Uninstall", self.VVuHUC, [])
    widths= (18, 57, 25)
   VVYDUR = sorted(VVYDUR, key=lambda x: x[0].lower())
   VVKCEj = ("Package Info.", self.VVCXsV, [])
   header   = ("Name" ,"Package" , "Version" )
   FFMNGj(self, None, header=header, VVYDUR=VVYDUR, VV5EM1=widths, VVzOAn=28, VVCAcJ=VVCAcJ, VVtony=VVtony, VVKCEj=VVKCEj, VVwFPr=VVwFPr, VV4Isj=self.lastSelectedRow
     , VVRbex="#22110011", VVihVe="#22191111", VVwsQj="#22191111", VVzAxe="#00003030", VVrSmG="#00333333")
 def VVCXsV(self, VVapBp, title, txt, colList):
  package = colList[1]
  self.VV4ksy(package)
 def VVyqPL(self, VVapBp, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VV23GK = []
  VV23GK.append(("All Packages", "all"))
  VV23GK.append(VV15MX)
  VV23GK.append(("Plugin/SoftCAM/Skin", "plugins"))
  VV23GK.append(VV15MX)
  for word in words:
   VV23GK.append((word, word))
  FFdX2v(self, boundFunction(self.VVmIZ2, VVapBp), VV23GK=VV23GK, title="Select Filter")
 def VVmIZ2(self, VVapBp, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFshid(VVapBp, boundFunction(self.VVNpYf, 0, grep, VVapBp, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVuHUC(self, VVapBp, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVGWw1, VVIJZ6)):
   FFCKL0(self, boundFunction(self.VVYnKI, VVapBp, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VV23GK = []
   VV23GK.append(("Remove Package"         , "remove_ExistingPackage" ))
   VV23GK.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VV23GK.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFdX2v(self, boundFunction(self.VVEQFT, VVapBp, package), VV23GK=VV23GK)
 def VVYnKI(self, VVapBp, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVvn2k)
  FFmkwf(self, cmd, VVHD9V=boundFunction(self.VVo9TQ, VVapBp))
 def VVEQFT(self, VVapBp, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVYc7m
   elif item == "remove_ForceRemove"  : cmdOpt = VV5RQp
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVNmfE
   FFCKL0(self, boundFunction(self.VVpPRG, VVapBp, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVpPRG(self, VVapBp, package, cmdOpt):
  self.lastSelectedRow = VVapBp.VVcTYx()
  cmd = FFHppj(cmdOpt, package)
  if cmd : FFmkwf(self, cmd, VVHD9V=boundFunction(self.VVo9TQ, VVapBp))
  else : FFywk7(self)
 def VVo9TQ(self, VVapBp):
  VVapBp.cancel()
  FFtnUh()
 def VVYQAK(self, VVapBp, title, txt, colList):
  package  = colList[1]
  VV23GK = []
  VV23GK.append(("Install Package"         , "install_CheckVersion" ))
  VV23GK.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VV23GK.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VV23GK.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VV23GK.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFdX2v(self, boundFunction(self.VVjIyn, package), VV23GK=VV23GK)
 def VVjIyn(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VV5wtI
   elif item == "install_ForceReinstall" : cmdOpt = VVqCt4
   elif item == "install_ForceOverwrite" : cmdOpt = VViGNM
   elif item == "install_ForceDowngrade" : cmdOpt = VVNwcc
   elif item == "install_IgnoreDepends" : cmdOpt = VVHGsQ
   FFCKL0(self, boundFunction(self.VVlTm3, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVlTm3(self, package, cmdOpt):
  cmd = FFHppj(cmdOpt, package)
  if cmd : FFmkwf(self, cmd, VVHD9V=FFtnUh, checkNetAccess=True)
  else : FFywk7(self)
 def VVax5C(self, VVapBp, title, txt, colList):
  package  = colList[1]
  FFCKL0(self, boundFunction(self.VVSI5p, package), "Download Package ?\n\n%s" % package)
 def VVSI5p(self, package):
  if FFkdJ5():
   cmd = FFHppj(VVeFMm, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FF7UqE(success, VVUnli))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FF7UqE(fail, VVf5u2))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFmkwf(self, cmd, VVutPQ=[VVf5u2, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFywk7(self)
  else:
   FFf3zP(self, "No internet connection !")
 def VV4ksy(self, package):
  infoCmd  = FFHppj(VVmFmC, package)
  filesCmd = FFHppj(VVHtxt, package)
  listInstCmd = FF6WlR(VVPYPU, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFtiGW(VVAjxB)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FF7UqE(notInst, VVd9bM))
   cmd += "else "
   cmd +=   FFpdcU("System Info", VVAjxB)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFpdcU("Related Files", VVAjxB)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFeXoK(self, cmd)
  else:
   FFywk7(self)
class CCLPQZ(Screen):
 VVSTvL  = 0
 VVxgo9 = 1
 VV2gXL  = 2
 VV8VOA  = 3
 VVgQnd = 4
 VVpDpg = 5
 VVNQUb = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFSDka(VVTY88, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVvijk = None
  self.lastfilterUsed  = None
  VV23GK = self.VV9YyB()
  FFyutK(self, VV23GK=VV23GK, title="Services/Channels")
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self["myMenu"].setList(self.VV9YyB())
  FFTEKh(self["myMenu"])
  FFm42V(self)
 def VV9YyB(self):
  VV23GK = []
  VV23GK.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VV23GK.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Services (Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VV23GK.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VV23GK.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VV23GK.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VV23GK.append(("Services with PIcons for the System"  , "VVjjMI"     ))
  VV23GK.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VV23GK.append(VV15MX)
  lamedbFile, disabledFile = CCLPQZ.VVvMdL()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VV23GK.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VV23GK.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VV23GK.append(("Reset Parental Control Settings"   , "VVqsc1"    ))
  VV23GK.append(("Delete Channels with no names"   , "VVtVh7"    ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Reload Channels and Bouquets"    , "VVpEqQ"      ))
  return VV23GK
 def VVNPMZ(self):
  global VV10fA
  VV10fA = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFezN6(self)
   elif item == "currentServiceInfo"     : FFMw5O(self, fncMode=CCkvvO.VVaJZ6)
   elif item == "TranspondersStats"     : FFshid(self, self.VViYl4     )
   elif item == "lameDB_allChannels_with_refCode"  : FFshid(self, self.VVDn19 )
   elif item == "lameDB_allChannels_with_tranaponder" : FFshid(self, self.VV0RVd)
   elif item == "lameDB_allChannels_with_details"  : FFshid(self, self.VVsaXA )
   elif item == "parentalControlChannels"    : FFshid(self, self.VV2DuN   )
   elif item == "showHiddenChannels"     : FFshid(self, self.VVrI1t     )
   elif item == "VVjjMI"     : FFshid(self, self.VVaLHn     )
   elif item == "servicesWithMissingPIcons"   : FFshid(self, self.VVN8NE   )
   elif item == "enableHiddenChannels"     : self.VVhWDk(True)
   elif item == "disableHiddenChannels"    : self.VVhWDk(False)
   elif item == "VVqsc1"    : FFCKL0(self, self.VVqsc1, "Reset and Restart ?" )
   elif item == "VVtVh7"    : FFshid(self, self.VVtVh7)
   elif item == "VVpEqQ"      : FFshid(self, boundFunction(CCLPQZ.VVpEqQ, self))
   else            : self.close()
 @staticmethod
 def VVpEqQ(SELF):
  FFVeqY()
  FFTVfn(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVDn19(self):
  self.VVvijk = None
  self.lastfilterUsed  = None
  self.filterObj   = CClJqP(self)
  VVKG2e = CCLPQZ.VVlZYk(self, self.VVSTvL)
  if VVKG2e:
   VVKG2e.sort(key=lambda x: x[0].lower())
   VVBmAn  = ("Zap"   , self.VVrBDw     , [])
   VVscS4 = (""    , self.VVYeW2   , [])
   VVKCEj = ("Options"  , self.VVdntv , [])
   VVtony = ("Current Service", self.VVVHsg , [])
   VVwFPr = ("Filter"   , self.VVUyvA  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVbtsV  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFMNGj(self, None, header=header, VVYDUR=VVKG2e, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=26, VVBmAn=VVBmAn, VVscS4=VVscS4, VVtony=VVtony, VVKCEj=VVKCEj, VVwFPr=VVwFPr)
 def VV0RVd(self):
  self.VVvijk = None
  self.lastfilterUsed  = None
  self.filterObj   = CClJqP(self)
  VVKG2e = CCLPQZ.VVlZYk(self, self.VVxgo9)
  if VVKG2e:
   VVKG2e.sort(key=lambda x: x[0].lower())
   VVBmAn  = ("Zap"   , self.VVrBDw      , [])
   VVscS4 = (""    , self.VVYeW2    , [])
   VVtony = ("Current Service", self.VVVHsg  , [])
   VVKCEj = ("Options"  , self.VVEfXN , [])
   VVwFPr = ("Filter"   , self.VV1WeF  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVbtsV  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFMNGj(self, None, header=header, VVYDUR=VVKG2e, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=26, VVBmAn=VVBmAn, VVscS4=VVscS4, VVtony=VVtony, VVKCEj=VVKCEj, VVwFPr=VVwFPr)
 def VVdntv(self, VVapBp, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel  = CClFPA(self, VVapBp, 3)
  mSel.VVRsLA(servName, refCode, pcState, hidState)
 def VVEfXN(self, VVapBp, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CClFPA(self, VVapBp, 3)
  mSel.VV98Tl(servName, refCode)
 def VVaNuH(self, VVapBp, refCode, isAddToBlackList):
  VVapBp.VV3Sbk("Processing ...")
  FFRXLV(boundFunction(self.VVI8ge, VVapBp, [refCode], isAddToBlackList))
 def VV22xF(self, VVapBp, isAddToBlackList):
  refCodeList = VVapBp.VVNzhg(3)
  if not refCodeList:
   FFf3zP(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVapBp.VV3Sbk("Processing ...")
  FFRXLV(boundFunction(self.VVI8ge, VVapBp, refCodeList, isAddToBlackList))
 def VVI8ge(self, VVapBp, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVkenr, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVkenr):
   lines = FF8ZwU(VVkenr)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVkenr, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVapBp.VVBMjk
   if isMulti:
    self.VV6R5z(VVapBp, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVjHQh(VVapBp, refCode)
    VVapBp.VVP0Av()
  else:
   VVapBp.VV1J0Q("No changes")
 def VVxTKv(self, VVapBp, refCode, isHide):
  title = "Change Hidden State"
  if FFeWHD(refCode):
   VVapBp.VV3Sbk("Processing ...")
   ret = FFnI4b(refCode, isHide)
   if ret : FFshid(self, boundFunction(self.VVjHQh, VVapBp, refCode))
   else : FFf3zP(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFf3zP(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVjHQh(self, VVapBp, refCode):
  VVKG2e = CCLPQZ.VVlZYk(self, self.VVSTvL, VVB6Ad=[3, [refCode], False])
  done = False
  if VVKG2e:
   data = VVKG2e[0]
   if data[3] == refCode:
    done = VVapBp.VVFZW7(data)
  if not done:
   self.VVIrQ3(VVapBp, VVapBp.VVGIFi(), self.VVSTvL)
  VVapBp.VVP0Av()
 def VV6R5z(self, VVapBp, totRefCodes):
  VVKG2e = CCLPQZ.VVlZYk(self, self.VVSTvL, VVB6Ad=self.VVvijk)
  VVapBp.VVs7In(VVKG2e)
  VVapBp.VVBnQy(False)
  VVapBp.VV1J0Q("%d Processed" % totRefCodes)
 def VVPG7K(self, VVapBp, isHide):
  refCodeList = VVapBp.VVNzhg(3)
  if not refCodeList:
   FFf3zP(self, "Nothing selected", title="Change Hidden State")
   return
  VVapBp.VV3Sbk("Processing ...")
  FFRXLV(boundFunction(self.VV7Iu7, VVapBp, refCodeList, isHide))
 def VV7Iu7(self, VVapBp, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFnI4b(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   db = eDVBDB.getInstance()
   if db:
    db.saveServicelist()
    db.reloadServicelist()
    db.reloadBouquets()
   self.VV6R5z(VVapBp, len(refCodeList))
  else:
   VVapBp.VV1J0Q("No changes")
 def VVUyvA(self, VVapBp, title, txt, colList):
  self.filterObj.VVepCf(1, VVapBp, 2, boundFunction(self.VVJEad, VVapBp))
 def VVJEad(self, VVapBp, item):
  self.VVk3EP(VVapBp, item, 2, self.VVSTvL)
 def VV1WeF(self, VVapBp, title, txt, colList):
  self.filterObj.VVepCf(2, VVapBp, 4, boundFunction(self.VV0RKl, VVapBp))
 def VV0RKl(self, VVapBp, item):
  self.VVk3EP(VVapBp, item, 4, self.VVxgo9)
 def VV2Ny3(self, VVapBp, title, txt, colList):
  self.filterObj.VVepCf(0, VVapBp, 4, boundFunction(self.VVxCpr, VVapBp))
 def VVxCpr(self, VVapBp, item):
  self.VVk3EP(VVapBp, item, 4, self.VV2gXL)
 def VVk3EP(self, VVapBp, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVapBp.VVTj1i(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVvijk = None
  else:
   words, asPrefix = CClJqP.VVFtXI(words)
   self.VVvijk = [col, words, asPrefix]
  if words: FFshid(self, boundFunction(self.VVIrQ3, VVapBp, title, mode), title="Reading Services ...")
  else : FF6E92(VVapBp, "Incorrect filter", 2000)
 def VVIrQ3(self, VVapBp, title, mode):
  VVKG2e = CCLPQZ.VVlZYk(self, mode, VVB6Ad=self.VVvijk, VVCkoG=False)
  if VVKG2e:
   VVKG2e.sort(key=lambda x: x[0].lower())
   VVapBp.VVs7In(VVKG2e, title)
  else:
   VVapBp.VVP0Av()
   FF6E92(VVapBp, "Not found!", 1500)
 def VVP6Ay(self, VVYDUR, VVBmAn=None, VVscS4=None, VVCAcJ=None, VVtony=None, VVKCEj=None, VVwFPr=None):
  VVtony = ("Current Service", self.VVVHsg, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVbtsV = (LEFT  , LEFT  , CENTER, LEFT    )
  FFMNGj(self, None, header=header, VVYDUR=VVYDUR, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=26, VVBmAn=VVBmAn, VVscS4=VVscS4, VVCAcJ=VVCAcJ, VVtony=VVtony, VVKCEj=VVKCEj, VVwFPr=VVwFPr)
 def VVVHsg(self, VVapBp, title, txt, colList):
  self.VVIWeg(VVapBp)
 def VVHJVI(self, VVapBp, title, txt, colList):
  self.VVIWeg(VVapBp, True)
 def VVIWeg(self, VVapBp, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVapBp.VVaB7A(colDict, VVHov8=True)
   else:
    VVapBp.VVdBnG(3, refCode, True)
   return
  FFf3zP(self, "Colud not read current Reference Code !")
 def VVsaXA(self):
  self.VVvijk = None
  self.lastfilterUsed  = None
  self.filterObj   = CClJqP(self)
  VVKG2e = CCLPQZ.VVlZYk(self, self.VV2gXL)
  if VVKG2e:
   VVKG2e.sort(key=lambda x: x[0].lower())
   VVscS4 = (""    , self.VVsUT6 , []      )
   VVtony = ("Current Service", self.VVHJVI  , []      )
   VVwFPr = ("Filter"   , self.VV2Ny3   , [], "Loading Filters ..." )
   VVBmAn  = ("Zap"   , self.VVIigG      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVbtsV  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFMNGj(self, None, header=header, VVYDUR=VVKG2e, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=26, VVBmAn=VVBmAn, VVscS4=VVscS4, VVtony=VVtony, VVwFPr=VVwFPr)
 def VVsUT6(self, VVapBp, title, txt, colList):
  refCode  = self.VVd5PU(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFMw5O(self, fncMode=CCkvvO.VV8f1T, refCode=refCode, chName=chName, text=txt)
 def VVIigG(self, VVapBp, title, txt, colList):
  refCode = self.VVd5PU(colList)
  FFjNnf(self, refCode)
 def VVrBDw(self, VVapBp, title, txt, colList):
  FFjNnf(self, colList[3])
 def VVd5PU(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVlZYk(SELF, mode, VVB6Ad=None, VVCkoG=True, VVRxi8=True):
  lamedbFile, disabledFile = CCLPQZ.VVvMdL()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVB6Ad:
    filterCol = VVB6Ad[0]
    filterWords = VVB6Ad[1]
    asPrefix = VVB6Ad[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCLPQZ.VVSTvL:
    blackList = None
    if fileExists(VVkenr):
     blackList = FF8ZwU(VVkenr)
     if blackList:
      blackList = set(blackList)
   elif mode == CCLPQZ.VVxgo9:
    tp = CCqMXo()
   VVkKMa, VVIZdu = FFCiCm()
   tagFound  = False
   if mode in (CCLPQZ.VVpDpg, CCLPQZ.VVNQUb):
    VVKG2e = {}
   else:
    VVKG2e = []
   with ioOpen(lamedbFile, "r", encoding="utf-8") as f:
    lines = []
    for line in f:
     line = str(line).strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FF3j6k(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CCLPQZ.VV2gXL:
        if sTypeInt in VVkKMa:
         STYPE = VVIZdu[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVKG2e.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVKG2e.append(tRow)
        else:
         VVKG2e.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCLPQZ.VVpDpg:
         VVKG2e[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCLPQZ.VVNQUb:
         VVKG2e[chName] = refCode
        elif mode == CCLPQZ.VVSTvL:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVKG2e.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVKG2e.append(tRow)
         else:
          VVKG2e.append(tRow)
        elif mode == CCLPQZ.VVxgo9:
         if sTypeInt in VVkKMa:
          STYPE = VVIZdu[sTypeInt]
         freq, pol, fec, sr, syst = tp.VVlM9z(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVKG2e.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVKG2e.append(tRow)
         else:
          VVKG2e.append(tRow)
        elif mode == CCLPQZ.VV8VOA:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VVKG2e.append((chName, chProv, sat, refCode))
        elif mode == CCLPQZ.VVgQnd:
         VVKG2e.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VVKG2e and VVCkoG:
    FFf3zP(SELF, "No services found!")
   return VVKG2e
  else:
   if VVRxi8:
    FFxtzL(SELF, lamedbFile)
   return None
 def VV2DuN(self):
  if fileExists(VVkenr):
   lines = FF8ZwU(VVkenr)
   if lines:
    newRows  = []
    VVKG2e = CCLPQZ.VVlZYk(self, self.VVgQnd)
    if VVKG2e:
     lines = set(lines)
     for item in VVKG2e:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVKG2e = newRows
      VVKG2e.sort(key=lambda x: x[0].lower())
      VVscS4 = ("", self.VVYeW2, [])
      VVBmAn = ("Zap", self.VVrBDw, [])
      self.VVP6Ay(VVYDUR=VVKG2e, VVBmAn=VVBmAn, VVscS4=VVscS4)
     else:
      FF9Qkx(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVKG2e)))
   else:
    FFTVfn(self, "No active Parental Control services.", FFlC9C())
  else:
   FFxtzL(self, VVkenr)
 def VVrI1t(self):
  VVKG2e = CCLPQZ.VVlZYk(self, self.VV8VOA)
  if VVKG2e:
   VVKG2e.sort(key=lambda x: x[0].lower())
   VVscS4 = ("" , self.VVYeW2, [])
   VVBmAn  = ("Zap", self.VVrBDw, [])
   self.VVP6Ay(VVYDUR=VVKG2e, VVBmAn=VVBmAn, VVscS4=VVscS4)
  else:
   FFTVfn(self, "No hidden services.", FFlC9C())
 def VViYl4(self):
  totT, totC, totA, totS, totS2, satList = self.VVf5Yw()
  txt = FFhqic("Total Transponders:\n\n", VVxzLQ)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFhqic("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVxzLQ)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFWw3B(item), satList.count(item))
  FF9Qkx(self, txt)
 def VVf5Yw(self):
  lamedbFile, disabledFile = CCLPQZ.VVvMdL()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with ioOpen(lamedbFile, "r", encoding="utf-8") as f:
    lines = []
    for line in f:
     line = str(line).strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFxtzL(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VVaLHn(self)   : self.VVjjMI(True)
 def VVN8NE(self) : self.VVjjMI(False)
 def VVjjMI(self, isWithPIcons):
  piconsPath = CCkYaA.VVN8ry()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCkYaA.VVDH7b(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVKG2e = CCLPQZ.VVlZYk(self, self.VVgQnd)
    if VVKG2e:
     channels = []
     for (chName, chProv, sat, refCode) in VVKG2e:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFfFnU(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVKG2e)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVXwkx(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVXwkx("PIcons Path"  , piconsPath)
     txt += VVXwkx("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVXwkx("Total services" , totalServices)
     txt += VVXwkx("With PIcons"  , totalWithPIcons)
     txt += VVXwkx("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FF9Qkx(self, txt)
     else:
      VVscS4     = (""      , self.VVYeW2 , [])
      if isWithPIcons : VVwFPr = ("Export Current PIcon", self.VV1aFi  , [])
      else   : VVwFPr = None
      VVKCEj     = ("Statistics", FF9Qkx, [txt])
      VVBmAn      = ("Zap", self.VVrBDw, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVP6Ay(VVYDUR=channels, VVBmAn=VVBmAn, VVscS4=VVscS4, VVKCEj=VVKCEj, VVwFPr=VVwFPr)
   else:
    FFf3zP(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFf3zP(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVYeW2(self, VVapBp, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFMw5O(self, fncMode=CCkvvO.VV8f1T, refCode=refCode, chName=chName, text=txt)
 def VV1aFi(self, VVapBp, title, txt, colList):
  png, path = CCkYaA.VVGhjU(colList[3], colList[0])
  if path:
   CCkYaA.VVzRzt(self, png, path)
 @staticmethod
 def VVvMdL():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVtBe0():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVhWDk(self, isEnable):
  lamedbFile, disabledFile = CCLPQZ.VVvMdL()
  if isEnable and not fileExists(disabledFile):
   FFTVfn(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FFf3zP(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFCKL0(self, boundFunction(self.VVq3Ox, isEnable), "%s Hidden Channels ?" % word)
 def VVq3Ox(self, isEnable):
  lamedbFile , disabledFile = CCLPQZ.VVvMdL()
  lamedb5File, diabled5File = CCLPQZ.VVtBe0()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FFVeqY()
  if res == 0 : FFTVfn(self, "Hidden List %s" % word)
  else  : FFf3zP(self, "Error while restoring:\n\n%s" % fileName)
 def VVqsc1(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFCEYQ(self, cmd)
 def VVtVh7(self):
  lamedbFile, disabledFile = CCLPQZ.VVvMdL()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFrWND("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FF8ZwU(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFrWND("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FFVeqY()
   FF9Qkx(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFxtzL(self, lamedbFile)
class CCkvvO(Screen):
 VVaJZ6  = 0
 VVHKIX   = 1
 VVJhTr   = 2
 VV8f1T    = 3
 VVwSAD    = 4
 VVbkFd   = 5
 VVlsQk   = 6
 VV5gZz    = 7
 VVU1OD   = 8
 VVQ7Sa   = 9
 VV7xzX   = 10
 VVDlAk   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFSDka(VVEzHn, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVaJZ6)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFhqic("%s\n", VVf4dJ) % VVBOaW
  FFyutK(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVT4Gi })
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  self["myLabel"].VVi2rz(textOutFile="chann_info")
  if   self.fncMode == self.VVaJZ6 : fnc = self.VVge46_VVaJZ6
  elif self.fncMode == self.VVHKIX  : fnc = self.VVge46_VVaJZ6
  elif self.fncMode == self.VVJhTr  : fnc = self.VVge46_VVaJZ6
  elif self.fncMode == self.VV8f1T  : fnc = self.VVge46_VV8f1T
  elif self.fncMode == self.VVwSAD  : fnc = self.VVge46_VVwSAD
  elif self.fncMode == self.VVbkFd  : fnc = self.VVge46_VVbkFd
  elif self.fncMode == self.VVlsQk  : fnc = self.VVge46_VVlsQk
  elif self.fncMode == self.VV5gZz  : fnc = self.VVge46_VV5gZz
  elif self.fncMode == self.VVU1OD  : fnc = self.VVge46_VVU1OD
  elif self.fncMode == self.VVQ7Sa : fnc = self.VVge46_VVQ7Sa
  elif self.fncMode == self.VV7xzX  : fnc = self.VVge46_VV7xzX
  elif self.fncMode == self.VVDlAk : fnc = self.VVge46_VVDlAk
  self["myLabel"].setText("\n   Reading Info ...")
  FFRXLV(fnc)
 def VVesZA(self, err):
  self["myLabel"].setText(err)
  FF6nEU(self["myTitle"], "#22200000")
  FF6nEU(self["myBody"], "#22200000")
  self["myLabel"].FF6nEUColor("#22200000")
  self["myLabel"].VVXdEA()
 def VVge46_VVaJZ6(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self)
  self.refCode = refCode
  self.VVJpko(chName)
 def VVge46_VV8f1T(self):
  self.VVJpko(self.chName)
 def VVge46_VVwSAD(self):
  self.VVJpko(self.chName)
 def VVge46_VVbkFd(self):
  self.VVJpko(self.chName)
 def VVge46_VVlsQk(self):
  self.VVJpko("Picon Info")
 def VVge46_VV5gZz(self):
  self.VVJpko(self.chName)
 def VVge46_VVU1OD(self):
  self.VVJpko(self.chName)
 def VVge46_VVQ7Sa(self):
  self.VVJpko(self.chName)
 def VVge46_VV7xzX(self):
  self.chUrl = self.refCode + self.callingSELF.VVmx1v(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVJpko(self.chName)
 def VVge46_VVDlAk(self):
  self.VVJpko(self.chName)
 def VVJpko(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFgUBe(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVNQkX(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFhqic(self.VVE2h0(tUrl), VVcDYh)
  if not self.epg:
   epg = self.VVRCJw(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVVk9S(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCkYaA.VVGhjU(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVVk9S(path)
  self.VV9WvL()
  self.VVEK18()
  self["myLabel"].setText(self.text, VViQnE=VVFRw7)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVXdEA(minHeight=minH)
 def VVEK18(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFzYwA(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVIFsN(FFIl0q(url))
  if epg:
   self.text += "\n" + FFJKjn("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VV9WvL()
 def VV9WvL(self):
  if not self.piconShown and self.picUrl:
   path, err = FF2QcO(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVVk9S(path)
    if self.piconShown and self.refCode:
     self.VVRT73(path, self.refCode)
 def VVRT73(self, path, refCode):
  if path and fileExists(path) and os.system(FFrWND("which ffmpeg")) == 0:
   pPath = CCkYaA.VVN8ry()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
    cmd += FFrWND("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVVk9S(self, path):
  if path and fileExists(path):
   err, w, h = self.VVGHBF(path)
   if not err:
    if h > w:
     self.VVhWdk(self["myPicF"], w, h, True)
     self.VVhWdk(self["myPic"] , w, h, False)
   allOK = FFRJ4c(self["myPic"], path)
   if allOK:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVhWdk(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVGHBF(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFjgvE(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVNQkX(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFhqic(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVXwkx(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFhqic(state, VVd9bM)
   txt += "State\t: %s\n" % state
  w = FF7eDN(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FF7eDN(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVyx4P(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVXwkx(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVXwkx(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVXwkx(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVmxVk()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VV22pr()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCkvvO.VV4GNS(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFhqic("IPTV", VVxzLQ)
   txt += self.VVTbSJ(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVXtzR(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCqMXo()
    tpTxt, namespace = tp.VVK0cj(refCode)
    del tp
    if tpTxt:
     txt += FFhqic("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFhqic("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVXwkx(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVXwkx(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVXwkx(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVXwkx(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVXwkx(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVXwkx(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVXwkx(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVXwkx(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVXwkx(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVyx4P(info):
  if info:
   aspect = FF7eDN(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVXwkx(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FF7eDN(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVJQtu(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVJQtu(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVmxVk(self):
  try:
   service = self.session.nav.getCurrentService()
   audio = service and service.audioTracks()
   return audio and audio.getNumberOfTracks() or 0
  except:
   pass
  return -1
 def VV22pr(self):
  try:
   service   = self.session.nav.getCurrentService()
   subtitle  = service and service.subtitle()
   subtitlelist = subtitle and subtitle.getSubtitleList()
   return len(subtitlelist)
  except:
   pass
  return -1
 def VVXtzR(self, refCode, iptvRef, chName):
  refCode = FFdrTi(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFp1Ek(VVF0QF + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFp1Ek(VVF0QF + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VVYDUR = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVF0QF + item
   if fileExists(path):
    txt = FFp1Ek(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVYDUR.append(bName)
  txt = self.Sep
  if VVYDUR:
   if len(VVYDUR) == 1:
    txt += "%s\t: %s\n" % (FFhqic("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VVYDUR[0])
   else:
    txt += FFhqic("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VVYDUR):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVRCJw(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVq1qM(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVq1qM(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVq1qM(event, 0)
     except:
      pass
  return epg
 def VVq1qM(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName().strip()    or ""
   evTime = event.getBeginTime()      or ""
   evDur = event.getDuration()      or ""
   evShort = event.getShortDescription() .strip() or ""
   evDesc = event.getExtendedDescription().strip() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = self.VVMlY9(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FFhqic(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FFhqic(evNameTransl, COLOR_CONS_BRIGHT_YELLOW))
    if evTime           : txt += "Start Time\t: %s\n" % FFXQPO(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFXQPO(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFN2Gj(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFN2Gj(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFN2Gj(evTime - now)
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFhqic(evShort, VVVd7L)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFhqic(evDesc , VVVd7L)
    if txt:
     txt = FFhqic("\n%s\n%s Event:\n%s\n" % (VVBOaW, ("Current", "Next")[evNum], VVBOaW), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVTbSJ(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFz3ec(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CC5PGk()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVpNE0(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFhqic("URL:", VVxzLQ) + "\n%s\n" % self.VVE2h0(decodedUrl)
  else:
   txt = "\n"
   txt += FFhqic("Reference:", VVxzLQ) + "\n%s\n" % refCode
  return txt
 def VVE2h0(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVHIEW:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VVIFsN(self, decodedUrl):
  if not FFkdJ5():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCFXWw.VVdr9M(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCFXWw.VV6PIg(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVEfvo(tDict)
   elif uType == "movie" : epg, picUrl = self.VVju3N(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVEfvo(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCFXWw.VV51wI(item, "title"    , is_base64=True )
     lang    = CCFXWw.VV51wI(item, "lang"         ).upper()
     description   = CCFXWw.VV51wI(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCFXWw.VV51wI(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCFXWw.VV51wI(item, "start_timestamp"      )
     stop_timestamp  = CCFXWw.VV51wI(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCFXWw.VV51wI(item, "stop_timestamp"       )
     now_playing   = CCFXWw.VV51wI(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVX9gW, ""
      else     : color, txt = VVd9bM , "    (CURRENT EVENT)"
      epg += FFhqic("_" * 32 + "\n", VVf4dJ)
      epg += FFhqic("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFhqic(description, VVcDYh)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVE0KW(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VVju3N(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCFXWw.VV51wI(item, "movie_image" )
    genre  = CCFXWw.VV51wI(item, "genre"   ) or "-"
    plot  = CCFXWw.VV51wI(item, "plot"   ) or "-"
    cast  = CCFXWw.VV51wI(item, "cast"   ) or "-"
    rating  = CCFXWw.VV51wI(item, "rating"   ) or "-"
    director = CCFXWw.VV51wI(item, "director"  ) or "-"
    releasedate = CCFXWw.VV51wI(item, "releasedate" ) or "-"
    duration = CCFXWw.VV51wI(item, "duration"  ) or "-"
    try:
     lang = CCFXWw.VV51wI(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFhqic(cast, VVcDYh)
    epg += "Plot:\n%s"    % FFhqic(self.VVMlY9(plot), VVcDYh)
   except:
    pass
  return epg, movie_image
 def VVMlY9(self, evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = self.VV41Ca(evTxt, lang)
   return CCkvvO.VVNTbe(txt).strip() or evTxt
 @staticmethod
 def VVNTbe(txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VV41Ca(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFuUoF(txt))
   txt, err = CCFXWw.VV6PIg(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFIl0q(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVE0KW(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
 @staticmethod
 def VVSOb0(SELF):
  if not CCCqon.VVUkNu(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(SELF)
  err = url =  fSize = resumable = ""
  if FFk8k1(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CC5PGk.VVyyLa(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CC5PGk.VVg3OhHeader(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FFf3zP(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCin0f.VVPicv(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFhqic(" (M3U/M3U8 File)", VVcDYh)
    else:
     fSize = "No info. from server. Try again later."
    hResume = resp.headers.get("Accept-Ranges" , "")
    if hResume:
     if not hResume == "none": resumable = "Yes"
     else     : resumable = "No"
   except requests.Timeout as e     : err = "Connection Timeout"
   except Exception as e       : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVygRP(subj, val):
   return "%s\n%s\n\n" % (FFhqic("%s:" % subj, COLOR_CONS_BRIGHT_YELLOW), val)
  title = "File Size"
  txt  = VVygRP(title , fSize or "?")
  txt += VVygRP("Name" , chName)
  txt += VVygRP("URL" , url)
  if resumable: txt += VVygRP("Supports Download-Resume", resumable)
  if err  : txt += FFhqic("Error:\n", VVd9bM) + err
  FF9Qkx(SELF, txt, title=title)
 @staticmethod
 def VV4GNS(SELF):
  fPath, fDir, fName = CCin0f.VVi90Z(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg", "mvi"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 def VVT4Gi(self):
  if VVHIEW:
   def VVXwkx(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVXwkx(n[i], v[i])
   if "chCode" in iptvRef:
    p = CC5PGk()
    valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVpNE0(decodedUrl)
    n = ("valid", "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVXwkx(n[i], v[i])
   with open("/tmp/ajp_channel_details", "a") as f:
    f.write("%s\n%s\n" % (VVBOaW, txt))
   FF6E92(self, "Saved to:", 1000)
class CC5PGk():
 def __init__(self):
  self.VVZSl1  = ""
  self.VVUfNV   = ""
  self.VVq316  = ""
  self.portal_rand  = ""
  self.portal_moreAuth = False
  self.portal_moreAuthMsg = ""
  self.colored_user  = "#f#11ffffaa#User"
  self.colored_server  = "#f#11aaffff#Server"
 def VVY5lc(self, url, mac, VVHov8=True):
  self.VVZSl1  = ""
  self.VVUfNV   = ""
  self.VVq316  = ""
  self.portal_rand  = ""
  self.portal_moreAuth = False
  self.portal_moreAuthMsg = ""
  host = self.VVskuh(url)
  if not host:
   if VVHov8:
    self.VVHov8or("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVwKOX(mac)
  if not host:
   if VVHov8:
    self.VVHov8or("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVZSl1 = host
  self.VVUfNV  = mac
  return True
 def VVskuh(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVwKOX(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVvi19(self, VVHov8=True):
  err = blkMsg = FFTVfnTxt = ""
  try:
   token, rand, err = self.VVxmlI()
   if token:
    self.VVq316 = token
    self.portal_rand  = rand
    prof = self.VVwhnH()
    if prof:
     word = "m" + "sg"
     blkMsg = CCFXWw.VV51wI(prof["js"], "block_%s" % word)
     FFTVfnTxt = CCFXWw.VV51wI(prof["js"], word)
     if blkMsg or FFTVfnTxt:
      self.portal_moreAuth = True
      self.portal_moreAuthMsg = FFTVfnTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFTVfnTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFTVfnTxt: tErr += "\n%s" % FFTVfnTxt
  if VVHov8:
   self.VVHov8or(tErr)
  return "", "", tErr
 def VVxmlI(self):
  res, err = self.VVbQfI(self.VVZv5I())
  urlPath = "/stalker_portal"
  if "404" in err and urlPath in self.VVZSl1:
   self.VVZSl1 = self.VVZSl1.replace(urlPath, "")
   res, err = self.VVbQfI(self.VVZv5I())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCFXWw.VV51wI(tDict["js"], "token")
    rand  = CCFXWw.VV51wI(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVwhnH(self):
  res, err = self.VVbQfI(self.VVREEd())
  if not err:
   try:
    profJson = jLoads(res.text)
    return profJson
   except:
    pass
  return ""
 def VVU8Ux(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVkPlZ()
  if len(rows) < 10:
   rows = self.VVou6V()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVZSl1 ))
   rows.append(("MAC (from URL)" , self.VVUfNV ))
   rows.append(("Token"   , self.VVq316 ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VVUfNV ))
   rows.append(("2", self.colored_server, "Host" , self.VVZSl1 ))
   rows.append(("2", self.colored_server, "Token" , self.VVq316 ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVNpUT(self, isPhp=True, VVHov8=False):
  token, profile, tErr = self.VVvi19(VVHov8)
  if not token:
   return "", tErr
  m3u_Url = ""
  url = self.VVXl4o()
  res, err = self.VVbQfI(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCFXWw.VV51wI(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFuUoF(span.group(2))
     pass1 = FFuUoF(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, err
 def VVkPlZ(self):
  m3u_Url, err = self.VVNpUT()
  rows = []
  if m3u_Url:
   res, err = self.VVbQfI(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFXQPO(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFXQPO(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVou6V(self):
  token, profile, tErr = self.VVvi19()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFFbmD(val): val = FFPO3d(val.decode("UTF-8"))
     else     : val = self.VVUfNV
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFXQPO(int(parts[1]))
      if parts[2] : ends = FFXQPO(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFXQPO(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVmx1v(self, mode, chCm, epNum, epId):
  crLinkUrl = self.VVeXNV(mode, chCm, epNum, epId)
  token, profile, tErr = self.VVvi19(VVHov8=False)
  if not token:
   return ""
  res, err = self.VVbQfI(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCFXWw.VV51wI(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  return chUrl
 def VV80RC(self):
  return self.VVZSl1 + "/server/load.php?"
 def VVZv5I(self):
  return self.VV80RC() + "type=stb&action=handshake&token=&mac=%s" % self.VVUfNV
 def VVREEd(self):
  if self.portal_moreAuth:
   import hashlib
   sn    = hashlib.md5(self.VVUfNV).hexdigest().upper()[:13]
   param  = ""
   param += "&sn=%s"   % sn
   param += "&device_id=%s" % hashlib.sha256(sn).hexdigest().upper()
   param += "&device_id2=%s" % hashlib.sha256(self.VVUfNV).hexdigest().upper()
   param += "&signature=%s" % hashlib.sha256(sn + self.VVUfNV).hexdigest().upper()
   param += '&auth_second_step=1'
   param += '&hw_version=2.17-IB-00&hw_version_2=62'
   param += '&metrics={"mac":"%s","sn":"%s","type":"STB","model":"MAG250","random":"%s"}' % (self.VVUfNV, sn, self.portal_rand)
  else:
   param = ""
  return self.VV80RC() + "type=stb&action=get_profile" + param
 def VVjNu4(self, mode):
  url = self.VV80RC() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVWjhr(self, catID):
  return self.VV80RC() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVMMw8(self, mode, catID, page):
  url = self.VV80RC() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "series" : url += "category=%s" % catID
  else    : url += "genre=%s&force_ch_link_check=" % catID
  return url
 def VVgzWk(self, mode, searchName, page):
  return self.VV80RC() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VVdZ5g(self, mode, catID):
  return self.VV80RC() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVeXNV(self, mode, chCm, serCode, serId):
  url = self.VV80RC() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVXl4o(self):
  return self.VV80RC() + "type=itv&action=create_link"
 def VVWEI2(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VV17ho(catID, stID, chNum)
  query = self.VVo0aK(mode, FFYW6B(host), FFYW6B(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVo0aK(self, mode, host, mac, serCode, serId, chCm):
  query = "mode=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVpNE0(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVo0aK(mode, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFPO3d(host)
  mac   = FFPO3d(mac)
  valid = False
  if self.VVskuh(playHost) and self.VVskuh(host) and self.VVskuh(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVbQfI(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CC5PGk.VVg3OhHeader()
   if self.VVq316:
    headers["Authorization"] = "Bearer %s" % self.VVq316
   if useCookies : cookies = {"mac": self.VVUfNV, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok : return res, ""
   else  : err = "Err-%d : %s" % (res.status_code, res.reason or "Unknown")
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVL7z2(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CC5PGk.VVg3OhHeader(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVg3OhHeader():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVZFkN(host, mac, tType, action, keysList=[]):
  myPortal = CC5PGk()
  ok = myPortal.VVY5lc(host, mac)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVvi19(VVHov8=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s/server/load.php?type=%s&action=%s" % (host, tType, action)
  res, err = myPortal.VVbQfI(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVanAs(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVanAs(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVHov8or(self, err, title="Portal Browser"):
  FFf3zP(self, str(err), title=title)
 def VVTtAg(self, mode):
  if   mode in ("itv"  , CCFXWw.VVGUIN , CCFXWw.VVJMIx)  : return "Live"
  elif mode in ("vod"  , CCFXWw.VVabIB , CCFXWw.VVOtIP)  : return "VOD"
  elif mode in ("series" , CCFXWw.VVoKXD , CCFXWw.VVhKle) : return "Series"
  else                          : return "IPTV"
 def VVjPEh(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVTtAg(mode), searchName)
 def VVpl12(self, catchup=False):
  VV23GK = []
  VV23GK.append(("Live"    , "live"  ))
  VV23GK.append(("VOD"    , "vod"   ))
  VV23GK.append(("Series"   , "series"  ))
  if catchup:
   VV23GK.append(VV15MX)
   VV23GK.append(("Catchup TV" , "catchup"  ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Account Info." , "accountInfo" ))
  return VV23GK
 @staticmethod
 def VVJtiS(decodedUrl):
  m3u_Url = ""
  p = CC5PGk()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVpNE0(decodedUrl)
  if valid:
   ok = p.VVY5lc(host, mac, VVHov8=False)
   if ok:
    m3u_Url, err = p.VVNpUT(isPhp=False, VVHov8=False)
    span = iSearch(r".+ch\/(.+)_", decodedUrl, IGNORECASE)
    if span:
     m3u_Url += span.group(1)
  return m3u_Url
 @staticmethod
 def VVyyLa(decodedUrl):
  p = CC5PGk()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVpNE0(decodedUrl)
  if valid:
   ok = p.VVY5lc(host, mac, VVHov8=False)
   if ok:
    try:
     chUrl = p.VVmx1v(mode, chCm, epNum, epId)
     return FFIl0q(chUrl)
    except Exception as e:
     pass
  return ""
class CCNVFP(CC5PGk):
 def __init__(self):
  CC5PGk.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVBwLw(self, refCode, chName, decodedUrl, iptvRef):
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVpNE0(decodedUrl)
  if valid:
   if self.VVY5lc(host, mac, VVHov8=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVp7S6(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVmx1v(self.mode, self.chCm, self.epNum, self.epId)
  except:
   pass
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = self.refCode + chUrl.strip() + ":" + self.chName
  newIptvRef = self.VV9DRb(chUrl)
  if newIptvRef:
   success = self.VVHK6x(self.iptvRef, newIptvRef)
   if passedSELF:
    FFjNnf(passedSELF, newIptvRef, VVOpaL=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFjNnf(self, newIptvRef, VVOpaL=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VV9DRb(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVHK6x(self, oldCode, newCode):
  bPath = FFjqQJ()
  if bPath:
   txt = FFp1Ek(bPath)
   if oldCode in txt:
    txt = txt.replace(oldCode, newCode)
    with open(bPath, "w") as f:
     f.write(txt)
    FFVeqY()
    return True
  return False
class CCwlrn(CCNVFP):
 def __init__(self, passedSession):
  CCNVFP.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.starttime  = iTime()
  self.timer1   = eTimer()
  self.isFromEOF  = False
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVwfWK, iPlayableService.evEOF: self.VVha1D, iPlayableService.evEnd: self.VVUaIo})
  except:
   pass
 def VVwfWK(self):
  self.starttime = iTime()
 def VVha1D(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.starttime) > 2:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self.passedSession, isFromSession=True)
    if iptvRef and not FFk8k1(decodedUrl):
     span = iSearch(r"(mode=itv.+end=)", decodedUrl, IGNORECASE)
     if span:
      self.isFromEOF = True
     CCzOLp(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
 def VVUaIo(self):
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVS8JG)
  except:
   self.timer1.callback.append(self.VVS8JG)
  self.timer1.start(100, True)
 def VVS8JG(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self.passedSession, isFromSession=True)
  valid = False
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVBwLw(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CC9pOJ.VVklBc:
       self.isFromEOF = False
       self.VVp7S6(self.passedSession, isFromSession=True)
class CC0WOt():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.adultWords  = ("adult", "aduld", "sex", "porn", "xxx", "xxi", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.nameTagPatt = r"\s*[\[(|:].*[\])|:](.+)|\s*(?:[^a-z]+:)*(.+)"
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.missingUtf8 = VVgpZu and not VVPpML
 def VVBESO(self, name):
  if self.missingUtf8:
   name = str(name.encode('ascii', 'replace').decode('utf-8'))
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCFXWw.VVkInU(name):
   return CCFXWw.VVYsZt(name)
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    name = span.group(1) or span.group(2)
  return name.strip() or name
 def VVxYfv(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  span = iSearch(self.nameTagPatt, name)
  if span:
   name = span.group(1) or span.group(2)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVGUDd(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  else:
   return name.strip()
 def VVU6xg(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVkOd4(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCCqon(CC5PGk):
 def __init__(self):
  CC5PGk.__init__(self)
 def VVrbUp(self):
  if CCCqon.VVUkNu(self):
   FFshid(self, self.VVKa4S, title="Searching ...")
 def VVjjdu(self, winSession, url, mac):
  if CCCqon.VVUkNu(self):
   if self.VVY5lc(url, mac):
    FFshid(winSession, self.VVRWw2, title="Checking Server ...")
   else:
    FFf3zP(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVKa4S(self):
  path = CCFXWw.VVtugE()
  lines = FFIx6K('find %s %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % (path, FF2qZL(1)))
  if lines:
   lines.sort()
   VV23GK = []
   for line in lines:
    VV23GK.append((line, line))
   OKBtnFnc  = self.VVH9AJ
   VVrMQs = ("Delete File", self.VVegYk)
   FFdX2v(self, None, title="Select Portals File", VV23GK=VV23GK, width=1200, OKBtnFnc=OKBtnFnc, VVrMQs=VVrMQs)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFf3zP(self, 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt)
 def VVegYk(self, VVoYT0Obj, path):
  FFCKL0(self, boundFunction(self.VVdnf1, VVoYT0Obj, path), "Delete this file ?\n\n%s" % path)
 def VVdnf1(self, VVoYT0Obj, path):
  os.system(FFrWND("rm -f '%s'" % path))
  if fileExists(path) : FF6E92(VVoYT0Obj, "Not deleted", 1000)
  else    : VVoYT0Obj.VV7n8k()
 def VVH9AJ(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = CC4HXa.VVhXg3(path, self)
   if enc == -1:
    return
   self.session.open(CCoBfV, barTheme=CCoBfV.VVL4g0
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VVCDHn, path, enc)
       , VVRMfQ = boundFunction(self.VV3Iy9, menuInstance, path))
 def VVCDHn(self, path, enc, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  progBarObj.VVOeug(totLines)
  progBarObj.VVNOpf = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVzPrH(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVskuh(url)
     mac  = self.VVwKOX(mac)
     if host and mac and progBarObj:
      progBarObj.VVNOpf.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVskuh(url)
      mac  = self.VVwKOX(mac)
      if host and mac and not mac.startswith("AC") and progBarObj:
       progBarObj.VVNOpf.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VV3Iy9(self, menuInstance, path, VVHm3J, VVNOpf, threadCounter, threadTotal, threadErr):
  title = "Portals List File"
  if VVNOpf:
   VVCAcJ  = ("Home Menu", FFurHP, [])
   VVwFPr  = None #("Check & Filter" , boundFunction(self.filterPortalAuthorizedServers, path), [])
   VVKCEj = ("Edit File" , boundFunction(self.VVjWZd, path) , [])
   VVtony = ("Open as M3U", self.VVYSS3     , [])
   VVBmAn  = ("Select"  , self.VVjjdu_fromMacFiles   , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVbtsV  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVapBp = FFMNGj(self, None, title=title, header=header, VVYDUR=VVNOpf, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=26, VVBmAn=VVBmAn, VVCAcJ=VVCAcJ, VVtony=VVtony, VVKCEj=VVKCEj, VVwFPr=VVwFPr, VVRbex="#0a001122", VVihVe="#0a001122", VVwsQj="#0a001122", VVzAxe="#00004455", VVrSmG="#0a333333", VVIRVU="#11331100", VViKTA=True, searchCol=1)
   if not VVHm3J:
    FF6E92(VVapBp, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVHm3J:
    FFf3zP(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVYSS3(self, VVapBp, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  FFshid(VVapBp, boundFunction(self.VVpz3P, VVapBp, host, mac), title="Checking Server ...")
 def VVpz3P(self, VVapBp, host, mac):
  p = CC5PGk()
  m3u_Url = ""
  ok = p.VVY5lc(host, mac, VVHov8=False)
  err = ""
  if ok:
   m3u_Url, err = p.VVNpUT(VVHov8=False)
  title = "Browsing M3U Server from Portal Data"
  if m3u_Url:
   self.VVaL01(title, m3u_Url)
  else:
   FFf3zP(self, err or "No response from Server !", title=title)
 def VVjjdu_fromMacFiles(self, VVapBp, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVjjdu(VVapBp, url, mac)
 def VVjWZd(self, path, VVapBp, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCUORs(self, path, VVRMfQ=boundFunction(self.VVtCne, VVapBp), curRowNum=rowNum)
  else    : FFxtzL(self, path)
 def VVdIug(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFPO3d(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVRWw2(self):
  token, profile, tErr = self.VVvi19()
  if token:
   VV23GK  = self.VVpl12()
   OKBtnFnc = self.VV597U
   VVp90K = ("Home Menu", FFurHP)
   VVvFvy = ("Bookmark Server", boundFunction(CCFXWw.VVIwFK, self, True, self.VVZSl1 + "\t" + self.VVUfNV))
   authMore = ".." if self.portal_moreAuth else ""
   FFdX2v(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVUfNV, authMore), VV23GK=VV23GK, OKBtnFnc=OKBtnFnc, VVp90K=VVp90K, VVvFvy=VVvFvy)
 def VV597U(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFshid(menuInstance, boundFunction(self.VVv3gy, mode), title="Reading Categories ...")
   else : FFshid(menuInstance, boundFunction(self.VVxzvx, menuInstance, title), title="Reading Account ...")
 def VVxzvx(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVU8Ux(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVUfNV)
  VVCAcJ  = ("Home Menu" , FFurHP, [])
  if totCols == 2:
   VVwFPr = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
   VVwFPr = ("More Info.", boundFunction(self.VVe9aY, menuInstance) , [])
  FFMNGj(self, None, title=title, width=1200, header=header, VVYDUR=rows, VV5EM1=widths, VVzOAn=26, VVCAcJ=VVCAcJ, VVwFPr=VVwFPr, VVRbex="#0a00292B", VVihVe="#0a002126", VVwsQj="#0a002126", VVzAxe="#00000000", searchCol=searchCol)
 def VVe9aY(self, menuInstance, VVapBp, title, txt, colList):
  VVapBp.cancel()
  FFshid(menuInstance, boundFunction(self.VVxzvx, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVv3gy(self, mode):
  token, profile, tErr = self.VVvi19()
  if not token:
   return
  res, err = self.VVbQfI(self.VVjNu4(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CC0WOt()
     chList = tDict["js"]
     for item in chList:
      Id   = CCFXWw.VV51wI(item, "id"       )
      Title  = CCFXWw.VV51wI(item, "title"      )
      censored = CCFXWw.VV51wI(item, "censored"     )
      Title = processChanName.VVGUDd(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVxotg:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVTtAg(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVRbex, VVihVe, VVwsQj, VVzAxe = self.VVUdFN(mode)
   mName = self.VVTtAg(mode)
   VVBmAn   = ("Show List"   , boundFunction(self.VVsA8y, mode) , [])
   VVCAcJ  = ("Home Menu"   , FFurHP         , [])
   if mode in ("vod", "series"):
    VVKCEj = ("Find in %s" % mName , boundFunction(self.VVx8pA, mode), [])
   else:
    VVKCEj = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FFMNGj(self, None, title=title, width=1200, header=header, VVYDUR=list, VV5EM1=widths, VVzOAn=30, VVCAcJ=VVCAcJ, VVKCEj=VVKCEj, VVBmAn=VVBmAn, VVRbex=VVRbex, VVihVe=VVihVe, VVwsQj=VVwsQj, VVzAxe=VVzAxe)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.portal_moreAuthMsg:
     txt += "\n\n( %s )" % self.portal_moreAuthMsg
   else:
    txt = "Could not get Categories from server!"
   FFf3zP(self, txt, title=title)
 def VVATyo(self, mode, VVapBp, title, txt, colList):
  FFshid(VVapBp, boundFunction(self.VVgjCG, mode, VVapBp, title, txt, colList), title="Downloading ...")
 def VVgjCG(self, mode, VVapBp, title, txt, colList):
  token, profile, tErr = self.VVvi19()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVbQfI(self.VVWjhr(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCFXWw.VV51wI(item, "id"    )
      actors   = CCFXWw.VV51wI(item, "actors"   )
      added   = CCFXWw.VV51wI(item, "added"   )
      age    = CCFXWw.VV51wI(item, "age"   )
      category_id  = CCFXWw.VV51wI(item, "category_id" )
      description  = CCFXWw.VV51wI(item, "description" )
      director  = CCFXWw.VV51wI(item, "director"  )
      genres_str  = CCFXWw.VV51wI(item, "genres_str"  )
      name   = CCFXWw.VV51wI(item, "name"   )
      path   = CCFXWw.VV51wI(item, "path"   )
      screenshot_uri = CCFXWw.VV51wI(item, "screenshot_uri" )
      series   = CCFXWw.VV51wI(item, "series"   )
      cmd    = CCFXWw.VV51wI(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VVBmAn  = ("Play"    , boundFunction(self.VVveFA, mode)       , [])
   VVscS4 = (""     , boundFunction(self.VVZv0x, mode)     , [])
   VVCAcJ = ("Home Menu"   , FFurHP               , [])
   VVtony = ("Download Options" , boundFunction(self.VVQdrB, mode, "sp", seriesName) , [])
   VVKCEj = ("Options" , boundFunction(self.VVD8QS, 0, "pEp", mode, seriesName)  , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVbtsV  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFMNGj(self, None, title=seriesName, width=1200, header=header, VVYDUR=list, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=26, VVCAcJ=VVCAcJ, VVtony=VVtony, VVKCEj=VVKCEj, VVBmAn=VVBmAn, VVscS4=VVscS4, VVRbex="#0a00292B", VVihVe="#0a002126", VVwsQj="#0a002126", VVzAxe="#00000000")
  else:
   FFf3zP(self, "Could not get Episodes from server!", title=seriesName)
 def VVx8pA(self, mode, VVapBp, title, txt, colList):
  VV23GK = []
  VV23GK.append(("Keyboard"  , "manualEntry"))
  VV23GK.append(("From Filter" , "fromFilter"))
  FFdX2v(self, boundFunction(self.VVKnYi, VVapBp, mode), title="Input Type", VV23GK=VV23GK, width=400)
 def VVKnYi(self, VVapBp, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFnG6g(self, boundFunction(self.VVbhVI, VVapBp, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CClJqP(self)
    filterObj.VVpDfj(boundFunction(self.VVbhVI, VVapBp, mode))
 def VVbhVI(self, VVapBp, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VVjPEh(mode, searchName)
   if len(searchName) < 3:
    FFf3zP(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CC0WOt()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVU6xg([searchName]):
     FFf3zP(self, processChanName.VVkOd4(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VVtROH(mode, searchName, "", searchName)
 def VVsA8y(self, mode, VVapBp, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVtROH(mode, bName, catID, "")
 def VVtROH(self, mode, bName, catID, searchName):
  self.session.open(CCoBfV, barTheme=CCoBfV.VVL4g0
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVgAdm, mode, bName, catID, searchName)
      , VVRMfQ = boundFunction(self.VVkBm7, mode, bName, catID, searchName))
 def VVkBm7(self, mode, bName, catID, searchName, VVHm3J, VVNOpf, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVjPEh(mode, searchName)
  else   : title = "%s : %s" % (self.VVTtAg(mode), bName)
  if VVNOpf:
   VVtony = None
   VVKCEj = None
   if mode == "series":
    VVRbex, VVihVe, VVwsQj, VVzAxe = self.VVUdFN("series2")
    VVBmAn  = ("Episodes", boundFunction(self.VVATyo, mode) , [])
   else:
    VVRbex, VVihVe, VVwsQj, VVzAxe = self.VVUdFN("")
    VVBmAn  = ("Play"    , boundFunction(self.VVveFA, mode)           , [])
    VVtony = ("Download Options" , boundFunction(self.VVQdrB, mode, "vp" if mode == "vod" else "", "") , [])
    VVKCEj = ("Options" , boundFunction(self.VVD8QS, 1, "pCh", mode, bName)  , [])
   VVscS4 = (""      , boundFunction(self.VVGc8S, mode)          , [])
   VVCAcJ = ("Home Menu"    , FFurHP                   , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVbtsV  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT )
   VVapBp = FFMNGj(self, None, title=title, header=header, VVYDUR=VVNOpf, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=26, VVCAcJ=VVCAcJ, VVtony=VVtony, VVKCEj=VVKCEj, VVBmAn=VVBmAn, VVscS4=VVscS4, VVRbex=VVRbex, VVihVe=VVihVe, VVwsQj=VVwsQj, VVzAxe=VVzAxe, VViKTA=True, searchCol=1)
   if not VVHm3J:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVapBp.VVQNhv(VVapBp.VVGIFi() + tot)
    if threadErr: FF6E92(VVapBp, "Error while reading !", 2000)
    else  : FF6E92(VVapBp, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFf3zP(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFf3zP(self, "Could not get list from server !", title=title)
 def VVGc8S(self, mode, VVapBp, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFMw5O(self, fncMode=CCkvvO.VVDlAk, portalHost=self.VVZSl1, portalMac=self.VVUfNV, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VViRaW(mode, VVapBp, title, txt, colList)
 def VVZv0x(self, mode, VVapBp, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFhqic(colList[10], VVcDYh)
  txt += "Description:\n%s" % FFhqic(colList[11], VVcDYh)
  self.VViRaW(mode, VVapBp, title, txt, colList)
 def VViRaW(self, mode, VVapBp, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVm5Ln(mode, colList)
  refCode, chUrl = self.VVWEI2(self.VVZSl1, self.VVUfNV, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFMw5O(self, fncMode=CCkvvO.VV7xzX, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVgAdm(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile, tErr = self.VVvi19()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VVNOpf, total_items, max_page_items, err = self.VVFq6w(mode, catID, 1, 1, searchName)
   if progBarObj.isCancelled:
    return
   if progBarObj.VVNOpf and total_items > -1 and max_page_items > -1:
    progBarObj.VVOeug(total_items)
    progBarObj.VVzPrH(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVFq6w(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VVfBe0()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VVNOpf += list
      progBarObj.VVzPrH(len(list), True)
  except:
   pass
 def VVFq6w(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVgzWk(mode, searchName, page)
  else   : url = self.VVMMw8(mode, catID, page)
  res, err = self.VVbQfI(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVIQgQ(CCFXWw.VV51wI(item, "total_items" ))
     max_page_items = self.VVIQgQ(CCFXWw.VV51wI(item, "max_page_items" ))
     processChanName = CC0WOt()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCFXWw.VV51wI(item, "id"    )
      name   = CCFXWw.VV51wI(item, "name"   )
      tv_genre_id  = CCFXWw.VV51wI(item, "tv_genre_id" )
      number   = CCFXWw.VV51wI(item, "number"   ) or str(counter)
      logo   = CCFXWw.VV51wI(item, "logo"   )
      screenshot_uri = CCFXWw.VV51wI(item, "screenshot_uri" )
      cmd    = CCFXWw.VV51wI(item, "cmd"   )
      cmd = cmd.replace("ffmpeg ", "")
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8"):
       span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      counter += 1
      name = processChanName.VVBESO(name)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVmume(self, mode, bName, VVapBp, title, txt, colList):
  bNameFile = CCFXWw.VVuSjW_forBouquet(bName)
  num  = 0
  path = VVF0QF + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVF0QF + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   isMulti = VVapBp.VVBMjk
   for ndx, row in enumerate(VVapBp.VVsv7I()):
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVm5Ln(mode, row)
    refCode, chUrl = self.VVWEI2(self.VVZSl1, self.VVUfNV, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    if not isMulti or VVapBp.VVZWda(ndx):
     f.write("#SERVICE %s\n"  % chUrl)
     f.write("#DESCRIPTION %s\n" % chName)
     totChange += 1
  FFodem(os.path.basename(path))
  self.VVT2o4(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVIQgQ(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVveFA(self, mode, VVapBp, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVm5Ln(mode, colList)
  refCode, chUrl = self.VVWEI2(self.VVZSl1, self.VVUfNV, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVkInU(chName):
   FF6E92(VVapBp, "This is a marker!", 300)
  else:
   FFshid(VVapBp, boundFunction(self.VVQKEr, mode, VVapBp, chUrl), title="Playing ...")
 def VVQKEr(self, mode, VVapBp, chUrl):
  FFjNnf(self, chUrl, VVOpaL=False)
  self.session.open(CC9pOJ, portalTableParam=(self, VVapBp, mode))
 def VVoies(self, mode, VVapBp, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVm5Ln(mode, colList)
  refCode, chUrl = self.VVWEI2(self.VVZSl1, self.VVUfNV, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVm5Ln(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVUkNu(SELF):
  try:
   import requests
   return True
  except:
   FFCKL0(SELF, boundFunction(CCCqon.VVvaOE, SELF), 'This requires the library "Requests".\n\nInstall it now ?')
   return False
 @staticmethod
 def VVvaOE(SELF):
  from sys import version_info
  cmdUpd = FF6WlR(VVqLEj, "")
  if cmdUpd:
   cmdInst = FFHppj(VV5wtI, "python-requests")
   if version_info[0] >= 3:
    cmdInst = cmdInst.replace("python-", "python3-")
   cmd = cmdUpd + " && " + cmdInst
   FFmkwf(SELF, cmd, checkNetAccess=True, title="Installing Requests Library")
  else:
   FFywk7(SELF)
class CCFXWw(Screen, CCCqon):
 VV3crh    = 0
 VVD8TD    = 1
 VVZT64    = 2
 VVBEI6    = 3
 VVUJsm     = 4
 VVIyoU     = 5
 VVcYJp     = 6
 VVKYmf     = 7
 VVXRyw      = 8
 VVKnD6     = 9
 VVUYjf     = 10
 VVxu6s     = 11
 VVBp6v     = 12
 VVKjet      = 13
 VVBNoh      = 14
 VV3nuJ      = 15
 VViRVd      = 16
 VVeHya      = 17
 VVpbBx    = 0
 VVGUIN   = 1
 VVabIB   = 2
 VVoKXD   = 3
 VVwwTK  = 4
 VVMbww  = 5
 VVJMIx   = 6
 VVOtIP   = 7
 VVhKle  = 8
 VVLS2z  = 9
 VVsxe3  = 10
 VV04fa = 0
 VVi36p = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFSDka(VVTY88, 1000, 1000, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.m3uOrM3u8File  = m3uOrM3u8File
  self.m3uOrM3u8BName  = ""
  self.VVapBp  = None
  self.tableTitle   = "IPTV Channels List"
  self.VVofBaData  = {}
  self.lastFindIptvName = ""
  CCCqon.__init__(self)
  VV23GK= self.VVD0so()
  FFyutK(self, title="IPTV", VV23GK=VV23GK)
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FFTEKh(self["myMenu"])
  FFm42V(self)
  FF64m1(self)
  if self.m3uOrM3u8File:
   self.VVMx1o(self.m3uOrM3u8File)
 def VVD0so(self):
  files = self.VVxWxo()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"        , "VVofBa_fromPlayList" ))
  tList.append(("IPTV Server Browser (from Portal List)"        , "VVofBa_fromMac"  ))
  tList.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)"    , "VVofBa_fromM3u"  ))
  qUrl, iptvRef = self.VV6wul()
  if qUrl or "chCode" in iptvRef:
   tList.append(("IPTV Server Browser (from Current Channel)"      , "VVofBa_fromCurrChan" ))
  VV23GK = []
  if files:
   if self.VVapBp:
    VV23GK.append(("Add Current List to a New Bouquet"      , "VVEuui"  ))
    VV23GK.append(VV15MX)
    VV23GK.append(("Change Current List References to Unique Codes"   , "VVx3kS"))
    VV23GK.append(("Change Current List References to Identical Codes"  , "VVHqHn_rows" ))
    VV23GK.append(VV15MX)
    VV23GK.append(("Share Reference with Satellite/C/T Service (manual entry)", "VVPAP9"   ))
    VV23GK.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VVUgwD"   ))
   else:
    VV23GK += tList
    VV23GK.append(VV15MX)
    VV23GK.append(("M3U/M3U8 Channels Browser"        , "VVCtiY"   ))
    VV23GK.append(("Local IPTV Channels"          , "iptvTable_all"   ))
    if qUrl:
     VV23GK.append(VV15MX)
     VV23GK.append(("Update Current Bouquet EPG (from IPTV Server)"  , "refreshIptvEPG"   ))
    VV23GK.append(VV15MX)
    VV23GK.append(("Count Available IPTV Channels"       , "VVQNdq"    ))
    VV23GK.append(("Check Reference Codes Format"        , "VVGocS"   ))
    VV23GK.append(("Check System Acceptable Reference Types"     , "VVF7tn"   ))
    VV23GK.append(VV15MX)
    VV23GK.append(("Share Reference with Sat./C/T (Only Matching Names)"  , "VV3UMB" ))
    VV23GK.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVAeIl"  ))
    VV23GK.append(("Change ALL References to Unique Codes"     , "VVctSU" ))
    VV23GK.append(("Change ALL References to Identical Codes"     , "VVHqHn_all" ))
  if not self.VVapBp:
   if not files:
    VV23GK += tList
   if not CCe2k3.VVlmfj():
    VV23GK.append(VV15MX)
    VV23GK.append(("Download Manager"           , "dload_stat"    ))
  return VV23GK
 def VVVYXc(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVEuui"   : FFnG6g(self, self.VVEuui, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVx3kS" : FFCKL0(self, boundFunction(FFshid, self.VVapBp, self.VVx3kS ), "Change Current List References to Unique Codes ?")
   elif item == "VVHqHn_rows" : FFCKL0(self, boundFunction(FFshid, self.VVapBp, self.VVHqHn   ), "Change Current List References to Identical Codes ?")
   elif item == "VVPAP9"   : self.VVPAP9(tTitle)
   elif item == "VVUgwD"   : self.VVUgwD(tTitle)
   elif item == "VVofBa_fromPlayList" : FFshid(self, self.VVW2um, title=title)
   elif item == "VVofBa_fromM3u"  : FFshid(self, boundFunction(self.VVzGJD, 0), title=title)
   elif item == "VVofBa_fromMac"  : self.VVrbUp()
   elif item == "VVofBa_fromCurrChan" : self.VVjjdu_fromCurrChan()
   elif item == "VVCtiY"   : self.VVCtiY()
   elif item == "iptvTable_live"   : FFshid(self, boundFunction(self.VVRIVo, self.VVKYmf ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFshid(self, boundFunction(self.VVRIVo, self.VV3crh) , title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VVoxfD()
   elif item == "VVQNdq"    : FFshid(self, self.VVQNdq)
   elif item == "VVGocS"    : FFshid(self, self.VVGocS)
   elif item == "VVF7tn"   : FFshid(self, self.VVF7tn)
   elif item == "VV3UMB"  : FFCKL0(self, boundFunction(FFshid, self, self.VV3UMB ), "Continue ?")
   elif item == "VVAeIl"  : self.VVAeIl()
   elif item == "VVctSU" : FFCKL0(self, boundFunction(FFshid, self, self.VVctSU ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVHqHn_all" : FFCKL0(self, boundFunction(FFshid, self, self.VVHqHn  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "dload_stat"    : CCe2k3.VVLmGk(self)
   elif item == "VVpEqQ"   : FFshid(self, boundFunction(CCLPQZ.VVpEqQ, self))
 def VVCtiY(self):
  if CCCqon.VVUkNu(self):
   FFshid(self, boundFunction(self.VVzGJD, 1), title="Searching ...")
 def VVNPMZ(self):
  global VV10fA
  VV10fA = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVVYXc(item)
 def VVRIVo(self, mode):
  VVKG2e = self.VVoiS4(mode)
  if VVKG2e:
   VVtony = ("Current Service", self.VVpTJH  , [])
   VVKCEj = ("Options"  , self.VV6QBA    , [])
   VVwFPr = ("Filter"   , self.VVLaZV    , [])
   VVBmAn  = ("Play"   , boundFunction(self.VVe5ST) , [])
   VVscS4 = (""    , self.VVj8bU     , [])
   VVd4rs = (""    , self.VVSOfQ      , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVbtsV  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFMNGj(self, None, header=header, VVYDUR=VVKG2e, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=26
     , VVBmAn=VVBmAn, VVtony=VVtony, VVKCEj=VVKCEj, VVwFPr=VVwFPr, VVscS4=VVscS4, VVd4rs=VVd4rs
     , VVRbex="#0a00292B", VVihVe="#0a002126", VVwsQj="#0a002126", VVzAxe="#00000000", VViKTA=True, searchCol=1)
  else:
   if mode == self.VVKYmf: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFf3zP(self, err)
 def VVSOfQ(self, VVapBp, title, txt, colList):
  self.VVapBp = VVapBp
 def VV6QBA(self, VVapBp, title, txt, colList):
  VV23GK= self.VVD0so()
  FFdX2v(self, self.VVVYXc, title="IPTV Tools", VV23GK=VV23GK)
 def VVLaZV(self, VVapBp, title, txt, colList):
  VV23GK = []
  VV23GK.append(("All"         , "all"   ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Prefix of Selected Channel"   , "sameName" ))
  VV23GK.append(("Suggest Words from Selected Channel" , "partName" ))
  VV23GK.append(("Names with Non-English Characters" , "nonEnglish" ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Live TV"        , "live"  ))
  VV23GK.append(("VOD"         , "vod"   ))
  VV23GK.append(("Series"        , "series"  ))
  VV23GK.append(("Uncategorised"      , "uncat"  ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Video"        , "video"  ))
  VV23GK.append(("Audio"        , "audio"  ))
  VV23GK.append(VV15MX)
  VV23GK.append(("MKV"         , "MKV"   ))
  VV23GK.append(("MP4"         , "MP4"   ))
  VV23GK.append(("MP3"         , "MP3"   ))
  VV23GK.append(("AVI"         , "AVI"   ))
  VV23GK.append(("FLV"         , "FLV"   ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVMrbj()
  if bNames:
   bNames.sort()
   VV23GK.append(VV15MX)
   for item in bNames:
    VV23GK.append((item, "__b__" + item))
  filterObj = CClJqP(self)
  filterObj.VVqg01(VV23GK, VV23GK, boundFunction(self.VV1vmN, VVapBp))
 def VV1vmN(self, VVapBp, item=None):
  prefix = VVapBp.VVTj1i(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VV3crh, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVD8TD , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVZT64 , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVBEI6 , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVKYmf  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVXRyw   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVKnD6  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVUYjf  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVxu6s  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVBp6v  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVKjet   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVBNoh   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VV3nuJ   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VViRVd   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVeHya   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVcYJp  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VVUJsm  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVIyoU  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVZT64:
   VV23GK = []
   chName = VVapBp.VVTj1i(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VV23GK.append((item, item))
    if not VV23GK and chName:
     VV23GK.append((chName, chName))
    FFdX2v(self, boundFunction(self.VV6ou2_partOfName, title), title="Words from Current Selection", VV23GK=VV23GK)
   else:
    VVapBp.VV1J0Q("Invalid Channel Name")
  else:
   words, asPrefix = CClJqP.VVFtXI(words)
   if not words and mode in (self.VVUJsm, self.VVIyoU):
    FF6E92(self.VVapBp, "Incorrect filter", 2000)
   else:
    FFshid(self.VVapBp, boundFunction(self.VV5O8Y, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VV6ou2_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFshid(self.VVapBp, boundFunction(self.VV5O8Y, self.VVZT64, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVYsZt(txt):
  return "#f#11ffff00#" + txt
 def VV5O8Y(self, mode, words, asPrefix, title):
  VVKG2e = self.VVoiS4(mode=mode, words=words, asPrefix=asPrefix)
  if VVKG2e : self.VVapBp.VVs7In(VVKG2e, title)
  else  : self.VVapBp.VV1J0Q("Not found")
 def VVoiS4(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VVKG2e = []
  files  = self.VVxWxo()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFp1Ek(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VV4moU = span.group(1)
    else : VV4moU = ""
    VV4moU_lCase = VV4moU.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVkInU(chName): chNameMod = self.VVYsZt(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VV4moU, chType, refCode, url)
     ok = False
     tUrl = FFIl0q(url).lower()
     if mode == self.VV3crh       : ok = True
     elif mode == self.VVcYJp       : ok = True
     elif mode == self.VVxu6s:
      if CCFXWw.VVdr9M(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVBp6v:
      if CCFXWw.VVdr9M(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVKYmf:
      if CCFXWw.VVdr9M(tUrl, compareType="live")  : ok = True
     elif mode == self.VVXRyw:
      if CCFXWw.VVdr9M(tUrl, compareType="movie") : ok = True
     elif mode == self.VVKnD6:
      if CCFXWw.VVdr9M(tUrl, compareType="series") : ok = True
     elif mode == self.VVUYjf:
      if CCFXWw.VVdr9M(tUrl, compareType="")   : ok = True
     elif mode == self.VVKjet:
      if CCFXWw.VVdr9M(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVBNoh:
      if CCFXWw.VVdr9M(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VV3nuJ:
      if CCFXWw.VVdr9M(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VViRVd:
      if CCFXWw.VVdr9M(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVeHya:
      if CCFXWw.VVdr9M(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVD8TD:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVZT64:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVBEI6:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VVUJsm:
      if words[0] == VV4moU_lCase:
       ok = True
     elif mode == self.VVIyoU:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VVKG2e.append(row)
      chNum += 1
  if VVKG2e and mode == self.VVcYJp:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VVKG2e)
   for item in VVKG2e:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VVKG2e = newRows
  return VVKG2e
 def VVEuui(self, bName):
  if bName:
   FFshid(self.VVapBp, boundFunction(self.VVCnaX, bName), title="Adding Channels ...")
 def VVCnaX(self, bName):
  num = 0
  path = VVF0QF + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVF0QF + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVapBp.VVsv7I():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFjaTr(row[1]))
    totChange += 1
  FFodem(os.path.basename(path))
  self.VVT2o4(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVAeIl(self):
  txt = "Stream Type "
  VV23GK = []
  VV23GK.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VV23GK.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VV23GK.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VV23GK.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VV23GK.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VV23GK.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFdX2v(self, self.VV3OPR, title="Change Reference Types to:", VV23GK=VV23GK)
 def VV3OPR(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVxhr7("1"   )
   elif item == "RT_4097" : self.VVxhr7("4097")
   elif item == "RT_5001" : self.VVxhr7("5001")
   elif item == "RT_5002" : self.VVxhr7("5002")
   elif item == "RT_8192" : self.VVxhr7("8192")
   elif item == "RT_8193" : self.VVxhr7("8193")
 def VVxhr7(self, rType):
  FFCKL0(self, boundFunction(FFshid, self, boundFunction(self.VV9bbI, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VV9bbI(self, refType):
  totChange = 0
  files  = self.VVxWxo()
  if files:
   for path in files:
    txt = FFp1Ek(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFodem(os.path.basename(path))
  self.VVT2o4(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVQNdq(self):
  totFiles = 0
  files  = self.VVxWxo()
  if files:
   totFiles = len(files)
  totChans = 0
  VVKG2e = self.VVoiS4()
  if VVKG2e:
   totChans = len(VVKG2e)
  FF9Qkx(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVGocS(self):
  files  = self.VVxWxo()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFp1Ek(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVUnli
   else    : color = VVd9bM
   totInvalid = FFhqic(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFhqic("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FF9Qkx(self, txt, title="Check IPTV References")
 def VVF7tn(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVF0QF + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFodem(os.path.basename(path))
  FFVeqY()
  acceptedList = []
  VVxOKd = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVxOKd:
   VVOPhm = FFho3z(VVxOKd)
   if VVOPhm:
    for service in VVOPhm:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVF0QF + userBName
  bFile = VVF0QF + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFrWND("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFrWND("rm -f '%s'" % path)
  os.system(cmd)
  FFVeqY()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVUnli
    else     : res, color = "No" , VVd9bM
    txt += "    %s\t: %s\n" % (item, FFhqic(res, color))
   FF9Qkx(self, txt, title=title)
  else:
   txt = FFf3zP(self, "Could not complete the test on your system!", title=title)
 def VV3UMB(self):
  lameDbChans = CCLPQZ.VVlZYk(self, CCLPQZ.VVNQUb)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVxWxo():
    toSave = False
    txt = FFp1Ek(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVT2o4(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFf3zP(self, 'No channels in "lamedb" !')
 def VVctSU(self):
  files  = self.VVxWxo()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FF8ZwU(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVXWKe(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVT2o4(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVx3kS(self):
  iptvRefList = []
  files  = self.VVxWxo()
  if files:
   for path in files:
    txt = FFp1Ek(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVapBp.VVHEz0(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVXWKe(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVxWxo()
  if files:
   for path in files:
    lines = FF8ZwU(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVT2o4(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVXWKe(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVHqHn(self):
  list = None
  if self.VVapBp:
   list = []
   for row in self.VVapBp.VVsv7I():
    list.append(row[4] + row[5])
  files  = self.VVxWxo()
  totChange = 0
  if files:
   for path in files:
    lines = FF8ZwU(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVT2o4(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVT2o4(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFVeqY()
   if refreshTable and self.VVapBp:
    VVKG2e = self.VVoiS4()
    if VVKG2e and self.VVapBp:
     self.VVapBp.VVs7In(VVKG2e, self.tableTitle)
     self.VVapBp.VV1J0Q(txt)
   FF9Qkx(self, txt, title=title)
  else:
   FFTVfn(self, "No changes.")
 def VVMrbj(self):
  files = self.VVxWxo()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with ioOpen(path, "r", encoding="utf-8") as f:
     span = iSearch(r"#NAME\s+(.*)", str(f.readline()), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VVXYvE = FF1HUL()
    if VVXYvE:
     for b in VVXYvE:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVxWxo(self):
  return CCFXWw.VVczEg(self)
 @staticmethod
 def VVczEg(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVF0QF + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFp1Ek(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVj8bU(self, VVapBp, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFIl0q(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFMw5O(self, fncMode=CCkvvO.VV5gZz, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVrXrx(self, VVapBp, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVe5ST(self, VVapBp, title, txt, colList):
  chName, chUrl = self.VVrXrx(VVapBp, colList)
  self.VVbSTn(VVapBp, chName, chUrl, "localIptv")
 def VVBboT(self, mode, VVapBp, colList):
  chName, chUrl, picUrl, refCode = self.VVew5D(mode, colList)
  return chName, chUrl
 def VVAHRX(self, mode, VVapBp, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVew5D(mode, colList)
  self.VVbSTn(VVapBp, chName, chUrl, mode)
 def VVbSTn(self, VVapBp, chName, chUrl, playerFlag):
  chName = FFjaTr(chName)
  if self.VVkInU(chName):
   FF6E92(VVapBp, "This is a marker!", 300)
  else:
   FFshid(VVapBp, boundFunction(self.VVINsP, VVapBp, chUrl, playerFlag), title="Playing ...")
 def VVINsP(self, VVapBp, chUrl, playerFlag):
  FFjNnf(self, chUrl, VVOpaL=False)
  self.session.open(CC9pOJ, portalTableParam=(self, VVapBp, playerFlag))
 @staticmethod
 def VVkInU(chName):
  mark = ("--", "__", "==", "##", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVpTJH(self, VVapBp, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self)
  if refCode:
   bName = FFw4PJ()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFdrTi(refCode, origUrl, chName) }
   VVapBp.VVaB7A_partial(colDict, VVHov8=True)
 def VVzGJD(self, m3uMode):
  path = CCFXWw.VVtugE()
  lines = FFIx6K("find %s %s -iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'" % (path, FF2qZL(1)))
  if lines:
   lines.sort()
   VV23GK = []
   for line in lines:
    VV23GK.append((line, line))
   if m3uMode == self.VV04fa:
    title = "Browse Server from M3U URLs"
    VVvFvy = ("All to Playlist", self.VV9nCC)
   else:
    title = "M3U/M3U8 Channels Browser"
    VVvFvy = None
   OKBtnFnc = boundFunction(self.VVEZWF, m3uMode, title)
   VVwqMz  = ("Show Full Path", self.VVkcEK)
   VVrMQs = ("Delete File", self.VVegYk)
   FFdX2v(self, None, title=title, VV23GK=VV23GK, width=1200, OKBtnFnc=OKBtnFnc, VVwqMz=VVwqMz, VVrMQs=VVrMQs, VVvFvy=VVvFvy)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n\n%s" % path
   FFf3zP(self, 'No ".m3u" files found %s' % txt)
 def VVkcEK(self, VVoYT0Obj, url):
  FF9Qkx(self, url, title="Full Path")
 def VVEZWF(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == self.VV04fa:
    FFshid(menuInstance, boundFunction(self.VVPgeM, title, path))
   else:
    FFshid(menuInstance, boundFunction(self.VVMx1o, path))
 def VVMx1o(self, srcPath):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFp1Ek(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  processChanName = CC0WOt()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VVm4qx(propLine, "group-title") or "-"
   if not group == "-" and processChanName.VVBESO(group):
    groups.add(group)
  VVKG2e = []
  if len(groups) > 0:
   title = "Groups"
   for group in groups:
    VVKG2e.append((group, group))
   VVKG2e.append(("ALL", ""))
   VVKG2e.sort(key=lambda x: x[0].lower())
   VVyVHa = self.VVRS9R
   VVBmAn  = ("Select" , boundFunction(self.VV4o5Y, srcPath), [])
   widths   = (100  , 0)
   VVbtsV  = (LEFT  , LEFT)
   FFMNGj(self, None, title=title, width= 800, header=None, VVYDUR=VVKG2e, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=30, VVBmAn=VVBmAn, VVyVHa=VVyVHa
     , VVRbex="#11110022", VVihVe="#11110022", VVwsQj="#11110022", VVzAxe="#00444400")
  else:
   txt = FFp1Ek(srcPath)
   self.VVDQmP(txt, filterGroup="")
 def VV4o5Y(self, srcPath, VVapBp, title, txt, colList):
  group = colList[1]
  txt = FFp1Ek(srcPath)
  self.VVDQmP(txt, filterGroup=group)
 def VVDQmP(self, txt, filterGroup=""):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = "Group : %s" % (filterGroup or "ALL")
  if lst:
   self.session.open(CCoBfV, barTheme=CCoBfV.VVL4g0
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VVILIF, lst, filterGroup)
       , VVRMfQ = boundFunction(self.VVp399, title, bName))
  else:
   self.VVhSFb("No valid lines found !", title)
 def VVILIF(self, lst, filterGroup, progBarObj):
  progBarObj.VVNOpf = []
  progBarObj.VVOeug(len(lst))
  processChanName = CC0WOt()
  num = 0
  for cols in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVzPrH(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VVm4qx(propLine, "tvg-logo")
   group = self.VVm4qx(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if group and not processChanName.VVBESO(group) : skip = True
    if chName and not processChanName.VVBESO(chName): skip = True
    if not skip and progBarObj:
     num += 1
     progBarObj.VVNOpf.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if progBarObj:
   progBarObj.VVinHX_forcedUpdate("Loading %d Channels" % len(progBarObj.VVNOpf))
 def VVp399(self, title, bName, VVHm3J, VVNOpf, threadCounter, threadTotal, threadErr):
  if VVNOpf:
   VVyVHa = self.VVRS9R
   VVBmAn  = ("Select"    , boundFunction(self.VVQRK5, title) , [])
   VVscS4 = (""     , self.VVcfiX         , [])
   VVtony = ("Download PIcons" , self.VV7ThT        , [])
   VVKCEj = ("Options" , boundFunction(self.VVD8QS, 1, "m3Ch", "", bName)  , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVbtsV  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFMNGj(self, None, title=title, header=header, VVYDUR=VVNOpf, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=28, VVBmAn=VVBmAn, VVyVHa=VVyVHa, VVscS4=VVscS4, VVtony=VVtony, VVKCEj=VVKCEj, VViKTA=True, searchCol=1
     , VVRbex="#0a00192B", VVihVe="#0a00192B", VVwsQj="#0a00192B", VVzAxe="#00000000")
  else:
   self.VVhSFb("No valid lines found !", title)
 def VV7ThT(self, VVapBp, title, txt, colList):
  self.VVgkUK(VVapBp, "m3u/m3u8")
 def VVPmlf(self, mode, bName, VVapBp, title, txt, colList):
  bNameFile = CCFXWw.VVuSjW_forBouquet(bName)
  num  = 0
  path = VVF0QF + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVF0QF + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   catID = "33"
   rowNum = 0
   isMulti = VVapBp.VVBMjk
   for ndx, row in enumerate(VVapBp.VVsv7I()):
    chName = row[1].strip()
    url  = row[3].strip()
    chUrl = self.VVJRmD(rowNum, url, chName)
    rowNum += 1
    if not isMulti or VVapBp.VVZWda(ndx):
     f.write("#SERVICE %s\n"  % chUrl)
     f.write("#DESCRIPTION %s\n" % chName)
     totChange += 1
  FFodem(os.path.basename(path))
  self.VVT2o4(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVJRmD(self, rowNum, url, chName):
  refCode = self.VV1Zh0(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFuUoF(url), chName)
  return chUrl
 def VV1Zh0(self, rowNum, url, chName):
  span = iSearch(r"\/(\d{2,})", url, IGNORECASE)
  if span : stID = span.group(1)
  else : stID = "444"
  catID = "333"
  chNum = str(rowNum + 1)
  refCode = self.VV17ho(catID, stID, chNum)
  return refCode
 def VVm4qx(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVQRK5(self, Title, VVapBp, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFshid(VVapBp, boundFunction(self.VVAxLm, Title, VVapBp, colList), title="Checking Server ...")
  else:
   self.VVvruV(VVapBp, url, chName)
 def VVAxLm(self, title, VVapBp, colList):
  if not CCCqon.VVUkNu(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CC5PGk.VVL7z2(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VV23GK = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCFXWw.VV5Lwe(url, fPath)
     VV23GK.append((resol, fullUrl))
    if VV23GK:
     if len(VV23GK) > 1:
      FFdX2v(self, boundFunction(self.VV8Uet, VVapBp, chName), VV23GK=VV23GK, title="Resolution", VVdwiN=True, VVqC46=True)
     else:
      self.VVvruV(VVapBp, VV23GK[0][1], chName)
    else:
     self.VVHov8or("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVDQmP(txt, filterGroup="")
      return
    self.VVvruV(VVapBp, url, chName)
   else:
    self.VVhSFb("Cannot process this channel !", title)
  else:
   self.VVhSFb(err, title)
 def VV8Uet(self, VVapBp, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVvruV(VVapBp, resolUrl, chName)
 def VVvruV(self, VVapBp, url, chName):
  FFshid(VVapBp, boundFunction(self.VVg2rA, VVapBp, url, chName), title="Playing ...")
 def VVg2rA(self, VVapBp, url, chName):
  chUrl = self.VVJRmD(VVapBp.VVcTYx(), url, chName)
  FFjNnf(self, chUrl, VVOpaL=False)
  self.session.open(CC9pOJ, portalTableParam=(self, VVapBp, "m3u/m3u8"))
 def VVUqnL(self, VVapBp, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVJRmD(VVapBp.VVcTYx(), url, chName)
  return chName, chUrl
 def VVcfiX(self, VVapBp, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFMw5O(self, fncMode=CCkvvO.VV5gZz, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVhSFb(self, err, title):
  FFf3zP(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVRS9R(self, VVapBp):
  if self.m3uOrM3u8File:
   self.close()
  VVapBp.cancel()
 def VV9nCC(self, VVoYT0Obj, item=None):
  FFshid(VVoYT0Obj, boundFunction(self.VVA5wl, VVoYT0Obj, item))
 def VVA5wl(self, VVoYT0Obj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVoYT0Obj.VV23GK):
    path = item[1]
    if fileExists(path):
     enc = CC4HXa.VVhXg3(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = self.VVr6sM(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCFXWw.VVtugE(orExportPath=True)
    pListF = "%sPlaylist_%s.txt" % (path, FF4Auk())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVoYT0Obj.VV23GK)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FF9Qkx(self, txt, title=title)
   else:
    FFf3zP(self, "Could not obtain URLs from this file list !", title=title)
 def VVW2um(self):
  path = CCFXWw.VVtugE()
  lines = FFIx6K('find %s %s -iname "*playlist*" | grep -i ".txt"' % (path, FF2qZL(1)))
  if lines:
   lines.sort()
   VV23GK = []
   for line in lines:
    VV23GK.append((line, line))
   OKBtnFnc  = self.VVA7cc
   VVrMQs = ("Delete File", self.VVegYk)
   FFdX2v(self, None, title="Select Playlist File", VV23GK=VV23GK, width=1200, OKBtnFnc=OKBtnFnc, VVrMQs=VVrMQs)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFf3zP(self, 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt)
 def VVA7cc(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFshid(menuInstance, boundFunction(self.VVMnES, menuInstance, path), title="Processing File ...")
 def VVMnES(self, fileMenuInstance, path):
  enc = CC4HXa.VVhXg3(path, self)
  if enc == -1:
   return
  VVKG2e = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0]
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFr9AH(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCFXWw.VVmypn(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVKG2e:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(filter(None, [item[5], item[0]]))
     num += 1
     VVKG2e.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVKG2e:
   title = "Playlist File"
   VVBmAn  = ("Start"    , boundFunction(self.VVGleM, title)  , [])
   VVCAcJ = ("Home Menu"   , FFurHP         , [])
   VVtony = ("Download M3U File" , self.VVkbTv     , [])
   VVKCEj = ("Edit File"   , boundFunction(self.VVJhTm, path) , [])
   VVwFPr = ("Check & Filter"  , boundFunction(self.VVIdaV, fileMenuInstance, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVbtsV  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFMNGj(self, None, title=title, header=header, VVYDUR=VVKG2e, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=26, VVBmAn=VVBmAn, VVCAcJ=VVCAcJ, VVwFPr=VVwFPr, VVtony=VVtony, VVKCEj=VVKCEj, VVRbex="#11001116", VVihVe="#11001116", VVwsQj="#11001116", VVzAxe="#00003635", VVrSmG="#0a333333", VVIRVU="#11331100", VViKTA=True)
  else:
   FFf3zP(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVkbTv(self, VVapBp, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFCKL0(self, boundFunction(FFshid, VVapBp, boundFunction(self.VVe59X, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVe59X(self, title, url):
  path, err = FF2QcO(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFf3zP(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFp1Ek(path)
   if '{"user_info":{"auth":0}}' in txt:
    os.system(FFrWND("rm -f '%s'" % path))
    FFf3zP(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    os.system(FFrWND("rm -f '%s'" % path))
    FFf3zP(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCFXWw.VVtugE(orExportPath=True) + fName
    os.system(FFrWND("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FFTVfn(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFf3zP(self, "Could not download the M3U file!", title=errTitle)
 def VVGleM(self, Title, VVapBp, title, txt, colList):
  url = colList[6]
  FFshid(VVapBp, boundFunction(self.VVaL01, Title, url), title="Checking Server ...")
 def VVJhTm(self, path, VVapBp, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCUORs(self, path, VVRMfQ=boundFunction(self.VVtCne, VVapBp), curRowNum=rowNum)
  else    : FFxtzL(self, path)
 def VVtCne(self, VVapBp, fileChanged):
  if fileChanged:
   VVapBp.cancel()
 def VVPAP9(self, title):
  curChName = self.VVapBp.VVTj1i(1)
  FFnG6g(self, boundFunction(self.VV3nYa, title), defaultText=curChName, title=title, message="Enter Name:")
 def VV3nYa(self, title, name):
  if name:
   lameDbChans = CCLPQZ.VVlZYk(self, CCLPQZ.VVgQnd, VVCkoG=False, VVRxi8=False)
   list = []
   if lameDbChans:
    processChanName = CC0WOt()
    name = processChanName.VVxYfv(name)
    ratio = "1"
    for item in lameDbChans:
     if name in item[0].lower():
      list.append((item[0], FFFD0p(item[2]), item[3], ratio))
   if list : self.VVlySX(list, title)
   else : FFf3zP(self, "Not found:\n\n%s" % name, title=title)
 def VVUgwD(self, title):
  curChName = self.VVapBp.VVTj1i(1)
  self.session.open(CCoBfV, barTheme=CCoBfV.VVL4g0
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVSBpr
      , VVRMfQ = boundFunction(self.VVTa1Z, title, curChName))
 def VVSBpr(self, progBarObj):
  curChName = self.VVapBp.VVTj1i(1)
  lameDbChans = CCLPQZ.VVlZYk(self, CCLPQZ.VVpDpg, VVCkoG=False, VVRxi8=False)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVNOpf = []
  progBarObj.VVOeug(len(lameDbChans))
  processChanName = CC0WOt()
  curCh = processChanName.VVxYfv(curChName)
  for refCode in lameDbChans:
   chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
   ratio = CCkYaA.VV5No4(chName.lower(), curCh)
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVzPrH(1, True)
   if progBarObj and ratio > 50:
    progBarObj.VVNOpf.append((chName, FFFD0p(sat), refCode.replace("_", ":"), str(ratio)))
 def VVTa1Z(self, title, curChName, VVHm3J, VVNOpf, threadCounter, threadTotal, threadErr):
  if VVNOpf: self.VVlySX(VVNOpf, title)
  elif VVHm3J: FFf3zP(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVlySX(self, VVKG2e, title):
  curChName = self.VVapBp.VVTj1i(1)
  curRefCode = self.VVapBp.VVTj1i(4)
  curUrl  = self.VVapBp.VVTj1i(5)
  VVKG2e = sorted(VVKG2e, key=lambda x: (100-int(x[3]), x[0].lower()))
  VVBmAn  = ("Share Sat/C/T Ref.", boundFunction(self.VVpFgi, title, curChName, curRefCode, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFMNGj(self, None, title=title, header=header, VVYDUR=VVKG2e, VV5EM1=widths, VVzOAn=26, VVBmAn=VVBmAn, VVRbex="#0a00112B", VVihVe="#0a001126", VVwsQj="#0a001126", VVzAxe="#00000000")
 def VVpFgi(self, newtitle, curChName, curRefCode, curUrl, VVapBp, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFCKL0(self.VVapBp, boundFunction(FFshid, self.VVapBp, boundFunction(self.VVhpbP, VVapBp, data)), ques, title=newtitle, VVCyqa=True)
 def VVhpbP(self, VVapBp, data):
  VVapBp.cancel()
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVxWxo():
    txt = FFp1Ek(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFVeqY()
    newRow = []
    for i in range(6):
     newRow.append(self.VVapBp.VVTj1i(i))
    newRow[4] = newRefCode
    done = self.VVapBp.VVFZW7(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFRXLV(boundFunction(FFTVfn , self, resTxt, title=title))
  elif resErr: FFRXLV(boundFunction(FFf3zP , self, resErr, title=title))
 def VVIdaV(self, fileMenuInstance, path, VVapBp, title, txt, colList):
  self.session.open(CCoBfV, barTheme=CCoBfV.VVL4g0
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VVquao, VVapBp)
      , VVRMfQ = boundFunction(self.VV9PvO, fileMenuInstance, path, VVapBp))
 def VVquao(self, VVapBp, progBarObj):
  progBarObj.VVOeug(VVapBp.VVSx26())
  progBarObj.VVNOpf = []
  for row in VVapBp.VVsv7I():
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVzPrH(1, True)
   qUrl = self.VV6o35(self.VVpbBx, row[6])
   txt, err = self.VV6PIg(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VV51wI(item, "auth") == "0":
       progBarObj.VVNOpf.append(qUrl)
    except:
     pass
 def VV9PvO(self, fileMenuInstance, path, VVapBp, VVHm3J, VVNOpf, threadCounter, threadTotal, threadErr):
  if VVHm3J:
   list = VVNOpf
   title = "Authorized Servers"
   if list:
    totChk = VVapBp.VVSx26()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FF4Auk()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVW2um()
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFhqic(str(totAuth), VVUnli)
     txt += "%s\n\n%s"    %  (FFhqic("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FF9Qkx(self, txt, title=title)
     VVapBp.close()
     fileMenuInstance.close()
    else:
     FFTVfn(self, "All URLs are authorized.", title=title)
   else:
    FFf3zP(self, "No authorized URL found !", title=title)
 @staticmethod
 def VV6PIg(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   cont = res.headers.get("Content-Type")
   if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
    return "", "Unexpected server data type ( %s )" % cont
   res = res.read().decode("UTF-8")
   if res:
    if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server !"
    else           : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVmypn(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVdr9M(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VV6o35(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVmypn(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVpbBx   : return "%s"            % url
  elif mode == self.VVGUIN   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVabIB   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVoKXD  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVwwTK  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVMbww : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVJMIx   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVOtIP    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVhKle  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVsxe3 : return "%s&action=get_live_streams"      % url
  elif mode == self.VVLS2z  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VV51wI(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFXQPO(int(val))
    elif is_base64 : val = FFPO3d(val)
    elif isToHHMMSS : val = FFN2Gj(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVPgeM(self, title, path):
  if fileExists(path):
   enc = CC4HXa.VVhXg3(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = self.VVr6sM(line)
     if qUrl:
      break
   if qUrl : self.VVaL01(title, qUrl)
   else : FFf3zP(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFf3zP(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVjjdu_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VV6wul()
  if qUrl or "chCode" in iptvRef:
   p = CC5PGk()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVpNE0(iptvRef)
   if valid:
    self.VVjjdu(self, host, mac)
    return
   elif qUrl:
    FFshid(self, boundFunction(self.VVaL01, title, qUrl), title="Checking Server ...")
    return
  FFf3zP(self, "Error in current channel URL !", title=title)
 def VV6wul(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self)
  qUrl = self.VVr6sM(decodedUrl)
  return qUrl, iptvRef
 def VVr6sM(self, url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVaL01(self, title, url):
  self.VVofBaData = {}
  qUrl = self.VV6o35(self.VVpbBx, url)
  txt, err = self.VV6PIg(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVofBaData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVofBaData["username"    ] = self.VV51wI(item, "username"        )
    self.VVofBaData["password"    ] = self.VV51wI(item, "password"        )
    self.VVofBaData["message"    ] = self.VV51wI(item, "message"        )
    self.VVofBaData["auth"     ] = self.VV51wI(item, "auth"         )
    self.VVofBaData["status"    ] = self.VV51wI(item, "status"        )
    self.VVofBaData["exp_date"    ] = self.VV51wI(item, "exp_date"    , isDate=True )
    self.VVofBaData["is_trial"    ] = self.VV51wI(item, "is_trial"        )
    self.VVofBaData["active_cons"   ] = self.VV51wI(item, "active_cons"       )
    self.VVofBaData["created_at"   ] = self.VV51wI(item, "created_at"   , isDate=True )
    self.VVofBaData["max_connections"  ] = self.VV51wI(item, "max_connections"      )
    self.VVofBaData["allowed_output_formats"] = self.VV51wI(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVofBaData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVofBaData["url"    ] = self.VV51wI(item, "url"        )
    self.VVofBaData["port"    ] = self.VV51wI(item, "port"        )
    self.VVofBaData["https_port"  ] = self.VV51wI(item, "https_port"      )
    self.VVofBaData["server_protocol" ] = self.VV51wI(item, "server_protocol"     )
    self.VVofBaData["rtmp_port"   ] = self.VV51wI(item, "rtmp_port"       )
    self.VVofBaData["timezone"   ] = self.VV51wI(item, "timezone"       )
    self.VVofBaData["timestamp_now"  ] = self.VV51wI(item, "timestamp_now"  , isDate=True )
    self.VVofBaData["time_now"   ] = self.VV51wI(item, "time_now"       )
    VV23GK  = self.VVpl12(True)
    OKBtnFnc = self.VVofBaOptions
    VVp90K = ("Home Menu", FFurHP)
    VVvFvy = ("Bookmark Server", boundFunction(CCFXWw.VVIwFK, self, False, self.VVofBaData["playListURL"]))
    FFdX2v(self, None, title="IPTV Server Resources", VV23GK=VV23GK, OKBtnFnc=OKBtnFnc, VVp90K=VVp90K, VVvFvy=VVvFvy)
   else:
    err = "Could not get data from server !"
  if err:
   FFf3zP(self, err, title=title)
  FF6E92(self)
 def VVofBaOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFshid(menuInstance, boundFunction(self.VVK1tN, self.VVGUIN  , title=title), title=wTxt)
   elif ref == "vod"   : FFshid(menuInstance, boundFunction(self.VVK1tN, self.VVabIB  , title=title), title=wTxt)
   elif ref == "series"  : FFshid(menuInstance, boundFunction(self.VVK1tN, self.VVoKXD , title=title), title=wTxt)
   elif ref == "catchup"  : FFshid(menuInstance, boundFunction(self.VVK1tN, self.VVwwTK , title=title), title=wTxt)
   elif ref == "accountInfo" : FFshid(menuInstance, boundFunction(self.VVJwwk           , title=title), title=wTxt)
 def VVJwwk(self, title):
  rows = []
  for key, val in self.VVofBaData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VVCAcJ = ("Home Menu", FFurHP, [])
  header   = ("Num", "User/Server" , "Subject" , "Value" )
  widths   = (0 , 15   , 35  , 50  )
  FFMNGj(self, None, title=title, width=1200, header=header, VVYDUR=rows, VV5EM1=widths, VVzOAn=26, VVCAcJ=VVCAcJ, VVRbex="#0a00292B", VVihVe="#0a002126", VVwsQj="#0a002126", VVzAxe="#00000000", searchCol=2)
 def VVnOYd(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CC0WOt()
    if mode in (self.VVJMIx, self.VVLS2z):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VV51wI(item, "num"         )
      name     = self.VV51wI(item, "name"        )
      stream_id    = self.VV51wI(item, "stream_id"       )
      stream_icon    = self.VV51wI(item, "stream_icon"       )
      epg_channel_id   = self.VV51wI(item, "epg_channel_id"      )
      added     = self.VV51wI(item, "added"    , isDate=True )
      is_adult    = self.VV51wI(item, "is_adult"       )
      category_id    = self.VV51wI(item, "category_id"       )
      tv_archive    = self.VV51wI(item, "tv_archive"       )
      name = processChanName.VVBESO(name)
      if name:
       if mode == self.VVJMIx or mode == self.VVLS2z and tv_archive == "1":
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVOtIP:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VV51wI(item, "num"         )
      name    = self.VV51wI(item, "name"        )
      stream_id   = self.VV51wI(item, "stream_id"       )
      stream_icon   = self.VV51wI(item, "stream_icon"       )
      added    = self.VV51wI(item, "added"    , isDate=True )
      is_adult   = self.VV51wI(item, "is_adult"       )
      category_id   = self.VV51wI(item, "category_id"       )
      container_extension = self.VV51wI(item, "container_extension"     ) or "mp4"
      name = processChanName.VVBESO(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVhKle:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VV51wI(item, "num"        )
      name    = self.VV51wI(item, "name"       )
      series_id   = self.VV51wI(item, "series_id"      )
      cover    = self.VV51wI(item, "cover"       )
      genre    = self.VV51wI(item, "genre"       )
      episode_run_time = self.VV51wI(item, "episode_run_time"    )
      category_id   = self.VV51wI(item, "category_id"      )
      container_extension = self.VV51wI(item, "container_extension"    ) or "mp4"
      name = processChanName.VVBESO(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVK1tN(self, mode, title):
  cList, err = self.VVa7Ty(mode)
  if cList and mode == self.VVwwTK:
   cList = self.VVSFdq(cList)
  if err:
   FFf3zP(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVRbex, VVihVe, VVwsQj, VVzAxe = self.VVUdFN(mode)
   mName = self.VVTtAg(mode)
   if   mode == self.VVGUIN  : fMode = self.VVJMIx
   elif mode == self.VVabIB  : fMode = self.VVOtIP
   elif mode == self.VVoKXD : fMode = self.VVhKle
   elif mode == self.VVwwTK : fMode = self.VVLS2z
   if mode == self.VVwwTK:
    VVKCEj = None
   else:
    VVKCEj = ("Find in %s" % mName , boundFunction(self.VVdoO6, fMode) , [])
   VVBmAn   = ("Show List"   , boundFunction(self.VV7Mdq, mode) , [])
   VVCAcJ  = ("Home Menu"   , FFurHP          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFMNGj(self, None, title=title, width=1200, header=header, VVYDUR=cList, VV5EM1=widths, VVzOAn=30, VVCAcJ=VVCAcJ, VVKCEj=VVKCEj, VVBmAn=VVBmAn, VVRbex=VVRbex, VVihVe=VVihVe, VVwsQj=VVwsQj, VVzAxe=VVzAxe)
  else:
   FFf3zP(self, "No list from server !", title=title)
  FF6E92(self)
 def VVa7Ty(self, mode):
  qUrl  = self.VV6o35(mode, self.VVofBaData["playListURL"])
  txt, err = self.VV6PIg(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    processChanName = CC0WOt()
    for item in tDict:
     category_id  = self.VV51wI(item, "category_id"  )
     category_name = self.VV51wI(item, "category_name" )
     parent_id  = self.VV51wI(item, "parent_id"  )
     category_name = processChanName.VVGUDd(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVSFdq(self, catList):
  mode  = self.VVLS2z
  qUrl  = self.VV6o35(mode, self.VVofBaData["playListURL"])
  txt, err = self.VV6PIg(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVnOYd(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VV7Mdq(self, mode, VVapBp, title, txt, colList):
  title = colList[1]
  FFshid(VVapBp, boundFunction(self.VVYS9E, mode, VVapBp, title, txt, colList), title="Downloading ...")
 def VVYS9E(self, mode, VVapBp, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVTtAg(mode) + " : "+ bName
  if   mode == self.VVGUIN  : mode = self.VVJMIx
  elif mode == self.VVabIB  : mode = self.VVOtIP
  elif mode == self.VVoKXD : mode = self.VVhKle
  elif mode == self.VVwwTK : mode = self.VVLS2z
  qUrl  = self.VV6o35(mode, self.VVofBaData["playListURL"], catID)
  txt, err = self.VV6PIg(qUrl)
  list  = []
  if not err and mode in (self.VVJMIx, self.VVOtIP, self.VVhKle, self.VVLS2z):
   list, err = self.VVnOYd(mode, txt)
  if err:
   FFf3zP(self, err, title=title)
  elif list:
   VVCAcJ  = ("Home Menu"   , FFurHP             , [])
   if mode in (self.VVJMIx, self.VVLS2z):
    VVRbex, VVihVe, VVwsQj, VVzAxe = self.VVUdFN(mode)
    VVscS4 = (""     , boundFunction(self.VV7nZN, mode)     , [])
    VVtony = ("Download Options" , boundFunction(self.VVQdrB, mode, "", "")  , [])
    VVKCEj = ("Options" , boundFunction(self.VVD8QS, 1, "lv", mode, bName)  , [])
    if mode == self.VVJMIx:
     VVBmAn = ("Play"    , boundFunction(self.VVAHRX, mode)     , [])
    elif mode == self.VVLS2z:
     VVBmAn  = ("Programs", boundFunction(self.VVlkp7_fromIptvTable, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVbtsV  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVOtIP:
    VVRbex, VVihVe, VVwsQj, VVzAxe = self.VVUdFN(mode)
    VVBmAn  = ("Play"    , boundFunction(self.VVAHRX, mode)    , [])
    VVscS4 = (""     , boundFunction(self.VV7nZN, mode)    , [])
    VVtony = ("Download Options" , boundFunction(self.VVQdrB, mode, "v", ""), [])
    VVKCEj = ("Options" , boundFunction(self.VVD8QS, 1, "v", mode, bName)  , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVbtsV  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVhKle:
    VVRbex, VVihVe, VVwsQj, VVzAxe = self.VVUdFN("series2")
    VVBmAn  = ("Show Seasons", boundFunction(self.VVBKbF, mode) , [])
    VVscS4 = ("", boundFunction(self.VVPrNx, mode)  , [])
    VVtony = None
    VVKCEj = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVbtsV  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFMNGj(self, None, title=title, header=header, VVYDUR=list, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=26, VVBmAn=VVBmAn, VVCAcJ=VVCAcJ, VVtony=VVtony, VVKCEj=VVKCEj, VVscS4=VVscS4, VVRbex=VVRbex, VVihVe=VVihVe, VVwsQj=VVwsQj, VVzAxe=VVzAxe, VViKTA=True, searchCol=1)
  else:
   FFf3zP(self, "No Channels found !", title=title)
  FF6E92(self)
 def VVlkp7_fromIptvTable(self, mode, bName, VVapBp, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVofBaData["playListURL"]
  ok_fnc  = boundFunction(self.VV5bLW, hostUrl, chName, catId, streamId)
  FFshid(VVapBp, boundFunction(CCFXWw.VVlkp7, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VV5bLW(self, chUrl, chName, catId, streamId, VVapBp, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCFXWw.VVmypn(chUrl)
   chNum = "333"
   refCode = CCFXWw.VV17ho(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFjNnf(self, chUrl, VVOpaL=False)
   self.session.open(CC9pOJ)
  else:
   FFf3zP(self, "Incorrect Timestamp", pTitle)
 def VVBKbF(self, mode, VVapBp, title, txt, colList):
  title = colList[1]
  FFshid(VVapBp, boundFunction(self.VVuehZ, mode, VVapBp, title, txt, colList), title="Downloading ...")
 def VVuehZ(self, mode, VVapBp, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VV6o35(self.VVMbww, self.VVofBaData["playListURL"], series_id)
  txt, err = self.VV6PIg(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VV51wI(tDict["info"], "name"   )
      category_id = self.VV51wI(tDict["info"], "category_id" )
      icon  = self.VV51wI(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VV51wI(EP, "id"     )
        episode_num   = self.VV51wI(EP, "episode_num"   )
        epTitle    = self.VV51wI(EP, "title"     )
        container_extension = self.VV51wI(EP, "container_extension" )
        seasonNum   = self.VV51wI(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFf3zP(self, err, title=title)
  elif list:
   VVCAcJ = ("Home Menu"   , FFurHP             , [])
   VVtony = ("Download Options" , boundFunction(self.VVQdrB, mode, "s", title) , [])
   VVKCEj = ("Options" , boundFunction(self.VVD8QS, 0, "s", mode, title)  , [])
   VVscS4 = (""     , boundFunction(self.VV7nZN, mode)     , [])
   VVBmAn  = ("Play"    , boundFunction(self.VVAHRX, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVbtsV  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFMNGj(self, None, title=title, header=header, VVYDUR=list, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=26, VVCAcJ=VVCAcJ, VVtony=VVtony, VVBmAn=VVBmAn, VVscS4=VVscS4, VVKCEj=VVKCEj, VVRbex="#0a00292B", VVihVe="#0a002126", VVwsQj="#0a002126", VVzAxe="#00000000")
  else:
   FFf3zP(self, "No Channels found !", title=title)
  FF6E92(self)
 def VVdoO6(self, mode, VVapBp, title, txt, colList):
  VV23GK = []
  VV23GK.append(("Keyboard"  , "manualEntry"))
  VV23GK.append(("From Filter" , "fromFilter"))
  FFdX2v(self, boundFunction(self.VVBysw, VVapBp, mode), title="Input Type", VV23GK=VV23GK, width=400)
 def VVBysw(self, VVapBp, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFnG6g(self, boundFunction(self.VV9iqO, VVapBp, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CClJqP(self)
    filterObj.VVpDfj(boundFunction(self.VV9iqO, VVapBp, mode))
 def VV9iqO(self, VVapBp, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CC0WOt()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVU6xg(words):
     FFf3zP(self, processChanName.VVkOd4(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CCoBfV, barTheme=CCoBfV.VVL4g0
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VV7obS, VVapBp, mode, title, words, toFind, asPrefix, processChanName)
         , VVRMfQ = boundFunction(self.VVi4YS, mode, toFind, title))
   else:
    FFf3zP(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VV7obS(self, VVapBp, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVOeug(VVapBp.VV4jLZ())
  progBarObj.VVNOpf = []
  for row in VVapBp.VVsv7I():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVzPrH(1)
   progBarObj.VVinHX_fromIptvFind(catName)
   qUrl  = self.VV6o35(mode, self.VVofBaData["playListURL"], catID)
   txt, err = self.VV6PIg(qUrl)
   if not err:
    tList, err = self.VVnOYd(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VVBESO(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VVJMIx:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VVNOpf.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVOtIP:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VVNOpf.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVhKle:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VVNOpf.append((num, name, catID, ID, genre, catName, ext, cover))
 def VVi4YS(self, mode, toFind, title, VVHm3J, VVNOpf, threadCounter, threadTotal, threadErr):
  if VVNOpf:
   title = self.VVjPEh(mode, toFind)
   if mode == self.VVJMIx or mode == self.VVOtIP:
    if mode == self.VVOtIP : typ = "v"
    else          : typ = ""
    bName   = CCFXWw.VVuSjW_forBouquet(toFind)
    VVBmAn  = ("Play"     , boundFunction(self.VVAHRX, mode)    , [])
    VVtony = ("Download Options" , boundFunction(self.VVQdrB, mode, typ, ""), [])
    VVKCEj = ("Options" , boundFunction(self.VVD8QS, 1, "fnd", mode, bName)  , [])
   elif mode == self.VVhKle:
    VVBmAn  = ("Show Seasons"  , boundFunction(self.VVBKbF, mode)    , [])
    VVKCEj = None
    VVtony = None
   VVscS4  = (""     , boundFunction(self.VV7nZN, mode)    , [])
   VVCAcJ  = ("Home Menu"   , FFurHP            , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVbtsV  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVapBp = FFMNGj(self, None, title=title, header=header, VVYDUR=VVNOpf, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=26, VVBmAn=VVBmAn, VVCAcJ=VVCAcJ, VVtony=VVtony, VVKCEj=VVKCEj, VVscS4=VVscS4, VVRbex="#0a00292B", VVihVe="#0a002126", VVwsQj="#0a002126", VVzAxe="#00000000", VViKTA=True, searchCol=1)
   if not VVHm3J:
    FF6E92(VVapBp, "Stopped" , 1000)
  else:
   if VVHm3J:
    FFf3zP(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVew5D(self, mode, colList):
  if mode in (self.VVJMIx, self.VVLS2z):
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVOtIP:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFjaTr(chName)
  url = self.VVofBaData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVmypn(url)
  refCode = self.VV17ho(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VV7nZN(self, mode, VVapBp, title, txt, colList):
  FFshid(VVapBp, boundFunction(self.VVPdBa, mode, VVapBp, title, txt, colList))
 def VVPdBa(self, mode, VVapBp, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVew5D(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFMw5O(self, fncMode=CCkvvO.VVU1OD, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVPrNx(self, mode, VVapBp, title, txt, colList):
  FFshid(VVapBp, boundFunction(self.VV3f2j, mode, VVapBp, title, txt, colList))
 def VV3f2j(self, mode, VVapBp, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFMw5O(self, fncMode=CCkvvO.VVQ7Sa, chName=name, text=txt, picUrl=Cover)
 def VV52WJ(self, mode, bName, VVapBp, title, txt, colList):
  url = self.VVofBaData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVmypn(url)
  bNameFile = CCFXWw.VVuSjW_forBouquet(bName)
  num  = 0
  path = VVF0QF + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVF0QF + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   isMulti = VVapBp.VVBMjk
   for ndx, row in enumerate(VVapBp.VVsv7I()):
    chName, chUrl, picUrl, refCode = self.VVew5D(mode, row)
    if not isMulti or VVapBp.VVZWda(ndx):
     f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
     f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
     totChange += 1
  FFodem(os.path.basename(path))
  self.VVT2o4(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVQdrB(self, mode, typ, seriesName, VVapBp, title, txt, colList):
  VV23GK = []
  isMulti = VVapBp.VVBMjk
  tot  = VVapBp.VVoHzk()
  if isMulti:
   if tot < 1:
    FF6E92(VVapBp, "Select rows first.", 1000)
    return
   else:
    s = "s" if tot > 1 else ""
    name = "%d Selected" % tot
  else:
   s = "s"
   name = "ALL"
  VV23GK.append(("Download %s PIcon%s" % (name, s), "dnldPicons" ))
  if typ:
   VV23GK.append(VV15MX)
   tName = "Movie" if typ.startswith("v") else "Series"
   VV23GK.append(("Download Current %s" % tName    , "dnldSel"  ))
   VV23GK.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VV23GK.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCe2k3.VVlmfj():
    VV23GK.append(VV15MX)
    VV23GK.append(("Download Manager"      , "dload_stat" ))
  FFdX2v(self, boundFunction(self.VVVYXc_VVwcFg, VVapBp, mode, typ, seriesName, colList), title="Download Options", VV23GK=VV23GK)
 def VVVYXc_VVwcFg(self, VVapBp, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVgkUK(VVapBp, mode)
   elif item == "dnldSel"  : self.VV6L6S(VVapBp, mode, typ, colList, True)
   elif item == "addSel"  : self.VV6L6S(VVapBp, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVnBTn(VVapBp, mode, typ, seriesName)
   elif item == "dload_stat" : CCe2k3.VVLmGk(self)
 def VV6L6S(self, VVapBp, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVekQ8(mode, typ, colList)
  if startDnld:
   CCe2k3.VVtBAK_url(self, decodedUrl)
  else:
   self.VVwcFg_FFCKL0(VVapBp, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVnBTn(self, VVapBp, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVapBp.VVsv7I():
   chName, decodedUrl = self.VVekQ8(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVwcFg_FFCKL0(VVapBp, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVwcFg_FFCKL0(self, VVapBp, title, chName, decodedUrl_list, startDnld):
  FFCKL0(self, boundFunction(self.VVgBzT, VVapBp, decodedUrl_list, startDnld), chName, title=title)
 def VVgBzT(self, VVapBp, decodedUrl_list, startDnld):
  added, skipped = CCe2k3.VVh2sKList(decodedUrl_list)
  FF6E92(VVapBp, "Added", 1000)
 def VVekQ8(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVew5D(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVm5Ln(mode, colList)
   refCode, chUrl = self.VVWEI2(self.VVZSl1, self.VVUfNV, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFz3ec(chUrl)
  return chName, decodedUrl
 def VVgkUK(self, VVapBp, mode):
  if os.system(FFrWND("which ffmpeg")) == 0:
   self.session.open(CCoBfV, barTheme=CCoBfV.VVBzoi
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VVXW2z, VVapBp, mode)
       , VVRMfQ = self.VVwVCi)
  else:
   FFCKL0(self, boundFunction(CCFXWw.VVWYQd, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVwVCi(self, VVHm3J, VVNOpf, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVNOpf["proces"], VVNOpf["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVNOpf["ok"], VVNOpf["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVNOpf["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVNOpf["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVNOpf["badURL"]
  txt += "Download Failure\t: %d\n"   % VVNOpf["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVNOpf["path"]
  if not VVHm3J  : color = "#11402000"
  elif VVNOpf["err"]: color = "#11201000"
  else     : color = None
  if VVNOpf["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVNOpf["err"], txt)
  title = "PIcons Download Result"
  if not VVHm3J:
   title += "  (cancelled)"
  FF9Qkx(self, txt, title=title, VVwsQj=color)
 def VVXW2z(self, VVapBp, mode, progBarObj):
  isMulti = VVapBp.VVBMjk
  if isMulti : totRows = VVapBp.VVoHzk()
  else  : totRows = VVapBp.VV4jLZ()
  progBarObj.VVOeug(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CCkYaA.VVN8ry()
  progBarObj.VVNOpf = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for rowNum, row in enumerate(VVapBp.VVsv7I()):
    if progBarObj.isCancelled:
     break
    if not isMulti or VVapBp.VVZWda(rowNum):
     progBarObj.VVNOpf["proces"] += 1
     progBarObj.VVzPrH(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVm5Ln(mode, row)
      refCode = CCFXWw.VV17ho(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VV1Zh0(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVew5D(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       progBarObj.VVNOpf["attempt"] += 1
       path, err = FF2QcO(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        progBarObj.VVNOpf["ok"] += 1
        if FFHtxR(path) > 0:
         cmd = ""
         if not mode == CCFXWw.VVJMIx:
          cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
         cmd += FFrWND("mv -f '%s' '%s'" % (path, pPath)) + ";"
         os.system(cmd)
        else:
         progBarObj.VVNOpf["size0"] += 1
         os.system(FFrWND("rm -f '%s'" % path))
       elif err:
        progBarObj.VVNOpf["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         progBarObj.VVNOpf["err"] = err.title()
         break
      else:
       progBarObj.VVNOpf["exist"] += 1
     else:
      progBarObj.VVNOpf["badURL"] += 1
  except:
   pass
 @staticmethod
 def VVWYQd(SELF):
  cmd = FFHppj(VV5wtI, "ffmpeg")
  if cmd : FFmkwf(SELF, cmd, title="Installing FFmpeg")
  else : FFywk7(SELF)
 def VVoxfD(self):
  self.session.open(CCoBfV, barTheme=CCoBfV.VVBzoi
      , titlePrefix = ""
      , fncToRun  = self.VV8D3W
      , VVRMfQ = self.VVlmOL)
 def VV8D3W(self, progBarObj):
  bName = FFw4PJ()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  progBarObj.VVNOpf = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = FFe78W()
  if not progBarObj or progBarObj.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   progBarObj.VVOeug(totCh)
   for serv in services:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVzPrH(1)
    progBarObj.VVinHX_fromImportEPG(totEpgOK, uChName)
    fullRef  = serv[0]
    if FFzYwA(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFz3ec(fullRef)
     span = iSearch(r"(mode=.+end=)", fullRef, IGNORECASE)
     if span:
      m3u_Url = CC5PGk.VVJtiS(fullRef)
      uType, uHost, uUser, uPass, uId, uChName  = CCFXWw.VVdr9M(fullRef)
      uType, uHost, uUser, uPass, uId, uChName1 = CCFXWw.VVdr9M(m3u_Url)
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCFXWw.VVdr9M(m3u_Url)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCFXWw.VVCHH5(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCkvvO.VVE0KW(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
      else:
       pass
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if progBarObj:
     progBarObj.VVNOpf = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   progBarObj.VVNOpf = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VVlmOL(self, VVHm3J, VVNOpf, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVNOpf
  title = "IPTV EPG Import"
  if err:
   FFf3zP(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFhqic(str(totNotIptv), VVd9bM)
    if totServErr : txt += "Server Errors\t: %s\n" % FFhqic(str(totServErr) + t1, VVd9bM)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFhqic(str(totInv), VVd9bM)
   if not VVHm3J:
    title += "  (stopped)"
   FF9Qkx(self, txt, title=title)
 @staticmethod
 def VVCHH5(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCFXWw.VVmypn(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCFXWw.VV6PIg(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCFXWw.VV51wI(item, "description" , is_base64=True ).replace("\n", " .. ")
    has_archive   = CCFXWw.VV51wI(item, "has_archive"      )
    lang    = CCFXWw.VV51wI(item, "lang"        ).upper()
    now_playing   = CCFXWw.VV51wI(item, "now_playing"      )
    start    = CCFXWw.VV51wI(item, "start"        )
    start_timestamp  = CCFXWw.VV51wI(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCFXWw.VV51wI(item, "start_timestamp"     )
    stop_timestamp  = CCFXWw.VV51wI(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCFXWw.VV51wI(item, "stop_timestamp"      )
    tTitle    = CCFXWw.VV51wI(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VV17ho(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCFXWw.VV1KfJ(catID, MAX_4b)
  TSID = CCFXWw.VV1KfJ(chNum, MAX_4b)
  ONID = CCFXWw.VV1KfJ(chNum, MAX_4b)
  NS  = CCFXWw.VV1KfJ(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VV1KfJ(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVuSjW_forBouquet(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVUdFN(mode):
  if   mode in ("itv"  , CCFXWw.VVGUIN)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCFXWw.VVabIB)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCFXWw.VVoKXD) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCFXWw.VVwwTK) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCFXWw.VVLS2z    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 @staticmethod
 def VVtugE(orExportPath=False):
  path = CFG.iptvHostsPath.getValue()
  if not pathExists(path) or path == VVKvlq:
   if orExportPath : path = CFG.exportedTablesPath.getValue()
   else   : path ="/"
  return FFr9AH(path)
 @staticmethod
 def VVlkp7(SELF, hostUrl, chName, streamId, ok_fnc):
  title = "Catchup TV Programs"
  pList, err = CCFXWw.VVCHH5(hostUrl, streamId, True)
  if err:
   FFf3zP(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVRbex, VVihVe, VVwsQj, VVzAxe = CCFXWw.VVUdFN("")
   VVCAcJ = ("Home Menu" , FFurHP, [])
   VVBmAn  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVbtsV  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFMNGj(SELF, None, title="Programs for : " + chName, header=header, VVYDUR=pList, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=24, VVBmAn=VVBmAn, VVCAcJ=VVCAcJ, VVRbex=VVRbex, VVihVe=VVihVe, VVwsQj=VVwsQj, VVzAxe=VVzAxe)
  else:
   FFf3zP(SELF, "No Programs from server", title=title)
 @staticmethod
 def VV5Lwe(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 @staticmethod
 def VVIwFK(SELF, isPortal, line, VVoYT0Obj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCFXWw.VVtugE(orExportPath=True)
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFf3zP(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFTVfn(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFf3zP(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVD8QS(self, nameCol, source, mode, bName, VVapBp, title, txt, colList):
  isMulti = VVapBp.VVBMjk
  mSel = CClFPA(self, VVapBp, nameCol, addSep=False)
  title = ""
  if isMulti:
   tot = VVapBp.VVoHzk()
   if tot > 0:
    s = "s" if tot > 1 else ""
    title = "Add %d Service%s to Bouquet" % (tot, s)
  else:
   title = "Add ALL to Bouquet"
  if title:
   mSel.VV23GK.append(VV15MX)
   mSel.VV23GK.append((title        , "addToBoquet"))
  FFdX2v(self, boundFunction(self.VVIams, mSel, source, mode, bName, VVapBp, title, txt, colList), title="Options", VV23GK=mSel.VV23GK)
 def VVIams(self, mSelObj, source, mode, bName, VVapBp, title, txt, colList, item):
  if item:
   if   item == "multSelEnab"     : mSelObj.VVapBp.VVBnQy(True)
   elif item == "MultSelDisab"     : mSelObj.VVapBp.VVBnQy(False)
   elif item == "selectAll"     : mSelObj.VVapBp.VV6QlI()
   elif item == "unselectAll"     : mSelObj.VVapBp.VVphsY()
   elif item == "addToBoquet"     :
    if   source == "pEp" : fnc = self.VVmume
    elif source == "pCh" : fnc = self.VVmume
    elif source == "m3Ch" : fnc = self.VVPmlf
    elif source == "lv"  : fnc = self.VV52WJ
    elif source == "v"  : fnc = self.VV52WJ
    elif source == "s"  : fnc = self.VV52WJ
    elif source == "fnd" : fnc = self.VV52WJ
    else     : return
    FFshid(VVapBp, boundFunction(fnc, mode, bName, VVapBp, title, txt, colList), title="Adding Channels ...")
class CC2t4f(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFSDka(VVTY88, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVTP2w  = 0
  self.VV7VVk = 1
  self.VVzWGb  = 2
  VV23GK = []
  VV23GK.append(("Find in All Service (from filter)" , "VVcaxk" ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Find in All (Manual Entry)"   , "VV84Vf"    ))
  VV23GK.append(("Find in TV"       , "VVfkpV"    ))
  VV23GK.append(("Find in Radio"      , "VV4c8z"   ))
  if self.VVGc0s():
   VV23GK.append(VV15MX)
   VV23GK.append(("Hide Channel: %s" % self.servName , "VVTJdC"   ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Zap History"       , "VV4rKf"    ))
  VV23GK.append(VV15MX)
  VV23GK.append(("IPTV Tools"       , "iptv"      ))
  VV23GK.append(("PIcons Tools"       , "PIconsTools"     ))
  VV23GK.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FFyutK(self, VV23GK=VV23GK, title=title)
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FFTEKh(self["myMenu"])
  FFm42V(self)
  if self.isFindMode:
   self.VVWJDq(self.VVekPT())
 def VVNPMZ(self):
  global VV10fA
  VV10fA = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VV84Vf"    : self.VV84Vf()
   elif item == "VVcaxk" : self.VVcaxk()
   elif item == "VVfkpV"    : self.VVfkpV()
   elif item == "VV4c8z"   : self.VV4c8z()
   elif item == "VVTJdC"   : self.VVTJdC()
   elif item == "VV4rKf"    : self.VV4rKf()
   elif item == "iptv"       : self.session.open(CCFXWw)
   elif item == "PIconsTools"     : self.session.open(CCkYaA)
   elif item == "ChannelsTools"    : self.session.open(CCLPQZ)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVfkpV(self) : self.VVWJDq(self.VVTP2w)
 def VV4c8z(self) : self.VVWJDq(self.VV7VVk)
 def VV84Vf(self) : self.VVWJDq(self.VVzWGb)
 def VVWJDq(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFnG6g(self, boundFunction(self.VV5RVm, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVcaxk(self):
  filterObj = CClJqP(self)
  filterObj.VVpDfj(self.VV6tGH)
 def VV6tGH(self, item):
  self.VV5RVm(self.VVzWGb, item)
 def VVGc0s(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFzYwA(self.refCode)        : return False
  return True
 def VV5RVm(self, mode, VVgpft):
  FFshid(self, boundFunction(self.VVDH38, mode, VVgpft), title="Searching ...")
 def VVDH38(self, mode, VVgpft):
  if VVgpft:
   self.findTxt = VVgpft
   if   mode == self.VVTP2w  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VV7VVk : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVgpft)
   if len(title) > 55:
    title = title[:55] + ".."
   VVKG2e = self.VV4Yil(VVgpft, servTypes)
   if self.isFindMode or mode == self.VVzWGb:
    VVKG2e += self.VVUzoi(VVgpft)
   if VVKG2e:
    VVKG2e.sort(key=lambda x: x[0].lower())
    VVyVHa = self.VVXAQg
    VVBmAn  = ("Zap"   , self.VV5JUP    , [])
    VVtony = ("Current Service", self.VVkiOF , [])
    VVKCEj = ("Options"  , self.VVTHVt , [])
    VVscS4 = (""    , self.VV9RiR , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVbtsV  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFMNGj(self, None, title=title, header=header, VVYDUR=VVKG2e, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=26, VVBmAn=VVBmAn, VVyVHa=VVyVHa, VVtony=VVtony, VVKCEj=VVKCEj, VVscS4=VVscS4)
   else:
    self.VVWJDq(self.VVekPT())
    FFTVfn(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VV4Yil(self, VVgpft, servTypes):
  VVXeyN  = eServiceCenter.getInstance()
  VVaNbq   = '%s ORDER BY name' % servTypes
  VVAZkD   = eServiceReference(VVaNbq)
  VVXEI6 = VVXeyN.list(VVAZkD)
  if VVXEI6: VVYDUR = VVXEI6.getContent("CN", False)
  else     : VVYDUR = None
  VVKG2e = []
  if VVYDUR:
   VVkKMa, VVIZdu = FFCiCm()
   tp   = CCqMXo()
   words, asPrefix = CClJqP.VVFtXI(VVgpft)
   colorYellow  = CCtme9.VVLf2h(VVAjxB)
   colorWhite  = CCtme9.VVLf2h(VVX9gW)
   for s in VVYDUR:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FF3fRh(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVkKMa:
        STYPE = VVIZdu[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVlM9z(refCode)
       if not "-S" in syst:
        sat = syst
       VVKG2e.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVKG2e
 def VVUzoi(self, VVgpft):
  VVgpft = VVgpft.lower()
  VVXYvE = FF1HUL()
  VVKG2e = []
  colorYellow  = CCtme9.VVLf2h(VVAjxB)
  colorWhite  = CCtme9.VVLf2h(VVX9gW)
  if VVXYvE:
   for b in VVXYvE:
    VV4moU  = b[0]
    VVcmgi  = b[1].toString()
    VVxOKd = eServiceReference(VVcmgi)
    VVOPhm = FFho3z(VVxOKd)
    for service in VVOPhm:
     refCode  = service[0]
     if FFzYwA(refCode):
      servName = service[1]
      if VVgpft in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VVgpft), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VVKG2e.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVKG2e
 def VVekPT(self):
  VVKFsj = InfoBar.instance
  if VVKFsj:
   VV0yB9 = VVKFsj.servicelist
   if VV0yB9:
    return VV0yB9.mode == 1
  return self.VVzWGb
 def VVXAQg(self, VVapBp):
  self.close()
  VVapBp.cancel()
 def VV5JUP(self, VVapBp, title, txt, colList):
  FFjNnf(VVapBp, colList[2], VVOpaL=False, checkParentalControl=True)
 def VVkiOF(self, VVapBp, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(VVapBp)
  if refCode:
   VVapBp.VVdBnG(2, FFdrTi(refCode, iptvRef, chName), True)
 def VVTHVt(self, VVapBp, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CClFPA(self, VVapBp, 2)
  mSel.VV98Tl(servName, refCode)
 def VV9RiR(self, VVapBp, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFMw5O(self, fncMode=CCkvvO.VVwSAD, refCode=refCode, chName=chName, text=txt)
 def VVTJdC(self):
  FFCKL0(self, self.VVPKPD, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVPKPD(self):
  ret = FFnI4b(self.refCode, True)
  if ret:
   self.VVb8T2()
   self.close()
  else:
   FF6E92(self, "Cannot change state" , 1000)
 def VVb8T2(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVs1Ry()
  except:
   self.VVD0kj()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFUl3V(self, serviceRef)
 def VVvcu4(self):
  VVKFsj = InfoBar.instance
  if VVKFsj:
   VV0yB9 = VVKFsj.servicelist
   if VV0yB9:
    VV0yB9.setMode()
 def VVs1Ry(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVKFsj = InfoBar.instance
   if VVKFsj:
    VV0yB9 = VVKFsj.servicelist
    if VV0yB9:
     hList = VV0yB9.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VV0yB9.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VV0yB9.history  = newList
       VV0yB9.history_pos = pos
 def VVD0kj(self):
  VVKFsj = InfoBar.instance
  if VVKFsj:
   VV0yB9 = VVKFsj.servicelist
   if VV0yB9:
    VV0yB9.history  = []
    VV0yB9.history_pos = 0
 def VV4rKf(self):
  VVKFsj = InfoBar.instance
  VVKG2e = []
  if VVKFsj:
   VV0yB9 = VVKFsj.servicelist
   if VV0yB9:
    VVkKMa, VVIZdu = FFCiCm()
    for chParams in VV0yB9.history:
     refCode = chParams[-1].toString()
     chName = FFYXgN(refCode)
     isIptv = FFzYwA(refCode)
     if isIptv: sat = "-"
     else  : sat = FF3fRh(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVkKMa:
       STYPE = VVIZdu[sTypeInt]
     VVKG2e.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVKG2e:
   VVBmAn  = ("Zap"   , self.VVQDje   , [])
   VVKCEj = ("Clear History" , self.VVp5hD   , [])
   VVscS4 = (""    , self.VVge46FromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVbtsV  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFMNGj(self, None, title=title, header=header, VVYDUR=VVKG2e, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=28, VVBmAn=VVBmAn, VVKCEj=VVKCEj, VVscS4=VVscS4)
  else:
   FFTVfn(self, "Not found", title=title)
 def VVQDje(self, VVapBp, title, txt, colList):
  FFjNnf(VVapBp, colList[3], VVOpaL=False, checkParentalControl=True)
 def VVp5hD(self, VVapBp, title, txt, colList):
  FFCKL0(self, boundFunction(self.VV7avj, VVapBp), "Clear Zap History ?")
 def VV7avj(self, VVapBp):
  self.VVD0kj()
  VVapBp.cancel()
 def VVge46FromZapHistory(self, VVapBp, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFMw5O(self, fncMode=CCkvvO.VVbkFd, refCode=refCode, chName=chName, text=txt)
class CCkYaA(Screen):
 VVctPr   = 0
 VVt6w0  = 1
 VVvNtE  = 2
 VVq9pd  = 3
 VVPPXS  = 4
 VV2wzM  = 5
 VVFpql  = 6
 VVtT6w  = 7
 VVz9RP = 8
 VVrMuz = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFSDka(VV8VQv, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFyutK(self, self.Title)
  FFdk5e(self["keyRed"] , "OK = Zap")
  FFdk5e(self["keyGreen"] , "Current Service")
  FFdk5e(self["keyYellow"], "Page Options")
  FFdk5e(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCkYaA.VVN8ry()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVYDUR    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV3bNB        ,
   "green"   : self.VVDhax       ,
   "yellow"  : self.VVbxTW        ,
   "blue"   : self.VVG9dN        ,
   "menu"   : self.VVCH4d        ,
   "info"   : self.VVge46         ,
   "up"   : self.VVSS9D          ,
   "down"   : self.VVjpkT         ,
   "left"   : self.VVB1cC         ,
   "right"   : self.VVAeY3         ,
   "pageUp"  : boundFunction(self.VVn7Fs, True) ,
   "chanUp"  : boundFunction(self.VVn7Fs, True) ,
   "pageDown"  : boundFunction(self.VVn7Fs, False) ,
   "chanDown"  : boundFunction(self.VVn7Fs, False) ,
   "next"   : self.VVMhsB        ,
   "last"   : self.VVUbWj         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FFDx5r(self)
  FF22W2(self)
  FF6nEU(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFshid(self, boundFunction(self.VVQwMX, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVCH4d(self):
  if not self.isBusy:
   VV23GK = []
   VV23GK.append(("Statistics"           , "VVyEsJ"    ))
   VV23GK.append(VV15MX)
   VV23GK.append(("Suggest PIcons for Current Channel"     , "VVvLS2"   ))
   VV23GK.append(("Set to Current Channel (copy file)"     , "VV30Lw_file"  ))
   VV23GK.append(("Set to Current Channel (as SymLink)"     , "VV30Lw_link"  ))
   VV23GK.append(VV15MX)
   VV23GK.append(CCkYaA.VVK1fm())
   VV23GK.append(VV15MX)
   if self.filterTitle == "PIcons without Channels":
    c = VVd9bM
    VV23GK.append((FFhqic("Move Unused PIcons to a Directory", c) , "VVLF6r"  ))
    VV23GK.append((FFhqic("DELETE Unused PIcons", c)    , "VVeK0h" ))
    VV23GK.append(VV15MX)
   VV23GK.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVctOo"  ))
   VV23GK.append(VV15MX)
   VV23GK += CCkYaA.VV7ySE()
   VV23GK.append(VV15MX)
   VV23GK.append(("RCU Keys Help"          , "VVXFT8"    ))
   FFdX2v(self, self.VVVYXc, title=self.Title, VV23GK=VV23GK)
 def VVVYXc(self, item=None):
  if item is not None:
   if   item == "VVyEsJ"     : self.VVyEsJ()
   elif item == "VVvLS2"    : self.VVvLS2()
   elif item == "VV30Lw_file"   : self.VV30Lw(0)
   elif item == "VV30Lw_link"   : self.VV30Lw(1)
   elif item == "VVFaPh_file"  : self.VVFaPh(0)
   elif item == "VVFaPh_link"  : self.VVFaPh(1)
   elif item == "VVBlwl"   : self.VVBlwl()
   elif item == "VV4W3D"  : self.VV4W3D()
   elif item == "VVLF6r"    : self.VVLF6r()
   elif item == "VVeK0h"   : self.VVeK0h()
   elif item == "VVctOo"   : self.VVctOo()
   elif item == "VVFJIL"   : CCkYaA.VVFJIL(self)
   elif item == "VVxrPL"   : CCkYaA.VVxrPL(self)
   elif item == "findPiconBrokenSymLinks"  : CCkYaA.VVtT2k(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCkYaA.VVtT2k(self, False)
   elif item == "VVXFT8"      : self.VVXFT8()
 def VVbxTW(self):
  if not self.isBusy:
   VV23GK = []
   VV23GK.append(("Go to First PIcon"  , "VVT2wH"  ))
   VV23GK.append(("Go to Last PIcon"   , "VVBWeY"  ))
   VV23GK.append(VV15MX)
   VV23GK.append(("Sort by Channel Name"     , "sortByChan" ))
   VV23GK.append(("Sort by File Name"  , "sortByFile" ))
   VV23GK.append(VV15MX)
   VV23GK.append(("Find from File List .." , "VVoYVQ" ))
   FFdX2v(self, self.VVIIJ1, title=self.Title, VV23GK=VV23GK)
 def VVIIJ1(self, item=None):
  if item is not None:
   if   item == "VVT2wH"   : self.VVT2wH()
   elif item == "VVBWeY"   : self.VVBWeY()
   elif item == "sortByChan"  : self.VVKEBj(2)
   elif item == "sortByFile"  : self.VVKEBj(0)
   elif item == "VVoYVQ"  : self.VVoYVQ()
 def VVXFT8(self):
  FFiYdB(self, VVBZq2 + "_help_picons", "PIcons Manager (Keys Help)")
 def VVSS9D(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVBWeY()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVTDfw()
 def VVjpkT(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVT2wH()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVTDfw()
 def VVB1cC(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVBWeY()
  else:
   self.curCol -= 1
   self.VVTDfw()
 def VVAeY3(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVT2wH()
  else:
   self.curCol += 1
   self.VVTDfw()
 def VVUbWj(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVTDfw(True)
 def VVMhsB(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVTDfw(True)
 def VVT2wH(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVTDfw(True)
 def VVBWeY(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVTDfw(True)
 def VVoYVQ(self):
  VV23GK = []
  for item in self.VVYDUR:
   VV23GK.append((item[0], item[0]))
  FFdX2v(self, self.VVoOl4, title='PIcons ".png" Files', VV23GK=VV23GK, VVdwiN=True)
 def VVoOl4(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVHBB4(ndx)
 def VV3bNB(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVjF4c()
   if refCode:
    FFjNnf(self, refCode)
    self.VVloim()
    self.VVGs9H()
 def VVn7Fs(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVloim()
   self.VVGs9H()
  except:
   pass
 def VVDhax(self):
  if self["keyGreen"].getVisible():
   self.VVHBB4(self.curChanIndex)
 def VVHBB4(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVTDfw(True)
  else:
   FF6E92(self, "Not found", 1000)
 def VVKEBj(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFshid(self, boundFunction(self.VVQwMX, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VV30Lw(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVjF4c()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VV23GK = []
     VV23GK.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VV23GK.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFdX2v(self, boundFunction(self.VVl2Nd, mode, curChF, selPiconF), VV23GK=VV23GK, title="Current Channel PIcon (already exists)")
    else:
     self.VVl2Nd(mode, curChF, selPiconF, "overwrite")
   else:
    FFf3zP(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFf3zP(self, "Could not read current channel info. !", title=title)
 def VVl2Nd(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFshid(self, boundFunction(self.VVQwMX, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVFaPh(self, mode):
  pass
 def VVBlwl(self):
  pass
 def VV4W3D(self):
  pass
 def VVLF6r(self):
  defDir = FFr9AH(CCkYaA.VVN8ry() + "picons_backup")
  os.system(FFrWND("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(boundFunction(self.VV5grt, defDir), boundFunction(CCin0f
         , mode=CCin0f.VVgfa4, VVz9Oc=CCkYaA.VVN8ry()))
 def VV5grt(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCkYaA.VVN8ry():
    FFf3zP(self, "Cannot move to same directory !", title=title)
   else:
    if not FFr9AH(path) == FFr9AH(defDir):
     self.VVHUXK(defDir)
    FFCKL0(self, boundFunction(FFshid, self, boundFunction(self.VVOMPZ, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVYDUR), path), title=title)
  else:
   self.VVHUXK(defDir)
 def VVOMPZ(self, title, defDir, toPath):
  try:
   from shutil import move as iMove
  except:
   self.VVHUXK(defDir)
   FFf3zP(self, 'Could not load "shutil" module !', title=title)
   return
  toPath = FFr9AH(toPath)
  pPath = CCkYaA.VVN8ry()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVYDUR:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVYDUR)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FF9Qkx(self, txt, title=title, VVwsQj="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VV6ou2("all")
 def VVHUXK(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVeK0h(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVYDUR)
  s = "s" if tot > 1 else ""
  FFCKL0(self, boundFunction(FFshid, self, boundFunction(self.VVfPeq, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, s), title=title)
 def VVfPeq(self, title):
  pPath = CCkYaA.VVN8ry()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVYDUR:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVYDUR)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFhqic(str(totErr), VVd9bM)
  FF9Qkx(self, txt, title=title)
 def VVctOo(self):
  lines = FFIx6K("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFCKL0(self, boundFunction(self.VVc71I, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVCyqa=True)
  else:
   FFTVfn(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVc71I(self, fList):
  os.system(FFrWND("find -L '%s' -type l -delete" % self.pPath))
  FFTVfn(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVge46(self):
  FFshid(self, self.VVS0sA)
 def VVS0sA(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVjF4c()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFhqic("PIcon Directory:\n", VVxzLQ)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FFmr53(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFmr53(path)
   txt += FFhqic("PIcon File:\n", VVxzLQ)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFIx6K(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFhqic("Found %d SymLink%s to this file from:\n" % (tot, s), VVxzLQ)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFYXgN(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFhqic(tChName, VVUnli)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFhqic(line, VVcDYh), tChName)
    txt += "\n"
   if chName:
    txt += FFhqic("Channel:\n", VVxzLQ)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFhqic(chName, VVUnli)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFhqic("Remarks:\n", VVxzLQ)
    txt += "  %s\n" % FFhqic("Unused", VVd9bM)
  else:
   txt = "No info found"
  FFMw5O(self, fncMode=CCkvvO.VVlsQk, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVjF4c(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVYDUR[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFFD0p(sat)
  return fName, refCode, chName, sat, inDB
 def VVloim(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVYDUR):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVGs9H(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVjF4c()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFhqic("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVxzLQ))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVjF4c()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFhqic(self.curChanName, VVAjxB)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVyEsJ(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VVYDUR:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFjgvE("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FF9Qkx(self, txt, title=self.Title)
 def VVG9dN(self):
  if not self.isBusy:
   VV23GK = []
   VV23GK.append(("All"         , "all"   ))
   VV23GK.append(VV15MX)
   VV23GK.append(("Used by Channels"      , "used"  ))
   VV23GK.append(("Unused PIcons"      , "unused"  ))
   VV23GK.append(VV15MX)
   VV23GK.append(("PIcons Files"       , "pFiles"  ))
   VV23GK.append(("SymLinks to PIcons"     , "pLinks"  ))
   VV23GK.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VV23GK.append(VV15MX)
   VV23GK.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VV23GK.append(VV15MX)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FF3j6k(val)
      VV23GK.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CClJqP(self)
   filterObj.VVqg01(VV23GK, self.nsList, self.VVVNHD)
 def VVVNHD(self, item=None):
  if item is not None:
   self.VV6ou2(item)
 def VV6ou2(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVctPr   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVt6w0   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVvNtE  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVq9pd  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVPPXS  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VV2wzM  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVFpql   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVtT6w   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVz9RP , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VV2wzM:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFIx6K("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FF6E92(self, "Not found", 1000)
     return
   elif mode == self.VVrMuz:
    return
   else:
    words, asPrefix = CClJqP.VVFtXI(words)
   if not words and mode in (self.VVtT6w, self.VVz9RP):
    FF6E92(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFshid(self, boundFunction(self.VVQwMX, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVvLS2(self):
  self.session.open(CCoBfV, barTheme=CCoBfV.VVL4g0
      , titlePrefix = ""
      , fncToRun  = self.VVzSRM
      , VVRMfQ = self.VVVOBg)
 def VVzSRM(self, progBarObj):
  lameDbChans = CCLPQZ.VVlZYk(self, CCLPQZ.VVpDpg, VVCkoG=False, VVRxi8=False)
  files = []
  words = []
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVNOpf = []
  progBarObj.VVOeug(len(lameDbChans))
  if lameDbChans:
   processChanName = CC0WOt()
   curCh = processChanName.VVxYfv(self.curChanName)
   for refCode in lameDbChans:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVzPrH(1, True)
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCkYaA.VV5No4(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCkYaA.VV97P9(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       progBarObj.VVNOpf.append(f.replace(".png", ""))
 def VVVOBg(self, VVHm3J, VVNOpf, threadCounter, threadTotal, threadErr):
  if VVNOpf:
   self.timer = eTimer()
   fnc = boundFunction(FFshid, self, boundFunction(self.VVQwMX, mode=self.VVrMuz, words=VVNOpf), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FF6E92(self, "Not found", 2000)
 def VVQwMX(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVZdRG(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCLPQZ.VVlZYk(self, CCLPQZ.VVpDpg, VVCkoG=False, VVRxi8=False)
  iptvRefList = self.VVrGAy()
  tList = []
  for fName, fType in CCkYaA.VVDH7b(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVctPr:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVt6w0  and chName         : isAdd = True
   elif mode == self.VVvNtE and not chName        : isAdd = True
   elif mode == self.VVq9pd  and fType == 0        : isAdd = True
   elif mode == self.VVPPXS  and fType == 1        : isAdd = True
   elif mode == self.VV2wzM  and fName in words       : isAdd = True
   elif mode == self.VVrMuz and fName in words       : isAdd = True
   elif mode == self.VVFpql  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVtT6w  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVz9RP:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVYDUR   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FF6E92(self)
  else:
   self.isBusy = False
   FF6E92(self, "Not found", 1000)
   return
  self.VVYDUR.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVloim()
  self.totalPIcons = len(self.VVYDUR)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVTDfw(True)
 def VVZdRG(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCkYaA.VVDH7b(self.pPath):
    if fName:
     return True
   if isFirstTime : FFf3zP(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FF6E92(self, "Not found", 1000)
  else:
   FFf3zP(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVrGAy(self):
  VVKG2e = {}
  files  = CCFXWw.VVczEg(self)
  if files:
   for path in files:
    txt = FFp1Ek(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVKG2e[refCode] = item[1]
  return VVKG2e
 def VVTDfw(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVS5nj = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVS5nj: self.curPage = VVS5nj
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVO9Wa()
  if self.curPage == VVS5nj:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVGs9H()
  filName, refCode, chName, sat, inDB = self.VVjF4c()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVO9Wa(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVYDUR[ndx]
   fName = self.VVYDUR[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFhqic(chName, VVUnli))
    else : lbl.setText("-")
   except:
    lbl.setText(FFhqic(chName, VVB0Mu))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VV5No4(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVK1fm():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVFJIL"   )
 @staticmethod
 def VV7ySE():
  VV23GK = []
  VV23GK.append(("Find SymLinks (to PIcon Directory)"   , "VVxrPL"   ))
  VV23GK.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VV23GK.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VV23GK
 @staticmethod
 def VVFJIL(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(SELF)
  png, path = CCkYaA.VVGhjU(refCode)
  if path : CCkYaA.VVzRzt(SELF, png, path)
  else : FFf3zP(SELF, "No PIcon found for current channel in:\n\n%s" % CCkYaA.VVN8ry())
 @staticmethod
 def VVxrPL(SELF):
  if VVAjxB:
   sed1 = FF7UqE("->", VVAjxB)
   sed2 = FF7UqE("picon", VVd9bM)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVB0Mu, VVX9gW)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFeXoK(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FF2qZL(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVtT2k(SELF, isPIcon):
  sed1 = FF7UqE("->", VVB0Mu)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FF7UqE("picon", VVd9bM)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFeXoK(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FF2qZL(), grep, sed1, sed2))
 @staticmethod
 def VVDH7b(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVN8ry():
  path = CFG.PIconsPath.getValue()
  return FFr9AH(path)
 @staticmethod
 def VVGhjU(refCode, chName=None):
  if FFzYwA(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFz3ec(refCode)
  allPath, fName, refCodeFile, pList = CCkYaA.VV97P9(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVzRzt(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FF7UqE("%s%s" % (dest, png), VVUnli))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FF7UqE(errTxt, VVf5u2))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFpzYC(SELF, cmd)
 @staticmethod
 def VV97P9(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCkYaA.VVN8ry()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFjaTr(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCXfQM():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVGb3e  = None
  self.VVYH11 = ""
  self.VV3zU6  = noService
  self.VV8eko = 0
  self.VV77qH  = noService
  self.VVMeS4 = 0
  self.VVZ8sY  = "-"
  self.VVujvk = 0
  self.VV3afj  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVKCQj(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVGb3e = frontEndStatus
     self.VVr7XL()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVr7XL(self):
  if self.VVGb3e:
   val = self.VVGb3e.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVYH11 = "%3.02f dB" % (val / 100.0)
   else         : self.VVYH11 = ""
   val = self.VVGb3e.get("tuner_signal_quality", 0) * 100 / 65536
   self.VV8eko = int(val)
   self.VV3zU6  = "%d%%" % val
   val = self.VVGb3e.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVMeS4 = int(val)
   self.VV77qH  = "%d%%" % val
   val = self.VVGb3e.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVZ8sY  = "%d" % val
   val = int(val * 100 / 500)
   self.VVujvk = min(500, val)
   val = self.VVGb3e.get("tuner_locked", 0)
   if val == 1 : self.VV3afj = "Locked"
   else  : self.VV3afj = "Not locked"
 def VVfFmL(self)   : return self.VVYH11
 def VVARd1(self)   : return self.VV3zU6
 def VVNys1(self)  : return self.VV8eko
 def VVxtRA(self)   : return self.VV77qH
 def VVFr88(self)  : return self.VVMeS4
 def VVyMWx(self)   : return self.VVZ8sY
 def VV4MaF(self)  : return self.VVujvk
 def VVVdDN(self)   : return self.VV3afj
 def VVannA(self) : return self.serviceName
class CCqMXo():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVCCu8(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFqYNr(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVQ6Ii(self.ORPOS  , mod=1   )
      self.sat2  = self.VVQ6Ii(self.ORPOS  , mod=2   )
      self.freq  = self.VVQ6Ii(self.FREQ  , mod=3   )
      self.sr   = self.VVQ6Ii(self.SR   , mod=4   )
      self.inv  = self.VVQ6Ii(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVQ6Ii(self.POL  , self.D_POL )
      self.fec  = self.VVQ6Ii(self.FEC  , self.D_FEC )
      self.syst  = self.VVQ6Ii(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVQ6Ii("modulation" , self.D_MOD )
       self.rolof = self.VVQ6Ii("rolloff"  , self.D_ROLOF )
       self.pil = self.VVQ6Ii("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVQ6Ii("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVQ6Ii("pls_code"  )
       self.iStId = self.VVQ6Ii("is_id"   )
       self.t2PlId = self.VVQ6Ii("t2mi_plp_id" )
       self.t2PId = self.VVQ6Ii("t2mi_pid"  )
 def VVQ6Ii(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FF3j6k(val)
  elif mod == 2   : return FFjHtS(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVK0cj(self, refCode):
  txt = ""
  self.VVCCu8(refCode)
  if self.data:
   def VVXwkx(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVXwkx("System"   , self.syst)
    txt += VVXwkx("Satellite"  , self.sat2)
    txt += VVXwkx("Frequency"  , self.freq)
    txt += VVXwkx("Inversion"  , self.inv)
    txt += VVXwkx("Symbol Rate"  , self.sr)
    txt += VVXwkx("Polarization" , self.pol)
    txt += VVXwkx("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVXwkx("Modulation" , self.mod)
     txt += VVXwkx("Roll-Off" , self.rolof)
     txt += VVXwkx("Pilot"  , self.pil)
     txt += VVXwkx("Input Stream", self.iStId)
     txt += VVXwkx("T2MI PLP ID" , self.t2PlId)
     txt += VVXwkx("T2MI PID" , self.t2PId)
     txt += VVXwkx("PLS Mode" , self.plsMod)
     txt += VVXwkx("PLS Code" , self.plsCod)
   else:
    txt += VVXwkx("System"   , self.txMedia)
    txt += VVXwkx("Frequency"  , self.freq)
  return txt, self.namespace
 def VVFILp(self, refCode):
  txt = "Transpoder : ?"
  self.VVCCu8(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VVxzLQ + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVlM9z(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFqYNr(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVQ6Ii(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVQ6Ii(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVQ6Ii(self.SYST, self.D_SYS_S)
     freq = self.VVQ6Ii(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVQ6Ii(self.POL , self.D_POL)
      fec = self.VVQ6Ii(self.FEC , self.D_FEC)
      sr = self.VVQ6Ii(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVTNDX(self, refCode):
  self.data = None
  self.VVCCu8(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCUORs():
 def __init__(self, VVAyPa, path, VVRMfQ=None, curRowNum=-1):
  self.VVAyPa  = VVAyPa
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVRMfQ  = VVRMfQ
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFrWND("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VV3E9U(curRowNum)
  else:
   FFf3zP(self.VVAyPa, "Error while preparing edit!")
 def VV3E9U(self, curRowNum):
  VVKG2e = self.VVzFZG()
  VVCAcJ = None #("Delete Line" , self.deleteLine  , [])
  VVtony = ("Save Changes" , self.VVgjLV   , [])
  VVBmAn  = ("Edit Line"  , self.VVftKL    , [])
  VVwFPr = ("Line Options" , self.VVRTBo   , [])
  VVd4rs = (""    , self.VVs9aw , [])
  VVyVHa = self.VVnVP2
  VVV8bN  = self.VVMxBI
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVbtsV  = (CENTER  , LEFT  )
  VVapBp = FFMNGj(self.VVAyPa, None, title=self.Title, header=header, VVYDUR=VVKG2e, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=26, VVCAcJ=VVCAcJ, VVtony=VVtony, VVBmAn=VVBmAn, VVwFPr=VVwFPr, VVyVHa=VVyVHa, VVV8bN=VVV8bN, VVd4rs=VVd4rs, VViKTA=True
    , VVRbex   = "#11001111"
    , VVihVe   = "#11001111"
    , VVwsQj   = "#11001111"
    , VVzAxe  = "#05333333"
    , VVrSmG  = "#00222222"
    , VVIRVU  = "#11331133"
    )
  VVapBp.VVuO0F(curRowNum)
 def VVRTBo(self, VVapBp, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVapBp.VVSx26()
  VV23GK = []
  VV23GK.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VV23GK.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVN7qC"  ))
  VV23GK.append(VV15MX)
  VV23GK.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVPKgK:
   VV23GK.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VV23GK.append(VV15MX)
  VV23GK.append(  ("Delete Line"         , "deleteLine"   ))
  FFdX2v(self.VVAyPa, boundFunction(self.VVrbsO, VVapBp, lineNum), VV23GK=VV23GK, title="Line Options")
 def VVrbsO(self, VVapBp, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVKy12("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVapBp)
   elif item == "VVN7qC"  : self.VVN7qC(VVapBp, lineNum)
   elif item == "copyToClipboard"  : self.VV3W8C(VVapBp, lineNum)
   elif item == "pasteFromClipboard" : self.VVne9V(VVapBp, lineNum)
   elif item == "deleteLine"   : self.VVKy12("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVapBp)
 def VVMxBI(self, VVapBp):
  VVapBp.VVx5Ai()
 def VVs9aw(self, VVapBp, title, txt, colList):
  if   self.insertMode == 1: VVapBp.VV910I()
  elif self.insertMode == 2: VVapBp.VVOPtk()
  self.insertMode = 0
 def VVN7qC(self, VVapBp, lineNum):
  if lineNum == VVapBp.VVSx26():
   self.insertMode = 1
   self.VVKy12("echo '' >> '%s'" % self.tmpFile, VVapBp)
  else:
   self.insertMode = 2
   self.VVKy12("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVapBp)
 def VV3W8C(self, VVapBp, lineNum):
  global VVPKgK
  VVPKgK = FFjgvE("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVapBp.VV1J0Q("Copied to clipboard")
 def VVgjLV(self, VVapBp, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFrWND("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFrWND("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVapBp.VV1J0Q("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVapBp.VVx5Ai()
    else:
     FFf3zP(self.VVAyPa, "Cannot save file!")
   else:
    FFf3zP(self.VVAyPa, "Cannot create backup copy of original file!")
 def VVnVP2(self, VVapBp):
  if self.fileChanged:
   FFCKL0(self.VVAyPa, boundFunction(self.VVrHiY, VVapBp), "Cancel changes ?")
  else:
   finalOK = os.system(FFrWND("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVrHiY(VVapBp)
 def VVrHiY(self, VVapBp):
  VVapBp.cancel()
  os.system(FFrWND("rm -f '%s'" % self.tmpFile))
  if self.VVRMfQ:
   self.VVRMfQ(self.fileSaved)
 def VVftKL(self, VVapBp, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVX9gW + "ORIGINAL TEXT:\n" + VVcDYh + lineTxt
  FFnG6g(self.VVAyPa, boundFunction(self.VVLLbj, lineNum, VVapBp), title="File Line", defaultText=lineTxt, message=message)
 def VVLLbj(self, lineNum, VVapBp, VVZ6mF):
  if not VVZ6mF is None:
   if VVapBp.VVSx26() <= 1:
    self.VVKy12("echo %s > '%s'" % (VVZ6mF, self.tmpFile), VVapBp)
   else:
    self.VV5I7z(VVapBp, lineNum, VVZ6mF)
 def VVne9V(self, VVapBp, lineNum):
  if lineNum == VVapBp.VVSx26() and VVapBp.VVSx26() == 1:
   self.VVKy12("echo %s >> '%s'" % (VVPKgK, self.tmpFile), VVapBp)
  else:
   self.VV5I7z(VVapBp, lineNum, VVPKgK)
 def VV5I7z(self, VVapBp, lineNum, newTxt):
  VVapBp.VV3Sbk("Saving ...")
  lines = FF8ZwU(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVapBp.VV7T41()
  VVKG2e = self.VVzFZG()
  VVapBp.VVs7In(VVKG2e)
 def VVKy12(self, cmd, VVapBp):
  tCons = CCPLjr()
  tCons.ePopen(cmd, boundFunction(self.VVYaXI, VVapBp))
  self.fileChanged = True
  VVapBp.VV7T41()
 def VVYaXI(self, VVapBp, result, retval):
  VVKG2e = self.VVzFZG()
  VVapBp.VVs7In(VVKG2e)
 def VVzFZG(self):
  if fileExists(self.tmpFile):
   lines = FF8ZwU(self.tmpFile)
   VVKG2e = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVKG2e.append((str(ndx), line.strip()))
   if not VVKG2e:
    VVKG2e.append((str(1), ""))
   return VVKG2e
  else:
   FFxtzL(self.VVAyPa, self.tmpFile)
class CClJqP():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VV23GK   = []
  self.satList   = []
 def VVpDfj(self, VVRMfQ):
  self.VV23GK = []
  VV23GK, VVYZJx = self.VVvuAu(False, True)
  if VV23GK:
   self.VV23GK += VV23GK
   self.VVgo83(VVRMfQ, VVYZJx)
 def VVepCf(self, mode, VVapBp, satCol, VVRMfQ):
  VVapBp.VV3Sbk("Loading Filters ...")
  self.VV23GK = []
  self.VV23GK.append(("All Services" , "all"))
  if mode == 1:
   self.VV23GK.append(VV15MX)
   self.VV23GK.append(("Parental Control", "parentalControl"))
   self.VV23GK.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VV23GK.append(VV15MX)
   self.VV23GK.append(("Selected Transponder"   , "selectedTP" ))
   self.VV23GK.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVHPvW(VVapBp, satCol)
  VV23GK, VVYZJx = self.VVvuAu(True, False)
  if VV23GK:
   VV23GK.insert(0, VV15MX)
   self.VV23GK += VV23GK
  VVapBp.VVP0Av()
  self.VVgo83(VVRMfQ, VVYZJx)
 def VVqg01(self, VV23GK, sats, VVRMfQ):
  self.VV23GK = VV23GK
  VV23GK, VVYZJx = self.VVvuAu(True, False)
  if VV23GK:
   self.VV23GK.append(VV15MX)
   self.VV23GK += VV23GK
  self.VVgo83(VVRMfQ, VVYZJx)
 def VVgo83(self, VVRMfQ, VVYZJx):
  VVrMQs = ("Edit Filter", boundFunction(self.VVl548, VVYZJx))
  VVvFvy  = ("Filter Help", boundFunction(self.VVm7zm, VVYZJx))
  FFdX2v(self.callingSELF, boundFunction(self.VVgntv, VVRMfQ), VV23GK=self.VV23GK, title="Select Filter", VVrMQs=VVrMQs, VVvFvy=VVvFvy)
 def VVgntv(self, VVRMfQ, item):
  if item:
   VVRMfQ(item)
 def VVl548(self, VVYZJx, VVoYT0Obj, sel):
  if fileExists(VVYZJx) : CCUORs(self.callingSELF, VVYZJx, VVRMfQ=None)
  else       : FFxtzL(self.callingSELF, VVYZJx)
  VVoYT0Obj.cancel()
 def VVm7zm(self, VVYZJx, VVoYT0Obj, sel):
  FFiYdB(self.callingSELF, VVBZq2 + "_help_service_filter", "Service Filter")
 def VVHPvW(self, VVapBp, satColNum):
  if not self.satList:
   satList = VVapBp.VVHEz0(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFFD0p(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VV15MX)
  if self.VV23GK:
   self.VV23GK += self.satList
 def VVvuAu(self, addTag, VVHov8):
  FFsIwZ()
  fileName  = "ajpanel_services_filter"
  VVYZJx = VVXukQ + fileName
  VV23GK  = []
  if not fileExists(VVYZJx):
   os.system(FFrWND("cp -f '%s' '%s'" % (VVBZq2 + fileName, VVYZJx)))
  fileFound = False
  if fileExists(VVYZJx):
   fileFound = True
   lines = FF8ZwU(VVYZJx)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VV23GK.append((line, "__w__" + line))
       else  : VV23GK.append((line, line))
  if VVHov8:
   if   not fileFound : FFxtzL(self.callingSELF , VVYZJx)
   elif not VV23GK : FF8yum(self.callingSELF , VVYZJx)
  return VV23GK, VVYZJx
 @staticmethod
 def VVFtXI(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CClFPA():
 def __init__(self, callingSELF, VVapBp, refCodeColNum, addSep=True):
  self.callingSELF = callingSELF
  self.VVapBp = VVapBp
  self.refCodeColNum = refCodeColNum
  self.VV23GK = []
  iMulSel = self.VVapBp.VVROxa()
  if iMulSel : self.VV23GK.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VV23GK.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVapBp.VVoHzk()
  self.VV23GK.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VV23GK.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VV23GK.append(VV15MX)
 def VV4pyE(self, servName):
  tot = self.VVapBp.VVoHzk()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VV23GK.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVM7nw_multi" ))
  else    : self.VV23GK.append( ("Add to Bouquet : %s"      % servName , "VVM7nw_one" ))
 def VV98Tl(self, servName, refCode):
  self.VV4pyE(servName)
  self.VVeui3(servName, refCode)
 def VVRsLA(self, servName, refCode, pcState, hidState):
  isMulti = self.VVapBp.VVBMjk
  if isMulti:
   refCodeList = self.VVapBp.VVNzhg(3)
   if refCodeList:
    self.VV23GK.append(("Add Selection to Parental Control"    , "parentalControl_sel_add"  ))
    self.VV23GK.append(("Remove Selection from Parental Control"   , "parentalControl_sel_remove" ))
    self.VV23GK.append(VV15MX)
    self.VV23GK.append(("Add Selection to Hidden Services"    , "hiddenServices_sel_add"  ))
    self.VV23GK.append(("Remove Selection from Hidden Services"   , "hiddenServices_sel_remove" ))
   else:
    self.VV23GK.pop(len(self.VV23GK) - 1)
  else:
   if pcState == "No" : self.VV23GK.append(("Add to Parental Control"  , "parentalControl_add"   ))
   else    : self.VV23GK.append(("Remove from Parental Control" , "parentalControl_remove"  ))
   self.VV23GK.append(VV15MX)
   if hidState == "No" : self.VV23GK.append(("Add to Hidden Services"  , "hiddenServices_add"   ))
   else    : self.VV23GK.append(("Remove from Hidden Services" , "hiddenServices_remove"  ))
  self.VV23GK.append(VV15MX)
  self.VV4pyE(servName)
  self.VVeui3(servName, refCode)
 def VVeui3(self, servName, refCode):
  FFdX2v(self.callingSELF, boundFunction(self.VV2jGO, servName, refCode), title="Options", VV23GK=self.VV23GK)
 def VV2jGO(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"     : self.VVapBp.VVBnQy(True)
   elif item == "MultSelDisab"     : self.VVapBp.VVBnQy(False)
   elif item == "selectAll"     : self.VVapBp.VV6QlI()
   elif item == "unselectAll"     : self.VVapBp.VVphsY()
   elif item == "parentalControl_add"   : self.callingSELF.VVaNuH(self.VVapBp, refCode, True)
   elif item == "parentalControl_remove"  : self.callingSELF.VVaNuH(self.VVapBp, refCode, False)
   elif item == "hiddenServices_add"   : self.callingSELF.VVxTKv(self.VVapBp, refCode, True)
   elif item == "hiddenServices_remove"  : self.callingSELF.VVxTKv(self.VVapBp, refCode, False)
   elif item == "parentalControl_sel_add"  : self.callingSELF.VV22xF(self.VVapBp, True)
   elif item == "parentalControl_sel_remove" : self.callingSELF.VV22xF(self.VVapBp, False)
   elif item == "hiddenServices_sel_add"  : self.callingSELF.VVPG7K(self.VVapBp, True)
   elif item == "hiddenServices_sel_remove" : self.callingSELF.VVPG7K(self.VVapBp, False)
   elif item == "VVM7nw_multi"  : self.VVM7nw(refCode, True)
   elif item == "VVM7nw_one"  : self.VVM7nw(refCode, False)
 def VV8tWi(self, VVapBp):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  mSel   = CClFPA(self, VVapBp, 3)
  mSel.VV98Tl(servName, refCode)
 def VVM7nw(self, refCode, isMulti):
  bouquets = FF1HUL()
  if bouquets:
   VV23GK = []
   for item in bouquets:
    VV23GK.append((item[0], item[1].toString()))
   VVrMQs = ("Create New", boundFunction(self.VVWblJ, refCode, isMulti))
   FFdX2v(self.callingSELF, boundFunction(self.VVynaD, refCode, isMulti), VV23GK=VV23GK, title="Add to Bouquet", VVrMQs=VVrMQs, VVdwiN=True, VVqC46=True)
  else:
   FFCKL0(self.callingSELF, boundFunction(self.VVbhsu, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVynaD(self, refCode, isMulti, bName=None):
  if bName:
   FFshid(self.VVapBp, boundFunction(self.VV7i7W, refCode, isMulti, bName), title="Adding Channels ...")
 def VV7i7W(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVlBsW(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVKFsj = InfoBar.instance
    if VVKFsj:
     VV0yB9 = VVKFsj.servicelist
     if VV0yB9:
      mutableList = VV0yB9.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVapBp.VVP0Av()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFTVfn(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FFf3zP(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVlBsW(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVapBp.VVNzhg(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VVWblJ(self, refCode, isMulti, VVoYT0Obj, path):
  self.VVbhsu(refCode, isMulti)
 def VVbhsu(self, refCode, isMulti):
  FFnG6g(self.callingSELF, boundFunction(self.VVdjwS, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVdjwS(self, refCode, isMulti, name):
  if name:
   FFshid(self.VVapBp, boundFunction(self.VVUlDU, refCode, isMulti, name), title="Adding Channels ...")
 def VVUlDU(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVlBsW(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVKFsj = InfoBar.instance
    if VVKFsj:
     VV0yB9 = VVKFsj.servicelist
     if VV0yB9:
      try:
       VV0yB9.addBouquet(name, services)
       allOK = True
      except:
       try:
        VV0yB9.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVapBp.VVP0Av()
   title = "Add to Bouquet"
   if allOK: FFTVfn(self.callingSELF, "Added to : %s" % name, title=title)
   else : FFf3zP(self.callingSELF, "Nothing added!", title=title)
class CCkRwU(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFSDka(VVbAWV, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFyutK(self)
  FFdk5e(self["keyRed"]  , "Exit")
  FFdk5e(self["keyGreen"]  , "Save")
  FFdk5e(self["keyYellow"] , "Refresh")
  FFdk5e(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VV494D  ,
   "green"   : self.VVjtl3 ,
   "yellow"  : self.VVwkKa  ,
   "blue"   : self.VVk2cl   ,
   "up"   : self.VVSS9D    ,
   "down"   : self.VVjpkT   ,
   "left"   : self.VVB1cC   ,
   "right"   : self.VVAeY3   ,
   "cancel"  : self.VV494D
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVwkKa()
  self.VVgRzW()
  FF22W2(self)
 def VV494D(self) : self.close(True)
 def VV7kdb(self) : self.close(False)
 def VVk2cl(self):
  self.session.openWithCallback(self.VVeu0j, boundFunction(CC58Az))
 def VVeu0j(self, closeAll):
  if closeAll:
   self.close()
 def VVSS9D(self):
  self.VVKcCh(1)
 def VVjpkT(self):
  self.VVKcCh(-1)
 def VVB1cC(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVgRzW()
 def VVAeY3(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVgRzW()
 def VVKcCh(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVudVn(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVudVn(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVudVn(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVFJ5P(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVFJ5P(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVgRzW(self):
  for obj in self.list:
   FF6nEU(obj, "#11404040")
  FF6nEU(self.list[self.index], "#11ff8000")
 def VVwkKa(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVjtl3(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCPLjr()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVbllM)
 def VVbllM(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFTVfn(self, "Nothing returned from the system!")
  else:
   FFTVfn(self, str(result))
class CC58Az(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFSDka(VVe0b2, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFyutK(self, addLabel=True)
  FFdk5e(self["keyRed"]  , "Exit")
  FFdk5e(self["keyGreen"]  , "Sync")
  FFdk5e(self["keyYellow"] , "Refresh")
  FFdk5e(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VV494D   ,
   "green"   : self.VV6NUO  ,
   "yellow"  : self.VVtGHI ,
   "blue"   : self.VVv0Ex  ,
   "cancel"  : self.VV494D
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVS2I9()
  self.onShow.append(self.start)
 def start(self):
  FFRXLV(self.refresh)
  FF22W2(self)
 def refresh(self):
  self.VVBEYQ()
  self.VVG9Ic(False)
 def VV494D(self)  : self.close(True)
 def VVv0Ex(self) : self.close(False)
 def VVS2I9(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVBEYQ(self):
  self.VVCdhq()
  self.VV82br()
  self.VVIAA5()
  self.VVNvdO()
 def VVtGHI(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVS2I9()
   self.VVBEYQ()
   FFRXLV(self.refresh)
 def VV6NUO(self):
  if len(self["keyGreen"].getText()) > 0:
   FFCKL0(self, self.VVsz87, "Synchronize with Internet Date/Time ?")
 def VVsz87(self):
  self.VVBEYQ()
  FFRXLV(boundFunction(self.VVG9Ic, True))
 def VVCdhq(self)  : self["keyRed"].show()
 def VVNc5f(self)  : self["keyGreen"].show()
 def VVyKmm(self) : self["keyYellow"].show()
 def VVCacw(self)  : self["keyBlue"].show()
 def VV82br(self)  : self["keyGreen"].hide()
 def VVIAA5(self) : self["keyYellow"].hide()
 def VVNvdO(self)  : self["keyBlue"].hide()
 def VVG9Ic(self, sync):
  localTime = FFqkDy()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVSLhl(server)
   if epoch_time is not None:
    ntpTime = FFXQPO(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCPLjr()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVbllM, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVyKmm()
  self.VVCacw()
  if ok:
   self.VVNc5f()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVbllM(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVG9Ic(False)
  except:
   pass
 def VVSLhl(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFkdJ5():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCJDAS(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFSDka(VVQs0x, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFyutK(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FFRXLV(self.VVj2nW)
 def VVj2nW(self):
  if FFkdJ5(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FF6nEU(self["myBody"], color)
   FF6nEU(self["myLabel"], color)
  except:
   pass
class CC1sBo(Screen):
 def __init__(self, session, isFromExternal=False):
  size = CFG.signalSize.getValue()
  screenW = FFx23H()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFSDka(VVF8vd, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self.isFromExternal  = isFromExternal
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCNgXf(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCNgXf(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCNgXf(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCXfQM()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFyutK(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVSS9D          ,
   "down"  : self.VVjpkT         ,
   "left"  : self.VVB1cC         ,
   "right"  : self.VVAeY3         ,
   "info"  : self.VVn4zP        ,
   "epg"  : self.VVn4zP        ,
   "menu"  : self.VVXFT8         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "blue"  : self.VVS7eH       ,
   "last"  : boundFunction(self.VVgGzR, -1)  ,
   "next"  : boundFunction(self.VVgGzR, 1)  ,
   "pageUp" : boundFunction(self.VV76x8, True) ,
   "chanUp" : boundFunction(self.VV76x8, True) ,
   "pageDown" : boundFunction(self.VV76x8, False) ,
   "chanDown" : boundFunction(self.VV76x8, False) ,
   "0"   : boundFunction(self.VVgGzR, 0)  ,
   "1"   : boundFunction(self.VVDUqo, pos=1) ,
   "2"   : boundFunction(self.VVDUqo, pos=2) ,
   "3"   : boundFunction(self.VVDUqo, pos=3) ,
   "4"   : boundFunction(self.VVDUqo, pos=4) ,
   "5"   : boundFunction(self.VVDUqo, pos=5) ,
   "6"   : boundFunction(self.VVDUqo, pos=6) ,
   "7"   : boundFunction(self.VVDUqo, pos=7) ,
   "8"   : boundFunction(self.VVDUqo, pos=8) ,
   "9"   : boundFunction(self.VVDUqo, pos=9) ,
  }, -1)
  self.onShown.append(self.VVSdHz)
  self.onClose.append(self.onExit)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  self.sliderSNR.VVJXPW()
  self.sliderAGC.VVJXPW()
  self.sliderBER.VVJXPW(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVDUqo()
  self.VVq9FvInfo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVq9Fv)
  except:
   self.timer.callback.append(self.VVq9Fv)
  self.timer.start(500, False)
 def VVq9FvInfo(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVKCQj(service)
  serviceName = self.tunerInfo.VVannA()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self)
  tp = CCqMXo()
  txt = tp.VVFILp(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVq9Fv(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVKCQj(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVfFmL())
   self["mySNR"].setText(self.tunerInfo.VVARd1())
   self["myAGC"].setText(self.tunerInfo.VVxtRA())
   self["myBER"].setText(self.tunerInfo.VVyMWx())
   self.sliderSNR.VVBgSe(self.tunerInfo.VVNys1())
   self.sliderAGC.VVBgSe(self.tunerInfo.VVFr88())
   self.sliderBER.VVBgSe(self.tunerInfo.VV4MaF())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVBgSe(0)
   self.sliderAGC.VVBgSe(0)
   self.sliderBER.VVBgSe(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self)
    if state and not state == "Tuned":
     FF6E92(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVn4zP(self):
  FFMw5O(self, fncMode=CCkvvO.VVHKIX)
 def VVXFT8(self):
  FFiYdB(self, VVBZq2 + "_help_signal", "Signal Monitor (Keys)")
 def VVS7eH(self):
  self.session.open(CC9pOJ, isFromExternal=self.isFromExternal)
  self.close()
 def VVSS9D(self)  : self.VVDUqo(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVjpkT(self) : self.VVDUqo(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVB1cC(self) : self.VVDUqo(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVAeY3(self) : self.VVDUqo(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVDUqo(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVgGzR(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFKZ30(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VV76x8(self, isUp):
  FF6E92(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVq9FvInfo()
  except:
   pass
class CCNgXf(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVJXPW(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FF6nEU(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVBZq2 +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FF6nEU(self.covObj, self.covColor)
   else:
    FF6nEU(self.covObj, "#00006688")
    self.isColormode = True
  self.VVBgSe(0)
 def VVBgSe(self, val):
  val  = FFKZ30(val, self.minN, self.maxN)
  width = int(FFqpoV(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFKZ30(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCoBfV(Screen):
 VVL4g0    = 0
 VVBzoi = 1
 VVqU0o = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVRMfQ=None, barTheme=VVL4g0):
  ratio = self.VViu53(barTheme)
  self.skin, self.skinParam = FFSDka(VVIjGQ, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVRMfQ = VVRMfQ
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVNOpf = None
  self.timer   = eTimer()
  self.myThread  = None
  FFyutK(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVSdHz)
  self.onClose.append(self.onExit)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  self.VV81tV()
  self["myProgBarVal"].setText("0%")
  FF6nEU(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVMXPs()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVMXPs)
  except:
   self.timer.callback.append(self.VVMXPs)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def VVOeug(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVinHX_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVNOpf), self.counter, self.maxValue, catName)
 def VVinHX_fromImportEPG(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVinHX_forcedUpdate(self, title):
  self.newTitle = title
  try:
   self.VVMXPs()
  except:
   pass
 def VVzPrH(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VVNOpf), self.counter, self.maxValue)
  except:
   pass
 def VVIUwv(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVOfEb(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVfBe0(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FF6E92(self, "Cancelling ...")
  self.isCancelled = True
  self.VViaIc(False)
 def VViaIc(self, isDone):
  if self.VVRMfQ:
   self.VVRMfQ(isDone, self.VVNOpf, self.counter, self.maxValue, self.isError)
  self.close()
 def VVMXPs(self):
  val = FFKZ30(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFqpoV(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VViaIc(True)
 def VV81tV(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVBzoi, self.VVqU0o):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VViu53(self, barTheme):
  if   barTheme == self.VVBzoi : return 0.7
  if   barTheme == self.VVqU0o : return 0.5
  else             : return 1
class CCPLjr(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVRMfQ = {}
  self.commandRunning = False
  self.VVPf2H  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVRMfQ, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVRMfQ[name] = VVRMfQ
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVPf2H:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVRMdO, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVmpIs , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVRMdO, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVmpIs , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVmpIs(name, retval)
  return True
 def VVRMdO(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVmpIs(self, name, retval):
  if not self.VVPf2H:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVRMfQ[name]:
   self.VVRMfQ[name](self.appResults[name], retval)
  del self.VVRMfQ[name]
 def VVxMfi(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CC88Hn(Screen):
 def __init__(self, session, title="", VVSgRh=None, VVp2W4=False, VVHeV2=False, VV6ZeF=False, VVO6LD=False, VV5wRI=False, VVmd2W=False, VViQnE=VV34ku, VVHD9V=None, VVNxzb=False, VVutPQ=None, VV2i7R="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFSDka(VVEzHn, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFyutK(self, addScrollLabel=True)
  if not VV2i7R:
   VV2i7R = "Processing ..."
  self["myLabel"].setText("   %s" % VV2i7R)
  self.VVp2W4   = VVp2W4
  self.VVHeV2   = VVHeV2
  self.VV6ZeF   = VV6ZeF
  self.VVO6LD  = VVO6LD
  self.VV5wRI = VV5wRI
  self.VVmd2W = VVmd2W
  self.VViQnE   = VViQnE
  self.VVHD9V = VVHD9V
  self.VVNxzb  = VVNxzb
  self.VVutPQ  = VVutPQ
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCPLjr()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFlC9C()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVSgRh, str):
   self.VVSgRh = [VVSgRh]
  else:
   self.VVSgRh = VVSgRh
  if self.VV6ZeF or self.VVO6LD:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVBOaW, VVBOaW)
   self.VVSgRh.append("echo -e '\n%s\n' %s" % (restartNote, FF7UqE(restartNote, VVAjxB)))
   if self.VV6ZeF:
    self.VVSgRh.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVSgRh.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VV5wRI:
   FF6E92(self, "Processing ...")
  self.onLayoutFinish.append(self.VVtLQl)
  self.onClose.append(self.VVzAlh)
 def VVtLQl(self):
  self["myLabel"].VVi2rz(textOutFile="console" if self.enableSaveRes else "")
  if self.VVp2W4:
   self["myLabel"].VVXdEA()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVE1RP()
  else:
   self.VVBctr()
 def VVE1RP(self):
  if FFkdJ5():
   self["myLabel"].setText("Processing ...")
   self.VVBctr()
  else:
   self["myLabel"].setText(FFhqic("\n   No connection to internet!", VVd9bM))
 def VVBctr(self):
  allOK = self.container.ePopen(self.VVSgRh[0], self.VVpGjl, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVpGjl("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVmd2W or self.VV6ZeF or self.VVO6LD:
    self["myLabel"].setText(FFJKjn("STARTED", VVAjxB) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVutPQ:
   colorWhite = CCtme9.VVLf2h(VVX9gW)
   color  = CCtme9.VVLf2h(self.VVutPQ[0])
   words  = self.VVutPQ[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VViQnE=self.VViQnE)
 def VVpGjl(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVSgRh):
   allOK = self.container.ePopen(self.VVSgRh[self.cmdNum], self.VVpGjl, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVpGjl("Cannot connect to Console!", -1)
  else:
   if self.VV5wRI and FFuEE1(self):
    FF6E92(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVmd2W:
    self["myLabel"].appendText("\n" + FFJKjn("FINISHED", VVAjxB), self.VViQnE)
   if self.VVp2W4 or self.VVHeV2:
    self["myLabel"].VVXdEA()
   if self.VVHD9V is not None:
    self.VVHD9V()
   if not retval and self.VVNxzb:
    self.VVzAlh()
 def VVzAlh(self):
  if self.container.VVxMfi():
   self.container.killAll()
class CC1Js8(Screen):
 def __init__(self, session, VVSgRh=None, VV5wRI=False):
  self.skin, self.skinParam = FFSDka(VVEzHn, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVXukQ + "ajpanel_terminal.history"
  self.customCommandsFile = VVXukQ + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFjgvE("pwd") or "/home/root"
  self.container   = CCPLjr()
  FFyutK(self, addScrollLabel=True)
  FFdk5e(self["keyRed"] , "Exit = Stop Command")
  FFdk5e(self["keyGreen"] , "OK = History")
  FFdk5e(self["keyYellow"], "Menu = Custom Cmds")
  FFdk5e(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVWM0u ,
   "cancel" : self.VVgLxz  ,
   "menu"  : self.VVLF45 ,
   "last"  : self.VVEFfY  ,
   "next"  : self.VVEFfY  ,
   "1"   : self.VVEFfY  ,
   "2"   : self.VVEFfY  ,
   "3"   : self.VVEFfY  ,
   "4"   : self.VVEFfY  ,
   "5"   : self.VVEFfY  ,
   "6"   : self.VVEFfY  ,
   "7"   : self.VVEFfY  ,
   "8"   : self.VVEFfY  ,
   "9"   : self.VVEFfY  ,
   "0"   : self.VVEFfY
  })
  self.onLayoutFinish.append(self.VVSdHz)
  self.onClose.append(self.VVTRbZ)
 def VVSdHz(self):
  self["myLabel"].VVi2rz(isResizable=False, textOutFile="terminal")
  FFE31q(self["keyRed"]  , "#00ff8000")
  FF6nEU(self["keyRed"]  , self.skinParam["titleColor"])
  FF6nEU(self["keyGreen"]  , self.skinParam["titleColor"])
  FF6nEU(self["keyYellow"] , self.skinParam["titleColor"])
  FF6nEU(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVjv9r(FFjgvE("date"), 5)
  result = FFjgvE("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VV5JAv()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVBZq2 + "LinuxCommands.lst"
   newTemplate = VVBZq2 + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFrWND("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFrWND("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVTRbZ(self):
  if self.container.VVxMfi():
   self.container.killAll()
   self.VVjv9r("Process killed\n", 4)
   self.VV5JAv()
 def VVgLxz(self):
  if self.container.VVxMfi():
   self.VVTRbZ()
  else:
   FFCKL0(self, self.close, "Exit ?", VVYAYv=False)
 def VV5JAv(self):
  self.VVjv9r(self.prompt, 1)
  self["keyRed"].hide()
 def VVjv9r(self, txt, mode):
  if   mode == 1 : color = VVAjxB
  elif mode == 2 : color = VVxzLQ
  elif mode == 3 : color = VVX9gW
  elif mode == 4 : color = VVd9bM
  elif mode == 5 : color = VVcDYh
  elif mode == 6 : color = VVf4dJ
  else   : color = VVX9gW
  try:
   self["myLabel"].appendText(FFhqic(txt, color))
  except:
   pass
 def VV14hS(self, cmd):
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVjv9r(cmd, 2)
   self.VVjv9r("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVjv9r(ch, 0)
   self.VVjv9r("\nor\n", 4)
   self.VVjv9r("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VV5JAv()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFhqic(parts[0].strip(), VVxzLQ)
    right = FFhqic("#" + parts[1].strip(), VVf4dJ)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVjv9r(txt, 2)
   lastLine = self.VVc36p()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVzniR(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVpGjl, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFf3zP(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVjv9r(data, 3)
 def VVpGjl(self, data, retval):
  if not retval == 0:
   self.VVjv9r("Exit Code : %d\n" % retval, 4)
  self.VV5JAv()
 def VVWM0u(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVc36p() == "":
   self.VVzniR("cd /tmp")
   self.VVzniR("ls")
  VVKG2e = []
  if fileExists(self.commandHistoryFile):
   lines  = FF8ZwU(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVKG2e.append((str(c), line, str(lNum)))
   self.VV5yQm(VVKG2e, title, self.commandHistoryFile, isHistory=True)
  else:
   FFxtzL(self, self.commandHistoryFile, title=title)
 def VVc36p(self):
  lastLine = FFjgvE("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVzniR(self, cmd):
  os.system("echo '%s' >> %s" % (str(cmd.encode("UTF-8")), str(self.commandHistoryFile)))
 def VVLF45(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FF8ZwU(self.customCommandsFile)
   lastLineIsSep = False
   VVKG2e = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVKG2e.append((str(c), line, str(lNum)))
   self.VV5yQm(VVKG2e, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFxtzL(self, self.customCommandsFile, title=title)
 def VV5yQm(self, VVKG2e, title, filePath=None, isHistory=False):
  if VVKG2e:
   VVzAxe = "#05333333"
   if isHistory: VVRbex = VVihVe = VVwsQj = "#11000020"
   else  : VVRbex = VVihVe = VVwsQj = "#06002020"
   VVKCEj = VVwFPr = None
   VVBmAn   = ("Send"   , self.VVtCd3        , [])
   VVtony  = ("Modify & Send" , self.VV5ys0        , [])
   if isHistory:
    VVKCEj = ("Clear History" , self.VVwvXV        , [])
   elif filePath:
    VVwFPr = ("Edit File"  , boundFunction(self.VV3O7E, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVbtsV     = (CENTER  , LEFT   , CENTER )
   FFMNGj(self, None, title=title, header=header, VVYDUR=VVKG2e, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=26, VVBmAn=VVBmAn, VVtony=VVtony, VVKCEj=VVKCEj, VVwFPr=VVwFPr, VViKTA=True
     , VVRbex   = VVRbex
     , VVihVe   = VVihVe
     , VVwsQj   = VVwsQj
     , VVfIrn  = "#05ffff00"
     , VVzAxe  = VVzAxe
    )
  else:
   FF8yum(self, filePath, title=title)
 def VVtCd3(self, VVapBp, title, txt, colList):
  cmd = colList[1].strip()
  VVapBp.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVjv9r("\n%s\n" % cmd, 6)
   self.VVjv9r(self.prompt, 1)
  else:
   self.VV14hS(cmd)
 def VV5ys0(self, VVapBp, title, txt, colList):
  cmd = colList[1]
  self.VVHM3A(VVapBp, cmd)
 def VVwvXV(self, VVapBp, title, txt, colList):
  FFCKL0(self, boundFunction(self.VVOxVO, VVapBp), "Reset History File ?", title="Command History")
 def VVOxVO(self, VVapBp):
  os.system(FFrWND("echo '' > %s" % self.commandHistoryFile))
  VVapBp.cancel()
 def VV3O7E(self, filePath, VVapBp, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCUORs(self, filePath, VVRMfQ=boundFunction(self.VV89kT, VVapBp), curRowNum=rowNum)
  else     : FFxtzL(self, filePath)
 def VV89kT(self, VVapBp, fileChanged):
  if fileChanged:
   VVapBp.cancel()
   FFRXLV(self.VVLF45)
 def VVEFfY(self):
  self.VVHM3A(None, self.lastCommand)
 def VVHM3A(self, VVapBp, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFnG6g(self, boundFunction(self.VVgqob, VVapBp), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVgqob(self, VVapBp, cmd):
  if cmd and len(cmd) > 0:
   self.VV14hS(cmd)
   if VVapBp:
    VVapBp.cancel()
class CCBg2X(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVZ6mF="", VV7XRy=False, VVWqJl=False, isTrimEnds=True):
  self.skin, self.skinParam = FFSDka(VV8F6y, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFyutK(self, title, addLabel=True)
  FFdk5e(self["keyRed"] , "Up/Down = Change")
  FFdk5e(self["keyGreen"] , "Overwrite")
  FFdk5e(self["keyYellow"], "Pick Key Map")
  FFdk5e(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVWqJl   = VVWqJl
  self.VV7XRy  = VV7XRy
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVZ6mF, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVk45e      ,
   "green"    : self.VVZPAe    ,
   "yellow"   : self.VVDrgX      ,
   "blue"    : self.VVBpU2     ,
   "menu"    : self.VVgLK4     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVNHst, True) ,
   "down"    : boundFunction(self.VVNHst, False) ,
   "left"    : self.VVoStF       ,
   "right"    : self.VVmOao       ,
   "home"    : self.VVhPSd       ,
   "end"    : self.VVc5aF       ,
   "next"    : self.VVDMFg      ,
   "last"    : self.VVZVfY      ,
   "deleteForward"  : self.VVDMFg      ,
   "deleteBackward" : self.VVZVfY      ,
   "tab"    : self.VVWEVZ       ,
   "toggleOverwrite" : self.VVZPAe    ,
   "0"     : self.VVnPxf     ,
   "1"     : self.VVnPxf     ,
   "2"     : self.VVnPxf     ,
   "3"     : self.VVnPxf     ,
   "4"     : self.VVnPxf     ,
   "5"     : self.VVnPxf     ,
   "6"     : self.VVnPxf     ,
   "7"     : self.VVnPxf     ,
   "8"     : self.VVnPxf     ,
   "9"     : self.VVnPxf
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVF3ei()
  self.onShown.append(self.VVSdHz)
  self.onClose.append(self.onExit)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FFDx5r(self)
  self["myLabel"].setText(self.message)
  self.VVDsqw()
  if self.VV7XRy : self.VVZPAe()
  else    : self.VVlWq2()
  FF22W2(self)
  FF6nEU(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVRlkz)
  except:
   self.timer.callback.append(self.VVRlkz)
 def onExit(self):
  self.timer.stop()
 def VVk45e(self):
  self.VVvZ64()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVvZ64()
  self.close(None)
 def VVgLK4(self):
  VV23GK = []
  VV23GK.append(("Home"         , "home"    ))
  VV23GK.append(("End"         , "end"     ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Clear All"       , "clearAll"   ))
  VV23GK.append(("Clear To Home"      , "clearToHome"   ))
  VV23GK.append(("Clear To End"       , "clearToEnd"   ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVPKgK:
   VV23GK.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VV23GK.append(VV15MX)
  VV23GK.append(("To Capital Letters"     , "toCapital"   ))
  VV23GK.append(("To Small Letters"      , "toSmall"    ))
  FFdX2v(self, self.VV52Ga, title="Edit Options", VV23GK=VV23GK)
 def VV52Ga(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVhPSd()
   elif item == "end"     : self.VVc5aF()
   elif item == "clearAll"    : self.VVfJrQ()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVhPSd()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVPKgK
    VVPKgK = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVPKgK)
    self.VVhPSd()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVRlkz(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVZPAe(self):
  self["myInput"].toggleOverwrite()
  self.VVlWq2()
 def VVDrgX(self):
  self.session.openWithCallback(self.VVGoAV, boundFunction(CCaHVc, mode=self.charMode, VVWqJl=self.VVWqJl))
 def VVGoAV(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVDsqw()
 def VVlWq2(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVF3ei(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVvZ64(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVskYP(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVoStF(self)     : self.VVnAax(self["myInput"].left)
 def VVmOao(self)     : self.VVnAax(self["myInput"].right)
 def VVDMFg(self)     : self.VVnAax(self["myInput"].delete)
 def VVhPSd(self)     : self.VVnAax(self["myInput"].home)
 def VVc5aF(self)     : self.VVnAax(self["myInput"].end)
 def VVZVfY(self)    : self.VVnAax(self["myInput"].deleteBackward)
 def VVWEVZ(self)     : self.VVnAax(self["myInput"].tab)
 def VVfJrQ(self)     : self["myInput"].setText("")
 def VVnAax(self, fnc):
  fnc()
  self.VVRlkz()
 def VVnPxf(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVskYP(newChar, overwrite)
   self.VVXiEN(newChar, self["myInput"].mapping[number])
 def VVNHst(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCaHVc.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCaHVc.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVskYP(newChar, True)
   for group in groups:
    if newChar in group:
     self.VVXiEN(newChar, group)
     break
 def VVXiEN(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVX9gW:
    group = VVcDYh + group.replace(newChar, FFhqic(newChar, VVX9gW, VVcDYh))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVBpU2(self):
  if self.VVWqJl : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVDsqw()
 def VVDsqw(self):
  self["myInput"].mapping = CCaHVc.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCaHVc.RCU_MAP_TITLES[self.charMode])
class CCaHVc(Screen):
 VVKKVv  = 0
 VVrzhA  = 1
 VVg0e1  = 2
 VVbExn  = 3
 VVvOCZ = 4
 VV6x1y = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols , arabic_nums1, arabic1)
       , ( symbols , arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A", u"\u0628")
       , (u"\u0647", u"\u062A")
       )
 def __init__(self, session, mode=VVKKVv, VVWqJl=False):
  self.skin, self.skinParam = FFSDka(VVjgl4, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVWqJl  = VVWqJl
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFyutK(self, title=self.Title)
  FFdk5e(self["keyRed"] ,"OK = Select")
  FFdk5e(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVOPJy     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVMYoy, -1) ,
   "next"  : boundFunction(self.VVMYoy, +1) ,
   "left"  : boundFunction(self.VVMYoy, -1) ,
   "right"  : boundFunction(self.VVMYoy, +1) ,
  }, -1)
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FF6nEU(self["keyRed"], "#11222222")
  FF6nEU(self["keyGreen"], "#11222222")
  self.VVt1bb()
 def VVt1bb(self):
  self.VVL2My()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVL2My(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVMYoy(self, direction):
  if self.VVWqJl : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVt1bb()
 def VVOPJy(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCYqdb(Screen):
 def __init__(self, session, title="", message="", VViQnE=VV34ku, VVin2T=False, VVwsQj=None, VVzOAn=30, canSaveToFile=""):
  self.skin, self.skinParam = FFSDka(VVEzHn, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVzOAn)
  self.session   = session
  FFyutK(self, title, addScrollLabel=True)
  self.VViQnE   = VViQnE
  self.VVin2T   = VVin2T
  self.VVwsQj   = VVwsQj
  self.canSaveToFile  = canSaveToFile
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  self["myLabel"].VVi2rz(VVin2T=self.VVin2T, textOutFile=self.canSaveToFile)
  self["myLabel"].setText(self.message, self.VViQnE)
  if self.VVwsQj:
   FF6nEU(self["myBody"], self.VVwsQj)
   FF6nEU(self["myLabel"], self.VVwsQj)
   FFiCqD(self["myLabel"], self.VVwsQj)
  self["myLabel"].VVXdEA()
class CCu2tz(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFSDka(VVWuPu, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFyutK(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FFbjWp(self["errPic"], "err")
class CCEhSE(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FFSDka(VVN0gV, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", 20)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FFyutK(self, " ", addCloser=True)
class CCzOLp():
 def __init__(self, session, txt):
  self.win = session.instantiateDialog(CCEhSE, txt)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  self.session = session
  self.timer  = eTimer()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVmkDl)
  except:
   self.timer.callback.append(self.VVmkDl)
  self.timer.start(1500, True)
 def VVmkDl(self):
  self.session.deleteDialog(self.win)
class CCe2k3():
 VVg84Q    = 0
 VVGXD0  = 1
 VVrTXS   = ""
 VVP9AA    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVapBp   = None
  self.timer     = eTimer()
  self.VVbkOK   = 0
  self.VVDpGW  = 1
  self.VVCdQA  = 2
  self.VV3Z4d   = 3
  self.VVd56O   = 4
  VVKG2e = self.VVGZTX()
  if VVKG2e:
   self.VVapBp = self.VV25RV(VVKG2e)
  if not VVKG2e and mode == self.VVg84Q:
   self.VVHov8or("Download list is empty !")
   self.cancel()
  if mode == self.VVGXD0:
   FFshid(self.VVapBp or self.SELF, boundFunction(self.VVWAZN, startDnld, decodedUrl), title="Checking Server ...")
  self.VVXTDq(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVXTDq)
  except:
   self.timer.callback.append(self.VVXTDq)
  self.timer.start(1000, False)
 def VV25RV(self, VVKG2e):
  VVKG2e.sort(key=lambda x: int(x[0]))
  VVyVHa = self.VVYUQF
  VVBmAn  = ("Play"  , self.VVqtzZ , [])
  VVscS4 = (""   , self.VVy0Of  , [])
  VVCAcJ = ("Stop"  , self.VVp2Rz  , [])
  VVtony = ("Resume"  , self.VVmwuA , [])
  VVKCEj = ("Options" , self.VVCH4d  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVbtsV  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFMNGj(self.SELF, None, title=self.Title, header=header, VVYDUR=VVKG2e, VVbtsV=VVbtsV, VV5EM1=widths, VVzOAn=26, VVBmAn=VVBmAn, VVscS4=VVscS4, VVyVHa=VVyVHa, VVCAcJ=VVCAcJ, VVtony=VVtony, VVKCEj=VVKCEj, VVihVe="#11110011", VVRbex="#11220022", VVwsQj="#11110011", VVfIrn="#00ffff00", VVzAxe="#00223025", VVrSmG="#0a333333", VVIRVU="#0a400040", VViKTA=True, searchCol=1)
 def VVGZTX(self):
  lines = CCe2k3.VV6EM6()
  VVKG2e = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",")
     left  = parts[0].strip()
     decodedUrl = ",".join(parts[1:]).strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVroul(decodedUrl)
      if fName:
       if   FF8rbS(decodedUrl) : sType = "Movie"
       elif FFBooI(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVpStM(decodedUrl, fName)
       if size > -1: sizeTxt = CCin0f.VVPicv(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVKG2e.append((str(len(VVKG2e) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVKG2e
 def VVnIKl(self):
  VVKG2e = self.VVGZTX()
  if VVKG2e:
   if self.VVapBp : self.VVapBp.VVs7In(VVKG2e, VVS2I9Msg=False)
   else     : self.VVapBp = self.VV25RV(VVKG2e)
  else:
   self.cancel()
 def VVXTDq(self, force=False):
  if self.VVapBp:
   thrList = self.VVlhgA()
   VVKG2e = []
   changed = False
   for ndx, row in enumerate(self.VVapBp.VVsv7I()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVbkOK
    if m3u8Log:
     percent = self.VVa5Ib(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VV3Z4d , "%.2f %%" % percent
      else   : flag, progr = self.VVd56O , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFHtxR(mPath)
     if curSize > -1:
      fSize = CCin0f.VVPicv(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCin0f.VVPicv(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFHtxR(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VV3Z4d , "%.2f %%" % percent
       else   : flag, progr = self.VVd56O , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCin0f.VVPicv(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrList:
     flag = self.VVCdQA
     if m3u8Log :
      if not speed and not force : flag = self.VVDpGW
      elif curSize == -1   : self.VVib3B(False)
    elif flag == self.VVbkOK  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVbkOK  : color2 = "#f#00555555#"
    elif flag == self.VVDpGW : color2 = "#f#0000FFFF#"
    elif flag == self.VVCdQA : color2 = "#f#0000FFFF#"
    elif flag == self.VV3Z4d  : color2 = "#f#00FF8000#"
    elif flag == self.VVd56O  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVKzH5(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVKG2e.append(row)
   if changed or force:
    self.VVapBp.VVs7In(VVKG2e, VVS2I9Msg=False)
 def VVKzH5(self, flag):
  tDict = self.VVXxq2()
  return tDict.get(flag, "?")
 def VVydnD(self, state):
  for flag, txt in self.VVXxq2().items():
   if txt == state:
    return flag
  return -1
 def VVXxq2(self):
  return { self.VVbkOK: "Not started", self.VVDpGW: "Connecting", self.VVCdQA: "Downloading", self.VV3Z4d: "Stopped", self.VVd56O: "Completed" }
 def VVxptk(self, title):
  colList = self.VVapBp.VVwC4z()
  path = colList[6]
  url  = colList[8]
  if self.VVgqmL() : self.VVHov8or("Cannot delete !\n\nFile is downloading.")
  else      : FFCKL0(self.SELF, boundFunction(self.VVXh0M, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVXh0M(self, path, url):
  m3u8Log = self.VVapBp.VVwC4z()[12].strip()
  if m3u8Log : os.system(FFrWND("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFrWND("rm -r '%s'" % path))
  self.VVIKYD()
  self.VVnIKl()
 def VVIKYD(self):
  if self.VVgqmL():
   FF6E92(self.VVapBp, self.VVKzH5(self.VVCdQA), 500)
  else:
   colList  = self.VVapBp.VVwC4z()
   state  = colList[4].strip()
   decodedUrl = colList[9].strip()
   if self.VVydnD(state) in (self.VVbkOK, self.VVd56O):
    lines = CCe2k3.VV6EM6()
    newLines = []
    found = False
    for line in lines:
     if CCe2k3.VVKPWa(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVip1b(newLines)
     self.VVnIKl()
     FF6E92(self.VVapBp, "Removed.", 1000)
    else:
     FF6E92(self.VVapBp, "Not found.", 1000)
   else:
    self.VVHov8or("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVrqjC(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFCKL0(self.SELF, boundFunction(self.VVHROW, flag), ques, title=title)
 def VVHROW(self, flag):
  list = []
  for ndx, row in enumerate(self.VVapBp.VVsv7I()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVydnD(state)
   if   flag == flagVal == self.VVd56O: list.append(decodedUrl)
   elif flag == flagVal == self.VVbkOK : list.append(decodedUrl)
  lines = CCe2k3.VV6EM6()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVip1b(newLines)
   self.VVnIKl()
   FF6E92(self.VVapBp, "%d removed." % totRem, 1000)
  else:
   FF6E92(self.VVapBp, "Not found.", 1000)
 def VVbIue(self):
  colList  = self.VVapBp.VVwC4z()
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FF6E92(self.VVapBp, "Poster exists", 1500)
  else    : FFshid(self.VVapBp, boundFunction(self.VVXdYh, decodedUrl, path, png), title="Checking Server ...")
 def VVXdYh(self, decodedUrl, path, png):
  err = self.VV59aI(decodedUrl, path, png)
  if err:
   FFf3zP(self.SELF, err, title="Poster Download")
 def VV59aI(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CC5PGk.VVyyLa(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCFXWw.VVdr9M(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCFXWw.VV6PIg(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCFXWw.VV51wI(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if pUrl:
   ext = os.path.splitext(pUrl)[1] or ".png"
   tPath, err = FF2QcO(pUrl, "ajpanel_tmp%s", timeout=2, mustBeImage=True)
   if err:
    return "Cannot download poster !\n\n%s" % err
   else:
    png = "%s%s" % (os.path.splitext(path)[0], ext)
    os.system(FFrWND("mv -f '%s' '%s'" % (tPath, png)))
    FFY2ZZ(self.SELF, title=os.path.basename(png), VV5cQF=png, showGrnMsg="Downloaded")
  else:
   return "Cannot get Poster URL !\n\n%s" % err
  return ""
 def VVy0Of(self, VVapBp, title, txt, colList):
  def VVygRP(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVXwkx(key, val) : return "\n%s:\n%s\n" % (FFhqic(key, COLOR_CONS_BRIGHT_YELLOW), val.strip())
  heads  = self.VVapBp.VV2g6P()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVygRP(heads[i]  , CCin0f.VVPicv(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVygRP("Downloaded" , CCin0f.VVPicv(int(curSize), mode=0))
   else:
    txt += VVygRP(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVXwkx(heads[i], colList[i])
  FF9Qkx(self.SELF, txt, title=title)
 def VVqtzZ(self, VVapBp, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCin0f.VVE6YU(self.SELF, path)
  else    : FF6E92(self.VVapBp, "File not found", 1000)
 def VVYUQF(self, VVapBp):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVapBp:
   self.VVapBp.cancel()
  del self
 def VVCH4d(self, VVapBp, title, txt, colList):
  decodedUrl = colList[9].strip()
  if CFG.downloadAutoResume.getValue(): resumeTxt = "Disable"
  else        : resumeTxt = "Enable"
  VV23GK = []
  VV23GK.append(("Remove current row"      , "VVIKYD"  ))
  VV23GK.append(VV15MX)
  VV23GK.append(('Remove all "Completed"'     , "remFinished"    ))
  VV23GK.append(('Remove all "Not started"'     , "remPending"    ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Delete the file (and remove from list)" , "VVxptk" ))
  if FF8rbS(decodedUrl):
   VV23GK.append(VV15MX)
   VV23GK.append(("Download Movie Poster (from server)" , "VVbIue"   ))
  VV23GK.append(VV15MX)
  VV23GK.append((resumeTxt + " Auto Resume"     , "VVyhod"  ))
  FFdX2v(self.SELF, self.VV0dBv, VV23GK=VV23GK, title=self.Title, VVdwiN=True, VVqC46=True)
 def VV0dBv(self, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVIKYD"  : self.VVIKYD()
   elif ref == "remFinished"   : self.VVrqjC(self.VVd56O, txt)
   elif ref == "remPending"   : self.VVrqjC(self.VVbkOK, txt)
   elif ref == "VVxptk" : self.VVxptk(txt)
   elif ref == "VVbIue"  : self.VVbIue()
   elif ref == "VVyhod"  : self.VVyhod()
 def VVWAZN(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CC5PGk.VVyyLa(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVHov8or("Could not get download link !\n\nTry again later.")
     return
  for line in CCe2k3.VV6EM6():
   if CCe2k3.VVKPWa(decodedUrl, line):
    self.VVP4xo(decodedUrl)
    FFRXLV(boundFunction(FF6E92, self.VVapBp, "Already listed !", 2000))
    break
  else:
   params = self.VViaWK(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVHov8or(params[0])
   elif len(params) == 2:
    self.VVsaFO(params[0], decodedUrl)
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCin0f.VVPicv(fSize)
    FFCKL0(self.SELF, boundFunction(self.VVEUts, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVEUts(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCe2k3.VVpkvx(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVnIKl()
  if self.VVapBp:
   self.VVapBp.VVOPtk()
  if startDnld:
   threadName = self.VVP9AA + decodedUrl
   self.VVB16z(threadName, url, decodedUrl, path, resp)
 def VVP4xo(self, decodedUrl):
  for ndx, row in enumerate(self.VVapBp.VVsv7I()):
   decodedUrl2 = row[9].strip()
   if decodedUrl == decodedUrl2 and self.VVapBp:
    self.VVapBp.VVP2LA(ndx)
    break
 def VViaWK(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVroul(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVpStM(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CC5PGk.VVyyLa(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CC5PGk.VVg3OhHeader()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head["Content-Length"]
   cType = head["Content-Type"]
   if not "video" in cType:
    if resp.url.endswith(".m3u8"):
     return [resp, 1]
    else:
     return ["Cannot download this video !\n\nNot allowed by server."]
   if "Accept-Ranges" in head:
    resume = head["Accept-Ranges"]
    if not resume == "none":
     resumable = True
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  err = CCe2k3.VV6SyH(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVsaFO(self, resp, decodedUrl):
  if not os.system(FFrWND("which ffmpeg")) == 0:
   FFCKL0(self.SELF, boundFunction(CCFXWw.VVWYQd, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVroul(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVVWGb(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFCKL0(self.SELF, boundFunction(self.VVUG3O, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVUG3O(rTxt, rUrl)
  else:
   self.VVHov8or("Cannot process m3u8 file !")
 def VVVWGb(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VV23GK = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCFXWw.VV5Lwe(rUrl, fPath)
   VV23GK.append((resol, fullUrl))
  if VV23GK:
   FFdX2v(self.SELF, self.VVm2E8, VV23GK=VV23GK, title="Resolution", VVdwiN=True, VVqC46=True)
  else:
   self.VVHov8or("Cannot get Resolutions list from server !")
 def VVm2E8(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFCKL0(self.SELF, boundFunction(FFRXLV, boundFunction(self.VVlXlS, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFRXLV(boundFunction(self.VVlXlS, resolUrl))
 def VVlXlS(self, resolUrl):
  txt, err = CC5PGk.VVL7z2(resolUrl)
  if err : self.VVHov8or(err)
  else : self.VVUG3O(txt, resolUrl)
 def VVMqNr(self, logF, decodedUrl):
  found = False
  lines = CCe2k3.VV6EM6()
  with open(CCe2k3.VVpkvx(), "w") as f:
   for line in lines:
    if CCe2k3.VVKPWa(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCe2k3.VVpkvx(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVnIKl()
 def VVUG3O(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCFXWw.VV5Lwe(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVHov8or("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVMqNr(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFrWND("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = self.VVP9AA + decodedUrl
  myThread = iThread(name=threadName, target=boundFunction(os.system, cmd))
  myThread.start()
 def VVa5Ib(self, dnldLog):
  if fileExists(dnldLog):
   dur = self.VVOFtU(dnldLog)
   if dur > -1:
    tim = self.VVGDuW(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 def VVOFtU(self, dnldLog):
  lines = FFIx6K("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVGDuW(self, dnldLog):
  lines = FFIx6K("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVpStM(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFBooI(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFrWND("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVB16z(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVapBp.VVwC4z()[7].strip())
  myThread = iThread(name=threadName, target=boundFunction(self.VVmsDE, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVmsDE(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if CCe2k3.VVrTXS == path:
       break
     else:
      break
  except:
   return
  if CCe2k3.VVrTXS:
   CCe2k3.VVrTXS = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFHtxR(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VViaWK(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVmsDE(url, decodedUrl, path, resp, totFileSize, True)
 def VVp2Rz(self, VVapBp, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVnGnu() : FF6E92(self.VVapBp, self.VVKzH5(self.VVd56O), 500)
  elif not self.VVgqmL() : FF6E92(self.VVapBp, self.VVKzH5(self.VV3Z4d), 500)
  elif m3u8Log      : FFCKL0(self.SELF, self.VVib3B, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVlhgA():
    CCe2k3.VVrTXS = colList[6]
    FF6E92(self.VVapBp, "Stopping ...", 1000)
   else:
    FF6E92(self.VVapBp, "Stopped", 500)
 def VVib3B(self, withMsg=True):
  if withMsg:
   FF6E92(self.VVapBp, "Stopping ...", 1000)
  os.system(FFrWND("killall -INT ffmpeg"))
 def VVyhod(self):
  CFG.downloadAutoResume.setValue(not CFG.downloadAutoResume.getValue())
  CFG.downloadAutoResume.save()
  configfile.save()
 def VVmwuA(self, *args):
  if   self.VVnGnu() : FF6E92(self.VVapBp, self.VVKzH5(self.VVd56O) , 500)
  elif self.VVgqmL() : FF6E92(self.VVapBp, self.VVKzH5(self.VVCdQA), 500)
  else:
   resume = False
   m3u8Log = self.VVapBp.VVwC4z()[12].strip()
   if m3u8Log:
    if fileExists(m3u8Log) : FFCKL0(self.SELF, boundFunction(self.VVkSC8, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVwdac():
    resume = True
   if resume: FFshid(self.VVapBp, boundFunction(self.VVFioo), title="Checking Server ...")
   else  : FF6E92(self.VVapBp, "Cannot resume !", 500)
 def VVkSC8(self, m3u8Log):
  os.system(FFrWND("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FFshid(self.VVapBp, boundFunction(self.VVFioo), title="Checking Server ...")
 def VVFioo(self):
  colList  = self.VVapBp.VVwC4z()
  path  = colList[6].strip()
  size  = colList[7].strip()
  decodedUrl = colList[9].strip()
  if "j.php" in decodedUrl:
   url = CC5PGk.VVyyLa(decodedUrl)
   if url:
    decodedUrl = self.VVN5aI(decodedUrl, url)
   else:
    self.VVHov8or("Could not get download link !\n\nTry again later.")
    return
  curSize = FFHtxR(path)
  params = self.VViaWK(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVHov8or(params[0])
   return
  elif len(params) == 2:
   self.VVsaFO(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVN5aI(decodedUrl, url, fSize)
  threadName = self.VVP9AA + decodedUrl
  if resumable: self.VVB16z(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVHov8or("Cannot resume from server !")
 def VVroul(self, decodedUrl):
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(http:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   x = decodedUrl.find("&mode")
   if x > -1: url = decodedUrl[:x]
   fName = ".mp4"
   x = decodedUrl.find("&end=")
   if x > -1: chName = decodedUrl[x+5:]
  if url and fName and chName:
   mix  = fName + chName
   fName =  mix.split(":")[0]
   chName = ":".join(mix.split(":")[1:])
   fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
   url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVHov8or(self, txt):
  FFf3zP(self.SELF, txt, title=self.Title)
 def VVlhgA(self):
  thrList = []
  for thr in iEnumerate():
   if self.VVP9AA in thr.name:
    thrList.append(thr.name.replace(self.VVP9AA, ""))
  return thrList
 def VVgqmL(self):
  decodedUrl = self.VVapBp.VVwC4z()[9].strip()
  return decodedUrl in self.VVlhgA()
 def VVnGnu(self):
  colList = self.VVapBp.VVwC4z()
  path = colList[6].strip()
  size = colList[7].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFHtxR(path)) == size
 def VVwdac(self):
  colList = self.VVapBp.VVwC4z()
  path = colList[6].strip()
  size = int(colList[7].strip())
  curSize = FFHtxR(path)
  if curSize > -1:
   size -= curSize
  err = CCe2k3.VV6SyH(size)
  if err:
   FFf3zP(self.SELF, err, title=self.Title)
   return False
  return True
 def VVip1b(self, list):
  with open(CCe2k3.VVpkvx(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVN5aI(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCe2k3.VV6EM6()
  url = decodedUrl
  with open(CCe2k3.VVpkvx(), "w") as f:
   for line in lines:
    if CCe2k3.VVKPWa(decodedUrl, line):
     parts = line.split(",")
     oldUrl = ",".join(parts[1:]).strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVnIKl()
  return url
 @staticmethod
 def VV6EM6():
  list = []
  if fileExists(CCe2k3.VVpkvx()):
   for line in FF8ZwU(CCe2k3.VVpkvx()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVKPWa(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VV6SyH(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCin0f.VVSeiy(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCin0f.VVPicv(size), CCin0f.VVPicv(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVeTb4(SELF):
  tot = CCe2k3.VVHVpd()
  if tot:
   FFf3zP(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVHVpd():
  c = 0
  for thread in iEnumerate():
   if thread.name.startswith(CCe2k3.VVP9AA):
    c += 1
  return c
 @staticmethod
 def VVlmfj():
  return len(CCe2k3.VV6EM6()) == 0
 @staticmethod
 def VV5x7N():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VV5Eqs():
  mPoints = CCe2k3.VV5x7N()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFrWND("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVpkvx():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVLmGk(SELF):
  CCe2k3.VVzeHd(SELF, CCe2k3.VVg84Q)
 @staticmethod
 def VVtBAK_cur(SELF):
  CCe2k3.VVzeHd(SELF, CCe2k3.VVGXD0, startDnld=True)
 @staticmethod
 def VVtBAK_url(SELF, url):
  CCe2k3.VVzeHd(SELF, CCe2k3.VVGXD0, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVh2sKCurrent(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(SELF)
  added, skipped = CCe2k3.VVh2sKList([decodedUrl])
  FF6E92(SELF, "Added", 1000)
 @staticmethod
 def VVh2sKList(list):
  added = skipped = 0
  for line in CCe2k3.VV6EM6():
   for ndx, url in enumerate(list):
    if url and CCe2k3.VVKPWa(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCe2k3.VVpkvx(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVzeHd(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCCqon.VVUkNu(SELF):
   return
  if mode == CCe2k3.VVg84Q and CCe2k3.VVlmfj():
   FFf3zP(SELF, "Download list is empty !", title=title)
  else:
   inst = CCe2k3(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
class CC9pOJ(Screen, CCNVFP):
 VVklBc = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False, enableDownloadMenu=True):
  self.skin, self.skinParam = FFSDka(VVmtqj, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCNVFP.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  self.SubtWin    = None
  FFyutK(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVyqoM())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVNPMZ         ,
   "info"  : self.VVn4zP        ,
   "epg"  : self.VVn4zP        ,
   "menu"  : self.VVUdz5       ,
   "cancel" : self.cancel         ,
   "blue"  : self.VVmzD4        ,
   "green"  : self.VVWWn2    ,
   "yellow" : self.VVbom5   ,
   "left"  : boundFunction(self.VV8I7r, -1)   ,
   "right"  : boundFunction(self.VV8I7r,  1)   ,
   "play"  : self.VV77Az        ,
   "pause"  : self.VV77Az        ,
   "playPause" : self.VV77Az        ,
   "stop"  : self.VV77Az        ,
   "rewind" : self.VVopPj        ,
   "forward" : self.VV0HTb        ,
   "rewindDm" : self.VVopPj        ,
   "forwardDm" : self.VV0HTb        ,
   "last"  : self.VVQzff        ,
   "next"  : self.VV1f0O        ,
   "pageUp" : boundFunction(self.VVZloq, True) ,
   "pageDown" : boundFunction(self.VVZloq, False) ,
   "chanUp" : boundFunction(self.VVZloq, True) ,
   "chanDown" : boundFunction(self.VVZloq, False) ,
   "up"  : boundFunction(self.VVZloq, True) ,
   "down"  : boundFunction(self.VVZloq, False) ,
   "audio"  : boundFunction(self.VVjTmC, True) ,
   "subtitle" : boundFunction(self.VVjTmC, False) ,
   "0"   : boundFunction(self.VVDFZt , 10)  ,
   "1"   : boundFunction(self.VVDFZt , 1)  ,
   "2"   : boundFunction(self.VVDFZt , 2)  ,
   "3"   : boundFunction(self.VVDFZt , 3)  ,
   "4"   : boundFunction(self.VVDFZt , 4)  ,
   "5"   : boundFunction(self.VVDFZt , 5)  ,
   "6"   : boundFunction(self.VVDFZt , 6)  ,
   "7"   : boundFunction(self.VVDFZt , 7)  ,
   "8"   : boundFunction(self.VVDFZt , 8)  ,
   "9"   : boundFunction(self.VVDFZt , 9)
  }, -1)
  self.onShown.append(self.VVSdHz)
  self.onClose.append(self.onExit)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FFDx5r(self)
  if not CC9pOJ.VVklBc:
   CC9pOJ.VVklBc = self
  else:
   self.close()
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFbjWp(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFbjWp(self["myPlayRpt"], "rpt")
  self.VVvziY()
  self.instance.move(ePoint(40, 40))
  self.VVzEyW(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVpi4S)
  except:
   self.timer.callback.append(self.VVpi4S)
  self.timer.start(250, False)
  self.VVpi4S("Checking ...")
  self.VVtdvL()
 def VVWWn2(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self)
  if "chCode" in iptvRef:
   if CCCqon.VVUkNu(self):
    self.VVtdvL(True)
 def VVvziY(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl:
   color = "#1120002a"
   self["myPlayGrn"].show()
  else:
   color = "#1100202a"
   self["myPlayGrn"].hide()
  FF6nEU(self["myTitle"], color)
 def VVUdz5(self):
  if self.SubtWin:
   self.SubtWin.VVi4eX()
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self)
  VV23GK = []
  if self.isFromExternal:
   VV23GK.append(("IPTV Menu"     , "iptv"  ))
   VV23GK.append(VV15MX)
  if FFzYwA(iptvRef) and not "&end=" in decodedUrl and not FFk8k1(decodedUrl):
   uType, uHost, uUser, uPass, uId, uChName = CCFXWw.VVdr9M(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VV23GK.append(("Catchup Programs"   , "catchup"  ))
    VV23GK.append(VV15MX)
  VV23GK.append(("Stop Current Service"    , "stop"  ))
  VV23GK.append(("Restart Current Service"   , "restart"  ))
  VV23GK.append(VV15MX)
  FF8rbSSeries = FFk8k1(decodedUrl)
  if FF8rbSSeries:
   VV23GK.append(("File Size"     , "fileSize" ))
   VV23GK.append(VV15MX)
  if self.enableDownloadMenu:
   addSep = False
   if FFzYwA(iptvRef) and FF8rbSSeries:
    VV23GK.append(("Start Download"   , "dload_cur" ))
    VV23GK.append(("Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCe2k3.VVlmfj():
    VV23GK.append(("Download Manager"   , "dload_stat" ))
    addSep = True
   if addSep:
    VV23GK.append(VV15MX)
  addSep = False
  fPath, fDir, fName = CCin0f.VVi90Z(self)
  if fPath:
   if not CCin0f.VVD0Fo:
    VV23GK.append((VVAjxB + "Open path in File Manager" , "VVuHFQ" ))
    addSep = True
   if fPath:
    VV23GK.append((VVAjxB + 'Add to "My Movies" Bouquet' , "VVmBLY" ))
    VV23GK.append((VVAjxB + "Start Subtitle"    , "VVYGVr"  ))
    addSep = True
   if addSep:
    VV23GK.append(VV15MX)
   VV23GK.append(("%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVjK1Z" ))
   VV23GK.append(VV15MX)
  if CFG.playerPos.getValue() : VV23GK.append(("Move Bar to Bottom"  , "botm"  ))
  else      : VV23GK.append(("Move Bar to Top"  , "top"   ))
  VV23GK.append(("Help"             , "help"  ))
  FFdX2v(self, self.VVI4bs, VV23GK=VV23GK, width=550, title="Options")
 def VVI4bs(self, item=None):
  if item:
   if item == "iptv"     : self.VVGEv7()
   elif item == "catchup"    : self.VVbom5()
   elif item == "stop"     : self.VVXE75(0)
   elif item == "restart"    : self.VVXE75(1)
   elif item == "fileSize"    : FFshid(self, boundFunction(CCkvvO.VVSOb0, self), title="Checking Server")
   elif item == "dload_cur"   : CCe2k3.VVtBAK_cur(self)
   elif item == "addToDload"   : CCe2k3.VVh2sKCurrent(self)
   elif item == "dload_stat"   : CCe2k3.VVLmGk(self)
   elif item == "VVuHFQ" : self.VVuHFQ()
   elif item == "VVmBLY" : FFshid(self, self.VVmBLY)
   elif item == "VVYGVr"  : self.VVYGVr(CCUHIj.VVq5dS)
   elif item == "VVjK1Z"  : self.VVjK1Z()
   elif item == "botm"     : self.VVzEyW(0)
   elif item == "top"     : self.VVzEyW(1)
   elif item == "help"     : FFiYdB(self, VVBZq2 + "_help_player", "Player Controller (Keys)")
 def onExit(self):
  self.timer.stop()
  CC9pOJ.VVklBc = None
  self.VVaQT2()
 def VVAI8o(self):
  if CC9pOJ.VVklBc:
   self.session.open(CC9pOJ, enableZapping= False, enableDownloadMenu=False)
  self.close()
 def VVuHFQ(self):
  self.session.open(CCin0f, gotoMovie=True)
  self.VVAI8o()
 def VVGEv7(self):
  self.session.open(CCFXWw)
  self.VVAI8o()
 def VVXE75(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.close()
   elif typ == 1:
    self.VVpi4S("Restarting Service ...")
    FFRXLV(boundFunction(self.VVHoUW, serv))
 def VVHoUW(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self)
  if "&end=" in decodedUrl: boundFunction(self.VVtdvL, True)
  else     : self.session.nav.playService(serv)
 def VVmBLY(self):
  title = "Add Movie to Bouquet"
  bName = "My Movies"
  path  = VVF0QF + "userbouquet.my_local_movies.tv"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self)
  fPath, fDir, fName = CCin0f.VVi90Z(self)
  if not fPath or not chName:
   FFf3zP(self, "Cannot read Path or Channel Name", title=title)
   return
  isNew = False
  if not fileExists(path):
   isNew = True
   with open(path, "w") as f:
    f.write("#NAME %s\n" % bName)
  catID, stID, chNum = "1638", "6", "6"
  refCode = CCFXWw.VV17ho(catID, stID, chNum)
  if not isNew:
   fTxt = FFp1Ek(path)
   chUrl_noRef = "%s:%s" % (fPath, chName)
   if chUrl_noRef in fTxt:
    FFf3zP(self, "Already added to bouquet:\n\n%s" % bName, title=title)
    return
   for ns in range(1, 65535 - 1):
    catID, stID, chNum = "1638", str(ns), "6"
    refCode = CCFXWw.VV17ho(catID, stID, chNum)
    if not refCode in fTxt:
     break
   else:
    FFf3zP(self, "Cannot create a unique Reference Code", title=title)
    return
  if refCode and fPath and chName:
   chUrl = "%s%s:%s" % (refCode, fPath, chName)
   with open(path, "a") as f:
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
   piconOk = self.VVdLEl(refCode)
   FFodem(os.path.basename(path))
   FFVeqY()
   FFTVfn(self, "Added to bouquet:\n\n%s" % bName, title=title + (" (with PIcon)" if piconOk else ""))
  else:
   FFf3zP(self, "Cannot create a unique Reference Code", title=title)
   return
 def VVjK1Z(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC9pOJ.VVDysK(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVpi4S(txt, highlight=ok)
 def VVYGVr(self, mode, useSubtFile=""):
  self.hide()
  self.SubtWin = self.session.instantiateDialog(CCUHIj, mode=mode, endCallback=self.VVwbb0)
  self.SubtWin.show()
  self.SubtWin.VVbE4r(useSubtFile)
 def VVwbb0(self, err):
  if err:
   if err == "noResume": self.VVaQT2(False)
   else    : self.VVaQT2(True)
   if   err == "noResume" : return
   if   err == "noErr"  : return
   elif err == "noAutoSrt" : CCUHIj.VVX81Y(self, self.VVfxfa)
   else      : FF6E92(self, err, 2000)
 def VVfxfa(self, path):
  if path:
   self.VVYGVr(CCUHIj.VVq5dS, useSubtFile=path)
 def VVdLEl(self, refCode):
  fPath, fDir, fName, picFile = CCkvvO.VV4GNS(self)
  pPath = CCkYaA.VVN8ry()
  if fileExists(pPath) and pathExists(picFile):
   pFile = refCode.replace(":", "_").strip("_") + ".png"
   dest = os.path.join(pPath, pFile)
   os.system(FFrWND("cp -f '%s' '%s'" % (picFile, dest)))
   os.system(FFrWND("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (dest, dest)))
   return True
  return False
 def VVzEyW(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VVNPMZ(self):
  if self.isManualSeek:
   self.VVb0Lq()
   self.VVd7g1(self.manualSeekPts)
  else:
   if self.shown:
    self.hide()
    self.VVYGVr(CCUHIj.VVTE3E)
   else:
    self.VVaQT2()
 def VVaQT2(self, showBar=True):
  if self.SubtWin:
   self.session.deleteDialog(self.SubtWin)
   self.SubtWin = None
  if showBar:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVb0Lq()
  elif self.SubtWin : self.VVaQT2()
  else    : self.close()
 def VVn4zP(self):
  if self.SubtWin:
   self.SubtWin.VVBuXT("noErr")
  FFMw5O(self, fncMode=CCkvvO.VVJhTr)
 def VV77Az(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except Exception as e:
   pass
  self.VVpi4S("Toggling Play/Pause ...")
 def VVb0Lq(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VV8I7r(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC9pOJ.VVDysK(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVV7Wb()
   else:
    self.manualSeekSec += direc * self.VVV7Wb()
    self.manualSeekSec = FFKZ30(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFqpoV(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFN2Gj(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVDFZt(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVyqoM())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVpi4S("Changed Seek Time to : %d%s" % (val, self.VVbN1D()))
 def VVyqoM(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVbN1D())
 def VVbN1D(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVFLJY(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVV7Wb(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVpi4S(self, stateTxt="", highlight=False):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFgUBe(self, addInfoObj=True)
  fr = res = ""
  if info:
   w = FF7eDN(info, iServiceInformation.sVideoWidth) or -1
   h = FF7eDN(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FF7eDN(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CCkvvO.VVyx4P(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC9pOJ.VVDysK(self)
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FFKZ30(percVal, 0, 100)
    width = int(FFqpoV(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not posTxt: self["myPlayPos"].setText("")
  if not remTxt: self["myPlayRem"].setText("")
  if not durTxt:
   if   prov : txt = prov
   elif posTxt : txt = ">>>>"
   else  : txt = "...."
   self["myPlayVal"].setText(txt)
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText("")
   FF6nEU(self["myPlayBarBG"], "#1100202a")
   self["myPlayBarF"].hide()
  else:
   FF6nEU(self["myPlayBarBG"], "#11000000")
   self["myPlayBarF"].show()
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VV1Omn() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   if highlight: FFE31q(self["myPlayMsg"], "#0000ffff")
   else  : FFE31q(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   self["myPlayMsg"].setText("-" if decodedUrl else FF3fRh(refCode, True))
   FFE31q(self["myPlayMsg"], "#00ff8066")
  tot = CCe2k3.VVHVpd()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVoBhs()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VVd7g1(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVQzff()
  state = self.VVou8U()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFE31q(self["myPlayMsg"], "#0000ff00")
  else     : FFE31q(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 @staticmethod
 def VVDysK(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFN2Gj(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFN2Gj(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFN2Gj(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVoBhs(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVmzD4(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VV1Omn()
   if cList:
    VV23GK = []
    for pts, what in cList:
     txt = FFN2Gj(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VV23GK.append((txt, pts))
    FFdX2v(self, self.VVfk0Y, VV23GK=VV23GK, title="Cut List")
   else:
    self.VVpi4S("No Cut-List for this channel !")
 def VVfk0Y(self, item=None):
  if item:
   self.VVd7g1(item)
 def VV1Omn(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VV0HTb(self) : self.VVvXqw(1)
 def VVopPj(self) : self.VVvXqw(-1)
 def VVvXqw(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC9pOJ.VVDysK(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVV7Wb() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVFLJY())
    self.VVpi4S(txt)
  except:
   self.VVpi4S("Cannot jump")
 def VVd7g1(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVpi4S("Changing Time ...")
 def VVQzff(self):
  self.VVXE75(1)
  self.VVpi4S("Replaying ...")
  self.VVb0Lq()
 def VV1f0O(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC9pOJ.VVDysK(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVpi4S("Jumping to end ...")
  except:
   pass
 def VVou8U(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVZloq(self, isUp):
  if self.enableZapping:
   self.VVpi4S("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVb0Lq()
   if self.portalTableParam:
    FFRXLV(boundFunction(self.VVELE2, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self)
    if "/timeshift/" in decodedUrl:
     self.VVpi4S("Cannot Zap Catcup TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVQZ21()
 def VVQZ21(self):
  self.lastPlayPos = 0
  self.VVvziY()
  self.VVtdvL()
 def VVELE2(self, isUp):
  CCFXWw_inatance, VVapBp, mode = self.portalTableParam
  if isUp : VVapBp.VVKSd7()
  else : VVapBp.VVqQzH()
  colList = VVapBp.VVwC4z()
  if mode == "localIptv":
   chName, chUrl = CCFXWw_inatance.VVrXrx(VVapBp, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCFXWw_inatance.VVUqnL(VVapBp, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCFXWw_inatance.VVBboT(mode, VVapBp, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCFXWw_inatance.VVoies(mode, VVapBp, colList)
  else:
   self.VVpi4S("Cannot Zap")
   return
  FFjNnf(self, chUrl, VVOpaL=False)
  self.VVQZ21()
 def VVtdvL(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC9pOJ.VVDysK(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self)
   if not self.VVBwLw(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVpi4S("Refreshing Portal")
   FFRXLV(self.VVBoR0)
  except:
   pass
 def VVBoR0(self):
  self.restoreLastPlayPos = self.VVp7S6()
 def VVbom5(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFgUBe(self)
  if not decodedUrl or FFk8k1(decodedUrl):
   self.VVpi4S("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCFXWw.VVdr9M(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVpi4S("Reading Program List ...")
   ok_fnc = boundFunction(self.VV4pe6, refCode, chName, streamId, uHost, uUser, uPass)
   FFRXLV(boundFunction(CCFXWw.VVlkp7, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVpi4S("Cannot process this channel")
 def VV4pe6(self, refCode, chName, streamId, uHost, uUser, uPass, VVapBp, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVapBp.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVpi4S("Changing Program ...")
   FFRXLV(boundFunction(self.VVLMwj, chUrl))
  else:
   self.VVpi4S("Incorrect Timestamp !")
 def VVLMwj(self, chUrl):
   FFjNnf(self, chUrl, VVOpaL=False)
   self.lastPlayPos = 0
   self.VVvziY()
 def VVjTmC(self, isAudio):
  try:
   VVKFsj = InfoBar.instance
   if VVKFsj:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVKFsj)
    else  : self.session.open(SubtitleSelection, VVKFsj)
  except:
   pass
class CCWmhj(Screen):
 def __init__(self, session, title="", VVoTby="Continue?", VVYAYv=True, VVCyqa=False):
  self.skin, self.skinParam = FFSDka(VVTlN4, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVoTby = VVoTby
  self.VVCyqa = VVCyqa
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVYAYv : VV23GK = [no , yes]
  else   : VV23GK = [yes, no ]
  FFyutK(self, title, VV23GK=VV23GK, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVNPMZ ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVoTby)
  if self.VVCyqa:
   self["myLabel"].instance.setHAlign(0)
  self.VVQXRy()
  FFTEKh(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFOTtB(self["myMenu"])
  FFtYxN(self, self["myMenu"])
 def VVNPMZ(self):
  item = FFrrou(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVQXRy(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCQxIB(Screen):
 def __init__(self, session, title="", VV23GK=None, width=1000, height=0, OKBtnFnc=None, VVp90K=None, VVwqMz=None, VVrMQs=None, VVvFvy=None, VVdwiN=False, VVqC46=False):
  if height == 0: height = 850
  self.skin, self.skinParam = FFSDka(VVTY88, width, height, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VV23GK   = VV23GK
  self.OKBtnFnc   = OKBtnFnc
  self.VVp90K   = VVp90K
  self.VVwqMz  = VVwqMz
  self.VVrMQs  = VVrMQs
  self.VVvFvy   = VVvFvy
  self.VVdwiN  = VVdwiN
  self.VVqC46  = VVqC46
  FFyutK(self, title, VV23GK=VV23GK)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVNPMZ          ,
   "cancel" : self.cancel          ,
   "red"  : self.VV0Chq         ,
   "green"  : self.VVIDBd         ,
   "yellow" : self.VV7qpQ         ,
   "blue"  : self.VV2F6s         ,
   "pageUp" : self.VVcGbt       ,
   "chanUp" : self.VVcGbt       ,
   "pageDown" : self.VVuXNx        ,
   "chanDown" : self.VVuXNx
  }, -1)
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FFTEKh(self["myMenu"])
  FFm42V(self)
  self.VVDEGI(self["keyRed"]  , self.VVp90K )
  self.VVDEGI(self["keyGreen"] , self.VVwqMz )
  self.VVDEGI(self["keyYellow"] , self.VVrMQs )
  self.VVDEGI(self["keyBlue"]  , self.VVvFvy )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FF22W2(self)
 def VVDEGI(self, btnObj, btnFnc):
  if btnFnc:
   FFdk5e(btnObj, btnFnc[0])
 def VVNPMZ(self):
  item = FFrrou(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVdwiN: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VV0Chq(self)  : self.VVnAax(self.VVp90K)
 def VVIDBd(self) : self.VVnAax(self.VVwqMz)
 def VV7qpQ(self) : self.VVnAax(self.VVrMQs)
 def VV2F6s(self) : self.VVnAax(self.VVvFvy)
 def VVnAax(self, btnFnc):
  if btnFnc:
   item = FFrrou(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVqC46:
    self.cancel()
 def VV7n8k(self):
  ndx = self["myMenu"].getSelectedIndex()
  VV23GK = self["myMenu"].list
  VV23GK.pop(ndx)
  if len(VV23GK) > 0: self["myMenu"].setList(VV23GK)
  else    : self.close()
 def VVmxo3(self, VV23GK):
  if len(VV23GK) > 0:
   newList = []
   for item in VV23GK:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVTTlI(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVcGbt(self):
  self["myMenu"].moveToIndex(0)
 def VVuXNx(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCr4It(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VVYDUR=None, VVbtsV=None, VV5EM1=None, VVzOAn=26, VViKTA=False, VVBmAn=None, VVscS4=None, VVCAcJ=None, VVtony=None, VVKCEj=None, VVwFPr=None, VVV8bN=None, VVd4rs=None, VVyVHa=None, VV4Isj=-1, VV5Y0Y=False, searchCol=0, VVRbex=None, VVihVe=None, VVcAi1="#00dddddd", VVwsQj="#11002233", VVfIrn="#00ff8833", VVzAxe="#11111111", VVrSmG="#0a555555", VVDW44="#0affffff", VVIRVU="#11552200", VVhdpI="#0055ff55"):
  self.skin, self.skinParam = FFSDka(VVRYc1, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFyutK(self, title)
  self.header     = header
  self.VVYDUR     = VVYDUR
  self.totalCols    = len(VVYDUR[0])
  self.VVFAjs   = 0
  self.lastSortModeIsReverese = False
  self.VViKTA   = VViKTA
  self.VVZ3zE   = 0.01
  self.VVxCIT   = 0.02
  self.VV4MXF = 0.03
  self.VVXsnQ  = 1
  self.VV5EM1 = VV5EM1
  self.colWidthPixels   = []
  self.VVBmAn   = VVBmAn
  self.OKButtonObj   = None
  self.VVscS4   = VVscS4
  self.VVCAcJ   = VVCAcJ
  self.VVtony   = VVtony
  self.VVKCEj  = VVKCEj
  self.VVwFPr   = VVwFPr
  self.VVV8bN    = VVV8bN
  self.VVd4rs   = VVd4rs
  self.VVyVHa  = VVyVHa
  self.VV4Isj    = VV4Isj
  self.VV5Y0Y   = VV5Y0Y
  self.searchCol    = searchCol
  self.VVbtsV    = VVbtsV
  self.keyPressed    = -1
  self.VVzOAn    = FFyq7C(VVzOAn)
  self.VVtEei    = FFMWzO(self.VVzOAn, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVRbex    = VVRbex
  self.VVihVe      = VVihVe
  self.VVcAi1    = FFeFJJ(VVcAi1)
  self.VVwsQj    = FFeFJJ(VVwsQj)
  self.VVfIrn    = FFeFJJ(VVfIrn)
  self.VVzAxe    = FFeFJJ(VVzAxe)
  self.VVrSmG   = FFeFJJ(VVrSmG)
  self.VVDW44    = FFeFJJ(VVDW44)
  self.VVIRVU    = FFeFJJ(VVIRVU)
  self.VVhdpI   = FFeFJJ(VVhdpI)
  self.VVBMjk  = False
  self.selectedItems   = 0
  self.VVY49z   = FFeFJJ("#01fefe01")
  self.VVNmJR   = FFeFJJ("#11400040")
  self.VVgviS  = self.VVY49z
  self.VVYxDE  = self.VVzAxe
  if self.VV5Y0Y:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVtgkG  ,
   "red"   : self.VVGw07  ,
   "green"   : self.VV4fNN ,
   "yellow"  : self.VVDOYf ,
   "blue"   : self.VVX8In  ,
   "menu"   : self.VVGjLT ,
   "info"   : self.VVAel2  ,
   "cancel"  : self.VVkxR6  ,
   "up"   : self.VVqQzH    ,
   "down"   : self.VVKSd7  ,
   "left"   : self.VVUbWj   ,
   "right"   : self.VVMhsB  ,
   "pageUp"  : self.VVOuOB  ,
   "chanUp"  : self.VVOuOB  ,
   "pageDown"  : self.VVOPtk  ,
   "chanDown"  : self.VVOPtk
  }, -1)
  FFffd6(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FFDx5r(self)
  try:
   self.VVkAKF()
  except Exception as err:
   FFf3zP(self, str(err))
   self.close(None)
 def VVkAKF(self):
  FF22W2(self)
  if self.VVRbex:
   FF6nEU(self["myTitle"], self.VVRbex)
  if self.VVihVe:
   FF6nEU(self["myBody"] , self.VVihVe)
   FF6nEU(self["myTableH"] , self.VVihVe)
   FF6nEU(self["myTable"] , self.VVihVe)
   FF6nEU(self["myBar"]  , self.VVihVe)
  self.VVDEGI(self.VVCAcJ  , self["keyRed"])
  self.VVDEGI(self.VVtony  , self["keyGreen"])
  self.VVDEGI(self.VVKCEj , self["keyYellow"])
  self.VVDEGI(self.VVwFPr  , self["keyBlue"])
  if self.VVBmAn:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVBmAn[0])
    FF6nEU(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVtEei)
  self["myTableH"].l.setFont(0, gFont(VVTpI8, self.VVzOAn))
  self["myTable"].l.setItemHeight(self.VVtEei)
  self["myTable"].l.setFont(0, gFont(VVTpI8, self.VVzOAn))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVtEei)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVtEei))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVtEei)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVtEei
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVtEei * len(self.VVYDUR) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VV5EM1:
   self.VV5EM1 = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VV5EM1)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVbtsV:
   self.VVbtsV = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVbtsV
   self.VVbtsV = []
   for item in tmpList:
    self.VVbtsV.append(item | RT_VALIGN_CENTER)
  self.VVxNjW()
  if self.VVV8bN:
   self.VVV8bN(self)
 def VVDEGI(self, btnFnc, btn):
  if btnFnc : FFdk5e(btn, btnFnc[0])
  else  : FFdk5e(btn, "")
 def VVZz2O(self, waitTxt):
  FFshid(self, self.VVxNjW, title=waitTxt)
 def VVxNjW(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVeqcr(0, self.header, self.VVDW44, self.VVIRVU, self.VVDW44, self.VVIRVU, self.VVhdpI)])
   rows = []
   for c, row in enumerate(self.VVYDUR):
    rows.append(self.VVeqcr(c, row, self.VVcAi1, self.VVwsQj, self.VVfIrn, self.VVzAxe, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VV4Isj > -1:
    self["myTable"].moveToIndex(self.VV4Isj )
   self.VVEbkk()
   if self.VV5Y0Y:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVtEei * len(self.VVYDUR)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVd4rs:
    self.VVnAax(self.VVd4rs, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFf3zP(self, str(err))
    self.close()
   except:
    pass
 def VVeqcr(self, keyIndex, columns, VVcAi1, VVwsQj, VVfIrn, VVzAxe, VVhdpI):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVhdpI and ndx == self.VVFAjs : textColor = VVhdpI
   else           : textColor = VVcAi1
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFeFJJ(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVwsQj = c
    entry = span.group(3)
   if self.VVbtsV[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVtEei)
           , font   = 0
           , flags   = self.VVbtsV[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVwsQj
           , color_sel  = VVfIrn
           , backcolor_sel = VVzAxe
           , border_width = 1
           , border_color = self.VVrSmG
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVAel2(self):
  rowData = self.VV4nWh()
  if rowData:
   title, txt, colList = rowData
   if self.VVscS4:
    fnc  = self.VVscS4[1]
    params = self.VVscS4[2]
    fnc(self, title, txt, colList)
   else:
    FF9Qkx(self, txt, title)
 def VVtgkG(self):
  if   self.VVBMjk : self.VV0WTY(self.VVcTYx(), mode=2)
  elif self.VVBmAn  : self.VVnAax(self.VVBmAn, None)
  else      : self.VVAel2()
 def VVGw07(self) : self.VVnAax(self.VVCAcJ , self["keyRed"])
 def VV4fNN(self) : self.VVnAax(self.VVtony , self["keyGreen"])
 def VVDOYf(self): self.VVnAax(self.VVKCEj , self["keyYellow"])
 def VVX8In(self) : self.VVnAax(self.VVwFPr , self["keyBlue"])
 def VVnAax(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FF6E92(self, buttonFnc[3])
    FFRXLV(boundFunction(self.VV6DB7, buttonFnc))
   else:
    self.VV6DB7(buttonFnc)
 def VV6DB7(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VV4nWh()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VV0WTY(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VVYDUR[ndx]
   isSelected = row[1][9] == self.VVY49z
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVeqcr(ndx, item, self.VVcAi1, self.VVwsQj, self.VVfIrn, self.VVzAxe, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVeqcr(ndx, item, self.VVY49z, self.VVNmJR, self.VVgviS, self.VVYxDE, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVEbkk()
 def VV6QlI(self):
  FFshid(self, self.VViFj2, title="Selecting all ...")
 def VViFj2(self):
  self.VVBnQy(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVY49z
   if not isSelected:
    item = self.VVYDUR[ndx]
    newRow = self.VVeqcr(ndx, item, self.VVY49z, self.VVNmJR, self.VVgviS, self.VVYxDE, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVEbkk()
  self.VVGfKv()
 def VVphsY(self):
  FFshid(self, self.VV6FsF, title="Unselecting all ...")
 def VV6FsF(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVY49z:
    item = self.VVYDUR[ndx]
    newRow = self.VVeqcr(ndx, item, self.VVcAi1, self.VVwsQj, self.VVfIrn, self.VVzAxe, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVEbkk()
  self.VVGfKv()
 def VVGfKv(self):
  self.hide()
  self.show()
 def VV4nWh(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VV5EM1[i] > 1 or self.VV5EM1[i] == self.VVZ3zE or self.VV5EM1[i] == self.VV4MXF:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VVYDUR))
   return rowNum, txt, colList
  else:
   return None
 def VVkxR6(self):
  if self.VVyVHa : self.VVyVHa(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVGIFi(self):
  return self["myTitle"].getText().strip()
 def VV2g6P(self):
  return self.header
 def VVQNhv(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VV3Sbk(self, txt):
  FF6E92(self, txt)
 def VV1J0Q(self, txt):
  FF6E92(self, txt, 1000)
 def VVP0Av(self):
  FF6E92(self)
 def VVSx26(self):
  return len(self.VVYDUR)
 def VV7T41(self): self["keyGreen"].show()
 def VVx5Ai(self): self["keyGreen"].hide()
 def VVcTYx(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VV4jLZ(self):
  return len(self["myTable"].list)
 def VVBnQy(self, isOn):
  self.VVBMjk = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu"].hide()
   if self.VVwFPr: self["keyBlue"].hide()
   if self.VVBmAn and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVwFPr: self["keyBlue"].show()
   if self.VVBmAn and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVBmAn[0])
   self.VVphsY()
  FF6nEU(self["myTitle"], color)
  FF6nEU(self["myBar"]  , color)
 def VVROxa(self):
  return self.VVBMjk
 def VVoHzk(self):
  return self.selectedItems
 def VVuO0F(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VVEbkk()
 def VV910I(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVEbkk()
 def VVT7Kr(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VVYDUR:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVyhHL(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVSx26()
  txt += FFJKjn("Total Unique Items", VVd9bM)
  for i in range(self.totalCols):
   if self.VV5EM1[i - 1] > 1 or self.VV5EM1[i - 1] == self.VVZ3zE or self.VV5EM1[i - 1] == self.VV4MXF:
    name, tot = self.VVT7Kr(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FF9Qkx(self, txt)
 def VVTj1i(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVwC4z(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVs7In(self, newList, newTitle="", VVS2I9Msg=True):
  if newList:
   self.VVYDUR = newList
   if self.VViKTA and self.VVFAjs == 0:
    self.VVYDUR = sorted(self.VVYDUR, key=lambda x: int(x[self.VVFAjs])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VVYDUR = sorted(self.VVYDUR, key=lambda x: x[self.VVFAjs].lower(), reverse=self.lastSortModeIsReverese)
   if VVS2I9Msg : self.VVZz2O("Refreshing ...")
   else   : self.VVxNjW()
   if newTitle:
    self.VVQNhv(newTitle)
  else:
   FFf3zP(self, "Cannot refresh list")
   self.cancel()
 def VVFZW7(self, data):
  ndx = self.VVcTYx()
  newRow = self.VVeqcr(ndx, data, self.VVcAi1, self.VVwsQj, self.VVfIrn, self.VVzAxe, None)
  if newRow:
   self.VVYDUR[ndx] = data
   self["myTable"].list[ndx] = newRow
   self.VVEbkk()
   return True
  else:
   return False
 def VVdBnG(self, colNum, textToFind, VVHov8=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVEbkk()
    break
  else:
   if VVHov8:
    FF6E92(self, "Not found", 1000)
 def VVaB7A(self, colDict, VVHov8=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVEbkk()
    return
  if VVHov8:
   FF6E92(self, "Not found", 1000)
 def VVaB7A_partial(self, colDict, VVHov8=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVEbkk()
    return
  if VVHov8:
   FF6E92(self, "Not found", 1000)
 def VVHEz0(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVNzhg(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVY49z:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVZWda(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VVY49z: return True
  else        : return False
 def VVsv7I(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVGjLT(self):
  if not self["keyMenu"].getVisible() or self.VV5Y0Y:
   return
  VV23GK = []
  VV23GK.append(("Table Statistcis"             , "tableStat"  ))
  VV23GK.append(VV15MX)
  VV23GK.append((FFhqic("Export Table to .html"     , VVd9bM) , "VVC7Vr" ))
  VV23GK.append((FFhqic("Export Table to .csv"     , VVd9bM) , "VVpLQE" ))
  VV23GK.append((FFhqic("Export Table to .txt (Tab Separated)", VVd9bM) , "VVAEoj" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VV5EM1[i] > 1 or self.VV5EM1[i] == self.VVxCIT:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VV23GK.append(VV15MX)
   if tot == 1 : VV23GK.append(("Sort", sList[0][1]))
   else  : VV23GK += sList
  FFdX2v(self, self.VVyoVS, VV23GK=VV23GK, title=self.VVGIFi())
 def VVyoVS(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVyhHL()
   elif item == "VVC7Vr": FFshid(self, self.VVC7Vr, title=title)
   elif item == "VVpLQE" : FFshid(self, self.VVpLQE , title=title)
   elif item == "VVAEoj" : FFshid(self, self.VVAEoj , title=title)
   else:
    isReversed = False
    if self.VVFAjs == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VViKTA and item == 0:
     self.VVYDUR = sorted(self.VVYDUR, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VVYDUR = sorted(self.VVYDUR, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVFAjs = item
    self.VVZz2O("Sorting ...")
 def VVqQzH(self):
  self["myTable"].up()
  self.VVEbkk()
 def VVKSd7(self):
  self["myTable"].down()
  self.VVEbkk()
 def VVUbWj(self):
  self["myTable"].pageUp()
  self.VVEbkk()
 def VVMhsB(self):
  self["myTable"].pageDown()
  self.VVEbkk()
 def VVOuOB(self):
  self["myTable"].moveToIndex(0)
  self.VVEbkk()
 def VVOPtk(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVEbkk()
 def VVP2LA(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVEbkk()
 def VVAEoj(self):
  expFile = self.VV1c9q() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVE16o()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VVYDUR:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VV5EM1[ndx] > self.VVXsnQ or self.VV5EM1[ndx] == self.VV4MXF:
      col = self.VVCN0z(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVf0V6(expFile)
 def VVpLQE(self):
  expFile = self.VV1c9q() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVE16o()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VVYDUR:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VV5EM1[ndx] > self.VVXsnQ or self.VV5EM1[ndx] == self.VV4MXF:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVCN0z(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVf0V6(expFile)
 def VVC7Vr(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVGIFi(), PLUGIN_NAME, VVvN9W)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVGIFi()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVE16o()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VV5EM1:
   colgroup += '   <colgroup>'
   for w in self.VV5EM1:
    if w > self.VVXsnQ or w == self.VV4MXF:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VV1c9q() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VVYDUR:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VV5EM1[ndx] > self.VVXsnQ or self.VV5EM1[ndx] == self.VV4MXF:
      col = self.VVCN0z(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVf0V6(expFile)
 def VVE16o(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VV5EM1[ndx] > self.VVXsnQ or self.VV5EM1[ndx] == self.VV4MXF:
     newRow.append(col.strip())
  return newRow
 def VVCN0z(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFjaTr(col)
 def VV1c9q(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVGIFi())
  fileName = fileName.replace("__", "_")
  path  = FFr9AH(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FF4Auk()
  return expFile
 def VVf0V6(self, expFile):
  FFTVfn(self, "File exported to:\n\n%s" % expFile, title=self.VVGIFi())
 def VVEbkk(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCw8PJ(Screen):
 def __init__(self, session, title="", VV5cQF=None, showGrnMsg=""):
  self.skin, self.skinParam = FFSDka(VVFRD7, 1400, 800, 30, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FFyutK(self, title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VV5cQF = VV5cQF
  self.showGrnMsg  = showGrnMsg
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  allOK = FFRJ4c(self["myLabel"], self.VV5cQF)
  if allOK:
   if self.showGrnMsg:
    FF6E92(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFf3zP(self, "Cannot view picture file:\n\n%s" % self.VV5cQF)
   self.close()
class CCftrN(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFSDka(VVWC5J, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 26, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFyutK(self, title=self.Title)
  FFdk5e(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Signal & Player Cotroller Hotkey"       , CFG.hotkey_signal    ))
  if VV7sfd:
   lst.append(getConfigListEntry("EPG Translation Language"        , CFG.epgLanguage    ))
  if VVgpZu:
   lst.append(getConfigListEntry("Force UTF-8 Encoding (only OpenVision Python-3.10.2+)" , CFG.forceUtf8Encoding   ))
  lst.append(getConfigListEntry(VVBOaW *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type"         , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsPath    ))
  lst.append(getConfigListEntry("Movie/Series Download Path"         , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(VVBOaW *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(VVBOaW *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB)"        , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons"            , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVTpwA()
  self.onShown.append(self.VVSdHz)
  self.onClose.append(self.onExit)
 def VVTpwA(self):
  kList = {
    "ok"  : self.VVNPMZ    ,
    "green"  : self.VVVXt7   ,
    "menu"  : self.VVMcR7  ,
    "cancel" : self.VVjt0D  ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"]  = boundFunction(self["config"].handleKey, kLeft)
   kList["right"]  = boundFunction(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = boundFunction(self["config"].VVxcJp, 0)
     kList["chanDown"] = boundFunction(self["config"].VVxcJp, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FFDx5r(self)
  FFTEKh(self["config"])
  FFm42V(self, self["config"])
  FF22W2(self)
  CFG.forceUtf8Encoding.addNotifier(self.VV70Py, initial_call=False)
 def onExit(self):
  CFG.forceUtf8Encoding.removeNotifier(self.VV70Py)
 def VV70Py(self, configElement=None):
  CC4HXa.VVp6xy()
 def VVNPMZ(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsPath   : self.VVQWBw()
   elif item == CFG.MovieDownloadPath   : self.VVnJGT(item, self["config"].getCurrent()[0])
   elif item == CFG.PIconsPath    : self.VVfOac(item)
   elif item == CFG.backupPath    : self.VVfOac(item)
   elif item == CFG.packageOutputPath  : self.VVfOac(item)
   elif item == CFG.downloadedPackagesPath : self.VVfOac(item)
   elif item == CFG.exportedTablesPath  : self.VVfOac(item)
   elif item == CFG.exportedPIconsPath  : self.VVfOac(item)
 def VVnJGT(self, item, title):
  tot = CCe2k3.VVHVpd()
  if tot : FFf3zP(self, "Cannot change while downloading.", title=title)
  else : self.VVfOac(item)
 def VVQWBw(self):
  VV23GK = []
  VV23GK.append(("Auto Find" , "auto"))
  VV23GK.append(("Custom Path" , "path"))
  FFdX2v(self, self.VV8Tvu, VV23GK=VV23GK, title="IPTV Hosts Files Path")
 def VV8Tvu(self, item=None):
  if item:
   if   item == "auto": CFG.iptvHostsPath.setValue(VVKvlq)
   elif item == "path": self.VVfOac(CFG.iptvHostsPath)
 def VVfOac(self, configObj):
  sDir = configObj.getValue()
  if sDir == VVKvlq:
   sDir = "/"
  self.session.openWithCallback(boundFunction(self.VVKcNT, configObj)
         , boundFunction(CCin0f, mode=CCin0f.VVgfa4, VVz9Oc=sDir))
 def VVKcNT(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVjt0D(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFCKL0(self, self.VVVXt7, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVVXt7(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VV1Mpc()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVMcR7(self):
  VV23GK = []
  VV23GK.append(("Use Backup directory in all other paths"      , "VVn1Xu"   ))
  VV23GK.append(("Reset all to default (including File Manager bookmarks)"  , "VV2TZP"   ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Backup %s Settings" % PLUGIN_NAME        , "VV7x72"  ))
  VV23GK.append(("Restore %s Settings" % PLUGIN_NAME       , "VVieaH"  ))
  if fileExists(VVXukQ + VVD4XV):
   VV23GK.append(VV15MX)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VV23GK.append(('%s Checking for Update' % txt1       , txt2     ))
   VV23GK.append(("Reinstall %s" % PLUGIN_NAME        , "VV9V2f"  ))
   VV23GK.append(("Update %s" % PLUGIN_NAME        , "VV4tCQ"   ))
  FFdX2v(self, self.VVV18E, VV23GK=VV23GK, title="Config. Options")
 def VVV18E(self, item=None):
  if item:
   if   item == "VVn1Xu"  : FFCKL0(self, self.VVn1Xu , "Use Backup directory in all other paths (and save) ?")
   elif item == "VV2TZP"  : FFCKL0(self, self.VV2TZP, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCtme9)
   elif item == "VV7x72" : self.VV7x72()
   elif item == "VVieaH" : FFshid(self, self.VVieaH, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVnoXc(True)
   elif item == "disableChkUpdate" : self.VVnoXc(False)
   elif item == "VV9V2f" : FFshid(self, self.VV9V2f , "Checking Server ...")
   elif item == "VV4tCQ"  : FFshid(self, self.VV4tCQ  , "Checking Server ...")
 def VV7x72(self):
  path = "%sajpanel_settings_%s" % (VVXukQ, FF4Auk())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFTVfn(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVieaH(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFIx6K("find / %s -iname '%s*' | grep %s" % (FF2qZL(1), name, name))
  if lines:
   lines.sort()
   VV23GK = []
   for line in lines:
    VV23GK.append((line, line))
   FFdX2v(self, boundFunction(self.VV5V12, title), title=title, VV23GK=VV23GK, width=1200)
  else:
   FFf3zP(self, "No settings files found !", title=title)
 def VV5V12(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FF8ZwU(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VV1Mpc()
    FFsIwZ()
   else:
    FFxtzL(SELF, path, title=title)
 def VVnoXc(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVn1Xu(self):
  newPath = FFr9AH(VVXukQ)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VV1Mpc()
 @staticmethod
 def VVoqEA():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VV2TZP(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.EventsInfoMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.epgLanguage.setValue("off")
  CFG.forceUtf8Encoding.setValue(True)
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.autoResetFrozenIptvChan.setValue(True)
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.iptvHostsPath.setValue(VVKvlq)
  CFG.MovieDownloadPath.setValue(CCe2k3.VV5Eqs())
  CFG.PIconsPath.setValue(VVo91x)
  CFG.backupPath.setValue(CCftrN.VVoqEA())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VV1Mpc()
  self.close()
 def VV1Mpc(self):
  configfile.save()
  global VVXukQ
  VVXukQ = CFG.backupPath.getValue()
  FFJ3AK()
 def VV4tCQ(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VV63uq(title)
  if webVer:
   FFCKL0(self, boundFunction(FFshid, self, boundFunction(self.VVWn87, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VV9V2f(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VV63uq(title, True)
  if webVer:
   FFCKL0(self, boundFunction(FFshid, self, boundFunction(self.VVWn87, webVer, title, True)), "Install and Restart ?", title=title)
 def VVWn87(self, webVer, title, isReinst=False):
  url = self.VV1lbJ(self, title)
  if url:
   VVPf2H = FFqGXf() == "dpkg"
   if VVPf2H == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVPf2H else "ipk")
   path, err = FF2QcO(url + fName, fName, timeout=2)
   if path:
    if isReinst : cmd = FFHppj(VVqCt4, path)
    else  : cmd = FFHppj(VViGNM, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFmkwf(self, cmd)
    else:
     FFywk7(self, title=title)
   else:
    FFf3zP(self, err, title=title)
 def VV63uq(self, title, anyVer=False):
  url = self.VV1lbJ(self, title)
  if not url:
   return ""
  path, err = FF2QcO(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFf3zP(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFp1Ek(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFf3zP(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVvN9W.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFIx6K(cmd)
   if list and curVer == list[0]:
    return webVer
  FFTVfn(self, FFhqic("No update required.", VVUnli) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VV1lbJ(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVXukQ + VVD4XV
  if fileExists(path):
   span = iSearch(r"(http.+)", FFp1Ek(path), IGNORECASE)
   if span : url = FFr9AH(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFf3zP(SELF, err, title)
  return url
 @staticmethod
 def VVvnK3(url):
  path, err = FF2QcO(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFp1Ek(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVvN9W.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFIx6K(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCtme9(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFSDka(VV7QkT, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVrHz1
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFyutK(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVYkd6("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVYkd6("\c00888888", i) + sp + "GREY\n"
   txt += self.VVYkd6("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVYkd6("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVYkd6("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVYkd6("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVYkd6("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVYkd6("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVYkd6("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVYkd6("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVYkd6("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVYkd6("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVNPMZ ,
   "green"   : self.VVNPMZ ,
   "left"   : self.VVB1cC ,
   "right"   : self.VVAeY3 ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  self.VVZKTc()
 def VVNPMZ(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFCKL0(self, self.VVIDH4, "Change to : %s" % txt, title=self.Title)
 def VVIDH4(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVrHz1
  VVrHz1 = self.cursorPos
  self.VVtGWt()
  self.close()
 def VVB1cC(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVZKTc()
 def VVAeY3(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVZKTc()
 def VVZKTc(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVYkd6(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVLf2h(color):
  if VVAjxB: return "\\" + color
  else    : return ""
 @staticmethod
 def VVtGWt():
  global VVf4dJ, VVcDYh, VVf5u2, VVd9bM, VVjqbJ, VVNYnt, VVUnli, VVAjxB, COLOR_CONS_BRIGHT_YELLOW, VVxzLQ, VVVd7L, VVB0Mu, VVX9gW
  VVX9gW   = CCtme9.VVYkd6("\c00FFFFFF", VVrHz1)
  VVcDYh    = CCtme9.VVYkd6("\c00888888", VVrHz1)
  VVf4dJ  = CCtme9.VVYkd6("\c005A5A5A", VVrHz1)
  VVNYnt    = CCtme9.VVYkd6("\c00FF0000", VVrHz1)
  VVf5u2   = CCtme9.VVYkd6("\c00FF5000", VVrHz1)
  VVAjxB   = CCtme9.VVYkd6("\c00FFFF00", VVrHz1)
  COLOR_CONS_BRIGHT_YELLOW = CCtme9.VVYkd6("\c00FFFFAA", VVrHz1)
  VVUnli   = CCtme9.VVYkd6("\c0000FF00", VVrHz1)
  VVjqbJ    = CCtme9.VVYkd6("\c000066FF", VVrHz1)
  VVxzLQ    = CCtme9.VVYkd6("\c0000FFFF", VVrHz1)
  VVVd7L  = CCtme9.VVYkd6("\c00DSFFFF", VVrHz1)  #
  VVB0Mu   = CCtme9.VVYkd6("\c00FA55E7", VVrHz1)
  VVd9bM    = CCtme9.VVYkd6("\c00FF8F5F", VVrHz1)
CCtme9.VVtGWt()
class CCp1zl(Screen):
 def __init__(self, session, path, VVPf2H):
  self.skin, self.skinParam = FFSDka(VVe0b2, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVcKV4   = path
  self.VVByhV   = ""
  self.VVY2rX   = ""
  self.VVPf2H    = VVPf2H
  self.VVFoZz    = ""
  self.VV74Q5  = ""
  self.VVQx6K    = False
  self.VV52Wv  = False
  self.postInstAcion   = 0
  self.VVYQ8o  = "enigma2-plugin-extensions"
  self.VVpVkU  = "enigma2-plugin-systemplugins"
  self.VVtT2L = "enigma2"
  self.VVIGjF  = 0
  self.VVvd4Q  = 1
  self.VVWyzs  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVL2A5 = "DEBIAN"
  else        : self.VVL2A5 = "CONTROL"
  self.controlPath = self.Path + self.VVL2A5
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVPf2H:
   self.packageExt  = ".deb"
   self.VVwsQj  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVwsQj  = "#11001020"
  FFyutK(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFdk5e(self["keyRed"] , "Create")
  FFdk5e(self["keyGreen"] , "Post Install")
  FFdk5e(self["keyYellow"], "Installation Path")
  FFdk5e(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVJMq4  ,
   "green"   : self.VVFXu7 ,
   "yellow"  : self.VV9n4g  ,
   "blue"   : self.VVBVtp  ,
   "cancel"  : self.VV494D
  }, -1)
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FF22W2(self)
  if self.VVwsQj:
   FF6nEU(self["myBody"], self.VVwsQj)
   FF6nEU(self["myLabel"], self.VVwsQj)
  self.VVIjPk(True)
  self.VVge46(True)
 def VVge46(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVPWgq()
  if isFirstTime:
   if   package.startswith(self.VVYQ8o) : self.VVcKV4 = VVGWw1 + self.VVFoZz + "/"
   elif package.startswith(self.VVpVkU) : self.VVcKV4 = VVIJZ6 + self.VVFoZz + "/"
   else            : self.VVcKV4 = self.Path
  if self.VVQx6K : myColor = VVd9bM
  else    : myColor = VVX9gW
  txt  = ""
  txt += "Source Path\t: %s\n" % FFhqic(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFhqic(self.VVcKV4, VVAjxB)
  if self.VVY2rX : txt += "Package File\t: %s\n" % FFhqic(self.VVY2rX, VVcDYh)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFhqic("Check Control File fields : %s" % errTxt, VVf5u2)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFhqic("Restart GUI", VVd9bM)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFhqic("Reboot Device", VVd9bM)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FFhqic("Post Install", VVUnli), act)
  if not errTxt and VVf5u2 in controlInfo:
   txt += "Warning\t: %s\n" % FFhqic("Errors in control file may affect the result package.", VVf5u2)
  txt += "\nControl File\t: %s\n" % FFhqic(self.controlFile, VVcDYh)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVFXu7(self):
  VV23GK = []
  VV23GK.append(("No Action"    , "noAction"  ))
  VV23GK.append(("Restart GUI"    , "VV6ZeF"  ))
  VV23GK.append(("Reboot Device"   , "rebootDev"  ))
  FFdX2v(self, self.VVTWPx, title="Package Installation Option (after completing installation)", VV23GK=VV23GK)
 def VVTWPx(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VV6ZeF"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVIjPk(False)
   self.VVge46()
 def VV9n4g(self):
  rootPath = FFhqic("/%s/" % self.VVFoZz, VVf4dJ)
  VV23GK = []
  VV23GK.append(("Current Path"        , "toCurrent"  ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Extension Path"       , "toExtensions" ))
  VV23GK.append(("System Plugins Path"      , "toSystemPlugins" ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VV23GK.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFdX2v(self, self.VVNJ8X, title="Installation Path", VV23GK=VV23GK)
 def VVNJ8X(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVENp8(FFL9q7(self.Path, True))
   elif item == "toExtensions"  : self.VVENp8(VVGWw1)
   elif item == "toSystemPlugins" : self.VVENp8(VVIJZ6)
   elif item == "toRootPath"  : self.VVENp8("/")
   elif item == "toRoot"   : self.VVENp8("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVsSkG, boundFunction(CCin0f, mode=CCin0f.VVgfa4, VVz9Oc=VVXukQ))
 def VVsSkG(self, path):
  if len(path) > 0:
   self.VVENp8(path)
 def VVENp8(self, parent, withPackageName=True):
  if withPackageName : self.VVcKV4 = parent + self.VVFoZz + "/"
  else    : self.VVcKV4 = "/"
  mode = self.VVcI06()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVvJrb(mode), self.controlFile))
  self.VVge46()
 def VVBVtp(self):
  if fileExists(self.controlFile):
   lines = FF8ZwU(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFnG6g(self, self.VVtOZV, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFf3zP(self, "Version not found or incorrectly set !")
  else:
   FFxtzL(self, self.controlFile)
 def VVtOZV(self, VVZ6mF):
  if VVZ6mF:
   version, color = self.VVaNQO(VVZ6mF, False)
   if color == VVxzLQ:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVZ6mF, self.controlFile))
    self.VVge46()
   else:
    FFf3zP(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VV494D(self):
  if self.newControlPath:
   if self.VVQx6K:
    self.VVYfHO()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFhqic(self.newControlPath, VVcDYh)
    txt += FFhqic("Do you want to keep these files ?", VVAjxB)
    FFCKL0(self, self.close, txt, callBack_No=self.VVYfHO, title="Create Package", VVCyqa=True)
  else:
   self.close()
 def VVYfHO(self):
  os.system(FFrWND("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVvJrb(self, mode):
  if   mode == self.VVvd4Q : prefix = self.VVYQ8o
  elif mode == self.VVWyzs : prefix = self.VVpVkU
  else        : prefix = self.VVtT2L
  return prefix + "-" + self.VV74Q5
 def VVcI06(self):
  if   self.VVcKV4.startswith(VVGWw1) : return self.VVvd4Q
  elif self.VVcKV4.startswith(VVIJZ6) : return self.VVWyzs
  else            : return self.VVIGjF
 def VVIjPk(self, isFirstTime):
  self.VVFoZz   = os.path.basename(os.path.normpath(self.Path))
  self.VVFoZz   = "_".join(self.VVFoZz.split())
  self.VV74Q5 = self.VVFoZz.lower()
  self.VVQx6K = self.VV74Q5 == VVKo9M.lower()
  if self.VVQx6K and self.VV74Q5.endswith("ajpan"):
   self.VV74Q5 += "el"
  if self.VVQx6K : self.VVByhV = VVXukQ
  else    : self.VVByhV = CFG.packageOutputPath.getValue()
  self.VVByhV = FFr9AH(self.VVByhV)
  if not pathExists(self.controlPath):
   os.system(FFrWND("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVQx6K : t = PLUGIN_NAME
  else    : t = self.VVFoZz
  self.VVfS01(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVbN0T.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVQx6K : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVfS01(self.postrmFile, txt)
  if self.VVQx6K:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVvN9W)
   self.VVfS01(self.preinstFile, txt)
  else:
   self.VVfS01(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVFoZz)
  mode = self.VVcI06()
  if isFirstTime and not mode == self.VVIGjF:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVBOaW
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVfS01(self.postinstFile, txt, VV7XRy=True)
  os.system(FFrWND("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVQx6K : version, descripton, maintainer = VVvN9W , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVFoZz , self.VVFoZz
   txt = ""
   txt += "Package: %s\n"  % self.VVvJrb(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVfS01(self, path, lines, VV7XRy=False):
  if not fileExists(path) or VV7XRy:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVPWgq(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FF8ZwU(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFhqic(line, VVf5u2)
     elif not line.startswith(" ")    : line = FFhqic(line, VVf5u2)
     else          : line = FFhqic(line, VVxzLQ)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVxzLQ
   else   : color = VVf5u2
   descr = FFhqic(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVf5u2
     elif line.startswith((" ", "\t")) : color = VVf5u2
     elif line.startswith("#")   : color = VVcDYh
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVaNQO(val, True)
      elif key == "Version"  : version, color = self.VVaNQO(val, False)
      elif key == "Maintainer" : maint  , color = val, VVxzLQ
      elif key == "Architecture" : arch  , color = val, VVxzLQ
      else:
       color = VVxzLQ
      if not key == "OE" and not key.istitle():
       color = VVf5u2
     else:
      color = VVd9bM
     txt += FFhqic(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVY2rX = self.VVByhV + packageName
   self.VV52Wv = True
   errTxt = ""
  else:
   self.VVY2rX  = ""
   self.VV52Wv = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVaNQO(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVxzLQ
  else          : return val, VVf5u2
 def VVJMq4(self):
  if not self.VV52Wv:
   FFf3zP(self, "Please fix Control File errors first.")
   return
  if self.VVPf2H: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFL9q7(self.VVcKV4, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVFoZz
  symlinkTo  = FFzC0I(self.Path)
  dataDir   = self.VVcKV4.rstrip("/")
  removePorjDir = FFrWND("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFrWND("rm -f '%s'" % self.VVY2rX) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFuJQY()
  if self.VVPf2H:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FF5kV1("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVQx6K:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVcKV4 == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVL2A5)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVY2rX, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVY2rX
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVY2rX, FF7UqE(result  , VVUnli))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVcKV4, FF7UqE(instPath, VVxzLQ))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FF7UqE(failed, VVf5u2))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFmkwf(self, cmd)
class CCin0f(Screen):
 VVkhi0   = 0
 VVgfa4  = 1
 VVaNuJ = 20
 VVD0Fo  = None
 def __init__(self, session, VVz9Oc="/", mode=VVkhi0, VVNnM5="Select", VVzOAn=30, gotoMovie=False):
  self.skin, self.skinParam = FFSDka(VVTY88, 1400, 920, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFyutK(self)
  FFdk5e(self["keyRed"] , "Exit")
  FFdk5e(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVNnM5 = VVNnM5
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  CCin0f.VVD0Fo = self
  if   self.gotoMovie        : VVSxBd, self.VVz9Oc = True , CCin0f.VVi90Z(self)[1] or "/"
  elif self.mode == self.VVkhi0  : VVSxBd, self.VVz9Oc = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVgfa4 : VVSxBd, self.VVz9Oc = False, VVz9Oc
  else           : VVSxBd, self.VVz9Oc = True , VVz9Oc
  self.VVz9Oc = FFr9AH(self.VVz9Oc)
  self["myMenu"] = CCswzr(  directory   = "/"
         , VVSxBd   = VVSxBd
         , VVVshN = True
         , VV9N7y   = self.skinParam["width"]
         , VVzOAn   = self.skinParam["bodyFontSize"]
         , VVtEei  = self.skinParam["bodyLineH"]
         , VVB7g2  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVNPMZ      ,
   "red"    : self.VVegpX     ,
   "green"    : self.VV2ZOP    ,
   "yellow"   : self.VV0k8b   ,
   "blue"    : self.VVAEWR   ,
   "menu"    : self.VV3iVg    ,
   "info"    : self.VVmYJO    ,
   "cancel"   : self.VVLvrx     ,
   "pageUp"   : self.VVLvrx     ,
   "chanUp"   : self.VVLvrx
  }, -1)
  FFffd6(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVgRzW)
 def onExit(self):
  CCin0f.VVD0Fo = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVgRzW)
  FFDx5r(self)
  FFTEKh(self["myMenu"], bg="#06003333")
  FF22W2(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode == self.VVgfa4:
   FFdk5e(self["keyGreen"], self.VVNnM5)
   color = "#22000022"
   FF6nEU(self["myBody"], color)
   FF6nEU(self["myMenu"], color)
   color = "#22220000"
   FF6nEU(self["myTitle"], color)
   FF6nEU(self["myBar"], color)
  self.VVgRzW()
  if self.VVs2xR(self.VVz9Oc) > self.bigDirSize:
   FF6E92(self, "Changing directory...")
   FFRXLV(self.VVGxww)
  else:
   self.VVGxww()
 def VVGxww(self):
  self["myMenu"].VVVMUN(self.VVz9Oc)
  if self.gotoMovie:
   self.VV6hUo(chDir=False)
 def VVP2LA(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VV5lI5(self):
  self["myMenu"].refresh()
  FFtnUh()
 def VVs2xR(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VVNPMZ(self):
  if self["myMenu"].VVEXvo():
   path = self.VVs2tr(self.VVoYT0())
   if self.VVs2xR(path) > self.bigDirSize:
    FF6E92(self, "Changing directory...")
    FFRXLV(self.VV8LDG)
   else:
    self.VV8LDG()
  else:
   self.VVStdv()
 def VV8LDG(self):
  self["myMenu"].descent()
  self.VVgRzW()
 def VVLvrx(self):
  if self["myMenu"].VVTIwi():
   self["myMenu"].moveToIndex(0)
   self.VV8LDG()
 def VVegpX(self):
  if not FFuEE1(self):
   self.close("")
 def VV2ZOP(self):
  if self.mode == self.VVgfa4:
   path = self.VVs2tr(self.VVoYT0())
   self.close(path)
 def VVmYJO(self):
  FFshid(self, self.VVfHMf, title="Calculating size ...")
 def VVfHMf(self):
  path = self.VVs2tr(self.VVoYT0())
  param = self.VVLZHs(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFjgvE("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCin0f.VVSvcC(path)
     freeSize = CCin0f.VVSeiy(path)
     size = totSize - freeSize
     totSize  = CCin0f.VVPicv(totSize)
     freeSize = CCin0f.VVPicv(freeSize)
    else:
     size = FFjgvE("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CCin0f.VVPicv(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFhqic(pathTxt, VVd9bM) + "\n"
   if slBroken : fileTime = self.VVXaoB(path)
   else  : fileTime = self.VVvmXm(path)
   def VVygRP(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVygRP("Path"    , pathTxt)
   txt += VVygRP("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVygRP("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVygRP("Total Size"   , "%s" % totSize)
    txt += VVygRP("Used Size"   , "%s" % usedSize)
    txt += VVygRP("Free Size"   , "%s" % freeSize)
   else:
    txt += VVygRP("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVygRP("Owner"    , owner)
   txt += VVygRP("Group"    , group)
   txt += VVygRP("Perm. (User)"  , permUser)
   txt += VVygRP("Perm. (Group)"  , permGroup)
   txt += VVygRP("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVygRP("Perm. (Ext.)" , permExtra)
   txt += VVygRP("iNode"    , iNode)
   txt += VVygRP("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVBOaW, VVBOaW)
    txt += hLinkedFiles
   txt += self.VVhL1K(path)
  else:
   FFf3zP(self, "Cannot access information !")
  if len(txt) > 0:
   FF9Qkx(self, txt)
 def VVLZHs(self, path):
  path = path.strip()
  path = FFzC0I(path)
  result = FFjgvE("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVSe6l(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVSe6l(perm, 1, 4)
   permGroup = VVSe6l(perm, 4, 7)
   permOther = VVSe6l(perm, 7, 10)
   permExtra = VVSe6l(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FF6bpX("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVhL1K(self, path):
  txt  = ""
  res  = FFjgvE("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFhqic("File Attributes:", VVB0Mu), txt)
  return txt
 def VVvmXm(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFXQPO(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFXQPO(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFXQPO(os.path.getctime(path))
  return txt
 def VVXaoB(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFjgvE("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFjgvE("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFjgvE("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVs2tr(self, currentSel):
  currentDir  = self["myMenu"].VVTIwi()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVEXvo():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVoYT0(self):
  return self["myMenu"].getSelection()[0]
 def VVgRzW(self):
  FF6E92(self)
  path = self.VVs2tr(self.VVoYT0())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VVYDUR = self.VVCNNy()
  if VVYDUR and len(VVYDUR) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VVHpx6(path)
  if self.mode == self.VVkhi0 and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
 def VVHpx6(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVOfGC(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VV3iVg(self):
  if self.mode == self.VVkhi0:
   path  = self.VVs2tr(self.VVoYT0())
   isDir  = os.path.isdir(path)
   VV23GK = []
   VV23GK.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVa3MU(path):
     sepShown = True
     VV23GK.append(VV15MX)
     VV23GK.append( (VVd9bM + "Archiving / Packaging"      , "VVnRZi"  ))
    if self.VV5Y6e(path):
     if not sepShown:
      VV23GK.append(VV15MX)
     VV23GK.append( (VVd9bM + "Read Backup information"     , "VVcpRT"  ))
     VV23GK.append( (VVd9bM + "Compress Octagon Image (to zip File)"  , "VVF8yT" ))
   elif os.path.isfile(path):
    selFile = self.VVoYT0()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar")) : VV23GK.extend(self.VVAxk8(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VV23GK.extend(self.VV5MhC(True))
    elif selFile.endswith(".m3u")              : VV23GK.extend(self.VVe6eZ(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FFguZp(path):
     VV23GK.append(VV15MX)
     VV23GK.append((VVd9bM + "View"     , "textView_def" ))
     VV23GK.append((VVd9bM + "View (Select Encoder)" , "textView_enc" ))
     VV23GK.append((VVd9bM + "Edit"     , "text_Edit"  ))
    if len(txt) > 0:
     VV23GK.append(VV15MX)
     VV23GK.append(   (VVd9bM + txt      , "VVStdv"  ))
   VV23GK.append(VV15MX)
   VV23GK.append(     ("Create SymLink"       , "VVXnyv" ))
   if not self.VVa3MU(path):
    VV23GK.append(   ("Rename"          , "VVawhu" ))
    VV23GK.append(   ("Copy"           , "copyFileOrDir" ))
    VV23GK.append(   ("Move"           , "moveFileOrDir" ))
    VV23GK.append(   ("DELETE"          , "VVNo4e" ))
    if fileExists(path):
     VV23GK.append(VV15MX)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VV23GK.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VV23GK.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VV23GK.append( (chmodTxt + "777)"       , "chmod777"  ))
   VV23GK.append(VV15MX)
   VV23GK.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VV23GK.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCin0f.VVi90Z(self)
   if fPath:
    VV23GK.append(VV15MX)
    VV23GK.append(   (VVAjxB + "Go to current movie"  , "VV6hUo"))
   VV23GK.append(VV15MX)
   VV23GK.append(    ("Set current directory as \"Startup Path\"" , "VVYyw2" ))
   FFdX2v(self, self.VVoWIC, title="Options", VV23GK=VV23GK)
 def VVoWIC(self, item=None):
  if self.mode == self.VVkhi0:
   if item is not None:
    path = self.VVs2tr(self.VVoYT0())
    selFile = self.VVoYT0()
    if   item == "properties"    : self.VVmYJO()
    elif item == "VVnRZi"  : self.VVnRZi(path)
    elif item == "VVcpRT"  : self.VVcpRT(path)
    elif item == "VVF8yT" : self.VVF8yT(path)
    elif item.startswith("extract_")  : self.VVl0xH(path, selFile, item)
    elif item.startswith("script_")   : self.VVxRHJ(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVVYXcItem_m3u(path, selFile, item)
    elif item.startswith("textView_def") : FFwdI3(self, path)
    elif item.startswith("textView_enc") : self.VVDFP0(path)
    elif item.startswith("text_Edit")  : CCUORs(self, path)
    elif item == "chmod644"     : self.VVnIoy(path, selFile, "644")
    elif item == "chmod755"     : self.VVnIoy(path, selFile, "755")
    elif item == "chmod777"     : self.VVnIoy(path, selFile, "777")
    elif item == "VVXnyv"   : self.VVXnyv(path, selFile)
    elif item == "VVawhu"   : self.VVawhu(path, selFile)
    elif item == "copyFileOrDir"   : self.VVUv3V(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVUv3V(path, selFile, True)
    elif item == "VVNo4e"   : self.VVNo4e(path, selFile)
    elif item == "createNewFile"   : self.VV9wPz(path, True)
    elif item == "createNewDir"    : self.VV9wPz(path, False)
    elif item == "VV6hUo"   : self.VV6hUo()
    elif item == "VVYyw2"   : self.VVYyw2(path)
    elif item == "VVStdv"    : self.VVStdv()
    else         : self.close()
 def VVStdv(self):
  selFile = self.VVoYT0()
  path  = self.VVs2tr(selFile)
  if os.path.isfile(path):
   VVSgRh = []
   category = self["myMenu"].VVWJMO(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVgM5L(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FFY2ZZ(self, selFile, path)
   elif category == "txt"         : FFwdI3(self, path)
   elif category in ("tar", "zip", "rar")     : self.VVruLb(path, selFile)
   elif category == "scr"         : self.VVYAVn(path, selFile)
   elif category == "m3u"         : self.VVcDKZ(path, selFile)
   elif category in ("ipk", "deb")       : self.VVPjFP(path, selFile)
   elif category == "mus"         : self.VVE6YU(self, path)
   elif category == "mov"         : self.VVE6YU(self, path)
   elif not FFguZp(path)        : FFwdI3(self, path)
 def VV0k8b(self):
  path = self.VVs2tr(self.VVoYT0())
  action = self.VVHpx6(path)
  if action == 1:
   self.VVxFpb(path)
   FF6E92(self, "Added", 500)
  elif action == -1:
   self.VVIwYD(path)
   FF6E92(self, "Removed", 500)
  self.VVHpx6(path)
 def VVxFpb(self, path):
  VVYDUR = self.VVCNNy()
  if not VVYDUR:
   VVYDUR = []
  if len(VVYDUR) >= self.VVaNuJ:
   FFf3zP(SELF, "Max bookmarks reached (max=%d)." % self.VVaNuJ)
  elif not path in VVYDUR:
   VVYDUR = [path] + VVYDUR
   self.VVWUqP(VVYDUR)
 def VVAEWR(self):
  VVYDUR = self.VVCNNy()
  if VVYDUR:
   newList = []
   for line in VVYDUR:
    newList.append((line, line))
   VVp90K  = ("Delete"  , self.VV60Zh )
   VVrMQs = ("Move Up"   , self.VVI1nS )
   VVvFvy  = ("Move Down" , self.VVsCMI )
   self.bookmarkMenu = FFdX2v(self, self.VVYT17, title="Bookmarks", VV23GK=newList, VVp90K=VVp90K, VVrMQs=VVrMQs, VVvFvy=VVvFvy)
 def VV60Zh(self, VVoYT0Obj, path):
  if self.bookmarkMenu:
   VVYDUR = self.VVIwYD(path)
   self.bookmarkMenu.VVmxo3(VVYDUR)
 def VVI1nS(self, VVoYT0Obj, path):
  if self.bookmarkMenu:
   VVYDUR = self.bookmarkMenu.VVTTlI(True)
   if VVYDUR:
    self.VVWUqP(VVYDUR)
 def VVsCMI(self, VVoYT0Obj, path):
  if self.bookmarkMenu:
   VVYDUR = self.bookmarkMenu.VVTTlI(False)
   if VVYDUR:
    self.VVWUqP(VVYDUR)
 def VVYT17(self, folder=None):
  if folder:
   folder = FFr9AH(folder)
   self["myMenu"].VVVMUN(folder)
   self["myMenu"].moveToIndex(0)
  self.VVgRzW()
 def VVCNNy(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVOfGC(self, path):
  VVYDUR = self.VVCNNy()
  if VVYDUR and path in VVYDUR:
   return True
  else:
   return False
 def VV8h9n(self):
  if VVCNNy():
   return True
  else:
   return False
 def VVWUqP(self, VVYDUR):
  line = ",".join(VVYDUR)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVIwYD(self, path):
  VVYDUR = self.VVCNNy()
  if VVYDUR:
   while path in VVYDUR:
    VVYDUR.remove(path)
   self.VVWUqP(VVYDUR)
   return VVYDUR
 def VV6hUo(self, chDir=True):
  fPath, fDir, fName = CCin0f.VVi90Z(self)
  if fPath:
   if chDir:
    self["myMenu"].VVVMUN(fDir)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FF6E92(self, "Not found", 1000)
 def VVYyw2(self, path):
  if not os.path.isdir(path):
   path = FFL9q7(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVgM5L(self, selFile, VVoTby, command):
  FFCKL0(self, boundFunction(FFmkwf, self, command, VVHD9V=self.VV5lI5), "%s\n\n%s" % (VVoTby, selFile))
 def VVAxk8(self, path, calledFromMenu):
  destPath = self.VVh1wa(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VV23GK = []
  if calledFromMenu:
   VV23GK.append(VV15MX)
   color = VVd9bM
  else:
   color = ""
  VV23GK.append((color + "List Archived Files"          , "extract_listFiles" ))
  VV23GK.append(VV15MX)
  VV23GK.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VV23GK.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VV23GK.append((color + "Extract Here"            , "extract_here"  ))
  if VVHIEW and path.endswith(".tar.gz"):
   VV23GK.append(VV15MX)
   VV23GK.append((color + 'Convert to ".ipk" Package' , "VVwMGZ"  ))
   VV23GK.append((color + 'Convert to ".deb" Package' , "VVFWeR"  ))
  return VV23GK
 def VVruLb(self, path, selFile):
  FFdX2v(self, boundFunction(self.VVl0xH, path, selFile), title="Compressed File Options", VV23GK=self.VVAxk8(path, False))
 def VVl0xH(self, path, selFile, item=None):
  if item is not None:
   parent  = FFL9q7(path, False)
   destPath = self.VVh1wa(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVBOaW
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FF5kV1("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FF5kV1("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVBOaW, VVBOaW)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFeXoK(self, cmd)
   elif path.endswith(".zip"):
    self.VVQ1Ej(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif path.endswith(".rar"):
    self.VV4XfX(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFrWND("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVgM5L(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVgM5L(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFL9q7(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVgM5L(selFile, "Extract Here ?"      , cmd)
   elif item == "VVwMGZ" : self.VVwMGZ(path)
   elif item == "VVFWeR" : self.VVFWeR(path)
 def VVh1wa(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVQ1Ej(self, item, path, parent, destPath, VVoTby):
  FFCKL0(self, boundFunction(self.VVucKD, item, path, parent, destPath), VVoTby)
 def VVucKD(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVBOaW
  cmd  = FF5kV1("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FF7UqE(destPath, VVUnli))
  cmd +=   sep
  cmd += "fi;"
  FFP4rI(self, cmd, VVHD9V=self.VV5lI5)
 def VV4XfX(self, item, path, parent, destPath, VVoTby):
  FFCKL0(self, boundFunction(self.VVd0s4, item, path, parent, destPath), VVoTby)
 def VVd0s4(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFr9AH(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVBOaW
  cmd  = FF5kV1("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FF7UqE(destPath, VVUnli))
  cmd +=   sep
  cmd += "fi;"
  FFP4rI(self, cmd, VVHD9V=self.VV5lI5)
 def VV5MhC(self, addSep=False):
  VV23GK = []
  if addSep:
   VV23GK.append(VV15MX)
  VV23GK.append((VVd9bM + "View Script File"  , "script_View"  ))
  VV23GK.append((VVd9bM + "Execute Script File" , "script_Execute" ))
  VV23GK.append((VVd9bM + "Edit"     , "script_Edit" ))
  return VV23GK
 def VVYAVn(self, path, selFile):
  FFdX2v(self, boundFunction(self.VVxRHJ, path, selFile), title="Script File Options", VV23GK=self.VV5MhC())
 def VVxRHJ(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFwdI3(self, path)
   elif item == "script_Execute" : self.VVgM5L(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCUORs(self, path)
 def VVe6eZ(self, addSep=False):
  VV23GK = []
  if addSep:
   VV23GK.append(VV15MX)
  VV23GK.append((VVd9bM + "Browse IPTV Channels"  , "m3u_Browse" ))
  VV23GK.append((VVd9bM + "Edit"      , "m3u_Edit" ))
  VV23GK.append((VVd9bM + "View"      , "m3u_View" ))
  return VV23GK
 def VVcDKZ(self, path, selFile):
  FFdX2v(self, boundFunction(self.VVVYXcItem_m3u, path, selFile), title="M3U/M3U8 File Options", VV23GK=self.VVe6eZ())
 def VVVYXcItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFshid(self, boundFunction(self.session.open, CCFXWw, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCUORs(self, path)
   elif item == "m3u_View"  : FFwdI3(self, path)
 def VVDFP0(self, path):
  if fileExists(path) : FFshid(self, boundFunction(CC4HXa.VVh3JB, self, path, boundFunction(self.VVaOQC, path), defEnc=None), title="Loading Codecs ...", clearMsg=False)
  else    : FFxtzL(self, path)
 def VVaOQC(self, path, item=None):
  if item:
   FFwdI3(self, path, encLst=item)
 def VVnIoy(self, path, selFile, newChmod):
  FFCKL0(self, boundFunction(self.VViYqp, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VViYqp(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVvn2k)
  result = FFjgvE(cmd)
  if result == "Successful" : FFTVfn(self, result)
  else      : FFf3zP(self, result)
 def VVXnyv(self, path, selFile):
  parent = FFL9q7(path, False)
  self.session.openWithCallback(self.VVVahN, boundFunction(CCin0f, mode=CCin0f.VVgfa4, VVz9Oc=parent, VVNnM5="Create Symlink here"))
 def VVVahN(self, newPath):
  if len(newPath) > 0:
   target = self.VVs2tr(self.VVoYT0())
   target = FFzC0I(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFr9AH(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFf3zP(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFCKL0(self, boundFunction(self.VVQ5ct, target, link), "Create Soft Link ?\n\n%s" % txt, VVCyqa=True)
 def VVQ5ct(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVvn2k)
  result = FFjgvE(cmd)
  if result == "Successful" : FFTVfn(self, result)
  else      : FFf3zP(self, result)
 def VVawhu(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFnG6g(self, boundFunction(self.VV24tA, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VV24tA(self, path, selFile, VVZ6mF):
  if VVZ6mF:
   parent = FFL9q7(path, True)
   if os.path.isdir(path):
    path = FFzC0I(path)
   newName = parent + VVZ6mF
   cmd = "mv '%s' '%s' %s" % (path, newName, VVvn2k)
   if VVZ6mF:
    if selFile != VVZ6mF:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFCKL0(self, boundFunction(self.VVEEMm, cmd), message, title="Rename file?")
    else:
     FFf3zP(self, "Cannot use same name!", title="Rename")
 def VVEEMm(self, cmd):
  result = FFjgvE(cmd)
  if "Fail" in result:
   FFf3zP(self, result)
  self.VV5lI5()
 def VVUv3V(self, path, selFile, isMove):
  if isMove : VVNnM5 = "Move to here"
  else  : VVNnM5 = "Copy to here"
  parent = FFL9q7(path, False)
  self.session.openWithCallback(boundFunction(self.VVC8In, isMove, path, selFile)
         , boundFunction(CCin0f, mode=CCin0f.VVgfa4, VVz9Oc=parent, VVNnM5=VVNnM5))
 def VVC8In(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFzC0I(path)
   newPath = FFr9AH(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFCKL0(self, boundFunction(FFpzYC, self, cmd, VVHD9V=self.VV5lI5), txt, VVCyqa=True)
   else:
    FFf3zP(self, "Cannot %s to same directory !" % action.lower())
 def VVNo4e(self, path, fileName):
  path = FFzC0I(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFCKL0(self, boundFunction(self.VVmHYi, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVmHYi(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VV5lI5()
 def VVa3MU(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVxotg and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VV9wPz(self, path, isFile):
  dirName = FFr9AH(os.path.dirname(path))
  if isFile : objName, VVZ6mF = "File"  , self.edited_newFile
  else  : objName, VVZ6mF = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFnG6g(self, boundFunction(self.VVvGB3, dirName, isFile, title), title=title, defaultText=VVZ6mF, message="Enter %s Name:" % objName)
 def VVvGB3(self, dirName, isFile, title, VVZ6mF):
  if VVZ6mF:
   if isFile : self.edited_newFile = VVZ6mF
   else  : self.edited_newDir  = VVZ6mF
   path = dirName + VVZ6mF
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVvn2k)
    else  : cmd = "mkdir '%s' %s" % (path, VVvn2k)
    result = FFjgvE(cmd)
    if "Fail" in result:
     FFf3zP(self, result)
    self.VV5lI5()
   else:
    FFf3zP(self, "Name already exists !\n\n%s" % path, title)
 def VVPjFP(self, path, selFile):
  VV23GK = []
  VV23GK.append(("List Package Files"          , "VV8kmI"     ))
  VV23GK.append(("Package Information"          , "VVBARp"     ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Install Package"           , "VVbo4Q_CheckVersion" ))
  VV23GK.append(("Install Package (force reinstall)"      , "VVbo4Q_ForceReinstall" ))
  VV23GK.append(("Install Package (force overwrite)"      , "VVbo4Q_ForceOverwrite" ))
  VV23GK.append(("Install Package (force downgrade)"      , "VVbo4Q_ForceDowngrade" ))
  VV23GK.append(("Install Package (ignore failed dependencies)"    , "VVbo4Q_IgnoreDepends" ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Remove Related Package"         , "VVXLLt_ExistingPackage" ))
  VV23GK.append(("Remove Related Package (force remove)"     , "VVXLLt_ForceRemove"  ))
  VV23GK.append(("Remove Related Package (ignore failed dependencies)"  , "VVXLLt_IgnoreDepends" ))
  VV23GK.append(VV15MX)
  VV23GK.append(("Extract Files"           , "VVoMhP"     ))
  VV23GK.append(("Unbuild Package"           , "VVTfqR"     ))
  FFdX2v(self, boundFunction(self.VVsdKB, path, selFile), VV23GK=VV23GK)
 def VVsdKB(self, path, selFile, item=None):
  if item is not None:
   if   item == "VV8kmI"      : self.VV8kmI(path, selFile)
   elif item == "VVBARp"      : self.VVBARp(path)
   elif item == "VVbo4Q_CheckVersion"  : self.VVbo4Q(path, selFile, VV5wtI     )
   elif item == "VVbo4Q_ForceReinstall" : self.VVbo4Q(path, selFile, VVqCt4 )
   elif item == "VVbo4Q_ForceOverwrite" : self.VVbo4Q(path, selFile, VViGNM )
   elif item == "VVbo4Q_ForceDowngrade" : self.VVbo4Q(path, selFile, VVNwcc )
   elif item == "VVbo4Q_IgnoreDepends" : self.VVbo4Q(path, selFile, VVHGsQ )
   elif item == "VVXLLt_ExistingPackage" : self.VVXLLt(path, selFile, VVYc7m     )
   elif item == "VVXLLt_ForceRemove"  : self.VVXLLt(path, selFile, VV5RQp  )
   elif item == "VVXLLt_IgnoreDepends"  : self.VVXLLt(path, selFile, VVNmfE )
   elif item == "VVoMhP"     : self.VVoMhP(path, selFile)
   elif item == "VVTfqR"     : self.VVTfqR(path, selFile)
   else           : self.close()
 def VV8kmI(self, path, selFile):
  if FFH7pp("ar") : cmd = "allOK='1';"
  else    : cmd  = FFuJQY()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVBOaW, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVBOaW, VVBOaW)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFfxIt(self, cmd, VVHD9V=self.VV5lI5)
 def VVoMhP(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFL9q7(path, True) + selFile[:-4]
  cmd  =  FFuJQY()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFrWND("mkdir '%s'" % dest) + ";"
  cmd +=    FFrWND("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FF7UqE(dest, VVUnli))
  cmd += "fi;"
  FFmkwf(self, cmd, VVHD9V=self.VV5lI5)
 def VVTfqR(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVpnzJ = os.path.splitext(path)[0]
  else        : VVpnzJ = path + "_"
  if path.endswith(".deb")   : VVL2A5 = "DEBIAN"
  else        : VVL2A5 = "CONTROL"
  cmd  = FFuJQY()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVpnzJ, FFZIFv())
  cmd += "  mkdir '%s';"    % VVpnzJ
  cmd += "  CONTPATH='%s/%s';"  % (VVpnzJ, VVL2A5)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVpnzJ
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVpnzJ, VVpnzJ)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVpnzJ
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVpnzJ, VVpnzJ)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVpnzJ
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVpnzJ
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVpnzJ, FF7UqE(VVpnzJ, VVUnli))
  cmd += "fi;"
  FFmkwf(self, cmd, VVHD9V=self.VV5lI5)
 def VVBARp(self, path):
  listCmd  = FF6WlR(VVPYPU, "")
  infoCmd  = FFHppj(VVmFmC , "")
  filesCmd = FFHppj(VVHtxt, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFtiGW(VVAjxB)
   notInst = "Package not installed."
   cmd  = FFpdcU("File Info", VVAjxB)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFpdcU("System Info", VVAjxB)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FF7UqE(notInst, VVd9bM))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFpdcU("Related Files", VVAjxB)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFeXoK(self, cmd)
  else:
   FFywk7(self)
 def VVbo4Q(self, path, selFile, cmdOpt):
  cmd = FFHppj(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFCKL0(self, boundFunction(FFmkwf, self, cmd, VVHD9V=FFtnUh), "Install Package ?\n\n%s" % selFile)
  else:
   FFywk7(self)
 def VVXLLt(self, path, selFile, cmdOpt):
  listCmd  = FF6WlR(VVPYPU, "")
  infoCmd  = FFHppj(VVmFmC, "")
  instRemCmd = FFHppj(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FF7UqE(errTxt, VVd9bM))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FF7UqE(cannotTxt, VVd9bM))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FF7UqE(tryTxt, VVd9bM))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFCKL0(self, boundFunction(FFmkwf, self, cmd, VVHD9V=FFtnUh), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFywk7(self)
 def VVSEWD(self, path):
  hostName = FFjgvE("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VV5Y6e(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVSEWD(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVnRZi(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VV23GK = []
  VV23GK.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VV23GK.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VV23GK.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VV23GK.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VV23GK.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VV23GK.append(VV15MX)
  VV23GK.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VV23GK.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VV23GK.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VV23GK.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VV23GK.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VV23GK.append(VV15MX)
  VV23GK.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VV23GK.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FFdX2v(self, boundFunction(self.VVwR1t, path), VV23GK=VV23GK)
 def VVwR1t(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VV1WQ3(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VV1WQ3(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VV1WQ3(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VV1WQ3(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VV1WQ3(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VV1WQ3(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VV1WQ3(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VV1WQ3(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VV1WQ3(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VV1WQ3(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVZ9uN(path, False)
   elif item == "convertDirToDeb"   : self.VVZ9uN(path, True)
   else         : self.close()
 def VVZ9uN(self, path, VVPf2H):
  self.session.openWithCallback(self.VV5lI5, boundFunction(CCp1zl, path=path, VVPf2H=VVPf2H))
 def VV1WQ3(self, path, fileExt, preserveDirStruct):
  parent  = FFL9q7(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FF5kV1("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FF5kV1("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FF5kV1("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVBOaW
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFrWND("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FF7UqE(resultFile, VVUnli))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FF7UqE(failed, VVf5u2))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFfxIt(self, cmd, VVHD9V=self.VV5lI5)
 def VVcpRT(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFwdI3(self, versionFile)
 def VVF8yT(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVSEWD(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFf3zP(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FF8ZwU(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFL9q7(path, False)
  VVpnzJ = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FF7UqE(errCmd, VVf5u2))
  installCmd = FFHppj(VV5wtI , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VVpnzJ, VVpnzJ)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VVpnzJ
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VVpnzJ
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VVpnzJ, VVpnzJ)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFmkwf(self, cmd, VVHD9V=self.VV5lI5)
 def VVwMGZ(self, path):
  FFf3zP(self, "Under Construction.")
 def VVFWeR(self, path):
  FFf3zP(self, "Under Construction.")
 @staticmethod
 def VVE6YU(SELF, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   SELF.session.open(CC9pOJ, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVi90Z(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFr9AH(fDir), fName
  return "", "", ""
 @staticmethod
 def VVSvcC(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVSeiy(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVPicv(size, mode=0):
  txt = CCin0f.VVVzJs(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVVzJs(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
class CCswzr(MenuList):
 def __init__(self, VVVshN=False, directory="/", VVIu6G=True, VVSxBd=True, VVmVjq=True, VVxtyx=None, VVutqW=False, VV8Jwh=False, VVV8No=False, isTop=False, VVGsCG=None, VV9N7y=1000, VVzOAn=30, VVtEei=30, VVB7g2="#00000000"):
  MenuList.__init__(self, list, VVVshN, eListboxPythonMultiContent)
  self.VVIu6G  = VVIu6G
  self.VVSxBd    = VVSxBd
  self.VVmVjq  = VVmVjq
  self.VVxtyx  = VVxtyx
  self.VVutqW   = VVutqW
  self.VV8Jwh   = VV8Jwh or []
  self.VVV8No   = VVV8No or []
  self.isTop     = isTop
  self.additional_extensions = VVGsCG
  self.VV9N7y    = VV9N7y
  self.VVzOAn    = VVzOAn
  self.VVtEei    = VVtEei
  self.pngBGColor    = FFeFJJ(VVB7g2)
  self.EXTENSIONS    = self.VVJEpE()
  self.VVXeyN   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVTpI8, self.VVzOAn))
  self.l.setItemHeight(self.VVtEei)
  self.png_mem   = self.VVoOgN("mem")
  self.png_usb   = self.VVoOgN("usb")
  self.png_fil   = self.VVoOgN("fil")
  self.png_dir   = self.VVoOgN("dir")
  self.png_dirup   = self.VVoOgN("dirup")
  self.png_srv   = self.VVoOgN("srv")
  self.png_slwfil   = self.VVoOgN("slwfil")
  self.png_slbfil   = self.VVoOgN("slbfil")
  self.png_slwdir   = self.VVoOgN("slwdir")
  self.VVE0NW()
  self.VVVMUN(directory)
 def VVoOgN(self, category):
  return LoadPixmap("%s%s.png" % (VVBZq2, category), getDesktop(0))
 def VVJEpE(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "rar" : "rar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u" ,
   "m3u8" : "m3u"
  }
 def VVTW2i(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFzC0I(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFhqic(" -> " , VVAjxB) + FFhqic(os.readlink(path), VVUnli)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVtEei + 10, 0, self.VV9N7y, self.VVtEei, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVOy8a: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVtEei-4, self.VVtEei-4, png, self.pngBGColor, self.pngBGColor, VVOy8a))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVtEei-4, self.VVtEei-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVWJMO(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVE0NW(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVLP8v(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVp9kd(self, file):
  if os.path.realpath(file) == file:
   return self.VVLP8v(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVLP8v(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVLP8v(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVSGwS(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVXeyN.info(l[0][0]).getEvent(l[0][0])
 def VVSRn8(self):
  return self.list
 def VVOwfz(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVVMUN(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVmVjq:
    self.current_mountpoint = self.VVp9kd(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVmVjq:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVV8No and not self.VVOwfz(path, self.VV8Jwh):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVTW2i(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVutqW:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVXeyN = eServiceCenter.getInstance()
   list = VVXeyN.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVIu6G and not self.isTop:
   if directory == self.current_mountpoint and self.VVmVjq:
    self.list.append(self.VVTW2i(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVV8No and self.VVLP8v(directory) in self.VVV8No):
    self.list.append(self.VVTW2i(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVIu6G:
   for x in directories:
    if not (self.VVV8No and self.VVLP8v(x) in self.VVV8No) and not self.VVOwfz(x, self.VV8Jwh):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVTW2i(name = name, absolute = x, isDir = True, png = png))
  if self.VVSxBd:
   for x in files:
    if self.VVutqW:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFhqic(" -> " , VVAjxB) + FFhqic(target, VVUnli)
       else:
        png = self.png_slbfil
        name += FFhqic(" -> " , VVAjxB) + FFhqic(target, VVf5u2)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVWJMO(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVBZq2, category))
    if (self.VVxtyx is None) or iCompile(self.VVxtyx).search(path):
     self.list.append(self.VVTW2i(name = name, absolute = x , isDir = False, png = png))
  if self.VVmVjq and len(self.list) == 0:
   self.list.append(self.VVTW2i(name = FFhqic("No USB connected", VVcDYh), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVTIwi(self):
  return self.current_directory
 def VVEXvo(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVVMUN(self.getSelection()[0], select = self.current_directory)
 def VVw65N(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVzj0e(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVrzRn)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVrzRn)
 def refresh(self):
  self.VVVMUN(self.current_directory, self.VVw65N())
 def VVrzRn(self, action, device):
  self.VVE0NW()
  if self.current_directory is None:
   self.refresh()
class CCsThb(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FFSDka(VVVX7e, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVYDUR   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVHgfz(defFG, "#00FFFFFF")
  self.defBG   = self.VVHgfz(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFyutK(self, self.Title)
  self["keyRed"].show()
  FFdk5e(self["keyGreen"] , "< > Transp.")
  FFdk5e(self["keyYellow"], "Foreground")
  FFdk5e(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVMX6C        ,
   "yellow"   : boundFunction(self.VVIdHu, False)  ,
   "blue"   : boundFunction(self.VVIdHu, True)  ,
   "up"   : self.VVSS9D          ,
   "down"   : self.VVjpkT         ,
   "left"   : self.VVB1cC         ,
   "right"   : self.VVAeY3         ,
   "last"   : boundFunction(self.VVMuCG, -5) ,
   "next"   : boundFunction(self.VVMuCG, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FF6nEU(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FF6nEU(self["keyRed"] , c)
  FF6nEU(self["keyGreen"] , c)
  self.VVIwoS()
  self.VVAnJz()
  FFE31q(self["myColorTst"], self.defFG)
  FF6nEU(self["myColorTst"], self.defBG)
 def VVHgfz(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVAnJz(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVqpyb(0, 0)
     return
 def VVMX6C(self):
  self.close(self.defFG, self.defBG)
 def VVSS9D(self): self.VVqpyb(-1, 0)
 def VVjpkT(self): self.VVqpyb(1, 0)
 def VVB1cC(self): self.VVqpyb(0, -1)
 def VVAeY3(self): self.VVqpyb(0, 1)
 def VVqpyb(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVtOVP()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVBbmY()
 def VVIwoS(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVBbmY(self):
  color = self.VVtOVP()
  if self.isBgMode: FF6nEU(self["myColorTst"], color)
  else   : FFE31q(self["myColorTst"], color)
 def VVIdHu(self, isBg):
  self.isBgMode = isBg
  self.VVIwoS()
  self.VVAnJz()
 def VVMuCG(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVqpyb(0, 0)
 def VVpWqw(self):
  return hex(self.transp)[2:].zfill(2)
 def VVtOVP(self):
  return ("#%s%s" % (self.VVpWqw(), self.colors[self.curRow][self.curCol])).upper()
class CCUHIj(Screen):
 VVq5dS  = 0
 VVTE3E = 1
 def __init__(self, session, mode, endCallback):
  self.session  = session
  margin    = 50
  screenSize   = FFx23H()
  w     = int(screenSize[0] - margin)
  h     = int(screenSize[1] / 2.0)
  self.skin, self.skinParam = FFSDka(WINDOW_SUBTITLE, w, h, 35, 20, 30, "#ff000000", "#ff000000", 60)
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.currentIndex  = -1
  self.subtitleMode  = mode
  self.defaultY   = 0
  self.endCallback  = endCallback
  FFyutK(self)
  self["myTitle"].hide()
  self["mySubtFr"] = Label()
  self["mySubtFr"].hide()
  for i in range(3):
   self["mySubt%d" % i] = Label()
 def VVbE4r(self, path=""):
  if path :
   self.VVEsOn()
   FFshid(self, boundFunction(self.VVrFn5, path), title="Checking file ...", clearMsg=False)
  else:
   self.VVrFn5()
 def VVrFn5(self, path=""):
  if path:
   subtList, err = self.VVPdB7(path)
   if err    : self.VVBuXT(err)
   elif not subtList : self.VVBuXT("Invalid srt file")
   else    :
    self.subtList = subtList
    self.VVLLmW()
  else:
   if self.VVZcKd():
    self.VVLLmW()
   elif self.subtitleMode == CCUHIj.VVTE3E:
    self.VVBuXT("noResume")
   else:
    if self.VVvvj5(): self.VVLLmW()
    else         : self.VVBuXT("noAutoSrt")
 def VVLLmW(self):
  try:
   InfoBar.instance.enableSubtitle(None)
  except:
   try:
    InfoBar.instance.setSubtitlesEnable(False)
   except:
    pass
  FF6E92(self, "Subtitle started", 1000, isGrn=True)
  self.VVEsOn()
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVhx36)
  except:
   self.timerUpdate.callback.append(self.VVhx36)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVw86G)
  except:
   self.timerEndText.callback.append(self.VVw86G)
  self.VVLjH2()
 def VVBuXT(self, res=""):
  self.timerUpdate.stop()
  self.timerEndText.stop()
  self.VV7oa7()
  self.endCallback(res)
 def VVZcKd(self):
  fPath, fDir, fName = CCin0f.VVi90Z(self)
  if fPath:
   path = fPath + ".ajp"
   if fileExists(path):
    lines = FF8ZwU(path)
    srt = delay = enc = ""
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : srtPath = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay   = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc   = line.split("=")[1].strip()
    if srtPath and fileExists(srtPath):
     subtList, err = self.VVPdB7(srtPath, enc)
     if subtList:
      self.lastSubtEnc = enc
      self.subtList = subtList
      try:
       CFG.subtDelay.setValue("%.1f" % float(delay))
      except:
       pass
      return True
  return False
 def VVvvj5(self):
  bestSrt, bestRatio = CCUHIj.VVAJiH(self)
  if bestSrt and bestRatio > 40:
   subtList, err = self.VVPdB7(bestSrt)
   if subtList:
    self.subtList = subtList
    return True
  return False
 def VVi4eX(self):
  VV23GK = []
  if self.lastSubtFile:
   VV23GK.append(("Settings"      , "set"  ))
   VV23GK.append(("Change Encoding"    , "enc"  ))
   VV23GK.append(("Disable Current Subtitle"  , "disab" ))
   VV23GK.append(VV15MX)
  VV23GK.append(("Find all srt file"    , "findSrt" ))
  lst = CCUHIj.VVxcal(self)
  if lst:
   VV23GK.append(VV15MX)
   for item in lst:
    fName = os.path.basename(item)
    if self.lastSubtFile == item:
     fName = FFhqic(fName, VVUnli)
    VV23GK.append((fName, item))
  win = FFdX2v(self, self.VVnBqT, VV23GK=VV23GK, width=1200, title="Subtitle Options")
  win.instance.move(ePoint(40, 40))
 def VVnBqT(self, item=None):
  if item:
   if item == "set":
    self["mySubtFr"].show()
    for i in range(3):
     FF6nEU(self["mySubt%d" % i], "#55000000")
    self.session.openWithCallback(self.VVxpPO, CCg5ys)
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile):
     FFshid(self, boundFunction(CC4HXa.VVh3JB, self, self.lastSubtFile, self.VVOL5l, defEnc=self.lastSubtEnc, pos=1), title="Loading Codecs ...", clearMsg=False)
    else:
     FF6E92(self, "SRT File error", 1000)
   elif item == "disab":
    fPath, fDir, fName = CCin0f.VVi90Z(self)
    os.system(FFrWND("rm -f '%s'" % fPath + ".ajp"))
    self.VVBuXT("noErr")
   elif item == "findSrt":
    CCUHIj.VVX81Y(self, self.VVHX6F, defSrt=self.lastSubtFile, pos=1)
   else:
    self.VVHX6F(item)
 def VVxpPO(self, res):
  self["mySubtFr"].hide()
  for i in range(3):
   FF6nEU(self["mySubt%d" % i], "#FF000000")
  if res:
   self.VVUPUR()
   self.VVEsOn()
 def VVLjH2(self):
  CFG.subtDelay.addNotifier(self.VVEsOn, initial_call=False)
  CFG.subtTextFg.addNotifier(self.VVEsOn, initial_call=False)
  CFG.subtTextFont.addNotifier(self.VVEsOn, initial_call=False)
  CFG.subtTextSize.addNotifier(self.VVEsOn, initial_call=False)
  CFG.subtTextAlign.addNotifier(self.VVEsOn, initial_call=False)
  CFG.subtShadowColor.addNotifier(self.VVEsOn, initial_call=False)
  CFG.subtShadowSize.addNotifier(self.VVEsOn, initial_call=False)
  CFG.subtVerticalPos.addNotifier(self.VVEsOn, initial_call=False)
 def VV7oa7(self):
  CFG.subtDelay.removeNotifier(self.VVEsOn)
  CFG.subtTextFg.removeNotifier(self.VVEsOn)
  CFG.subtTextFont.removeNotifier(self.VVEsOn)
  CFG.subtTextSize.removeNotifier(self.VVEsOn)
  CFG.subtTextAlign.removeNotifier(self.VVEsOn)
  CFG.subtShadowColor.removeNotifier(self.VVEsOn)
  CFG.subtShadowSize.removeNotifier(self.VVEsOn)
  CFG.subtVerticalPos.removeNotifier(self.VVEsOn)
 def VVEsOn(self, configElement=None):
  fnt = CFG.subtTextFont.getValue()
  if not fnt in FFqAsU():
   fnt = VVTpI8
  lineH = 0
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFE31q(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    inst.setHAlign(int(CFG.subtTextAlign.getValue()))
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    inst.setNoWrap(True)
    lineH = FFMWzO(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    inst.move(ePoint(int(inst.position().x()), int(lineH * i + 1)))
  except:
   pass
  try:
   height = lineH * 3 + 2
   if not self.defaultY:
    self.defaultY = int(getDesktop(0).size().height() - height - self.skinParam["marginTop"])
   if lineH:
    self.instance.resize(eSize(*(int(self.instance.size().width()), height)))
   y = int(self.defaultY + CFG.subtVerticalPos.getValue())
   y = min(y, getDesktop(0).size().height() - height - 5)
   self.instance.move(ePoint(int(self.instance.position().x()), int(y)))
   inst = self["myInfoFrame"].instance
   inst.move(ePoint(int(inst.position().x()), 2))
   inst = self["myInfoBody"].instance
   inst.move(ePoint(int(inst.position().x()), 4))
  except:
   pass
 def VVHX6F(self, path, enc=None):
  self.timerUpdate.stop()
  subtList, err = self.VVPdB7(path, enc)
  if err    : FF6E92(self, err, 2000)
  elif not subtList : FF6E92(self, "Invalid SRT file", 2000)
  else    :
   self.subtList  = subtList
   self.lastSubtInfo = ""
   self.lastSubtEnc = ""
   self.currentIndex = 0
   CFG.subtDelay.setValue("0.0")
   for i in range(3):
    FFE31q(self["mySubt%d" % i], "#ffffff")
    self["mySubt%d" % i].setText("")
   FF6E92(self, "Subtitle started", 1000, isGrn=True)
  self.timerUpdate.start(500, False)
 def VVOL5l(self, item=None):
  if item:
   self.VVHX6F(self.lastSubtFile, item)
 @staticmethod
 def VVxcal(SELF):
  fPath, fDir, fName = CCin0f.VVi90Z(SELF)
  if pathExists(fDir):
   files = iGlob("%s*.srt" % fDir)
   if files:
    return files
  return []
 @staticmethod
 def VVAJiH(SELF):
  bestSrt = ""
  bestRatio = 0
  fPath, fDir, fName = CCin0f.VVi90Z(SELF)
  if fName:
   movName = os.path.splitext(fName)[0].lower()
   files = CCUHIj.VVxcal(SELF)
   for path in files:
    fName = os.path.basename(path)
    fName = os.path.splitext(fName)[0]
    ratio = CCkYaA.VV5No4(movName.lower(), fName.lower())
    if ratio > bestRatio:
     bestRatio = ratio
     bestSrt = path
  return bestSrt, bestRatio
 def VVTkBe(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVPdB7(self, path, enc=None):
  if not fileExists(path):
   return [], "File not found"
  if (FFHtxR(path) > 1024 * 700):
   return [], "File too big"
  capNum = frmSec = toSec = bold = italic = under = 0
  color  = ""
  subtLines = []
  subtList = []
  capFound = False
  lines  = FF8ZwU(path, encLst=enc if enc else None)
  for line in lines:
   line = line.strip()
   if line:
    if not capFound and line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVTkBe(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      subtLines.append((line.strip(), color, bold, italic, under))
   else:
    if (toSec - frmSec) > 0:
     subtList.append((capNum, frmSec, toSec, subtLines))
    capFound = False
    subtLines = []
    color = ""
    capNum = frmSec = toSec = bold = italic = under = 0
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVUPUR()
  return subtList, ""
 def VVUPUR(self):
  fPath, fDir, fName = CCin0f.VVi90Z(self)
  if fPath and pathExists(fDir):
   with open(fPath + ".ajp", "w") as f:
    f.write("srt=%s\n" % self.lastSubtFile)
    f.write("delay=%s\n" % CFG.subtDelay.getValue())
    if self.lastSubtEnc:
     f.write("enc=%s\n" % self.lastSubtEnc)
 def VVhx36(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC9pOJ.VVDysK(self)
  txtDur = 0
  lines = []
  self.VVAqCV(posVal)
  if self.currentIndex == -2:
   return
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[self.currentIndex]
   if not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    for i in range(3):
     FFE31q(self["mySubt%d" % i], "#ffffff")
     self["mySubt%d" % i].setText("")
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
     txtDur = int(toSec * 1000 - frmSec * 1000)
     if txtDur > 0:
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        line = line.replace(u"\u202A", "")
        line = line.replace(u"\u202B", "")
        line = line.replace(u"\u202C", "")
        line = str(line)
        if newColor:
         FFE31q(self["mySubt%d" % ndx], newColor)
        self["mySubt%d" % ndx].setText(line)
      self.timerEndText.start(txtDur, True)
 def VVAqCV(self, posVal):
  if posVal > 0:
   delay = float(CFG.subtDelay.getValue())
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     self.currentIndex = ndx
     return
  self.currentIndex = -2
 def VVw86G(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
 @staticmethod
 def VVX81Y(SELF, cbFnc, defSrt="", pos=0):
  FFshid(SELF, boundFunction(CCUHIj.VVe8jP, SELF, cbFnc, defSrt, pos), title="Searching for srt files", clearMsg=False)
 @staticmethod
 def VVe8jP(SELF, cbFnc, defSrt="", pos=0):
  FF6E92(SELF)
  lines = FFIx6K('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FF2qZL(1)))
  if lines:
   lines.sort()
   VV23GK = []
   for item in lines:
    VV23GK.append(((VVUnli if defSrt == item else "") + item, item))
   VVwqMz = ("Show Full Path", CCUHIj.VVkcEK)
   win = FFdX2v(SELF, boundFunction(CCUHIj.VVmeVj, cbFnc), title="Subtitle Files", VV23GK=VV23GK, width=1200, height=500 if pos == 1 else 900, VVwqMz=VVwqMz)
   if pos == 1:
    win.instance.move(ePoint(40, 40))
  else:
   FF6E92(SELF, "No srt files found !", 2000)
 @staticmethod
 def VVkcEK(VVoYT0Obj, path):
  FF9Qkx(VVoYT0Obj, path, title="Full Path")
 @staticmethod
 def VVmeVj(cbFnc, item):
  if item:
   cbFnc(item)
 @staticmethod
 def VVPZ2j():
  c = s = m = h = 0
  with open(VVXukQ + "AJPanel_test.srt", "w") as f:
   for i in range(1, 5401):
    s += 2
    if s >= 60:
     s = 0
     m += 1
     if m >= 60:
      m = 0
      h += 1
    if i < 6:
     txt  = '<font color="#ffff00">Created by AJPanel</font>\n'
     txt += '<font color="#00ffff">Testing Subtitle Files</font>\n'
     txt += '<font color="#00ff00">Line - %d</font>\n\n' % i
    else:
     txt = '<font color="#ffffbb">Subtitle Line - %d</font>\n\n' % i
    f.write("%d\n" % i)
    f.write("%02d:%02d:%02d,001 --> %02d:%02d:%02d,001\n" % (h, m, s, h, m, s+1))
    f.write(txt)
class CCg5ys(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFSDka(VVWC5J, 600, 600, 40, 30, 10, "#11331010", "#11442020", 30, barHeight=40)
  self.session  = session
  self.Title   = "Subtitle Settings"
  FFyutK(self, title=self.Title)
  FFdk5e(self["keyRed"] , "Exit")
  FFdk5e(self["keyGreen"] , "Save")
  FFdk5e(self["keyYellow"], "Reset")
  self.confList = []
  self.confList.append(getConfigListEntry("Delay (current movie)" , CFG.subtDelay   ))
  self.confList.append(getConfigListEntry(VVBOaW *2     ,       ))
  self.confList.append(getConfigListEntry("Text Color"   , CFG.subtTextFg  ))
  self.confList.append(getConfigListEntry("Text Font"    , CFG.subtTextFont  ))
  self.confList.append(getConfigListEntry("Text Size"    , CFG.subtTextSize  ))
  self.confList.append(getConfigListEntry("Alignment"    , CFG.subtTextAlign  ))
  self.confList.append(getConfigListEntry("Shadow Color"   , CFG.subtShadowColor ))
  self.confList.append(getConfigListEntry("Shadow Size"   , CFG.subtShadowSize ))
  self.confList.append(getConfigListEntry(VVBOaW *2     ,       ))
  self.confList.append(getConfigListEntry("Vertical Pos"   , CFG.subtVerticalPos ))
  ConfigListScreen.__init__(self, self.confList, session)
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVjt0D  ,
   "green"   : self.VVVXt7   ,
   "yellow"  : boundFunction(FFCKL0, self, self.VV2TZP, "Reset Subtitle Settings to default ?", title="Subtitle Settings"),
   "cancel"  : self.VVjt0D
  }, -1)
  self.onShown.append(self.VVSdHz)
 def VVSdHz(self):
  self.onShown.remove(self.VVSdHz)
  FFTEKh(self["config"])
  FFm42V(self, self["config"])
  FF22W2(self)
  self.instance.move(ePoint(40, 40))
 def VVjt0D(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFCKL0(self, self.VVVXt7, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVVXt7(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  configfile.save()
  self.close(True)
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close(False)
 def VV2TZP(self):
  CFG.subtDelay.setValue("0.0")
  CFG.subtTextFg.setValue("srt")
  CFG.subtTextFont.setValue(VVTpI8)
  CFG.subtTextSize.setValue(50)
  CFG.subtTextAlign.setValue("1")
  CFG.subtShadowColor.setValue("#000080")
  CFG.subtShadowSize.setValue(5)
  CFG.subtVerticalPos.setValue(0)
  self.VVVXt7()
class CCHFVK(ScrollLabel):
 def __init__(self, parentSELF, text="", VV6O68=True):
  ScrollLabel.__init__(self, text)
  self.VV6O68=VV6O68
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVFiKV  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVzOAn    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close     ,
   "cancel"  : parentSELF.close     ,
   "red"   : self.VV2LNi     ,
   "green"   : self.VVJ6f3    ,
   "yellow"  : self.VVGhOh    ,
   "blue"   : self.VVFyzn    ,
   "up"   : self.pageUp      ,
   "down"   : self.pageDown      ,
   "left"   : self.pageUp      ,
   "right"   : self.pageDown      ,
   "last"   : boundFunction(self.VV5fDT, 0) ,
   "next"   : boundFunction(self.VV5fDT, 2) ,
   "0"    : boundFunction(self.VV5fDT, 1) ,
   "pageUp"  : self.VVib0y      ,
   "chanUp"  : self.VVib0y      ,
   "pageDown"  : self.VVS5nj      ,
   "chanDown"  : self.VVS5nj
  }, -1)
 def VVi2rz(self, isResizable=True, VVin2T=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FF22W2(self.parentSELF, True)
  self.isResizable = isResizable
  if VVin2T:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVzOAn  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FF6nEU(self, color)
 def FF6nEUColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVFiKV - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVlfbl()
 def pageUp(self):
  if self.VVFiKV > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVFiKV > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVib0y(self):
  self.setPos(0)
 def VVS5nj(self):
  self.setPos(self.VVFiKV-self.pageHeight)
 def VVc4Il(self):
  return self.VVFiKV <= self.pageHeight or self.curPos == self.VVFiKV - self.pageHeight
 def VVlfbl(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVFiKV, 3))
   start = int((100 - vis) * self.curPos / (self.VVFiKV - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VViQnE=VV34ku):
  old_VVc4Il = self.VVc4Il()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VVFiKV = self.long_text.calculateSize().height()
   if self.VV6O68 and self.VVFiKV > self.pageHeight:
    self.scrollbar.show()
    self.VVlfbl()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVFiKV))
   if   VViQnE == VVFRw7: self.setPos(0)
   elif VViQnE == VVtm8Y : self.VVS5nj()
   elif old_VVc4Il    : self.VVS5nj()
 def appendText(self, text, VViQnE=VVtm8Y):
  self.setText(self.message + str(text), VViQnE)
 def VVGhOh(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVKPiM(size)
 def VVFyzn(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVKPiM(size)
 def VVJ6f3(self):
  self.VVKPiM(self.VVzOAn)
 def VVKPiM(self, VVzOAn):
  self.long_text.setFont(gFont(self.fontFamily, VVzOAn))
  self.setText(self.message, VViQnE=VV34ku)
  self.VVXdEA(calledFromFontSizer=True)
 def VV5fDT(self, align):
  self.long_text.setHAlign(align)
 def VV2LNi(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FFr9AH(expPath), self.textOutFile, FF4Auk())
    with open(outF, "w") as f:
     f.write(FFjaTr(self.message))
    FFTVfn(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FFf3zP(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVXdEA(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVFiKV > 0 and self.pageHeight > 0:
   if self.VVFiKV < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVFiKV
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
