import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VV3jny   = "v5.4.1"
VVyMwU    = "15-06-2022"
EASY_MODE    = 0
VVJI8j   = 0
VVHl1Y   = 0
VVkJbg  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVYeIO  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVXcuX    = "/media/usb/"
VVOl08    = "/usr/share/enigma2/picon/"
VV0MNj = "/etc/enigma2/blacklist"
VVDNL1   = "/etc/enigma2/"
VVOw0l  = "ajpanel_update_url"
VVAcxn   = "AJPan"
VVyIDW    = "AUTO FIND"
VVO4au    = ""
VV1ltY    = "Regular"
VV0fId      = "-" * 80
VVBgIm    = ("-" * 100, )
VVsFSY    = ""
VVGWSe   = " && echo 'Successful' || echo 'Failed!'"
VVVZSu    = []
VVqB9V  = "Cannot continue (No Enough Memory) !"
VV0DJY  = False
VVMhOQ  = False
VVVoSD = False
VVQLSY     = 0
VVnsgM    = 1
VV7nuh    = 2
VVH6oF   = 3
VV49bm    = 4
VVaG65    = 5
VV4NSz = 6
VVMEvp = 7
VV4EQp  = 8
VVmSOs   = 9
VViGyr   = 10
VVpINd   = 11
VVdhez  = 12
VVCv21  = 13
VVJFb8    = 14
VVosYn   = 15
VVswW1   = 16
VVBmKE    = 17
WINDOW_SUBTITLE    = 18
VV0aiW  = 19
VVxNTa   = 0
VV9a7T   = 1
VV39v7   = 2
def FFIJwc():
 fList = None
 try:
  from enigma import getFontFaces
  return set(getFontFaces())
 except:
  try:
   from skin import getFontFaces
   return set(getFontFaces())
  except:
   pass
 return [VV1ltY]
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices=[ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.forceUtf8Encoding   = ConfigYesNo(default=True)
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsPath    = ConfigDirectory(default=VVyIDW, visible_width=51)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=51)
CFG.PIconsPath     = ConfigDirectory(default=VVOl08, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVXcuX, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
tmp = [("srt", "From SRT File"), ("#FFFFFF", "White"), ("#C0C0C0", "Silver"), ("#808080", "Gray"), ("#000000", "Black"), ("#FF0000", "Red"), ("#800000", "Maroon"), ("#FFFF00", "Yellow"), ("#808000", "Olive"), ("#00FF00", "Lime"), ("#008000", "Green"), ("#00FFFF", "Aqua"), ("#008080", "Teal"), ("#0000FF", "Blue"), ("#000080", "Navy"), ("#FF00FF", "Fuchsia"), ("#800080", "Purple")]
CFG.subtDelay     = ConfigSelection(default="0.0", choices=[ (str(x/10.0),  str(x/10.0)) for x in range(-600, 600, 5) ])
CFG.subtTextFg     = ConfigSelection(default="srt", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VV1ltY, choices=[ (x,  x) for x in FFIJwc() ])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=80, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[ ("0", "Left"), ("1", "Center"), ("2", "Right") ])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=0, stepwidth=10, min=-140, max=140, wraparound=False)
del tmp
def FFjGLA():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVUSlg  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VV8Q6o = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVUSlg  : return 0
  elif VV8Q6o : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVKUje = FFjGLA()
VVx60q = VVXOiG = VVovWl = VVII83 = VVAyBT = VVKlhh = VVcGUH = VVuneX = COLOR_CONS_BRIGHT_YELLOW = VV0ckb = VVHzAP = VVw2dJ = VVKQBm = ""
def FF0WQo()  : FFnRlx(FFgsHN())
def FFMhqE()  : FFnRlx(FF4zDp())
def FFgM6M(tDict): FFnRlx(iDumps(tDict, indent=4, sort_keys=True))
def FFQByP(*args): FFTfIG(True, False, *args)
def FFnRlx(*args) : FFTfIG(True , True , *args)
def FFrhto(*args): FFTfIG(False, True , *args)
def FFTfIG(addSep=True, oneLine=True, *args):
 if VVJI8j:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if oneLine:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  else:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item:
      txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFZ7IL(txt, isAppend=True, ignoreErr=False):
 if VVJI8j:
  tm = FFTnop()
  err = ""
  if not ignoreErr:
   err = FF4zDp()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFnRlx(err)
  FFnRlx("Output Log File : %s" % fileName)
def FF4zDp():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFTnop()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except Exception as e:
  return "Cannot Trace !"
def FFgsHN():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVVZSu = []
def FFTR3L(win):
 global VVVZSu
 if not win in VVVZSu:
  VVVZSu.append(win)
def FF4ANQ(*args):
 global VVVZSu
 for win in VVVZSu:
  try:
   win.close()
  except:
   pass
 VVVZSu = []
def FFJzVz():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVChHQ = FFJzVz()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFez4Q()     : return PluginDescriptor(fnc=FFF0QH, where=[PluginDescriptor.WHERE_SESSIONSTART] , needsRestart=True   , description="AJPanel Startup")
def FFZHms()      : return getDescriptor(FF7edg   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFDY9G()       : return getDescriptor(FFMTte  , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFfrT5()   : return getDescriptor(FFjpcp , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFnofl(): return getDescriptor(FFfCtV , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player"  , descr="Signal Monitor / Player")
def FFBsQz()  : return getDescriptor(FFStb9  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV"     , descr="IPTV Menu")
def FF9NZw()     : return getDescriptor(FFGgT2 , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info."    , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFZHms() , FFDY9G() , FFez4Q() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFfrT5())
  result.append(FFnofl())
  result.append(FFBsQz())
 if CFG.EventsInfoMenu.getValue():
  result.append(FF9NZw())
 return result
def FFF0QH(reason, **kwargs):
 if reason == 0:
  FFFr7U()
  if "session" in kwargs:
   session = kwargs["session"]
   FFYPod(session)
   CCAccE(session)
  CCVXoR.VVWDJh()
def FFMTte(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FF7edg, PLUGIN_NAME, 45)]
 else:
  return []
def FF7edg(session, **kwargs):
 session.open(Main_Menu)
def FFjpcp(session, **kwargs):
 session.open(CCoBpc)
def FFfCtV(session, **kwargs):
 FFHiYE(session, isFromSession=True)
def FFStb9(session, **kwargs):
 session.open(CCZkJV)
def FFGgT2(session, **kwargs):
 session.open(CCzqpW, fncMode=CCzqpW.VVlhwR)
def FFtp37():
 FFnYaY(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFfrT5(), FFnofl(), FFBsQz() ])
 FFnYaY(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FF9NZw() ])
def FFnYaY(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VV2tyG = None
def FFFr7U():
 try:
  global VV2tyG
  if VV2tyG is None:
   VV2tyG    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFfOyH
  ChannelContextMenu.FFyYa1 = FFyYa1
 except:
  pass
def FFfOyH(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VV2tyG(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFyYa1, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFyYa1, title1, csel, isFind=True))))
def FFyYa1(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FF3Swx(refCode)
 except:
  pass
 self.session.open(boundFunction(CCbxwm, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFYPod(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FFsDPR, session, "lok")
 hk.actions['longCancel'] = boundFunction(FFsDPR, session, "lesc")
 hk.actions['longRed']  = boundFunction(FFsDPR, session, "lred")
def FFsDPR(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFHiYE(session, isFromSession=True)
def FF8NiA(SELF, title="", addLabel=False, addScrollLabel=False, VVE6xF=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFR16z()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCDWBz(SELF)
 if VVE6xF:
  SELF["myMenu"] = MenuList(VVE6xF)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVWw2Z        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FF4h3g(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FF09AS, SELF, "0") ,
  "1"    : boundFunction(FF09AS, SELF, "1") ,
  "2"    : boundFunction(FF09AS, SELF, "2") ,
  "3"    : boundFunction(FF09AS, SELF, "3") ,
  "4"    : boundFunction(FF09AS, SELF, "4") ,
  "5"    : boundFunction(FF09AS, SELF, "5") ,
  "6"    : boundFunction(FF09AS, SELF, "6") ,
  "7"    : boundFunction(FF09AS, SELF, "7") ,
  "8"    : boundFunction(FF09AS, SELF, "8") ,
  "9"    : boundFunction(FF09AS, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FFTkD7, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FF09AS(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVKQBm:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVKQBm + SELF.keyPressed + VVXOiG)
    txt = VVXOiG + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FF7QSu(SELF, txt)
def FFTkD7(SELF, tableObj, colNum):
 FF7QSu(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     SELF.VVVCdA(i)
     break
 except:
  pass
def FFUcO2(SELF, setMenuAction=True):
 if setMenuAction:
  global VVsFSY
  VVsFSY = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFR16z():
 return ("  %s" % VVsFSY)
def FFUWFF(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FF67wV(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFTNDf(color):
 return parseColor(color).argb()
def FF2dIb(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFH6QJ(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFiN17(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FF2CqO(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVKQBm)
 else:
  return ""
def FFIQaW(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VV0fId, word, VV0fId, VVKQBm)
 else : return "echo -e '%s\n--- %s\n%s';" % (VV0fId, word, VV0fId)
def FFcK2v(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVKQBm
def FFNiKT(color):
 if color: return "echo -e '%s' %s;" % (VV0fId, FF2CqO(VV0fId, VVuneX))
 else : return "echo -e '%s';" % VV0fId
def FFtcsN(title, color):
 title = "%s\n%s\n%s\n" % (VV0fId, title, VV0fId)
 return FFcK2v(title, color)
def FFCnHd(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FF9lZw(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFt2dO(callBackFunction):
 tCons = CCT3NF()
 tCons.ePopen("echo", boundFunction(FFFjcR, callBackFunction))
def FFFjcR(callBackFunction, result, retval):
 callBackFunction()
def FFy61j(SELF, fnc, title="Processing ...", clearMsg=True):
 FF7QSu(SELF, title)
 tCons = CCT3NF()
 tCons.ePopen("echo", boundFunction(FFDjqp, SELF, fnc, clearMsg))
def FFDjqp(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FF7QSu(SELF)
def FFPbn8(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVqB9V
  else       : return ""
def FFDp6V(cmd):
 txt = FFPbn8(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFmAmO(cmd):
 lines = FFDp6V(cmd)
 if lines: return lines[0]
 else : return ""
def FFPomL(SELF, cmd):
 lines = FFDp6V(cmd)
 VV7OA3 = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VV7OA3.append((key, val))
  elif line:
   VV7OA3.append((line, ""))
 if VV7OA3:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFIbZw(SELF, None, header=header, VVU7lj=VV7OA3, VVSkoS=widths, VVhkQh=28)
 else:
  FFAiEX(SELF, cmd)
def FFAiEX(    SELF, cmd, **kwargs): SELF.session.open(CCtW47, VV6guL=cmd, VVHvbP=True, VVvy8W=VV9a7T, **kwargs)
def FFrwEd(  SELF, cmd, **kwargs): SELF.session.open(CCtW47, VV6guL=cmd, **kwargs)
def FF5cnY(   SELF, cmd, **kwargs): SELF.session.open(CCtW47, VV6guL=cmd, VVUPts=True, VVOr3c=True, VVvy8W=VV9a7T, **kwargs)
def FFgEn3(  SELF, cmd, **kwargs): SELF.session.open(CCtW47, VV6guL=cmd, VVUPts=True, VVOr3c=True, VVvy8W=VV39v7, **kwargs)
def FFR9ZE(  SELF, cmd, **kwargs): SELF.session.open(CCtW47, VV6guL=cmd, VVUtK4=True , **kwargs)
def FF2OHw( SELF, cmd, **kwargs): SELF.session.open(CCtW47, VV6guL=cmd, VV1rFv=True   , **kwargs)
def FFfdoD( SELF, cmd, **kwargs): SELF.session.open(CCtW47, VV6guL=cmd, VVaLIm=True  , **kwargs)
def FFGA8O(cmd):
 return cmd + " > /dev/null 2>&1"
def FFGDo5():
 return " > /dev/null 2>&1"
def FF04jg(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFGFzp(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFSfMS():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFmAmO(cmd)
VVtlAg     = 0
VV9zyt      = 1
VVoGNt   = 2
VVeYXl      = 3
VVP3o8      = 4
VVa6wk     = 5
VVOR4D     = 6
VVPoce = 7
VV6Sp7 = 8
VVnwcJ = 9
VVbCwc  = 10
VV9JbV     = 11
VVodMr  = 12
VVPul6  = 13
def FFomnU(parmNum, grepTxt):
 if   parmNum == VVtlAg  : param = ["update"   , "dpkg update" ]
 elif parmNum == VV9zyt   : param = ["list"   , "apt list" ]
 elif parmNum == VVoGNt: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFSfMS()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFH2eT(parmNum, package):
 if   parmNum == VVeYXl      : param = ["info"      , "apt show"         ]
 elif parmNum == VVP3o8      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVa6wk     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVOR4D     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVPoce : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VV6Sp7 : param = ["install --force-overwrite" , "dpkg -i --force-overwrite -y"    ]
 elif parmNum == VVnwcJ : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVbCwc  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VV9JbV     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVodMr  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVPul6  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFSfMS()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFDxbr():
 result = FFmAmO("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFH2eT(VVOR4D , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFGA8O("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFGA8O("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FF2CqO(failed1, VVuneX))
   cmd += "  echo -e '%s' %s;"  % (failed2, FF2CqO(failed2, VVuneX))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FF2CqO(failed3, VVovWl))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFCwJZ(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFH2eT(VVOR4D , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFGA8O("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FF2CqO(failed1, VVuneX))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FF2CqO(failed2, VVovWl))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFvkoy(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFGA8O('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFGA8O("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFbAeW(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCVXoR.VVB5C9()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFel5Q(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFbAeW(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FF1D46(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFLJ49(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFbAeW(path, maxSize=maxSize, encLst=encLst)
  if lines: FFUojK(SELF, lines, title=title, VVvy8W=VV9a7T)
  else : FFojte(SELF, path, title=title)
 else:
  FFC6jW(SELF, path, title)
def FFirQR(SELF, path, title):
 if fileExists(path):
  txt = FFbAeW(path)
  txt = txt.replace("#W#", VVKQBm)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVXOiG)
  txt = txt.replace("#C#", VV0ckb)
  txt = txt.replace("#P#", VVII83)
  FFUojK(SELF, txt, title=title)
 else:
  FFC6jW(SELF, path, title)
def FFnmUX(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FFE8QH(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFsMYs(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFSNlf(parent)
 else    : return FFkxUt(parent)
def FFLJ49(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFSNlf(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFkxUt(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FF1jQ3():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVkJbg)
 paths.append(VVkJbg.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFE8QH(ba)
 for p in list:
  p = ba + p + VVkJbg
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVAcxn, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVkJbg, VVAcxn , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVCTiY, VVMNbP = FF1jQ3()
def FF92U4():
 def VVyn3z(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 iPath = CFG.iptvHostsPath.getValue()
 if not iPath == VVyIDW and not pathExists(iPath):
  CFG.iptvHostsPath.setValue(VVyIDW)
  CFG.iptvHostsPath.save()
  oldIptvHostsPath = VVyIDW
 else:
  oldIptvHostsPath = ""
 oldMovieDownloadPath = VVyn3z(CFG.MovieDownloadPath, CCRR2A.VVsu5T())
 VVj26V   = VVyn3z(CFG.backupPath, CCRdqr.VV2C5x())
 VVjg6X   = VVyn3z(CFG.downloadedPackagesPath, t)
 VVUxX5  = VVyn3z(CFG.exportedTablesPath, t)
 VVERsA  = VVyn3z(CFG.exportedPIconsPath, t)
 VVZULh   = VVyn3z(CFG.packageOutputPath, t)
 global VVXcuX
 VVXcuX = FFSNlf(CFG.backupPath.getValue())
 if VVj26V or VVZULh or VVjg6X or VVUxX5 or VVERsA or oldIptvHostsPath or oldMovieDownloadPath:
  configfile.save()
 return VVj26V, VVZULh, VVjg6X, VVUxX5, VVERsA, oldIptvHostsPath, oldMovieDownloadPath
def FF1B9B(path):
 path = FFkxUt(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFHkyo(SELF, pathList, tarFileName, addTimeStamp=True):
 VVU7lj = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVU7lj.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVU7lj.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVU7lj.append(path)
 if not VVU7lj:
  FFDQ9M(SELF, "Files not found!")
 elif not pathExists(VVXcuX):
  FFDQ9M(SELF, "Path not found!\n\n%s" % VVXcuX)
 else:
  VV6arv = FFSNlf(VVXcuX)
  tarFileName = "%s%s" % (VV6arv, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFmDuf())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVU7lj:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VV0fId
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FF2CqO(tarFileName, VVcGUH))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FF2CqO(failed, VVcGUH))
  cmd += "fi;"
  cmd +=  sep
  FFrwEd(SELF, cmd)
def FFu654(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFH6Sj(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFH6Sj(SELF["keyInfo"], "info")
def FFH6Sj(barObj, fName):
 path = "%s%s%s" % (VVMNbP, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FF06Jn(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFEPU0(satNum)
  return satName
def FFEPU0(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFGGpm(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FF06Jn(val)
  else  : sat = FFEPU0(val)
 return sat
def FFNC3M(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FF06Jn(num)
 except:
  pass
 return sat
def FFWxL8(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFEN32(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFmWQs(info, iServiceInformation.sServiceref)
   prov = FFmWQs(info, iServiceInformation.sProvider)
   state = str(FFmWQs(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFMLue(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFhxAo(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFmWQs(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFJ5i5(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FF3Swx(refCode):
 info = FFGf8V(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFPr51(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFS8i0(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFGf8V(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVUKzq = eServiceCenter.getInstance()
  if VVUKzq:
   info = VVUKzq.info(service)
 return info
def FFI7Gq(SELF, refCode, VVetCj=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFEdjA(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVetCj:
   FFHiYE(SELF, isFromSession)
 try:
  VV6H2w = InfoBar.instance
  if VV6H2w:
   VVD1Bc = VV6H2w.servicelist
   if VVD1Bc:
    servRef = eServiceReference(refCode)
    VVD1Bc.saveChannel(servRef)
 except:
  pass
def FFEdjA(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCEwnB()
    if pr.VVVZM9(refCode, chName, decodedUrl, iptvRef):
     pr.VV4Uz9(SELF, isFromSession)
def FFMLue(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFt5Pb(url): return FFFRPV(url) or FFUQed(url)
def FFFRPV(url)  : return any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFUQed(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FFhxAo(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFugDB(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFugDB(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFd2eb(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFnf6Q(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFscG4(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFRSri(txt):
 try:
  return FFnf6Q(FFscG4(txt)) == txt
 except:
  return False
def FFHiYE(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCZOmQ, isFromExternal=isFromSession)
 else      : FFhpzE(session, reopen=True, isFromExternal=isFromSession)
def FFhpzE(session, reopen=False, isFromExternal=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFhpzE, session, isFromExternal=isFromExternal), boundFunction(CCcyxw, isFromExternal=isFromExternal))
  except:
   try:
    FFVvSu(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFggFM(refCode):
 tp = CCKps4()
 if tp.VVdQQp(refCode) : return True
 else        : return False
def FF5nBZ(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFY6Ac():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FFEhoo():
 VV6H2w = InfoBar.instance
 if VV6H2w:
  VVD1Bc = VV6H2w.servicelist
  if VVD1Bc:
   return VVD1Bc.getBouquetList()
 return []
def FFMr65():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FF7F8X():
 path = FFMr65()
 if path:
  txt = FFbAeW(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FFixCI(userBfile):
 txt = ""
 bFile = VVDNL1 + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVDNL1 + userBfile):
  fTxt = FFbAeW(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFmAmO('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
def FFzK2b():
 return FFnpqA(InfoBar.instance.servicelist.getRoot())
def FFnpqA(root):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVUKzq = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVUKzq.info(service)
    lst.append((service.toString(), info.getName(service)))
 except:
  pass
 return lst
def FFPELm():
 VVSuGF = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVomQx = list(VVSuGF)
 return VVomQx, VVSuGF
def FFQnRo():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFKnfS(session, VVSo1J):
 VVMyR1, VVz6F9, VVBINO, camCommand = FFPGR5()
 if VVz6F9:
  runLog = False
  if   VVSo1J == CCsHqc.VV6SOn : runLog = True
  elif VVSo1J == CCsHqc.VVvXhS : runLog = True
  elif not VVBINO          : FFVvSu(session, message="SoftCam not started yet!")
  elif fileExists(VVBINO)        : runLog = True
  else             : FFVvSu(session, message="File not found !\n\n%s" % VVBINO)
  if runLog:
   session.open(boundFunction(CCsHqc, VVMyR1=VVMyR1, VVz6F9=VVz6F9, VVBINO=VVBINO, VVSo1J=VVSo1J))
 else:
  FFVvSu(session, message="No active OSCam/NCam found !", title="Live Log")
def FFPGR5():
 VVMyR1 = "/etc/tuxbox/config/"
 VVz6F9 = None
 VVBINO  = None
 camCommand = FFmAmO("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVz6F9 = "oscam"
 elif "ncam"  in camCommand : VVz6F9 = "ncam"
 if VVz6F9:
  path = FFmAmO(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFSNlf(path)
  if pathExists(path):
   VVMyR1 = path
  tFile = VVMyR1 + VVz6F9 + ".conf"
  tFile = FFmAmO("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVBINO = tFile
 return VVMyR1, VVz6F9, VVBINO, camCommand
def FFtsyU(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFApFw():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFmDuf():
 return FFApFw().replace(" ", "_").replace("-", "").replace(":", "")
def FFesdJ(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFTnop():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFZ5gR(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCZkJV.VVU5fz(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCZkJV.VVUGxW_forBouquet(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFGA8O("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFhjCC(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFhZ13(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
VViNiY = 0
def FFiJA2():
 global VViNiY
 VViNiY = iTime()
def FFkC8y():
 FFnRlx(">>>>>> Elapsed\t: {:.6f} seconds".format(iTime() - VViNiY).rstrip("0").rstrip("."))
def FFrSV8(SELF, message, title=""):
 SELF.session.open(boundFunction(CCJzoM, title=title, message=message, VVYs0e=True))
def FFUojK(SELF, message, title="", VVvy8W=VV9a7T, **kwargs):
 SELF.session.open(boundFunction(CCJzoM, title=title, message=message, VVvy8W=VVvy8W, **kwargs))
def FFDQ9M(SELF, message, title="")  : FFVvSu(SELF.session, message, title)
def FFC6jW(SELF, path, title="") : FFVvSu(SELF.session, "File not found !\n\n%s" % path, title)
def FFojte(SELF, path, title="") : FFVvSu(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFVSFz(SELF, title="")  : FFVvSu(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFVvSu(session, message, title="") : session.open(boundFunction(CCQmOV, title=title, message=message))
def FFzG9s(SELF, VVG4RV, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVG4RV, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVG4RV, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVG4RV, boundFunction(CCwfNJ, title=title, message=message, VVsHM3=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFDQ9M(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFZhjP(SELF, callBack_Yes, VVDJXG, callBack_No=None, title="", VVXqay=False, VVLb4n=True):
 SELF.session.openWithCallback(boundFunction(FFDZVW, callBack_Yes, callBack_No)
        , boundFunction(CCPijz, title=title, VVDJXG=VVDJXG, VVLb4n=VVLb4n, VVXqay=VVXqay))
def FFDZVW(callBack_Yes, callBack_No, FFZhjPed):
 if FFZhjPed : callBack_Yes()
 elif callBack_No: callBack_No()
def FF7QSu(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFH6QJ(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFP4Dm(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFSWW2(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVoxNi = eTimer()
def FFP4Dm(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFHeuN, SELF))
 fnc = boundFunction(FFHeuN, SELF)
 try:
  t = VVoxNi.timeout.connect(fnc)
 except:
  VVoxNi.callback.append(fnc)
 VVoxNi.start(milliSeconds, 1)
def FFHeuN(SELF):
 VVoxNi.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFIbZw(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCO89m, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCO89m, **kwargs))
  FFTR3L(win)
  return win
 except:
  return None
def FFtUqp(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCHE0w, **kwargs))
 FFTR3L(win)
 return win
def FFvad7(SELF, **kwargs):
 SELF.session.open(CCzqpW, **kwargs)
def FFvFrO(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFh1vf(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VV1ltY, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFoto4(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFh1vf(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFzSJo():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFWFhZ(VVhkQh):
 screenSize  = FFzSJo()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVhkQh)
 return bodyFontSize
def FFPMOz(VVhkQh, extraSpace):
 font = gFont(VV1ltY, VVhkQh)
 VVQFBH = fontRenderClass.getInstance().getLineHeight(font) or (VVhkQh * 1.25)
 return int(VVQFBH + VVQFBH * extraSpace)
def FFoyhf(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFzSJo()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VV1ltY, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFPMOz(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VV1ltY, titleFontSize, alignLeftCenter)
 if winType == VVQLSY or winType == VVnsgM:
  if winType == VVnsgM : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VV0aiW:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == WINDOW_SUBTITLE:
  lineH = int((height - 8) / 3.0)
  top = 2
  tmp += '<widget name="mySubtFr" position="0,0" size="%d,%d" zPosition="10" backgroundColor="#00FFFF00" />' % (width, height)
  for i in range(3):
   tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="11" foregroundColor="#ffffff" shadowColor="#555555" shadowOffset="-2,-2" backgroundColor="#ff000000" %s %s />' % (i, top + 2, width - 2, lineH - 2, bodyFontStr, alignCenter)
   top += lineH
 elif winType == VVJFb8:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FFrSV8L = b2Left2 + timeW + marginLeft
  FFrSV8W = b2Left3 - marginLeft - FFrSV8L
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FFrSV8L  , b2Top, FFrSV8W , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
 elif winType == VVosYn:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VV49bm:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VV7nuh:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVH6oF:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VV1ltY, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VV1ltY, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VViGyr:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFrSV8H = int(bodyH * 0.5)
  inpTop = bodyTop + FFrSV8H
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFrSV8H, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VV1ltY, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VV1ltY, mapF, alignCenter)
 elif winType == VVpINd:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVdhez:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VV1ltY, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVswW1:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VV1ltY, fontH, alignCenter)
 elif winType == VVCv21:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VV1ltY, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VV1ltY, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VV1ltY, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVBmKE:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVaG65:
  tmp += '<widget name="myPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (marginLeft, bodyTop, bodyW, bodyH)
 else:
  if   winType == VVMEvp : align = alignLeftCenter
  elif winType == VV4NSz : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVmSOs:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VV1ltY
  if usefixedFont and winType == VV4NSz:
   fnt = "Fixed"
   if fnt in FFIJwc():
    fontName = "Fixed"
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVhkQh = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VV1ltY, VVhkQh, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVDUXJ = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VV1ltY, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVDUXJ[i], VV1ltY, barFont, alignCenter)
   left += btnW + gap
 if winType == VV4NSz:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVDUXJ = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVDUXJ[i], VV1ltY, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFoyhf(VVQLSY, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.VVu9NU = ""
  self.themsList  = []
  VVE6xF = []
  if VVHl1Y:
   VVE6xF.append(("-- MY TEST --"    , "myTest"   ))
  VVE6xF.append(("  File Manager"     , "FileManager"  ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("  Services/Channels"    , "ChannelsTools" ))
  VVE6xF.append(("  IPTV"       , "IptvTools"  ))
  VVE6xF.append(("  PIcons"       , "PIconsTools"  ))
  VVE6xF.append(("  SoftCam"      , "SoftCam"   ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("  Plugins"      , "PluginsTools" ))
  VVE6xF.append(("  Terminal"      , "Terminal"  ))
  VVE6xF.append(("  Backup & Restore"    , "BackupRestore" ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("  Date/Time"      , "Date_Time"  ))
  VVE6xF.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVE6xF)
  FF8NiA(self, VVE6xF=VVE6xF)
  FFUWFF(self["keyRed"] , "Exit")
  FFUWFF(self["keyGreen"] , "Settings")
  FFUWFF(self["keyYellow"], "Dev. Info.")
  FFUWFF(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VVafLK       ,
   "yellow"  : self.VVv5XV       ,
   "blue"   : self.VVqjse       ,
   "info"   : self.VVqjse       ,
   "next"   : self.VVHMup       ,
   "menu"   : self.VVuB2z     ,
   "text"   : self.VV3yQd      ,
   "0"    : boundFunction(self.VV6L49, 0) ,
   "1"    : boundFunction(self.VV6P0F, 1)   ,
   "2"    : boundFunction(self.VV6P0F, 2)   ,
   "3"    : boundFunction(self.VV6P0F, 3)   ,
   "4"    : boundFunction(self.VV6P0F, 4)   ,
   "5"    : boundFunction(self.VV6P0F, 5)   ,
   "6"    : boundFunction(self.VV6P0F, 6)   ,
   "7"    : boundFunction(self.VV6P0F, 7)   ,
   "8"    : boundFunction(self.VV6P0F, 8)   ,
   "9"    : boundFunction(self.VV6P0F, 9)
  })
  self.onShown.append(self.VVbxfr)
  self.onClose.append(self.onExit)
  global VV0DJY, VVMhOQ, VVVoSD
  VV0DJY = VVMhOQ = VVVoSD = False
 def VVWw2Z(self):
  item = FFUcO2(self)
  self.VV6P0F(item)
 def VV6P0F(self, item):
  if item is not None:
   if   item == "myTest"     : self.VV54Gs()
   elif item in ("FileManager"  , 1) : self.session.open(CCoBpc)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCZkgq)
   elif item in ("IptvTools"  , 3) : self.session.open(CCZkJV)
   elif item in ("PIconsTools"  , 4) : self.VVdI0g()
   elif item in ("SoftCam"   , 5) : self.session.open(CCBoE2)
   elif item in ("PluginsTools" , 6) : self.session.open(CCmvxM)
   elif item in ("Terminal"  , 7) : self.session.open(CC2aVM)
   elif item in ("BackupRestore" , 8) : self.session.open(CC2EQw)
   elif item in ("Date_Time"  , 9) : self.session.open(CCG29I)
   elif item in ("CheckInternet" , 10) : self.session.open(CCch2L)
   else         : self.close()
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFCnHd(self["myMenu"])
  FFoto4(self)
  FFvFrO(self)
  title = "  %s - %s" % (PLUGIN_NAME, VV3jny)
  self["myTitle"].setText(title)
  VVj26V, VVZULh, VVjg6X, VVUxX5, VVERsA, oldIptvHostsPath, oldMovieDownloadPath = FF92U4()
  self.VVyTo0()
  if VVj26V or VVZULh or VVjg6X or VVUxX5 or VVERsA or oldIptvHostsPath or oldMovieDownloadPath:
   VVUkWF = lambda path, subj: "%s:\n%s\n\n" % (subj, FFcK2v(path, VVovWl)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVUkWF(oldIptvHostsPath  , "IPTV Hosts Files Path"   )
   txt += VVUkWF(VVj26V   , "Backup/Restore Path"    )
   txt += VVUkWF(VVZULh  , "Created Package Files (IPK/DEB)" )
   txt += VVUkWF(VVjg6X  , "Download Packages (from feeds)" )
   txt += VVUkWF(VVUxX5 , "Exported Tables"     )
   txt += VVUkWF(VVERsA , "Exported PIcons"     )
   txt += VVUkWF(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFUojK(self, txt, title="Settings Paths")
  if (EASY_MODE or VVJI8j or VVHl1Y):
   FFH6QJ(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FF7QSu(self, "Welcome", 300)
  FFt2dO(boundFunction(self.VV18jG, title))
 def VV18jG(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCRdqr.VV206t()
   if url:
    newWebVer = CCRdqr.VV74EJ(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFGA8O("rm /tmp/ajpanel*"))
  global VV0DJY, VVMhOQ, VVVoSD
  VV0DJY = VVMhOQ = VVVoSD = False
 def VV6L49(self, digit):
  self.VVu9NU += str(digit)
  ln = len(self.VVu9NU)
  global VV0DJY, VVVoSD
  if ln == 4:
   if self.VVu9NU == "0" * ln:
    VV0DJY = True
    FFH6QJ(self["myTitle"], "#800080")
   else:
    self.VVu9NU = "x"
  elif self.VVu9NU == "0" * 8:
   VVVoSD = True
 def VVHMup(self):
  self.VVu9NU += ">"
  if self.VVu9NU == "0" * 4 + ">" * 2:
   global VVMhOQ
   VVMhOQ = True
   FFH6QJ(self["myTitle"], "#dd5588")
 def VV3yQd(self):
  if self.VVu9NU == "0" * 4:
   ok = False
   fnt = "ae_AlMateen.ttf"
   fontFile = "/usr/share/fonts/%s" % fnt
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    try:
     addFont(fontFile, fontName, 100, True)
     ok = True
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      ok = True
     except:
      pass
   if ok: txt = 'Added Font: "%s"' % fnt
   else : txt = '"%s" Not Found' % fnt
   FF7QSu(self, txt, 2000, isGrn=ok)
 def VVdI0g(self):
  found = False
  pPath = CC5NMK.VVBX3T()
  if pathExists(pPath):
   for fName, fType in CC5NMK.VVj5cd(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CC5NMK)
  else:
   VVE6xF = []
   VVE6xF.append(("PIcons Manager" , "CC5NMK" ))
   VVE6xF.append(VVBgIm)
   VVE6xF.append(CC5NMK.VVBy0r())
   VVE6xF.append(VVBgIm)
   VVE6xF += CC5NMK.VV3Lbt()
   FFtUqp(self, self.VV0ddU, VVE6xF=VVE6xF)
 def VV0ddU(self, item=None):
  if item:
   if   item == "CC5NMK"   : self.session.open(CC5NMK)
   elif item == "VVu0QH"  : CC5NMK.VVu0QH(self)
   elif item == "VVJn99"  : CC5NMK.VVJn99(self)
   elif item == "findPiconBrokenSymLinks" : CC5NMK.VVqrU1(self, True)
   elif item == "FindAllBrokenSymLinks" : CC5NMK.VVqrU1(self, False)
 def VVafLK(self):
  self.session.open(CCRdqr)
 def VVv5XV(self):
  self.session.open(CCXVMz)
 def VVqjse(self):
  changeLogFile = VVMNbP + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FFel5Q(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFcK2v("\n%s\n%s\n%s" % (VV0fId, line, VV0fId), VVuneX, VVKQBm)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FFcK2v(line, VVXOiG, VVKQBm)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFUojK(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VV3jny, PLUGIN_DESCRIPTION), VVhkQh=26)
 def VVuB2z(self):
  VVE6xF = []
  VVE6xF.append(("Title Colors"   , "title" ))
  VVE6xF.append(("Menu Area Colors"  , "body" ))
  VVE6xF.append(("Menu Pointer Colors" , "cursor" ))
  VVE6xF.append(("Bottom Bar Colors" , "bar"  ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Reset Colors"   , "reset" ))
  title = "Main Menu Colors"
  FFtUqp(self, boundFunction(self.VVcdnK, title), VVE6xF=VVE6xF, width=500, title=title)
 def VVcdnK(self, title, item=None):
  if item:
   if item == "reset":
    FFZhjP(self, self.VVqo1l, "Reset to default colors ?", title=title)
   else:
    tDict = self.VV1YvX()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VVjQWK, tDict, item), CCQSWl, defFG=fg, defBG=bg)
 def VVAa3h(self):
  return VVXcuX + "ajpanel_colors"
 def VV1YvX(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVAa3h()
  if fileExists(p):
   txt = FFbAeW(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVjQWK(self, tDict, item, fg, bg):
  if fg:
   self.VVp9xi(item, fg)
   self.VVcJFy(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVFPBj(tDict)
 def VVFPBj(self, tDict):
   p = self.VVAa3h()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVp9xi(self, item, fg):
  if   item == "title" : FF2dIb(self["myTitle"], fg)
  elif item == "body"  :
   FF2dIb(self["myMenu"], fg)
   FF2dIb(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFH6QJ(self["myBar"], fg)
   FF2dIb(self["keyRed"], fg)
   FF2dIb(self["keyGreen"], fg)
   FF2dIb(self["keyYellow"], fg)
   FF2dIb(self["keyBlue"], fg)
 def VVcJFy(self, item, bg):
  if   item == "title" : FFH6QJ(self["myTitle"], bg)
  elif item == "body"  :
   FFH6QJ(self["myMenu"], bg)
   FFH6QJ(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFH6QJ(self["myBar"], bg)
 def VVqo1l(self):
  os.system(FFGA8O("rm %s" % self.VVAa3h()))
  self.close()
 def VVyTo0(self):
  tDict = self.VV1YvX()
  self.VV6UOn(tDict, "title")
  self.VV6UOn(tDict, "body")
  self.VV6UOn(tDict, "cursor")
  self.VV6UOn(tDict, "bar")
 def VV6UOn(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVp9xi(name, fg)
  if bg: self.VVcJFy(name, bg)
 def VV54Gs(self):
  pass
class CCVXoR():
 @staticmethod
 def VVB5C9():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVWDJh(isApply=False):
  global VV9gmM, VV28fl
  VV9gmM  = True
  VV28fl = CCVXoR.VVozJS()
  CCVXoR.VVnsql()
 @staticmethod
 def VVnsql():
  if VV28fl:
   global VV9gmM
   if CFG.forceUtf8Encoding.getValue():
    if CCVXoR.VVNtRl() : VV9gmM = True
    else        : VV9gmM = False
   else:
    CCVXoR.VVKZBM()
    VV9gmM = False
 @staticmethod
 def VVozJS(isApply=False):
  from sys import version_info
  if version_info[0] >= 3 and version_info[1] >= 10:
   path = "/etc/issue"
   if fileExists(path):
    path = "/etc/issue"
    if fileExists(path):
     txt = FFbAeW(path)
     span = iSearch(r"open.?vision", txt, IGNORECASE)
     if span:
      return True
  return False
 @staticmethod
 def VVNtRl():
  import locale
  enc = locale.getdefaultlocale()[1]
  span = iSearch(r"UTF.?8", enc, IGNORECASE)
  if not span:
   try:
    import locale
    return locale.setlocale(locale.LC_ALL, "en_GB.UTF-8")
   except:
    pass
  return None
 @staticmethod
 def VVKZBM():
  try:
   import locale
   return locale.setlocale(locale.LC_ALL, "")
  except:
   return None
 @staticmethod
 def VVRDY0(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFIbZw(SELF, None, VVU7lj=lst, VVhkQh=30, VVkAlE=True)
 @staticmethod
 def VVJhd6(path, SELF=None):
  for enc in CCVXoR.VVB5C9():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFDQ9M(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVlt7K(SELF, path, cbFnc, defEnc="", pos=0):
  FF7QSu(SELF)
  lst = CCVXoR.VVzZFG(path)
  if lst:
   VVE6xF = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if defEnc == enc:
     txt = FFcK2v(txt, VVcGUH)
    VVE6xF.append((txt, enc))
   win = FFtUqp(SELF, cbFnc, title="Select Encoding", VVE6xF=VVE6xF, width=900, height=500 if pos == 1 else 0)
   if pos == 1:
    win.instance.move(ePoint(40, 40))
  else:
   FF7QSu(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVzZFG(path):
  encLst = []
  cPath = VVMNbP + "codecs"
  if fileExists(cPath):
   lines = FFel5Q(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCVXoR.VVB5C9())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    try:
     with ioOpen(path, "r", encoding=enc) as f:
      for line in f:
       pass
     lst.append((item[0], enc))
    except:
     pass
  return lst
class CCXVMz(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFoyhf(VVQLSY, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVE6xF = []
  VVE6xF.append(("Settings File"        , "SettingsFile"   ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Box Info"          , "VVev7i"    ))
  VVE6xF.append(("Tuners Info"         , "VVugS5"   ))
  VVE6xF.append(("Python Version"        , "VVExd6"   ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Screen Size"         , "ScreenSize"    ))
  VVE6xF.append(("Language/Locale"        , "Locale"     ))
  VVE6xF.append(("Processor"         , "Processor"    ))
  VVE6xF.append(("Operating System"        , "OperatingSystem"   ))
  VVE6xF.append(("Drivers"          , "drivers"     ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("System Users"         , "SystemUsers"    ))
  VVE6xF.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVE6xF.append(("Uptime"          , "Uptime"     ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Host Name"         , "HostName"    ))
  VVE6xF.append(("MAC Address"         , "MACAddress"    ))
  VVE6xF.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVE6xF.append(("Network Status"        , "NetworkStatus"   ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Disk Usage"         , "VVzkan"    ))
  VVE6xF.append(("Mount Points"         , "MountPoints"    ))
  VVE6xF.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVE6xF.append(("USB Devices"         , "USB_Devices"    ))
  VVE6xF.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVE6xF.append(("Directory Size"        , "DirectorySize"   ))
  VVE6xF.append(("Memory"          , "Memory"     ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVE6xF.append(("Running Processes"       , "RunningProcesses"  ))
  VVE6xF.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FF8NiA(self, VVE6xF=VVE6xF, title="Device Information")
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFCnHd(self["myMenu"])
  FFoto4(self)
 def VVWw2Z(self):
  global VVsFSY
  VVsFSY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCKZPU)
   elif item == "VVev7i"    : self.VVev7i()
   elif item == "VVugS5"   : self.VVugS5()
   elif item == "VVExd6"   : self.VVExd6()
   elif item == "ScreenSize"    : FFUojK(self, "Width\t: %s\nHeight\t: %s" % (FFzSJo()[0], FFzSJo()[1]))
   elif item == "Locale"     : CCVXoR.VVRDY0(self)
   elif item == "Processor"    : self.VVOKMz()
   elif item == "OperatingSystem"   : FFAiEX(self, "uname -a"        )
   elif item == "drivers"     : self.VVgHHv()
   elif item == "SystemUsers"    : FFAiEX(self, "id"          )
   elif item == "LoggedInUsers"   : FFAiEX(self, "who -a"         )
   elif item == "Uptime"     : FFAiEX(self, "uptime"         )
   elif item == "HostName"     : FFAiEX(self, "hostname"        )
   elif item == "MACAddress"    : self.VViBey()
   elif item == "NetworkConfiguration"  : FFAiEX(self, "ifconfig %s %s" % (FF2CqO("HWaddr", VVw2dJ), FF2CqO("addr:", VVuneX)))
   elif item == "NetworkStatus"   : FFAiEX(self, "netstat -tulpn"       )
   elif item == "VVzkan"    : self.VVzkan()
   elif item == "MountPoints"    : FFAiEX(self, "mount %s" % (FF2CqO(" on ", VVuneX)))
   elif item == "FileSystemTable"   : FFAiEX(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFAiEX(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFAiEX(self, "blkid"         )
   elif item == "DirectorySize"   : FFAiEX(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVWS5r="Reading size ...")
   elif item == "Memory"     : FFAiEX(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVIhzZ()
   elif item == "RunningProcesses"   : FFAiEX(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFAiEX(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VV7iyf()
   else         : self.close()
 def VViBey(self):
  res = FFPbn8("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFUojK(self, txt)
  else:
   FFAiEX(self, "ip link")
 def VVp6eF(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFDp6V(cmd)
  return lines
 def VVrSqZ(self, lines, headerRepl, widths, VV9ki4):
  VV7OA3 = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VV7OA3.append(parts)
  if VV7OA3 and len(header) == len(widths):
   VV7OA3.sort(key=lambda x: x[0].lower())
   FFIbZw(self, None, header=header, VVU7lj=VV7OA3, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=28, VVkAlE=True)
   return True
  else:
   return False
 def VVzkan(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFPbn8(cmd)
  if not "invalid option" in txt:
   lines  = self.VVp6eF(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VV9ki4 = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVrSqZ(lines, headerRepl, widths, VV9ki4)
  else:
   cmd = "df -h"
   lines  = self.VVp6eF(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VV9ki4 = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVrSqZ(lines, headerRepl, widths, VV9ki4)
  if not allOK:
   lines = FFDp6V(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFkxUt(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVcGUH:
     note = "\n%s" % FFcK2v("Green = Mounted Partitions", VVcGUH)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVuneX
     elif line.endswith(mountList) : color = VVcGUH
     else       : color = VVXOiG
     txt += FFcK2v(line, color) + "\n"
    FFUojK(self, txt + note)
   else:
    FFDQ9M(self, "Not data from system !")
 def VVIhzZ(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVp6eF(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VV9ki4 = (LEFT , CENTER, LEFT )
  allOK = self.VVrSqZ(lines, headerRepl, widths, VV9ki4)
  if not allOK:
   FFAiEX(self, cmd)
 def VVgHHv(self):
  cmd = FFomnU(VVoGNt, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFAiEX(self, cmd)
  else : FFVSFz(self)
 def VVOKMz(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFAiEX(self, cmd)
 def VV7iyf(self):
  cmd = FFomnU(VV9zyt, "| grep secondstage")
  if cmd : FFAiEX(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFVSFz(self)
 def VVev7i(self):
  c = VVcGUH
  VVU7lj = []
  VVU7lj.append((FFcK2v("Box Type"  , c), FFcK2v(self.VVs3vi("boxtype").upper(), c)))
  VVU7lj.append((FFcK2v("Board Version", c), FFcK2v(self.VVs3vi("board_revision") , c)))
  VVU7lj.append((FFcK2v("Chipset"  , c), FFcK2v(self.VVs3vi("chipset")  , c)))
  VVU7lj.append((FFcK2v("S/N"   , c), FFcK2v(self.VVs3vi("sn")    , c)))
  VVU7lj.append((FFcK2v("Version"  , c), FFcK2v(self.VVs3vi("version")  , c)))
  VVkIUb   = []
  VV5QbQ = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VV5QbQ = SystemInfo[key]
     else:
      VVkIUb.append((FFcK2v(str(key), VV0ckb), FFcK2v(str(SystemInfo[key]), VV0ckb)))
  except:
   pass
  if VV5QbQ:
   VV5yy2 = self.VVbhtZ(VV5QbQ)
   if VV5yy2:
    VV5yy2.sort(key=lambda x: x[0].lower())
    VVU7lj += VV5yy2
  if VVkIUb:
   VVkIUb.sort(key=lambda x: x[0].lower())
   VVU7lj += VVkIUb
  if VVU7lj:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFIbZw(self, None, header=header, VVU7lj=VVU7lj, VVSkoS=widths, VVhkQh=28, VVkAlE=True)
  else:
   FFUojK(self, "Could not read info!")
 def VVs3vi(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFel5Q(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVbhtZ(self, mbDict):
  try:
   mbList = list(mbDict)
   VVU7lj = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVU7lj.append((FFcK2v(subject, VVuneX), FFcK2v(value, VVuneX)))
  except:
   pass
  return VVU7lj
 def VVugS5(self):
  txt = self.VVrI47("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVrI47("/proc/bus/nim_sockets")
  if not txt: txt = self.VV02ub()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFUojK(self, txt)
 def VV02ub(self):
  txt = ""
  VVUkWF = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVUkWF("Slot Name" , slot.getSlotName())
     txt += FFcK2v(slotName, VVuneX)
     txt += VVUkWF("Description"  , slot.getFullDescription())
     txt += VVUkWF("Frontend ID"  , slot.frontend_id)
     txt += VVUkWF("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVrI47(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFel5Q(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFcK2v(line, VVuneX)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVExd6(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFUojK(self, txt)
class CCKZPU(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFoyhf(VVQLSY, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVE6xF = []
  VVE6xF.append(("Settings (All)"   , "Settings_All"   ))
  VVE6xF.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  if VVMhOQ:
   VVE6xF.append(("Settings (FHDG-17)" , "Settings_FHDG_17"  ))
  VVE6xF.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVE6xF.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVE6xF.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVE6xF.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVE6xF.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FF8NiA(self, VVE6xF=VVE6xF)
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFCnHd(self["myMenu"])
  FFoto4(self)
 def VVWw2Z(self):
  global VVsFSY
  VVsFSY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFAiEX(self, cmd                )
   elif item == "Settings_HotKeys"   : FFAiEX(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFAiEX(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFAiEX(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFAiEX(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFAiEX(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFAiEX(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFAiEX(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCBoE2(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFoyhf(VVQLSY, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVMyR1, VVz6F9, VVBINO, camCommand = FFPGR5()
  self.VVz6F9 = VVz6F9
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVE6xF = []
  VVE6xF.append(("OSCam Files"        , "OSCamFiles"  ))
  VVE6xF.append(("NCam Files"        , "NCamFiles"  ))
  VVE6xF.append(("CCcam Files"        , "CCcamFiles"  ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVE6xF.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVE6xF.append(VVBgIm)
  if VVz6F9:
   if   "oscam" in VVz6F9 : camName = "OSCam"
   elif "ncam"  in VVz6F9 : camName = "NCam"
   VVE6xF.append((camName + " Info."      , "camInfo"   ))
   VVE6xF.append((camName + " Live Status"    , "camLiveStatus" ))
   VVE6xF.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVE6xF.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVE6xF.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FF8NiA(self, VVE6xF=VVE6xF)
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFCnHd(self["myMenu"])
  FFoto4(self)
 def VVWw2Z(self):
  global VVsFSY
  VVsFSY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CC6pKg, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CC6pKg, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CC6pKg, "cccam"))
   elif item == "OSCamReaders"  : self.VVSMVd("os")
   elif item == "NSCamReaders"  : self.VVSMVd("n")
   elif item == "camInfo"   : FFPomL(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFKnfS(self.session, CCsHqc.VV6SOn)
   elif item == "camLiveReaders" : FFKnfS(self.session, CCsHqc.VVvXhS)
   elif item == "camLiveLog"  : FFKnfS(self.session, CCsHqc.VVxFM2)
   else       : self.close()
 def VVSMVd(self, camPrefix):
  VV7OA3 = self.VV65ZO(camPrefix)
  if VV7OA3:
   VV7OA3.sort(key=lambda x: int(x[0]))
   if self.VVz6F9 and self.VVz6F9.startswith(camPrefix):
    VVJlME = ("Toggle State", self.VVgrwY, [camPrefix], "Changing State ...")
   else:
    VVJlME = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VV9ki4  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFIbZw(self, None, header=header, VVU7lj=VV7OA3, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=26, VVJlME=VVJlME, VVyLkT=True)
 def VV65ZO(self, camPrefix):
  readersFile = self.VVMyR1 + camPrefix + "cam.server"
  VV7OA3 = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFel5Q(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VV7OA3.append((str(len(VV7OA3) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VV7OA3:
    FFDQ9M(self, "No readers found !")
  else:
   FFC6jW(self, readersFile)
  return VV7OA3
 def VVgrwY(self, VVoKzZ, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVMyR1, camPrefix)
  readerState  = VVoKzZ.VVai60(1)
  readerLabel  = VVoKzZ.VVai60(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCBoE2.VVsK44(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVoKzZ.VVItnB()
    FFDQ9M(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VV7OA3 = self.VV65ZO(camPrefix)
   if VV7OA3:
    VVoKzZ.VVZlxC(VV7OA3)
 @staticmethod
 def VVsK44(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFel5Q(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFDQ9M(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFDQ9M(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFC6jW(SELF, confFile)
   return None
  if not iRequest:
   FFDQ9M(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FFDQ9M(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FFDQ9M(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CC6pKg(Screen):
 def __init__(self, VV3XF6, session, args=0):
  self.skin, self.skinParam = FFoyhf(VVQLSY, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVMyR1, VVz6F9, VVBINO, camCommand = FFPGR5()
  if   VV3XF6 == "ncam" : self.prefix = "n"
  elif VV3XF6 == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVE6xF = []
  if self.prefix == "":
   VVE6xF.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVE6xF.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVE6xF.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVE6xF.append(("constant.cw"         , "x_constant_cw" ))
   VVE6xF.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVE6xF.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVE6xF.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVE6xF.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVE6xF.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVE6xF.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVE6xF.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVE6xF.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVE6xF.append(VVBgIm)
   VVE6xF.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVE6xF.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVE6xF.append(VVBgIm)
   VVE6xF.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVE6xF.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVE6xF.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FF8NiA(self, VVE6xF=VVE6xF)
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFCnHd(self["myMenu"])
  FFoto4(self)
 def VVWw2Z(self):
  global VVsFSY
  VVsFSY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FF1D46(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FF1D46(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FF1D46(self, self.VVMyR1 + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FF1D46(self, self.VVMyR1 + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVYyUp("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVYyUp("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVYyUp("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVYyUp("cam.provid"        )
   elif item == "x_cam_server"  : self.VVYyUp("cam.server"        )
   elif item == "x_cam_services" : self.VVYyUp("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVYyUp("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVYyUp("cam.user"        )
   elif item == "x_VV0fId"   : pass
   elif item == "x_SoftCam_Key" : self.VVSneB()
   elif item == "x_CCcam_cfg"  : FF1D46(self, self.VVMyR1 + "CCcam.cfg"    )
   elif item == "x_VV0fId"   : pass
   elif item == "x_cam_log"  : FF1D46(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FF1D46(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FF1D46(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVYyUp(self, fileName):
  FF1D46(self, self.VVMyR1 + self.prefix + fileName)
 def VVSneB(self):
  path = self.VVMyR1 + "SoftCam.Key"
  if fileExists(path) : FF1D46(self, path)
  else    : FF1D46(self, path.replace(".Key", ".key"))
class CCsHqc(Screen):
 VV6SOn  = 0
 VVvXhS = 1
 VVxFM2 = 2
 def __init__(self, session, VVMyR1="", VVz6F9="", VVBINO="", VVSo1J=VV6SOn):
  self.skin, self.skinParam = FFoyhf(VV4NSz, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVBINO   = VVBINO
  self.VVSo1J  = VVSo1J
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVMyR1 + VVz6F9 + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVz6F9 : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVMyR1, self.camPrefix)
  if self.VVSo1J == self.VV6SOn:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVSo1J == self.VVvXhS:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FF8NiA(self, self.Title, addScrollLabel=True)
  FFUWFF(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVbocZ
  self.onShown.append(self.VVbxfr)
  self.onClose.append(self.onExit)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  self["myLabel"].VVfh1g(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFvFrO(self)
  self.VVbocZ()
 def onExit(self):
  self.timer.stop()
 def VV35Wr(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVKbkz)
  except:
   self.timer.callback.append(self.VVKbkz)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FF7QSu(self, "Started", 1000)
 def VVSm96(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVKbkz)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FF7QSu(self, "Stopped", 1000)
 def VVbocZ(self):
  if self.timerRunning:
   self.VVSm96()
  else:
   self.VV35Wr()
   if self.VVSo1J == self.VV6SOn or self.VVSo1J == self.VVvXhS:
    if self.VVSo1J == self.VV6SOn : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCBoE2.VVsK44(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFt2dO(self.VVYVXg)
    else:
     self.close()
   else:
    self.VVt4pK()
 def VVKbkz(self):
  if self.timerRunning:
   if   self.VVSo1J == self.VV6SOn : self.VVRShm()
   elif self.VVSo1J == self.VVvXhS : self.VVRShm()
   else            : self.VVt4pK()
 def VVt4pK(self):
  if fileExists(self.VVBINO):
   fTime = FFtsyU(os.path.getmtime(self.VVBINO))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VV7Vwl(), VVvy8W=VV39v7)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVBINO)
 def VVYVXg(self):
  self.VVRShm()
 def VVRShm(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFcK2v("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVII83))
   self.camWebIfErrorFound = True
   self.VVSm96()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVSo1J == self.VV6SOn : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFcK2v("Error while parsing data elements !\n\nError = %s" % str(e), VVovWl)
   self.camWebIfErrorFound = True
   self.VVSm96()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVqpKp(root)
  self["myLabel"].setText(txt, VVvy8W=VV39v7)
  self["myBar"].setText("Last Update : %s" % FFApFw())
 def VVqpKp(self, rootElement):
  def VVUkWF(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVSo1J == self.VV6SOn:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFcK2v(status, VVcGUH)
    else          : status = FFcK2v(status, VVovWl)
    txt += VV0fId + "\n"
    txt += VVUkWF("Name"  , name)
    txt += VVUkWF("Description" , desc)
    txt += VVUkWF("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVUkWF("Protocol" , protocol)
    txt += VVUkWF("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFcK2v("Yes", VVcGUH)
    else    : enabTxt = FFcK2v("No", VVovWl)
    txt += VV0fId + "\n"
    txt += VVUkWF("Label"  , label)
    txt += VVUkWF("Protocol" , protocol)
    txt += VVUkWF("Enabled" , enabTxt)
  return txt
 def VV7Vwl(self):
  wordsDict = self.VVXntr()
  color = [ VVuneX, VVw2dJ, VVcGUH, VVovWl, VV0ckb, VVAyBT]
  lines = FFDp6V("tail -n %d %s" % (100, self.VVBINO))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVII83 + line[:19] + VVXOiG + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVKQBm + line[ndx + 3:] + VVXOiG
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVuneX + line[ndx + 8 : ndx1 + 4] + VVXOiG + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVXOiG)
   elif line.startswith("----") or ">>" in line:
    line = FFcK2v(line, VVuneX)
   txt += line + "\n"
  return txt
 def VVXntr(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFel5Q(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CC2EQw(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFoyhf(VVQLSY, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVE6xF = []
  VVE6xF.append(("Backup Channels"    , "VVQDXq"   ))
  VVE6xF.append(("Restore Channels"    , "Restore_Channels"  ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Backup SoftCAM Files"   , "VVFvz9" ))
  VVE6xF.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVE6xF.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVE6xF.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Backup Network Settings"  , "VVkakf"   ))
  VVE6xF.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVMhOQ:
   VVE6xF.append(VVBgIm)
   VVE6xF.append((VVII83 + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VVG98L"   ))
   VVE6xF.append((VVcGUH + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVyMwU) , "createMyIpk"   ))
   VVE6xF.append((VVcGUH + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVyMwU) , "createMyDeb"   ))
   VVE6xF.append((VV0ckb + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVE6xF.append((VV0ckb + "Decode %s Crash Report"   % PLUGIN_NAME     , "VViwVg" ))
  FF8NiA(self, VVE6xF=VVE6xF)
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFCnHd(self["myMenu"])
  FFoto4(self)
 def VVWw2Z(self):
  global VVsFSY
  VVsFSY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVQDXq"    : self.VVQDXq()
   elif item == "Restore_Channels"    : self.VV5524("channels_backup*.tar.gz", self.VVuD4v)
   elif item == "VVFvz9"   : self.VVFvz9()
   elif item == "Restore_SoftCAM_Files"  : self.VV5524("softcam_backup*.tar.gz", self.VVwFZp)
   elif item == "Backup_TunerDiSEqC"   : self.VV9kHj("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VV5524("tuner_backup*.backup", boundFunction(self.VVhXry, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VV9kHj("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VV5524("hotkey_*backup*.backup", boundFunction(self.VVhXry, "misc"))
   elif item == "VVkakf"    : self.VVkakf()
   elif item == "Restore_Network"    : self.VV5524("network_backup*.tar.gz", self.VVwYS3)
   elif item == "VVG98L"     : FFZhjP(self, boundFunction(FFy61j, self, boundFunction(CC2EQw.VVG98L, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVALQT(False)
   elif item == "createMyDeb"     : self.VVALQT(True)
   elif item == "createMyTar"     : self.VVN2Yd()
   elif item == "VViwVg"   : self.VViwVg()
 @staticmethod
 def VVG98L(SELF):
  OBF_Path = VVCTiY + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVCTiY, VV3jny, VVyMwU)
   if err : FFDQ9M(SELF, err)
   else : FFUojK(SELF, txt)
  else:
   FFC6jW(SELF, OBF_Path)
 def VVALQT(self, VVctLC):
  OBF_Path = VVCTiY + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFDQ9M(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVCTiY)
  os.system("mv -f %s %s" % (VVCTiY + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVCTiY + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVCTiY + "plugin.py"))
  self.session.openWithCallback(self.VVALQT1, boundFunction(CCiS47, path=VVCTiY, VVctLC=VVctLC))
 def VVALQT1(self):
  os.system("mv -f %s %s" % (VVCTiY + "OBF/main.py"  , VVCTiY))
  os.system("mv -f %s %s" % (VVCTiY + "OBF/plugin.py" , VVCTiY))
 def VViwVg(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFDQ9M(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFDQ9M(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVDeBb("%s*.list" % path)
  if err:
   FFC6jW(self, path + "*.list")
   return
  srcF, err = self.VVDeBb("%s*main_final.py" % path)
  if err:
   FFC6jW(self, path + "*.final.py")
   return
  VVU7lj = []
  for f in files:
   f = os.path.basename(f)
   VVU7lj.append((f, f))
  FFtUqp(self, boundFunction(self.VVhypB, path, codF, srcF), VVE6xF=VVU7lj)
 def VVhypB(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFC6jW(self, logF)
   else     : FFy61j(self, boundFunction(self.VVqXH0, logF, codF, srcF))
 def VVqXH0(self, logF, codF, srcF):
  lst  = []
  lines = FFel5Q(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFDQ9M(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVF4hL(lst, logF, newLogF)
  totSrc  = self.VVF4hL(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFUojK(self, txt)
 def VVDeBb(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVF4hL(self, lst, f1, f2):
  txt = FFbAeW(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVN2Yd(self):
  VVU7lj = []
  VVU7lj.append("%s%s" % (VVCTiY, "*.py"))
  VVU7lj.append("%s%s" % (VVCTiY, "*.png"))
  VVU7lj.append("%s%s" % (VVCTiY, "*.xml"))
  VVU7lj.append("%s"  % (VVMNbP))
  FFHkyo(self, VVU7lj, "%s_%s" % (PLUGIN_NAME, VV3jny), addTimeStamp=False)
 def VVQDXq(self):
  path1 = VVDNL1
  path2 = "/etc/tuxbox/"
  VVU7lj = []
  VVU7lj.append("%s%s" % (path1, "*.tv"))
  VVU7lj.append("%s%s" % (path1, "*.radio"))
  VVU7lj.append("%s%s" % (path1, "*list"))
  VVU7lj.append("%s%s" % (path1, "lamedb*"))
  VVU7lj.append("%s%s" % (path2, "*.xml"))
  FFHkyo(self, VVU7lj, "channels_backup", addTimeStamp=True)
 def VVFvz9(self):
  VVU7lj = []
  VVU7lj.append("/etc/tuxbox/config/")
  VVU7lj.append("/usr/keys/")
  VVU7lj.append("/usr/scam/")
  VVU7lj.append("/etc/CCcam.cfg")
  FFHkyo(self, VVU7lj, "softcam_backup", addTimeStamp=True)
 def VVkakf(self):
  VVU7lj = []
  VVU7lj.append("/etc/hostname")
  VVU7lj.append("/etc/default_gw")
  VVU7lj.append("/etc/resolv.conf")
  VVU7lj.append("/etc/wpa_supplicant*.conf")
  VVU7lj.append("/etc/network/interfaces")
  VVU7lj.append("/etc/enigma2/nameserversdns.conf")
  FFHkyo(self, VVU7lj, "network_backup", addTimeStamp=True)
 def VVuD4v(self, fileName=None):
  if fileName:
   FFZhjP(self, boundFunction(self.VV7vu8, fileName), "Overwrite current channels ?")
 def VV7vu8(self, fileName):
  path = "%s%s" % (VVXcuX, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCZkgq.VV6phL()
   lamedb5File, diabled5File = CCZkgq.VVp2vC()
   cmd = ""
   cmd += FFGA8O("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFGA8O("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFY6Ac()
   if res == 0 : FFrSV8(self, "Channels Restored.")
   else  : FFDQ9M(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFC6jW(self, path)
 def VVwFZp(self, fileName=None):
  if fileName:
   FFZhjP(self, boundFunction(self.VVPoDg, fileName), "Overwrite SoftCAM files ?")
 def VVPoDg(self, fileName):
  fileName = "%s%s" % (VVXcuX, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VV0fId
   note = "You may need to restart your SoftCAM."
   FFgEn3(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FF2CqO(note, VVuneX), sep))
  else:
   FFC6jW(self, fileName)
 def VVwYS3(self, fileName=None):
  if fileName:
   FFZhjP(self, boundFunction(self.VV5hG8, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VV5hG8(self, fileName):
  fileName = "%s%s" % (VVXcuX, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFR9ZE(self,  cmd)
  else:
   FFC6jW(self, fileName)
 def VV5524(self, pattern, callBackFunction, isTuner=False):
  title = FFR16z()
  if pathExists(VVXcuX):
   myFiles = iGlob("%s%s" % (VVXcuX, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVU7lj = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVU7lj.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVf3L2 = ("Sat. List", self.VVspLx)
    else  : VVf3L2 = None
    VVJsRJ = ("Delete File", self.VVuICx)
    FFtUqp(self, callBackFunction, title=title, VVE6xF=VVU7lj, VVf3L2=VVf3L2, VVJsRJ=VVJsRJ)
   else:
    FFDQ9M(self, "No files found in:\n\n%s" % VVXcuX, title)
  else:
   FFDQ9M(self, "Path not found:\n\n%s" % VVXcuX, title)
 def VVuICx(self, VVtbO0Obj, path):
  FFZhjP(self, boundFunction(self.VVLJ91, VVtbO0Obj, path), "Delete this file ?\n\n%s" % path)
 def VVLJ91(self, VVtbO0Obj, path):
  path = VVXcuX + path
  os.system(FFGA8O("rm -f '%s'" % path))
  if fileExists(path) : FF7QSu(VVtbO0Obj, "Not deleted", 1000)
  else    : VVtbO0Obj.VVIekM()
 def VV9kHj(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCT3NF()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VVa7rX, filePrefix))
 def VVa7rX(self, filePrefix, result, retval):
  title = FFR16z()
  if pathExists(VVXcuX):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFDQ9M(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVXcuX, filePrefix, FFmDuf())
    try:
     VVU7lj = str(result.strip()).split()
     if VVU7lj:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVU7lj:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VV0fId, FFcK2v(fName, VVuneX), VV0fId)
       FFUojK(self, txt, title=title, VVvy8W=VV39v7)
      else:
       FFDQ9M(self, "File creation failed!", title)
     else:
      FFDQ9M(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFGA8O("rm %s" % fName))
     FFDQ9M(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFGA8O("rm %s" % fName))
     FFDQ9M(self, "Error while writing file.")
  else:
   FFDQ9M(self, "Path not found:\n\n%s" % VVXcuX, title)
 def VVhXry(self, mode, path=None):
  if path:
   path = "%s%s" % (VVXcuX, path)
   if fileExists(path):
    lines = FFel5Q(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFZhjP(self, boundFunction(self.VV4q59, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFojte(self, path, title=FFR16z())
   else:
    FFC6jW(self, path)
 def VV4q59(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VV6guL = []
  VV6guL.append("echo -e 'Reading current settings ...'")
  VV6guL.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VV6guL.append("echo -e 'Preparing new settings ...'")
  VV6guL.append(settingsLines)
  VV6guL.append("echo -e 'Applying new settings ...'")
  VV6guL.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFfdoD(self, VV6guL)
 def VVspLx(self, VVtbO0Obj, path):
  if not path:
   return
  path = VVXcuX + path
  if not fileExists(path):
   FFC6jW(self, path)
   return
  txt = FFbAeW(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVU7lj  = []
   for item in satList:
    VVU7lj.append("%s\t%s" % (item[0], FF06Jn(item[1])))
   FFUojK(self, VVU7lj, title="  Satellites List")
  else:
   FFDQ9M(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCmvxM(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFoyhf(VVQLSY, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVE6xF = []
  VVE6xF.append(("Plugins Browser List"       , "VVcHX0"   ))
  VVE6xF.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVE6xF.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVE6xF.append(("Remove Packages (show all)"     , "VVQJVIsAll"   ))
  VVE6xF.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Update List of Available Packages"   , "VVmEuw"   ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Packaging Tool"        , "VVgcA9"    ))
  VVE6xF.append(("Packages Feeds"        , "packagesFeeds"    ))
  FF8NiA(self, VVE6xF=VVE6xF)
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFCnHd(self["myMenu"])
  FFoto4(self)
 def VVWw2Z(self):
  global VVsFSY
  VVsFSY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVcHX0"   : self.VVcHX0()
   elif item == "pluginsMenus"     : self.VVAf0p(0)
   elif item == "pluginsStartup"    : self.VVAf0p(1)
   elif item == "pluginsDirList"    : self.VV7sFM()
   elif item == "downloadInstallPackages"  : FFy61j(self, boundFunction(self.VV0SGG, 0, ""))
   elif item == "VVQJVIsAll"   : FFy61j(self, boundFunction(self.VV0SGG, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFy61j(self, boundFunction(self.VV0SGG, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVmEuw"   : self.VVmEuw()
   elif item == "VVgcA9"    : self.VVgcA9()
   elif item == "packagesFeeds"    : self.VVo696()
   else          : self.close()
 def VV7sFM(self):
  extDirs  = FFE8QH(VVkJbg)
  sysDirs  = FFE8QH(VVYeIO)
  VVU7lj  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVU7lj.append((item, VVkJbg + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVU7lj.append((item, VVYeIO + item))
  if VVU7lj:
   VVU7lj = sorted(VVU7lj, key=lambda x: x[0].lower())
   VVZ5MP = ("Package Info.", self.VVmC2M, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFIbZw(self, None, header=header, VVU7lj=VVU7lj, VVSkoS=widths, VVhkQh=28, VVZ5MP=VVZ5MP)
  else:
   FFDQ9M(self, "Nothing found!")
 def VVmC2M(self, VVoKzZ, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVkJbg) : loc = "extensions"
  elif path.startswith(VVYeIO) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVnRgQ(package)
  else:
   FFDQ9M(self, "No info!")
 def VVo696(self):
  pkg = FFSfMS()
  if pkg : FFAiEX(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFVSFz(self)
 def VVcHX0(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVUkWF(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VV0fId + "\n"
    txt += VVUkWF("Number"   , str(c))
    txt += VVUkWF("Name"   , FFcK2v(str(p.name), VVuneX))
    txt += VVUkWF("Path"  , p.path  )
    txt += VVUkWF("Description" , p.description )
    txt += VVUkWF("Icon"  , p.iconstr  )
    txt += VVUkWF("Wakeup Fnc" , p.wakeupfnc )
    txt += VVUkWF("NeedsRestart", p.needsRestart)
    txt += VVUkWF("Internal" , p.internal )
    txt += VVUkWF("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFUojK(self, txt)
 def VVAf0p(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVU7lj = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVU7lj.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVU7lj:
   VVU7lj.sort(key=lambda x: x[0].lower())
   header  = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths  = (19  , 25 , 20  , 27   , 9  )
   FFIbZw(self, None, title=title, header=header, VVU7lj=VVU7lj, VVSkoS=widths, VVhkQh=26)
  else:
   FFDQ9M(self, "Nothing Found", title=title)
 def VVmEuw(self):
  cmd = FFomnU(VVtlAg, "")
  if cmd : FFR9ZE(self, cmd, checkNetAccess=True)
  else : FFVSFz(self)
 def VVgcA9(self):
  pkg = FFSfMS()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFrSV8(self, txt)
 def VV0SGG(self, mode, grep, VVoKzZ=None, title=""):
  if   mode == 0: cmd = FFomnU(VV9zyt    , grep)
  elif mode == 1: cmd = FFomnU(VVoGNt , grep)
  elif mode == 2: cmd = FFomnU(VVoGNt , grep)
  if not cmd:
   FFVSFz(self)
   return
  VV7OA3 = FFDp6V(cmd)
  if not VV7OA3:
   if VVoKzZ: VVoKzZ.VVItnB()
   FFDQ9M(self, "No packages found!")
   return
  elif len(VV7OA3) == 1 and VV7OA3[0] == VVqB9V:
   FFDQ9M(self, VVqB9V)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVU7lj  = []
  for item in VV7OA3:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVU7lj.append((name, package, version))
  if mode > 0:
   extensions = FFDp6V("ls %s -l | grep '^d' | awk '{print $9}'" % VVkJbg)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVU7lj:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVU7lj.append((name, VVkJbg + item, "-"))
   systemPlugins = FFDp6V("ls %s -l | grep '^d' | awk '{print $9}'" % VVYeIO)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVU7lj:
      if item.lower() == row[0].lower():
       break
     else:
      VVU7lj.append((item, VVYeIO + item, "-"))
  if not VVU7lj:
   FFDQ9M(self, "No packages found!")
   return
  if VVoKzZ:
   VVU7lj.sort(key=lambda x: x[0].lower())
   VVoKzZ.VVZlxC(VVU7lj, title)
  else:
   widths = (20, 50, 30)
   VVJlME = None
   VV2x0g = None
   if mode == 0:
    VVjx9F = ("Install" , self.VVTpAx   , [])
    VVJlME = ("Download" , self.VVEZYs   , [])
    VV2x0g = ("Filter"  , self.VVKmt5 , [])
   elif mode == 1:
    VVjx9F = ("Uninstall", self.VVQJVI, [])
   elif mode == 2:
    VVjx9F = ("Uninstall", self.VVQJVI, [])
    widths= (18, 57, 25)
   VVU7lj = sorted(VVU7lj, key=lambda x: x[0].lower())
   VVZ5MP = ("Package Info.", self.VVO8QX, [])
   header   = ("Name" ,"Package" , "Version" )
   FFIbZw(self, None, header=header, VVU7lj=VVU7lj, VVSkoS=widths, VVhkQh=28, VVjx9F=VVjx9F, VVJlME=VVJlME, VVZ5MP=VVZ5MP, VV2x0g=VV2x0g, VVNMPm=self.lastSelectedRow
     , VV6Us0="#22110011", VVezBA="#22191111", VVDUXJ="#22191111", VVTpzJ="#00003030", VVvufb="#00333333")
 def VVO8QX(self, VVoKzZ, title, txt, colList):
  package = colList[1]
  self.VVnRgQ(package)
 def VVKmt5(self, VVoKzZ, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVE6xF = []
  VVE6xF.append(("All Packages", "all"))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVE6xF.append(VVBgIm)
  for word in words:
   VVE6xF.append((word, word))
  FFtUqp(self, boundFunction(self.VVpIQ8, VVoKzZ), VVE6xF=VVE6xF, title="Select Filter")
 def VVpIQ8(self, VVoKzZ, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFy61j(VVoKzZ, boundFunction(self.VV0SGG, 0, grep, VVoKzZ, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVQJVI(self, VVoKzZ, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVkJbg, VVYeIO)):
   FFZhjP(self, boundFunction(self.VV9N4Y, VVoKzZ, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVE6xF = []
   VVE6xF.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVE6xF.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVE6xF.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFtUqp(self, boundFunction(self.VVYrUD, VVoKzZ, package), VVE6xF=VVE6xF)
 def VV9N4Y(self, VVoKzZ, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVGWSe)
  FFR9ZE(self, cmd, VV6fyE=boundFunction(self.VVxqkr, VVoKzZ))
 def VVYrUD(self, VVoKzZ, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VV9JbV
   elif item == "remove_ForceRemove"  : cmdOpt = VVodMr
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVPul6
   FFZhjP(self, boundFunction(self.VVa39m, VVoKzZ, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVa39m(self, VVoKzZ, package, cmdOpt):
  self.lastSelectedRow = VVoKzZ.VVjUL9()
  cmd = FFH2eT(cmdOpt, package)
  if cmd : FFR9ZE(self, cmd, VV6fyE=boundFunction(self.VVxqkr, VVoKzZ))
  else : FFVSFz(self)
 def VVxqkr(self, VVoKzZ):
  VVoKzZ.cancel()
  FFQnRo()
 def VVTpAx(self, VVoKzZ, title, txt, colList):
  package  = colList[1]
  VVE6xF = []
  VVE6xF.append(("Install Package"         , "install_CheckVersion" ))
  VVE6xF.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVE6xF.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VVE6xF.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVE6xF.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFtUqp(self, boundFunction(self.VVyHsZ, package), VVE6xF=VVE6xF)
 def VVyHsZ(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVOR4D
   elif item == "install_ForceReinstall" : cmdOpt = VVPoce
   elif item == "install_ForceOverwrite" : cmdOpt = VV6Sp7
   elif item == "install_ForceDowngrade" : cmdOpt = VVnwcJ
   elif item == "install_IgnoreDepends" : cmdOpt = VVbCwc
   FFZhjP(self, boundFunction(self.VVF1bq, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVF1bq(self, package, cmdOpt):
  cmd = FFH2eT(cmdOpt, package)
  if cmd : FFR9ZE(self, cmd, VV6fyE=FFQnRo, checkNetAccess=True)
  else : FFVSFz(self)
 def VVEZYs(self, VVoKzZ, title, txt, colList):
  package  = colList[1]
  FFZhjP(self, boundFunction(self.VV7SPM, package), "Download Package ?\n\n%s" % package)
 def VV7SPM(self, package):
  if FFvkoy():
   cmd = FFH2eT(VVa6wk, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FF2CqO(success, VVcGUH))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FF2CqO(fail, VVovWl))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFR9ZE(self, cmd, VV4FBV=[VVovWl, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFVSFz(self)
  else:
   FFDQ9M(self, "No internet connection !")
 def VVnRgQ(self, package):
  infoCmd  = FFH2eT(VVeYXl, package)
  filesCmd = FFH2eT(VVP3o8, package)
  listInstCmd = FFomnU(VVoGNt, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFNiKT(VVuneX)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FF2CqO(notInst, VVII83))
   cmd += "else "
   cmd +=   FFIQaW("System Info", VVuneX)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFIQaW("Related Files", VVuneX)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FF5cnY(self, cmd)
  else:
   FFVSFz(self)
class CCZkgq(Screen):
 VVvE1g  = 0
 VVSx3B = 1
 VVGokD  = 2
 VV8iNb  = 3
 VV2MPi = 4
 VV7uJa = 5
 VVMK3m = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFoyhf(VVQLSY, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVk8O0 = None
  self.lastfilterUsed  = None
  VVE6xF = self.VVw3he()
  FF8NiA(self, VVE6xF=VVE6xF, title="Services/Channels")
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self["myMenu"].setList(self.VVw3he())
  FFCnHd(self["myMenu"])
  FFoto4(self)
 def VVw3he(self):
  VVE6xF = []
  VVE6xF.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VVE6xF.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Services (Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVE6xF.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVE6xF.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVE6xF.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVE6xF.append(("Services with PIcons for the System"  , "VVnSBJ"     ))
  VVE6xF.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVE6xF.append(VVBgIm)
  lamedbFile, disabledFile = CCZkgq.VV6phL()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVE6xF.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVE6xF.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVE6xF.append(("Reset Parental Control Settings"   , "VV5HL3"    ))
  VVE6xF.append(("Delete Channels with no names"   , "VVjkfv"    ))
  VVE6xF.append(('Export Services to "channels.xml"'  , "VVTxPe"      ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Reload Channels and Bouquets"    , "VVIcmK"      ))
  return VVE6xF
 def VVWw2Z(self):
  global VVsFSY
  VVsFSY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFHiYE(self)
   elif item == "currentServiceInfo"     : FFvad7(self, fncMode=CCzqpW.VVlhwR)
   elif item == "TranspondersStats"     : FFy61j(self, self.VVWgBO     )
   elif item == "lameDB_allChannels_with_refCode"  : FFy61j(self, self.VVa98P )
   elif item == "lameDB_allChannels_with_tranaponder" : FFy61j(self, self.VVdxNi)
   elif item == "lameDB_allChannels_with_details"  : FFy61j(self, self.VVlGCp )
   elif item == "parentalControlChannels"    : FFy61j(self, self.VV8Aqv   )
   elif item == "showHiddenChannels"     : FFy61j(self, self.VV3M2U     )
   elif item == "VVnSBJ"     : FFy61j(self, self.VV4lx6     )
   elif item == "servicesWithMissingPIcons"   : FFy61j(self, self.VVhmTv   )
   elif item == "enableHiddenChannels"     : self.VVA0IZ(True)
   elif item == "disableHiddenChannels"    : self.VVA0IZ(False)
   elif item == "VV5HL3"    : FFZhjP(self, self.VV5HL3, "Reset and Restart ?" )
   elif item == "VVjkfv"    : FFy61j(self, self.VVjkfv)
   elif item == "VVTxPe"      : self.VVTxPe()
   elif item == "VVIcmK"      : FFy61j(self, boundFunction(CCZkgq.VVIcmK, self))
   else            : self.close()
 def VVTxPe(self):
  VVE6xF = []
  VVE6xF.append(("All Sat/C/T Services", "all"))
  VVE6xF.append(("--[ BOUQUETS ]" + "-" * 100, ))
  bouquets = FFEhoo()
  if bouquets:
   for item in bouquets:
    VVE6xF.append((item[0], item[1].toString()))
  FFtUqp(self, self.VVAOa1, VVE6xF=VVE6xF, title="", VVETIV=True)
 def VVAOa1(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCZkgq.VVgkHK("1:7:")
   else   : lst = FFnpqA(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     fPath = "%schannels_%s.xml" % (FFSNlf(CFG.exportedTablesPath.getValue()), FFmDuf())
     with open(fPath, "w") as f:
      f.write('<?xml version="1.0" encoding="utf-8"?>\n')
      f.write('<channels>\n\n')
      for r, n in lst:
       sat = "?"
       serv = eServiceReference(r)
       if serv:
        chPath = serv.getPath()
        if not chPath    : sat = FFGGpm(r, False)
        elif chPath.startswith("/") : sat = "Local"
        elif FFMLue(r)    : sat = "IPTV"
       f.write('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
      f.write('\n</channels>\n')
     FFrSV8(self, "Saved %d services to:\n\n%s" % (tot, fPath))
     return
   FF7QSu(self, "No Services found !", 1500)
 @staticmethod
 def VVIcmK(SELF):
  FFY6Ac()
  FFrSV8(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVa98P(self):
  self.VVk8O0 = None
  self.lastfilterUsed  = None
  self.filterObj   = CC2Xqg(self)
  VV7OA3 = CCZkgq.VVDUdr(self, self.VVvE1g)
  if VV7OA3:
   VV7OA3.sort(key=lambda x: x[0].lower())
   VV2mqV  = ("Zap"   , self.VVwH8p     , [])
   VVmEVe = (""    , self.VVwMkK   , [])
   VVZ5MP = ("Options"  , self.VVp518 , [])
   VVJlME = ("Current Service", self.VVMhfz , [])
   VV2x0g = ("Filter"   , self.VV06uK  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VV9ki4  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFIbZw(self, None, header=header, VVU7lj=VV7OA3, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=26, VV2mqV=VV2mqV, VVmEVe=VVmEVe, VVJlME=VVJlME, VVZ5MP=VVZ5MP, VV2x0g=VV2x0g)
 def VVdxNi(self):
  self.VVk8O0 = None
  self.lastfilterUsed  = None
  self.filterObj   = CC2Xqg(self)
  VV7OA3 = CCZkgq.VVDUdr(self, self.VVSx3B)
  if VV7OA3:
   VV7OA3.sort(key=lambda x: x[0].lower())
   VV2mqV  = ("Zap"   , self.VVwH8p      , [])
   VVmEVe = (""    , self.VVwMkK    , [])
   VVJlME = ("Current Service", self.VVMhfz  , [])
   VVZ5MP = ("Options"  , self.VVPRLG , [])
   VV2x0g = ("Filter"   , self.VVVYTO  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VV9ki4  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFIbZw(self, None, header=header, VVU7lj=VV7OA3, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=26, VV2mqV=VV2mqV, VVmEVe=VVmEVe, VVJlME=VVJlME, VVZ5MP=VVZ5MP, VV2x0g=VV2x0g)
 def VVp518(self, VVoKzZ, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel  = CCFJmT(self, VVoKzZ, 3)
  mSel.VVJV6C(servName, refCode, pcState, hidState)
 def VVPRLG(self, VVoKzZ, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CCFJmT(self, VVoKzZ, 3)
  mSel.VVsxzH(servName, refCode)
 def VVoKCe(self, VVoKzZ, refCode, isAddToBlackList):
  VVoKzZ.VVCv3A("Processing ...")
  FFt2dO(boundFunction(self.VVE1uy, VVoKzZ, [refCode], isAddToBlackList))
 def VVthBi(self, VVoKzZ, isAddToBlackList):
  refCodeList = VVoKzZ.VVW3Zw(3)
  if not refCodeList:
   FFDQ9M(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVoKzZ.VVCv3A("Processing ...")
  FFt2dO(boundFunction(self.VVE1uy, VVoKzZ, refCodeList, isAddToBlackList))
 def VVE1uy(self, VVoKzZ, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VV0MNj, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VV0MNj):
   lines = FFel5Q(VV0MNj)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VV0MNj, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVoKzZ.VVf82F
   if isMulti:
    self.VVjWXj(VVoKzZ, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVYx1h(VVoKzZ, refCode)
    VVoKzZ.VVItnB()
  else:
   VVoKzZ.VV3MOD("No changes")
 def VVO6Nt(self, VVoKzZ, refCode, isHide):
  title = "Change Hidden State"
  if FFggFM(refCode):
   VVoKzZ.VVCv3A("Processing ...")
   ret = FF5nBZ(refCode, isHide)
   if ret : FFy61j(self, boundFunction(self.VVYx1h, VVoKzZ, refCode))
   else : FFDQ9M(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFDQ9M(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVYx1h(self, VVoKzZ, refCode):
  VV7OA3 = CCZkgq.VVDUdr(self, self.VVvE1g, VVpYMF=[3, [refCode], False])
  done = False
  if VV7OA3:
   data = VV7OA3[0]
   if data[3] == refCode:
    done = VVoKzZ.VVMRjs(data)
  if not done:
   self.VVAuE1(VVoKzZ, VVoKzZ.VVwDp0(), self.VVvE1g)
  VVoKzZ.VVItnB()
 def VVjWXj(self, VVoKzZ, totRefCodes):
  VV7OA3 = CCZkgq.VVDUdr(self, self.VVvE1g, VVpYMF=self.VVk8O0)
  VVoKzZ.VVZlxC(VV7OA3)
  VVoKzZ.VVFiCZ(False)
  VVoKzZ.VV3MOD("%d Processed" % totRefCodes)
 def VVNMcd(self, VVoKzZ, isHide):
  refCodeList = VVoKzZ.VVW3Zw(3)
  if not refCodeList:
   FFDQ9M(self, "Nothing selected", title="Change Hidden State")
   return
  VVoKzZ.VVCv3A("Processing ...")
  FFt2dO(boundFunction(self.VVuosl, VVoKzZ, refCodeList, isHide))
 def VVuosl(self, VVoKzZ, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FF5nBZ(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   db = eDVBDB.getInstance()
   if db:
    db.saveServicelist()
    db.reloadServicelist()
    db.reloadBouquets()
   self.VVjWXj(VVoKzZ, len(refCodeList))
  else:
   VVoKzZ.VV3MOD("No changes")
 def VV06uK(self, VVoKzZ, title, txt, colList):
  self.filterObj.VVSd87(1, VVoKzZ, 2, boundFunction(self.VVdajf, VVoKzZ))
 def VVdajf(self, VVoKzZ, item):
  self.VVuQpp(VVoKzZ, item, 2, self.VVvE1g)
 def VVVYTO(self, VVoKzZ, title, txt, colList):
  self.filterObj.VVSd87(2, VVoKzZ, 4, boundFunction(self.VVR3yH, VVoKzZ))
 def VVR3yH(self, VVoKzZ, item):
  self.VVuQpp(VVoKzZ, item, 4, self.VVSx3B)
 def VVEJjm(self, VVoKzZ, title, txt, colList):
  self.filterObj.VVSd87(0, VVoKzZ, 4, boundFunction(self.VVDKQR, VVoKzZ))
 def VVDKQR(self, VVoKzZ, item):
  self.VVuQpp(VVoKzZ, item, 4, self.VVGokD)
 def VVuQpp(self, VVoKzZ, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVoKzZ.VVai60(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVk8O0 = None
  else:
   words, asPrefix = CC2Xqg.VVHOBM(words)
   self.VVk8O0 = [col, words, asPrefix]
  if words: FFy61j(self, boundFunction(self.VVAuE1, VVoKzZ, title, mode), title="Reading Services ...")
  else : FF7QSu(VVoKzZ, "Incorrect filter", 2000)
 def VVAuE1(self, VVoKzZ, title, mode):
  VV7OA3 = CCZkgq.VVDUdr(self, mode, VVpYMF=self.VVk8O0, VVivON=False)
  if VV7OA3:
   VV7OA3.sort(key=lambda x: x[0].lower())
   VVoKzZ.VVZlxC(VV7OA3, title)
  else:
   VVoKzZ.VVItnB()
   FF7QSu(VVoKzZ, "Not found!", 1500)
 def VVfH1U(self, VVU7lj, VV2mqV=None, VVmEVe=None, VVjx9F=None, VVJlME=None, VVZ5MP=None, VV2x0g=None):
  VVJlME = ("Current Service", self.VVMhfz, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VV9ki4 = (LEFT  , LEFT  , CENTER, LEFT    )
  FFIbZw(self, None, header=header, VVU7lj=VVU7lj, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=26, VV2mqV=VV2mqV, VVmEVe=VVmEVe, VVjx9F=VVjx9F, VVJlME=VVJlME, VVZ5MP=VVZ5MP, VV2x0g=VV2x0g)
 def VVMhfz(self, VVoKzZ, title, txt, colList):
  self.VVDwgV(VVoKzZ)
 def VVqsjt(self, VVoKzZ, title, txt, colList):
  self.VVDwgV(VVoKzZ, True)
 def VVDwgV(self, VVoKzZ, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVoKzZ.VVQRIY(colDict, VVS6In=True)
   else:
    VVoKzZ.VVayhx(3, refCode, True)
   return
  FFDQ9M(self, "Colud not read current Reference Code !")
 def VVlGCp(self):
  self.VVk8O0 = None
  self.lastfilterUsed  = None
  self.filterObj   = CC2Xqg(self)
  VV7OA3 = CCZkgq.VVDUdr(self, self.VVGokD)
  if VV7OA3:
   VV7OA3.sort(key=lambda x: x[0].lower())
   VVmEVe = (""    , self.VVQAsA , []      )
   VVJlME = ("Current Service", self.VVqsjt  , []      )
   VV2x0g = ("Filter"   , self.VVEJjm   , [], "Loading Filters ..." )
   VV2mqV  = ("Zap"   , self.VVmLgP      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VV9ki4  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFIbZw(self, None, header=header, VVU7lj=VV7OA3, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=26, VV2mqV=VV2mqV, VVmEVe=VVmEVe, VVJlME=VVJlME, VV2x0g=VV2x0g)
 def VVQAsA(self, VVoKzZ, title, txt, colList):
  refCode  = self.VVJb1r(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFvad7(self, fncMode=CCzqpW.VV4Yp0, refCode=refCode, chName=chName, text=txt)
 def VVmLgP(self, VVoKzZ, title, txt, colList):
  refCode = self.VVJb1r(colList)
  FFI7Gq(self, refCode)
 def VVwH8p(self, VVoKzZ, title, txt, colList):
  FFI7Gq(self, colList[3])
 def VVJb1r(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVDUdr(SELF, mode, VVpYMF=None, VVivON=True, VVaPZO=True):
  lamedbFile, disabledFile = CCZkgq.VV6phL()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVpYMF:
    filterCol = VVpYMF[0]
    filterWords = VVpYMF[1]
    asPrefix = VVpYMF[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCZkgq.VVvE1g:
    blackList = None
    if fileExists(VV0MNj):
     blackList = FFel5Q(VV0MNj)
     if blackList:
      blackList = set(blackList)
   elif mode == CCZkgq.VVSx3B:
    tp = CCKps4()
   VVomQx, VVSuGF = FFPELm()
   tagFound  = False
   if mode in (CCZkgq.VV7uJa, CCZkgq.VVMK3m):
    VV7OA3 = {}
   else:
    VV7OA3 = []
   with ioOpen(lamedbFile, "r", encoding="utf-8") as f:
    lines = []
    for line in f:
     line = str(line).strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFEPU0(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CCZkgq.VVGokD:
        if sTypeInt in VVomQx:
         STYPE = VVSuGF[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VV7OA3.append(tRow)
         elif any(x in tmp for x in filterWords)    : VV7OA3.append(tRow)
        else:
         VV7OA3.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCZkgq.VV7uJa:
         VV7OA3[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCZkgq.VVMK3m:
         VV7OA3[chName] = refCode
        elif mode == CCZkgq.VVvE1g:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VV7OA3.append(tRow)
          elif any(x in tmp for x in filterWords)    : VV7OA3.append(tRow)
         else:
          VV7OA3.append(tRow)
        elif mode == CCZkgq.VVSx3B:
         if sTypeInt in VVomQx:
          STYPE = VVSuGF[sTypeInt]
         freq, pol, fec, sr, syst = tp.VVHuCR(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VV7OA3.append(tRow)
          elif any(x in tmp for x in filterWords)    : VV7OA3.append(tRow)
         else:
          VV7OA3.append(tRow)
        elif mode == CCZkgq.VV8iNb:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VV7OA3.append((chName, chProv, sat, refCode))
        elif mode == CCZkgq.VV2MPi:
         VV7OA3.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VV7OA3 and VVivON:
    FFDQ9M(SELF, "No services found!")
   return VV7OA3
  else:
   if VVaPZO:
    FFC6jW(SELF, lamedbFile)
   return None
 def VV8Aqv(self):
  if fileExists(VV0MNj):
   lines = FFel5Q(VV0MNj)
   if lines:
    newRows  = []
    VV7OA3 = CCZkgq.VVDUdr(self, self.VV2MPi)
    if VV7OA3:
     lines = set(lines)
     for item in VV7OA3:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VV7OA3 = newRows
      VV7OA3.sort(key=lambda x: x[0].lower())
      VVmEVe = ("", self.VVwMkK, [])
      VV2mqV = ("Zap", self.VVwH8p, [])
      self.VVfH1U(VVU7lj=VV7OA3, VV2mqV=VV2mqV, VVmEVe=VVmEVe)
     else:
      FFUojK(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VV7OA3)))
   else:
    FFrSV8(self, "No active Parental Control services.", FFR16z())
  else:
   FFC6jW(self, VV0MNj)
 def VV3M2U(self):
  VV7OA3 = CCZkgq.VVDUdr(self, self.VV8iNb)
  if VV7OA3:
   VV7OA3.sort(key=lambda x: x[0].lower())
   VVmEVe = ("" , self.VVwMkK, [])
   VV2mqV  = ("Zap", self.VVwH8p, [])
   self.VVfH1U(VVU7lj=VV7OA3, VV2mqV=VV2mqV, VVmEVe=VVmEVe)
  else:
   FFrSV8(self, "No hidden services.", FFR16z())
 def VVWgBO(self):
  totT, totC, totA, totS, totS2, satList = self.VVFiIp()
  txt = FFcK2v("Total Transponders:\n\n", VV0ckb)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFcK2v("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VV0ckb)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFWxL8(item), satList.count(item))
  FFUojK(self, txt)
 def VVFiIp(self):
  lamedbFile, disabledFile = CCZkgq.VV6phL()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with ioOpen(lamedbFile, "r", encoding="utf-8") as f:
    lines = []
    for line in f:
     line = str(line).strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFC6jW(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VV4lx6(self)   : self.VVnSBJ(True)
 def VVhmTv(self) : self.VVnSBJ(False)
 def VVnSBJ(self, isWithPIcons):
  piconsPath = CC5NMK.VVBX3T()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CC5NMK.VVj5cd(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VV7OA3 = CCZkgq.VVDUdr(self, self.VV2MPi)
    if VV7OA3:
     channels = []
     for (chName, chProv, sat, refCode) in VV7OA3:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFS8i0(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VV7OA3)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVUkWF(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVUkWF("PIcons Path"  , piconsPath)
     txt += VVUkWF("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVUkWF("Total services" , totalServices)
     txt += VVUkWF("With PIcons"  , totalWithPIcons)
     txt += VVUkWF("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFUojK(self, txt)
     else:
      VVmEVe     = (""      , self.VVwMkK , [])
      if isWithPIcons : VV2x0g = ("Export Current PIcon", self.VVIXF5  , [])
      else   : VV2x0g = None
      VVZ5MP     = ("Statistics", FFUojK, [txt])
      VV2mqV      = ("Zap", self.VVwH8p, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVfH1U(VVU7lj=channels, VV2mqV=VV2mqV, VVmEVe=VVmEVe, VVZ5MP=VVZ5MP, VV2x0g=VV2x0g)
   else:
    FFDQ9M(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFDQ9M(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVwMkK(self, VVoKzZ, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFvad7(self, fncMode=CCzqpW.VV4Yp0, refCode=refCode, chName=chName, text=txt)
 def VVIXF5(self, VVoKzZ, title, txt, colList):
  png, path = CC5NMK.VVJiax(colList[3], colList[0])
  if path:
   CC5NMK.VV5G6i(self, png, path)
 @staticmethod
 def VV6phL():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVp2vC():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVA0IZ(self, isEnable):
  lamedbFile, disabledFile = CCZkgq.VV6phL()
  if isEnable and not fileExists(disabledFile):
   FFrSV8(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FFDQ9M(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFZhjP(self, boundFunction(self.VV4bIj, isEnable), "%s Hidden Channels ?" % word)
 def VV4bIj(self, isEnable):
  lamedbFile , disabledFile = CCZkgq.VV6phL()
  lamedb5File, diabled5File = CCZkgq.VVp2vC()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FFY6Ac()
  if res == 0 : FFrSV8(self, "Hidden List %s" % word)
  else  : FFDQ9M(self, "Error while restoring:\n\n%s" % fileName)
 def VV5HL3(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFfdoD(self, cmd)
 def VVjkfv(self):
  lamedbFile, disabledFile = CCZkgq.VV6phL()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFGA8O("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFel5Q(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFGA8O("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FFY6Ac()
   FFUojK(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFC6jW(self, lamedbFile)
 @staticmethod
 def VVgkHK(servTypes):
  VVUKzq  = eServiceCenter.getInstance()
  VVNzuI   = '%s ORDER BY name' % servTypes
  VVviI9   = eServiceReference(VVNzuI)
  VVSE8K = VVUKzq.list(VVviI9)
  if VVSE8K: return VVSE8K.getContent("CN", False)
  else     : return []
class CCzqpW(Screen):
 VVlhwR  = 0
 VVC9sP   = 1
 VVfwde   = 2
 VV4Yp0    = 3
 VVYF8W    = 4
 VVUVhT   = 5
 VVkolS   = 6
 VV56bA    = 7
 VVmJif   = 8
 VVK2JV   = 9
 VVxNb6   = 10
 VVS21f   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFoyhf(VV4NSz, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVlhwR)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFcK2v("%s\n", VVx60q) % VV0fId
  self.picViewer  = None
  FF8NiA(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVmz6Q })
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVbxfr)
  self.onClose.append(self.onExit)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  self["myLabel"].VVfh1g(textOutFile="chann_info")
  if   self.fncMode == self.VVlhwR : fnc = self.VV9hLh_VVlhwR
  elif self.fncMode == self.VVC9sP  : fnc = self.VV9hLh_VVlhwR
  elif self.fncMode == self.VVfwde  : fnc = self.VV9hLh_VVlhwR
  elif self.fncMode == self.VV4Yp0  : fnc = self.VV9hLh_VV4Yp0
  elif self.fncMode == self.VVYF8W  : fnc = self.VV9hLh_VVYF8W
  elif self.fncMode == self.VVUVhT  : fnc = self.VV9hLh_VVUVhT
  elif self.fncMode == self.VVkolS  : fnc = self.VV9hLh_VVkolS
  elif self.fncMode == self.VV56bA  : fnc = self.VV9hLh_VV56bA
  elif self.fncMode == self.VVmJif  : fnc = self.VV9hLh_VVmJif
  elif self.fncMode == self.VVK2JV : fnc = self.VV9hLh_VVK2JV
  elif self.fncMode == self.VVxNb6  : fnc = self.VV9hLh_VVxNb6
  elif self.fncMode == self.VVS21f : fnc = self.VV9hLh_VVS21f
  self["myLabel"].setText("\n   Reading Info ...")
  FFt2dO(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVn9JE()
 def VVAV00(self, err):
  self["myLabel"].setText(err)
  FFH6QJ(self["myTitle"], "#22200000")
  FFH6QJ(self["myBody"], "#22200000")
  self["myLabel"].FFH6QJColor("#22200000")
  self["myLabel"].VVnF2W()
 def VV9hLh_VVlhwR(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self)
  self.refCode = refCode
  self.VVZIHa(chName)
 def VV9hLh_VV4Yp0(self):
  self.VVZIHa(self.chName)
 def VV9hLh_VVYF8W(self):
  self.VVZIHa(self.chName)
 def VV9hLh_VVUVhT(self):
  self.VVZIHa(self.chName)
 def VV9hLh_VVkolS(self):
  self.VVZIHa("Picon Info")
 def VV9hLh_VV56bA(self):
  self.VVZIHa(self.chName)
 def VV9hLh_VVmJif(self):
  self.VVZIHa(self.chName)
 def VV9hLh_VVK2JV(self):
  self.VVZIHa(self.chName)
 def VV9hLh_VVxNb6(self):
  self.chUrl = self.refCode + self.callingSELF.VVrXxA(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVZIHa(self.chName)
 def VV9hLh_VVS21f(self):
  self.VVZIHa(self.chName)
 def VVZIHa(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFEN32(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVs31X(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFcK2v(self.VVULCZ(tUrl), VVXOiG)
  if not self.epg:
   epg = self.VVgolg(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VV4UQ6(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CC5NMK.VVJiax(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VV4UQ6(path)
  self.VV1HOs()
  self.VVQU29()
  self["myLabel"].setText(self.text, VVvy8W=VV9a7T)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVnF2W(minHeight=minH)
 def VVQU29(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFMLue(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVDHWk(FFugDB(url))
  if epg:
   self.text += "\n" + FFtcsN("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VV1HOs()
 def VV1HOs(self):
  if not self.piconShown and self.picUrl:
   path, err = FFZ5gR(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VV4UQ6(path)
    if self.piconShown and self.refCode:
     self.VVi0rm(path, self.refCode)
 def VVi0rm(self, path, refCode):
  if path and fileExists(path) and os.system(FFGA8O("which ffmpeg")) == 0:
   pPath = CC5NMK.VVBX3T()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
    cmd += FFGA8O("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VV4UQ6(self, path):
  if path and fileExists(path):
   err, w, h = self.VVfh0B(path)
   if not err:
    if h > w:
     self.VVButS(self["myPicF"], w, h, True)
     self.VVButS(self["myPic"] , w, h, False)
   self.picViewer = CCafhh.VVOSVs(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVButS(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVfh0B(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFmAmO(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVs31X(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFcK2v(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVUkWF(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFcK2v(state, VVII83)
   txt += "State\t: %s\n" % state
  w = FFmWQs(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFmWQs(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVjpk3(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVUkWF(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVUkWF(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVUkWF(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVn0uo()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VV3lLC()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCzqpW.VV9FpO(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFcK2v("IPTV", VV0ckb)
   txt += self.VV1v9O(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVx7PY(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCKps4()
    tpTxt, namespace = tp.VVKpej(refCode)
    del tp
    if tpTxt:
     txt += FFcK2v("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFcK2v("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVUkWF(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVUkWF(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVUkWF(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVUkWF(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVUkWF(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVUkWF(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVUkWF(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVUkWF(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVUkWF(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVjpk3(info):
  if info:
   aspect = FFmWQs(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVUkWF(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFmWQs(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVLKAb(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVLKAb(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVn0uo(self):
  try:
   service = self.session.nav.getCurrentService()
   audio = service and service.audioTracks()
   return audio and audio.getNumberOfTracks() or 0
  except:
   pass
  return -1
 def VV3lLC(self):
  try:
   service   = self.session.nav.getCurrentService()
   subtitle  = service and service.subtitle()
   subtitlelist = subtitle and subtitle.getSubtitleList()
   return len(subtitlelist)
  except:
   pass
  return -1
 def VVx7PY(self, refCode, iptvRef, chName):
  refCode = FFJ5i5(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFbAeW(VVDNL1 + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFbAeW(VVDNL1 + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VVU7lj = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVDNL1 + item
   if fileExists(path):
    txt = FFbAeW(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVU7lj.append(bName)
  txt = self.Sep
  if VVU7lj:
   if len(VVU7lj) == 1:
    txt += "%s\t: %s\n" % (FFcK2v("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VVU7lj[0])
   else:
    txt += FFcK2v("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VVU7lj):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVgolg(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVgdgM(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVgdgM(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVgdgM(event, 0)
     except:
      pass
  return epg
 def VVgdgM(self, event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCzqpW.VVYdEK(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = self.VVYpz3(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FFcK2v(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FFcK2v(evNameTransl, COLOR_CONS_BRIGHT_YELLOW))
    if evTime           : txt += "Start Time\t: %s\n" % FFtsyU(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFtsyU(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFesdJ(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFesdJ(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFesdJ(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFcK2v(evShort, VVHzAP)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFcK2v(evDesc , VVHzAP)
    if txt:
     txt = FFcK2v("\n%s\n%s Event:\n%s\n" % (VV0fId, ("Current", "Next")[evNum], VV0fId), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VV1v9O(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFhxAo(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCn4Pa()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVijeK(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFcK2v("URL:", VV0ckb) + "\n%s\n" % self.VVULCZ(decodedUrl)
  else:
   txt = "\n"
   txt += FFcK2v("Reference:", VV0ckb) + "\n%s\n" % refCode
  return txt
 def VVULCZ(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVMhOQ:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VVDHWk(self, decodedUrl):
  if not FFvkoy():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCZkJV.VVU5fz(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCZkJV.VVQVQc(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVh1Ux(tDict)
   elif uType == "movie" : epg, picUrl = self.VVcSSl(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVh1Ux(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCZkJV.VV8QZS(item, "title"    , is_base64=True )
     lang    = CCZkJV.VV8QZS(item, "lang"         ).upper()
     description   = CCZkJV.VV8QZS(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCZkJV.VV8QZS(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCZkJV.VV8QZS(item, "start_timestamp"      )
     stop_timestamp  = CCZkJV.VV8QZS(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCZkJV.VV8QZS(item, "stop_timestamp"       )
     now_playing   = CCZkJV.VV8QZS(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVKQBm, ""
      else     : color, txt = VVII83 , "    (CURRENT EVENT)"
      epg += FFcK2v("_" * 32 + "\n", VVx60q)
      epg += FFcK2v("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFcK2v(description, VVXOiG)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVhCTV(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VVcSSl(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCZkJV.VV8QZS(item, "movie_image" )
    genre  = CCZkJV.VV8QZS(item, "genre"   ) or "-"
    plot  = CCZkJV.VV8QZS(item, "plot"   ) or "-"
    cast  = CCZkJV.VV8QZS(item, "cast"   ) or "-"
    rating  = CCZkJV.VV8QZS(item, "rating"   ) or "-"
    director = CCZkJV.VV8QZS(item, "director"  ) or "-"
    releasedate = CCZkJV.VV8QZS(item, "releasedate" ) or "-"
    duration = CCZkJV.VV8QZS(item, "duration"  ) or "-"
    try:
     lang = CCZkJV.VV8QZS(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFcK2v(cast, VVXOiG)
    epg += "Plot:\n%s"    % FFcK2v(self.VVYpz3(plot), VVXOiG)
   except:
    pass
  return epg, movie_image
 def VVYpz3(self, evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = self.VVz6ix(evTxt, lang)
   return CCzqpW.VV1JQM(txt).strip() or evTxt
 def VVmz6Q(self):
  if VVMhOQ:
   def VVUkWF(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVUkWF(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCn4Pa()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVijeK(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVUkWF(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (VV0fId, txt))
   FF7QSu(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VV1JQM(txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VV1P3e(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CCzqpW.VVYdEK(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVYdEK(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCzqpW.VVWXps(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVz6ix(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFd2eb(txt))
   txt, err = CCZkJV.VVQVQc(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFugDB(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVhCTV(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
 @staticmethod
 def VVkwEP(SELF):
  if not CCxV8P.VVCiK0(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(SELF)
  err = url =  fSize = resumable = ""
  if FFt5Pb(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCn4Pa.VVdZe1(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCn4Pa.VV6HSAHeader(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FFDQ9M(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCoBpc.VVDLDB(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFcK2v(" (M3U/M3U8 File)", VVXOiG)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCRR2A.VVszT9(resp) else "No"
   except requests.Timeout as e     : err = "Connection Timeout"
   except Exception as e       : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVt407(subj, val):
   return "%s\n%s\n\n" % (FFcK2v("%s:" % subj, COLOR_CONS_BRIGHT_YELLOW), val)
  title = "File Size"
  txt  = VVt407(title , fSize or "?")
  txt += VVt407("Name" , chName)
  txt += VVt407("URL" , url)
  if resumable: txt += VVt407("Supports Download-Resume", resumable)
  if err  : txt += FFcK2v("Error:\n", VVII83) + err
  FFUojK(SELF, txt, title=title)
 @staticmethod
 def VV9FpO(SELF):
  fPath, fDir, fName = CCoBpc.VVDIiU(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg", "mvi"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVWXps(event):
  genre = PR = ""
  try:
   genre  = CCzqpW.VV2OfT(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCzqpW.VVuYIR(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVuYIR(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VV2OfT(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCzqpW.VVZ6Lp()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVZ6Lp():
  path = VVMNbP + "genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFbAeW(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFbAeW(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
class CCn4Pa():
 def __init__(self):
  self.VVYPQ6   = ""
  self.VVfXoU    = ""
  self.VVD7M2   = ""
  self.portal_moreAuthRand = ""
  self.portal_moreAuthMsg  = ""
  self.portal_moreAuthType = 0
  self.portal_php    = ""
  self.colored_user   = "#f#11ffffaa#User"
  self.colored_server   = "#f#11aaffff#Server"
 def VVBgNj(self, url, mac, ph1="", VVS6In=True):
  self.VVYPQ6   = ""
  self.VVfXoU    = ""
  self.VVD7M2   = ""
  self.portal_moreAuthRand = ""
  self.portal_moreAuthMsg  = ""
  self.portal_moreAuthType = 0
  self.portal_php    = {"s": "/server/load.php", "p": "/portal.php"}.get(ph1, "")
  host = self.VVdHVs(url)
  if not host:
   if VVS6In:
    self.VVS6Inor("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVfxc6(mac)
  if not host:
   if VVS6In:
    self.VVS6Inor("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVYPQ6 = host
  self.VVfXoU  = mac
  return True
 def VVdHVs(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVfxc6(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVMDOT(self):
  res, err = self.VVIYoW(self.VVky3m())
  urlPath = "/stalker_portal"
  if "404" in err and urlPath in self.VVYPQ6:
   self.VVYPQ6 = self.VVYPQ6.replace(urlPath, "")
   res, err = self.VVIYoW(self.VVky3m())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCZkJV.VV8QZS(tDict["js"], "token")
    rand  = CCZkJV.VV8QZS(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVnSBR(self, VVS6In=True):
  if not self.portal_php:
   self.portal_php = self.VVltRv()
  err = blkMsg = FFrSV8Txt = ""
  try:
   token, rand, err = self.VVMDOT()
   if token:
    self.VVD7M2 = token
    self.portal_moreAuthRand = rand
    if rand:
     self.portal_moreAuthType = 2
    prof, retTxt = self.VV3QHI(True)
    if prof:
     self.portal_moreAuthMsg = retTxt
     if "device_id mismatch" in retTxt:
      self.portal_moreAuthType = 3
      prof, retTxt = self.VV3QHI(False)
      if retTxt:
       self.portal_moreAuthMsg = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFrSV8Txt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFrSV8Txt: tErr += "\n%s" % FFrSV8Txt
  if VVS6In:
   self.VVS6Inor(tErr)
  return "", "", tErr
 def VVltRv(self):
  try:
   import requests
   res = requests.get("%s/c/xpcom.common.js" % self.VVYPQ6, headers=CCn4Pa.VV6HSAHeader(), stream=True, timeout=2)
   if res.ok :
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       return span.group(1)
  except:
   pass
  return ""
 def VV3QHI(self, capMac):
  res, err = self.VVIYoW(self.VVKayv(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCZkJV.VV8QZS(tDict["js"], "block_%s" % word)
    FFrSV8Txt = CCZkJV.VV8QZS(tDict["js"], word)
    return tDict, FFrSV8Txt.strip() or blkMsg.strip()
   except Exception as e:
    pass
  return "", ""
 def VVKayv(self, capMac):
  if self.portal_moreAuthMsg or self.portal_moreAuthRand:
   import hashlib
   if capMac: mac = self.VVfXoU.upper()
   else  : mac = self.VVfXoU.lower()
   macUtf8 = mac.encode('utf-8')
   sn = hashlib.md5(macUtf8).hexdigest().upper()[:13]
   Id = hashlib.sha256(macUtf8).hexdigest().upper()
   sig = hashlib.sha256((sn + mac).encode('utf-8')).hexdigest().upper()
   param  = ""
   param += "&sn=%s"   % sn
   param += "&device_id=%s" % Id
   param += "&device_id2=%s" % Id
   param += "&signature=%s" % sig
   param += '&auth_second_step=1'
   param += '&hw_version=2.17-IB-00&hw_version_2=62'
   param += '&metrics={"mac":"%s","sn":"%s","type":"STB","model":"MAG250","random":"%s"}' % (self.VVfXoU, sn, self.portal_moreAuthRand)
  else:
   param = ""
  return self.VVhBAQ() + "type=stb&action=get_profile" + param
 def VVe7vf(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVuCPQ()
  if len(rows) < 10:
   rows = self.VVtjeZ()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVYPQ6 ))
   rows.append(("MAC (from URL)" , self.VVfXoU ))
   rows.append(("Token"   , self.VVD7M2 ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VVfXoU ))
   rows.append(("2", self.colored_server, "Host" , self.VVYPQ6 ))
   rows.append(("2", self.colored_server, "Token" , self.VVD7M2 ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVrH50(self, isPhp=True, VVS6In=False):
  token, profile, tErr = self.VVnSBR(VVS6In)
  if not token:
   return "", tErr
  m3u_Url = ""
  url = self.VVGJiq()
  res, err = self.VVIYoW(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCZkJV.VV8QZS(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFd2eb(span.group(2))
     pass1 = FFd2eb(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, err
 def VVuCPQ(self):
  m3u_Url, err = self.VVrH50()
  rows = []
  if m3u_Url:
   res, err = self.VVIYoW(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFtsyU(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFtsyU(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVtjeZ(self):
  token, profile, tErr = self.VVnSBR()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFRSri(val): val = FFscG4(val.decode("UTF-8"))
     else     : val = self.VVfXoU
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFtsyU(int(parts[1]))
      if parts[2] : ends = FFtsyU(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFtsyU(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVrXxA(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVnSBR(VVS6In=False)
  if not token:
   return ""
  crLinkUrl = self.VVIk3G(mode, chCm, epNum, epId)
  res, err = self.VVIYoW(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCZkJV.VV8QZS(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVhBAQ(self):
  return self.VVYPQ6 + (self.portal_php or "/server/load.php") + "?"
 def VVky3m(self):
  return self.VVhBAQ() + "type=stb&action=handshake&token=&mac=%s" % self.VVfXoU
 def VVaRw4(self, mode):
  url = self.VVhBAQ() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVuQqF(self, catID):
  return self.VVhBAQ() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVuC3w(self, mode, catID, page):
  url = self.VVhBAQ() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVYZ6j(self, mode, searchName, page):
  return self.VVhBAQ() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VVavkF(self, mode, catID):
  return self.VVhBAQ() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVIk3G(self, mode, chCm, serCode, serId):
  url = self.VVhBAQ() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=false" % (mode, chCm)
  return url
 def VVGJiq(self):
  return self.VVhBAQ() + "type=itv&action=create_link"
 def VV33XY(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVZway(catID, stID, chNum)
  query = self.VVA12X(mode, self.portal_php[1:2], FFnf6Q(host), FFnf6Q(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVA12X(self, mode, ph1, host, mac, serCode, serId, chCm):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVijeK(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVA12X(mode, ph1, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFscG4(host)
  mac   = FFscG4(mac)
  valid = False
  if self.VVdHVs(playHost) and self.VVdHVs(host) and self.VVdHVs(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVIYoW(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCn4Pa.VV6HSAHeader()
   if self.VVD7M2:
    headers["Authorization"] = "Bearer %s" % self.VVD7M2
   if useCookies : cookies = {"mac": self.VVfXoU, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok : return res, ""
   else  : err = "Err-%d : %s" % (res.status_code, res.reason or "Unknown")
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVttWf(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCn4Pa.VV6HSAHeader(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VV6HSAHeader():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VV7j0M(host, mac, tType, action, keysList=[]):
  myPortal = CCn4Pa()
  ph1 = "s"
  pref = "/portal.php" if par == "p" else "/server/load.php"
  ok = myPortal.VVBgNj(host, mac, ph1)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVnSBR(VVS6In=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s%s?type=%s&action=%s" % (host, ph1, tType, action)
  res, err = myPortal.VVIYoW(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVhh48(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVhh48(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVS6Inor(self, err, title="Portal Browser"):
  FFDQ9M(self, str(err), title=title)
 def VVbJvq(self, mode):
  if   mode in ("itv"  , CCZkJV.VVptHP , CCZkJV.VVIBxJ)  : return "Live"
  elif mode in ("vod"  , CCZkJV.VVM4on , CCZkJV.VVP4Qm)  : return "VOD"
  elif mode in ("series" , CCZkJV.VVk6vH , CCZkJV.VVujxI) : return "Series"
  else                          : return "IPTV"
 def VVam07(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVbJvq(mode), searchName)
 def VVSbKx(self, catchup=False):
  VVE6xF = []
  VVE6xF.append(("Live"    , "live"  ))
  VVE6xF.append(("VOD"    , "vod"   ))
  VVE6xF.append(("Series"   , "series"  ))
  if catchup:
   VVE6xF.append(VVBgIm)
   VVE6xF.append(("Catchup TV" , "catchup"  ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Account Info." , "accountInfo" ))
  return VVE6xF
 @staticmethod
 def VVLk1m(decodedUrl):
  m3u_Url = ""
  p = CCn4Pa()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVijeK(decodedUrl)
  if valid:
   ok = p.VVBgNj(host, mac, ph1, VVS6In=False)
   if ok:
    m3u_Url, err = p.VVrH50(isPhp=False, VVS6In=False)
    span = iSearch(r".+ch\/(.+)_", decodedUrl, IGNORECASE)
    if span:
     m3u_Url += span.group(1)
  return m3u_Url
 @staticmethod
 def VVdZe1(decodedUrl):
  p = CCn4Pa()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVijeK(decodedUrl)
  if valid:
   if CCn4Pa.VVwV0r(chCm):
    return FFugDB(chCm)
   else:
    ok = p.VVBgNj(host, mac, ph1, VVS6In=False)
    if ok:
     try:
      chUrl = p.VVrXxA(mode, chCm, epNum, epId)
      return FFugDB(chUrl)
     except Exception as e:
      pass
  return ""
 @staticmethod
 def VVwV0r(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
class CCEwnB(CCn4Pa):
 def __init__(self):
  CCn4Pa.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVVZM9(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVijeK(decodedUrl)
  if valid:
   if self.VVBgNj(host, mac, ph1, VVS6In=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VV4Uz9(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVrXxA(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CCn4Pa.VVwV0r(self.chCm):
   chUrl = FFugDB(self.chCm)
   chUrl = FFd2eb(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
   isDirect = True
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
   isDirect = True
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVnzdZ(chUrl)
  if newIptvRef:
   success = self.VVrZAa(self.iptvRef, newIptvRef, isDirect)
   if passedSELF:
    FFI7Gq(passedSELF, newIptvRef, VVetCj=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFI7Gq(self, newIptvRef, VVetCj=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VVnzdZ(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVrZAa(self, oldCode, newCode, isDirect):
  bPath = FFMr65()
  if bPath:
   if isDirect:
    patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
    span = iSearch(patt, newCode, IGNORECASE)
    if span:
     newRef = span.group(1)
     newPar = span.group(2)
     lines = FFel5Q(bPath)
     for ndx, line in enumerate(lines):
      span = iSearch(patt, line, IGNORECASE)
      if span and newRef == span.group(1) and newPar == span.group(2):
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f:
        for line in lines:
         f.write(line + "\n")
       FFY6Ac()
       return True
   else:
    txt = FFbAeW(bPath)
    if oldCode in txt:
     txt = txt.replace(oldCode, newCode)
     with open(bPath, "w") as f:
      f.write(txt)
     FFY6Ac()
     return True
  return False
class CCAccE(CCEwnB):
 def __init__(self, passedSession):
  CCEwnB.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.isFromEOF  = False
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVC88v, iPlayableService.evEOF: self.VVD4XR, iPlayableService.evEnd: self.VVodBO})
  except:
   pass
 def VVC88v(self):
  self.startTime = iTime()
 def VVD4XR(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self.passedSession, isFromSession=True)
    if iptvRef and not FFt5Pb(decodedUrl):
     self.isFromEOF = True
     CCsnpJ(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVodBO(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VV3oqV)
  except:
   self.timer1.callback.append(self.VV3oqV)
  self.timer1.start(100, True)
 def VV3oqV(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVVZM9(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCZOmQ.VVn5e3:
       self.isFromEOF = False
       self.VV4Uz9(self.passedSession, isFromSession=True)
class CCyogD():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.nameTagPatt = r"\s*.{1,2}\s*[\[(|:]{1,2}\s*(.+)|\s*[\[(|:].{1,5}[\])|:](.+)|\s*(?:[^a-z]+:)*(.+)"
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.missingUtf8 = VV28fl and not VV9gmM
  self.adultWords  = ("adult", "aduld", "sex", "porn", "xxx", "xxi", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.adultWords2 = ("\u042d\u0440\u043e\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0435", "dla doros\u0142ych")
 def VVqxfD(self, name,  censored=""):
  if self.missingUtf8:
   name = str(name.encode('ascii', 'replace').decode('utf-8'))
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCZkJV.VVpS2n(name):
   return CCZkJV.VVqXY2(name)
  name = self.VVTELn(name)
  return name.strip() or name
 def VVTELn(self, name):
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    return span.group(1) or span.group(2) or span.group(3)
  return name
 def VVxaMb(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVTELn(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVArKJ(self, name):
  if self.hideAdult:
   if any(x in name.lower() for x in self.adultWords):
    return ""
   elif any(x in name.encode('ascii', 'backslashreplace').decode('utf-8').lower() for x in self.adultWords2):
    return ""
  return name.strip()
 def VVWsz1(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVimQm(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCxV8P(CCn4Pa):
 def __init__(self):
  CCn4Pa.__init__(self)
 def VVPM9v(self):
  if CCxV8P.VVCiK0(self):
   FFy61j(self, self.VVrncK, title="Searching ...")
 def VVAO9J(self, winSession, url, mac):
  if CCxV8P.VVCiK0(self):
   if self.VVBgNj(url, mac):
    FFy61j(winSession, self.VVmBHb, title="Checking Server ...")
   else:
    FFDQ9M(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVrncK(self):
  path = CCZkJV.VVCIeb()
  lines = FFDp6V('find %s %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % (path, FFGFzp(1)))
  if lines:
   if len(lines) == 1 and lines[0] == VVqB9V:
    FFDQ9M(self, VVqB9V)
   else:
    lines.sort()
    VVE6xF = []
    for line in lines:
     VVE6xF.append((line, line))
    OKBtnFnc  = self.VV6PeH
    VVJsRJ = ("Delete File", self.VV7iFA)
    FFtUqp(self, None, title="Select Portals File", VVE6xF=VVE6xF, width=1200, OKBtnFnc=OKBtnFnc, VVJsRJ=VVJsRJ)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFDQ9M(self, 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt)
 def VV7iFA(self, VVtbO0Obj, path):
  FFZhjP(self, boundFunction(self.VV0VcD, VVtbO0Obj, path), "Delete this file ?\n\n%s" % path)
 def VV0VcD(self, VVtbO0Obj, path):
  os.system(FFGA8O("rm -f '%s'" % path))
  if fileExists(path) : FF7QSu(VVtbO0Obj, "Not deleted", 1000)
  else    : VVtbO0Obj.VVIekM()
 def VV6PeH(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = CCVXoR.VVJhd6(path, self)
   if enc == -1:
    return
   self.session.open(CCucls, barTheme=CCucls.VVVMet
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VVmELW, path, enc)
       , VVG4RV = boundFunction(self.VVi3IG, menuInstance, path))
 def VVmELW(self, path, enc, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  progBarObj.VVo3zA(totLines)
  progBarObj.VVaHnU = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVCm3j(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVdHVs(url)
     mac  = self.VVfxc6(mac)
     if host and mac and progBarObj:
      progBarObj.VVaHnU.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVdHVs(url)
      mac  = self.VVfxc6(mac)
      if host and mac and not mac.startswith("AC") and progBarObj:
       progBarObj.VVaHnU.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVi3IG(self, menuInstance, path, VVojmq, VVaHnU, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVaHnU:
   VVjx9F  = ("Home Menu"  , FF4ANQ               , [])
   VVZ5MP = ("Edit File"  , boundFunction(self.VVPZwh, path)       , [])
   VVJlME = ("Open as M3U" , self.VVO4ep           , [])
   VV2x0g = ("Check & Filter" , boundFunction(self.VV6lj2, menuInstance, path) , [])
   VV2mqV  = ("Select"   , self.VVAO9J_fromMacFiles         , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VV9ki4  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVoKzZ = FFIbZw(self, None, title=title, header=header, VVU7lj=VVaHnU, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=26, VV2mqV=VV2mqV, VVjx9F=VVjx9F, VVJlME=VVJlME, VVZ5MP=VVZ5MP, VV2x0g=VV2x0g, VV6Us0="#0a001122", VVezBA="#0a001122", VVDUXJ="#0a001122", VVTpzJ="#00004455", VVvufb="#0a333333", VVeHz9="#11331100", VVyLkT=True, searchCol=1)
   if not VVojmq:
    FF7QSu(VVoKzZ, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVojmq:
    FFDQ9M(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVO4ep(self, VVoKzZ, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  FFy61j(VVoKzZ, boundFunction(self.VVPtg7, VVoKzZ, host, mac), title="Checking Server ...")
 def VVPtg7(self, VVoKzZ, host, mac):
  p = CCn4Pa()
  m3u_Url = ""
  ok = p.VVBgNj(host, mac, VVS6In=False)
  err = ""
  if ok:
   m3u_Url, err = p.VVrH50(VVS6In=False)
  title = "Browsing M3U Server from Portal Data"
  if m3u_Url:
   self.VViCv1(title, m3u_Url)
  else:
   FFDQ9M(self, err or "No response from Server !", title=title)
 def VVAO9J_fromMacFiles(self, VVoKzZ, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVAO9J(VVoKzZ, url, mac)
 def VVPZwh(self, path, VVoKzZ, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CC5Lyi(self, path, VVG4RV=boundFunction(self.VVTueG, VVoKzZ), curRowNum=rowNum)
  else    : FFC6jW(self, path)
 def VV6lj2(self, menuInstance, path, VVoKzZ, title, txt, colList):
  self.session.open(CCucls, barTheme=CCucls.VVgBcO
      , titlePrefix = "Checking Portals"
      , fncToRun  = boundFunction(self.VVk1Jg, VVoKzZ)
      , VVG4RV = boundFunction(self.VVICYl, menuInstance, VVoKzZ, path))
 def VVk1Jg(self, VVoKzZ, progBarObj):
  progBarObj.VVaHnU = []
  progBarObj.VVo3zA(VVoKzZ.VVLYac())
  for row in VVoKzZ.VVtoSt():
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVCm3j(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVBgNj(host, mac, VVS6In=False):
    token, profile, tErr = self.VVnSBR(VVS6In=False)
    if token and progBarObj and not progBarObj.isCancelled:
     res, err = self.VVIYoW(self.VVaRw4("itv"))
     if res and progBarObj and not progBarObj.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       progBarObj.VVCm3j(0, showFound=True)
       progBarObj.VVaHnU.append((titl, host, mac, cmnt))
      except:
       pass
   if not progBarObj:
    return
 def VVICYl(self, menuInstance, VVoKzZ, path, VVojmq, VVaHnU, threadCounter, threadTotal, threadErr):
  if VVaHnU:
   VVoKzZ.close()
   menuInstance.close()
   newPath = "%s_OK_%s.txt" % (path, FFmDuf())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVaHnU:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FFcK2v(str(threadCounter), VVII83)
    skipped = FFcK2v(str(threadTotal - threadCounter), VVII83)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVaHnU)
   txt += "%s\n\n%s"    %  (FFcK2v("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
   FFUojK(self, txt, title="Accessible Portals")
  elif VVojmq:
   FFDQ9M(self, "No portal access found !", title="Accessible Portals")
 def VVRmEu(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFscG4(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVmBHb(self):
  token, profile, tErr = self.VVnSBR()
  if token:
   dots = "." * self.portal_moreAuthType
   dots += "+" if self.portal_php[1:2] == "p" else ""
   VVE6xF  = self.VVSbKx()
   OKBtnFnc = self.VVemHL
   VVXOT7 = ("Home Menu", FF4ANQ)
   VVhU9p = ("Bookmark Server", boundFunction(CCZkJV.VVXSig, self, True, self.VVYPQ6 + "\t" + self.VVfXoU))
   FFtUqp(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVfXoU, dots), VVE6xF=VVE6xF, OKBtnFnc=OKBtnFnc, VVXOT7=VVXOT7, VVhU9p=VVhU9p)
 def VVemHL(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFy61j(menuInstance, boundFunction(self.VVCuSJ, mode), title="Reading Categories ...")
   else : FFy61j(menuInstance, boundFunction(self.VVkUFx, menuInstance, title), title="Reading Account ...")
 def VVkUFx(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVe7vf(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVfXoU)
  VVjx9F  = ("Home Menu" , FF4ANQ            , [])
  VVJlME  = None
  if VV0DJY:
   VVJlME = ("Get JS"  , boundFunction(self.VV06DM, self.VVYPQ6) , [])
  if totCols == 2:
   VV2x0g = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VV2x0g = ("More Info.", boundFunction(self.VVzaUk, menuInstance) , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFIbZw(self, None, title=title, width=1200, header=header, VVU7lj=rows, VVSkoS=widths, VVhkQh=26, VVjx9F=VVjx9F, VVJlME=VVJlME, VV2x0g=VV2x0g, VV6Us0="#0a00292B", VVezBA="#0a002126", VVDUXJ="#0a002126", VVTpzJ="#00000000", searchCol=searchCol)
 def VV06DM(self, url, VVoKzZ, title, txt, colList):
  FFy61j(VVoKzZ, boundFunction(self.VVlkHN, url), title="Getting JS ...")
 def VVlkHN(self, url):
  txt = "// Host\t: %s\n" % url
  res, err = self.VVIYoW("%s/c/version.js" % url)
  if not err: ver = res.text
  else   : ver = "Error: %s" % err
  txt += "// Version\t: %s\n" % ver
  res, err = self.VVIYoW("%s/c/xpcom.common.js" % url)
  if not err: js = res.text
  else   : js = "Error: %s" % err
  txt += "\n%s" % js
  FFUojK(self, txt, title="JS Info", canSaveToFile="Server_xpcom.common.js")
 def VVzaUk(self, menuInstance, VVoKzZ, title, txt, colList):
  VVoKzZ.cancel()
  FFy61j(menuInstance, boundFunction(self.VVkUFx, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVCuSJ(self, mode):
  token, profile, tErr = self.VVnSBR()
  if not token:
   return
  res, err = self.VVIYoW(self.VVaRw4(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CCyogD()
     chList = tDict["js"]
     for item in chList:
      Id   = CCZkJV.VV8QZS(item, "id"       )
      Title  = CCZkJV.VV8QZS(item, "title"      )
      censored = CCZkJV.VV8QZS(item, "censored"     )
      Title = processChanName.VVArKJ(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VV0DJY:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVbJvq(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VV6Us0, VVezBA, VVDUXJ, VVTpzJ = self.VVyQAw(mode)
   mName = self.VVbJvq(mode)
   VV2mqV   = ("Show List"   , boundFunction(self.VVaLFT, mode) , [])
   VVjx9F  = ("Home Menu"   , FF4ANQ         , [])
   if mode in ("vod", "series"):
    VVZ5MP = ("Find in %s" % mName , boundFunction(self.VVqzoU, mode), [])
   else:
    VVZ5MP = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FFIbZw(self, None, title=title, width=1200, header=header, VVU7lj=list, VVSkoS=widths, VVhkQh=30, VVjx9F=VVjx9F, VVZ5MP=VVZ5MP, VV2mqV=VV2mqV, VV6Us0=VV6Us0, VVezBA=VVezBA, VVDUXJ=VVDUXJ, VVTpzJ=VVTpzJ)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.portal_moreAuthMsg:
     txt += "\n\n( %s )" % self.portal_moreAuthMsg
   else:
    txt = "Could not get Categories from server!"
   FFDQ9M(self, txt, title=title)
 def VVuvkV(self, mode, VVoKzZ, title, txt, colList):
  FFy61j(VVoKzZ, boundFunction(self.VV9T6F, mode, VVoKzZ, title, txt, colList), title="Downloading ...")
 def VV9T6F(self, mode, VVoKzZ, title, txt, colList):
  token, profile, tErr = self.VVnSBR()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVIYoW(self.VVuQqF(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCZkJV.VV8QZS(item, "id"    )
      actors   = CCZkJV.VV8QZS(item, "actors"   )
      added   = CCZkJV.VV8QZS(item, "added"   )
      age    = CCZkJV.VV8QZS(item, "age"   )
      category_id  = CCZkJV.VV8QZS(item, "category_id" )
      description  = CCZkJV.VV8QZS(item, "description" )
      director  = CCZkJV.VV8QZS(item, "director"  )
      genres_str  = CCZkJV.VV8QZS(item, "genres_str"  )
      name   = CCZkJV.VV8QZS(item, "name"   )
      path   = CCZkJV.VV8QZS(item, "path"   )
      screenshot_uri = CCZkJV.VV8QZS(item, "screenshot_uri" )
      series   = CCZkJV.VV8QZS(item, "series"   )
      cmd    = CCZkJV.VV8QZS(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VV2mqV  = ("Play"    , boundFunction(self.VVjgmQ, mode)       , [])
   VVmEVe = (""     , boundFunction(self.VVKjRY, mode)     , [])
   VVjx9F = ("Home Menu"   , FF4ANQ               , [])
   VVJlME = ("Download Options" , boundFunction(self.VVPte5, mode, "sp", seriesName) , [])
   VVZ5MP = ("Options" , boundFunction(self.VViKMU, 0, "pEp", mode, seriesName)  , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VV9ki4  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFIbZw(self, None, title=seriesName, width=1200, header=header, VVU7lj=list, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=26, VVjx9F=VVjx9F, VVJlME=VVJlME, VVZ5MP=VVZ5MP, VV2mqV=VV2mqV, VVmEVe=VVmEVe, VV6Us0="#0a00292B", VVezBA="#0a002126", VVDUXJ="#0a002126", VVTpzJ="#00000000")
  else:
   FFDQ9M(self, "Could not get Episodes from server!", title=seriesName)
 def VVqzoU(self, mode, VVoKzZ, title, txt, colList):
  VVE6xF = []
  VVE6xF.append(("Keyboard"  , "manualEntry"))
  VVE6xF.append(("From Filter" , "fromFilter"))
  FFtUqp(self, boundFunction(self.VV3D9g, VVoKzZ, mode), title="Input Type", VVE6xF=VVE6xF, width=400)
 def VV3D9g(self, VVoKzZ, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFzG9s(self, boundFunction(self.VVIXjT, VVoKzZ, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CC2Xqg(self)
    filterObj.VVfaak(boundFunction(self.VVIXjT, VVoKzZ, mode))
 def VVIXjT(self, VVoKzZ, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VVam07(mode, searchName)
   if len(searchName) < 3:
    FFDQ9M(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CCyogD()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVWsz1([searchName]):
     FFDQ9M(self, processChanName.VVimQm(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VVTTtI(mode, searchName, "", searchName)
 def VVaLFT(self, mode, VVoKzZ, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVTTtI(mode, bName, catID, "")
 def VVTTtI(self, mode, bName, catID, searchName):
  self.session.open(CCucls, barTheme=CCucls.VVVMet
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVhfRP, mode, bName, catID, searchName)
      , VVG4RV = boundFunction(self.VVt51b, mode, bName, catID, searchName))
 def VVt51b(self, mode, bName, catID, searchName, VVojmq, VVaHnU, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVam07(mode, searchName)
  else   : title = "%s : %s" % (self.VVbJvq(mode), bName)
  if VVaHnU:
   VVJlME = None
   VVZ5MP = None
   if mode == "series":
    VV6Us0, VVezBA, VVDUXJ, VVTpzJ = self.VVyQAw("series2")
    VV2mqV  = ("Episodes", boundFunction(self.VVuvkV, mode) , [])
   else:
    VV6Us0, VVezBA, VVDUXJ, VVTpzJ = self.VVyQAw("")
    VV2mqV  = ("Play"    , boundFunction(self.VVjgmQ, mode)           , [])
    VVJlME = ("Download Options" , boundFunction(self.VVPte5, mode, "vp" if mode == "vod" else "", "") , [])
    VVZ5MP = ("Options"   , boundFunction(self.VViKMU, 1, "pCh", mode, bName)      , [])
   VVmEVe = (""      , boundFunction(self.VVzErB, mode)          , [])
   VVjx9F = ("Home Menu"    , FF4ANQ                   , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VV9ki4  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT )
   VVoKzZ = FFIbZw(self, None, title=title, header=header, VVU7lj=VVaHnU, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=26, VVjx9F=VVjx9F, VVJlME=VVJlME, VVZ5MP=VVZ5MP, VV2mqV=VV2mqV, VVmEVe=VVmEVe, VV6Us0=VV6Us0, VVezBA=VVezBA, VVDUXJ=VVDUXJ, VVTpzJ=VVTpzJ, VVyLkT=True, searchCol=1)
   if not VVojmq:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVoKzZ.VVzQpf(VVoKzZ.VVwDp0() + tot)
    if threadErr: FF7QSu(VVoKzZ, "Error while reading !", 2000)
    else  : FF7QSu(VVoKzZ, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFDQ9M(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFDQ9M(self, "Could not get list from server !", title=title)
 def VVzErB(self, mode, VVoKzZ, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFvad7(self, fncMode=CCzqpW.VVS21f, portalHost=self.VVYPQ6, portalMac=self.VVfXoU, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VV4kmy(mode, VVoKzZ, title, txt, colList)
 def VVKjRY(self, mode, VVoKzZ, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFcK2v(colList[10], VVXOiG)
  txt += "Description:\n%s" % FFcK2v(colList[11], VVXOiG)
  self.VV4kmy(mode, VVoKzZ, title, txt, colList)
 def VV4kmy(self, mode, VVoKzZ, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVcbEI(mode, colList)
  refCode, chUrl = self.VV33XY(self.VVYPQ6, self.VVfXoU, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFvad7(self, fncMode=CCzqpW.VVxNb6, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVhfRP(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile, tErr = self.VVnSBR()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VVaHnU, total_items, max_page_items, err = self.VVZXrn(mode, catID, 1, 1, searchName)
   if progBarObj.isCancelled:
    return
   if progBarObj.VVaHnU and total_items > -1 and max_page_items > -1:
    progBarObj.VVo3zA(total_items)
    progBarObj.VVCm3j(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVZXrn(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VVe5ri()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VVaHnU += list
      progBarObj.VVCm3j(len(list), True)
  except:
   pass
 def VVZXrn(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVYZ6j(mode, searchName, page)
  else   : url = self.VVuC3w(mode, catID, page)
  res, err = self.VVIYoW(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VV6bHD(CCZkJV.VV8QZS(item, "total_items" ))
     max_page_items = self.VV6bHD(CCZkJV.VV8QZS(item, "max_page_items" ))
     processChanName = CCyogD()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCZkJV.VV8QZS(item, "id"    )
      name   = CCZkJV.VV8QZS(item, "name"   )
      o_name   = CCZkJV.VV8QZS(item, "o_name"   )
      tv_genre_id  = CCZkJV.VV8QZS(item, "tv_genre_id" )
      number   = CCZkJV.VV8QZS(item, "number"   ) or str(counter)
      logo   = CCZkJV.VV8QZS(item, "logo"   )
      screenshot_uri = CCZkJV.VV8QZS(item, "screenshot_uri" )
      cmd    = CCZkJV.VV8QZS(item, "cmd"   )
      censored  = CCZkJV.VV8QZS(item, "censored"  )
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       span = iSearch(r"stream=(.+)&", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
       else:
        span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVYPQ6 + picon).replace(sp * 2, sp)
      counter += 1
      name = processChanName.VVqxfD(name, censored)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VV0iPI(self, mode, bName, VVoKzZ, title, txt, colList):
  bNameFile = CCZkJV.VVUGxW_forBouquet(bName)
  num  = 0
  path = VVDNL1 + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVDNL1 + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   isMulti = VVoKzZ.VVf82F
   for ndx, row in enumerate(VVoKzZ.VVtoSt()):
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVcbEI(mode, row)
    refCode, chUrl = self.VV33XY(self.VVYPQ6, self.VVfXoU, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    if not isMulti or VVoKzZ.VVeIuQ(ndx):
     f.write("#SERVICE %s\n"  % chUrl)
     f.write("#DESCRIPTION %s\n" % chName)
     totChange += 1
  FFixCI(os.path.basename(path))
  self.VVZCMs(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VV6bHD(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVjgmQ(self, mode, VVoKzZ, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVcbEI(mode, colList)
  refCode, chUrl = self.VV33XY(self.VVYPQ6, self.VVfXoU, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVpS2n(chName):
   FF7QSu(VVoKzZ, "This is a marker!", 300)
  else:
   FFy61j(VVoKzZ, boundFunction(self.VVnorY, mode, VVoKzZ, chUrl), title="Playing ...")
 def VVnorY(self, mode, VVoKzZ, chUrl):
  FFI7Gq(self, chUrl, VVetCj=False)
  self.session.open(CCZOmQ, portalTableParam=(self, VVoKzZ, mode))
 def VVlRZ2(self, mode, VVoKzZ, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVcbEI(mode, colList)
  refCode, chUrl = self.VV33XY(self.VVYPQ6, self.VVfXoU, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVcbEI(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVCiK0(SELF):
  try:
   import requests
   return True
  except:
   title = 'Install "Requests"'
   VVE6xF = []
   VVE6xF.append((title        , "inst" ))
   VVE6xF.append(("Update Packages then %s" % title , "updInst" ))
   FFtUqp(SELF, boundFunction(CCxV8P.VVjYma, SELF), title='This requires Python "Requests" library', VVE6xF=VVE6xF)
   return False
 @staticmethod
 def VVjYma(SELF, item=None):
  if item:
   from sys import version_info
   cmdUpd = FFomnU(VVtlAg, "")
   if cmdUpd:
    cmdInst = FFH2eT(VVOR4D, "python-requests")
    if version_info[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFR9ZE(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library')
   else:
    FFVSFz(SELF)
class CCZkJV(Screen, CCxV8P):
 VVKI0F    = 0
 VV0ukS    = 1
 VVKueA    = 2
 VVvNMc    = 3
 VVgNSk     = 4
 VVlt3R     = 5
 VVb9nT     = 6
 VVsbxL     = 7
 VVFa9C      = 8
 VVx530     = 9
 VV7AMb     = 10
 VVNX25     = 11
 VVRM6X     = 12
 VVxHPP      = 13
 VV1PB1      = 14
 VVF0Xk      = 15
 VVvVre      = 16
 VV2JVf      = 17
 VVIsxY    = 0
 VVptHP   = 1
 VVM4on   = 2
 VVk6vH   = 3
 VVNlNe  = 4
 VVF9C4  = 5
 VVIBxJ   = 6
 VVP4Qm   = 7
 VVujxI  = 8
 VVGdQW  = 9
 VV8wNK  = 10
 VV3ahX = 0
 VVkazA = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFoyhf(VVQLSY, 1000, 1000, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.m3uOrM3u8File  = m3uOrM3u8File
  self.m3uOrM3u8BName  = ""
  self.VVoKzZ  = None
  self.tableTitle   = "IPTV Channels List"
  self.VV5ueOData  = {}
  self.lastFindIptvName = ""
  CCxV8P.__init__(self)
  VVE6xF= self.VVQf4f()
  FF8NiA(self, title="IPTV", VVE6xF=VVE6xF)
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFCnHd(self["myMenu"])
  FFoto4(self)
  FFTR3L(self)
  if self.m3uOrM3u8File:
   self.VVbuYA(self.m3uOrM3u8File)
 def VVQf4f(self):
  files = self.VVAoc1()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"        , "VV5ueO_fromPlayList" ))
  tList.append(("IPTV Server Browser (from Portal List)"        , "VV5ueO_fromMac"  ))
  tList.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)"    , "VV5ueO_fromM3u"  ))
  qUrl, iptvRef = self.VV7a9u()
  if qUrl or "chCode" in iptvRef:
   tList.append(("IPTV Server Browser (from Current Channel)"      , "VV5ueO_fromCurrChan" ))
  VVE6xF = []
  if files:
   if self.VVoKzZ:
    VVE6xF.append(("Add Current List to a New Bouquet"      , "VVCn3A"  ))
    VVE6xF.append(VVBgIm)
    VVE6xF.append(("Change Current List References to Unique Codes"   , "VVPx6e"))
    VVE6xF.append(("Change Current List References to Identical Codes"  , "VV9F6L_rows" ))
    VVE6xF.append(VVBgIm)
    VVE6xF.append(("Share Reference with Satellite/C/T Service (manual entry)", "VVrECx"   ))
    VVE6xF.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VVhPAx"   ))
   else:
    VVE6xF += tList
    VVE6xF.append(VVBgIm)
    VVE6xF.append(("M3U/M3U8 File Browser"         , "VVzkFP"   ))
    VVE6xF.append(("Local IPTV Channels"          , "iptvTable_all"   ))
    if qUrl:
     VVE6xF.append(VVBgIm)
     VVE6xF.append(("Update Current Bouquet EPG (from IPTV Server)"  , "refreshIptvEPG"   ))
    VVE6xF.append(VVBgIm)
    VVE6xF.append(("Count Available IPTV Channels"       , "VVPxRS"    ))
    VVE6xF.append(("Check Reference Codes Format"        , "VVBzf7"   ))
    VVE6xF.append(("Check System Acceptable Reference Types"     , "VVo57X"   ))
    VVE6xF.append(VVBgIm)
    VVE6xF.append(("Share Reference with Sat./C/T (Only Matching Names)"  , "VVsX2p" ))
    VVE6xF.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVopgM"  ))
    VVE6xF.append(("Change ALL References to Unique Codes"     , "VVLFno" ))
    VVE6xF.append(("Change ALL References to Identical Codes"     , "VV9F6L_all" ))
  if not self.VVoKzZ:
   if not files:
    VVE6xF += tList
   if not CCRR2A.VVaulr():
    VVE6xF.append(VVBgIm)
    VVE6xF.append(("Download Manager"           , "dload_stat"    ))
  return VVE6xF
 def VV6P0F(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVCn3A"   : FFzG9s(self, self.VVCn3A, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVPx6e" : FFZhjP(self, boundFunction(FFy61j, self.VVoKzZ, self.VVPx6e ), "Change Current List References to Unique Codes ?")
   elif item == "VV9F6L_rows" : FFZhjP(self, boundFunction(FFy61j, self.VVoKzZ, self.VV9F6L   ), "Change Current List References to Identical Codes ?")
   elif item == "VVrECx"   : self.VVrECx(tTitle)
   elif item == "VVhPAx"   : self.VVhPAx(tTitle)
   elif item == "VV5ueO_fromPlayList" : FFy61j(self, self.VV40Hs, title=title)
   elif item == "VV5ueO_fromM3u"  : FFy61j(self, boundFunction(self.VVn1Bz, 0), title=title)
   elif item == "VV5ueO_fromMac"  : self.VVPM9v()
   elif item == "VV5ueO_fromCurrChan" : self.VVAO9J_fromCurrChan()
   elif item == "VVzkFP"   : self.VVzkFP()
   elif item == "iptvTable_live"   : FFy61j(self, boundFunction(self.VVJXhN, self.VVsbxL ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFy61j(self, boundFunction(self.VVJXhN, self.VVKI0F) , title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VVqHm9()
   elif item == "VVPxRS"    : FFy61j(self, self.VVPxRS)
   elif item == "VVBzf7"    : FFy61j(self, self.VVBzf7)
   elif item == "VVo57X"   : FFy61j(self, self.VVo57X)
   elif item == "VVsX2p"  : FFZhjP(self, boundFunction(FFy61j, self, self.VVsX2p ), "Continue ?")
   elif item == "VVopgM"  : self.VVopgM()
   elif item == "VVLFno" : FFZhjP(self, boundFunction(FFy61j, self, self.VVLFno ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VV9F6L_all" : FFZhjP(self, boundFunction(FFy61j, self, self.VV9F6L  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "dload_stat"    : CCRR2A.VVjaLW(self)
   elif item == "VVIcmK"   : FFy61j(self, boundFunction(CCZkgq.VVIcmK, self))
 def VVzkFP(self):
  if CCxV8P.VVCiK0(self):
   FFy61j(self, boundFunction(self.VVn1Bz, 1), title="Searching ...")
 def VVWw2Z(self):
  global VVsFSY
  VVsFSY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VV6P0F(item)
 def VVJXhN(self, mode):
  VV7OA3 = self.VVllys(mode)
  if VV7OA3:
   VVJlME = ("Current Service", self.VVuncN  , [])
   VVZ5MP = ("Options"  , self.VVq7O0    , [])
   VV2x0g = ("Filter"   , self.VVY8By    , [])
   VV2mqV  = ("Play"   , boundFunction(self.VVTXE3) , [])
   VVmEVe = (""    , self.VVpViE     , [])
   VV8qPL = (""    , self.VVHaZO      , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VV9ki4  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFIbZw(self, None, header=header, VVU7lj=VV7OA3, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=26
     , VV2mqV=VV2mqV, VVJlME=VVJlME, VVZ5MP=VVZ5MP, VV2x0g=VV2x0g, VVmEVe=VVmEVe, VV8qPL=VV8qPL
     , VV6Us0="#0a00292B", VVezBA="#0a002126", VVDUXJ="#0a002126", VVTpzJ="#00000000", VVyLkT=True, searchCol=1)
  else:
   if mode == self.VVsbxL: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFDQ9M(self, err)
 def VVHaZO(self, VVoKzZ, title, txt, colList):
  self.VVoKzZ = VVoKzZ
 def VVq7O0(self, VVoKzZ, title, txt, colList):
  VVE6xF= self.VVQf4f()
  FFtUqp(self, self.VV6P0F, title="IPTV Tools", VVE6xF=VVE6xF)
 def VVY8By(self, VVoKzZ, title, txt, colList):
  VVE6xF = []
  VVE6xF.append(("All"         , "all"   ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Prefix of Selected Channel"   , "sameName" ))
  VVE6xF.append(("Suggest Words from Selected Channel" , "partName" ))
  VVE6xF.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Live TV"        , "live"  ))
  VVE6xF.append(("VOD"         , "vod"   ))
  VVE6xF.append(("Series"        , "series"  ))
  VVE6xF.append(("Uncategorised"      , "uncat"  ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Video"        , "video"  ))
  VVE6xF.append(("Audio"        , "audio"  ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("MKV"         , "MKV"   ))
  VVE6xF.append(("MP4"         , "MP4"   ))
  VVE6xF.append(("MP3"         , "MP3"   ))
  VVE6xF.append(("AVI"         , "AVI"   ))
  VVE6xF.append(("FLV"         , "FLV"   ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVbNZx()
  if bNames:
   bNames.sort()
   VVE6xF.append(VVBgIm)
   for item in bNames:
    VVE6xF.append((item, "__b__" + item))
  filterObj = CC2Xqg(self)
  filterObj.VVpWoc(VVE6xF, VVE6xF, boundFunction(self.VVF7d8, VVoKzZ))
 def VVF7d8(self, VVoKzZ, item=None):
  prefix = VVoKzZ.VVai60(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVKI0F, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VV0ukS , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVKueA , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVvNMc , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVsbxL  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVFa9C   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVx530  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VV7AMb  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVNX25  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVRM6X  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVxHPP   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VV1PB1   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVF0Xk   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVvVre   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VV2JVf   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVb9nT  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VVgNSk  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVlt3R  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVKueA:
   VVE6xF = []
   chName = VVoKzZ.VVai60(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVE6xF.append((item, item))
    if not VVE6xF and chName:
     VVE6xF.append((chName, chName))
    FFtUqp(self, boundFunction(self.VV90Y4_partOfName, title), title="Words from Current Selection", VVE6xF=VVE6xF)
   else:
    VVoKzZ.VV3MOD("Invalid Channel Name")
  else:
   words, asPrefix = CC2Xqg.VVHOBM(words)
   if not words and mode in (self.VVgNSk, self.VVlt3R):
    FF7QSu(self.VVoKzZ, "Incorrect filter", 2000)
   else:
    FFy61j(self.VVoKzZ, boundFunction(self.VVHja5, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VV90Y4_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFy61j(self.VVoKzZ, boundFunction(self.VVHja5, self.VVKueA, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVqXY2(txt):
  return "#f#11ffff00#" + txt
 def VVHja5(self, mode, words, asPrefix, title):
  VV7OA3 = self.VVllys(mode=mode, words=words, asPrefix=asPrefix)
  if VV7OA3 : self.VVoKzZ.VVZlxC(VV7OA3, title)
  else  : self.VVoKzZ.VV3MOD("Not found")
 def VVllys(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VV7OA3 = []
  files  = self.VVAoc1()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFbAeW(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VV3JU1 = span.group(1)
    else : VV3JU1 = ""
    VV3JU1_lCase = VV3JU1.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVpS2n(chName): chNameMod = self.VVqXY2(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VV3JU1, chType, refCode, url)
     ok = False
     tUrl = FFugDB(url).lower()
     if mode == self.VVKI0F       : ok = True
     elif mode == self.VVb9nT       : ok = True
     elif mode == self.VVNX25:
      if CCZkJV.VVU5fz(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVRM6X:
      if CCZkJV.VVU5fz(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVsbxL:
      if CCZkJV.VVU5fz(tUrl, compareType="live")  : ok = True
     elif mode == self.VVFa9C:
      if CCZkJV.VVU5fz(tUrl, compareType="movie") : ok = True
     elif mode == self.VVx530:
      if CCZkJV.VVU5fz(tUrl, compareType="series") : ok = True
     elif mode == self.VV7AMb:
      if CCZkJV.VVU5fz(tUrl, compareType="")   : ok = True
     elif mode == self.VVxHPP:
      if CCZkJV.VVU5fz(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VV1PB1:
      if CCZkJV.VVU5fz(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVF0Xk:
      if CCZkJV.VVU5fz(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVvVre:
      if CCZkJV.VVU5fz(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VV2JVf:
      if CCZkJV.VVU5fz(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VV0ukS:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVKueA:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVvNMc:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VVgNSk:
      if words[0] == VV3JU1_lCase:
       ok = True
     elif mode == self.VVlt3R:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VV7OA3.append(row)
      chNum += 1
  if VV7OA3 and mode == self.VVb9nT:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VV7OA3)
   for item in VV7OA3:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VV7OA3 = newRows
  return VV7OA3
 def VVCn3A(self, bName):
  if bName:
   FFy61j(self.VVoKzZ, boundFunction(self.VVTDjf, bName), title="Adding Channels ...")
 def VVTDjf(self, bName):
  num = 0
  path = VVDNL1 + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVDNL1 + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVoKzZ.VVtoSt():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FF67wV(row[1]))
    totChange += 1
  FFixCI(os.path.basename(path))
  self.VVZCMs(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVopgM(self):
  txt = "Stream Type "
  VVE6xF = []
  VVE6xF.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVE6xF.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVE6xF.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVE6xF.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVE6xF.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVE6xF.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFtUqp(self, self.VVy9QK, title="Change Reference Types to:", VVE6xF=VVE6xF)
 def VVy9QK(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVjFgf("1"   )
   elif item == "RT_4097" : self.VVjFgf("4097")
   elif item == "RT_5001" : self.VVjFgf("5001")
   elif item == "RT_5002" : self.VVjFgf("5002")
   elif item == "RT_8192" : self.VVjFgf("8192")
   elif item == "RT_8193" : self.VVjFgf("8193")
 def VVjFgf(self, rType):
  FFZhjP(self, boundFunction(FFy61j, self, boundFunction(self.VVqYHw, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVqYHw(self, refType):
  totChange = 0
  files  = self.VVAoc1()
  if files:
   for path in files:
    txt = FFbAeW(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFixCI(os.path.basename(path))
  self.VVZCMs(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVPxRS(self):
  totFiles = 0
  files  = self.VVAoc1()
  if files:
   totFiles = len(files)
  totChans = 0
  VV7OA3 = self.VVllys()
  if VV7OA3:
   totChans = len(VV7OA3)
  FFUojK(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVBzf7(self):
  files  = self.VVAoc1()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFbAeW(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVcGUH
   else    : color = VVII83
   totInvalid = FFcK2v(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFcK2v("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFUojK(self, txt, title="Check IPTV References")
 def VVo57X(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVDNL1 + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFixCI(os.path.basename(path))
  FFY6Ac()
  acceptedList = []
  VVJ9Td = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVJ9Td:
   VVJTTD = FFnpqA(VVJ9Td)
   if VVJTTD:
    for service in VVJTTD:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVDNL1 + userBName
  bFile = VVDNL1 + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFGA8O("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFGA8O("rm -f '%s'" % path)
  os.system(cmd)
  FFY6Ac()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVcGUH
    else     : res, color = "No" , VVII83
    txt += "    %s\t: %s\n" % (item, FFcK2v(res, color))
   FFUojK(self, txt, title=title)
  else:
   txt = FFDQ9M(self, "Could not complete the test on your system!", title=title)
 def VVsX2p(self):
  lameDbChans = CCZkgq.VVDUdr(self, CCZkgq.VVMK3m)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVAoc1():
    toSave = False
    txt = FFbAeW(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVZCMs(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFDQ9M(self, 'No channels in "lamedb" !')
 def VVLFno(self):
  files  = self.VVAoc1()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFel5Q(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVVno6(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVZCMs(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVPx6e(self):
  iptvRefList = []
  files  = self.VVAoc1()
  if files:
   for path in files:
    txt = FFbAeW(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVoKzZ.VV36Sx(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVVno6(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVAoc1()
  if files:
   for path in files:
    lines = FFel5Q(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVZCMs(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVVno6(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VV9F6L(self):
  list = None
  if self.VVoKzZ:
   list = []
   for row in self.VVoKzZ.VVtoSt():
    list.append(row[4] + row[5])
  files  = self.VVAoc1()
  totChange = 0
  if files:
   for path in files:
    lines = FFel5Q(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVZCMs(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVZCMs(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFY6Ac()
   if refreshTable and self.VVoKzZ:
    VV7OA3 = self.VVllys()
    if VV7OA3 and self.VVoKzZ:
     self.VVoKzZ.VVZlxC(VV7OA3, self.tableTitle)
     self.VVoKzZ.VV3MOD(txt)
   FFUojK(self, txt, title=title)
  else:
   FFrSV8(self, "No changes.")
 def VVbNZx(self):
  files = self.VVAoc1()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with ioOpen(path, "r", encoding="utf-8") as f:
     span = iSearch(r"#NAME\s+(.*)", str(f.readline()), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    for b in FFEhoo():
     sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVAoc1(self):
  return CCZkJV.VVNgU9(self)
 @staticmethod
 def VVNgU9(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVDNL1 + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFbAeW(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVpViE(self, VVoKzZ, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFugDB(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFvad7(self, fncMode=CCzqpW.VV56bA, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VV6rFq(self, VVoKzZ, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVTXE3(self, VVoKzZ, title, txt, colList):
  chName, chUrl = self.VV6rFq(VVoKzZ, colList)
  self.VVL9hd(VVoKzZ, chName, chUrl, "localIptv")
 def VV4dui(self, mode, VVoKzZ, colList):
  chName, chUrl, picUrl, refCode = self.VVT2o1(mode, colList)
  return chName, chUrl
 def VVjxRN(self, mode, VVoKzZ, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVT2o1(mode, colList)
  self.VVL9hd(VVoKzZ, chName, chUrl, mode)
 def VVL9hd(self, VVoKzZ, chName, chUrl, playerFlag):
  chName = FF67wV(chName)
  if self.VVpS2n(chName):
   FF7QSu(VVoKzZ, "This is a marker!", 300)
  else:
   FFy61j(VVoKzZ, boundFunction(self.VVCvIT, VVoKzZ, chUrl, playerFlag), title="Playing ...")
 def VVCvIT(self, VVoKzZ, chUrl, playerFlag):
  FFI7Gq(self, chUrl, VVetCj=False)
  self.session.open(CCZOmQ, portalTableParam=(self, VVoKzZ, playerFlag))
 @staticmethod
 def VVpS2n(chName):
  mark = ("--", "__", "==", "##",  "**", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVuncN(self, VVoKzZ, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self)
  if refCode:
   bName = FF7F8X()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFJ5i5(refCode, origUrl, chName) }
   VVoKzZ.VVQRIY_partial(colDict, VVS6In=True)
 def VVn1Bz(self, m3uMode):
  path = CCZkJV.VVCIeb()
  lines = FFDp6V("find %s %s -iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'" % (path, FFGFzp(1)))
  if lines:
   lines.sort()
   VVE6xF = []
   for line in lines:
    VVE6xF.append((line, line))
   if m3uMode == self.VV3ahX:
    title = "Browse Server from M3U URLs"
    VVhU9p = ("All to Playlist", self.VVk34e)
   else:
    title = "M3U/M3U8 File Browser"
    VVhU9p = None
   OKBtnFnc = boundFunction(self.VVggIn, m3uMode, title)
   VVf3L2  = ("Show Full Path", self.VVmJfw)
   VVJsRJ = ("Delete File", self.VV7iFA)
   FFtUqp(self, None, title=title, VVE6xF=VVE6xF, width=1200, OKBtnFnc=OKBtnFnc, VVf3L2=VVf3L2, VVJsRJ=VVJsRJ, VVhU9p=VVhU9p)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n\n%s" % path
   FFDQ9M(self, 'No ".m3u" files found %s' % txt)
 def VVmJfw(self, VVtbO0Obj, url):
  FFUojK(self, url, title="Full Path")
 def VVggIn(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == self.VV3ahX:
    FFy61j(menuInstance, boundFunction(self.VVXI29, title, path))
   else:
    FFy61j(menuInstance, boundFunction(self.VVbuYA, path))
 def VVbuYA(self, srcPath):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFbAeW(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  processChanName = CCyogD()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VVPOdW(propLine, "group-title") or "-"
   if not group == "-" and processChanName.VVqxfD(group):
    groups.add(group)
  VV7OA3 = []
  if len(groups) > 0:
   title = "Groups"
   for group in groups:
    VV7OA3.append((group, group))
   VV7OA3.append(("ALL", ""))
   VV7OA3.sort(key=lambda x: x[0].lower())
   VVu2WP = self.VVgerL
   VV2mqV  = ("Select" , boundFunction(self.VV4Vnq, srcPath), [])
   widths   = (100  , 0)
   VV9ki4  = (LEFT  , LEFT)
   FFIbZw(self, None, title=title, width= 800, header=None, VVU7lj=VV7OA3, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=30, VV2mqV=VV2mqV, VVu2WP=VVu2WP
     , VV6Us0="#11110022", VVezBA="#11110022", VVDUXJ="#11110022", VVTpzJ="#00444400")
  else:
   txt = FFbAeW(srcPath)
   self.VVEg7j(txt, filterGroup="")
 def VV4Vnq(self, srcPath, VVoKzZ, title, txt, colList):
  group = colList[1]
  txt = FFbAeW(srcPath)
  self.VVEg7j(txt, filterGroup=group)
 def VVEg7j(self, txt, filterGroup=""):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = "Group : %s" % (filterGroup or "ALL")
  if lst:
   self.session.open(CCucls, barTheme=CCucls.VVVMet
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VV4HGq, lst, filterGroup)
       , VVG4RV = boundFunction(self.VV4OZF, title, bName))
  else:
   self.VVfFP3("No valid lines found !", title)
 def VV4HGq(self, lst, filterGroup, progBarObj):
  progBarObj.VVaHnU = []
  progBarObj.VVo3zA(len(lst))
  processChanName = CCyogD()
  num = 0
  for cols in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVCm3j(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VVPOdW(propLine, "tvg-logo")
   group = self.VVPOdW(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if group and not processChanName.VVqxfD(group) : skip = True
    if chName and not processChanName.VVqxfD(chName): skip = True
    if not skip and progBarObj:
     num += 1
     progBarObj.VVaHnU.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if progBarObj:
   progBarObj.VVzckZ_forcedUpdate("Loading %d Channels" % len(progBarObj.VVaHnU))
 def VV4OZF(self, title, bName, VVojmq, VVaHnU, threadCounter, threadTotal, threadErr):
  if VVaHnU:
   VVu2WP = self.VVgerL
   VV2mqV  = ("Select"    , boundFunction(self.VVj7Fa, title) , [])
   VVmEVe = (""     , self.VVUvAH         , [])
   VVJlME = ("Download PIcons" , self.VV20sm        , [])
   VVZ5MP = ("Options" , boundFunction(self.VViKMU, 1, "m3Ch", "", bName)  , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VV9ki4  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFIbZw(self, None, title=title, header=header, VVU7lj=VVaHnU, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=28, VV2mqV=VV2mqV, VVu2WP=VVu2WP, VVmEVe=VVmEVe, VVJlME=VVJlME, VVZ5MP=VVZ5MP, VVyLkT=True, searchCol=1
     , VV6Us0="#0a00192B", VVezBA="#0a00192B", VVDUXJ="#0a00192B", VVTpzJ="#00000000")
  else:
   self.VVfFP3("No valid lines found !", title)
 def VV20sm(self, VVoKzZ, title, txt, colList):
  self.VVVjbM(VVoKzZ, "m3u/m3u8")
 def VVAFo2(self, mode, bName, VVoKzZ, title, txt, colList):
  bNameFile = CCZkJV.VVUGxW_forBouquet(bName)
  num  = 0
  path = VVDNL1 + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVDNL1 + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   catID = "33"
   rowNum = 0
   isMulti = VVoKzZ.VVf82F
   for ndx, row in enumerate(VVoKzZ.VVtoSt()):
    chName = row[1].strip()
    url  = row[3].strip()
    chUrl = self.VV1PBV(rowNum, url, chName)
    rowNum += 1
    if not isMulti or VVoKzZ.VVeIuQ(ndx):
     f.write("#SERVICE %s\n"  % chUrl)
     f.write("#DESCRIPTION %s\n" % chName)
     totChange += 1
  FFixCI(os.path.basename(path))
  self.VVZCMs(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VV1PBV(self, rowNum, url, chName):
  refCode = self.VV51Pw(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFd2eb(url), chName)
  return chUrl
 def VV51Pw(self, rowNum, url, chName):
  span = iSearch(r"\/(\d{2,})", url, IGNORECASE)
  if span : stID = span.group(1)
  else : stID = "444"
  catID = "333"
  chNum = str(rowNum + 1)
  refCode = self.VVZway(catID, stID, chNum)
  return refCode
 def VVPOdW(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVj7Fa(self, Title, VVoKzZ, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFy61j(VVoKzZ, boundFunction(self.VV6qVy, Title, VVoKzZ, colList), title="Checking Server ...")
  else:
   self.VVNHcE(VVoKzZ, url, chName)
 def VV6qVy(self, title, VVoKzZ, colList):
  if not CCxV8P.VVCiK0(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCn4Pa.VVttWf(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVE6xF = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCZkJV.VVr7z3(url, fPath)
     VVE6xF.append((resol, fullUrl))
    if VVE6xF:
     if len(VVE6xF) > 1:
      FFtUqp(self, boundFunction(self.VVxNTA, VVoKzZ, chName), VVE6xF=VVE6xF, title="Resolution", VVETIV=True, VVOsJ7=True)
     else:
      self.VVNHcE(VVoKzZ, VVE6xF[0][1], chName)
    else:
     self.VVS6Inor("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVEg7j(txt, filterGroup="")
      return
    self.VVNHcE(VVoKzZ, url, chName)
   else:
    self.VVfFP3("Cannot process this channel !", title)
  else:
   self.VVfFP3(err, title)
 def VVxNTA(self, VVoKzZ, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVNHcE(VVoKzZ, resolUrl, chName)
 def VVNHcE(self, VVoKzZ, url, chName):
  FFy61j(VVoKzZ, boundFunction(self.VV3F4z, VVoKzZ, url, chName), title="Playing ...")
 def VV3F4z(self, VVoKzZ, url, chName):
  chUrl = self.VV1PBV(VVoKzZ.VVjUL9(), url, chName)
  FFI7Gq(self, chUrl, VVetCj=False)
  self.session.open(CCZOmQ, portalTableParam=(self, VVoKzZ, "m3u/m3u8"))
 def VV5jSb(self, VVoKzZ, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VV1PBV(VVoKzZ.VVjUL9(), url, chName)
  return chName, chUrl
 def VVUvAH(self, VVoKzZ, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFvad7(self, fncMode=CCzqpW.VV56bA, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVfFP3(self, err, title):
  FFDQ9M(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVgerL(self, VVoKzZ):
  if self.m3uOrM3u8File:
   self.close()
  VVoKzZ.cancel()
 def VVk34e(self, VVtbO0Obj, item=None):
  FFy61j(VVtbO0Obj, boundFunction(self.VVWWiV, VVtbO0Obj, item))
 def VVWWiV(self, VVtbO0Obj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVtbO0Obj.VVE6xF):
    path = item[1]
    if fileExists(path):
     enc = CCVXoR.VVJhd6(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = self.VV4dBL(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCZkJV.VVCIeb(orExportPath=True)
    pListF = "%sPlaylist_%s.txt" % (path, FFmDuf())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVtbO0Obj.VVE6xF)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFUojK(self, txt, title=title)
   else:
    FFDQ9M(self, "Could not obtain URLs from this file list !", title=title)
 def VV40Hs(self):
  path = CCZkJV.VVCIeb()
  lines = FFDp6V('find %s %s -iname "*playlist*" | grep -i ".txt"' % (path, FFGFzp(1)))
  if lines:
   lines.sort()
   VVE6xF = []
   for line in lines:
    VVE6xF.append((line, line))
   OKBtnFnc  = self.VVHH7m
   VVJsRJ = ("Delete File", self.VV7iFA)
   FFtUqp(self, None, title="Select Playlist File", VVE6xF=VVE6xF, width=1200, OKBtnFnc=OKBtnFnc, VVJsRJ=VVJsRJ)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFDQ9M(self, 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt)
 def VVHH7m(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFy61j(menuInstance, boundFunction(self.VVOj2k, menuInstance, path), title="Processing File ...")
 def VVOj2k(self, fileMenuInstance, path):
  enc = CCVXoR.VVJhd6(path, self)
  if enc == -1:
   return
  VV7OA3 = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0]
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFSNlf(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCZkJV.VV5Ehl(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VV7OA3:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(filter(None, [item[5], item[0]]))
     num += 1
     VV7OA3.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VV7OA3:
   title = "Playlist File : %s" % os.path.basename(path)
   VV2mqV  = ("Start"    , boundFunction(self.VVPRqj, "Playlist File"), [])
   VVjx9F = ("Home Menu"   , FF4ANQ          , [])
   VVJlME = ("Download M3U File" , self.VVBPlf      , [])
   VVZ5MP = ("Edit File"   , boundFunction(self.VVtvny, path)  , [])
   VV2x0g = ("Check & Filter"  , boundFunction(self.VVdlCh, fileMenuInstance, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VV9ki4  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFIbZw(self, None, title=title, header=header, VVU7lj=VV7OA3, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=26, VV2mqV=VV2mqV, VVjx9F=VVjx9F, VV2x0g=VV2x0g, VVJlME=VVJlME, VVZ5MP=VVZ5MP, VV6Us0="#11001116", VVezBA="#11001116", VVDUXJ="#11001116", VVTpzJ="#00003635", VVvufb="#0a333333", VVeHz9="#11331100", VVyLkT=True)
  else:
   FFDQ9M(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVBPlf(self, VVoKzZ, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFZhjP(self, boundFunction(FFy61j, VVoKzZ, boundFunction(self.VVlDil, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVlDil(self, title, url):
  path, err = FFZ5gR(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFDQ9M(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFbAeW(path)
   if '{"user_info":{"auth":0}}' in txt:
    os.system(FFGA8O("rm -f '%s'" % path))
    FFDQ9M(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    os.system(FFGA8O("rm -f '%s'" % path))
    FFDQ9M(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCZkJV.VVCIeb(orExportPath=True) + fName
    os.system(FFGA8O("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FFrSV8(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFDQ9M(self, "Could not download the M3U file!", title=errTitle)
 def VVPRqj(self, Title, VVoKzZ, title, txt, colList):
  url = colList[6]
  FFy61j(VVoKzZ, boundFunction(self.VViCv1, Title, url), title="Checking Server ...")
 def VVtvny(self, path, VVoKzZ, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CC5Lyi(self, path, VVG4RV=boundFunction(self.VVTueG, VVoKzZ), curRowNum=rowNum)
  else    : FFC6jW(self, path)
 def VVTueG(self, VVoKzZ, fileChanged):
  if fileChanged:
   VVoKzZ.cancel()
 def VVrECx(self, title):
  curChName = self.VVoKzZ.VVai60(1)
  FFzG9s(self, boundFunction(self.VVfwb4, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVfwb4(self, title, name):
  if name:
   lameDbChans = CCZkgq.VVDUdr(self, CCZkgq.VV2MPi, VVivON=False, VVaPZO=False)
   list = []
   if lameDbChans:
    processChanName = CCyogD()
    name = processChanName.VVxaMb(name)
    ratio = "1"
    for item in lameDbChans:
     if name in item[0].lower():
      list.append((item[0], FFNC3M(item[2]), item[3], ratio))
   if list : self.VVzIME(list, title)
   else : FFDQ9M(self, "Not found:\n\n%s" % name, title=title)
 def VVhPAx(self, title):
  curChName = self.VVoKzZ.VVai60(1)
  self.session.open(CCucls, barTheme=CCucls.VVVMet
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVAgCW
      , VVG4RV = boundFunction(self.VV9DKg, title, curChName))
 def VVAgCW(self, progBarObj):
  curChName = self.VVoKzZ.VVai60(1)
  lameDbChans = CCZkgq.VVDUdr(self, CCZkgq.VV7uJa, VVivON=False, VVaPZO=False)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVaHnU = []
  progBarObj.VVo3zA(len(lameDbChans))
  processChanName = CCyogD()
  curCh = processChanName.VVxaMb(curChName)
  for refCode in lameDbChans:
   chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
   ratio = CC5NMK.VVzCR6(chName.lower(), curCh)
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVCm3j(1, True)
   if progBarObj and ratio > 50:
    progBarObj.VVaHnU.append((chName, FFNC3M(sat), refCode.replace("_", ":"), str(ratio)))
 def VV9DKg(self, title, curChName, VVojmq, VVaHnU, threadCounter, threadTotal, threadErr):
  if VVaHnU: self.VVzIME(VVaHnU, title)
  elif VVojmq: FFDQ9M(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVzIME(self, VV7OA3, title):
  curChName = self.VVoKzZ.VVai60(1)
  curRefCode = self.VVoKzZ.VVai60(4)
  curUrl  = self.VVoKzZ.VVai60(5)
  VV7OA3 = sorted(VV7OA3, key=lambda x: (100-int(x[3]), x[0].lower()))
  VV2mqV  = ("Share Sat/C/T Ref.", boundFunction(self.VVzyMi, title, curChName, curRefCode, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFIbZw(self, None, title=title, header=header, VVU7lj=VV7OA3, VVSkoS=widths, VVhkQh=26, VV2mqV=VV2mqV, VV6Us0="#0a00112B", VVezBA="#0a001126", VVDUXJ="#0a001126", VVTpzJ="#00000000")
 def VVzyMi(self, newtitle, curChName, curRefCode, curUrl, VVoKzZ, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFZhjP(self.VVoKzZ, boundFunction(FFy61j, self.VVoKzZ, boundFunction(self.VVdqHg, VVoKzZ, data)), ques, title=newtitle, VVXqay=True)
 def VVdqHg(self, VVoKzZ, data):
  VVoKzZ.cancel()
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVAoc1():
    txt = FFbAeW(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFY6Ac()
    newRow = []
    for i in range(6):
     newRow.append(self.VVoKzZ.VVai60(i))
    newRow[4] = newRefCode
    done = self.VVoKzZ.VVMRjs(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFt2dO(boundFunction(FFrSV8 , self, resTxt, title=title))
  elif resErr: FFt2dO(boundFunction(FFDQ9M , self, resErr, title=title))
 def VVdlCh(self, fileMenuInstance, path, VVoKzZ, title, txt, colList):
  self.session.open(CCucls, barTheme=CCucls.VVgBcO
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VVNcmS, VVoKzZ)
      , VVG4RV = boundFunction(self.VVpxTI, fileMenuInstance, path, VVoKzZ))
 def VVNcmS(self, VVoKzZ, progBarObj):
  progBarObj.VVo3zA(VVoKzZ.VVcMXW())
  progBarObj.VVaHnU = []
  for row in VVoKzZ.VVtoSt():
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVCm3j(1, True)
   qUrl = self.VVydxv(self.VVIsxY, row[6])
   txt, err = self.VVQVQc(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VV8QZS(item, "auth") == "0":
       progBarObj.VVaHnU.append(qUrl)
    except:
     pass
 def VVpxTI(self, fileMenuInstance, path, VVoKzZ, VVojmq, VVaHnU, threadCounter, threadTotal, threadErr):
  if VVojmq:
   list = VVaHnU
   title = "Authorized Servers"
   if list:
    totChk = VVoKzZ.VVcMXW()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFmDuf()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VV40Hs()
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFcK2v(str(totAuth), VVcGUH)
     txt += "%s\n\n%s"    %  (FFcK2v("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFUojK(self, txt, title=title)
     VVoKzZ.close()
     fileMenuInstance.close()
    else:
     FFrSV8(self, "All URLs are authorized.", title=title)
   else:
    FFDQ9M(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVQVQc(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   cont = res.headers.get("Content-Type")
   if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
    return "", "Unexpected server data type ( %s )" % cont
   res = res.read().decode("UTF-8")
   if res:
    if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server !"
    else           : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VV5Ehl(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVU5fz(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVydxv(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VV5Ehl(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVIsxY   : return "%s"            % url
  elif mode == self.VVptHP   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVM4on   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVk6vH  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVNlNe  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVF9C4 : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVIBxJ   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVP4Qm    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVujxI  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VV8wNK : return "%s&action=get_live_streams"      % url
  elif mode == self.VVGdQW  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VV8QZS(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFtsyU(int(val))
    elif is_base64 : val = FFscG4(val)
    elif isToHHMMSS : val = FFesdJ(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVXI29(self, title, path):
  if fileExists(path):
   enc = CCVXoR.VVJhd6(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = self.VV4dBL(line)
     if qUrl:
      break
   if qUrl : self.VViCv1(title, qUrl)
   else : FFDQ9M(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFDQ9M(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVAO9J_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VV7a9u()
  if qUrl or "chCode" in iptvRef:
   p = CCn4Pa()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVijeK(iptvRef)
   if valid:
    self.VVAO9J(self, host, mac)
    return
   elif qUrl:
    FFy61j(self, boundFunction(self.VViCv1, title, qUrl), title="Checking Server ...")
    return
  FFDQ9M(self, "Error in current channel URL !", title=title)
 def VV7a9u(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self)
  qUrl = self.VV4dBL(decodedUrl)
  return qUrl, iptvRef
 def VV4dBL(self, url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VViCv1(self, title, url):
  self.VV5ueOData = {}
  qUrl = self.VVydxv(self.VVIsxY, url)
  txt, err = self.VVQVQc(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VV5ueOData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VV5ueOData["username"    ] = self.VV8QZS(item, "username"        )
    self.VV5ueOData["password"    ] = self.VV8QZS(item, "password"        )
    self.VV5ueOData["message"    ] = self.VV8QZS(item, "message"        )
    self.VV5ueOData["auth"     ] = self.VV8QZS(item, "auth"         )
    self.VV5ueOData["status"    ] = self.VV8QZS(item, "status"        )
    self.VV5ueOData["exp_date"    ] = self.VV8QZS(item, "exp_date"    , isDate=True )
    self.VV5ueOData["is_trial"    ] = self.VV8QZS(item, "is_trial"        )
    self.VV5ueOData["active_cons"   ] = self.VV8QZS(item, "active_cons"       )
    self.VV5ueOData["created_at"   ] = self.VV8QZS(item, "created_at"   , isDate=True )
    self.VV5ueOData["max_connections"  ] = self.VV8QZS(item, "max_connections"      )
    self.VV5ueOData["allowed_output_formats"] = self.VV8QZS(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VV5ueOData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VV5ueOData["url"    ] = self.VV8QZS(item, "url"        )
    self.VV5ueOData["port"    ] = self.VV8QZS(item, "port"        )
    self.VV5ueOData["https_port"  ] = self.VV8QZS(item, "https_port"      )
    self.VV5ueOData["server_protocol" ] = self.VV8QZS(item, "server_protocol"     )
    self.VV5ueOData["rtmp_port"   ] = self.VV8QZS(item, "rtmp_port"       )
    self.VV5ueOData["timezone"   ] = self.VV8QZS(item, "timezone"       )
    self.VV5ueOData["timestamp_now"  ] = self.VV8QZS(item, "timestamp_now"  , isDate=True )
    self.VV5ueOData["time_now"   ] = self.VV8QZS(item, "time_now"       )
    VVE6xF  = self.VVSbKx(True)
    OKBtnFnc = self.VV5ueOOptions
    VVXOT7 = ("Home Menu", FF4ANQ)
    VVhU9p = ("Bookmark Server", boundFunction(CCZkJV.VVXSig, self, False, self.VV5ueOData["playListURL"]))
    FFtUqp(self, None, title="IPTV Server Resources", VVE6xF=VVE6xF, OKBtnFnc=OKBtnFnc, VVXOT7=VVXOT7, VVhU9p=VVhU9p)
   else:
    err = "Could not get data from server !"
  if err:
   FFDQ9M(self, err, title=title)
  FF7QSu(self)
 def VV5ueOOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFy61j(menuInstance, boundFunction(self.VVJq5m, self.VVptHP  , title=title), title=wTxt)
   elif ref == "vod"   : FFy61j(menuInstance, boundFunction(self.VVJq5m, self.VVM4on  , title=title), title=wTxt)
   elif ref == "series"  : FFy61j(menuInstance, boundFunction(self.VVJq5m, self.VVk6vH , title=title), title=wTxt)
   elif ref == "catchup"  : FFy61j(menuInstance, boundFunction(self.VVJq5m, self.VVNlNe , title=title), title=wTxt)
   elif ref == "accountInfo" : FFy61j(menuInstance, boundFunction(self.VVDL76           , title=title), title=wTxt)
 def VVDL76(self, title):
  rows = []
  for key, val in self.VV5ueOData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VVjx9F  = ("Home Menu", FF4ANQ, [])
  VVJlME  = None
  if VV0DJY:
   VVJlME = ("Get JS" , boundFunction(self.VV06DM, "/".join(self.VV5ueOData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFIbZw(self, None, title=title, width=1200, header=header, VVU7lj=rows, VVSkoS=widths, VVhkQh=26, VVjx9F=VVjx9F, VVJlME=VVJlME, VV6Us0="#0a00292B", VVezBA="#0a002126", VVDUXJ="#0a002126", VVTpzJ="#00000000", searchCol=2)
 def VV2Ynv(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CCyogD()
    if mode in (self.VVIBxJ, self.VVGdQW):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VV8QZS(item, "num"         )
      name     = self.VV8QZS(item, "name"        )
      stream_id    = self.VV8QZS(item, "stream_id"       )
      stream_icon    = self.VV8QZS(item, "stream_icon"       )
      epg_channel_id   = self.VV8QZS(item, "epg_channel_id"      )
      added     = self.VV8QZS(item, "added"    , isDate=True )
      is_adult    = self.VV8QZS(item, "is_adult"       )
      category_id    = self.VV8QZS(item, "category_id"       )
      tv_archive    = self.VV8QZS(item, "tv_archive"       )
      name = processChanName.VVqxfD(name)
      if name:
       if mode == self.VVIBxJ or mode == self.VVGdQW and tv_archive == "1":
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVP4Qm:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VV8QZS(item, "num"         )
      name    = self.VV8QZS(item, "name"        )
      stream_id   = self.VV8QZS(item, "stream_id"       )
      stream_icon   = self.VV8QZS(item, "stream_icon"       )
      added    = self.VV8QZS(item, "added"    , isDate=True )
      is_adult   = self.VV8QZS(item, "is_adult"       )
      category_id   = self.VV8QZS(item, "category_id"       )
      container_extension = self.VV8QZS(item, "container_extension"     ) or "mp4"
      name = processChanName.VVqxfD(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVujxI:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VV8QZS(item, "num"        )
      name    = self.VV8QZS(item, "name"       )
      series_id   = self.VV8QZS(item, "series_id"      )
      cover    = self.VV8QZS(item, "cover"       )
      genre    = self.VV8QZS(item, "genre"       )
      episode_run_time = self.VV8QZS(item, "episode_run_time"    )
      category_id   = self.VV8QZS(item, "category_id"      )
      container_extension = self.VV8QZS(item, "container_extension"    ) or "mp4"
      name = processChanName.VVqxfD(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVJq5m(self, mode, title):
  cList, err = self.VVliZY(mode)
  if cList and mode == self.VVNlNe:
   cList = self.VVRDi7(cList)
  if err:
   FFDQ9M(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VV6Us0, VVezBA, VVDUXJ, VVTpzJ = self.VVyQAw(mode)
   mName = self.VVbJvq(mode)
   if   mode == self.VVptHP  : fMode = self.VVIBxJ
   elif mode == self.VVM4on  : fMode = self.VVP4Qm
   elif mode == self.VVk6vH : fMode = self.VVujxI
   elif mode == self.VVNlNe : fMode = self.VVGdQW
   if mode == self.VVNlNe:
    VVZ5MP = None
   else:
    VVZ5MP = ("Find in %s" % mName , boundFunction(self.VVUMRk, fMode) , [])
   VV2mqV   = ("Show List"   , boundFunction(self.VVr8tB, mode) , [])
   VVjx9F  = ("Home Menu"   , FF4ANQ          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFIbZw(self, None, title=title, width=1200, header=header, VVU7lj=cList, VVSkoS=widths, VVhkQh=30, VVjx9F=VVjx9F, VVZ5MP=VVZ5MP, VV2mqV=VV2mqV, VV6Us0=VV6Us0, VVezBA=VVezBA, VVDUXJ=VVDUXJ, VVTpzJ=VVTpzJ)
  else:
   FFDQ9M(self, "No list from server !", title=title)
  FF7QSu(self)
 def VVliZY(self, mode):
  qUrl  = self.VVydxv(mode, self.VV5ueOData["playListURL"])
  txt, err = self.VVQVQc(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    processChanName = CCyogD()
    for item in tDict:
     category_id  = self.VV8QZS(item, "category_id"  )
     category_name = self.VV8QZS(item, "category_name" )
     parent_id  = self.VV8QZS(item, "parent_id"  )
     category_name = processChanName.VVArKJ(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVRDi7(self, catList):
  mode  = self.VVGdQW
  qUrl  = self.VVydxv(mode, self.VV5ueOData["playListURL"])
  txt, err = self.VVQVQc(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VV2Ynv(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVr8tB(self, mode, VVoKzZ, title, txt, colList):
  title = colList[1]
  FFy61j(VVoKzZ, boundFunction(self.VVZa9V, mode, VVoKzZ, title, txt, colList), title="Downloading ...")
 def VVZa9V(self, mode, VVoKzZ, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVbJvq(mode) + " : "+ bName
  if   mode == self.VVptHP  : mode = self.VVIBxJ
  elif mode == self.VVM4on  : mode = self.VVP4Qm
  elif mode == self.VVk6vH : mode = self.VVujxI
  elif mode == self.VVNlNe : mode = self.VVGdQW
  qUrl  = self.VVydxv(mode, self.VV5ueOData["playListURL"], catID)
  txt, err = self.VVQVQc(qUrl)
  list  = []
  if not err and mode in (self.VVIBxJ, self.VVP4Qm, self.VVujxI, self.VVGdQW):
   list, err = self.VV2Ynv(mode, txt)
  if err:
   FFDQ9M(self, err, title=title)
  elif list:
   VVjx9F  = ("Home Menu"   , FF4ANQ             , [])
   if mode in (self.VVIBxJ, self.VVGdQW):
    VV6Us0, VVezBA, VVDUXJ, VVTpzJ = self.VVyQAw(mode)
    VVmEVe = (""     , boundFunction(self.VV4leQ, mode)     , [])
    VVJlME = ("Download Options" , boundFunction(self.VVPte5, mode, "", "")  , [])
    VVZ5MP = ("Options" , boundFunction(self.VViKMU, 1, "lv", mode, bName)  , [])
    if mode == self.VVIBxJ:
     VV2mqV = ("Play"    , boundFunction(self.VVjxRN, mode)     , [])
    elif mode == self.VVGdQW:
     VV2mqV  = ("Programs", boundFunction(self.VVnqez_fromIptvTable, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VV9ki4  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVP4Qm:
    VV6Us0, VVezBA, VVDUXJ, VVTpzJ = self.VVyQAw(mode)
    VV2mqV  = ("Play"    , boundFunction(self.VVjxRN, mode)    , [])
    VVmEVe = (""     , boundFunction(self.VV4leQ, mode)    , [])
    VVJlME = ("Download Options" , boundFunction(self.VVPte5, mode, "v", ""), [])
    VVZ5MP = ("Options" , boundFunction(self.VViKMU, 1, "v", mode, bName)  , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VV9ki4  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVujxI:
    VV6Us0, VVezBA, VVDUXJ, VVTpzJ = self.VVyQAw("series2")
    VV2mqV  = ("Show Seasons", boundFunction(self.VViDjk, mode) , [])
    VVmEVe = ("", boundFunction(self.VVnZX6, mode)  , [])
    VVJlME = None
    VVZ5MP = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VV9ki4  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFIbZw(self, None, title=title, header=header, VVU7lj=list, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=26, VV2mqV=VV2mqV, VVjx9F=VVjx9F, VVJlME=VVJlME, VVZ5MP=VVZ5MP, VVmEVe=VVmEVe, VV6Us0=VV6Us0, VVezBA=VVezBA, VVDUXJ=VVDUXJ, VVTpzJ=VVTpzJ, VVyLkT=True, searchCol=1)
  else:
   FFDQ9M(self, "No Channels found !", title=title)
  FF7QSu(self)
 def VVnqez_fromIptvTable(self, mode, bName, VVoKzZ, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VV5ueOData["playListURL"]
  ok_fnc  = boundFunction(self.VV1O9M, hostUrl, chName, catId, streamId)
  FFy61j(VVoKzZ, boundFunction(CCZkJV.VVnqez, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VV1O9M(self, chUrl, chName, catId, streamId, VVoKzZ, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCZkJV.VV5Ehl(chUrl)
   chNum = "333"
   refCode = CCZkJV.VVZway(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFI7Gq(self, chUrl, VVetCj=False)
   self.session.open(CCZOmQ)
  else:
   FFDQ9M(self, "Incorrect Timestamp", pTitle)
 def VViDjk(self, mode, VVoKzZ, title, txt, colList):
  title = colList[1]
  FFy61j(VVoKzZ, boundFunction(self.VVeodc, mode, VVoKzZ, title, txt, colList), title="Downloading ...")
 def VVeodc(self, mode, VVoKzZ, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVydxv(self.VVF9C4, self.VV5ueOData["playListURL"], series_id)
  txt, err = self.VVQVQc(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VV8QZS(tDict["info"], "name"   )
      category_id = self.VV8QZS(tDict["info"], "category_id" )
      icon  = self.VV8QZS(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      processChanName = CCyogD()
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VV8QZS(EP, "id"     )
        episode_num   = self.VV8QZS(EP, "episode_num"   )
        epTitle    = self.VV8QZS(EP, "title"     )
        container_extension = self.VV8QZS(EP, "container_extension" )
        seasonNum   = self.VV8QZS(EP, "season"    )
        epTitle = processChanName.VVqxfD(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFDQ9M(self, err, title=title)
  elif list:
   VVjx9F = ("Home Menu"   , FF4ANQ             , [])
   VVJlME = ("Download Options" , boundFunction(self.VVPte5, mode, "s", title) , [])
   VVZ5MP = ("Options" , boundFunction(self.VViKMU, 0, "s", mode, title)  , [])
   VVmEVe = (""     , boundFunction(self.VV4leQ, mode)     , [])
   VV2mqV  = ("Play"    , boundFunction(self.VVjxRN, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VV9ki4  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFIbZw(self, None, title=title, header=header, VVU7lj=list, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=26, VVjx9F=VVjx9F, VVJlME=VVJlME, VV2mqV=VV2mqV, VVmEVe=VVmEVe, VVZ5MP=VVZ5MP, VV6Us0="#0a00292B", VVezBA="#0a002126", VVDUXJ="#0a002126", VVTpzJ="#00000000")
  else:
   FFDQ9M(self, "No Channels found !", title=title)
  FF7QSu(self)
 def VVUMRk(self, mode, VVoKzZ, title, txt, colList):
  VVE6xF = []
  VVE6xF.append(("Keyboard"  , "manualEntry"))
  VVE6xF.append(("From Filter" , "fromFilter"))
  FFtUqp(self, boundFunction(self.VVRHin, VVoKzZ, mode), title="Input Type", VVE6xF=VVE6xF, width=400)
 def VVRHin(self, VVoKzZ, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFzG9s(self, boundFunction(self.VVg8Vu, VVoKzZ, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CC2Xqg(self)
    filterObj.VVfaak(boundFunction(self.VVg8Vu, VVoKzZ, mode))
 def VVg8Vu(self, VVoKzZ, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CCyogD()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVWsz1(words):
     FFDQ9M(self, processChanName.VVimQm(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CCucls, barTheme=CCucls.VVVMet
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VVrTno, VVoKzZ, mode, title, words, toFind, asPrefix, processChanName)
         , VVG4RV = boundFunction(self.VVQS0P, mode, toFind, title))
   else:
    FFDQ9M(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VVrTno(self, VVoKzZ, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVo3zA(VVoKzZ.VVLYac())
  progBarObj.VVaHnU = []
  for row in VVoKzZ.VVtoSt():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVCm3j(1)
   progBarObj.VVzckZ_fromIptvFind(catName)
   qUrl  = self.VVydxv(mode, self.VV5ueOData["playListURL"], catID)
   txt, err = self.VVQVQc(qUrl)
   if not err:
    tList, err = self.VV2Ynv(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VVqxfD(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VVIBxJ:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VVaHnU.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVP4Qm:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VVaHnU.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVujxI:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VVaHnU.append((num, name, catID, ID, genre, catName, ext, cover))
 def VVQS0P(self, mode, toFind, title, VVojmq, VVaHnU, threadCounter, threadTotal, threadErr):
  if VVaHnU:
   title = self.VVam07(mode, toFind)
   if mode == self.VVIBxJ or mode == self.VVP4Qm:
    if mode == self.VVP4Qm : typ = "v"
    else          : typ = ""
    bName   = CCZkJV.VVUGxW_forBouquet(toFind)
    VV2mqV  = ("Play"     , boundFunction(self.VVjxRN, mode)    , [])
    VVJlME = ("Download Options" , boundFunction(self.VVPte5, mode, typ, ""), [])
    VVZ5MP = ("Options" , boundFunction(self.VViKMU, 1, "fnd", mode, bName)  , [])
   elif mode == self.VVujxI:
    VV2mqV  = ("Show Seasons"  , boundFunction(self.VViDjk, mode)    , [])
    VVZ5MP = None
    VVJlME = None
   VVmEVe  = (""     , boundFunction(self.VV4leQ, mode)    , [])
   VVjx9F  = ("Home Menu"   , FF4ANQ            , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VV9ki4  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVoKzZ = FFIbZw(self, None, title=title, header=header, VVU7lj=VVaHnU, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=26, VV2mqV=VV2mqV, VVjx9F=VVjx9F, VVJlME=VVJlME, VVZ5MP=VVZ5MP, VVmEVe=VVmEVe, VV6Us0="#0a00292B", VVezBA="#0a002126", VVDUXJ="#0a002126", VVTpzJ="#00000000", VVyLkT=True, searchCol=1)
   if not VVojmq:
    FF7QSu(VVoKzZ, "Stopped" , 1000)
  else:
   if VVojmq:
    FFDQ9M(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVT2o1(self, mode, colList):
  if mode in (self.VVIBxJ, self.VVGdQW):
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVP4Qm:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FF67wV(chName)
  url = self.VV5ueOData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VV5Ehl(url)
  refCode = self.VVZway(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VV4leQ(self, mode, VVoKzZ, title, txt, colList):
  FFy61j(VVoKzZ, boundFunction(self.VV3lxK, mode, VVoKzZ, title, txt, colList))
 def VV3lxK(self, mode, VVoKzZ, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVT2o1(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFvad7(self, fncMode=CCzqpW.VVmJif, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVnZX6(self, mode, VVoKzZ, title, txt, colList):
  FFy61j(VVoKzZ, boundFunction(self.VVwD5H, mode, VVoKzZ, title, txt, colList))
 def VVwD5H(self, mode, VVoKzZ, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFvad7(self, fncMode=CCzqpW.VVK2JV, chName=name, text=txt, picUrl=Cover)
 def VVDJTX(self, mode, bName, VVoKzZ, title, txt, colList):
  url = self.VV5ueOData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VV5Ehl(url)
  bNameFile = CCZkJV.VVUGxW_forBouquet(bName)
  num  = 0
  path = VVDNL1 + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVDNL1 + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   isMulti = VVoKzZ.VVf82F
   for ndx, row in enumerate(VVoKzZ.VVtoSt()):
    chName, chUrl, picUrl, refCode = self.VVT2o1(mode, row)
    if not isMulti or VVoKzZ.VVeIuQ(ndx):
     f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
     f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
     totChange += 1
  FFixCI(os.path.basename(path))
  self.VVZCMs(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVPte5(self, mode, typ, seriesName, VVoKzZ, title, txt, colList):
  VVE6xF = []
  isMulti = VVoKzZ.VVf82F
  tot  = VVoKzZ.VVIqO1()
  if isMulti:
   if tot < 1:
    FF7QSu(VVoKzZ, "Select rows first.", 1000)
    return
   else:
    s = "s" if tot > 1 else ""
    name = "%d Selected" % tot
  else:
   s = "s"
   name = "ALL"
  VVE6xF.append(("Download %s PIcon%s" % (name, s), "dnldPicons" ))
  if typ:
   VVE6xF.append(VVBgIm)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVE6xF.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVE6xF.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVE6xF.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCRR2A.VVaulr():
    VVE6xF.append(VVBgIm)
    VVE6xF.append(("Download Manager"      , "dload_stat" ))
  FFtUqp(self, boundFunction(self.VV6P0F_VVpjlc, VVoKzZ, mode, typ, seriesName, colList), title="Download Options", VVE6xF=VVE6xF)
 def VV6P0F_VVpjlc(self, VVoKzZ, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVVjbM(VVoKzZ, mode)
   elif item == "dnldSel"  : self.VVtyX8(VVoKzZ, mode, typ, colList, True)
   elif item == "addSel"  : self.VVtyX8(VVoKzZ, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVb5ba(VVoKzZ, mode, typ, seriesName)
   elif item == "dload_stat" : CCRR2A.VVjaLW(self)
 def VVtyX8(self, VVoKzZ, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VV2rCx(mode, typ, colList)
  if startDnld:
   CCRR2A.VVcSSy_url(self, decodedUrl)
  else:
   self.VVpjlc_FFZhjP(VVoKzZ, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVb5ba(self, VVoKzZ, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVoKzZ.VVtoSt():
   chName, decodedUrl = self.VV2rCx(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVpjlc_FFZhjP(VVoKzZ, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVpjlc_FFZhjP(self, VVoKzZ, title, chName, decodedUrl_list, startDnld):
  FFZhjP(self, boundFunction(self.VVupl1, VVoKzZ, decodedUrl_list, startDnld), chName, title=title)
 def VVupl1(self, VVoKzZ, decodedUrl_list, startDnld):
  added, skipped = CCRR2A.VVa8VWList(decodedUrl_list)
  FF7QSu(VVoKzZ, "Added", 1000)
 def VV2rCx(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVT2o1(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVcbEI(mode, colList)
   refCode, chUrl = self.VV33XY(self.VVYPQ6, self.VVfXoU, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFhxAo(chUrl)
  return chName, decodedUrl
 def VVVjbM(self, VVoKzZ, mode):
  if os.system(FFGA8O("which ffmpeg")) == 0:
   self.session.open(CCucls, barTheme=CCucls.VVgBcO
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VV8n5c, VVoKzZ, mode)
       , VVG4RV = self.VVXJ7N)
  else:
   FFZhjP(self, boundFunction(CCZkJV.VV9wix, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVXJ7N(self, VVojmq, VVaHnU, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVaHnU["proces"], VVaHnU["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVaHnU["ok"], VVaHnU["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVaHnU["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVaHnU["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVaHnU["badURL"]
  txt += "Download Failure\t: %d\n"   % VVaHnU["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVaHnU["path"]
  if not VVojmq  : color = "#11402000"
  elif VVaHnU["err"]: color = "#11201000"
  else     : color = None
  if VVaHnU["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVaHnU["err"], txt)
  title = "PIcons Download Result"
  if not VVojmq:
   title += "  (cancelled)"
  FFUojK(self, txt, title=title, VVDUXJ=color)
 def VV8n5c(self, VVoKzZ, mode, progBarObj):
  isMulti = VVoKzZ.VVf82F
  if isMulti : totRows = VVoKzZ.VVIqO1()
  else  : totRows = VVoKzZ.VVLYac()
  progBarObj.VVo3zA(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CC5NMK.VVBX3T()
  progBarObj.VVaHnU = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for rowNum, row in enumerate(VVoKzZ.VVtoSt()):
    if progBarObj.isCancelled:
     break
    if not isMulti or VVoKzZ.VVeIuQ(rowNum):
     progBarObj.VVaHnU["proces"] += 1
     progBarObj.VVCm3j(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVcbEI(mode, row)
      refCode = CCZkJV.VVZway(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VV51Pw(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVT2o1(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       progBarObj.VVaHnU["attempt"] += 1
       path, err = FFZ5gR(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        progBarObj.VVaHnU["ok"] += 1
        if FFLJ49(path) > 0:
         cmd = ""
         if not mode == CCZkJV.VVIBxJ:
          cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
         cmd += FFGA8O("mv -f '%s' '%s'" % (path, pPath)) + ";"
         os.system(cmd)
        else:
         progBarObj.VVaHnU["size0"] += 1
         os.system(FFGA8O("rm -f '%s'" % path))
       elif err:
        progBarObj.VVaHnU["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         progBarObj.VVaHnU["err"] = err.title()
         break
      else:
       progBarObj.VVaHnU["exist"] += 1
     else:
      progBarObj.VVaHnU["badURL"] += 1
  except:
   pass
 @staticmethod
 def VV9wix(SELF):
  cmd = FFH2eT(VVOR4D, "ffmpeg")
  if cmd : FFR9ZE(SELF, cmd, title="Installing FFmpeg")
  else : FFVSFz(SELF)
 def VVqHm9(self):
  self.session.open(CCucls, barTheme=CCucls.VVgBcO
      , titlePrefix = ""
      , fncToRun  = self.VVEqe2
      , VVG4RV = self.VV0wa7)
 def VVEqe2(self, progBarObj):
  bName = FF7F8X()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  progBarObj.VVaHnU = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = FFzK2b()
  if not progBarObj or progBarObj.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   progBarObj.VVo3zA(totCh)
   for serv in services:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVCm3j(1)
    progBarObj.VVzckZ_fromImportEPG(totEpgOK, uChName)
    fullRef  = serv[0]
    if FFMLue(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFhxAo(fullRef)
     span = iSearch(r"(mode=.+end=)", fullRef, IGNORECASE)
     if span:
      m3u_Url = CCn4Pa.VVLk1m(fullRef)
      uType, uHost, uUser, uPass, uId, uChName  = CCZkJV.VVU5fz(fullRef)
      uType, uHost, uUser, uPass, uId, uChName1 = CCZkJV.VVU5fz(m3u_Url)
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCZkJV.VVU5fz(m3u_Url)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCZkJV.VVNw1N(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCzqpW.VVhCTV(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
      else:
       pass
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if progBarObj:
     progBarObj.VVaHnU = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   progBarObj.VVaHnU = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VV0wa7(self, VVojmq, VVaHnU, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVaHnU
  title = "IPTV EPG Import"
  if err:
   FFDQ9M(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFcK2v(str(totNotIptv), VVII83)
    if totServErr : txt += "Server Errors\t: %s\n" % FFcK2v(str(totServErr) + t1, VVII83)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFcK2v(str(totInv), VVII83)
   if not VVojmq:
    title += "  (stopped)"
   FFUojK(self, txt, title=title)
 @staticmethod
 def VVNw1N(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCZkJV.VV5Ehl(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCZkJV.VVQVQc(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCZkJV.VV8QZS(item, "description" , is_base64=True ).replace("\n", " .. ")
    has_archive   = CCZkJV.VV8QZS(item, "has_archive"      )
    lang    = CCZkJV.VV8QZS(item, "lang"        ).upper()
    now_playing   = CCZkJV.VV8QZS(item, "now_playing"      )
    start    = CCZkJV.VV8QZS(item, "start"        )
    start_timestamp  = CCZkJV.VV8QZS(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCZkJV.VV8QZS(item, "start_timestamp"     )
    stop_timestamp  = CCZkJV.VV8QZS(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCZkJV.VV8QZS(item, "stop_timestamp"      )
    tTitle    = CCZkJV.VV8QZS(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVZway(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCZkJV.VVwjUf(catID, MAX_4b)
  TSID = CCZkJV.VVwjUf(chNum, MAX_4b)
  ONID = CCZkJV.VVwjUf(chNum, MAX_4b)
  NS  = CCZkJV.VVwjUf(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVwjUf(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVUGxW_forBouquet(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVyQAw(mode):
  if   mode in ("itv"  , CCZkJV.VVptHP)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCZkJV.VVM4on)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCZkJV.VVk6vH) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCZkJV.VVNlNe) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCZkJV.VVGdQW    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 @staticmethod
 def VVCIeb(orExportPath=False):
  path = CFG.iptvHostsPath.getValue()
  if not pathExists(path) or path == VVyIDW:
   if orExportPath : path = CFG.exportedTablesPath.getValue()
   else   : path ="/"
  return FFSNlf(path)
 @staticmethod
 def VVnqez(SELF, hostUrl, chName, streamId, ok_fnc):
  title = "Catchup TV Programs"
  pList, err = CCZkJV.VVNw1N(hostUrl, streamId, True)
  if err:
   FFDQ9M(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VV6Us0, VVezBA, VVDUXJ, VVTpzJ = CCZkJV.VVyQAw("")
   VVjx9F = ("Home Menu" , FF4ANQ, [])
   VV2mqV  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VV9ki4  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFIbZw(SELF, None, title="Programs for : " + chName, header=header, VVU7lj=pList, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=24, VV2mqV=VV2mqV, VVjx9F=VVjx9F, VV6Us0=VV6Us0, VVezBA=VVezBA, VVDUXJ=VVDUXJ, VVTpzJ=VVTpzJ)
  else:
   FFDQ9M(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVr7z3(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 @staticmethod
 def VVXSig(SELF, isPortal, line, VVtbO0Obj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCZkJV.VVCIeb(orExportPath=True)
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFDQ9M(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFrSV8(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFDQ9M(SELF, "Error:\n\n%s" % str(e), title=title)
 def VViKMU(self, nameCol, source, mode, bName, VVoKzZ, title, txt, colList):
  isMulti = VVoKzZ.VVf82F
  mSel = CCFJmT(self, VVoKzZ, nameCol, addSep=False)
  title = ""
  if isMulti:
   tot = VVoKzZ.VVIqO1()
   if tot > 0:
    s = "s" if tot > 1 else ""
    title = "Add %d Service%s to Bouquet" % (tot, s)
  else:
   title = "Add ALL to Bouquet"
  if title:
   mSel.VVE6xF.append(VVBgIm)
   mSel.VVE6xF.append((title        , "addToBoquet"))
  FFtUqp(self, boundFunction(self.VVpSrP, mSel, source, mode, bName, VVoKzZ, title, txt, colList), title="Options", VVE6xF=mSel.VVE6xF)
 def VVpSrP(self, mSelObj, source, mode, bName, VVoKzZ, title, txt, colList, item):
  if item:
   if   item == "multSelEnab"     : mSelObj.VVoKzZ.VVFiCZ(True)
   elif item == "MultSelDisab"     : mSelObj.VVoKzZ.VVFiCZ(False)
   elif item == "selectAll"     : mSelObj.VVoKzZ.VVEEsl()
   elif item == "unselectAll"     : mSelObj.VVoKzZ.VVueCg()
   elif item == "addToBoquet"     :
    if   source == "pEp" : fnc = self.VV0iPI
    elif source == "pCh" : fnc = self.VV0iPI
    elif source == "m3Ch" : fnc = self.VVAFo2
    elif source == "lv"  : fnc = self.VVDJTX
    elif source == "v"  : fnc = self.VVDJTX
    elif source == "s"  : fnc = self.VVDJTX
    elif source == "fnd" : fnc = self.VVDJTX
    else     : return
    FFy61j(VVoKzZ, boundFunction(fnc, mode, bName, VVoKzZ, title, txt, colList), title="Adding Channels ...")
class CCbxwm(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFoyhf(VVQLSY, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVjeuz  = 0
  self.VVP6bJ = 1
  self.VVU4NK  = 2
  VVE6xF = []
  VVE6xF.append(("Find in All Service (from filter)" , "VVtXGc" ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Find in All (Manual Entry)"   , "VVGPqk"    ))
  VVE6xF.append(("Find in TV"       , "VVzxPc"    ))
  VVE6xF.append(("Find in Radio"      , "VV69Ol"   ))
  if self.VVojoC():
   VVE6xF.append(VVBgIm)
   VVE6xF.append(("Hide Channel: %s" % self.servName , "VV6IaA"   ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Zap History"       , "VVAngt"    ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("IPTV Tools"       , "iptv"      ))
  VVE6xF.append(("PIcons Tools"       , "PIconsTools"     ))
  VVE6xF.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FF8NiA(self, VVE6xF=VVE6xF, title=title)
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFCnHd(self["myMenu"])
  FFoto4(self)
  if self.isFindMode:
   self.VVRQ6C(self.VVA4E8())
 def VVWw2Z(self):
  global VVsFSY
  VVsFSY = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVGPqk"    : self.VVGPqk()
   elif item == "VVtXGc" : self.VVtXGc()
   elif item == "VVzxPc"    : self.VVzxPc()
   elif item == "VV69Ol"   : self.VV69Ol()
   elif item == "VV6IaA"   : self.VV6IaA()
   elif item == "VVAngt"    : self.VVAngt()
   elif item == "iptv"       : self.session.open(CCZkJV)
   elif item == "PIconsTools"     : self.session.open(CC5NMK)
   elif item == "ChannelsTools"    : self.session.open(CCZkgq)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVzxPc(self) : self.VVRQ6C(self.VVjeuz)
 def VV69Ol(self) : self.VVRQ6C(self.VVP6bJ)
 def VVGPqk(self) : self.VVRQ6C(self.VVU4NK)
 def VVRQ6C(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFzG9s(self, boundFunction(self.VVdcmp, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVtXGc(self):
  filterObj = CC2Xqg(self)
  filterObj.VVfaak(self.VV2Agc)
 def VV2Agc(self, item):
  self.VVdcmp(self.VVU4NK, item)
 def VVojoC(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFMLue(self.refCode)        : return False
  return True
 def VVdcmp(self, mode, VVwbfP):
  FFy61j(self, boundFunction(self.VVXcQE, mode, VVwbfP), title="Searching ...")
 def VVXcQE(self, mode, VVwbfP):
  if VVwbfP:
   self.findTxt = VVwbfP
   if   mode == self.VVjeuz  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVP6bJ : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVwbfP)
   if len(title) > 55:
    title = title[:55] + ".."
   VV7OA3 = self.VV1IhJ(VVwbfP, servTypes)
   if self.isFindMode or mode == self.VVU4NK:
    VV7OA3 += self.VVFIct(VVwbfP)
   if VV7OA3:
    VV7OA3.sort(key=lambda x: x[0].lower())
    VVu2WP = self.VVMXQ1
    VV2mqV  = ("Zap"   , self.VVS2a7    , [])
    VVJlME = ("Current Service", self.VVaedT , [])
    VVZ5MP = ("Options"  , self.VV6nB5 , [])
    VVmEVe = (""    , self.VVVCuJ , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VV9ki4  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFIbZw(self, None, title=title, header=header, VVU7lj=VV7OA3, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=26, VV2mqV=VV2mqV, VVu2WP=VVu2WP, VVJlME=VVJlME, VVZ5MP=VVZ5MP, VVmEVe=VVmEVe)
   else:
    self.VVRQ6C(self.VVA4E8())
    FFrSV8(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VV1IhJ(self, VVwbfP, servTypes):
  VV7OA3 = []
  if CCZkgq.VVgkHK(servTypes):
   VVomQx, VVSuGF = FFPELm()
   tp   = CCKps4()
   words, asPrefix = CC2Xqg.VVHOBM(VVwbfP)
   colorYellow  = CCtmPK.VVtmem(VVuneX)
   colorWhite  = CCtmPK.VVtmem(VVKQBm)
   for s in VVU7lj:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFGGpm(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVomQx:
        STYPE = VVSuGF[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVHuCR(refCode)
       if not "-S" in syst:
        sat = syst
       VV7OA3.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VV7OA3
 def VVFIct(self, VVwbfP):
  VVwbfP = VVwbfP.lower()
  VV7OA3 = []
  colorYellow  = CCtmPK.VVtmem(VVuneX)
  colorWhite  = CCtmPK.VVtmem(VVKQBm)
  for b in FFEhoo():
   VV3JU1  = b[0]
   VVG98c  = b[1].toString()
   VVJ9Td = eServiceReference(VVG98c)
   VVJTTD = FFnpqA(VVJ9Td)
   for service in VVJTTD:
    refCode  = service[0]
    if FFMLue(refCode):
     servName = service[1]
     if VVwbfP in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVwbfP), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VV7OA3.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VV7OA3
 def VVA4E8(self):
  VV6H2w = InfoBar.instance
  if VV6H2w:
   VVD1Bc = VV6H2w.servicelist
   if VVD1Bc:
    return VVD1Bc.mode == 1
  return self.VVU4NK
 def VVMXQ1(self, VVoKzZ):
  self.close()
  VVoKzZ.cancel()
 def VVS2a7(self, VVoKzZ, title, txt, colList):
  FFI7Gq(VVoKzZ, colList[2], VVetCj=False, checkParentalControl=True)
 def VVaedT(self, VVoKzZ, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(VVoKzZ)
  if refCode:
   VVoKzZ.VVayhx(2, FFJ5i5(refCode, iptvRef, chName), True)
 def VV6nB5(self, VVoKzZ, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CCFJmT(self, VVoKzZ, 2)
  mSel.VVsxzH(servName, refCode)
 def VVVCuJ(self, VVoKzZ, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFvad7(self, fncMode=CCzqpW.VVYF8W, refCode=refCode, chName=chName, text=txt)
 def VV6IaA(self):
  FFZhjP(self, self.VVefZs, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVefZs(self):
  ret = FF5nBZ(self.refCode, True)
  if ret:
   self.VVHYXk()
   self.close()
  else:
   FF7QSu(self, "Cannot change state" , 1000)
 def VVHYXk(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVuqwn()
  except:
   self.VVFCrt()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFEdjA(self, serviceRef)
 def VVBC6S(self):
  VV6H2w = InfoBar.instance
  if VV6H2w:
   VVD1Bc = VV6H2w.servicelist
   if VVD1Bc:
    VVD1Bc.setMode()
 def VVuqwn(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VV6H2w = InfoBar.instance
   if VV6H2w:
    VVD1Bc = VV6H2w.servicelist
    if VVD1Bc:
     hList = VVD1Bc.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVD1Bc.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVD1Bc.history  = newList
       VVD1Bc.history_pos = pos
 def VVFCrt(self):
  VV6H2w = InfoBar.instance
  if VV6H2w:
   VVD1Bc = VV6H2w.servicelist
   if VVD1Bc:
    VVD1Bc.history  = []
    VVD1Bc.history_pos = 0
 def VVAngt(self):
  VV6H2w = InfoBar.instance
  VV7OA3 = []
  if VV6H2w:
   VVD1Bc = VV6H2w.servicelist
   if VVD1Bc:
    VVomQx, VVSuGF = FFPELm()
    for chParams in VVD1Bc.history:
     refCode = chParams[-1].toString()
     chName = FF3Swx(refCode)
     isIptv = FFMLue(refCode)
     if isIptv: sat = "-"
     else  : sat = FFGGpm(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVomQx:
       STYPE = VVSuGF[sTypeInt]
     VV7OA3.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VV7OA3:
   VV2mqV  = ("Zap"   , self.VVZsyN   , [])
   VVZ5MP = ("Clear History" , self.VVRyDu   , [])
   VVmEVe = (""    , self.VV9hLhFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VV9ki4  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFIbZw(self, None, title=title, header=header, VVU7lj=VV7OA3, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=28, VV2mqV=VV2mqV, VVZ5MP=VVZ5MP, VVmEVe=VVmEVe)
  else:
   FFrSV8(self, "Not found", title=title)
 def VVZsyN(self, VVoKzZ, title, txt, colList):
  FFI7Gq(VVoKzZ, colList[3], VVetCj=False, checkParentalControl=True)
 def VVRyDu(self, VVoKzZ, title, txt, colList):
  FFZhjP(self, boundFunction(self.VVZ7dF, VVoKzZ), "Clear Zap History ?")
 def VVZ7dF(self, VVoKzZ):
  self.VVFCrt()
  VVoKzZ.cancel()
 def VV9hLhFromZapHistory(self, VVoKzZ, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFvad7(self, fncMode=CCzqpW.VVUVhT, refCode=refCode, chName=chName, text=txt)
class CC5NMK(Screen):
 VV2tGI   = 0
 VVGFWB  = 1
 VV3oBX  = 2
 VV9MK6  = 3
 VVK3kL  = 4
 VVgp2R  = 5
 VVhouu  = 6
 VVWQWe  = 7
 VVhQwy = 8
 VVjMRQ = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFoyhf(VVCv21, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FF8NiA(self, self.Title)
  FFUWFF(self["keyRed"] , "OK = Zap")
  FFUWFF(self["keyGreen"] , "Current Service")
  FFUWFF(self["keyYellow"], "Page Options")
  FFUWFF(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CC5NMK.VVBX3T()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVU7lj    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVMS1B        ,
   "green"   : self.VVFiKw       ,
   "yellow"  : self.VVIwhC        ,
   "blue"   : self.VVBdcO        ,
   "menu"   : self.VVZ2Lz        ,
   "info"   : self.VV9hLh         ,
   "up"   : self.VV860S          ,
   "down"   : self.VV1G2T         ,
   "left"   : self.VVjnNT         ,
   "right"   : self.VV04H7         ,
   "pageUp"  : boundFunction(self.VVuaNU, True) ,
   "chanUp"  : boundFunction(self.VVuaNU, True) ,
   "pageDown"  : boundFunction(self.VVuaNU, False) ,
   "chanDown"  : boundFunction(self.VVuaNU, False) ,
   "next"   : self.VV935a        ,
   "last"   : self.VV7lIH         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFu654(self)
  FFvFrO(self)
  FFH6QJ(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFy61j(self, boundFunction(self.VVrpcN, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVZ2Lz(self):
  if not self.isBusy:
   VVE6xF = []
   VVE6xF.append(("Statistics"           , "VVVhsE"    ))
   VVE6xF.append(VVBgIm)
   VVE6xF.append(("Suggest PIcons for Current Channel"     , "VVnWJ6"   ))
   VVE6xF.append(("Set to Current Channel (copy file)"     , "VVLQEF_file"  ))
   VVE6xF.append(("Set to Current Channel (as SymLink)"     , "VVLQEF_link"  ))
   VVE6xF.append(VVBgIm)
   VVE6xF.append(CC5NMK.VVBy0r())
   VVE6xF.append(VVBgIm)
   if self.filterTitle == "PIcons without Channels":
    c = VVII83
    VVE6xF.append((FFcK2v("Move Unused PIcons to a Directory", c) , "VViSzT"  ))
    VVE6xF.append((FFcK2v("DELETE Unused PIcons", c)    , "VViRxu" ))
    VVE6xF.append(VVBgIm)
   VVE6xF.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVFDvf"  ))
   VVE6xF.append(VVBgIm)
   VVE6xF += CC5NMK.VV3Lbt()
   VVE6xF.append(VVBgIm)
   VVE6xF.append(("RCU Keys Help"          , "VVZI1p"    ))
   FFtUqp(self, self.VV6P0F, title=self.Title, VVE6xF=VVE6xF)
 def VV6P0F(self, item=None):
  if item is not None:
   if   item == "VVVhsE"     : self.VVVhsE()
   elif item == "VVnWJ6"    : self.VVnWJ6()
   elif item == "VVLQEF_file"   : self.VVLQEF(0)
   elif item == "VVLQEF_link"   : self.VVLQEF(1)
   elif item == "VVGUuy_file"  : self.VVGUuy(0)
   elif item == "VVGUuy_link"  : self.VVGUuy(1)
   elif item == "VVgUxO"   : self.VVgUxO()
   elif item == "VV3jNH"  : self.VV3jNH()
   elif item == "VViSzT"    : self.VViSzT()
   elif item == "VViRxu"   : self.VViRxu()
   elif item == "VVFDvf"   : self.VVFDvf()
   elif item == "VVu0QH"   : CC5NMK.VVu0QH(self)
   elif item == "VVJn99"   : CC5NMK.VVJn99(self)
   elif item == "findPiconBrokenSymLinks"  : CC5NMK.VVqrU1(self, True)
   elif item == "FindAllBrokenSymLinks"  : CC5NMK.VVqrU1(self, False)
   elif item == "VVZI1p"      : self.VVZI1p()
 def VVIwhC(self):
  if not self.isBusy:
   VVE6xF = []
   VVE6xF.append(("Go to First PIcon"  , "VVzHXf"  ))
   VVE6xF.append(("Go to Last PIcon"   , "VVhJtk"  ))
   VVE6xF.append(VVBgIm)
   VVE6xF.append(("Sort by Channel Name"     , "sortByChan" ))
   VVE6xF.append(("Sort by File Name"  , "sortByFile" ))
   VVE6xF.append(VVBgIm)
   VVE6xF.append(("Find from File List .." , "VVrzRC" ))
   FFtUqp(self, self.VVTnQH, title=self.Title, VVE6xF=VVE6xF)
 def VVTnQH(self, item=None):
  if item is not None:
   if   item == "VVzHXf"   : self.VVzHXf()
   elif item == "VVhJtk"   : self.VVhJtk()
   elif item == "sortByChan"  : self.VVqXlq(2)
   elif item == "sortByFile"  : self.VVqXlq(0)
   elif item == "VVrzRC"  : self.VVrzRC()
 def VVZI1p(self):
  FFirQR(self, VVMNbP + "_help_picons", "PIcons Manager (Keys Help)")
 def VV860S(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVhJtk()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVwWCt()
 def VV1G2T(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVzHXf()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVwWCt()
 def VVjnNT(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVhJtk()
  else:
   self.curCol -= 1
   self.VVwWCt()
 def VV04H7(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVzHXf()
  else:
   self.curCol += 1
   self.VVwWCt()
 def VV7lIH(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVwWCt(True)
 def VV935a(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVwWCt(True)
 def VVzHXf(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVwWCt(True)
 def VVhJtk(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVwWCt(True)
 def VVrzRC(self):
  VVE6xF = []
  for item in self.VVU7lj:
   VVE6xF.append((item[0], item[0]))
  FFtUqp(self, self.VVsCtn, title='PIcons ".png" Files', VVE6xF=VVE6xF, VVETIV=True)
 def VVsCtn(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVBrvB(ndx)
 def VVMS1B(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VV4kq3()
   if refCode:
    FFI7Gq(self, refCode)
    self.VVFBRA()
    self.VV34n7()
 def VVuaNU(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVFBRA()
   self.VV34n7()
  except:
   pass
 def VVFiKw(self):
  if self["keyGreen"].getVisible():
   self.VVBrvB(self.curChanIndex)
 def VVBrvB(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVwWCt(True)
  else:
   FF7QSu(self, "Not found", 1000)
 def VVqXlq(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFy61j(self, boundFunction(self.VVrpcN, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVLQEF(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VV4kq3()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVE6xF = []
     VVE6xF.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVE6xF.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFtUqp(self, boundFunction(self.VVsCpK, mode, curChF, selPiconF), VVE6xF=VVE6xF, title="Current Channel PIcon (already exists)")
    else:
     self.VVsCpK(mode, curChF, selPiconF, "overwrite")
   else:
    FFDQ9M(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFDQ9M(self, "Could not read current channel info. !", title=title)
 def VVsCpK(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFy61j(self, boundFunction(self.VVrpcN, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVGUuy(self, mode):
  pass
 def VVgUxO(self):
  pass
 def VV3jNH(self):
  pass
 def VViSzT(self):
  defDir = FFSNlf(CC5NMK.VVBX3T() + "picons_backup")
  os.system(FFGA8O("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(boundFunction(self.VVgPgN, defDir), boundFunction(CCoBpc
         , mode=CCoBpc.VVLlqx, VVRddm=CC5NMK.VVBX3T()))
 def VVgPgN(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CC5NMK.VVBX3T():
    FFDQ9M(self, "Cannot move to same directory !", title=title)
   else:
    if not FFSNlf(path) == FFSNlf(defDir):
     self.VVrVYK(defDir)
    FFZhjP(self, boundFunction(FFy61j, self, boundFunction(self.VVMrFN, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVU7lj), path), title=title)
  else:
   self.VVrVYK(defDir)
 def VVMrFN(self, title, defDir, toPath):
  try:
   from shutil import move as iMove
  except:
   self.VVrVYK(defDir)
   FFDQ9M(self, 'Could not load "shutil" module !', title=title)
   return
  toPath = FFSNlf(toPath)
  pPath = CC5NMK.VVBX3T()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVU7lj:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVU7lj)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFUojK(self, txt, title=title, VVDUXJ="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VV90Y4("all")
 def VVrVYK(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VViRxu(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVU7lj)
  s = "s" if tot > 1 else ""
  FFZhjP(self, boundFunction(FFy61j, self, boundFunction(self.VVcUQ7, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, s), title=title)
 def VVcUQ7(self, title):
  pPath = CC5NMK.VVBX3T()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVU7lj:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVU7lj)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFcK2v(str(totErr), VVII83)
  FFUojK(self, txt, title=title)
 def VVFDvf(self):
  lines = FFDp6V("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFZhjP(self, boundFunction(self.VVgrEh, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVXqay=True)
  else:
   FFrSV8(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVgrEh(self, fList):
  os.system(FFGA8O("find -L '%s' -type l -delete" % self.pPath))
  FFrSV8(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VV9hLh(self):
  FFy61j(self, self.VVqDxi)
 def VVqDxi(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VV4kq3()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFcK2v("PIcon Directory:\n", VV0ckb)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FF1B9B(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FF1B9B(path)
   txt += FFcK2v("PIcon File:\n", VV0ckb)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFDp6V(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFcK2v("Found %d SymLink%s to this file from:\n" % (tot, s), VV0ckb)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FF3Swx(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFcK2v(tChName, VVcGUH)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFcK2v(line, VVXOiG), tChName)
    txt += "\n"
   if chName:
    txt += FFcK2v("Channel:\n", VV0ckb)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFcK2v(chName, VVcGUH)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFcK2v("Remarks:\n", VV0ckb)
    txt += "  %s\n" % FFcK2v("Unused", VVII83)
  else:
   txt = "No info found"
  FFvad7(self, fncMode=CCzqpW.VVkolS, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VV4kq3(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVU7lj[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFNC3M(sat)
  return fName, refCode, chName, sat, inDB
 def VVFBRA(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVU7lj):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VV34n7(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VV4kq3()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFcK2v("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VV0ckb))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VV4kq3()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFcK2v(self.curChanName, VVuneX)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVVhsE(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VVU7lj:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFmAmO("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFUojK(self, txt, title=self.Title)
 def VVBdcO(self):
  if not self.isBusy:
   VVE6xF = []
   VVE6xF.append(("All"         , "all"   ))
   VVE6xF.append(VVBgIm)
   VVE6xF.append(("Used by Channels"      , "used"  ))
   VVE6xF.append(("Unused PIcons"      , "unused"  ))
   VVE6xF.append(VVBgIm)
   VVE6xF.append(("PIcons Files"       , "pFiles"  ))
   VVE6xF.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVE6xF.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVE6xF.append(VVBgIm)
   VVE6xF.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVE6xF.append(VVBgIm)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFEPU0(val)
      VVE6xF.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CC2Xqg(self)
   filterObj.VVpWoc(VVE6xF, self.nsList, self.VVOyfh)
 def VVOyfh(self, item=None):
  if item is not None:
   self.VV90Y4(item)
 def VV90Y4(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VV2tGI   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVGFWB   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VV3oBX  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VV9MK6  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVK3kL  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVgp2R  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVhouu   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVWQWe   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVhQwy , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVgp2R:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFDp6V("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FF7QSu(self, "Not found", 1000)
     return
   elif mode == self.VVjMRQ:
    return
   else:
    words, asPrefix = CC2Xqg.VVHOBM(words)
   if not words and mode in (self.VVWQWe, self.VVhQwy):
    FF7QSu(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFy61j(self, boundFunction(self.VVrpcN, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVnWJ6(self):
  self.session.open(CCucls, barTheme=CCucls.VVVMet
      , titlePrefix = ""
      , fncToRun  = self.VV3193
      , VVG4RV = self.VVfZNY)
 def VV3193(self, progBarObj):
  lameDbChans = CCZkgq.VVDUdr(self, CCZkgq.VV7uJa, VVivON=False, VVaPZO=False)
  files = []
  words = []
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVaHnU = []
  progBarObj.VVo3zA(len(lameDbChans))
  if lameDbChans:
   processChanName = CCyogD()
   curCh = processChanName.VVxaMb(self.curChanName)
   for refCode in lameDbChans:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVCm3j(1, True)
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CC5NMK.VVzCR6(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CC5NMK.VVDIj7(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       progBarObj.VVaHnU.append(f.replace(".png", ""))
 def VVfZNY(self, VVojmq, VVaHnU, threadCounter, threadTotal, threadErr):
  if VVaHnU:
   self.timer = eTimer()
   fnc = boundFunction(FFy61j, self, boundFunction(self.VVrpcN, mode=self.VVjMRQ, words=VVaHnU), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FF7QSu(self, "Not found", 2000)
 def VVrpcN(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVPq0q(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCZkgq.VVDUdr(self, CCZkgq.VV7uJa, VVivON=False, VVaPZO=False)
  iptvRefList = self.VVPdo0()
  tList = []
  for fName, fType in CC5NMK.VVj5cd(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VV2tGI:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVGFWB  and chName         : isAdd = True
   elif mode == self.VV3oBX and not chName        : isAdd = True
   elif mode == self.VV9MK6  and fType == 0        : isAdd = True
   elif mode == self.VVK3kL  and fType == 1        : isAdd = True
   elif mode == self.VVgp2R  and fName in words       : isAdd = True
   elif mode == self.VVjMRQ and fName in words       : isAdd = True
   elif mode == self.VVhouu  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVWQWe  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVhQwy:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVU7lj   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FF7QSu(self)
  else:
   self.isBusy = False
   FF7QSu(self, "Not found", 1000)
   return
  self.VVU7lj.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVFBRA()
  self.totalPIcons = len(self.VVU7lj)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVwWCt(True)
 def VVPq0q(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CC5NMK.VVj5cd(self.pPath):
    if fName:
     return True
   if isFirstTime : FFDQ9M(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FF7QSu(self, "Not found", 1000)
  else:
   FFDQ9M(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVPdo0(self):
  VV7OA3 = {}
  files  = CCZkJV.VVNgU9(self)
  if files:
   for path in files:
    txt = FFbAeW(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VV7OA3[refCode] = item[1]
  return VV7OA3
 def VVwWCt(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVuTef = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVuTef: self.curPage = VVuTef
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VV0ACW()
  if self.curPage == VVuTef:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VV34n7()
  filName, refCode, chName, sat, inDB = self.VV4kq3()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VV0ACW(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVU7lj[ndx]
   fName = self.VVU7lj[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFcK2v(chName, VVcGUH))
    else : lbl.setText("-")
   except:
    lbl.setText(FFcK2v(chName, VVw2dJ))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVzCR6(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVBy0r():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVu0QH"   )
 @staticmethod
 def VV3Lbt():
  VVE6xF = []
  VVE6xF.append(("Find SymLinks (to PIcon Directory)"   , "VVJn99"   ))
  VVE6xF.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVE6xF.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVE6xF
 @staticmethod
 def VVu0QH(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(SELF)
  png, path = CC5NMK.VVJiax(refCode)
  if path : CC5NMK.VV5G6i(SELF, png, path)
  else : FFDQ9M(SELF, "No PIcon found for current channel in:\n\n%s" % CC5NMK.VVBX3T())
 @staticmethod
 def VVJn99(SELF):
  if VVuneX:
   sed1 = FF2CqO("->", VVuneX)
   sed2 = FF2CqO("picon", VVII83)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVw2dJ, VVKQBm)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FF5cnY(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFGFzp(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVqrU1(SELF, isPIcon):
  sed1 = FF2CqO("->", VVw2dJ)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FF2CqO("picon", VVII83)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FF5cnY(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFGFzp(), grep, sed1, sed2))
 @staticmethod
 def VVj5cd(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVBX3T():
  path = CFG.PIconsPath.getValue()
  return FFSNlf(path)
 @staticmethod
 def VVJiax(refCode, chName=None):
  if FFMLue(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFhxAo(refCode)
  allPath, fName, refCodeFile, pList = CC5NMK.VVDIj7(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VV5G6i(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FF2CqO("%s%s" % (dest, png), VVcGUH))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FF2CqO(errTxt, VVovWl))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFAiEX(SELF, cmd)
 @staticmethod
 def VVDIj7(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CC5NMK.VVBX3T()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FF67wV(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCC0TA():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVE8SM  = None
  self.VVmK3b = ""
  self.VV3ct1  = noService
  self.VV41bD = 0
  self.VVGeye  = noService
  self.VVcb7s = 0
  self.VVRI60  = "-"
  self.VVizAs = 0
  self.VVkxPN  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVZ30O(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVE8SM = frontEndStatus
     self.VV5y8c()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VV5y8c(self):
  if self.VVE8SM:
   val = self.VVE8SM.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVmK3b = "%3.02f dB" % (val / 100.0)
   else         : self.VVmK3b = ""
   val = self.VVE8SM.get("tuner_signal_quality", 0) * 100 / 65536
   self.VV41bD = int(val)
   self.VV3ct1  = "%d%%" % val
   val = self.VVE8SM.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVcb7s = int(val)
   self.VVGeye  = "%d%%" % val
   val = self.VVE8SM.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVRI60  = "%d" % val
   val = int(val * 100 / 500)
   self.VVizAs = min(500, val)
   val = self.VVE8SM.get("tuner_locked", 0)
   if val == 1 : self.VVkxPN = "Locked"
   else  : self.VVkxPN = "Not locked"
 def VVov9G(self)   : return self.VVmK3b
 def VV9UEr(self)   : return self.VV3ct1
 def VVi3wW(self)  : return self.VV41bD
 def VVnfk9(self)   : return self.VVGeye
 def VVCeVx(self)  : return self.VVcb7s
 def VVKqbD(self)   : return self.VVRI60
 def VVYS7P(self)  : return self.VVizAs
 def VVvGc1(self)   : return self.VVkxPN
 def VVmBcY(self) : return self.serviceName
class CCKps4():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVY59W(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFPr51(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVujYo(self.ORPOS  , mod=1   )
      self.sat2  = self.VVujYo(self.ORPOS  , mod=2   )
      self.freq  = self.VVujYo(self.FREQ  , mod=3   )
      self.sr   = self.VVujYo(self.SR   , mod=4   )
      self.inv  = self.VVujYo(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVujYo(self.POL  , self.D_POL )
      self.fec  = self.VVujYo(self.FEC  , self.D_FEC )
      self.syst  = self.VVujYo(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVujYo("modulation" , self.D_MOD )
       self.rolof = self.VVujYo("rolloff"  , self.D_ROLOF )
       self.pil = self.VVujYo("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVujYo("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVujYo("pls_code"  )
       self.iStId = self.VVujYo("is_id"   )
       self.t2PlId = self.VVujYo("t2mi_plp_id" )
       self.t2PId = self.VVujYo("t2mi_pid"  )
 def VVujYo(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFEPU0(val)
  elif mod == 2   : return FF06Jn(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVKpej(self, refCode):
  txt = ""
  self.VVY59W(refCode)
  if self.data:
   def VVUkWF(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVUkWF("System"   , self.syst)
    txt += VVUkWF("Satellite"  , self.sat2)
    txt += VVUkWF("Frequency"  , self.freq)
    txt += VVUkWF("Inversion"  , self.inv)
    txt += VVUkWF("Symbol Rate"  , self.sr)
    txt += VVUkWF("Polarization" , self.pol)
    txt += VVUkWF("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVUkWF("Modulation" , self.mod)
     txt += VVUkWF("Roll-Off" , self.rolof)
     txt += VVUkWF("Pilot"  , self.pil)
     txt += VVUkWF("Input Stream", self.iStId)
     txt += VVUkWF("T2MI PLP ID" , self.t2PlId)
     txt += VVUkWF("T2MI PID" , self.t2PId)
     txt += VVUkWF("PLS Mode" , self.plsMod)
     txt += VVUkWF("PLS Code" , self.plsCod)
   else:
    txt += VVUkWF("System"   , self.txMedia)
    txt += VVUkWF("Frequency"  , self.freq)
  return txt, self.namespace
 def VVvm42(self, refCode):
  txt = "Transpoder : ?"
  self.VVY59W(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VV0ckb + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVHuCR(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFPr51(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVujYo(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVujYo(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVujYo(self.SYST, self.D_SYS_S)
     freq = self.VVujYo(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVujYo(self.POL , self.D_POL)
      fec = self.VVujYo(self.FEC , self.D_FEC)
      sr = self.VVujYo(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVdQQp(self, refCode):
  self.data = None
  self.VVY59W(refCode)
  if self.data and self.freq : return True
  else      : return False
class CC5Lyi():
 def __init__(self, VVBV2V, path, VVG4RV=None, curRowNum=-1):
  self.VVBV2V  = VVBV2V
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVG4RV  = VVG4RV
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFGA8O("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVeJdm(curRowNum)
  else:
   FFDQ9M(self.VVBV2V, "Error while preparing edit!")
 def VVeJdm(self, curRowNum):
  VV7OA3 = self.VVYVrc()
  VVjx9F = None #("Delete Line" , self.deleteLine  , [])
  VVJlME = ("Save Changes" , self.VV9x4M   , [])
  VV2mqV  = ("Edit Line"  , self.VVGi7a    , [])
  VV2x0g = ("Line Options" , self.VVJcXE   , [])
  VV8qPL = (""    , self.VVLQJI , [])
  VVu2WP = self.VV8Sxq
  VVU4La  = self.VVfyBg
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VV9ki4  = (CENTER  , LEFT  )
  VVoKzZ = FFIbZw(self.VVBV2V, None, title=self.Title, header=header, VVU7lj=VV7OA3, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=26, VVjx9F=VVjx9F, VVJlME=VVJlME, VV2mqV=VV2mqV, VV2x0g=VV2x0g, VVu2WP=VVu2WP, VVU4La=VVU4La, VV8qPL=VV8qPL, VVyLkT=True
    , VV6Us0   = "#11001111"
    , VVezBA   = "#11001111"
    , VVDUXJ   = "#11001111"
    , VVTpzJ  = "#05333333"
    , VVvufb  = "#00222222"
    , VVeHz9  = "#11331133"
    )
  VVoKzZ.VVwRIG(curRowNum)
 def VVJcXE(self, VVoKzZ, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVoKzZ.VVcMXW()
  VVE6xF = []
  VVE6xF.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVE6xF.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVKAlJ"  ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVO4au:
   VVE6xF.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(  ("Delete Line"         , "deleteLine"   ))
  FFtUqp(self.VVBV2V, boundFunction(self.VVWuy1, VVoKzZ, lineNum), VVE6xF=VVE6xF, title="Line Options")
 def VVWuy1(self, VVoKzZ, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVcrYv("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVoKzZ)
   elif item == "VVKAlJ"  : self.VVKAlJ(VVoKzZ, lineNum)
   elif item == "copyToClipboard"  : self.VVhyBY(VVoKzZ, lineNum)
   elif item == "pasteFromClipboard" : self.VVB9Wp(VVoKzZ, lineNum)
   elif item == "deleteLine"   : self.VVcrYv("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVoKzZ)
 def VVfyBg(self, VVoKzZ):
  VVoKzZ.VVMBdO()
 def VVLQJI(self, VVoKzZ, title, txt, colList):
  if   self.insertMode == 1: VVoKzZ.VVwV9r()
  elif self.insertMode == 2: VVoKzZ.VVYsMr()
  self.insertMode = 0
 def VVKAlJ(self, VVoKzZ, lineNum):
  if lineNum == VVoKzZ.VVcMXW():
   self.insertMode = 1
   self.VVcrYv("echo '' >> '%s'" % self.tmpFile, VVoKzZ)
  else:
   self.insertMode = 2
   self.VVcrYv("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVoKzZ)
 def VVhyBY(self, VVoKzZ, lineNum):
  global VVO4au
  VVO4au = FFmAmO("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVoKzZ.VV3MOD("Copied to clipboard")
 def VV9x4M(self, VVoKzZ, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFGA8O("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFGA8O("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVoKzZ.VV3MOD("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVoKzZ.VVMBdO()
    else:
     FFDQ9M(self.VVBV2V, "Cannot save file!")
   else:
    FFDQ9M(self.VVBV2V, "Cannot create backup copy of original file!")
 def VV8Sxq(self, VVoKzZ):
  if self.fileChanged:
   FFZhjP(self.VVBV2V, boundFunction(self.VVRx4L, VVoKzZ), "Cancel changes ?")
  else:
   finalOK = os.system(FFGA8O("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVRx4L(VVoKzZ)
 def VVRx4L(self, VVoKzZ):
  VVoKzZ.cancel()
  os.system(FFGA8O("rm -f '%s'" % self.tmpFile))
  if self.VVG4RV:
   self.VVG4RV(self.fileSaved)
 def VVGi7a(self, VVoKzZ, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVKQBm + "ORIGINAL TEXT:\n" + VVXOiG + lineTxt
  FFzG9s(self.VVBV2V, boundFunction(self.VVEcgJ, lineNum, VVoKzZ), title="File Line", defaultText=lineTxt, message=message)
 def VVEcgJ(self, lineNum, VVoKzZ, VVsHM3):
  if not VVsHM3 is None:
   if VVoKzZ.VVcMXW() <= 1:
    self.VVcrYv("echo %s > '%s'" % (VVsHM3, self.tmpFile), VVoKzZ)
   else:
    self.VVviLR(VVoKzZ, lineNum, VVsHM3)
 def VVB9Wp(self, VVoKzZ, lineNum):
  if lineNum == VVoKzZ.VVcMXW() and VVoKzZ.VVcMXW() == 1:
   self.VVcrYv("echo %s >> '%s'" % (VVO4au, self.tmpFile), VVoKzZ)
  else:
   self.VVviLR(VVoKzZ, lineNum, VVO4au)
 def VVviLR(self, VVoKzZ, lineNum, newTxt):
  VVoKzZ.VVCv3A("Saving ...")
  lines = FFel5Q(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVoKzZ.VVhurj()
  VV7OA3 = self.VVYVrc()
  VVoKzZ.VVZlxC(VV7OA3)
 def VVcrYv(self, cmd, VVoKzZ):
  tCons = CCT3NF()
  tCons.ePopen(cmd, boundFunction(self.VVO7FV, VVoKzZ))
  self.fileChanged = True
  VVoKzZ.VVhurj()
 def VVO7FV(self, VVoKzZ, result, retval):
  VV7OA3 = self.VVYVrc()
  VVoKzZ.VVZlxC(VV7OA3)
 def VVYVrc(self):
  if fileExists(self.tmpFile):
   lines = FFel5Q(self.tmpFile)
   VV7OA3 = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VV7OA3.append((str(ndx), line.strip()))
   if not VV7OA3:
    VV7OA3.append((str(1), ""))
   return VV7OA3
  else:
   FFC6jW(self.VVBV2V, self.tmpFile)
class CC2Xqg():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVE6xF   = []
  self.satList   = []
 def VVfaak(self, VVG4RV):
  self.VVE6xF = []
  VVE6xF, VV6AUj = self.VVuHi8(False, True)
  if VVE6xF:
   self.VVE6xF += VVE6xF
   self.VVzavB(VVG4RV, VV6AUj)
 def VVSd87(self, mode, VVoKzZ, satCol, VVG4RV):
  VVoKzZ.VVCv3A("Loading Filters ...")
  self.VVE6xF = []
  self.VVE6xF.append(("All Services" , "all"))
  if mode == 1:
   self.VVE6xF.append(VVBgIm)
   self.VVE6xF.append(("Parental Control", "parentalControl"))
   self.VVE6xF.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVE6xF.append(VVBgIm)
   self.VVE6xF.append(("Selected Transponder"   , "selectedTP" ))
   self.VVE6xF.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVSx3w(VVoKzZ, satCol)
  VVE6xF, VV6AUj = self.VVuHi8(True, False)
  if VVE6xF:
   VVE6xF.insert(0, VVBgIm)
   self.VVE6xF += VVE6xF
  VVoKzZ.VVItnB()
  self.VVzavB(VVG4RV, VV6AUj)
 def VVpWoc(self, VVE6xF, sats, VVG4RV):
  self.VVE6xF = VVE6xF
  VVE6xF, VV6AUj = self.VVuHi8(True, False)
  if VVE6xF:
   self.VVE6xF.append(VVBgIm)
   self.VVE6xF += VVE6xF
  self.VVzavB(VVG4RV, VV6AUj)
 def VVzavB(self, VVG4RV, VV6AUj):
  VVJsRJ = ("Edit Filter", boundFunction(self.VVMjDv, VV6AUj))
  VVhU9p  = ("Filter Help", boundFunction(self.VV0AWb, VV6AUj))
  FFtUqp(self.callingSELF, boundFunction(self.VVozfk, VVG4RV), VVE6xF=self.VVE6xF, title="Select Filter", VVJsRJ=VVJsRJ, VVhU9p=VVhU9p)
 def VVozfk(self, VVG4RV, item):
  if item:
   VVG4RV(item)
 def VVMjDv(self, VV6AUj, VVtbO0Obj, sel):
  if fileExists(VV6AUj) : CC5Lyi(self.callingSELF, VV6AUj, VVG4RV=None)
  else       : FFC6jW(self.callingSELF, VV6AUj)
  VVtbO0Obj.cancel()
 def VV0AWb(self, VV6AUj, VVtbO0Obj, sel):
  FFirQR(self.callingSELF, VVMNbP + "_help_service_filter", "Service Filter")
 def VVSx3w(self, VVoKzZ, satColNum):
  if not self.satList:
   satList = VVoKzZ.VV36Sx(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFNC3M(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VVBgIm)
  if self.VVE6xF:
   self.VVE6xF += self.satList
 def VVuHi8(self, addTag, VVS6In):
  FF92U4()
  fileName  = "ajpanel_services_filter"
  VV6AUj = VVXcuX + fileName
  VVE6xF  = []
  if not fileExists(VV6AUj):
   os.system(FFGA8O("cp -f '%s' '%s'" % (VVMNbP + fileName, VV6AUj)))
  fileFound = False
  if fileExists(VV6AUj):
   fileFound = True
   lines = FFel5Q(VV6AUj)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVE6xF.append((line, "__w__" + line))
       else  : VVE6xF.append((line, line))
  if VVS6In:
   if   not fileFound : FFC6jW(self.callingSELF , VV6AUj)
   elif not VVE6xF : FFojte(self.callingSELF , VV6AUj)
  return VVE6xF, VV6AUj
 @staticmethod
 def VVHOBM(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CCFJmT():
 def __init__(self, callingSELF, VVoKzZ, refCodeColNum, addSep=True):
  self.callingSELF = callingSELF
  self.VVoKzZ = VVoKzZ
  self.refCodeColNum = refCodeColNum
  self.VVE6xF = []
  iMulSel = self.VVoKzZ.VVD4m4()
  if iMulSel : self.VVE6xF.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVE6xF.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVoKzZ.VVIqO1()
  self.VVE6xF.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVE6xF.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVE6xF.append(VVBgIm)
 def VVOvQv(self, servName):
  tot = self.VVoKzZ.VVIqO1()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVE6xF.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVRHkG_multi" ))
  else    : self.VVE6xF.append( ("Add to Bouquet : %s"      % servName , "VVRHkG_one" ))
 def VVsxzH(self, servName, refCode):
  self.VVOvQv(servName)
  self.VVb7C2(servName, refCode)
 def VVJV6C(self, servName, refCode, pcState, hidState):
  isMulti = self.VVoKzZ.VVf82F
  if isMulti:
   refCodeList = self.VVoKzZ.VVW3Zw(3)
   if refCodeList:
    self.VVE6xF.append(("Add Selection to Parental Control"    , "parentalControl_sel_add"  ))
    self.VVE6xF.append(("Remove Selection from Parental Control"   , "parentalControl_sel_remove" ))
    self.VVE6xF.append(VVBgIm)
    self.VVE6xF.append(("Add Selection to Hidden Services"    , "hiddenServices_sel_add"  ))
    self.VVE6xF.append(("Remove Selection from Hidden Services"   , "hiddenServices_sel_remove" ))
   else:
    self.VVE6xF.pop(len(self.VVE6xF) - 1)
  else:
   if pcState == "No" : self.VVE6xF.append(("Add to Parental Control"  , "parentalControl_add"   ))
   else    : self.VVE6xF.append(("Remove from Parental Control" , "parentalControl_remove"  ))
   self.VVE6xF.append(VVBgIm)
   if hidState == "No" : self.VVE6xF.append(("Add to Hidden Services"  , "hiddenServices_add"   ))
   else    : self.VVE6xF.append(("Remove from Hidden Services" , "hiddenServices_remove"  ))
  self.VVE6xF.append(VVBgIm)
  self.VVOvQv(servName)
  self.VVb7C2(servName, refCode)
 def VVb7C2(self, servName, refCode):
  FFtUqp(self.callingSELF, boundFunction(self.VVcfCw, servName, refCode), title="Options", VVE6xF=self.VVE6xF)
 def VVcfCw(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"     : self.VVoKzZ.VVFiCZ(True)
   elif item == "MultSelDisab"     : self.VVoKzZ.VVFiCZ(False)
   elif item == "selectAll"     : self.VVoKzZ.VVEEsl()
   elif item == "unselectAll"     : self.VVoKzZ.VVueCg()
   elif item == "parentalControl_add"   : self.callingSELF.VVoKCe(self.VVoKzZ, refCode, True)
   elif item == "parentalControl_remove"  : self.callingSELF.VVoKCe(self.VVoKzZ, refCode, False)
   elif item == "hiddenServices_add"   : self.callingSELF.VVO6Nt(self.VVoKzZ, refCode, True)
   elif item == "hiddenServices_remove"  : self.callingSELF.VVO6Nt(self.VVoKzZ, refCode, False)
   elif item == "parentalControl_sel_add"  : self.callingSELF.VVthBi(self.VVoKzZ, True)
   elif item == "parentalControl_sel_remove" : self.callingSELF.VVthBi(self.VVoKzZ, False)
   elif item == "hiddenServices_sel_add"  : self.callingSELF.VVNMcd(self.VVoKzZ, True)
   elif item == "hiddenServices_sel_remove" : self.callingSELF.VVNMcd(self.VVoKzZ, False)
   elif item == "VVRHkG_multi"  : self.VVRHkG(refCode, True)
   elif item == "VVRHkG_one"  : self.VVRHkG(refCode, False)
 def VVUYM2(self, VVoKzZ):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  mSel   = CCFJmT(self, VVoKzZ, 3)
  mSel.VVsxzH(servName, refCode)
 def VVRHkG(self, refCode, isMulti):
  bouquets = FFEhoo()
  if bouquets:
   VVE6xF = []
   for item in bouquets:
    VVE6xF.append((item[0], item[1].toString()))
   VVJsRJ = ("Create New", boundFunction(self.VV16C9, refCode, isMulti))
   FFtUqp(self.callingSELF, boundFunction(self.VVVYTK, refCode, isMulti), VVE6xF=VVE6xF, title="Add to Bouquet", VVJsRJ=VVJsRJ, VVETIV=True, VVOsJ7=True)
  else:
   FFZhjP(self.callingSELF, boundFunction(self.VVPLJa, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVVYTK(self, refCode, isMulti, bName=None):
  if bName:
   FFy61j(self.VVoKzZ, boundFunction(self.VVHWhW, refCode, isMulti, bName), title="Adding Channels ...")
 def VVHWhW(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVTaDj(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VV6H2w = InfoBar.instance
    if VV6H2w:
     VVD1Bc = VV6H2w.servicelist
     if VVD1Bc:
      mutableList = VVD1Bc.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVoKzZ.VVItnB()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFrSV8(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FFDQ9M(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVTaDj(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVoKzZ.VVW3Zw(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VV16C9(self, refCode, isMulti, VVtbO0Obj, path):
  self.VVPLJa(refCode, isMulti)
 def VVPLJa(self, refCode, isMulti):
  FFzG9s(self.callingSELF, boundFunction(self.VVijYP, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVijYP(self, refCode, isMulti, name):
  if name:
   FFy61j(self.VVoKzZ, boundFunction(self.VVxmkM, refCode, isMulti, name), title="Adding Channels ...")
 def VVxmkM(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVTaDj(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VV6H2w = InfoBar.instance
    if VV6H2w:
     VVD1Bc = VV6H2w.servicelist
     if VVD1Bc:
      try:
       VVD1Bc.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVD1Bc.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVoKzZ.VVItnB()
   title = "Add to Bouquet"
   if allOK: FFrSV8(self.callingSELF, "Added to : %s" % name, title=title)
   else : FFDQ9M(self.callingSELF, "Nothing added!", title=title)
class CCG29I(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFoyhf(VVH6oF, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF8NiA(self)
  FFUWFF(self["keyRed"]  , "Exit")
  FFUWFF(self["keyGreen"]  , "Save")
  FFUWFF(self["keyYellow"] , "Refresh")
  FFUWFF(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VViS5G  ,
   "green"   : self.VVyAk8 ,
   "yellow"  : self.VVfjbJ  ,
   "blue"   : self.VVYYQM   ,
   "up"   : self.VV860S    ,
   "down"   : self.VV1G2T   ,
   "left"   : self.VVjnNT   ,
   "right"   : self.VV04H7   ,
   "cancel"  : self.VViS5G
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVfjbJ()
  self.VVgjZa()
  FFvFrO(self)
 def VViS5G(self) : self.close(True)
 def VVsRWU(self) : self.close(False)
 def VVYYQM(self):
  self.session.openWithCallback(self.VVCVK1, boundFunction(CCDaKi))
 def VVCVK1(self, closeAll):
  if closeAll:
   self.close()
 def VV860S(self):
  self.VV37T3(1)
 def VV1G2T(self):
  self.VV37T3(-1)
 def VVjnNT(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVgjZa()
 def VV04H7(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVgjZa()
 def VV37T3(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVY8bZ(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVY8bZ(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVY8bZ(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVGE4h(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVGE4h(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVgjZa(self):
  for obj in self.list:
   FFH6QJ(obj, "#11404040")
  FFH6QJ(self.list[self.index], "#11ff8000")
 def VVfjbJ(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVyAk8(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCT3NF()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVhVUv)
 def VVhVUv(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFrSV8(self, "Nothing returned from the system!")
  else:
   FFrSV8(self, str(result))
class CCDaKi(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFoyhf(VVMEvp, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF8NiA(self, addLabel=True)
  FFUWFF(self["keyRed"]  , "Exit")
  FFUWFF(self["keyGreen"]  , "Sync")
  FFUWFF(self["keyYellow"] , "Refresh")
  FFUWFF(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VViS5G   ,
   "green"   : self.VV2AoN  ,
   "yellow"  : self.VVzshC ,
   "blue"   : self.VVyX0q  ,
   "cancel"  : self.VViS5G
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVjHsH()
  self.onShow.append(self.start)
 def start(self):
  FFt2dO(self.refresh)
  FFvFrO(self)
 def refresh(self):
  self.VVKdPu()
  self.VV4xsP(False)
 def VViS5G(self)  : self.close(True)
 def VVyX0q(self) : self.close(False)
 def VVjHsH(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVKdPu(self):
  self.VVAUh6()
  self.VVK1A8()
  self.VVj8FH()
  self.VVfkxr()
 def VVzshC(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVjHsH()
   self.VVKdPu()
   FFt2dO(self.refresh)
 def VV2AoN(self):
  if len(self["keyGreen"].getText()) > 0:
   FFZhjP(self, self.VVBuYa, "Synchronize with Internet Date/Time ?")
 def VVBuYa(self):
  self.VVKdPu()
  FFt2dO(boundFunction(self.VV4xsP, True))
 def VVAUh6(self)  : self["keyRed"].show()
 def VVt3ta(self)  : self["keyGreen"].show()
 def VVxueL(self) : self["keyYellow"].show()
 def VVD3zP(self)  : self["keyBlue"].show()
 def VVK1A8(self)  : self["keyGreen"].hide()
 def VVj8FH(self) : self["keyYellow"].hide()
 def VVfkxr(self)  : self["keyBlue"].hide()
 def VV4xsP(self, sync):
  localTime = FFApFw()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVh8ci(server)
   if epoch_time is not None:
    ntpTime = FFtsyU(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCT3NF()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVhVUv, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVxueL()
  self.VVD3zP()
  if ok:
   self.VVt3ta()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVhVUv(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VV4xsP(False)
  except:
   pass
 def VVh8ci(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFvkoy():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCch2L(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFoyhf(VV4EQp, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FF8NiA(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFt2dO(self.VVbxou)
 def VVbxou(self):
  if FFvkoy(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFH6QJ(self["myBody"], color)
   FFH6QJ(self["myLabel"], color)
  except:
   pass
class CCcyxw(Screen):
 def __init__(self, session, isFromExternal=False):
  size = CFG.signalSize.getValue()
  screenW = FFzSJo()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFoyhf(VVdhez, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self.isFromExternal  = isFromExternal
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCK0nV(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCK0nV(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCK0nV(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCC0TA()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FF8NiA(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VV860S          ,
   "down"  : self.VV1G2T         ,
   "left"  : self.VVjnNT         ,
   "right"  : self.VV04H7         ,
   "info"  : self.VVFkRQ        ,
   "epg"  : self.VVFkRQ        ,
   "menu"  : self.VVZI1p         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "blue"  : self.VVsVbZ       ,
   "last"  : boundFunction(self.VVauki, -1)  ,
   "next"  : boundFunction(self.VVauki, 1)  ,
   "pageUp" : boundFunction(self.VVBE8U, True) ,
   "chanUp" : boundFunction(self.VVBE8U, True) ,
   "pageDown" : boundFunction(self.VVBE8U, False) ,
   "chanDown" : boundFunction(self.VVBE8U, False) ,
   "0"   : boundFunction(self.VVauki, 0)  ,
   "1"   : boundFunction(self.VVH2VP, pos=1) ,
   "2"   : boundFunction(self.VVH2VP, pos=2) ,
   "3"   : boundFunction(self.VVH2VP, pos=3) ,
   "4"   : boundFunction(self.VVH2VP, pos=4) ,
   "5"   : boundFunction(self.VVH2VP, pos=5) ,
   "6"   : boundFunction(self.VVH2VP, pos=6) ,
   "7"   : boundFunction(self.VVH2VP, pos=7) ,
   "8"   : boundFunction(self.VVH2VP, pos=8) ,
   "9"   : boundFunction(self.VVH2VP, pos=9) ,
  }, -1)
  self.onShown.append(self.VVbxfr)
  self.onClose.append(self.onExit)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  self.sliderSNR.VVXK8Z()
  self.sliderAGC.VVXK8Z()
  self.sliderBER.VVXK8Z(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVH2VP()
  self.VVLajjInfo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVLajj)
  except:
   self.timer.callback.append(self.VVLajj)
  self.timer.start(500, False)
 def VVLajjInfo(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVZ30O(service)
  serviceName = self.tunerInfo.VVmBcY()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self)
  tp = CCKps4()
  txt = tp.VVvm42(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVLajj(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVZ30O(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVov9G())
   self["mySNR"].setText(self.tunerInfo.VV9UEr())
   self["myAGC"].setText(self.tunerInfo.VVnfk9())
   self["myBER"].setText(self.tunerInfo.VVKqbD())
   self.sliderSNR.VVI8j4(self.tunerInfo.VVi3wW())
   self.sliderAGC.VVI8j4(self.tunerInfo.VVCeVx())
   self.sliderBER.VVI8j4(self.tunerInfo.VVYS7P())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVI8j4(0)
   self.sliderAGC.VVI8j4(0)
   self.sliderBER.VVI8j4(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self)
    if state and not state == "Tuned":
     FF7QSu(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVFkRQ(self):
  FFvad7(self, fncMode=CCzqpW.VVC9sP)
 def VVZI1p(self):
  FFirQR(self, VVMNbP + "_help_signal", "Signal Monitor (Keys)")
 def VVsVbZ(self):
  self.session.open(CCZOmQ, isFromExternal=self.isFromExternal)
  self.close()
 def VV860S(self)  : self.VVH2VP(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VV1G2T(self) : self.VVH2VP(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVjnNT(self) : self.VVH2VP(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VV04H7(self) : self.VVH2VP(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVH2VP(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVauki(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFhjCC(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVBE8U(self, isUp):
  FF7QSu(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVLajjInfo()
  except:
   pass
class CCK0nV(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVXK8Z(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFH6QJ(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVMNbP +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFH6QJ(self.covObj, self.covColor)
   else:
    FFH6QJ(self.covObj, "#00006688")
    self.isColormode = True
  self.VVI8j4(0)
 def VVI8j4(self, val):
  val  = FFhjCC(val, self.minN, self.maxN)
  width = int(FFhZ13(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFhjCC(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCucls(Screen):
 VVVMet    = 0
 VVgBcO = 1
 VVwm0D = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVG4RV=None, barTheme=VVVMet):
  ratio = self.VVV3ZG(barTheme)
  self.skin, self.skinParam = FFoyhf(VVswW1, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVG4RV = VVG4RV
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVaHnU = None
  self.timer   = eTimer()
  self.myThread  = None
  FF8NiA(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVbxfr)
  self.onClose.append(self.onExit)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  self.VV3agO()
  self["myProgBarVal"].setText("0%")
  FFH6QJ(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVRxqN()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVRxqN)
  except:
   self.timer.callback.append(self.VVRxqN)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def VVo3zA(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVzckZ_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVaHnU), self.counter, self.maxValue, catName)
 def VVzckZ_fromImportEPG(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVzckZ_forcedUpdate(self, title):
  self.newTitle = title
  try:
   self.VVRxqN()
  except:
   pass
 def VVCm3j(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VVaHnU), self.counter, self.maxValue)
  except:
   pass
 def VVynPq(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVhOJO(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVe5ri(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FF7QSu(self, "Cancelling ...")
  self.isCancelled = True
  self.VVm2SY(False)
 def VVm2SY(self, isDone):
  if self.VVG4RV:
   self.VVG4RV(isDone, self.VVaHnU, self.counter, self.maxValue, self.isError)
  self.close()
 def VVRxqN(self):
  val = FFhjCC(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFhZ13(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VVm2SY(True)
 def VV3agO(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVgBcO, self.VVwm0D):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVV3ZG(self, barTheme):
  if   barTheme == self.VVgBcO : return 0.7
  if   barTheme == self.VVwm0D : return 0.5
  else             : return 1
class CCT3NF(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVG4RV = {}
  self.commandRunning = False
  self.VVctLC  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVG4RV, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVG4RV[name] = VVG4RV
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVctLC:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVF6xq, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVYQ3T , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVF6xq, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVYQ3T , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVYQ3T(name, retval)
  return True
 def VVF6xq(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVYQ3T(self, name, retval):
  if not self.VVctLC:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVG4RV[name]:
   self.VVG4RV[name](self.appResults[name], retval)
  del self.VVG4RV[name]
 def VVH9Zu(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCtW47(Screen):
 def __init__(self, session, title="", VV6guL=None, VVHvbP=False, VVOr3c=False, VV1rFv=False, VVaLIm=False, VVUPts=False, VVUtK4=False, VVvy8W=VVxNTa, VV6fyE=None, VVAJrG=False, VV4FBV=None, VVWS5r="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFoyhf(VV4NSz, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FF8NiA(self, addScrollLabel=True)
  if not VVWS5r:
   VVWS5r = "Processing ..."
  self["myLabel"].setText("   %s" % VVWS5r)
  self.VVHvbP   = VVHvbP
  self.VVOr3c   = VVOr3c
  self.VV1rFv   = VV1rFv
  self.VVaLIm  = VVaLIm
  self.VVUPts = VVUPts
  self.VVUtK4 = VVUtK4
  self.VVvy8W   = VVvy8W
  self.VV6fyE = VV6fyE
  self.VVAJrG  = VVAJrG
  self.VV4FBV  = VV4FBV
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCT3NF()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFR16z()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VV6guL, str):
   self.VV6guL = [VV6guL]
  else:
   self.VV6guL = VV6guL
  if self.VV1rFv or self.VVaLIm:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VV0fId, VV0fId)
   self.VV6guL.append("echo -e '\n%s\n' %s" % (restartNote, FF2CqO(restartNote, VVuneX)))
   if self.VV1rFv:
    self.VV6guL.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VV6guL.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVUPts:
   FF7QSu(self, "Processing ...")
  self.onLayoutFinish.append(self.VVEbeB)
  self.onClose.append(self.VV2Ntr)
 def VVEbeB(self):
  self["myLabel"].VVfh1g(textOutFile="console" if self.enableSaveRes else "")
  if self.VVHvbP:
   self["myLabel"].VVnF2W()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VV6UfU()
  else:
   self.VVZqCm()
 def VV6UfU(self):
  if FFvkoy():
   self["myLabel"].setText("Processing ...")
   self.VVZqCm()
  else:
   self["myLabel"].setText(FFcK2v("\n   No connection to internet!", VVII83))
 def VVZqCm(self):
  allOK = self.container.ePopen(self.VV6guL[0], self.VV3d6Q, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VV3d6Q("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVUtK4 or self.VV1rFv or self.VVaLIm:
    self["myLabel"].setText(FFtcsN("STARTED", VVuneX) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VV4FBV:
   colorWhite = CCtmPK.VVtmem(VVKQBm)
   color  = CCtmPK.VVtmem(self.VV4FBV[0])
   words  = self.VV4FBV[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVvy8W=self.VVvy8W)
 def VV3d6Q(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VV6guL):
   allOK = self.container.ePopen(self.VV6guL[self.cmdNum], self.VV3d6Q, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VV3d6Q("Cannot connect to Console!", -1)
  else:
   if self.VVUPts and FFSWW2(self):
    FF7QSu(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVUtK4:
    self["myLabel"].appendText("\n" + FFtcsN("FINISHED", VVuneX), self.VVvy8W)
   if self.VVHvbP or self.VVOr3c:
    self["myLabel"].VVnF2W()
   if self.VV6fyE is not None:
    self.VV6fyE()
   if not retval and self.VVAJrG:
    self.VV2Ntr()
 def VV2Ntr(self):
  if self.container.VVH9Zu():
   self.container.killAll()
class CC2aVM(Screen):
 def __init__(self, session, VV6guL=None, VVUPts=False):
  self.skin, self.skinParam = FFoyhf(VV4NSz, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVXcuX + "ajpanel_terminal.history"
  self.customCommandsFile = VVXcuX + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFmAmO("pwd") or "/home/root"
  self.container   = CCT3NF()
  FF8NiA(self, addScrollLabel=True)
  FFUWFF(self["keyRed"] , "Exit = Stop Command")
  FFUWFF(self["keyGreen"] , "OK = History")
  FFUWFF(self["keyYellow"], "Menu = Custom Cmds")
  FFUWFF(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVVqr5 ,
   "cancel" : self.VVOE27  ,
   "menu"  : self.VV1Ck2 ,
   "last"  : self.VVKm0e  ,
   "next"  : self.VVKm0e  ,
   "1"   : self.VVKm0e  ,
   "2"   : self.VVKm0e  ,
   "3"   : self.VVKm0e  ,
   "4"   : self.VVKm0e  ,
   "5"   : self.VVKm0e  ,
   "6"   : self.VVKm0e  ,
   "7"   : self.VVKm0e  ,
   "8"   : self.VVKm0e  ,
   "9"   : self.VVKm0e  ,
   "0"   : self.VVKm0e
  })
  self.onLayoutFinish.append(self.VVbxfr)
  self.onClose.append(self.VVqOsn)
 def VVbxfr(self):
  self["myLabel"].VVfh1g(isResizable=False, textOutFile="terminal")
  FF2dIb(self["keyRed"]  , "#00ff8000")
  FFH6QJ(self["keyRed"]  , self.skinParam["titleColor"])
  FFH6QJ(self["keyGreen"]  , self.skinParam["titleColor"])
  FFH6QJ(self["keyYellow"] , self.skinParam["titleColor"])
  FFH6QJ(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVZp9H(FFmAmO("date"), 5)
  result = FFmAmO("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVUbS7()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVMNbP + "LinuxCommands.lst"
   newTemplate = VVMNbP + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFGA8O("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFGA8O("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVqOsn(self):
  if self.container.VVH9Zu():
   self.container.killAll()
   self.VVZp9H("Process killed\n", 4)
   self.VVUbS7()
 def VVOE27(self):
  if self.container.VVH9Zu():
   self.VVqOsn()
  else:
   FFZhjP(self, self.close, "Exit ?", VVLb4n=False)
 def VVUbS7(self):
  self.VVZp9H(self.prompt, 1)
  self["keyRed"].hide()
 def VVZp9H(self, txt, mode):
  if   mode == 1 : color = VVuneX
  elif mode == 2 : color = VV0ckb
  elif mode == 3 : color = VVKQBm
  elif mode == 4 : color = VVII83
  elif mode == 5 : color = VVXOiG
  elif mode == 6 : color = VVx60q
  else   : color = VVKQBm
  try:
   self["myLabel"].appendText(FFcK2v(txt, color))
  except:
   pass
 def VVEBBk(self, cmd):
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVZp9H(cmd, 2)
   self.VVZp9H("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVZp9H(ch, 0)
   self.VVZp9H("\nor\n", 4)
   self.VVZp9H("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVUbS7()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFcK2v(parts[0].strip(), VV0ckb)
    right = FFcK2v("#" + parts[1].strip(), VVx60q)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVZp9H(txt, 2)
   lastLine = self.VVizqq()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVC3gf(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VV3d6Q, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFDQ9M(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVZp9H(data, 3)
 def VV3d6Q(self, data, retval):
  if not retval == 0:
   self.VVZp9H("Exit Code : %d\n" % retval, 4)
  self.VVUbS7()
 def VVVqr5(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVizqq() == "":
   self.VVC3gf("cd /tmp")
   self.VVC3gf("ls")
  VV7OA3 = []
  if fileExists(self.commandHistoryFile):
   lines  = FFel5Q(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VV7OA3.append((str(c), line, str(lNum)))
   self.VVdt78(VV7OA3, title, self.commandHistoryFile, isHistory=True)
  else:
   FFC6jW(self, self.commandHistoryFile, title=title)
 def VVizqq(self):
  lastLine = FFmAmO("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVC3gf(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VV1Ck2(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFel5Q(self.customCommandsFile)
   lastLineIsSep = False
   VV7OA3 = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VV7OA3.append((str(c), line, str(lNum)))
   self.VVdt78(VV7OA3, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFC6jW(self, self.customCommandsFile, title=title)
 def VVdt78(self, VV7OA3, title, filePath=None, isHistory=False):
  if VV7OA3:
   VVTpzJ = "#05333333"
   if isHistory: VV6Us0 = VVezBA = VVDUXJ = "#11000020"
   else  : VV6Us0 = VVezBA = VVDUXJ = "#06002020"
   VVZ5MP = VV2x0g = None
   VV2mqV   = ("Send"   , self.VVelzq        , [])
   VVJlME  = ("Modify & Send" , self.VVIGwP        , [])
   if isHistory:
    VVZ5MP = ("Clear History" , self.VVqLqd        , [])
   elif filePath:
    VV2x0g = ("Edit File"  , boundFunction(self.VV6pZS, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VV9ki4     = (CENTER  , LEFT   , CENTER )
   FFIbZw(self, None, title=title, header=header, VVU7lj=VV7OA3, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=26, VV2mqV=VV2mqV, VVJlME=VVJlME, VVZ5MP=VVZ5MP, VV2x0g=VV2x0g, VVyLkT=True
     , VV6Us0   = VV6Us0
     , VVezBA   = VVezBA
     , VVDUXJ   = VVDUXJ
     , VVd2s1  = "#05ffff00"
     , VVTpzJ  = VVTpzJ
    )
  else:
   FFojte(self, filePath, title=title)
 def VVelzq(self, VVoKzZ, title, txt, colList):
  cmd = colList[1].strip()
  VVoKzZ.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVZp9H("\n%s\n" % cmd, 6)
   self.VVZp9H(self.prompt, 1)
  else:
   self.VVEBBk(cmd)
 def VVIGwP(self, VVoKzZ, title, txt, colList):
  cmd = colList[1]
  self.VVgeq1(VVoKzZ, cmd)
 def VVqLqd(self, VVoKzZ, title, txt, colList):
  FFZhjP(self, boundFunction(self.VVMfXO, VVoKzZ), "Reset History File ?", title="Command History")
 def VVMfXO(self, VVoKzZ):
  os.system(FFGA8O("echo '' > %s" % self.commandHistoryFile))
  VVoKzZ.cancel()
 def VV6pZS(self, filePath, VVoKzZ, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CC5Lyi(self, filePath, VVG4RV=boundFunction(self.VV2vpT, VVoKzZ), curRowNum=rowNum)
  else     : FFC6jW(self, filePath)
 def VV2vpT(self, VVoKzZ, fileChanged):
  if fileChanged:
   VVoKzZ.cancel()
   FFt2dO(self.VV1Ck2)
 def VVKm0e(self):
  self.VVgeq1(None, self.lastCommand)
 def VVgeq1(self, VVoKzZ, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFzG9s(self, boundFunction(self.VVnXSu, VVoKzZ), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVnXSu(self, VVoKzZ, cmd):
  if cmd and len(cmd) > 0:
   self.VVEBBk(cmd)
   if VVoKzZ:
    VVoKzZ.cancel()
class CCwfNJ(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVsHM3="", VVsgRe=False, VV186i=False, isTrimEnds=True):
  self.skin, self.skinParam = FFoyhf(VViGyr, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FF8NiA(self, title, addLabel=True)
  FFUWFF(self["keyRed"] , "Up/Down = Change")
  FFUWFF(self["keyGreen"] , "Overwrite")
  FFUWFF(self["keyYellow"], "Pick Key Map")
  FFUWFF(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VV186i   = VV186i
  self.VVsgRe  = VVsgRe
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVsHM3, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVNg5d      ,
   "green"    : self.VVvPR0    ,
   "yellow"   : self.VVv674      ,
   "blue"    : self.VVlnnK     ,
   "menu"    : self.VVTILN     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVqBqT, True) ,
   "down"    : boundFunction(self.VVqBqT, False) ,
   "left"    : self.VVAaWK       ,
   "right"    : self.VVhYsK       ,
   "home"    : self.VVC3Z8       ,
   "end"    : self.VVUSoz       ,
   "next"    : self.VVL3p8      ,
   "last"    : self.VV7z6M      ,
   "deleteForward"  : self.VVL3p8      ,
   "deleteBackward" : self.VV7z6M      ,
   "tab"    : self.VVNAKs       ,
   "toggleOverwrite" : self.VVvPR0    ,
   "0"     : self.VVKTRY     ,
   "1"     : self.VVKTRY     ,
   "2"     : self.VVKTRY     ,
   "3"     : self.VVKTRY     ,
   "4"     : self.VVKTRY     ,
   "5"     : self.VVKTRY     ,
   "6"     : self.VVKTRY     ,
   "7"     : self.VVKTRY     ,
   "8"     : self.VVKTRY     ,
   "9"     : self.VVKTRY
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVEo4K()
  self.onShown.append(self.VVbxfr)
  self.onClose.append(self.onExit)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFu654(self)
  self["myLabel"].setText(self.message)
  self.VVC6fI()
  if self.VVsgRe : self.VVvPR0()
  else    : self.VVPWop()
  FFvFrO(self)
  FFH6QJ(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVjVAo)
  except:
   self.timer.callback.append(self.VVjVAo)
 def onExit(self):
  self.timer.stop()
 def VVNg5d(self):
  self.VVwUhi()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVwUhi()
  self.close(None)
 def VVTILN(self):
  VVE6xF = []
  VVE6xF.append(("Home"         , "home"    ))
  VVE6xF.append(("End"         , "end"     ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Clear All"       , "clearAll"   ))
  VVE6xF.append(("Clear To Home"      , "clearToHome"   ))
  VVE6xF.append(("Clear To End"       , "clearToEnd"   ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVO4au:
   VVE6xF.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("To Capital Letters"     , "toCapital"   ))
  VVE6xF.append(("To Small Letters"      , "toSmall"    ))
  FFtUqp(self, self.VVK6j0, title="Edit Options", VVE6xF=VVE6xF)
 def VVK6j0(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVC3Z8()
   elif item == "end"     : self.VVUSoz()
   elif item == "clearAll"    : self.VVCiS2()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVC3Z8()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVO4au
    VVO4au = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVO4au)
    self.VVC3Z8()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVjVAo(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVvPR0(self):
  self["myInput"].toggleOverwrite()
  self.VVPWop()
 def VVv674(self):
  self.session.openWithCallback(self.VVe19C, boundFunction(CC91w6, mode=self.charMode, VV186i=self.VV186i))
 def VVe19C(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVC6fI()
 def VVPWop(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVEo4K(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVwUhi(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VV2fNV(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVAaWK(self)     : self.VVqe98(self["myInput"].left)
 def VVhYsK(self)     : self.VVqe98(self["myInput"].right)
 def VVL3p8(self)     : self.VVqe98(self["myInput"].delete)
 def VVC3Z8(self)     : self.VVqe98(self["myInput"].home)
 def VVUSoz(self)     : self.VVqe98(self["myInput"].end)
 def VV7z6M(self)    : self.VVqe98(self["myInput"].deleteBackward)
 def VVNAKs(self)     : self.VVqe98(self["myInput"].tab)
 def VVCiS2(self)     : self["myInput"].setText("")
 def VVqe98(self, fnc):
  fnc()
  self.VVjVAo()
 def VVKTRY(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VV2fNV(newChar, overwrite)
   self.VVCoUD(newChar, self["myInput"].mapping[number])
 def VVqBqT(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CC91w6.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CC91w6.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VV2fNV(newChar, True)
   for group in groups:
    if newChar in group:
     self.VVCoUD(newChar, group)
     break
 def VVCoUD(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVKQBm:
    group = VVXOiG + group.replace(newChar, FFcK2v(newChar, VVKQBm, VVXOiG))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVlnnK(self):
  if self.VV186i : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVC6fI()
 def VVC6fI(self):
  self["myInput"].mapping = CC91w6.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CC91w6.RCU_MAP_TITLES[self.charMode])
class CC91w6(Screen):
 VVKb1C  = 0
 VVR4Uy  = 1
 VVrhit  = 2
 VVumHR  = 3
 VVJV5K = 4
 VV2FV8 = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols , arabic_nums1, arabic1)
       , ( symbols , arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A", u"\u0628")
       , (u"\u0647", u"\u062A")
       )
 def __init__(self, session, mode=VVKb1C, VV186i=False):
  self.skin, self.skinParam = FFoyhf(VVpINd, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VV186i  = VV186i
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FF8NiA(self, title=self.Title)
  FFUWFF(self["keyRed"] ,"OK = Select")
  FFUWFF(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVorbW     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVU24y, -1) ,
   "next"  : boundFunction(self.VVU24y, +1) ,
   "left"  : boundFunction(self.VVU24y, -1) ,
   "right"  : boundFunction(self.VVU24y, +1) ,
  }, -1)
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFH6QJ(self["keyRed"], "#11222222")
  FFH6QJ(self["keyGreen"], "#11222222")
  self.VVgtk2()
 def VVgtk2(self):
  self.VV3NiQ()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VV3NiQ(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVU24y(self, direction):
  if self.VV186i : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVgtk2()
 def VVorbW(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCJzoM(Screen):
 def __init__(self, session, title="", message="", VVvy8W=VVxNTa, VVYs0e=False, VVDUXJ=None, VVhkQh=30, canSaveToFile=""):
  self.skin, self.skinParam = FFoyhf(VV4NSz, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVhkQh)
  self.session   = session
  FF8NiA(self, title, addScrollLabel=True)
  self.VVvy8W   = VVvy8W
  self.VVYs0e   = VVYs0e
  self.VVDUXJ   = VVDUXJ
  self.canSaveToFile  = canSaveToFile
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  self["myLabel"].VVfh1g(VVYs0e=self.VVYs0e, textOutFile=self.canSaveToFile)
  self["myLabel"].setText(self.message, self.VVvy8W)
  if self.VVDUXJ:
   FFH6QJ(self["myBody"], self.VVDUXJ)
   FFH6QJ(self["myLabel"], self.VVDUXJ)
   FFiN17(self["myLabel"], self.VVDUXJ)
  self["myLabel"].VVnF2W()
class CCQmOV(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFoyhf(VVmSOs, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FF8NiA(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFH6Sj(self["errPic"], "err")
class CCyqD8(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FFoyhf(VV0aiW, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", 20)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FF8NiA(self, " ", addCloser=True)
class CCsnpJ():
 def __init__(self, session, txt):
  self.win = session.instantiateDialog(CCyqD8, txt)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  self.session = session
  self.timer  = eTimer()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVrkRK)
  except:
   self.timer.callback.append(self.VVrkRK)
  self.timer.start(1500, True)
 def VVrkRK(self):
  self.session.deleteDialog(self.win)
class CCRR2A():
 VVbv3p    = 0
 VV58Qv  = 1
 VVyqpj   = ""
 VV24i4    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVoKzZ   = None
  self.timer     = eTimer()
  self.VV1yQK   = 0
  self.VVhh8v  = 1
  self.VVW2jl  = 2
  self.VVgvtG   = 3
  self.VVKTKs   = 4
  VV7OA3 = self.VVvHgp()
  if VV7OA3:
   self.VVoKzZ = self.VVBPh0(VV7OA3)
  if not VV7OA3 and mode == self.VVbv3p:
   self.VVS6Inor("Download list is empty !")
   self.cancel()
  if mode == self.VV58Qv:
   FFy61j(self.VVoKzZ or self.SELF, boundFunction(self.VVUydV, startDnld, decodedUrl), title="Checking Server ...")
  self.VVaYg6(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVaYg6)
  except:
   self.timer.callback.append(self.VVaYg6)
  self.timer.start(1000, False)
 def VVBPh0(self, VV7OA3):
  VV7OA3.sort(key=lambda x: int(x[0]))
  VVu2WP = self.VVSl00
  VV2mqV  = ("Play"  , self.VVYE3g , [])
  VVmEVe = (""   , self.VVZcpo  , [])
  VVjx9F = ("Stop"  , self.VVYU2G  , [])
  VVJlME = ("Resume"  , self.VVt6Gd , [])
  VVZ5MP = ("Options" , self.VVZ2Lz  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VV9ki4  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFIbZw(self.SELF, None, title=self.Title, header=header, VVU7lj=VV7OA3, VV9ki4=VV9ki4, VVSkoS=widths, VVhkQh=26, VV2mqV=VV2mqV, VVmEVe=VVmEVe, VVu2WP=VVu2WP, VVjx9F=VVjx9F, VVJlME=VVJlME, VVZ5MP=VVZ5MP, VVezBA="#11110011", VV6Us0="#11220022", VVDUXJ="#11110011", VVd2s1="#00ffff00", VVTpzJ="#00223025", VVvufb="#0a333333", VVeHz9="#0a400040", VVyLkT=True, searchCol=1)
 def VVvHgp(self):
  lines = CCRR2A.VVpDUa()
  VV7OA3 = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",")
     left  = parts[0].strip()
     decodedUrl = ",".join(parts[1:]).strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVP2k7(decodedUrl)
      if fName:
       if   FFFRPV(decodedUrl) : sType = "Movie"
       elif FFUQed(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVRw5v(decodedUrl, fName)
       if size > -1: sizeTxt = CCoBpc.VVDLDB(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VV7OA3.append((str(len(VV7OA3) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VV7OA3
 def VVaHyR(self):
  VV7OA3 = self.VVvHgp()
  if VV7OA3:
   if self.VVoKzZ : self.VVoKzZ.VVZlxC(VV7OA3, VVjHsHMsg=False)
   else     : self.VVoKzZ = self.VVBPh0(VV7OA3)
  else:
   self.cancel()
 def VVaYg6(self, force=False):
  if self.VVoKzZ:
   thrList = self.VVe8mk()
   VV7OA3 = []
   changed = False
   for ndx, row in enumerate(self.VVoKzZ.VVtoSt()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VV1yQK
    if m3u8Log:
     percent = self.VVLtNF(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVgvtG , "%.2f %%" % percent
      else   : flag, progr = self.VVKTKs , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFLJ49(mPath)
     if curSize > -1:
      fSize = CCoBpc.VVDLDB(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCoBpc.VVDLDB(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFLJ49(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVgvtG , "%.2f %%" % percent
       else   : flag, progr = self.VVKTKs , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCoBpc.VVDLDB(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrList:
     flag = self.VVW2jl
     if m3u8Log :
      if not speed and not force : flag = self.VVhh8v
      elif curSize == -1   : self.VVKpuN(False)
    elif flag == self.VV1yQK  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VV1yQK  : color2 = "#f#00555555#"
    elif flag == self.VVhh8v : color2 = "#f#0000FFFF#"
    elif flag == self.VVW2jl : color2 = "#f#0000FFFF#"
    elif flag == self.VVgvtG  : color2 = "#f#00FF8000#"
    elif flag == self.VVKTKs  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVOTVi(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VV7OA3.append(row)
   if changed or force:
    self.VVoKzZ.VVZlxC(VV7OA3, VVjHsHMsg=False)
 def VVOTVi(self, flag):
  tDict = self.VV6Exz()
  return tDict.get(flag, "?")
 def VVTYu7(self, state):
  for flag, txt in self.VV6Exz().items():
   if txt == state:
    return flag
  return -1
 def VV6Exz(self):
  return { self.VV1yQK: "Not started", self.VVhh8v: "Connecting", self.VVW2jl: "Downloading", self.VVgvtG: "Stopped", self.VVKTKs: "Completed" }
 def VVS1a8(self, title):
  colList = self.VVoKzZ.VVHEqy()
  path = colList[6]
  url  = colList[8]
  if self.VVgu8k() : self.VVS6Inor("Cannot delete !\n\nFile is downloading.")
  else      : FFZhjP(self.SELF, boundFunction(self.VVMSgJ, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVMSgJ(self, path, url):
  m3u8Log = self.VVoKzZ.VVHEqy()[12].strip()
  if m3u8Log : os.system(FFGA8O("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFGA8O("rm -r '%s'" % path))
  self.VVd2Dv(False)
  self.VVaHyR()
 def VVd2Dv(self, VVS6In=True):
  if self.VVgu8k():
   FF7QSu(self.VVoKzZ, self.VVOTVi(self.VVW2jl), 500)
  else:
   colList  = self.VVoKzZ.VVHEqy()
   state  = colList[4].strip()
   decodedUrl = colList[9].strip()
   if self.VVTYu7(state) in (self.VV1yQK, self.VVKTKs, self.VVgvtG):
    lines = CCRR2A.VVpDUa()
    newLines = []
    found = False
    for line in lines:
     if CCRR2A.VVOJLh(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VV6Lkq(newLines)
     self.VVaHyR()
     FF7QSu(self.VVoKzZ, "Removed.", 1000)
    else:
     FF7QSu(self.VVoKzZ, "Not found.", 1000)
   elif VVS6In:
    self.VVS6Inor("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVnBoX(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFZhjP(self.SELF, boundFunction(self.VVtGLf, flag), ques, title=title)
 def VVtGLf(self, flag):
  list = []
  for ndx, row in enumerate(self.VVoKzZ.VVtoSt()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVTYu7(state)
   if   flag == flagVal == self.VVKTKs: list.append(decodedUrl)
   elif flag == flagVal == self.VV1yQK : list.append(decodedUrl)
  lines = CCRR2A.VVpDUa()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VV6Lkq(newLines)
   self.VVaHyR()
   FF7QSu(self.VVoKzZ, "%d removed." % totRem, 1000)
  else:
   FF7QSu(self.VVoKzZ, "Not found.", 1000)
 def VVd45w(self):
  colList  = self.VVoKzZ.VVHEqy()
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FF7QSu(self.VVoKzZ, "Poster exists", 1500)
  else    : FFy61j(self.VVoKzZ, boundFunction(self.VV4Eev, decodedUrl, path, png), title="Checking Server ...")
 def VV4Eev(self, decodedUrl, path, png):
  err = self.VVUxb5(decodedUrl, path, png)
  if err:
   FFDQ9M(self.SELF, err, title="Poster Download")
 def VVUxb5(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCn4Pa.VVdZe1(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCZkJV.VVU5fz(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCZkJV.VVQVQc(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCZkJV.VV8QZS(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFZ5gR(pUrl, "ajpanel_tmp%s", timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   os.system(FFGA8O("mv -f '%s' '%s'" % (tPath, png)))
   CC2NT0.VVq95w(self.SELF, VVnSZB=png, showGrnMsg="Downloaded")
   return ""
 def VVZcpo(self, VVoKzZ, title, txt, colList):
  def VVt407(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVUkWF(key, val) : return "\n%s:\n%s\n" % (FFcK2v(key, COLOR_CONS_BRIGHT_YELLOW), val.strip())
  heads  = self.VVoKzZ.VVZZK0()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVt407(heads[i]  , CCoBpc.VVDLDB(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVt407("Downloaded" , CCoBpc.VVDLDB(int(curSize), mode=0))
   else:
    txt += VVt407(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVUkWF(heads[i], colList[i])
  FFUojK(self.SELF, txt, title=title)
 def VVYE3g(self, VVoKzZ, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCoBpc.VV70MR(self.SELF, path)
  else    : FF7QSu(self.VVoKzZ, "File not found", 1000)
 def VVSl00(self, VVoKzZ):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVoKzZ:
   self.VVoKzZ.cancel()
  del self
 def VVZ2Lz(self, VVoKzZ, title, txt, colList):
  decodedUrl = colList[9].strip()
  if CFG.downloadAutoResume.getValue(): resumeTxt = "Disable"
  else        : resumeTxt = "Enable"
  VVE6xF = []
  VVE6xF.append(("Remove current row"      , "VVd2Dv"  ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(('Remove all "Completed"'     , "remFinished"    ))
  VVE6xF.append(('Remove all "Not started"'     , "remPending"    ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Delete the file (and remove from list)" , "VVS1a8" ))
  if FFFRPV(decodedUrl):
   VVE6xF.append(VVBgIm)
   VVE6xF.append(("Download Movie Poster (from server)" , "VVd45w"   ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append((resumeTxt + " Auto Resume"     , "VVM7yc"  ))
  FFtUqp(self.SELF, self.VVzh58, VVE6xF=VVE6xF, title=self.Title, VVETIV=True, VVOsJ7=True)
 def VVzh58(self, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVd2Dv"  : self.VVd2Dv()
   elif ref == "remFinished"   : self.VVnBoX(self.VVKTKs, txt)
   elif ref == "remPending"   : self.VVnBoX(self.VV1yQK, txt)
   elif ref == "VVS1a8" : self.VVS1a8(txt)
   elif ref == "VVd45w"  : self.VVd45w()
   elif ref == "VVM7yc"  : self.VVM7yc()
 def VVUydV(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCn4Pa.VVdZe1(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVS6Inor("Could not get download link !\n\nTry again later.")
     return
  for line in CCRR2A.VVpDUa():
   if CCRR2A.VVOJLh(decodedUrl, line):
    self.VVjL7u(decodedUrl)
    FFt2dO(boundFunction(FF7QSu, self.VVoKzZ, "Already listed !", 2000))
    break
  else:
   params = self.VVbZTF(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVS6Inor(params[0])
   elif len(params) == 2:
    FFZhjP(self.SELF, boundFunction(self.VVLzOd, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCoBpc.VVDLDB(fSize)
    FFZhjP(self.SELF, boundFunction(self.VVrAaV, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVrAaV(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCRR2A.VVUsx4(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVaHyR()
  if self.VVoKzZ:
   self.VVoKzZ.VVYsMr()
  if startDnld:
   threadName = self.VV24i4 + decodedUrl
   self.VVZWzx(threadName, url, decodedUrl, path, resp)
 def VVjL7u(self, decodedUrl):
  for ndx, row in enumerate(self.VVoKzZ.VVtoSt()):
   decodedUrl2 = row[9].strip()
   if decodedUrl == decodedUrl2 and self.VVoKzZ:
    self.VVoKzZ.VVVCdA(ndx)
    break
 def VVbZTF(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVP2k7(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVRw5v(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCn4Pa.VVdZe1(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCn4Pa.VV6HSAHeader()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCRR2A.VVszT9(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCRR2A.VVtFNf(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVLzOd(self, resp, decodedUrl):
  if not os.system(FFGA8O("which ffmpeg")) == 0:
   FFZhjP(self.SELF, boundFunction(CCZkJV.VV9wix, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVP2k7(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVB2dz(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFZhjP(self.SELF, boundFunction(self.VV1gzu, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VV1gzu(rTxt, rUrl)
  else:
   self.VVS6Inor("Cannot process m3u8 file !")
 def VVB2dz(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVE6xF = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCZkJV.VVr7z3(rUrl, fPath)
   VVE6xF.append((resol, fullUrl))
  if VVE6xF:
   FFtUqp(self.SELF, self.VVdisn, VVE6xF=VVE6xF, title="Resolution", VVETIV=True, VVOsJ7=True)
  else:
   self.VVS6Inor("Cannot get Resolutions list from server !")
 def VVdisn(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFZhjP(self.SELF, boundFunction(FFt2dO, boundFunction(self.VV6Hn6, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFt2dO(boundFunction(self.VV6Hn6, resolUrl))
 def VV6Hn6(self, resolUrl):
  txt, err = CCn4Pa.VVttWf(resolUrl)
  if err : self.VVS6Inor(err)
  else : self.VV1gzu(txt, resolUrl)
 def VVLkLm(self, logF, decodedUrl):
  found = False
  lines = CCRR2A.VVpDUa()
  with open(CCRR2A.VVUsx4(), "w") as f:
   for line in lines:
    if CCRR2A.VVOJLh(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCRR2A.VVUsx4(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVaHyR()
  if self.VVoKzZ:
   self.VVoKzZ.VVYsMr()
 def VV1gzu(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCZkJV.VVr7z3(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVS6Inor("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVLkLm(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFGA8O("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = self.VV24i4 + decodedUrl
  myThread = iThread(name=threadName, target=boundFunction(os.system, cmd))
  myThread.start()
 def VVLtNF(self, dnldLog):
  if fileExists(dnldLog):
   dur = self.VVYVGo(dnldLog)
   if dur > -1:
    tim = self.VVzH39(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 def VVYVGo(self, dnldLog):
  lines = FFDp6V("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVzH39(self, dnldLog):
  lines = FFDp6V("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVRw5v(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFUQed(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFGA8O("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVZWzx(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVoKzZ.VVHEqy()[7].strip())
  myThread = iThread(name=threadName, target=boundFunction(self.VV0k0k, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VV0k0k(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if CCRR2A.VVyqpj == path:
       break
     else:
      break
  except:
   return
  if CCRR2A.VVyqpj:
   CCRR2A.VVyqpj = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFLJ49(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVbZTF(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VV0k0k(url, decodedUrl, path, resp, totFileSize, True)
 def VVYU2G(self, VVoKzZ, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVzTrl() : FF7QSu(self.VVoKzZ, self.VVOTVi(self.VVKTKs), 500)
  elif not self.VVgu8k() : FF7QSu(self.VVoKzZ, self.VVOTVi(self.VVgvtG), 500)
  elif m3u8Log      : FFZhjP(self.SELF, self.VVKpuN, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVe8mk():
    CCRR2A.VVyqpj = colList[6]
    FF7QSu(self.VVoKzZ, "Stopping ...", 1000)
   else:
    FF7QSu(self.VVoKzZ, "Stopped", 500)
 def VVKpuN(self, withMsg=True):
  if withMsg:
   FF7QSu(self.VVoKzZ, "Stopping ...", 1000)
  os.system(FFGA8O("killall -INT ffmpeg"))
 def VVM7yc(self):
  CFG.downloadAutoResume.setValue(not CFG.downloadAutoResume.getValue())
  CFG.downloadAutoResume.save()
  configfile.save()
 def VVt6Gd(self, *args):
  if   self.VVzTrl() : FF7QSu(self.VVoKzZ, self.VVOTVi(self.VVKTKs) , 500)
  elif self.VVgu8k() : FF7QSu(self.VVoKzZ, self.VVOTVi(self.VVW2jl), 500)
  else:
   resume = False
   m3u8Log = self.VVoKzZ.VVHEqy()[12].strip()
   if m3u8Log:
    if fileExists(m3u8Log) : FFZhjP(self.SELF, boundFunction(self.VVFsPO, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVFehh():
    resume = True
   if resume: FFy61j(self.VVoKzZ, boundFunction(self.VVOUtP), title="Checking Server ...")
   else  : FF7QSu(self.VVoKzZ, "Cannot resume !", 500)
 def VVFsPO(self, m3u8Log):
  os.system(FFGA8O("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FFy61j(self.VVoKzZ, boundFunction(self.VVOUtP), title="Checking Server ...")
 def VVOUtP(self):
  colList  = self.VVoKzZ.VVHEqy()
  path  = colList[6].strip()
  size  = colList[7].strip()
  decodedUrl = colList[9].strip()
  if "j.php" in decodedUrl:
   url = CCn4Pa.VVdZe1(decodedUrl)
   if url:
    decodedUrl = self.VVzJtY(decodedUrl, url)
   else:
    self.VVS6Inor("Could not get download link !\n\nTry again later.")
    return
  curSize = FFLJ49(path)
  params = self.VVbZTF(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVS6Inor(params[0])
   return
  elif len(params) == 2:
   self.VVLzOd(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVzJtY(decodedUrl, url, fSize)
  threadName = self.VV24i4 + decodedUrl
  if resumable: self.VVZWzx(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVS6Inor("Cannot resume from server !")
 def VVP2k7(self, decodedUrl):
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(http:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   x = decodedUrl.find("&mode")
   if x > -1: url = decodedUrl[:x]
   fName = ".mp4"
   x = decodedUrl.find("&end=")
   if x > -1: chName = decodedUrl[x+5:]
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + ".mp4"
     fixName = False
     ok  = True
   if not ok and FFt5Pb(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + ".mp4"
     fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    fName =  mix.split(":")[0]
    chName = ":".join(mix.split(":")[1:])
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVS6Inor(self, txt):
  FFDQ9M(self.SELF, txt, title=self.Title)
 def VVe8mk(self):
  thrList = []
  for thr in iEnumerate():
   if self.VV24i4 in thr.name:
    thrList.append(thr.name.replace(self.VV24i4, ""))
  return thrList
 def VVgu8k(self):
  decodedUrl = self.VVoKzZ.VVHEqy()[9].strip()
  return decodedUrl in self.VVe8mk()
 def VVzTrl(self):
  colList = self.VVoKzZ.VVHEqy()
  path = colList[6].strip()
  size = colList[7].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFLJ49(path)) == size
 def VVFehh(self):
  colList = self.VVoKzZ.VVHEqy()
  path = colList[6].strip()
  size = int(colList[7].strip())
  curSize = FFLJ49(path)
  if curSize > -1:
   size -= curSize
  err = CCRR2A.VVtFNf(size)
  if err:
   FFDQ9M(self.SELF, err, title=self.Title)
   return False
  return True
 def VV6Lkq(self, list):
  with open(CCRR2A.VVUsx4(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVzJtY(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCRR2A.VVpDUa()
  url = decodedUrl
  with open(CCRR2A.VVUsx4(), "w") as f:
   for line in lines:
    if CCRR2A.VVOJLh(decodedUrl, line):
     parts = line.split(",")
     oldUrl = ",".join(parts[1:]).strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVaHyR()
  return url
 @staticmethod
 def VVpDUa():
  list = []
  if fileExists(CCRR2A.VVUsx4()):
   for line in FFel5Q(CCRR2A.VVUsx4()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVOJLh(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVtFNf(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCoBpc.VVvPBf(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCoBpc.VVDLDB(size), CCoBpc.VVDLDB(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVepsy(SELF):
  tot = CCRR2A.VVAm7p()
  if tot:
   FFDQ9M(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVAm7p():
  c = 0
  for thread in iEnumerate():
   if thread.name.startswith(CCRR2A.VV24i4):
    c += 1
  return c
 @staticmethod
 def VVaulr():
  return len(CCRR2A.VVpDUa()) == 0
 @staticmethod
 def VVDCnd():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVsu5T():
  mPoints = CCRR2A.VVDCnd()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFGA8O("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVUsx4():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVjaLW(SELF):
  CCRR2A.VVGnBJ(SELF, CCRR2A.VVbv3p)
 @staticmethod
 def VVcSSy_cur(SELF):
  CCRR2A.VVGnBJ(SELF, CCRR2A.VV58Qv, startDnld=True)
 @staticmethod
 def VVcSSy_url(SELF, url):
  CCRR2A.VVGnBJ(SELF, CCRR2A.VV58Qv, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVa8VWCurrent(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(SELF)
  added, skipped = CCRR2A.VVa8VWList([decodedUrl])
  FF7QSu(SELF, "Added", 1000)
 @staticmethod
 def VVa8VWList(list):
  added = skipped = 0
  for line in CCRR2A.VVpDUa():
   for ndx, url in enumerate(list):
    if url and CCRR2A.VVOJLh(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCRR2A.VVUsx4(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVGnBJ(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCxV8P.VVCiK0(SELF):
   return
  if mode == CCRR2A.VVbv3p and CCRR2A.VVaulr():
   FFDQ9M(SELF, "Download list is empty !", title=title)
  else:
   inst = CCRR2A(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVszT9(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCZOmQ(Screen, CCEwnB):
 VVn5e3 = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False, enableDownloadMenu=True):
  self.skin, self.skinParam = FFoyhf(VVJFb8, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCEwnB.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  self.SubtWin    = None
  FF8NiA(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVOHbK())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVWw2Z         ,
   "info"  : self.VVFkRQ        ,
   "epg"  : self.VVFkRQ        ,
   "menu"  : self.VVMYGo       ,
   "cancel" : self.cancel         ,
   "blue"  : self.VVobk0        ,
   "green"  : self.VVx3RJ    ,
   "yellow" : self.VV7yQI   ,
   "left"  : boundFunction(self.VVPkw5, -1)   ,
   "right"  : boundFunction(self.VVPkw5,  1)   ,
   "play"  : self.VVsxAf        ,
   "pause"  : self.VVsxAf        ,
   "playPause" : self.VVsxAf        ,
   "stop"  : self.VVsxAf        ,
   "rewind" : self.VVQsXD        ,
   "forward" : self.VVXiQ7        ,
   "rewindDm" : self.VVQsXD        ,
   "forwardDm" : self.VVXiQ7        ,
   "last"  : self.VVRBRA        ,
   "next"  : self.VVAE4S        ,
   "pageUp" : boundFunction(self.VVMS54, True) ,
   "pageDown" : boundFunction(self.VVMS54, False) ,
   "chanUp" : boundFunction(self.VVMS54, True) ,
   "chanDown" : boundFunction(self.VVMS54, False) ,
   "up"  : boundFunction(self.VVMS54, True) ,
   "down"  : boundFunction(self.VVMS54, False) ,
   "audio"  : boundFunction(self.VV36UV, True) ,
   "subtitle" : boundFunction(self.VV36UV, False) ,
   "0"   : boundFunction(self.VVRvH4 , 10)  ,
   "1"   : boundFunction(self.VVRvH4 , 1)  ,
   "2"   : boundFunction(self.VVRvH4 , 2)  ,
   "3"   : boundFunction(self.VVRvH4 , 3)  ,
   "4"   : boundFunction(self.VVRvH4 , 4)  ,
   "5"   : boundFunction(self.VVRvH4 , 5)  ,
   "6"   : boundFunction(self.VVRvH4 , 6)  ,
   "7"   : boundFunction(self.VVRvH4 , 7)  ,
   "8"   : boundFunction(self.VVRvH4 , 8)  ,
   "9"   : boundFunction(self.VVRvH4 , 9)
  }, -1)
  self.onShown.append(self.VVbxfr)
  self.onClose.append(self.onExit)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFu654(self)
  if not CCZOmQ.VVn5e3:
   CCZOmQ.VVn5e3 = self
  else:
   self.close()
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFH6Sj(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFH6Sj(self["myPlayRpt"], "rpt")
  self.VVKKz1()
  self.instance.move(ePoint(40, 40))
  self.VVwoAq(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV68ST)
  except:
   self.timer.callback.append(self.VV68ST)
  self.timer.start(250, False)
  self.VV68ST("Checking ...")
  self.VVHKMU()
 def VVx3RJ(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self)
  if "chCode" in iptvRef:
   if CCxV8P.VVCiK0(self):
    self.VVHKMU(True)
 def VVKKz1(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl:
   if "get_download_link" in origUrl: color = "#1120101a"
   else        : color = "#1120002a"
   self["myPlayGrn"].show()
  else:
   color = "#1100202a"
   self["myPlayGrn"].hide()
  FFH6QJ(self["myTitle"], color)
 def VVMYGo(self):
  if self.SubtWin:
   self.SubtWin.VVwx0y()
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self)
  VVE6xF = []
  if self.isFromExternal:
   VVE6xF.append(("IPTV Menu"     , "iptv"  ))
   VVE6xF.append(VVBgIm)
  if FFMLue(iptvRef) and not "&end=" in decodedUrl and not FFt5Pb(decodedUrl):
   uType, uHost, uUser, uPass, uId, uChName = CCZkJV.VVU5fz(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVE6xF.append(("Catchup Programs"   , "catchup"  ))
    VVE6xF.append(VVBgIm)
  VVE6xF.append(("Stop Current Service"    , "stop"  ))
  VVE6xF.append(("Restart Current Service"   , "restart"  ))
  VVE6xF.append(VVBgIm)
  FFFRPVSeries = FFt5Pb(decodedUrl)
  if FFFRPVSeries:
   VVE6xF.append(("File Size"     , "fileSize" ))
   VVE6xF.append(VVBgIm)
  if self.enableDownloadMenu:
   addSep = False
   if FFMLue(iptvRef) and FFFRPVSeries:
    VVE6xF.append(("Start Download"   , "dload_cur" ))
    VVE6xF.append(("Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCRR2A.VVaulr():
    VVE6xF.append(("Download Manager"   , "dload_stat" ))
    addSep = True
   if addSep:
    VVE6xF.append(VVBgIm)
  fPath, fDir, fName = CCoBpc.VVDIiU(self)
  if fPath:
   if not CCoBpc.VVilmH:
    VVE6xF.append((VVuneX + "Open path in File Manager", "VV1xXv" ))
   VVE6xF.append((VVuneX + 'Add to "My Movies" Bouquet' , "VV7D9s" ))
   VVE6xF.append(("%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VV1oV7" ))
   VVE6xF.append(VVBgIm)
  enabl = False
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCZOmQ.VVIo9B(self)
  if posVal and durVal:
   enabl = True
  else:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCzqpW.VV1P3e(self)
   enabl = evName and evTime and evDur
  if enabl:
   VVE6xF.append((VVuneX + "Start Subtitle"    , "VVKVBn"  ))
   VVE6xF.append(VVBgIm)
  if CFG.playerPos.getValue() : VVE6xF.append(("Move Bar to Bottom"  , "botm"  ))
  else      : VVE6xF.append(("Move Bar to Top"  , "top"   ))
  VVE6xF.append(("Help"             , "help"  ))
  FFtUqp(self, self.VVAgtO, VVE6xF=VVE6xF, width=550, title="Options")
 def VVAgtO(self, item=None):
  if item:
   if item == "iptv"     : self.VVZVSu()
   elif item == "catchup"    : self.VV7yQI()
   elif item == "stop"     : self.VVX1Af(0)
   elif item == "restart"    : self.VVX1Af(1)
   elif item == "fileSize"    : FFy61j(self, boundFunction(CCzqpW.VVkwEP, self), title="Checking Server")
   elif item == "dload_cur"   : CCRR2A.VVcSSy_cur(self)
   elif item == "addToDload"   : CCRR2A.VVa8VWCurrent(self)
   elif item == "dload_stat"   : CCRR2A.VVjaLW(self)
   elif item == "VV1xXv" : self.VV1xXv()
   elif item == "VV7D9s" : FFy61j(self, self.VV7D9s)
   elif item == "VVKVBn"  : self.VVKVBn(CCKkaB.VVDmI0)
   elif item == "VV1oV7"  : self.VV1oV7()
   elif item == "botm"     : self.VVwoAq(0)
   elif item == "top"     : self.VVwoAq(1)
   elif item == "help"     : FFirQR(self, VVMNbP + "_help_player", "Player Controller (Keys)")
 def onExit(self):
  self.timer.stop()
  CCZOmQ.VVn5e3 = None
  self.VVE1bq()
 def VV30Y4(self):
  if CCZOmQ.VVn5e3:
   self.session.open(CCZOmQ, enableZapping= False, enableDownloadMenu=False)
  self.close()
 def VV1xXv(self):
  self.session.open(CCoBpc, gotoMovie=True)
  self.VV30Y4()
 def VVZVSu(self):
  self.session.open(CCZkJV)
  self.VV30Y4()
 def VVX1Af(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.close()
   elif typ == 1:
    self.VV68ST("Restarting Service ...")
    FFt2dO(boundFunction(self.VVWgCS, serv))
 def VVWgCS(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self)
  if "&end=" in decodedUrl: boundFunction(self.VVHKMU, True)
  else     : self.session.nav.playService(serv)
 def VV7D9s(self):
  title = "Add Movie to Bouquet"
  bName = "My Movies"
  path  = VVDNL1 + "userbouquet.my_local_movies.tv"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self)
  fPath, fDir, fName = CCoBpc.VVDIiU(self)
  if not fPath or not chName:
   FFDQ9M(self, "Cannot read Path or Channel Name", title=title)
   return
  isNew = False
  if not fileExists(path):
   isNew = True
   with open(path, "w") as f:
    f.write("#NAME %s\n" % bName)
  catID, stID, chNum = "1638", "6", "6"
  refCode = CCZkJV.VVZway(catID, stID, chNum)
  if not isNew:
   fTxt = FFbAeW(path)
   chUrl_noRef = "%s:%s" % (fPath, chName)
   if chUrl_noRef in fTxt:
    FFDQ9M(self, "Already added to bouquet:\n\n%s" % bName, title=title)
    return
   for ns in range(1, 65535 - 1):
    catID, stID, chNum = "1638", str(ns), "6"
    refCode = CCZkJV.VVZway(catID, stID, chNum)
    if not refCode in fTxt:
     break
   else:
    FFDQ9M(self, "Cannot create a unique Reference Code", title=title)
    return
  if refCode and fPath and chName:
   chUrl = "%s%s:%s" % (refCode, fPath, chName)
   with open(path, "a") as f:
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
   piconOk = self.VVzypw(refCode)
   FFixCI(os.path.basename(path))
   FFY6Ac()
   FFrSV8(self, "Added to bouquet:\n\n%s" % bName, title=title + (" (with PIcon)" if piconOk else ""))
  else:
   FFDQ9M(self, "Cannot create a unique Reference Code", title=title)
   return
 def VV1oV7(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCZOmQ.VVIo9B(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VV68ST(txt, highlight=ok)
 def VVKVBn(self, mode, useSubtFile=""):
  self.hide()
  self.SubtWin = self.session.instantiateDialog(CCKkaB, mode=mode, endCallback=self.VVP4Qz)
  self.SubtWin.show()
  self.SubtWin.VVhjQS(useSubtFile)
 def VVP4Qz(self, err):
  if err:
   if err == "noResume": self.VVE1bq(False)
   else    : self.VVE1bq(True)
   if   err == "noResume" : return
   if   err == "noErr"  : return
   elif err == "noAutoSrt" : CCKkaB.VVBHxE(self, self.VVTyvY)
   else      : FF7QSu(self, err, 2000)
 def VVTyvY(self, path):
  if path:
   self.VVKVBn(CCKkaB.VVDmI0, useSubtFile=path)
 def VVzypw(self, refCode):
  fPath, fDir, fName, picFile = CCzqpW.VV9FpO(self)
  pPath = CC5NMK.VVBX3T()
  if fileExists(pPath) and pathExists(picFile):
   pFile = refCode.replace(":", "_").strip("_") + ".png"
   dest = os.path.join(pPath, pFile)
   os.system(FFGA8O("cp -f '%s' '%s'" % (picFile, dest)))
   os.system(FFGA8O("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (dest, dest)))
   return True
  return False
 def VVwoAq(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VVWw2Z(self):
  if self.isManualSeek:
   self.VVlOco()
   self.VV5Z6h(self.manualSeekPts)
  else:
   if self.shown:
    self.hide()
    self.VVKVBn(CCKkaB.VVXgjV)
   else:
    self.VVE1bq()
 def VVE1bq(self, showBar=True):
  if self.SubtWin:
   self.session.deleteDialog(self.SubtWin)
   self.SubtWin = None
  if showBar:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVlOco()
  elif self.SubtWin : self.VVE1bq()
  else    : self.close()
 def VVFkRQ(self):
  if self.SubtWin:
   self.SubtWin.VVDrbg("noErr")
  FFvad7(self, fncMode=CCzqpW.VVfwde)
 def VVsxAf(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except Exception as e:
   pass
  self.VV68ST("Toggling Play/Pause ...")
 def VVlOco(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVPkw5(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCZOmQ.VVIo9B(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VV97sS()
   else:
    self.manualSeekSec += direc * self.VV97sS()
    self.manualSeekSec = FFhjCC(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFhZ13(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFesdJ(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVRvH4(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVOHbK())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VV68ST("Changed Seek Time to : %d%s" % (val, self.VVHOFt()))
 def VVOHbK(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVHOFt())
 def VVHOFt(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVN7Jo(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VV97sS(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VV68ST(self, stateTxt="", highlight=False):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFEN32(self, addInfoObj=True)
  fr = res = ""
  if info:
   w = FFmWQs(info, iServiceInformation.sVideoWidth) or -1
   h = FFmWQs(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFmWQs(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CCzqpW.VVjpk3(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCZOmQ.VVIo9B(self)
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FFhjCC(percVal, 0, 100)
    width = int(FFhZ13(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not posTxt: self["myPlayPos"].setText("")
  if not remTxt: self["myPlayRem"].setText("")
  if not durTxt:
   if   prov : txt = prov
   elif posTxt : txt = ">>>>"
   else  : txt = "...."
   self["myPlayVal"].setText(txt)
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText("")
   FFH6QJ(self["myPlayBarBG"], "#1100202a")
   self["myPlayBarF"].hide()
  else:
   FFH6QJ(self["myPlayBarBG"], "#11000000")
   self["myPlayBarF"].show()
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VVEJxe() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   if highlight: FF2dIb(self["myPlayMsg"], "#0000ffff")
   else  : FF2dIb(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   self["myPlayMsg"].setText("-" if decodedUrl else FFGGpm(refCode, True))
   FF2dIb(self["myPlayMsg"], "#00ff8066")
  tot = CCRR2A.VVAm7p()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVKJGt()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VV5Z6h(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVRBRA()
  state = self.VVYkFx()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FF2dIb(self["myPlayMsg"], "#0000ff00")
  else     : FF2dIb(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 @staticmethod
 def VVIo9B(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFesdJ(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFesdJ(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFesdJ(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVKJGt(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVobk0(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VVEJxe()
   if cList:
    VVE6xF = []
    for pts, what in cList:
     txt = FFesdJ(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVE6xF.append((txt, pts))
    FFtUqp(self, self.VVj6Ve, VVE6xF=VVE6xF, title="Cut List")
   else:
    self.VV68ST("No Cut-List for this channel !")
 def VVj6Ve(self, item=None):
  if item:
   self.VV5Z6h(item)
 def VVEJxe(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVXiQ7(self) : self.VViPgN(1)
 def VVQsXD(self) : self.VViPgN(-1)
 def VViPgN(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCZOmQ.VVIo9B(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VV97sS() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVN7Jo())
    self.VV68ST(txt)
  except:
   self.VV68ST("Cannot jump")
 def VV5Z6h(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VV68ST("Changing Time ...")
 def VVRBRA(self):
  self.VVX1Af(1)
  self.VV68ST("Replaying ...")
  self.VVlOco()
 def VVAE4S(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCZOmQ.VVIo9B(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VV68ST("Jumping to end ...")
  except:
   pass
 def VVYkFx(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVMS54(self, isUp):
  if self.enableZapping:
   self.VV68ST("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVlOco()
   if self.portalTableParam:
    FFt2dO(boundFunction(self.VVWz4P, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self)
    if "/timeshift/" in decodedUrl:
     self.VV68ST("Cannot Zap Catcup TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVftjD()
 def VVftjD(self):
  self.lastPlayPos = 0
  self.VVKKz1()
  self.VVHKMU()
 def VVWz4P(self, isUp):
  CCZkJV_inatance, VVoKzZ, mode = self.portalTableParam
  if isUp : VVoKzZ.VVgcvk()
  else : VVoKzZ.VVZlLE()
  colList = VVoKzZ.VVHEqy()
  if mode == "localIptv":
   chName, chUrl = CCZkJV_inatance.VV6rFq(VVoKzZ, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCZkJV_inatance.VV5jSb(VVoKzZ, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCZkJV_inatance.VV4dui(mode, VVoKzZ, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCZkJV_inatance.VVlRZ2(mode, VVoKzZ, colList)
  else:
   self.VV68ST("Cannot Zap")
   return
  FFI7Gq(self, chUrl, VVetCj=False)
  self.VVftjD()
 def VVHKMU(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCZOmQ.VVIo9B(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self)
   if not self.VVVZM9(refCode, chName, decodedUrl, iptvRef):
    return
   self.VV68ST("Refreshing Portal")
   FFt2dO(self.VVgIoB)
  except:
   pass
 def VVgIoB(self):
  self.restoreLastPlayPos = self.VV4Uz9()
 def VV7yQI(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self)
  if not decodedUrl or FFt5Pb(decodedUrl):
   self.VV68ST("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCZkJV.VVU5fz(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VV68ST("Reading Program List ...")
   ok_fnc = boundFunction(self.VVmiqD, refCode, chName, streamId, uHost, uUser, uPass)
   FFt2dO(boundFunction(CCZkJV.VVnqez, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VV68ST("Cannot process this channel")
 def VVmiqD(self, refCode, chName, streamId, uHost, uUser, uPass, VVoKzZ, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVoKzZ.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VV68ST("Changing Program ...")
   FFt2dO(boundFunction(self.VVtmCC, chUrl))
  else:
   self.VV68ST("Incorrect Timestamp !")
 def VVtmCC(self, chUrl):
   FFI7Gq(self, chUrl, VVetCj=False)
   self.lastPlayPos = 0
   self.VVKKz1()
 def VV36UV(self, isAudio):
  try:
   VV6H2w = InfoBar.instance
   if VV6H2w:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VV6H2w)
    else  : self.session.open(SubtitleSelection, VV6H2w)
  except:
   pass
class CCPijz(Screen):
 def __init__(self, session, title="", VVDJXG="Continue?", VVLb4n=True, VVXqay=False):
  self.skin, self.skinParam = FFoyhf(VV49bm, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVDJXG = VVDJXG
  self.VVXqay = VVXqay
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVLb4n : VVE6xF = [no , yes]
  else   : VVE6xF = [yes, no ]
  FF8NiA(self, title, VVE6xF=VVE6xF, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVWw2Z ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVDJXG)
  if self.VVXqay:
   self["myLabel"].instance.setHAlign(0)
  self.VV2egQ()
  FFCnHd(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FF9lZw(self["myMenu"])
  FFh1vf(self, self["myMenu"])
 def VVWw2Z(self):
  item = FFUcO2(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VV2egQ(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCHE0w(Screen):
 def __init__(self, session, title="", VVE6xF=None, width=1000, height=0, OKBtnFnc=None, VVXOT7=None, VVf3L2=None, VVJsRJ=None, VVhU9p=None, VVETIV=False, VVOsJ7=False):
  if height == 0: height = 850
  self.skin, self.skinParam = FFoyhf(VVQLSY, width, height, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVE6xF   = VVE6xF
  self.OKBtnFnc   = OKBtnFnc
  self.VVXOT7   = VVXOT7
  self.VVf3L2  = VVf3L2
  self.VVJsRJ  = VVJsRJ
  self.VVhU9p   = VVhU9p
  self.VVETIV  = VVETIV
  self.VVOsJ7  = VVOsJ7
  FF8NiA(self, title, VVE6xF=VVE6xF)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVWw2Z          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVljtt         ,
   "green"  : self.VV1Nnx         ,
   "yellow" : self.VVckdo         ,
   "blue"  : self.VVi3D0         ,
   "pageUp" : self.VV9QSY       ,
   "chanUp" : self.VV9QSY       ,
   "pageDown" : self.VVn02P        ,
   "chanDown" : self.VVn02P
  }, -1)
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFCnHd(self["myMenu"])
  FFoto4(self)
  self.VVrvIP(self["keyRed"]  , self.VVXOT7 )
  self.VVrvIP(self["keyGreen"] , self.VVf3L2 )
  self.VVrvIP(self["keyYellow"] , self.VVJsRJ )
  self.VVrvIP(self["keyBlue"]  , self.VVhU9p )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFvFrO(self)
 def VVrvIP(self, btnObj, btnFnc):
  if btnFnc:
   FFUWFF(btnObj, btnFnc[0])
 def VVWw2Z(self):
  item = FFUcO2(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVETIV: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVljtt(self)  : self.VVqe98(self.VVXOT7)
 def VV1Nnx(self) : self.VVqe98(self.VVf3L2)
 def VVckdo(self) : self.VVqe98(self.VVJsRJ)
 def VVi3D0(self) : self.VVqe98(self.VVhU9p)
 def VVqe98(self, btnFnc):
  if btnFnc:
   item = FFUcO2(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVOsJ7:
    self.cancel()
 def VVIekM(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVE6xF = self["myMenu"].list
  VVE6xF.pop(ndx)
  if len(VVE6xF) > 0: self["myMenu"].setList(VVE6xF)
  else    : self.close()
 def VVtW3d(self, VVE6xF):
  if len(VVE6xF) > 0:
   newList = []
   for item in VVE6xF:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVvVxF(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VV9QSY(self):
  self["myMenu"].moveToIndex(0)
 def VVn02P(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCO89m(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VVU7lj=None, VV9ki4=None, VVSkoS=None, VVhkQh=26, VVyLkT=False, VV2mqV=None, VVmEVe=None, VVjx9F=None, VVJlME=None, VVZ5MP=None, VV2x0g=None, VVU4La=None, VV8qPL=None, VVu2WP=None, VVNMPm=-1, VVkAlE=False, searchCol=0, VV6Us0=None, VVezBA=None, VV9kVb="#00dddddd", VVDUXJ="#11002233", VVd2s1="#00ff8833", VVTpzJ="#11111111", VVvufb="#0a555555", VV8Fc3="#0affffff", VVeHz9="#11552200", VVRWgO="#0055ff55"):
  self.skin, self.skinParam = FFoyhf(VV7nuh, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FF8NiA(self, title)
  self.header     = header
  self.VVU7lj     = VVU7lj
  self.totalCols    = len(VVU7lj[0])
  self.VV7Vgv   = 0
  self.lastSortModeIsReverese = False
  self.VVyLkT   = VVyLkT
  self.VVwGql   = 0.01
  self.VVeNDQ   = 0.02
  self.VVcyCn = 0.03
  self.VVhBRT  = 1
  self.VVSkoS = VVSkoS
  self.colWidthPixels   = []
  self.VV2mqV   = VV2mqV
  self.OKButtonObj   = None
  self.VVmEVe   = VVmEVe
  self.VVjx9F   = VVjx9F
  self.VVJlME   = VVJlME
  self.VVZ5MP  = VVZ5MP
  self.VV2x0g   = VV2x0g
  self.VVU4La    = VVU4La
  self.VV8qPL   = VV8qPL
  self.VVu2WP  = VVu2WP
  self.VVNMPm    = VVNMPm
  self.VVkAlE   = VVkAlE
  self.searchCol    = searchCol
  self.VV9ki4    = VV9ki4
  self.keyPressed    = -1
  self.VVhkQh    = FFWFhZ(VVhkQh)
  self.VVQFBH    = FFPMOz(self.VVhkQh, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VV6Us0    = VV6Us0
  self.VVezBA      = VVezBA
  self.VV9kVb    = FFTNDf(VV9kVb)
  self.VVDUXJ    = FFTNDf(VVDUXJ)
  self.VVd2s1    = FFTNDf(VVd2s1)
  self.VVTpzJ    = FFTNDf(VVTpzJ)
  self.VVvufb   = FFTNDf(VVvufb)
  self.VV8Fc3    = FFTNDf(VV8Fc3)
  self.VVeHz9    = FFTNDf(VVeHz9)
  self.VVRWgO   = FFTNDf(VVRWgO)
  self.VVf82F  = False
  self.selectedItems   = 0
  self.VViEpI   = FFTNDf("#01fefe01")
  self.VVEvDl   = FFTNDf("#11400040")
  self.VVpPCP  = self.VViEpI
  self.VV6eAb  = self.VVTpzJ
  if self.VVkAlE:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVBF1p  ,
   "red"   : self.VVuHPq  ,
   "green"   : self.VVAbSv ,
   "yellow"  : self.VVuruT ,
   "blue"   : self.VVJZWf  ,
   "menu"   : self.VVHVaY ,
   "info"   : self.VVvYcP  ,
   "cancel"  : self.VVpPwa  ,
   "up"   : self.VVZlLE    ,
   "down"   : self.VVgcvk  ,
   "left"   : self.VV7lIH   ,
   "right"   : self.VV935a  ,
   "pageUp"  : self.VVNlhc  ,
   "chanUp"  : self.VVNlhc  ,
   "pageDown"  : self.VVYsMr  ,
   "chanDown"  : self.VVYsMr
  }, -1)
  FF4h3g(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFu654(self)
  try:
   self.VV5n9h()
  except Exception as err:
   FFDQ9M(self, str(err))
   self.close(None)
 def VV5n9h(self):
  FFvFrO(self)
  if self.VV6Us0:
   FFH6QJ(self["myTitle"], self.VV6Us0)
  if self.VVezBA:
   FFH6QJ(self["myBody"] , self.VVezBA)
   FFH6QJ(self["myTableH"] , self.VVezBA)
   FFH6QJ(self["myTable"] , self.VVezBA)
   FFH6QJ(self["myBar"]  , self.VVezBA)
  self.VVrvIP(self.VVjx9F  , self["keyRed"])
  self.VVrvIP(self.VVJlME  , self["keyGreen"])
  self.VVrvIP(self.VVZ5MP , self["keyYellow"])
  self.VVrvIP(self.VV2x0g  , self["keyBlue"])
  if self.VV2mqV:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VV2mqV[0])
    FFH6QJ(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVQFBH)
  self["myTableH"].l.setFont(0, gFont(VV1ltY, self.VVhkQh))
  self["myTable"].l.setItemHeight(self.VVQFBH)
  self["myTable"].l.setFont(0, gFont(VV1ltY, self.VVhkQh))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVQFBH)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVQFBH))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVQFBH)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVQFBH
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVQFBH * len(self.VVU7lj) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVSkoS:
   self.VVSkoS = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVSkoS)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VV9ki4:
   self.VV9ki4 = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VV9ki4
   self.VV9ki4 = []
   for item in tmpList:
    self.VV9ki4.append(item | RT_VALIGN_CENTER)
  self.VVlKQ3()
  if self.VVU4La:
   self.VVU4La(self)
 def VVrvIP(self, btnFnc, btn):
  if btnFnc : FFUWFF(btn, btnFnc[0])
  else  : FFUWFF(btn, "")
 def VVU30p(self, waitTxt):
  FFy61j(self, self.VVlKQ3, title=waitTxt)
 def VVlKQ3(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVBAAR(0, self.header, self.VV8Fc3, self.VVeHz9, self.VV8Fc3, self.VVeHz9, self.VVRWgO)])
   rows = []
   for c, row in enumerate(self.VVU7lj):
    rows.append(self.VVBAAR(c, row, self.VV9kVb, self.VVDUXJ, self.VVd2s1, self.VVTpzJ, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVNMPm > -1:
    self["myTable"].moveToIndex(self.VVNMPm )
   self.VVyEdi()
   if self.VVkAlE:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVQFBH * len(self.VVU7lj)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VV8qPL:
    self.VVqe98(self.VV8qPL, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFDQ9M(self, str(err))
    self.close()
   except:
    pass
 def VVBAAR(self, keyIndex, columns, VV9kVb, VVDUXJ, VVd2s1, VVTpzJ, VVRWgO):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVRWgO and ndx == self.VV7Vgv : textColor = VVRWgO
   else           : textColor = VV9kVb
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFTNDf(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVDUXJ = c
    entry = span.group(3)
   if self.VV9ki4[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVQFBH)
           , font   = 0
           , flags   = self.VV9ki4[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVDUXJ
           , color_sel  = VVd2s1
           , backcolor_sel = VVTpzJ
           , border_width = 1
           , border_color = self.VVvufb
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVvYcP(self):
  rowData = self.VVSG6w()
  if rowData:
   title, txt, colList = rowData
   if self.VVmEVe:
    fnc  = self.VVmEVe[1]
    params = self.VVmEVe[2]
    fnc(self, title, txt, colList)
   else:
    FFUojK(self, txt, title)
 def VVBF1p(self):
  if   self.VVf82F : self.VV7vPp(self.VVjUL9(), mode=2)
  elif self.VV2mqV  : self.VVqe98(self.VV2mqV, None)
  else      : self.VVvYcP()
 def VVuHPq(self) : self.VVqe98(self.VVjx9F , self["keyRed"])
 def VVAbSv(self) : self.VVqe98(self.VVJlME , self["keyGreen"])
 def VVuruT(self): self.VVqe98(self.VVZ5MP , self["keyYellow"])
 def VVJZWf(self) : self.VVqe98(self.VV2x0g , self["keyBlue"])
 def VVqe98(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FF7QSu(self, buttonFnc[3])
    FFt2dO(boundFunction(self.VVcFlV, buttonFnc))
   else:
    self.VVcFlV(buttonFnc)
 def VVcFlV(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVSG6w()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VV7vPp(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VVU7lj[ndx]
   isSelected = row[1][9] == self.VViEpI
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVBAAR(ndx, item, self.VV9kVb, self.VVDUXJ, self.VVd2s1, self.VVTpzJ, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVBAAR(ndx, item, self.VViEpI, self.VVEvDl, self.VVpPCP, self.VV6eAb, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVyEdi()
 def VVEEsl(self):
  FFy61j(self, self.VV50Pj, title="Selecting all ...")
 def VV50Pj(self):
  self.VVFiCZ(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VViEpI
   if not isSelected:
    item = self.VVU7lj[ndx]
    newRow = self.VVBAAR(ndx, item, self.VViEpI, self.VVEvDl, self.VVpPCP, self.VV6eAb, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVyEdi()
  self.VV9rki()
 def VVueCg(self):
  FFy61j(self, self.VVJ5Uc, title="Unselecting all ...")
 def VVJ5Uc(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VViEpI:
    item = self.VVU7lj[ndx]
    newRow = self.VVBAAR(ndx, item, self.VV9kVb, self.VVDUXJ, self.VVd2s1, self.VVTpzJ, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVyEdi()
  self.VV9rki()
 def VV9rki(self):
  self.hide()
  self.show()
 def VVSG6w(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVSkoS[i] > 1 or self.VVSkoS[i] == self.VVwGql or self.VVSkoS[i] == self.VVcyCn:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VVU7lj))
   return rowNum, txt, colList
  else:
   return None
 def VVpPwa(self):
  if self.VVu2WP : self.VVu2WP(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVwDp0(self):
  return self["myTitle"].getText().strip()
 def VVZZK0(self):
  return self.header
 def VVzQpf(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVCv3A(self, txt):
  FF7QSu(self, txt)
 def VV3MOD(self, txt):
  FF7QSu(self, txt, 1000)
 def VVItnB(self):
  FF7QSu(self)
 def VVcMXW(self):
  return len(self.VVU7lj)
 def VVhurj(self): self["keyGreen"].show()
 def VVMBdO(self): self["keyGreen"].hide()
 def VVjUL9(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVLYac(self):
  return len(self["myTable"].list)
 def VVFiCZ(self, isOn):
  self.VVf82F = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu"].hide()
   if self.VV2x0g: self["keyBlue"].hide()
   if self.VV2mqV and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VV2x0g: self["keyBlue"].show()
   if self.VV2mqV and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VV2mqV[0])
   self.VVueCg()
  FFH6QJ(self["myTitle"], color)
  FFH6QJ(self["myBar"]  , color)
 def VVD4m4(self):
  return self.VVf82F
 def VVIqO1(self):
  return self.selectedItems
 def VVwRIG(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VVyEdi()
 def VVwV9r(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVyEdi()
 def VV5eiQ(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VVU7lj:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VV7scN(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVcMXW()
  txt += FFtcsN("Total Unique Items", VVII83)
  for i in range(self.totalCols):
   if self.VVSkoS[i - 1] > 1 or self.VVSkoS[i - 1] == self.VVwGql or self.VVSkoS[i - 1] == self.VVcyCn:
    name, tot = self.VV5eiQ(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFUojK(self, txt)
 def VVai60(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVHEqy(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVZlxC(self, newList, newTitle="", VVjHsHMsg=True):
  if newList:
   self.VVU7lj = newList
   if self.VVyLkT and self.VV7Vgv == 0:
    self.VVU7lj = sorted(self.VVU7lj, key=lambda x: int(x[self.VV7Vgv])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VVU7lj = sorted(self.VVU7lj, key=lambda x: x[self.VV7Vgv].lower(), reverse=self.lastSortModeIsReverese)
   if VVjHsHMsg : self.VVU30p("Refreshing ...")
   else   : self.VVlKQ3()
   if newTitle:
    self.VVzQpf(newTitle)
  else:
   FFDQ9M(self, "Cannot refresh list")
   self.cancel()
 def VVMRjs(self, data):
  ndx = self.VVjUL9()
  newRow = self.VVBAAR(ndx, data, self.VV9kVb, self.VVDUXJ, self.VVd2s1, self.VVTpzJ, None)
  if newRow:
   self.VVU7lj[ndx] = data
   self["myTable"].list[ndx] = newRow
   self.VVyEdi()
   return True
  else:
   return False
 def VVayhx(self, colNum, textToFind, VVS6In=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVyEdi()
    break
  else:
   if VVS6In:
    FF7QSu(self, "Not found", 1000)
 def VVQRIY(self, colDict, VVS6In=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVyEdi()
    return
  if VVS6In:
   FF7QSu(self, "Not found", 1000)
 def VVQRIY_partial(self, colDict, VVS6In=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVyEdi()
    return
  if VVS6In:
   FF7QSu(self, "Not found", 1000)
 def VV36Sx(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVW3Zw(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VViEpI:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVeIuQ(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VViEpI: return True
  else        : return False
 def VVtoSt(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVHVaY(self):
  if not self["keyMenu"].getVisible() or self.VVkAlE:
   return
  VVE6xF = []
  VVE6xF.append(("Table Statistcis"             , "tableStat"  ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append((FFcK2v("Export Table to .html"     , VVII83) , "VV0JIX" ))
  VVE6xF.append((FFcK2v("Export Table to .csv"     , VVII83) , "VVH876" ))
  VVE6xF.append((FFcK2v("Export Table to .txt (Tab Separated)", VVII83) , "VVMWrw" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVSkoS[i] > 1 or self.VVSkoS[i] == self.VVeNDQ:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVE6xF.append(VVBgIm)
   if tot == 1 : VVE6xF.append(("Sort", sList[0][1]))
   else  : VVE6xF += sList
  FFtUqp(self, self.VVIZza, VVE6xF=VVE6xF, title=self.VVwDp0())
 def VVIZza(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VV7scN()
   elif item == "VV0JIX": FFy61j(self, self.VV0JIX, title=title)
   elif item == "VVH876" : FFy61j(self, self.VVH876 , title=title)
   elif item == "VVMWrw" : FFy61j(self, self.VVMWrw , title=title)
   else:
    isReversed = False
    if self.VV7Vgv == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVyLkT and item == 0:
     self.VVU7lj = sorted(self.VVU7lj, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VVU7lj = sorted(self.VVU7lj, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VV7Vgv = item
    self.VVU30p("Sorting ...")
 def VVZlLE(self):
  self["myTable"].up()
  self.VVyEdi()
 def VVgcvk(self):
  self["myTable"].down()
  self.VVyEdi()
 def VV7lIH(self):
  self["myTable"].pageUp()
  self.VVyEdi()
 def VV935a(self):
  self["myTable"].pageDown()
  self.VVyEdi()
 def VVNlhc(self):
  self["myTable"].moveToIndex(0)
  self.VVyEdi()
 def VVYsMr(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVyEdi()
 def VVVCdA(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVyEdi()
 def VVMWrw(self):
  expFile = self.VVzvFS() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVI01g()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VVU7lj:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVSkoS[ndx] > self.VVhBRT or self.VVSkoS[ndx] == self.VVcyCn:
      col = self.VVaYep(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVaEBM(expFile)
 def VVH876(self):
  expFile = self.VVzvFS() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVI01g()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VVU7lj:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVSkoS[ndx] > self.VVhBRT or self.VVSkoS[ndx] == self.VVcyCn:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVaYep(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVaEBM(expFile)
 def VV0JIX(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVwDp0(), PLUGIN_NAME, VV3jny)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVwDp0()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVI01g()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVSkoS:
   colgroup += '   <colgroup>'
   for w in self.VVSkoS:
    if w > self.VVhBRT or w == self.VVcyCn:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVzvFS() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VVU7lj:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVSkoS[ndx] > self.VVhBRT or self.VVSkoS[ndx] == self.VVcyCn:
      col = self.VVaYep(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVaEBM(expFile)
 def VVI01g(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVSkoS[ndx] > self.VVhBRT or self.VVSkoS[ndx] == self.VVcyCn:
     newRow.append(col.strip())
  return newRow
 def VVaYep(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FF67wV(col)
 def VVzvFS(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVwDp0())
  fileName = fileName.replace("__", "_")
  path  = FFSNlf(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFmDuf()
  return expFile
 def VVaEBM(self, expFile):
  FFrSV8(self, "File exported to:\n\n%s" % expFile, title=self.VVwDp0())
 def VVyEdi(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCafhh():
 def __init__(self, pixmapObj, picPath):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
 def VVtaxF(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVLVe7)
    except Exception as e:
     self.picLoad.PictureData.get().append(self.VVLVe7)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, "#2200002a"])
    self.picLoad.startDecode(self.picPath)
    return True
   except Exception as e:
    pass
  return False
 def VVLVe7(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    self.pixmapObj.instance.setPixmap(ptr)
 def VVn9JE(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVOSVs(pixmapObj, path):
  cl = CCafhh(pixmapObj, path)
  ok = cl.VVtaxF()
  if ok: return cl
  else : return None
class CC2NT0(Screen):
 def __init__(self, session, title="", VVnSZB=None, showGrnMsg=""):
  self.skin, self.skinParam = FFoyhf(VVaG65, 1400, 800, 30, 40, 20, "#22000060", "#2200002a", 30)
  if not title:
   title = os.path.basename(VVnSZB),
  self.session = session
  FF8NiA(self, title, addCloser=True)
  self["myPic"]  = Pixmap()
  self.VVnSZB = VVnSZB
  self.showGrnMsg  = showGrnMsg
  self.picViewer  = None
  self.onShown.append(self.VVbxfr)
  self.onClose.append(self.onExit)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  self.picViewer = CCafhh.VVOSVs(self["myPic"], self.VVnSZB)
  if self.picViewer:
   if self.showGrnMsg:
    FF7QSu(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFDQ9M(self, "Cannot view picture file:\n\n%s" % self.VVnSZB)
   self.close()
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVn9JE()
 @staticmethod
 def VVq95w(SELF, VVnSZB, title="", showGrnMsg=""):
  SELF.session.open(boundFunction(CC2NT0, title=title, VVnSZB=VVnSZB, showGrnMsg=showGrnMsg))
class CCRdqr(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFoyhf(VVnsgM, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 26, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FF8NiA(self, title=self.Title)
  FFUWFF(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Signal & Player Cotroller Hotkey"       , CFG.hotkey_signal    ))
  if VVVoSD:
   lst.append(getConfigListEntry("EPG Translation Language"        , CFG.epgLanguage    ))
  if VV28fl:
   lst.append(getConfigListEntry("Force UTF-8 Encoding (only OpenVision Python-3.10.2+)" , CFG.forceUtf8Encoding   ))
  lst.append(getConfigListEntry(VV0fId *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type"         , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsPath    ))
  lst.append(getConfigListEntry("Movie/Series Download Path"         , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(VV0fId *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(VV0fId *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB)"        , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons"            , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVHPe2()
  self.onShown.append(self.VVbxfr)
 def VVHPe2(self):
  kList = {
    "ok"  : self.VVWw2Z    ,
    "green"  : self.VVlSEj   ,
    "menu"  : self.VV3nxh  ,
    "cancel" : self.VVPPvc  ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"]  = boundFunction(self["config"].handleKey, kLeft)
   kList["right"]  = boundFunction(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = boundFunction(self["config"].VVMBXg, 0)
     kList["chanDown"] = boundFunction(self["config"].VVMBXg, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFu654(self)
  FFCnHd(self["config"])
  FFoto4(self, self["config"])
  FFvFrO(self)
 def VVWw2Z(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsPath   : self.VVx5Nh()
   elif item == CFG.MovieDownloadPath   : self.VVO2ff(item, self["config"].getCurrent()[0])
   elif item == CFG.PIconsPath    : self.VVvsIk(item)
   elif item == CFG.backupPath    : self.VVvsIk(item)
   elif item == CFG.packageOutputPath  : self.VVvsIk(item)
   elif item == CFG.downloadedPackagesPath : self.VVvsIk(item)
   elif item == CFG.exportedTablesPath  : self.VVvsIk(item)
   elif item == CFG.exportedPIconsPath  : self.VVvsIk(item)
 def VVO2ff(self, item, title):
  tot = CCRR2A.VVAm7p()
  if tot : FFDQ9M(self, "Cannot change while downloading.", title=title)
  else : self.VVvsIk(item)
 def VVx5Nh(self):
  VVE6xF = []
  VVE6xF.append(("Auto Find" , "auto"))
  VVE6xF.append(("Custom Path" , "path"))
  FFtUqp(self, self.VVN3ug, VVE6xF=VVE6xF, title="IPTV Hosts Files Path")
 def VVN3ug(self, item=None):
  if item:
   if   item == "auto": CFG.iptvHostsPath.setValue(VVyIDW)
   elif item == "path": self.VVvsIk(CFG.iptvHostsPath)
 def VVvsIk(self, configObj):
  sDir = configObj.getValue()
  if sDir == VVyIDW:
   sDir = "/"
  self.session.openWithCallback(boundFunction(self.VVoPBQ, configObj)
         , boundFunction(CCoBpc, mode=CCoBpc.VVLlqx, VVRddm=sDir))
 def VVoPBQ(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVPPvc(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFZhjP(self, self.VVlSEj, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVlSEj(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVxYUl()
  self.VV2daJ()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VV2daJ(self):
  CCVXoR.VVnsql()
 def VV3nxh(self):
  VVE6xF = []
  VVE6xF.append(("Use Backup directory in all other paths"      , "VV7kJz"   ))
  VVE6xF.append(("Reset all to default (including File Manager bookmarks)"  , "VVnMQW"   ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Backup %s Settings" % PLUGIN_NAME        , "VVoGkC"  ))
  VVE6xF.append(("Restore %s Settings" % PLUGIN_NAME       , "VVc8ie"  ))
  if fileExists(VVXcuX + VVOw0l):
   VVE6xF.append(VVBgIm)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVE6xF.append(('%s Checking for Update' % txt1       , txt2     ))
   VVE6xF.append(("Reinstall %s" % PLUGIN_NAME        , "VVoI1n"  ))
   VVE6xF.append(("Update %s" % PLUGIN_NAME        , "VVD5Ls"   ))
  FFtUqp(self, self.VVVusW, VVE6xF=VVE6xF, title="Config. Options")
 def VVVusW(self, item=None):
  if item:
   if   item == "VV7kJz"  : FFZhjP(self, self.VV7kJz , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVnMQW"  : FFZhjP(self, self.VVnMQW, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCtmPK)
   elif item == "VVoGkC" : self.VVoGkC()
   elif item == "VVc8ie" : FFy61j(self, self.VVc8ie, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVG6EL(True)
   elif item == "disableChkUpdate" : self.VVG6EL(False)
   elif item == "VVoI1n" : FFy61j(self, self.VVoI1n , "Checking Server ...")
   elif item == "VVD5Ls"  : FFy61j(self, self.VVD5Ls  , "Checking Server ...")
 def VVoGkC(self):
  path = "%sajpanel_settings_%s" % (VVXcuX, FFmDuf())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFrSV8(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVc8ie(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFDp6V("find / %s -iname '%s*' | grep %s" % (FFGFzp(1), name, name))
  if lines:
   lines.sort()
   VVE6xF = []
   for line in lines:
    VVE6xF.append((line, line))
   FFtUqp(self, boundFunction(self.VVdQuT, title), title=title, VVE6xF=VVE6xF, width=1200)
  else:
   FFDQ9M(self, "No settings files found !", title=title)
 def VVdQuT(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFel5Q(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVxYUl()
    FF92U4()
   else:
    FFC6jW(SELF, path, title=title)
 def VVG6EL(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VV7kJz(self):
  newPath = FFSNlf(VVXcuX)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVxYUl()
 @staticmethod
 def VV2C5x():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVnMQW(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.EventsInfoMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.epgLanguage.setValue("off")
  CFG.forceUtf8Encoding.setValue(True)
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.autoResetFrozenIptvChan.setValue(True)
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.iptvHostsPath.setValue(VVyIDW)
  CFG.MovieDownloadPath.setValue(CCRR2A.VVsu5T())
  CFG.PIconsPath.setValue(VVOl08)
  CFG.backupPath.setValue(CCRdqr.VV2C5x())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVxYUl()
  self.close()
 def VVxYUl(self):
  configfile.save()
  global VVXcuX
  VVXcuX = CFG.backupPath.getValue()
  FFtp37()
 def VVD5Ls(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVYdZR(title)
  if webVer:
   FFZhjP(self, boundFunction(FFy61j, self, boundFunction(self.VVJe1r, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVoI1n(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVYdZR(title, True)
  if webVer:
   FFZhjP(self, boundFunction(FFy61j, self, boundFunction(self.VVJe1r, webVer, title, True)), "Install and Restart ?", title=title)
 def VVJe1r(self, webVer, title, isReinst=False):
  url = self.VV206t(self, title)
  if url:
   VVctLC = FFSfMS() == "dpkg"
   if VVctLC == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVctLC else "ipk")
   path, err = FFZ5gR(url + fName, fName, timeout=2)
   if path:
    if isReinst : cmd = FFH2eT(VVPoce, path)
    else  : cmd = FFH2eT(VV6Sp7, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFR9ZE(self, cmd)
    else:
     FFVSFz(self, title=title)
   else:
    FFDQ9M(self, err, title=title)
 def VVYdZR(self, title, anyVer=False):
  url = self.VV206t(self, title)
  if not url:
   return ""
  path, err = FFZ5gR(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFDQ9M(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFbAeW(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFDQ9M(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VV3jny.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFDp6V(cmd)
   if list and curVer == list[0]:
    return webVer
  FFrSV8(self, FFcK2v("No update required.", VVcGUH) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VV206t(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVXcuX + VVOw0l
  if fileExists(path):
   span = iSearch(r"(http.+)", FFbAeW(path), IGNORECASE)
   if span : url = FFSNlf(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFDQ9M(SELF, err, title)
  return url
 @staticmethod
 def VV74EJ(url):
  path, err = FFZ5gR(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFbAeW(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VV3jny.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFDp6V(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCtmPK(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFoyhf(VVosYn, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVKUje
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FF8NiA(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVn43I("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVn43I("\c00888888", i) + sp + "GREY\n"
   txt += self.VVn43I("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVn43I("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVn43I("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVn43I("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVn43I("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVn43I("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVn43I("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVn43I("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVn43I("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVn43I("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVWw2Z ,
   "green"   : self.VVWw2Z ,
   "left"   : self.VVjnNT ,
   "right"   : self.VV04H7 ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  self.VVcN9l()
 def VVWw2Z(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFZhjP(self, self.VVQPj8, "Change to : %s" % txt, title=self.Title)
 def VVQPj8(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVKUje
  VVKUje = self.cursorPos
  self.VVyRLE()
  self.close()
 def VVjnNT(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVcN9l()
 def VV04H7(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVcN9l()
 def VVcN9l(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVn43I(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVtmem(color):
  if VVuneX: return "\\" + color
  else    : return ""
 @staticmethod
 def VVyRLE():
  global VVx60q, VVXOiG, VVovWl, VVII83, VVAyBT, VVKlhh, VVcGUH, VVuneX, COLOR_CONS_BRIGHT_YELLOW, VV0ckb, VVHzAP, VVw2dJ, VVKQBm
  VVKQBm   = CCtmPK.VVn43I("\c00FFFFFF", VVKUje)
  VVXOiG    = CCtmPK.VVn43I("\c00888888", VVKUje)
  VVx60q  = CCtmPK.VVn43I("\c005A5A5A", VVKUje)
  VVKlhh    = CCtmPK.VVn43I("\c00FF0000", VVKUje)
  VVovWl   = CCtmPK.VVn43I("\c00FF5000", VVKUje)
  VVuneX   = CCtmPK.VVn43I("\c00FFFF00", VVKUje)
  COLOR_CONS_BRIGHT_YELLOW = CCtmPK.VVn43I("\c00FFFFAA", VVKUje)
  VVcGUH   = CCtmPK.VVn43I("\c0000FF00", VVKUje)
  VVAyBT    = CCtmPK.VVn43I("\c000066FF", VVKUje)
  VV0ckb    = CCtmPK.VVn43I("\c0000FFFF", VVKUje)
  VVHzAP  = CCtmPK.VVn43I("\c00DSFFFF", VVKUje)  #
  VVw2dJ   = CCtmPK.VVn43I("\c00FA55E7", VVKUje)
  VVII83    = CCtmPK.VVn43I("\c00FF8F5F", VVKUje)
CCtmPK.VVyRLE()
class CCiS47(Screen):
 def __init__(self, session, path, VVctLC):
  self.skin, self.skinParam = FFoyhf(VVMEvp, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVK3tY   = path
  self.VV4qmX   = ""
  self.VV3F4L   = ""
  self.VVctLC    = VVctLC
  self.VVRKJx    = ""
  self.VVKdP2  = ""
  self.VVLliE    = False
  self.VVCyuT  = False
  self.postInstAcion   = 0
  self.VVSWM4  = "enigma2-plugin-extensions"
  self.VV3DXp  = "enigma2-plugin-systemplugins"
  self.VVzdiV = "enigma2"
  self.VVNfFz  = 0
  self.VVyFBH  = 1
  self.VVfU01  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVZQiM = "DEBIAN"
  else        : self.VVZQiM = "CONTROL"
  self.controlPath = self.Path + self.VVZQiM
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVctLC:
   self.packageExt  = ".deb"
   self.VVDUXJ  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVDUXJ  = "#11001020"
  FF8NiA(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFUWFF(self["keyRed"] , "Create")
  FFUWFF(self["keyGreen"] , "Post Install")
  FFUWFF(self["keyYellow"], "Installation Path")
  FFUWFF(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVcBea  ,
   "green"   : self.VV9jXo ,
   "yellow"  : self.VVfoXN  ,
   "blue"   : self.VV3BTh  ,
   "cancel"  : self.VViS5G
  }, -1)
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFvFrO(self)
  if self.VVDUXJ:
   FFH6QJ(self["myBody"], self.VVDUXJ)
   FFH6QJ(self["myLabel"], self.VVDUXJ)
  self.VVEIZE(True)
  self.VV9hLh(True)
 def VV9hLh(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVEAF3()
  if isFirstTime:
   if   package.startswith(self.VVSWM4) : self.VVK3tY = VVkJbg + self.VVRKJx + "/"
   elif package.startswith(self.VV3DXp) : self.VVK3tY = VVYeIO + self.VVRKJx + "/"
   else            : self.VVK3tY = self.Path
  if self.VVLliE : myColor = VVII83
  else    : myColor = VVKQBm
  txt  = ""
  txt += "Source Path\t: %s\n" % FFcK2v(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFcK2v(self.VVK3tY, VVuneX)
  if self.VV3F4L : txt += "Package File\t: %s\n" % FFcK2v(self.VV3F4L, VVXOiG)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFcK2v("Check Control File fields : %s" % errTxt, VVovWl)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFcK2v("Restart GUI", VVII83)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFcK2v("Reboot Device", VVII83)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FFcK2v("Post Install", VVcGUH), act)
  if not errTxt and VVovWl in controlInfo:
   txt += "Warning\t: %s\n" % FFcK2v("Errors in control file may affect the result package.", VVovWl)
  txt += "\nControl File\t: %s\n" % FFcK2v(self.controlFile, VVXOiG)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VV9jXo(self):
  VVE6xF = []
  VVE6xF.append(("No Action"    , "noAction"  ))
  VVE6xF.append(("Restart GUI"    , "VV1rFv"  ))
  VVE6xF.append(("Reboot Device"   , "rebootDev"  ))
  FFtUqp(self, self.VVcZ4U, title="Package Installation Option (after completing installation)", VVE6xF=VVE6xF)
 def VVcZ4U(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VV1rFv"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVEIZE(False)
   self.VV9hLh()
 def VVfoXN(self):
  rootPath = FFcK2v("/%s/" % self.VVRKJx, VVx60q)
  VVE6xF = []
  VVE6xF.append(("Current Path"        , "toCurrent"  ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Extension Path"       , "toExtensions" ))
  VVE6xF.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVE6xF.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFtUqp(self, self.VVTSGU, title="Installation Path", VVE6xF=VVE6xF)
 def VVTSGU(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVYHzR(FFsMYs(self.Path, True))
   elif item == "toExtensions"  : self.VVYHzR(VVkJbg)
   elif item == "toSystemPlugins" : self.VVYHzR(VVYeIO)
   elif item == "toRootPath"  : self.VVYHzR("/")
   elif item == "toRoot"   : self.VVYHzR("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVpfeP, boundFunction(CCoBpc, mode=CCoBpc.VVLlqx, VVRddm=VVXcuX))
 def VVpfeP(self, path):
  if len(path) > 0:
   self.VVYHzR(path)
 def VVYHzR(self, parent, withPackageName=True):
  if withPackageName : self.VVK3tY = parent + self.VVRKJx + "/"
  else    : self.VVK3tY = "/"
  mode = self.VVgJW4()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVQOcV(mode), self.controlFile))
  self.VV9hLh()
 def VV3BTh(self):
  if fileExists(self.controlFile):
   lines = FFel5Q(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFzG9s(self, self.VVKYAN, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFDQ9M(self, "Version not found or incorrectly set !")
  else:
   FFC6jW(self, self.controlFile)
 def VVKYAN(self, VVsHM3):
  if VVsHM3:
   version, color = self.VVs1Qr(VVsHM3, False)
   if color == VV0ckb:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVsHM3, self.controlFile))
    self.VV9hLh()
   else:
    FFDQ9M(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VViS5G(self):
  if self.newControlPath:
   if self.VVLliE:
    self.VVDGl7()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFcK2v(self.newControlPath, VVXOiG)
    txt += FFcK2v("Do you want to keep these files ?", VVuneX)
    FFZhjP(self, self.close, txt, callBack_No=self.VVDGl7, title="Create Package", VVXqay=True)
  else:
   self.close()
 def VVDGl7(self):
  os.system(FFGA8O("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVQOcV(self, mode):
  if   mode == self.VVyFBH : prefix = self.VVSWM4
  elif mode == self.VVfU01 : prefix = self.VV3DXp
  else        : prefix = self.VVzdiV
  return prefix + "-" + self.VVKdP2
 def VVgJW4(self):
  if   self.VVK3tY.startswith(VVkJbg) : return self.VVyFBH
  elif self.VVK3tY.startswith(VVYeIO) : return self.VVfU01
  else            : return self.VVNfFz
 def VVEIZE(self, isFirstTime):
  self.VVRKJx   = os.path.basename(os.path.normpath(self.Path))
  self.VVRKJx   = "_".join(self.VVRKJx.split())
  self.VVKdP2 = self.VVRKJx.lower()
  self.VVLliE = self.VVKdP2 == VVAcxn.lower()
  if self.VVLliE and self.VVKdP2.endswith("ajpan"):
   self.VVKdP2 += "el"
  if self.VVLliE : self.VV4qmX = VVXcuX
  else    : self.VV4qmX = CFG.packageOutputPath.getValue()
  self.VV4qmX = FFSNlf(self.VV4qmX)
  if not pathExists(self.controlPath):
   os.system(FFGA8O("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVLliE : t = PLUGIN_NAME
  else    : t = self.VVRKJx
  self.VVhTsu(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVCTiY.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVLliE : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVhTsu(self.postrmFile, txt)
  if self.VVLliE:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VV3jny)
   self.VVhTsu(self.preinstFile, txt)
  else:
   self.VVhTsu(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVRKJx)
  mode = self.VVgJW4()
  if isFirstTime and not mode == self.VVNfFz:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VV0fId
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVhTsu(self.postinstFile, txt, VVsgRe=True)
  os.system(FFGA8O("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVLliE : version, descripton, maintainer = VV3jny , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVRKJx , self.VVRKJx
   txt = ""
   txt += "Package: %s\n"  % self.VVQOcV(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVhTsu(self, path, lines, VVsgRe=False):
  if not fileExists(path) or VVsgRe:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVEAF3(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFel5Q(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFcK2v(line, VVovWl)
     elif not line.startswith(" ")    : line = FFcK2v(line, VVovWl)
     else          : line = FFcK2v(line, VV0ckb)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VV0ckb
   else   : color = VVovWl
   descr = FFcK2v(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVovWl
     elif line.startswith((" ", "\t")) : color = VVovWl
     elif line.startswith("#")   : color = VVXOiG
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVs1Qr(val, True)
      elif key == "Version"  : version, color = self.VVs1Qr(val, False)
      elif key == "Maintainer" : maint  , color = val, VV0ckb
      elif key == "Architecture" : arch  , color = val, VV0ckb
      else:
       color = VV0ckb
      if not key == "OE" and not key.istitle():
       color = VVovWl
     else:
      color = VVII83
     txt += FFcK2v(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VV3F4L = self.VV4qmX + packageName
   self.VVCyuT = True
   errTxt = ""
  else:
   self.VV3F4L  = ""
   self.VVCyuT = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVs1Qr(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VV0ckb
  else          : return val, VVovWl
 def VVcBea(self):
  if not self.VVCyuT:
   FFDQ9M(self, "Please fix Control File errors first.")
   return
  if self.VVctLC: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFsMYs(self.VVK3tY, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVRKJx
  symlinkTo  = FFkxUt(self.Path)
  dataDir   = self.VVK3tY.rstrip("/")
  removePorjDir = FFGA8O("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFGA8O("rm -f '%s'" % self.VV3F4L) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFDxbr()
  if self.VVctLC:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFCwJZ("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVLliE:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVK3tY == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVZQiM)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VV3F4L, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VV3F4L
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VV3F4L, FF2CqO(result  , VVcGUH))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVK3tY, FF2CqO(instPath, VV0ckb))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FF2CqO(failed, VVovWl))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFR9ZE(self, cmd)
class CCoBpc(Screen):
 VV2aVY   = 0
 VVLlqx  = 1
 VVsl9J = 20
 VVilmH  = None
 def __init__(self, session, VVRddm="/", mode=VV2aVY, VVxmlw="Select", VVhkQh=30, gotoMovie=False):
  self.skin, self.skinParam = FFoyhf(VVQLSY, 1400, 920, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FF8NiA(self)
  FFUWFF(self["keyRed"] , "Exit")
  FFUWFF(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVxmlw = VVxmlw
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  CCoBpc.VVilmH = self
  if   self.gotoMovie        : VV24ng, self.VVRddm = True , CCoBpc.VVDIiU(self)[1] or "/"
  elif self.mode == self.VV2aVY  : VV24ng, self.VVRddm = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVLlqx : VV24ng, self.VVRddm = False, VVRddm
  else           : VV24ng, self.VVRddm = True , VVRddm
  self.VVRddm = FFSNlf(self.VVRddm)
  self["myMenu"] = CCNRz6(  directory   = "/"
         , VV24ng   = VV24ng
         , VV7NEF = True
         , VVJKSE   = self.skinParam["width"]
         , VVhkQh   = self.skinParam["bodyFontSize"]
         , VVQFBH  = self.skinParam["bodyLineH"]
         , VV1XMl  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVWw2Z      ,
   "red"    : self.VV8tRv     ,
   "green"    : self.VV7hCi    ,
   "yellow"   : self.VV2aIv   ,
   "blue"    : self.VVi7HM   ,
   "menu"    : self.VVQpCd    ,
   "info"    : self.VVdbb1    ,
   "cancel"   : self.VVAQ17     ,
   "pageUp"   : self.VVAQ17     ,
   "chanUp"   : self.VVAQ17
  }, -1)
  FF4h3g(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVgjZa)
 def onExit(self):
  CCoBpc.VVilmH = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVgjZa)
  FFu654(self)
  FFCnHd(self["myMenu"], bg="#06003333")
  FFvFrO(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode == self.VVLlqx:
   FFUWFF(self["keyGreen"], self.VVxmlw)
   color = "#22000022"
   FFH6QJ(self["myBody"], color)
   FFH6QJ(self["myMenu"], color)
   color = "#22220000"
   FFH6QJ(self["myTitle"], color)
   FFH6QJ(self["myBar"], color)
  self.VVgjZa()
  if self.VVL0x7(self.VVRddm) > self.bigDirSize:
   FF7QSu(self, "Changing directory...")
   FFt2dO(self.VVQOX2)
  else:
   self.VVQOX2()
 def VVQOX2(self):
  self["myMenu"].VVut4g(self.VVRddm)
  if self.gotoMovie:
   self.VV9tXo(chDir=False)
 def VVVCdA(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVHTSv(self):
  self["myMenu"].refresh()
  FFQnRo()
 def VVL0x7(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VVWw2Z(self):
  if self["myMenu"].VVLgMg():
   path = self.VVttea(self.VVtbO0())
   if self.VVL0x7(path) > self.bigDirSize:
    FF7QSu(self, "Changing directory...")
    FFt2dO(self.VV7xP1)
   else:
    self.VV7xP1()
  else:
   self.VV2ONx()
 def VV7xP1(self):
  self["myMenu"].descent()
  self.VVgjZa()
 def VVAQ17(self):
  if self["myMenu"].VVX7f9():
   self["myMenu"].moveToIndex(0)
   self.VV7xP1()
 def VV8tRv(self):
  if not FFSWW2(self):
   self.close("")
 def VV7hCi(self):
  if self.mode == self.VVLlqx:
   path = self.VVttea(self.VVtbO0())
   self.close(path)
 def VVdbb1(self):
  FFy61j(self, self.VV9Jem, title="Calculating size ...")
 def VV9Jem(self):
  path = self.VVttea(self.VVtbO0())
  param = self.VVUQWo(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFmAmO("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCoBpc.VV7lvz(path)
     freeSize = CCoBpc.VVvPBf(path)
     size = totSize - freeSize
     totSize  = CCoBpc.VVDLDB(totSize)
     freeSize = CCoBpc.VVDLDB(freeSize)
    else:
     size = FFmAmO("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CCoBpc.VVDLDB(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFcK2v(pathTxt, VVII83) + "\n"
   if slBroken : fileTime = self.VVhGsP(path)
   else  : fileTime = self.VVHGDU(path)
   def VVt407(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVt407("Path"    , pathTxt)
   txt += VVt407("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVt407("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVt407("Total Size"   , "%s" % totSize)
    txt += VVt407("Used Size"   , "%s" % usedSize)
    txt += VVt407("Free Size"   , "%s" % freeSize)
   else:
    txt += VVt407("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVt407("Owner"    , owner)
   txt += VVt407("Group"    , group)
   txt += VVt407("Perm. (User)"  , permUser)
   txt += VVt407("Perm. (Group)"  , permGroup)
   txt += VVt407("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVt407("Perm. (Ext.)" , permExtra)
   txt += VVt407("iNode"    , iNode)
   txt += VVt407("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VV0fId, VV0fId)
    txt += hLinkedFiles
   txt += self.VVqpui(path)
  else:
   FFDQ9M(self, "Cannot access information !")
  if len(txt) > 0:
   FFUojK(self, txt)
 def VVUQWo(self, path):
  path = path.strip()
  path = FFkxUt(path)
  result = FFmAmO("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVq07s(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVq07s(perm, 1, 4)
   permGroup = VVq07s(perm, 4, 7)
   permOther = VVq07s(perm, 7, 10)
   permExtra = VVq07s(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFPbn8("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVqpui(self, path):
  txt  = ""
  res  = FFmAmO("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFcK2v("File Attributes:", VVw2dJ), txt)
  return txt
 def VVHGDU(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFtsyU(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFtsyU(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFtsyU(os.path.getctime(path))
  return txt
 def VVhGsP(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFmAmO("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFmAmO("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFmAmO("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVttea(self, currentSel):
  currentDir  = self["myMenu"].VVX7f9()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVLgMg():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVtbO0(self):
  return self["myMenu"].getSelection()[0]
 def VVgjZa(self):
  FF7QSu(self)
  path = self.VVttea(self.VVtbO0())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VVU7lj = self.VVUIyG()
  if VVU7lj and len(VVU7lj) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VVD2ev(path)
  if self.mode == self.VV2aVY and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
 def VVD2ev(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVRmvX(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVQpCd(self):
  if self.mode == self.VV2aVY:
   path  = self.VVttea(self.VVtbO0())
   isDir  = os.path.isdir(path)
   VVE6xF = []
   VVE6xF.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VV2K9o(path):
     sepShown = True
     VVE6xF.append(VVBgIm)
     VVE6xF.append( (VVII83 + "Archiving / Packaging"      , "VVyI2z"  ))
    if self.VV4R0b(path):
     if not sepShown:
      VVE6xF.append(VVBgIm)
     VVE6xF.append( (VVII83 + "Read Backup information"     , "VVgJn4"  ))
     VVE6xF.append( (VVII83 + "Compress Octagon Image (to zip File)"  , "VVKfhW" ))
   elif os.path.isfile(path):
    selFile = self.VVtbO0()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar")) : VVE6xF.extend(self.VVQ9d4(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVE6xF.extend(self.VV9Gyg(True))
    elif selFile.endswith(".m3u")              : VVE6xF.extend(self.VVLqS5(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FFnmUX(path):
     VVE6xF.append(VVBgIm)
     VVE6xF.append((VVII83 + "View"     , "textView_def" ))
     VVE6xF.append((VVII83 + "View (Select Encoder)" , "textView_enc" ))
     VVE6xF.append((VVII83 + "Edit"     , "text_Edit"  ))
    if len(txt) > 0:
     VVE6xF.append(VVBgIm)
     VVE6xF.append(   (VVII83 + txt      , "VV2ONx"  ))
   VVE6xF.append(VVBgIm)
   VVE6xF.append(     ("Create SymLink"       , "VVpQtB" ))
   if not self.VV2K9o(path):
    VVE6xF.append(   ("Rename"          , "VVngKz" ))
    VVE6xF.append(   ("Copy"           , "copyFileOrDir" ))
    VVE6xF.append(   ("Move"           , "moveFileOrDir" ))
    VVE6xF.append(   ("DELETE"          , "VVEYyO" ))
    if fileExists(path):
     VVE6xF.append(VVBgIm)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVE6xF.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVE6xF.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVE6xF.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVE6xF.append(VVBgIm)
   VVE6xF.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVE6xF.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCoBpc.VVDIiU(self)
   if fPath:
    VVE6xF.append(VVBgIm)
    VVE6xF.append(   (VVuneX + "Go to current movie"  , "VV9tXo"))
   VVE6xF.append(VVBgIm)
   VVE6xF.append(    ("Set current directory as \"Startup Path\"" , "VVZZMX" ))
   FFtUqp(self, self.VVQC5x, title="Options", VVE6xF=VVE6xF)
 def VVQC5x(self, item=None):
  if self.mode == self.VV2aVY:
   if item is not None:
    path = self.VVttea(self.VVtbO0())
    selFile = self.VVtbO0()
    if   item == "properties"    : self.VVdbb1()
    elif item == "VVyI2z"  : self.VVyI2z(path)
    elif item == "VVgJn4"  : self.VVgJn4(path)
    elif item == "VVKfhW" : self.VVKfhW(path)
    elif item.startswith("extract_")  : self.VVcQTb(path, selFile, item)
    elif item.startswith("script_")   : self.VVCcjc(path, selFile, item)
    elif item.startswith("m3u_")   : self.VV6P0FItem_m3u(path, selFile, item)
    elif item.startswith("textView_def") : FF1D46(self, path)
    elif item.startswith("textView_enc") : self.VVTYLy(path)
    elif item.startswith("text_Edit")  : CC5Lyi(self, path)
    elif item == "chmod644"     : self.VVL2gR(path, selFile, "644")
    elif item == "chmod755"     : self.VVL2gR(path, selFile, "755")
    elif item == "chmod777"     : self.VVL2gR(path, selFile, "777")
    elif item == "VVpQtB"   : self.VVpQtB(path, selFile)
    elif item == "VVngKz"   : self.VVngKz(path, selFile)
    elif item == "copyFileOrDir"   : self.VVpPWf(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVpPWf(path, selFile, True)
    elif item == "VVEYyO"   : self.VVEYyO(path, selFile)
    elif item == "createNewFile"   : self.VVqEtU(path, True)
    elif item == "createNewDir"    : self.VVqEtU(path, False)
    elif item == "VV9tXo"   : self.VV9tXo()
    elif item == "VVZZMX"   : self.VVZZMX(path)
    elif item == "VV2ONx"    : self.VV2ONx()
    else         : self.close()
 def VV2ONx(self):
  selFile = self.VVtbO0()
  path  = self.VVttea(selFile)
  if os.path.isfile(path):
   VV6guL = []
   category = self["myMenu"].VVFfWn(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVqugi(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : CC2NT0.VVq95w(self, path)
   elif category == "txt"         : FF1D46(self, path)
   elif category in ("tar", "zip", "rar")     : self.VVkLs9(path, selFile)
   elif category == "scr"         : self.VVdwxe(path, selFile)
   elif category == "m3u"         : self.VVgmhd(path, selFile)
   elif category in ("ipk", "deb")       : self.VVFBk7(path, selFile)
   elif category == "mus"         : self.VV70MR(self, path)
   elif category == "mov"         : self.VV70MR(self, path)
   elif not FFnmUX(path)        : FF1D46(self, path)
 def VV2aIv(self):
  path = self.VVttea(self.VVtbO0())
  action = self.VVD2ev(path)
  if action == 1:
   self.VVkM1p(path)
   FF7QSu(self, "Added", 500)
  elif action == -1:
   self.VVTHGx(path)
   FF7QSu(self, "Removed", 500)
  self.VVD2ev(path)
 def VVkM1p(self, path):
  VVU7lj = self.VVUIyG()
  if not VVU7lj:
   VVU7lj = []
  if len(VVU7lj) >= self.VVsl9J:
   FFDQ9M(SELF, "Max bookmarks reached (max=%d)." % self.VVsl9J)
  elif not path in VVU7lj:
   VVU7lj = [path] + VVU7lj
   self.VVJT2O(VVU7lj)
 def VVi7HM(self):
  VVU7lj = self.VVUIyG()
  if VVU7lj:
   newList = []
   for line in VVU7lj:
    newList.append((line, line))
   VVXOT7  = ("Delete"  , self.VVTEjH )
   VVJsRJ = ("Move Up"   , self.VV395r )
   VVhU9p  = ("Move Down" , self.VVt4vc )
   self.bookmarkMenu = FFtUqp(self, self.VV5pGK, title="Bookmarks", VVE6xF=newList, VVXOT7=VVXOT7, VVJsRJ=VVJsRJ, VVhU9p=VVhU9p)
 def VVTEjH(self, VVtbO0Obj, path):
  if self.bookmarkMenu:
   VVU7lj = self.VVTHGx(path)
   self.bookmarkMenu.VVtW3d(VVU7lj)
 def VV395r(self, VVtbO0Obj, path):
  if self.bookmarkMenu:
   VVU7lj = self.bookmarkMenu.VVvVxF(True)
   if VVU7lj:
    self.VVJT2O(VVU7lj)
 def VVt4vc(self, VVtbO0Obj, path):
  if self.bookmarkMenu:
   VVU7lj = self.bookmarkMenu.VVvVxF(False)
   if VVU7lj:
    self.VVJT2O(VVU7lj)
 def VV5pGK(self, folder=None):
  if folder:
   folder = FFSNlf(folder)
   self["myMenu"].VVut4g(folder)
   self["myMenu"].moveToIndex(0)
  self.VVgjZa()
 def VVUIyG(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVRmvX(self, path):
  VVU7lj = self.VVUIyG()
  if VVU7lj and path in VVU7lj:
   return True
  else:
   return False
 def VVJikl(self):
  if VVUIyG():
   return True
  else:
   return False
 def VVJT2O(self, VVU7lj):
  line = ",".join(VVU7lj)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVTHGx(self, path):
  VVU7lj = self.VVUIyG()
  if VVU7lj:
   while path in VVU7lj:
    VVU7lj.remove(path)
   self.VVJT2O(VVU7lj)
   return VVU7lj
 def VV9tXo(self, chDir=True):
  fPath, fDir, fName = CCoBpc.VVDIiU(self)
  if fPath:
   if chDir:
    self["myMenu"].VVut4g(fDir)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FF7QSu(self, "Not found", 1000)
 def VVZZMX(self, path):
  if not os.path.isdir(path):
   path = FFsMYs(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVqugi(self, selFile, VVDJXG, command):
  FFZhjP(self, boundFunction(FFR9ZE, self, command, VV6fyE=self.VVHTSv), "%s\n\n%s" % (VVDJXG, selFile))
 def VVQ9d4(self, path, calledFromMenu):
  destPath = self.VV6hfK(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVE6xF = []
  if calledFromMenu:
   VVE6xF.append(VVBgIm)
   color = VVII83
  else:
   color = ""
  VVE6xF.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVE6xF.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVE6xF.append((color + "Extract Here"            , "extract_here"  ))
  if VVMhOQ and path.endswith(".tar.gz"):
   VVE6xF.append(VVBgIm)
   VVE6xF.append((color + 'Convert to ".ipk" Package' , "VV0t6J"  ))
   VVE6xF.append((color + 'Convert to ".deb" Package' , "VVgPLw"  ))
  return VVE6xF
 def VVkLs9(self, path, selFile):
  FFtUqp(self, boundFunction(self.VVcQTb, path, selFile), title="Compressed File Options", VVE6xF=self.VVQ9d4(path, False))
 def VVcQTb(self, path, selFile, item=None):
  if item is not None:
   parent  = FFsMYs(path, False)
   destPath = self.VV6hfK(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VV0fId
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFCwJZ("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFCwJZ("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VV0fId, VV0fId)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FF5cnY(self, cmd)
   elif path.endswith(".zip"):
    self.VVm6Hp(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif path.endswith(".rar"):
    self.VV1VAL(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFGA8O("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVqugi(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVqugi(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFsMYs(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVqugi(selFile, "Extract Here ?"      , cmd)
   elif item == "VV0t6J" : self.VV0t6J(path)
   elif item == "VVgPLw" : self.VVgPLw(path)
 def VV6hfK(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVm6Hp(self, item, path, parent, destPath, VVDJXG):
  FFZhjP(self, boundFunction(self.VVYpLE, item, path, parent, destPath), VVDJXG)
 def VVYpLE(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VV0fId
  cmd  = FFCwJZ("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FF2CqO(destPath, VVcGUH))
  cmd +=   sep
  cmd += "fi;"
  FFgEn3(self, cmd, VV6fyE=self.VVHTSv)
 def VV1VAL(self, item, path, parent, destPath, VVDJXG):
  FFZhjP(self, boundFunction(self.VVz7gD, item, path, parent, destPath), VVDJXG)
 def VVz7gD(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFSNlf(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VV0fId
  cmd  = FFCwJZ("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FF2CqO(destPath, VVcGUH))
  cmd +=   sep
  cmd += "fi;"
  FFgEn3(self, cmd, VV6fyE=self.VVHTSv)
 def VV9Gyg(self, addSep=False):
  VVE6xF = []
  if addSep:
   VVE6xF.append(VVBgIm)
  VVE6xF.append((VVII83 + "View Script File"  , "script_View"  ))
  VVE6xF.append((VVII83 + "Execute Script File" , "script_Execute" ))
  VVE6xF.append((VVII83 + "Edit"     , "script_Edit" ))
  return VVE6xF
 def VVdwxe(self, path, selFile):
  FFtUqp(self, boundFunction(self.VVCcjc, path, selFile), title="Script File Options", VVE6xF=self.VV9Gyg())
 def VVCcjc(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FF1D46(self, path)
   elif item == "script_Execute" : self.VVqugi(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CC5Lyi(self, path)
 def VVLqS5(self, addSep=False):
  VVE6xF = []
  if addSep:
   VVE6xF.append(VVBgIm)
  VVE6xF.append((VVII83 + "Browse IPTV Channels"  , "m3u_Browse" ))
  VVE6xF.append((VVII83 + "Edit"      , "m3u_Edit" ))
  VVE6xF.append((VVII83 + "View"      , "m3u_View" ))
  return VVE6xF
 def VVgmhd(self, path, selFile):
  FFtUqp(self, boundFunction(self.VV6P0FItem_m3u, path, selFile), title="M3U/M3U8 File Options", VVE6xF=self.VVLqS5())
 def VV6P0FItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFy61j(self, boundFunction(self.session.open, CCZkJV, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CC5Lyi(self, path)
   elif item == "m3u_View"  : FF1D46(self, path)
 def VVTYLy(self, path):
  if fileExists(path) : FFy61j(self, boundFunction(CCVXoR.VVlt7K, self, path, boundFunction(self.VVTsqi, path), defEnc=None), title="Loading Codecs ...", clearMsg=False)
  else    : FFC6jW(self, path)
 def VVTsqi(self, path, item=None):
  if item:
   FF1D46(self, path, encLst=item)
 def VVL2gR(self, path, selFile, newChmod):
  FFZhjP(self, boundFunction(self.VVBUpH, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVBUpH(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVGWSe)
  result = FFmAmO(cmd)
  if result == "Successful" : FFrSV8(self, result)
  else      : FFDQ9M(self, result)
 def VVpQtB(self, path, selFile):
  parent = FFsMYs(path, False)
  self.session.openWithCallback(self.VVqXLS, boundFunction(CCoBpc, mode=CCoBpc.VVLlqx, VVRddm=parent, VVxmlw="Create Symlink here"))
 def VVqXLS(self, newPath):
  if len(newPath) > 0:
   target = self.VVttea(self.VVtbO0())
   target = FFkxUt(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFSNlf(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFDQ9M(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFZhjP(self, boundFunction(self.VVTdPF, target, link), "Create Soft Link ?\n\n%s" % txt, VVXqay=True)
 def VVTdPF(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVGWSe)
  result = FFmAmO(cmd)
  if result == "Successful" : FFrSV8(self, result)
  else      : FFDQ9M(self, result)
 def VVngKz(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFzG9s(self, boundFunction(self.VVkZTE, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVkZTE(self, path, selFile, VVsHM3):
  if VVsHM3:
   parent = FFsMYs(path, True)
   if os.path.isdir(path):
    path = FFkxUt(path)
   newName = parent + VVsHM3
   cmd = "mv '%s' '%s' %s" % (path, newName, VVGWSe)
   if VVsHM3:
    if selFile != VVsHM3:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFZhjP(self, boundFunction(self.VVZXmO, cmd), message, title="Rename file?")
    else:
     FFDQ9M(self, "Cannot use same name!", title="Rename")
 def VVZXmO(self, cmd):
  result = FFmAmO(cmd)
  if "Fail" in result:
   FFDQ9M(self, result)
  self.VVHTSv()
 def VVpPWf(self, path, selFile, isMove):
  if isMove : VVxmlw = "Move to here"
  else  : VVxmlw = "Copy to here"
  parent = FFsMYs(path, False)
  self.session.openWithCallback(boundFunction(self.VVU62w, isMove, path, selFile)
         , boundFunction(CCoBpc, mode=CCoBpc.VVLlqx, VVRddm=parent, VVxmlw=VVxmlw))
 def VVU62w(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFkxUt(path)
   newPath = FFSNlf(newPath)
   dest = newPath + lastPart
   if os.path.isdir(path) and os.path.isdir(dest):
    if isMove:
     FFDQ9M(self, 'Same directory already exists:\n\n%s\n\n( Try to copy then delete the source )' % dest)
     return
    else:
     dest = newPath
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFZhjP(self, boundFunction(FFAiEX, self, cmd, VV6fyE=self.VVHTSv), txt, VVXqay=True)
   else:
    FFDQ9M(self, "Cannot %s to same directory !" % action.lower())
 def VVEYyO(self, path, fileName):
  path = FFkxUt(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFZhjP(self, boundFunction(self.VVoCB1, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVoCB1(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VVHTSv()
 def VV2K9o(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VV0DJY and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVqEtU(self, path, isFile):
  dirName = FFSNlf(os.path.dirname(path))
  if isFile : objName, VVsHM3 = "File"  , self.edited_newFile
  else  : objName, VVsHM3 = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFzG9s(self, boundFunction(self.VVHvhf, dirName, isFile, title), title=title, defaultText=VVsHM3, message="Enter %s Name:" % objName)
 def VVHvhf(self, dirName, isFile, title, VVsHM3):
  if VVsHM3:
   if isFile : self.edited_newFile = VVsHM3
   else  : self.edited_newDir  = VVsHM3
   path = dirName + VVsHM3
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVGWSe)
    else  : cmd = "mkdir '%s' %s" % (path, VVGWSe)
    result = FFmAmO(cmd)
    if "Fail" in result:
     FFDQ9M(self, result)
    self.VVHTSv()
   else:
    FFDQ9M(self, "Name already exists !\n\n%s" % path, title)
 def VVFBk7(self, path, selFile):
  VVE6xF = []
  VVE6xF.append(("List Package Files"          , "VVnyqO"     ))
  VVE6xF.append(("Package Information"          , "VVMLBB"     ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Install Package"           , "VVxLca_CheckVersion" ))
  VVE6xF.append(("Install Package (force reinstall)"      , "VVxLca_ForceReinstall" ))
  VVE6xF.append(("Install Package (force overwrite)"      , "VVxLca_ForceOverwrite" ))
  VVE6xF.append(("Install Package (force downgrade)"      , "VVxLca_ForceDowngrade" ))
  VVE6xF.append(("Install Package (ignore failed dependencies)"    , "VVxLca_IgnoreDepends" ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Remove Related Package"         , "VVgUsu_ExistingPackage" ))
  VVE6xF.append(("Remove Related Package (force remove)"     , "VVgUsu_ForceRemove"  ))
  VVE6xF.append(("Remove Related Package (ignore failed dependencies)"  , "VVgUsu_IgnoreDepends" ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("Extract Files"           , "VVpcnW"     ))
  VVE6xF.append(("Unbuild Package"           , "VVCGcR"     ))
  FFtUqp(self, boundFunction(self.VVBmP1, path, selFile), VVE6xF=VVE6xF)
 def VVBmP1(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVnyqO"      : self.VVnyqO(path, selFile)
   elif item == "VVMLBB"      : self.VVMLBB(path)
   elif item == "VVxLca_CheckVersion"  : self.VVxLca(path, selFile, VVOR4D     )
   elif item == "VVxLca_ForceReinstall" : self.VVxLca(path, selFile, VVPoce )
   elif item == "VVxLca_ForceOverwrite" : self.VVxLca(path, selFile, VV6Sp7 )
   elif item == "VVxLca_ForceDowngrade" : self.VVxLca(path, selFile, VVnwcJ )
   elif item == "VVxLca_IgnoreDepends" : self.VVxLca(path, selFile, VVbCwc )
   elif item == "VVgUsu_ExistingPackage" : self.VVgUsu(path, selFile, VV9JbV     )
   elif item == "VVgUsu_ForceRemove"  : self.VVgUsu(path, selFile, VVodMr  )
   elif item == "VVgUsu_IgnoreDepends"  : self.VVgUsu(path, selFile, VVPul6 )
   elif item == "VVpcnW"     : self.VVpcnW(path, selFile)
   elif item == "VVCGcR"     : self.VVCGcR(path, selFile)
   else           : self.close()
 def VVnyqO(self, path, selFile):
  if FF04jg("ar") : cmd = "allOK='1';"
  else    : cmd  = FFDxbr()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VV0fId, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VV0fId, VV0fId)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFrwEd(self, cmd, VV6fyE=self.VVHTSv)
 def VVpcnW(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFsMYs(path, True) + selFile[:-4]
  cmd  =  FFDxbr()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFGA8O("mkdir '%s'" % dest) + ";"
  cmd +=    FFGA8O("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FF2CqO(dest, VVcGUH))
  cmd += "fi;"
  FFR9ZE(self, cmd, VV6fyE=self.VVHTSv)
 def VVCGcR(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VV6arv = os.path.splitext(path)[0]
  else        : VV6arv = path + "_"
  if path.endswith(".deb")   : VVZQiM = "DEBIAN"
  else        : VVZQiM = "CONTROL"
  cmd  = FFDxbr()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VV6arv, FFGDo5())
  cmd += "  mkdir '%s';"    % VV6arv
  cmd += "  CONTPATH='%s/%s';"  % (VV6arv, VVZQiM)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VV6arv
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VV6arv, VV6arv)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VV6arv
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VV6arv, VV6arv)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VV6arv
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VV6arv
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VV6arv, FF2CqO(VV6arv, VVcGUH))
  cmd += "fi;"
  FFR9ZE(self, cmd, VV6fyE=self.VVHTSv)
 def VVMLBB(self, path):
  listCmd  = FFomnU(VVoGNt, "")
  infoCmd  = FFH2eT(VVeYXl , "")
  filesCmd = FFH2eT(VVP3o8, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFNiKT(VVuneX)
   notInst = "Package not installed."
   cmd  = FFIQaW("File Info", VVuneX)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFIQaW("System Info", VVuneX)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FF2CqO(notInst, VVII83))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFIQaW("Related Files", VVuneX)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FF5cnY(self, cmd)
  else:
   FFVSFz(self)
 def VVxLca(self, path, selFile, cmdOpt):
  cmd = FFH2eT(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFZhjP(self, boundFunction(FFR9ZE, self, cmd, VV6fyE=FFQnRo), "Install Package ?\n\n%s" % selFile)
  else:
   FFVSFz(self)
 def VVgUsu(self, path, selFile, cmdOpt):
  listCmd  = FFomnU(VVoGNt, "")
  infoCmd  = FFH2eT(VVeYXl, "")
  instRemCmd = FFH2eT(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FF2CqO(errTxt, VVII83))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FF2CqO(cannotTxt, VVII83))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FF2CqO(tryTxt, VVII83))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFZhjP(self, boundFunction(FFR9ZE, self, cmd, VV6fyE=FFQnRo), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFVSFz(self)
 def VVLnrX(self, path):
  hostName = FFmAmO("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VV4R0b(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVLnrX(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVyI2z(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVE6xF = []
  VVE6xF.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVE6xF.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVE6xF.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVE6xF.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVE6xF.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVE6xF.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVE6xF.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVE6xF.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVE6xF.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVE6xF.append(VVBgIm)
  VVE6xF.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVE6xF.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FFtUqp(self, boundFunction(self.VVpN9F, path), VVE6xF=VVE6xF)
 def VVpN9F(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVpHw6(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVpHw6(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVpHw6(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVpHw6(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVpHw6(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVpHw6(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVpHw6(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVpHw6(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVpHw6(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVpHw6(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVBCkf(path, False)
   elif item == "convertDirToDeb"   : self.VVBCkf(path, True)
   else         : self.close()
 def VVBCkf(self, path, VVctLC):
  self.session.openWithCallback(self.VVHTSv, boundFunction(CCiS47, path=path, VVctLC=VVctLC))
 def VVpHw6(self, path, fileExt, preserveDirStruct):
  parent  = FFsMYs(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFCwJZ("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFCwJZ("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFCwJZ("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VV0fId
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFGA8O("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FF2CqO(resultFile, VVcGUH))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FF2CqO(failed, VVovWl))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFrwEd(self, cmd, VV6fyE=self.VVHTSv)
 def VVgJn4(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FF1D46(self, versionFile)
 def VVKfhW(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVLnrX(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFDQ9M(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFel5Q(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFsMYs(path, False)
  VV6arv = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FF2CqO(errCmd, VVovWl))
  installCmd = FFH2eT(VVOR4D , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VV6arv, VV6arv)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VV6arv
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VV6arv
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VV6arv, VV6arv)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFR9ZE(self, cmd, VV6fyE=self.VVHTSv)
 def VV0t6J(self, path):
  FFDQ9M(self, "Under Construction.")
 def VVgPLw(self, path):
  FFDQ9M(self, "Under Construction.")
 @staticmethod
 def VV70MR(SELF, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   SELF.session.open(CCZOmQ, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVDIiU(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFSNlf(fDir), fName
  return "", "", ""
 @staticmethod
 def VV7lvz(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVvPBf(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVDLDB(size, mode=0):
  txt = CCoBpc.VViA57(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VViA57(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
class CCNRz6(MenuList):
 def __init__(self, VV7NEF=False, directory="/", VVk8p3=True, VV24ng=True, VV66T5=True, VVuxtC=None, VVTbp0=False, VVxCOC=False, VVsad1=False, isTop=False, VVh8nk=None, VVJKSE=1000, VVhkQh=30, VVQFBH=30, VV1XMl="#00000000"):
  MenuList.__init__(self, list, VV7NEF, eListboxPythonMultiContent)
  self.VVk8p3  = VVk8p3
  self.VV24ng    = VV24ng
  self.VV66T5  = VV66T5
  self.VVuxtC  = VVuxtC
  self.VVTbp0   = VVTbp0
  self.VVxCOC   = VVxCOC or []
  self.VVsad1   = VVsad1 or []
  self.isTop     = isTop
  self.additional_extensions = VVh8nk
  self.VVJKSE    = VVJKSE
  self.VVhkQh    = VVhkQh
  self.VVQFBH    = VVQFBH
  self.pngBGColor    = FFTNDf(VV1XMl)
  self.EXTENSIONS    = self.VV1HLS()
  self.VVUKzq   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VV1ltY, self.VVhkQh))
  self.l.setItemHeight(self.VVQFBH)
  self.png_mem   = self.VV33Je("mem")
  self.png_usb   = self.VV33Je("usb")
  self.png_fil   = self.VV33Je("fil")
  self.png_dir   = self.VV33Je("dir")
  self.png_dirup   = self.VV33Je("dirup")
  self.png_srv   = self.VV33Je("srv")
  self.png_slwfil   = self.VV33Je("slwfil")
  self.png_slbfil   = self.VV33Je("slbfil")
  self.png_slwdir   = self.VV33Je("slwdir")
  self.VVwx0x()
  self.VVut4g(directory)
 def VV33Je(self, category):
  return LoadPixmap("%s%s.png" % (VVMNbP, category), getDesktop(0))
 def VV1HLS(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "rar" : "rar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u" ,
   "m3u8" : "m3u"
  }
 def VVWRGH(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFkxUt(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFcK2v(" -> " , VVuneX) + FFcK2v(os.readlink(path), VVcGUH)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVQFBH + 10, 0, self.VVJKSE, self.VVQFBH, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVChHQ: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVQFBH-4, self.VVQFBH-4, png, self.pngBGColor, self.pngBGColor, VVChHQ))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVQFBH-4, self.VVQFBH-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVFfWn(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVwx0x(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVqlH5(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VV76P0(self, file):
  if os.path.realpath(file) == file:
   return self.VVqlH5(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVqlH5(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVqlH5(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VV3MIY(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVUKzq.info(l[0][0]).getEvent(l[0][0])
 def VVtT07(self):
  return self.list
 def VV2pvE(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVut4g(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VV66T5:
    self.current_mountpoint = self.VV76P0(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VV66T5:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVsad1 and not self.VV2pvE(path, self.VVxCOC):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVWRGH(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVTbp0:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVUKzq = eServiceCenter.getInstance()
   list = VVUKzq.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVk8p3 and not self.isTop:
   if directory == self.current_mountpoint and self.VV66T5:
    self.list.append(self.VVWRGH(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVsad1 and self.VVqlH5(directory) in self.VVsad1):
    self.list.append(self.VVWRGH(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVk8p3:
   for x in directories:
    if not (self.VVsad1 and self.VVqlH5(x) in self.VVsad1) and not self.VV2pvE(x, self.VVxCOC):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVWRGH(name = name, absolute = x, isDir = True, png = png))
  if self.VV24ng:
   for x in files:
    if self.VVTbp0:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFcK2v(" -> " , VVuneX) + FFcK2v(target, VVcGUH)
       else:
        png = self.png_slbfil
        name += FFcK2v(" -> " , VVuneX) + FFcK2v(target, VVovWl)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVFfWn(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVMNbP, category))
    if (self.VVuxtC is None) or iCompile(self.VVuxtC).search(path):
     self.list.append(self.VVWRGH(name = name, absolute = x , isDir = False, png = png))
  if self.VV66T5 and len(self.list) == 0:
   self.list.append(self.VVWRGH(name = FFcK2v("No USB connected", VVXOiG), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVX7f9(self):
  return self.current_directory
 def VVLgMg(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVut4g(self.getSelection()[0], select = self.current_directory)
 def VVAeJ2(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVM0nQ(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVlz8k)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVlz8k)
 def refresh(self):
  self.VVut4g(self.current_directory, self.VVAeJ2())
 def VVlz8k(self, action, device):
  self.VVwx0x()
  if self.current_directory is None:
   self.refresh()
class CCQSWl(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FFoyhf(VVBmKE, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVU7lj   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VV736g(defFG, "#00FFFFFF")
  self.defBG   = self.VV736g(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FF8NiA(self, self.Title)
  self["keyRed"].show()
  FFUWFF(self["keyGreen"] , "< > Transp.")
  FFUWFF(self["keyYellow"], "Foreground")
  FFUWFF(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVmyg9        ,
   "yellow"   : boundFunction(self.VVAVgK, False)  ,
   "blue"   : boundFunction(self.VVAVgK, True)  ,
   "up"   : self.VV860S          ,
   "down"   : self.VV1G2T         ,
   "left"   : self.VVjnNT         ,
   "right"   : self.VV04H7         ,
   "last"   : boundFunction(self.VVxeBh, -5) ,
   "next"   : boundFunction(self.VVxeBh, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFH6QJ(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFH6QJ(self["keyRed"] , c)
  FFH6QJ(self["keyGreen"] , c)
  self.VVqj9f()
  self.VVTkL1()
  FF2dIb(self["myColorTst"], self.defFG)
  FFH6QJ(self["myColorTst"], self.defBG)
 def VV736g(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVTkL1(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VV2w0N(0, 0)
     return
 def VVmyg9(self):
  self.close(self.defFG, self.defBG)
 def VV860S(self): self.VV2w0N(-1, 0)
 def VV1G2T(self): self.VV2w0N(1, 0)
 def VVjnNT(self): self.VV2w0N(0, -1)
 def VV04H7(self): self.VV2w0N(0, 1)
 def VV2w0N(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVTjob()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVazxu()
 def VVqj9f(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVazxu(self):
  color = self.VVTjob()
  if self.isBgMode: FFH6QJ(self["myColorTst"], color)
  else   : FF2dIb(self["myColorTst"], color)
 def VVAVgK(self, isBg):
  self.isBgMode = isBg
  self.VVqj9f()
  self.VVTkL1()
 def VVxeBh(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VV2w0N(0, 0)
 def VVN2hp(self):
  return hex(self.transp)[2:].zfill(2)
 def VVTjob(self):
  return ("#%s%s" % (self.VVN2hp(), self.colors[self.curRow][self.curCol])).upper()
class CCKkaB(Screen):
 VVDmI0  = 0
 VVXgjV = 1
 def __init__(self, session, mode, endCallback):
  self.session  = session
  margin    = 50
  screenSize   = FFzSJo()
  w     = int(screenSize[0] - margin)
  h     = int(screenSize[1] / 2.0)
  self.skin, self.skinParam = FFoyhf(WINDOW_SUBTITLE, w, h, 35, 20, 30, "#ff000000", "#ff000000", 60)
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.currentIndex  = -1
  self.subtitleMode  = mode
  self.defaultY   = 0
  self.endCallback  = endCallback
  FF8NiA(self)
  self["myTitle"].hide()
  self["mySubtFr"] = Label()
  self["mySubtFr"].hide()
  for i in range(3):
   self["mySubt%d" % i] = Label()
  self.onClose.append(self.VVDrbg)
 def VVhjQS(self, path=""):
  if path :
   self.VV1PlI()
   FFy61j(self, boundFunction(self.VVkApL, path), title="Checking file ...", clearMsg=False)
  else:
   self.VVkApL()
 def VVkApL(self, path=""):
  if path:
   subtList, err = self.VVcJbS(path)
   if err    : self.VVDrbg(err)
   elif not subtList : self.VVDrbg("Invalid srt file")
   else    :
    self.subtList = subtList
    self.VVQno9()
  else:
   if self.VVya6N():
    self.VVQno9()
   elif self.subtitleMode == CCKkaB.VVXgjV:
    self.VVDrbg("noResume")
   else:
    if self.VVX5ST(): self.VVQno9()
    else         : self.VVDrbg("noAutoSrt")
 def VVQno9(self):
  try:
   InfoBar.instance.enableSubtitle(None)
  except:
   try:
    InfoBar.instance.setSubtitlesEnable(False)
   except:
    pass
  FF7QSu(self, "Subtitle started", 1000, isGrn=True)
  self.VV1PlI()
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVeBw0)
  except:
   self.timerUpdate.callback.append(self.VVeBw0)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVSvcG)
  except:
   self.timerEndText.callback.append(self.VVSvcG)
  self.VVpJL0(True)
 def VVDrbg(self, res=""):
  self.timerUpdate.stop()
  self.timerEndText.stop()
  self.VVpJL0(False)
  self.endCallback(res)
 def VVpJL0(self, isAdd):
  lst = [CFG.subtDelay, CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextSize, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtShadowSize, CFG.subtVerticalPos]
  notifier = self.VV1PlI
  for item in lst:
   if isAdd:
    item.addNotifier(notifier, initial_call=False)
   else:
    try:
     item.removeNotifier(notifier)
    except:
     try:
      notifier in item.notifiers and item.notifiers.remove(notifier)
      notifier in item.notifiers_final and item.notifiers_final.remove(notifier)
     except Exception as e:
      pass
 def VVya6N(self):
  path = self.VV8wth()
  if path:
   if fileExists(path):
    lines = FFel5Q(path)
    srt = delay = enc = ""
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : srtPath = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay   = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc   = line.split("=")[1].strip()
    if srtPath and fileExists(srtPath):
     subtList, err = self.VVcJbS(srtPath, enc)
     if subtList:
      self.lastSubtEnc = enc
      self.subtList = subtList
      try:
       CFG.subtDelay.setValue("%.1f" % float(delay))
      except:
       pass
      return True
  return False
 def VVX5ST(self):
  bestSrt, bestRatio = CCKkaB.VVw3q1(self)
  if bestSrt and bestRatio > 40:
   subtList, err = self.VVcJbS(bestSrt)
   if subtList:
    self.subtList = subtList
    return True
  return False
 def VVwx0y(self):
  VVE6xF = []
  if self.lastSubtFile:
   VVE6xF.append(("Settings"      , "set"  ))
   VVE6xF.append(("Change Encoding"    , "enc"  ))
   VVE6xF.append(("Disable Current Subtitle"  , "disab" ))
   VVE6xF.append(VVBgIm)
  VVE6xF.append(("Find all srt file"    , "findSrt" ))
  lst = CCKkaB.VV8UzC(self)
  if lst:
   VVE6xF.append(VVBgIm)
   for item in lst:
    fName = os.path.basename(item)
    if self.lastSubtFile == item:
     fName = FFcK2v(fName, VVcGUH)
    VVE6xF.append((fName, item))
  win = FFtUqp(self, self.VVtbni, VVE6xF=VVE6xF, width=1200, title="Subtitle Options")
  win.instance.move(ePoint(40, 40))
 def VVtbni(self, item=None):
  if item:
   if item == "set":
    self["mySubtFr"].show()
    for i in range(3):
     FFH6QJ(self["mySubt%d" % i], "#55000000")
    self.session.openWithCallback(self.VV5cun, CCcM7Q)
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile):
     FFy61j(self, boundFunction(CCVXoR.VVlt7K, self, self.lastSubtFile, self.VVOCys, defEnc=self.lastSubtEnc, pos=1), title="Loading Codecs ...", clearMsg=False)
    else:
     FF7QSu(self, "SRT File error", 1000)
   elif item == "disab":
    path = self.VV8wth()
    os.system(FFGA8O("rm -f '%s'" % path))
    self.VVDrbg("noErr")
   elif item == "findSrt":
    CCKkaB.VVBHxE(self, self.VVd89Z, defSrt=self.lastSubtFile, pos=1)
   else:
    self.VVd89Z(item)
 def VV5cun(self, res):
  self["mySubtFr"].hide()
  for i in range(3):
   FFH6QJ(self["mySubt%d" % i], "#FF000000")
  if res:
   self.VVdXsd()
   self.VV1PlI()
 def VV1PlI(self, configElement=None):
  fnt = CFG.subtTextFont.getValue()
  if not fnt in FFIJwc():
   fnt = VV1ltY
  lineH = 0
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FF2dIb(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    inst.setHAlign(int(CFG.subtTextAlign.getValue()))
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    inst.setNoWrap(True)
    lineH = FFPMOz(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    inst.move(ePoint(int(inst.position().x()), int(lineH * i + 1)))
  except:
   pass
  try:
   height = lineH * 3 + 2
   if not self.defaultY:
    self.defaultY = int(getDesktop(0).size().height() - height - self.skinParam["marginTop"])
   if lineH:
    self.instance.resize(eSize(*(int(self.instance.size().width()), height)))
   y = int(self.defaultY + CFG.subtVerticalPos.getValue())
   y = min(y, getDesktop(0).size().height() - height - 5)
   self.instance.move(ePoint(int(self.instance.position().x()), int(y)))
   inst = self["myInfoFrame"].instance
   inst.move(ePoint(int(inst.position().x()), 2))
   inst = self["myInfoBody"].instance
   inst.move(ePoint(int(inst.position().x()), 4))
  except:
   pass
 def VVd89Z(self, path, enc=None):
  self.timerUpdate.stop()
  subtList, err = self.VVcJbS(path, enc)
  if err    : FF7QSu(self, err, 2000)
  elif not subtList : FF7QSu(self, "Invalid SRT file", 2000)
  else    :
   self.subtList  = subtList
   self.lastSubtInfo = ""
   self.lastSubtEnc = ""
   self.currentIndex = 0
   CFG.subtDelay.setValue("0.0")
   for i in range(3):
    FF2dIb(self["mySubt%d" % i], "#ffffff")
    self["mySubt%d" % i].setText("")
   FF7QSu(self, "Subtitle started", 1000, isGrn=True)
  self.timerUpdate.start(500, False)
 def VVOCys(self, item=None):
  if item:
   self.VVd89Z(self.lastSubtFile, item)
 @staticmethod
 def VV8UzC(SELF):
  fPath, fDir, fName = CCoBpc.VVDIiU(SELF)
  if pathExists(fDir):
   files = iGlob("%s*.srt" % fDir)
   if files:
    return files
  return []
 @staticmethod
 def VVw3q1(SELF):
  bestSrt = ""
  bestRatio = 0
  fPath, fDir, fName = CCoBpc.VVDIiU(SELF)
  if fName:
   movName = os.path.splitext(fName)[0].lower()
   files = CCKkaB.VV8UzC(SELF)
   for path in files:
    fName = os.path.basename(path)
    fName = os.path.splitext(fName)[0]
    ratio = CC5NMK.VVzCR6(movName.lower(), fName.lower())
    if ratio > bestRatio:
     bestRatio = ratio
     bestSrt = path
  return bestSrt, bestRatio
 def VVEeAA(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVcJbS(self, path, enc=None):
  if not fileExists(path):
   return [], "File not found"
  if (FFLJ49(path) > 1024 * 700):
   return [], "File too big"
  capNum = frmSec = toSec = bold = italic = under = 0
  color  = ""
  subtLines = []
  subtList = []
  capFound = False
  lines  = FFel5Q(path, encLst=enc if enc else None)
  for line in lines:
   line = line.strip()
   if line:
    if not capFound and line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVEeAA(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      subtLines.append((line.strip(), color, bold, italic, under))
   else:
    if (toSec - frmSec) > 0:
     subtList.append((capNum, frmSec, toSec, subtLines))
    capFound = False
    subtLines = []
    color = ""
    capNum = frmSec = toSec = bold = italic = under = 0
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVdXsd()
  return subtList, ""
 def VVdXsd(self):
  path = self.VV8wth()
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelay.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VV8wth(self):
  fPath, fDir, fName = CCoBpc.VVDIiU(self)
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEN32(self)
   if iptvRef: fPath = "/tmp/" + chName
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCzqpW.VV1P3e(self)
   if evName and evTime and evDur: fPath = "/tmp/" + evName
  if fPath: return fPath + ".ajp"
  else : return ""
 def VVeBw0(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCZOmQ.VVIo9B(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCzqpW.VV1P3e(self)
   if evTime and evDur:
    posVal = iTime() - evTime
  self.VVV8la(posVal)
  if self.currentIndex == -2:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[self.currentIndex]
   if not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    for i in range(3):
     FF2dIb(self["mySubt%d" % i], "#ffffff")
     self["mySubt%d" % i].setText("")
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
     txtDur = int(toSec * 1000 - frmSec * 1000)
     if txtDur > 0:
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        line = line.replace(u"\u202A", "")
        line = line.replace(u"\u202B", "")
        line = line.replace(u"\u202C", "")
        line = str(line)
        if newColor:
         FF2dIb(self["mySubt%d" % ndx], newColor)
        self["mySubt%d" % ndx].setText(line)
      self.timerEndText.start(txtDur, True)
 def VVV8la(self, posVal):
  if posVal > 0:
   delay = float(CFG.subtDelay.getValue())
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     self.currentIndex = ndx
     return
  self.currentIndex = -2
 def VVSvcG(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
 @staticmethod
 def VVBHxE(SELF, cbFnc, defSrt="", pos=0):
  FFy61j(SELF, boundFunction(CCKkaB.VVYr62, SELF, cbFnc, defSrt, pos), title="Searching for srt files", clearMsg=False)
 @staticmethod
 def VVYr62(SELF, cbFnc, defSrt="", pos=0):
  FF7QSu(SELF)
  lines = FFDp6V('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFGFzp(1)))
  if lines:
   lines.sort()
   VVE6xF = []
   for item in lines:
    VVE6xF.append(((VVcGUH if defSrt == item else "") + item, item))
   VVf3L2 = ("Show Full Path", CCKkaB.VVmJfw)
   win = FFtUqp(SELF, boundFunction(CCKkaB.VVSNhs, cbFnc), title="Subtitle Files", VVE6xF=VVE6xF, width=1200, height=500 if pos == 1 else 900, VVf3L2=VVf3L2)
   if pos == 1:
    win.instance.move(ePoint(40, 40))
  else:
   FF7QSu(SELF, "No srt files found !", 2000)
 @staticmethod
 def VVmJfw(VVtbO0Obj, path):
  FFUojK(VVtbO0Obj, path, title="Full Path")
 @staticmethod
 def VVSNhs(cbFnc, item):
  if item:
   cbFnc(item)
 @staticmethod
 def VVV5Wf():
  c = s = m = h = 0
  with open(VVXcuX + "AJPanel_test.srt", "w") as f:
   for i in range(1, 5401):
    s += 2
    if s >= 60:
     s = 0
     m += 1
     if m >= 60:
      m = 0
      h += 1
    if i < 6:
     txt  = '<font color="#ffff00">Created by AJPanel</font>\n'
     txt += '<font color="#00ffff">Testing Subtitle Files</font>\n'
     txt += '<font color="#00ff00">Line - %d</font>\n\n' % i
    else:
     txt = '<font color="#ffffbb">Subtitle Line - %d</font>\n\n' % i
    f.write("%d\n" % i)
    f.write("%02d:%02d:%02d,001 --> %02d:%02d:%02d,001\n" % (h, m, s, h, m, s+1))
    f.write(txt)
class CCcM7Q(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFoyhf(VVnsgM, 600, 600, 40, 30, 10, "#11331010", "#11442020", 30, barHeight=40)
  self.session  = session
  self.Title   = "Subtitle Settings"
  FF8NiA(self, title=self.Title)
  FFUWFF(self["keyRed"] , "Exit")
  FFUWFF(self["keyGreen"] , "Save")
  FFUWFF(self["keyYellow"], "Reset")
  self.confList = []
  self.confList.append(getConfigListEntry("Delay (current movie)" , CFG.subtDelay   ))
  self.confList.append(getConfigListEntry(VV0fId *2     ,       ))
  self.confList.append(getConfigListEntry("Text Color"   , CFG.subtTextFg  ))
  self.confList.append(getConfigListEntry("Text Font"    , CFG.subtTextFont  ))
  self.confList.append(getConfigListEntry("Text Size"    , CFG.subtTextSize  ))
  self.confList.append(getConfigListEntry("Alignment"    , CFG.subtTextAlign  ))
  self.confList.append(getConfigListEntry("Shadow Color"   , CFG.subtShadowColor ))
  self.confList.append(getConfigListEntry("Shadow Size"   , CFG.subtShadowSize ))
  self.confList.append(getConfigListEntry(VV0fId *2     ,       ))
  self.confList.append(getConfigListEntry("Vertical Pos"   , CFG.subtVerticalPos ))
  ConfigListScreen.__init__(self, self.confList, session)
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVPPvc  ,
   "green"   : self.VVlSEj   ,
   "yellow"  : boundFunction(FFZhjP, self, self.VVnMQW, "Reset Subtitle Settings to default ?", title="Subtitle Settings"),
   "cancel"  : self.VVPPvc
  }, -1)
  self.onShown.append(self.VVbxfr)
 def VVbxfr(self):
  self.onShown.remove(self.VVbxfr)
  FFCnHd(self["config"])
  FFoto4(self, self["config"])
  FFvFrO(self)
  self.instance.move(ePoint(40, 40))
 def VVPPvc(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFZhjP(self, self.VVlSEj, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVlSEj(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  configfile.save()
  self.close(True)
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close(False)
 def VVnMQW(self):
  CFG.subtDelay.setValue("0.0")
  CFG.subtTextFg.setValue("srt")
  CFG.subtTextFont.setValue(VV1ltY)
  CFG.subtTextSize.setValue(50)
  CFG.subtTextAlign.setValue("1")
  CFG.subtShadowColor.setValue("#000080")
  CFG.subtShadowSize.setValue(5)
  CFG.subtVerticalPos.setValue(0)
  self.VVlSEj()
class CCDWBz(ScrollLabel):
 def __init__(self, parentSELF, text="", VVe0Vt=True):
  ScrollLabel.__init__(self, text)
  self.VVe0Vt=VVe0Vt
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVOMk9  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVhkQh    = None
  self.parentW    = None
  self.parentH    = None
  self.firstTime    = True
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close     ,
   "cancel"  : parentSELF.close     ,
   "red"   : self.VVmAVM     ,
   "green"   : self.VVl5Y9    ,
   "yellow"  : self.VVRSb6    ,
   "blue"   : self.VVu1eQ    ,
   "up"   : self.pageUp      ,
   "down"   : self.pageDown      ,
   "left"   : self.pageUp      ,
   "right"   : self.pageDown      ,
   "last"   : boundFunction(self.VVXTCh, 0) ,
   "next"   : boundFunction(self.VVXTCh, 2) ,
   "0"    : boundFunction(self.VVXTCh, 1) ,
   "pageUp"  : self.VVUBY0      ,
   "chanUp"  : self.VVUBY0      ,
   "pageDown"  : self.VVuTef      ,
   "chanDown"  : self.VVuTef
  }, -1)
 def VVfh1g(self, isResizable=True, VVYs0e=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FFvFrO(self.parentSELF, True)
  self.isResizable = isResizable
  if VVYs0e:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVhkQh  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFH6QJ(self, color)
 def FFH6QJColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVOMk9 - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVUthu()
 def pageUp(self):
  if self.VVOMk9 > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVOMk9 > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVUBY0(self):
  self.setPos(0)
 def VVuTef(self):
  self.setPos(self.VVOMk9-self.pageHeight)
 def VVnq8D(self):
  return self.VVOMk9 <= self.pageHeight or self.curPos == self.VVOMk9 - self.pageHeight
 def VVUthu(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVOMk9, 3))
   start = int((100 - vis) * self.curPos / (self.VVOMk9 - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVvy8W=VVxNTa):
  old_VVnq8D = self.VVnq8D()
  self.message = str(text)
  if self.pageHeight:
   self.long_text.setText(self.message)
   self.VVOMk9 = self.long_text.calculateSize().height()
   if self.VVe0Vt and self.VVOMk9 > self.pageHeight:
    self.scrollbar.show()
    self.VVUthu()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVOMk9))
   if   VVvy8W == VV9a7T: self.setPos(0)
   elif VVvy8W == VV39v7 : self.VVuTef()
   elif old_VVnq8D    : self.VVuTef()
   if self.firstTime and len(self.message) > 0:
    self.firstTime = False
    self.setText(self.message, VVvy8W=VVvy8W)
 def appendText(self, text, VVvy8W=VV39v7):
  self.setText(self.message + str(text), VVvy8W=VVvy8W)
 def VVRSb6(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVxwzW(size)
 def VVu1eQ(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVxwzW(size)
 def VVl5Y9(self):
  self.VVxwzW(self.VVhkQh)
 def VVxwzW(self, VVhkQh):
  self.long_text.setFont(gFont(self.fontFamily, VVhkQh))
  self.setText(self.message, VVvy8W=VVxNTa)
  self.VVnF2W(calledFromFontSizer=True)
 def VVXTCh(self, align):
  self.long_text.setHAlign(align)
 def VVmAVM(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FFSNlf(expPath), self.textOutFile, FFmDuf())
    with open(outF, "w") as f:
     f.write(FF67wV(self.message))
    FFrSV8(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FFDQ9M(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVnF2W(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVOMk9 > 0 and self.pageHeight > 0:
   if self.VVOMk9 < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVOMk9
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
