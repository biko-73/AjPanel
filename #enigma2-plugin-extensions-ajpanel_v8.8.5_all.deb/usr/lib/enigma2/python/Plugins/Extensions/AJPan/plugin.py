import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from collections    import Counter as iCounter
from base64      import b64encode, b64decode
from sys      import version_info as pyVersion
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Tools.Directories   import SCOPE_CURRENT_SKIN
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile, copymode as iCopymode
except: iMove = iCopyfile = iCopymode = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VV9AsZ   = "v8.8.5"
VVY49w    = "06-05-2023"
EASY_MODE    = 0
VVsxLO   = 0
VVjQ9n   = 0
VVuGsg  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVlNeR  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVmIIf   = "AJPan"
VVEzAi  = "AUTO FIND"
VVvWaG  = "Custom"
VVrXLj    = "/media/usb/"
VVvwNj    = "/usr/share/enigma2/picon/"
VVMixw   = "/etc/enigma2/"
VVDhAD   = VVMixw + "settings"
VV6lWZ = VVMixw + "blacklist"
VVth2N  = None
VVgCDK    = ""
VVUTqI = "Regular"
VVPR2M = "Fixed"
VVPRk7  = "AJP_Main"
VV6Bd8 = "AJP_Terminal"
VVjcx1 = "AJP_System"
VVwRnH  = VVUTqI
VVEyaB    = ""
VVLVyg   = " && echo 'Successful' || echo 'Failed!'"
VVeucV  = "Cannot continue (No Enough Memory) !"
VVX0Ji  = ["#119f1313","#11005500","#11a08000","#1118188b"]
VVKDoB    = ["KeyMap_RC", "KeyMap_KeyBoard"]
VVRaeq  = "utf8"
VVm7kE    = ("-" * 100, )
SEP      = "-" * 80
VVbMcv  = False
VVxrH7  = False
VVuQx7     = 0
VV59l2    = 1
VVWkz0    = 2
VV4ArL   = 3
VV8WPg    = 4
VVn9ax    = 5
VViAAJ = 6
VVWUpg = 7
VVb4PG  = 8
VVJOa0   = 9
VVgvGh  = 10
VVg2zc  = 11
VVMhmD = 12
VVgc94 = 13
VVDylj = 14
VV3N9u  = 15
VVOalx    = 16
VVMqMG   = 17
VV8KOT   = 18
VVYTfH    = 19
VVHjhJ    = 20
VVkgN4  = 21
VVZhbx    = 22
VVrJOZ   = 0
VVyFvO   = 1
VVCUL7   = 2
def FF1tiC():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VVwRnH
  if VVPRk7 in lst and CFG.fontPathMain.getValue(): VVwRnH = VVPRk7
  else               : VVwRnH = VVUTqI
  return lst
 else:
  return [VVUTqI]
def FFA3nY(path, alias, scale=100, isRepl=0):
 try:
  addFont(path, alias, scale, isRepl)
  return True
 except:
  try:
   addFont(path, alias, scale, isRepl, 0)
   return True
  except:
   pass
 return False
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[("v", "Virtual Keyboard"),("s", "System Default")])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[("d", "Directory Up"),("e", "Exit")])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[("off", "Disable"),("lok", "Long-OK"),("lesc", "Long-Exit"),("lred", "Long-Red")])
CFG.subtDefaultEnc    = ConfigDirectory(default=VVRaeq)
CFG.screenshotFType    = ConfigSelection(default="jpg", choices=[("off", "Disable"),("jpg", "JPG"),("png", "PNG"),("bmp", "BMP")])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[("1", "1 (DVB Stream)"),("4097", "4097 (servicemp3)"),("5001", "5001 (GST Player)"),("5002", "5002 (Ext-3 EPlayer)"),("8192", "8192 (HDMI input)"),("8193", "8193 (eServiceUri)")])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVEzAi, visible_width=45)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.portalConnTimeout   = ConfigSelectionNumber(default=2, stepwidth=1, min=1, max=5, wraparound=False)
CFG.PIconsPath     = ConfigDirectory(default=VVvwNj, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVrXLj, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastPkgProjDir    = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindMovie    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.lastFindRepl_fnd   = ConfigText(default="")
CFG.lastFindRepl_rpl   = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
CFG.transpColorMovies   = ConfigText(default="#11404040")
CFG.transpColorChannels   = ConfigText(default="#88004040")
CFG.epgLangTitle    = ConfigText(default="")
CFG.epgLangDescr    = ConfigText(default="")
CFG.lastFtpLocalPath   = ConfigText(default="")
CFG.lastNetworkDevice   = ConfigInteger(default=0)
CFG.terminalCmdFile    = ConfigText(default="LinuxCommands.lst")
tmp = [("srt","FROM SRT FILE"),("#00FFFF","Aqua"),("#000000","Black"),("#0000FF","Blue"),("#FF00FF","Fuchsia"),("#808080","Gray"),("#008000","Green"),("#00FF00","Lime"),("#800000","Maroon"),("#000080","Navy"),("#808000","Olive"),("#800080","Purple"),("#FF0000","Red"),("#C0C0C0","Silver"),("#008080","Teal"),("#FFFFFF","White"),("#FFFF00","Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVwRnH, choices=[(x,  x) for x in FF1tiC()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[("0", "Left"),("1", "Center"),("2", "Right")])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FFYNBN():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVDWoq  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVvhH7 = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVDWoq  : return 0
  elif VVvhH7 : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVmjYo = FFYNBN()
VVqC3w = VVdl3O = VVYZPJ = VVWgbP = VVf8NN = VVeksK = VVhCly = VVFApq = VVNQoM = VVo8aK = VVChVP = VVyz0j = VV4aa0 = VVifMr = VVJU8R = VVTKcZ = ""
def FFhsCS()  : FFG96P(FFFdpw())
def FFdeqS()  : FFG96P(FFVbVu())
def FFjFbO(tDict): FFG96P(iDumps(tDict, indent=4, sort_keys=True))
def FFhd3H(*args): FF7ZSE(True, True, *args)
def FFG96P(*args) : FF7ZSE(True , False , *args)
def FFB9TF(*args): FF7ZSE(False, False, *args)
def FF7ZSE(addSep=True, isArray=True, *args):
 if VVsxLO:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(str(key).ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFqens(fnc):
 def VVq9ml(*args, **kwargs):
  t1 = iTime()
  fnc(*args, **kwargs)
  FFG96P(">>>>>> Elapsed : %s sec\nargs = %s\nkwargs = %s" % (("%.6f" % (iTime() - t1)).rstrip("0"), args, kwargs))
 return VVq9ml
def FFcdDU(*args):
 if VVsxLO:
  path = "/tmp/ajp_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FFB9TF("Added to : %s" % path)
def FF36ju(txt, isAppend=True, ignoreErr=False):
 if VVsxLO:
  tm = FFADdS()
  err = ""
  if not ignoreErr:
   err = FFVbVu()
  fileName = "/tmp/ajp_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFG96P(err)
  FFG96P("Output Log File : %s" % fileName)
def FFVbVu():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFADdS()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFFdpw():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VV8Q6J = 0
def FFzmM8():
 global VV8Q6J
 VV8Q6J = iTime()
def FF2u23(txt=""):
 FFG96P(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VV8Q6J)).rstrip("0"), txt))
VVyAqV = []
def FF8Q9A(win):
 global VVyAqV
 if not win in VVyAqV:
  VVyAqV.append(win)
def FFcTP7(*args):
 global VVyAqV
 for win in VVyAqV:
  try:
   win.close()
  except:
   pass
 VVyAqV = []
def FFTeQk(vTxt):
 if vTxt in globals(): del globals()[vTxt]
def FFZh10():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVbE23 = FFZh10()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFpJ2N()    : return PluginDescriptor(fnc=FFRV3f, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FFlPIA()      : return getDescriptor(FFPOMh  , [ PluginDescriptor.WHERE_MENU   ] , PLUGIN_NAME     , descr="Main Menu")
def FFl3XK()     : return getDescriptor(FFwui0   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFRqQQ()  : return getDescriptor(FFN1zq , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFcUkr() : return getDescriptor(FFsHa7  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FFymWJ()  : return getDescriptor(FFN6xt  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FFUzym(): return getDescriptor(FFbHJr, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Plugin Browser"  , descr="Plugin Browser")
def FFTAus()  : return getDescriptor(FFkf3j   , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FFX5sk() : return getDescriptor(FFk3WI  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Terminal"    , descr="Terminal")
def FFCX1Q()      : return getDescriptor(FFWF1P , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFl3XK() , FFlPIA() , FFpJ2N() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFRqQQ())
  result.append(FFcUkr())
  result.append(FFymWJ())
  result.append(FFUzym())
  result.append(FFTAus())
  result.append(FFX5sk())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFCX1Q())
 return result
def FFRV3f(reason, **kwargs):
 if reason == 0:
  CCOdiR.VVMqy9()
  if "session" in kwargs:
   session = kwargs["session"]
   FFGKJO(session)
   CCf894(session)
def FFPOMh(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFwui0, PLUGIN_NAME, 45)]
 else:
  return []
def FFwui0(session, **kwargs):
 session.open(Main_Menu)
def FFN1zq(session, **kwargs) : session.open(CCyssW)
def FFsHa7(session, **kwargs)  : session.open(CCul6W)
def FFN6xt(session, **kwargs)  : CCppT7.VVkxsS(session)
def FFbHJr(session, **kwargs): CCO0s2.VVxNg1(session)
def FFkf3j(session, **kwargs)   : FFf5BK(session, reopen=True)
def FFk3WI(session, **kwargs)  : session.open(CCrdgM)
def FFWF1P(session, **kwargs):
 session.open(CCXzVR, fncMode=CCXzVR.VV0WSU)
def FF3EeP():
 FFQYIR(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [FFRqQQ(), FFcUkr(), FFymWJ(), FFUzym(), FFTAus(), FFX5sk()])
 FFQYIR(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFCX1Q() ])
def FFQYIR(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
def FFGKJO(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions["longOK"] = BF(FFSXzu, session, "lok")
 hk.actions["longCancel"]= BF(FFSXzu, session, "lesc")
 hk.actions["longRed"] = BF(FFSXzu, session, "lred")
 for k in (CCqxHs.VVr25E, CCqxHs.VVIZWA, CCqxHs.VVRchV):
  hk.actions[k] = BF(CCqxHs.VVwhb8, session, k)
def FFSXzu(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CCN4DC.VVrpd7:
    CCN4DC.VVrpd7.close()
   if not CCppT7.VVVBav:
    CCppT7.VVkxsS(session)
  except:
   pass
def FFeLB8(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FFj3mb(SELF, title="", addLabel=False, addScrollLabel=False, VVgktg=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFMV8t()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF.VVN3o2 = eTimer()
 try: SELF.VV7uVh = SELF.VVN3o2.timeout.connect(BF(FFlYCg, SELF))
 except: SELF.VVN3o2.callback.append(BF(FFlYCg, SELF))
 SELF.onClose.append(SELF.VVN3o2.stop)
 FFlYCg(SELF)
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCF1f8(SELF)
 if VVgktg:
  SELF["myMenu"] = MenuList(VVgktg)
  SELF["myActionMap"] = ActionMap(VVKDoB,
  {
   "ok" : SELF.VV96hS ,
   "cancel": SELF.close ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(VVKDoB,
  {
   "ok" : SELF.close,
   "cancel": SELF.close,
   "red" : SELF.close
  }, -1)
def FFaxrK(SELF, tableObj, colNum=0, isMenu=False):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FFYfGc, SELF, "0"),
  "1" : BF(FFYfGc, SELF, "1"),
  "2" : BF(FFYfGc, SELF, "2"),
  "3" : BF(FFYfGc, SELF, "3"),
  "4" : BF(FFYfGc, SELF, "4"),
  "5" : BF(FFYfGc, SELF, "5"),
  "6" : BF(FFYfGc, SELF, "6"),
  "7" : BF(FFYfGc, SELF, "7"),
  "8" : BF(FFYfGc, SELF, "8"),
  "9" : BF(FFYfGc, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFF1J6, SELF, tableObj, colNum, isMenu))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFYfGc(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVTKcZ:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVTKcZ + SELF.keyPressed + VVdl3O)
    txt = VVdl3O + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFpIgV(SELF, txt)
def FFF1J6(SELF, tableObj, colNum, isMenu):
 FFpIgV(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    if isMenu: item = tableObj.list[i][colNum].strip()
    else  : item = tableObj.list[i][colNum + 1][7].strip()
    item = FFOD7l(item).encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     if isMenu: SELF.VVI0nr(i)
     else  : SELF.VV2NBO(i)
     break
 except:
  pass
def FFMV8t():
 return ("  %s" % VVEyaB)
def FFuetT(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFOD7l(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFe2hp(color):
 return parseColor(color).argb()
def FFfLQO(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFeNfF(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FF6YO5(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFog5k(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVTKcZ)
 else:
  return ""
def FF9KyJ(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, SEP, word, SEP, VVTKcZ)
 else : return "echo -e '%s\n--- %s\n%s';" % (SEP, word, SEP)
def FF1YQ7(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVTKcZ
def FFMGJW(color):
 if color: return "echo -e '%s' %s;" % (SEP, FFog5k(SEP, VVChVP))
 else : return "echo -e '%s';" % SEP
def FFCQJ8(title, color):
 title = "%s\n%s\n%s\n" % (SEP, title, SEP)
 return FF1YQ7(title, color)
def FFayJd(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFgnVm(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFLYGh(fncCB):
 tCons = CCz78Z()
 tCons.ePopen(":", BF(FFJdrl, fncCB))
def FFJdrl(fncCB, result, retval):
 fncCB()
def FFkWFV(SELF, fnc, title="Processing ...", clearMsg=True):
 FFpIgV(SELF, title)
 tCons = CCz78Z()
 tCons.ePopen(":", BF(FFlMFq, SELF, fnc, clearMsg))
def FFlMFq(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFpIgV(SELF)
def FFnpLo(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVeucV
  else       : return ""
def FFa467(cmd):
 txt = FFnpLo(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFdHIn(cmd):
 lines = FFa467(cmd)
 if lines: return lines[0]
 else : return ""
def FFBlaB(SELF, cmd):
 lines = FFa467(cmd)
 VVUl7I = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVUl7I.append((key, val))
  elif line:
   VVUl7I.append((line, ""))
 if VVUl7I:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FF69ky(SELF, None, header=header, VV9gTz=VVUl7I, VVYiuZ=widths, VVvi36=28)
 else:
  FFL00E(SELF, cmd)
def FFLgW2(cmd):
 return os.system(FFhkCt(cmd)) == 0
def FFJ2Ng(cmd):
 return os.system(FFxbhS(cmd)) == 0
def FFhkCt(cmd)  : return cmd.rstrip("\t; ") + " > /dev/null 2>&1;"
def FFxbhS(cmd) : return cmd.rstrip("\t; ") + " 2> /dev/null;"
def FFL00E(    SELF, cmd, **kwargs): SELF.session.open(CCpvy4, VV4Fmi=cmd, VVdnhU=True, VVMXNv=VVyFvO, **kwargs)
def FFfu76(  SELF, cmd, **kwargs): SELF.session.open(CCpvy4, VV4Fmi=cmd, **kwargs)
def FFTKzr(   SELF, cmd, **kwargs): SELF.session.open(CCpvy4, VV4Fmi=cmd, VVWUJo=True, VV1ZDq=True, VVMXNv=VVyFvO, **kwargs)
def FF0I5A(  SELF, cmd, **kwargs): SELF.session.open(CCpvy4, VV4Fmi=cmd, VVWUJo=True, VV1ZDq=True, VVMXNv=VVCUL7, **kwargs)
def FF20zH(  SELF, cmd, **kwargs): SELF.session.open(CCpvy4, VV4Fmi=cmd, VVRUv5=True , **kwargs)
def FFk9XI(  session, cmd, **kwargs):      session.open(CCpvy4, VV4Fmi=cmd, VVRUv5=True , **kwargs)
def FFehqS( SELF, cmd, **kwargs): SELF.session.open(CCpvy4, VV4Fmi=cmd, VVoFLA=True   , **kwargs)
def FFyemP( SELF, cmd, **kwargs): SELF.session.open(CCpvy4, VV4Fmi=cmd, VVJ4cj=True  , **kwargs)
def FFGqL5(cmd):
 return FFLgW2("which %s" % cmd)
def FFyncK():
 cmd = "if [ -f /etc/apt/apt.conf ]; then echo dpkg; else if [ -f /etc/opkg/opkg.conf ]; then echo opkg; else if which dpkg; then echo dpkg; else if which opkg; then echo opkg; else if which ipkg; then echo ipkg; else echo ''; fi; fi; fi; fi; fi"
 return FFdHIn(cmd)
def FFZu9n(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
VVdsnf     = 0
VVhuD3      = 1
VVnFKX   = 2
VV9SVb   = 3
VVDKlz      = 4
VVqQqK      = 5
VVV2eV     = 6
VVN09a     = 7
VVEdih     = 8
VVg1cm = 9
VVEgPl = 10
VVz2tU = 11
VVHnoT  = 12
VVvpx9     = 13
VVv695  = 14
VVlF8r  = 15
def FFnyVC(parmNum, grepTxt):
 if   parmNum == VVdsnf  : param = ["update"   , "dpkg update"    ]
 elif parmNum == VVhuD3   : param = ["list"   , "apt list"    ]
 elif parmNum == VVnFKX: param = ["list-installed" , "dpkg -l"     ]
 elif parmNum == VV9SVb: param = ["list-upgradable", "apt list --upgradable"]
 else         : param = []
 if param:
  pkg = FFyncK()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFjDaF(parmNum, package):
 if   parmNum == VVDKlz      : param = ["info"      , "apt show"         ]
 elif parmNum == VVqQqK      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVV2eV     : param = ["search"      , "dpkg -S"          ]
 elif parmNum == VVN09a     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVEdih     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVg1cm : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVEgPl : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VVz2tU : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVHnoT  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVvpx9     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVv695  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVlF8r  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFyncK()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFNkgD():
 result = FFdHIn("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e 'GNU \"ar\" command not found!';"
  installCmd = FFjDaF(VVEdih, "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFhkCt("%s enigma2-plugin-extensions-opkg-tools" % installCmd)
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFhkCt("%s binutils" % installCmd)
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFog5k(failed1, VVChVP))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFog5k(failed2, VVChVP))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFog5k(failed3, VVYZPJ))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FF3zFj(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFjDaF(VVEdih , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFhkCt("%s %s" % (installCmd, toolPkgName))
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFog5k(failed1, VVChVP))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFog5k(failed2, VVYZPJ))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFSIRe(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCmJil.VVyiVj()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FFjqdo(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFSIRe(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFMf21(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FF1fFq(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFSIRe(path, maxSize=maxSize, encLst=encLst)
  if lines: FF8ShK(SELF, lines, title=title, VVMXNv=VVyFvO, width=1600, height=1000, titleFontSize=30)
  else : FFM0Ji(SELF, path, title=title)
 else:
  FFcMQr(SELF, path, title)
def FFxVrN(SELF, fName, title):
 path = VVkwgw + fName
 if fileExists(path):
  txt = FFSIRe(path)
  txt = txt.replace("#W#", VVTKcZ)
  txt = txt.replace("#Y#", VVyz0j)
  txt = txt.replace("#G#", VVdl3O)
  txt = txt.replace("#C#", VV4aa0)
  txt = txt.replace("#P#", VVf8NN)
  FF8ShK(SELF, txt, title=title)
 else:
  FFcMQr(SELF, path, title)
def FF4id7(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFMiJ8(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFGa2t(parent)
 else    : return FFTgmt(parent)
def FFBBEq(path):
 return os.path.basename(os.path.normpath(path))
def FFMvn6(path):
 try:
  os.mkdir(path)
  return "" if pathExists(path) else "Cannot create dir !"
 except Exception as e:
  return str(e)
def FF1fFq(path):
 try:
  if os.path.islink(path)  : return os.lstat(path).st_size
  elif os.path.isfile(path): return os.path.getsize(path)
 except:
  pass
 return -1
def FFiyww(path):
 path = FFTgmt(path)
 if   os.path.islink(path) : return "SymLink"
 elif os.path.ismount(path) : return "Mount"
 elif os.path.isfile(path) : return "File"
 elif os.path.isdir(path) : return "Directory"
 else      : return ""
def FFN3lb(path):
 size = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   try:
    if os.path.islink(fp) : size += os.lstat(fp).st_size
    elif os.path.isfile(fp) : size += os.path.getsize(fp)
   except:
    pass
 return size
def FFaAKb(path):
 totDir = totFile = totLink = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   if os.path.islink(fp) : totLink += 1
   elif os.path.isfile(fp) : totFile += 1
   else     : totDir += 1
 return totDir, totFile, totLink
def FFMc8G(path):
 try: os.remove(path)
 except: pass
def FFVch7(path):
 with open(path, "rb+") as f:
  try:
   f.seek(-1, 2)
   if ord(f.read(1)) not in (10, 13):
    f.write(b"\n")
  except:
   pass
def FFEnJ0(path):
 return FFLgW2("chattr -AacDdijsStu '%s'; rm -fr '%s'" % (path, path))
def FFn35Z(path):
 return FFLgW2("cp -f '%s' '%s.bak'" % (path, path))
def FFGa2t(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFTgmt(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFYFA0():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVuGsg)
 paths.append(VVuGsg.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FF4id7(ba)
 for p in list:
  p = ba + p + VVuGsg
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVmIIf, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVuGsg, VVmIIf , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VV3r3b, VVkwgw = FFYFA0()
def FFkDix():
 def VVbFxb(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VVF0TJ   = VVbFxb(CFG.backupPath, CCmbpf.VV1HMk())
 VV0QbE   = VVbFxb(CFG.downloadedPackagesPath, t)
 VV53sD  = VVbFxb(CFG.exportedTablesPath, t)
 VVvUtx  = VVbFxb(CFG.exportedPIconsPath, t)
 VVktaV   = VVbFxb(CFG.packageOutputPath, t)
 global VVrXLj
 VVrXLj = FFGa2t(CFG.backupPath.getValue())
 if VVF0TJ or VVktaV or VV0QbE or VV53sD or VVvUtx or oldMovieDownloadPath:
  configfile.save()
 return VVF0TJ, VVktaV, VV0QbE, VV53sD, VVvUtx, oldMovieDownloadPath
def FFYfiw(path):
 path = FFTgmt(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFHdLu(SELF, pathList, tarFileName, addTimeStamp=True):
 VV9gTz = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VV9gTz.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VV9gTz.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VV9gTz.append(path)
 if not VV9gTz:
  FFG2mq(SELF, "Files not found!")
 elif not pathExists(VVrXLj):
  FFG2mq(SELF, "Path not found!\n\n%s" % VVrXLj)
 else:
  VVAWjc = FFGa2t(VVrXLj)
  tarFileName = "%s%s" % (VVAWjc, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FF4Fnb())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VV9gTz:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % SEP
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFog5k(tarFileName, VVNQoM))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFog5k(failed, VVNQoM))
  cmd += "fi;"
  cmd +=  sep
  FFfu76(SELF, cmd)
def FFIl1A(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FF90h2(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FF90h2(SELF["keyInfo"], "info")
def FF90h2(barObj, fName):
 path = "%s%s%s" % (VVkwgw, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFthxA(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFAOQQ(satNum)
  return satName
def FFAOQQ(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFCt6D(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFthxA(val)
  else  : sat = FFAOQQ(val)
 return sat
def FFDSYZ(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFthxA(num)
 except:
  pass
 return sat
def FFAVM1(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFkbEk(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFeZyZ(info, iServiceInformation.sServiceref)
   prov = FFeZyZ(info, iServiceInformation.sProvider)
   state = str(FFeZyZ(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFUsGW(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFzXIA(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFeZyZ(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFc5SJ(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFXevL(refCode):
 info = FFZgQf(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFmxJt(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FFWHq3(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFZgQf(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVnXy1 = eServiceCenter.getInstance()
  if VVnXy1:
   info = VVnXy1.info(service)
 return info
def FFWpQx(SELF, refCode, VVxOHd=True, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if "j.php" in refCode and "&end=:" in refCode:
  refCode1, decodedUrl, origUrl, iptvRef = FFzXIA(refCode)
  chName = decodedUrl[decodedUrl.index("&end=:") + 6:]
  pr = CCBhNc()
  if pr.VVMsTt(refCode1, chName, decodedUrl, iptvRef):
   if pr.VVveVR(SELF, isFromSession):
    return
   else:
    fromPortalReplay = True
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFPJLb(SELF, serviceRef, checkParentalControl, isFromSession, fromPortalReplay)
  if VVxOHd:
   FFKNy7(SELF, isFromSession)
 try:
  VVw847 = InfoBar.instance
  if VVw847:
   VVpnhD = VVw847.servicelist
   if VVpnhD:
    servRef = eServiceReference(refCode)
    VVpnhD.saveChannel(servRef)
 except:
  pass
def FFPJLb(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPortalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCBhNc()
    if pr.VVMsTt(refCode, chName, decodedUrl, iptvRef):
     pr.VVveVR(SELF, isFromSession)
def FFUsGW(refCode):
 return True if iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE) else False
def FF5JUW(ref):
 return "FROM BOUQUET " in ref.upper()
def FFtvcx(ref):
 if "chcm=" in ref.lower(): return False
 else      : return True if iSearch(r"https?([:]|%3a)\/\/(127.0.0.\d|0.0.0.0|192.168.\d.\d|localhost).+", ref, IGNORECASE) else False
def FF0hYs(url): return FFeh36(url) or FFW9kO(url)
def FFeh36(url) : return not "mode=itv" in url and any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFW9kO(url): return any(x in url for x in ("/series/", "mode=series"))
def FFzXIA(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFyEM8(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFyEM8(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFP4cn(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFXAmg(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FF3BMa(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFIQ17(txt):
 try:
  return FFXAmg(FF3BMa(txt)) == txt
 except:
  return False
def FFcJlI(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FFGa2t(newPath), patt))
def FFKNy7(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not FF5JUW(servPath):
   isForPlayer = True
 if iptvRef or isForPlayer: CCppT7.VVkxsS(session)
 else      : FFf5BK(session, reopen=True)
def FFf5BK(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FFf5BK, session), CCN4DC)
  except:
   try:
    FF07lH(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFDQBg(refCode):
 tp = CC5l6x()
 if tp.VVSV38(refCode) : return True
 else        : return False
def FFzHg5(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFHpDz(True)
     return True
 return False
def FFHpDz(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FFduqt()
def FFduqt():
 VVw847 = InfoBar.instance
 if VVw847:
  VVpnhD = VVw847.servicelist
  if VVpnhD:
   VVpnhD.setMode()
def FFanBk(root, mode=0):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVnXy1 = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    flags = service.flags
    if mode == 0 and service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    ref, info = service.toString(), VVnXy1.info(service)
    name = info.getName(service)
    if   mode == 0: lst.append((ref, name))
    elif mode == 1: lst.append((ref, name, flags))
 except:
  pass
 return lst
def FFGsAb():
 VVQ0ZT = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVASq4 = list(VVQ0ZT)
 return VVASq4, VVQ0ZT
def FFxmPl():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFv0f4(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FFPuhT(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFzGjj():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FF4Fnb():
 return FFzGjj().replace(" ", "_").replace("-", "").replace(":", "")
def FFGcFN(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFADdS():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFq7bz(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCul6W.VVuv9X(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCul6W.VVY5tM(fName)
     phpFile = tmpDir + fName + ext
     FFLgW2("mv -f '%s' '%s'" % (outFile, phpFile))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FF39jL(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FFLFel(num):
 return "s" if num > 1 else ""
def FF5kC0(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFfvBi(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFfQKQ(a, b):
 return (a > b) - (a < b)
def FFVQmS(a, b):
 def VV0Dse(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VV0Dse(a)
 b = VV0Dse(b)
 return (a > b) - (a < b)
def FFCmv7(mycmp):
 class CCU5G9(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CCU5G9
def FF27fq(SELF, message, title="", VVJ8mq=None):
 SELF.session.openWithCallback(VVJ8mq, CC7Isx, title=title, message=message, VVHrLx=True)
def FF8ShK(SELF, message, title="", VVMXNv=VVyFvO, VVJ8mq=None, **kwargs):
 SELF.session.openWithCallback(VVJ8mq, CC7Isx, title=title, message=message, VVMXNv=VVMXNv, **kwargs)
def FFspfF(SELF, txt):
 SELF.session.open(CCcrgE, txt)
def FFG2mq(SELF, message, title="")  : FF07lH(SELF.session, message, title)
def FFcMQr(SELF, path, title="") : FF07lH(SELF.session, "File not found !\n\n%s" % path, title)
def FFM0Ji(SELF, path, title="") : FF07lH(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFEPUu(SELF, title="")  : FF07lH(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FF07lH(session, message, title="") : session.open(BF(CCTfGo, title=title, message=message))
def FF8ISk(SELF, VVJ8mq, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVJ8mq, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVJ8mq, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFG2mq(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFDiGG(SELF, callBack_Yes, VVDdTB, callBack_No=None, title="", VVm2Fj=False, VV5fzj=True, isFromExternal=False):
 session = SELF if isFromExternal else SELF.session
 return session.openWithCallback(BF(FFZ4DN, callBack_Yes, callBack_No)
         , BF(CCj78i, title=title, VVDdTB=VVDdTB, VV5fzj=VV5fzj, VVm2Fj=VVm2Fj))
def FFZ4DN(callBack_Yes, callBack_No, FFDiGGed):
 if FFDiGGed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFpIgV(SELF, txt="", timeout=0, isGrn=False):
 if len(txt) > 0:
  try:
   if isGrn: FFeNfF(SELF["myInfoBody"], "#00004040")
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   SELF["myInfoBody"].setText(str(txt))
   if timeout > 0: SELF.VVN3o2.start(timeout, True)
  except: pass
 else: FFlYCg(SELF)
def FFrKlA(*kargs, **kwargs):
 FFLYGh(BF(FFpIgV, *kargs, **kwargs))
def FFlYCg(SELF):
 try:
  SELF.VVN3o2.stop()
  SELF["myInfoFrame"].hide()
  SELF["myInfoBody"].hide()
 except:
  pass
def FFcGBG(SELF):
 try: return SELF["myInfoBody"].visible
 except: return False
def FF69ky(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCo9yf, **kwargs))
  else   : win = SELF.session.open(BF(CCo9yf, **kwargs))
  FF8Q9A(win)
  return win
 except:
  return None
def FFBqvZ(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CCfuZE, **kwargs))
 FF8Q9A(win)
 return win
def FFZRMI(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FFVKGp(txt, ref, cond, color=""):
 return (color + txt, ref) if cond else (txt,)
def FFPrkv(SELF, **kwargs):
 SELF.session.open(CCXzVR, **kwargs)
def FF2kyZ(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   FFY2jk(SELF[name], "#000000", 3)
  except:
   pass
def FFY2jk(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FFHLyO(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVwRnH, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FF08xD(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFHLyO(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize = winInst.size()
 FFLVLw(SELF, winSize.width(), winSize.height())
def FFLVLw(SELF, w, h):
 fSize = SELF["myInfoFrame"].instance.size()
 bSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((w - fSize.width()) // 2, (h - fSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((w - bSize.width()) // 2, (h - bSize.height()) // 2))
def FFfQyb():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFPiPj(VVvi36):
 screenSize  = FFfQyb()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVvi36)
 return bodyFontSize
def FF0NHz(VVvi36, extraSpace):
 font = gFont(VVwRnH, VVvi36)
 VVaKvA = fontRenderClass.getInstance().getLineHeight(font) or (VVvi36 * 1.25)
 return int(VVaKvA + VVaKvA * extraSpace)
def FFdP4M(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, vSliderW=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True, menuLabel=0, morePar={}):
 screenSize = FFfQyb()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 extraPar  = None
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 vSliderW  = int(ratioW  * vSliderW)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVwRnH, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FF0NHz(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0" size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb"  %s />' % (width, titleH, titleColor, VVwRnH, titleFontSize, alignLeftCenter)
 if winType == VVZhbx:
  pass
 elif winType in (VVuQx7, VV59l2):
  if winType == VV59l2 : menuName = "config"
  else      : menuName = "myMenu"
  menuW = bodyW - int(bodyW * menuLabel / 100.0) - marginLeft if menuLabel else bodyW
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, menuW, bodyH, bodyColor, bodyLineH)
  if menuLabel:
   param = 'backgroundColor="%s" foregroundColor="#ffffff" %s' % (bodyColor, bodyFontStr)
   x, w, gap = menuW + marginLeft * 2, bodyW - menuW - marginLeft, int(marginLeft / 2.0)
   tmp += '<widget name="myLabelFrm" position="%d,%d" size="%d,%d" zPosition="3" %s />' % (x - gap, bodyTop, w + gap * 2, bodyH, param)
   tmp += '<widget name="myLabelTit" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + 10, w, titleH, alignCenter, param)
   tmp += '<widget name="myLabelTxt" position="%d,%d" size="%d,%d" zPosition="4" noWrap="1" %s %s />' % (x, bodyTop + titleH + gap , w, bodyH - titleH - gap * 2, alignLeftCenter, param)
 elif winType == VVkgN4:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignCenter)
 elif winType == VVHjhJ:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VVwRnH, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="6" noWrap="1" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VVOalx:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FF27fqL = b2Left2 + timeW + marginLeft
  FF27fqW = b2Left3 - marginLeft - FF27fqL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FF27fqL , b2Top, FF27fqW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVMqMG:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VV8WPg:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVWkz0:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VV4ArL:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVwRnH, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVwRnH, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVgvGh:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVwRnH, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VV8KOT:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVwRnH, fontH, alignCenter)
 elif winType in (VVg2zc, VVMhmD, VVgc94, VVDylj, VV3N9u):
  if   winType == VVg2zc  : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  elif winType == VVMhmD : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  elif winType == VVgc94 : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorMovies.getValue()
  elif winType == VVDylj : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.80, 0.20, int(width * 0.80), int(width * 0.20), CFG.transpColorChannels.getValue()
  else          : totRows, totCols, picR, lblR, w1, w2, transpBG = 4, 5, 0.65, 0.35, int(width * 0.85), int(width * 0.15), ""
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + marginTop + 2
  boxW = int((width - vSliderW - marginLeft * 2)  / totCols)
  boxH = int((height - barHeight - boxT - marginTop * 2) / totRows)
  extraPar = marginLeft, boxT, boxW, boxH
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" noWrap="1" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVg2zc:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h, fg, bg[i]  , VVwRnH, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h, fg, bg[i+3], VVwRnH, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VVwRnH, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VVwRnH, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h, fg, bg, VVwRnH, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h, fg, bg, VVwRnH, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  if morePar.get("grid", 0):
   y = boxT + boxH
   for i in range(totRows - 1):
    tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
    y += boxH
   x = boxW
   h = height - barHeight - boxT
   for i in range(totCols - 1):
    tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
    x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s"/>' % (marginLeft, boxT + marginTop, boxW, boxH, morePar.get("cursC", "#00ffff00"))
  picBgTr = 'transparent="1"' if morePar.get("picBgTr", 0) else ""
  lblTr = 'transparent="1"' if morePar.get("lblTr", 0) else ""
  lblC = morePar.get("lblC", "#00003333")
  gapX = morePar.get("gapX", 3)
  gapY = morePar.get("gapY", 3)
  midGap = morePar.get("mGap", 0)
  areaW = boxW - gapX * 2
  areaH = boxH - gapY * 2 - midGap
  picT = boxT + gapY
  picH = int(areaH * picR)
  lblH = int(areaH * lblR)
  lblT = boxT + gapY + picH + midGap
  lblFont = int(lblH * 0.65)
  transpBG = 'backgroundColor="%s"'% transpBG if transpBG else ""
  for row in range(totRows):
   left = marginLeft + gapX
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (row, col, left, picT, areaW, picH, transpBG, picBgTr)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, left, picT, areaW, picH)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="%s" noWrap="1" %s font="%s;%d" %s />' % (row, col, left, lblT, areaW, lblH, lblC, lblTr, VVwRnH, lblFont, alignCenter)
    left += boxW
   picT += boxH
   lblT += boxH
 elif winType == VVYTfH:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVn9ax:
  tmp += '<widget name="myPic" position="0,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (bodyTop, bodyW+3, bodyH+3)
 else:
  if   winType == VVWUpg : align = alignLeftCenter
  elif winType == VViAAJ : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVJOa0:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVwRnH
  if usefixedFont and winType == VViAAJ:
   fLst = FF1tiC()
   if   VV6Bd8 in fLst and CFG.fontPathTerm.getValue(): fontName = VV6Bd8
   elif VVPR2M in fLst         : fontName = VVPR2M
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVvi36 = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVwRnH, VVvi36, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVwRnH, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" noWrap="1" %s />' % (name[i], left, btnTop, btnW, btnH, VVX0Ji[i], VVwRnH, barFont, alignCenter)
   left += btnW + gap
 if vSliderW:
  par = 'position="0,0" size="20,20"'
  tmp += '<widget name="mySbFrm" zPosition="13" %s />' % par
  tmp += '<widget name="mySbBak" zPosition="14" %s />' % par
  tmp += '<widget name="mySbSld" zPosition="15" %s />' % par
 if winType == VViAAJ:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVX0Ji[i], VVwRnH, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap, "extraPar":extraPar}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFdP4M(VVuQx7, 800, 1000, 40, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VVFznL = ""
  self.themsList  = []
  self.Title   = "%s - %s" % (PLUGIN_NAME, VV9AsZ)
  VVgktg = []
  if VVjQ9n:
   VVgktg.append(("-- MY TEST --", "myTest" ))
  VVgktg.append(("File Manager"  , "fMan" ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("IPTV"    , "iptv" ))
  VVgktg.append(("Movies Browser" , "movie" ))
  VVgktg.append(("Services/Channels", "chan" ))
  VVgktg.append(("Bouquet Editor" , "bouq" ))
  VVgktg.append(("PIcons"   , "picon" ))
  VVgktg.append(("EPG"    , "epg"  ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Terminal"   , "term" ))
  VVgktg.append(("SoftCam"   , "soft" ))
  VVgktg.append(("Plugins"   , "plug" ))
  VVgktg.append(("Backup & Restore" , "bakup" ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Date/Time"  , "date" ))
  VVgktg.append(("Network"   , "net"  ))
  for ndx, item in enumerate(VVgktg):
   item = list(item)
   item[0] = "  %s" % item[0]
   VVgktg[ndx] = tuple(item)
  FFj3mb(self, title=self.Title, VVgktg=VVgktg)
  FFuetT(self["keyRed"] , "Exit")
  FFuetT(self["keyGreen"] , "Settings")
  FFuetT(self["keyYellow"], "Dev. Info.")
  FFuetT(self["keyBlue"] , "Color/Font")
  self["myActionMap"].actions.update({
   "red" : self.close       ,
   "green" : self.VVUK8j      ,
   "yellow": self.VVMogo      ,
   "blue" : self.VVNMO9     ,
   "info" : BF(FFkWFV, self, self.VVHitG) ,
   "text" : self.VVp6gQ      ,
   "menu" : self.VVozv0    ,
   "0"  : BF(self.VVBEK9, 0)   ,
   "1"  : BF(self.VVBssi, "fMan")   ,
   "2"  : BF(self.VVBssi, "iptv")   ,
   "3"  : BF(self.VVBssi, "movie")   ,
   "4"  : BF(self.VVBssi, "chan")   ,
   "5"  : BF(self.VVBssi, "bouq")   ,
   "6"  : BF(self.VVBssi, "picon")   ,
   "7"  : BF(self.VVBssi, "epg")   ,
   "8"  : BF(self.VVBssi, "term")   ,
   "9"  : BF(self.VVBssi, "soft")   ,
   "last" : BF(self.VVBssi, "plug")   ,
   "next" : BF(self.VVBssi, "bakup")
  })
  self.onShown.append(self.VVgr8g)
  self.onClose.append(self.onExit)
  global VVbMcv, VVxrH7, VVI342
  VVbMcv = VVxrH7 = False
  VVI342 = True
 def VV96hS(self):
  self.VVBssi(self["myMenu"].l.getCurrentSelection()[1])
 def VVBssi(self, item):
  if item is not None:
   for ndx, param in enumerate(self["myMenu"].list):
    if len(param) > 1 and param[1] == item:
     self["myMenu"].moveToIndex(ndx)
     break
   global VVEyaB
   VVEyaB = self["myMenu"].l.getCurrentSelection()[0].strip()
   if   item == "myTest" : self.VVFYzg()
   elif item == "fMan"  : self.session.open(CCyssW)
   elif item == "iptv"  : self.session.open(CCul6W)
   elif item == "movie" : FFkWFV(self, BF(CCCsLn.VVayku, self))
   elif item == "chan"  : self.session.open(CCmfL4)
   elif item == "bouq"  : self.session.open(CC01PH)
   elif item == "picon" : self.VVMEQi()
   elif item == "epg"  : self.session.open(CCjxcj)
   elif item == "term"  : self.session.open(CCrdgM)
   elif item == "soft"  : self.session.open(CCMhuj)
   elif item == "plug"  : self.session.open(CChEm5)
   elif item == "bakup" : self.session.open(CCrB7W)
   elif item == "date"  : self.session.open(CCMnH7)
   elif item == "net"  : self.session.open(CCkO1u)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFayJd(self["myMenu"])
  FF08xD(self)
  FF2kyZ(self)
  FFIl1A(self)
  VVF0TJ, VVktaV, VV0QbE, VV53sD, VVvUtx, oldMovieDownloadPath = FFkDix()
  if VVF0TJ or VVktaV or VV0QbE or VV53sD or VVvUtx or oldMovieDownloadPath:
   VVy4Ld = lambda path, subj: "%s:\n%s\n\n" % (subj, FF1YQ7(path, VVWgbP)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVy4Ld(VVF0TJ   , "Backup/Restore Path"    )
   txt += VVy4Ld(VVktaV  , "Created Package Files (IPK/DEB)" )
   txt += VVy4Ld(VV0QbE  , "Download Packages (from feeds)" )
   txt += VVy4Ld(VV53sD , "Exported Tables"     )
   txt += VVy4Ld(VVvUtx , "Exported PIcons"     )
   txt += VVy4Ld(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FF8ShK(self, txt, title="Settings Paths")
  self.VVenkv()
  if (EASY_MODE or VVsxLO or VVjQ9n):
   FFeNfF(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFpIgV(self, "Welcome", 300)
  FFLYGh(self.VVMFXV)
 def VVMFXV(self):
  if CFG.checkForUpdateAtStartup.getValue():
   curVer, webVer, url, isHigher, err = CCmbpf.VV7p9u()
   if webVer and isHigher:
    self["myTitle"].setText("  %s (v%s available)" % (self.Title, webVer))
 def onExit(self):
  FFLgW2("rm -f /tmp/ajp_*")
  global VVbMcv, VVxrH7
  VVbMcv = VVxrH7 = False
  FFTeQk("VVI342")
 def VVBEK9(self, digit):
  self.VVFznL += str(digit)
  ln = len(self.VVFznL)
  global VVbMcv
  if ln == 4:
   if self.VVFznL == "0" * ln:
    VVbMcv = True
    FFeNfF(self["myTitle"], "#11805040")
   else:
    self.VVFznL = "x"
 def VVp6gQ(self):
  self.VVFznL += "t"
  if self.VVFznL == "0" * 4 + "t" * 2:
   global VVxrH7
   VVxrH7 = True
   FFeNfF(self["myTitle"], "#dd5588")
 def VVMEQi(self):
  found = False
  pPath = CCQVwA.VVzkHI()
  if pathExists(pPath):
   for fName, fType in CCQVwA.VVbOxR(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCQVwA)
  else:
   VVgktg = []
   VVgktg.append(("PIcons Tools" , "CCQVwA" ))
   VVgktg.append(VVm7kE)
   VVgktg.append(CCQVwA.VVQ96v())
   VVgktg.append(VVm7kE)
   VVgktg += CCQVwA.VVixei()
   FFBqvZ(self, self.VVoRAF, VVgktg=VVgktg)
 def VVoRAF(self, item=None):
  if item:
   if   item == "CCQVwA"   : self.session.open(CCQVwA)
   elif item == "VVmdY1"  : CCQVwA.VVmdY1(self)
   elif item == "VVjypC"  : CCQVwA.VVjypC(self)
   elif item == "findPiconBrokenSymLinks" : CCQVwA.VV6Oh0(self, True)
   elif item == "FindAllBrokenSymLinks" : CCQVwA.VV6Oh0(self, False)
 def VVHitG(self):
  changeLogFile = VVkwgw + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FFjqdo(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FF1YQ7("\n%s\n%s\n%s" % (SEP, line, SEP), VVChVP, VVTKcZ)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FF1YQ7(line, VVdl3O, VVTKcZ)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FF8ShK(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VV9AsZ, PLUGIN_DESCRIPTION), VVvi36=28, width=1600, height=1000, VVRr4z="#11000011")
 def VVozv0(self):
  VVgktg = []
  VVgktg.append(("%s Requirements" % PLUGIN_NAME, "libr"))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Keys Help"     , "hlp" ))
  FFBqvZ(self, self.VV0YtO, VVgktg=VVgktg, width=650, title="Options")
 def VV0YtO(self, item=None):
  if item:
   if   item == "libr" : FFkWFV(self, BF(self.VVYJIM))
   elif item == "hlp" : FFxVrN(self, "_help_main", "Main Page (Keys Help)")
 def VVUK8j(self) : self.session.open(CCmbpf)
 def VVMogo(self) : self.session.open(CCpL5C)
 def VVNMO9(self):
  title = "Colors and Fonts"
  c1, c2, c3, c4 = VVo8aK, VVWgbP, VVyz0j, VVeksK
  VVgktg = []
  VVgktg.append((c1 + "Change Title Colors"   , "title"  ))
  VVgktg.append((c1 + "Change Menu Area Colors"  , "body"  ))
  VVgktg.append((c1 + "Change Menu Pointer Colors" , "cursor"  ))
  VVgktg.append((c1 + "Change Bottom Bar Colors" , "bar"   ))
  VVgktg.append((c2 + "Reset Colors"    , "resetColor" ))
  VVgktg.append(VVm7kE)
  VVgktg.append((c3 + "Change %s Font" % PLUGIN_NAME, "mainFont" ))
  VVgktg.append((c3 + "Change Termianl Font"   , "termFont" ))
  VVgktg.append(VVm7kE)
  VVgktg.append((c4 + "Change System Font"    , "sysFont"  ))
  FFBqvZ(self, BF(self.VVghzQ, title), VVgktg=VVgktg, width=600, title=title)
 def VVghzQ(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VVVwfL()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVybY2, tDict, item), CCXTPW, defFG=fg, defBG=bg)
   elif item == "resetColor" : FFDiGG(self, self.VVoB0w, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVZpLE(VVPRk7  )
   elif item == "termFont"  : self.VVZpLE(VV6Bd8)
   elif item == "sysFont"  : self.VVZpLE(VVjcx1  )
 def VVYJIM(self):
  title = "%s requirements (for some features)" % PLUGIN_NAME
  VVUl7I = self.VVPoE1()
  VVkY0R = ("Install", BF(self.VVhMEm, title)    , [])
  VVM4el  = ("Update Sys. Packages", self.VV2pUu , [])
  header  = ("Library", "State", "Usage" )
  widths  = (20   , 25  , 55  )
  VVwZxf = (LEFT  , CENTER , LEFT  )
  VVkINB = FF69ky(self, None, title=title, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=28, width=1350, VVkY0R=VVkY0R, VVM4el=VVM4el, VVsykS="#00ffffaa", VVDWdv=1)
 def VVhMEm(self, Title, VVkINB, title, txt, colList):
  if "Not" in colList[1]:
   cbFnc = BF(self.VVbnWM, VVkINB)
   pkgDict = self.VV55y1()
   pkg = colList[0]
   if   pkg == "requests" : CCbAHw.VVGJKq(self, cbFnc=cbFnc)
   elif pkg == "Imaging" : CCqxHs.VVCz7t(self, Title, False, cbFnc=cbFnc)
   elif pkg == "ar"  : FF20zH(self, FFNkgD(), VVAJlf=cbFnc, title=Title)
   elif pkg in pkgDict  : FF20zH(self, FF3zFj(pkgDict[pkg], pkg, pkg.capitalize()), VVAJlf=cbFnc, title=Title)
  else:
   FFpIgV(VVkINB, "Already installed.", 700, isGrn=True)
 def VV2pUu(self, VVkINB, title, txt, colList):
  CChEm5.VVZh28(self)
 def VVbnWM(self, VVkINB):
  VVUl7I = self.VVPoE1()
  VVkINB.VVrgU7(VVUl7I[VVkINB.VVnbBC()])
 def VVPoE1(self):
  tDict = {}
  path = VVkwgw + "_sup_lib"
  if fileExists(path):
   for line in FFjqdo(path):
    lib, eq, txt = line.partition("=")
    tDict[lib] = txt
  def VVy4Ld(lib, ok):
   txt = tDict.get(lib, "")
   if ok: return (lib, FF1YQ7("Installed", VVNQoM), txt)
   else : return (lib, FF1YQ7("Not installed", VVYZPJ), txt)
  VVUl7I = []
  VVUl7I.append(VVy4Ld("requests", CCbAHw.VVGJKq(self, install=False)))
  VVUl7I.append(VVy4Ld("Imaging" , CCqxHs.VVCz7t(self, "", False, install=False)))
  VVUl7I.append(VVy4Ld("ar"   , FFLgW2("if [[ \"$(ar -V 2> /dev/null | grep 'GNU ar')\" ]]; then exit 0; else exit 1; fi")))
  for pkg, cmd in self.VV55y1().items(): VVUl7I.append(VVy4Ld(pkg, FFGqL5(cmd)))
  VVUl7I.sort(key=lambda x: x[0].lower())
  return VVUl7I
 def VV55y1(self):
  d = {}
  for pkg in ("xz", "zip", "p7zip", "unrar", "bzip2", "ffmpeg"):
   d[pkg] = pkg
  d["p7zip"] = "7za"
  return d
 def VVjuyL(self):
  return VVrXLj + "ajpanel_colors"
 def VVVwfL(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVjuyL()
  if fileExists(p):
   txt = FFSIRe(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVybY2(self, tDict, item, fg, bg):
  if fg:
   self.VVMWzj(item, fg)
   self.VVHaL0(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VV2WbE(tDict)
 def VV2WbE(self, tDict):
   p = self.VVjuyL()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVMWzj(self, item, fg):
  if   item == "title" : FFfLQO(self["myTitle"], fg)
  elif item == "body"  :
   FFfLQO(self["myMenu"], fg)
   FFfLQO(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   for item in ("myBar", "keyRed", "keyGreen", "keyYellow", "keyBlue"): FFfLQO(self[item], fg)
 def VVHaL0(self, item, bg):
  if   item == "title" : FFeNfF(self["myTitle"], bg)
  elif item == "body"  :
   FFeNfF(self["myMenu"], bg)
   FFeNfF(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFeNfF(self["myBar"], bg)
 def VVoB0w(self):
  FFLgW2("rm '%s'" % self.VVjuyL())
  self.close()
 def VVenkv(self):
  tDict = self.VVVwfL()
  for item in ("title", "body", "cursor", "bar"):
   self.VVuAPl(tDict, item)
 def VVuAPl(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVMWzj(name, fg)
  if bg: self.VVHaL0(name, bg)
 def VVZpLE(self, which):
  if   which == VVPRk7  : rest, defFnt, title = False, CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif which == VV6Bd8 : rest, defFnt, title = False, CFG.fontPathTerm.getValue(), "Terminal "
  elif which == VVjcx1  : rest, defFnt, title = True , CFG.fontPathSys.getValue() , "System"
  CCmerT.VVC1RB(self, "Change %s Font" % title, defFnt, rest, BF(self.VVSJBq, which))
 def VVSJBq(self, which, path=None):
  if path:
   path = "" if path == "DEFAULT" else path
   if   which == VVPRk7  : FFeLB8(CFG.fontPathMain, path)
   elif which == VV6Bd8: FFeLB8(CFG.fontPathTerm, path)
   elif which == VVjcx1  : FFeLB8(CFG.fontPathSys , path)
   err = Main_Menu.VVjf34(which)
   if err          : FFG2mq(self, err, title=title)
   elif which == VVPRk7   : self.close()
   elif which == VV6Bd8  : FFpIgV(self, "Terminal font applied", 1500, isGrn=True)
   elif which == VVjcx1 and path: FFpIgV(self, "System font applied", 1500, isGrn=True)
   elif which == VVjcx1   : FFDiGG(self, BF(Main_Menu.VVoFLA, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VVoFLA(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVjf34(name):
  if   name == VVPRk7 : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VV6Bd8: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VVjcx1 : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FF1tiC()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VVjcx1:
   nameLst = []
   for nm in FF1tiC():
    if not nm in (VVPRk7, VV6Bd8):
     nameLst.append(nm)
  else:
   nameLst = [name]
  totDone = 0
  for fntName in nameLst:
   if FFA3nY(path, fntName, isRepl=repl):
    totDone += 1
  if totDone > 0: FF1tiC()
  else    : return "Could not add font"
 def VVFYzg(self):
  self.session.open(CC01PH)
class CCkO1u(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFdP4M(VVuQx7, 800, 950, 40, 50, 30, "#22300030", "#0a202020", 33)
  self.session  = session
  self.netEntryFile = "%s%s" % (VVrXLj, "ajpanel_network")
  c1, c2 = VVyz0j, VVo8aK
  VVgktg = []
  VVgktg.append((c1 + "Network Devices"     , "dev" ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Network Scanner (ping)"    , "ping"))
  VVgktg.append(("Port Scanner (scan for famous ports)" , "port"))
  VVgktg.append(VVm7kE)
  VVgktg.append((c2 + "Check Internet Connection"  , "intr"))
  FFj3mb(self, title="Network Tools", VVgktg=VVgktg)
  FFj3mb(self, VVgktg=VVgktg)
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFayJd(self["myMenu"])
  FF08xD(self)
 def VV96hS(self):
  global VVEyaB
  VVEyaB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if   item == "dev" : FFkWFV(self, self.VVF5S3, title="Reading Devices ...")
  elif item == "ping" : FFkWFV(self, self.VVgMom, title="Scanning ...")
  elif item == "port" : CCUSzd.VVQITq(self, self.VV34Uy, title="Select host to scan")
  elif item == "intr" : self.session.open(CCXhCY)
 def VVF5S3(self, canCencel=False):
  title = "Network Devices"
  VVUl7I = self.VVIzwi()
  if VVUl7I:
   bg = "#0a223333"
   VVUl7I.sort(key=lambda x: x[0].lower())
   VVIcAB = BF(self.VVmdJ0, canCencel)
   VVp0o5  = ("Start FTP"   , self.VVwBIk    , [])
   VVW1zM = ("Entry Options"  , self.VVfdGp  , [])
   VVM4el = ("Scan for Devices" , self.VVFmkM , [])
   header  = ("Num" , "IP-Address", "Username", "Password", "Default Path", "Remarks" )
   widths  = (7  , 25   , 19  , 19  , 0.01   , 30  )
   VVwZxf = (CENTER , LEFT   , LEFT  , LEFT  , LEFT   , LEFT  )
   VVkINB = FF69ky(self, None, title=title, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, width=1500, height=900, VVYiuZ=widths, VVvi36=28, VVp0o5=VVp0o5, VVIcAB=VVIcAB, VVW1zM=VVW1zM, VVM4el=VVM4el
       , VVrcFy=bg, VVZZ3c=bg, VVRr4z=bg, VVsykS="#11ffff00", VVLwCQ="#11220000", VVhvzQ="#00333333", VVEjwd="#11400040")
   ndx = CFG.lastNetworkDevice.getValue()
   if isinstance(ndx, int):
    VVkINB.VV2NBO(ndx)
  else:
   FFDiGG(self, BF(FFkWFV, self, BF(self.VVfQNV, canCencel=canCencel), title="Scanning ..."), "No devices found !\n\nScan network ?", callBack_No=BF(self.VVmdJ0, canCencel), title=title)
 def VVfdGp(self, VVkINB, title, txt, colList):
  VVgktg = []
  VVgktg.append(("Change Username"   , "user"))
  VVgktg.append(("Change Password"   , "pass"))
  VVgktg.append(("Change Remarks"   , "rem"))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Remove Selected Server" , "del"))
  FFBqvZ(self, BF(self.VVV7lt, VVkINB), VVgktg=VVgktg, title="Entry Options")
 def VVV7lt(self, VVkINB, item=None):
  if item:
   if   item == "user" : self.VVtEet("u", VVkINB)
   elif item == "pass" : self.VVtEet("p", VVkINB)
   elif item == "rem" : self.VVtEet("r", VVkINB)
   elif item == "del" : FFDiGG(self, BF(FFkWFV, self, BF(self.VVstcA, VVkINB), title="Deleting ..."), "Continue ?", title="Delete Entry")
 def VVmdJ0(self, canCencel, VVkINB=None):
  if VVkINB: VVkINB.cancel()
  if canCencel : self.close()
 def VVwBIk(self, VVkINB, title, txt, colList):
  num, ip, u, p, path, rem = colList
  entry = (ip, u, p, path, rem)
  FFeLB8(CFG.lastNetworkDevice, VVkINB.VVnbBC())
  self.session.openWithCallback(BF(self.VVKJjP, entry, VVkINB), CCmkME, entry)
 def VVKJjP(self, entry, VVkINB, newPath=None):
  if newPath:
   ip, u, p, path, rem = entry
   if path != newPath:
    self.VVWoxJ("d", newPath, ip, u, p, path, rem)
    self.VVfijG(VVkINB)
 def VVFmkM(self, VVkINB, title, txt, colList):
  FFkWFV(VVkINB, BF(self.VVfQNV, mainTableInst=VVkINB), title="Scanning Network ...")
 def VVfQNV(self, canCencel=False, mainTableInst=None):
  title = "Network Devices"
  ftpLst, err = CCUSzd.VVNuEM(CCUSzd.VVAFO1)
  if err:
   FFG2mq(self, err, title=title)
   return
  telLst, err = CCUSzd.VVNuEM(CCUSzd.VVAmu0)
  if err:
   FFG2mq(self, err, title=title)
   return
  tLst = list(set(ftpLst + telLst))
  lst = []
  for item in tLst:
   typ = []
   if item in ftpLst: typ.append("FTP")
   if item in telLst: typ.append("Telnet")
   lst.append((item[0], item[1], " / ".join(typ)))
  ftpLst = telLst = tLst = None
  if lst:
   def VVjnbW(p1, p2): return FFVQmS(p1[0], p2[0])
   lst.sort(key=FFCmv7(VVjnbW))
   bg = "#0a202020"
   VVIcAB = BF(self.VVmdJ0, canCencel)
   VVp0o5  = ("Add to Devices" , BF(self.VV54xK, mainTableInst, canCencel), [])
   header  = ("IP-Address" , "MAC-Address" , "Open Ports" )
   widths  = (40   , 34   , 26   )
   VVwZxf = (LEFT   , CENTER  , CENTER  )
   FF69ky(self, None, title=title, header=header, VV9gTz=lst, VVwZxf=VVwZxf, VVYiuZ=widths, width=1200, VVvi36=30, VVp0o5=VVp0o5, VVIcAB=VVIcAB, VVDWdv=2
     , VVrcFy=bg, VVZZ3c=bg, VVRr4z=bg, VVLwCQ="#0a225555", VVEjwd="#11403040")
  else:
   FFG2mq(self, "No devices found !", title=title)
 def VVgMom(self):
  title = 'Hosts that responded to "ping"'
  lst, err = CCUSzd.VVNuEM(-1)
  if err:
   FFG2mq(self, err, title=title)
  elif lst:
   def VVjnbW(p1, p2): return FFVQmS(p1[0], p2[0])
   lst.sort(key=FFCmv7(VVjnbW))
   bg = "#0a202020"
   header  = ("IP-Address" , "MAC-Address" )
   widths  = (50   , 50   )
   VVwZxf = (LEFT   , LEFT   )
   FF69ky(self, None, title=title, header=header, VV9gTz=lst, VVwZxf=VVwZxf, VVYiuZ=widths, width=1000, height=700, VVvi36=30
     , VVrcFy=bg, VVZZ3c=bg, VVRr4z=bg, VVLwCQ="#0a225555", VVEjwd="#11403040")
  else:
   FFG2mq(self, "Network scanning failed !", title=title)
 def VV34Uy(self, ip=None):
  if ip:
   FFkWFV(self, BF(self.VVd2tz, ip), title="Scanning %s" % ip)
 def VVd2tz(self, ip):
  dct = {20: "FTP Data Transfer", 21: "FTP Control", 22: "SSH", 23: "Telnet", 25: "SMTP (eMail)", 80: "HTTP", 443: "HTTPS"}
  txt  = "IP:\n   %s\n\n" % ip
  txt += "Ping Result:\n   %s\n\n" % ("OK" if CCUSzd.VV2S7e(ip) else "Failed")
  txt += "Available Ports:\n"
  ports = ""
  for port, subj in dct.items():
   ok = CCUSzd.VVk1tY(ip, port, timeout=0.5)
   if ok:
    ports += "   %d : %s\n" % (port, subj)
  FF8ShK(self, txt + (ports or "   None"), title="Scanned ports : %s" % str(list(dct)).strip("[]"))
 def VVIzwi(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFSIRe(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVjnbW(p1, p2): return FFVQmS(p1[0], p2[0])
  tLst.sort(key=FFCmv7(VVjnbW))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VV54xK(self, mainTableInst, canCencel, VVkINB, title, txt, colList):
  ip, mac, typ = VVkINB.VV68fw(VVkINB.VVnbBC())
  if "Own" in ip:
   FFpIgV(VVkINB, "Cannot add your device", 1500)
  else:
   gw = "Gateway"
   if gw in ip : ip, u, p, path, rem = ip.split()[0].strip(), "admin", "123456", "/", gw
   else  : ip, u, p, path, rem = ip, "root", "dreambox", "/", "No-name"
   for entry in self.VVIzwi():
    num1, ip1, u1, p1, path1, rem1 = entry
    if (ip, u, p, path, rem) == (ip1, u1, p1, path1, rem1):
     break
   else:
    if fileExists(self.netEntryFile):
     FFVch7(self.netEntryFile)
    with open(self.netEntryFile, "a") as f:
     f.write(self.VVUlC3(ip, u, p, path, rem))
   if mainTableInst: self.VVfijG(mainTableInst, [ip, u, p, path, rem])
   else   : self.VVF5S3(canCencel)
   VVkINB.cancel()
 def VVUlC3(self, ip, u, p, path, rem):
  return "host=%s,user=%s,pass=%s,path=%s,rem=%s\n" % (ip, u, p, path, rem)
 def VVstcA(self, VVkINB):
  num, ip, u, p, path, rem = VVkINB.VV68fw(VVkINB.VVnbBC())
  lst = self.VVIzwi()
  tot = 0
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if not (ip1, u1, p1, path1, rem1) == (ip, u, p, path, rem):
     f.write(self.VVUlC3(ip1, u1, p1, path1, rem1))
     tot += 1
  if tot:
   self.VVfijG(VVkINB)
  else:
   VVkINB.cancel()
 def VVtEet(self, col, VVkINB):
  num, ip, u, p, path, rem = VVkINB.VV68fw(VVkINB.VVnbBC())
  if   col == "u": orig, subj = u  , "User"
  elif col == "p": orig, subj = p  , "Password"
  elif col == "r": orig, subj = rem, "Remarks"
  FF8ISk(self, BF(self.VVe4Za, col, orig, VVkINB, num, ip, u, p, path, rem), defaultText=orig, title="Change %s" % subj, message="Enter %s:" % subj)
 def VVe4Za(self, col, orig, VVkINB, num, ip, u, p, path, rem, newTxt):
  if not newTxt == None:
   newTxt = newTxt.strip()
   if orig == newTxt:
    FFpIgV(VVkINB, "No change", 1500)
   elif not newTxt and col == "u":
    FFpIgV(VVkINB, "No user !", 2000)
   else:
    self.VVWoxJ(col, newTxt, ip, u, p, path, rem)
    self.VVfijG(VVkINB)
 def VVWoxJ(self, col, newTxt, ip, u, p, path, rem):
  lst = self.VVIzwi()
  oldItem = (ip, u, p, path, rem)
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if (ip1, u1, p1, path1, rem1) == oldItem:
     if   col == "u": u1  = newTxt
     elif col == "p": p1  = newTxt
     elif col == "d": path1 = newTxt
     elif col == "r": rem1 = newTxt
    f.write(self.VVUlC3(ip1, u1, p1, path1, rem1))
 def VVfijG(self, VVkINB, newEntry=None):
  VVUl7I = self.VVIzwi()
  if VVUl7I : VVkINB.VVDqeT(VVUl7I, tableRefreshCB=BF(self.VVXK4S, newEntry))
  else  : VVkINB.cancel()
 def VVXK4S(self, newEntry, VVkINB, title, txt, colList):
  if newEntry:
   for ndx, row in enumerate(VVkINB.VV3rlI()):
    if row[1:] == newEntry:
     VVkINB.VV2NBO(ndx)
 def VVmdJ0(self, canCencel, VVkINB=None):
  if VVkINB: VVkINB.cancel()
  if canCencel : self.close()
class CCUSzd():
 VVAFO1 = 21
 VVAmu0 = 23
 def __init__(self):
  self.VVpS2l()
 def VVpS2l(self):
  self.ftp  = None
  self.ftpIp  = ""
  self.ftpUser = ""
  self.ftpPass = ""
  self.ftpSys  = ""
 def VVFzIW(self, ip, User, Pass, timeout=5):
  myIp = CCUSzd.VVQJdK()
  if ip != myIp:
   if CCUSzd.VVk1tY(ip, CCUSzd.VVAFO1):
    self.VVpS2l()
    err = ""
    try:
     from ftplib import FTP
     self.ftp  = FTP(ip, user=User, passwd=Pass, timeout=timeout)
     self.ftp.set_pasv(False)
     self.ftpIp  = ip
     self.ftpUser = User
     self.ftpPass = Pass
    except Exception as e:
     err = str(e)
   else:
    err = "Connection timed out !\n\n%s" % ip
  else:
   err = "Cannot FTP to your Device-IP:\n\n%s" % ip
  return err
 def VVAexA(self):
  try: return self.ftp.sendcmd("SYST")
  except: return ""
 def VVSycB(self):
  try: return self.ftp.sendcmd("NOOP")
  except: return ""
 def VVLO03(self, timeout=3):
  t1 = iTime()
  while True:
   state = self.VVSycB()
   if not state or state == "200 OK" or iTime() - t1 >= timeout:
    break
 def VV3dQQ(self):
  try: return self.ftp.sendcmd("STAT")
  except: return ""
 def VV0Qlz(self, Dir, isLong=False):
  files, err = [], ""
  if self.ftp and self.VVrZJ8(Dir):
   try:
    if isLong: self.ftp.dir(files.append)
    else  : self.ftp.nlst()
   except Exception as e:
    err = str(e)
  else:
   err = "No FTP Connection !"
  return files, err
 def VV05kx(self):
  try: return self.ftp.pwd()
  except: return ""
 def VVSaFp(self, path):
  try:
   size = self.ftp.sendcmd("SIZE %s" % path)
   return "f"
  except:
   curDir = self.VV05kx()
   if self.VVrZJ8(path) : typ = "d"
   else      : typ = "b"
   self.VVrZJ8(curDir)
   return typ
 def VVnlqh(self, path):
  try: return self.ftp.size(path)
  except: return -1
 def VVrZJ8(self, path):
  try:
   self.ftp.cwd(path)
   return True
  except:
   return False
 def VVjZAj(self, path):
  try:
   self.ftp.mkd(path)
   return True
  except:
   return False
 def VVoGXD(self, path, flag):
  try:
   if flag == "d" : self.ftp.rmd(path)
   else   : self.ftp.delete(path)
   return True
  except:
   return False
 def VV2gdE(self, fromN, toN):
  try:
   self.ftp.rename(fromN, toN)
   return True
  except:
   return False
 def VV4k2q(self, remFile, locFile="", maxSz=10000000):
  sz = self.VVnlqh(remFile)
  if   sz == -1 : return "", sz, "Cannot read file size."
  elif sz > maxSz : return "", sz, "File too big."
  else   : err= ""
  locFile = locFile or "/tmp/%s" % os.path.basename(remFile)
  try:
   self.ftp.retrbinary("RETR %s" % remFile, open(locFile, "wb").write)
   if fileExists(locFile) : return locFile, sz, ""
   else     : return "", sz, "Download Failed."
  except Exception as e:
   FFMc8G(locFile)
   return "", sz, str(e)
 def VVnwSj(self):
  if self.ftp:
   try: self.ftp.quit()
   except: pass
  self.VVpS2l()
 @staticmethod
 def VVTCY2():
  from uuid import getnode
  return ':'.join(iFindall('..', '%012x' % getnode())).upper()
 @staticmethod
 def VVQJdK():
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_DGRAM
  try:
   setdefaulttimeout(1)
   s = socket(AF_INET, SOCK_DGRAM)
   s.connect(("1.1.1.1", 80))
   ip = s.getsockname()[0]
   s.close()
   return ip
  except:
   return ""
 @staticmethod
 def VVbRO4():
  myIp = CCUSzd.VVQJdK()
  if myIp.count(".") == 3:
   parts = myIp.split('.')
   return ".".join(parts[:3]) + "."
  return ""
 @staticmethod
 def VV3RY2():
  span = iSearch(r"((?:\d+.){3}\.\d+)", FFdHIn("ip route | grep default"), IGNORECASE)
  return span.group(1) if span else ""
 @staticmethod
 def VVRWrk(port=-1):
  lst = []
  def VVGlot(ip):
   if port > -1: ok = CCUSzd.VVk1tY(ip, port)
   else  : ok = CCUSzd.VV2S7e(ip)
   if ok:
    lst.append(ip)
  try:
   baseIp = CCUSzd.VVbRO4()
   thLst  = []
   for num in range(1, 255):
    ip = "%s%d" % (baseIp, num)
    th = iThread(name="ajp_scanIp%d" % num, target=BF(VVGlot, ip))
    th.start()
    thLst.append(th)
   for th in thLst: th.join()
   return lst, ""
  except Exception as e:
   err = str(e)
   return [], err + '\n\nMax Threads = %d\nCheck your system "Max User Processes" with "ulimit -u"' % len(thLst) if "can't start new thread" in err else ""
 @staticmethod
 def VVNuEM(port):
  myIp = CCUSzd.VVQJdK()
  myGw = CCUSzd.VV3RY2()
  tDict = { myIp: CCUSzd.VVTCY2() }
  devLst, err = CCUSzd.VVRWrk(port)
  if err:
   return [], err
  else:
   for ip in devLst:
    span = iSearch(r"((?:\d+.){3}\.\d+).+\s+((?:[a-f\d]{2}:){5}[a-f\d]{2})", FFnpLo("arp -n %s" % ip), IGNORECASE)
    if span    : tDict[ip] = span.group(2).upper()
    elif not ip == myIp : tDict[ip] = ""
   lst = []
   for key, val in tDict.items():
    if   key == myIp: txt = " %s Own" % VVyz0j
    elif key == myGw: txt = " %s Gateway" % VVyz0j
    else   : txt = ""
    lst.append((key + txt, val))
   return lst, ""
 @staticmethod
 def VV2S7e(ip):
  return FFLgW2("ping -W1 -q -c1 %s" % ip)
 @staticmethod
 def VVk1tY(host, port, timeout=1.0):
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
  setdefaulttimeout(timeout)
  try:
   socket(AF_INET, SOCK_STREAM).connect((host, port))
   return True
  except:
   return False
 @staticmethod
 def VVd24U(ip="1.1.1.1", timeout=1):
  if CCUSzd.VVk1tY(ip, 53, timeout):
   return True
  if CCUSzd.VV2S7e(ip):
   return True
  return FFLgW2("wget -q -T %d -t 1 --spider %s" % (timeout, ip))
 @staticmethod
 def VVQITq(SELF, okFnc, title):
  baseIp = CCUSzd.VVbRO4()
  lst = []
  for num in range(1, 255):
   item = "%s%d" % (baseIp, num)
   lst.append((item, item))
  FFBqvZ(SELF, okFnc, VVgktg=lst, width=600, title=title, VVrcFy="#222222", VVZZ3c="#222222")
class CCmkME(Screen, CCUSzd):
 def __init__(self, session, entry):
  self.skin, self.skinParam = FFdP4M(VVuQx7, 1400, 920, 40, 50, 30, "#11333344", "#08303030", 30, barHeight=40, topRightBtns=2)
  self.session  = session
  self.ftpEntry  = entry
  self.VVvi36  = self.skinParam["bodyFontSize"]
  self.VVaKvA  = self.skinParam["bodyLineH"]
  self.VVo2w3  = self.skinParam["width"]
  self.curDir   = "/"
  self.list   = []
  self.png_fil  = CC7kl8.VV4ail("fil")
  self.png_dir  = CC7kl8.VV4ail("dir")
  self.png_dirup  = CC7kl8.VV4ail("dirup")
  self.png_slwfil  = CC7kl8.VV4ail("slwfil")
  self.png_slbfil  = CC7kl8.VV4ail("slbfil")
  self.png_slwdir  = CC7kl8.VV4ail("slwdir")
  self.serverOrigData = None
  self.Title   = "FTP (%s)" % entry[0]
  CCUSzd.__init__(self)
  VVgktg = [("Item-%d" % x,) for x in range(50)]
  FFj3mb(self, title=self.Title, VVgktg=VVgktg)
  FFuetT(self["keyRed"] , "Exit")
  self["myMenu"] = MenuList(VVgktg, True, eListboxPythonMultiContent)
  self["myMenu"].l.setFont(0, gFont(VVwRnH, self.VVvi36))
  self["myMenu"].l.setItemHeight(self.VVaKvA)
  self["myActionMap"] = ActionMap(VVKDoB,
  {
   "red" : BF(self.VVs00w, True) ,
   "ok" : self.VV96hS    ,
   "cancel": self.VVs00w    ,
   "menu" : self.VVdNlS   ,
   "info" : self.VVIri6  ,
   "pageUp": self.VV9Bxo    ,
   "chanUp": self.VV9Bxo
  })
  self.onShown.append(self.VVgr8g)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVNpxz)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFayJd(self["myMenu"])
  FF08xD(self)
  FF2kyZ(self)
  FFIl1A(self)
  FFeNfF(self["keyBlue"], "#11333333")
  FFkWFV(self, self.VV31Dx, title="Connecting ...")
 def VV31Dx(self):
  ip, u, p, path, rem = self.ftpEntry
  err = self.VVFzIW(ip, u, p)
  if err:
   FFG2mq(self, err, title=self.Title)
   FFuetT(self["keyBlue"] , "")
   self.close()
  elif self.ftp:
   FFuetT(self["keyBlue"], self.ftpIp)
   if not self.VVrZJ8(path):
    path = "/"
   self.VVwd2e(path)
   self.serverOrigData = (ip, u, p, path, rem)
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.VVSycB():
   self.VVnwSj()
 def VV96hS(self):
  if self.VVLYWS():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    if   flag == "d" or targetState == "d" : self.VVwd2e(os.path.join(self.curDir, name))
    elif flag == "x"      : self.VV9Bxo()
    else         : self.VVAES8(os.path.join(self.curDir, name))
 def VVs00w(self, force=False):
  if force or CFG.FileManagerExit.getValue() == "e": self.close(self.curDir)
  else            : self.VV9Bxo()
 def VVLYWS(self):
  if self.VVSycB():
   return True
  else:
   FFG2mq(self, "FTP Server is now diconnected !", title=self.Title)
   return False
 def VVAES8(self, path):
  cat = self.VVpieo(path)
  if cat in ("pic"):
   FFkWFV(self, BF(self.VVzEuF, path))
  elif cat in ("mov", "mus"):
   if CCul6W.VVdh3m("5002"):
    url = "ftp%%3a//%s%%3a%s@%s%s" % (self.ftpUser, self.ftpPass, self.ftpIp, path)
    rType = "5002"
   else:
    rType = CFG.iptvAddToBouquetRefType.getValue()
    url = "http%%3a//%s/file?file=%s" % (self.ftpIp, path)
   FFkWFV(self, BF(CCyssW.VVkN1L, self, url, rType=rType), title="Playing Media ...")
 def VVzEuF(self, path):
  locFile, size, err = self.VV4k2q(path)
  if err: FFG2mq(self, err, title="View Picture File")
  else  : CCLIUZ.VV94CH(self, locFile, fakePath="ftp:/%s" % path, cbFnc=BF(FFMc8G))
 def VVNpxz(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel: title = "  %s  " % os.path.join(self.curDir, "" if sel[0][0] == CC7kl8.VV4vML else sel[0][0])
  else  : title=  VVYZPJ + "  No Files Found !"
  self["myTitle"].setText(title)
 def VV9Bxo(self):
  if self.VVLYWS():
   lastPart = FFBBEq(self.curDir)
   parentDir = os.path.abspath(os.path.join(self.curDir, os.pardir))
   self.VVwd2e(parentDir, lastPart, "d")
 def VVwd2e(self, Dir, moveTo="", moveToType=""):
  FFkWFV(self, BF(self.VVv7rT, Dir, moveTo, moveToType))
 def VVv7rT(self, Dir, moveTo, moveToType):
  files, err = self.VV0Qlz(Dir, isLong=True)
  self.curDir = self.VV05kx() or "/"
  self.VV97Yo(files)
  if moveTo:
   for ndx, item in enumerate(self.list):
    name, target, targetState, flag, sortSeq = item[0]
    if moveTo == name:
     if not moveToType or moveToType == flag:
      self["myMenu"].moveToIndex(ndx)
      break
  else:
   self["myMenu"].moveToIndex(0)
 def VV97Yo(self, files):
  self.list = []
  if self.curDir != "/":
   self.list.append(self.VVqZKT(CC7kl8.VV4vML, CC7kl8.VV4vML, "", "", "x"))
  for item in files:
   linkTo = ""
   isDir = isFile = isLink = False
   item = item.strip()
   if   item.startswith("l")     : flag = "l"
   elif item.startswith("d") or "<DIR>" in item: flag = "d"
   else          : flag = "f"
   gaps = 3 if item[:1].isdigit() else 8
   name = item.split(None, gaps)[gaps]
   linkSep = " -> "
   origName = name
   target = targetState = ""
   if linkSep in name:
    flag = "l"
    name, _, target = name.partition(linkSep)
    if not target.startswith("/"):
     target = "/" + target
    targetState = self.VVSaFp(target)
    color = VVYZPJ if targetState == "b" else VVNQoM
    origName = name + VVChVP + linkSep + color + " "+ target
   self.list.append(self.VVqZKT(origName, name, target, targetState, flag))
  self.list.sort(key=lambda x: (x[0][4], x[0][0]))
  self["myMenu"].l.setList(self.list)
 def VVqZKT(self, origName, name, target, targetState, flag):
  if flag == "f":
   png = self.png_fil
   ext = os.path.splitext(name)[1]
   if ext:
    cat = self.VVpieo(name)
    if cat: png = LoadPixmap("%s%s.png" % (VVkwgw, cat))
  elif flag == "d": png = self.png_dir
  elif flag == "l":
   if   targetState == "f" : png = self.png_slwfil
   elif targetState == "d" : png = self.png_slwdir
   elif targetState == "b" : png = self.png_slbfil
   else      : png = self.png_slwfil
  elif flag == "x": png = self.png_dirup
  else   : png = self.png_fil
  if   origName == CC7kl8.VV4vML: sortSeq = 0
  elif flag == "d" or targetState == "d"  : sortSeq = 1
  else          : sortSeq = 2
  tableRow = [ (name, target, targetState, flag, sortSeq) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVaKvA + 10, 0, self.VVo2w3, self.VVaKvA, 0, LEFT | RT_VALIGN_CENTER, origName))
  tableRow.append(CCo9yf.VVa1FY(0, 2, self.VVaKvA-4, self.VVaKvA-4, png))
  return tableRow
 def VVpieo(self, path):
  ext = os.path.splitext(path)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in CC7kl8.VVBUKY().items():
    if ext in lst:
     return cat
  return ""
 def VVdNlS(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel : name, target, targetState, flag, sortSeq = sel[0]
  else : name = target = targetState = flag = ""
  isTop  = name == CC7kl8.VV4vML
  isDir  = flag == "d" or targetState == "d"
  isFile = flag == "f" or targetState == "f"
  def VVma9K(titl, ref, chk, color=""):
   if chk: return VVgktg.append((color + titl, ref))
   else  : return VVgktg.append((titl, ))
  VVgktg = []
  VVma9K("Properties", "VVIri6", not isTop)
  c = VVyz0j
  VVgktg.append(VVm7kE)
  VVma9K("Download Selected File ..."    , "FFq7bzFromServer", isFile, c)
  VVma9K("Upload a Local File to Remote Server ...", "VVvfdP" , True  , c)
  VVgktg.append(VVm7kE)
  VVma9K("Create new directory", "VVRaL9", True)
  VVma9K("Rename", "VV5Gvh", not isTop)
  VVma9K("DELETE", "VVOffr", not isTop, VVf8NN)
  VVgktg.append(VVm7kE)
  VVma9K("FTP Server Information", "VVcd8Q", True)
  VVgktg.append(VVm7kE)
  VVma9K("Refresh File List", "refresh", True)
  FFBqvZ(self, self.VV9kGM, VVgktg=VVgktg, title="Options")
 def VV9kGM(self, item=None):
  if item:
   if   item == "VVIri6"     : self.VVIri6()
   elif item == "FFq7bzFromServer"   : self.FFq7bzFromServer()
   elif item == "VVvfdP"   : self.VVvfdP()
   elif item == "VVRaL9"   : self.VVRaL9()
   elif item == "VV5Gvh"   : self.VV5Gvh()
   elif item == "VVOffr"   : self.VVOffr()
   elif item == "VVcd8Q"    : self.VVcd8Q()
   elif item == "refresh"and self.VVLYWS() : self.VVwd2e(self.curDir)
 def VVIri6(self):
  if self.VVLYWS():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    path = os.path.join(self.curDir, name)
    txt = "%s:\n%s\n\n" % (FF1YQ7("Path", VVyz0j), path)
    typ = {"d": "Directory", "f": "File", "l": "SymLink", "x": ""}.get(flag, "")
    if typ: txt += "Type\t: %s%s\n" % (typ, " (Broken)" if targetState == "b" else "")
    if target: txt += "Target\t: %s\n" % target
    sz = self.VVnlqh(path)
    if sz > -1: txt += "Size\t: %s" % CCyssW.VV1ctA(sz)
   else:
    txt = "Nothing selected"
   FF8ShK(self, txt, title="Properties")
 def VVcd8Q(self):
  if self.VVLYWS():
   Sys  = self.VVAexA() or " -"
   txt = "%s\n  %s\n\n" % (FF1YQ7("System:", VVyz0j), Sys[4:] if Sys.startswith("215 ") else Sys)
   Stat = self.VV3dQQ() or " -"
   txt += "%s\n" % (FF1YQ7("Status:", VVyz0j))
   for line in Stat.splitlines():
    txt += "  %s\n" % (line[4:] if line.startswith("211-") or line.startswith("211 ") else line)
   FF8ShK(self, txt, title="FTP Server Information")
 def VVRaL9(self, name=""):
  if self.VVLYWS():
   title = "Add New Directory"
   FF8ISk(self, BF(self.VVAORx, title), defaultText=name, title=title, message="Enter Directory name")
 def VVAORx(self, title, name):
  if name and name.strip():
   if self.VVjZAj(name) : self.VVwd2e(self.curDir, name, "d")
   else     : FFG2mq(self, "Failed to create : %s" % name, title)
 def VV5Gvh(self):
  if self.VVLYWS():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Rename"
    name, target, targetState, flag, sortSeq = sel[0]
    FF8ISk(self, BF(self.VV28sh, title, name, flag), defaultText=name, title=title, message="Enter new name")
 def VV28sh(self, title, name, flag, newName):
  if newName and newName.strip():
   if self.VV2gdE(name, newName.strip()) : self.VVwd2e(self.curDir, newName, flag)
   else          : FFG2mq(self, "Failed to rename to : %s" % newName, title)
 def VVOffr(self):
  if self.VVLYWS():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    FFDiGG(self, BF(FFkWFV, self, BF(self.VViVKw, name, flag), title="Deleting ..."), "Delete ?\n\n%s" % name, title="Delete")
 def VViVKw(self, name, flag):
  if self.VVoGXD(name, flag) : self.VVwd2e(self.curDir)
  else         : FFG2mq(self, "Failed to delete:\n\n%s" % name, "Delete")
 def FFq7bzFromServer(self):
  if self.VVLYWS():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Download File"
    name, target, targetState, flag, sortSeq = sel[0]
    remFile = os.path.join(self.curDir, name)
    size = self.VVnlqh(remFile)
    if size == -1:
     FFG2mq(self, "Cannot get file size for:\n\n%s" % remFile, title=title)
    else:
     Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVrXLj
     self.session.openWithCallback(BF(self.VVvBA0, title, remFile, name, size), BF(CCyssW, mode=CCyssW.VVaEvY, VVxuyD="Download here", VV9Esa=Dir, width=1200, height=840, pickTitleBG="#11002222", pickBodyBG="#11003333", cursorBG="#11005566"))
 def VVvBA0(self, title, remFile, name, size, locPath):
  if locPath:
   FFeLB8(CFG.lastFtpLocalPath, locPath)
   locFile = os.path.join(locPath, name)
   self.session.open(CCKX0k, barTheme=CCKX0k.VVzy8h, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Downloading ..."
       , fncToRun  = BF(self.VVlAPp, remFile, size, locFile)
       , VVJ8mq = BF(self.VVYAcv, remFile, size, locFile))
 def VVlAPp(self, remFile, size, locFile, VVzRAM):
  VVzRAM.VVGeXq(size)
  VVzRAM.VVgo83 = ""
  with open(locFile, "wb") as locFileObj:
   try:
    def VVMdmD(data):
     if not VVzRAM or VVzRAM.isCancelled:
      return
     locFileObj.write(data)
     VVzRAM.VVu4eE(len(data))
    self.ftp.retrbinary("RETR %s" % remFile, VVMdmD)
   except Exception as e:
    VVzRAM.VVgo83 = str(e)
 def VVYAcv(self, remFile, size, locFile, VV4mF1, VVgo83, threadCounter, threadTotal, threadErr):
  title = "File Download"
  delF = False
  if VVgo83:
   FFG2mq(self, "%s\n\nftp:/%s" % (VVgo83, remFile), title="Download Error")
   delF = True
  elif not VV4mF1:
   FFG2mq(self, "Download cancelled for:\n\nftp:/%s" % remFile, title=title)
   delF = True
  else:
   if size == FF1fFq(locFile):
    txt = "Successfully downloaded to:\n\n%s" % locFile
    FF27fq(self, txt, title=title)
   else:
    FFG2mq(self, "Incorrect downloaded file size for:\n\nftp:/%s" % remFile, title=title)
    delF = True
  if delF:
   FFMc8G(locFile)
 def VVvfdP(self):
  if self.VVLYWS():
   Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVrXLj
   self.session.openWithCallback(self.VVPzO5, BF(CCyssW, VVxuyD="Upload selected file", VV9Esa=Dir, patternMode="all", width=1200, height=850, pickTitleBG="#11001122", pickBodyBG="#11330033", cursorBG="#11662200"))
 def VVPzO5(self, locFile):
  if locFile:
   title = "Upload File to Remote Server"
   FFeLB8(CFG.lastFtpLocalPath, os.path.dirname(locFile))
   size = FF1fFq(locFile)
   if size == -1:
    FFG2mq(self, "Cannot get file size for:\n\n%s" % locFile, title=title)
   else:
    remFile = os.path.join(self.curDir, os.path.basename(locFile))
    self.session.open(CCKX0k, barTheme=CCKX0k.VVzy8h, titleBg="#22220022", bodyBg="#22220022"
        , titlePrefix = "Uploading ..."
        , fncToRun  = BF(self.VVi5gC, locFile, size, remFile)
        , VVJ8mq = BF(self.VVqCNv, locFile, size, remFile))
 def VVi5gC(self, locFile, size, remFile, VVzRAM):
  VVzRAM.VVGeXq(size)
  VVzRAM.VVgo83 = ""
  with open(locFile, "rb") as locFileObj:
   try:
    def VVuQm1(data):
     if not VVzRAM or VVzRAM.isCancelled:
      VVzRAM.VVgo83 = "Upload cancelled"
      locFileObj.close()
      return
     VVzRAM.VVu4eE(len(data))
    self.ftp.storbinary("STOR %s" % remFile, locFileObj, callback=VVuQm1)
   except Exception as e:
    VVzRAM.VVgo83 = VVzRAM.VVgo83 or str(e)
 def VVqCNv(self, locFile, size, remFile, VV4mF1, VVgo83, threadCounter, threadTotal, threadErr):
  title = "File Upload"
  err = ""
  if VV4mF1:
   if size == FF1fFq(locFile) : FF27fq(self, "Successfully uploaded to:\n\n%s" % remFile, title=title)
   else       : err = "Incorrect uploaded file size for:\n\nftp:/%s" % remFile
  elif VVgo83 : err = "%s\n\n%s" % (VVgo83, locFile)
  else    : err = "Incomplete file transfer:\n\n%s" % locFile
  if err:
   FFG2mq(self, err, title=title)
   self.VVLO03()
   self.VVoGXD(remFile, "")
  self.VVwd2e(self.curDir)
class CCqxHs():
 VVr25E  = "all"
 VVIZWA = "vid"
 VVRchV  = "osd"
 @staticmethod
 def VVwhb8(session, k):
  if not CFG.screenshotFType.getValue() == "off":
   title = "%s Screenshot" % PLUGIN_NAME
   if FFGqL5("grab"):
    winShown = session.current_dialog.shown
    if k == CCqxHs.VVIZWA and winShown: session.current_dialog.hide()
    FFLYGh(BF(CCqxHs.VVXUfS, title, session, k, winShown))
   else:
    FF07lH(session, "No Grab command !", title=title)
 @staticmethod
 def VVXUfS(title, session, k, winShown):
  fTitle = skinName = ""
  x = y = w = h = 0
  if k == CCqxHs.VVRchV:
   if not winShown:
    FF07lH(session, "No Window to capture !", title=title)
    return
   if not CCqxHs.VVCz7t(session, title, True):
    return
   valid, origTitle, clnTitle, skinName, x, y, w, h = CCqxHs.VVFYxC(session)
   fTitle = "%s_(%s)" % (clnTitle, skinName)
   if not valid:
    FF07lH(session, "Cannot get Window Dimensions !", title=title)
    return
  if not fTitle:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(session, isFromSession=True)
   chName = iSub(r"[^A-Za-z0-9]" ,"-" , chName.strip())
   fTitle = chName or refCode.replace(":", "_")
  ext = CFG.screenshotFType.getValue()
  if   ext == "jpg": typ = "-j 100"
  elif ext == "png": typ = "-p"
  else    : typ = ""
  path = "%sscreenshot_%s_%s.%s" % (FFGa2t(CFG.exportedPIconsPath.getValue()), fTitle, FF4Fnb(), ext)
  ok = FFJ2Ng("grab -q -s %s > '%s'" % (typ, path))
  if k == CCqxHs.VVIZWA and winShown:
   session.current_dialog.show()
  elif k == CCqxHs.VVRchV:
   ok = CCqxHs.VVVtkG(path, x, y, w, h)
   if not ok:
    FFMc8G(path)
    FF07lH(session, "Error while cropping image file !", title=title)
    return
  if ok and fileExists(path) : session.open(BF(CCLIUZ, title=path, VVMYFn=path))
  else      : FF07lH(session, "Error while capturing screen !", title=title)
 @staticmethod
 def VVCz7t(SELF, title, isFromExternal, install=True, cbFnc=None):
  try:
   from PIL import Image
   return True
  except:
   if install:
    FFDiGG(SELF, BF(CCqxHs.VVzgjz, SELF, isFromExternal, cbFnc=cbFnc), "Imaging Library is required.\n\nInstall ?", title=title, isFromExternal=isFromExternal)
   return False
 @staticmethod
 def VVzgjz(SELF, isFromExternal, cbFnc=None):
  if pyVersion[0] >= 3: name = "python3-pillow"
  else    : name = "python-imaging"
  if isFromExternal: fnc = BF(FFk9XI, VVAJlf=cbFnc)
  else    : fnc = BF(FF20zH , VVAJlf=cbFnc)
  fnc(SELF, FFjDaF(VVEdih, name), checkNetAccess=True, title="Installing Imaging Library")
 @staticmethod
 def VVFYxC(session, repl="-"):
  valid = False
  origTitle = clnTitle = skinName = ""
  x = y = w = h = 0
  obj = session.current_dialog
  if obj:
   inst = obj.instance
   skinName = obj.skinName
   if inst:
    origTitle = inst.getTitle()
    pos, size = inst.position(), inst.size()
    x, y, w, h = pos.x(), pos.y(), size.width(), size.height()
    valid = w != 0 and h !=0
    clnTitle = iSub(r"[^A-Za-z0-9]", repl , origTitle.strip())
  return valid, origTitle, clnTitle, skinName, x, y, w, h
 @staticmethod
 def VVVtkG(path, x, y, w, h, scaleToScreen=True):
  try:
   from PIL import Image
   im = Image.open(path)
   x1 = w + x
   y1 = h + y
   if scaleToScreen:
    scrW, scrH = FFfQyb()
    w, h = im.size
    if w != scrW or h != scrH:
     x  = FFfvBi(x , 0, scrW, 0, w)
     y  = FFfvBi(y , 0, scrH, 0, h)
     x1 = FFfvBi(x1, 0, scrW, 0, w)
     y1 = FFfvBi(y1, 0, scrH, 0, h)
   im = im.crop((x, y, x1, y1))
   im.save(path)
   return True
  except:
   return False
 @staticmethod
 def VVjoVP(path):
  size = FF1fFq(path)
  sizeTxt = CCyssW.VV1ctA(size) if size > -1 else ""
  try:
   from PIL import Image
   im = Image.open(path)
   form = im.format
   mode = im.mode
   resTxt = "%d x %d" % im.size
  except:
   resTxt = form = mode = ""
  return size, sizeTxt, resTxt, form, mode
class CCmerT(Screen):
 def __init__(self, session, title, fontsList, defFnt, withRestart):
  self.skin, self.skinParam = FFdP4M(VVuQx7, 1400, 1000, 40, 40, 30, "#0a001100", "#10110000", 30, barHeight=220)
  self.session  = session
  self.fontsList  = fontsList
  self.defFnt   = defFnt
  txt = FF1YQ7(" (Requires GUI Restart)", VVeksK) if withRestart else ""
  VVgktg = []
  for path in self.fontsList:
   VVgktg.append((os.path.splitext(os.path.basename(path))[0], path))
  VVgktg.sort(key=lambda x: x[0].lower())
  VVgktg.insert(0, VVm7kE)
  VVgktg.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if self.defFnt:
   for ndx, item in enumerate(VVgktg):
    if len(item) == 2 and item[1] == self.defFnt:
     VVgktg[ndx] = (VVNQoM + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVgktg[curIndex] = (VVNQoM + VVgktg[curIndex][0], VVgktg[curIndex][1])
  FFj3mb(self, VVgktg=VVgktg, title=title)
  self["myActionMap"].actions.update({"cancel": self.cancel})
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFayJd(self["myMenu"])
  FF08xD(self)
  self["myBar"].setText(self.VV8xOg())
  self["myBar"].instance.setHAlign(1)
  self["myMenu"].onSelectionChanged.append(self.VVkSro)
  self.VVkSro()
 def VV96hS(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVkSro(self):
  path = self["myMenu"].l.getCurrentSelection()[1]
  if fileExists(path):
   fnt = "AJP_Sample"
   FFA3nY(path, fnt, isRepl=1)
  else:
   fnt = VVUTqI
  self["myMenu"].instance.setFont(gFont(fnt, self.skinParam["bodyFontSize"]))
  self["myMenu"].instance.invalidate()
  self["myBar"].instance.setFont(gFont(fnt, int(self.skinParam["bodyFontSize"] * 1.3)))
  self["myBar"].instance.invalidate()
 def VV8xOg(self):
  txt = ""
  for i in range(65, 91): txt += chr(i)
  txt += "\n"
  for i in range(97, 123): txt += chr(i)
  txt += "  "
  for i in range(48, 58): txt += chr(i)
  txt += "\n"
  txt += u"\u0623\u0628\u062c\u062f \u0647\u0648\u0632 \u062d\u0637\u064a \u0643\u0644\u0645\u0646 \u0633\u0639\u0641\u0635 \u0642\u0631\u0634\u062a \u062b\u062e\u0630 \u0636\u0638\u063a  \u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
  return str(txt)
 @staticmethod
 def VVC1RB(SELF, title, defFnt, rest, VVJ8mq):
  fntPath = resolveFilename(SCOPE_FONTS)
  fontsList = FFcJlI(fntPath, "*.[tToO][tT][fF]")
  if fontsList: SELF.session.openWithCallback(VVJ8mq, CCmerT, title, fontsList, defFnt, rest)
  else  : FFG2mq(self, "No fonts found in:\n\n%s" % fntPath, title=title)
class CCINsx(Screen):
 def __init__(self, session, path, VVgktg, title):
  self.skin, self.skinParam = FFdP4M(VVuQx7, 1700, 1000, 40, 40, 30, "#11001122", "#11002233", 30, menuLabel=50)
  self.session = session
  self.path  = path
  FFj3mb(self, VVgktg=VVgktg, title=title)
  self["myLabelFrm"] = Label()
  self["myLabelTit"] = Label("Result Sample")
  self["myLabelTxt"] = Label()
  self["myActionMap"] = ActionMap(VVKDoB,
  {
   "ok"  : self.VV96hS   ,
   "cancel" : self.cancel   ,
   "pageUp" : self.VVFeal,
   "chanUp" : self.VVFeal,
   "pageDown" : self.VVR0lp ,
   "chanDown" : self.VVR0lp ,
  }, -1)
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFayJd(self["myMenu"])
  FF08xD(self)
  FFeNfF(self["myLabelFrm"], "#11110000")
  FFeNfF(self["myLabelTit"], "#11663322")
  FFeNfF(self["myLabelTxt"], "#11110000")
  self["myMenu"].onSelectionChanged.append(self.VVcqyg)
  self.VVcqyg()
 def VVcqyg(self):
  if fileExists(self.path): txt = FFSIRe(self.path, maxSize=1000, encLst=[self["myMenu"].l.getCurrentSelection()[1]])
  else     : txt = "Review error !"
  self["myLabelTxt"].setText(txt.strip())
 def VV96hS(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVFeal(self) : self["myMenu"].moveToIndex(0)
 def VVR0lp(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCmJil():
 @staticmethod
 def VVyiVj():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVj83G(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FF69ky(SELF, None, VV9gTz=lst, VVvi36=30, VVDWdv=1)
 @staticmethod
 def VVm967(path, SELF=None):
  for enc in CCmJil.VVyiVj():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFG2mq(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVhium(path, enc):
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     pass
   return True
  except:
   return False
 @staticmethod
 def VVnQil(SELF, path, cbFnc, curEnc=VVRaeq, title="Select Encoding"):
  lst = CCmJil.VVZwPs(SELF, path, "")
  if lst:
   SELF.session.openWithCallback(cbFnc, CCINsx, path, lst, title)
 @staticmethod
 def VVgJeJ(SELF, cbFnc, curEnc=VVRaeq, title="Select Encoding"):
  lst = CCmJil.VVZwPs(SELF, "", "")
  if lst:
   FFBqvZ(SELF, cbFnc, title=title, VVgktg=lst, width=1000, height=1000, VVrcFy="#22220000", VVZZ3c="#22220000", VVomDt=True)
 @staticmethod
 def VVZwPs(SELF, path, curEnc):
  lst = CCmJil.VVe90B(path)
  if lst:
   VVgktg = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if   enc == curEnc   : c = VVNQoM
    elif enc == VVRaeq: c = VVChVP
    else      : c = ""
    VVgktg.append((c + txt, enc))
   return VVgktg
  else:
   FFrKlA(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVe90B(path=""):
  encLst = []
  cPath = VVkwgw + "_sup_codecs"
  if fileExists(cPath):
   lines = FFjqdo(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCmJil.VVyiVj())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if path:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CCpL5C(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFdP4M(VVuQx7, 900, 950, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVgktg = []
  VVgktg.append(("Settings File"   , "SettingsFile"  ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Box Info"     , "VVVzCf"   ))
  VVgktg.append(("Tuners Info"    , "VVWJjd"  ))
  VVgktg.append(("Python Version"   , "VVydzn"  ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Screen Size"    , "ScreenSize"   ))
  VVgktg.append(("Language/Locale"   , "Locale"    ))
  VVgktg.append(("Processor"    , "Processor"   ))
  VVgktg.append(("Operating System"   , "OperatingSystem"  ))
  VVgktg.append(("Drivers"     , "drivers"    ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("System Users"    , "SystemUsers"   ))
  VVgktg.append(("Logged-in Users"   , "LoggedInUsers"  ))
  VVgktg.append(("Uptime"     , "Uptime"    ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Host Name"    , "HostName"   ))
  VVgktg.append(("MAC Address"    , "MACAddress"   ))
  VVgktg.append(("Network Configuration" , "NetworkConfiguration"))
  VVgktg.append(("Network Status"   , "NetworkStatus"  ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Disk Usage"    , "VVAMfX"   ))
  VVgktg.append(("Mount Points"    , "MountPoints"   ))
  VVgktg.append(("File System Table (FSTAB)", "FileSystemTable"  ))
  VVgktg.append(("USB Devices"    , "USB_Devices"   ))
  VVgktg.append(("List Block-Devices"  , "listBlockDevices" ))
  VVgktg.append(("Directory Size"   , "DirectorySize"  ))
  VVgktg.append(("Memory"     , "Memory"    ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Loaded Kernel Modules" , "LoadedKernelModules" ))
  VVgktg.append(("Running Processes"  , "RunningProcesses" ))
  VVgktg.append(("Processes with open files", "ProcessesOpenFiles" ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"))
  FFj3mb(self, VVgktg=VVgktg, title="Device Information")
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFayJd(self["myMenu"])
  FF08xD(self)
 def VV96hS(self):
  global VVEyaB
  VVEyaB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"   : self.session.open(CC9a0J)
   elif item == "VVVzCf"   : self.VVVzCf()
   elif item == "VVWJjd"  : self.VVWJjd()
   elif item == "VVydzn"  : self.VVydzn()
   elif item == "ScreenSize"   : FF8ShK(self, "Width\t: %s\nHeight\t: %s" % (FFfQyb()[0], FFfQyb()[1]))
   elif item == "Locale"    : CCmJil.VVj83G(self)
   elif item == "Processor"   : self.VVrWwd()
   elif item == "OperatingSystem"  : FFL00E(self, "uname -a")
   elif item == "drivers"    : self.VVudxt()
   elif item == "SystemUsers"   : FFL00E(self, "id")
   elif item == "LoggedInUsers"  : FFL00E(self, "who -a", consFont=True)
   elif item == "Uptime"    : FFL00E(self, "uptime")
   elif item == "HostName"    : FFL00E(self, "hostname")
   elif item == "MACAddress"   : self.VVGc4J()
   elif item == "NetworkConfiguration" : FFL00E(self, "ifconfig %s %s" % (FFog5k("HWaddr", VVJU8R), FFog5k("addr:", VVChVP)))
   elif item == "NetworkStatus"  : FFL00E(self, "netstat -tulpn", VVvi36=24, consFont=True)
   elif item == "VVAMfX"   : self.VVAMfX()
   elif item == "MountPoints"   : FFL00E(self, "mount %s" % (FFog5k(" on ", VVChVP)))
   elif item == "FileSystemTable"  : FFL00E(self, "cat /etc/fstab", VVvi36=24, consFont=True)
   elif item == "USB_Devices"   : FFL00E(self, "lsusb")
   elif item == "listBlockDevices"  : FFL00E(self, "blkid")
   elif item == "DirectorySize"  : FFL00E(self, "du -shc /* 2>/dev/null | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVklND="Reading size ...")
   elif item == "Memory"    : FFL00E(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules" : self.VVKNOb()
   elif item == "RunningProcesses"  : FFL00E(self, "ps", consFont=True)
   elif item == "ProcessesOpenFiles" : FFL00E(self, "lsof", consFont=True)
   elif item == "DreamBoxBootloader"  : self.VVQopQ()
   else        : self.close()
 def VVGc4J(self):
  res = FFnpLo("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FF8ShK(self, txt)
  else:
   FFL00E(self, "ip link")
 def VVZUxH(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFa467(cmd)
  return lines
 def VVlBgT(self, lines, headerRepl, widths, VVwZxf):
  VVUl7I = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVUl7I.append(parts)
  if VVUl7I and len(header) == len(widths):
   VVUl7I.sort(key=lambda x: x[0].lower())
   FF69ky(self, None, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=28, VVDWdv=1)
   return True
  else:
   return False
 def VVAMfX(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFnpLo(cmd)
  if not "invalid option" in txt:
   lines  = self.VVZUxH(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VVwZxf = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVlBgT(lines, headerRepl, widths, VVwZxf)
  else:
   cmd = "df -h"
   lines  = self.VVZUxH(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VVwZxf = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVlBgT(lines, headerRepl, widths, VVwZxf)
  if not allOK:
   lines = FFa467(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFTgmt(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVNQoM:
     note = "\n%s" % FF1YQ7("Green = Mounted Partitions", VVNQoM)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVChVP
     elif line.endswith(mountList) : color = VVNQoM
     else       : color = VVdl3O
     txt += FF1YQ7(line, color) + "\n"
    FF8ShK(self, txt + note)
   else:
    FFG2mq(self, "Not data from system !")
 def VVKNOb(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVZUxH(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVwZxf = (LEFT , CENTER, LEFT )
  allOK = self.VVlBgT(lines, headerRepl, widths, VVwZxf)
  if not allOK:
   FFL00E(self, cmd)
 def VVudxt(self):
  cmd = FFnyVC(VVnFKX, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFL00E(self, cmd)
  else : FFEPUu(self)
 def VVrWwd(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFL00E(self, cmd)
 def VVQopQ(self):
  cmd = FFnyVC(VVhuD3, "| grep secondstage")
  if cmd : FFL00E(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFEPUu(self)
 def VVVzCf(self):
  c = VVNQoM
  VV9gTz = []
  VV9gTz.append((FF1YQ7("Box Type"  , c), FF1YQ7(self.VViuow("boxtype").upper(), c)))
  VV9gTz.append((FF1YQ7("Board Version", c), FF1YQ7(self.VViuow("board_revision") , c)))
  VV9gTz.append((FF1YQ7("Chipset"  , c), FF1YQ7(self.VViuow("chipset")  , c)))
  VV9gTz.append((FF1YQ7("S/N"   , c), FF1YQ7(self.VViuow("sn")    , c)))
  VV9gTz.append((FF1YQ7("Version"  , c), FF1YQ7(self.VViuow("version")  , c)))
  VVNI3d   = []
  VVYW2f = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVYW2f = SystemInfo[key]
     else:
      VVNI3d.append((FF1YQ7(str(key), VV4aa0), FF1YQ7(str(SystemInfo[key]), VV4aa0)))
  except:
   pass
  if VVYW2f:
   VV8aIq = self.VVNHaq(VVYW2f)
   if VV8aIq:
    VV8aIq.sort(key=lambda x: x[0].lower())
    VV9gTz += VV8aIq
  if VVNI3d:
   VVNI3d.sort(key=lambda x: x[0].lower())
   VV9gTz += VVNI3d
  if VV9gTz:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FF69ky(self, None, header=header, VV9gTz=VV9gTz, VVYiuZ=widths, VVvi36=28, VVDWdv=1)
  else:
   FF8ShK(self, "Could not read info!")
 def VViuow(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFjqdo(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVNHaq(self, mbDict):
  try:
   mbList = list(mbDict)
   VV9gTz = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VV9gTz.append((FF1YQ7(subject, VVChVP), FF1YQ7(value, VVChVP)))
  except:
   pass
  return VV9gTz
 def VVWJjd(self):
  txt = self.VVdcdo("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVdcdo("/proc/bus/nim_sockets")
  if not txt: txt = self.VVKxN5()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FF8ShK(self, txt)
 def VVKxN5(self):
  txt = ""
  VVy4Ld = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVy4Ld("Slot Name" , slot.getSlotName())
     txt += FF1YQ7(slotName, VVChVP)
     txt += VVy4Ld("Description"  , slot.getFullDescription())
     txt += VVy4Ld("Frontend ID"  , slot.frontend_id)
     txt += VVy4Ld("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVdcdo(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFjqdo(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FF1YQ7(line, VVChVP)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVydzn(self):
  major   = pyVersion[0]
  minor   = pyVersion[1]
  micro   = pyVersion[2]
  releaselevel = pyVersion[3]
  serial   = pyVersion[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FF8ShK(self, txt)
 @staticmethod
 def VVRK7q():
  def VVy4Ld(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VVy4Ld(v,0), "/etc/issue.net": VVy4Ld(v,1), "/etc/image-version": VVy4Ld(v,2)}
  for p1, d in v.items():
   img = CCpL5C.VVDHFh(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VVy4Ld(v,0), p + "Plugins/": VVy4Ld(v,1), VVlNeR: VVy4Ld(v,2), VVuGsg: VVy4Ld(v,3)}
  for p1, d in v.items():
   img = CCpL5C.VVjHwX(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VVDHFh(path, d):
  if fileExists(path):
   txt = FFSIRe(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VVjHwX(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CC9a0J(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFdP4M(VVuQx7, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVgktg = []
  VVgktg.append(("Settings (All)"   , "Settings_All"   ))
  VVgktg.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVgktg.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVgktg.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVgktg.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVgktg.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVgktg.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VVxrH7:
   VVgktg.append(VVm7kE)
   VVgktg.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVgktg.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FFj3mb(self, VVgktg=VVgktg)
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFayJd(self["myMenu"])
  FF08xD(self)
 def VV96hS(self):
  global VVEyaB
  VVEyaB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %s" % VVDhAD
   grep = " | grep "
   if   item == "Settings_All"   : FFL00E(self, cmd)
   elif item == "Settings_HotKeys"  : FFL00E(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'")
   elif item == "Settings_ajp"   : FFL00E(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME)
   elif item == "Settings_FHDG_17"  : FFL00E(self, cmd + grep + "'config.plugins.setupGlass17.'")
   elif item == "Settings_Tuner_DiSEqC": FFL00E(self, cmd + grep + "'config.Nims.'")
   elif item == "Settings_Plugins"  : FFL00E(self, cmd + grep + "'.plugins.\|config.TS'")
   elif item == "Settings_Usage"  : FFL00E(self, cmd + grep + "'.usage.'")
   elif item == "Settings_TimeZone" : FFL00E(self, cmd + grep + "'.timezone.'")
   elif item == "Settings_Skin"  : FFL00E(self, cmd + grep + "'.skin.'")
   else        : self.close()
class CCMhuj(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFdP4M(VVuQx7, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVmOeX, VV2EXd, VVb0n7, camCommand = CCMhuj.VV71uZ()
  self.VV2EXd = VV2EXd
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VV2EXd:
   c = VVo8aK if VVb0n7 else VVifMr
   if   "oscam" in VV2EXd : camName, oC = "OSCam", c
   elif "ncam"  in VV2EXd : camName, nC = "NCam" , c
  VVgktg = []
  VVgktg.append(("OSCam Files" , "OSCamFiles" ))
  VVgktg.append(("NCam Files" , "NCamFiles" ))
  VVgktg.append(("CCcam Files" , "CCcamFiles" ))
  VVgktg.append(VVm7kE)
  VVgktg.append((VVyz0j + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VVh1Fm" ))
  VVgktg.append(VVm7kE)
  VVgktg.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVgktg.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVgktg.append(VVm7kE)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  VVgktg.append(FFVKGp(txt, "camInfo", VV2EXd, c))
  VVgktg.append(VVm7kE)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VV2EXd:
   for item in camLst: VVgktg.append(item)
  else:
   for item in camLst: VVgktg.append((item[0], ))
  FFj3mb(self, VVgktg=VVgktg)
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFayJd(self["myMenu"])
  FF08xD(self)
 def VV96hS(self):
  global VVEyaB
  VVEyaB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CCkPwd, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CCkPwd, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CCkPwd, "cccam"))
   elif item == "VVh1Fm" : self.VVh1Fm()
   elif item == "OSCamReaders"  : self.VVkSrE("os")
   elif item == "NSCamReaders"  : self.VVkSrE("n")
   elif item == "camInfo"   : FFBlaB(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CCMhuj.VVimN9(self.session, CC0XOn.VV5lwE)
   elif item == "camLiveReaders" : CCMhuj.VVimN9(self.session, CC0XOn.VVC3Jw)
   elif item == "camLiveLog"  : CCMhuj.VVimN9(self.session, CC0XOn.VVVuHi)
   else       : self.close()
 def VVh1Fm(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VVrXLj, FF4Fnb())
  if fileExists(path):
   lines = FFjqdo("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VVy4Ld = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VVy4Ld("label"    , "CCcam-Line-%d" % ndx))
      f.write(VVy4Ld("description"  , "CCcam-Line-%d" % ndx))
      f.write(VVy4Ld("protocol"   , "cccam"))
      f.write(VVy4Ld("device"    , "%s,%s" % (host, port)))
      f.write(VVy4Ld("user"    , User))
      f.write(VVy4Ld("password"   , Pass))
      f.write(VVy4Ld("fallback"   , "1"))
      f.write(VVy4Ld("group"    , "64"))
      f.write(VVy4Ld("cccversion"   , "2.3.2"))
      f.write(VVy4Ld("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FF27fq(self, "Output = %d Reader%s in:\n\n%s" % (tot, FFLFel(tot), outFile))
   else:
    FFpIgV(self, "No valid CCcam lines", 1500)
  else:
   FFpIgV(self, "%s not found" % path, 1500)
 def VVkSrE(self, camPrefix):
  VVUl7I = self.VVu3Uz(camPrefix)
  if VVUl7I:
   VVUl7I.sort(key=lambda x: int(x[0]))
   if self.VV2EXd and self.VV2EXd.startswith(camPrefix):
    VVkY0R = ("Toggle State", self.VVF5CI, [camPrefix], "Changing State ...")
   else:
    VVkY0R = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVwZxf  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FF69ky(self, None, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=26, VVkY0R=VVkY0R, VVFwVS=True)
 def VVu3Uz(self, camPrefix):
  readersFile = self.VVmOeX + camPrefix + "cam.server"
  VVUl7I = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFjqdo(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVUl7I.append((str(len(VVUl7I) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVUl7I:
    FFG2mq(self, "No readers found !")
  else:
   FFcMQr(self, readersFile)
  return VVUl7I
 def VVF5CI(self, VVkINB, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVmOeX, camPrefix)
  readerState  = VVkINB.VVRYeh(1)
  readerLabel  = VVkINB.VVRYeh(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCMhuj.VVm3uo(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVkINB.VVTm6g()
    FFG2mq(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVUl7I = self.VVu3Uz(camPrefix)
   if VVUl7I:
    VVkINB.VVDqeT(VVUl7I)
  else:
   VVkINB.VVTm6g()
 @staticmethod
 def VVm3uo(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFjqdo(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFG2mq(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFG2mq(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFcMQr(SELF, confFile)
   return None
  if not iRequest:
   FFG2mq(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CCMhuj.VVQg4l(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FFG2mq(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VVQg4l(SELF):
  if iElem:
   return True
  else:
   FFG2mq(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVimN9(session, VVrP6W):
  VVmOeX, VV2EXd, VVb0n7, camCommand = CCMhuj.VV71uZ()
  if VV2EXd:
   runLog = False
   if   VVrP6W == CC0XOn.VV5lwE : runLog = True
   elif VVrP6W == CC0XOn.VVC3Jw : runLog = True
   elif not VVb0n7          : FF07lH(session, message="SoftCam not started yet!")
   elif fileExists(VVb0n7)        : runLog = True
   else             : FF07lH(session, message="File not found !\n\n%s" % VVb0n7)
   if runLog:
    session.open(BF(CC0XOn, VVmOeX=VVmOeX, VV2EXd=VV2EXd, VVb0n7=VVb0n7, VVrP6W=VVrP6W))
  else:
   FF07lH(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VV71uZ():
  VVmOeX = "/etc/tuxbox/config/"
  VV2EXd = None
  VVb0n7  = None
  camCommand = FFdHIn("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VV2EXd = "oscam"
   elif camCmd.startswith("ncam") : VV2EXd = "ncam"
  if VV2EXd:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FFSIRe(path), IGNORECASE)
     if span:
      VVmOeX = FFGa2t(span.group(1))
      break
   else:
    path = FFdHIn(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FFGa2t(path)
    if pathExists(path):
     VVmOeX = path
   tFile = FFGa2t(VVmOeX) + VV2EXd + ".conf"
   tFile = FFdHIn("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VVb0n7 = tFile
  return VVmOeX, VV2EXd, VVb0n7, camCommand
class CCkPwd(Screen):
 def __init__(self, VVH5Qs, session, args=0):
  self.skin, self.skinParam = FFdP4M(VVuQx7, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVmOeX, VV2EXd, VVb0n7, camCommand = CCMhuj.VV71uZ()
  if   VVH5Qs == "ncam" : self.prefix = "n"
  elif VVH5Qs == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVgktg = []
  if self.prefix == "":
   VVgktg.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVgktg.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVgktg.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVgktg.append(("constant.cw"         , "x_constant_cw" ))
   VVgktg.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVgktg.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVgktg.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVgktg.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVgktg.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVgktg.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVgktg.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVgktg.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVgktg.append(VVm7kE)
   VVgktg.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVgktg.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVgktg.append(VVm7kE)
   VVgktg.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVgktg.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVgktg.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFj3mb(self, VVgktg=VVgktg)
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFayJd(self["myMenu"])
  FF08xD(self)
 def VV96hS(self):
  global VVEyaB
  VVEyaB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFMf21(self, "/var/etc/CCcam.cfg")
   elif item == "c_ecm_info"  : FFMf21(self, "/tmp/ecm.info")
   elif item == "x_AutoRoll_Key" : FFMf21(self, self.VVmOeX + "AutoRoll.Key")
   elif item == "x_constant_cw" : FFMf21(self, self.VVmOeX + "constant.cw")
   elif item == "x_cam_ccache"  : self.VVCauh("cam.ccache")
   elif item == "x_cam_conf"  : self.VVCauh("cam.conf")
   elif item == "x_cam_dvbapi"  : self.VVCauh("cam.dvbapi")
   elif item == "x_cam_provid"  : self.VVCauh("cam.provid")
   elif item == "x_cam_server"  : self.VVCauh("cam.server")
   elif item == "x_cam_services" : self.VVCauh("cam.services")
   elif item == "x_cam_srvid2"  : self.VVCauh("cam.srvid2")
   elif item == "x_cam_user"  : self.VVCauh("cam.user")
   elif item == "x_SEP"   : pass
   elif item == "x_SoftCam_Key" : self.VVyX0H()
   elif item == "x_CCcam_cfg"  : FFMf21(self, self.VVmOeX + "CCcam.cfg")
   elif item == "x_SEP"   : pass
   elif item == "x_cam_log"  : FFMf21(self, pathTmp + self.prefix + "cam.log")
   elif item == "x_cam_log_prev" : FFMf21(self, pathTmp + self.prefix + "cam.log-prev")
   elif item == "x_cam_pid"  : FFMf21(self, pathTmp + self.prefix + "cam.pid")
   else       : self.close()
 def VVCauh(self, fileName):
  FFMf21(self, self.VVmOeX + self.prefix + fileName)
 def VVyX0H(self):
  path = self.VVmOeX + "SoftCam.Key"
  if fileExists(path) : FFMf21(self, path)
  else    : FFMf21(self, path.replace(".Key", ".key"))
class CC0XOn(Screen):
 VV5lwE  = 0
 VVC3Jw = 1
 VVVuHi = 2
 def __init__(self, session, VVmOeX="", VV2EXd="", VVb0n7="", VVrP6W=VV5lwE):
  self.skin, self.skinParam = FFdP4M(VViAAJ, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVb0n7   = VVb0n7
  self.VVrP6W  = VVrP6W
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVmOeX + VV2EXd + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VV2EXd : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVmOeX, self.camPrefix)
  if self.VVrP6W == self.VV5lwE:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVrP6W == self.VVC3Jw:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFj3mb(self, self.Title, addScrollLabel=True)
  FFuetT(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VV9pQX
  self.onShown.append(self.VVgr8g)
  self.onClose.append(self.onExit)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  self["myLabel"].VVdp3X(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FF2kyZ(self)
  self.VV9pQX()
 def onExit(self):
  self.timer.stop()
 def VVo9Ik(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVhpEH)
  except:
   self.timer.callback.append(self.VVhpEH)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFpIgV(self, "Started", 1000)
 def VVjDK1(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVhpEH)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFpIgV(self, "Stopped", 1000)
 def VV9pQX(self):
  if self.timerRunning:
   self.VVjDK1()
  else:
   self.VVo9Ik()
   if self.VVrP6W == self.VV5lwE or self.VVrP6W == self.VVC3Jw:
    if self.VVrP6W == self.VV5lwE : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCMhuj.VVm3uo(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFLYGh(self.VVLwfs)
    else:
     self.close()
   else:
    self.VVANCQ()
 def VVhpEH(self):
  if self.timerRunning:
   if   self.VVrP6W == self.VV5lwE : self.VVvgGS()
   elif self.VVrP6W == self.VVC3Jw : self.VVvgGS()
   else            : self.VVANCQ()
 def VVANCQ(self):
  if fileExists(self.VVb0n7):
   fTime = FFPuhT(os.path.getmtime(self.VVb0n7))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVRM3T(), VVMXNv=VVCUL7)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVb0n7)
 def VVLwfs(self):
  self.VVvgGS()
 def VVvgGS(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FF1YQ7("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVf8NN))
   self.camWebIfErrorFound = True
   self.VVjDK1()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVrP6W == self.VV5lwE : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FF1YQ7("Error while parsing data elements !\n\nError = %s" % str(e), VVYZPJ)
   self.camWebIfErrorFound = True
   self.VVjDK1()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VV7kwq(root)
  self["myLabel"].setText(txt, VVMXNv=VVCUL7)
  self["myBar"].setText("Last Update : %s" % FFzGjj())
 def VV7kwq(self, rootElement):
  def VVy4Ld(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVrP6W == self.VV5lwE:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FF1YQ7(status, VVNQoM)
    else          : status = FF1YQ7(status, VVYZPJ)
    txt += SEP + "\n"
    txt += VVy4Ld("Name"  , name)
    txt += VVy4Ld("Description" , desc)
    txt += VVy4Ld("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVy4Ld("Protocol" , protocol)
    txt += VVy4Ld("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FF1YQ7("Yes", VVNQoM)
    else    : enabTxt = FF1YQ7("No", VVYZPJ)
    txt += SEP + "\n"
    txt += VVy4Ld("Label"  , label)
    txt += VVy4Ld("Protocol" , protocol)
    txt += VVy4Ld("Enabled" , enabTxt)
  return txt
 def VVRM3T(self):
  lines = FFa467("tail -n %d %s" % (100, self.VVb0n7))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VVeksK + line[:19] + VVdl3O + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VVhCly + "WebIf" + VVdl3O)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VV4aa0 + h1 + h2 + VVdl3O + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VVNQoM + span.group(2) + VVyz0j + span.group(3) + VVdl3O + span.group(4)
    line = self.VVDfSs(line, VVyz0j, ("(webif)", ))
    line = self.VVDfSs(line, VVyz0j, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VVDfSs(line, VVNQoM, ("OSCam", "NCam", "log switched"))
    line = self.VVDfSs(line, VVWgbP, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVChVP + line[ndx + 3:] + VVdl3O
   elif line.startswith("----") or ">>" in line:
    line = FF1YQ7(line, VVTKcZ)
   txt += line + "\n"
  return txt
 def VVDfSs(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVdl3O + t3
  return line
class CCrB7W(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFdP4M(VVuQx7, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVgktg = []
  VVgktg.append(("Backup Channels"    , "VVcXLj"   ))
  VVgktg.append(("Restore Channels"    , "Restore_Channels"  ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Backup SoftCAM Files"   , "VVYCxZ" ))
  VVgktg.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVgktg.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVgktg.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Backup Network Settings"  , "VVis7e"   ))
  VVgktg.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVxrH7:
   VVgktg.append(VVm7kE)
   VVgktg.append((VVf8NN + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME    , "VVBEPh"   ))
   VVgktg.append((VVNQoM + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVY49w), "createMyIpk"   ))
   VVgktg.append((VVNQoM + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVY49w), "createMyDeb"   ))
   VVgktg.append((VV4aa0 + "Create %s TAR (Absolute Path)" % PLUGIN_NAME    , "createMyTar"   ))
   VVgktg.append((VV4aa0 + "Decode %s Crash Report"   % PLUGIN_NAME    , "VVO2Ex" ))
   VVgktg.append((VV4aa0 + "Show Windows Stats"           , "VVjQHF" ))
  FFj3mb(self, VVgktg=VVgktg)
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFayJd(self["myMenu"])
  FF08xD(self)
 def VV96hS(self):
  global VVEyaB
  VVEyaB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVcXLj"    : self.VVcXLj()
   elif item == "Restore_Channels"    : self.VVqeXr("channels_backup*.tar.gz", self.VVj1Bv, isChan=True)
   elif item == "VVYCxZ"   : self.VVYCxZ()
   elif item == "Restore_SoftCAM_Files"  : self.VVqeXr("softcam_backup*.tar.gz", self.VVGymf)
   elif item == "Backup_TunerDiSEqC"   : self.VVFHeV("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVqeXr("tuner_backup*.backup", BF(self.VVEtVe, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVFHeV("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVqeXr("hotkey_*backup*.backup", BF(self.VVEtVe, "misc"))
   elif item == "VVis7e"    : self.VVis7e()
   elif item == "Restore_Network"    : self.VVqeXr("network_backup*.tar.gz", self.VV4CuZ)
   elif item == "VVBEPh"     : FFDiGG(self, BF(FFkWFV, self, BF(CCrB7W.VVBEPh, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVlyq8(False)
   elif item == "createMyDeb"     : self.VVlyq8(True)
   elif item == "createMyTar"     : self.VV2V4K()
   elif item == "VVO2Ex"   : self.VVO2Ex()
   elif item == "VVjQHF"    : CCrB7W.VVjQHF(self)
 @staticmethod
 def VV4rj9(SELF):
  OBF_Path = VV3r3b + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try: from .OBF import obf
   except: import obf
   reload(obf)
   return obf
  else:
   FFcMQr(SELF, OBF_Path)
   return None
 @staticmethod
 def VVjQHF(SELF):
  obf = CCrB7W.VV4rj9(SELF)
  if obf:
   txt, title = obf.windowsStats()
   FF8ShK(SELF, txt, title=title, outputFileToSave="WinStat")
 @staticmethod
 def VVBEPh(SELF):
  obf = CCrB7W.VV4rj9(SELF)
  if obf:
   txt, err = obf.fixCode(VV3r3b, VV9AsZ, VVY49w)
   if err : FFG2mq(SELF, err)
   else : FF8ShK(SELF, txt)
 def VVlyq8(self, VVYfey):
  OBF_Path = VV3r3b + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFG2mq(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  FFLgW2("rm -f %s__pycache__/" % VV3r3b)
  FFLgW2("mv -f '%smain.py' '%s'" % (VV3r3b, OBF_Path))
  FFLgW2("mv -f '%splugin.py' '%s'" % (VV3r3b, OBF_Path))
  FFLgW2("cp -f %s*main_final.py %splugin.py" % (OBF_Path, VV3r3b))
  self.session.openWithCallback(self.VVTl4P, BF(CCtQ7C, path=VV3r3b, VVYfey=VVYfey))
 def VVTl4P(self):
  FFLgW2("mv -f %s %s" % (VV3r3b + "OBF/main.py" , VV3r3b))
  FFLgW2("mv -f %s %s" % (VV3r3b + "OBF/plugin.py", VV3r3b))
 def VVO2Ex(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFG2mq(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFG2mq(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VV3DHs("%s*.list" % path)
  if err:
   FFcMQr(self, path + "*.list")
   return
  srcF, err = self.VV3DHs("%s*main_final.py" % path)
  if err:
   FFcMQr(self, path + "*.final.py")
   return
  VV9gTz = []
  for f in files:
   f = os.path.basename(f)
   VV9gTz.append((f, f))
  FFBqvZ(self, BF(self.VVz5Nr, path, codF, srcF), VVgktg=VV9gTz)
 def VVz5Nr(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFcMQr(self, logF)
   else     : FFkWFV(self, BF(self.VVz1u3, logF, codF, srcF))
 def VVz1u3(self, logF, codF, srcF):
  lst  = []
  lines = FFjqdo(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFG2mq(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VV71UG(lst, logF, newLogF)
  totSrc  = self.VV71UG(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FF8ShK(self, txt)
 def VV3DHs(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VV71UG(self, lst, f1, f2):
  txt = FFSIRe(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VV2V4K(self):
  VV9gTz = []
  VV9gTz.append("%s%s" % (VV3r3b, "*.py"))
  VV9gTz.append("%s%s" % (VV3r3b, "*.png"))
  VV9gTz.append("%s%s" % (VV3r3b, "*.xml"))
  VV9gTz.append("%s"  % (VVkwgw))
  FFHdLu(self, VV9gTz, "%s_%s" % (PLUGIN_NAME, VV9AsZ), addTimeStamp=False)
 def VVcXLj(self):
  path1 = VVMixw
  path2 = "/etc/tuxbox/"
  VV9gTz = []
  VV9gTz.append("%s%s" % (path1, "*.tv"))
  VV9gTz.append("%s%s" % (path1, "*.radio"))
  VV9gTz.append("%s%s" % (path1, "*list"))
  VV9gTz.append("%s%s" % (path1, "lamedb*"))
  VV9gTz.append("%s%s" % (path2, "*.xml"))
  FFHdLu(self, VV9gTz, self.VVl8Mi("channels_backup"), addTimeStamp=True)
 def VVYCxZ(self):
  VV9gTz = []
  VV9gTz.append("/etc/tuxbox/config/")
  VV9gTz.append("/usr/keys/")
  VV9gTz.append("/usr/scam/")
  VV9gTz.append("/etc/CCcam.cfg")
  FFHdLu(self, VV9gTz, self.VVl8Mi("softcam_backup"), addTimeStamp=True)
 def VVis7e(self):
  VV9gTz = []
  VV9gTz.append("/etc/hostname")
  VV9gTz.append("/etc/default_gw")
  VV9gTz.append("/etc/resolv.conf")
  VV9gTz.append("/etc/wpa_supplicant*.conf")
  VV9gTz.append("/etc/network/interfaces")
  VV9gTz.append("%snameserversdns.conf" % VVMixw)
  FFHdLu(self, VV9gTz, self.VVl8Mi("network_backup"), addTimeStamp=True)
 def VVl8Mi(self, fName):
  img = CCpL5C.VVRK7q()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VVj1Bv(self, fileName=None):
  if fileName:
   FFDiGG(self, BF(FFkWFV, self, BF(self.VV8xup, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VV8xup(self, fileName):
  path = "%s%s" % (VVrXLj, fileName)
  if fileExists(path):
   if CCyssW.VV4AIW(path):
    VVqizq , VV7f3w = CCmfL4.VVgbQn()
    VVesVR, VVvbY9 = CCmfL4.VVUXrv()
    cmd  = FFhkCt("cd %s" % VVMixw)
    cmd += FFhkCt("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VV7f3w, VVvbY9))
    cmd += "tar -xzf '%s' -C /" % path
    ok = FFLgW2(cmd)
    FFHpDz()
    if ok: FF27fq(self, "Channels Restored.")
    else : FFG2mq(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FFG2mq(self, "Invalid tar file:\n\n%s" % path)
  else:
   FFcMQr(self, path)
 def VVGymf(self, fileName=None):
  if fileName:
   FFDiGG(self, BF(self.VVMfoF, fileName), "Overwrite SoftCAM files ?")
 def VVMfoF(self, fileName):
  fileName = "%s%s" % (VVrXLj, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % SEP
   note = "You may need to restart your SoftCAM."
   FF0I5A(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFog5k(note, VVChVP), sep))
  else:
   FFcMQr(self, fileName)
 def VV4CuZ(self, fileName=None):
  if fileName:
   FFDiGG(self, BF(self.VVewan, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVewan(self, fileName):
  fileName = "%s%s" % (VVrXLj, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FF20zH(self,  cmd)
  else:
   FFcMQr(self, fileName)
 def VVqeXr(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FFMV8t()
  if pathExists(VVrXLj):
   myFiles = FFcJlI(VVrXLj, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VV9gTz = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VV9gTz.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VVG8PG = ("Sat. List", self.VVpun7)
    elif isChan and iTar: VVG8PG = ("Bouquets Importer", CCZL1y.VVzZNx)
    else    : VVG8PG = None
    FFBqvZ(self, callBackFunction, title=title, width=1200, VVgktg=VV9gTz, VVG8PG=VVG8PG, VVfXMZ=VVrXLj)
   else:
    FFG2mq(self, "No files found in:\n\n%s" % VVrXLj, title)
  else:
   FFG2mq(self, "Path not found:\n\n%s" % VVrXLj, title)
 def VVFHeV(self, filePrefix, wordsFilter):
  title = FFMV8t()
  if fileExists(VVDhAD):
   tCons = CCz78Z()
   tCons.ePopen("cat %s | grep '%s'" % (VVDhAD, wordsFilter), BF(self.VVPPdf, title, filePrefix))
  else:
   FFG2mq(self, "Cannot read settings file", title)
 def VVPPdf(self, title, filePrefix, result, retval):
  if pathExists(VVrXLj):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFG2mq(self, "No settings found to backup !", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVrXLj, filePrefix, self.VVl8Mi(""), FF4Fnb())
    try:
     VV9gTz = str(result.strip()).split()
     if VV9gTz:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VV9gTz:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (SEP, FF1YQ7(fName, VVChVP), SEP)
       FF8ShK(self, txt, title=title, VVMXNv=VVCUL7)
      else:
       FFG2mq(self, "File creation failed!", title)
     else:
      FFG2mq(self, "Parameters not found in settings file.", title)
    except IOError as e:
     FFLgW2("rm %s" % fName)
     FFG2mq(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     FFLgW2("rm %s" % fName)
     FFG2mq(self, "Error while writing file.")
  else:
   FFG2mq(self, "Path not found:\n\n%s" % VVrXLj, title)
 def VVEtVe(self, mode, path=None):
  if path:
   path = "%s%s" % (VVrXLj, path)
   if fileExists(path):
    lines = FFjqdo(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFDiGG(self, BF(self.VVHxJb, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFM0Ji(self, path, title=FFMV8t())
   else:
    FFcMQr(self, path)
 def VVHxJb(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  finalList = []
  for line in newList:
   if line.strip() and not line in finalList:
    finalList.append(line)
  VV4Fmi = []
  tFile = "/tmp/ajp_tmp"
  VV4Fmi.append("echo -e 'Reading current settings ...'")
  VV4Fmi.append("cat %s | grep -v '%s' > %s" % (VVDhAD, grepFilter, tFile))
  settingsLines = "echo -e '"
  for line in finalList:
   settingsLines += line
  settingsLines = settingsLines.strip()
  settingsLines += "' >> %s" % tFile
  VV4Fmi.append("echo -e 'Preparing new settings ...'")
  VV4Fmi.append(settingsLines)
  VV4Fmi.append("echo -e 'Applying new settings ...'")
  VV4Fmi.append("mv -f %s %s" % (tFile, VVDhAD))
  FFyemP(self, VV4Fmi)
 def VVpun7(self, selectionObj, path):
  if not path:
   return
  path = VVrXLj + path
  if not fileExists(path):
   FFcMQr(self, path)
   return
  txt = FFSIRe(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   txt = ""
   for item in satList:
    txt += "%s\t%s\n" % (item[0], FFthxA(item[1]))
   FF8ShK(self, txt, title="Satellites List")
  else:
   FFG2mq(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCZL1y():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VVzZNx(SELF, fName):
  bi = CCZL1y(SELF)
  bi.instance = bi
  bi.VVhVlR(SELF, fName)
 @staticmethod
 def VV7JiB(SELF):
  bi = CCZL1y(SELF)
  bi.instance = bi
  bi.VVeX0V()
 def VVhVlR(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VVrXLj + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FFkWFV(waitObg, self.VVCGGT, title="Reading bouquets ...")
  else      : self.VVbuHo(self.filePath)
 def VVr3Eu(self, txt) : FFG2mq(self.SELF, txt, title=self.Title)
 def VVT0Gn(self, txt)  : FFpIgV(self, txt, 1500)
 def VVbuHo(self, path) : FFcMQr(self.SELF, path, title=self.Title)
 def VVeX0V(self):
  if pathExists(VVrXLj):
   lst = FFcJlI(VVrXLj, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VVbDdl())
   if len(lst) > 0:
    VVgktg = []
    for item in lst:
     item = os.path.basename(item)
     txt = FF1YQ7(item, VVyz0j) if item.endswith(".zip") else item
     VVgktg.append((txt, item))
    VVgktg.sort(key=lambda x: x[1].lower())
    VVl3Ru = self.VVRFmU
    FFBqvZ(self.SELF, self.VV5kC3, minRows=3, title=self.Title, width=1200, VVgktg=VVgktg, VVl3Ru=VVl3Ru, VVfXMZ=VVrXLj, VVrcFy="#22111111", VVZZ3c="#22111111")
   else:
    self.VVr3Eu("No valid backup files found in:\n\n%s" % VVrXLj)
  else:
   self.VVr3Eu("Backup Directory not found:\n\n%s" % VVrXLj)
 def VVRFmU(self, item=None):
  if item:
   VVVYOp, txt, fName, ndx = item
   self.VVhVlR(VVVYOp, fName)
 def VV5kC3(self, item=None):
  if not item and self.instance:
   del self.instance
 def VVbDdl(self):
  files = FFcJlI(VVrXLj, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VVCGGT(self):
  lines, err = CCZL1y.VVHUla(self.filePath, "bouquets.tv")
  if err:
   self.VVr3Eu(err)
   return
  bTvSortLst  = self.VV89Nt(lines)
  lines, err = CCZL1y.VVHUla(self.filePath, "bouquets.radio")
  if err:
   self.VVr3Eu(err)
   return
  bRadSortLst = self.VV89Nt(lines)
  VVUl7I = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VVerl0(f, mode, len(VVUl7I), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VVUl7I.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VVerl0(f, mode, len(VVUl7I), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VVerl0(f, mode, len(VVUl7I), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VVUl7I.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VVerl0(f, mode, len(VVUl7I), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VVUl7I:
   VVUl7I.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VVUl7I): VVUl7I[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VVUl7I):
     if key == os.path.basename(row[9]):
      VVUl7I = VVUl7I[:ndx+1] + lst + VVUl7I[ndx+1:]
      break
   for ndx, item in enumerate(VVUl7I): VVUl7I[ndx][0] = str(ndx + 1)
   VVRr4z = "#11000600"
   VVp0o5  = ("Show Services" , self.VVzHZ7  , [], "Reading ..." )
   VVq5Be = (""    , self.VVtmxh, [])
   VVW1zM = ("Options"  , self.VVmv0i, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "S.Relay" , "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 36   , 7  , 7   , 7  , 7  , 7   , 7   , 7   , 8   ,  0.01 )
   VVwZxf  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER , CENTER ,  LEFT )
   FF69ky(self.SELF, None, title=self.Title, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=24, VVp0o5=VVp0o5, VVq5Be=VVq5Be, VVW1zM=VVW1zM, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVrcFy=VVRr4z, VVZZ3c=VVRr4z, VVRr4z=VVRr4z, VVLwCQ="#00004455", VVhvzQ="#0a282828")
  else:
   self.VVr3Eu("No valid bouquets in:\n\n%s" % self.filePath)
 def VV89Nt(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VVtmxh(self, VVkINB, title, txt, colList):
  FF8ShK(self.SELF, FFOD7l(txt), title=title)
 def VVmv0i(self, VVkINB, title, txt, colList):
  mSel = CCVAoa(self.SELF, VVkINB)
  if VVkINB.VVopq8:
   totSel = VVkINB.VVIf28()
   if totSel: VVgktg = [("Import %s Bouquet%s" % (FF1YQ7(str(totSel), VVNQoM), FFLFel(totSel)), "imp")]
   else  : VVgktg = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FF1YQ7(bName, VVNQoM)
   VVgktg = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FFkWFV, VVkINB, BF(CCZL1y.VVfEfF, self.SELF, VVkINB, self.filePath))}
  mSel.VVLgo2(VVgktg, cbFncDict)
 def VVzHZ7(self, VVkINB, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CCZL1y.VVHUla(self.filePath, "lamedb")
   if err:
    self.VVr3Eu(err)
    return
   dbServLst = CCmfL4.VVmZYf(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName = VVkINB.VVw0xB()
   lines, err = CCZL1y.VVHUla(self.filePath, os.path.basename(fName))
   if err:
    self.VVr3Eu(err)
    return
   VVUl7I = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VVUl7I.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VVUl7I.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VVUl7I.append((span.group(1).strip() or "-", "Stream Relay" if FFtvcx(line) else "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VVUl7I.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VVUl7I.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CCmfL4.VV2fpO(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VVUl7I.append((name.strip() or "-", FFCt6D(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VVUl7I):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CCZL1y.VVHUla(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VVUl7I[ndx] = (bName, descr)
   if VVUl7I:
    VVRr4z = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VVwZxf = (LEFT  , CENTER)
    FF69ky(self.SELF, None, title="Services in : %s" % bName, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=28, VVrcFy=VVRr4z, VVZZ3c=VVRr4z, VVRr4z=VVRr4z, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FFpIgV(VVkINB, err, 1500)
  else : VVkINB.VVTm6g()
 def VVerl0(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totSRelay = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VVr3Eu("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif FFtvcx(line)             : totSRelay += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VVGnZU(var):
   return str(var) if var else VVqC3w + str(var)
  totItem = VVChVP + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VVf8NN   , str(totBnb)
  elif isSubB : bColor, totBnb  = VVyz0j, "Sub-B."
  else  : bColor, totBnb = ""      , VVGnZU(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VVGnZU(totDVB), VVGnZU(totIptv), VVGnZU(totSRelay), VVGnZU(totLoc), VVGnZU(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VVfEfF(SELF, VVkINB, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVMixw + "bouquets.tv"
  radBouquetFile = VVMixw + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FFcMQr(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FFcMQr(SELF, radBouquetFile, title=title)
   return
  isMulti = VVkINB.VVopq8
  if isMulti : rows = VVkINB.VV0XBH()
  else  : rows = [VVkINB.VVw0xB()]
  for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FFG2mq(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FFOD7l(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FFOD7l(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVMixw + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVMixw + newFile
    CCZL1y.VVWAe8(archPath, fName, VVMixw, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   FFVch7(tvBouquetFile)
   FFVch7(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CCZL1y.VV1oFF(SELF, archPath, bList)
   FFHpDz()
  txt  = FF1YQ7("Added:\n", VVyz0j)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FF1YQ7("Imported to lamedab:\n", VVyz0j)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FF1YQ7("Missing from archived lamedb:\n", VVf8NN)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FF8ShK(SELF, txt, title=title, width=1000)
 @staticmethod
 def VV1oFF(SELF, archPath, bList):
  VVqizq, err = CCmfL4.VVECFt(SELF, VVoFHD=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CCmfL4.VVx9TU(VVqizq, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FFjqdo(VVMixw + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CCmfL4.VV2fpO(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CCmfL4.VVOQgW(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CCZL1y.VVXX5s(archPath, dbName)
   CCZL1y.VVWAe8(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CCmfL4.VVx9TU(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CCmfL4.VVx9TU(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CCmfL4.VVx9TU(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CCmfL4.VVx9TU(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FFMc8G(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VVqizq + ".tmp"
   lines   = FFjqdo(VVqizq)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   FFLgW2("mv -f '%s' '%s'" % (tmpDbFile, VVqizq))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VVwfRc(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VVXX5s(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VVWAe8(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VVHUla(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CCQaUY():
 def __init__(self):
  self.projTitle   = "Package Creator"
  self.projPrefix   = "ajpanel_package_"
  self.projMainPath  = CFG.packageOutputPath.getValue()
  self.projName   = ""
  self.projPath   = ""
  self.projFile   = ""
  self.projMenu   = None
  self.projTable   = None
  self.projFile_control = ""
  self.projFile_preRm  = ""
  self.projFile_postRm = ""
  self.projFile_preInst = ""
  self.projFile_postInst = ""
  self.projLastDepends = ""
  self.VVhPYP()
 def VVhPYP(self):
  self.projPkg   = ""
  self.projVer   = ""
  self.projArch   = ""
  self.projFilesSize  = 0
  self.projTotalDirs  = 0
  self.projTotalFiles  = 0
  self.projAct_postInst = 0
  self.projAct_postRm  = 0
 def VVy3dA(self):
  FFkWFV(self, self.VV31BD)
 def VV31BD(self):
  if pathExists(self.projMainPath):
   lst = FF4id7(self.projMainPath)
   VVgktg = []
   if lst:
    for path in lst:
     if path.startswith(self.projPrefix):
      prName = os.path.basename(path)
      VVgktg.append((prName, prName))
   if VVgktg:
    VVgktg.sort(key=lambda x: x[1].lower())
    VVl3Ru = self.VVtZrn
    VVG8PG = ("Add new project", self.VV3K8y)
    VVG0eT= ("Delete Project" , self.VVcBMX)
    self.projMenu = FFBqvZ(self, None, VVgktg=VVgktg, width=1100, VVl3Ru=VVl3Ru, VVG8PG=VVG8PG, VVG0eT=VVG0eT, minRows=5, VVrcFy="#22111133", VVZZ3c="#22111133")
   else:
    FFDiGG(self, self.VVGcNt, "No projects found !\n\n Create new project ?", title=self.projTitle)
  else:
   self.VVMXkF("Main Packages Directory not found:\n\n%s" % self.projMainPath)
 def VVGcNt(self)    : FFkWFV(self, BF(self.VVoD1x))
 def VV3K8y(self, VVVYOp, item) : FFkWFV(self.projMenu, BF(self.VVoD1x))
 def VVoD1x(self):
  c = 0
  while True:
   c += 1
   name = "project_%d" % (c)
   if not pathExists("%s%s%s" % (self.projMainPath, self.projPrefix, name)):
    break
  self.VVe25X(name)
 def VVe25X(self, name, cbFnc=None):
  FF8ISk(self, cbFnc or self.VVMdyd, defaultText=name, title="New Project Name", message="Enter project name")
 def VVMdyd(self, name):
  if name and name.strip():
   path = "%s%s%s" % (self.projMainPath, self.projPrefix, name)
   if pathExists(path):
    FFDiGG(self, BF(self.VVe25X, name), "Project directory already exists !\n\n Change name ?", title=self.projTitle)
   else:
    err = FFMvn6(path)
    if err:
     self.VVMXkF("Cannot create project directory !\n\n %s" % err)
    else:
     item = os.path.basename(path)
     if self.projMenu: self.projMenu.VVLDpi((item, item), isSort=True)
     else   : self.VVy3dA()
 def VVcBMX(self, VVVYOp, path):
  if path:
   path = self.projMainPath + path
   if pathExists(path):
    totDir, totFile, totLink = FFaAKb(path)
    FFDiGG(self, BF(self.VV7RB6, path), "Project directory contains %d items.\n\n%s\n\nDelete ?" %(totDir + totFile + totLink, path), title=self.projTitle)
 def VV7RB6(self, path):
  if FFLgW2("rm -rf '%s'" % path):
   self.projMenu.VVsxK0()
 def VVtZrn(self, item=None):
  if item:
   VVVYOp, txt, Dir, ndx = item
   self.VVhPYP()
   self.projName = os.path.basename(Dir)[len(self.projPrefix):]
   self.projPath = "%s%s/" % (self.projMainPath, Dir)
   self.projFile = "%s%s.cfg"  % (self.projPath, self.projName)
   self.projFile_control = self.projPath + "control"
   self.projFile_preRm  = self.projPath + "prerm"
   self.projFile_postRm = self.projPath + "postrm"
   self.projFile_preInst = self.projPath + "preinst"
   self.projFile_postInst = self.projPath + "postinst"
   tmplF = "%sajpanel_pkg" % VVkwgw
   if not fileExists(self.projFile_control) and fileExists(tmplF):
    pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
    with open(self.projFile_control, "w") as f:
     for line in FFjqdo(tmplF, keepends=True):
      f.write(line.replace("xx1", pkg).replace("xx2", self.projName))
   if not fileExists(self.projFile):
    with open(self.projFile, "w") as f:
     sep = "#" * 80
     f.write("%s\n" % sep)
     f.write("%s Project\t: %s\n" % ("#", self.projName))
     f.write("%s Started\t: %s\n" % ("#", FFzGjj()))
     f.write("%s\n" % sep)
   if fileExists(self.projFile): self.VVdDsn()
   else      : self.VVMXkF("Cannot create project file:\n\n%s" % self.projFile)
 def VVdDsn(self, VVVYOp=None, jmpDict=None):
  FFkWFV(VVVYOp or self.projTable or self, BF(self.VVugdy, jmpDict))
 def VVugdy(self, jmpDict):
  self.VVhPYP()
  pkgRows, ctrlRows, actnRows, fileRows, unknRows = [], [], [], [], []
  if fileExists(self.projFile_control):
   for lineNdx, line in enumerate(FFjqdo(self.projFile_control)):
    line = line.strip()
    if ":" in line:
     subj, val, rem = self.VVJ1P3(line)
     pkgRows.append((str(lineNdx), "Control", subj, val, "", rem, ""))
  if not pkgRows:
   self.VVMXkF('Invalid "control" file:\n\n%s' % self.projFile_control)
   return
  for path in (self.projFile_preInst, self.projFile_postInst, self.projFile_preRm, self.projFile_postRm):
   size = val = ""
   if fileExists(path):
    val = path
    sz = FF1fFq(path)
    if sz > -1: size = CCyssW.VV1ctA(sz, mode=4)
    else   : size = FF1YQ7("Size error", VVf8NN)
   ctrlRows.append(("", "Script", os.path.basename(path), val, size, "", ""))
  for lineNdx, line in enumerate(FFjqdo(self.projFile)):
   lineNdx = str(lineNdx)
   line = line.strip()
   if line and not line.startswith("#"):
    validF = size = rem = ""
    if line.startswith("/"):
     path, fName, typ, size, rem, validF = self.VVdep9(line, fileRows)
     fileRows.append((lineNdx, "Resource", typ or "Unknown", path, size, rem, validF))
    else:
     Title, val = self.VVJsZB(line)
     if Title: actnRows.append((lineNdx, "Action", Title, val, size, rem, validF))
     else : unknRows.append((lineNdx, "?", "-", line, size, FF1YQ7("Unknown value", VVf8NN), validF))
  for ndx, row in enumerate(actnRows):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   rem = ""
   if   fileExists(self.projFile_postInst) and Title == "postinst" : rem = "Ignored (if custom postinst)"
   elif fileExists(self.projFile_postRm  ) and Title == "postrm" : rem = "Ignored (if custom postrm)"
   if rem:
    actnRows[ndx] = (lineNdx, Section, Title, Value, Size, FF1YQ7(rem, VVf8NN), ValidF)
  actnRows.sort(key=lambda x: x[2].lower())
  fileRows.sort(key=lambda x: (x[2].lower(), x[3].lower()))
  unknRows.sort(key=lambda x: x[3].lower())
  VVUl7I = pkgRows
  VVUl7I.extend(actnRows)
  VVUl7I.extend(ctrlRows)
  VVUl7I.extend(fileRows)
  VVUl7I.extend(unknRows)
  cDict = {"Control":"", "Action":"0c302636", "Script":"0a28281a", "Resource":"1100385a", "?":"11550000"}
  for ndx, row in enumerate(VVUl7I):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   color = cDict.get(Section, "")
   if color:
    if ValidF: Remarks = "%s%s" % (FF1YQ7("Valid", VVNQoM), " ... " + Remarks if Remarks else "")
    VVUl7I[ndx] = (lineNdx, "#b#%s#" % color + Section, Title, Value, Size, "#b#0a0b0b1b#" + Remarks, ValidF)
  if self.projTable:
   self.projTable.VVDqeT(VVUl7I, tableRefreshCB=BF(self.VVznKc, jmpDict) if jmpDict else None, isSort=False)
  else:
   bg = "#15000000"
   title = "%s : %s" % (self.projTitle, self.projName)
   VVq5Be = (""     , self.VVZ7Kw   , [])
   menuButtonFnc = (""     , self.VVoHFg   , [])
   VVcNot = ("Create Package"  , self.VVWryW , [])
   VVW1zM = ("Post Install Action", self.VVpxDe, [])
   VVM4el = ("Edit File"   , self.VVmxNT  , [])
   header  = ("lineNdx", "Section" , "Title" , "Value / Path", "Size", "Remarks" , "ValidF")
   widths  = (0  , 9   , 11  , 48   , 10 , 22  , 0   )
   VVwZxf = (CENTER , CENTER , LEFT  , LEFT   , CENTER, LEFT  , CENTER )
   self.projTable = FF69ky(self, None, title=title, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, width=1850, height=1040, VVvi36=26, VVq5Be=VVq5Be, menuButtonFnc=menuButtonFnc, VVcNot=VVcNot, VVW1zM=VVW1zM, VVM4el=VVM4el, searchCol=2
         , VVrcFy=bg, VVZZ3c=bg, VVRr4z=bg, VVLwCQ="#00664411", VVhvzQ="#00444444", VVEjwd="#08442211")
   self.projTable.VVxHVQ(self.VVsS6y, True)
 def VVznKc(self, jmpDict, VVkINB, title, txt, colList):
  self.projTable.VVfOKC(jmpDict)
 def VVsS6y(self):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = self.projTable.VVw0xB()
  if Section == "Control":
   txt = '"control" File'
  elif Section == "Script" :
   txt = "Script File"
   if Value.startswith("/") and fileExists(Value):
    txt = "Script File"
   else:
    self.projTable["keyBlue"].hide()
    return
  else:
   txt = "Project File"
  self.projTable["keyBlue"].show()
  self.projTable["keyBlue"].setText("Edit %s" % txt)
 def VVJ1P3(self, line):
  def VVGlot(patt, val, Len):
   if len(val) < Len   : return FF1YQ7("Length error" , VVf8NN)
   elif not iMatch(patt, val) : return FF1YQ7("Invalid format" , VVf8NN)
   else      : return ""
  subj, _, val = line.partition(":")
  val, rem = val.strip(), ""
  if   not self.projPkg  and subj == "Package"  : self.projPkg, rem = val, VVGlot(r"^[a-z]+[a-z0-9+-_.]+$", val, 2)
  elif not self.projVer  and subj == "Version"  : self.projVer, rem = val, VVGlot(r"^[a-zA-Z0-9_+-.~]*$" , val, 1)
  elif not self.projArch and subj == "Architecture": self.projArch = val
  return subj, val, rem
 def VVdep9(self, path, fileRows):
  rem = note = validF = targetType = ""
  size = "-"
  isCtrl = False
  fName = os.path.basename(path)
  typ = FFiyww(path)
  path = FFTgmt(path)
  c = VVf8NN
  if   typ == "Mount" : rem = FF1YQ7("Not allowed", c)
  elif not typ  : rem = FF1YQ7("Not found", c)
  else:
   for item in fileRows:
    if item[3].strip() == path:
     rem = FF1YQ7("Duplicate", c)
     break
   else:
    sz = -1
    skipSz = False
    if typ == "Directory":
     sz = FFN3lb(path)
    elif typ == "SymLink":
     targetPath = os.path.realpath(path)
     targetType = FFiyww(targetPath)
     if  targetType == "Mount"  : skipSz, rem = True, FF1YQ7("Not allowed", c)
     elif targetType == "Directory" : sz = FFN3lb(targetPath)
     elif targetType == "File"  : sz = FF1fFq(targetPath)
     else       : sz, rem = FF1fFq(path), FF1YQ7("Invalid", c)
     note = "%s%s%s" % (note, " ... " if note else "", "Linked to : %s" % targetPath)
    elif typ == "File":
     sz = FF1fFq(path)
    if not skipSz:
     if sz > -1:
      validF = "" if rem else "1"
      if validF:
       if "Directory" in (typ, targetType) : self.projTotalDirs  += 1
       if "File" in (typ, targetType)  : self.projTotalFiles += 1
       self.projFilesSize += sz
      size = CCyssW.VV1ctA(sz, mode=4)
     else:
      size = FF1YQ7("Size error", c)
    rem = "%s%s%s" % (rem, " ... " if rem else "", note)
  return path, fName, typ, size, rem, validF
 def VVJsZB(self, line):
  Title = val = ""
  actDict = {"restart":1, "reboot":2 }
  span = iSearch(r"postinst\s*=\s*(.+)", line, IGNORECASE)
  if span:
   act = span.group(1).lower()
   self.projAct_postInst = actDict.get(act, 0)
   Title, val = "postinst", "%s after the package is installed" % act.capitalize()
  else:
   span = iSearch(r"postrm\s*=\s*(.+)", line, IGNORECASE)
   if span:
    act = span.group(1).lower()
    self.projAct_postRm = actDict.get(act, 0)
    Title, val = "postrm", "%s after the package is removed" % act.capitalize()
  return Title, val
 def VVmxNT(self, VVkINB, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  if   Section == "Control": path, lineNdx = self.projFile_control, int(lineNdx)
  elif Section == "Script" : path, lineNdx = Value, 0
  else      : path, lineNdx = self.projFile, int(lineNdx)
  if fileExists(path) : CC0TyL(self, path, VVJ8mq=self.VV5wLY, curRowNum=lineNdx)
  else    : FFcMQr(self, path)
 def VV5wLY(self, fileChanged):
  if fileChanged:
   self.VVdDsn()
 def VVMXkF(self, txt):
  FFG2mq(self, txt, title=self.projTitle)
 def VVZ7Kw(self, VVkINB, title, txt, colList):
  tab = lambda x, y: "%s\t: %s\n" % (x, y)
  c = VVyz0j
  s  = FFCQJ8("Current Row", c)
  s += title + "\n"
  s += txt + "\n"
  s += FFCQJ8("Project", c)
  s += tab("File Name", self.projFile)
  s += tab("Valid Dirs", self.projTotalDirs)
  s += tab("Valid Files", self.projTotalFiles)
  s += tab("Total Size", CCyssW.VV1ctA(self.projFilesSize))
  FF8ShK(self, s, title="Project Info", width=1600)
 def VVoHFg(self, VVkINB, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  c1, c2, c3 = VVo8aK, VVifMr, VVyz0j
  VVgktg = []
  VVgktg.append((c1 + "Add Resource File"  , "addFile" ))
  VVgktg.append((c1 + "Add Resource Directory" , "addDir" ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Change Package Name"   , "pkgNam" ))
  VVgktg.append(VVm7kE)
  VVgktg.append((c2 + "Add Dependency"   , "addDep" ))
  VVgktg.append((c2 + "Remove Dependency"  , "delDep" ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Import Control File (control/preinst/prerm/postinst/postrm)", "ctrlFMan"))
  VVgktg.append(VVm7kE)
  VVgktg.append((c3 + 'Import Control Data from an Installed Package' , "ctrlImprt" ))
  VVgktg.append(FFVKGp('Undo Last "control" File Changes'   , "ctrlUndo" , fileExists(self.projFile_control + ".bak"), c3))
  VVgktg.append(VVm7kE)
  VVgktg.append(FFVKGp("Delete Current Row (from Project File)" , "delRow"  , Section not in ("Control", "Script")   , VVf8NN))
  FFBqvZ(self, self.VVWY2F, VVgktg=VVgktg, width=1050, title="Options", VVrcFy="#11001122", VVZZ3c="#11001122")
 def VVWY2F(self, item=None):
  if item:
   if   item == "addFile" : self.VVi0Q1(False)
   elif item == "addDir" : self.VVi0Q1(True)
   elif item == "pkgNam" : self.VVIk0O()
   elif item == "addDep" : FFkWFV(self.projTable, self.VVKrQT)
   elif item == "delDep" : self.VVPLGq()
   elif item == "ctrlFMan" : self.VVVoWv()
   elif item == "ctrlImprt": FFkWFV(self.projTable, self.VVnkZG)
   elif item == "ctrlUndo" : self.VVD6tM()
   elif item == "delRow" : self.VVwfxH()
 def VVi0Q1(self, isDir):
  Dir = FFMiJ8(CFG.lastPkgProjDir.getValue(), False)
  if isDir: self.session.openWithCallback(self.VVdY6l, BF(CCyssW, mode=CCyssW.VVaEvY, VV9Esa=Dir))
  else : self.session.openWithCallback(self.VVdY6l, BF(CCyssW, patternMode="all", VV9Esa=Dir))
 def VVdY6l(self, path):
  if path:
   FFeLB8(CFG.lastPkgProjDir, path)
   self.VVLIEr(path, 2)
 def VVVoWv(self):
  Dir = FFMiJ8(CFG.lastPkgProjDir.getValue(), False)
  self.session.openWithCallback(self.VVomQZ, BF(CCyssW, patternMode="pkgCtrl", VV9Esa=Dir))
 def VVomQZ(self, path):
  if path:
   FFeLB8(CFG.lastPkgProjDir, path)
   fName = os.path.basename(path)
   if FFLgW2("cp -f '%s' '%s'" % (path, self.projPath + fName)):
    self.VVdDsn()
    self.projTable.VVfOKC({1:"Script", 2:fName})
 def VVnkZG(self):
  cmd = FFnyVC(VVnFKX, "")
  if not cmd:
   FFEPUu(self)
   return
  lst = FFa467(cmd)
  if lst:
   err = CCyssW.VVqYVb(lst, fromFind=False)
   if err:
    self.VVMXkF(err)
    return
   lst.sort()
   VVUl7I = []
   for item in lst:
    span = iSearch(r"(.+) - (.+)", item)
    if span:
     VVUl7I.append(("", span.group(1), span.group(2)))
   if VVUl7I:
    VVkY0R = ("Import 'control' data", self.VVG4QW, [])
    VVW1zM = ("Package Info.", self.VVLAy6     , [])
    header = ("dum", "Package" , "Version" )
    widths = (0 , 70  , 30  )
    FF69ky(self, None, header=header, VV9gTz=VVUl7I, VVYiuZ=widths, VVvi36=30, VVkY0R=VVkY0R, VVW1zM=VVW1zM, VVyWTx=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
      , VVrcFy="#22110011", VVZZ3c="#22191111", VVRr4z="#22191111", VVLwCQ="#00003030", VVhvzQ="#00333333")
   else:
    self.VVMXkF("Cannot process installed packages !")
  else:
   self.VVMXkF("Cannot read installed packages !")
 def VVD6tM(self):
  if FFLgW2("mv -f '%s' '%s'" % (self.projFile_control + ".bak", self.projFile_control)):
   self.VVdDsn(jmpDict={1:"Control", 2:"Package"})
  else:
   self.VVMXkF("Process Failed !")
 def VVG4QW(self, VVkINB, title, txt, colList):
  FFkWFV(VVkINB, BF(self.VVEBcd, VVkINB, colList[1]))
 def VVEBcd(self, VVkINB, pkg):
  lines = []
  for line in FFa467(FFjDaF(VVDKlz, pkg)):
   span = iSearch(r"^([A-Z].+):\s*.+", line)
   if span and span.group(1) in ("Package", "Version", "Depends", "Section", "Architecture", "Maintainer", "Source", "Description"):
    lines.append(line)
  if lines: FFDiGG(self, BF(self.VVDRed, VVkINB, lines), "Replace current fields ?", title="Import Control Fields")
  else : self.VVMXkF("Cannot import from this package:\n\n%s" % pkg)
 def VVDRed(self, VVkINB, lines):
  VVkINB.cancel()
  FFn35Z(self.projFile_control)
  with open(self.projFile_control, "w") as f:
   for line in lines:
    f.write(line.strip()+ "\n")
  self.VVdDsn(jmpDict={1:"Control", 2:"Package"})
 def VVwfxH(self):
  lineNum = int(self.projTable.VVw0xB()[0]) + 1
  FFLgW2("sed -i.bak -e '%dd' '%s'" % (lineNum, self.projFile))
  self.VVdDsn()
 def VVLIEr(self, line, jmp):
  if fileExists(self.projFile):
   FFn35Z(self.projFile)
   FFVch7(self.projFile)
   with open(self.projFile, "a") as f:
    f.write("%s\n" % line)
   if   jmp == 1: jmpDict = {1:"Action" , 2:line.split("=")[0]}
   elif jmp == 2: jmpDict = {1:"Resource" , 3:line.strip().rstrip("/")}
   else   : jmpDict = None
   self.VVdDsn(jmpDict=jmpDict)
  else:
   FFcMQr(self, self.projFile, title=self.projTitle)
 def VVpxDe(self, VVkINB, title, txt, colList):
  VVgktg = []
  VVgktg.append(FFVKGp("No-Action after installation" , "instNon", self.projAct_postInst != 0))
  VVgktg.append(FFVKGp("Restart after installation" , "instRes", self.projAct_postInst != 1))
  VVgktg.append(FFVKGp("Reboot after installation"  , "instReb", self.projAct_postInst != 2))
  VVgktg.append(VVm7kE)
  VVgktg.append(FFVKGp("No-Action after removal" , "rmNon", self.projAct_postRm != 0))
  VVgktg.append(FFVKGp("Restart after removal" , "rmRes", self.projAct_postRm != 1))
  VVgktg.append(FFVKGp("Reboot after removal"  , "rmReb", self.projAct_postRm != 2))
  FFBqvZ(self, self.VVe32S, VVgktg=VVgktg, title="Action (after the package is installed/removed)")
 def VVe32S(self, item=None):
  if item:
   if   item == "instNon" : self.VVaNGV("postinst", 0)
   elif item == "instRes" : self.VVaNGV("postinst", 1)
   elif item == "instReb" : self.VVaNGV("postinst", 2)
   elif item == "rmNon" : self.VVaNGV("postrm", 0)
   elif item == "rmRes" : self.VVaNGV("postrm", 1)
   elif item == "rmReb" : self.VVaNGV("postrm", 2)
 def VVaNGV(self, subj, val):
  if fileExists(self.projFile):
   lines = FFjqdo(self.projFile)
   FFn35Z(self.projFile)
  else:
   lines = []
  inFile = False
  with open(self.projFile, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if not iMatch(r"%s\s*=.+" % subj, line, IGNORECASE) : f.write(line + "\n")
    else            : inFile = True
  if val > 0: self.VVLIEr("%s=%s" % (subj, {1:"restart", 2:"reboot"}.get(val, "")), 1)
  elif inFile: self.VVdDsn()
 def VVIk0O(self):
  pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
  VVgktg = []
  VVgktg.append((pkg, pkg))
  VVgktg.append(VVm7kE)
  for s in ("extensions", "systemplugins", "", "skins", "picons", "softcams", "", "drivers", "security", "settings"):
   if s:
    name = "enigma2-plugin-%s-%s" % (s, pkg)
    c = VVyz0j if name == self.projPkg else ""
    VVgktg.append((c + name, name))
   else:
    VVgktg.append(VVm7kE)
  FFBqvZ(self, self.VVeYoo, VVgktg=VVgktg, title="Package Name")
 def VVeYoo(self, item=None):
  if item:
   self.VVoelZ("Package", item)
 def VVKrQT(self):
  lst = set()
  for s in ("d", "o", "i"):
   path = "/var/lib/%spkg/status" % s
   if fileExists(path):
    with open(path, "r") as f:
     for line in f:
      if line.startswith(("Package:", "Depends:", "Recommends:", "Suggests:", "Conflicts:", "Replaces:", "Breaks:", "Provides:")):
       line = line.split(":", 1)[1]
       for dep in line.split(","):
        lst.add(dep.strip())
  if lst:
   VVgktg = []
   for item in lst: VVgktg.append((item, item))
   VVgktg.sort(key=lambda x: x[0].lower())
   VVVYOp = FFBqvZ(self, self.VVl8rq, VVgktg=VVgktg, width=1100, title="Add Dependency")
   if self.projLastDepends:
    VVVYOp.VVfFH1(self.projLastDepends)
  else:
   self.VVMXkF("Cannot read dependencies list !")
 def VVl8rq(self, item=None):
  if item:
   lst = []
   self.projLastDepends = item
   if fileExists(self.projFile_control):
    for line in FFjqdo(self.projFile_control):
     if line.startswith("Depends:"):
      lst = list(map(str.strip, line[8:].split(",")))
      break
   if not item in lst:
    lst.append(item)
    self.VVoelZ("Depends", ", ".join(lst))
   else:
    FFpIgV(self.projTable, "Already added", 1500)
    self.projTable.VVfOKC({1:"Control", 2:"Depends"})
 def VVPLGq(self):
  lst = []
  for row in self.projTable.VV3rlI():
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Title == "Depends":
    lst = list(map(str.strip, Value.split(",")))
    break
  if lst:
   VVgktg = []
   for item in lst: VVgktg.append((item, item))
   FFBqvZ(self, BF(self.VVqGGB, lst), VVgktg=VVgktg, title="Remove Dependency")
  else:
   self.VVMXkF("No dependencies to remove !")
 def VVqGGB(self, lst, item=None):
  if item:
   for ndx, dep in enumerate(lst):
    if dep == item:
     del lst[ndx]
     break
   if lst:
    self.VVoelZ("Depends", ", ".join(lst))
   else:
    FFLgW2("sed -i '/Depends:*/d' '%s'" % self.projFile_control)
    self.VVdDsn()
 def VVoelZ(self, subj, val):
  lines = FFjqdo(self.projFile_control) if fileExists(self.projFile_control) else []
  inFile = False
  with open(self.projFile_control, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if iMatch(r"%s\s*:\s*.+" % subj, line):
     line = "%s: %s" % (subj, val)
     inFile = True
    f.write(line + "\n")
   if not inFile:
    f.write("%s: %s\n" % (subj, val))
  self.VVdDsn(jmpDict={1:"Control", 2:subj})
 def VVWryW(self, VVkINB, title, txt, colList):
  VVgktg = []
  VVgktg.append(("Create .ipk"  , "ipk"))
  VVgktg.append(("Create .deb"  , "deb"))
  VVgktg.append(("Create .tar.gz" , "tar"))
  FFBqvZ(self, self.VVFgbi, VVgktg=VVgktg, width=500, title=self.projTitle)
 def VVFgbi(self, item=None):
  if item:
   FFkWFV(self.projTable, BF(self.VVUfj8, item))
 def VVUfj8(self, item):
  if self.projTotalDirs + self.projTotalFiles == 0:
   self.VVMXkF("No Dirs/Files found !\n\nYou need to add at least 1 directory or 1 file to the project !")
   return
  if   item in ("ipk", "tar") : VVYfey, tarParam, tarExt = False, "-czhf", ".tar.gz"
  elif item == "deb"   : VVYfey, tarParam, tarExt = True , "-cJhf", ".tar.xz"
  if   not self.projPkg : err = "Package"
  elif not self.projVer : err = "Version"
  elif not self.projArch : err = "Architecture"
  else     : err = ""
  if err:
   VVMXkF(self, 'Parameter "%s" not found !' % err)
   return
  if item == "tar": pName, arch, ext = self.projName, "", "tar.gz"
  else   : pName, arch, ext = self.projPkg , self.projArch, item
  pkgFile = "%s%s_%s_%s.%s" % (CFG.packageOutputPath.getValue(), pName, self.projVer, arch, ext)
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  dataTmpPath  = projDir + "DATA/"
  dataFile  = projDir + "data" + tarExt
  removePorjDir = FFhkCt("rm -rf '%s'" % projDir)
  ctrlDir   = "%sCONTROL" % projDir
  controlTarF  = projDir + "control" + tarExt
  controlFile  = "%s/control" % ctrlDir
  debianFile  = projDir + "debian-binary"
  result = "Package:"
  failed= "Process Failed."
  resCmd  = " if [ -f '%s' ]; then "  % pkgFile
  resCmd += "  echo -e '\n%s\n%s' %s;" % (result, pkgFile, FFog5k(result  , VVNQoM))
  resCmd += " else"
  resCmd += "  echo -e '\n%s' %s;"  % (failed, FFog5k(failed, VVYZPJ))
  resCmd += " fi;"
  cmd  = ""
  cmd += FFhkCt("rm -f '%s'" % pkgFile)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % dataTmpPath
  linkLst = []
  ctrlLst = []
  for ndx, row in enumerate(self.projTable.VV3rlI()):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Section == "Control":
    ctrlLst.append("%s: %s" % (Title, Value))
   elif ValidF:
    Dir = os.path.dirname(Value)
    cmd += "mkdir -p '%s%s';"  % (dataTmpPath, Dir)
    cmd += "ln -sf '%s' '%s%s';" % (Value, dataTmpPath, Value)
  if item == "tar":
   cmd += "echo 'Processing Data Files ...';"
   cmd += "tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, pkgFile)
   cmd += resCmd
   cmd += removePorjDir
   FF20zH(self, cmd)
   return
  cmd += "mkdir -p '%s';"  % ctrlDir
  cmd += " echo '2.0' > %s;" % debianFile
  if not FFLgW2(cmd) or not pathExists(ctrlDir):
   VVMXkF(self, "Preparation Failed")
   return
  else:
   with open(controlFile, "w") as f:
    for item in ctrlLst:
     f.write("%s\n" % item)
  fName = ("prerm"     ,"preinst"      ,"postrm"     , "postinst"     )
  srcF  = (self.projFile_preRm  , self.projFile_preInst   , self.projFile_postRm  , self.projFile_postInst  )
  line  = ("Removing package : xx ...", "Installing Package : xx ..." , "Package removed (xx)." , "Installation completed (xx)" )
  act   = (0       , 0        , self.projAct_postRm  , self.projAct_postInst   )
  def VVGlot(act):
   if   act == 1: return "echo 'RESTARTING GUI ...'\nif which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
   elif act == 2: return "echo 'REBOOTING DEVICE ...'\nsleep 3; reboot\n"
   else   : return "echo 'echo 'You may need to Restart GUI.'\n"
  for fName, srcF, line, act in zip(fName, srcF, line, act):
   dstF = os.path.join(ctrlDir, fName)
   if fileExists(srcF):
    FFLgW2("cp -f '%s' '%s'" % (srcF, dstF))
   else:
    with open(dstF, "w") as f:
     f.write("#!/bin/bash\n")
     f.write("echo '%s'\n" % line.replace("xx", self.projPkg))
     f.write(VVGlot(act) if srcF in (self.projFile_postInst, self.projFile_postRm) else "")
     f.write("exit 0\n")
   FFVch7(dstF)
   FFLgW2("chmod 755 '%s'" % dstF)
  cmd  = ""
  cmd += FFNkgD()
  if VVYfey:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FF3zFj("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  cmd += "cd '%s';" % dataTmpPath
  cmd += " echo 'Processing Control Files ...';"
  cmd += " cd '%s';"   % ctrlDir
  cmd += " tar %s '%s' ./*;" % (tarParam, controlTarF)
  cmd += " echo 'Processing Data Files ...';"
  cmd += " tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, dataFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlTarF, "control.tar")
  cmd += checkCmd % (dataFile   , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (pkgFile, debianFile, controlTarF, dataFile)
  cmd += " fi;"
  cmd +=  resCmd
  cmd += "fi;"
  cmd += removePorjDir
  FF20zH(self, cmd)
class CChEm5(Screen, CCQaUY):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFdP4M(VVuQx7, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  CCQaUY.__init__(self)
  c1, c2, c3, c4 = VVo8aK, VVifMr, VVeksK, VVyz0j
  VVgktg = []
  VVgktg.append((c1 + "Plugins Browser"        , "pluginsBrowser"   ))
  VVgktg.append(VVm7kE)
  VVgktg.append((c2 + "Download/Install Packages (from image feeds)", "downloadInstallPackages" ))
  VVgktg.append(VVm7kE)
  VVgktg.append((c3 + "Remove Packages (show all)"     , "VVll9ksAll"  ))
  VVgktg.append((c3 + "Remove Packages (Plugins/SoftCams/Skins)" , "removePluginSkinSoftCAM" ))
  VVgktg.append(VVm7kE)
  VVgktg.append((c2 + "Update Packages List from Feed"    , "VVZh28"  ))
  VVgktg.append((c2 + "Upgradable Packages"       , "VVN9ao" ))
  VVgktg.append(VVm7kE)
  VVgktg.append((c4 + "Package Creator (ipk/deb/tar.gz)"   , "packageCreator"   ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Packaging Tool"         , "VVJHHq"   ))
  VVgktg.append(("Active Feeds"          , "VV3Jo5"   ))
  FFj3mb(self, VVgktg=VVgktg)
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFayJd(self["myMenu"])
  FF08xD(self)
 def VV96hS(self):
  global VVEyaB
  VVEyaB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "pluginsBrowser"    : CCO0s2.VVxNg1(self.session)
   elif item == "downloadInstallPackages"  : FFkWFV(self, BF(self.VVXoLo, 0, ""))
   elif item == "VVll9ksAll"   : FFkWFV(self, BF(self.VVXoLo, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFkWFV(self, BF(self.VVXoLo, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVZh28"   : CChEm5.VVZh28(self)
   elif item == "VVN9ao"  : FFkWFV(self, self.VVN9ao)
   elif item == "packageCreator"    : self.VVy3dA()
   elif item == "VVJHHq"    : self.VVJHHq()
   elif item == "VV3Jo5"    : FFkWFV(self, self.VV3Jo5)
   else          : self.close()
 def VV3Jo5(self):
  files = []
  for s in ("d", "o", "i"):
   files.extend(iGlob("/var/lib/%spkg/lists/*" % s))
  VVUl7I = []
  if files:
   for path in files:
    tot = 0
    with open(path, "r") as f:
     for line in f:
      if line.startswith("Package:"): tot += 1
    VVUl7I.append((os.path.basename(path), str(tot)))
  if VVUl7I:
   VVUl7I.sort(key=lambda x: x[0].lower())
   header  = ("Feed","Packages")
   widths  = (82  , 18  )
   VVwZxf = (LEFT  , CENTER )
   FF69ky(self, None, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, width=1000, VVvi36=26, VVDWdv=2)
  else:
   self.VVMXkF("Cannot read packages list !")
 def VVN9ao(self, VVkINB=None):
  lst = FFa467(FFnyVC(VV9SVb, ""))
  VVUl7I = []
  if lst:
   lst.sort(key=lambda x: x.lower())
   for line in lst:
    pkg = curV = newVer = ""
    span = iSearch(r"(.+) - (.+) - (.+)", line)
    if span:
     pkg, curV, newVer = span.group(1), span.group(2), span.group(3)
    else:
     span = iSearch(r"(.+) (.+) (.+) \[upgradable from: (.+)\]", line)
     if span:
      pkg, newVer, arch, curV = span.group(1), span.group(2), span.group(3), span.group(4)
    if all((pkg, curV, newVer)):
     VVUl7I.append((str(len(VVUl7I) + 1), pkg, curV, newVer))
   if VVUl7I:
    if VVkINB:
     VVkINB.VVDqeT(VVUl7I, VVc63JMsg=True)
    else:
     bg = "#00221111"
     VVkY0R = ("Upgrade", self.VVkakE   , [])
     VVW1zM = ("Package Info.", self.VVLAy6 , [])
     header  = ("Num" ,"Package" ,"Version" , "New Version" )
     widths  = (6  , 42  , 26  , 26   )
     VVwZxf = (CENTER , LEFT  , LEFT  , LEFT   )
     FF69ky(self, None, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, width=1700, VVvi36=26, VVkY0R=VVkY0R, VVW1zM=VVW1zM, VVFwVS=True, VVWtKU=0, searchCol=1, lastFindConfigObj=CFG.lastFindPackages, VVrcFy=bg, VVZZ3c=bg, VVRr4z=bg, VVsykS="#00ffff55", VVLwCQ="#00003040")
  if not VVUl7I:
   FFrKlA(self, "Nothing to upgrade", 1500)
   if VVkINB: VVkINB.cancel()
 def VVkakE(self, VVkINB, title, txt, colList):
  pkg = colList[1]
  cmd = FFjDaF(VVEdih, pkg)
  if cmd : FF20zH(self, cmd, title="Installing : %s" % pkg, VVAJlf=BF(self.VVN9ao, VVkINB))
  else : FFEPUu(SELF)
 def VVJHHq(self):
  pkg = FFyncK()
  aptT = "apt - Advanced Package Tool" if FFGqL5("apt") else ""
  txt = {"ipkg": "Itsy", "opkg": "Open", "dpkg": "Debian"}.get(pkg, "")
  txt = "%s - %s Package Management System" % (pkg, txt) if txt else ""
  txt += "%s%s" % ("\n\nand\n\n" if txt and aptT else "", aptT)
  FF27fq(self, txt or "No packaging tools found!")
 def VVXoLo(self, mode, grep, VVkINB=None, title=""):
  if   mode == 0: cmd = FFnyVC(VVhuD3    , grep)
  elif mode == 1: cmd = FFnyVC(VVnFKX , grep)
  elif mode == 2: cmd = FFnyVC(VVnFKX , grep)
  if not cmd:
   FFEPUu(self)
   return
  VVUl7I = FFa467(cmd)
  if VVUl7I:
   err = CCyssW.VVqYVb(VVUl7I, fromFind=False)
   if err:
    FFG2mq(self, err)
    return
  else:
   if VVkINB: VVkINB.VVTm6g()
   FFG2mq(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VV9gTz  = []
  for item in VVUl7I:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VV9gTz.append((name, package, version))
  if mode > 0:
   extensions = FFa467("ls %s -l | grep '^d' | awk '{print $9}'" % VVuGsg)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VV9gTz:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == VVmIIf: name += "el"
      VV9gTz.append((name, VVuGsg + item, "-"))
   systemPlugins = FFa467("ls %s -l | grep '^d' | awk '{print $9}'" % VVlNeR)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VV9gTz:
      if item.lower() == row[0].lower():
       break
     else:
      VV9gTz.append((item, VVlNeR + item, "-"))
  if not VV9gTz:
   FFG2mq(self, "No packages found!")
   return
  if VVkINB:
   VV9gTz.sort(key=lambda x: x[0].lower())
   VVkINB.VVDqeT(VV9gTz, title)
  else:
   widths = (20, 50, 30)
   VVkY0R = None
   VVM4el = None
   if mode == 0:
    VVcNot = ("Install" , self.VVDFCt   , [])
    VVkY0R = ("Download" , self.VVU9Bw   , [])
    VVM4el = ("Filter"  , self.VVD131 , [])
   elif mode == 1:
    VVcNot = ("Uninstall", self.VVll9k, [])
   elif mode == 2:
    VVcNot = ("Uninstall", self.VVll9k, [])
    widths= (18, 57, 25)
   VV9gTz.sort(key=lambda x: x[0].lower())
   VVW1zM = ("Package Info.", self.VVLAy6, [])
   header   = ("Name" ,"Package" , "Version" )
   FF69ky(self, None, header=header, VV9gTz=VV9gTz, VVYiuZ=widths, VVvi36=28, VVcNot=VVcNot, VVkY0R=VVkY0R, VVW1zM=VVW1zM, VVM4el=VVM4el, VVyWTx=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVrcFy="#22110011", VVZZ3c="#22191111", VVRr4z="#22191111", VVLwCQ="#00003030", VVhvzQ="#00333333")
 def VVLAy6(self, VVkINB, title, txt, colList):
  FFkWFV(VVkINB, BF(self.VVeN8I, VVkINB, colList[1]))
 def VVeN8I(self, VVkINB, pkg):
  if pathExists(pkg):
   pkg, err = CChEm5.VVVozm(pkg)
   if err:
    FFrKlA(VVkINB, err, 1000)
    return
  CChEm5.VVZH5R(self, pkg)
 def VVD131(self, VVkINB, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVgktg = []
  VVgktg.append(("All Packages", "all"))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVgktg.append(VVm7kE)
  for word in words:
   VVgktg.append((word, word))
  FFBqvZ(self, BF(self.VV8Xmq, VVkINB), VVgktg=VVgktg, title="Select Filter")
 def VV8Xmq(self, VVkINB, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFkWFV(VVkINB, BF(self.VVXoLo, 0, grep, VVkINB, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVll9k(self, VVkINB, title, txt, colList):
  FFkWFV(VVkINB, BF(self.VVDbmm, VVkINB, colList[1]))
 def VVDbmm(self, VVkINB, package):
  if pathExists(package):
   pkg, err = CChEm5.VVVozm(package)
   if pkg:
    package = pkg
  if package.startswith((VVuGsg, VVlNeR)):
   FFDiGG(self, BF(self.VVYS1v, VVkINB, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVgktg = []
   VVgktg.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVgktg.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVgktg.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFBqvZ(self, BF(self.VVsk58, VVkINB, package), VVgktg=VVgktg)
 def VVYS1v(self, VVkINB, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -rf '%s' &>/dev/null %s" % (package, VVLVyg)
  FF20zH(self, cmd, VVAJlf=BF(self.VVsj1W, VVkINB))
 def VVsk58(self, VVkINB, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVvpx9
   elif item == "remove_ForceRemove"  : cmdOpt = VVv695
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVlF8r
   FFDiGG(self, BF(self.VVDOD0, VVkINB, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVDOD0(self, VVkINB, package, cmdOpt):
  self.lastSelectedRow = VVkINB.VVnbBC()
  cmd = FFjDaF(cmdOpt, package)
  if cmd : FF20zH(self, cmd, VVAJlf=BF(self.VVsj1W, VVkINB))
  else : FFEPUu(self)
 def VVsj1W(self, VVkINB):
  VVkINB.cancel()
  FFxmPl()
 def VVDFCt(self, VVkINB, title, txt, colList):
  package  = colList[1]
  VVgktg = []
  VVgktg.append(("Install Package"        , "install_CheckVersion" ))
  VVgktg.append(("Install Package (force reinstall)"   , "install_ForceReinstall" ))
  VVgktg.append(("Install Package (force overwrite)"   , "install_ForceOverwrite" ))
  VVgktg.append(("Install Package (force downgrade)"   , "install_ForceDowngrade" ))
  VVgktg.append(("Install Package (ignore failed dependencies)" , "install_IgnoreDepends" ))
  FFBqvZ(self, BF(self.VVdV2x, package), VVgktg=VVgktg)
 def VVdV2x(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVEdih
   elif item == "install_ForceReinstall" : cmdOpt = VVg1cm
   elif item == "install_ForceOverwrite" : cmdOpt = VVEgPl
   elif item == "install_ForceDowngrade" : cmdOpt = VVz2tU
   elif item == "install_IgnoreDepends" : cmdOpt = VVHnoT
   FFDiGG(self, BF(self.VV2R6v, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VV2R6v(self, package, cmdOpt):
  cmd = FFjDaF(cmdOpt, package)
  if cmd : FF20zH(self, cmd, VVAJlf=FFxmPl, checkNetAccess=True)
  else : FFEPUu(self)
 def VVU9Bw(self, VVkINB, title, txt, colList):
  package  = colList[1]
  FFDiGG(self, BF(self.VVCR57, package), "Download Package ?\n\n%s" % package)
 def VVCR57(self, package):
  if CCUSzd.VVd24U():
   cmd = FFjDaF(VVN09a, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFog5k(success, VVNQoM))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFog5k(fail, VVYZPJ))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FF20zH(self, cmd, VVdaxv=[VVYZPJ, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFEPUu(self)
  else:
   FFG2mq(self, "No internet connection !")
 @staticmethod
 def VVZh28(SELF):
  cmd = FFnyVC(VVdsnf, "")
  if cmd : FF20zH(SELF, cmd, checkNetAccess=True, title="Available Packages List Upadate")
  else : FFEPUu(SELF)
 @staticmethod
 def VVVozm(path):
  pkg = err = ""
  if pathExists(path):
   for line in FFa467(FFjDaF(VVV2eV, "*%s*" % path)):
    span = iSearch(r"(.+) - .+", line)
    if span:
     pkg = span.group(1)
     break
    else:
     span = iSearch(r"(.+):+", line)
     if span:
      pkg = span.group(1)
      break
   if not pkg:
    err = "No package info !"
  else:
   err = "Path not found !"
  return pkg, err
 @staticmethod
 def VVZH5R(SELF, package, title=""):
  title = title or package
  infoCmd  = FFjDaF(VVDKlz, package)
  filesCmd = FFjDaF(VVqQqK, package)
  listInstCmd = FFnyVC(VVnFKX, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFMGJW(VVChVP)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFog5k(notInst, VVf8NN))
   cmd += "else "
   cmd +=   FF9KyJ("System Info", VVChVP)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FF9KyJ("Related Files", VVChVP)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFTKzr(SELF, cmd, title=title)
  else:
   FFEPUu(SELF, title=title)
class CCImRc():
 def VVb27z(self, isRef, onlyEpg=False):
  self.shareIsRef   = isRef
  self.onlyEpg   = onlyEpg
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VVL3v7()
 def VVL3v7(self):
  files = FFcJlI(VVrXLj, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVgktg = []
   for fil in files:
    VVgktg.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVrcFy, VVZZ3c = "#22221133", "#22221133"
   else    : VVrcFy, VVZZ3c = "#22003344", "#22002233"
   VVG8PG  = ("Add new File", self.VVo0l6)
   FFBqvZ(self, self.VVg8y3, VVgktg=VVgktg, width=1100, VVG8PG=VVG8PG, VVfXMZ="", minRows=4, VVrcFy=VVrcFy, VVZZ3c=VVZZ3c)
  else:
   FFDiGG(self, self.VVMTF0, "No files found.\n\nCreate a new file ?")
 def VVMTF0(self):
  path = self.VVTQdN()
  if fileExists(path) : self.VVL3v7()
  else    : FFpIgV(self, "Cannot create file", 1500)
 def VVo0l6(self, VVVYOp, path):
  path = self.VVTQdN()
  VVVYOp.VVLDpi((os.path.basename(path), path), isSort=True)
 def VVTQdN(self):
  path = "%s%s%s.xml" % (VVrXLj, self.shareFilePrefix, FF4Fnb())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VVg8y3(self, path=None):
  if path:
   FFkWFV(self, BF(self.VVawZo, path))
 def VVawZo(self, path):
  if not fileExists(path):
   FFcMQr(self, path)
   return
  elif not CCyssW.VVfwhn(self, path, FFMV8t()):
   return
  else:
   self.shareFilePath = path
  if not CCMhuj.VVQg4l(self):
   return
  tree = CCmfL4.VVmm3j(self, self.shareFilePath)
  if not tree:
   return
  refLst = CCMyrC.VVbsTQ()
  def VVy4Ld(refCode):
   if   FFDQBg(refCode): return FF1YQ7("DVB", VVo8aK)
   elif refCode in refLst     : return FF1YQ7("IPTV", VVo8aK)
   else         : return ""
  VVUl7I= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VVewib(ch)
   if ok:
    srcTxt = VVy4Ld(srcRef)
    dstTxt = VVy4Ld(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VVUl7I:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VVUl7I.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VVUl7I:
   if self.shareIsRef : VVrcFy, VVZZ3c, optTxt = "#1a221133", "#1a221133", "Share Reference"
   else    : VVrcFy, VVZZ3c, optTxt = "#1a003344", "#1a002233", "Copy EPG" if self.onlyEpg else "Copy EPG/PIcons"
   VVgDd7 = (""    , BF(self.VVQ1vk, dupl), [])
   VVq5Be = (""    , self.VV5yxW    , [])
   VVcNot = ("Delete Entry" , self.VVadky   , [])
   VVkY0R = ("Add Entry"  , self.VVWFy2   , [])
   VVW1zM = (optTxt   , self.VVXiJs  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VVwZxf = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVkINB = FF69ky(self, None, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=24, VVgDd7=VVgDd7, VVq5Be=VVq5Be, VVcNot=VVcNot, VVkY0R=VVkY0R, VVW1zM=VVW1zM, VVFwVS=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVrcFy=VVrcFy, VVZZ3c=VVZZ3c, VVRr4z=VVZZ3c, VVLwCQ="#0a000000")
  else:
   FFG2mq(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VVQ1vk(self, dupl, VVkINB, title, txt, colList):
  if dupl:
   VVkINB.VVpB4f("Skipped %d duplicate%s" % (dupl, FFLFel(dupl)), 2000)
 def VV5yxW(self, VVkINB, title, txt, colList):
  def VVy4Ld(key, val): return "%s\t: %s\n" % (key, val or FF1YQ7("?", VVWgbP))
  Keys = VVkINB.VV5aE2()
  Vals = VVkINB.VVw0xB()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VVy4Ld(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VVNQoM, VVWgbP
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FF8ShK(self, txt + txt1, title=title)
 def VVewib(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VVadky(self, VVkINB, title, txt, colList):
  if VVkINB.VVnbBC() == 0 and VVkINB.VVKW2u() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FFDiGG(self, BF(self.VVBpNF, isLast, VVkINB), ques)
 def VVBpNF(self, isLast, VVkINB):
  if isLast:
   FFMc8G(self.shareFilePath)
   VVkINB.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVkINB.VVw0xB()
   if self.VVVyP3(srcName, srcRef, dstName, dstRef):
    VVkINB.VVPu0N()
    VVkINB.VV71sD()
    FFpIgV(VVkINB, "Deleted", 500, isGrn=True)
   else:
    FFpIgV(VVkINB, "Cannot delete from file", 2000)
 def VVWFy2(self, VVkINB, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VVUsUp(VVkINB, isDvb=True)
  else    : self.VVq9JB(VVkINB, "Source Channel", "#22003344", "#22002233")
 def VVq9JB(self, mainTableInst, title, VVrcFy, VVZZ3c):
  FFBqvZ(self, BF(self.VVdmcK, mainTableInst, title), VVgktg=[("DVB", "DVB"), ("IPTV / Stream Relay", "IPTV")], title=title + " Type", width=800, VVrcFy=VVrcFy, VVZZ3c=VVZZ3c)
 def VVdmcK(self, mainTableInst, title, item=None):
  if item:
   FFkWFV(mainTableInst, BF(self.VVaTGN, mainTableInst, title, item), clearMsg=False)
 def VVaTGN(self, mainTableInst, title, item):
  FFpIgV(mainTableInst)
  if item == "DVB": self.VVUsUp(mainTableInst, isDvb=True)
  else   : self.VVUsUp(mainTableInst, isDvb=False)
 def VVf2Dj(self, mainTableInst, chType, VVkINB, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVkINB.VVnbBC()
  if   chType == "DVB" : FFeLB8(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FFeLB8(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VV3rlI()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FFG2mq(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VV8Pej(srcName, srcRef, dstName, dstRef):
      mainTableInst.VVVxYM((str(mainTableInst.VVKW2u() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FFpIgV(mainTableInst, "Added", 500, isGrn=True)
     else:
      FFpIgV(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FFpIgV(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VVUsUp(mainTableInst, isDvb=False)
   else    : FFLYGh(BF(self.VVq9JB, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVkINB.cancel()
 def VVAXx7(self, item, VVkINB, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVkINB.VV2NBO(ndx)
 def VVUsUp(self, VVkINB, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VVf2Dj, VVkINB, typ)
  doneFnc = BF(self.VVAXx7, typ)
  if isDvb: CCImRc.VV76IE(VVkINB , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CCImRc.VVJxfu(VVkINB, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VV76IE(SELF, title, okFnc, doneFnc=None):
  FFkWFV(SELF, BF(CCImRc.VVqmmU, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VVqmmU(SELF, title, okFnc, doneFnc=None):
  VVUl7I, err = CCmfL4.VVwWVD(SELF, CCmfL4.VVSMx3)
  if VVUl7I:
   color = "#0a000022"
   VVUl7I.sort(key=lambda x: x[0].lower())
   VVp0o5 = ("Select" , okFnc, [])
   VVgDd7= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VVwZxf = (LEFT  , LEFT  , CENTER, LEFT    )
   FF69ky(SELF, None, title=title, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=26, VVrcFy=color, VVZZ3c=color, VVRr4z=color, VVp0o5=VVp0o5, VVgDd7=VVgDd7, lastFindConfigObj=CFG.lastFindServices)
  else:
   FFG2mq(SELF, "No DVB Services !")
 @staticmethod
 def VVJxfu(SELF, title, okFnc, doneFnc=None):
  FFkWFV(SELF, BF(CCImRc.VV46YW, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VV46YW(SELF, title, okFnc, doneFnc=None):
  VVUl7I = CCImRc.VVKTuc()
  if VVUl7I:
   color = "#0a112211"
   VVUl7I.sort(key=lambda x: x[0].lower())
   VVp0o5 = ("Select" , okFnc, [])
   VVgDd7= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FF69ky(SELF, None, title=title, header=header, VV9gTz=VVUl7I, VVYiuZ=widths, VVvi36=26, VVrcFy=color, VVZZ3c=color, VVRr4z=color, VVp0o5=VVp0o5, VVgDd7=VVgDd7, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFG2mq(SELF, "No IPTV Services !")
 @staticmethod
 def VVKTuc():
  VVUl7I = []
  files  = CCul6W.VVMJXK()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFSIRe(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVwjmO = span.group(1)
    else : VVwjmO = ""
    VVwjmO_lCase = VVwjmO.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VVUl7I.append((chName, VVwjmO, url, refCode))
  return VVUl7I
 def VV8Pej(self, srcName, srcRef, dstName, dstRef):
  tree = CCmfL4.VVmm3j(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VVFtPZ(tree, root)
  return True
 def VVVyP3(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CCmfL4.VVmm3j(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VVewib(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VVFtPZ(tree, root)
  return found
 def VVFtPZ(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CCmfL4.VVUe5u(xmlTxt)
  parser = CCmfL4.CCVy1X()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VVXiJs(self, VVkINB, title, txt, colList):
  if self.onlyEpg:
   self.VVRxpv(VVkINB, "epg")
  else:
   if self.shareIsRef:
    FFDiGG(self, BF(FFkWFV, VVkINB, BF(self.VVFKYT, VVkINB)), "Copy all References from Source to Destination ?")
   else:
    VVgktg = []
    VVgktg.append(("Copy EPG\t (All List)" , "epg"  ))
    VVgktg.append(("Copy Picons\t (All List)" , "picon" ))
    FFBqvZ(self, BF(self.VVRxpv, VVkINB), VVgktg=VVgktg, width=1000)
 def VVRxpv(self, VVkINB, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VVMRMk  , "EPG"
   elif item == "picon": fnc, txt = self.VVwkLg , "PIcons"
   title = "Copy %s" % txt
   tot   = VVkINB.VVKW2u()
   FFDiGG(self, BF(FFkWFV, VVkINB, BF(fnc, VVkINB, title)), "Overwrite %s for %d Service%s ?" % (FF1YQ7(txt, VVChVP), tot, FFLFel(tot)), title=title)
 def VVFKYT(self, VVkINB):
  files = CCul6W.VVMJXK()
  totChange = 0
  if files:
   for path in files:
    txt = FFSIRe(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVkINB.VV3rlI():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFHpDz()
  tot = VVkINB.VVKW2u()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FF8ShK(self, txt)
 def VVwkLg(self, VVkINB, title):
  if not iCopyfile:
   FFG2mq(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CCQVwA.VVzkHI()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVkINB.VV3rlI():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVkINB.VVKW2u()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FF8ShK(self, txt, title=title)
 def VVMRMk(self, VVkINB, title):
  txt, err = CCjxcj.VV9Mui(VVkINB, title)
  if err : FFG2mq(self, err, title=title)
  else : FF8ShK(self, txt, title=title)
 class CCVy1X(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VVmm3j(SELF, path, withComments=True, title=""):
  try:
   if withComments : parser = iElem.XMLParser(target=CCmfL4.CCVy1X())
   else   : parser = None
   return iElem.parse(path, parser=parser)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FF1YQ7("XML Parse Error in:", VVWgbP), path)
   txt += "%s\n%s\n\n" % (FF1YQ7("Error:", VVWgbP), str(e))
   FF8ShK(SELF, txt, VVRr4z="#11220000", title=title)
   return None
 @staticmethod
 def VVUe5u(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
class CCjxcj(Screen, CCImRc):
 VV9IYB  = "BDTSE"
 VV6ZMT   = "save"
 VVMA1T   = "load"
 VVl94D  = "flushEPG"
 def __init__(self, session):
  self.skin, self.skinParam = FFdP4M(VVuQx7, 950, 800, 50, 40, 30, "#22110011", "#22110022", 30)
  self.session  = session
  valid, path, sz, szTxt = CCjxcj.VV5AoT()
  qUrl, iptvRef = CCul6W.VV9TTr(self)
  VVgktg = []
  VVgktg.append((VVo8aK + "Cache File Info." , "inf"))
  VVgktg.append(VVm7kE)
  fTxt = " (%s)" % os.path.basename(path) if valid else ""
  VVgktg.append(FFVKGp("Save EPG to File%s" % fTxt , self.VV6ZMT, valid))
  VVgktg.append(FFVKGp("Load EPG from File%s" % fTxt , self.VVMA1T, valid))
  VVgktg.append(VVm7kE)
  VVgktg.append((VVf8NN + "Delete EPG (from RAM only)", self.VVl94D))
  VVgktg.append(VVm7kE)
  VVgktg.append(FFVKGp("Update Current Bouquet EPG (from IPTV Server)", "refreshIptvEPG", qUrl or "chCode" in iptvRef))
  VVgktg.append(("Copy EPG between Channels (from xml file)", "copyEpg" ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Translate Current Channel EPG %s(Experimental)" % VVf8NN, "VVfikf"))
  FFj3mb(self, VVgktg=VVgktg)
  self.onShown.append(self.VVgr8g)
 def VV96hS(self):
  global VVEyaB
  VVEyaB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "inf"    : self.VVvnny()
   elif item in (self.VV6ZMT, self.VVMA1T, self.VVl94D):
    reset = item == self.VVMA1T
    FFDiGG(self, BF(FFkWFV, self, BF(self.VVGR0d, item, reset)), VVDdTB="Continue ?")
   elif item == "refreshIptvEPG"  : CCul6W.VVLeg8(self)
   elif item == "VVfikf" : self.VVfikf()
   elif item == "copyEpg"    : self.VVb27z(False, onlyEpg=True)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFayJd(self["myMenu"])
  FF08xD(self)
 def VVGR0d(self, act, reset=False):
  ok = CCjxcj.VVCFoV(act)
  if ok:
   if reset:
    CCjxcj.VVhbCI(self)
   FF27fq(self, "Done")
  else:
   FF27fq(self, "Failed!")
 def VVvnny(self):
  title = "EPG Cache File"
  valid, path, sz, szTxt = CCjxcj.VV5AoT()
  if path:
   if valid: txt = "File Path\t: %s\n\nFile Size\t: %s\n" % (path, szTxt or "?")
   else : txt = "System Settings: %s\n\n%s" % (path, FF1YQ7("File not found (check System EPG settings).", VVf8NN))
   FF8ShK(self, txt, title=title)
  else:
   FFG2mq(self, "Cannot read Path Settings !", title=title)
 @staticmethod
 def VVKWeq():
  return [("", "Disable"),("af","Afrikaans"),("sq","Albanian"),("am","Amharic"),("ar","Arabic"),("hy","Armenian"),("as","Assamese"),("ay","Aymara"),("az","Azerbaijani"),("bm","Bambara"),("eu","Basque"),("be","Belarusian"),("bn","Bengali"),("bho","Bhojpuri"),("bs","Bosnian"),("bg","Bulgarian"),("ca","Catalan"),("ceb","Cebuano"),("ny","Chichewa"),("zh-CN","Chinese (Simplified)"),("zh-TW","Chinese (Traditional)"),("co","Corsican"),("hr","Croatian"),("cs","Czech"),("da","Danish"),("dv","Dhivehi"),("doi","Dogri"),("nl","Dutch"),("en","English"),("eo","Esperanto"),("et","Estonian"),("ee","Ewe"),("tl","Filipino"),("fi","Finnish"),("fr","French"),("fy","Frisian"),("gl","Galician"),("ka","Georgian"),("de","German"),("el","Greek"),("gn","Guarani"),("gu","Gujarati"),("ht","Haitian Creole"),("ha","Hausa"),("haw","Hawaiian"),("iw","Hebrew"),("hi","Hindi"),("hmn","Hmong"),("hu","Hungarian"),("is","Icelandic"),("ig","Igbo"),("ilo","Ilocano"),("id","Indonesian"),("ga","Irish"),("it","Italian"),("ja","Japanese"),("jw","Javanese"),("kn","Kannada"),("kk","Kazakh"),("km","Khmer"),("rw","Kinyarwanda"),("gom","Konkani"),("ko","Korean"),("kri","Krio"),("ku","Kurdish (Kurmanji)"),("ckb","Kurdish (Sorani)"),("ky","Kyrgyz"),("lo","Lao"),("la","Latin"),("lv","Latvian"),("ln","Lingala"),("lt","Lithuanian"),("lg","Luganda"),("lb","Luxembourgish"),("mk","Macedonian"),("mai","Maithili"),("mg","Malagasy"),("ms","Malay"),("ml","Malayalam"),("mt","Maltese"),("mi","Maori"),("mr","Marathi"),("mni-Mtei","Meiteilon (Manipuri)"),("lus","Mizo"),("mn","Mongolian"),("my","Myanmar (Burmese)"),("ne","Nepali"),("no","Norwegian"),("or","Odia (Oriya)"),("om","Oromo"),("ps","Pashto"),("fa","Persian"),("pl","Polish"),("pt","Portuguese"),("pa","Punjabi"),("qu","Quechua"),("ro","Romanian"),("ru","Russian"),("sm","Samoan"),("sa","Sanskrit"),("gd","Scots Gaelic"),("nso","Sepedi"),("sr","Serbian"),("st","Sesotho"),("sn","Shona"),("sd","Sindhi"),("si","Sinhala"),("sk","Slovak"),("sl","Slovenian"),("so","Somali"),("es","Spanish"),("su","Sundanese"),("sw","Swahili"),("sv","Swedish"),("tg","Tajik"),("ta","Tamil"),("tt","Tatar"),("te","Telugu"),("th","Thai"),("ti","Tigrinya"),("ts","Tsonga"),("tr","Turkish"),("tk","Turkmen"),("ak","Twi"),("uk","Ukrainian"),("ur","Urdu"),("ug","Uyghur"),("uz","Uzbek"),("vi","Vietnamese"),("cy","Welsh"),("xh","Xhosa"),("yi","Yiddish"),("yo","Yoruba"),("zu","Zulu")]
 def VVfikf(self):
  title = "Translate Current Channel EPG"
  bg = "#11101010"
  VVp0o5  = (""  , BF(self.VVQg8b, title, True) , [])
  VVkY0R = ("Start" , BF(self.VVQg8b, title, False), [])
  VVM4el = ("Change Language", self.VVN2Hz      , [])
  widths  = (70 , 30)
  VVwZxf = (LEFT , CENTER)
  FF69ky(self, None, title=title, VV9gTz=self.VVojvW(), VVwZxf=VVwZxf, VVYiuZ=widths, width=1200, vMargin=20, VVvi36=30, VVp0o5=VVp0o5, VVkY0R=VVkY0R, VVM4el=VVM4el, VVDWdv=2
    , VVrcFy="#11201010", VVZZ3c=bg, VVRr4z=bg, VVLwCQ="#00004455", VVhvzQ=bg)
 def VVojvW(self):
  Def, ch = "DISABLED", dict(CCjxcj.VVKWeq())
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  VV9gTz = [("Event Name Language", ch.get(tVal, Def)), ("Description Language", ch.get(dVal, Def))]
  return VV9gTz
 def VVN2Hz(self, VVkINB, title, txt, colList):
  ndx = VVkINB.VVnbBC()
  title = colList[0]
  confItem = CFG.epgLangTitle if ndx == 0 else CFG.epgLangDescr
  CCmbpf.VVhrFb(self, confItem, title, lst=CCjxcj.VVKWeq(), cbFnc=BF(self.VVTSII, VVkINB), isSave=True)
 def VVTSII(self, VVkINB):
  for ndx, row in enumerate(self.VVojvW()):
   VVkINB.VVp9X7(ndx, row)
 def VVQg8b(self, Title, isAsk, VVkINB, title, txt, colList):
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  if not (tVal or dVal):
   FFpIgV(VVkINB, "Change Language", 700)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
   refCode, evList, err = CCjxcj.VVRBqP(refCode)
   fnc = BF(self.VVFvC5, Title, refCode, evList, VVkINB)
   if   err : FFG2mq(self, err, title=Title)
   elif isAsk : FFDiGG(self, fnc, "Start ?", title=Title)
   else  : fnc()
 def VVFvC5(self, title, refCode, evList, VVkINB):
  self.session.open(CCKX0k, barTheme=CCKX0k.VVzy8h, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVUJRR, evList)
      , VVJ8mq = BF(self.VVBOHG, title, refCode))
  VVkINB.cancel()
 def VVUJRR(self, evList, VVzRAM):
  totEv = len(evList)
  newLst = []
  totErrName = totErrShort = totErrLong = totSkip = 0
  VVzRAM.VVGeXq(totEv)
  VVzRAM.VVgo83 = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
  lang = CFG.epgLangDescr.getValue()
  for ev in evList:
   trName, trShort, trLong, errName, errShort, errLong = CCjxcj.VVulMW(*ev[2:5])
   totErrName  += errName
   totErrShort += errShort
   totErrLong  += errLong
   if not VVzRAM or VVzRAM.isCancelled:
    return
   VVzRAM.VVu4eE(1)
   VVzRAM.VVAaZR(len(newLst), ev[2] if len(ev[2]) < 22 else ev[2][:22] + " ...")
   name1, short1, long1 = ev[2:5]
   if (name1, short1, long1) != (trName, trShort, trLong):
    item = list(ev)
    item[2], item[3], item[4] = trName, trShort, trLong
    item.append(1)
    newLst.append(tuple(item))
   else:
    totSkip += 1
   VVzRAM.VVgo83 = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
 def VVBOHG(self, title, refCode, VV4mF1, VVgo83, threadCounter, threadTotal, threadErr):
  newLst, totEv, totErrName, totErrShort, totErrLong, totSkip = VVgo83
  if newLst: totEv, totOK = CCjxcj.VVrq0M(refCode, newLst)
  else  : totOK = 0
  if totOK:
   CCjxcj.VVn2mE()
   CCjxcj.VVhbCI(self)
  txt  = "Events\t: %d\n"  % totEv
  txt += "Processed\t: %d\n" % len(newLst)
  txt += "Changed\t: %d\n" % totOK
  if totSkip : txt += "Skipped\t: %d \t... Same language\n" % totSkip
  if any((totErrName, totErrShort, totErrLong)):
   txt += "\nErrors:\n"
   if totErrName : txt += "  Event Name\t: %d\n" % totErrName
   if totErrShort: txt += "  Description\t: %d\n" % totErrShort
   if totErrLong : txt += "  Description\t: %d\n" % totErrLong
  FF8ShK(self, txt, title=title)
 @staticmethod
 def VVulMW(eName, eShort, eLong):
  eName, eShort, eLong = eName.strip(), eShort.strip(), eLong.strip()
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  lang, lst, resLst, errLst = (tVal, dVal, dVal), (eName, eShort, eLong), ["", "", ""], [0, 0, 0]
  def VVy4Ld(ndx):
   if lst[ndx] and lang[ndx]:
    txt, err = CCjxcj.VVU1IA(lst[ndx], lang[ndx])
    resLst[ndx], errLst[ndx] = txt, 1 if err else 0
  thLst = []
  for ndx in range(3):
   th = iThread(name="ajp_%d" % ndx, target=BF(VVy4Ld, ndx))
   th.start()
   thLst.append(th)
  for th in thLst: th.join()
  trName, trShort, trLong = resLst[0] or eName, resLst[1] or eShort, resLst[2] or eLong
  errName, errShort, errLong = errLst
  return trName, trShort, trLong, errName, errShort, errLong
 @staticmethod
 def VVU1IA(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "%s%s&q=%s" % ("=lt&otua=ls&?m/moc.elgoog.etalsnart//:sptth"[::-1], toLang, FFP4cn(txt))
   txt, err = CCul6W.VVbwRu(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFyEM8(txt)
    ndx  = txt.find('<div class="result-container">')
    if ndx > -1:
     txt = txt[ndx + 30:]
     ndx  = txt.find("</div>")
     if ndx > -1:
      return str(CCjxcj.VVJSXz(txt[:ndx])).strip(), ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VV5AoT():
  path = szTxt = ""
  valid = sz = 0
  try: path = config.misc.epgcache_filename.getValue()
  except: pass
  if fileExists(path):
   valid = 1
   sz = FF1fFq(path)
   szTxt = CCyssW.VV1ctA(sz) if sz > -1 else ""
  return valid, path, sz, szTxt
 @staticmethod
 def VVViEf():
  try:
   from enigma import eEPGCache
   return eEPGCache, eEPGCache.getInstance()
  except:
   return None, None
 @staticmethod
 def VVn2mE(): CCjxcj.VVCFoV(CCjxcj.VV6ZMT)
 @staticmethod
 def VVCFoV(act):
  ec, inst = CCjxcj.VVViEf()
  if inst and hasattr(ec, act):
   try:
    exec("inst.%s()" % act)
    return True
   except:
    pass
  return False
 @staticmethod
 def VVhbCI(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   SELF.session.nav.stopService()
   SELF.session.nav.playService(serv)
 @staticmethod
 def VVRBqP(refCode):
  ec, inst = CCjxcj.VVViEf()
  if inst:
   try:
    evList = inst.lookupEvent([CCjxcj.VV9IYB, (refCode, 0, -1, 20160)])
    if evList: return refCode, evList, ""
    else  : return refCode, [], "System returned empty EPG list"
   except:
    return refCode, [], "EPG Read-Error !"
  else:
   return refCode, [], "Cannot read EPG Cache !"
 @staticmethod
 def VVrq0M(refCode, events, longDescDays=0):
  ec, inst = CCjxcj.VVViEf()
  totEv, totOK, fnc = 0, 0, None
  if inst:
   if   hasattr(ec, "importEvents"): fnc = inst.importEvents
   elif hasattr(ec, "importEvent") : fnc = inst.importEvent
  if fnc:
   for data in events:
    totEv += 1
    try:
     if longDescDays and data[0] > iTime() + 86400 * longDescDays:
      data = data[:4] + ("",) + data[5:]
     fnc(refCode, (data,))
     totOK += 1
    except:
     pass
  return totEv, totOK
 @staticmethod
 def VVCaOX(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   ec, inst = CCjxcj.VVViEf()
   if ec:
    event = inst.lookupEventTime(serv, -1, 0)
    if event:
     return CCjxcj.VVy7ay(event)
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CCXzVR.CCjxcj(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVy7ay(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCjxcj.VVPC3a(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVpNjI(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   ec, inst = CCjxcj.VVViEf()
   try:
    if inst:
     for evNum in range(2):
      event = inst.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CCjxcj.VVy7ay(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FFPuhT(evTime)
       evEndTxt  = FFPuhT(evEnd)
       evDurTxt  = FFGcFN(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FFGcFN(evPos)
        evRem = evEnd - now
        evRemTxt = FFGcFN(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FFGcFN(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VVPC3a(event):
  genre = PR = ""
  try:
   genre  = CCjxcj.VVEDuk(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCjxcj.VVmFse(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVmFse(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVEDuk(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCjxcj.VVM5Vs()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVM5Vs():
  path = VVkwgw + "_sup_genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFSIRe(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFSIRe(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VV9Mui(VVkINB, title):
  ec, inst = CCjxcj.VVViEf()
  if not inst:
   return "", "Cannot access EPG Cache !"
  totFound = totEvents = totSuccess = totInvalid = totEvErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVkINB.VV3rlI():
   if remark == "0":
    try:
     evList = inst.lookupEvent([CCjxcj.VV9IYB, (srcRef, 0, -1, 20160)])
    except:
     totEvErr += 1
     evList = []
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CCjxcj.VVrq0M(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CCjxcj.VVn2mE()
  txt  = "Services\t: %d\n"  % VVkINB.VVKW2u()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  if totEvErr:
   txt += "EPG Errors\t: %d" % totEvErr
  return txt, ""
 @staticmethod
 def VV3CMT(info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += CCjxcj.VVal59(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += CCjxcj.VVal59(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += CCjxcj.VVal59(event, 0)
     except:
      pass
  return epg
 @staticmethod
 def VVal59(event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCjxcj.VVy7ay(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    trName, trShort, trLong, errName, errShort, errLong = CCjxcj.VVulMW(evName, evShort, evDesc)
    evShort, evDesc = trShort, trLong
    evNameTransl = trName if evName and trName and evName != trName else ""
    if evName          : txt += "Name\t: %s\n"   % FF1YQ7(evName, VVyz0j)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (CFG.epgLangDescr.getValue().upper(), FF1YQ7(evNameTransl, VVyz0j))
    if evTime           : txt += "Start Time\t: %s\n" % FFPuhT(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFPuhT(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFGcFN(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFGcFN(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFGcFN(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FF1YQ7(evShort, VVifMr)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FF1YQ7(evDesc , VVifMr)
    if txt:
     txt = FF1YQ7("\n%s\n%s Event:\n%s\n" % (SEP, ("Current", "Next")[evNum], SEP), VVyz0j) + txt
  return txt
 @staticmethod
 def VVJSXz(txt):
  try:
   from HTMLParser import HTMLParser
   return HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
class CCmfL4(Screen, CCImRc):
 VV48rD  = 0
 VVDwIP = 1
 VV3mpE  = 2
 VVAxTD  = 3
 VVvknG = 4
 VVQkKK = 5
 VVZhkO = 6
 VVSMx3   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FFdP4M(VVuQx7, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVeJjT = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVgktg = self.VVijHM()
  FFj3mb(self, VVgktg=VVgktg, title="Services/Channels")
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self["myMenu"].setList(self.VVijHM())
  FFayJd(self["myMenu"])
  FF08xD(self)
 def VVijHM(self):
  VVgktg = []
  c = VVo8aK
  VVgktg.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVgktg.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVgktg.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVgktg.append(VVm7kE)
  c = VVyz0j
  VVgktg.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVgktg.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVgktg.append((VVWgbP + "More tables ..."     , "VVmSVa"    ))
  c = VVifMr
  VVgktg.append(VVm7kE)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVgktg.append((c + txt          , "VV7JiB"  ))
  else : VVgktg.append((txt           ,          ))
  VVgktg.append((c + 'Export Services to "channels.xml"'    , "VVD1de"      ))
  VVgktg.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VVeksK
  VVgktg.append(VVm7kE)
  VVgktg.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVgktg.append((c + "Invalid Services Cleaner"       , "VV4HuT"    ))
  c = VVeksK
  VVgktg.append(VVm7kE)
  VVgktg.append((c + "Delete Channels with no names"     , "VV1As7"    ))
  VVgktg.append((c + "Delete Empty Bouquets"       , "VVKate"     ))
  VVgktg.append(VVm7kE)
  VVqizq, VV7f3w = CCmfL4.VVgbQn()
  if fileExists(VVqizq):
   enab = fileExists(VV7f3w)
   if enab: VVgktg.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVgktg.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVgktg.append(("Reset Parental Control Settings"      , "VV26Tl"    ))
  VVgktg.append(("Reload Channels and Bouquets"       , "VVYF1I"      ))
  return VVgktg
 def VV96hS(self):
  global VVEyaB
  VVEyaB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCppT7.VVkxsS(self.session)
   elif item == "openSignal"       : FFf5BK(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FFPrkv(self, fncMode=CCXzVR.VV0WSU)
   elif item == "lameDB_allChannels_with_refCode"  : FFkWFV(self, self.VVcU6u)
   elif item == "lameDB_allChannels_with_tranaponder" : FFkWFV(self, self.VVX6Hv)
   elif item == "VVmSVa"     : self.VVmSVa()
   elif item == "VV7JiB"  : CCZL1y.VV7JiB(self)
   elif item == "VVD1de"      : self.VVD1de()
   elif item == "copyEpgPicons"      : self.VVb27z(False)
   elif item == "SatellitesCleaner"     : FFkWFV(self, self.FFkWFV_SatellitesCleaner)
   elif item == "VV4HuT"    : FFkWFV(self, BF(self.VV4HuT))
   elif item == "VV1As7"    : FFkWFV(self, self.VV1As7)
   elif item == "VVKate"     : self.VVKate(self)
   elif item == "enableHiddenChannels"     : self.VV8u6U(True)
   elif item == "disableHiddenChannels"    : self.VV8u6U(False)
   elif item == "VV26Tl"    : FFDiGG(self, self.VV26Tl, "Reset and Restart ?")
   elif item == "VVYF1I"      : FFkWFV(self, BF(CCmfL4.VVYF1I, self))
 def VVmSVa(self):
  VVgktg = []
  VVgktg.append(("Services (IDs)"       , "lameDB_allChannels_with_details" ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Services (Parental-Control List)"   , "parentalControlChannels"   ))
  VVgktg.append(("Services (Hidden List)"     , "showHiddenChannels"    ))
  VVgktg.append(("Services with PIcons for the System"  , "VVJLZW"    ))
  VVgktg.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"  ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Transponders (Statistics)"    , "TranspondersStats"    ))
  VVgktg.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"    ))
  FFBqvZ(self, self.VVyxgK, VVgktg=VVgktg, title="Service Information", VVomDt=True)
 def VVyxgK(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FFkWFV(self, BF(self.VVVzDr, title))
   elif ref == "parentalControlChannels"   : FFkWFV(self, BF(self.VVEfLS, title))
   elif ref == "showHiddenChannels"    : FFkWFV(self, BF(self.VV2hHL, title))
   elif ref == "VVJLZW"    : FFkWFV(self, BF(self.VVoFRf, title))
   elif ref == "servicesWithMissingPIcons"   : FFkWFV(self, BF(self.VVbd9z, title))
   elif ref == "TranspondersStats"     : FFkWFV(self, BF(self.VVfwIh, title))
   elif ref == "SatellitesXmlStats"    : FFkWFV(self, BF(self.VVdrwN, title))
 def VVD1de(self):
  VVgktg = []
  VVgktg.append(("All DVB-S/C/T Services", "all"))
  VVgktg.extend(CCMyrC.VVyIT7())
  FFBqvZ(self, self.VVpiEz, VVgktg=VVgktg, title="", VVomDt=True)
 def VVpiEz(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCmfL4.VV2Rz4("1:7:")
   else   : lst = FFanBk(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFCt6D(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFtvcx(r)  : sat = "Stream Relay"
       elif FFUsGW(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FFGa2t(CFG.exportedTablesPath.getValue()), FF4Fnb())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FF27fq(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFpIgV(self, "No Services found !", 1500)
 @staticmethod
 def VVYF1I(SELF):
  FFHpDz()
  FF27fq(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVcU6u(self):
  self.VVeJjT = None
  self.lastfilterUsed  = None
  self.filterObj   = CCYFnw(self)
  VVUl7I, err = CCmfL4.VVwWVD(self, self.VV48rD)
  if VVUl7I:
   VVUl7I.sort(key=lambda x: x[0].lower())
   VVp0o5  = ("Zap"   , self.VV8bKi     , [])
   VVq5Be = (""    , self.VVeIb6   , [])
   VVW1zM = ("Options"  , self.VVG9dA , [])
   VVkY0R = ("Current Service", self.VVuRVg , [])
   VVM4el = ("Filter"   , self.VVBOWy  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVwZxf  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FF69ky(self, None, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=26, VVp0o5=VVp0o5, VVq5Be=VVq5Be, VVkY0R=VVkY0R, VVW1zM=VVW1zM, VVM4el=VVM4el, lastFindConfigObj=CFG.lastFindServices)
 def VVX6Hv(self):
  self.VVeJjT = None
  self.lastfilterUsed  = None
  self.filterObj   = CCYFnw(self)
  VVUl7I, err = CCmfL4.VVwWVD(self, self.VVDwIP)
  if VVUl7I:
   VVUl7I.sort(key=lambda x: x[0].lower())
   VVp0o5  = ("Zap"   , self.VV8bKi      , [])
   VVq5Be = (""    , self.VVeIb6    , [])
   VVkY0R = ("Current Service", self.VVuRVg  , [])
   VVW1zM = ("Options"  , self.VVEQeZ , [])
   VVM4el = ("Filter"   , self.VVuly1  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVwZxf  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FF69ky(self, None, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=26, VVp0o5=VVp0o5, VVq5Be=VVq5Be, VVkY0R=VVkY0R, VVW1zM=VVW1zM, VVM4el=VVM4el, lastFindConfigObj=CFG.lastFindServices)
 def VVG9dA(self, VVkINB, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CCVAoa(self, VVkINB)
  VVgktg = []
  isMulti = VVkINB.VVopq8
  if isMulti:
   refCodeList = VVkINB.VVYlFT(3)
   if refCodeList:
    VVgktg.append(("Add Selection to Parental Control"  , "parentalControl_sel_add"  ))
    VVgktg.append(("Remove Selection from Parental Control" , "parentalControl_sel_remove" ))
    VVgktg.append(VVm7kE)
    VVgktg.append(("Add Selection to Hidden Services"   , "hiddenServices_sel_add"  ))
    VVgktg.append(("Remove Selection from Hidden Services" , "hiddenServices_sel_remove" ))
    VVgktg.append(VVm7kE)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVgktg.append((txt1, "parentalControl_add" ))
    VVgktg.append((txt2,        ))
   else:
    VVgktg.append((txt1,       ))
    VVgktg.append((txt2, "parentalControl_remove" ))
   VVgktg.append(VVm7kE)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVgktg.append((txt1, "hiddenServices_add"  ))
    VVgktg.append((txt2,       ))
   else:
    VVgktg.append((txt1,        ))
    VVgktg.append((txt2, "hiddenServices_remove" ))
   VVgktg.append(VVm7kE)
  cbFncDict = { "parentalControl_add"   : BF(self.VVfRYf, VVkINB, refCode, True)
     , "parentalControl_remove"  : BF(self.VVfRYf, VVkINB, refCode, False)
     , "hiddenServices_add"   : BF(self.VVTCiW, VVkINB, refCode, True)
     , "hiddenServices_remove"  : BF(self.VVTCiW, VVkINB, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVel80, VVkINB, True)
     , "parentalControl_sel_remove" : BF(self.VVel80, VVkINB, False)
     , "hiddenServices_sel_add"  : BF(self.VVfXcN, VVkINB, True)
     , "hiddenServices_sel_remove" : BF(self.VVfXcN, VVkINB, False)
     }
  VVgktg1, cbFncDict1 = CCmfL4.VVndoT(self, VVkINB, servName, 3)
  VVgktg.extend(VVgktg1)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VVLgo2(VVgktg, cbFncDict)
 def VVEQeZ(self, VVkINB, title, txt, colList):
  servName = colList[0]
  mSel = CCVAoa(self, VVkINB)
  VVgktg, cbFncDict = CCmfL4.VVndoT(self, VVkINB, servName, 3)
  mSel.VVLgo2(VVgktg, cbFncDict)
 @staticmethod
 def VVndoT(SELF, VVkINB, servName, refCodeCol):
  tot = VVkINB.VVIf28()
  if tot > 0:
   sTxt = FF1YQ7("%d Service%s" % (tot, FFLFel(tot)), VVyz0j)
   VVgktg = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FFOD7l(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FF1YQ7(servName, VVyz0j)
   VVgktg = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CCmfL4.VVsvdD, SELF, VVkINB, refCodeCol, True)
     , "addToBouquet_one" : BF(CCmfL4.VVsvdD, SELF, VVkINB, refCodeCol, False)
     }
  return VVgktg, cbFncDict
 @staticmethod
 def VVsvdD(SELF, VVkINB, refCodeCol, isMulti):
  picker = CCMyrC(SELF, VVkINB, "Add to Bouquet", BF(CCmfL4.VVL35p, VVkINB, refCodeCol, isMulti))
 @staticmethod
 def VVL35p(VVkINB, refCodeCol, isMulti):
  if isMulti : refCodeList = VVkINB.VVYlFT(refCodeCol)
  else  : refCodeList = [VVkINB.VVw0xB()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VVfRYf(self, VVkINB, refCode, isAddToBlackList):
  VVkINB.VVeMZj("Processing ...")
  FFLYGh(BF(self.VVR4u3, VVkINB, [refCode], isAddToBlackList))
 def VVel80(self, VVkINB, isAddToBlackList):
  refCodeList = VVkINB.VVYlFT(3)
  if not refCodeList:
   FFG2mq(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVkINB.VVeMZj("Processing ...")
  FFLYGh(BF(self.VVR4u3, VVkINB, refCodeList, isAddToBlackList))
 def VVR4u3(self, VVkINB, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VV6lWZ, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VV6lWZ):
   lines = FFjqdo(VV6lWZ)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VV6lWZ, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVkINB.VVopq8
   if isMulti:
    self.VVZK4U(VVkINB, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VV3FeL(VVkINB, refCode)
    VVkINB.VVTm6g()
  else:
   VVkINB.VVpB4f("No changes")
 def VVTCiW(self, VVkINB, refCode, isHide):
  title = "Change Hidden State"
  if FFDQBg(refCode):
   VVkINB.VVeMZj("Processing ...")
   ret = FFzHg5(refCode, isHide)
   if ret : FFkWFV(self, BF(self.VV3FeL, VVkINB, refCode))
   else : FFG2mq(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFG2mq(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VV3FeL(self, VVkINB, refCode):
  VVUl7I, err = CCmfL4.VVwWVD(self, self.VV48rD, VVUlLT=[3, [refCode], False])
  done = False
  if VVUl7I:
   data = VVUl7I[0]
   if data[3] == refCode:
    done = VVkINB.VVrgU7(data)
  if not done:
   self.VVT3Ca(VVkINB, VVkINB.VVZC2U(), self.VV48rD)
  VVkINB.VVTm6g()
 def VVZK4U(self, VVkINB, totRefCodes):
  VVUl7I, err = CCmfL4.VVwWVD(self, self.VV48rD, VVUlLT=self.VVeJjT)
  VVkINB.VVDqeT(VVUl7I)
  VVkINB.VVBKwU(False)
  VVkINB.VVpB4f("%d Processed" % totRefCodes)
 def VVfXcN(self, VVkINB, isHide):
  refCodeList = VVkINB.VVYlFT(3)
  if not refCodeList:
   FFG2mq(self, "Nothing selected", title="Change Hidden State")
   return
  VVkINB.VVeMZj("Processing ...")
  FFLYGh(BF(self.VVzZ5M, VVkINB, refCodeList, isHide))
 def VVzZ5M(self, VVkINB, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFzHg5(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFHpDz(True)
   self.VVZK4U(VVkINB, len(refCodeList))
  else:
   VVkINB.VVpB4f("No changes")
 def VVBOWy(self, VVkINB, title, txt, colList):
  inFilterFnc = BF(self.VVNnAl, VVkINB) if self.VVeJjT else None
  self.filterObj.VV07rO(1, VVkINB, 2, BF(self.VVzFVA, VVkINB), inFilterFnc=inFilterFnc)
 def VVzFVA(self, VVkINB, item):
  self.VVGonI(VVkINB, False, item, 2, self.VV48rD)
 def VVNnAl(self, VVkINB, VVVYOp, item):
  self.VVGonI(VVkINB, True, item, 2, self.VV48rD)
 def VVuly1(self, VVkINB, title, txt, colList):
  inFilterFnc = BF(self.VVKCFD, VVkINB) if self.VVeJjT else None
  self.filterObj.VV07rO(2, VVkINB, 4, BF(self.VVLwkS, VVkINB), inFilterFnc=inFilterFnc)
 def VVLwkS(self, VVkINB, item):
  self.VVGonI(VVkINB, False, item, 4, self.VVDwIP)
 def VVKCFD(self, VVkINB, VVVYOp, item):
  self.VVGonI(VVkINB, True, item, 4, self.VVDwIP)
 def VVU42U(self, VVkINB, title, txt, colList):
  inFilterFnc = BF(self.VVPvmZ, VVkINB) if self.VVeJjT else None
  self.filterObj.VV07rO(0, VVkINB, 4, BF(self.VVezF8, VVkINB), inFilterFnc=inFilterFnc)
 def VVezF8(self, VVkINB, item):
  self.VVGonI(VVkINB, False, item, 4, self.VV3mpE)
 def VVPvmZ(self, VVkINB, VVVYOp, item):
  self.VVGonI(VVkINB, True, item, 4, self.VV3mpE)
 def VVGonI(self, VVkINB, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVkINB.VVRYeh(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVeJjT = None
  else:
   words, asPrefix = CCYFnw.VVt9Ew(words)
   self.VVeJjT = [col, words, asPrefix]
  if words: FFkWFV(VVkINB, BF(self.VVT3Ca, VVkINB, title, mode), clearMsg=False)
  else : FFpIgV(VVkINB, "Incorrect filter", 2000)
 def VVT3Ca(self, VVkINB, title, mode):
  VVUl7I, err = CCmfL4.VVwWVD(self, mode, VVUlLT=self.VVeJjT, VV1Nw8=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVkINB.VV3rlI():
    try:
     ndx = VVUl7I.index(tuple(list(map(str.strip, row))))
     lst.append(VVUl7I[ndx])
    except:
     pass
   VVUl7I = lst
  if VVUl7I:
   VVUl7I.sort(key=lambda x: x[0].lower())
   VVkINB.VVDqeT(VVUl7I, title, VVc63JMsg=True)
  else:
   FFpIgV(VVkINB, "Not found!", 1500)
 def VVsDeu(self, title, VV9gTz, VVp0o5=None, VVq5Be=None, VVcNot=None, VVkY0R=None, VVW1zM=None, VVM4el=None):
  VVkY0R = ("Current Service", self.VVuRVg, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVwZxf = (LEFT  , LEFT  , CENTER, LEFT    )
  FF69ky(self, None, title=title, header=header, VV9gTz=VV9gTz, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=26, VVp0o5=VVp0o5, VVq5Be=VVq5Be, VVcNot=VVcNot, VVkY0R=VVkY0R, VVW1zM=VVW1zM, VVM4el=VVM4el, lastFindConfigObj=CFG.lastFindServices)
 def VVuRVg(self, VVkINB, title, txt, colList):
  self.VVhVFZ(VVkINB)
 def VVPI4o(self, VVkINB, title, txt, colList):
  self.VVhVFZ(VVkINB, True)
 def VVhVFZ(self, VVkINB, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVkINB.VVfOKC(colDict, VVT0Gn=True)
   else:
    VVkINB.VVXQxM(3, refCode, True)
   return
  FFG2mq(self, "Cannot read current Reference Code !")
 def VVVzDr(self, title):
  self.VVeJjT = None
  self.lastfilterUsed  = None
  self.filterObj   = CCYFnw(self)
  VVUl7I, err = CCmfL4.VVwWVD(self, self.VV3mpE)
  if VVUl7I:
   VVUl7I.sort(key=lambda x: x[0].lower())
   VVq5Be = (""    , self.VVbBVs , []      )
   VVkY0R = ("Current Service", self.VVPI4o  , []      )
   VVM4el = ("Filter"   , self.VVU42U   , [], "Loading Filters ..." )
   VVp0o5  = ("Zap"   , self.VV2Ozt      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVwZxf  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FF69ky(self, None, title=title, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=26, VVp0o5=VVp0o5, VVq5Be=VVq5Be, VVkY0R=VVkY0R, VVM4el=VVM4el, lastFindConfigObj=CFG.lastFindServices)
 def VVbBVs(self, VVkINB, title, txt, colList):
  refCode  = self.VVE46C(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFPrkv(self, fncMode=CCXzVR.VVGUgD, refCode=refCode, chName=chName, text=txt)
 def VV2Ozt(self, VVkINB, title, txt, colList):
  refCode = self.VVE46C(colList)
  FFWpQx(self, refCode)
 def VV8bKi(self, VVkINB, title, txt, colList):
  FFWpQx(self, colList[3])
 def VVE46C(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVx9TU(VVqizq, mode=0):
  lines = FFjqdo(VVqizq, encLst=["UTF-8"])
  return CCmfL4.VVmZYf(lines, mode)
 @staticmethod
 def VVmZYf(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VVwWVD(SELF, mode, VVUlLT=None, VV1Nw8=True, VVoFHD=True):
  VVqizq, err = CCmfL4.VVECFt(SELF, VVoFHD)
  if err:
   return None, err
  asPrefix = False
  if VVUlLT:
   filterCol = VVUlLT[0]
   filterWords = VVUlLT[1]
   asPrefix = VVUlLT[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCmfL4.VV48rD:
   blackList = None
   if fileExists(VV6lWZ):
    blackList = FFjqdo(VV6lWZ)
    if blackList:
     blackList = set(blackList)
  elif mode == CCmfL4.VVDwIP:
   tp = CC5l6x()
  VVASq4, VVQ0ZT = FFGsAb()
  if mode in (CCmfL4.VVQkKK, CCmfL4.VVZhkO):
   VVUl7I = {}
  else:
   VVUl7I = []
  tagFound = False
  with ioOpen(VVqizq, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FFAOQQ(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCmfL4.VV3mpE:
       if sTypeInt in VVASq4:
        STYPE = VVQ0ZT[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVUl7I.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVUl7I.append(tRow)
       else:
        VVUl7I.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCmfL4.VVSMx3:
        VVUl7I.append((chName, chProv, sat, refCode))
       elif mode == CCmfL4.VVQkKK:
        VVUl7I[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCmfL4.VVZhkO:
        VVUl7I[chName] = refCode
       elif mode == CCmfL4.VV48rD:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVUl7I.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVUl7I.append(tRow)
        else:
         VVUl7I.append(tRow)
       elif mode == CCmfL4.VVDwIP:
        if sTypeInt in VVASq4:
         STYPE = VVQ0ZT[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVSfcz(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVUl7I.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVUl7I.append(tRow)
        else:
         VVUl7I.append(tRow)
       elif mode == CCmfL4.VVAxTD:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVUl7I.append((chName, chProv, sat, refCode))
       elif mode == CCmfL4.VVvknG:
        VVUl7I.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVUl7I and VV1Nw8:
   FFG2mq(SELF, "No services found!")
  return VVUl7I, ""
 def VVEfLS(self, title):
  if fileExists(VV6lWZ):
   lines = FFjqdo(VV6lWZ)
   if lines:
    newRows = []
    VVUl7I, err = CCmfL4.VVwWVD(self, self.VVvknG)
    if VVUl7I:
     lines = set(lines)
     for item in VVUl7I:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVUl7I = newRows
      VVUl7I.sort(key=lambda x: x[0].lower())
      VVq5Be = ("", self.VVeIb6, [])
      VVp0o5 = ("Zap", self.VV8bKi, [])
      self.VVsDeu(title, VVUl7I, VVp0o5=VVp0o5, VVq5Be=VVq5Be)
     else:
      FF8ShK(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVUl7I)))
   else:
    FF27fq(self, "No active Parental Control services.", FFMV8t())
  else:
   FFcMQr(self, VV6lWZ)
 def VV2hHL(self, title):
  VVUl7I, err = CCmfL4.VVwWVD(self, self.VVAxTD)
  if VVUl7I:
   VVUl7I.sort(key=lambda x: x[0].lower())
   VVq5Be = ("" , self.VVeIb6, [])
   VVp0o5  = ("Zap", self.VV8bKi, [])
   self.VVsDeu(title, VVUl7I, VVp0o5=VVp0o5, VVq5Be=VVq5Be)
  elif err:
   pass
  else:
   FF27fq(self, "No hidden services.", FFMV8t())
 def VV4HuT(self):
  title = "Services unused in Tuner Configuration"
  VVqizq, err = CCmfL4.VVECFt(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CCmfL4.VVBGms()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VVZdHt(str(item[0]))
    nsLst.add(ns)
  sysLst = CCmfL4.VV2Rz4("1:7:")
  tpLst  = CCmfL4.VVx9TU(VVqizq, mode=1)
  VVUl7I = []
  for refCode, chName in sysLst:
   servID = CCmfL4.VV2fpO(refCode)
   tpID = CCmfL4.VVOQgW(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VVUl7I.append((chName, FFCt6D(refCode, False), refCode, servID))
  if VVUl7I:
   VVUl7I.sort(key=lambda x: x[0].lower())
   VVW1zM = ("Options"   , BF(self.VVX9Nr, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VVwZxf  = (LEFT  , CENTER , LEFT   , CENTER   )
   FF69ky(self, None, title=title, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=26, VVW1zM=VVW1zM, VVrcFy="#0a001122", VVZZ3c="#0a001122", VVRr4z="#0a001122", VVLwCQ="#00004455", VVhvzQ="#0a333333", VVEjwd="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FF27fq(self, "No invalid service found !", title=title)
 def VVX9Nr(self, Title, VVkINB, title, txt, colList):
  mSel = CCVAoa(self, VVkINB)
  isMulti = VVkINB.VVopq8
  if isMulti : txt = "Remove %s Services" % FF1YQ7(str(VVkINB.VVIf28()), VVWgbP)
  else  : txt = "Remove : %s" % FF1YQ7(VVkINB.VVw0xB()[0], VVWgbP)
  VVgktg = [(txt, "del")]
  cbFncDict = {"del": BF(FFkWFV, VVkINB, BF(self.VVvkkc, VVkINB, Title))}
  mSel.VVLgo2(VVgktg, cbFncDict)
 def VVvkkc(self, VVkINB, title):
  VVqizq, err = CCmfL4.VVECFt(self, title=title)
  if err:
   return
  isMulti = VVkINB.VVopq8
  skipLst = []
  if isMulti : skipLst = VVkINB.VVYlFT(3)
  else  : skipLst = [VVkINB.VVw0xB()[3]]
  tpLst = CCmfL4.VVx9TU(VVqizq, mode=0)
  servLst = CCmfL4.VVx9TU(VVqizq, mode=10)
  tmpDbFile = VVqizq + ".tmp"
  lines   = FFjqdo(VVqizq)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  FFLgW2("mv -f '%s' '%s'" % (tmpDbFile, VVqizq))
  VVUl7I = []
  for row in VVkINB.VV3rlI():
   if not row[3] in skipLst:
    VVUl7I.append(row)
  FFHpDz()
  FF8ShK(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VVUl7I:
   VVkINB.VVDqeT(VVUl7I, title)
   VVkINB.VVBKwU(False)
  else:
   VVkINB.cancel()
 def VVfwIh(self, title):
  VVqizq, err = CCmfL4.VVECFt(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VV1RCy(VVqizq)
  txt = FF1YQ7("Total Transponders:\n\n", VV4aa0)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FF1YQ7("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VV4aa0)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFAVM1(item), satList.count(item))
  FF8ShK(self, txt, title)
 def VV1RCy(self, VVqizq):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VVqizq, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVdrwN(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FFcMQr(self, path, title=title)
   return
  elif not CCyssW.VVfwhn(self, path, title):
   return
  if not CCMhuj.VVQg4l(self):
   return
  tree = CCmfL4.VVmm3j(self, path, title=title)
  if not tree:
   return
  VVUl7I = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FFAOQQ(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVUl7I.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVUl7I:
   VVUl7I.sort(key=lambda x: int(x[1]))
   VVkY0R = ("Current Satellite", BF(self.VVvXkL, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VVwZxf  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FF69ky(self, None, title=title, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=25, VVWtKU=1, VVkY0R=VVkY0R, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFG2mq(self, "No data found !", title=title)
 def VVvXkL(self, satCol, VVkINB, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
  sat = FFCt6D(refCode, False)
  for ndx, row in enumerate(VVkINB.VV3rlI()):
   if sat == row[satCol].strip():
    VVkINB.VV2NBO(ndx)
    break
  else:
   FFpIgV(VVkINB, "No listed !", 1500)
 def FFkWFV_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FFG2mq(self, "No Satellites found !")
   return
  usedSats = CCmfL4.VVBGms()
  VVUl7I = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VVUl7I.append((sat[1], posTxt, FFAOQQ(sat[0]), tuners, str(posVal)))
  if VVUl7I:
   VVRr4z = "#11222222"
   VVUl7I.sort(key=lambda x: int(x[1]))
   VVkY0R = ("Current Satellite" , BF(self.VVvXkL, 2) , [])
   VVW1zM = ("Options"   , self.VVInxq  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VVwZxf  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FF69ky(self, None, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=28, VVkY0R=VVkY0R, VVW1zM=VVW1zM, VVrcFy=VVRr4z, VVZZ3c=VVRr4z, VVRr4z=VVRr4z, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFG2mq(self, "No data found !")
 def VVInxq(self, VVkINB, title, txt, colList):
  mSel = CCVAoa(self, VVkINB)
  isMulti = VVkINB.VVopq8
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FF1YQ7(str(VVkINB.VVIf28()), VVWgbP)
  else  : txt = "Remove ALL Services on : %s" % FF1YQ7(VVkINB.VVw0xB()[0], VVWgbP)
  VVgktg = []
  VVgktg.append((txt, "deleteSat"))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Delete Empty Bouquets", "VVKate"))
  cbFncDict = { "deleteSat"   : BF(FFkWFV, VVkINB, BF(self.VV7FcD, VVkINB))
     , "VVKate" : BF(self.VVKate, VVkINB)
     }
  mSel.VVLgo2(VVgktg, cbFncDict)
 def VV7FcD(self, VVkINB):
  posLst = []
  isMulti = VVkINB.VVopq8
  posLst = []
  if isMulti : posLst = VVkINB.VVYlFT(4)
  else  : posLst = [VVkINB.VVw0xB()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VVZdHt(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VVBXDk(nsLst)
  FFHpDz(True)
  FF8ShK(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VVKate(self, winObj):
  title = "Delete Empty Bouquets"
  FFDiGG(self, BF(FFkWFV, winObj, BF(self.VVG2dP, title)), "Delete bouquets with no services ?", title=title)
 def VVG2dP(self, title):
  bList = CCMyrC.VVgUZC()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CCMyrC.VVETMB(bRef)
    bPath = VVMixw + bFile
    FFMc8G(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVMixw + fil
     if fileExists(path):
      lines = FFjqdo(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFHpDz(True)
  if bNames: txt = "%s\n\n%s" % (FF1YQ7("Deleted Bouquets:", VVyz0j), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FF8ShK(self, txt, title=title)
 def VVZdHt(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VVBXDk(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVMixw)
  for srcF in files:
   if fileExists(srcF):
    lines = FFjqdo(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFmxJt(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VVoFRf(self, title)   : self.VVJLZW(title, True)
 def VVbd9z(self, title) : self.VVJLZW(title, False)
 def VVJLZW(self, title, isWithPIcons):
  piconsPath = CCQVwA.VVzkHI()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCQVwA.VVbOxR(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVUl7I, err = CCmfL4.VVwWVD(self, self.VVvknG)
    if VVUl7I:
     channels = []
     for (chName, chProv, sat, refCode) in VVUl7I:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFWHq3(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVUl7I)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVy4Ld(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVy4Ld("PIcons Path"  , piconsPath)
     txt += VVy4Ld("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVy4Ld("Total services" , totalServices)
     txt += VVy4Ld("With PIcons"  , totalWithPIcons)
     txt += VVy4Ld("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FF8ShK(self, txt)
     else:
      VVq5Be     = (""      , self.VVeIb6 , [])
      if isWithPIcons : VVM4el = ("Export Current PIcon", self.VVVmnt  , [])
      else   : VVM4el = None
      VVW1zM     = ("Statistics", FF8ShK, [txt])
      VVp0o5      = ("Zap", self.VV8bKi, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VVsDeu(title, channels, VVp0o5=VVp0o5, VVq5Be=VVq5Be, VVW1zM=VVW1zM, VVM4el=VVM4el)
   else:
    FFG2mq(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFG2mq(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVeIb6(self, VVkINB, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFPrkv(self, fncMode=CCXzVR.VVGUgD, refCode=refCode, chName=chName, text=txt)
 def VVVmnt(self, VVkINB, title, txt, colList):
  png, path = CCQVwA.VV4b82(colList[3], colList[0])
  if path:
   CCQVwA.VVdmuI(self, png, path)
 @staticmethod
 def VVgbQn():
  VVqizq  = "%slamedb" % VVMixw
  VV7f3w = "%slamedb.disabled" % VVMixw
  return VVqizq, VV7f3w
 @staticmethod
 def VVUXrv():
  VVesVR  = "%slamedb5" % VVMixw
  VVvbY9 = "%slamedb5.disabled" % VVMixw
  return VVesVR, VVvbY9
 def VV8u6U(self, isEnable):
  VVqizq, VV7f3w = CCmfL4.VVgbQn()
  if isEnable and not fileExists(VV7f3w):
   FF27fq(self, "Aready enabled.")
  elif not isEnable and not fileExists(VVqizq):
   FFG2mq(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFDiGG(self, BF(self.VVW4Fn, isEnable), "%s Hidden Channels ?" % word)
 def VVW4Fn(self, isEnable):
  VVqizq , VV7f3w = CCmfL4.VVgbQn()
  VVesVR, VVvbY9 = CCmfL4.VVUXrv()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VV7f3w, VV7f3w, VVqizq)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVvbY9, VVvbY9, VVesVR)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVqizq  , VVqizq , VV7f3w)
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVesVR , VVesVR, VVvbY9)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VV7f3w, VVqizq )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVvbY9, VVesVR)
  ok = FFLgW2(cmd)
  FFHpDz()
  if ok: FF27fq(self, "Hidden List %s" % word)
  else : FFG2mq(self, "Error while restoring:\n\n%s" % fileName)
 def VV26Tl(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %s | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVDhAD
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %s" % VVDhAD
  FFyemP(self, cmd)
 def VV1As7(self):
  VVqizq, err = CCmfL4.VVECFt(self)
  if err:
   return
  tmpFile = "/tmp/ajp_lamedb"
  FFMc8G(tmpFile)
  totChan = totRemoved = 0
  lines = FFjqdo(VVqizq, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FFDiGG(self, BF(FFkWFV, self, BF(self.VVFqGf, tmpFile, VVqizq, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FFLFel(totRemoved), totChan, FFLFel(totChan))
      , callBack_No=BF(self.VVZ3Lc, tmpFile))
  else:
   FF8ShK(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VVFqGf(self, tmpFile, VVqizq, totRemoved, totChan):
  FFLgW2("mv -f '%s' '%s'" % (tmpFile, VVqizq))
  FFHpDz()
  FF8ShK(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VVZ3Lc(self, tmpFile):
  FFMc8G(tmpFile)
 @staticmethod
 def VVECFt(SELF, VVoFHD=True, title=""):
  VVqizq, VV7f3w = CCmfL4.VVgbQn()
  if   not fileExists(VVqizq)       : err = "File not found !\n\n%s" % VVqizq
  elif not CCyssW.VVfwhn(SELF, VVqizq) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VVoFHD:
   FFG2mq(SELF, err, title=title)
  return VVqizq, err
 @staticmethod
 def VVOQgW(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VV2fpO(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VV2Rz4(servTypes):
  VVnXy1  = eServiceCenter.getInstance()
  VVtIoG   = '%s ORDER BY name' % servTypes
  VVo2GV   = eServiceReference(VVtIoG)
  VVnXmm = VVnXy1.list(VVo2GV)
  if VVnXmm: return VVnXmm.getContent("CN", False)
  else     : return []
 @staticmethod
 def VVBGms():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CCXzVR(Screen):
 VV0WSU  = 0
 VVKBIM   = 1
 VVfGK9   = 2
 VVGUgD    = 3
 VVkdMR    = 4
 VVjZ7J   = 5
 VVPeIV   = 6
 VV4myO    = 7
 VV8Twr   = 8
 VV2cm1   = 9
 VVylhq   = 10
 VVAlR2   = 11
 EPG_MODE_BOUQUET_EDITOR   = 12
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFdP4M(VViAAJ, 1400, 1000, 50, 30, 10, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VV0WSU)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.portalEpgUrl = kwargs.get("portalEpgUrl", "")
  self.piconShown  = False
  self.Sep   = FF1YQ7("%s\n", VVqC3w) % SEP
  self.picViewer  = None
  FFj3mb(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVVKga })
  self["myPicF"] = Label()
  self["myPicB"] = Label()
  self["myPic"] = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVgr8g)
  self.onClose.append(self.onExit)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  self["myLabel"].VVdp3X(outputFileToSave="chann_info")
  if   self.fncMode == self.VV0WSU : fnc = self.VVbYn8
  elif self.fncMode == self.VVKBIM  : fnc = self.VVbYn8
  elif self.fncMode == self.VVfGK9  : fnc = self.VVbYn8
  elif self.fncMode == self.VVGUgD  : fnc = self.VVwRUP
  elif self.fncMode == self.VVkdMR  : fnc = self.VVwalq
  elif self.fncMode == self.VVjZ7J  : fnc = self.VV73QD
  elif self.fncMode == self.VVPeIV  : fnc = self.VVxUTb
  elif self.fncMode == self.VV4myO  : fnc = self.VVdIKV
  elif self.fncMode == self.VV8Twr  : fnc = self.VVIW3y
  elif self.fncMode == self.VV2cm1 : fnc = self.VV1G41
  elif self.fncMode == self.VVylhq  : fnc = self.VV3FUo
  elif self.fncMode == self.VVAlR2 : fnc = self.VVQhYU
  elif self.fncMode == self.EPG_MODE_BOUQUET_EDITOR : fnc = self.VVPxOM
  self["myLabel"].setText("\n   Reading Info ...")
  self["myLabel"].VVVjqa()
  FFLYGh(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVaf9s()
 def VVnrSX(self, err):
  self["myLabel"].setText(err)
  FFeNfF(self["myTitle"], "#22200000")
  FFeNfF(self["myBody"], "#22200000")
  self["myLabel"].VVkKJD("#22200000")
  self["myLabel"].VVVjqa()
 def VVbYn8(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
  self.refCode = refCode
  self.VVGJjE(chName)
 def VVwRUP(self):
  self.VVGJjE(self.chName)
 def VVwalq(self):
  self.VVGJjE(self.chName)
 def VV73QD(self):
  self.VVGJjE(self.chName)
 def VVxUTb(self):
  self.VVGJjE("Picon Info")
 def VVdIKV(self):
  self.VVGJjE(self.chName)
 def VVIW3y(self):
  self.VVGJjE(self.chName)
 def VV1G41(self):
  self.VVGJjE(self.chName)
 def VV3FUo(self):
  if self.chCm.startswith("Zz1") : self.chUrl = FF3BMa(self.chCm[3:])
  else       : self.chUrl = self.refCode + self.callingSELF.VVhkrA(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVGJjE(self.chName)
 def VVQhYU(self):
  self.VVGJjE(self.chName)
 def VVPxOM(self):
  self.VV8pp6(self.picPath)
  self.VV32IS()
 def VVGJjE(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFkbEk(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VV02Wy(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.portalEpgUrl or self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    self.text = self.text.rstrip() + "\n\nURL:\n%s\n" % FF1YQ7(self.VVhdf1(tUrl), VVdl3O)
  if not self.epg:
   epg = CCjxcj.VV3CMT(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VV8pp6(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCQVwA.VV4b82(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VV8pp6(path)
  self.VVTltx()
  self.VVthsF(decodedUrl)
  self.VV32IS()
 def VV32IS(self):
  self["myLabel"].setText(self.text or "   No active service", VVMXNv=VVyFvO)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVVjqa(minHeight=minH)
 def VVthsF(self, decodedUrl):
  url = max([self.refCode, self.chUrl, self.iptvRef, self.portalEpgUrl], key=len)
  if not FFUsGW(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVfUwN(FFyEM8(url))
  if not epg:
   if self.portalEpgUrl: epg, err = CCwoYk.VVuNFm(self.portalEpgUrl, refCode=self.refCode)
   else    : epg, err = CCwoYk.VVuNFm(decodedUrl, refCode=self.refCode)
  if epg:
   self.text += "\n" + FFCQJ8("EPG:", VVyz0j) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVTltx()
 def VVTltx(self):
  if not self.piconShown and self.picUrl:
   path, err = FFq7bz(self.picUrl, "ajp_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VV8pp6(path)
    if self.piconShown and self.refCode:
     self.VVTN4T(path, self.refCode)
 def VVTN4T(self, path, refCode):
  if path and fileExists(path) and FFGqL5("ffmpeg"):
   pPath = CCQVwA.VVzkHI()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CCXzVR.VVB1Rq(path)
    cmd += FFhkCt("mv -f '%s' '%s%s'" % (path, pPath, picon))
    FFLgW2(cmd)
 def VV8pp6(self, path):
  if path and fileExists(path):
   err, w, h = self.VV8bfq(path)
   if not err:
    if h > w:
     self.VVgDlE(self["myPicF"], w, h, True)
     self.VVgDlE(self["myPicB"], w, h, False)
     self.VVgDlE(self["myPic"] , w, h, False)
   self.picViewer = CCnohF.VVfe7g(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VVgDlE(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VV8bfq(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFdHIn(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VV02Wy(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FF1YQ7(chName, VVyz0j)
  txt += self.VVy4Ld(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FF1YQ7(state, VVf8NN)
   txt += "State\t: %s\n" % state
  w = FFeZyZ(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFeZyZ(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVZ5cZ(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVy4Ld(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVy4Ld(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVy4Ld(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVWH4k()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVlS9s()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCXzVR.VVNUlF(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FF1YQ7("Stream-Relay" if FFtvcx(decodedUrl) else "IPTV", VV4aa0)
   txt += self.VV8uBG(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VV2Q9h(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CC5l6x()
    tpTxt, namespace = tp.VVEZJz(refCode)
    if tpTxt:
     txt += FF1YQ7("Tuner:\n", VVyz0j)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FF1YQ7("Codes:\n", VVyz0j)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVy4Ld(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVy4Ld(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVy4Ld(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVy4Ld(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVy4Ld(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVy4Ld(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVy4Ld(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVy4Ld(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVy4Ld(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVZ5cZ(info):
  if info:
   aspect = FFeZyZ(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVy4Ld(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFeZyZ(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVG9zc(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVG9zc(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVWH4k(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VVlS9s(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VV2Q9h(self, refCode, iptvRef, chName):
  refCode = FFc5SJ(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFSIRe(VVMixw + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFSIRe(VVMixw + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VV9gTz = []
  tmpRefCode = FFyEM8(refCode)
  for item in fList:
   path = VVMixw + item
   if fileExists(path):
    txt = FFSIRe(path)
    if tmpRefCode in FFyEM8(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VV9gTz.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VV9gTz:
   if len(VV9gTz) == 1:
    txt += "%s\t: %s%s\n" % (FF1YQ7("Bouquet", VVyz0j), VV9gTz[0][0], " (%s)" % VV9gTz[0][1] if VVbMcv else "")
   else:
    txt += FF1YQ7("Bouquets:\n", VVyz0j)
    for ndx, item in enumerate(VV9gTz):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVbMcv else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VV8uBG(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFzXIA(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCwoYk()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVDj8z(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FF1YQ7("URL:", VV4aa0) + "\n%s\n" % self.VVhdf1(decodedUrl)
  else:
   txt = "\n"
   txt += FF1YQ7("Reference:", VV4aa0) + "\n%s\n" % refCode
  return txt
 def VVhdf1(self, url):
  if not FFtvcx(url):
   span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
   if span:
    url = span.group(1)
   if not VVxrH7:
    url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return FFyEM8(url)
 def VVfUwN(self, decodedUrl):
  if not CCUSzd.VVd24U():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCul6W.VVuv9X(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCul6W.VVbwRu(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVpK8i(tDict)
   elif uType == "movie" : epg, picUrl = CCXzVR.VVz95e(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVpK8i(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCul6W.VVaXRJ(item, "title"    , is_base64=True )
     lang    = CCul6W.VVaXRJ(item, "lang"         ).upper()
     description   = CCul6W.VVaXRJ(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCul6W.VVaXRJ(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCul6W.VVaXRJ(item, "start_timestamp"      )
     stop_timestamp  = CCul6W.VVaXRJ(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCul6W.VVaXRJ(item, "stop_timestamp"       )
     now_playing   = CCul6W.VVaXRJ(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVTKcZ, ""
      else     : color, txt = VVf8NN , "    (CURRENT EVENT)"
      epg += FF1YQ7("_" * 32 + "\n", VVqC3w)
      epg += FF1YQ7("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FF1YQ7(description, VVdl3O)
      else   : epg += "Description\t: - \n"
      evNum += 1
      try:
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       totEv, totOK = CCjxcj.VVrq0M(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)], longDescDays=7)
      except:
       pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VVz95e(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCul6W.VVaXRJ(item, "movie_image" )
    genre  = CCul6W.VVaXRJ(item, "genre"   ) or "-"
    plot  = CCul6W.VVaXRJ(item, "plot"   ) or "-"
    country  = CCul6W.VVaXRJ(item, "country"  ) or "-"
    actors  = CCul6W.VVaXRJ(item, "actors"   ) or "-"
    cast  = CCul6W.VVaXRJ(item, "cast"   ) or "-"
    rating  = CCul6W.VVaXRJ(item, "rating"   ) or "-"
    director = CCul6W.VVaXRJ(item, "director"  ) or "-"
    releasedate = CCul6W.VVaXRJ(item, "releasedate" ) or "-"
    duration = CCul6W.VVaXRJ(item, "duration"  ) or "-"
    try:
     lang = CCul6W.VVaXRJ(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Country\t: %s\n"  % country
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FF1YQ7(cast if cast != "-" else actors, VVdl3O)
    epg += "Plot:\n%s"    % FF1YQ7(plot, VVdl3O)
   except:
    pass
  return epg, movie_image
 def VVVKga(self):
  if VVxrH7:
   def VVy4Ld(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVy4Ld(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCwoYk()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVDj8z(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVy4Ld(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (SEP, txt))
   FFpIgV(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VV8hy7(SELF):
  if not CCbAHw.VVGJKq(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(SELF)
  err = url =  fSize = resumable = ""
  if FF0hYs(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCwoYk.VVyxli(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCwoYk.VVbFm5(), timeout=4, stream=True, verify=False)
    if not resp.ok:
     FFG2mq(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCyssW.VV1ctA(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FF1YQ7(" (M3U/M3U8 File)", VVdl3O)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCfWgm.VVH16S(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVGnZU(subj, val):
   return "%s\n%s\n\n" % (FF1YQ7("%s:" % subj, VVyz0j), val)
  title = "File Size"
  txt  = VVGnZU(title , fSize or "?")
  txt += VVGnZU("Name" , chName)
  txt += VVGnZU("URL" , url)
  if resumable: txt += VVGnZU("Supports Download-Resume", resumable)
  if err  : txt += FF1YQ7("Error:\n", VVf8NN) + err
  FF8ShK(SELF, txt, title=title)
 @staticmethod
 def VVNUlF(SELF):
  fPath, fDir, fName = CCyssW.VVOVMO(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVB1Rq(path):
  return FFhkCt("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (path, path))
 @staticmethod
 def VVzlyh(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CCQVwA.VVzkHI() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VV9xJZ(serv):
  isLocal = isIptv = isFtp = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if "file?file" in refCode or ":ftp%3a//" in refCode:
    isFtp = True
    typeTxt = "FTP"
   elif FFUsGW(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFmxJt(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCwoYk():
 def __init__(self):
  self.VVZEc9()
  self.VVbURL    = ""
  self.VVsJBI   = "#f#11ffffaa#User"
  self.VVQ6Km   = "#f#11aaffff#Server"
 def VVZEc9(self):
  self.VVFIuc   = ""
  self.VVUwU6    = ""
  self.VVXBZD   = ""
  self.VVQsBo = ""
  self.VViiyc  = ""
  self.VVXbqE = 0
 def VVM3PL(self, url, mac, ph1="", VVT0Gn=True):
  self.VVZEc9()
  self.VVbURL = {"s": "/server/load.php", "p": "/portal.php", "q": "/portal1.php"}.get(ph1, "")
  host = self.VVeMxK(url)
  if not host:
   if VVT0Gn:
    self.VVr3Eu("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVmQK1(mac)
  if not host:
   if VVT0Gn:
    self.VVr3Eu("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVFIuc = host
  self.VVUwU6  = mac
  return True
 def VVPvU3(self):
  return {"/server/load.php":"s", "/portal.php":"p", "/portal1.php":"q"}.get(self.VVbURL, "")
 def VVeMxK(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVmQK1(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVga3s(self):
  res, err = self.VVzF6N(self.VVtxQy())
  if "404" in err or res and res.status_code == 200 and not res.text.strip():
   if self.VVFIuc.endswith("/c"):
    self.VVFIuc = self.VVFIuc[:-2]
    res, err = self.VVzF6N(self.VVtxQy())
   elif self.VVFIuc.endswith("/stalker_portal"):
    self.VVFIuc = self.VVFIuc[:-15]
    res, err = self.VVzF6N(self.VVtxQy())
   else:
    self.VVFIuc += "/c"
    res, err = self.VVzF6N(self.VVtxQy())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCul6W.VVaXRJ(tDict["js"], "token")
    rand  = CCul6W.VVaXRJ(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVwUVb(self, VVT0Gn=True):
  if not self.VVbURL:
   self.VVZtd2()
  err = blkMsg = FF27fqTxt = ""
  try:
   token, rand, err = self.VVga3s()
   if token:
    self.VVXBZD = token
    self.VVQsBo = rand
    if rand:
     self.VVXbqE = 2
    prof, retTxt = self.VVL5N3(True)
    if prof:
     self.VViiyc = retTxt
     if any(x in retTxt for x in ("device_id mismatch", "old firmware")):
      self.VVXbqE = 3
      prof, retTxt = self.VVL5N3(False)
      if retTxt:
       self.VViiyc = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FF27fqTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FF27fqTxt: tErr += "\n%s" % FF27fqTxt
  if VVT0Gn:
   self.VVr3Eu(tErr)
  return "", "", tErr
 def VVZtd2(self):
  try:
   import requests
   url = self.VVPD6z()
   jsFile = "xpcom.common.js"
   res = requests.get("%s/stalker_portal/c/%s" % (url, jsFile), headers=CCwoYk.VVbFm5(), stream=True, timeout=2)
   if not res.ok or not "javascript" in res.headers.get("content-type"):
    res = requests.get("%s/c/%s" % (url, jsFile), headers=CCwoYk.VVbFm5(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    patt = ""
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r"\s*var\s+pattern\s*=\s*\/(.+)\/\s*;", line, IGNORECASE)
      if span:
       patt = span.group(1)
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       if "portal_path" in line:
        if patt.endswith("*\/(.)*") : url += "/c"
        else      : url += "/stalker_portal"
       self.VVFIuc = url
       self.VVbURL = span.group(1)
       return
  except:
   pass
  self.VVbURL = "/server/load.php"
 def VVPD6z(self):
  url = self.VVFIuc.rstrip("/")
  if url.endswith("/c")    : url = url[:-2]
  if url.endswith("/stalker_portal") : url = url[:-15]
  if url.endswith("/c")    : url = url[:-2]
  return url
 def VV19Tl(self, url, isJsFile=False):
  import requests
  jsFile = "xpcom.common.js" if isJsFile else "version.js"
  res, err = self.VVzF6N("%s/stalker_portal/c/%s" % (url, jsFile))
  if not res or not "javascript" in res.headers.get("content-type"):
   res, err = self.VVzF6N("%s/c/%s" % (url, jsFile))
  if res and "javascript" in res.headers.get("content-type"):
   if isJsFile:
    return str(res.content), ""
   else:
    span = iSearch(r"var\s+ver\s*=\s*'(.+)'", res.text, IGNORECASE)
    if span:
     return span.group(1), ""
  return "", err
 def VVL5N3(self, capMac):
  res, err = self.VVzF6N(self.VVr7BG(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCul6W.VVaXRJ(tDict["js"], "block_%s" % word)
    FF27fqTxt = CCul6W.VVaXRJ(tDict["js"], word)
    return tDict, FF27fqTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVr7BG(self, capMac):
  param = ""
  if self.VViiyc or self.VVQsBo:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVUwU6.upper() if capMac else self.VVUwU6.lower(), self.VVQsBo))
  return self.VVV67p() + "type=stb&action=get_profile" + param
 exec(FF3BMa("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gPSAiJmF1dGhfc2Vjb25kX3N0ZXA9MSZod192ZXJzaW9uPTIuMTctSUItMDAmaHdfdmVyc2lvbl8yPTYyJnNuPSVzJmRldmljZV9pZD0lcyZkZXZpY2VfaWQyPSVzJnNpZ25hdHVyZT0lcyIgJSAoSWRbMF0sIElkWzFdLCBJZFsxXSwgSWRbMl0pDQogcmV0dXJuIHBhcmFtICsgJyZ2ZXI9UGxheWVyIEVuZ2luZSB2ZXJzaW9uOiAweDU4YyZtZXRyaWNzPXsibWFjIjoiJXMiLCJzbiI6IiVzIiwidHlwZSI6IlNUQiIsIm1vZGVsIjoiTUFHMjUwIiwicmFuZG9tIjoiJXMifScgJSAoSWRbM10sIElkWzBdLCBJZFs0XSkNCmRlZiBnZXRNb3JlQXV0aF9JRHMoc2VsZiwgbSwgcik6DQogaW1wb3J0IGhhc2hsaWINCiBtYWNVdGY4ID0gbS5lbmNvZGUoJ3V0Zi04JykNCiBzID0gaGFzaGxpYi5tZDUobWFjVXRmOCkuaGV4ZGlnZXN0KCkudXBwZXIoKVs6MTNdDQogcmV0dXJuIHMsIGhhc2hsaWIuc2hhMjU2KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKCksIGhhc2hsaWIuc2hhMjU2KChzICsgbSkuZW5jb2RlKCd1dGYtOCcpKS5oZXhkaWdlc3QoKS51cHBlcigpLCBtLCBy"))
 def VVQWXA(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VV38Qm()
  if len(rows) < 10:
   rows = self.VVZAli()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVFIuc ))
   rows.append(("MAC (from URL)" , self.VVUwU6 ))
   rows.append(("Token"   , self.VVXBZD ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VVsJBI  , "MAC" , self.VVUwU6 ))
   rows.append(("2", self.VVQ6Km, "Host" , self.VVFIuc ))
   rows.append(("2", self.VVQ6Km, "Token" , self.VVXBZD ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVE6Ei(self, isPhp=True, VVT0Gn=False):
  token, profile, tErr = self.VVwUVb(VVT0Gn)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VVYJ4h()
  res, err = self.VVzF6N(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCul6W.VVaXRJ(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFP4cn(span.group(2))
     pass1 = FFP4cn(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VV38Qm(self):
  m3u_Url, host, user1, pass1, err = self.VVE6Ei()
  rows = []
  if m3u_Url:
   res, err = self.VVzF6N(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFPuhT(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VVsJBI, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFPuhT(int(val))
      else      : val = str(val)
      rows.append(("2", self.VVQ6Km, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVZAli(self):
  token, profile, tErr = self.VVwUVb()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFIQ17(val): val = FF3BMa(val.decode("UTF-8"))
     else     : val = self.VVUwU6
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFPuhT(int(parts[1]))
      if parts[2] : ends = FFPuhT(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFPuhT(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVhkrA(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVwUVb(VVT0Gn=False)
  if not token:
   return ""
  crLinkUrl = self.VVFZCR(mode, chCm, epNum, epId)
  res, err = self.VVzF6N(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCul6W.VVaXRJ(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVV67p(self):
  return self.VVFIuc + self.VVbURL + "?"
 def VVtxQy(self):
  return self.VVV67p() + "type=stb&action=handshake&token=&mac=%s" % self.VVUwU6
 def VVmCvW(self, mode):
  url = self.VVV67p() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VV5Gys(self, catID):
  return self.VVV67p() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVJETl(self, mode, catID, page):
  url = self.VVV67p() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVDTDm(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VVV67p() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVbDsj(self, stID):
  return self.VVV67p() + "type=itv&action=get_short_epg&ch_id=%s" % stID
 def VVFZCR(self, mode, chCm, serCode, serId):
  url = self.VVV67p() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=0&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVYJ4h(self):
  return self.VVV67p() + "type=itv&action=create_link"
 def VVhIR5(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVOCPv(catID, stID, chNum)
  query = self.VViWLS(mode, self.VVPvU3(), FFXAmg(host), FFXAmg(mac), serCode, serId, chCm, catID, stID)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VViWLS(self, mode, ph1, host, mac, serCode, serId, chCm, catID, stID):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&cId=%s&sId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, catID, stID, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVDj8z(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  catID = tDict.get("cId" , [""])[0].strip()
  stID = tDict.get("sId" , [""])[0].strip()
  query = self.VViWLS(mode, ph1, host, mac, epNum, epId, FFP4cn(chCm), catID, stID)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FF3BMa(host)
  mac   = FF3BMa(mac)
  valid = False
  if self.VVeMxK(playHost) and self.VVeMxK(host) and self.VVeMxK(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query
 def VVzF6N(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCwoYk.VVbFm5()
   if self.VVXBZD:
    headers["Authorization"] = "Bearer %s" % self.VVXBZD
   if useCookies : cookies = {"mac": self.VVUwU6, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=CFG.portalConnTimeout.getValue(), cookies=cookies)
   if res.ok:
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVZkcb(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCwoYk.VVbFm5(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVbFm5():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 def VVr3Eu(self, err, title="Portal Browser"):
  FFG2mq(self, str(err), title=title)
 def VVNX3j(self, mode):
  if   mode in ("itv"  , CCul6W.VVrGBU , CCul6W.VVBFzQ)  : return "Live"
  elif mode in ("vod"  , CCul6W.VVwJHr , CCul6W.VV8igu)  : return "VOD"
  elif mode in ("series" , CCul6W.VVOmtY , CCul6W.VVhjgU) : return "Series"
  else                          : return "IPTV"
 def VVLXjt(self, mode, searchName):
  return 'Find in %s : %s' % (self.VVNX3j(mode), FF1YQ7(searchName, VVdl3O))
 def VV54VK(self, catchup=False):
  VVgktg = []
  VVgktg.append(("Live"    , "live"  ))
  VVgktg.append(("VOD"    , "vod"   ))
  VVgktg.append(("Series"   , "series"  ))
  if catchup:
   VVgktg.append(VVm7kE)
   VVgktg.append(("Catch-up TV" , "catchup"  ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Account Info." , "accountInfo" ))
  return VVgktg
 @staticmethod
 def VVgDS9(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCwoYk()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVDj8z(decodedUrl)
  if valid:
   ok = p.VVM3PL(host, mac, ph1, VVT0Gn=False)
   if ok:
    m3u_Url, host1, user1, pass1, err = p.VVE6Ei(isPhp=False, VVT0Gn=False)
    streamId = CCwoYk.VVJQSf(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err
 @staticmethod
 def VVJQSf(decodedUrl):
  p = CCwoYk()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVDj8z(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FF3BMa(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVyxli(decodedUrl):
  p = CCwoYk()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVDj8z(decodedUrl)
  if valid:
   if CCwoYk.VVDNkf(chCm):
    return FFyEM8(chCm)
   else:
    ok = p.VVM3PL(host, mac, ph1, VVT0Gn=False)
    if ok:
     try:
      chUrl = p.VVhkrA(mode, chCm, epNum, epId)
      return FFyEM8(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VVDNkf(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
 @staticmethod
 def VVuNFm(decodedUrl, retLst=False, refCode=""):
  epg = err = ""
  if "mode=itv" in decodedUrl:
   p = CCwoYk()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVDj8z(decodedUrl)
   if valid:
    if not stID:
     stID = CCwoYk.VVJQSf(decodedUrl)
    if stID:
     if p.VVM3PL(host, mac, ph1, VVT0Gn=False):
      token, profile, tErr = p.VVwUVb(VVT0Gn=False)
      if token:
       res, err = p.VVzF6N(p.VVbDsj(stID))
       if res:
        epg, err = CCwoYk.VVRkJA(res.text, retLst)
        if not retLst and epg and refCode:
         pList, err = CCwoYk.VVRkJA(res.text, retLst=True)
         if pList:
          totEv, totOK = CCjxcj.VVrq0M(refCode, pList)
  return epg, err
 @staticmethod
 def VVRkJA(txt, retLst=False):
  epg, lst = "", []
  try:
   tDict = jLoads(txt)
   evNum = 1
   for item in tDict["js"]:
    actor    = CCul6W.VVaXRJ(item, "actor"       )
    category   = CCul6W.VVaXRJ(item, "category"      )
    descr    = CCul6W.VVaXRJ(item, "descr"   , is_base64=True).replace("\n", " .. ")
    director   = CCul6W.VVaXRJ(item, "director"      )
    name    = CCul6W.VVaXRJ(item, "name"   , is_base64=True)
    start_timestamp  = CCul6W.VVaXRJ(item, "start_timestamp", isDate=True )
    start_timestamp_unix= CCul6W.VVaXRJ(item, "start_timestamp"    )
    stop_timestamp  = CCul6W.VVaXRJ(item, "stop_timestamp" , isDate=True )
    stop_timestamp_unix = CCul6W.VVaXRJ(item, "stop_timestamp"     )
    if retLst:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ""
       lst.append((start, dur, name, shortDesc, descr, 1))
     except:
      pass
    else:
     skip, curEv = False, ""
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
      if float(start_timestamp_unix) < iTime() and float(stop_timestamp_unix) > iTime():
       curEv = FF1YQ7("    (CURRENT EVENT)", VVo8aK)
     except:
      pass
     if not skip:
      epg += FF1YQ7("_" * 32 + "\n", VVqC3w)
      epg += "Event\t: %d%s\n" % (evNum, curEv)
      epg += "Title\t: %s\n"  % FF1YQ7(name, VVyz0j)
      epg += "Start\t: %s\n"  % start_timestamp
      epg += "End\t: %s\n"  % stop_timestamp
      epg += "Description:\n%s\n" % FF1YQ7(descr , VVdl3O) if descr else "Description\t: - \n"
      epg += "Genre:\n%s\n"  % FF1YQ7(category, VVdl3O) if category else ""
      epg += "Actors:\n%s\n"  % FF1YQ7(actor , VVdl3O) if actor else ""
      epg += "Director:\n%s\n" % FF1YQ7(director, VVdl3O) if director else ""
      evNum += 1
  except:
   return "", "Cannot parse received data !"
  if retLst: return lst, ""
  else  : return epg, ""
class CCBhNc(CCwoYk):
 def __init__(self):
  CCwoYk.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVMsTt(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVDj8z(decodedUrl)
  if valid:
   if self.VVM3PL(host, mac, ph1, VVT0Gn=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVveVR(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   if self.chCm.startswith("Zz1"):
    self.chCm = FF3BMa(self.chCm[3:])
   else:
    chUrl = self.VVhkrA(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CCwoYk.VVDNkf(self.chCm):
   chUrl = FFyEM8(self.chCm)
   chUrl = FFP4cn(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl.startswith("http"):
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVUK9x(chUrl)
  bPath = CCMyrC.VVUvjS()
  if newIptvRef:
   if passedSELF:
    FFWpQx(passedSELF, newIptvRef, VVxOHd=False, fromPortalReplay=True, isFromSession=isFromSession)
   else:
    FFWpQx(self, newIptvRef, VVxOHd=False, fromPortalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VVho3n(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VVUK9x(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVho3n(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("ph1", "cId", "sId")
   for par in params:
    newPar = iSub(r"&%s=.*?&" % par, "&", newPar)
   lines = FFjqdo(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for par in params:
       filePar = iSub(r"&%s=.*?&" % par, "&", filePar)
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFHpDz()
class CCf894(CCBhNc):
 def __init__(self, passedSession):
  CCBhNc.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVjf34(VVPRk7  )
  Main_Menu.VVjf34(VV6Bd8)
  Main_Menu.VVjf34(VVjcx1  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVsSzl, iPlayableService.evEOF: self.VVY2uE, iPlayableService.evEnd: self.VVyI3w})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VV1KqN)
  except:
   self.timer2.callback.append(self.VV1KqN)
  self.timer2.start(3000, False)
  self.VV1KqN()
 def VV1KqN(self):
  if not CFG.downloadMonitor.getValue():
   self.VV503e()
   return
  lst = CCfWgm.VVJB4v()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FF1fFq(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCfWgm.VVkQIB(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin : self.dnldWin = CChhP9.VVfLzp(self.passedSession, txt, 30)
   else    : CChhP9.VVr3dW(self.dnldWin, txt)
  elif self.dnldWin:
   self.VV503e()
 def VV503e(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVsSzl(self):
  self.startTime = iTime()
 def VVY2uE(self):
  global VV5YNu
  VV5YNu = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self.passedSession, isFromSession=True)
    if iptvRef and not "file?file" in iptvRef and not ":ftp%3a//" in iptvRef and not FF0hYs(decodedUrl):
     self.isFromEOF = True
     CChhP9(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVyI3w(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVvFAe)
  except:
   self.timer1.callback.append(self.VVvFAe)
  self.timer1.start(100, True)
 def VVvFAe(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVMsTt(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCppT7.VVVBav:
       self.isFromEOF = False
       self.VVveVR(self.passedSession, isFromSession=True)
class CCnY2W():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Za-z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-Za-z0-9\/\-._:|\]\[]+[\])|:](.+)"
          r"|^[A-Za-z]{,3}[^\x00-\x7F]{,3}\ (.+)")
  self.prefixRemoveList = self.VVJyjg(self.removeTag, "ajpanel_iptv_prefix", False, ())
  self.adultWords = self.VVJyjg(self.hideAdult, "ajpanel_iptv_blacklist", True, ("adult","aduld","sex","porn","xxx","xxi","erotic","x-rated","xrated","skin flick","dirty movie","dirty film","blue movie","blue film","18+","+18","r18 movie","r18 film","r-18 movie","r-18 film","r-17 movie","r-17 film"))
 def VVJyjg(self, cond, fName, isLower, tSet):
  tSet = set(tSet)
  if cond:
   for path in (VVkwgw, VVrXLj):
    path += fName
    if fileExists(path):
     for line in FFjqdo(path):
      line = line.strip()
      if len(line) >= 3:
       tSet.add(line.lower() if isLower else line)
  return tuple(sorted(tSet, key=lambda x: x.lower()))
 def VVNobF(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCul6W.VVJyIw(name):
   return CCul6W.VVYR2z(name)
  return self.VVE2fn(name)
 def VVE2fn(self, name):
  newName = ""
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2) or span.group(3)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     newName = tName
   for t in self.prefixRemoveList:
    if name.startswith(t):
     newName = name[len(t):]
     break
  return newName.strip() or name
 def VVP5Ly(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVE2fn(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVy0Lv(self, name):
  if self.hideAdult:
   tName = name.lower()
   if any(x in tName for x in self.adultWords):
    return ""
  return name.strip()
 def VVkkyz(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVhIKA(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCbAHw(CCwoYk):
 def __init__(self):
  self.curPortalCatId = ""
  CCwoYk.__init__(self)
 def VVS51q(self):
  if CCbAHw.VVGJKq(self):
   FFkWFV(self, BF(self.VVem8X, 2), title="Searching ...")
 def VVc65h(self, winSession, url, mac):
  self.curUrl = url
  if CCbAHw.VVGJKq(self):
   if self.VVM3PL(url, mac):
    FFkWFV(winSession, self.VVmY9h, title="Checking Server ...")
   else:
    FFG2mq(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVVMyW(self, item=None):
  if item:
   VVVYOp, txt, path, ndx = item
   enc = CCmJil.VVm967(path, self)
   if enc == -1:
    return
   self.session.open(CCKX0k, barTheme=CCKX0k.VVfjb8
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VVUA1Y, path, enc)
       , VVJ8mq = BF(self.VVXT7I, VVVYOp, path))
 def VVUA1Y(self, path, enc, VVzRAM):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVzRAM.VVGeXq(totLines)
  VVzRAM.VVgo83 = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVzRAM or VVzRAM.isCancelled:
     return
    VVzRAM.VVu4eE(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVeMxK(url)
     mac  = self.VVmQK1(mac)
     if host and mac and VVzRAM:
      VVzRAM.VVgo83.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVeMxK(url)
      mac  = self.VVmQK1(mac)
      if host and mac and not mac.startswith("AC") and VVzRAM:
       VVzRAM.VVgo83.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVXT7I(self, VVVYOp, path, VV4mF1, VVgo83, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVgo83:
   VVcNot  = ("Home Menu"  , FFcTP7            , [])
   VVW1zM = ("Edit File"  , BF(self.VVRV1M, path)       , [])
   VVkY0R = ("M3U Options" , self.VVGlc1         , [])
   VVM4el = ("Check & Filter" , BF(self.VVakF7, VVVYOp, path), [])
   VVp0o5  = ("Select"   , self.VV8h7r      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVwZxf  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVkINB = FF69ky(self, None, title=title, header=header, VV9gTz=VVgo83, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=26, VVp0o5=VVp0o5, VVcNot=VVcNot, VVkY0R=VVkY0R, VVW1zM=VVW1zM, VVM4el=VVM4el, VVrcFy="#0a001122", VVZZ3c="#0a001122", VVRr4z="#0a001122", VVLwCQ="#00004455", VVhvzQ="#0a333333", VVEjwd="#11331100", VVFwVS=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VV4mF1:
    FFpIgV(VVkINB, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VV4mF1:
    FFG2mq(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVGlc1(self, VVkINB, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVgktg = []
  VVgktg.append(("Browse as M3U"  , "browse"))
  VVgktg.append(("Download M3U File" , "downld"))
  FFBqvZ(self, BF(self.VVI3vd, VVkINB, host, mac), title=title, VVgktg=VVgktg, width=600, VVomDt=True)
 def VVI3vd(self, VVkINB, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FFkWFV(VVkINB, BF(self.VVAnLi, VVkINB, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FFDiGG(self, BF(FFkWFV, VVkINB, BF(self.VVAnLi, VVkINB, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVAnLi(self, VVkINB, title, host, mac, item):
  p = CCwoYk()
  m3u_Url = ""
  ok = p.VVM3PL(host, mac, VVT0Gn=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VVE6Ei(VVT0Gn=False)
  if m3u_Url:
   if   item == "browse": self.VVhut5(title, m3u_Url)
   elif item == "downld": self.VVLYwV(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FFG2mq(self, err or "No response from Server !", title=title)
 def VV8h7r(self, VVkINB, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVc65h(VVkINB, url, mac)
 def VVRV1M(self, path, VVkINB, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CC0TyL(self, path, VVJ8mq=BF(self.VVkOTi, VVkINB), curRowNum=rowNum)
  else    : FFcMQr(self, path)
 def VVakF7(self, VVVYOp, path, VVkINB, title, txt, colList):
  self.session.open(CCKX0k, barTheme=CCKX0k.VVzy8h
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VVdilG, VVkINB)
      , VVJ8mq = BF(self.VVp2P3, VVVYOp, VVkINB, path))
 def VVdilG(self, VVkINB, VVzRAM):
  VVzRAM.VVgo83 = []
  VVzRAM.VVGeXq(VVkINB.VVKW2u())
  for row in VVkINB.VV3rlI():
   if not VVzRAM or VVzRAM.isCancelled:
    return
   VVzRAM.VVu4eE(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVM3PL(host, mac, VVT0Gn=False):
    token, profile, tErr = self.VVwUVb(VVT0Gn=False)
    if token and VVzRAM and not VVzRAM.isCancelled:
     res, err = self.VVzF6N(self.VVmCvW("itv"))
     if res and VVzRAM and not VVzRAM.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVzRAM.VVu4eE(0, showFound=True)
       VVzRAM.VVgo83.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVzRAM:
    return
 def VVp2P3(self, VVVYOp, VVkINB, path, VV4mF1, VVgo83, threadCounter, threadTotal, threadErr):
  if VVgo83:
   VVkINB.close()
   VVVYOp.close()
   newPath = "%s_OK_%s.txt" % (path, FF4Fnb())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVgo83:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FF1YQ7(str(threadCounter), VVf8NN)
    skipped = FF1YQ7(str(threadTotal - threadCounter), VVf8NN)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVgo83)
   txt += "%s\n\n%s"    %  (FF1YQ7("Result File:", VVyz0j), newPath)
   FF8ShK(self, txt, title="Accessible Portals")
  elif VV4mF1:
   FFG2mq(self, "No portal access found !", title="Accessible Portals")
 def VVMRQi(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FF3BMa(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVmY9h(self):
  token, profile, tErr = self.VVwUVb()
  if token:
   dots = "." * self.VVXbqE
   dots += {"s":"", "p":"+", "q":"++", }.get(self.VVPvU3(), "")
   dots += "*" if not self.VVFIuc == self.curUrl else ""
   VVgktg  = self.VV54VK()
   VVl3Ru = self.VVV6PS
   VVdi3l = self.VVxEsN
   VVqafJ = ("Home Menu", FFcTP7)
   VVG0eT= ("Add to Menu", BF(CCul6W.VVPPGS, self, True, self.VVFIuc + "\t" + self.VVUwU6))
   VV2qPD = ("Bookmark Server", BF(CCul6W.VVtuDc, self, True, self.VVFIuc + "\t" + self.VVUwU6))
   VVVYOp = FFBqvZ(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVUwU6, dots), VVgktg=VVgktg, VVl3Ru=VVl3Ru, VVdi3l=VVdi3l, VVqafJ=VVqafJ, VVG0eT=VVG0eT, VV2qPD=VV2qPD)
   self.VVsTVD(VVVYOp)
 def VVV6PS(self, item=None):
  if item:
   VVVYOp, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFkWFV(VVVYOp, BF(self.VVmeLu, mode), title="Reading Categories ...")
   else : FFkWFV(VVVYOp, BF(self.VVXCJu, VVVYOp, title), title="Reading Account ...")
 def VVXCJu(self, VVVYOp, title, forceMoreInfo=False):
  rows, totCols = self.VVQWXA(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVUwU6)
  VVcNot  = ("Home Menu" , FFcTP7           , [])
  VVkY0R  = None
  if VVxrH7:
   VVkY0R = ("Get JS"  , BF(self.VVL3c7, self.VVPD6z()) , [])
  if totCols == 2:
   VVM4el = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVM4el = ("More Info.", BF(self.VV7Utk, VVVYOp)    , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FF69ky(self, None, title=title, width=1200, header=header, VV9gTz=rows, VVYiuZ=widths, VVvi36=26, VVcNot=VVcNot, VVkY0R=VVkY0R, VVM4el=VVM4el, VVrcFy="#0a00292B", VVZZ3c="#0a002126", VVRr4z="#0a002126", VVLwCQ="#00000000", searchCol=searchCol)
 def VVL3c7(self, url, VVkINB, title, txt, colList):
  FFkWFV(VVkINB, BF(self.VVzAyK, url), title="Getting JS ...")
 def VVzAyK(self, url):
  txt  = "// Host\t: %s\t%s\n" % (url, self.VVUwU6)
  ver, err = self.VV19Tl(url)
  txt += "// Version\t: %s\n\n" % (ver or err)
  js , err = self.VV19Tl(url, isJsFile=True)
  if err: txt += "Error : %s" % err
  else  : txt += js
  FF8ShK(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VV7Utk(self, VVVYOp, VVkINB, title, txt, colList):
  VVkINB.cancel()
  FFkWFV(VVVYOp, BF(self.VVXCJu, VVVYOp, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVmeLu(self, mode):
  token, profile, tErr = self.VVwUVb()
  if not token:
   return
  res, err = self.VVzF6N(self.VVmCvW(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]
     for item in chList:
      Id   = CCul6W.VVaXRJ(item, "id"       )
      Title  = CCul6W.VVaXRJ(item, "title"      )
      censored = CCul6W.VVaXRJ(item, "censored"     )
      Title = self.VVy0Lv(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVbMcv:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVNX3j(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVrcFy, VVZZ3c, VVRr4z, VVLwCQ = self.VVxwoR(mode)
   mName = self.VVNX3j(mode)
   VVgDd7  = (""     , BF(self.VVBxnG, mode), [])
   VVp0o5   = ("Show List"   , BF(self.VVzIgg, mode)   , [])
   VVcNot  = ("Home Menu"   , FFcTP7        , [])
   if mode in ("vod", "series"):
    VVW1zM = ("Find in %s" % mName , BF(self.VVPUpy, mode, False), [])
    VVM4el = ("Find in Selected" , BF(self.VVPUpy, mode, True) , [])
   else:
    VVW1zM = None
    VVM4el = None
   header   = None
   widths   = (100   , 0  )
   FF69ky(self, None, title=title, width=1200, header=header, VV9gTz=list, VVYiuZ=widths, VVvi36=30, VVcNot=VVcNot, VVW1zM=VVW1zM, VVM4el=VVM4el, VVgDd7=VVgDd7, VVp0o5=VVp0o5, VVrcFy=VVrcFy, VVZZ3c=VVZZ3c, VVRr4z=VVRr4z, VVLwCQ=VVLwCQ, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VViiyc:
     txt += "\n\n( %s )" % self.VViiyc
   else:
    txt = "Could not get Categories from server!"
   FFG2mq(self, txt, title=title)
 def VVZd0i(self, mode, VVkINB, title, txt, colList):
  FFkWFV(VVkINB, BF(self.VVYnR1, mode, VVkINB, title, txt, colList), title="Downloading ...")
 def VVYnR1(self, mode, VVkINB, title, txt, colList):
  token, profile, tErr = self.VVwUVb()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVzF6N(self.VV5Gys(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]['data']
     for item in chList:
      Id    = CCul6W.VVaXRJ(item, "id"    )
      actors   = CCul6W.VVaXRJ(item, "actors"   )
      added   = CCul6W.VVaXRJ(item, "added"   )
      age    = CCul6W.VVaXRJ(item, "age"   )
      category_id  = CCul6W.VVaXRJ(item, "category_id" )
      description  = CCul6W.VVaXRJ(item, "description" )
      director  = CCul6W.VVaXRJ(item, "director"  )
      genres_str  = CCul6W.VVaXRJ(item, "genres_str"  )
      name   = CCul6W.VVaXRJ(item, "name"   )
      path   = CCul6W.VVaXRJ(item, "path"   )
      screenshot_uri = CCul6W.VVaXRJ(item, "screenshot_uri" )
      series   = CCul6W.VVaXRJ(item, "series"   )
      cmd    = CCul6W.VVaXRJ(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VVgDd7 = (""     , BF(self.VVbcrl, mode, True)  , [])
   VVp0o5  = ("Play"    , BF(self.VVBL2H, mode)       , [])
   VVq5Be = (""     , BF(self.VVgfqj, mode)     , [])
   VVcNot = ("Home Menu"   , FFcTP7            , [])
   VVkY0R = ("Download Options" , BF(self.VVWhTK, mode, "sp", seriesName) , [])
   VVW1zM = ("Options"   , BF(self.VVl0R4, "pEp", mode, seriesName) , [])
   VVM4el = ("Posters Mode"  , BF(self.VVc0ii, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVwZxf  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FF69ky(self, None, title=seriesName, width=1200, header=header, VV9gTz=list, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=26, VVgDd7=VVgDd7, VVp0o5=VVp0o5, VVq5Be=VVq5Be, VVcNot=VVcNot, VVkY0R=VVkY0R, VVW1zM=VVW1zM, VVM4el=VVM4el, lastFindConfigObj=CFG.lastFindIptv, VVrcFy="#0a00292B", VVZZ3c="#0a002126", VVRr4z="#0a002126", VVLwCQ="#00000000")
  else:
   FFG2mq(self, "Could not get Episodes from server!", title=seriesName)
 def VVPUpy(self, mode, searchInCat, VVkINB, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVgktg = []
  VVgktg.append(("Keyboard"  , "manualEntry"))
  VVgktg.append(("From Filter" , "fromFilter"))
  FFBqvZ(self, BF(self.VVlPE7, VVkINB, mode, searchCatId), title="Input Type", VVgktg=VVgktg, width=400)
 def VVlPE7(self, VVkINB, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FF8ISk(self, BF(self.VVirYO, VVkINB, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCYFnw(self)
    filterObj.VVk2Wn(BF(self.VVirYO, VVkINB, mode, searchCatId))
 def VVirYO(self, VVkINB, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FFeLB8(CFG.lastFindIptv, searchName)
   title = self.VVLXjt(mode, searchName)
   if "," in searchName : FFG2mq(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FFG2mq(self, "Enter at least 3 characters.", title=title)
   else     :
    if CFG.hideIptvServerAdultWords.getValue() and self.VVkkyz([searchName]):
     FFG2mq(self, self.VVhIKA(), title=title)
    else:
     self.VVfWUv(mode, searchName, "", searchName, searchCatId)
 def VVzIgg(self, mode, VVkINB, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.curPortalCatId = catID
  self.VVfWUv(mode, bName, catID, "", "")
 def VVfWUv(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CCKX0k, barTheme=CCKX0k.VVfjb8
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVgy8K, mode, bName, catID, searchName, searchCatId)
      , VVJ8mq = BF(self.VVBTji, mode, bName, catID, searchName, searchCatId))
 def VVBTji(self, mode, bName, catID, searchName, searchCatId, VV4mF1, VVgo83, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVLXjt(mode, searchName)
  else   : title = "%s : %s" % (self.VVNX3j(mode), bName)
  if VVgo83:
   VVkY0R = None
   VVW1zM = None
   if mode == "series":
    VVrcFy, VVZZ3c, VVRr4z, VVLwCQ = self.VVxwoR("series2")
    VVp0o5  = ("Episodes"   , BF(self.VVZd0i, mode)           , [])
   else:
    VVrcFy, VVZZ3c, VVRr4z, VVLwCQ = self.VVxwoR("")
    VVp0o5  = ("Play"    , BF(self.VVBL2H, mode)           , [])
    VVkY0R = ("Download Options" , BF(self.VVWhTK, mode, "vp" if mode == "vod" else "", "") , [])
    VVW1zM = ("Options"   , BF(self.VVl0R4, "pCh", mode, bName)      , [])
   VVgDd7 = (""      , BF(self.VVbcrl, mode, False)      , [])
   VVq5Be = (""      , BF(self.VVYZmQ, mode)         , [])
   VVcNot = ("Home Menu"    , FFcTP7                , [])
   VVM4el = ("Posters Mode"   , BF(self.VVc0ii, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Cat./Genre" , "Logo", "play", "actors" , "descr" , "director")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25   , 6  , 0  , 0   , 0   , 0   )
   VVwZxf  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT   , CENTER, LEFT , LEFT  , LEFT  , LEFT  )
   VVkINB = FF69ky(self, None, title=title, header=header, VV9gTz=VVgo83, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=26, VVcNot=VVcNot, VVkY0R=VVkY0R, VVW1zM=VVW1zM, VVM4el=VVM4el, lastFindConfigObj=CFG.lastFindIptv, VVp0o5=VVp0o5, VVgDd7=VVgDd7, VVq5Be=VVq5Be, VVrcFy=VVrcFy, VVZZ3c=VVZZ3c, VVRr4z=VVRr4z, VVLwCQ=VVLwCQ, VVFwVS=True, searchCol=1)
   if not VV4mF1:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVkINB.VVQgjr(VVkINB.VVZC2U() + tot)
    if threadErr: FFpIgV(VVkINB, "Error while reading !", 2000)
    else  : FFpIgV(VVkINB, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFG2mq(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFG2mq(self, "Could not get list from server !", title=title)
 def VVYZmQ(self, mode, VVkINB, title, txt, colList):
  ttl = lambda x, y: "%s:\n%s\n\n" % (FF1YQ7(x, VVyz0j), str(y)) if y.strip() and not "N/A" in y else ""
  tab = lambda x, y: "%s\t: %s\n" % (x, y) if y.strip() and not "N/A" in y else ""
  Num, Name, catID, genreID, Icon, cmd, Cat_Genre, Logo, play, actors, descr, director = colList
  txt  = tab("Number"  , Num)
  txt += tab("Name"  , Name)
  txt += tab("Cat./Genre" , Cat_Genre)
  txt += tab("Director" , director)
  txt += "\n"
  txt += ttl("Actors"  , actors)
  txt += ttl("Description", descr)
  play = play.strip()
  if play and not play.startswith("[No "):
   txt += ttl("Cur. Playing", play)
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFPrkv(self, fncMode=CCXzVR.VVAlR2, portalHost=self.VVFIuc, portalMac=self.VVUwU6, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VV0zsS(mode, VVkINB, title, txt, colList)
 def VVgfqj(self, mode, VVkINB, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FF1YQ7(colList[10], VVdl3O)
  txt += "Description:\n%s" % FF1YQ7(colList[11], VVdl3O)
  self.VV0zsS(mode, VVkINB, title, txt, colList)
 def VV0zsS(self, mode, VVkINB, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVYH7w(mode, colList)
  refCode, chUrl = self.VVhIR5(self.VVFIuc, self.VVUwU6, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFPrkv(self, fncMode=CCXzVR.VVylhq, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId, portalEpgUrl=chUrl)
 def VVgy8K(self, mode, bName, catID, searchName, searchCatId, VVzRAM):
  try:
   token, profile, tErr = self.VVwUVb()
   if not token:
    return
   if VVzRAM.isCancelled:
    return
   VVzRAM.VVgo83, total_items, max_page_items, err = self.VVAOrP(mode, catID, 1, 1, searchName, searchCatId)
   if VVzRAM.isCancelled:
    return
   if VVzRAM.VVgo83 and total_items > -1 and max_page_items > -1:
    VVzRAM.VVGeXq(total_items)
    VVzRAM.VVu4eE(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVzRAM.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVAOrP(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVzRAM.VVE0Dg()
     if VVzRAM.isCancelled:
      return
     if list:
      VVzRAM.VVgo83 += list
      VVzRAM.VVu4eE(len(list), True)
  except:
   pass
 def VVAOrP(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVDTDm(mode, searchName, searchCatId, page)
  else   : url = self.VVJETl(mode, catID, page)
  res, err = self.VVzF6N(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVQAK9(CCul6W.VVaXRJ(item, "total_items" ))
     max_page_items = self.VVQAK9(CCul6W.VVaXRJ(item, "max_page_items" ))
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCul6W.VVaXRJ(item, "id"    )
      name   = CCul6W.VVaXRJ(item, "name"   )
      o_name   = CCul6W.VVaXRJ(item, "o_name"   )
      category_id  = CCul6W.VVaXRJ(item, "category_id" )
      tv_genre_id  = CCul6W.VVaXRJ(item, "tv_genre_id" )
      number   = CCul6W.VVaXRJ(item, "number"   ) or str(counter)
      logo   = CCul6W.VVaXRJ(item, "logo"   )
      screenshot_uri = CCul6W.VVaXRJ(item, "screenshot_uri" )
      pic    = CCul6W.VVaXRJ(item, "pic"   )
      cmd    = CCul6W.VVaXRJ(item, "cmd"   )
      censored  = CCul6W.VVaXRJ(item, "censored"  )
      genres_str  = CCul6W.VVaXRJ(item, "genres_str"  )
      curPlay   = CCul6W.VVaXRJ(item, "cur_playing" )
      actors   = CCul6W.VVaXRJ(item, "actors"   )
      descr   = CCul6W.VVaXRJ(item, "description" )
      director  = CCul6W.VVaXRJ(item, "director"  )
      catID   = category_id or tv_genre_id
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       if "token=" in cmd and "d=Mag" in cmd:
        cmd = "Zz1" + FFXAmg(cmd)
       else:
        span = iSearch(r"stream=(.+)&", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
        else:
         span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
         if span:
          cmd = "%s%s_" % (cmdStr, span.group(1))
      if   logo.startswith("http")   : picon = logo
      elif pic.startswith("http")    : picon = pic
      elif screenshot_uri.startswith("http") : picon = screenshot_uri
      else         : picon = logo or screenshot_uri or pic
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVFIuc + picon).replace(sp * 2, sp)
      isIcon = "Yes" if picon.startswith("http") else ""
      counter += 1
      name = self.VVNobF(name, censored)
      if name:
       list.append((number, name, Id, catID, picon, cmd, genres_str, isIcon, curPlay, actors, descr, director))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVQAK9(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVBL2H(self, mode, VVkINB, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVYH7w(mode, colList)
  refCode, chUrl = self.VVhIR5(self.VVFIuc, self.VVUwU6, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVJyIw(chName):
   FFpIgV(VVkINB, "This is a marker!", 300)
  else:
   FFkWFV(VVkINB, BF(self.VVIIk1, mode, VVkINB, chUrl), title="Playing ...")
 def VVIIk1(self, mode, VVkINB, chUrl):
  FFWpQx(self, chUrl, VVxOHd=False)
  CCppT7.VVkxsS(self.session, iptvTableParams=(self, VVkINB, mode))
 def VVkw1O(self, mode, VVkINB, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVYH7w(mode, colList)
  refCode, chUrl = self.VVhIR5(self.VVFIuc, self.VVUwU6, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVYH7w(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "_")
  else:
   chNum = colList[0]
   chName = colList[1]
   stID = colList[2]
   catID = colList[3]
   picUrl = colList[4]
   chCm = colList[5]
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVGJKq(SELF, install=True, cbFnc=None):
  try:
   import requests
   return True
  except:
   if install:
    title = 'Install "Requests"'
    VVgktg = []
    VVgktg.append((title        , "inst" ))
    VVgktg.append(("Update Packages then %s" % title , "updInst" ))
    FFBqvZ(SELF, BF(CCbAHw.VV8uWq, SELF, cbFnc=cbFnc), title='This requires Python "Requests" library', VVgktg=VVgktg)
   return False
 @staticmethod
 def VV8uWq(SELF, item=None, cbFnc=None):
  if item:
   cmdUpd = FFnyVC(VVdsnf, "")
   if cmdUpd:
    cmdInst = FFjDaF(VVEdih, "python-requests")
    if pyVersion[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FF20zH(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library', VVAJlf=cbFnc)
   else:
    FFEPUu(SELF)
 def VVeC1s(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVDj8z(decodedUrl)
  return mode, host, catID, stID, epNum.replace("%3a", ":"), epId.replace("%3a", ":")
 def VVsTVD(self, VVVYOp):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVeC1s()
  if all((curMode, curHost, curCat)) and curHost == self.VVFIuc:
   VVVYOp.VVI0nr({"itv": 0, "vod": 1, "series": 2}.get(curMode, 0))
 def VVBxnG(self, mode, VVkINB, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVeC1s()
  if all((curMode, curHost, curCat)) and curMode == mode and curHost == self.VVFIuc:
   VVkINB.VVfOKC({1:curCat})
 def VVbcrl(self, mode, isEp, VVkINB, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVeC1s()
  if all((curMode, curHost, curCat)) and curCat == self.curPortalCatId and curMode == mode and curHost == self.VVFIuc:
   if mode in ("itv", "vod"):
    VVkINB.VVfOKC({2:curStID})
   else: #series
    if isEp:
     VVkINB.VVfOKC({2:curEpNum, 4:curEpId})
    elif mode == "series":
     ser1 = curEpId.split(":")[0]
     ser2 = "%s:%s" % (ser1, ser1)
     ok = VVkINB.VVfOKC({2:ser2})
     if not ok: VVkINB.VVfOKC({2:ser1})
class CCul6W(Screen, CCbAHw, CCnY2W, CCImRc):
 VVYg9T    = 0
 VV4oAS    = 1
 VVotwV    = 2
 VVlZTi    = 3
 VVGK4X     = 4
 VVYwYi     = 5
 VVyeyp     = 6
 VVT0Fd     = 7
 VVOyCk     = 8
 VVPUa0     = 9
 VVZbYS      = 10
 VVHpuE     = 11
 VVR4Y0     = 12
 VVDfKU     = 13
 VV5OFv     = 14
 VVpnTl      = 15
 VVVo4D      = 16
 VVj2zf      = 17
 VVDeR2      = 18
 VVqtuP      = 19
 VVmmwH    = 0
 VVrGBU   = 1
 VVwJHr   = 2
 VVOmtY   = 3
 VV7O0w  = 4
 VVfIfb  = 5
 VVBFzQ   = 6
 VV8igu   = 7
 VVhjgU  = 8
 VVY4ZD  = 9
 VVei9H  = 10
 VVqMfl = 0
 VVpo8R = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFdP4M(VVuQx7, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28, topRightBtns=1)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVkINB    = None
  self.tableTitle     = "IPTV Channels List"
  self.VV2QshData    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CCul6W.VVMJXK(atLeastOne=True)
  self.isFirstTime    = True
  self.curUrl      = ""
  CCbAHw.__init__(self)
  CCnY2W.__init__(self)
  VVgktg = self.VVijHM()
  FFj3mb(self, title="IPTV", VVgktg=VVgktg)
  self["myActionMap"].actions.update({
   "menu" : self.VVHAjA
  })
  self.onShown.append(self.VVgr8g)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VV6Mbl)
  global VV3m55
  VV3m55 = True
 def VVgr8g(self):
  self["myMenu"].setList(self.VVijHM())
  FF08xD(self)
  FFIl1A(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FFayJd(self["myMenu"])
   FF8Q9A(self)
   if self.m3uOrM3u8File:
    self.VVqQxu(self.m3uOrM3u8File)
   else:
    self.VVZkIt()
 def VVZkIt(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
  if "chCode" in decodedUrl:
   for ndx, item in enumerate(self["myMenu"].list):
    if item[0] == "IPTV Server Browser (from Current Channel)" and len(item) > 1:
     self["myMenu"].moveToIndex(ndx)
     break
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  FFTeQk("VV3m55")
 def VV6Mbl(self):
  if self["myMenu"].getCurrent()[1] in ("VVA3l0", "VV3GhHPortal") : self["keyMenu"].show()
  else                      : self["keyMenu"].hide()
 def VVHAjA(self):
  if self["myMenu"].getVisible():
   title, item = self["myMenu"].getCurrent()
   if   item == "VV3GhHPortal" : confItem = CFG.favServerPortal
   elif item == "VVA3l0" : confItem = CFG.favServerPlaylist
   else         : return
   FFDiGG(self, BF(self.VVb7FG, confItem), 'Remove from menu ?', title=title)
 def VVb7FG(self, confItem):
  FFeLB8(confItem, "")
  self.VVgr8g()
 def VVijHM(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VVeksK
  VVgktg = []
  if isFav1: VVgktg.append((c +  "Favourite Playlist Server"   , "VVA3l0" ))
  if isFav2: VVgktg.append((c +  "Favourite Portal Server"    , "VV3GhHPortal" ))
  VVgktg.append(("IPTV Server Browser (from Playlists)"     , "VV2Qsh_fromPlayList" ))
  VVgktg.append(("IPTV Server Browser (from Portal List)"    , "VV2Qsh_fromMac"  ))
  VVgktg.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VV2Qsh_fromM3u"  ))
  qUrl, iptvRef = CCul6W.VV9TTr(self)
  fromCurCond = qUrl or "chCode" in iptvRef
  VVgktg.append(FFVKGp("IPTV Server Browser (from Current Channel)", "VV2Qsh_fromCurrChan", fromCurCond))
  VVgktg.append(VVm7kE)
  VVgktg.append(("M3U/M3U8 File Browser"        , "VVd01H"   ))
  if self.iptvFileAvailable:
   VVgktg.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVgktg.append(VVm7kE)
  VVgktg.append(FFVKGp("Update Current Bouquet EPG (from IPTV Server)" , "refreshIptvEPG"  , fromCurCond))
  VVgktg.append(FFVKGp("Update Current Bouquet PIcons (from IPTV Server)" , "refreshIptvPicons", fromCurCond))
  if self.iptvFileAvailable:
   VVgktg.append(VVm7kE)
   c1, c2 = VVifMr, VVyz0j
   t1 = FF1YQ7("auto-match names", VVeksK)
   t2 = FF1YQ7("from xml file"  , VVeksK)
   VVgktg.append((c1 + "Count Available IPTV Channels"    , "VVZtmx"    ))
   VVgktg.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVgktg.append(VVm7kE)
   VVgktg.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVgktg.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VVfxsf" ))
   VVgktg.append((VVWgbP + "More Reference Tools ..."  , "VVaph9"   ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Reload Channels and Bouquets"       , "VVYF1I"   ))
  VVgktg.append(VVm7kE)
  if not CCfWgm.VV7SC7():
   VVgktg.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVgktg.append(("Download Manager ... No downloads"    ,       ))
  return VVgktg
 def VVBssi(self, item):
  self.curUrl = ""
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVHzP6"   : self.VVHzP6()
   elif item == "VVS3Ss" : FFDiGG(self, self.VVS3Ss, "Change Current List References to Unique Codes ?")
   elif item == "VVsa6l_rows" : FFDiGG(self, BF(FFkWFV, self.VVkINB, self.VVsa6l), "Change Current List References to Identical Codes ?")
   elif item == "VVPBqx"   : self.VVPBqx(tTitle)
   elif item == "VVvWUT"   : self.VVvWUT(tTitle)
   elif item == "VVA3l0" : self.VV3GhH(False)
   elif item == "VV3GhHPortal" : self.VV3GhH(True)
   elif item == "VV2Qsh_fromPlayList" : FFkWFV(self, BF(self.VVem8X, 1), title=title)
   elif item == "VV2Qsh_fromM3u"  : FFkWFV(self, BF(self.VVrqXC, CCul6W.VVqMfl), title=title)
   elif item == "VV2Qsh_fromMac"  : self.VVS51q()
   elif item == "VV2Qsh_fromCurrChan" : self.VVCTxp()
   elif item == "VVd01H"   : self.VVd01H()
   elif item == "iptvTable_all"   : FFkWFV(self, BF(self.VVTZdA, self.VVYg9T), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : CCul6W.VVLeg8(self)
   elif item == "refreshIptvPicons"  : self.VVPxkx()
   elif item == "VVZtmx"    : FFkWFV(self, self.VVZtmx)
   elif item == "copyEpgPicons"   : self.VVb27z(False)
   elif item == "renumIptvRef_fromFile" : self.VVb27z(True)
   elif item == "VVfxsf" : FFDiGG(self, BF(FFkWFV, self, self.VVfxsf), VVDdTB="Continue ?")
   elif item == "VVaph9"    : self.VVaph9()
   elif item == "VVYF1I"   : FFkWFV(self, BF(CCmfL4.VVYF1I, self))
   elif item == "dload_stat"    : CCfWgm.VVivnA(self)
 def VVd01H(self):
  if CCbAHw.VVGJKq(self):
   FFkWFV(self, BF(self.VVrqXC, CCul6W.VVpo8R), title="Searching ...")
 def VV96hS(self):
  global VVEyaB
  VVEyaB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVBssi(item)
 def VVTZdA(self, mode):
  VVUl7I = self.VVMqHo(mode)
  if VVUl7I:
   VVkY0R = ("Current Service", self.VVXwDk , [])
   VVW1zM = ("Options"  , self.VVyezt   , [])
   VVM4el = ("Filter"   , self.VVmdPp   , [])
   VVp0o5  = ("Play"   , BF(self.VVKZnR)  , [])
   VVq5Be = (""    , self.VV9CLm    , [])
   VVgDd7 = (""    , self.VVdN5Y     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VVwZxf  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FF69ky(self, None, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=26
     , VVp0o5=VVp0o5, VVkY0R=VVkY0R, VVW1zM=VVW1zM, VVM4el=VVM4el, VVq5Be=VVq5Be, VVgDd7=VVgDd7
     , VVrcFy="#0a00292B", VVZZ3c="#0a002126", VVRr4z="#0a002126", VVLwCQ="#00000000", VVFwVS=True, searchCol=1)
  else:
   if mode == self.VVPUa0: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFG2mq(self, err)
 def VVdN5Y(self, VVkINB, title, txt, colList):
  self.VVkINB = VVkINB
 def VVyezt(self, VVkINB, title, txt, colList):
  VVgktg = []
  VVgktg.append(("Add Current List to a New Bouquet"    , "VVHzP6"  ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Change Current List References to Unique Codes" , "VVS3Ss"))
  VVgktg.append(("Change Current List References to Identical Codes", "VVsa6l_rows" ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Share Reference with DVB Service (manual entry)" , "VVPBqx"   ))
  VVgktg.append(("Share Reference with DVB Service (auto-find)"  , "VVvWUT"   ))
  FFBqvZ(self, self.VVBssi, title="IPTV Tools", VVgktg=VVgktg)
 def VVmdPp(self, VVkINB, title, txt, colList):
  FFkWFV(VVkINB, BF(self.VVzK39, VVkINB))
 def VVzK39(self, VVkINB):
  VVgktg = []
  VVgktg.append(("All"         , "all"   ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Prefix of Selected Channel"   , "sameName" ))
  VVgktg.append(("Suggest Words from Selected Channel" , "partName" ))
  VVgktg.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVgktg.append(("Duplicate References"     , "depRef"  ))
  VVgktg.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVgktg.append(("Stream Relay"       , "SRelay"  ))
  VVgktg.append(FFZRMI("Category"))
  VVgktg.append(("Live TV"        , "live"  ))
  VVgktg.append(("VOD"         , "vod"   ))
  VVgktg.append(("Series"        , "series"  ))
  VVgktg.append(("Uncategorised"      , "uncat"  ))
  VVgktg.append(FFZRMI("Media"))
  VVgktg.append(("Video"        , "video"  ))
  VVgktg.append(("Audio"        , "audio"  ))
  VVgktg.append(FFZRMI("File Type"))
  VVgktg.append(("MKV"         , "MKV"   ))
  VVgktg.append(("MP4"         , "MP4"   ))
  VVgktg.append(("MP3"         , "MP3"   ))
  VVgktg.append(("AVI"         , "AVI"   ))
  VVgktg.append(("FLV"         , "FLV"   ))
  VVgktg.extend(CCMyrC.VVyIT7(prefix="__b__", onlyIptv=True))
  inFilterFnc = BF(self.VVSqCq, VVkINB) if VVkINB.VVZC2U().startswith("IPTV Filter ") else None
  filterObj = CCYFnw(self)
  filterObj.VVZvwW(VVgktg, VVgktg, BF(self.VVG8ig, VVkINB, False), inFilterFnc=inFilterFnc)
 def VVSqCq(self, VVkINB, VVVYOp, item):
  self.VVG8ig(VVkINB, True, item)
 def VVG8ig(self, VVkINB, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVkINB.VVRYeh(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVYg9T , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VV4oAS , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVotwV , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVlZTi , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVyeyp  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VVT0Fd  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "SRelay"   : mode, words, title = self.VVOyCk  , ""  , f + "= Stream Relay"
   elif item == "live"    : mode, words, title = self.VVPUa0  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVZbYS   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVHpuE  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVR4Y0  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVDfKU  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VV5OFv  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVpnTl   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVVo4D   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVj2zf   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVDeR2   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVqtuP   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVGK4X  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVYwYi  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVotwV:
   VVgktg = []
   chName = VVkINB.VVRYeh(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVgktg.append((item, item))
    if not VVgktg and chName:
     VVgktg.append((chName, chName))
    FFBqvZ(self, BF(self.VVsbj3, title), title="Words from Current Selection", VVgktg=VVgktg)
   else:
    VVkINB.VVpB4f("Invalid Channel Name")
  else:
   words, asPrefix = CCYFnw.VVt9Ew(words)
   if not words and mode in (self.VVGK4X, self.VVYwYi):
    FFpIgV(self.VVkINB, "Incorrect filter", 2000)
   else:
    FFkWFV(self.VVkINB, BF(self.VV6Bx0, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VVsbj3(self, title, word=None):
  if word:
   words = [word.lower()]
   FFkWFV(self.VVkINB, BF(self.VV6Bx0, self.VVotwV, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVYR2z(txt):
  return "#f#11ffff00#" + txt
 def VV6Bx0(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVUl7I = self.VVQ8s4(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVUl7I = self.VVMqHo(mode=mode, words=words, asPrefix=asPrefix)
  if VVUl7I : self.VVkINB.VVDqeT(VVUl7I, title)
  else  : self.VVkINB.VVpB4f("Not found")
 def VVQ8s4(self, mode=0, words=None, asPrefix=False):
  VVUl7I = []
  for row in self.VVkINB.VV3rlI():
   row = list(map(str.strip, row))
   chNum, chName, VVwjmO, chType, refCode, url = row
   if self.VVXXfp(mode, refCode, FFyEM8(url).lower(), chName, words, VVwjmO.lower(), asPrefix):
    VVUl7I.append(row)
  VVUl7I = self.VVRHmD(mode, VVUl7I)
  return VVUl7I
 def VVMqHo(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VVUl7I = []
  files = CCul6W.VVMJXK()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFSIRe(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVwjmO = span.group(1)
    else : VVwjmO = ""
    VVwjmO_lCase = VVwjmO.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVJyIw(chName): chNameMod = self.VVYR2z(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVwjmO, chType + (" SRel" if FFtvcx(url) else ""), refCode, url)
     if self.VVXXfp(mode, refCode, FFyEM8(url).lower(), chName, words, VVwjmO_lCase, asPrefix):
      VVUl7I.append(row)
      chNum += 1
  VVUl7I = self.VVRHmD(mode, VVUl7I)
  return VVUl7I
 def VVRHmD(self, mode, VVUl7I):
  newRows = []
  if VVUl7I and mode == self.VVyeyp:
   counted  = iCounter(elem[4] for elem in VVUl7I)
   for item in VVUl7I:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVUl7I
 def VVXXfp(self, mode, refCode, tUrl, chName, words, VVwjmO_lCase, asPrefix):
  if   mode == self.VVYg9T : return True
  elif mode == self.VVyeyp : return True
  elif mode == self.VVT0Fd  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VVOyCk : return FFtvcx(tUrl)
  elif mode == self.VVDfKU  : return CCul6W.VVuv9X(tUrl, getAudVid=True) == "vid"
  elif mode == self.VV5OFv  : return CCul6W.VVuv9X(tUrl, getAudVid=True) == "aud"
  elif mode == self.VVPUa0  : return CCul6W.VVuv9X(tUrl, compareType="live")
  elif mode == self.VVZbYS  : return CCul6W.VVuv9X(tUrl, compareType="movie")
  elif mode == self.VVHpuE : return CCul6W.VVuv9X(tUrl, compareType="series")
  elif mode == self.VVR4Y0  : return CCul6W.VVuv9X(tUrl, compareType="")
  elif mode == self.VVpnTl  : return CCul6W.VVuv9X(tUrl, compareExt="mkv")
  elif mode == self.VVVo4D  : return CCul6W.VVuv9X(tUrl, compareExt="mp4")
  elif mode == self.VVj2zf  : return CCul6W.VVuv9X(tUrl, compareExt="mp3")
  elif mode == self.VVDeR2  : return CCul6W.VVuv9X(tUrl, compareExt="avi")
  elif mode == self.VVqtuP  : return CCul6W.VVuv9X(tUrl, compareExt="flv")
  elif mode == self.VV4oAS: return chName.lower().startswith(words[0])
  elif mode == self.VVotwV: return words[0] in chName.lower()
  elif mode == self.VVlZTi: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVGK4X : return words[0] == VVwjmO_lCase
  elif mode == self.VVYwYi :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVHzP6(self):
  picker = CCMyrC(self, self.VVkINB, "Add to Bouquet", self.VVVGMG)
 def VVVGMG(self):
  chUrlLst = []
  for row in self.VVkINB.VV3rlI():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VVaph9(self):
  t1 = FF1YQ7("Bouquet" , VVyz0j)
  t2 = FF1YQ7("ALL"  , VVWgbP)
  t3 = FF1YQ7("Unique"  , VVifMr)
  t4 = FF1YQ7("Identical" , VVeksK)
  VVgktg = []
  VVgktg.append((VVo8aK + "Check System Acceptable Reference Types", "VVj2CR"))
  VVgktg.append(FFVKGp("Check Reference Codes Format", "VVrhuc", self.iptvFileAvailable, VVo8aK))
  VVgktg.append(VVm7kE)
  txt = "Change %s Ref. Types to (1/4097/5001/5002/8192/8193) .."
  VVgktg.append((txt % t1, "VVReC0" ))
  VVgktg.append((txt % t2, "VVD95C_all"  ))
  VVgktg.append(VVm7kE)
  txt = "Change %s References to %s Codes .."
  VVgktg.append((txt % (t1, t3), "VV3Rec" ))
  VVgktg.append((txt % (t2, t3), "VVpMWU"  ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Change %s References to %s Codes" % (t2, t4) , "VVsa6l_all"))
  VVl3Ru = self.VVybSC
  FFBqvZ(self, None, width=1150, title="IPTV Reference Tools", VVgktg=VVgktg, VVl3Ru=VVl3Ru, VVrcFy="#22002233", VVZZ3c="#22001122")
 def VVybSC(self, item=None):
  if item:
   ques = "Continue ?"
   VVVYOp, txt, item, ndx = item
   if   item == "VVj2CR"    : FFkWFV(VVVYOp, self.VVj2CR)
   elif item == "VVrhuc"     : FFkWFV(VVVYOp, self.VVrhuc)
   elif item == "VVReC0" : self.VVoRgu(VVVYOp, self.VVpLiP)
   elif item == "VVD95C_all"  : self.VVpLiP(VVVYOp, None, None)
   elif item == "VV3Rec" : self.VV3Rec(VVVYOp, txt)
   elif item == "VVpMWU"  : FFDiGG(self, BF(self.VVpMWU , VVVYOp, txt), title=txt, VVDdTB=ques)
   elif item == "VVsa6l_all"  : FFDiGG(self, BF(FFkWFV, VVVYOp, self.VVsa6l), title=txt, VVDdTB=ques)
 def VVpLiP(self, VVVYOp, bName, bPath):
  VVgktg = []
  for rt in CCul6W.VVEoQY():
   VVgktg.append(("%s\t ... %s" % (rt, CCul6W.VVtkH0(rt)), rt))
  FFBqvZ(self, BF(self.VV3uiu, VVVYOp, bName, bPath), VVgktg=VVgktg, width=800, title="Change Reference Types to:")
 def VV3uiu(self, VVVYOp, bName, bPath, rType=None):
  if rType:
   self.VVurle(VVVYOp, bName, bPath, rType)
 def VVoRgu(self, VVVYOp, fnc):
  VVgktg = CCMyrC.VVyIT7()
  if VVgktg:
   FFBqvZ(self, BF(self.VVoTPJ, VVVYOp, fnc), VVgktg=VVgktg, title="IPTV Bouquets", VVomDt=True)
  else:
   FFpIgV(VVVYOp, "No bouquets Found !", 1500)
 def VVoTPJ(self, VVVYOp, fnc, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVMixw + span.group(1)
    if fileExists(bPath): fnc(VVVYOp, bName, bPath)
    else    : FFpIgV(VVVYOp, "Bouquet file not found!", 2000)
   else:
    FFpIgV(VVVYOp, "Cannot process bouquet !", 2000)
 def VVurle(self, VVVYOp, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FF1YQ7(bName, VVChVP)
  else : title = "Change for %s" % FF1YQ7("All IPTV Services", VVChVP)
  FFDiGG(self, BF(FFkWFV, VVVYOp, BF(self.VVk8V3, VVVYOp, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FF1YQ7(rType, VVChVP), title=title)
 def VVk8V3(self, VVVYOp, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = CCul6W.VVMJXK()
  if files:
   newRType = rType + ":"
   piconPath = CCQVwA.VVzkHI()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CCyssW.VVfwhn(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FFG2mq(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           FFLgW2("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png"))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    FFLgW2(cmd)
  self.VVhD4b(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VVZtmx(self):
  totFiles = 0
  files  = CCul6W.VVMJXK()
  if files:
   totFiles = len(files)
  totChans = 0
  VVUl7I = self.VVMqHo()
  if VVUl7I:
   totChans = len(VVUl7I)
  FF8ShK(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVrhuc(self):
  files = CCul6W.VVMJXK()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFSIRe(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVNQoM
   else    : color = VVf8NN
   totInvalid = FF1YQ7(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FF1YQ7("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FF8ShK(self, txt, title="Check IPTV References")
 def VVj2CR(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = CCul6W.VVEoQY()
  chUrlLst = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CCMyrC.VVmRoE(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VVGnmK = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVGnmK:
   VVdY8S = FFanBk(VVGnmK)
   if VVdY8S:
    for service in VVdY8S:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVMixw + userBName
  bFile = VVMixw + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFhkCt("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += FFhkCt("rm -f '%s'" % path)
  FFLgW2(cmd)
  FFHpDz()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVNQoM
    else     : res, color = "No" , VVf8NN
    pl = CCul6W.VVtkH0(item)
    txt += "    %s\t: %s%s\n" % (item, FF1YQ7(res, color), FF1YQ7("\t... %s" % pl, VVdl3O) if pl else "")
   FF8ShK(self, txt, title=title)
  else:
   txt = FFG2mq(self, "Could not complete the test on your system!", title=title)
 def VVfxsf(self):
  VVN0xv, err = CCmfL4.VVwWVD(self, CCmfL4.VVZhkO)
  if VVN0xv:
   totChannels = 0
   totChange = 0
   for path in CCul6W.VVMJXK():
    toSave = False
    txt = FFSIRe(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVN0xv.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVhD4b(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFG2mq(self, 'No channels in "lamedb" !')
 def VVpMWU(self, VVVYOp, title):
  bFiles = CCul6W.VVMJXK()
  if bFiles: self.VVZXc8(bFiles, title)
  else  : FFpIgV(VVVYOp, "No bouquets files !", 1500)
 def VV3Rec(self, VVVYOp, title):
  self.VVoRgu(VVVYOp, BF(self.VVBq92, title))
 def VVBq92(self, title, VVVYOp, bName, bPath):
  self.VVZXc8([bPath], title)
 def VVZXc8(self, bFiles, title):
  self.session.open(CCKX0k, barTheme=CCKX0k.VVzy8h
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVF4MM, bFiles)
      , VVJ8mq = BF(self.VV1nUw, title))
 def VVF4MM(self, bFiles, VVzRAM):
  VVzRAM.VVgo83 = ""
  VVzRAM.VVyYoz("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FFjqdo(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVzRAM or VVzRAM.isCancelled:
   return
  elif not totLines:
   VVzRAM.VVgo83 = "No IPTV Services !"
   return
  else:
   VVzRAM.VVGeXq(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVzRAM or VVzRAM.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FFjqdo(path)
    for ndx, line in enumerate(lines):
     if not VVzRAM or VVzRAM.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVzRAM:
       VVzRAM.VVyYoz("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVzRAM:
       VVzRAM.VVu4eE(1)
      refCode, startId, startNS = CCMyrC.VVxXF4(rType, CCMyrC.VVtBB2, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVzRAM:
        VVzRAM.VVgo83 = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VV1nUw(self, title, VV4mF1, VVgo83, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VVgo83:
   txt += "\n\n%s\n%s" % (FF1YQ7("Ended with Error:", VVf8NN), VVgo83)
  self.VVhD4b(True, title, txt)
 def VVS3Ss(self):
  bFiles = CCul6W.VVMJXK()
  if not bFiles:
   FFpIgV(self.VVkINB, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVkINB.VV3rlI():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FFpIgV(self.VVkINB, "Cannot read list", 1500)
   return
  self.session.open(CCKX0k, barTheme=CCKX0k.VVzy8h
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVzQpE, bFiles, tableRefList)
      , VVJ8mq = BF(self.VV1nUw, "Change Current List References to Unique Codes"))
 def VVzQpE(self, bFiles, tableRefList, VVzRAM):
  VVzRAM.VVgo83 = ""
  VVzRAM.VVyYoz("Reading System References ...")
  refLst = CCMyrC.VVSnUF(CCMyrC.VVtBB2, stripRType=True)
  if not VVzRAM or VVzRAM.isCancelled:
   return
  VVzRAM.VVGeXq(len(tableRefList))
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVzRAM or VVzRAM.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFSIRe(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVzRAM or VVzRAM.isCancelled:
     return
    VVzRAM.VVyYoz("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVzRAM or VVzRAM.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVzRAM.VVu4eE(1)
      refCode, startId, startNS = CCMyrC.VVxXF4(rType, CCMyrC.VVtBB2, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVzRAM:
        VVzRAM.VVgo83 = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VVsa6l(self):
  list = None
  if self.VVkINB:
   list = []
   for row in self.VVkINB.VV3rlI():
    list.append(row[4] + row[5])
  files = CCul6W.VVMJXK()
  totChange = 0
  if files:
   for path in files:
    lines = FFjqdo(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VVhD4b(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVhD4b(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFHpDz()
   if refreshTable and self.VVkINB:
    VVUl7I = self.VVMqHo()
    if VVUl7I and self.VVkINB:
     self.VVkINB.VVDqeT(VVUl7I, self.tableTitle)
     self.VVkINB.VVpB4f(txt)
   FF8ShK(self, txt, title=title)
  else:
   FF27fq(self, "No changes.")
 @staticmethod
 def VVMJXK(atLeastOne=False, onlyFileName=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVMixw + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFSIRe(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(os.path.basename(path) if onlyFileName else path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VV9CLm(self, VVkINB, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFyEM8(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFPrkv(self, fncMode=CCXzVR.VV4myO, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVfdQN(self, VVkINB, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVKZnR(self, VVkINB, title, txt, colList):
  chName, chUrl = self.VVfdQN(VVkINB, colList)
  self.VV9tUL(VVkINB, chName, chUrl, "localIptv")
 def VV5lIf(self, mode, VVkINB, colList):
  chName, chUrl, picUrl, refCode = self.VVKWZ5(mode, colList)
  return chName, chUrl
 def VVZMsS(self, mode, VVkINB, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVKWZ5(mode, colList)
  self.VV9tUL(VVkINB, chName, chUrl, mode)
 def VV9tUL(self, VVkINB, chName, chUrl, playerFlag):
  chName = FFOD7l(chName)
  if self.VVJyIw(chName):
   FFpIgV(VVkINB, "This is a marker!", 300)
  else:
   FFkWFV(VVkINB, BF(self.VVdqee, VVkINB, chUrl, playerFlag), title="Playing ...")
 def VVdqee(self, VVkINB, chUrl, playerFlag):
  FFWpQx(self, chUrl, VVxOHd=False)
  CCppT7.VVkxsS(self.session, iptvTableParams=(self, VVkINB, playerFlag))
 @staticmethod
 def VVJyIw(chName):
  mark = ("--", "__", "==", "##",  "**", str(u"\u2605" * 2))
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVXwDk(self, VVkINB, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
  if refCode:
   url1 = FFyEM8(origUrl.strip())
   for ndx, row in enumerate(VVkINB.VV3rlI()):
    if refCode in row[4]:
     tableRow = FFyEM8(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVkINB.VV2NBO(ndx)
      break
   else:
    FFpIgV(VVkINB, "No found", 1000)
 def VVrqXC(self, m3uMode):
  lines = self.VVHd53(3)
  if lines:
   lines.sort()
   VVgktg = []
   for line in lines:
    VVgktg.append((line, line))
   if m3uMode == CCul6W.VVqMfl:
    title = "Browse Server from M3U URLs"
    VV2qPD = ("All to Playlist", self.VVwXrq)
   else:
    title = "M3U/M3U8 File Browser"
    VV2qPD = None
   VVl3Ru = BF(self.VVxh1w, m3uMode, title)
   VVdi3l = self.VV3xEt
   FFBqvZ(self, None, title=title, VVgktg=VVgktg, width=1200, VVl3Ru=VVl3Ru, VVdi3l=VVdi3l, VVfXMZ="", VV2qPD=VV2qPD, VVrcFy="#11221122", VVZZ3c="#11221122")
 def VVxh1w(self, m3uMode, title, item=None):
  if item:
   VVVYOp, txt, path, ndx = item
   if m3uMode == CCul6W.VVqMfl:
    FFkWFV(VVVYOp, BF(self.VVVWoq, title, path))
   else:
    FFkWFV(VVVYOp, BF(self.VVqQxu, path))
 def VVqQxu(self, path, m3uFilterParam=None, VVkINB=None):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(path))[0]
  txt = FFSIRe(path)
  span = iSearch(r"#EXTINF:.+\n(.+)\n.+", txt, IGNORECASE)
  if span:
   self.curUrl = span.group(1)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  groups = []
  mode, words, asPrefix, fTitle = m3uFilterParam or (0, (), False, "")
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVfykd(propLine, "group-title") or "-"
   if not group == "-" and self.VVy0Lv(group):
    if not chName or self.VVNobF(chName):
     if self.VVXXfp(mode, "", url.lower(), chName, words, "", asPrefix):
      groups.append(group)
  VVUl7I = []
  if groups:
   totAll = 0
   for name, tot in iCounter(groups).items():
    VVUl7I.append((name, str(tot), name))
    totAll += tot
   VVUl7I.sort(key=lambda x: x[0].lower())
   VVUl7I.insert(0, ("ALL", str(totAll), ""))
  if VVUl7I:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   if VVkINB:
    VVkINB.VVDqeT(VVUl7I, newTitle=title, VVc63JMsg=True)
   else:
    VVIcAB = self.VVc4GY
    VVp0o5  = ("Select" , BF(self.VVu4dX, path, m3uFilterParam)  , [])
    VVM4el = ("Filter" , BF(self.VVMLEk, path, m3uFilterParam), [])
    header   = ("Group" , "Total" , "grp" )
    widths   = (85  , 15  , 0  )
    VVwZxf  = (LEFT  , CENTER , LEFT )
    FF69ky(self, None, title=title, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, width= 1400, height= 1000, VVvi36=28, VVp0o5=VVp0o5, VVM4el=VVM4el, VVIcAB=VVIcAB, lastFindConfigObj=CFG.lastFindIptv
      , VVrcFy="#11110022", VVZZ3c="#11110022", VVRr4z="#11110022", VVLwCQ="#00444400")
  elif VVkINB:
   FFrKlA(VVkINB, "Not found !", 1500)
  else:
   self.VVuSrw(FFSIRe(path), "", m3uFilterParam)
 def VVu4dX(self, path, m3uFilterParam, VVkINB, title, txt, colList):
  self.VVuSrw(FFSIRe(path), colList[2], m3uFilterParam)
 def VVMLEk(self, path, m3uFilterParam, VVkINB, title, txt, colList):
  VVgktg = []
  VVgktg.append(("All"      , "all"  ))
  VVgktg.append(FFZRMI("Category"))
  VVgktg.append(("Live TV"     , "live" ))
  VVgktg.append(("VOD"      , "vod"  ))
  VVgktg.append(("Series"     , "series" ))
  VVgktg.append(("Uncategorised"   , "uncat" ))
  VVgktg.append(FFZRMI("Media"))
  VVgktg.append(("Video"     , "video" ))
  VVgktg.append(("Audio"     , "audio" ))
  VVgktg.append(FFZRMI("File Type"))
  VVgktg.append(("MKV"      , "MKV"  ))
  VVgktg.append(("MP4"      , "MP4"  ))
  VVgktg.append(("MP3"      , "MP3"  ))
  VVgktg.append(("AVI"      , "AVI"  ))
  VVgktg.append(("FLV"      , "FLV"  ))
  filterObj = CCYFnw(self, VVrcFy="#11332244", VVZZ3c="#11222244")
  filterObj.VVZvwW(VVgktg, [], BF(self.VVcbXF, VVkINB, path), inFilterFnc=None)
 def VVcbXF(self, VVkINB, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VVYg9T , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VVPUa0  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VVZbYS  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VVHpuE  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VVR4Y0  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VVDfKU  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VV5OFv  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VVpnTl  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VVVo4D  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VVj2zf  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVDeR2  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VVqtuP  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVYwYi  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CCYFnw.VVt9Ew(words)
   if not mode == self.VVYg9T:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FF1YQ7(fTitle, VVdl3O)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FFkWFV(VVkINB, BF(self.VVqQxu, path, m3uFilterParam, VVkINB), title="Filtering ...")
 def VVuSrw(self, txt, filterGroup="", m3uFilterParam=None):
  lst   = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CCKX0k, barTheme=CCKX0k.VVfjb8
       , titlePrefix = "Reading File Lines", endTitle="Loading channels ..."
       , fncToRun  = BF(self.VVHZtF, lst, filterGroup, m3uFilterParam)
       , VVJ8mq = BF(self.VV36ZM, title, bName))
  else:
   self.VV1C0S("No valid lines found !", title)
 def VVHZtF(self, lst, filterGroup, m3uFilterParam, VVzRAM):
  VVzRAM.VVgo83 = []
  VVzRAM.VVGeXq(len(lst))
  num = 0
  for cols in lst:
   if not VVzRAM or VVzRAM.isCancelled:
    return
   VVzRAM.VVu4eE(1, True)
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVfykd(propLine, "group-title") or "-"
   picon = self.VVfykd(propLine, "tvg-logo")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not self.VVy0Lv(group) : skip = True
    elif chName and not self.VVNobF(chName)   : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VVXXfp(mode, "", FFyEM8(url).lower(), chName, words, "", asPrefix)
    if not skip and VVzRAM:
     num += 1
     VVzRAM.VVgo83.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
 def VV36ZM(self, title, bName, VV4mF1, VVgo83, threadCounter, threadTotal, threadErr):
  if VVgo83:
   VVIcAB = self.VVc4GY
   VVp0o5  = ("Select"   , BF(self.VVJHx5, title)   , [])
   VVq5Be = (""    , self.VVafQa        , [])
   VVkY0R = ("Download PIcons", self.VV1b6T       , [])
   VVW1zM = ("Options"  , BF(self.VVl0R4, "m3Ch", "", bName) , [])
   VVM4el = ("Posters Mode" , BF(self.VVc0ii, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVwZxf  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FF69ky(self, None, title=title, header=header, VV9gTz=VVgo83, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=28, VVp0o5=VVp0o5, VVIcAB=VVIcAB, VVq5Be=VVq5Be, VVkY0R=VVkY0R, VVW1zM=VVW1zM, VVM4el=VVM4el, lastFindConfigObj=CFG.lastFindIptv, VVFwVS=True, searchCol=1
     , VVrcFy="#0a00192B", VVZZ3c="#0a00192B", VVRr4z="#0a00192B", VVLwCQ="#00000000")
  else:
   self.VV1C0S("Not found !", title)
 def VV1b6T(self, VVkINB, title, txt, colList):
  self.VV4jXr(VVkINB, "m3u/m3u8")
 def VVnqG1(self, rowNum, url, chName):
  refCode = self.VVex6x(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFP4cn(url), chName)
  return chUrl
 def VVex6x(self, rowNum, url, chName):
  fName = os.path.basename(url)
  catID = "333"
  stID  =  "444"
  if fName:
   num = os.path.splitext(fName)[0]
   if num.isdigit() and int(num) < 0xeeee0000:
    stID = num
  chNum = str(rowNum + 1)
  refCode = self.VVOCPv(catID, stID, chNum)
  return refCode
 def VVfykd(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVJHx5(self, Title, VVkINB, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFkWFV(VVkINB, BF(self.VVonj1, Title, VVkINB, colList), title="Checking Server ...")
  else:
   self.VVOrYv(VVkINB, url, chName)
 def VVonj1(self, title, VVkINB, colList):
  if not CCbAHw.VVGJKq(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCwoYk.VVZkcb(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVgktg = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCul6W.VVZqsK(url, fPath)
     VVgktg.append((resol, fullUrl))
    if VVgktg:
     if len(VVgktg) > 1:
      FFBqvZ(self, BF(self.VVW1gf, VVkINB, chName), VVgktg=VVgktg, title="Resolution", VVomDt=True, VVRHyh=True)
     else:
      self.VVOrYv(VVkINB, VVgktg[0][1], chName)
    else:
     span = iSearch(r"(http.+)", txt, IGNORECASE)
     if span:
      self.VVOrYv(VVkINB, span.group(1), chName)
     else:
      span = iSearch(r"#EXT-X-STREAM-INF.*\n(.+)", txt, IGNORECASE)
      if span:
       fullUrl = CCul6W.VVZqsK(url, span.group(1))
       self.VVOrYv(VVkINB, fullUrl, chName)
      else:
       self.VVr3Eu("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVuSrw(txt, filterGroup="")
      return
    self.VVOrYv(VVkINB, url, chName)
   else:
    self.VV1C0S("Cannot process this channel !", title)
  else:
   self.VV1C0S(err, title)
 def VVW1gf(self, VVkINB, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVOrYv(VVkINB, resolUrl, chName)
 def VVOrYv(self, VVkINB, url, chName):
  FFkWFV(VVkINB, BF(self.VVfij4, VVkINB, url, chName), title="Playing ...")
 def VVfij4(self, VVkINB, url, chName):
  chUrl = self.VVnqG1(VVkINB.VVnbBC(), url, chName)
  FFWpQx(self, chUrl, VVxOHd=False)
  CCppT7.VVkxsS(self.session, iptvTableParams=(self, VVkINB, "m3u/m3u8"))
 def VVdNgx(self, VVkINB, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVnqG1(VVkINB.VVnbBC(), url, chName)
  return chName, chUrl
 def VVafQa(self, VVkINB, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFPrkv(self, fncMode=CCXzVR.VV4myO, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VV1C0S(self, err, title):
  FFG2mq(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVc4GY(self, VVkINB):
  if self.m3uOrM3u8File:
   self.close()
  VVkINB.cancel()
 def VVwXrq(self, selectionObj, item=None):
  FFkWFV(selectionObj, BF(self.VVPitd, selectionObj, item))
 def VVPitd(self, selectionObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(selectionObj.VVgktg):
    path = item[1]
    if fileExists(path):
     enc = CCmJil.VVm967(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = CCul6W.VVdhYz(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCul6W.VV55YY()
    pListF = "%sPlaylist_%s.txt" % (path, FF4Fnb())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(selectionObj.VVgktg)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FF8ShK(self, txt, title=title)
   else:
    FFG2mq(self, "Could not obtain URLs from this file list !", title=title)
 def VVem8X(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VVc3y9
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VVVMyW
  lines = self.VVHd53(mode)
  if lines:
   lines.sort()
   VVgktg = []
   for line in lines:
    VVgktg.append((FF1YQ7(line, VVyz0j) if "Bookmarks" in line else line, line))
   VVdi3l = self.VV3xEt
   FFBqvZ(self, None, title=title, VVgktg=VVgktg, width=1200, VVl3Ru=okFnc, VVdi3l=VVdi3l, VVfXMZ="")
 def VV3xEt(self, VVVYOp, txt, ref, ndx):
  txt = ref
  sz = FF1fFq(ref)
  if sz > 0:
   txt += "\n\nSize: %s" % CCyssW.VV1ctA(sz)
  FF8ShK(self, txt, title="File Path")
 def VVc3y9(self, item=None):
  if item:
   VVVYOp, txt, path, ndx = item
   FFkWFV(VVVYOp, BF(self.VVJV9B, VVVYOp, path), title="Processing File ...")
 def VVJV9B(self, VVvV6x, path):
  enc = CCmJil.VVm967(path, self)
  if enc == -1:
   return
  VVUl7I = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFGa2t(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCul6W.VVmXX1(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVUl7I:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVUl7I.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVUl7I:
   title = "Playlist File : %s" % os.path.basename(path)
   VVp0o5  = ("Start"    , BF(self.VVeWrm, "Playlist File")      , [])
   VVcNot = ("Home Menu"   , FFcTP7             , [])
   VVkY0R = ("Download M3U File" , self.VVqkye         , [])
   VVW1zM = ("Edit File"   , BF(self.VVC6Pa, path)        , [])
   VVM4el = ("Check & Filter"  , BF(self.VVXler, VVvV6x, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVwZxf  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FF69ky(self, None, title=title, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=26, VVp0o5=VVp0o5, VVcNot=VVcNot, VVM4el=VVM4el, VVkY0R=VVkY0R, VVW1zM=VVW1zM, VVrcFy="#11001116", VVZZ3c="#11001116", VVRr4z="#11001116", VVLwCQ="#00003635", VVhvzQ="#0a333333", VVEjwd="#11331100", VVFwVS=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FFG2mq(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVqkye(self, VVkINB, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFDiGG(self, BF(FFkWFV, VVkINB, BF(self.VVLYwV, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVLYwV(self, title, url):
  path, err = FFq7bz(url, "ajp_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFG2mq(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFSIRe(path)
   if '{"user_info":{"auth":0}}' in txt:
    FFMc8G(path)
    FFG2mq(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FFMc8G(path)
    FFG2mq(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCul6W.VV55YY() + fName
    FFLgW2("mv -f '%s' '%s'" % (path, newPath))
    if fileExists(newPath):
     path = newPath
    FF27fq(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFG2mq(self, "Could not download the M3U file!", title=errTitle)
 def VVeWrm(self, Title, VVkINB, title, txt, colList):
  url = colList[6]
  FFkWFV(VVkINB, BF(self.VVhut5, Title, url), title="Checking Server ...")
 def VVC6Pa(self, path, VVkINB, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CC0TyL(self, path, VVJ8mq=BF(self.VVkOTi, VVkINB), curRowNum=rowNum)
  else    : FFcMQr(self, path)
 def VVkOTi(self, VVkINB, fileChanged):
  if fileChanged:
   VVkINB.cancel()
 def VVPBqx(self, title):
  curChName = self.VVkINB.VVRYeh(1)
  FF8ISk(self, BF(self.VVV6lm, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVV6lm(self, title, name):
  if name:
   VVN0xv, err = CCmfL4.VVwWVD(self, CCmfL4.VVvknG, VV1Nw8=False, VVoFHD=False)
   list = []
   if VVN0xv:
    name = self.VVP5Ly(name)
    ratio = "1"
    for item in VVN0xv:
     if name in item[0].lower():
      list.append((item[0], FFDSYZ(item[2]), item[3], ratio))
   if list : self.VVRJAz(list, title)
   else : FFG2mq(self, "Not found:\n\n%s" % name, title=title)
 def VVvWUT(self, title):
  curChName = self.VVkINB.VVRYeh(1)
  self.session.open(CCKX0k, barTheme=CCKX0k.VVfjb8
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVa6Q7
      , VVJ8mq = BF(self.VVFYhj, title, curChName))
 def VVa6Q7(self, VVzRAM):
  curChName = self.VVkINB.VVRYeh(1)
  VVN0xv, err = CCmfL4.VVwWVD(self, CCmfL4.VVQkKK, VV1Nw8=False, VVoFHD=False)
  if not VVN0xv or not VVzRAM or VVzRAM.isCancelled:
   return
  VVzRAM.VVgo83 = []
  VVzRAM.VVGeXq(len(VVN0xv))
  curCh = self.VVP5Ly(curChName)
  for refCode in VVN0xv:
   chName, sat, inDB = VVN0xv.get(refCode, ("", "", 0))
   ratio = CCQVwA.VVrcfj(chName.lower(), curCh)
   if not VVzRAM or VVzRAM.isCancelled:
    return
   VVzRAM.VVu4eE(1, True)
   if VVzRAM and ratio > 50:
    VVzRAM.VVgo83.append((chName, FFDSYZ(sat), refCode.replace("_", ":"), str(ratio)))
 def VVFYhj(self, title, curChName, VV4mF1, VVgo83, threadCounter, threadTotal, threadErr):
  if VVgo83: self.VVRJAz(VVgo83, title)
  elif VV4mF1: FFG2mq(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVRJAz(self, VVUl7I, title):
  curChName = self.VVkINB.VVRYeh(1)
  VVrI2w = self.VVkINB.VVRYeh(4)
  curUrl  = self.VVkINB.VVRYeh(5)
  VVUl7I.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVp0o5  = ("Share Sat/C/T Ref.", BF(self.VVHcIo, title, curChName, VVrI2w, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FF69ky(self, None, title=title, header=header, VV9gTz=VVUl7I, VVYiuZ=widths, VVvi36=26, VVp0o5=VVp0o5, VVrcFy="#0a00112B", VVZZ3c="#0a001126", VVRr4z="#0a001126", VVLwCQ="#00000000")
 def VVHcIo(self, newtitle, curChName, VVrI2w, curUrl, VVkINB, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVrI2w, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFDiGG(self.VVkINB, BF(FFkWFV, self.VVkINB, BF(self.VVrO5X, VVkINB, data)), ques, title=newtitle, VVm2Fj=True)
 def VVrO5X(self, VVkINB, data):
  VVkINB.cancel()
  title, curChName, VVrI2w, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVrI2w = VVrI2w.strip()
  newRefCode = newRefCode.strip()
  if not VVrI2w.endswith(":") : VVrI2w += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVrI2w, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVrI2w + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in CCul6W.VVMJXK():
    txt = FFSIRe(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFHpDz()
    newRow = []
    for i in range(6):
     newRow.append(self.VVkINB.VVRYeh(i))
    newRow[4] = newRefCode
    done = self.VVkINB.VVrgU7(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFLYGh(BF(FF27fq , self, resTxt, title=title))
  elif resErr: FFLYGh(BF(FFG2mq, self, resErr, title=title))
 def VVXler(self, VVvV6x, path, VVkINB, title, txt, colList):
  self.session.open(CCKX0k, barTheme=CCKX0k.VVzy8h
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVJ9uj, VVkINB)
      , VVJ8mq = BF(self.VVgouk, VVvV6x, path, VVkINB))
 def VVJ9uj(self, VVkINB, VVzRAM):
  VVzRAM.VVGeXq(VVkINB.VVgq7g())
  VVzRAM.VVgo83 = []
  for row in VVkINB.VV3rlI():
   if not VVzRAM or VVzRAM.isCancelled:
    return
   VVzRAM.VVu4eE(1, True)
   qUrl = self.VV5Wrq(self.VVmmwH, row[6])
   txt, err = self.VVbwRu(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVaXRJ(item, "auth") == "0":
       VVzRAM.VVgo83.append(qUrl)
    except:
     pass
 def VVgouk(self, VVvV6x, path, VVkINB, VV4mF1, VVgo83, threadCounter, threadTotal, threadErr):
  if VV4mF1:
   list = VVgo83
   title = "Authorized Servers"
   if list:
    totChk = VVkINB.VVgq7g()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FF4Fnb()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVem8X(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FF1YQ7(str(totAuth), VVNQoM)
     txt += "%s\n\n%s"    %  (FF1YQ7("Result File:", VVyz0j), newPath)
     FF8ShK(self, txt, title=title)
     VVkINB.close()
     VVvV6x.close()
    else:
     FF27fq(self, "All URLs are authorized.", title=title)
   else:
    FFG2mq(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVbwRu(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVmXX1(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVuv9X(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CC7kl8.VVBUKY()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VVH60n(decodedUrl):
  return CCul6W.VVuv9X(decodedUrl, justRetDotExt=True)
 def VV5Wrq(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVmXX1(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVmmwH   : return "%s"            % url
  elif mode == self.VVrGBU   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVwJHr   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVOmtY  : return "%s&action=get_series_categories"     % url
  elif mode == self.VV7O0w  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVfIfb : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVBFzQ   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VV8igu    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVhjgU  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVei9H : return "%s&action=get_live_streams"      % url
  elif mode == self.VVY4ZD  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVaXRJ(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFPuhT(int(val))
    elif is_base64 : val = FF3BMa(val)
    elif isToHHMMSS : val = FFGcFN(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVVWoq(self, title, path):
  if fileExists(path):
   enc = CCmJil.VVm967(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = CCul6W.VVdhYz(line)
     if qUrl:
      break
   if qUrl : self.VVhut5(title, qUrl)
   else : FFG2mq(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFG2mq(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVCTxp(self):
  title = "Current Channel Server"
  qUrl, iptvRef = CCul6W.VV9TTr(self)
  if qUrl or "chCode" in iptvRef:
   p = CCwoYk()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVDj8z(iptvRef)
   if valid:
    self.VVc65h(self, host, mac)
    return
   elif qUrl:
    FFkWFV(self, BF(self.VVhut5, title, qUrl), title="Checking Server ...")
    return
  FFG2mq(self, "Error in current channel URL !", title=title)
 @staticmethod
 def VV9TTr(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(SELF)
  qUrl = CCul6W.VVdhYz(decodedUrl)
  return qUrl, iptvRef
 @staticmethod
 def VVdhYz(url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVhut5(self, title, url):
  self.curUrl = url
  self.VV2QshData = {}
  qUrl = self.VV5Wrq(self.VVmmwH, url)
  txt, err = self.VVbwRu(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VV2QshData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VV2QshData["username"    ] = self.VVaXRJ(item, "username"        )
    self.VV2QshData["password"    ] = self.VVaXRJ(item, "password"        )
    self.VV2QshData["message"    ] = self.VVaXRJ(item, "message"        )
    self.VV2QshData["auth"     ] = self.VVaXRJ(item, "auth"         )
    self.VV2QshData["status"    ] = self.VVaXRJ(item, "status"        )
    self.VV2QshData["exp_date"    ] = self.VVaXRJ(item, "exp_date"    , isDate=True )
    self.VV2QshData["is_trial"    ] = self.VVaXRJ(item, "is_trial"        )
    self.VV2QshData["active_cons"   ] = self.VVaXRJ(item, "active_cons"       )
    self.VV2QshData["created_at"   ] = self.VVaXRJ(item, "created_at"   , isDate=True )
    self.VV2QshData["max_connections"  ] = self.VVaXRJ(item, "max_connections"      )
    self.VV2QshData["allowed_output_formats"] = self.VVaXRJ(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VV2QshData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VV2QshData["url"    ] = self.VVaXRJ(item, "url"        )
    self.VV2QshData["port"    ] = self.VVaXRJ(item, "port"        )
    self.VV2QshData["https_port"  ] = self.VVaXRJ(item, "https_port"      )
    self.VV2QshData["server_protocol" ] = self.VVaXRJ(item, "server_protocol"     )
    self.VV2QshData["rtmp_port"   ] = self.VVaXRJ(item, "rtmp_port"       )
    self.VV2QshData["timezone"   ] = self.VVaXRJ(item, "timezone"       )
    self.VV2QshData["timestamp_now"  ] = self.VVaXRJ(item, "timestamp_now"  , isDate=True )
    self.VV2QshData["time_now"   ] = self.VVaXRJ(item, "time_now"       )
    VVgktg  = self.VV54VK(True)
    VVl3Ru = self.VV6K5h
    VVdi3l = self.VVxEsN
    VVqafJ = ("Home Menu", FFcTP7)
    VVG0eT= ("Add to Menu", BF(CCul6W.VVPPGS, self, False, self.VV2QshData["playListURL"]))
    VV2qPD = ("Bookmark Server", BF(CCul6W.VVtuDc, self, False, self.VV2QshData["playListURL"]))
    FFBqvZ(self, None, title="IPTV Server Resources", VVgktg=VVgktg, VVl3Ru=VVl3Ru, VVdi3l=VVdi3l, VVqafJ=VVqafJ, VVG0eT=VVG0eT, VV2qPD=VV2qPD)
   else:
    err = "Could not get data from server !"
  if err:
   FFG2mq(self, err, title=title)
  FFpIgV(self)
 def VV6K5h(self, item=None):
  if item:
   VVVYOp, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFkWFV(VVVYOp, BF(self.VVNny0, self.VVrGBU  , title=title), title=wTxt)
   elif ref == "vod"   : FFkWFV(VVVYOp, BF(self.VVNny0, self.VVwJHr  , title=title), title=wTxt)
   elif ref == "series"  : FFkWFV(VVVYOp, BF(self.VVNny0, self.VVOmtY , title=title), title=wTxt)
   elif ref == "catchup"  : FFkWFV(VVVYOp, BF(self.VVNny0, self.VV7O0w , title=title), title=wTxt)
   elif ref == "accountInfo" : FFkWFV(VVVYOp, BF(self.VVcCco           , title=title), title=wTxt)
 def VVxEsN(self, VVVYOp, txt, ref, ndx):
  FFkWFV(VVVYOp, self.VVzba6)
 def VVzba6(self):
  txt = self.curUrl
  if VVxrH7:
   ver, err = self.VV19Tl(self.VVPD6z())
   txt += "\n\n"
   txt += "Original\t: %s\n" % self.curUrl
   txt += "Modified\t: %s\n" % self.VVFIuc
   txt += "PHP\t: %s\n"  % self.VVbURL
   txt += "Extra\t: %s\n"  % {2:"Big", 3:"Sml"}.get(self.VVXbqE, "-")
   txt += "Version\t: %s"  % (ver or err)
  FF8ShK(self, txt, title="Current Server URL")
 def VVcCco(self, title):
  rows = []
  for key, val in self.VV2QshData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VVQ6Km
   else:
    num, part = "1", self.VVsJBI
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVcNot  = ("Home Menu", FFcTP7, [])
  VVkY0R  = None
  if VVxrH7:
   VVkY0R = ("Get JS" , BF(self.VVL3c7, "/".join(self.VV2QshData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FF69ky(self, None, title=title, width=1200, header=header, VV9gTz=rows, VVYiuZ=widths, VVvi36=26, VVcNot=VVcNot, VVkY0R=VVkY0R, VVrcFy="#0a00292B", VVZZ3c="#0a002126", VVRr4z="#0a002126", VVLwCQ="#00000000", searchCol=2)
 def VVKDjE(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    if mode in (self.VVBFzQ, self.VVY4ZD):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVaXRJ(item, "num"         )
      name     = self.VVaXRJ(item, "name"        )
      stream_id    = self.VVaXRJ(item, "stream_id"       )
      stream_icon    = self.VVaXRJ(item, "stream_icon"       )
      epg_channel_id   = self.VVaXRJ(item, "epg_channel_id"      )
      added     = self.VVaXRJ(item, "added"    , isDate=True )
      is_adult    = self.VVaXRJ(item, "is_adult"       )
      category_id    = self.VVaXRJ(item, "category_id"       )
      tv_archive    = self.VVaXRJ(item, "tv_archive"       )
      direct_source   = self.VVaXRJ(item, "direct_source"      )
      tv_archive_duration  = self.VVaXRJ(item, "tv_archive_duration"     )
      name = self.VVNobF(name, is_adult)
      if name:
       if mode == self.VVBFzQ or mode == self.VVY4ZD and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VV8igu:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVaXRJ(item, "num"         )
      name    = self.VVaXRJ(item, "name"        )
      stream_id   = self.VVaXRJ(item, "stream_id"       )
      stream_icon   = self.VVaXRJ(item, "stream_icon"       )
      added    = self.VVaXRJ(item, "added"    , isDate=True )
      is_adult   = self.VVaXRJ(item, "is_adult"       )
      category_id   = self.VVaXRJ(item, "category_id"       )
      container_extension = self.VVaXRJ(item, "container_extension"     ) or "mp4"
      name = self.VVNobF(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VVhjgU:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVaXRJ(item, "num"        )
      name    = self.VVaXRJ(item, "name"       )
      series_id   = self.VVaXRJ(item, "series_id"      )
      cover    = self.VVaXRJ(item, "cover"       )
      genre    = self.VVaXRJ(item, "genre"       )
      episode_run_time = self.VVaXRJ(item, "episode_run_time"    )
      category_id   = self.VVaXRJ(item, "category_id"      )
      container_extension = self.VVaXRJ(item, "container_extension"    ) or "mp4"
      name = self.VVNobF(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVNny0(self, mode, title):
  cList, err = self.VVDv1C(mode)
  if cList and mode == self.VV7O0w:
   cList = self.VVuBoM(cList)
  if err:
   FFG2mq(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVrcFy, VVZZ3c, VVRr4z, VVLwCQ = self.VVxwoR(mode)
   mName = self.VVNX3j(mode)
   if   mode == self.VVrGBU  : fMode = self.VVBFzQ
   elif mode == self.VVwJHr  : fMode = self.VV8igu
   elif mode == self.VVOmtY : fMode = self.VVhjgU
   elif mode == self.VV7O0w : fMode = self.VVY4ZD
   if mode == self.VV7O0w:
    VVW1zM = None
    VVM4el = None
   else:
    VVW1zM = ("Find in %s" % mName , BF(self.VV719T, fMode, True) , [])
    VVM4el = ("Find in Selected" , BF(self.VV719T, fMode, False) , [])
   VVp0o5   = ("Show List"   , BF(self.VVAc0L, mode)  , [])
   VVcNot  = ("Home Menu"   , FFcTP7         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FF69ky(self, None, title=title, width=1200, header=header, VV9gTz=cList, VVYiuZ=widths, VVvi36=30, VVcNot=VVcNot, VVW1zM=VVW1zM, VVM4el=VVM4el, VVp0o5=VVp0o5, VVrcFy=VVrcFy, VVZZ3c=VVZZ3c, VVRr4z=VVRr4z, VVLwCQ=VVLwCQ, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFG2mq(self, "No list from server !", title=title)
  FFpIgV(self)
 def VVDv1C(self, mode):
  qUrl  = self.VV5Wrq(mode, self.VV2QshData["playListURL"])
  txt, err = self.VVbwRu(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    for item in tDict:
     category_id  = self.VVaXRJ(item, "category_id"  )
     category_name = self.VVaXRJ(item, "category_name" )
     parent_id  = self.VVaXRJ(item, "parent_id"  )
     category_name = self.VVy0Lv(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVuBoM(self, catList):
  mode  = self.VVY4ZD
  qUrl  = self.VV5Wrq(mode, self.VV2QshData["playListURL"])
  txt, err = self.VVbwRu(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVKDjE(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVAc0L(self, mode, VVkINB, title, txt, colList):
  title = colList[1]
  FFkWFV(VVkINB, BF(self.VVNJAt, mode, VVkINB, title, txt, colList), title="Downloading ...")
 def VVNJAt(self, mode, VVkINB, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVNX3j(mode) + " : "+ bName
  if   mode == self.VVrGBU  : mode = self.VVBFzQ
  elif mode == self.VVwJHr  : mode = self.VV8igu
  elif mode == self.VVOmtY : mode = self.VVhjgU
  elif mode == self.VV7O0w : mode = self.VVY4ZD
  qUrl  = self.VV5Wrq(mode, self.VV2QshData["playListURL"], catID)
  txt, err = self.VVbwRu(qUrl)
  list  = []
  if not err and mode in (self.VVBFzQ, self.VV8igu, self.VVhjgU, self.VVY4ZD):
   list, err = self.VVKDjE(mode, txt)
  if err:
   FFG2mq(self, err, title=title)
  elif list:
   VVcNot  = ("Home Menu"   , FFcTP7            , [])
   if mode in (self.VVBFzQ, self.VVY4ZD):
    VVrcFy, VVZZ3c, VVRr4z, VVLwCQ = self.VVxwoR(mode)
    VVq5Be = (""     , BF(self.VVSfX2, mode)      , [])
    VVkY0R = ("Download Options" , BF(self.VVWhTK, mode, "", "")   , [])
    VVW1zM = ("Options"   , BF(self.VVl0R4, "lv", mode, bName)   , [])
    VVM4el = ("Posters Mode"  , BF(self.VVc0ii, mode, False)     , [])
    if mode == self.VVBFzQ:
     VVp0o5 = ("Play"    , BF(self.VVZMsS, mode)       , [])
    else:
     VVp0o5 = ("Programs"   , BF(self.VVRdWR, mode, bName) , [])
   elif mode == self.VV8igu:
    VVrcFy, VVZZ3c, VVRr4z, VVLwCQ = self.VVxwoR(mode)
    VVp0o5  = ("Play"    , BF(self.VVZMsS, mode)       , [])
    VVq5Be = (""     , BF(self.VVSfX2, mode)      , [])
    VVkY0R = ("Download Options" , BF(self.VVWhTK, mode, "v", "")   , [])
    VVW1zM = ("Options"   , BF(self.VVl0R4, "v", mode, bName)   , [])
    VVM4el = ("Posters Mode"  , BF(self.VVc0ii, mode, False)     , [])
   elif mode == self.VVhjgU:
    VVrcFy, VVZZ3c, VVRr4z, VVLwCQ = self.VVxwoR("series2")
    VVp0o5  = ("Show Seasons"  , BF(self.VVzlxc, mode)       , [])
    VVq5Be = (""     , BF(self.VVWuP7, mode)     , [])
    VVkY0R = None
    VVW1zM = None
    VVM4el = ("Posters Mode"  , BF(self.VVc0ii, mode, True)      , [])
   header, widths, VVwZxf = self.VVr9PD(mode)
   FF69ky(self, None, title=title, header=header, VV9gTz=list, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=26, VVp0o5=VVp0o5, VVcNot=VVcNot, VVkY0R=VVkY0R, VVW1zM=VVW1zM, VVM4el=VVM4el, lastFindConfigObj=CFG.lastFindIptv, VVq5Be=VVq5Be, VVrcFy=VVrcFy, VVZZ3c=VVZZ3c, VVRr4z=VVRr4z, VVLwCQ=VVLwCQ, VVFwVS=True, searchCol=1)
  else:
   FFG2mq(self, "No Channels found !", title=title)
  FFpIgV(self)
 def VVr9PD(self, mode):
  if mode in (self.VVBFzQ, self.VVY4ZD):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VVwZxf  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VV8igu:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VVwZxf  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VVhjgU:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VVwZxf  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VVwZxf
 def VVRdWR(self, mode, bName, VVkINB, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VV2QshData["playListURL"]
  ok_fnc  = BF(self.VVmliW, hostUrl, chName, catId, streamId)
  FFkWFV(VVkINB, BF(CCul6W.VVUfEc, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVmliW(self, chUrl, chName, catId, streamId, VVkINB, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCul6W.VVmXX1(chUrl)
   chNum = "333"
   refCode = CCul6W.VVOCPv(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFWpQx(self, chUrl, VVxOHd=False)
   CCppT7.VVkxsS(self.session)
  else:
   FFG2mq(self, "Incorrect Timestamp", pTitle)
 def VVzlxc(self, mode, VVkINB, title, txt, colList):
  title = colList[1]
  FFkWFV(VVkINB, BF(self.VV405Y, mode, VVkINB, title, txt, colList), title="Downloading ...")
 def VV405Y(self, mode, VVkINB, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VV5Wrq(self.VVfIfb, self.VV2QshData["playListURL"], series_id)
  txt, err = self.VVbwRu(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVaXRJ(tDict["info"], "name"   )
      category_id = self.VVaXRJ(tDict["info"], "category_id" )
      icon  = self.VVaXRJ(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVaXRJ(EP, "id"     )
        episode_num   = self.VVaXRJ(EP, "episode_num"   )
        epTitle    = self.VVaXRJ(EP, "title"     )
        container_extension = self.VVaXRJ(EP, "container_extension" )
        seasonNum   = self.VVaXRJ(EP, "season"    )
        epTitle = self.VVNobF(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFG2mq(self, err, title=title)
  elif list:
   VVcNot = ("Home Menu"   , FFcTP7          , [])
   VVkY0R = ("Download Options" , BF(self.VVWhTK, mode, "s", title), [])
   VVW1zM = ("Options"   , BF(self.VVl0R4, "s", mode, title) , [])
   VVM4el = ("Posters Mode"  , BF(self.VVc0ii, mode, False)   , [])
   VVq5Be = (""     , BF(self.VVSfX2, mode)    , [])
   VVp0o5  = ("Play"    , BF(self.VVZMsS, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVwZxf  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FF69ky(self, None, title=title, header=header, VV9gTz=list, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=26, VVcNot=VVcNot, VVkY0R=VVkY0R, VVp0o5=VVp0o5, VVq5Be=VVq5Be, VVW1zM=VVW1zM, VVM4el=VVM4el, lastFindConfigObj=CFG.lastFindIptv, VVrcFy="#0a00292B", VVZZ3c="#0a002126", VVRr4z="#0a002126", VVLwCQ="#00000000")
  else:
   FFG2mq(self, "No Channels found !", title=title)
  FFpIgV(self)
 def VV719T(self, mode, isAll, VVkINB, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVgktg = []
  VVgktg.append(("Keyboard"  , "manualEntry"))
  VVgktg.append(("From Filter" , "fromFilter"))
  FFBqvZ(self, BF(self.VV8c5x, VVkINB, mode, onlyCatID), title="Input Type", VVgktg=VVgktg, width=400)
 def VV8c5x(self, VVkINB, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FF8ISk(self, BF(self.VVYOyB, VVkINB, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCYFnw(self)
    filterObj.VVk2Wn(BF(self.VVYOyB, VVkINB, mode, onlyCatID))
 def VVYOyB(self, VVkINB, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FFeLB8(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CCYFnw.VVt9Ew(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FFG2mq(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FFG2mq(self, "All words must be at least 3 characters !", title=title)
        return
     if CFG.hideIptvServerAdultWords.getValue() and self.VVkkyz(words):
      FFG2mq(self, self.VVhIKA(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CCKX0k, barTheme=CCKX0k.VVfjb8
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVN4xy, VVkINB, mode, onlyCatID, title, words, toFind, asPrefix)
          , VVJ8mq = BF(self.VVONHh, mode, toFind, title))
   if not words:
    FFpIgV(VVkINB, "Nothing to find !", 1500)
 def VVN4xy(self, VVkINB, mode, onlyCatID, title, words, toFind, asPrefix, VVzRAM):
  VVzRAM.VVGeXq(VVkINB.VVKW2u() if onlyCatID is None else 1)
  VVzRAM.VVgo83 = []
  for row in VVkINB.VV3rlI():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVzRAM or VVzRAM.isCancelled:
    return
   VVzRAM.VVu4eE(1)
   VVzRAM.VVr1mh(catName)
   qUrl  = self.VV5Wrq(mode, self.VV2QshData["playListURL"], catID)
   txt, err = self.VVbwRu(qUrl)
   if not err:
    tList, err = self.VVKDjE(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = self.VVNobF(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if not VVzRAM or VVzRAM.isCancelled:
        return
       VVzRAM.VVgo83.append(item)
       VVzRAM.VVr1mh(catName)
 def VVONHh(self, mode, toFind, title, VV4mF1, VVgo83, threadCounter, threadTotal, threadErr):
  if VVgo83:
   title = self.VVLXjt(mode, toFind)
   if mode == self.VVBFzQ or mode == self.VV8igu:
    if mode == self.VV8igu : typ = "v"
    else          : typ = ""
    bName   = CCul6W.VVY5tM(toFind)
    VVp0o5  = ("Play"     , BF(self.VVZMsS, mode)     , [])
    VVkY0R = ("Download Options" , BF(self.VVWhTK, mode, typ, "") , [])
    VVW1zM = ("Options"   , BF(self.VVl0R4, "fnd", mode, bName), [])
    VVM4el = ("Posters Mode"  , BF(self.VVc0ii, mode, False)   , [])
    VVq5Be = (""     , BF(self.VVSfX2, mode)    , [])
   elif mode == self.VVhjgU:
    VVp0o5  = ("Show Seasons"  , BF(self.VVzlxc, mode)     , [])
    VVW1zM = None
    VVkY0R = None
    VVM4el = ("Posters Mode"  , BF(self.VVc0ii, mode, True)    , [])
    VVq5Be = (""     , BF(self.VVWuP7, mode)   , [])
   VVcNot  = ("Home Menu"   , FFcTP7          , [])
   header, widths, VVwZxf = self.VVr9PD(mode)
   VVkINB = FF69ky(self, None, title=title, header=header, VV9gTz=VVgo83, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=26, VVp0o5=VVp0o5, VVcNot=VVcNot, VVkY0R=VVkY0R, VVW1zM=VVW1zM, VVM4el=VVM4el, VVq5Be=VVq5Be, VVrcFy="#0a00292B", VVZZ3c="#0a002126", VVRr4z="#0a002126", VVLwCQ="#00000000", VVFwVS=True, searchCol=1)
   if not VV4mF1:
    FFpIgV(VVkINB, "Stopped" , 1000)
  else:
   if VV4mF1:
    FFG2mq(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVKWZ5(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VVBFzQ, self.VVY4ZD):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VV8igu:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FFOD7l(chName)
  url = self.VV2QshData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVmXX1(url)
  refCode = self.VVOCPv(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVSfX2(self, mode, VVkINB, title, txt, colList):
  FFkWFV(VVkINB, BF(self.VVcLQn, mode, VVkINB, title, txt, colList))
 def VVcLQn(self, mode, VVkINB, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVKWZ5(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFPrkv(self, fncMode=CCXzVR.VV8Twr, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVWuP7(self, mode, VVkINB, title, txt, colList):
  FFkWFV(VVkINB, BF(self.VViSWg, mode, VVkINB, title, txt, colList))
 def VViSWg(self, mode, VVkINB, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFPrkv(self, fncMode=CCXzVR.VV2cm1, chName=name, text=txt, picUrl=Cover)
 def VVc0ii(self, mode, isSerNames, VVkINB, title, txt, colList):
  if   mode in ("itv"  , CCul6W.VVBFzQ, CCul6W.VVY4ZD): category = "live"
  elif mode in ("vod"  , CCul6W.VV8igu )          : category = "vod"
  elif mode in ("series" , CCul6W.VVhjgU)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VVBFzQ : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVY4ZD : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VV8igu  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVhjgU : picCol, descCol, descTxt = 5, 0, "Season"
  FFkWFV(VVkINB, BF(self.session.open, CCbpAL, VVkINB, category, nameCol, picCol, descCol, descTxt))
 def VVWhTK(self, mode, typ, seriesName, VVkINB, title, txt, colList):
  VVgktg = []
  isMulti = VVkINB.VVopq8
  tot  = VVkINB.VVIf28()
  if isMulti:
   if tot < 1:
    FFpIgV(VVkINB, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVgktg.append(("Download %s PIcon%s" % (name, FFLFel(tot)), "dnldPicons" ))
  if typ:
   VVgktg.append(VVm7kE)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVgktg.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVgktg.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVgktg.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCfWgm.VV7SC7():
    VVgktg.append(VVm7kE)
    VVgktg.append(("Download Manager"      , "dload_stat" ))
  FFBqvZ(self, BF(self.VV8IwU, VVkINB, mode, typ, seriesName, colList), title="Download Options", VVgktg=VVgktg)
 def VV8IwU(self, VVkINB, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VV4jXr(VVkINB, mode)
   elif item == "dnldSel"  : self.VVDTVe(VVkINB, mode, typ, colList, True)
   elif item == "addSel"  : self.VVDTVe(VVkINB, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VViM0L(VVkINB, mode, typ, seriesName)
   elif item == "dload_stat" : CCfWgm.VVivnA(self, VVkINB)
 def VVDTVe(self, VVkINB, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VV8EVc(mode, typ, colList)
  if startDnld:
   CCfWgm.VVyAAA(self, decodedUrl)
  else:
   self.VVjyzv(VVkINB, "Add to Download list", chName, [decodedUrl], startDnld)
 def VViM0L(self, VVkINB, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVkINB.VV3rlI():
   chName, decodedUrl = self.VV8EVc(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVjyzv(VVkINB, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVjyzv(self, VVkINB, title, chName, decodedUrl_list, startDnld):
  FFDiGG(self, BF(self.VVc7Ph, VVkINB, decodedUrl_list, startDnld), chName, title=title)
 def VVc7Ph(self, VVkINB, decodedUrl_list, startDnld):
  added, skipped = CCfWgm.VVv0AB(decodedUrl_list)
  FFpIgV(VVkINB, "Added", 1000)
 def VV8EVc(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVKWZ5(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVYH7w(mode, colList)
   refCode, chUrl = self.VVhIR5(self.VVFIuc, self.VVUwU6, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFzXIA(chUrl)
  return chName, decodedUrl
 def VV4jXr(self, VVkINB, mode):
  if FFGqL5("ffmpeg"):
   self.session.open(CCKX0k, barTheme=CCKX0k.VVzy8h
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VVNHm7, VVkINB, mode)
       , VVJ8mq = self.VVJ56y)
  else:
   FFDiGG(self, BF(CCul6W.VVQH9K, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVJ56y(self, VV4mF1, VVgo83, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVgo83["proces"], VVgo83["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVgo83["ok"], VVgo83["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVgo83["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVgo83["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVgo83["badURL"]
  txt += "Download Failure\t: %d\n"   % VVgo83["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVgo83["path"]
  if not VV4mF1  : color = "#11402000"
  elif VVgo83["err"]: color = "#11201000"
  else     : color = "#22001122"
  if VVgo83["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVgo83["err"], txt)
  title = "PIcons Download Result"
  if not VV4mF1:
   title += "  (cancelled)"
  FF8ShK(self, txt, title=title, VVRr4z=color)
 def VVNHm7(self, VVkINB, mode, VVzRAM):
  isMulti = VVkINB.VVopq8
  if isMulti : totRows = VVkINB.VVIf28()
  else  : totRows = VVkINB.VVKW2u()
  VVzRAM.VVGeXq(totRows)
  VVzRAM.VVMbnP(0)
  counter     = VVzRAM.counter
  maxValue    = VVzRAM.maxValue
  pPath     = CCQVwA.VVzkHI()
  VVzRAM.VVgo83 = {   "total" : totRows
         , "proces" : 0
         , "attempt" : 0
         , "fail" : 0
         , "ok"  : 0
         , "size0" : 0
         , "exist" : 0
         , "badURL" : 0
         , "path" : pPath
         , "err"  : "" }
  try:
   for rowNum, row in enumerate(VVkINB.VV3rlI()):
    if VVzRAM.isCancelled:
     break
    if not isMulti or VVkINB.VVv7Q6(rowNum):
     VVzRAM.VVgo83["proces"] += 1
     VVzRAM.VVu4eE(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVYH7w(mode, row)
      refCode = CCul6W.VVOCPv(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVex6x(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVKWZ5(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVzRAM.VVgo83["attempt"] += 1
       path, err = FFq7bz(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVzRAM:
         VVzRAM.VVgo83["ok"] += 1
         VVzRAM.VVMbnP(VVzRAM.VVgo83["ok"])
        if FF1fFq(path) > 0:
         cmd = CCXzVR.VVB1Rq(path)
         cmd += FFhkCt("mv -f '%s' '%s'" % (path, pPath))
         FFLgW2(cmd)
        else:
         if VVzRAM:
          VVzRAM.VVgo83["size0"] += 1
         FFMc8G(path)
       elif err:
        if VVzRAM:
         VVzRAM.VVgo83["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVzRAM:
          VVzRAM.VVgo83["err"] = err.title()
         break
      else:
       if VVzRAM:
        VVzRAM.VVgo83["exist"] += 1
     else:
      if VVzRAM:
       VVzRAM.VVgo83["badURL"] += 1
  except:
   pass
 def VVPxkx(self):
  title = "Download PIcons for Current Bouquet"
  if FFGqL5("ffmpeg"):
   self.session.open(CCKX0k, barTheme=CCKX0k.VVzy8h
       , titlePrefix = ""
       , fncToRun  = self.VVG6t7
       , VVJ8mq = BF(self.VVsAde, title))
  else:
   FFDiGG(self, BF(CCul6W.VVQH9K, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VVG6t7(self, VVzRAM):
  bName = CCMyrC.VVIIML()
  pPath = CCQVwA.VVzkHI()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVzRAM.VVgo83 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CCMyrC.VVKuzJ()
  if not VVzRAM or VVzRAM.isCancelled:
   return
  if not services or len(services) == 0:
   VVzRAM.VVgo83 = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVzRAM.VVGeXq(totCh)
  VVzRAM.VVMbnP(0)
  for serv in services:
   if not VVzRAM or VVzRAM.isCancelled:
    return
   VVzRAM.VVgo83 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVzRAM.VVu4eE(1)
   VVzRAM.VVMbnP(totPic)
   fullRef  = serv[0]
   if FFUsGW(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFzXIA(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err = CCwoYk.VVgDS9(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CCul6W.VVuv9X(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInvServ += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCul6W.VVbwRu(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CCXzVR.VVz95e(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFq7bz(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVzRAM:
     VVzRAM.VVMbnP(totPic)
    if FF1fFq(path) > 0:
     cmd = CCXzVR.VVB1Rq(path)
     cmd += FFhkCt("mv -f '%s' '%s'" % (path, pPath))
     FFLgW2(cmd)
     totPicOK += 1
    else:
     totSize0
     FFMc8G(path)
  if VVzRAM:
   VVzRAM.VVgo83 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVsAde(self, title, VV4mF1, VVgo83, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VVgo83
  if err:
   FFG2mq(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FF1YQ7(str(totExist)  , VVf8NN)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FF1YQ7(str(totNotIptv)  , VVf8NN)
    if totServErr : txt += "Server Errors\t: %s\n" % FF1YQ7(str(totServErr) + t1, VVf8NN)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FF1YQ7(str(totParseErr) , VVf8NN)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FF1YQ7(str(totInvServ)  , VVf8NN)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FF1YQ7(str(totInvPicUrl) , VVf8NN)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FF1YQ7(str(totSize0)  , VVf8NN)
   if not VV4mF1:
    title += "  (stopped)"
   FF8ShK(self, txt, title=title)
 @staticmethod
 def VVQH9K(SELF):
  cmd = FFjDaF(VVEdih, "ffmpeg")
  if cmd : FF20zH(SELF, cmd, title="Installing FFmpeg")
  else : FFEPUu(SELF)
 @staticmethod
 def VVLeg8(SELF):
  SELF.session.open(CCKX0k, barTheme=CCKX0k.VVzy8h
      , titlePrefix = ""
      , fncToRun  = CCul6W.VVO2PJ
      , VVJ8mq = BF(CCul6W.VVPDoJ, SELF))
 @staticmethod
 def VVO2PJ(VVzRAM):
  bName = CCMyrC.VVIIML()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVzRAM.VVgo83 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CCMyrC.VVKuzJ()
  if not VVzRAM or VVzRAM.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVzRAM.VVGeXq(totCh)
   for serv in services:
    if not VVzRAM or VVzRAM.isCancelled:
     return
    VVzRAM.VVu4eE(1)
    fullRef = serv[0]
    if FFUsGW(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFzXIA(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     pList, err = [], ""
     if span:
      pList, err = CCwoYk.VVuNFm(decodedUrl, retLst=True)
     else:
      uType, uHost, uUser, uPass, uId, uChName = CCul6W.VVuv9X(decodedUrl)
      if all([uHost, uUser, uPass, uId]):
       url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
       pList, err = CCul6W.VVsS00(url, uId)
      else:
       totInv += 1
     if err:
      totServErr += 1
      if "Unauth" in err:
       totUnauth += 1
     if VVzRAM:
      VVzRAM.VVqRqk(totEpgOK, uChName)
     if pList:
      totEv, totOK = CCjxcj.VVrq0M(refCode, pList)
      totEpg += totEv
      totEpgOK += totOK
    else:
     totNotIptv += 1
    if VVzRAM:
     VVzRAM.VVgo83 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVzRAM.VVgo83 = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 @staticmethod
 def VVPDoJ(SELF, VV4mF1, VVgo83, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVgo83
  title = "IPTV EPG Import"
  if err:
   FFG2mq(SELF, err, title=title)
  else:
   if VV4mF1 and totEpgOK > 0:
    CCjxcj.VVn2mE()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FF1YQ7(str(totNotIptv), VVf8NN)
    if totServErr : txt += "Server Errors\t: %s\n" % FF1YQ7(str(totServErr) + t1, VVf8NN)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FF1YQ7(str(totInv), VVf8NN)
   if not VV4mF1:
    title += "  (stopped)"
   FF8ShK(SELF, txt, title=title)
 @staticmethod
 def VVsS00(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCul6W.VVmXX1(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCul6W.VVbwRu(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCul6W.VVaXRJ(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CCul6W.VVaXRJ(item, "lang"        ).upper()
    now_playing   = CCul6W.VVaXRJ(item, "now_playing"      )
    start    = CCul6W.VVaXRJ(item, "start"        )
    start_timestamp  = CCul6W.VVaXRJ(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCul6W.VVaXRJ(item, "start_timestamp"     )
    stop_timestamp  = CCul6W.VVaXRJ(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCul6W.VVaXRJ(item, "stop_timestamp"      )
    tTitle    = CCul6W.VVaXRJ(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVOCPv(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCul6W.VVtkL4(catID, MAX_4b)
  TSID = CCul6W.VVtkL4(chNum, MAX_4b)
  ONID = CCul6W.VVtkL4(chNum, MAX_4b)
  NS  = CCul6W.VVtkL4(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVtkL4(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVY5tM(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVxwoR(mode):
  if   mode in ("itv"  , CCul6W.VVrGBU)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCul6W.VVwJHr)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCul6W.VVOmtY) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCul6W.VV7O0w) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCul6W.VVY4ZD    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVHd53(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVEzAi:
   excl = FFZu9n(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FFG2mq(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FFa467('find %s %s %s' % (path, excl, par))
  if files:
   err = CCyssW.VVqYVb(files)
   if err : FFG2mq(self, err + FF1YQ7('\n\n( Change "IPTV Hosts Files Path" to "Custom" and try again )', VVyz0j))
   else : return files
  else:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FFG2mq(self, err)
  return []
 @staticmethod
 def VV55YY():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FFGa2t(path)
  return "/"
 @staticmethod
 def VVUfEc(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CCul6W.VVsS00(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FFG2mq(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVrcFy, VVZZ3c, VVRr4z, VVLwCQ = CCul6W.VVxwoR("")
   VVcNot = ("Home Menu" , FFcTP7, [])
   VVp0o5  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVwZxf  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FF69ky(SELF, None, title="Programs for : " + chName, header=header, VV9gTz=pList, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=24, VVp0o5=VVp0o5, VVcNot=VVcNot, VVrcFy=VVrcFy, VVZZ3c=VVZZ3c, VVRr4z=VVRr4z, VVLwCQ=VVLwCQ)
  else:
   FFG2mq(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVZqsK(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VVPPGS(self, isPortal, line, selectionObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FFDiGG(self, BF(self.VVIWR0, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FFeLB8(confItem, line)
   FF27fq(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VVIWR0(self, title, confItem):
  FFeLB8(confItem, "")
  FF27fq(self, "Removed from IPTV Menu.", title=title)
 def VV3GhH(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VVc65h(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FFkWFV(self, BF(self.VVhut5, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FFG2mq(self, "Incorrect server data !")
 @staticmethod
 def VVtuDc(SELF, isPortal, line, selectionObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCul6W.VV55YY()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFG2mq(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FF27fq(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFG2mq(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVl0R4(self, source, mode, curBName, VVkINB, title, txt, colList):
  isMulti = VVkINB.VVopq8
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVkINB.VVIf28()
   totTxt = "%d Service%s" % (tot, FFLFel(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FF1YQ7(totTxt, VVyz0j)
  curBName2 = ""
  if self.curUrl:
   name = iUrlparse(self.curUrl).netloc
   if name:
    curBName2 = "%s (%s)" % (curBName, name.split(":")[0])
  title = "Add to Bouquet"
  mSel = CCVAoa(self, VVkINB, addSep=False)
  thTxt = "Adding Services ..."
  VVgktg, cbFncDict = [], None
  VVgktg.append(VVm7kE)
  if itemsOK:
   VVgktg.append(("Add %s to New Bouquet : %s"    % (totTxt, FF1YQ7(curBName , VVNQoM)), "addToCur1"))
   if curBName2: VVgktg.append(("Add %s to New Bouquet : %s" % (totTxt, FF1YQ7(curBName2, VV4aa0)) , "addToCur2"))
   VVgktg.append(("Add %s to Existing Bouquet ..."   % (totTxt)            , "addToNew" ))
   cbFncDict = { "addToCur1": BF(FFkWFV, mSel.VVkINB, BF(self.VVRmr4,source, mode, curBName , VVkINB, title), title=thTxt)
      , "addToCur2": BF(FFkWFV, mSel.VVkINB, BF(self.VVRmr4,source, mode, curBName2, VVkINB, title), title=thTxt)
      , "addToNew" : BF(self.VVlGe8, source, mode, curBName, VVkINB, title)
      }
  else:
   VVgktg.append(("Add to Bouquet (nothing selected)", ))
  mSel.VVLgo2(VVgktg, cbFncDict, width=1400)
 def VVRmr4(self, source, mode, curBName, VVkINB, Title):
  chUrlLst = self.VVuin1(source, mode, VVkINB)
  CCMyrC.VVmRoE(self, Title, curBName, "", chUrlLst)
 def VVlGe8(self, source, mode, curBName, VVkINB, Title):
  picker = CCMyrC(self, VVkINB, Title, BF(self.VVuin1, source, mode, VVkINB), defBName=curBName)
 def VVuin1(self, source, mode, VVkINB):
  totChange = 0
  isMulti = VVkINB.VVopq8
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVkINB.VV3rlI()):
   if not isMulti or VVkINB.VVv7Q6(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVYH7w(mode, row)
     refCode, chUrl = self.VVhIR5(self.VVFIuc, self.VVUwU6, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VVnqG1(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VVKWZ5(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
 @staticmethod
 def VVKpRJ():
  return {"1": "DVB Stream", "4097": "servicemp3", "5001": "GST Player", "5002": "Ext-3 EPlayer", "8192": "HDMI input", "8193": "eServiceUri"}
 @staticmethod
 def VVEoQY():
  return sorted(tuple(CCul6W.VVKpRJ()))
 @staticmethod
 def VVtkH0(rt):
  return CCul6W.VVKpRJ().get(str(rt), "")
 @staticmethod
 def VVw4Gb(refCode):
  span = iSearch(r"(?:([A-Fa-f0-9]+):){1}(?:[A-Fa-f0-9]+:){8}", refCode)
  return CCul6W.VVtkH0(span.group(1)) if span else ""
 @staticmethod
 def VVdh3m(rt):
  if   rt == "1"  : return True
  elif rt == "4097": return True
  elif rt == "5001": return fileExists("/usr/bin/gstplayer") or fileExists("/usr/bin/gstplayer_gst-1.0")
  elif rt == "5002": return fileExists("/usr/bin/exteplayer3")
  elif rt == "8192": return False
  elif rt == "8193": return os.path.exists("/usr/bin/apt-get")
  else    : return False
 @staticmethod
 def VVApKt():
  defRt = CFG.iptvAddToBouquetRefType.getValue()
  VVgktg = []
  for ndx, rt in enumerate(CCul6W.VVEoQY()):
   VVgktg.append(FFVKGp("%s\t... %s" % (CCul6W.VVtkH0(rt), rt), rt, CCul6W.VVdh3m(rt), VVo8aK if rt == defRt else ""))
   if ndx < 4 and ndx % 2: VVgktg.append(VVm7kE)
  return VVgktg
class CCvF7K(object):
 def __init__(self, SELF):
  SELF["mySbFrm"] = Label()
  SELF["mySbBak"] = Label()
  SELF["mySbSld"] = Label()
  self.frm, self.bak, self.sld = SELF["mySbFrm"], SELF["mySbBak"], SELF["mySbSld"]
  self.frmI = self.bakI = self.sldI = None
  self.sldX = self.sldY = self.sldW = self.sldH = 0
  for obj in (self.frm, self.bak, self.sld): obj.hide()
 def VVTzZb(self, x, y, w, h, bW=1, frmColor="#11aaaaaa", bakColor="#11003344", sldColor="#11ff8000"):
  x, y, w, h = int(x), int(y), int(w), int(h)
  FFeNfF(self.frm, frmColor)
  FFeNfF(self.bak, bakColor)
  FFeNfF(self.sld, sldColor)
  self.frmI, self.bakI, self.sldI = self.frm.instance, self.bak.instance, self.sld.instance
  self.frmI.move(ePoint(x, y))
  self.frmI.resize(eSize(w, h))
  self.bakI.move(ePoint(x + bW, y + bW))
  self.bakI.resize(eSize(w - bW * 2, h - bW * 2))
  self.sldX = x + bW
  self.sldY = y + bW
  self.sldW = w - bW * 2
  self.sldH = h - bW * 2
  self.sldI.move(ePoint(self.sldX, self.sldY))
  self.sldI.resize(eSize(self.sldW, self.sldH))
 def VVieBL(self, val, maxN):
  if maxN < 2:
   for obj in (self.frm, self.bak, self.sld): obj.hide()
  else:
   for obj in (self.frm, self.bak, self.sld): obj.show()
   visH = max(self.sldH / maxN, self.sldH * 0.05)
   self.sldI.resize(eSize(self.sldW, int(visH)))
   y = FFfvBi(val, 1, maxN, 0, self.sldH - visH)
   self.sldI.move(ePoint(self.sldX, int(self.sldY + y)))
class CCkk4o(CCvF7K):
 def __init__(self, rows, cols, colorCfg):
  self.TOTAL_ROWS   = rows
  self.TOTAL_COLS   = cols
  self.PAGE_ITEMS   = self.TOTAL_ROWS * self.TOTAL_COLS
  self.colorCfg   = colorCfg
  self.totalItems   = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.isBusy    = False
  CCvF7K.__init__(self, self)
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  self.VVy2mb()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(VVKDoB,
  {
   "up" : self.VVRAom   ,
   "down" : self.VVOgNQ  ,
   "left" : self.VVvxS4  ,
   "right" : self.VV3Elm  ,
   "next" : self.VViXre ,
   "last" : self.VVjNzZ
  }, -1)
 def VVMqRC(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
  gap = int(self.skinParam["marginLeft"] / 1)
  topBox = self["myPosterPic%d%d" % (0, 0)].instance
  botBox = self["myPosterPic%d%d" % (self.TOTAL_ROWS - 1, self.TOTAL_COLS - 1)].instance
  w = 20
  y = topBox.position().y() - int(self.skinParam["marginTop"] / 2) + 2
  h = self.skinParam["height"] - self.skinParam["barHeight"] - y - 2
  x = self.skinParam["width"] - w - 2
  self.VVTzZb(x, y, w, h)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    try:
     inst = (self["myPosterLbl%d%d" % (row, col)]).instance
     inst.setBorderColor(parseColor("#000000"))
     inst.setBorderWidth(2)
    except:
     pass
  self.VVd0Vd()
  self["myPiconPtr"].hide()
 def VVzqa0(self):
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > self.totalItems: f1 = self.totalItems
  if f2 > self.totalItems: f2 = self.totalItems
  return f1, f2
 def VVRAom(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVna77()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VV32Ix()
 def VVOgNQ(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVvfk2()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VV32Ix()
 def VVvxS4(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVna77()
  else:
   self.curCol -= 1
   self.VV32Ix()
 def VV3Elm(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVvfk2()
  else:
   self.curCol += 1
   self.VV32Ix()
 def VVjNzZ(self):
  oldPage = self.curPage
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VV32Ix(oldPage != self.curPage)
 def VViXre(self):
  oldPage = self.curPage
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VV32Ix(oldPage != self.curPage)
 def VVvfk2(self):
  force = self.curPage != 0
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VV32Ix(force)
 def VVna77(self):
  force = self.curPage != self.totalPages - 1
  self.curPage = self.totalPages - 1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VV32Ix(force)
 def VV32Ix(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVaYjD = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVaYjD: self.curPage = VVaYjD
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  self.VVELkX()
  self["myPiconPtr"].hide()
  self.VVieBL(self.curPage + 1, self.totalPages)
  FFLYGh(BF(self.VV7Vum, force or not oldPage == self.curPage, VVaYjD))
 def VV7Vum(self, force, VVaYjD):
  try:
   if force:
    self.VVewtM()
   if self.curPage == VVaYjD:
    if self.curRow > self.lastRow:
     self.curRow = self.lastRow
    if self.curRow == self.lastRow and self.curCol > self.lastCol:
     self.curCol = self.lastCol
   self.curIndex = self.curPage * self.PAGE_ITEMS + self.curRow * self.TOTAL_COLS + self.curCol
   self.VVELkX()
   boxX, boxY, boxW, boxH = self.skinParam["extraPar"]
   self["myPiconPtr"].instance.move(ePoint(int(boxX + boxW * self.curCol), int(boxY + boxH * self.curRow)))
  except:
   pass
  self["myPiconPtr"].show()
 def VVJ3Do(self, ndx):
  if ndx > -1 and ndx < self.totalItems:
   oldPage   = self.curPage
   self.curPage = int(ndx / self.PAGE_ITEMS)
   firstInPage  = self.curPage * self.PAGE_ITEMS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VV32Ix(False if oldPage == self.curPage else True)
  else:
   FFpIgV(self, "Not found", 1000)
 def VVNeBP(self):
  self.VVJ3Do(self.totalItems - 1 if self.curIndex == 0 else 0)
 def VVy2mb(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)].hide()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
 def VV2ZE7(self):
  if self.colorCfg:
   fg = bg = self.colorCfg.getValue()
   self.session.openWithCallback(self.VVl6Xb, CCXTPW, defFG=fg, defBG=bg, onlyBG=True)
 def VVl6Xb(self, fg, bg):
  if self.colorCfg and bg:
   FFeLB8(self.colorCfg, bg)
   self.VVd0Vd()
 def VVd0Vd(self):
  if self.colorCfg:
   for row in range(self.TOTAL_ROWS):
    for col in range(self.TOTAL_COLS):
     FFeNfF(self["myPosterRep%d%d" % (row, col)], self.colorCfg.getValue())
 def VVF2QO(self, lbl, txt, color=""):
  CCkk4o.VVVwSE(lbl, txt, color)
 @staticmethod
 def VVVwSE(lbl, txt, color=""):
  lbl.show()
  lbl.setText(txt)
  txtW = lbl.instance.calculateSize().width()
  lblW = lbl.instance.size().width() - 15
  if txtW > lblW:
   for i in range(len(txt), 5, -1):
    txt = txt[:-1]
    lbl.setText("%s.." % txt)
    txtW = lbl.instance.calculateSize().width()
    if txtW < lblW:
     break
  if color:
   lbl.setText("%s%s" % (color, txt))
 @staticmethod
 def VVUPy4(pic, path):
  pic.show()
  if fileExists(path):
   try:
    png = LoadPixmap(path)
    pic.instance.setScale(1)
    pic.instance.setPixmap(png)
    return png
   except:
    pass
  return None
class CCbpAL(Screen, CCkk4o):
 def __init__(self, session, VVkINB, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FFdP4M(VVMhmD, 1870, 1030, 50, 3, 3, "#33000000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "Server Browser"
  self.VVkINB  = VVkINB
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.VV9gTz    = []
  self.totPosterUrls  = 0
  self.totalItems   = 0
  FFj3mb(self, self.Title)
  CCkk4o.__init__(self, 2, 6, CFG.transpColorPosters)
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VVrXLj, subPath)
  if not pathExists(self.pPath):
   FFLgW2("mkdir -p '%s'" % self.pPath)
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myAction"].actions.update(
  {
   "ok" : self.VV96hS    ,
   "cancel": self.close    ,
   "menu" : self.VVdEQ8 ,
   "info" : self.VVdigx  ,
   "0"  : self.VVNeBP
  })
  self.onShown.append(self.VVgr8g)
  self.onClose.append(self.onExit)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFIl1A(self)
  FF2kyZ(self)
  self.VVMqRC()
  self.VVMWAU()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVdEQ8(self):
  chName, subj, desc, fName, picUrl = self.VV9gTz[self.curIndex]
  VVgktg = []
  VVgktg.append(FFVKGp("Show Selected Picture"        , "VVbbCr"  , fName))
  VVgktg.append(FFVKGp("Copy Selected Picture to Export-Directory"   , "VVrtn2" , fName))
  VVgktg.append(FFVKGp("Set Selected Picture as a Poster for a Local Media" , "VVMkAP", fName))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Cache details"       , "VV8vKS"  ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Change Poster/Picon Transparency Color" , "VV2ZE7" ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Help (Keys)"        , "help"     ))
  FFBqvZ(self, self.VV7JMM, title=self.Title, VVgktg=VVgktg)
 def VV7JMM(self, item=None):
  if item is not None:
   if   item == "VVbbCr"   : self.VVbbCr()
   elif item == "VVrtn2"   : self.VVrtn2()
   elif item == "VVMkAP"  : self.VVMkAP()
   elif item == "VV8vKS"  : FFkWFV(self, self.VV8vKS, title="Calculating ...")
   elif item == "VV2ZE7": self.VV2ZE7()
   elif item == "help"     : FFxVrN(self, "_help_servBr", "Server Browser (Keys)")
 def VV96hS(self):
  self.VVkINB.VV2NBO(self.curIndex)
  self.VVkINB.VVHYCL()
 def VVdigx(self):
  self.VVkINB.VV2NBO(self.curIndex)
  self.VVkINB.VVQeVi()
 def VVMWAU(self):
  for colList in self.VVkINB.VV3rlI():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = self.VVfgKd(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VV9gTz.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalItems = len(self.VV9gTz)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  ndx = self.VVkINB.VVnbBC()
  self.curPage = int(ndx / self.PAGE_ITEMS)
  ndx     -= self.curPage * self.PAGE_ITEMS
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VV32Ix(True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVuesA)
  except:
   self.timer.callback.append(self.VVuesA)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VVB6kq)
  self.myThread.start()
 def VVfgKd(self, url):
  fName = os.path.basename(url)
  span = iSearch(r'(.+\.(?:png|jpg))', fName, IGNORECASE)
  return span.group(1) if span else fName
 def VVB6kq(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VV9gTz):
    if not self.stopThread:
     if picUrl and not fName:
      fName = self.VVfgKd(picUrl)
      path, err = FFq7bz(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       FFLgW2("mv -f '%s' '%s'" % (path, self.pPath + fName))
       self.VV9gTz[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VVuesA(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VVYZPJ + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalItems
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VV9gTz[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VV9gTz[ndx] = (chName, subj, desc, fName, "")
     CCkk4o.VVUPy4(self["myPosterPic%d%d" % (row, col)], path)
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVewtM(self):
  self.VVy2mb()
  f1, f2 = self.VVzqa0()
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VV9gTz[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVF2QO(lbl, chName)
   path = ""
   if fName    : path = self.pPath + fName
   if not fileExists(path) : path = VVkwgw + "iptv.png"
   CCkk4o.VVUPy4(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVELkX(self):
  chName, subj, desc, fName, picUrl = self.VV9gTz[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVbbCr(self):
  chName, subj, desc, fName, picUrl = self.VV9gTz[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CCLIUZ.VV94CH(self, self.pPath + fName)
  else          : FFpIgV(self, "File not found", 1500)
 def VVrtn2(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VV9gTz[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   if FFLgW2("cp -f '%s' '%s'" % (self.pPath + fName, dstF)):
    FF27fq(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FFG2mq(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FFG2mq(self, "No Poster/PIcon found", title=title)
 def VVMkAP(self):
  self.session.openWithCallback(self.VVYmy1, BF(CCyssW, patternMode="movies", VV9Esa=CFG.MovieDownloadPath.getValue()))
 def VVYmy1(self, path):
  if path:
   title = "Set Selected Picture as a Poster for a Local Media"
   chName, subj, desc, fName, picUrl = self.VV9gTz[self.curIndex]
   if fName:
    srcF = self.pPath + fName
    dstF = "%s%s" % (os.path.splitext(path)[0], os.path.splitext(srcF)[1])
    if FFLgW2("cp -f '%s' '%s'" % (srcF, dstF)):
     FF27fq(self, "File copied to:\n\n%s" % dstF, title=title)
    else:
     FFG2mq(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstF), title=title)
    CCCsLn.VVHvvR(dstF)
   else:
    FFG2mq(self, "No Poster/PIcon found", title=title)
 def VV8vKS(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VVrXLj, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FFdHIn("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CCyssW.VV1ctA(size)
   txt += "%s\n    %s\n\n" % (FF1YQ7(path, VVyz0j), size)
  mainPath = "%sPosters" % VVrXLj
  totFiles = FFdHIn("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FFLFel(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FF1YQ7("Total space used by Posters/PIcons%s:" % totFTxt, VVChVP), CCyssW.VV1ctA(totSize))
  mountPath = CCyssW.VVY84w(mainPath)
  if pathExists(mountPath):
   totSize  = CCyssW.VV3pfV(mountPath)
   freeSize = CCyssW.VVeQ1N(mountPath)
   usedSize = CCyssW.VV1ctA(totSize - freeSize)
   totSize  = CCyssW.VV1ctA(totSize)
   freeSize = CCyssW.VV1ctA(freeSize)
   txt += "%s\n" % SEP
   txt += FF1YQ7("Media Space:\n", VVeksK)
   txt += "    Media Path\t: %s\n" % FF1YQ7(mountPath, VVifMr)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FF8ShK(self, txt, title="Cache Used Size", height=1000)
class CCCsLn(Screen, CCkk4o):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFdP4M(VVgc94, 1870, 1030, 50, 3, 3, "#33440000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = title
  self.VV9gTz    = lst
  FFj3mb(self, self.Title)
  CCkk4o.__init__(self, 2, 6, CFG.transpColorMovies)
  self["myAction"].actions.update(
  {
   "ok" : self.VV96hS    ,
   "cancel": self.close    ,
   "menu" : self.VVXNgY ,
   "info" : self.VVijeI  ,
   "0"  : self.VVNeBP
  })
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFIl1A(self)
  FF2kyZ(self)
  self.VVMqRC()
  self.totalItems = len(self.VV9gTz)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VV32Ix(True)
 def VVewtM(self):
  self.VVy2mb()
  f1, f2 = self.VVzqa0()
  mPath = CFG.MovieDownloadPath.getValue()
  row = col = 0
  for ndx in range(f1, f2):
   path, movie, poster = self.VV9gTz[ndx]
   path = os.path.join(mPath, path)
   path = os.path.join(path, movie)
   if poster: poster = os.path.join(os.path.dirname(path), poster)
   else  : poster = VVkwgw + "noPos.png"
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVF2QO(lbl, os.path.splitext(os.path.basename(path))[0])
   CCkk4o.VVUPy4(pic, poster)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVZAw3(self):
  path, movie, poster = self.VV9gTz[self.curIndex]
  path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
  path = os.path.join(path, movie)
  if poster:
   poster = os.path.join(os.path.dirname(path), poster)
  return path, poster
 def VVELkX(self):
  path, poster = self.VVZAw3()
  self["myPiconInf0"].setText("  " + os.path.splitext(os.path.basename(path))[0] + "  ")
  self["myPiconInf1"].setText("   " + os.path.dirname(path) + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVXNgY(self):
  path, poster = self.VVZAw3()
  VVgktg = []
  VVgktg.append(("Go to movie ...", "VVeQ4T"))
  VVgktg.append(VVm7kE)
  VVgktg.append(FFVKGp("Show Poster"      , "VVbbCr" , poster))
  VVgktg.append(FFVKGp("Copy Poster to Export-Directory" , "VVrtn2", poster))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Change Poster/Picon Transparency Color"  , "VV2ZE7" ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Change Poster (from current movie path) ..." , "VVrA6c1"  ))
  VVgktg.append(("Change Poster (locate manually) ..."   , "VVrA6c2"  ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Help (Keys)"         , "help"     ))
  FFBqvZ(self, self.VVUilK, title=self.Title, VVgktg=VVgktg)
 def VVUilK(self, item=None):
  if item is not None:
   if   item == "VVeQ4T"    : self.VVeQ4T()
   elif item == "VVrtn2"    : self.VVrtn2()
   elif item == "VVbbCr"    : self.VVbbCr()
   elif item == "VV2ZE7" : self.VV2ZE7()
   elif item == "VVrA6c1"  : self.VVrA6c()
   elif item == "VVrA6c2"  : self.VVrA6c(True)
   elif item == "help"      : FFxVrN(self, "_help_movBr", "Movies Browser (Keys)")
 def VVeQ4T(self):
  VVUl7I = []
  for ndx, item in enumerate(self.VV9gTz):
   path, movie, poster = item
   path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
   VVUl7I.append((os.path.splitext(movie)[0], path, str(ndx)))
  VVUl7I.sort(key=lambda x: x[0].lower())
  VVp0o5 = ("Select" , self.VV3oY0, [])
  header  = ("Name" , "Path", "NDX.")
  widths  = (60  , 40 , 0  )
  FF69ky(self, None, title="Select Movie", width=1800, height=1000, header=header, VV9gTz=VVUl7I, VVYiuZ=widths, VVvi36=26, VVp0o5=VVp0o5, lastFindConfigObj=CFG.lastFindMovie)
 def VV3oY0(self, VVkINB, title, txt, colList):
  self.VVJ3Do(int(colList[2].strip()))
  VVkINB.cancel()
 def VV96hS(self):
  path, poster = self.VVZAw3()
  FFkWFV(self, BF(CCyssW.VVkN1L, self, path), title="Playing Media ...")
 def VVijeI(self):
  path, poster = self.VVZAw3()
  txt = "%s:\n%s\n\n" % (FF1YQ7("Path", VVyz0j), path)
  size = FF1fFq(path)
  if size > -1:
   txt += "%s:\n%s\n\n" % (FF1YQ7("File Size", VVyz0j), CCyssW.VV1ctA(size))
  if poster:
   txt += "%s:\n%s" % (FF1YQ7("Poster", VVyz0j), poster)
  FF8ShK(self, txt, title="Media File Information")
 def VVbbCr(self):
  path, poster = self.VVZAw3()
  if fileExists(poster): CCLIUZ.VV94CH(self, poster)
  else     : FFpIgV(self, "No Poster", 1500)
 def VVrtn2(self):
  title = "Copy Poster"
  path, poster = self.VVZAw3()
  if poster:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = os.path.join(dstPath, os.path.basename(poster))
   if FFLgW2("cp -f '%s' '%s'" % (poster, dstF)):
    FF27fq(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FFG2mq(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (poster, dstPath), title=title)
  else:
   FFpIgV(self, "No Poster", 1500)
 def VVrA6c(self, isManual=False):
  path, poster = self.VVZAw3()
  sDir = FFGa2t(os.path.dirname(path))
  if isManual:
   self.session.openWithCallback(BF(self.VVtsXZ, sDir, path), BF(CCyssW, patternMode="poster", VV9Esa=sDir))
  else:
   VVgktg = []
   for item in [f for f in os.listdir(sDir) if iSearch(r"^.*\.(jpg|png)", f, IGNORECASE)]:
    VVgktg.append((os.path.basename(item), sDir + item))
   if VVgktg:
    VVgktg.sort(key=lambda x: x[0].lower())
    VVdi3l = self.VVkPhA
    FFBqvZ(self, BF(self.VVtsXZ, sDir, path), VVgktg=VVgktg, title="Posters", VVdi3l=VVdi3l, VVfXMZ=sDir)
   else:
    FFpIgV(self, "No jpg/png in current dir", 1500)
 def VVkPhA(self, VVVYOp, txt, ref, ndx):
  CCLIUZ.VV94CH(self, VVMYFn=ref)
 def VVtsXZ(self, sDir, path, pPath=None):
  if pPath:
   newPath = sDir + os.path.splitext(os.path.basename(path))[0] + os.path.splitext(pPath)[1].lower()
   if FFLgW2("cp -f '%s' '%s'" % (pPath, newPath)) or pPath == newPath:
    self.VV9gTz[self.curIndex] = (self.VV9gTz[self.curIndex][0], self.VV9gTz[self.curIndex][1], os.path.basename(newPath))
    FFkWFV(self, self.VVewtM)
    CCCsLn.VVHvvR(newPath)
   else:
    FFpIgV(self, "Cannot copy file", 1000)
 @staticmethod
 def VVHvvR(path):
  if path.endswith(".png"):
   fileNoExt = path[:-4]
   jpgF = fileNoExt + ".jpg"
   if fileExists(jpgF):
    c = 1
    newF = "%s_%d.jpg" % (fileNoExt, c)
    while fileExists(newF):
     c += 1
     newF = "%s_%d.jpg" % (fileNoExt, c)
    FFLgW2("mv -f '%s' '%s'" % (jpgF, newF))
 @staticmethod
 def VVayku(SELF):
  eLst = CC7kl8.VVBUKY()["mov"]
  mPath = CFG.MovieDownloadPath.getValue()
  lst = []
  for (Dir, dirs, files) in os.walk(mPath):
   for f in files:
    if os.path.splitext(f)[1].lstrip(".").lower() in eLst:
     path = os.path.join(Dir, f)
     poster = ""
     for ext in ("jpg", "png"):
      pic = "%s.%s" % (os.path.splitext(path)[0], ext)
      if fileExists(pic):
       poster = os.path.basename(pic)
       break
     lst.append((os.path.dirname(path).replace(mPath, ""), os.path.basename(path), poster))
  title = "Movies Browser"
  lst.sort(key=lambda x: x[1].lower())
  if lst: SELF.session.open(CCCsLn, title, lst)
  else  : FFG2mq(SELF, "No movies found in:\n\n%s\n\nYou can change the path from settings." % mPath, title=title)
class CCnW1v(Screen, CCkk4o):
 def __init__(self, session, bName, lst):
  self.skin, self.skinParam = FFdP4M(VVDylj, 1840, 1040, 50, 3, 3, "#22003344", "#22001122", 45, barHeight=40, topRightBtns=1, vSliderW=20)
  self.session   = session
  self.Title    = bName
  self.VV9gTz    = lst
  self.pPath    = CCQVwA.VVzkHI()
  self.totalItems   = 0
  self.isFirstTime  = True
  FFj3mb(self, self.Title)
  FFuetT(self["keyRed"] , "OK = Zap (Review)")
  FFuetT(self["keyGreen"] , "Zap & Exit")
  FFuetT(self["keyYellow"], "Find Current Service")
  CCkk4o.__init__(self, 5, 7, CFG.transpColorChannels)
  self["myAction"].actions.update(
  {
   "ok"  : BF(self.VV8S36, False),
   "cancel" : self.VVs00w      ,
   "menu"  : self.VVLA7l   ,
   "red"  : self.VVs00w      ,
   "green"  : BF(self.VV8S36, True) ,
   "yellow" : BF(self.VV9U4y, True)  ,
   "0"   : self.VVNeBP
  })
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  if self.isFirstTime:
   force = True
   self.isFirstTime = False
   FFIl1A(self)
   FF2kyZ(self)
   FFeNfF(self["keyRed"], "#0a333333")
   self.VVMqRC()
  else:
   pName, srvLst = CCnW1v.VV14Nh()
   if srvLst and not srvLst == self.VV9gTz:
    force = True
    self.Title = pName
    self["myTitle"].setText("  %s  " % self.Title)
    self.VV9gTz = srvLst
   else:
    force = False
  self.totalItems = len(self.VV9gTz)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VV32Ix(force)
  self.VV9U4y()
 def VVLA7l(self):
  VVgktg = []
  VVgktg.append(("Find Name (sorted list)" , "findSrt"  ))
  VVgktg.append(("Find Name (as listed)" , "findNoSrt"))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Change Background Color" , "VV2ZE7"))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Help (Keys)", "help"))
  FFBqvZ(self, self.VVWjfl, title="Options", VVgktg=VVgktg)
 def VVWjfl(self, item=None):
  if item:
   if   item == "findSrt"    : self.VVJkbt(True)
   elif item == "findNoSrt"   : self.VVJkbt(False)
   elif item == "VV2ZE7": self.VV2ZE7()
   elif item == "help"     : FFxVrN(self, "_help_srvcBr", "Services Browser (Keys)")
 def VVJkbt(self, isSort):
  VVgktg = []
  for ndx, item in enumerate(self.VV9gTz):
   VVgktg.append((item[1], ndx))
  if isSort:
   VVgktg.sort(key=lambda x: x[0].lower())
  FFBqvZ(self, self.VVyVZK, title="Find Name", VVgktg=VVgktg, width=1300)
 def VVyVZK(self, ndx=None):
  if ndx is not None:
   self.VVJ3Do(ndx)
 def VVs00w(self):
  if self.shown: self.close()
  else   : self.show()
 def VV8S36(self, isExit):
  FFkWFV(self, BF(self.VV8K0M, isExit), title="Starting ...")
 def VV8K0M(self, isExit):
  try:
   if self.shown:
    FFWpQx(self, self.VV9gTz[self.curIndex][0], VVxOHd=False)
    if isExit: self.close()
    else  : CCppT7.VVkxsS(self.session)
   else:
    self.show()
  except:
   pass
 def VV9U4y(self, VVT0Gn=False):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  err = ""
  if serv:
   curRef = serv.toString()
   for ndx, item in enumerate(self.VV9gTz):
    if curRef == item[0]:
     self.VVJ3Do(ndx)
     return ndx
   else:
    err = "Not found"
  else:
   err = "No active service"
  if VVT0Gn and err:
   FFpIgV(self, err, 500)
  return -1
 def VVewtM(self):
  self.VVy2mb()
  f1, f2 = self.VVzqa0()
  row = col = 0
  noPos = VVkwgw + "noPos.png"
  for ndx in range(f1, f2):
   ref, name = self.VV9gTz[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVF2QO(lbl, name)
   path = CCQVwA.VVSjPn(self.pPath, ref, name) or noPos
   CCkk4o.VVUPy4(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVELkX(self):
  ref, name = self.VV9gTz[self.curIndex]
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % ref)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVYcl9():
  refCode = refName = rootRef = rootName = ""
  inBouquet = False
  VVw847 = InfoBar.instance
  if VVw847:
   csel = VVw847.servicelist
   if csel:
    currSel  = csel.getCurrentSelection()
    rootRef  = csel.getRoot().toString()
    refCode  = currSel.toString()
    rootName = FFXevL(rootRef)
    refName  = FFXevL(refCode)
    inBouquet = csel.inBouquet()
  return refCode, refName, rootRef, rootName, inBouquet
 @staticmethod
 def VV14Nh(refCode="", refName="", rootRef="", rootName="", inBouquet=False):
  refCode, rootRef = refCode.strip(), rootRef.strip()
  if not refCode and not rootRef:
   refCode, refName, rootRef, rootName, inBouquet = CCnW1v.VVYcl9()
   refCode, rootRef = refCode.strip(), rootRef.strip()
  pName, srvLst = "", []
  if refCode and rootRef:
   if   refCode.startswith("1:7:") : ref, name = refCode, refName
   elif rootRef.startswith("1:7:") : ref, name = rootRef, rootName
   else       : return "", []
   srvLst = FFanBk(eServiceReference(ref))
   pName = name or "No-Name"
   if not inBouquet: srvLst.sort(key=lambda x: x[1].lower())
  else:
   srvLst = CCMyrC.VVKuzJ()
   pName  = CCMyrC.VVIIML() or "ALL (Group)"
  return pName, srvLst
 @staticmethod
 def VV4cS2(SELF):
  pName, srvLst = CCnW1v.VV14Nh()
  if srvLst: SELF.session.open(CCnW1v, pName, srvLst)
  else  : FFG2mq(SELF, "No services found:\n\n%s" % pName, title="Channels Browser")
class CCO0s2(Screen, CCkk4o):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFdP4M(VV3N9u, 1600, 1000, 50, 20, 20, "#2200202a", "#2200101a", 45, barHeight=40, topRightBtns=2, vSliderW=20, morePar={"gapX":30, "gapY":30, "mGap":5, "lblC":"#2200101a", "lblTr":1, "picBgTr":1, "cursC":"#00336070"})
  self.session   = session
  self.Title    = title
  self.VV9gTz    = CCO0s2.VVJ3Jp(lst)
  self.totalItems   = 0
  self.useOrigSize  = False
  self.firstTime   = True
  FFj3mb(self, self.Title)
  FFuetT(self["keyRed"] , "Remove Plugins")
  FFuetT(self["keyGreen"] , "Download New Plugins")
  FFuetT(self["keyYellow"], "Package Info.")
  FFuetT(self["keyBlue"] , "Plugins Group")
  CCkk4o.__init__(self, 4, 5, "")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVYrEw   ,
   "cancel" : self.close    ,
   "menu"  : self.VVB9pB ,
   "info"  : self.VVvjdg  ,
   "red"  : BF(self.VVTyf1, False)   ,
   "green"  : BF(self.VVTyf1, True)   ,
   "yellow" : BF(FFkWFV, self, self.VVYGgv),
   "blue"  : self.VVOAY1  ,
   "0"   : self.VVNeBP
  })
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFIl1A(self)
  FF2kyZ(self)
  self.VVMqRC()
  self.VVGGfR()
 def VVGGfR(self):
  self.totalItems = len(self.VV9gTz)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VV32Ix(True)
 def VV8Xur(self):
  lst = CCO0s2.VVhyDI(PluginDescriptor.WHERE_PLUGINMENU)
  if lst:
   lst = CCO0s2.VVJ3Jp(lst)
   if lst != self.VV9gTz:
    self.VV9gTz = lst
    self.VVGGfR()
  else:
   self.close()
 def VVTyf1(self, isInstall):
  try:
   from Screens.PluginBrowser import PluginDownloadBrowser as pb
   if isInstall:
    self.session.openWithCallback(self.VV8Xur, pb, pb.DOWNLOAD, self.firstTime)
    self.firstTime = False
   else:
    self.session.openWithCallback(self.VV8Xur, pb, pb.REMOVE)
  except:
   try:
    from Plugins.SystemPlugins.SoftwareManager.plugin import PluginManager as pb
    self.session.openWithCallback(self.VV8Xur, pb)
   except:
    FFG2mq(self, 'Cannot open "Extensions Management" !', title=self.Title)
 def VVYrEw(self):
  name, desc = self.VV52fU(self.curIndex)
  if name == PLUGIN_NAME and "VVI342" in globals() and VVI342:
   FFpIgV(self, "Already running.", 500)
  else:
   try:
    p = self.VV9gTz[self.curIndex]
    p(session=self.session)
   except:
    FFG2mq(self, "Cannot start from here !", title="Error in : %s" % name)
 def VVvjdg(self):
  def VVy4Ld(key, val):
   return key + "\t: " + str(val) + "\n"
  p = self.VV9gTz[self.curIndex]
  txt = ""
  try:
   txt += VVy4Ld("Path"  , p.path  )
   txt += VVy4Ld("Description" , p.description )
   txt += VVy4Ld("Icon"  , p.iconstr  )
   txt += VVy4Ld("Wakeup Fnc" , p.wakeupfnc )
   txt += VVy4Ld("NeedsRestart", p.needsRestart)
   txt += VVy4Ld("Internal" , p.internal )
   txt += VVy4Ld("Weight"  , p.weight  )
  except:
   pass
  name, desc = self.VV52fU(self.curIndex)
  if txt : FF8ShK(self, txt, title=name)
  else : FFG2mq(self, "Could not read plugin info.", title=name)
 def VVYGgv(self):
  p = self.VV9gTz[self.curIndex]
  name, desc = self.VV52fU(self.curIndex)
  path = p.path
  pkg, err = CChEm5.VVVozm(path)
  if pkg : CChEm5.VVZH5R(self, pkg, name)
  else : FFrKlA(self, err, 1000)
 def VVB9pB(self):
  path = self.VV9gTz[self.curIndex].path
  VVgktg = []
  txt = "Open Plugin Path in File Manager"
  VVgktg.append(FFVKGp("Open Plugin Path in File Manager", "inFileMan", pathExists(path)))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Use Original Icon Size", "setOrigSize"))
  FFBqvZ(self, self.VVXlby, title="Plugins Group", VVgktg=VVgktg)
 def VVXlby(self, item=None):
  if item:
   if item == "inFileMan":
    self.session.open(CCyssW, mode=CCyssW.VVxsbx, VV9Esa=self.VV9gTz[self.curIndex].path)
   elif item == "setOrigSize":
    self.useOrigSize = True
    self.VV32Ix(True)
 def VVOAY1(self):
  FFBqvZ(self, self.VVWaHx, title="Plugins Group", VVgktg=CCO0s2.VVYkb9(True, True), width=700, VVomDt=True)
 def VVWaHx(self, item=None):
  if item:
   title, where, ndx = item
   self["myTitle"].setText("  %s (%s)" % (self.Title, title))
   lst = CCO0s2.VVhyDI(where)
   if lst:
    self.VV9gTz = CCO0s2.VVJ3Jp(lst)
    self.curPage = self.curCol = self.curRow = self.curIndex = 0
    self.totalItems = len(self.VV9gTz)
    self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
    self.VV32Ix(True)
   else:
    FFG2mq(self, "Not found !", title=self.Title)
 def VVewtM(self):
  self.VVy2mb()
  f1, f2 = self.VVzqa0()
  row = col = 0
  for ndx in range(f1, f2):
   name, desc = self.VV52fU(ndx)
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVF2QO(lbl, name)
   iconOk = False
   pngSz = None
   if self.VV9gTz[ndx].icon:
    try:
     pngSz = self.VV9gTz[ndx].icon.size()
     pic.instance.setScale(1)
     pic.instance.setPixmap(self.VV9gTz[ndx].icon)
     pic.show()
     iconOk = True
    except:
     pass
   if not iconOk:
    icons = []
    path = self.VV9gTz[ndx].path
    if pathExists(path):
     for f in ("iconfhd.png", "iconhd.png", "icon.png"):
      icons.append(os.path.join(path, f))
    icons.append(resolveFilename(SCOPE_CURRENT_SKIN, "icons/plugin.png"))
    icons.append(VVkwgw + "plugin.png")
    for path in icons:
     pixMap = CCkk4o.VVUPy4(pic, path)
     if pixMap:
      pngSz = pixMap.size()
      break
   if self.useOrigSize and pngSz:
    try:
     boxSz = pic.instance.size()
     picPos = pic.instance.position()
     pngW, pngH = pngSz.width(), pngSz.height()
     boxW, boxH = boxSz.width(), boxSz.height()
     if boxW > pngW and boxH > pngH:
      pic.instance.resize(pngSz)
      pic.instance.move(ePoint(picPos.x() + (boxW - pngW) // 2, picPos.y() + (boxH - pngH) // 2))
    except:
     pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VV52fU(self, ndx):
  name = str(self.VV9gTz[ndx].name).strip()
  desc = str(self.VV9gTz[ndx].description).strip().replace("\n", " >> ")
  if not name or name == "Plugin":
   name = desc or FFBBEq(self.VV9gTz[ndx].path)
  return name, desc
 def VVELkX(self):
  name, desc = self.VV52fU(self.curIndex)
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % desc)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVYkb9(isMenu=False, addTot=False):
  lst =[("Plugin Menu"   , PluginDescriptor.WHERE_PLUGINMENU    )
   , ("Audio Menu"    , PluginDescriptor.WHERE_AUDIOMENU    )
   , ("Auto-Start Menu"  , PluginDescriptor.WHERE_AUTOSTART    )
   , ("Channel Context Menu" , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU )
   , ("Event Info"    , PluginDescriptor.WHERE_EVENTINFO    )
   , ("Extensions Menu"  , PluginDescriptor.WHERE_EXTENSIONSMENU   )
   , ("File Scan"    , PluginDescriptor.WHERE_FILESCAN    )
   , ("Main Menu"    , PluginDescriptor.WHERE_MAINMENU    )
   , ("Menu"     , PluginDescriptor.WHERE_MENU     )
   , ("Movie List"    , PluginDescriptor.WHERE_MOVIELIST    )
   , ("Network Configuration" , PluginDescriptor.WHERE_NETWORKCONFIG_READ  )
   , ("Network Setup"   , PluginDescriptor.WHERE_NETWORKSETUP   )
   , ("Session Start"   , PluginDescriptor.WHERE_SESSIONSTART   )
   , ("Software Manager"  , PluginDescriptor.WHERE_SOFTWAREMANAGER  )
   , ("Teletext"    , PluginDescriptor.WHERE_TELETEXT    )
   , ("Wizard"     , PluginDescriptor.WHERE_WIZARD     )]
  if addTot:
   for ndx, item in enumerate(lst):
    tot = len(CCO0s2.VVhyDI(item[1]))
    lst[ndx] = ("%s   %s(%d)" % (lst[ndx][0], VVdl3O, tot), lst[ndx][1])
  if isMenu: lst.insert(1, VVm7kE)
  else  : lst.sort(key=lambda x: x[0].lower())
  return lst
 @staticmethod
 def VVhyDI(where):
  try: return iPlugins.getPlugins(where)
  except: return []
 @staticmethod
 def VVJ3Jp(lst):
  tmp = []
  for item in lst:
   name = str(item.name).strip()
   if not name or name == "Plugin":
    name = str(item.description).strip() or FFBBEq(item.path)
   tmp.append((name, item))
  tmp.sort(key=lambda x: x[0].lower())
  lst = []
  for nm, obj in tmp:
   lst.append(obj)
  return lst
 @staticmethod
 def VVxNg1(session):
  title = "Plugins Browser"
  lst = CCO0s2.VVhyDI(PluginDescriptor.WHERE_PLUGINMENU)
  if lst : session.open(CCO0s2, title, lst)
  else : FF07lH(session, "No plugins found !", title=title)
class CCOdiR(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", isFind=False):
  self.skin, self.skinParam = FFdP4M(VVuQx7, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.isFindMode     = isFind
  self.VVPtmX  = 0
  self.VVnwis = 1
  self.VVsQ7L  = 2
  VVgktg = []
  VVgktg.append(("Find in All Service (from filter)" , "VVRTLt" ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Find in All (Manual Entry)"   , "VV5uXZ"    ))
  VVgktg.append(("Find in TV"       , "VVjB0L"    ))
  VVgktg.append(("Find in Radio"      , "VVfHWe"   ))
  if self.VVXqbl():
   VVgktg.append(VVm7kE)
   VVgktg.append(("Hide Channel: %s" % self.servName , "VVzFUa"   ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Zap History"       , "VVNMKw"    ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("IPTV Tools"       , "iptv"      ))
  VVgktg.append(("PIcons Tools"       , "PIconsTools"     ))
  VVgktg.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  VVgktg.append(("EPG Tools"       , "epgTools"     ))
  FFj3mb(self, VVgktg=VVgktg, title=title)
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFayJd(self["myMenu"])
  FF08xD(self)
  if self.isFindMode:
   self.VVsBHf(self.VVcAXg())
 def VV96hS(self):
  global VVEyaB
  VVEyaB = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VV5uXZ"    : self.VV5uXZ()
   elif item == "VVRTLt" : self.VVRTLt()
   elif item == "VVjB0L"    : self.VVjB0L()
   elif item == "VVfHWe"   : self.VVfHWe()
   elif item == "VVzFUa"   : self.VVzFUa()
   elif item == "VVNMKw"    : self.VVNMKw()
   elif item == "iptv"       : self.session.open(CCul6W)
   elif item == "PIconsTools"     : self.session.open(CCQVwA)
   elif item == "ChannelsTools"    : self.session.open(CCmfL4)
   elif item == "epgTools"      : self.session.open(CCjxcj)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVjB0L(self) : self.VVsBHf(self.VVPtmX)
 def VVfHWe(self) : self.VVsBHf(self.VVnwis)
 def VV5uXZ(self) : self.VVsBHf(self.VVsQ7L)
 def VVsBHf(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FF8ISk(self, BF(self.VVAj3h, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VVRTLt(self):
  filterObj = CCYFnw(self)
  filterObj.VVk2Wn(self.VVVTrQ)
 def VVVTrQ(self, item):
  self.VVAj3h(self.VVsQ7L, item)
 def VVXqbl(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFUsGW(self.refCode)        : return False
  return True
 def VVAj3h(self, mode, VVMLwJ):
  FFkWFV(self, BF(self.VVRZAA, mode, VVMLwJ), title="Searching ...")
 def VVRZAA(self, mode, VVMLwJ):
  if VVMLwJ:
   VVMLwJ = VVMLwJ.strip()
  if VVMLwJ:
   self.findTxt = VVMLwJ
   CFG.lastFindContextFind.setValue(VVMLwJ)
   if   mode == self.VVPtmX  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVnwis : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVMLwJ)
   if len(title) > 55:
    title = title[:55] + ".."
   VVUl7I = self.VV0rSX(VVMLwJ, servTypes)
   if self.isFindMode or mode == self.VVsQ7L:
    VVUl7I += self.VV6fpY(VVMLwJ)
   if VVUl7I:
    VVUl7I.sort(key=lambda x: x[0].lower())
    VVIcAB = self.VVkby1
    VVp0o5  = ("Zap"   , self.VVxGtx    , [])
    VVkY0R = ("Current Service", self.VVOkES , [])
    VVW1zM = ("Options"  , self.VVQ5u0 , [])
    VVq5Be = (""    , self.VVdMHS , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVwZxf  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FF69ky(self, None, title=title, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=26, VVp0o5=VVp0o5, VVIcAB=VVIcAB, VVkY0R=VVkY0R, VVW1zM=VVW1zM, VVq5Be=VVq5Be, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVsBHf(self.VVcAXg())
    FF27fq(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VV0rSX(self, VVMLwJ, servTypes):
  VV9gTz = CCmfL4.VV2Rz4(servTypes)
  VVUl7I = []
  if VV9gTz:
   VVASq4, VVQ0ZT = FFGsAb()
   tp = CC5l6x()
   words, asPrefix = CCYFnw.VVt9Ew(VVMLwJ)
   colorYellow  = CC73JY.VVN66D(VVChVP)
   colorWhite  = CC73JY.VVN66D(VVTKcZ)
   for s in VV9gTz:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFCt6D(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVASq4:
        STYPE = VVQ0ZT[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVSfcz(refCode)
       if not "-S" in syst:
        sat = syst
       VVUl7I.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVUl7I
 def VV6fpY(self, VVMLwJ):
  VVMLwJ = VVMLwJ.lower()
  VVUl7I = []
  colorYellow  = CC73JY.VVN66D(VVChVP)
  colorWhite  = CC73JY.VVN66D(VVTKcZ)
  for b in CCMyrC.VVQmFq():
   VVwjmO  = b[0]
   VVwjeu  = b[1].toString()
   VVGnmK = eServiceReference(VVwjeu)
   VVdY8S = FFanBk(VVGnmK)
   for service in VVdY8S:
    refCode  = service[0]
    if FFUsGW(refCode):
     servName = service[1]
     if VVMLwJ in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVMLwJ), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVUl7I.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVUl7I
 def VVcAXg(self):
  mode = CC01PH.VVlkXF(default=-1)
  return self.VVsQ7L if mode == -1 else mode
 def VVkby1(self, VVkINB):
  self.close()
  VVkINB.cancel()
 def VVxGtx(self, VVkINB, title, txt, colList):
  FFWpQx(VVkINB, colList[2], VVxOHd=False, checkParentalControl=True)
 def VVOkES(self, VVkINB, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(VVkINB)
  if refCode:
   VVkINB.VVXQxM(2, FFc5SJ(refCode, iptvRef, chName), True)
 def VVQ5u0(self, VVkINB, title, txt, colList):
  servName = colList[0]
  mSel = CCVAoa(self, VVkINB)
  VVgktg, cbFncDict = CCmfL4.VVndoT(self, VVkINB, servName, 2)
  mSel.VVLgo2(VVgktg, cbFncDict)
 def VVdMHS(self, VVkINB, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFPrkv(self, fncMode=CCXzVR.VVkdMR, refCode=refCode, chName=chName, text=txt)
 def VVzFUa(self):
  FFDiGG(self, self.VVrN9r, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVrN9r(self):
  ret = FFzHg5(self.refCode, True)
  if ret:
   self.VVIRdx()
   self.close()
  else:
   FFpIgV(self, "Cannot change state" , 1000)
 def VVIRdx(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VV0AY6()
  except:
   self.VVjhW4()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFPJLb(self, serviceRef)
 def VV0AY6(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVw847 = InfoBar.instance
   if VVw847:
    VVpnhD = VVw847.servicelist
    if VVpnhD:
     hList = VVpnhD.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVpnhD.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVpnhD.history  = newList
       VVpnhD.history_pos = pos
 def VVjhW4(self):
  VVw847 = InfoBar.instance
  if VVw847:
   VVpnhD = VVw847.servicelist
   if VVpnhD:
    VVpnhD.history  = []
    VVpnhD.history_pos = 0
 def VVNMKw(self):
  VVw847 = InfoBar.instance
  VVUl7I = []
  if VVw847:
   VVpnhD = VVw847.servicelist
   if VVpnhD:
    VVASq4, VVQ0ZT = FFGsAb()
    for serv in VVpnhD.history:
     refCode = serv[-1].toString()
     chName = FFXevL(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FFUsGW(refCode)
     isSRel = FFtvcx(refCode)
     sat = "-" if isIptv and not isSRel or isLocal else FFCt6D(refCode, True)
     if isIptv : STYPE = "Stream Relay" if isSRel else "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVASq4:
       STYPE = VVQ0ZT[sTypeInt]
     VVUl7I.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVUl7I:
   VVp0o5  = ("Zap"   , self.VVDuV2   , [])
   VVW1zM = ("Clear History" , self.VVDOiV   , [])
   VVq5Be = (""    , self.VVOfEe , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVwZxf  = (LEFT    , LEFT   , CENTER , LEFT   )
   FF69ky(self, None, title=title, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=28, VVp0o5=VVp0o5, VVW1zM=VVW1zM, VVq5Be=VVq5Be)
  else:
   FF27fq(self, "History is empty.", title=title)
 def VVDuV2(self, VVkINB, title, txt, colList):
  FFWpQx(VVkINB, colList[3], VVxOHd=False, checkParentalControl=True)
 def VVDOiV(self, VVkINB, title, txt, colList):
  FFDiGG(self, BF(self.VVpSAH, VVkINB), "Clear Zap History ?")
 def VVpSAH(self, VVkINB):
  self.VVjhW4()
  VVkINB.cancel()
 def VVOfEe(self, VVkINB, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFPrkv(self, fncMode=CCXzVR.VVjZ7J, refCode=refCode, chName=chName, text=txt)
 @staticmethod
 def VVMqy9():
  try:
   global VVth2N
   if VVth2N is None:
    VVth2N    = ChannelContextMenu.__init__
   ChannelContextMenu.__init__   = CCOdiR.VVqolT
   ChannelContextMenu.VVNxmP = CCOdiR.VVNxmP
  except:
   pass
 @staticmethod
 def VVqolT(SELF, session, csel):
  from Components.ChoiceList import ChoiceEntryComponent
  VVth2N(SELF, session, csel)
  if CFG.showInChannelListMenu.getValue():
   for ndx, title in enumerate(("Channels Browser", "Find", "Bouquet Editor", "Channels Tools")):
    title = "%s - %s" % (PLUGIN_NAME, title)
    SELF["menu"].list.insert(ndx, ChoiceEntryComponent(key=" ", text=(title , BF(SELF.VVNxmP, csel, ndx, title))))
 @staticmethod
 def VVNxmP(SELF, csel, mode, title):
  try:
   currSel  = csel.getCurrentSelection()
   refCode  = currSel.toString()
   refName  = FFXevL(refCode)
  except:
   refCode = refName = ""
  if   mode == 0: CCnW1v.VV4cS2(SELF)
  elif mode == 2: SELF.session.open(CC01PH)
  else    : SELF.session.open(CCOdiR, title=title, csel=csel, refCode=refCode, servName=refName, isFind=True if mode == 1 else False)
  SELF.close()
class CC01PH(Screen):
 def __init__(self, session, refCode="", servName=""):
  self.skin, self.skinParam = FFdP4M(VVZhbx, 10, 10, 30, 0, 0, "#ff000000", "#ff000000", 30)
  self.session = session
  self.Title  = "Bouquet Editor"
  self.pPath  = CCQVwA.VVzkHI()
  self.bTables = []
  FFj3mb(self)
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  self.VVKF0x()
 def VV6cwa(self, tbl, bName, bRef):
  self.bTables.append(tbl)
  tbl.bouqName = bName
  tbl.bouqRef  = bRef
 def VVKF0x(self):
  rootStr = CC01PH.VV8UPK()
  rows = self.VV5gaT(rootStr)
  if rows :
   self.VVv7J3(self, "Main Bouquets List", rootStr, rows)
   refCode, refName, rootRef, rootName, inBouquet = CCnW1v.VVYcl9()
   if not self.bTables[-1].VVfOKC({3:refCode}):
    self.bTables[-1].VVfOKC({3:rootRef})
  else:
   FFG2mq(self, "No bouquets Found !", title=self.Title)
   self.close()
 def VVwCAB(self):
  self.bTables[-1].cancel()
  if len(self.bTables) > 0: del self.bTables[-1]
  if not len(self.bTables): self.close()
 def VV5gaT(self, bRef=None):
  blkLst = CC01PH.VVWtjU()
  rows = []
  for ndx, row in enumerate(FFanBk(eServiceReference(bRef), mode=1), start=1):
   ref, name, flags = row
   fTxt, fColor = CC01PH.VVA7QI(flags)
   lck = "1" if CC01PH.VVUxz1(ref, blkLst) > -1 else ""
   rows.append((str(ndx), "", fColor + name, ref, fTxt, str(flags), lck))
  return rows
 def VVv7J3(self, selfObj, bName, bRef, rows):
  totTbl = len(self.bTables)
  title = {0:"Main Bouquets List", 1:"%s %s" % (FF1YQ7("Fav: ", VVdl3O), bName), 2:"%s %s" % (FF1YQ7("Sub: ", VVdl3O), bName)}.get(totTbl, bName)
  bg  = {0:"#11002233", 1:"#0a112222"}.get(totTbl, "#0a131111")
  VVIcAB = self.VVIiE4
  VVq5Be = (""    , self.VVc9NO  , [])
  VVp0o5  = ("Enter Bouquet" , self.VVEQea , [])
  VVcNot = ("Delete"   , self.VVxVnL , [])
  VVW1zM = ("Options"  , self.VVNPlT , [])
  VVM4el = ("Move Here"  , self.VVYzh5 , [])
  picParams  = (1, self.VVs2sB, None)
  widths  = (12   , 7   , 81 , 0  , 0   , 0   , 0   )
  VVwZxf = (CENTER  , CENTER , LEFT , LEFT , LEFT  , CENTER , CENTER )
  tbl = FF69ky(self, None, title=title, VV9gTz=rows, VVwZxf=VVwZxf, width=1500, height=1000, VVYiuZ=widths, VVvi36=28, addSort=False, VVq5Be=VVq5Be, VVp0o5=VVp0o5, VVIcAB=VVIcAB, VVcNot=VVcNot, VVW1zM=VVW1zM, VVM4el=VVM4el, VVFwVS=True, searchCol=1, picParams=picParams, lastFindConfigObj=CFG.lastFindServices
     , VVrcFy=bg, VVZZ3c=bg, VVRr4z=bg, VVLwCQ="#0a442200", borderWidth=0, VVEjwd="#11330000")
  tbl.VVxHVQ(BF(self.VV5xz2, tbl), True)
  self.VV6cwa(tbl, bName, bRef)
 def VViCzN(self, VVkINB, mutableList, tot, jumpDict=None):
  if tot:
   if mutableList:
    mutableList.flushChanges()
   FFHpDz()
   rows = self.VV5gaT(VVkINB.bouqRef)
   if rows:
    VVkINB.VVBKwU(False)
    VVkINB.VVDqeT(rows, VVc63JMsg=True, isSort=False, tableRefreshCB=BF(self.VVvgw2, jumpDict))
   else:
    self.VVwCAB()
    totTbl = len(self.bTables)
    FFpIgV(self.bTables[-1] if totTbl > 0 else self, "Empty List !", 1500)
  else:
   FFrKlA(VVkINB, "No change !", 1500)
 def VVvgw2(self, jumpDict, VVkINB, title, txt, colList):
  if jumpDict:
   VVkINB.VVfOKC(jumpDict)
 def VV5xz2(self, VVkINB):
  VVkINB["keyRed"].hide()
  VVkINB["keyBlue"].hide()
  if VVkINB.VVopq8:
   if VVkINB.VVIf28() > 0:
    VVkINB["keyRed"].show()
    VVkINB["keyBlue"].show()
  else:
   VVkINB["keyRed"].show()
 def VVc9NO(self, VVkINB, title, txt, colList):
  c1, c2, c3 = VVChVP, VV4aa0, VVf8NN
  ttl = lambda x, y, color=c1: "%s:\n%s\n\n" % (FF1YQ7(x, color), y) if y else ""
  num, picon, name, ref, rem, flags, lck = colList
  path = CC01PH.VVbeeT(ref, mode=1)
  txt  = ttl("Name"    , name)
  txt += ttl("Bouquet File"  , path if path.startswith("/") else "")
  txt += ttl("Parent Bouquet"  , VVkINB.bouqName, c2)
  txt += ttl("Parent Bouquet File", CC01PH.VVbeeT(VVkINB.bouqRef, mode=1), c2)
  txt += ttl("Ref."    , ref, c3) if VVxrH7 else ""
  txt += ttl("Remarks"   , rem, c3) if VVxrH7 else ""
  path = CCQVwA.VVSjPn(self.pPath, ref, name)
  FFPrkv(self, fncMode=CCXzVR.EPG_MODE_BOUQUET_EDITOR, text=txt, picPath=path)
 def VVEQea(self, VVkINB, title, txt, colList):
  FFkWFV(VVkINB, BF(self.VVVIpM, VVkINB, colList) )
 def VVVIpM(self, VVkINB, colList):
  maxLev = 2
  num, picon, name, ref, rem, flags, lck = colList
  if FF5JUW(ref):
   if len(self.bTables) <= maxLev:
    rows = self.VV5gaT(ref)
    if rows : self.VVv7J3(VVkINB, name, ref, rows)
    else : FFrKlA(VVkINB, "Empty list !", 1500)
   else:
    FFG2mq(self, "Maximum Level of Recursive Bouquets (%d) !" % maxLev, title=self.Title)
  elif CC01PH.VVS7kY(ref) == 0:
   FFWpQx(self, ref, VVxOHd=False)
   FFspfF(self, "Cancel to go back to table")
  else:
   FFpIgV(VVkINB, "No action", 300)
 def VVIiE4(self, VVkINB):
  if VVkINB.VVopq8:
   VVkINB.VVBKwU(False)
   self.VV5xz2(VVkINB)
  else:
   self.VVwCAB()
 def VVNPlT(self, VVkINB, title, txt, colList):
  VVgktg = []
  iMulSel = VVkINB.VVeANU()
  sortItem = ("Sort", )
  if iMulSel:
   tot = VVkINB.VVIf28()
   if tot > 1: sortItem = ("Sort", "sort")
   isSel = tot > 0
   bTxt = "Bouquet%s" % FFLFel(tot)
  else:
   isSel = True
   bTxt = "Bouquet"
  inMain = len(self.bTables) == 1
  okToMain = False
  if not inMain:
   for ref in self.VVNa1q(VVkINB):
    if not FF5JUW(ref) and not ref.startswith("1:64:"): break
   else:
    okToMain = True
  totDel = len(self.VVpaP1())
  c1, c2, c3, c4 = VV4aa0, VVo8aK, VVyz0j, VVf8NN
  VVgktg.append(FFVKGp("Rename"   , "renm" , not iMulSel, c1))
  VVgktg.append(VVm7kE)
  VVgktg.append(FFVKGp("Add Marker"  , "mrkr" , not iMulSel, c2))
  VVgktg.append(FFVKGp("Add Empty Bouquet", "addBouq" , not iMulSel and inMain, c2))
  if totDel:
   VVgktg.append(VVm7kE)
   VVgktg.append((c4 + 'Delete %d Unused ".del" Bouquets File%s' % (totDel, FFLFel(totDel)), "unused"))
  if inMain:
   VVgktg.append(VVm7kE)
   VVgktg.append(FFVKGp("Hide %s" % bTxt , "hidOn" , isSel, c3))
   VVgktg.append(FFVKGp("Unhide %s" % bTxt , "hidOff" , isSel, c3))
   VVgktg.append(VVm7kE)
   VVgktg.append(FFVKGp("Protect %s" % bTxt , "lckOn" , isSel, c3))
   VVgktg.append(FFVKGp("Unprotect %s" % bTxt , "lckOff" , isSel, c3))
   VVrcFy, VVZZ3c = "#22001122", "#22000a15"
  else:
   VVrcFy, VVZZ3c = "#2200120a", "#2200120a"
  VVgktg.append(VVm7kE)
  VVgktg.append(sortItem)
  VVgktg.append(FFVKGp("Copy to Main Bouquets List" , "toMain", okToMain))
  VVgktg.append(FFVKGp("Copy to a Bouquet"   , "toBouq", isSel))
  cbFncDict = { "renm" : BF(self.VVXcyE  , VVkINB)
     , "mrkr" : BF(self.VV1TcV , VVkINB)
     , "addBouq" : BF(self.VVmOcl, VVkINB)
     , "unused" : BF(self.VVe3MU , VVkINB)
     , "hidOn" : BF(self.VVPJid  , VVkINB, True)
     , "hidOff" : BF(self.VVPJid  , VVkINB, False)
     , "lckOn" : BF(self.VVzJz2  , VVkINB, True)
     , "lckOff" : BF(self.VVzJz2  , VVkINB, False)
     , "sort" : BF(self.VVeD6e  , VVkINB)
     , "toMain" : BF(self.VVFtYA , VVkINB)
     , "toBouq" : BF(self.VVrGhn , VVkINB) }
  fnc = BF(self.VV5xz2, VVkINB)
  mSel = CCVAoa(self, VVkINB)
  mSel.VVLgo2(VVgktg, cbFncDict, okFnc=fnc, onMultiSelFnc=fnc, height=1000, VVrcFy=VVrcFy, VVZZ3c=VVZZ3c)
 def VVxVnL(self, VVkINB, title, txt, colList):
  txt, totSel = "", 0
  if VVkINB.VVeANU():
   totSel = VVkINB.VVIf28()
   if totSel:
    txt = "Delete %s item%s" % (FF1YQ7(str(totSel), VVChVP), FFLFel(totSel))
  else:
   num, picon, name, ref, rem, flags, lck = colList
   txt = "Delete : %s" % FF1YQ7(name, VVChVP)
  if txt:
   FFDiGG(self, BF(self.VViDLu, VVkINB), "%s\n\nContinue ?" % txt, title=self.Title)
 def VViDLu(self, VVkINB):
  FFkWFV(VVkINB, BF(self.VV5aod, VVkINB))
 def VV5aod(self, VVkINB):
  lst, mutableList, csel, bServ = self.VVytsl(VVkINB)
  if mutableList is not None:
   tot = 0
   for ref in lst:
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.removeService(serv):
     tot += 1
     bFile = CCMyrC.VVETMB(ref)
     if bFile:
      bFile = VVMixw + bFile
      FFLgW2("rm -f '%s' '%s.del'" % (bFile, bFile))
   self.VViCzN(VVkINB, mutableList, tot)
 def VVYzh5(self, VVkINB, title, txt, colList):
  FFkWFV(VVkINB, BF(self.VVAsok, VVkINB))
 def VVAsok(self, VVkINB):
  lst, mutableList, csel, bServ = self.VVytsl(VVkINB)
  if mutableList is not None:
   curNdx = VVkINB.VVnbBC()
   if curNdx <= VVkINB.VVHLTv(): lst = reversed(lst)
   else             : curNdx -= 1
   tot = 0
   for ref in lst:
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.moveService(serv, curNdx):
     tot += 1
   self.VViCzN(VVkINB, mutableList, tot)
 def VVeD6e(self, VVkINB):
  FFkWFV(VVkINB, BF(self.VVDROS, VVkINB))
 def VVDROS(self, VVkINB):
  lst, mutableList, csel, bServ = self.VVytsl(VVkINB)
  if mutableList is not None:
   nmlst = VVkINB.VVYlFT(2)
   lst = list(zip(nmlst, lst))
   lst.sort(key=lambda x: x[0].lower())
   curNdx = VVkINB.VVHLTv()
   tot = 0
   for name, ref in reversed(lst):
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.moveService(serv, curNdx):
     tot += 1
   self.VViCzN(VVkINB, mutableList, tot)
 def VVXcyE(self, VVkINB, item=None):
  name = VVkINB.VVw0xB()[2]
  FF8ISk(self, BF(self.VVWnRl, VVkINB), defaultText=name, title="Rename", message="Enter new name")
 def VVWnRl(self, VVkINB, name):
  lst, mutableList, csel, bServ = self.VVytsl(VVkINB)
  if name and csel and mutableList:
   name = name.strip()
   if name:
    ref = VVkINB.VVw0xB()[3]
    if FF5JUW(ref):
     CCMyrC.VV5CdL(ref, name)
    else:
     serv = eServiceReference(ref)
     if serv.valid():
      serv.setName(name)
      mutableList.removeService(serv)
      mutableList.addService(serv)
      mutableList.moveService(serv, VVkINB.VVnbBC())
    self.VViCzN(VVkINB, mutableList, 1)
 def VV1TcV(self, VVkINB):
  name = "%s Marker %s" % ("=" * 7, "=" * 7)
  FFkWFV(VVkINB, BF(self.VV1SiZ, VVkINB, name))
 def VV1SiZ(self, VVkINB, name):
  lst, mutableList, csel, bServ = self.VVytsl(VVkINB)
  if mutableList is not None:
   curServ = eServiceReference(VVkINB.VVw0xB()[3])
   cnt = tot = 0
   while mutableList:
    serv = eServiceReference("1:64:%d:0:0:0:0:0:0:0::%s" % (cnt, name))
    if curServ and curServ.valid():
     if not mutableList.addService(serv, curServ):
      csel.servicelist.addService(serv, True)
      tot += 1
      break
    elif not mutableList.addService(serv):
     csel.servicelist.addService(serv, True)
     tot += 1
     break
    cnt += 1
   self.VViCzN(VVkINB, mutableList, tot)
 def VVmOcl(self, VVkINB):
  names = VVkINB.VV92Is(2)
  name = "Bouquet-1"
  num = 0
  while name in names:
   num += 1
   name = "Bouquet-%s" % num
  FF8ISk(self, BF(self.VV8pJu, VVkINB), defaultText=name, title="New Bouquet", message="Enter Bouquet name")
 def VV8pJu(self, VVkINB, name=None):
  if name and name.strip():
   FFkWFV(VVkINB, BF(self.VV2BWM, VVkINB, name.strip()))
 def VV2BWM(self, VVkINB, bName):
  CCMyrC.VV11cv(bName)
  self.VViCzN(VVkINB, None, 1, jumpDict={2:bName})
 def VVpaP1(self):
  lst = []
  for fil in os.listdir(VVMixw):
   if fil.endswith(".tv.del") or fil.endswith(".radio.del"):
    lst.append(fil)
  return lst
 def VVe3MU(self, VVkINB):
  lst = self.VVpaP1()
  for fil in lst:
   FFMc8G(VVMixw + fil)
  VVkINB.VVpB4f("Done")
 def VVNa1q(self, VVkINB):
  if VVkINB.VVopq8 : return VVkINB.VVYlFT(3)
  else        : return [VVkINB.VVw0xB()[3]]
 def VVFtYA(self, VVkINB):
  dstFile = "bouquets.%s" % ("tv" if CC01PH.VVlkXF() == 0 else "radio")
  FFkWFV(VVkINB, BF(self.VVzURN, VVkINB, "Main Bouquets List", dstFile, True))
 def VVrGhn(self, VVkINB):
  bRows = CCMyrC.VVXXpV()
  lst = self.VVNa1q(VVkINB)
  VVgktg = []
  for name, ref in bRows:
   if not ref in lst:
    VVgktg.append((name, ref))
  if VVgktg : FFBqvZ(self,  BF(self.VVEqjI, VVkINB), VVgktg=VVgktg, width=1100, height=900, VVrcFy="#22220000", VVZZ3c="#22110000", title="Destination Bouquet", VVomDt=True)
  else  : FFpIgV(VVkINB, "No bouquets left !", 1000)
 def VVEqjI(self, VVkINB, item=None):
  if item:
   bName, bRef, ndx = item
   dstFile = CCMyrC.VVETMB(bRef)
   FFkWFV(VVkINB, BF(self.VVzURN, VVkINB, bName, dstFile))
 def VVzURN(self, VVkINB, bName, dstFile, mainToo=False):
  lst = self.VVNa1q(VVkINB)
  tot = 0
  for ref in lst:
   ok = CCMyrC.VVP7kB(ref, dstFile)
   if ok:
    tot += 1
  self.VViCzN(VVkINB, None, tot)
  if mainToo:
   rootStr = CC01PH.VV8UPK()
   rows = self.VV5gaT(rootStr)
   self.bTables[0].VVDqeT(rows, VVc63JMsg=True)
  ttl = lambda x, y: "%s:\n%s\n\n" % (FF1YQ7(x, VVyz0j), y)
  txt  = ttl("Source Bouquet"  , VVkINB.bouqName)
  txt += ttl("Destination Bouquet", bName)
  txt += ttl("Copied Services" , tot)
  FF8ShK(VVkINB, txt, title="Copy Services")
 def VVPJid(self, VVkINB, isHide):
  FFkWFV(VVkINB, BF(self.VVZ7bd, VVkINB, isHide))
 def VVZ7bd(self, VVkINB, isHide):
  lst, mutableList, csel, bServ = self.VVytsl(VVkINB)
  mode = CC01PH.VVlkXF()
  path = VVMixw + "bouquets.%s" % ("tv" if mode==0 else "radio")
  if fileExists(path):
   tot = 0
   lines = list(map(str.strip, FFjqdo(path)))
   for ref in lst:
    if FF5JUW(ref):
     ref = "#SERVICE " + ref
     nrm = ref.replace("1:519:", "1:7:")
     hid = ref.replace("1:7:"  , "1:519:")
     if isHide: r1, r2 = nrm, hid
     else  : r1, r2 = hid, nrm
     if r1 in lines:
      ndx = lines.index(r1)
      lines[ndx] = r2
      tot += 1
   if tot:
    with open(path, "w") as f:
     for line in lines:
      f.write("%s\n" % line)
    self.VViCzN(VVkINB, None, tot)
 def VVzJz2(self, VVkINB, isLck):
  FFkWFV(VVkINB, BF(self.VVTCnc, VVkINB, isLck))
 def VVTCnc(self, VVkINB, isLck):
  lst, mutableList, csel, bServ = self.VVytsl(VVkINB)
  blkLst = CC01PH.VVWtjU()
  tot = 0
  for ref in lst:
   if FF5JUW(ref):
    ndx = CC01PH.VVUxz1(ref, blkLst)
    if isLck:
     if ndx == -1:
      ref = ref.replace("1:519:", "1:0:").replace("1:7:", "1:0:")
      blkLst.append(ref)
      tot += 1
    else:
     if ndx > -1:
      blkLst[ndx] = ""
      tot += 1
  if tot:
   with open(VV6lWZ, "w") as f:
    for line in blkLst:
     if line.strip():
      f.write("%s\n" % line)
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   self.VViCzN(VVkINB, None, tot)
 def VVytsl(self, VVkINB, bServ=None):
  lst = self.VVNa1q(VVkINB)
  mutableList = csel = None
  VVw847 = InfoBar.instance
  if VVw847:
   csel = VVw847.servicelist
   if csel:
    if not bServ:
     bServ = eServiceReference(VVkINB.bouqRef)
    if bServ.valid():
     mutableList = csel.getMutableList(bServ)
  return lst,  mutableList, csel, bServ
 def VVs2sB(self, colList):
  num, picon, name, ref, rem, flags, lck = colList
  png = lambda x: "%s%s.png" % (VVkwgw, x)
  if   rem == "Marker"   : return png("mrk1")
  elif rem == "Numbered Marker" : return png("mrk2")
  elif rem == "Group"    : return png("grp")
  elif FF5JUW(ref):
   if   lck == "1" and rem == "Invisible" : return png("dirLckInvis")
   elif lck == "1"       : return png("dirLck")
   elif rem == "Invisible"     : return png("dirInvis")
   else         : return png("dir1")
  else:
   return CCQVwA.VVSjPn(self.pPath, ref, name)
 @staticmethod
 def VVA7QI(flag):
  t = c = ""
  try:
   if   flag & eServiceReference.isInvisible  : t, c = "Invisible"  , "#f#00ff7722#"
   elif flag & eServiceReference.isNumberedMarker : t, c = "Numbered Marker" , "#f#00ffffaa#"
   elif flag & eServiceReference.isGroup   : t, c = "Group"   , "#f#00bbffbb#"
   elif flag & eServiceReference.isMarker   : t, c = "Marker"   , "#f#00ffffaa#"
   elif flag & eServiceReference.isDirectory  : t, c = "Directory"  , ""
  except:
   pass
  return t, c
 @staticmethod
 def VVbeeT(ref, mode=0):
  path = ""
  serv = eServiceReference(ref)
  if serv.valid():
   path = serv.getPath()
   if path and not VVxrH7:
    path = iSub(r"[&?]mode=.+end=", r"", path, flags=IGNORECASE)
   if mode == 1:
    span = iSearch(r'FROM\s+BOUQUET\s+"(.+)"\s+ORDER\s+BY\s+bouquet', path, IGNORECASE)
    if span:
     path = VVMixw + span.group(1)
  return path
 @staticmethod
 def VVS7kY(ref):
  path = ""
  serv = eServiceReference(ref)
  if serv.valid():
   return serv.flags
  return -1
 @staticmethod
 def VVlkXF(default=0):
  VVw847 = InfoBar.instance
  if VVw847:
   csel = VVw847.servicelist
   if csel:
    return csel.mode
  return default
 @staticmethod
 def VV8UPK():
  VVw847 = InfoBar.instance
  if VVw847:
   csel = VVw847.servicelist
   if csel:
    return csel.bouquet_rootstr
  return ""
 @staticmethod
 def VVWtjU():
  return FFjqdo(VV6lWZ) if fileExists(VV6lWZ) else []
 @staticmethod
 def VVUxz1(ref, lst=None):
  if not lst:
   lst = CC01PH.VVWtjU()
  if FF5JUW(ref):
   ref1 = ref.replace("1:7:", "1:0:")
   ref2 = ref.replace("1:519:", "1:0:")
   if   ref1 in lst: return lst.index(ref1)
   elif ref2 in lst: return lst.index(ref2)
  return -1
class CCQVwA(Screen, CCkk4o, CCnY2W):
 VVs3fL   = 0
 VV1Tqy  = 1
 VVrOh5  = 2
 VVsgYh  = 3
 VVadAc  = 4
 VVXxSb  = 5
 VVcXnL  = 6
 VVq4sk  = 7
 VVVtOR = 8
 VV4oAf = 9
 VVnQPE = 10
 VVFMyy = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFdP4M(VVg2zc, 1400, 840, 30, 0, 0, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "PIcons Tools"
  self.pPath    = CCQVwA.VVzkHI()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VV9gTz    = []
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  FFj3mb(self, self.Title)
  FFuetT(self["keyRed"] , "OK = Zap")
  FFuetT(self["keyGreen"] , "Current Service")
  FFuetT(self["keyYellow"], "Page Options")
  FFuetT(self["keyBlue"] , "Filter")
  CCkk4o.__init__(self, 5, 7, CFG.transpColorPicons)
  CCnY2W.__init__(self)
  self["myAction"].actions.update(
  {
   "ok"  : self.VVcOJY     ,
   "green"  : self.VVJM0u    ,
   "yellow" : self.VVycYP     ,
   "blue"  : self.VVQ5lo     ,
   "menu"  : self.VVthGJ     ,
   "info"  : self.VVSEc3    ,
   "pageUp" : BF(self.VVNj9Y, True) ,
   "chanUp" : BF(self.VVNj9Y, True) ,
   "pageDown" : BF(self.VVNj9Y, False) ,
   "chanDown" : BF(self.VVNj9Y, False) ,
   "0"   : self.VVNeBP  ,
   "cancel" : self.close
  })
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFIl1A(self)
  FF2kyZ(self)
  FFeNfF(self["keyRed"], "#0a333333")
  self.VVMqRC()
  FFkWFV(self, BF(self.VVZEBk, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVthGJ(self):
  if not self.isBusy:
   VVgktg = []
   VVgktg.append(("Statistics"           , "VVW8js"    ))
   VVgktg.append(VVm7kE)
   VVgktg.append(("Suggest PIcons for Current Channel"     , "VVgUzG"   ))
   VVgktg.append(("Set to Current Channel (copy file)"     , "VVF30Q_file"  ))
   VVgktg.append(("Set to Current Channel (as SymLink)"     , "VVF30Q_link"  ))
   VVgktg.append(VVm7kE)
   VVgktg.append(("Export Current File Names List"      , "VVX7qG" ))
   VVgktg.append(CCQVwA.VVQ96v())
   VVgktg.append(VVm7kE)
   c, cond = VVWgbP, self.filterTitle == "PIcons without Channels"
   VVgktg.append(FFVKGp("Move Unused PIcons to a Directory", "VVDBJu" , cond, c))
   VVgktg.append(FFVKGp("DELETE Unused PIcons"    , "VV78Xo" , cond, c))
   VVgktg.append(VVm7kE)
   VVgktg.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVn5eX"  ))
   VVgktg.append(VVm7kE)
   VVgktg += CCQVwA.VVixei()
   VVgktg.append(VVm7kE)
   VVgktg.append(("Change Poster/Picon Transparency Color"    , "VV2ZE7" ))
   VVgktg.append(("Keys Help"           , "VVzX2Q"    ))
   FFBqvZ(self, self.VVBssi, width=1100, height=1050, title=self.Title, VVgktg=VVgktg)
 def VVBssi(self, item=None):
  if item is not None:
   if   item == "VVW8js"    : self.VVW8js()
   elif item == "VVgUzG"   : self.VVgUzG()
   elif item == "VVF30Q_file"  : self.VVF30Q(0)
   elif item == "VVF30Q_link"  : self.VVF30Q(1)
   elif item == "VVX7qG"  : self.VVX7qG()
   elif item == "VVmdY1"  : CCQVwA.VVmdY1(self)
   elif item == "VVDBJu"   : self.VVDBJu()
   elif item == "VV78Xo"  : self.VV78Xo()
   elif item == "VVn5eX"  : self.VVn5eX()
   elif item == "VVjypC"  : CCQVwA.VVjypC(self)
   elif item == "findPiconBrokenSymLinks" : CCQVwA.VV6Oh0(self, True)
   elif item == "FindAllBrokenSymLinks" : CCQVwA.VV6Oh0(self, False)
   elif item == "VV2ZE7" : self.VV2ZE7()
   elif item == "VVzX2Q"     : FFxVrN(self, "_help_picons", "PIcons Tools (Keys Help)")
 def VVycYP(self):
  if not self.isBusy:
   VVgktg = []
   VVgktg.append(("Go to First PIcon"  , "VVvfk2"  ))
   VVgktg.append(("Go to Last PIcon"   , "VVna77"  ))
   VVgktg.append(VVm7kE)
   VVgktg.append(("Sort by Channel Name"     , "sortByChan" ))
   VVgktg.append(("Sort by File Name"  , "sortByFile" ))
   VVgktg.append(VVm7kE)
   VVgktg.append(("Find from File List .." , "VVuhVm" ))
   FFBqvZ(self, self.VV8VeS, title=self.Title, VVgktg=VVgktg)
 def VV8VeS(self, item=None):
  if item is not None:
   if   item == "VVvfk2"   : self.VVvfk2()
   elif item == "VVna77"   : self.VVna77()
   elif item == "sortByChan"  : self.VVOb9i(2)
   elif item == "sortByFile"  : self.VVOb9i(0)
   elif item == "VVuhVm"  : self.VVuhVm()
 def VVuhVm(self):
  VVgktg = []
  for item in self.VV9gTz:
   VVgktg.append((item[0], item[0]))
  FFBqvZ(self, self.VVouDZ, title='PIcons ".png" Files', VVgktg=VVgktg, VVomDt=True)
 def VVouDZ(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVJ3Do(ndx)
 def VVcOJY(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VV4Orm()
   if refCode:
    FFWpQx(self, refCode)
    self.VVahQZ()
    self.VVELkX()
 def VVNj9Y(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVahQZ()
   self.VVELkX()
  except:
   pass
 def VVJM0u(self):
  if self["keyGreen"].getVisible():
   self.VVJ3Do(self.curChanIndex)
 def VVOb9i(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFkWFV(self, BF(self.VVZEBk, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVF30Q(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VV4Orm()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVgktg = []
     VVgktg.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVgktg.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFBqvZ(self, BF(self.VV0dPM, mode, curChF, selPiconF), VVgktg=VVgktg, title="Current Channel PIcon (already exists)")
    else:
     self.VV0dPM(mode, curChF, selPiconF, "overwrite")
   else:
    FFG2mq(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFG2mq(self, "Could not read current channel info. !", title=title)
 def VV0dPM(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   FFLgW2(cmd)
   FFkWFV(self, BF(self.VVZEBk, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVDBJu(self):
  defDir = FFGa2t(CCQVwA.VVzkHI() + "picons_backup")
  FFLgW2("mkdir '%s'" % defDir)
  self.session.openWithCallback(BF(self.VVPfSq, defDir), BF(CCyssW
         , mode=CCyssW.VVaEvY, VV9Esa=CCQVwA.VVzkHI()))
 def VVPfSq(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCQVwA.VVzkHI():
    FFG2mq(self, "Cannot move to same directory !", title=title)
   else:
    if not FFGa2t(path) == FFGa2t(defDir):
     self.VV51JK(defDir)
    FFDiGG(self, BF(FFkWFV, self, BF(self.VVEpe2, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VV9gTz), path), title=title)
  else:
   self.VV51JK(defDir)
 def VVEpe2(self, title, defDir, toPath):
  if not iMove:
   self.VV51JK(defDir)
   FFG2mq(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FFGa2t(toPath)
  pPath = CCQVwA.VVzkHI()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VV9gTz:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VV9gTz)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FF8ShK(self, txt, title=title, VVRr4z="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVxTBo("all")
 def VV51JK(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VV78Xo(self):
  title = "Delete Unused PIcons"
  tot = len(self.VV9gTz)
  FFDiGG(self, BF(FFkWFV, self, BF(self.VVZnBR, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FFLFel(tot)), title=title)
 def VVZnBR(self, title):
  pPath = CCQVwA.VVzkHI()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VV9gTz:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VV9gTz)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FF1YQ7(str(totErr), VVf8NN)
  FF8ShK(self, txt, title=title)
 def VVn5eX(self):
  lines = FFa467("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FFDiGG(self, BF(self.VVOyLu, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FFLFel(tot)), VVm2Fj=True)
  else:
   FF27fq(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVOyLu(self, fList):
  FFLgW2("find -L '%s' -type l -delete" % self.pPath)
  FF27fq(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVSEc3(self):
  FFkWFV(self, self.VVxZ6K)
 def VVxZ6K(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VV4Orm()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FF1YQ7("PIcon Directory:\n", VV4aa0)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FFYfiw(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFYfiw(path)
   txt += FF1YQ7("PIcon File:\n", VV4aa0)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FF1YQ7("Found %d SymLink%s to this file from:\n" % (tot, FFLFel(tot)), VV4aa0)
     for fPath in slLst:
      txt += "  %s\n" % FF1YQ7(fPath, VVdl3O)
     txt += "\n"
   if chName:
    txt += FF1YQ7("Channel:\n", VV4aa0)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FF1YQ7(chName, VVNQoM)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FF1YQ7("Remarks:\n", VV4aa0)
    txt += "  %s\n" % FF1YQ7("Unused", VVf8NN)
  else:
   txt = "No info found"
  FFPrkv(self, fncMode=CCXzVR.VVPeIV, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VV4Orm(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalItems:
   fName, fType, chName, sat, inDB = self.VV9gTz[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFDSYZ(sat)
  return fName, refCode, chName, sat, inDB
 def VVahQZ(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VV9gTz):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVELkX(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VV4Orm()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalItems)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FF1YQ7("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VV4aa0))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VV4Orm()[1]))
  if self.curChanIptvRef : typ = "Stream Relay" if FFtvcx(self.curChanIptvRef) else "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FF1YQ7(self.curChanName, VVChVP)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
  filName, refCode, chName, sat, inDB = self.VV4Orm()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVW8js(self):
  VVASq4, VVQ0ZT = FFGsAb()
  sTypeNameDict = {}
  for key, val in VVQ0ZT.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VV9gTz:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VVQ0ZT: sTypeDict[VVQ0ZT[stNum]] = sTypeDict.get(VVQ0ZT[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FFdHIn("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVUl7I = []
  c = "#b#11003333#"
  VVUl7I.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalItems, totUsedFiles + totUsedLinks)))
  VVUl7I.append((c + "Files" , "%d\tUsed = %s" % (self.totalItems - totSymLinks, totUsedFiles)))
  VVUl7I.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVUl7I.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVUl7I.append((c + "Not In Database (lamedb)" , str(self.totalItems - totInDB)))
  VVUl7I.append((c + "Satellites"    , str(len(self.nsList))))
  VVUl7I.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVUl7I.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVUl7I.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVUl7I.extend(sTypeRows)
  FF69ky(self, None, title=self.Title, VV9gTz=VVUl7I, VVvi36=28, VVLwCQ="#00003333", VVhvzQ="#00222222")
 def VVX7qG(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FFGa2t(CFG.exportedTablesPath.getValue()), txt, FF4Fnb())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VV9gTz:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FF27fq(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVQ5lo(self):
  if not self.isBusy:
   VVgktg = []
   VVgktg.append(("All"        , "all"  ))
   VVgktg.append(VVm7kE)
   VVgktg.append(("Used by Channels"     , "used" ))
   VVgktg.append(("Unused PIcons"     , "unused" ))
   VVgktg.append(("IPTV PIcons"      , "iptv" ))
   VVgktg.append(VVm7kE)
   VVgktg.append(("PIcons Files"      , "pFiles" ))
   VVgktg.append(("SymLinks to PIcons"    , "pLinks" ))
   VVgktg.append(("PIcons Files Targeted by SymLinks", "pTargets"))
   VVgktg.append(("By Files Date ..."    , "pDate" ))
   VVgktg.append(("By Service Type ..."    , "servType"))
   if self.nsList:
    VVgktg.append(FFZRMI("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFAOQQ(val)
      VVgktg.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCYFnw(self)
   filterObj.VVZvwW(VVgktg, self.nsList, self.VV1XaR)
 def VV1XaR(self, item=None):
  if item is not None:
   self.VVxTBo(item)
 def VVxTBo(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVs3fL   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VV1Tqy   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVrOh5  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVcXnL   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVsgYh  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVadAc  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVXxSb  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VVnQPE , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VVFMyy , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVq4sk   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVVtOR , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVXxSb:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFa467("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFBBEq(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFpIgV(self, "Not found", 1000)
     return
   elif mode == self.VVnQPE:
    self.VVVktT(mode)
    return
   elif mode == self.VVFMyy:
    self.VVfpmp(mode)
    return
   elif mode == self.VV4oAf:
    return
   else:
    words, asPrefix = CCYFnw.VVt9Ew(words)
   if not words and mode in (self.VVq4sk, self.VVVtOR):
    FFpIgV(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFkWFV(self, BF(self.VVZEBk, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVVktT(self, mode):
  VVgktg = []
  VVgktg.append(("Today"   , "today" ))
  VVgktg.append(("Since Yesterday" , "yest" ))
  VVgktg.append(("Since 7 days"  , "week" ))
  FFBqvZ(self, BF(self.VVOWnA, mode), VVgktg=VVgktg, title="Filter by Added/Modified Date")
 def VVOWnA(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFv0f4(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFv0f4(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFv0f4(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FFkWFV(self, BF(self.VVZEBk, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVfpmp(self, mode):
  VVASq4, VVQ0ZT = FFGsAb()
  lst = set()
  for key, val in VVQ0ZT.items():
   lst.add(val)
  VVgktg = []
  for item in lst:
   VVgktg.append((item, item))
  VVgktg.sort(key=lambda x: x[0])
  FFBqvZ(self, BF(self.VV0XTi, mode), VVgktg=VVgktg, title="Filter by Service Type")
 def VV0XTi(self, mode, item=None):
  if item:
   VVASq4, VVQ0ZT = FFGsAb()
   sTypeList = []
   for key, val in VVQ0ZT.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FFkWFV(self, BF(self.VVZEBk, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVgUzG(self):
  self.session.open(CCKX0k, barTheme=CCKX0k.VVfjb8
      , titlePrefix = ""
      , fncToRun  = self.VVDMN9
      , VVJ8mq = self.VV0Q8L)
 def VVDMN9(self, VVzRAM):
  VVN0xv, err = CCmfL4.VVwWVD(self, CCmfL4.VVQkKK, VV1Nw8=False, VVoFHD=False)
  files = []
  words = []
  if not VVzRAM or VVzRAM.isCancelled:
   return
  VVzRAM.VVgo83 = []
  VVzRAM.VVGeXq(len(VVN0xv))
  if VVN0xv:
   curCh = self.VVP5Ly(self.curChanName)
   for refCode in VVN0xv:
    if not VVzRAM or VVzRAM.isCancelled:
     return
    VVzRAM.VVu4eE(1, True)
    chName, sat, inDB = VVN0xv.get(refCode, ("", "", 0))
    ratio = CCQVwA.VVrcfj(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCQVwA.VVFpkT(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFBBEq(f)
       fil = f.replace(".png", "")
       if not fil in VVzRAM.VVgo83:
        VVzRAM.VVgo83.append(fil)
 def VV0Q8L(self, VV4mF1, VVgo83, threadCounter, threadTotal, threadErr):
  if VVgo83 : FFkWFV(self, BF(self.VVZEBk, mode=self.VV4oAf, words=VVgo83), title="Loading ...")
  else   : FFpIgV(self, "Not found", 2000)
 def VVZEBk(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VVTZEe(isFirstTime):
   return
  self.isBusy = True
  VVoFHD = True if isFirstTime else False
  VVN0xv, err = CCmfL4.VVwWVD(self, CCmfL4.VVQkKK, VV1Nw8=False, VVoFHD=VVoFHD)
  if err:
   self.close()
  iptvRefList = self.VV0gEW()
  tList = []
  for fName, fType in CCQVwA.VVbOxR(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVN0xv:
    if fName in VVN0xv:
     chName, sat, inDB = VVN0xv.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVs3fL:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VV1Tqy  and chName         : isAdd = True
   elif mode == self.VVrOh5 and not chName        : isAdd = True
   elif mode == self.VVsgYh  and fType == 0        : isAdd = True
   elif mode == self.VVadAc  and fType == 1        : isAdd = True
   elif mode == self.VVXxSb  and fName in words       : isAdd = True
   elif mode == self.VV4oAf and fName in words       : isAdd = True
   elif mode == self.VVcXnL  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVq4sk  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVVtOR:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VVnQPE:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VVFMyy:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VV9gTz   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FFpIgV(self)
  else:
   self.isBusy = False
   FFpIgV(self, "Not found", 1000)
   return
  self.VV9gTz.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVahQZ()
  self.totalItems = len(self.VV9gTz)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self.isBusy = False
  self.VV32Ix(True)
 def VVTZEe(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCQVwA.VVbOxR(self.pPath):
    if fName:
     return True
   if isFirstTime : FFG2mq(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFpIgV(self, "Not found", 1000)
  else:
   FFG2mq(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VV0gEW(self):
  VVUl7I = {}
  files  = CCul6W.VVMJXK()
  if files:
   for path in files:
    txt = FFSIRe(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVUl7I[refCode] = item[1]
  return VVUl7I
 def VVewtM(self):
  self.VVy2mb()
  f1, f2 = self.VVzqa0()
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VV9gTz[ndx]
   fName = self.VV9gTz[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   if CCkk4o.VVUPy4(pic, path) : color = VVNQoM if inDB else ""
   elif not chName           : color = ""
   else             : color = VVJU8R
   self.VVF2QO(lbl, chName or "-", color)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVrcfj(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVQ96v():
  return ("Copy Current Channel PIcon (to PIcons Export Path)", "VVmdY1")
 @staticmethod
 def VVixei():
  VVgktg = []
  VVgktg.append(("Find SymLinks (to PIcon Directory)"   , "VVjypC"  ))
  VVgktg.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks" ))
  VVgktg.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks" ))
  return VVgktg
 @staticmethod
 def VVmdY1(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(SELF)
  png, path = CCQVwA.VV4b82(refCode)
  if path : CCQVwA.VVdmuI(SELF, png, path)
  else : FFG2mq(SELF, "No PIcon found for current channel in:\n\n%s" % CCQVwA.VVzkHI())
 @staticmethod
 def VVjypC(SELF):
  if VVChVP:
   sed1 = FFog5k("->", VVChVP)
   sed2 = FFog5k("picon", VVf8NN)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVJU8R, VVTKcZ)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFTKzr(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFZu9n(), grep, sed1, sed2, sed3))
 @staticmethod
 def VV6Oh0(SELF, isPIcon):
  sed1 = FFog5k("->", VVJU8R)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFog5k("picon", VVf8NN)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFTKzr(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFZu9n(), grep, sed1, sed2))
 @staticmethod
 def VVdmuI(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFog5k("%s%s" % (dest, png), VVNQoM))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFog5k(errTxt, VVYZPJ))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFL00E(SELF, cmd)
 @staticmethod
 def VVbOxR(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVzkHI():
  path = CFG.PIconsPath.getValue()
  return FFGa2t(path)
 @staticmethod
 def VV4b82(refCode, chName=None):
  if FFUsGW(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFzXIA(refCode)
  allPath, fName, refCodeFile, pList = CCQVwA.VVFpkT(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return "", ""
 @staticmethod
 def VVSjPn(pPath, refCode, chName):
  span = iSearch(r"^((?:[A-Fa-f0-9]+:){10})", refCode.strip())
  if span:
   exts = ("png", "jpg")
   refCode = span.group(1).rstrip(":").replace(":", "_")
   tPath = "%s%s." % (pPath, refCode)
   for ext in exts:
    path = tPath + ext
    if fileExists(path):
     return path
   refParts = refCode.split("_", 1)
   for rType in CCul6W.VVEoQY():
    if not rType == refParts[0]:
     for ext in exts:
      path = "%s%s_%s.%s" %  (pPath, rType, refParts[1], ext)
      if fileExists(path):
       return path
   chName = FFOD7l(chName)
   chName1 = chName.replace(" ", "")
   for name in (chName, chName.lower(), chName.upper(), chName1.lower(), chName1.upper()):
    for ext in exts:
     path = "%s%s.%s" % (pPath, name, ext)
     if fileExists(path):
      return path
  return ""
 @staticmethod
 def VVFpkT(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   fName = fName.rstrip(":")
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCQVwA.VVzkHI()
   pList = []
   lst = FFcJlI(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FFOD7l(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFBBEq(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCp4dL():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVdMUB  = None
  self.VV9JGm = ""
  self.VVmou8  = noService
  self.VVicfS = 0
  self.VVeOSQ  = noService
  self.VVsPfa = 0
  self.VVYFKd  = "-"
  self.VVqPhq = 0
  self.VVdd5c  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVosRD(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVdMUB = frontEndStatus
     self.VVPirC()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVPirC(self):
  if self.VVdMUB:
   val = self.VVdMUB.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VV9JGm = "%3.02f dB" % (val / 100.0)
   else         : self.VV9JGm = ""
   val = self.VVdMUB.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVicfS = int(val)
   self.VVmou8  = "%d%%" % val
   val = self.VVdMUB.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVsPfa = int(val)
   self.VVeOSQ  = "%d%%" % val
   val = self.VVdMUB.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVYFKd  = "%d" % val
   val = int(val * 100 / 500)
   self.VVqPhq = min(500, val)
   val = self.VVdMUB.get("tuner_locked", 0)
   if val == 1 : self.VVdd5c = "Locked"
   else  : self.VVdd5c = "Not locked"
 def VVkdrE(self)   : return self.VV9JGm
 def VViH7W(self)   : return self.VVmou8
 def VV2plV(self)  : return self.VVicfS
 def VVjqRZ(self)   : return self.VVeOSQ
 def VV5sQq(self)  : return self.VVsPfa
 def VVp4lT(self)   : return self.VVYFKd
 def VVYsH4(self)  : return self.VVqPhq
 def VVsz5V(self)   : return self.VVdd5c
 def VVEVjZ(self) : return self.serviceName
class CC5l6x():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVAout(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFmxJt(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVNpEA(self.ORPOS  , mod=1   )
      self.sat2  = self.VVNpEA(self.ORPOS  , mod=2   )
      self.freq  = self.VVNpEA(self.FREQ  , mod=3   )
      self.sr   = self.VVNpEA(self.SR   , mod=4   )
      self.inv  = self.VVNpEA(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVNpEA(self.POL  , self.D_POL )
      self.fec  = self.VVNpEA(self.FEC  , self.D_FEC )
      self.syst  = self.VVNpEA(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVNpEA("modulation" , self.D_MOD )
       self.rolof = self.VVNpEA("rolloff"  , self.D_ROLOF )
       self.pil = self.VVNpEA("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVNpEA("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVNpEA("pls_code"  )
       self.iStId = self.VVNpEA("is_id"   )
       self.t2PlId = self.VVNpEA("t2mi_plp_id" )
       self.t2PId = self.VVNpEA("t2mi_pid"  )
 def VVNpEA(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFAOQQ(val)
  elif mod == 2   : return FFthxA(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VVEZJz(self, refCode):
  txt = ""
  self.VVAout(refCode)
  if self.data:
   def VVy4Ld(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVy4Ld("System"   , self.syst)
    txt += VVy4Ld("Satellite"  , self.sat2)
    txt += VVy4Ld("Frequency"  , self.freq)
    txt += VVy4Ld("Inversion"  , self.inv)
    txt += VVy4Ld("Symbol Rate"  , self.sr)
    txt += VVy4Ld("Polarization" , self.pol)
    txt += VVy4Ld("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVy4Ld("Modulation" , self.mod)
     txt += VVy4Ld("Roll-Off" , self.rolof)
     txt += VVy4Ld("Pilot"  , self.pil)
     txt += VVy4Ld("Input Stream", self.iStId)
     txt += VVy4Ld("T2MI PLP ID" , self.t2PlId)
     txt += VVy4Ld("T2MI PID" , self.t2PId)
     txt += VVy4Ld("PLS Mode" , self.plsMod)
     txt += VVy4Ld("PLS Code" , self.plsCod)
   else:
    txt += VVy4Ld("System"   , self.txMedia)
    txt += VVy4Ld("Frequency"  , self.freq)
  return txt, self.namespace
 def VVipj8(self, refCode):
  txt = "Transpoder : ?"
  self.VVAout(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VVSfcz(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFmxJt(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVNpEA(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVNpEA(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVNpEA(self.SYST, self.D_SYS_S)
     freq = self.VVNpEA(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVNpEA(self.POL , self.D_POL)
      fec = self.VVNpEA(self.FEC , self.D_FEC)
      sr = self.VVNpEA(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVSV38(self, refCode):
  self.data = None
  self.VVAout(refCode)
  if self.data and self.freq : return True
  else      : return False
class CC0TyL():
 def __init__(self, VVNXYW, path, VVJ8mq=None, curRowNum=-1):
  self.VVNXYW  = VVNXYW
  self.origFile   = path
  self.Title    = "File Editor: " + FFBBEq(path)
  self.VVJ8mq  = VVJ8mq
  self.tmpFile   = "/tmp/ajp_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  self.editorTable  = None
  if FFLgW2("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)):
   FFkWFV(self.VVNXYW, BF(self.VVTqS6, curRowNum), title="Loading file ...")
  else:
   FFG2mq(self.VVNXYW, "Error while preparing edit!")
 def VVTqS6(self, curRowNum):
  VVUl7I = self.VVuZdB()
  VVkY0R = ("Save Changes" , self.VV0U4H   , [])
  VVp0o5  = ("Edit Line"  , self.VVZJxW    , [])
  VVW1zM = ("Options"  , self.VVEGbU  , [])
  VVM4el = ("Line Options" , self.VViNEI   , [])
  VVgDd7 = (""    , self.VVd4uC , [])
  VVIcAB = self.VVU3SA
  VV1MrT  = self.VVkmlQ
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVwZxf  = (CENTER  , LEFT  )
  bg    = "#11001111"
  self.editorTable = FF69ky(self.VVNXYW, None, title=self.Title, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, width=1600, height=1000, VVvi36=26, isEditor=True, VVkY0R=VVkY0R, VVp0o5=VVp0o5, VVW1zM=VVW1zM, VVM4el=VVM4el, VVIcAB=VVIcAB, VV1MrT=VV1MrT, VVgDd7=VVgDd7, VVFwVS=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
        , VVrcFy=bg, VVZZ3c=bg, VVRr4z=bg, VVLwCQ="#05333333", VVhvzQ="#00303030", VVEjwd="#11331133")
  self.editorTable.VV2NBO(curRowNum)
 def VVkmlQ(self, VVkINB):
  VVkINB.VVETBP()
 def VVEGbU(self, VVkINB, title, txt, colList):
  VVgktg = []
  VVgktg.append(("Go to Line Num" , "toLine"))
  VVgktg.append(("Find & Replace" , "repl"))
  FFBqvZ(self.VVNXYW, self.VVD7Cr, VVgktg=VVgktg, width=500, title="Options", VVomDt=True)
 def VVD7Cr(self, item=None):
  if item:
   title, ref, ndx = item
   if   ref == "toLine" : self.VVFl3x()
   elif ref == "repl"  : self.VVFQf5(title)
 def VVFQf5(self, title):
  fnd = CFG.lastFindRepl_fnd.getValue()
  rpl = CFG.lastFindRepl_rpl.getValue()
  lst = [(" Find", fnd, str(len(fnd))), (" Replace with", rpl, str(len(rpl)))]
  bg = "#11101010"
  VVp0o5  = ("Change" , BF(self.VVUOvx, title, lst) , [])
  VVkY0R = ("Start" , BF(self.VVjnaJ, title)  , [])
  header  = (" Subject", " Text" , "Len.")
  widths  = (20   , 70  , 10 )
  VVwZxf = (LEFT   , LEFT  , CENTER)
  FF69ky(self.VVNXYW, None, title=title, VV9gTz=lst, header=header, VVwZxf=VVwZxf, VVYiuZ=widths, width=1200, VVvi36=30, isEditor=True, VVp0o5=VVp0o5, VVkY0R=VVkY0R, VVDWdv=2
    , VVrcFy=bg, VVZZ3c=bg, VVRr4z=bg, VVLwCQ="#06224455", VVhvzQ="#0a303030")
 def VVUOvx(self, Title, lst, VVkINB, title, txt, colList):
  title = VVkINB.VVRYeh(0)
  ndx = VVkINB.VVnbBC()
  txt = CFG.lastFindRepl_fnd.getValue() if ndx == 0 else CFG.lastFindRepl_rpl.getValue()
  FF8ISk(self.VVNXYW, BF(self.VVu9AZ, VVkINB, ndx), title=title, defaultText=txt, message="New entry")
 def VVu9AZ(self, VVkINB, ndx, newTxt=None):
  if newTxt:
   if ndx == 0 : FFeLB8(CFG.lastFindRepl_fnd, newTxt)
   else  : FFeLB8(CFG.lastFindRepl_rpl, newTxt)
   VVkINB.VVa8VT({1:newTxt, 2:len(newTxt)})
 def VVjnaJ(self, Title, VVkINB, title, txt, colList):
  fnd = CFG.lastFindRepl_fnd.getValue()
  rpl = CFG.lastFindRepl_rpl.getValue()
  if len(fnd) > 0:
   txt = FFSIRe(self.tmpFile)
   tot = txt.count(fnd)
   if tot > 0:
    FFDiGG(self.VVNXYW, BF(FFkWFV, VVkINB, BF(self.VVQeTD, VVkINB, fnd, rpl), title="Replacing ..."), "Replace %d occurrences ?" % tot, title=Title)
   else:
    FFpIgV(VVkINB, "Not found in file !", 1000)
    VVkINB.VV2NBO(0)
  else:
   FFpIgV(VVkINB, "Nothing to find", 1000)
 def VVQeTD(self, VVkINB, fnd, rpl):
  txt = FFSIRe(self.tmpFile)
  txt = txt.replace(fnd, rpl)
  with open(self.tmpFile, "w") as f:
   f.write(txt)
  VVkINB.cancel()
  self.fileChanged = True
  self.editorTable.VVmDzk()
  VVUl7I = self.VVuZdB()
  self.editorTable.VVDqeT(VVUl7I)
 def VVFl3x(self):
  totRows = self.editorTable.VVKW2u()
  lineNum = self.editorTable.VVnbBC() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FF8ISk(self.VVNXYW, BF(self.VVw6Lt, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VVw6Lt(self, lineNum, totRows, VVDhxg):
  if VVDhxg:
   VVDhxg = VVDhxg.strip()
   if VVDhxg.isdigit():
    num = FF5kC0(int(VVDhxg) - 1, 0, totRows)
    self.editorTable.VV2NBO(num)
    self.lastLineNum = num + 1
   else:
    FFpIgV(self.editorTable, "Incorrect number", 1500)
 def VViNEI(self, VVkINB, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVkINB.VVgq7g()
  VVgktg = []
  VVgktg.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVgktg.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVeUUf"  ))
  VVgktg.append(VVm7kE)
  VVgktg.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVgCDK:
   VVgktg.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVgktg.append(VVm7kE)
  VVgktg.append(  ("Delete Line"         , "deleteLine"   ))
  FFBqvZ(self.VVNXYW, BF(self.VVP4tA, lineNum), VVgktg=VVgktg, title="Line Options")
 def VVP4tA(self, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VV44M0("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile))
   elif item == "VVeUUf"  : self.VVeUUf(lineNum)
   elif item == "copyToClipboard"  : self.VVm5ER(lineNum)
   elif item == "pasteFromClipboard" : self.VV44d6(lineNum)
   elif item == "deleteLine"   : self.VV44M0("sed -i '%dd' '%s'" % (lineNum, self.tmpFile))
 def VVd4uC(self, VVkINB, title, txt, colList):
  if   self.insertMode == 1: VVkINB.VVdTes()
  elif self.insertMode == 2: VVkINB.VVQbYY()
  self.insertMode = 0
 def VVeUUf(self, lineNum):
  if lineNum == self.editorTable.VVgq7g():
   self.insertMode = 1
   self.VV44M0("echo '' >> '%s'" % self.tmpFile)
  else:
   self.insertMode = 2
   self.VV44M0("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile))
 def VVm5ER(self, lineNum):
  global VVgCDK
  VVgCDK = FFdHIn("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  self.editorTable.VVpB4f("Copied to clipboard")
 def VV0U4H(self, VVkINB, title, txt, colList):
  if self.fileChanged:
   if FFn35Z(self.origFile):
    if FFLgW2("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)):
     VVkINB.VVpB4f("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVkINB.VVETBP()
    else:
     FFG2mq(self.VVNXYW, "Cannot save file!")
   else:
    FFG2mq(self.VVNXYW, "Cannot create backup copy of original file!")
 def VVU3SA(self, VVkINB):
  if self.fileChanged:
   FFDiGG(self.VVNXYW, BF(self.VVkWsR, VVkINB), "Cancel changes ?")
  else:
   FFLgW2("cp -f '%s' '%s'" % (self.tmpFile, self.origFile))
   self.VVkWsR(VVkINB)
 def VVkWsR(self, VVkINB):
  VVkINB.cancel()
  FFMc8G(self.tmpFile)
  if self.VVJ8mq:
   self.VVJ8mq(self.fileSaved)
 def VVZJxW(self, VVkINB, title, txt, colList):
  lineNum = int(VVkINB.VVRYeh(0))
  lineTxt = VVkINB.VVRYeh(1, isStrip=False)
  message = VVTKcZ + "ORIGINAL TEXT:\n" + VVdl3O + lineTxt
  FF8ISk(self.VVNXYW, BF(self.VVURjb, lineNum), title="File Line", defaultText=lineTxt, message=message)
 def VVURjb(self, lineNum, VVDhxg):
  if not VVDhxg is None:
   if self.editorTable.VVgq7g() <= 1:
    self.VV44M0("echo %s > '%s'" % (VVDhxg, self.tmpFile))
   else:
    self.VV0Y9M(lineNum, VVDhxg)
 def VV44d6(self, lineNum):
  if lineNum == self.editorTable.VVgq7g() and self.editorTable.VVgq7g() == 1:
   self.VV44M0("echo %s >> '%s'" % (VVgCDK, self.tmpFile))
  else:
   self.VV0Y9M(lineNum, VVgCDK)
 def VV0Y9M(self, lineNum, newTxt):
  self.editorTable.VVeMZj("Saving ...")
  lines = FFjqdo(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  self.editorTable.VVmDzk()
  VVUl7I = self.VVuZdB()
  self.editorTable.VVDqeT(VVUl7I)
 def VV44M0(self, cmd):
  tCons = CCz78Z()
  tCons.ePopen(cmd, self.VVZDWu)
  self.fileChanged = True
  self.editorTable.VVmDzk()
 def VVZDWu(self, result, retval):
  VVUl7I = self.VVuZdB()
  self.editorTable.VVDqeT(VVUl7I)
 def VVuZdB(self):
  if fileExists(self.tmpFile):
   lines = FFjqdo(self.tmpFile)
   VVUl7I = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVUl7I.append((str(ndx), line))
   if not VVUl7I:
    VVUl7I.append((str(1), ""))
   return VVUl7I
  else:
   FFcMQr(self.VVNXYW, self.tmpFile)
class CCYFnw():
 def __init__(self, callingSELF, VVrcFy="#22003344", VVZZ3c="#22002233"):
  self.callingSELF = callingSELF
  self.VVgktg  = []
  self.satList  = []
  self.VVrcFy  = VVrcFy
  self.VVZZ3c   = VVZZ3c
 def VVk2Wn(self, VVJ8mq):
  self.VVgktg = []
  VVgktg, VVNisj = CCYFnw.VVXxWc(self.callingSELF, False, True)
  if VVgktg:
   self.VVgktg += VVgktg
   self.VV1y3F(VVJ8mq, VVNisj)
 def VV07rO(self, mode, VVkINB, satCol, VVJ8mq, inFilterFnc=None):
  VVkINB.VVeMZj("Loading Filters ...")
  self.VVgktg = []
  self.VVgktg.append(("All Services" , "all"))
  if mode == 1:
   self.VVgktg.append(VVm7kE)
   self.VVgktg.append(("Parental Control", "parentalControl" ))
   self.VVgktg.append(("Hidden Services" , "hiddenServices" ))
  elif mode == 2:
   self.VVgktg.append(VVm7kE)
   self.VVgktg.append(("Selected Transponder"   , "selectedTP" ))
   self.VVgktg.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVzYOW(VVkINB, satCol)
  VVgktg, VVNisj = CCYFnw.VVXxWc(self.callingSELF, True, False)
  if VVgktg:
   VVgktg.insert(0, FFZRMI("Custom Words"))
   self.VVgktg += VVgktg
  VVkINB.VVTm6g()
  self.VV1y3F(VVJ8mq, VVNisj, inFilterFnc)
 def VVZvwW(self, VVgktg, sats, VVJ8mq, inFilterFnc=None):
  self.VVgktg = VVgktg
  VVgktg, VVNisj = CCYFnw.VVXxWc(self.callingSELF, True, False)
  if VVgktg:
   self.VVgktg.append(FFZRMI("Custom Words"))
   self.VVgktg += VVgktg
  self.VV1y3F(VVJ8mq, VVNisj, inFilterFnc)
 def VV1y3F(self, VVJ8mq, VVNisj, inFilterFnc=None):
  VVG8PG  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VVG0eT = ("Edit Filter"  , BF(self.VVPZhp, VVNisj))
  VV2qPD  = ("Filter Help"  , BF(self.VV16Jr, VVNisj))
  FFBqvZ(self.callingSELF, BF(self.VVaU7K, VVJ8mq), VVgktg=self.VVgktg, title="Select Filter", VVG8PG=VVG8PG, VVG0eT=VVG0eT, VV2qPD=VV2qPD, VVRHyh=True, VVrcFy=self.VVrcFy, VVZZ3c=self.VVZZ3c)
 def VVaU7K(self, VVJ8mq, item):
  if item:
   VVJ8mq(item)
 def VVPZhp(self, VVNisj, selectionObj, sel):
  if fileExists(VVNisj) : CC0TyL(self.callingSELF, VVNisj, VVJ8mq=None)
  else       : FFcMQr(self.callingSELF, VVNisj)
  selectionObj.cancel()
 def VV16Jr(self, VVNisj, selectionObj, sel):
  FFxVrN(self.callingSELF, "_help_service_filter", "Service Filter")
 def VVzYOW(self, VVkINB, satColNum):
  if not self.satList:
   satList = VVkINB.VV92Is(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFDSYZ(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FFZRMI("Satellites"))
  if self.VVgktg:
   self.VVgktg += self.satList
 @staticmethod
 def VVXxWc(SELF, addTag, VVT0Gn):
  FFkDix()
  fileName  = "ajpanel_services_filter"
  VVNisj = VVrXLj + fileName
  VVgktg  = []
  if not fileExists(VVNisj):
   FFLgW2("cp -f '%s' '%s'" % (VVkwgw + fileName, VVNisj))
  fileFound = False
  if fileExists(VVNisj):
   fileFound = True
   lines = FFjqdo(VVNisj)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVgktg.append((line, "__w__" + line))
       else  : VVgktg.append((line, line))
  if VVT0Gn:
   if   not fileFound : FFcMQr(SELF, VVNisj)
   elif not VVgktg : FFM0Ji(SELF, VVNisj)
  return VVgktg, VVNisj
 @staticmethod
 def VVt9Ew(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CCVAoa():
 def __init__(self, callingSELF, VVkINB, addSep=True):
  self.callingSELF = callingSELF
  self.VVkINB = VVkINB
  self.VVgktg = []
  iMulSel = self.VVkINB.VVeANU()
  if iMulSel : self.VVgktg.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVgktg.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVkINB.VVIf28()
  self.VVgktg.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVgktg.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVgktg.append(VVm7kE)
 def VVLgo2(self, extraMenu, cbFncDict, okFnc=None, onMultiSelFnc=None, width=1000, height=850, VVrcFy="#22003344", VVZZ3c="#22002233"):
  self.VVkINB.onMultiSelFnc = onMultiSelFnc
  if extraMenu:
   self.VVgktg.extend(extraMenu)
  FFBqvZ(self.callingSELF, BF(self.VVegWk, cbFncDict, okFnc), width=width, height=height, title="Options", VVgktg=self.VVgktg, VVrcFy=VVrcFy, VVZZ3c=VVZZ3c)
 def VVegWk(self, cbFncDict, okFnc, item=None):
  if item:
   if   item == "multSelEnab" : self.VVkINB.VVBKwU(True)
   elif item == "MultSelDisab" : self.VVkINB.VVBKwU(False)
   elif item == "selectAll" : self.VVkINB.VVbpDn()
   elif item == "unselectAll" : self.VVkINB.VVPWK2()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
   if okFnc:
    okFnc()
class CCMnH7(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFdP4M(VV4ArL, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFj3mb(self)
  FFuetT(self["keyRed"]  , "Exit")
  FFuetT(self["keyGreen"]  , "Save")
  FFuetT(self["keyYellow"] , "Refresh")
  FFuetT(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(VVKDoB,
  {
   "red" : self.VVr4Bm  ,
   "green" : self.VVYA8E ,
   "yellow": self.VVDcQP  ,
   "blue" : self.VVmRVJ   ,
   "up" : self.VVRAom    ,
   "down" : self.VVOgNQ   ,
   "left" : self.VVvxS4   ,
   "right" : self.VV3Elm   ,
   "cancel": self.VVr4Bm
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VVgr8g)
  self.onClose.append(self.onExit)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  self.VVDcQP()
  self.VVhGGF()
  FF2kyZ(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVUHqr)
  except:
   self.timer.callback.append(self.VVUHqr)
  self.timer.start(1000, False)
  self.VVUHqr()
 def onExit(self):
  self.timer.stop()
 def VVr4Bm(self) : self.close(True)
 def VV4Gxg(self) : self.close(False)
 def VVmRVJ(self):
  self.session.openWithCallback(self.VVQC0W, BF(CCXH4E))
 def VVQC0W(self, closeAll):
  if closeAll:
   self.close()
 def VVUHqr(self):
  self["curTime"].setText(str(FFPuhT(iTime())))
 def VVRAom(self):
  self.VV2tCi(1)
 def VVOgNQ(self):
  self.VV2tCi(-1)
 def VVvxS4(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVhGGF()
 def VV3Elm(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVhGGF()
 def VV2tCi(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VV3HZw(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VV3HZw(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VV3HZw(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVEem9(year)):
   days += 1
  return days
 def VVEem9(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVhGGF(self):
  for obj in self.list:
   FFeNfF(obj, "#11404040")
  FFeNfF(self.list[self.index], "#11ff8000")
 def VVDcQP(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVYA8E(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCz78Z()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVcIVh)
 def VVcIVh(self, result, retval):
  result = str(result.strip())
  if len(result) == 0 : FF27fq(self, "Nothing returned from the system!")
  else    : FF27fq(self, str(result))
class CCXH4E(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFdP4M(VVWUpg, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFj3mb(self, addLabel=True)
  FFuetT(self["keyRed"]  , "Exit")
  FFuetT(self["keyGreen"]  , "Sync")
  FFuetT(self["keyYellow"] , "Refresh")
  FFuetT(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(VVKDoB,
  {
   "red" : self.VVr4Bm   ,
   "green" : self.VVuekG  ,
   "yellow": self.VV56vu ,
   "blue" : self.VViEzv  ,
   "cancel": self.VVr4Bm
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVc63J()
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  FF2kyZ(self)
  FFLYGh(self.VVYMbR)
 def VVYMbR(self):
  self.VVGoqf()
  self.VVyYgY(False)
 def VVr4Bm(self)  : self.close(True)
 def VViEzv(self) : self.close(False)
 def VVc63J(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVGoqf(self):
  self.VVBNrk()
  self.VVqz7e()
  self.VVc6GX()
  self.VVPjFL()
 def VV56vu(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVc63J()
   self.VVGoqf()
   FFLYGh(self.VVYMbR)
 def VVuekG(self):
  if len(self["keyGreen"].getText()) > 0:
   FFDiGG(self, self.VVsAoT, "Synchronize with Internet Date/Time ?")
 def VVsAoT(self):
  self.VVGoqf()
  FFLYGh(BF(self.VVyYgY, True))
 def VVBNrk(self)  : self["keyRed"].show()
 def VVNpvG(self)  : self["keyGreen"].show()
 def VVKxak(self) : self["keyYellow"].show()
 def VVUd1d(self)  : self["keyBlue"].show()
 def VVqz7e(self)  : self["keyGreen"].hide()
 def VVc6GX(self) : self["keyYellow"].hide()
 def VVPjFL(self)  : self["keyBlue"].hide()
 def VVyYgY(self, sync):
  localTime = FFzGjj()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVTcuQ(server)
   if epoch_time is not None:
    ntpTime = FFPuhT(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCz78Z()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VVcIVh, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVKxak()
  self.VVUd1d()
  if ok:
   self.VVNpvG()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVcIVh(self, syncAgain, result, retval):
  result = str(result.strip())
  if   len(result) == 0  : result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20: result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVyYgY(False)
  except:
   pass
 def VVTcuQ(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if CCUSzd.VVd24U():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCXhCY(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFdP4M(VVb4PG, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FFj3mb(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFLYGh(self.VVudls)
 def VVudls(self):
  if CCUSzd.VVd24U() : color, txt = "#22002020", "Internet Connection = Successful."
  else     : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFeNfF(self["myBody"], color)
   FFeNfF(self["myLabel"], color)
  except:
   pass
class CCN4DC(Screen):
 VVrpd7 = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFfQyb()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFdP4M(VVgvGh, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCUvxH(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCUvxH(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCUvxH(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCp4dL()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFj3mb(self, title="Signal")
  self["myActionMap"] = ActionMap(VVKDoB,
  {
   "ok"  : self.close      ,
   "up"  : self.VVRAom       ,
   "down"  : self.VVOgNQ      ,
   "left"  : self.VVvxS4      ,
   "right"  : self.VV3Elm      ,
   "info"  : self.VVCQHx     ,
   "epg"  : self.VVCQHx     ,
   "menu"  : self.VVzX2Q      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VVAFn8, -1)  ,
   "next"  : BF(self.VVAFn8, 1)  ,
   "pageUp" : BF(self.VVTLIu, True) ,
   "chanUp" : BF(self.VVTLIu, True) ,
   "pageDown" : BF(self.VVTLIu, False) ,
   "chanDown" : BF(self.VVTLIu, False) ,
   "0"   : BF(self.VVAFn8, 0)  ,
   "1"   : BF(self.VVuK2g, pos=1) ,
   "2"   : BF(self.VVuK2g, pos=2) ,
   "3"   : BF(self.VVuK2g, pos=3) ,
   "4"   : BF(self.VVuK2g, pos=4) ,
   "5"   : BF(self.VVuK2g, pos=5) ,
   "6"   : BF(self.VVuK2g, pos=6) ,
   "7"   : BF(self.VVuK2g, pos=7) ,
   "8"   : BF(self.VVuK2g, pos=8) ,
   "9"   : BF(self.VVuK2g, pos=9) ,
  }, -1)
  self.onShown.append(self.VVgr8g)
  self.onClose.append(self.onExit)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  if not CCN4DC.VVrpd7:
   CCN4DC.VVrpd7 = self
  self.sliderSNR.VV0WsD()
  self.sliderAGC.VV0WsD()
  self.sliderBER.VV0WsD(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVuK2g()
  self.VVt3W1()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVCQQL)
  except:
   self.timer.callback.append(self.VVCQQL)
  self.timer.start(500, False)
 def VVt3W1(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVosRD(service)
  serviceName = self.tunerInfo.VVEVjZ()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
  tp = CC5l6x()
  tpTxt, satTxt = tp.VVipj8(refCode)
  if tpTxt == "?" :
   tpTxt = FF1YQ7("NO SIGNAL", VVWgbP)
  self["myTPInfo"].setText(tpTxt + "  " + FF1YQ7(satTxt, VVyz0j))
 def VVCQQL(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVosRD(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVkdrE())
   self["mySNR"].setText(self.tunerInfo.VViH7W())
   self["myAGC"].setText(self.tunerInfo.VVjqRZ())
   self["myBER"].setText(self.tunerInfo.VVp4lT())
   self.sliderSNR.VVZhZc(self.tunerInfo.VV2plV())
   self.sliderAGC.VVZhZc(self.tunerInfo.VV5sQq())
   self.sliderBER.VVZhZc(self.tunerInfo.VVYsH4())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVZhZc(0)
   self.sliderAGC.VVZhZc(0)
   self.sliderBER.VVZhZc(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
    if state and not state == "Tuned":
     FFpIgV(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVCQHx(self):
  FFPrkv(self, fncMode=CCXzVR.VVKBIM)
 def VVzX2Q(self):
  FFxVrN(self, "_help_signal", "Signal Monitor (Keys)")
 def VVRAom(self)  : self.VVuK2g(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVOgNQ(self) : self.VVuK2g(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVvxS4(self) : self.VVuK2g(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VV3Elm(self) : self.VVuK2g(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVuK2g(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FFeLB8(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVAFn8(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FF5kC0(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FFeLB8(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CCN4DC.VVrpd7 = None
 def VVTLIu(self, isUp):
  FFpIgV(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVt3W1()
  except:
   pass
class CCUvxH(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VV0WsD(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFeNfF(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVkwgw +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFeNfF(self.covObj, self.covColor)
   else:
    FFeNfF(self.covObj, "#00006688")
    self.isColormode = True
  self.VVZhZc(0)
 def VVZhZc(self, val):
  val  = FF5kC0(val, self.minN, self.maxN)
  width = int(FFfvBi(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FF5kC0(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCKX0k(Screen):
 VVfjb8    = 0
 VVzy8h = 1
 VVp1vX = 2
 def __init__(self, session, titlePrefix="Processing ...", endTitle="Finishing ...", fncToRun=None, VVJ8mq=None, barTheme=VVfjb8, titleBg="#0a042328", bodyBg="#0a042328"):
  ratio = self.VVGDtZ(barTheme)
  self.skin, self.skinParam = FFdP4M(VV8KOT, 900, 200, 30, 40, 30, titleBg, bodyBg, 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.endTitle  = endTitle
  self.fncToRun  = fncToRun
  self.VVJ8mq = VVJ8mq
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVgo83 = None
  self.timer   = eTimer()
  self.myThread  = None
  FFj3mb(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(VVKDoB, { "cancel" : self.cancel }, -1)
  self.onShown.append(self.VVgr8g)
  self.onClose.append(self.onExit)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  self.VVHvpk()
  self["myProgBarVal"].setText("0%")
  FFeNfF(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVsieG()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVsieG)
  except:
   self.timer.callback.append(self.VVsieG)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VVGeXq(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVr1mh(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVgo83), self.counter, self.maxValue, catName)
 def VVqRqk(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVMbnP(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VVAaZR(self, tot, evName):
  self.newTitle = "Translated: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, evName)
 def VVLKr2(self, action, tot, name):
  self.newTitle = "%s: %d   ... %d/%d >> %s" % (action, tot, self.counter, self.maxValue, name)
 def VVsrWH(self, tot, name):
  self.newTitle = "Added: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, name)
 def VVyYoz(self, txt):
  self.newTitle = txt
 def VVu4eE(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VVgo83), self.counter, self.maxValue)
  except:
   pass
 def VVO2Ta(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVMHP5(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVE0Dg(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFpIgV(self, "Cancelling ...")
  self.isCancelled = True
  self.VV67nD(False)
 def VV67nD(self, isDone):
  FFLYGh(BF(self.VVsVrf, isDone))
 def VVsVrf(self, isDone):
  if self.VVJ8mq:
   self.VVJ8mq(isDone, self.VVgo83, self.counter, self.maxValue, self.isError)
  self.close()
 def VVsieG(self):
  val = FF5kC0(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFfvBi(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self["myTitle"].setText("  %s  " % self.endTitle)
    self.VV67nD(True)
 def VVHvpk(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVzy8h, self.VVp1vX):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVGDtZ(self, barTheme):
  if   barTheme == self.VVzy8h : return 0.7
  if   barTheme == self.VVp1vX : return 0.5
  else             : return 1
class CCz78Z(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVJ8mq = {}
  self.commandRunning = False
  self.VVYfey  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVJ8mq, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVJ8mq[name] = VVJ8mq
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVYfey:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVMpsx, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVGLLT , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVMpsx, name))
    self.appContainers[name].appClosed.append(BF(self.VVGLLT , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVGLLT(name, retval)
  return True
 def VVMpsx(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FF1YQ7("[UN-DECODED STRING]", VVWgbP))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVGLLT(self, name, retval):
  if not self.VVYfey:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVJ8mq[name]:
   self.VVJ8mq[name](self.appResults[name], retval)
  del self.VVJ8mq[name]
 def VVd1Nh(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCpvy4(Screen):
 def __init__(self, session, title="", VV4Fmi=None, VVdnhU=False, VV1ZDq=False, VVoFLA=False, VVJ4cj=False, VVWUJo=False, VVRUv5=False, VVMXNv=VVrJOZ, VVAJlf=None, VVQaO9=False, VVdaxv=None, VVklND="", checkNetAccess=False, VVvi36=30, consFont=False, enableSaveRes=True):
  self.skin, self.skinParam = FFdP4M(VViAAJ, 1600, 1000, 50, 40, 20, "#22003040", "#22001122", VVvi36, usefixedFont=consFont)
  self.session   = session
  self.VVklND = VVklND
  FFj3mb(self, addScrollLabel=True)
  self.VVdnhU   = VVdnhU
  self.VV1ZDq   = VV1ZDq
  self.VVoFLA   = VVoFLA
  self.VVJ4cj  = VVJ4cj
  self.VVWUJo = VVWUJo
  self.VVRUv5 = VVRUv5
  self.VVMXNv   = VVMXNv
  self.VVAJlf = VVAJlf
  self.VVQaO9  = VVQaO9
  self.VVdaxv  = VVdaxv
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCz78Z()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFMV8t()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VV4Fmi, str):
   self.VV4Fmi = [VV4Fmi]
  else:
   self.VV4Fmi = VV4Fmi
  if self.VVoFLA or self.VVJ4cj:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (SEP, SEP)
   self.VV4Fmi.append("echo -e '\n%s\n' %s" % (restartNote, FFog5k(restartNote, VVChVP)))
   if self.VVoFLA:
    self.VV4Fmi.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VV4Fmi.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVWUJo:
   FFpIgV(self, "Processing ...")
  self.onLayoutFinish.append(self.VVE8o6)
  self.onClose.append(self.VVAoKj)
 def VVE8o6(self):
  self["myLabel"].VVdp3X(outputFileToSave="console" if self.enableSaveRes else "")
  self["myLabel"].setText("   %s" % (self.VVklND or "Processing ..."))
  if self.VVdnhU:
   self["myLabel"].VVVjqa()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVXAAE()
  else:
   self.VVvdNF()
 def VVXAAE(self):
  if CCUSzd.VVd24U():
   self["myLabel"].setText("Processing ...")
   self.VVvdNF()
  else:
   self["myLabel"].setText(FF1YQ7("\n   No connection to internet!", VVf8NN))
 def VVvdNF(self):
  allOK = self.container.ePopen(self.VV4Fmi[0], self.VV5v89, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VV5v89("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVRUv5 or self.VVoFLA or self.VVJ4cj:
    self["myLabel"].setText(FFCQJ8("STARTED", VVChVP) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVdaxv:
   colorWhite = CC73JY.VVN66D(VVTKcZ)
   color  = CC73JY.VVN66D(self.VVdaxv[0])
   words  = self.VVdaxv[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVMXNv=self.VVMXNv)
 def VV5v89(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VV4Fmi):
   allOK = self.container.ePopen(self.VV4Fmi[self.cmdNum], self.VV5v89, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VV5v89("Cannot connect to Console!", -1)
  else:
   if self.VVWUJo and FFcGBG(self):
    FFpIgV(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVRUv5:
    self["myLabel"].appendText("\n" + FFCQJ8("FINISHED", VVChVP), self.VVMXNv)
   if self.VVdnhU or self.VV1ZDq:
    self["myLabel"].VVVjqa()
   if self.VVAJlf is not None:
    self.VVAJlf()
   if not retval and self.VVQaO9:
    self.VVAoKj()
 def VVAoKj(self):
  if self.container.VVd1Nh():
   self.container.killAll()
class CCrdgM(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFdP4M(VViAAJ, 1650, 950, 40, 20, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVrXLj + "ajpanel_terminal.history"
  self.customCommandsFile = ""
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFdHIn("pwd") or "/home/root"
  self.container   = CCz78Z()
  self.commandsList  = []
  self.exitBtnText  = "Exit = Interrupt"
  FFj3mb(self, title="Terminal", addScrollLabel=True)
  FFuetT(self["keyRed"] , self.exitBtnText)
  FFuetT(self["keyGreen"] , "OK = History")
  FFuetT(self["keyYellow"], "Menu = Custom Cmds")
  FFuetT(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok" : self.VVOTNa ,
   "cancel": self.VV3vA3  ,
   "menu" : self.VVs5I0 ,
   "last" : self.VViAYF  ,
   "next" : self.VViAYF  ,
   "1"  : self.VViAYF  ,
   "2"  : self.VViAYF  ,
   "3"  : self.VViAYF  ,
   "4"  : self.VViAYF  ,
   "5"  : self.VViAYF  ,
   "6"  : self.VViAYF  ,
   "7"  : self.VViAYF  ,
   "8"  : self.VViAYF  ,
   "9"  : self.VViAYF  ,
   "0"  : self.VViAYF
  })
  self.onLayoutFinish.append(self.VVgr8g)
  self.onClose.append(self.VVDIRl)
 def VVgr8g(self):
  self["myLabel"].VVdp3X(isResizable=False, outputFileToSave="terminal")
  FFfLQO(self["keyRed"]  , "#00ff8000")
  FFeNfF(self["keyRed"]  , self.skinParam["titleColor"])
  FFeNfF(self["keyGreen"]  , self.skinParam["titleColor"])
  FFeNfF(self["keyYellow"] , self.skinParam["titleColor"])
  FFeNfF(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVHSZA(FFdHIn("date"), 5)
  result = FFdHIn("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VV1vlz()
  self.VV3h1R()
 def VV3h1R(self):
  userFile = CFG.terminalCmdFile.getValue()
  alterFile = VVrXLj + "LinuxCommands.lst"
  templPath = VVkwgw + "ajpanel_cmd_list"
  if   fileExists(userFile) : self.customCommandsFile = userFile
  elif fileExists(alterFile): self.customCommandsFile = alterFile
  else:
   if not FFLgW2("cp -f '%s' '%s'" % (templPath, alterFile)):
    FFJ2Ng("echo -e 'pwd\ncd\ncd /tmp\nls\nls -ls' > '%s'" % alterFile)
   self.customCommandsFile = alterFile
 def VVDIRl(self):
  if self.container.VVd1Nh():
   self.container.killAll()
   self.VVHSZA("Process killed\n", 4)
   self.VV1vlz()
 def VV3vA3(self):
  if self.container.VVd1Nh():
   self.VVDIRl()
  else:
   FFDiGG(self, self.close, "Exit ?", VV5fzj=False)
 def VV1vlz(self):
  self.VVHSZA(self.prompt, 1)
  self["keyRed"].hide()
 def VVHSZA(self, txt, mode):
  if   mode == 1 : color = VVChVP
  elif mode == 2 : color = VV4aa0
  elif mode == 3 : color = VVTKcZ
  elif mode == 4 : color = VVf8NN
  elif mode == 5 : color = VVdl3O
  elif mode == 6 : color = VVqC3w
  else   : color = VVTKcZ
  try:
   self["myLabel"].appendText(FF1YQ7(txt, color))
  except:
   pass
 def VVOTNa(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVt1fR() == "":
   self.VVr930("cd /tmp")
   self.VVr930("ls")
  VVUl7I = []
  if fileExists(self.commandHistoryFile):
   lines  = FFjqdo(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVUl7I.append((str(c), line, str(lNum)))
   self.VVdCO2(VVUl7I, title, self.commandHistoryFile, isHistory=True)
  else:
   FFcMQr(self, self.commandHistoryFile, title=title)
 def VVt1fR(self):
  lastLine = FFdHIn("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVr930(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVs5I0(self, VVkINB=None):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines = FFjqdo(self.customCommandsFile)
   VVUl7I = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVUl7I.append((str(c), line, str(lNum)))
   if VVkINB:
    VVkINB.VVDqeT(VVUl7I)
    VVkINB.VV2NBO(CFG.lastTerminalCustCmdLineNum.getValue())
   else:
    self.VVdCO2(VVUl7I, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFcMQr(self, self.customCommandsFile, title=title)
 def VVdCO2(self, VVUl7I, title, filePath=None, isHistory=False):
  if VVUl7I:
   VVLwCQ = "#05333333"
   if isHistory: VVrcFy = VVZZ3c = VVRr4z = "#11000020"
   else  : VVrcFy = VVZZ3c = VVRr4z = "#06002020"
   VVp0o5   = ("Send"   , BF(self.VVMThv, isHistory)  , [])
   VVkY0R  = ("Modify & Send" , self.VVCUrR     , [])
   if isHistory:
    VVW1zM = ("Clear History" , self.VVB8HK     , [])
    VVM4el = None
    VVq5Be = None
   elif filePath:
    VVW1zM = ("Options"  , self.VVVpJn      , [])
    VVM4el = ("Edit File"  , BF(self.VVe1qP, filePath) , [])
    VVq5Be = (""    , self.VVYnew     , [])
   header  = ("No." , "Commands", "LineNum" )
   widths  = (7  , 93   , 0    )
   VVwZxf = (CENTER , LEFT   , CENTER )
   VVkINB = FF69ky(self, None, title=title, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=26, VVp0o5=VVp0o5, VVkY0R=VVkY0R, VVW1zM=VVW1zM, VVM4el=VVM4el, VVq5Be=VVq5Be, lastFindConfigObj=CFG.lastFindTerminal, VVFwVS=True, searchCol=1
         , VVrcFy=VVrcFy, VVZZ3c=VVZZ3c, VVRr4z=VVRr4z, VVLwCQ=VVLwCQ)
   if not isHistory:
    VVkINB.VV2NBO(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FFDiGG(self, BF(self.VVYik8, None, "Change Custom Commands File"), "File is empty:\n\n%s\n\nSelect another file ?" % self.customCommandsFile, title=title)
 def VVYnew(self, VVkINB, title, txt, colList):
  txt  = "%s\n%s\n\n" % (FF1YQ7("Command:", VVyz0j), colList[1])
  txt += "%s\n%s\n\n" % (FF1YQ7("Line %s in File:" % colList[2], VVyz0j), self.customCommandsFile)
  FF8ShK(self, txt, title=title)
 def VVVpJn(self, VVkINB, title, txt, colList):
  mSel = CCVAoa(self, VVkINB)
  VVgktg = []
  txt1 = "Change Custom Commands File"
  if VVkINB.VVopq8:
   VVgktg.append((txt1, ))
   VVgktg.append(VVm7kE)
   totSel = VVkINB.VVIf28()
   totTxt = str(totSel)
   txt2 = "Send %s Command%s" % (FF1YQ7(totTxt, VVChVP) if totSel else totTxt, FFLFel(totSel))
   VVgktg.append((txt2, "send") if totSel else (txt2,))
  else:
   VVgktg.append((txt1, "newFile"))
   VVgktg.append(VVm7kE)
   txt2 = "Send current line"
   VVgktg.append((txt2, "send"))
  cbFncDict = { "newFile" : BF(self.VVYik8, VVkINB, txt1)
     , "send" : BF(self.VVMThv, False, VVkINB, title, txt2, colList) }
  mSel.VVLgo2(VVgktg, cbFncDict, okFnc=BF(self.VVPnBz, VVkINB))
 def VVYik8(self, VVkINB, title):
  VVgktg = []
  for fName in os.listdir(VVrXLj):
   path = os.path.join(VVrXLj, fName)
   if fName.lower().startswith(("ajpanel_cmd", "linuxcommands")) and os.path.isfile(path):
    VVgktg.append((fName, path))
  VVgktg.sort(key=lambda x: x[0].lower())
  if VVgktg : FFBqvZ(self, BF(self.VVA2tZ, VVkINB, title), VVgktg=VVgktg, title=title, minRows=3, VVrcFy="#11220000", VVZZ3c="#11220000")
  else  : FFG2mq(self, "No valid files found in:\n\n%s" % VVrXLj, title=title)
 def VVA2tZ(self, VVkINB, title, path=None):
  if path:
   if CCyssW.VVk88F(path):
    FFG2mq(self, "Incorrect file format:\n\n%s" % path, title=title)
   else:
    lines = FFjqdo(path)
    for line in lines:
     if line.strip():
      oldF = self.customCommandsFile
      self.customCommandsFile = path
      FFeLB8(CFG.terminalCmdFile, path)
      if not oldF == self.customCommandsFile:
       FFeLB8(CFG.lastTerminalCustCmdLineNum, 0)
      self.VVs5I0(VVkINB)
      break
    else:
     FFG2mq(self, "File is empty:\n\n%s" % path, title=title)
 def VVPnBz(self, VVkINB):
  if VVkINB.VVopq8 : VVkINB.VVETBP()
  else        : VVkINB.VVmDzk()
 def VVMThv(self, isHistory, VVkINB, title, txt, colList):
  if VVkINB.VVopq8:
   lst = VVkINB.VVYlFT(1)
   curNdx = VVkINB.VVHLTv()
  else:
   lst = [colList[1]]
   curNdx = VVkINB.VVnbBC()
  if not isHistory:
   FFeLB8(CFG.lastTerminalCustCmdLineNum, curNdx)
  self.commandsList = lst
  VVkINB.cancel()
  FFLYGh(self.VVTckC)
 def VVTckC(self):
  if self.commandsList:
   cmd = self.commandsList[0]
   self.commandsList.pop(0)
   if not iMatch("^[a-zA-Z0-9_]", cmd):
    self.VVHSZA("\n%s\n" % cmd, 6)
    self.VVHSZA(self.prompt, 1)
    self.VVTckC()
   else:
    self.VVyOsa(cmd)
 def VVyOsa(self, cmd):
  tot = len(self.commandsList)
  self["keyRed"].setText("%s%s" % (self.exitBtnText, " (%s)" % tot if tot > 0 else ""))
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVHSZA(cmd, 2)
   self.VVHSZA("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVHSZA(ch, 0)
   self.VVHSZA("\nor\n", 4)
   self.VVHSZA("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VV1vlz()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FF1YQ7(parts[0].strip(), VV4aa0)
    right = FF1YQ7("#" + parts[1].strip(), VVqC3w)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVHSZA(txt, 2)
   lastLine = self.VVt1fR()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVr930(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VV5v89, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFG2mq(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVHSZA(data, 3)
 def VV5v89(self, data, retval):
  if not retval == 0:
   self.VVHSZA("Exit Code : %d\n" % retval, 4)
  self.VV1vlz()
  if self.commandsList:
   self.VVTckC()
 def VVCUrR(self, VVkINB, title, txt, colList):
  if VVkINB.VVqMjN():
   cmd = colList[1]
   self.VVLY5B(VVkINB, cmd)
 def VVB8HK(self, VVkINB, title, txt, colList):
  FFDiGG(self, BF(self.VVnvJe, VVkINB), "Reset History File ?", title="Command History")
 def VVnvJe(self, VVkINB):
  FFJ2Ng("> '%s'" % self.commandHistoryFile)
  VVkINB.cancel()
 def VVe1qP(self, filePath, VVkINB, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CC0TyL(self, filePath, VVJ8mq=BF(self.VV5Cc2, VVkINB), curRowNum=rowNum)
  else     : FFcMQr(self, filePath)
 def VV5Cc2(self, VVkINB, fileChanged):
  if fileChanged:
   VVkINB.cancel()
   FFLYGh(self.VVs5I0)
 def VViAYF(self):
  self.VVLY5B(None, self.lastCommand)
 def VVLY5B(self, VVkINB, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FF8ISk(self, BF(self.VV4bhZ, VVkINB), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VV4bhZ(self, VVkINB, cmd):
  if cmd and len(cmd) > 0:
   self.VVyOsa(cmd)
   if VVkINB:
    VVkINB.cancel()
class CC7Isx(Screen):
 def __init__(self, session, title="", message="", VVMXNv=VVrJOZ, width=1400, height=900, VVHrLx=False, titleBg="#22002020", VVRr4z="#22001122", VVvi36=30, titleFontSize=50, outputFileToSave=""):
  self.skin, self.skinParam = FFdP4M(VViAAJ, width, height, titleFontSize, 30, 20, titleBg, VVRr4z, VVvi36)
  self.session   = session
  FFj3mb(self, title, addScrollLabel=True)
  self.VVMXNv   = VVMXNv
  self.VVHrLx   = VVHrLx
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  self["myLabel"].VVdp3X(VVHrLx=self.VVHrLx, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VVMXNv)
  self["myLabel"].VVVjqa()
class CCcrgE(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FFdP4M(VVkgN4, 1800, 60, 30, 30, 20, "#55000000", "#ff000000", 30)
  self.session  = session
  self.txt   = txt
  self["myWinTitle"] = Label()
  FFj3mb(self, " ", addCloser=True)
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  CChhP9.VVr3dW(self, self.txt)
  self.instance.move(ePoint((getDesktop(0).size().width() - self.instance.size().width()) // 2, 20))
class CCTfGo(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFdP4M(VVJOa0, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFj3mb(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FF90h2(self["errPic"], "err")
class CCJ3Iz(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFdP4M(VVkgN4, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label()
  FFj3mb(self, " ", addCloser=True)
class CChhP9():
 def __init__(self, session, txt, timeout=1500, fonSize=24):
  self.session = session
  self.win  = CChhP9.VVfLzp(session, txt, fonSize)
  self.timer  = eTimer()
  try: self.timer_conn = self.timer.timeout.connect(self.VVWi26)
  except: self.timer.callback.append(self.VVWi26)
  self.timer.start(timeout, True)
 def VVWi26(self):
  self.session.deleteDialog(self.win)
 @staticmethod
 def VVfLzp(session, txt, fonSize, shadW=2, shadColor="#440000", x=30, y=20):
  win = session.instantiateDialog(CCJ3Iz, txt.strip(), fonSize)
  win.instance.move(ePoint(x, y))
  win.show()
  FFY2jk(win["myWinTitle"], shadColor, shadW)
  CChhP9.VVr3dW(win, txt)
  return win
 @staticmethod
 def VVr3dW(win, txt):
  win["myWinTitle"].setText(txt.strip())
  inst = win["myWinTitle"].instance
  w = inst.calculateSize().width() + 30
  h = int(inst.size().height())
  inst.resize(eSize(*(w, h)))
  win.instance.resize(eSize(*(w, h)))
class CCfWgm():
 VVva3j    = 0
 VVzLmf  = 1
 VVyIVA   = ""
 VVJhrl    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVkINB   = None
  self.timer     = eTimer()
  self.VVYQBl   = 0
  self.VVEMHA  = 1
  self.VVvl3h  = 2
  self.VVaWpk   = 3
  self.VVkjL2   = 4
  VVUl7I = self.VVV293()
  if VVUl7I:
   self.VVkINB = self.VVlxuE(VVUl7I)
  if not VVUl7I and mode == self.VVva3j:
   self.VVr3Eu("Download list is empty !")
   self.cancel()
  if mode == self.VVzLmf:
   FFkWFV(self.VVkINB or self.SELF, BF(self.VVXB9r, startDnld, decodedUrl), title="Checking Server ...")
  self.VVVPI7(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVVPI7)
  except:
   self.timer.callback.append(self.VVVPI7)
  self.timer.start(1000, False)
 def VVlxuE(self, VVUl7I):
  VVUl7I.sort(key=lambda x: int(x[0]))
  VVIcAB = self.VVwElb
  VVp0o5  = ("Play"  , self.VVB9fg , [])
  VVq5Be = (""   , self.VVl37V  , [])
  VVcNot = ("Stop"  , self.VVYsST  , [])
  VVkY0R = ("Resume"  , self.VVSMr4 , [])
  VVW1zM = ("Options" , self.VVthGJ  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVwZxf  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FF69ky(self.SELF, None, title=self.Title, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=26, VVp0o5=VVp0o5, VVq5Be=VVq5Be, VVIcAB=VVIcAB, VVcNot=VVcNot, VVkY0R=VVkY0R, VVW1zM=VVW1zM, lastFindConfigObj=CFG.lastFindIptv, VVrcFy="#11220022", VVZZ3c="#11110011", VVRr4z="#11110011", VVLwCQ="#00223025", VVhvzQ="#0a333333", VVEjwd="#0a400040", VVFwVS=True, searchCol=1)
 def VVV293(self):
  lines = CCfWgm.VVYqV6()
  VVUl7I = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVc6ME(decodedUrl)
      if fName:
       if   FFeh36(decodedUrl) : sType = "Movie"
       elif FFW9kO(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVtrvS(decodedUrl, fName)
       if size > -1: sizeTxt = CCyssW.VV1ctA(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVUl7I.append((str(len(VVUl7I) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVUl7I
 def VVrHWt(self):
  VVUl7I = self.VVV293()
  if VVUl7I:
   if self.VVkINB : self.VVkINB.VVDqeT(VVUl7I, VVc63JMsg=False)
   else     : self.VVkINB = self.VVlxuE(VVUl7I)
  else:
   self.cancel()
 def VVVPI7(self, force=False):
  if self.VVkINB:
   thrListUrls = self.VVRW6S()
   VVUl7I = []
   changed = False
   for ndx, row in enumerate(self.VVkINB.VV3rlI()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVYQBl
    if m3u8Log:
     percent = CCfWgm.VVkQIB(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVaWpk , "%.2f %%" % percent
      else   : flag, progr = self.VVkjL2 , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FF1fFq(mPath)
     if curSize > -1:
      fSize = CCyssW.VV1ctA(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCyssW.VV1ctA(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FF1fFq(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVaWpk , "%.2f %%" % percent
       else   : flag, progr = self.VVkjL2 , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCyssW.VV1ctA(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VVvl3h
     if m3u8Log :
      if not speed and not force : flag = self.VVEMHA
      elif curSize == -1   : self.VVZMoS(False)
    elif flag == self.VVYQBl  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVYQBl  : color2 = "#f#00555555#"
    elif flag == self.VVEMHA : color2 = "#f#0000FFFF#"
    elif flag == self.VVvl3h : color2 = "#f#0000FFFF#"
    elif flag == self.VVaWpk  : color2 = "#f#00FF8000#"
    elif flag == self.VVkjL2  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VV0U2Y(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVUl7I.append(row)
   if changed or force:
    self.VVkINB.VVDqeT(VVUl7I, VVc63JMsg=False)
 def VV0U2Y(self, flag):
  tDict = self.VVTfR9()
  return tDict.get(flag, "?")
 def VVKljk(self, state):
  for flag, txt in self.VVTfR9().items():
   if txt == state:
    return flag
  return -1
 def VVTfR9(self):
  return { self.VVYQBl: "Not started", self.VVEMHA: "Connecting", self.VVvl3h: "Downloading", self.VVaWpk: "Stopped", self.VVkjL2: "Completed" }
 def VVQ5JE(self, title):
  colList = self.VVkINB.VVw0xB()
  path = colList[6]
  url  = colList[8]
  if self.VVxKRl() : self.VVr3Eu("Cannot delete !\n\nFile is downloading.")
  else      : FFDiGG(self.SELF, BF(self.VVXA8s, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVXA8s(self, path, url):
  m3u8Log = self.VVkINB.VVw0xB()[12]
  if m3u8Log : FFLgW2("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  else  : FFLgW2("rm -rf '%s'" % path)
  self.VV5He4(False)
  self.VVrHWt()
 def VV5He4(self, VVT0Gn=True):
  if self.VVxKRl():
   FFpIgV(self.VVkINB, self.VV0U2Y(self.VVvl3h), 500)
  else:
   colList  = self.VVkINB.VVw0xB()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VVKljk(state) in (self.VVYQBl, self.VVkjL2, self.VVaWpk):
    lines = CCfWgm.VVYqV6()
    newLines = []
    found = False
    for line in lines:
     if CCfWgm.VVe5t7(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVKaTx(newLines)
     self.VVrHWt()
     FFpIgV(self.VVkINB, "Removed.", 1000)
    else:
     FFpIgV(self.VVkINB, "Not found.", 1000)
   elif VVT0Gn:
    self.VVr3Eu("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVSX21(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFDiGG(self.SELF, BF(self.VV6VVE, flag), ques, title=title)
 def VV6VVE(self, flag):
  list = []
  for ndx, row in enumerate(self.VVkINB.VV3rlI()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVKljk(state)
   if   flag == flagVal == self.VVkjL2: list.append(decodedUrl)
   elif flag == flagVal == self.VVYQBl : list.append(decodedUrl)
  lines = CCfWgm.VVYqV6()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVKaTx(newLines)
   self.VVrHWt()
   FFpIgV(self.VVkINB, "%d removed." % totRem, 1000)
  else:
   FFpIgV(self.VVkINB, "Not found.", 1000)
 def VVOGer(self):
  colList  = self.VVkINB.VVw0xB()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFpIgV(self.VVkINB, "Poster exists", 1500)
  else    : FFkWFV(self.VVkINB, BF(self.VV9ex4, decodedUrl, path, png), title="Checking Server ...")
 def VV9ex4(self, decodedUrl, path, png):
  err = self.VVSuSs(decodedUrl, path, png)
  if err:
   FFG2mq(self.SELF, err, title="Poster Download")
 def VVSuSs(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCwoYk.VVyxli(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCul6W.VVuv9X(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCul6W.VVbwRu(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCul6W.VVaXRJ(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFq7bz(pUrl, "ajp_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   FFLgW2("mv -f '%s' '%s'" % (tPath, png))
   CCLIUZ.VV94CH(self.SELF, VVMYFn=png, showGrnMsg="Downloaded")
   return ""
 def VVl37V(self, VVkINB, title, txt, colList):
  def VVGnZU(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVy4Ld(key, val) : return "\n%s:\n%s\n" % (FF1YQ7(key, VVyz0j), val.strip())
  heads  = self.VVkINB.VV5aE2()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVGnZU(heads[i]  , CCyssW.VV1ctA(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVGnZU("Downloaded" , CCyssW.VV1ctA(int(curSize), mode=0))
   else:
    txt += VVGnZU(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVy4Ld(heads[i], colList[i])
  FF8ShK(self.SELF, txt, title=title)
 def VVB9fg(self, VVkINB, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCyssW.VVkN1L(self.SELF, path)
  else    : FFpIgV(self.VVkINB, "File not found", 1000)
 def VVwElb(self, VVkINB):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVkINB:
   self.VVkINB.cancel()
  del self
 def VVthGJ(self, VVkINB, title, txt, colList):
  c1, c2, c3 = VVeksK, VVf8NN, VVyz0j
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVgktg = []
  VVgktg.append((c1 + "Remove current row"       , "VV5He4" ))
  VVgktg.append(VVm7kE)
  VVgktg.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVgktg.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVgktg.append(VVm7kE)
  VVgktg.append((c2 + "Delete the file (and remove from list)"  , "VVQ5JE"))
  VVgktg.append(VVm7kE)
  VVgktg.append((resumeTxt + " Auto Resume"       , "VVCDwB" ))
  VVgktg.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVgktg.append(VVm7kE)
  cond = FFeh36(decodedUrl)
  VVgktg.append(FFVKGp("Download Movie Poster %s" % ("(from server)" if cond else "... Movies only"), "VVOGer", cond, c3))
  VVgktg.append(FFVKGp("Open in File Manager", "inFileMan,%s" % path, fileExists(path), c3))
  FFBqvZ(self.SELF, BF(self.VVUyBY, VVkINB), VVgktg=VVgktg, title=self.Title, VVomDt=True, width=800, VVRHyh=True, VVrcFy="#1a001122", VVZZ3c="#1a001122")
 def VVUyBY(self, VVkINB, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VV5He4"  : self.VV5He4()
   elif ref == "remFinished"   : self.VVSX21(self.VVkjL2, txt)
   elif ref == "remPending"   : self.VVSX21(self.VVYQBl, txt)
   elif ref == "VVQ5JE" : self.VVQ5JE(txt)
   elif ref == "VVOGer"  : self.VVOGer()
   elif ref == "VVCDwB"  : FFeLB8(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FFeLB8(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CCyssW, mode=CCyssW.VVlToO, jumpToFile=path)
    else    : FFpIgV(VVkINB, "Path not found !", 1500)
 def VVXB9r(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCwoYk.VVyxli(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVr3Eu("Could not get download link !\n\nTry again later.")
     return
  for line in CCfWgm.VVYqV6():
   if CCfWgm.VVe5t7(decodedUrl, line):
    if self.VVkINB:
     self.VVulJm(decodedUrl)
     FFLYGh(BF(FFpIgV, self.VVkINB, "Already listed !", 2000))
    break
  else:
   params = self.VV3a3Y(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVr3Eu(params[0])
   elif len(params) == 2:
    FFDiGG(self.SELF, BF(self.VVag91, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCyssW.VV1ctA(fSize)
    FFDiGG(self.SELF, BF(self.VV9MAl, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VV9MAl(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCfWgm.VVwkM6(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVrHWt()
  if self.VVkINB:
   self.VVkINB.VVQbYY()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCfWgm.VVJhrl, path, decodedUrl)
   self.VVhILI(threadName, url, decodedUrl, path, resp)
 def VVulJm(self, decodedUrl):
  if self.VVkINB:
   for ndx, row in enumerate(self.VVkINB.VV3rlI()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVkINB:
     self.VVkINB.VV2NBO(ndx)
     break
 def VV3a3Y(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVc6ME(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVtrvS(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCwoYk.VVyxli(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCwoYk.VVbFm5()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCfWgm.VVH16S(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCfWgm.VV6O7s(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVag91(self, resp, decodedUrl):
  if not FFGqL5("ffmpeg"):
   FFDiGG(self.SELF, BF(CCul6W.VVQH9K, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVc6ME(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVxAz9(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFDiGG(self.SELF, BF(self.VVt181, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVt181(rTxt, rUrl)
  else:
   self.VVr3Eu("Cannot process m3u8 file !")
 def VVxAz9(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVgktg = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCul6W.VVZqsK(rUrl, fPath)
   VVgktg.append((resol, fullUrl))
  if VVgktg:
   FFBqvZ(self.SELF, self.VVV0aG, VVgktg=VVgktg, title="Resolution", VVomDt=True, VVRHyh=True)
  else:
   self.VVr3Eu("Cannot get Resolutions list from server !")
 def VVV0aG(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFDiGG(self.SELF, BF(FFLYGh, BF(self.VVQRut, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFLYGh(BF(self.VVQRut, resolUrl))
 def VVQRut(self, resolUrl):
  txt, err = CCwoYk.VVZkcb(resolUrl)
  if err : self.VVr3Eu(err)
  else : self.VVt181(txt, resolUrl)
 def VVd38Y(self, logF, decodedUrl):
  found = False
  lines = CCfWgm.VVYqV6()
  with open(CCfWgm.VVwkM6(), "w") as f:
   for line in lines:
    if CCfWgm.VVe5t7(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCfWgm.VVwkM6(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVrHWt()
  if self.VVkINB:
   self.VVkINB.VVQbYY()
 def VVt181(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  fName = fName.replace("(", "_").replace(")", "_")
  dest = dest.replace("(", "_").replace(")", "_")
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCul6W.VVZqsK(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVr3Eu("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVd38Y(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFhkCt("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCfWgm.VVJhrl, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVkQIB(dnldLog):
  if fileExists(dnldLog):
   dur = CCfWgm.VVQxXP(dnldLog)
   if dur > -1:
    tim = CCfWgm.VVLcvf(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVQxXP(dnldLog):
  lines = FFa467("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVLcvf(dnldLog):
  lines = FFa467("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVtrvS(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFW9kO(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    FFLgW2("mkdir '%s'" % path1)
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVhILI(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVkINB.VVw0xB()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VVRlVD, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVRlVD(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVyIVA == path:
       break
     else:
      break
  except:
   return
  if CCfWgm.VVyIVA:
   CCfWgm.VVyIVA = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FF1fFq(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VV3a3Y(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVRlVD(url, decodedUrl, path, resp, totFileSize, True)
 def VVYsST(self, VVkINB, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVaDax() : FFpIgV(self.VVkINB, self.VV0U2Y(self.VVkjL2), 500)
  elif not self.VVxKRl() : FFpIgV(self.VVkINB, self.VV0U2Y(self.VVaWpk), 500)
  elif m3u8Log      : FFDiGG(self.SELF, self.VVZMoS, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVRW6S():
    CCfWgm.VVyIVA = colList[6]
    FFpIgV(self.VVkINB, "Stopping ...", 1000)
   else:
    FFpIgV(self.VVkINB, "Stopped", 500)
 def VVZMoS(self, withMsg=True):
  if withMsg:
   FFpIgV(self.VVkINB, "Stopping ...", 1000)
  FFLgW2("killall -INT ffmpeg")
 def VVSMr4(self, *args):
  if   self.VVaDax() : FFpIgV(self.VVkINB, self.VV0U2Y(self.VVkjL2) , 500)
  elif self.VVxKRl() : FFpIgV(self.VVkINB, self.VV0U2Y(self.VVvl3h), 500)
  else:
   resume = False
   m3u8Log = self.VVkINB.VVw0xB()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FFDiGG(self.SELF, BF(self.VVRrrW, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVQ364():
    resume = True
   if resume: FFkWFV(self.VVkINB, BF(self.VVgkUY), title="Checking Server ...")
   else  : FFpIgV(self.VVkINB, "Cannot resume !", 500)
 def VVRrrW(self, m3u8Log):
  FFLgW2("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  FFkWFV(self.VVkINB, BF(self.VVgkUY), title="Checking Server ...")
 def VVgkUY(self):
  colList  = self.VVkINB.VVw0xB()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCwoYk.VVyxli(decodedUrl)
   if url:
    decodedUrl = self.VV85Ot(decodedUrl, url)
   else:
    self.VVr3Eu("Could not get download link !\n\nTry again later.")
    return
  curSize = FF1fFq(path)
  params = self.VV3a3Y(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVr3Eu(params[0])
   return
  elif len(params) == 2:
   self.VVag91(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VV85Ot(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCfWgm.VVJhrl, path, decodedUrl)
  if resumable: self.VVhILI(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVr3Eu("Cannot resume from server !")
 def VVc6ME(self, decodedUrl):
  fileExt = CCul6W.VVH60n(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FF0hYs(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVr3Eu(self, txt):
  FFG2mq(self.SELF, txt, title=self.Title)
 def VVRW6S(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCfWgm.VVJhrl, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VVxKRl(self):
  decodedUrl = self.VVkINB.VVw0xB()[9]
  return decodedUrl in self.VVRW6S()
 def VVaDax(self):
  colList = self.VVkINB.VVw0xB()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FF1fFq(path)) == size
 def VVQ364(self):
  colList = self.VVkINB.VVw0xB()
  path = colList[6]
  size = int(colList[7])
  curSize = FF1fFq(path)
  if curSize > -1:
   size -= curSize
  err = CCfWgm.VV6O7s(size)
  if err:
   FFG2mq(self.SELF, err, title=self.Title)
   return False
  return True
 def VVKaTx(self, list):
  with open(CCfWgm.VVwkM6(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VV85Ot(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCfWgm.VVYqV6()
  url = decodedUrl
  with open(CCfWgm.VVwkM6(), "w") as f:
   for line in lines:
    if CCfWgm.VVe5t7(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVrHWt()
  return url
 @staticmethod
 def VVYqV6():
  list = []
  if fileExists(CCfWgm.VVwkM6()):
   for line in FFjqdo(CCfWgm.VVwkM6()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVe5t7(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VV6O7s(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCyssW.VVeQ1N(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCyssW.VV1ctA(size), CCyssW.VV1ctA(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VV5pk5(SELF):
  tot = CCfWgm.VVeM2V()
  if tot:
   FFG2mq(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVeM2V():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCfWgm.VVJhrl):
    c += 1
  return c
 @staticmethod
 def VVJB4v():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCfWgm.VVJhrl, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VV7SC7():
  return len(CCfWgm.VVYqV6()) == 0
 @staticmethod
 def VVl62f():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVGPlI():
  mPoints = CCfWgm.VVl62f()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    FFLgW2("mkdir '%s'" % path)
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVwkM6():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVivnA(SELF, waitMsgObj=None):
  FFkWFV(waitMsgObj or SELF, BF(CCfWgm.VV3q5j, SELF, CCfWgm.VVva3j))
 @staticmethod
 def VVZ32N(SELF):
  CCfWgm.VV3q5j(SELF, CCfWgm.VVzLmf, startDnld=True)
 @staticmethod
 def VVyAAA(SELF, url):
  CCfWgm.VV3q5j(SELF, CCfWgm.VVzLmf, startDnld=True, decodedUrl=url)
 @staticmethod
 def VV4XJS(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(SELF)
  added, skipped = CCfWgm.VVv0AB([decodedUrl])
  FFpIgV(SELF, "Added", 1000)
 @staticmethod
 def VVv0AB(list):
  added = skipped = 0
  for line in CCfWgm.VVYqV6():
   for ndx, url in enumerate(list):
    if url and CCfWgm.VVe5t7(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCfWgm.VVwkM6(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VV3q5j(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCbAHw.VVGJKq(SELF):
   return
  if mode == CCfWgm.VVva3j and CCfWgm.VV7SC7():
   FFG2mq(SELF, "Download list is empty !", title=title)
  else:
   inst = CCfWgm(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVH16S(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCppT7(Screen, CCBhNc):
 VVVBav = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, enableDownloadMenu=True):
  self.skin, self.skinParam = FFdP4M(VVOalx, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCBhNc.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.iptvTableParams  = iptvTableParams
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FFj3mb(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVymbM())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(VVKDoB,
  {
   "ok"  : self.VV96hS       ,
   "info"  : self.VVCQHx      ,
   "epg"  : self.VVCQHx      ,
   "menu"  : self.VVZsG1     ,
   "cancel" : self.cancel       ,
   "red"  : self.VVFXZf   ,
   "green"  : self.VVJo1Z  ,
   "blue"  : self.VVl71x      ,
   "yellow" : self.VVn9xR ,
   "left"  : BF(self.VVZiIR, -1)    ,
   "right"  : BF(self.VVZiIR,  1)    ,
   "play"  : self.VVhzVt      ,
   "pause"  : self.VVhzVt      ,
   "playPause" : self.VVhzVt      ,
   "stop"  : self.VVhzVt      ,
   "rewind" : self.VVrsBT      ,
   "forward" : self.VVnRC1      ,
   "rewindDm" : self.VVrsBT      ,
   "forwardDm" : self.VVnRC1      ,
   "last"  : self.VVzNOB      ,
   "next"  : self.VVo7Y7      ,
   "pageUp" : BF(self.VVkkbX, True)  ,
   "pageDown" : BF(self.VVkkbX, False)  ,
   "chanUp" : BF(self.VVkkbX, True)  ,
   "chanDown" : BF(self.VVkkbX, False)  ,
   "up"  : BF(self.VVkkbX, True)  ,
   "down"  : BF(self.VVkkbX, False)  ,
   "audio"  : BF(self.VV4EsQ, True)  ,
   "subtitle" : BF(self.VV4EsQ, False)  ,
   "text"  : self.VVHZbC  ,
   "0"   : BF(self.VV694C , 10)   ,
   "1"   : BF(self.VV694C , 1)   ,
   "2"   : BF(self.VV694C , 2)   ,
   "3"   : BF(self.VV694C , 3)   ,
   "4"   : BF(self.VV694C , 4)   ,
   "5"   : BF(self.VV694C , 5)   ,
   "6"   : BF(self.VV694C , 6)   ,
   "7"   : BF(self.VV694C , 7)   ,
   "8"   : BF(self.VV694C , 8)   ,
   "9"   : BF(self.VV694C , 9)
  }, -1)
  self.onShown.append(self.VVgr8g)
  self.onClose.append(self.onExit)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFIl1A(self)
  if not CCppT7.VVVBav:
   CCppT7.VVVBav = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FF90h2(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FF90h2(self["myPlayRpt"], "rpt")
  self.VVlRCU()
  self.instance.move(ePoint(40, 40))
  self.VVgocd(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVqP2H)
  except:
   self.timer.callback.append(self.VVqP2H)
  self.timer.start(250, False)
  self.VVqP2H("Checking ...")
  if not bool(self.iptvTableParams):
   self.VVH7Zj()
 def VVJo1Z(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
  self.lastSubtitle = CC81AE.VVimlw()
  if "chCode" in iptvRef:
   if CCbAHw.VVGJKq(self):
    self.VVH7Zj(True)
  else:
   self.VVqP2H("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVlRCU(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVa1HD()
  chName = FFOD7l(chName)
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VVWgbP + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FFeNfF(self["myTitle"], tColor)
  FFeNfF(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FFeNfF(self["myPlay%s" % item], tColor)
  picFile = CCXzVR.VVzlyh(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CCXzVR.VVNUlF(self)
  cl = CCnohF.VVfe7g(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VVqP2H(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCfWgm.VVeM2V()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVa1HD()
  if evName:
   evName = "    %s    " % FF1YQ7(evName, VVdl3O)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVazBC():
   FFfLQO(self["myPlayBlu"], "#00FFFFFF")
   FFeNfF(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFfLQO(self["myPlayBlu"], "#00FFFF88")
   FFeNfF(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  if not self.isManualSeek:
   player = CCul6W.VVw4Gb(refCode)
   if player:
    self["myPlaySkp"].show()
    self["myPlaySkp"].setText(VVqC3w + player)
   else:
    self["myPlaySkp"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FFeNfF(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FF5kC0(percVal, 0, 100)
   width = int(FFfvBi(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FFeNfF(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFfLQO(self["myPlayMsg"], "#0000ffff")
   else  : FFfLQO(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFfLQO(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFfLQO(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VV1XjE()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VVBhpX(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CC81AE.VVFF0X(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVzNOB()
  state = self.VVAo4m()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFfLQO(self["myPlayMsg"], "#0000ff00")
  else     : FFfLQO(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVa1HD(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFkbEk(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCppT7.VVUA6s(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCXzVR.VV9xJZ(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  elif isFtp        : tColor = "#11222222"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CC5l6x()
   tpTxt, satTxt = tp.VVipj8(refCode)
   self.satInfo_TP = tpTxt + "  " + FF1YQ7(satTxt, VVifMr)
  evName = evNameNext = ""
  evLst = CCjxcj.VVpNjI(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFeZyZ(info, iServiceInformation.sVideoWidth) or -1
   h = FFeZyZ(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFeZyZ(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CCXzVR.VVZ5cZ(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VVUA6s(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFGcFN(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFGcFN(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFGcFN(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVZsG1(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVa1HD()
  FFeh36Series = FF0hYs(decodedUrl)
  VVgktg = []
  if not "VVI342" in globals() and not "VV3m55" in globals():
   VVgktg.append((VVifMr + "IPTV Menu", "iptv"))
   VVgktg.append(VVm7kE)
  if isIptv and not "&end=" in decodedUrl and not FFeh36Series:
   uType, uHost, uUser, uPass, uId, uChName = CCul6W.VVuv9X(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVgktg.append((VVifMr + "Catchup Programs", "catchup" ))
    VVgktg.append(VVm7kE)
  if refCode:
   c = VVWgbP
   VVgktg.append((c + "Stop Current Service"  , "stop"  ))
   VVgktg.append((c + "Restart Current Service" , "restart"  ))
   VVgktg.append(FFVKGp("Replay with ..." , "replayWith", not isDvb, c))
   VVgktg.append(VVm7kE)
  if FFeh36Series:
   VVgktg.append((VVifMr + "File Size (on server)", "fileSize" ))
   VVgktg.append(VVm7kE)
  if self.enableDownloadMenu:
   c = VVifMr
   addSep = False
   if isIptv and FFeh36Series:
    VVgktg.append((c + "Start Download"  , "dload_cur" ))
    VVgktg.append((c + "Add to Download List" , "addToDload" ))
    addSep = True
   if not CCfWgm.VV7SC7():
    VVgktg.append((VVifMr + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVgktg.append(VVm7kE)
  fPath, fDir, fName = CCyssW.VVOVMO(self)
  if fPath:
   c = VVo8aK
   if not "VVSZdo" in globals():
    VVgktg.append((c + "Open path in File Manager", "VVYRs3"))
   VVgktg.append((c + "Add to Bouquet"             , "VVcokH" ))
   VVgktg.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VV9Maq"  ))
   VVgktg.append(VVm7kE)
  elif isFtp:
   VVgktg.append((VVyz0j + "Add FTP Media to Bouquet"     , "VVkkGL"))
  if isDvb:
   VVgktg.append((VVifMr + "Signal Monitor", "sigMon"))
  if posTxt and durTxt:
   VVgktg.append((VVyz0j + "Start Subtitle", "VVMC1E"))
   VVgktg.append(VVm7kE)
  if CFG.playerPos.getValue() : VVgktg.append(("Move Bar to Bottom" , "botm"))
  else      : VVgktg.append(("Move Bar to Top" , "top" ))
  VVgktg.append(("Help", "help"))
  FFBqvZ(self, self.VV4vRI, VVgktg=VVgktg, width=600, title="Options")
 def VV4vRI(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VVn9xR()
   elif item == "stop"     : self.VV5xv5(0)
   elif item == "restart"    : self.VV5xv5(1)
   elif item == "replayWith"   : self.VVSdGV()
   elif item == "fileSize"    : FFkWFV(self, BF(CCXzVR.VV8hy7, self), title="Checking Server")
   elif item == "dload_cur"   : CCfWgm.VVZ32N(self)
   elif item == "addToDload"   : CCfWgm.VV4XJS(self)
   elif item == "dload_stat"   : CCfWgm.VVivnA(self)
   elif item == "VVYRs3" : self.close("close_openInFileMan")
   elif item == "VVcokH" : self.VVcokH()
   elif item == "VVkkGL" : self.VVkkGL()
   elif item == "VVMC1E"  : self.VVKnLe()
   elif item == "VV9Maq"  : self.VV9Maq()
   elif item == "botm"     : self.VVgocd(0)
   elif item == "top"     : self.VVgocd(1)
   elif item == "sigMon"    : self.VVFXZf()
   elif item == "help"     : FFxVrN(self, "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCppT7.VVVBav = None
 def VV5xv5(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VVlRCU()
   elif typ == 1:
    self.VVqP2H("Restarting Service ...")
    FFLYGh(BF(self.VVCfao, serv))
 def VVCfao(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
  if "&end=" in decodedUrl: BF(self.VVH7Zj, True)
  else     : self.session.nav.playService(serv)
 def VVSdGV(self):
  FFBqvZ(self, self.VVY88d, VVgktg=CCul6W.VVApKt(), width=650, title="Select Player", VVrcFy="#11220000", VVZZ3c="#11220000")
 def VVY88d(self, rType=None):
  if rType:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv : FFPJLb(self, eServiceReference(rType + ":" + serv.toString().split(":", 1)[1]))
   else : self.VVqP2H("No active service !")
 def VVcokH(self):
  fPath, fDir, fName = CCyssW.VVOVMO(self)
  if fPath: picker = CCMyrC(self, self, "Add Current Movie to a Bouquet", BF(self.VV0zRI, [fPath]))
  else : FFpIgV(self, "Path not found !", 1500)
 def VV0zRI(self, pathLst):
  return CCMyrC.VVYYRX(pathLst)
 def VVkkGL(self):
  picker = CCMyrC(self, self, "Add FTP Media to Bouquet", self.VVNe2r)
 def VVNe2r(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
  return CCMyrC.VVYYRX([origUrl], rType=refCode.split(":", 1)[0])
 def VV9Maq(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCppT7.VVUA6s(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVqP2H(txt, highlight=ok)
 def VVgocd(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FFeLB8(CFG.playerPos, pos)
 def VVFXZf(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCXzVR.VV9xJZ(serv)
   if isDvb: self.close("close_sig")
   else : self.VVqP2H("No Signal for Current Service")
 def VVKnLe(self):
  self.session.openWithCallback(self.VVV7Gx, BF(CC81AE))
 def VVHZbC(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVa1HD()
   if posTxt and durTxt: self.VVKnLe()
   else    : self.VVqP2H("No duration Info. !")
 def VVV7Gx(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VVkkbX(True)
  elif reason == "subtZapDn" : self.VVkkbX(False)
  elif reason == "pause"  : self.VVhzVt()
  elif reason == "audio"  : self.VV4EsQ(True)
  elif reason == "subtitle" : self.VV4EsQ(False)
  elif reason == "rewind"     : self.VVrsBT()
  elif reason == "forward" : self.VVnRC1()
  elif reason == "rewindDm" : self.VVrsBT()
  elif reason == "forwardDm" : self.VVnRC1()
  else      : txt = reason
  if txt:
   FFpIgV(self, txt, 2000)
 def VV96hS(self):
  if self.isManualSeek:
   self.VVJzek()
   self.VVBhpX(self.manualSeekPts)
  elif self.shown:
   if CC81AE.VV6BhP(self): self.VVKnLe()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVJzek()
  else    : self.close()
 def VVCQHx(self):
  FFPrkv(self, fncMode=CCXzVR.VVfGK9)
 def VVhzVt(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VVqP2H("Toggling Play/Pause ...")
 def VVJzek(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVZiIR(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCppT7.VVUA6s(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVqKFu()
   else:
    self.manualSeekSec += direc * self.VVqKFu()
    self.manualSeekSec = FF5kC0(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFfvBi(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFGcFN(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VV694C(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVymbM())
   FFeLB8(CFG.playerJumpMin, self.jumpMinutes)
  self.VVqP2H("Changed Seek Time to : %d%s" % (val, self.VV30kg()))
 def VVymbM(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VV30kg())
 def VV30kg(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVFHcO(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVqKFu(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VV1XjE(self):
  if "VV5YNu" in globals():
   global VV5YNu
   if VV5YNu:
    VV5YNu = VV5YNu[1:-1]
    if len(VV5YNu) == 3: VV5YNu = ""
    else     : return VV5YNu
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVl71x(self):
  cList = self.VVazBC()
  if cList:
   VVgktg = []
   for pts, what in cList:
    txt = FFGcFN(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVgktg.append((txt, pts))
   FFBqvZ(self, self.VVaTiu, VVgktg=VVgktg, title="Cut List")
  else:
   self.VVqP2H("No Cut-List for this channel !")
 def VVaTiu(self, item=None):
  if item:
   self.VVBhpX(item)
 def VVazBC(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVnRC1(self) : self.VVfFK5(1)
 def VVrsBT(self) : self.VVfFK5(-1)
 def VVfFK5(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCppT7.VVUA6s(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVqKFu() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVFHcO())
    self.VVqP2H(txt)
  except:
   self.VVqP2H("Cannot jump")
 def VVBhpX(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVqP2H("Changing Time ...")
 def VVzNOB(self):
  self.VV5xv5(1)
  self.VVqP2H("Replaying ...")
  self.VVJzek()
 def VVo7Y7(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCppT7.VVUA6s(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVqP2H("Jumping to end ...")
  except:
   pass
 def VVAo4m(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVkkbX(self, isUp):
  if self.enableZapping:
   self.VVqP2H("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVJzek()
   if self.iptvTableParams:
    FFLYGh(BF(self.VVsVZk, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
    if "/timeshift/" in decodedUrl:
     self.VVqP2H("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVXbUd()
  else:
   self.VVqP2H("Zap Disabled !")
 def VVXbUd(self):
  self.lastPlayPos = 0
  self.VVlRCU()
  self.VVH7Zj()
 def VVsVZk(self, isUp):
  CCul6W_inatance, VVkINB, mode = self.iptvTableParams
  if isUp : VVkINB.VVMmTF()
  else : VVkINB.VVpqnv()
  colList = VVkINB.VVw0xB()
  if mode == "localIptv":
   chName, chUrl = CCul6W_inatance.VVfdQN(VVkINB, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCul6W_inatance.VVdNgx(VVkINB, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCul6W_inatance.VV5lIf(mode, VVkINB, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCul6W_inatance.VVkw1O(mode, VVkINB, colList)
  else:
   self.VVqP2H("Cannot Zap")
   return
  FFWpQx(self, chUrl, VVxOHd=False)
  self.VVXbUd()
 def VVH7Zj(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCppT7.VVUA6s(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
   if not self.VVMsTt(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVqP2H("Refreshing Portal")
   FFLYGh(self.VVDdih)
  except:
   pass
 def VVDdih(self):
  self.restoreLastPlayPos = self.VVveVR()
 def VVn9xR(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
  if not decodedUrl or FF0hYs(decodedUrl):
   self.VVqP2H("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCul6W.VVuv9X(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVqP2H("Reading Program List ...")
   ok_fnc = BF(self.VVw2Oi, refCode, chName, streamId, uHost, uUser, uPass)
   FFLYGh(BF(CCul6W.VVUfEc, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVqP2H("Cannot process this channel")
 def VVw2Oi(self, refCode, chName, streamId, uHost, uUser, uPass, VVkINB, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVkINB.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVqP2H("Changing Program ...")
   FFLYGh(BF(self.VVC2ye, chUrl))
  else:
   self.VVqP2H("Incorrect Timestamp !")
 def VVC2ye(self, chUrl):
  FFWpQx(self, chUrl, VVxOHd=False)
  self.lastPlayPos = 0
  self.VVlRCU()
 def VV4EsQ(self, isAudio):
  try:
   VVw847 = InfoBar.instance
   if VVw847:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVw847)
    else  : self.session.open(SubtitleSelection, VVw847)
  except:
   pass
 @staticmethod
 def VVgYwf(session, mode=None):
  if   mode == "close_sig"   : FFf5BK(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CCul6W)
  elif mode == "close_openInFileMan" : session.open(CCyssW, gotoMovie=True)
 @staticmethod
 def VVkxsS(session, **kwargs):
  session.openWithCallback(BF(CCppT7.VVgYwf, session), CCppT7, **kwargs)
class CCj78i(Screen):
 def __init__(self, session, title="", VVDdTB="Continue?", VV5fzj=True, VVm2Fj=False):
  self.skin, self.skinParam = FFdP4M(VV8WPg, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVDdTB = VVDdTB
  self.VVm2Fj = VVm2Fj
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VV5fzj : VVgktg = [no , yes]
  else   : VVgktg = [yes, no ]
  FFj3mb(self, title, VVgktg=VVgktg, addLabel=True)
  self["myActionMap"] = ActionMap(VVKDoB,
  {
   "ok" : self.VV96hS ,
   "cancel": self.cancel ,
   "red" : self.cancel ,
  }, -1)
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVDdTB)
  if self.VVm2Fj:
   self["myLabel"].instance.setHAlign(0)
  self.VVQHD1()
  FFayJd(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFgnVm(self["myMenu"])
  FFHLyO(self, self["myMenu"])
 def VV96hS(self):
  item = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVQHD1(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  diff  = textSize.height() - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCfuZE(Screen):
 def __init__(self, session, title="", VVgktg=None, width=1000, height=850, VVvi36=30, barText="", minRows=1, VVl3Ru=None, VVdi3l=None, VVqafJ=None, VVG8PG=None, VVG0eT=None, VV2qPD=None, VVomDt=False, VVRHyh=False, VVfXMZ=None, VVuxux=True, VVrcFy="#22003344", VVZZ3c="#22002233"):
  self.skin, self.skinParam = FFdP4M(VVuQx7, width, height, 50, 40, 30, VVrcFy, VVZZ3c, VVvi36, barHeight=40, topRightBtns=3 if VVdi3l else 0)
  self.session   = session
  self.VVgktg   = VVgktg
  self.barText   = barText
  self.minRows   = minRows
  self.VVl3Ru   = VVl3Ru
  self.VVdi3l   = VVdi3l
  self.VVqafJ   = VVqafJ
  self.VVG8PG  = VVG8PG
  self.VVG0eT  = ("Delete File", BF(self.VVn8tZ, VVfXMZ)) if not VVfXMZ is None else VVG0eT
  self.VV2qPD   = VV2qPD
  self.VVomDt  = VVomDt
  self.VVRHyh  = VVRHyh
  self.Title    = title
  FFj3mb(self, title, VVgktg=VVgktg)
  self["myActionMap"] = ActionMap(VVKDoB,
  {
   "ok"  : self.VV96hS    ,
   "cancel" : self.cancel    ,
   "info"  : self.VV45p2   ,
   "red"  : self.VVrW3G   ,
   "green"  : self.VVb8m3   ,
   "yellow" : self.VV5H8P   ,
   "blue"  : self.VVrQi6   ,
   "pageUp" : self.VVFeal ,
   "chanUp" : self.VVFeal ,
   "pageDown" : self.VVR0lp  ,
   "chanDown" : self.VVR0lp  ,
   "0"   : BF(self.VVMZ9T, 0) ,
   "1"   : BF(self.VVMZ9T, 1) ,
   "2"   : BF(self.VVMZ9T, 2) ,
   "3"   : BF(self.VVMZ9T, 3) ,
   "4"   : BF(self.VVMZ9T, 4) ,
   "5"   : BF(self.VVMZ9T, 5) ,
   "6"   : BF(self.VVMZ9T, 6) ,
   "7"   : BF(self.VVMZ9T, 7) ,
   "8"   : BF(self.VVMZ9T, 8) ,
   "9"   : BF(self.VVMZ9T, 9)
  }, -1)
  if VVuxux:
   FFaxrK(self, self["myMenu"], isMenu=True)
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFayJd(self["myMenu"])
  FF08xD(self, minRows=self.minRows)
  FFIl1A(self)
  self.VVr94E(self["keyRed"]  , self.VVqafJ )
  self.VVr94E(self["keyGreen"] , self.VVG8PG )
  self.VVr94E(self["keyYellow"] , self.VVG0eT )
  self.VVr94E(self["keyBlue"]  , self.VV2qPD )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FF2kyZ(self)
 def VVr94E(self, btnObj, btnFnc):
  if btnFnc:
   FFuetT(btnObj, btnFnc[0])
 def VVCTwJ(self, fnc=None):
  self.VVG8PG = fnc
  if fnc : self.VVr94E(self["keyGreen"], self.VVG8PG)
  else : self["keyGreen"].hide()
 def VVMZ9T(self, digit):
  digit = str(digit)
  VVgktg = self["myMenu"].list
  for ndx, item in enumerate(VVgktg):
   if len(item) == 2:
    span = iSearch(r"^\[(\d)\]\s.+", FFOD7l(item[0]), IGNORECASE)
    if span and span.group(1) == digit:
     self.VVI0nr(ndx)
     self.VV96hS()
     break
 def VV96hS(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if item is not None:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   if self.VVl3Ru:
    self.VVl3Ru((self, txt, ref, ndx))
   else:
    if self.VVomDt: self.close((txt, ref, ndx))
    else     : self.close(item)
 def VV45p2(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if self.VVdi3l and item:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   self.VVdi3l(self, txt, ref, ndx)
 def cancel(self):
  self.close(None)
 def VVrW3G(self)  : self.VVoluG(self.VVqafJ)
 def VVb8m3(self) : self.VVoluG(self.VVG8PG)
 def VV5H8P(self) : self.VVoluG(self.VVG0eT)
 def VVrQi6(self) : self.VVoluG(self.VV2qPD)
 def VVoluG(self, btnFnc):
  if btnFnc:
   item = self["myMenu"].l.getCurrentSelection()[1]
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVRHyh:
    self.cancel()
 def VVsxK0(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVgktg = self["myMenu"].list
  VVgktg.pop(ndx)
  if len(VVgktg) > 0: self["myMenu"].setList(VVgktg)
  else    : self.close()
 def VVn8tZ(self, basePath, menuObj, fName):
  FFDiGG(self, BF(self.VVy7OG, basePath + fName), "Delete this file ?\n\n%s" % fName, title=self.Title)
 def VVy7OG(self, path):
  FFMc8G(path)
  if fileExists(path) : FFpIgV(self, "Not deleted", 1000)
  else    : self.VVsxK0()
 def VVgQPR(self, VVgktg):
  if len(VVgktg) > 0:
   newList = []
   for item in VVgktg:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FF08xD(self, minRows=self.minRows)
  else:
   self.close("")
 def VVLDpi(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FF08xD(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVIuty(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVI0nr(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VVy5pY(self, refTxt):
  for ndx, item in enumerate(self["myMenu"].list):
   if refTxt == item[1]:
    self.VVI0nr(ndx)
    break
 def VVfFH1(self, txt):
  for ndx, item in enumerate(self["myMenu"].list):
   if txt == item[0]:
    self.VVI0nr(ndx)
    break
 def VVFeal(self) : self["myMenu"].moveToIndex(0)
 def VVR0lp(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCo9yf(Screen):
 def __init__(self, session, title="", width=1600, height=900, vMargin=5, header=None, VV9gTz=None, VVwZxf=None, VVYiuZ=None, VVvi36=26, isEditor=False, addSort=True, VVFwVS=False, VVWtKU=0, picParams=None, VVp0o5=None, VVq5Be=None, menuButtonFnc=None, VVcNot=None, VVkY0R=None, VVW1zM=None, VVM4el=None, VV1MrT=None, VVgDd7=None, VVIcAB=None, VVyWTx=-1, VVDWdv=0, searchCol=0, lastFindConfigObj=None, VVrcFy="#22003344", VVZZ3c="#22002233", VVVH0w="#00dddddd", VVRr4z="#11002233", VVsykS=None, VVLwCQ="#11111111", borderWidth=1, VVhvzQ="#0a555555", VVHdfY="#0affffff", VVEjwd="#11552200", VVeuST="#0055ff55", VVeuSTRev="#0000bbff"):
  self.skin, self.skinParam = FFdP4M(VVWkz0, width, height, 50, 10, vMargin, VVrcFy, VVZZ3c, 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFj3mb(self, title)
  self.Title     = title
  self.header     = header
  self.VV9gTz     = VV9gTz
  self.totalCols    = len(VV9gTz[0])
  self.VVWtKU   = VVWtKU
  self.picParams    = picParams
  self.lastSortModeIsReverese = False
  self.VVFwVS   = VVFwVS
  self.VVGaZQ   = 0.01
  self.VVXHfA   = 0.02
  self.VVEmb5 = 0.03
  self.VVWd36  = 1
  self.VVYiuZ = VVYiuZ
  self.colWidthPixels   = []
  self.VVp0o5   = VVp0o5
  self.OKButtonObj   = None
  self.VVq5Be   = VVq5Be
  self.VVcNot   = VVcNot
  self.VVkY0R   = VVkY0R
  self.VVW1zM  = VVW1zM
  self.VVM4el   = VVM4el
  self.VV1MrT    = VV1MrT
  self.VVgDd7   = VVgDd7
  self.tableRefreshCB   = None
  self.VVIcAB  = VVIcAB
  self.menuButtonFnc   = menuButtonFnc
  self.VVyWTx    = VVyWTx
  self.VVDWdv   = VVDWdv
  self.searchCol    = searchCol
  self.VVwZxf    = VVwZxf
  self.keyPressed    = -1
  self.VVvi36    = FFPiPj(VVvi36)
  self.isEditor    = isEditor
  self.addSort    = addSort
  self.VVaKvA    = FF0NHz(self.VVvi36, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVrcFy    = VVrcFy
  self.VVZZ3c      = VVZZ3c
  self.VVVH0w    = FFe2hp(VVVH0w)
  self.VVRr4z    = FFe2hp(VVRr4z)
  self.VVsykS    = VVsykS
  self.VVLwCQ    = FFe2hp(VVLwCQ)
  self.borderWidth   = borderWidth
  self.VVhvzQ   = FFe2hp(VVhvzQ)
  self.VVHdfY    = FFe2hp(VVHdfY)
  self.VVEjwd    = FFe2hp(VVEjwd)
  self.VVeuST   = FFe2hp(VVeuST)
  self.VVeuSTRev  = FFe2hp(VVeuSTRev)
  self.VVopq8  = False
  self.selectedItems   = 0
  self.VVJEju   = FFe2hp("#06542132")
  self.onMultiSelFnc   = None
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VVDWdv:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   if self.VVDWdv == 1: self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(VVKDoB,
  {
   "ok"  : self.VVHYCL  ,
   "red"  : self.VVjrbs  ,
   "green"  : self.VVEOH5 ,
   "yellow" : self.VV4ZEf ,
   "blue"  : self.VVdlSR  ,
   "menu"  : self.VVLeVj ,
   "info"  : self.VVQeVi  ,
   "cancel" : self.VVnyQH  ,
   "up"  : self.VVpqnv    ,
   "down"  : self.VVMmTF  ,
   "left"  : self.VVjNzZ   ,
   "right"  : self.VViXre  ,
   "next"  : self.VV5Wle  ,
   "last"  : self.VVGKpP  ,
   "home"  : self.VV81wS  ,
   "pageUp" : self.VV81wS  ,
   "chanUp" : self.VV81wS  ,
   "end"  : self.VVQbYY  ,
   "pageDown" : self.VVQbYY  ,
   "chanDown" : self.VVQbYY
  }, -1)
  FFaxrK(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFIl1A(self)
  try:
   self.VVMZyI()
  except Exception as e:
   FFG2mq(self, str(e), title=self.Title)
   self.close(None)
 def VVMZyI(self):
  FF2kyZ(self)
  self.VVr94E(self.VVcNot , self["keyRed"])
  self.VVr94E(self.VVkY0R , self["keyGreen"])
  self.VVr94E(self.VVW1zM, self["keyYellow"])
  self.VVr94E(self.VVM4el , self["keyBlue"])
  if self.VVp0o5:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj and self.VVp0o5[0]:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVp0o5[0])
    FFeNfF(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVaKvA)
  self["myTableH"].l.setFont(0, gFont(VVwRnH, self.VVvi36))
  self["myTable"].l.setItemHeight(self.VVaKvA)
  self["myTable"].l.setFont(0, gFont(VVwRnH, self.VVvi36))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w = self["myTable"].instance.size().width()
  h = self["myTable"].instance.size().height()
  pos = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVaKvA)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVaKvA))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVaKvA)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVaKvA
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVaKvA * len(self.VV9gTz) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVYiuZ:
   self.VVYiuZ = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVYiuZ)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVwZxf:
   self.VVwZxf = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVwZxf
   self.VVwZxf = []
   for item in tmpList:
    self.VVwZxf.append(item | RT_VALIGN_CENTER)
  self.VVclfP()
  if self.VV1MrT:
   self.VV1MrT(self)
 def VVr94E(self, btnFnc, btn):
  if btnFnc : FFuetT(btn, btnFnc[0])
  else  : FFuetT(btn, "")
 def VVeQBv(self, waitTxt):
  FFkWFV(self, self.VVclfP, title=waitTxt)
 def VVclfP(self, onlyHeader=False):
  try:
   if self.header:
    sortedFg = self.VVeuSTRev if self.lastSortModeIsReverese else self.VVeuST
    self["myTableH"].setList([self.VVjwlo(0, self.header, self.VVHdfY, self.VVEjwd, None, self.VVEjwd, sortedFg)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VV9gTz):
    self["myTable"].list.append(self.VVjwlo(c, row, self.VVVH0w, self.VVRr4z, self.VVsykS, self.VVLwCQ, None))
   self.VV9gTz = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVyWTx > -1:
    self["myTable"].moveToIndex(self.VVyWTx )
   self.VV7b1R()
   if self.VVDWdv:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVaKvA * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
     FFLVLw(self, width, newH)
   if self.VVgDd7:
    self.VVoluG(self.VVgDd7, None)
   if self.tableRefreshCB:
    self.VVoluG(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FFG2mq(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VVjwlo(self, keyIndex, columns, VVVH0w, VVRr4z, VVsykS, VVLwCQ, VVeuST):
  row = [keyIndex]
  if VVsykS:
   VVsykS = FFe2hp(VVsykS)
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVeuST and ndx == self.VVWtKU : textColor = VVeuST
   else           : textColor = VVVH0w
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFe2hp(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVRr4z = c
    entry = span.group(3)
   if not self.isEditor and self.VVwZxf[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVaKvA)
           , font   = 0
           , flags   = self.VVwZxf[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVRr4z
           , color_sel  = VVsykS or textColor
           , backcolor_sel = VVLwCQ
           , border_width = self.borderWidth
           , border_color = self.VVhvzQ
           ))
   posX += self.colWidthPixels[ndx]
  if not VVeuST and self.picParams:
   picPosCol, picFnc, pathCol = self.picParams
   if   picFnc : png = picFnc(columns)
   elif pathCol: png = columns[pathCol].strip()
   else  : png = ""
   if png.startswith("/"):
    try:
     pngX = sum(self.colWidthPixels[:picPosCol])
     row.append(CCo9yf.VVa1FY(pngX+2, picPosCol+2, self.colWidthPixels[picPosCol]-4, self.VVaKvA-4, LoadPixmap(png)))
    except:
     pass
  return row
 def VVQeVi(self):
  rowData = self.VVburF()
  if rowData:
   title, txt, colList = rowData
   if self.VVq5Be:
    fnc  = self.VVq5Be[1]
    params = self.VVq5Be[2]
    fnc(self, title, txt, colList)
   else:
    FF8ShK(self, txt, title)
 def VVHYCL(self):
  if   self.VVopq8 : self.VVBkeI(self.VVnbBC(), mode=2)
  elif self.VVp0o5  : self.VVoluG(self.VVp0o5, None)
  else      : self.VVQeVi()
 def VVjrbs(self) : self.VVoluG(self.VVcNot , self["keyRed"])
 def VVEOH5(self) : self.VVoluG(self.VVkY0R , self["keyGreen"])
 def VV4ZEf(self): self.VVoluG(self.VVW1zM , self["keyYellow"])
 def VVdlSR(self) : self.VVoluG(self.VVM4el , self["keyBlue"])
 def VVoluG(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFpIgV(self, buttonFnc[3])
    FFLYGh(BF(self.VVfGDl, buttonFnc))
   else:
    self.VVfGDl(buttonFnc)
 def VVfGDl(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVburF()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVBkeI(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][10] == self.VVJEju
   if mode == 0 or (mode == 2 and isSelected):
    bg = self.VVRr4z
    if isSelected:
     self.selectedItems -= 1
   else:
    bg = self.VVJEju
    if not isSelected:
     self.selectedItems += 1
   for col in range(1, len(row)):
    cols = list(row[col])
    if cols[0] == 0:
     cols[10] = bg
    row[col] = tuple(cols)
   self["myTable"].l.invalidate()
   if self.VVnbBC() < len(self["myTable"].list) - 1 : self.VVMmTF()
   else              : self.VV7b1R()
   if self.onMultiSelFnc:
    self.onMultiSelFnc()
 def VVbpDn(self)  : FFkWFV(self, BF(self.VV4gTE, True ), title="Selecting all ..."  )
 def VVPWK2(self) : FFkWFV(self, BF(self.VV4gTE, False), title="Unselecting all ...")
 def VV4gTE(self, isSel=True):
  if isSel:
   bg = self.VVJEju
   self.selectedItems = len(self["myTable"].list)
   self.VVBKwU(True)
  else:
   bg = self.VVRr4z
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][10] == self.VVJEju
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     cols = list(self["myTable"].list[ndx][col])
     if cols[0] == 0:
      cols[10] = bg
     self["myTable"].list[ndx][col] = tuple(cols)
  self["myTable"].l.invalidate()
 def VVburF(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVYiuZ[i] > 1 or self.VVYiuZ[i] == self.VVGaZQ or self.VVYiuZ[i] == self.VVEmb5:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VVnyQH(self):
  self["myTable"].onSelectionChanged = []
  if self.VVIcAB : self.VVIcAB(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VVZC2U(self):
  return self["myTitle"].getText().strip()
 def VV5aE2(self):
  return self.header
 def VVQgjr(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVvkWi(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFfLQO(self["myBar"], color)
 def VVeMZj(self, txt):
  FFpIgV(self, txt)
 def VVpB4f(self, txt, Time=1000):
  FFpIgV(self, txt, Time)
 def VVmDzk(self): self["keyGreen"].show()
 def VVETBP(self): self["keyGreen"].hide()
 def VVqMjN(self): return self["keyGreen"].visible
 def VVTm6g(self):
  FFpIgV(self)
 def VVxHVQ(self, fnc, callFnc=False):
  self["myTable"].onSelectionChanged.append(fnc)
  if callFnc:
   fnc()
 def VVgq7g(self):
  return len(self["myTable"].list)
 def VVnbBC(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVKW2u(self):
  return len(self["myTable"].list)
 def VVBKwU(self, isOn):
  self.VVopq8 = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VVM4el: self["keyBlue"].hide()
   if self.VVp0o5 and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.VVrcFy
   self["keyMenu"].show()
   if self.VVM4el: self["keyBlue"].show()
   if self.VVp0o5 and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVp0o5[0])
   self.VVPWK2()
  FFeNfF(self["myTitle"], color)
  FFeNfF(self["myBar"]  , color)
 def VVeANU(self):
  return self.VVopq8
 def VVIf28(self):
  return self.selectedItems
 def VVdTes(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VV7b1R()
 def VVnTed(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVNtqp(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVgq7g()
  txt += FFCQJ8("Total Unique Items", VVf8NN)
  for i in range(self.totalCols):
   if self.VVYiuZ[i - 1] > 1 or self.VVYiuZ[i - 1] == self.VVGaZQ or self.VVYiuZ[i - 1] == self.VVEmb5:
    name, tot = self.VVnTed(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FF8ShK(self, txt)
 def VVRYeh(self, colNum, isStrip=True):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip() if isStrip else item[colNum + 1][7]
  else : return None
 def VVw0xB(self):
  return self.VV68fw(self["myTable"].l.getCurrentSelectionIndex())
 def VV68fw(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVDqeT(self, newList, newTitle="", VVc63JMsg=True, tableRefreshCB=None, isSort=True):
  if newTitle:
   self.VVQgjr(newTitle)
  if newList:
   self.VV9gTz = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VVFwVS and self.VVWtKU == 0:
    isNum = True
   else:
    for cols in self.VV9gTz:
     if not FF39jL(cols[self.VVWtKU]): break
    else:
     isNum = True
   if isSort:
    if isNum: self.VV9gTz.sort(key=lambda x: int(x[self.VVWtKU])  , reverse=self.lastSortModeIsReverese)
    else : self.VV9gTz.sort(key=lambda x: x[self.VVWtKU].lower() , reverse=self.lastSortModeIsReverese)
   if VVc63JMsg : self.VVeQBv("Refreshing ...")
   else   : self.VVclfP()
  else:
   FFG2mq(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VVVxYM(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VVjwlo(self.VVKW2u(), row, self.VVVH0w, self.VVRr4z, self.VVsykS, self.VVLwCQ, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VVQbYY()
 def VVPu0N(self):
  self["myTable"].list.pop(self.VVnbBC())
  self["myTable"].l.setList(self["myTable"].list)
 def VVrgU7(self, data):
  ndx = self.VVnbBC()
  newRow = self.VVjwlo(ndx, data, self.VVVH0w, self.VVRr4z, self.VVsykS, self.VVLwCQ, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VV7b1R()
   return True
  else:
   return False
 def VVa8VT(self, tDict):
  ndx = self.VVnbBC()
  for colNum, val in tDict.items():
   txt = str(val)
   if not self.isEditor and self.VVwZxf[ndx] & LEFT:
    txt = " %s " % txt.strip()
   col = list(self["myTable"].list[ndx][colNum + 1])
   col[7] = txt
   self["myTable"].list[ndx][colNum + 1] = tuple(col)
  self.VV3Rev()
 def VVp9X7(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VVjwlo(ndx, data, self.VVVH0w, self.VVRr4z, self.VVsykS, self.VVLwCQ, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VV3Rev()
 def VV3Rev(self):
  self["myTable"].l.setList(self["myTable"].list)
  self.VV7b1R()
 def VV71sD(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VVXQxM(self, colNum, textToFind, VVT0Gn=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VV7b1R()
    break
  else:
   if VVT0Gn:
    FFpIgV(self, "Not found", 1000)
 def VVfOKC(self, colDict, VVT0Gn=False):
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VV7b1R()
    return
  if VVT0Gn:
   FFpIgV(self, "Not found", 1000)
  return False
 def VV92Is(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVvpA1(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FF39jL(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VVYlFT(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][10] == self.VVJEju:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVHLTv(self):
  if self.selectedItems:
   for ndx, row in enumerate(self["myTable"].list):
    if row[1][10] == self.VVJEju:
     return ndx
  return -1
 def VV0XBH(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][10] == self.VVJEju:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VVv7Q6(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][10] == self.VVJEju : return True
  else        : return False
 def VV3rlI(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVLeVj(self):
  if self.menuButtonFnc:
   self.VVfGDl(self.menuButtonFnc)
   return
  if not self["keyMenu"].getVisible() or self.VVDWdv:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVnbBC()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVgktg1, VVNisj = CCYFnw.VVXxWc(self, False, False)
  VVgktg = []
  VVgktg.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVgktg.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVgktg.append(("Find ...\t\t%s" % (FF1YQ7(txt, VV4aa0) if txt else ""), "findNew"   ))
  VVgktg.append(itemOf(bool(VVgktg1)    , "Find (from Filter) ..."   , "filter"   ))
  if self.header:
   VVgktg.append(VVm7kE)
   VVgktg.append(("Table Statistcis"            , "tableStat"  ))
  VVgktg.append(VVm7kE)
  VVgktg.append((FF1YQ7("Export Table to .html"     , VVf8NN) , "VVZKYi" ))
  VVgktg.append((FF1YQ7("Export Table to .csv"     , VVf8NN) , "VVQegB" ))
  VVgktg.append((FF1YQ7("Export Table to .txt (Tab Separated)", VVf8NN) , "VVcAFh" ))
  if self.addSort:
   sList = []
   tot  = 0
   for i in range(self.totalCols):
    if self.VVYiuZ[i] > 1 or self.VVYiuZ[i] == self.VVXHfA:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     sList.append(("Sort by : %s" % name, i))
   if tot:
    VVgktg.append(VVm7kE)
    if tot == 1 : VVgktg.append(("Sort", sList[0][1]))
    else  : VVgktg += sList
  VV2qPD = ("Keys Help", self.FF69kyHelp)
  FFBqvZ(self, self.VV1An6, VVgktg=VVgktg, title=self.VVZC2U(), VV2qPD=VV2qPD)
 def VV1An6(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VVu8fG()
   elif item == "findPrev"  : self.VVu8fG(isPrev=True)
   elif item == "findNew"  : self.VVcXoP()
   elif item == "filter"  : self.VVW3aq()
   elif item == "tableStat" : self.VVNtqp()
   elif item == "VVZKYi": FFkWFV(self, self.VVZKYi, title=title)
   elif item == "VVQegB" : FFkWFV(self, self.VVQegB , title=title)
   elif item == "VVcAFh" : FFkWFV(self, self.VVcAFh , title=title)
   else:
    if self.VVWtKU == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVWtKU, self.lastSortModeIsReverese = item, False
    if self.VVFwVS and self.VVWtKU == 0 or self.VVvpA1(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVclfP(onlyHeader=True)
 def FF69kyHelp(self, VVVYOp, path):
  FFxVrN(self, "_help_table", "Table (Keys Help)")
 def VVpqnv(self):
  self["myTable"].up()
  self.VV7b1R()
 def VVMmTF(self):
  self["myTable"].down()
  self.VV7b1R()
 def VVjNzZ(self):
  self["myTable"].pageUp()
  self.VV7b1R()
 def VViXre(self):
  self["myTable"].pageDown()
  self.VV7b1R()
 def VV81wS(self):
  self["myTable"].moveToIndex(0)
  self.VV7b1R()
 def VVQbYY(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VV7b1R()
 def VV2NBO(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VV7b1R()
 def VV5Wle(self):
  if self.lastFindConfigObj.getValue():
   if self.VVnbBC() == len(self["myTable"].list) - 1 : FFpIgV(self, "End reached", 1000)
   else              : self.VVu8fG()
  else:
   FFpIgV(self, 'Set "Find" in Menu', 1500)
 def VVGKpP(self):
  if self.lastFindConfigObj.getValue():
   if self.VVnbBC() == 0 : FFpIgV(self, "Top reached", 1000)
   else       : self.VVu8fG(isPrev=True)
  else:
   FFpIgV(self, 'Set "Find" in Menu', 1500)
 def VVPZCS(self, txt):
  FFeLB8(self.lastFindConfigObj, txt)
 def VVcXoP(self):
  FF8ISk(self, self.VV9pEx, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VV9pEx(self, VVDhxg):
  if not VVDhxg is None:
   txt = VVDhxg.strip()
   self.VVPZCS(txt)
   if VVDhxg: self.VVu8fG(reset=True)
   else  : FFpIgV(self, "Nothing to find !", 1500)
 def VVW3aq(self):
  VVgktg, VVNisj = CCYFnw.VVXxWc(self, False, False)
  VVG0eT = ("Edit Filter", BF(self.VV4hpB, VVNisj))
  if VVgktg : FFBqvZ(self, self.VVxSHr, VVgktg=VVgktg, VVG0eT=VVG0eT, title="Find from Filter")
  else  : FFpIgV(self, "Filter Error !", 1500)
 def VVxSHr(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VVPZCS(txt)
    self.VVu8fG(reset=True)
   else:
    FFpIgV(self, "No entry !", 1500)
 def VV4hpB(self, VVNisj, selectionObj, sel):
  if fileExists(VVNisj) : CC0TyL(self, VVNisj, VVJ8mq=None)
  else       : FFcMQr(self, VVNisj)
  selectionObj.cancel()
 def VVu8fG(self, reset=False, isPrev=False):
  curRow = self.VVnbBC()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CCYFnw.VVt9Ew(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VV2NBO(i)
      break
    elif any(x in line for x in tupl):
     self.VV2NBO(i)
     break
   else:
    FFpIgV(self, "Not found", 1000)
  else:
   FFpIgV(self, "Check your query", 1500)
 def VVcAFh(self):
  expFile = self.VVytLC() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VV13le()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VV68fw(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVYiuZ[ndx] > self.VVWd36 or self.VVYiuZ[ndx] == self.VVEmb5:
      col = self.VVH3t3(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VVgN07(expFile)
 def VVQegB(self):
  expFile = self.VVytLC() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VV13le()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VV68fw(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVYiuZ[ndx] > self.VVWd36 or self.VVYiuZ[ndx] == self.VVEmb5:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VVH3t3(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVgN07(expFile)
 def VVZKYi(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVZC2U(), PLUGIN_NAME, VV9AsZ)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVZC2U()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VV13le()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVYiuZ:
   colgroup += '   <colgroup>'
   for w in self.VVYiuZ:
    if w > self.VVWd36 or w == self.VVEmb5:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVytLC() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VV68fw(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVYiuZ[ndx] > self.VVWd36 or self.VVYiuZ[ndx] == self.VVEmb5:
      col = self.VVH3t3(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVgN07(expFile)
 def VV13le(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVYiuZ[ndx] > self.VVWd36 or self.VVYiuZ[ndx] == self.VVEmb5:
     newRow.append(col.strip())
  return newRow
 def VVH3t3(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFOD7l(col)
 def VVytLC(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVZC2U())
  fileName = fileName.replace("__", "_")
  path  = FFGa2t(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FF4Fnb()
  return expFile
 def VVgN07(self, expFile):
  FF27fq(self, "File exported to:\n\n%s" % expFile, title=self.VVZC2U())
 def VV7b1R(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   totCols = len(row)
   if row[totCols - 1][0] == 0 : lastCol = totCols - 1
   else      : lastCol = totCols - 2
   x, y, w, h = row[lastCol][1:5]
   self["myTable"].l.setSelectionClip(eRect(0, 0, int(x + w), int(h)), True)
 @staticmethod
 def VVa1FY(x, y, w, h, png, bg=None, bgSel=None):
  typ = eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST
  if VVbE23: return (typ, x, y, w, h, png, bg, bgSel, VVbE23 | CENTER)
  else   : return (typ, x, y, w, h, png, bg, bgSel)
class CCnohF():
 def __init__(self, pixmapObj, picPath, VVRr4z=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VVRr4z  = VVRr4z or "#2200002a"
 def VVm7cT(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVpMH2)
    except:
     self.picLoad.PictureData.get().append(self.VVpMH2)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VVRr4z])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVpMH2(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVaf9s(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVfe7g(pixmapObj, path, VVRr4z=None):
  cl = CCnohF(pixmapObj, path, VVRr4z)
  ok = cl.VVm7cT()
  if ok: return cl
  else : return None
class CCLIUZ(Screen):
 def __init__(self, session, VVMYFn, title="", showGrnMsg="", fileList=None, curIndex=0, fakePath=None, cbFnc=None):
  scrW, scrH = FFfQyb()
  w = 1700
  h = int(min(w * scrH / scrW + 51, 1040))
  self.skin, self.skinParam = FFdP4M(VVn9ax, w, h, 30, 0, 0, "#22000060", "#2200002a", 30, topRightBtns=3)
  self.session  = session
  self.Title   = title
  self["myPic"]  = Pixmap()
  self.VVMYFn = VVMYFn
  self.showGrnMsg  = showGrnMsg
  self.fileList  = fileList
  self.curIndex  = curIndex
  self.fakePath  = fakePath
  self.cbFnc   = cbFnc
  self.picViewer  = None
  FFj3mb(self)
  self["myActionMap"] = ActionMap(VVKDoB,
  {
   "ok" : self.close    ,
   "red" : self.close    ,
   "cancel": self.close    ,
   "info" : self.VVaNFg  ,
   "up" : BF(self.VVmhgS, -1),
   "down" : BF(self.VVmhgS,  1),
   "left" : BF(self.VVmhgS, -1),
   "right" : BF(self.VVmhgS,  1)
  }, -1)
  self.onShown.append(self.VVgr8g)
  self.onClose.append(self.onExit)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFIl1A(self)
  self.VVNpxz()
  self.picViewer = CCnohF.VVfe7g(self["myPic"], self.VVMYFn)
  if self.picViewer:
   if self.showGrnMsg:
    FFpIgV(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFG2mq(self, "Cannot view picture file:\n\n%s" % self.VVMYFn)
   self.close()
 def onExit(self):
  if self.picViewer: self.picViewer.VVaf9s()
  if self.cbFnc  : self.cbFnc(self.VVMYFn)
 def VVmhgS(self, direc):
  if self.fileList:
   oldNdx = self.curIndex
   self.curIndex += direc
   if direc == -1 and self.curIndex < 0      : self.curIndex = len(self.fileList) - 1
   if direc ==  1 and self.curIndex > len(self.fileList) - 1 : self.curIndex = 0
   if not oldNdx == self.curIndex:
    fName = self.fileList[self.curIndex]
    self.VVMYFn = FFGa2t(os.path.dirname(self.VVMYFn)) + fName
    self.picViewer.picPath = self.VVMYFn
    self.picViewer.VVm7cT()
    self.VVNpxz()
 def VVaNFg(self):
  txt = "%s:\n  %s" % (FF1YQ7("Path", VVyz0j), self.fakePath or self.VVMYFn)
  size, sizeTxt, resTxt, form, mode = CCqxHs.VVjoVP(self.VVMYFn)
  if any((size, sizeTxt, resTxt, form, mode)):
   txt += "\n\n%s:\n" % FF1YQ7("Properties", VVyz0j)
   if sizeTxt: txt += "  File Size\t: %s\n" % sizeTxt
   if resTxt : txt += "  Dimensions\t: %s\n" % resTxt
   if form   : txt += "  Format\t: %s\n"  % form
   if mode   : txt += "  Mode\t: %s\n"   % mode
  FF8ShK(self, txt, title="File Information")
 def VVNpxz(self):
  if self.fileList: title = "%d/%d : %s" % (self.curIndex + 1, len(self.fileList), self.fileList[self.curIndex])
  elif self.Title : title = self.Title
  else   : title = os.path.basename(self.VVMYFn)
  self["myTitle"].setText("  %s  " % title)
 @staticmethod
 def VV94CH(SELF, VVMYFn, **kwargs):
  SELF.session.open(CCLIUZ, VVMYFn, **kwargs)
class CCcVRq(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FFdP4M(VVZhbx, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FFj3mb(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VVgr8g)
  self.onClose.append(self.onExit)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  if not FFLgW2("showiframe %s" % self.mviFile):
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VV7V4h(SELF, mviFile):
  SELF.session.openWithCallback(BF(CCcVRq.VVWFLG, SELF), CCcVRq, mviFile)
 @staticmethod
 def VVWFLG(SELF, reason=None):
  if reason == -1: FFG2mq(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CCmbpf(Screen, ConfigListScreen):
 VVESon = "ajpanel_update_url"
 def __init__(self, session):
  self.skin, self.skinParam = FFdP4M(VV59l2, 1400, 1050, 50, 15, 15, "#11201010", "#11101010", 27, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFj3mb(self, title=self.Title)
  FFuetT(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Exit-Button Action (in File Manager and FTP)"    , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Player Bar Hotkey"           , CFG.hotkey_signal    ))
  lst.append(getConfigListEntry("Screenshot"             , CFG.screenshotFType   ))
  lst.append(getConfigListEntry("Subtitle Files Encoding Priority"       , CFG.subtDefaultEnc   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type (defines the player)"   , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("Portal Servers Connection Timeout (seconds)"     , CFG.portalConnTimeout   ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Local Movies and IPTV Download Path"       , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB/etc.) + Package Projects"  , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons/Screenshots/Pictures"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVQLYc()
  self.onShown.append(self.VVgr8g)
 def VVQLYc(self):
  kList = {
    "ok" : self.VV96hS   ,
    "green" : self.VVcnBb ,
    "menu" : self.VVUcTe ,
    "cancel": self.VVtKDj ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VVaEit, 0)
     kList["chanDown"] = BF(self["config"].VVaEit, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(VVKDoB, kList, -1)
  else:
   self["actions"] = ActionMap(VVKDoB, kList, -1)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FFIl1A(self)
  FFayJd(self["config"])
  FF08xD(self, self["config"])
  FF2kyZ(self)
  self["config"].onSelectionChanged.append(self.VVWfJe)
  self.VVWfJe()
  FFeNfF(self["keyRed"], "#11000000")
  self["keyRed"].show()
 def VVWfJe(self):
  cfg = self["config"].getCurrent()[1]
  if   isinstance(cfg, ConfigDirectory): txt = "Change Path"
  else         : txt = "Show Choices"
  self["keyRed"].setText("OK = %s" % txt)
 def VV96hS(self):
  title, item = self["config"].getCurrent()
  if item:
   if   item == CFG.iptvHostsMode   : self.VVE4CT()
   elif item == CFG.MovieDownloadPath   : self.VVs6ap(item, self["config"].getCurrent()[0])
   elif item == CFG.subtDefaultEnc   : self.VVui5V()
   elif isinstance(item, ConfigDirectory) : self.VVbkKB(item)
   else         : CCmbpf.VVhrFb(self, item, title)
 @staticmethod
 def VVhrFb(SELF, confItem, title, lst=None, cbFnc=None, isSave=False):
  if not lst:
   if   isinstance(confItem, ConfigYesNo)  : lst = [(True, "ON"), (False, "OFF")]
   elif isinstance(confItem, ConfigSelectionNumber):
    lst = confItem.choices.choices
    if not isinstance(lst[0], tuple)  : lst = [(x, x) for x in lst]
   elif isinstance(confItem, ConfigSelection) : lst = confItem.choices.choices
   else          : return
  curNdx = defNdx = -1
  VVgktg = []
  for ndx, item in enumerate(lst):
   if len(item) == 1:
    val, txt = ("dum",SEP)
   else:
    val, txt = item
    if   val == confItem.value : curNdx, txt = ndx, VV4aa0 + txt
    elif val == confItem.default: defNdx, txt = ndx, VVChVP + txt
   VVgktg.append((txt, val))
  if defNdx == -1: defNdx = curNdx
  VV2qPD  = ("Current", BF(CCmbpf.VVzy6f, curNdx))
  VVG0eT = ("Default", BF(CCmbpf.VVzy6f, defNdx))
  VVVYOp = FFBqvZ(SELF, BF(CCmbpf.VVKqBz, confItem, cbFnc, isSave), VVgktg=VVgktg, width=1200, VVG0eT=VVG0eT, VV2qPD=VV2qPD, title=title, VVrcFy="#33221111", VVZZ3c="#33110011")
  VVVYOp.VVI0nr(curNdx)
 @staticmethod
 def VVKqBz(confItem, cbFnc, isSave, item=None):
  if not item is None:
   confItem.setValue(item)
   if isSave: FFeLB8(confItem, item)
   if cbFnc: cbFnc()
 @staticmethod
 def VVzy6f(ndx, selectionObj, item):
  selectionObj.VVI0nr(ndx)
 @staticmethod
 def VVVA5I(confItem, lst):
  for ndx, item in enumerate(lst):
   if item[0] == confItem.value:
    return ndx
  return -1
 def VVs6ap(self, item, title):
  tot = CCfWgm.VVeM2V()
  if tot : FFG2mq(self, "Cannot change while downloading.", title=title)
  else : self.VVbkKB(item)
 def VVui5V(self):
  curEnc = CFG.subtDefaultEnc.getValue()
  lst = CCmJil.VVZwPs(self, "", curEnc)
  if lst:
   VVG0eT = ("Default", self.VV4cHO)
   VV2qPD  = ("Current", self.VVB25b)
   VVVYOp = FFBqvZ(self, self.VVR3on, title="Select Priority Encoding", VVgktg=lst, width=1000, height=1000, VV2qPD=VV2qPD, VVG0eT=VVG0eT, VVrcFy="#22220000", VVZZ3c="#22220000", VVomDt=True)
   VVVYOp.VVy5pY(curEnc)
 def VVR3on(self, item=None):
  if item:
   txt, enc, ndx = item
   CFG.subtDefaultEnc.setValue(enc)
 def VV4cHO(self, VVVYOp, item): VVVYOp.VVy5pY(VVRaeq)
 def VVB25b(self, VVVYOp, item): VVVYOp.VVy5pY(CFG.subtDefaultEnc.getValue())
 def VVE4CT(self):
  VVgktg = []
  VVgktg.append(("Auto Find" , "auto"))
  VVgktg.append(("Custom Path" , "cust"))
  FFBqvZ(self, self.VVJSfy, VVgktg=VVgktg, title="IPTV Hosts Files Path")
 def VVJSfy(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVEzAi)
   elif item == "cust":
    VVUl7I = self.VVYwjo()
    if VVUl7I : self.VVTLuT(VVUl7I)
    else  : self.session.openWithCallback(self.VVZ6UZ, BF(CCyssW, mode=CCyssW.VVaEvY, VV9Esa="/"))
 def VVTLuT(self, VVUl7I):
  VVIcAB = self.VVldAG
  VVcNot = ("Remove"  , self.VVwuMD , [])
  VVW1zM = ("Add "  , self.VVtK17, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VVwZxf  = (LEFT   , LEFT  )
  FF69ky(self, None, title="IPTV Hosts Search Paths", header=header, VV9gTz=VVUl7I, width=1200, height=700, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=26, VVIcAB=VVIcAB, VVcNot=VVcNot, VVW1zM=VVW1zM
    , VVrcFy="#22220000", VVZZ3c="#22110000", VVRr4z="#22110011", VVLwCQ="#11223025", VVhvzQ="#0a333333", VVEjwd="#11400040")
 def VVldAG(self, VVkINB):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VVvWaG)
  VVkINB.cancel()
 def VVZ6UZ(self, path):
  if path:
   FFeLB8(CFG.iptvHostsDirs, FFGa2t(path.strip()))
   VVUl7I = self.VVYwjo()
   if VVUl7I : self.VVTLuT(VVUl7I)
   else  : FFpIgV(self, "Cannot add dir", 1500)
 def VVlpfp(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVEzAi:
   return []
  return lst
 def VVYwjo(self):
  lst = self.VVlpfp()
  if lst:
   VVUl7I = []
   for Dir in lst:
    VVUl7I.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVUl7I.sort(key=lambda x: x[0].lower())
   return VVUl7I
  else:
   return []
 def VVtK17(self, VVkINB, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VVKYgI, VVkINB)
         , BF(CCyssW, mode=CCyssW.VVaEvY, VV9Esa=sDir))
 def VVKYgI(self, VVkINB, path):
  if path:
   path = FFGa2t(path.strip())
   if self.VVaHC1(VVkINB, path):
    FFpIgV(VVkINB, "Already added", 1500)
   else:
    lst = self.VVlpfp()
    lst.append(path)
    FFeLB8(CFG.iptvHostsDirs, ",".join(lst))
    VVUl7I = self.VVYwjo()
    VVkINB.VVDqeT(VVUl7I, tableRefreshCB=BF(self.VVMfbG, path))
 def VVMfbG(self, path, VVkINB, title, txt, colList):
  self.VVaHC1(VVkINB, path)
 def VVaHC1(self, VVkINB, path):
  for ndx, row in enumerate(VVkINB.VV3rlI()):
   if row[0].strip() == path.strip():
    VVkINB.VV2NBO(ndx)
    return True
  return False
 def VVwuMD(self, VVkINB, title, txt, colList):
  path = colList[0]
  FFDiGG(self, BF(self.VVZupZ, VVkINB), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VVZupZ(self, VVkINB):
  row = VVkINB.VVw0xB()
  path, rem = row[0], row[1]
  VVUl7I = []
  lst = []
  for ndx, row in enumerate(VVkINB.VV3rlI()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVUl7I.append((tPath, tRem))
  if len(VVUl7I) > 0:
   FFeLB8(CFG.iptvHostsDirs, ",".join(lst))
   VVkINB.VVDqeT(VVUl7I)
   FFpIgV(VVkINB, "Deleted", 1500)
  else:
   FFeLB8(CFG.iptvHostsMode, VVEzAi)
   FFeLB8(CFG.iptvHostsDirs, "")
   VVkINB.cancel()
   FFLYGh(BF(FFpIgV, self, "Changed to Auto-Find", 1500))
 def VVbkKB(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VV21kn, configObj)
         , BF(CCyssW, mode=CCyssW.VVaEvY, VV9Esa=sDir))
 def VV21kn(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVtKDj(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFDiGG(self, self.VVcnBb, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVcnBb(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVBzW2()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVUcTe(self):
  VVgktg = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VVgktg.append((txt    , "VVDM0j"   ))
  else        : VVgktg.append((txt    ,       ))
  VVgktg.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Reset %s Settings" % PLUGIN_NAME      , "VVfra0"   ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Backup %s Settings" % PLUGIN_NAME      , "VVPsk6"  ))
  VVgktg.append(("Restore %s Settings" % PLUGIN_NAME     , "VVTVWy"  ))
  if fileExists(VVrXLj + CCmbpf.VVESon):
   VVgktg.append(VVm7kE)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VVgktg.append(('%s Checking for Update' % txt1     , txt2     ))
   VVgktg.append(("Reinstall %s" % PLUGIN_NAME      , "VVTI55"  ))
   VVgktg.append(("Update %s" % PLUGIN_NAME      , "VVarrY"   ))
  FFBqvZ(self, self.VVuCCD, VVgktg=VVgktg, title="Config. Options")
 def VVuCCD(self, item=None):
  if item:
   if   item == "VVDM0j"  : FFDiGG(self, self.VVDM0j , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CC73JY)
   elif item == "VVfra0"  : FFDiGG(self, BF(self.VVfra0, True), "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VVPsk6" : self.VVPsk6()
   elif item == "VVTVWy" : FFkWFV(self, self.VVTVWy, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FFeLB8(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FFeLB8(CFG.checkForUpdateAtStartup, False)
   elif item == "VVTI55" : FFkWFV(self, BF(self.VVxrvV, True ), "Checking Server ...")
   elif item == "VVarrY"  : FFkWFV(self, BF(self.VVxrvV, False), "Checking Server ...")
 def VVPsk6(self):
  path = "%sajpanel_settings_%s" % (VVrXLj, FF4Fnb())
  FFJ2Ng("grep .%s. %s > %s" % (PLUGIN_NAME, VVDhAD, path))
  FF27fq(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVTVWy(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name  = "ajpanel_settings_"
  files = FFa467("find / %s -iname '%s*' | grep %s" % (FFZu9n(1), name, name))
  if files:
   err = CCyssW.VVqYVb(files)
   if err:
    FFDiGG(self, BF(self.VVE5EH, title), "No valid settings files found !\n\nLocate Manually ?", title=title)
   else:
    files = sorted(files, key=lambda t: -os.stat(t).st_mtime)
    VVgktg = []
    for line in files:
     VVgktg.append((line, line))
    FFBqvZ(self, BF(self.VViej8, title), title=title, VVgktg=VVgktg, width=1200, VVfXMZ="")
  else:
   FFG2mq(self, "No settings files found !", title=title)
 def VVE5EH(self, title, path=None):
  sDir = "/"
  for path in (VVrXLj, "/media/usb/", "/media/hdd/", "/media/"):
   if pathExists(path):
    sDir = path
    break
  self.session.openWithCallback(BF(self.VViej8, title), BF(CCyssW, patternMode="ajpSet", VV9Esa=sDir))
 def VViej8(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFjqdo(path)
    self.VVfra0()
    for line in lines:
     name, _, val = line.partition("=")
     try:
      confItem = eval(name)
      if confItem is not None:
       if   isinstance(confItem, ConfigInteger)  : val = int(val)
       elif isinstance(confItem, ConfigSelectionNumber): val = int(val)
       elif isinstance(confItem, ConfigYesNo)   : val = { "true": True, "false": False }.get(val.lower())
       if not val is None:
        confItem.setValue(val)
        confItem.save()
     except:
      pass
    self.VVBzW2()
    FFkDix()
    FFpIgV(self, "Apllied", 1500, isGrn=True)
   else:
    FFcMQr(self, path, title=title)
 def VVDM0j(self):
  newPath = FFGa2t(VVrXLj)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVBzW2()
 @staticmethod
 def VV1HMk():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVfra0(self, exit=False):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVBzW2()
  if exit:
   self.close()
 def VVBzW2(self):
  configfile.save()
  global VVrXLj
  VVrXLj = CFG.backupPath.getValue()
  FF3EeP()
 def VVxrvV(self, force):
  pre = "Reinstall" if force else "Update"
  title = "%s %s (from server)" % (pre, PLUGIN_NAME)
  curVer, webVer, url, isHigher, err = CCmbpf.VV7p9u()
  if   err    : FFG2mq(self, err, title)
  elif isHigher or force : FFDiGG(self, BF(FFkWFV, self, BF(self.VVxgq8, webVer, url, title, force)), "%s v%s and Restart ?" % ("Reinstall" if force else "Upgrade to", webVer), title=title)
  else     : FF27fq(self, FF1YQ7("No update required.", VVNQoM) + "\n\nCurrent Version = v%s\n\nWeb Version = v%s" % (curVer, webVer), title)
 def VVxgq8(self, webVer, url, title, force):
  fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if FFyncK() == "dpkg" else "ipk")
  path, err = FFq7bz(url + fName, fName, timeout=2)
  if path:
   if force: cmd = FFjDaF(VVg1cm, path)
   else : cmd = FFjDaF(VVEgPl, path)
   if cmd:
    cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -rf '%s'" % (cmd, path)
    FF20zH(self, cmd, title=title)
   else:
    FFEPUu(self, title=title)
  else:
   FFG2mq(self, err, title=title)
 @staticmethod
 def VV7p9u():
  span = iSearch(r"v*(\d.\d.\d)", VV9AsZ, IGNORECASE)
  if span : curVer = span.group(1)
  else : return "", "", "", False, "Incorrect local version format !"
  path = VVrXLj + CCmbpf.VVESon
  if fileExists(path):
   span = iSearch(r"(http.+)", FFSIRe(path), IGNORECASE)
   if span : url = FFGa2t(span.group(1))
   else : return curVer, "", "", False, err
  else:
   return curVer, "", "", False, "Update File not found:\n\n%s" % path
  path, err = FFq7bz(url + "version", "ajp_tmp.ver", timeout=2)
  if err:
   return curVer, "", url, False, err
  if fileExists(path):
   txt  = FFSIRe(path).strip().replace(" ", "")
   FFMc8G(path)
   span = iSearch(r"v*(\d.\d.\d)", txt.partition("=")[2], IGNORECASE)
   if span:
    webVer = span.group(1)
    webTup = tuple(map(int, (webVer.split("."))))
    curTup = tuple(map(int, (curVer.split("."))))
    return curVer, webVer, url, webTup > curTup, ""
   else:
    return curVer, "", url, False, "Incorrect version format (from server) !"
  else:
   return curVer, "", url, False, "Cannot download Version File !"
class CC73JY(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFdP4M(VVMqMG, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVmjYo
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFj3mb(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVMnWs("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVMnWs("\c00888888", i) + sp + "GREY\n"
   txt += self.VVMnWs("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVMnWs("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVMnWs("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVMnWs("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVMnWs("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVMnWs("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVMnWs("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVMnWs("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVMnWs("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVMnWs("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(VVKDoB,
  {
   "ok" : self.VV96hS ,
   "green" : self.VV96hS ,
   "left" : self.VVvxS4 ,
   "right" : self.VV3Elm ,
   "cancel": self.close
  }, -1)
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  self.VVVqdW()
 def VV96hS(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFDiGG(self, self.VVE9nT, "Change to : %s" % txt, title=self.Title)
 def VVE9nT(self):
  FFeLB8(CFG.mixedColorScheme, self.cursorPos)
  global VVmjYo
  VVmjYo = self.cursorPos
  self.VVwnQs()
  self.close()
 def VVvxS4(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVVqdW()
 def VV3Elm(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVVqdW()
 def VVVqdW(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVMnWs(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVN66D(color):
  if VVChVP: return "\\" + color
  else    : return ""
 @staticmethod
 def VVwnQs():
  global VVqC3w, VVdl3O, VVYZPJ, VVWgbP, VVf8NN, VVeksK, VVhCly, VVFApq, VVNQoM, VVo8aK, VVChVP, VVyz0j, VV4aa0, VVifMr, VVJU8R, VVTKcZ
  VVTKcZ   = CC73JY.VVMnWs("\c00FFFFFF", VVmjYo)
  VVdl3O    = CC73JY.VVMnWs("\c00888888", VVmjYo)
  VVqC3w  = CC73JY.VVMnWs("\c005A5A5A", VVmjYo)
  VVFApq    = CC73JY.VVMnWs("\c00FF0000", VVmjYo)
  VVYZPJ   = CC73JY.VVMnWs("\c00FF5000", VVmjYo)
  VVWgbP   = CC73JY.VVMnWs("\c00FFBB66", VVmjYo)
  VVChVP   = CC73JY.VVMnWs("\c00FFFF00", VVmjYo)
  VVyz0j = CC73JY.VVMnWs("\c00FFFFAA", VVmjYo)
  VVNQoM   = CC73JY.VVMnWs("\c0000FF00", VVmjYo)
  VVo8aK  = CC73JY.VVMnWs("\c00AAFFAA", VVmjYo)
  VVhCly    = CC73JY.VVMnWs("\c000066FF", VVmjYo)
  VV4aa0    = CC73JY.VVMnWs("\c0000FFFF", VVmjYo)
  VVifMr  = CC73JY.VVMnWs("\c00AAFFFF", VVmjYo)  #
  VVJU8R   = CC73JY.VVMnWs("\c00FA55E7", VVmjYo)
  VVf8NN    = CC73JY.VVMnWs("\c00FF8F5F", VVmjYo)
  VVeksK  = CC73JY.VVMnWs("\c00FFC0C0", VVmjYo)
CC73JY.VVwnQs()
class CCtQ7C(Screen):
 def __init__(self, session, path, VVYfey):
  self.skin, self.skinParam = FFdP4M(VVWUpg, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVC7As   = path
  self.VVCdH1   = ""
  self.VVKIRD   = ""
  self.VVYfey    = VVYfey
  self.VVduVi    = ""
  self.VVm7Vv  = ""
  self.VVkan6    = False
  self.VVibWX  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VVpxJY  = "enigma2-plugin-extensions-"
  self.VVHW4Z  = "enigma2-plugin-systemplugins-"
  self.VVsMeV = "enigma2-"
  self.VVFPFo  = 0
  self.VV2dNO  = 1
  self.VVSkLs  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVcZHS = "DEBIAN"
  else        : self.VVcZHS = "CONTROL"
  self.controlPath = self.Path + self.VVcZHS
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVYfey:
   self.packageExt  = ".deb"
   self.VVRr4z  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVRr4z  = "#11001020"
  FFj3mb(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFuetT(self["keyRed"] , "Create")
  FFuetT(self["keyGreen"] , "Post Install")
  FFuetT(self["keyYellow"], "Installation Path")
  FFuetT(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(VVKDoB,
  {
   "red"   : self.VVXSep  ,
   "green"   : self.VVQbDq ,
   "yellow"  : self.VVdvGe  ,
   "blue"   : self.VVnrLT  ,
   "cancel"  : self.VVr4Bm
  }, -1)
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FF2kyZ(self)
  if self.VVRr4z:
   FFeNfF(self["myBody"], self.VVRr4z)
   FFeNfF(self["myLabel"], self.VVRr4z)
  self.VV5xEA(True)
  self.VV2qPf(True)
 def VV2qPf(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVFJil()
  if isFirstTime:
   if   package.startswith(self.VVpxJY) : self.VVC7As = VVuGsg + self.VVduVi + "/"
   elif package.startswith(self.VVHW4Z) : self.VVC7As = VVlNeR + self.VVduVi + "/"
   else            : self.VVC7As = self.Path
  if self.VVkan6 : myColor = VVf8NN
  else    : myColor = VVTKcZ
  txt  = ""
  txt += "Source Path\t: %s\n" % FF1YQ7(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FF1YQ7(self.VVC7As, VVChVP)
  if self.VVKIRD : txt += "Package File\t: %s\n" % FF1YQ7(self.VVKIRD, VVdl3O)
  elif errTxt   : txt += "Warning\t: %s\n"  % FF1YQ7("Check Control File fields : %s" % errTxt, VVYZPJ)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FF1YQ7("Restart GUI", VVf8NN)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FF1YQ7("Reboot Device", VVf8NN)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FF1YQ7("Post Install", VVNQoM), act)
  if not errTxt and VVYZPJ in controlInfo:
   txt += "Warning\t: %s\n" % FF1YQ7("Errors in control file may affect the result package.", VVYZPJ)
  txt += "\nControl File\t: %s\n" % FF1YQ7(self.controlFile, VVdl3O)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVQbDq(self):
  if self["keyGreen"].getVisible():
   VVgktg = []
   VVgktg.append(("No Action"    , "noAction"  ))
   VVgktg.append(("Restart GUI"    , "VVoFLA"  ))
   VVgktg.append(("Reboot Device"   , "rebootDev"  ))
   FFBqvZ(self, self.VVf7uv, title="Package Installation Option (after completing installation)", VVgktg=VVgktg)
 def VVf7uv(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVoFLA"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VV5xEA(False)
   self.VV2qPf()
 def VVdvGe(self):
  rootPath = FF1YQ7("/%s/" % self.VVduVi, VVyz0j)
  VVgktg = []
  VVgktg.append(("Current Path"        , "toCurrent"  ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Extension Path"       , "toExtensions" ))
  VVgktg.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVgktg.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFBqvZ(self, self.VVYMNL, title="Installation Path", VVgktg=VVgktg)
 def VVYMNL(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VV1YX2(FFMiJ8(self.Path, True))
   elif item == "toExtensions"  : self.VV1YX2(VVuGsg)
   elif item == "toSystemPlugins" : self.VV1YX2(VVlNeR)
   elif item == "toRootPath"  : self.VV1YX2("/")
   elif item == "toRoot"   : self.VV1YX2("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VViCnd, BF(CCyssW, mode=CCyssW.VVaEvY, VV9Esa=VVrXLj))
 def VViCnd(self, path):
  if len(path) > 0:
   self.VV1YX2(path)
 def VV1YX2(self, parent, withPackageName=True):
  if withPackageName : self.VVC7As = parent + self.VVduVi + "/"
  else    : self.VVC7As = "/"
  mode = self.VVSzEZ()
  FFLgW2("sed -i '/Package/c\Package: %s' %s" % (self.VVp6GM(mode), self.controlFile))
  self.VV2qPf()
 def VVnrLT(self):
  if fileExists(self.controlFile):
   lines = FFjqdo(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FF8ISk(self, self.VVklcn, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFG2mq(self, "Version not found or incorrectly set !")
  else:
   FFcMQr(self, self.controlFile)
 def VVklcn(self, VVDhxg):
  if VVDhxg:
   version, color = self.VVvBfo(VVDhxg, False)
   if color == VV4aa0:
    FFLgW2("sed -i '/Version:/c\Version: %s' %s" % (VVDhxg, self.controlFile))
    self.VV2qPf()
   else:
    FFG2mq(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVr4Bm(self):
  if self.newControlPath:
   if self.VVkan6:
    self.VVoKFf()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FF1YQ7(self.newControlPath, VVdl3O)
    txt += FF1YQ7("Do you want to keep these files ?", VVChVP)
    FFDiGG(self, self.close, txt, callBack_No=self.VVoKFf, title="Create Package", VVm2Fj=True)
  else:
   self.close()
 def VVoKFf(self):
  FFLgW2("rm -rf '%s'" % self.newControlPath)
  self.close()
 def VVp6GM(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VVm7Vv
  if package.startswith(self.VVsMeV):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VVsMeV, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VV2dNO : prefix = self.VVpxJY
  elif mode == self.VVSkLs : prefix = self.VVHW4Z
  return (prefix + name).lower()
 def VVSzEZ(self):
  if   self.VVC7As.startswith(VVuGsg) : return self.VV2dNO
  elif self.VVC7As.startswith(VVlNeR) : return self.VVSkLs
  else            : return self.VVFPFo
 def VV5xEA(self, isFirstTime):
  self.VVduVi   = FFBBEq(self.Path)
  self.VVduVi   = "_".join(self.VVduVi.split())
  self.VVm7Vv = self.VVduVi.lower()
  self.VVkan6 = self.VVm7Vv == VVmIIf.lower()
  if self.VVkan6 and self.VVm7Vv.endswith(VVmIIf.lower()):
   self.VVm7Vv += "el"
  if self.VVkan6 : self.VVCdH1 = VVrXLj
  else    : self.VVCdH1 = CFG.packageOutputPath.getValue()
  self.VVCdH1 = FFGa2t(self.VVCdH1)
  if not pathExists(self.controlPath):
   FFLgW2("mkdir '%s'" % self.controlPath)
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VVSzEZ()
  if fileExists(self.controlFile):
   lines = FFjqdo(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VVkan6 : version, descripton, maintainer = VV9AsZ , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVduVi , self.VVduVi
   txt = ""
   txt += "Package: %s\n"  % self.VVp6GM(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VVkan6 : t = PLUGIN_NAME
  else    : t = self.VVduVi
  self.VVeifI(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VVeifI(self.postrmFile, "echo 'Package removed.'\n")
  if self.VVkan6 : self.VVeifI(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VV9AsZ))
  else    : self.VVeifI(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVduVi)
  if isFirstTime and not mode == self.VVFPFo:
   self.postInstAcion = 1
  txt = self.VVVOSZ(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFSIRe(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VVVOSZ(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  FFLgW2("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile))
 def VVeifI(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VVVOSZ(self, action):
  sep  = "echo '%s'\n" % SEP
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VVFJil(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFjqdo(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FF1YQ7(line, VVYZPJ)
     elif not line.startswith(" ")    : line = FF1YQ7(line, VVYZPJ)
     else          : line = FF1YQ7(line, VV4aa0)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VV4aa0
   else   : color = VVYZPJ
   descr = FF1YQ7(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVYZPJ
     elif line.startswith((" ", "\t")) : color = VVYZPJ
     elif line.startswith("#")   : color = VVdl3O
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVvBfo(val, True)
      elif key == "Version"  : version, color = self.VVvBfo(val, False)
      elif key == "Maintainer" : maint  , color = val, VV4aa0
      elif key == "Architecture" : arch  , color = val, VV4aa0
      else:
       color = VV4aa0
      if not key == "OE" and not key.istitle():
       color = VVYZPJ
     else:
      color = VVf8NN
     txt += FF1YQ7(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVKIRD = self.VVCdH1 + packageName
   self.VVibWX = True
   errTxt = ""
  else:
   self.VVKIRD  = ""
   self.VVibWX = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVvBfo(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VV4aa0
  else          : return val, VVYZPJ
 def VVXSep(self):
  if not self.VVibWX:
   FFG2mq(self, "Please fix Control File errors first.")
   return
  if self.VVYfey: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFMiJ8(self.VVC7As, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVduVi
  symlinkTo  = FFTgmt(self.Path)
  dataDir   = self.VVC7As.rstrip("/")
  removePorjDir = FFhkCt("rm -rf '%s'"  % projDir)
  cmd  = ""
  cmd += FFhkCt("rm -f '%s'" % self.VVKIRD)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFNkgD()
  if self.VVYfey:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FF3zFj("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVkan6:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVC7As == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVcZHS)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVKIRD, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVKIRD
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVKIRD, FFog5k(result  , VVNQoM))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVC7As, FFog5k(instPath, VV4aa0))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFog5k(failed, VVYZPJ))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FF20zH(self, cmd)
class CCMyrC():
 VVDBBs  = "666"
 VVtBB2   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.VVVYOp   = None
  self.VVHFvr()
 def VVHFvr(self):
  VVgktg = CCMyrC.VVyIT7()
  if VVgktg:
   VVG0eT = ("Create New", self.VV5OnM)
   self.VVVYOp = FFBqvZ(self.SELF, self.VV8In0, VVgktg=VVgktg, title=self.Title, VVG0eT=VVG0eT, VVomDt=True, VVrcFy="#22222233", VVZZ3c="#22222233")
  else:
   self.VV5OnM()
 def VV8In0(self, item):
  if item:
   bName, bRef, ndx = item
   self.VVRfat(bName, bRef)
  else:
   CCMyrC.VVitUX(self)
 def VV5OnM(self, selectionObj=None, item=None):
  FF8ISk(self.SELF, BF(self.VVl14h), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVl14h(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.VVVYOp:
     self.VVVYOp.cancel()
    self.VVRfat(bName, "")
   else:
    FFpIgV(self.VVVYOp, "Incorrect Bouquet Name !", 2000)
    CCMyrC.VVitUX(self)
 def VVRfat(self, bName, bRef):
  FFkWFV(self.waitMsgSELF, BF(self.VVh4IP, bName, bRef), title="Adding Services ...")
 def VVh4IP(self, bName, bRef):
  CCMyrC.VVmRoE(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VVitUX(classObj):
  del classObj
 @staticmethod
 def VVmRoE(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FFG2mq(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVMixw + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FFcMQr(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CCMyrC.VVETMB(bRef)
   bPath = VVMixw + bFile
  else:
   fName = CCul6W.VVY5tM(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVMixw + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVMixw + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  FFVch7(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   FFVch7(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CCQVwA.VVzkHI()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       FFLgW2("cp -f '%s' '%s'" % (poster, picon))
       FFLgW2(CCXzVR.VVB1Rq(picon))
       break
  FFHpDz()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FF8ShK(SELF, txt, title=title)
 @staticmethod
 def VV11cv(bName):
  mode = CC01PH.VVlkXF(default=-1)
  modeTxt = "tv" if mode == 0 else "radio"
  fName = CCul6W.VVY5tM(bName)
  bFile = "userbouquet.%s.%s" % (fName, modeTxt)
  num   = 0
  while fileExists(VVMixw + bFile):
   num += 1
   bFile = "userbouquet.%s_%d.%s" % (fName, num, modeTxt)
  with open(VVMixw + bFile, "w") as f:
   f.write("#NAME %s\n" % bName)
  mainBFile = "%sbouquets.%s" % (VVMixw, modeTxt)
  if fileExists(mainBFile):
   FFVch7(mainBFile)
   with open(mainBFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
 @staticmethod
 def VV5CdL(ref, bName):
  bFile = CCMyrC.VVETMB(ref)
  ok = False
  if bFile:
   bFile = VVMixw + bFile
   if fileExists(bFile):
    lines = FFjqdo(bFile, keepends=True)
    with open(bFile, "w") as f:
     for line in lines:
      if line.startswith("#NAME "):
       f.write("#NAME %s\n" % bName)
       ok = True
      else:
       f.write(line)
  return ok
 @staticmethod
 def VVyIT7(mode=2, showTitle=True, prefix="", onlyIptv=False):
  VVgktg = []
  if mode in (0, 2): VVgktg.extend(CCMyrC.VVEj4Y(0, showTitle, prefix, onlyIptv))
  if mode in (1, 2): VVgktg.extend(CCMyrC.VVEj4Y(1, showTitle, prefix, onlyIptv))
  return VVgktg
 @staticmethod
 def VVEj4Y(mode, showTitle, prefix, onlyIptv):
  VVgktg = []
  lst = CCMyrC.VVj9jy(mode)
  if onlyIptv:
   lst = CCMyrC.VVAjKs(lst)
  if lst:
   if showTitle:
    VVgktg.append(FFZRMI("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVgktg.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVgktg.append((item[0], item[1].toString()))
  return VVgktg
 @staticmethod
 def VVAjKs(lst):
  fLst = CCul6W.VVMJXK(onlyFileName=True)
  newLst = []
  if fLst:
   for item in lst:
    span = iSearch(r".+(userbouquet\..+\.(tv|radio))", item[1].toString())
    if span and span.group(1) in fLst:
     newLst.append(item)
  return newLst
 @staticmethod
 def VVQmFq():
  lst = CCMyrC.VVj9jy(0)
  lst.extend(CCMyrC.VVj9jy(1))
  return lst
 @staticmethod
 def VVj9jy(mode=0):
  bList = []
  VVw847 = InfoBar.instance
  VVpnhD = VVw847 and VVw847.servicelist
  if VVpnhD:
   curMode = VVpnhD.mode
   CCMyrC.VVSXQv(VVpnhD, mode)
   bList.extend(VVpnhD.getBouquetList() or [])
   CCMyrC.VVSXQv(VVpnhD, curMode)
  return bList
 @staticmethod
 def VVSXQv(VVpnhD, mode):
  if not mode == VVpnhD.mode:
   if   mode == 0: VVpnhD.setModeTv()
   elif mode == 1: VVpnhD.setModeRadio()
 @staticmethod
 def VVXXpV(isAll=True, onlyMain=False):
  bLst = []
  inst = InfoBar.instance
  if inst:
   csel = inst.servicelist
   if csel:
    root = csel.bouquet_root
    VVnXy1 = eServiceCenter.getInstance()
    if onlyMain:
     info = VVnXy1.info(root)
     if info:
      bLst.append((info.getName(root), root.toString()))
    else:
     list = VVnXy1 and VVnXy1.list(root)
     if list:
      while True:
       s = list.getNext()
       if not s.valid():
        break
       if isAll or (s.flags & eServiceReference.isDirectory and not s.flags & eServiceReference.isInvisible):
        info = VVnXy1.info(s)
        if info:
         bLst.append((info.getName(s), s.toString()))
  return bLst
 @staticmethod
 def VVETMB(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : return ""
 @staticmethod
 def VVP7kB(ref, dstFile):
  dstFile = VVMixw + dstFile
  if fileExists(dstFile):
   FFVch7(dstFile)
   bLine = ""
   srcFile = CCMyrC.VVETMB(ref)
   if srcFile:
    span = iSearch(r"\.(.+)\.(tv|radio)", srcFile, IGNORECASE)
    if span:
     fName, fType = span.group(1), span.group(2)
     newName = "userSubBouquet.%s.%s" % (fName, fType)
     num = 0
     while fileExists(VVMixw + newName):
      num += 1
      newName = "userSubBouquet.%s_%d.%s" % (fName, num, fType)
     subFile = VVMixw + newName
     FFLgW2("cp -f '%s%s' '%s'" % (VVMixw, srcFile, subFile))
     if fileExists(subFile):
      bLine = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % newName
   else:
    bLine = ref
   if bLine:
    if fileExists(dstFile):
     with open(dstFile, "a") as f:
      f.write("#SERVICE %s\n" % bLine)
     return True
  return False
 @staticmethod
 def VVUvjS():
  try:
   fName = CCMyrC.VVETMB(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVMixw, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VVIIML():
  path = CCMyrC.VVUvjS()
  if path:
   txt = FFSIRe(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VVKuzJ():
  return FFanBk(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VVgUZC():
  lst = []
  for b in CCMyrC.VVQmFq():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVMixw + CCMyrC.VVETMB(bRef)
   if fileExists(path):
    lines = FFjqdo(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VVnaNl(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VVSnUF(SID="", stripRType=False):
  if SID : patt = CCMyrC.VVnaNl(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CCMyrC.VVQmFq():
   for service in FFanBk(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VVbsTQ():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CCMyrC.VVQmFq():
   for service in FFanBk(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VVxXF4(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VVYYRX(pathLst, rType=""):
  refLst = CCMyrC.VVSnUF(CCMyrC.VVDBBs, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = rType or CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CCMyrC.VVxXF4(rType, CCMyrC.VVDBBs, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CCyssW(Screen):
 VVlToO   = 0
 VVxsbx  = 1
 VVaEvY  = 2
 VVkFv4 = 3
 VVIqsA    = 20
 VVJ1bQ   = 0
 VV5KfG   = 1
 VV1sKW   = 2
 def __init__(self, session, VV9Esa="/", mode=VVlToO, VVxuyD="Select", width=1400, height=920, VVvi36=30, VVrcFy="#22001111", VVZZ3c="#22000000", pickTitleBG="#11001144", pickBodyBG="#11002255", cursorBG="#06003333", gotoMovie=False, jumpToFile="", patternMode=""):
  self.skin, self.skinParam = FFdP4M(VVuQx7, width, height, 30, 40, 20, VVrcFy, VVZZ3c, VVvi36, barHeight=40, topRightBtns=2)
  self.session   = session
  self.VVrcFy   = VVrcFy
  self.VVZZ3c    = VVZZ3c
  self.pickTitleBG  = pickTitleBG
  self.pickBodyBG   = pickBodyBG
  FFj3mb(self)
  FFuetT(self["keyRed"] , "Exit")
  FFuetT(self["keyYellow"], "More Options")
  FFuetT(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVxuyD = VVxuyD
  self.jumpToFile   = jumpToFile
  self.patternMode  = patternMode
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = cursorBG
  self.multiSelectState = False
  VVGaPA = None
  if patternMode:
   self.mode = self.VVkFv4
   if   patternMode == "srt"  : VVGaPA = ("^.*\.srt$"    , IGNORECASE)
   elif patternMode == "ajpSet" : VVGaPA = ("^.*\/ajpanel_settings_" , 0    )
   elif patternMode == "poster" : VVGaPA = ("^.*\.(jpg|png)$"    , IGNORECASE)
   elif patternMode == "pkgCtrl": VVGaPA = ("^.*\/(control|preinst|prerm|postinst|postrm)$", 0)
   elif patternMode == "movies" : VVGaPA = ("^.*\.(%s)$" % "|".join(CC7kl8.VVBUKY()["mov"]), IGNORECASE)
   else       : VVGaPA = None
  if self.mode in (self.VVaEvY, self.VVkFv4):
   FFuetT(self["keyRed"], "Cancel")
  if   self.jumpToFile       : VVX1av, self.VV9Esa = True , FFMiJ8(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VVX1av, self.VV9Esa = True , CCyssW.VVOVMO(self)[1] or "/"
  elif self.mode == self.VVlToO  : VVX1av, self.VV9Esa = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVaEvY : VVX1av, self.VV9Esa = False, VV9Esa
  elif self.mode == self.VVkFv4 : VVX1av, self.VV9Esa = True , VV9Esa
  else           : VVX1av, self.VV9Esa = True , VV9Esa
  self.VV9Esa = FFGa2t(self.VV9Esa)
  self["myMenu"] = CC7kl8(  directory   = None
         , VVGaPA = VVGaPA
         , VVX1av   = VVX1av
         , VVuCsD = True
         , VVWR88 = True
         , VVo2w3   = self.skinParam["width"]
         , VVvi36   = self.skinParam["bodyFontSize"]
         , VVaKvA  = self.skinParam["bodyLineH"] )
  self["myActionMap"] = ActionMap(VVKDoB,
  {
   "ok" : self.VV96hS    ,
   "red" : self.VVhiEI   ,
   "green" : self.VVmmbz,
   "yellow": self.VVtcqD  ,
   "blue" : self.VV2X5Q ,
   "menu" : self.VVHzp7  ,
   "info" : self.VV0pXw  ,
   "cancel": self.VVUaes    ,
   "pageUp": self.VVx5nS   ,
   "chanUp": self.VVx5nS
  }, -1)
  FFaxrK(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVhGGF)
  global VVSZdo
  VVSZdo = True
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.mode == self.VVlToO:
   FFTeQk("VVSZdo")
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVhGGF)
  FFIl1A(self)
  FFayJd(self["myMenu"], bg=self.cursorBG)
  FF2kyZ(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVaEvY, self.VVkFv4):
   FFuetT(self["keyGreen"], self.VVxuyD)
   self.VVufOL(self.VV5KfG)
  self.VVhGGF()
  w  = self["myMenu"].instance.size().width()
  h  = self["myMenu"].instance.size().height()
  pos  = self["myMenu"].getPosition()
  part = self["myMenu"].instance.size().height() % self.skinParam["bodyLineH"]
  half = int(part / 2)
  self["myMenu"].instance.resize(eSize(*(w, h - part)))
  self["myMenu"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.VV4sFC(self.VV9Esa) > self.bigDirSize: FFkWFV(self, self.VVrBQh, title="Changing directory...")
  else              : self.VVrBQh()
 def VVrBQh(self):
  if self.jumpToFile : self.VV7POC(self.jumpToFile)
  elif self.gotoMovie : self.VVge0R(chDir=False)
  else    : self["myMenu"].VVFX3C(self.VV9Esa)
 def VV2NBO(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVG86q(self):
  FFkWFV(self, self.VVOL9C, title="Refreshing list ...")
 def VVOL9C(self):
  isSel = self["myMenu"].VVnaun()
  if not isSel:
   self.VV9DAi(False)
  FFxmPl()
 def VVwY5T(self, saved):
  if saved: self.VVG86q()
 def VV4sFC(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VV96hS(self):
  if self.multiSelectState:
   ok = self["myMenu"].VVazbP()
   if ok : self["keyBlue"].setText(self.VVehCH())
   else : FFpIgV(self, "Cannot select item", 500)
  elif self["myMenu"].VVmriY(): self.VV55Lm()
  else       : self.VVWDeJ()
 def VVx5nS(self):
  if self.multiSelectState:
   FFpIgV(self, "Disable Multi-Select first", 1000)
  else:
   self["myMenu"].moveToIndex(0)
   if self["myMenu"].VV5ARR():
    self.VV55Lm()
 def VV55Lm(self, isDirUp=False):
  if self["myMenu"].VVmriY():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VVPQtX(self.VVW0lj())
   if self.VV4sFC(path) > self.bigDirSize : FFkWFV(self, self.VVgopj, title="Changing directory...")
   else           : self.VVgopj()
 def VVgopj(self):
  self["myMenu"].descent()
  self.VVhGGF()
 def VVUaes(self):
  if   self.multiSelectState     : self.VV9DAi(False, True)
  elif CFG.FileManagerExit.getValue() == "e" : self.VVhiEI()
  else          : self.VVx5nS()
 def VVhiEI(self):
  if not FFcGBG(self):
   self.close("")
 def VVmmbz(self):
  path = self.VVPQtX(self.VVW0lj())
  if self.mode == self.VVaEvY:
   self.close(path)
  elif self.mode == self.VVkFv4:
   if os.path.isfile(path) : self.close(path)
   else     : FFpIgV(self, "Cannot access this file", 1000)
 def VV0pXw(self):
  FFkWFV(self, self.VVcJNk, title="Calculating size ...")
 def VVcJNk(self):
  path = self.VVPQtX(self.VVW0lj())
  param = self.VViFMa(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFdHIn("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCyssW.VV3pfV(path)
     freeSize = CCyssW.VVeQ1N(path)
     size = totSize - freeSize
     totSize  = CCyssW.VV1ctA(totSize)
     freeSize = CCyssW.VV1ctA(freeSize)
    else:
     size = FFN3lb(path)
   usedSize = CCyssW.VV1ctA(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FF1YQ7(pathTxt, VVf8NN) + "\n"
   if slBroken : fileTime = self.VVnkCL(path)
   else  : fileTime = self.VVTDbt(path)
   def VVGnZU(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVGnZU("Path"    , pathTxt)
   txt += VVGnZU("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVGnZU("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVGnZU("Total Size"   , "%s" % totSize)
    txt += VVGnZU("Used Size"   , "%s" % usedSize)
    txt += VVGnZU("Free Size"   , "%s" % freeSize)
   else:
    txt += VVGnZU("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVGnZU("Owner"    , owner)
   txt += VVGnZU("Group"    , group)
   txt += VVGnZU("Perm. (User)"  , permUser)
   txt += VVGnZU("Perm. (Group)"  , permGroup)
   txt += VVGnZU("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVGnZU("Perm. (Ext.)" , permExtra)
   txt += VVGnZU("iNode"    , iNode)
   txt += VVGnZU("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (SEP, SEP)
    txt += hLinkedFiles
   txt += self.VVqaXl(path)
  else:
   FFG2mq(self, "Cannot access information !")
  if len(txt) > 0:
   FF8ShK(self, txt)
 def VViFMa(self, path):
  path = path.strip()
  path = FFTgmt(path)
  result = FFdHIn("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVPUpJ(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVPUpJ(perm, 1, 4)
   permGroup = VVPUpJ(perm, 4, 7)
   permOther = VVPUpJ(perm, 7, 10)
   permExtra = VVPUpJ(perm, 10, 100)
   typeChar = perm[0:1]
   typeStr = {"-":"File", "b":"Block Device File", "c":"Character Device File", "d":"Directory", "e":"External Link", "l":"Symbolic Link", "n":"Network File", "p":"Named Pipe", "s":"Local Socket File"}.get(typeChar, "Unknown")
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFnpLo("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVqaXl(self, path):
  txt  = ""
  res  = FFdHIn("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = {"a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file"}
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FF1YQ7("File Attributes:", VVJU8R), txt)
  return txt
 def VVTDbt(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFPuhT(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFPuhT(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFPuhT(os.path.getctime(path))
  return txt
 def VVnkCL(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFdHIn("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFdHIn("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFdHIn("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVPQtX(self, currentSel):
  currentDir  = self["myMenu"].VVs67s()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVmriY():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVW0lj(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VVhGGF(self):
  path = self.VVPQtX(self.VVW0lj())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VVidVk()
  if self.mode == self.VVlToO:
   if len(path) > 0: self["keyMenu"].show()
   else   : self["keyMenu"].hide()
  if self.mode == self.VVkFv4:
   path = self.VVPQtX(self.VVW0lj())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VVHzp7(self):
  color1 = VVeksK
  color2 = VVyz0j
  color3 = VVifMr
  totSel = 0
  menuW = 1000
  title = "Options"
  VVgktg= []
  if self.multiSelectState:
   menuW = 850
   totSel = self["myMenu"].VVqDOA()
   if totSel > 0:
    if iTar:
     txt1 = "Archive to .tar.gz"
     txt2 = " (Preserve Path Structure)"
     title = "Options  (%d item%s)" % (totSel, FFLFel(totSel))
     VVgktg.append((color1 + txt1     , "VVB2zI1" ))
     VVgktg.append((color1 + txt1 + txt2   , "VVB2zI2" ))
     VVgktg.append(VVm7kE)
    VVgktg.append(("[6] Copy"       , "copyBulk" ))
    VVgktg.append(("[7] Move"       , "moveBulk" ))
    VVgktg.append(("[8] %sDELETE" % VVf8NN , "VVa99j" ))
   else:
    FFpIgV(self, "Nothing selected", 700)
    return
  elif self.mode in (self.VVaEvY, self.VVkFv4):
   VVgktg.append(("Properties"           , "properties" ))
   VVgktg.append(VVm7kE)
   VVgktg.append((color3 + "Create New Directory (in current directory)" , "createNewDir"))
  else:
   menuW = 1000
   path  = self.VVPQtX(self.VVW0lj())
   isEditable = self["myMenu"].VVJKtv()
   VVgktg.append(("Properties", "properties"))
   if os.path.isdir(path):
    if isEditable:
     VVgktg.append(VVm7kE)
     VVgktg.append((color1 + "Archiving / Packaging", "VVwh72_dir"))
   elif os.path.isfile(path):
    selFile = self.VVW0lj()
    isArch = selFile.endswith((".tar", ".gz", ".tar.bz2", "tar.xz", ".zip", ".rar", ".7z"))
    if not isArch:
     VVgktg.append((color1 + "Archive ...", "VVwh72_file"))
    isText = False
    txt = ""
    if   isArch            : VVgktg.extend(self.VVa9R9(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith((".m3u", ".m3u8"))    : VVgktg.extend(self.VVWp8u(True))
    elif selFile.endswith(".sh"):
     VVgktg.extend(self.VVUPHM(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CCyssW.VVk88F(path):
     VVgktg.append(VVm7kE)
     VVgktg.append((color2 + "View"     , "textView_def"))
     VVgktg.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVgktg.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VVTCyR(path) == "pic":
     VVgktg.append(VVm7kE)
     VVgktg.append((color2 + "Set as PIcon for current channel" , "VVYUYv" ))
     if FFGqL5("ffmpeg") and selFile.lower().endswith((".jpg", ".png")):
      VVgktg.append(VVm7kE)
      VVgktg.append((color2 + "Convert to MVI (1280 x 720 )" , "VVHwYdHd"   ))
      VVgktg.append((color2 + "Convert to MVI (1920 x 1080)" , "VVHwYdFhd"   ))
    elif selFile.endswith(CCyssW.VVmb5b()):
     if selFile.endswith(".mvi"):
      if FFGqL5("showiframe"):
       VVgktg.append(VVm7kE)
       VVgktg.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVgktg.append(VVm7kE)
      VVgktg.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVgktg.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
      VVgktg.append((color2 + "Play with ..."       , "playWith"    ))
    if isText:
     VVgktg.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVgktg.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVgktg.append((color1 + "Convert Line-Breaks to Unix Format..." , "VVIkAL" ))
    if len(txt) > 0:
     VVgktg.append(VVm7kE)
     VVgktg.append((color1 + txt, "VVWDeJ"))
   VVgktg.append(VVm7kE)
   VVgktg.append(("[4] Create SymLink", "VVT8ux"))
   if isEditable:
    VVgktg.append(("[5] Rename"      , "VVI27u" ))
    VVgktg.append(("[6] Copy"       , "copyFileOrDir" ))
    VVgktg.append(("[7] Move"       , "moveFileOrDir" ))
    VVgktg.append(("[8] %sDELETE" % VVf8NN , "VV9xd6" ))
    if fileExists(path):
     VVgktg.append(VVm7kE)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVgktg.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVgktg.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVgktg.append((chmodTxt + "777)", "chmod777"))
   VVgktg.append(VVm7kE)
   VVgktg.append((color3 + "Create New File (in current directory)"  , "createNewFile" ))
   VVgktg.append((color3 + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCyssW.VVOVMO(self)
   if fPath:
    VVgktg.append(VVm7kE)
    VVgktg.append((color2 + "Go to Current Movie Dir", "VVge0R"))
  FFBqvZ(self, self.VV8cDK, width=menuW, height=1050, title=title, VVgktg=VVgktg, VVuxux=False, VVrcFy="#00101020", VVZZ3c="#00101A2A")
 def VV8cDK(self, item=None):
  if item is not None:
   path = self.VVPQtX(self.VVW0lj())
   selFile = self.VVW0lj()
   if   item == "VVB2zI1"    : self.VVB2zI(False)
   if   item == "VVB2zI2"    : self.VVB2zI(True)
   elif item == "copyBulk"     : self.VVepTh(False)
   elif item == "moveBulk"     : self.VVepTh(True)
   elif item == "VVa99j"    : self.VVa99j()
   elif item == "properties"    : self.VV0pXw()
   elif item == "VVwh72_dir" : self.VVwh72(path, True)
   elif item == "VVwh72_file" : self.VVwh72(path, False)
   elif item == "VVE85P"  : self.VVE85P(path)
   elif item == "VVI8u8"  : self.VVI8u8(path)
   elif item.startswith("extract_")  : self.VV2uOT(path, selFile, item)
   elif item.startswith("script_")   : self.VVxMIE(path, selFile, item)
   elif item.startswith("m3u_")   : self.VV9dAm(path, selFile, item)
   elif item.startswith("textView_def") : FFMf21(self, path)
   elif item.startswith("textView_enc") : self.VVvp7M(path)
   elif item.startswith("text_Edit")  : CC0TyL(self, path, VVJ8mq=self.VVwY5T)
   elif item.startswith("textSave_encUtf8"): self.VVest2(path, "Save as UTF-8"   , True)
   elif item.startswith("textSave_encOthr"): self.VVest2(path, "Save as Other Encoding", False)
   elif item.startswith("VVIkAL") : self.VVIkAL(path)
   elif item == "viewAsBootlogo"   : self.VVG18I(path, True)
   elif item == "addMovieToBouquet"  : self.VVgb7j(path, False)
   elif item == "addAllMoviesToBouquet" : self.VVgb7j(path, True)
   elif item == "playWith"     : self.VVZl02(path)
   elif item == "VVYUYv" : self.VVYUYv(path)
   elif item == "VVHwYdHd"   : FFkWFV(self, BF(self.VVHwYd, path, False))
   elif item == "VVHwYdFhd"   : FFkWFV(self, BF(self.VVHwYd, path, True))
   elif item == "VVT8ux"   : self.VVT8ux(path, selFile)
   elif item == "VVI27u"   : self.VVI27u(path, selFile)
   elif item == "copyFileOrDir"   : self.VVLehh(path, False)
   elif item == "moveFileOrDir"   : self.VVLehh(path, True)
   elif item == "VV9xd6"   : self.VV9xd6(path, selFile)
   elif item == "chmod644"     : self.VVXb8r(path, selFile, "644")
   elif item == "chmod755"     : self.VVXb8r(path, selFile, "755")
   elif item == "chmod777"     : self.VVXb8r(path, selFile, "777")
   elif item == "createNewFile"   : self.VVfTCc(path, True)
   elif item == "createNewDir"    : self.VVfTCc(path, False)
   elif item == "VVge0R"   : self.VVge0R()
   elif item == "VVWDeJ"    : self.VVWDeJ()
 def VVWDeJ(self):
  if self.mode == self.VVkFv4 and not self.patternMode == "poster":
   return
  selFile = self.VVW0lj()
  path  = self.VVPQtX(selFile)
  if os.path.isfile(path):
   cat = self["myMenu"].VVTCyR(path)
   if   cat == "pic"       : self.VVIHWP(path)
   elif cat == "txt"       : FFMf21(self, path)
   elif cat in ("tar", "rar", "zip", "p7z") : self.VVcvRQ(path, selFile)
   elif cat == "scr"       : self.VVM8aG(path, selFile)
   elif cat == "m3u"       : self.VVqZu5(path, selFile)
   elif cat in ("ipk", "deb")     : self.VVoS8D(path, selFile)
   elif cat in ("mov", "mus")     : self.VVG18I(path)
   elif not CCyssW.VVk88F(path) : FFMf21(self, path)
 def VVIHWP(self, path):
  curIndex = 0
  curFile = os.path.basename(path)
  lst = []
  for item in self["myMenu"].list:
   if not item[0][1]:
    category = self["myMenu"].VVTCyR(item[1][7])
    if category == "pic":
     if curFile == item[1][7]:
      curIndex = len(lst)
     lst.append(item[1][7])
  CCLIUZ.VV94CH(self, path, fileList=lst, curIndex=curIndex, cbFnc=self.VVK8N7)
 def VVK8N7(self, path):
  self.VV7POC(path)
 def VVG18I(self, path, asLogo=False):
  if asLogo : CCcVRq.VV7V4h(self, path)
  else  : FFkWFV(self, BF(self.VVkN1L, self, path), title="Playing Media ...")
 def VV2X5Q(self):
  if self["keyBlue"].getVisible():
   VV9gTz = self.VVhniW()
   if VV9gTz:
    path = self.VVPQtX(self.VVW0lj())
    enableGreenBtn = False if path in self.VVhniW() else True
    newList = []
    for line in VV9gTz:
     newList.append((line, line))
    VVqafJ  = ("Delete"    , self.VVL4rg    )
    VVG8PG  = ("Add Current Dir"   , BF(self.VVzyC3, path) ) if enableGreenBtn else None
    VVG0eT = ("Move Up"     , self.VVBpAx    )
    VV2qPD  = ("Move Down"   , self.VViBE0    )
    self.bookmarkMenu = FFBqvZ(self, self.VVukVL, width=1200, title="Bookmarks", VVgktg=newList, minRows=10 ,VVqafJ=VVqafJ, VVG8PG=VVG8PG, VVG0eT=VVG0eT, VV2qPD=VV2qPD, VVrcFy="#00000022", VVZZ3c="#00000022")
 def VVL4rg(self, VVVYOp=None, path=None):
  VV9gTz = self.VVhniW()
  if VV9gTz:
   while path in VV9gTz:
    VV9gTz.remove(path)
   self.VVNkIX(VV9gTz)
  if self.bookmarkMenu:
   self.bookmarkMenu.VVgQPR(VV9gTz)
   self.bookmarkMenu.VVCTwJ(("Add Current Dir", BF(self.VVzyC3, path)))
  else:
   FFpIgV(self, "Removed", 800)
  self.VVidVk()
 def VVzyC3(self, path, VVVYOp=None, item=None):
  VV9gTz = self.VVhniW()
  if len(VV9gTz) >= self.VVIqsA:
   FFG2mq(SELF, "Max bookmarks reached (max=%d)." % self.VVIqsA)
  elif not path in VV9gTz:
   if not os.path.isdir(path):
    path = FFMiJ8(path, True)
   newList = [path] + VV9gTz
   self.VVNkIX(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VVgQPR(newList)
    self.bookmarkMenu.VVCTwJ()
   else:
    FFpIgV(self, "Added", 800)
  self.VVidVk()
 def VVBpAx(self, selectionObj, path):
  if self.bookmarkMenu:
   VV9gTz = self.bookmarkMenu.VVIuty(True)
   if VV9gTz:
    self.VVNkIX(VV9gTz)
 def VViBE0(self, selectionObj, path):
  if self.bookmarkMenu:
   VV9gTz = self.bookmarkMenu.VVIuty(False)
   if VV9gTz:
    self.VVNkIX(VV9gTz)
 def VVukVL(self, folder=None):
  if folder:
   folder = FFGa2t(folder)
   self["myMenu"].VVFX3C(folder)
   self["myMenu"].moveToIndex(0)
  self.VVhGGF()
 def VVhniW(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VVYSQ4(self):
  return True if VVhniW() else False
 def VVNkIX(self, VV9gTz):
  line = ",".join(VV9gTz)
  FFeLB8(CFG.browserBookmarks, line)
 def VV7POC(self, path):
  if fileExists(path):
   fDir  = FFGa2t(os.path.dirname(path))
   if fDir:
    self["myMenu"].VVFX3C(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFpIgV(self, "Not found", 1000)
 def VVge0R(self, chDir=True):
  fPath, fDir, fName = CCyssW.VVOVMO(self)
  self.VV7POC(fPath)
 def VVtcqD(self):
  path = self.VVPQtX(self.VVW0lj())
  isAdd = False if path in self.VVhniW() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  c1, c2 , c3 = VV4aa0, VVo8aK, VVyz0j
  VVgktg = []
  VVgktg.append(("Find Files ..." , "find"))
  VVgktg.append(("Sort ..."   , "sort"))
  VVgktg.append(VVm7kE)
  if isAdd: VVgktg.append((c1 + "Add %s Dir to Bookmarks"  % dirTxt, "addBM"))
  else : VVgktg.append((c1 + "Remove %s Dir from Bookmarks" % dirTxt, "remBM"))
  VVgktg.append(VVm7kE)
  VVgktg.append(    (c2 + 'Set %s Dir as "Startup Dir"' % dirTxt, "start"))
  if self.mode == self.VVlToO:
   VVgktg.append(VVm7kE)
   if self.multiSelectState: VVgktg.append( (c3 + "Disable Multi-Select ", "multiOff"))
   else     : VVgktg.append( (c3 + "Enable Multi-Select"  , "multiOn" ))
   VVgktg.append(       (c3 + "Select all"    , "selAll"  ))
  FFBqvZ(self, BF(self.VVq9a7, path), width=750, title="More Options", VVgktg=VVgktg, VVrcFy="#00221111", VVZZ3c="#00221111")
 def VVq9a7(self, path, item):
  if item:
   if   item == "find"  : self.VVLwVq(path)
   elif item == "sort"  : self.VVlHSd()
   elif item == "addBM" : self.VVzyC3(path)
   elif item == "remBM" : self.VVL4rg(None, path)
   elif item == "start" : self.VVfMTr(path)
   elif item == "multiOn" : self.VV9DAi(True)
   elif item == "multiOff" : self.VV9DAi(False)
   elif item == "selAll" : self.VV9DAi(True, True)
 def VV9DAi(self, isOn, isAll=False):
  self.multiSelectState = isOn
  if isAll or not isOn:
   FFkWFV(self, BF(self["myMenu"].VVprL8, isOn), title="Selecting ..." if isOn else "Unselecting ...")
  self.VVufOL(self.VV1sKW if isOn else self.VVJ1bQ)
 def VVufOL(self, mode=0):
  if   mode == self.VV5KfG : titBg, bodBg = self.pickTitleBG, self.pickBodyBG
  elif mode == self.VV1sKW: titBg, bodBg = "#01883366", "#11002233"
  else        : titBg, bodBg = self.VVrcFy, self.VVZZ3c
  FFeNfF(self["myTitle"], titBg)
  FFeNfF(self["myBar"], titBg)
  FFeNfF(self["myBody"], bodBg)
  FFeNfF(self["myMenu"], bodBg)
  if self.multiSelectState: bg, txt = "#01883366", self.VVehCH()
  else     : bg, txt = VVX0Ji[3], "Bookmarks"
  FFuetT(self["keyBlue"], txt)
  FFeNfF(self["keyBlue"], bg)
  self.VVidVk()
 def VVehCH(self):
  return "Selected Items = %d" % self["myMenu"].VVqDOA()
 def VVidVk(self):
  if self.VVhniW() or self.multiSelectState: self["keyBlue"].show()
  else            : self["keyBlue"].hide()
 def VVLwVq(self, path):
  VVgktg = []
  VVgktg.append(("Find in Current Directory"    , "findCur"  ))
  VVgktg.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVgktg.append(("Find in all Storage Systems"    , "findAll"  ))
  FFBqvZ(self, BF(self.VVIfeh, path), width=700, title="Find File/Pattern", VVgktg=VVgktg, VVomDt=True, VVRHyh=True, VVrcFy="#00221111", VVZZ3c="#00221111")
 def VVIfeh(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VVDi70(0, path, title)
   elif item == "findCurR" : self.VVDi70(1, path, title)
   elif item == "findAll" : self.VVDi70(2, path, title)
 def VVDi70(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FF8ISk(self, BF(self.VVJPp5, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VVJPp5(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FFeLB8(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FFpIgV(self, "No entery", 1500)
   elif badLst  : FFpIgV(self, "Too many file !", 1500)
   else   : FFkWFV(self, BF(self.VVaFjC, mode, path, title, filePatt), title="Searching ...")
 def VVaFjC(self, mode, path, title, filePatt):
  lst = FFa467(FFxbhS("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   err = CCyssW.VVqYVb(lst)
   if err:
    FFG2mq(self, err)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VVq5Be = (""     , self.VVY4xt , [])
    VVkY0R = ("Go to File Location", self.VVKoqs  , [])
    FF69ky(self, None, title="%s : %s" % (title, filePatt), header=header, VV9gTz=lst, VVYiuZ=widths, VVvi36=26, VVq5Be=VVq5Be, VVkY0R=VVkY0R)
  else:
   FFrKlA(self, "Not found !", 2000)
 def VVKoqs(self, VVkINB, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVkINB.cancel()
   self.VV7POC(path)
  else:
   FFpIgV(VVkINB, "Path not found !", 1000)
 def VVY4xt(self, VVkINB, title, txt, colList):
  txt = "%s\n%s\n\n" % (FF1YQ7("File:"  , VVyz0j), colList[0])
  txt += "%s\n%s"  % (FF1YQ7("Directory:", VVyz0j), FFGa2t(colList[1]))
  FF8ShK(VVkINB, txt, title=title)
 def VVlHSd(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VV1WSM()
  VVgktg = []
  VVgktg.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVgktg.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVgktg.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVgktg.append(("Type\t%s" % typeTxt, "typeAlp"))
  VV2qPD = ("Mix", BF(self.VVCoBi, True))
  FFBqvZ(self, BF(self.VVrMO2, False), barText=txt, width=650, title="Sort Options", VVgktg=VVgktg, VV2qPD=VV2qPD, VVRHyh=True, VVrcFy="#00221111", VVZZ3c="#00221111")
 def VVCoBi(self, isMix, VVVYOp, item):
  self.VVrMO2(True, item)
 def VVrMO2(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VV1WSM()
   title = "Sorting ... "
   if   item == "nameAlp": FFkWFV(self, BF(self["myMenu"].VVs3rt, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FFkWFV(self, BF(self["myMenu"].VVs3rt, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FFkWFV(self, BF(self["myMenu"].VVs3rt, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FFkWFV(self, BF(self["myMenu"].VVs3rt, typeMode , isMix, False), title=title)
 def VVfMTr(self, path):
  if not os.path.isdir(path):
   path = FFMiJ8(path, True)
  FFeLB8(CFG.browserStartPath, path)
  FFpIgV(self, "Done", 500)
 def VVmQ8L(self, selFile, VVDdTB, command):
  FFDiGG(self, BF(FF20zH, self, command, consFont=True, VVAJlf=self.VVG86q), "%s\n\n%s" % (VVDdTB, selFile))
 def VVa9R9(self, path, calledFromMenu):
  destPath = self.VV9Wsk(path)
  lastPart = FFBBEq(destPath)
  color = VVyz0j if calledFromMenu else ""
  VVgktg = []
  if path.endswith(".gz") and not path.endswith(".tar.gz"):
   VVgktg.append((color + "Extract Content"           , "extract_gz" ))
  else:
   if calledFromMenu: VVgktg.append(VVm7kE)
   VVgktg.append((color + "List Archived Files"          , "extract_listFiles" ))
   VVgktg.append(VVm7kE)
   VVgktg.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
   VVgktg.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
   VVgktg.append((color + "Extract Here"            , "extract_here"  ))
   if iTar and iZip:
    if path.endswith(".zip"):
     if not calledFromMenu: VVgktg.append(VVm7kE)
     VVgktg.append((color + "Convert .zip to .tar.gz"       , "VVE85P" ))
    elif path.endswith(".tar.gz"):
     if not calledFromMenu: VVgktg.append(VVm7kE)
     VVgktg.append((color + "Convert .tar.gz to .zip"       , "VVI8u8" ))
  return VVgktg
 def VVcvRQ(self, path, selFile):
  FFBqvZ(self, BF(self.VV2uOT, path, selFile), title="Compressed File Options", VVgktg=self.VVa9R9(path, False))
 def VV2uOT(self, path, selFile, item=None):
  if item is not None:
   parent  = FFMiJ8(path, False)
   destPath = self.VV9Wsk(path)
   lastPart = FFBBEq(destPath)
   cmd   = ""
   ques  = "Extract file ?\n\n%s" % selFile
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % SEP
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FF3zFj("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo ''; unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FF3zFj("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo ''; unrar l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".7z"):
     cmd += FF3zFj("7za", "p7zip", "P7Zip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo ''; 7za l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n\n';" % path
     cmd += "totFiles=$(tar -tf '%s' | wc -l);" % path
     cmd += "if (( $totFiles > 300 )); then moreInf='  ... Will list the first 300 only ...'; else moreInf=''; fi;"
     cmd += "echo -e '\n%s\n--- Contents (Total='$totFiles')'$moreInf'\n%s';" % (SEP, SEP)
     cmd += "tar -tf '%s' | head -n300;" % path
     cmd += "if (( $totFiles > 300 )); then echo '\n... Only the first 300 are listed ...'; fi;"
    cmd += "echo '';"
    cmd += linux_sep
    FFTKzr(self, cmd, consFont=True)
   elif path.endswith(".rar"):
    self.VV6wRH(item, path, parent, destPath, ques)
   elif path.endswith(".7z"):
    self.VVDRTN(item, path, parent, destPath, ques)
   elif path.endswith(".zip"):
    if item == "VVE85P" : self.VVE85P(path)
    else       : self.VVKl40(item, path, parent, destPath, ques)
   elif item == "VVI8u8" and path.endswith(".tar.gz"):
    self.VVI8u8(path)
   elif item == "extract_gz":
    title = 'Extract ".gz" file'
    res = FFdHIn("RES=$(gzip -dk '%s') && echo ok || echo $RES" % path)
    if res == "ok":
     FF27fq(self, "Result:\n\n%s" % path[:-3], title=title)
     self.VVG86q()
    else:
     FFG2mq(self, "Error:\n\n%s" % res, title=title)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFhkCt("mkdir '%s'"   % lastPart)
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVmQ8L(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVmQ8L(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FFMiJ8(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVmQ8L(selFile, "Extract Here ?"      , cmd)
 def VV9Wsk(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  elif path.endswith(".7z")  : extLen = 3
  elif path.endswith(".gz")  : extLen = 3
  else       : extLen = 0
  return path[:-extLen]
 def VVKl40(self, item, path, parent, destPath, VVDdTB):
  FFDiGG(self, BF(self.VVGS8h, item, path, parent, destPath), VVDdTB)
 def VVGS8h(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FF3zFj("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFog5k(destPath, VVNQoM))
  cmd +=   sep
  cmd += "fi;"
  FF0I5A(self, cmd, VVAJlf=self.VVG86q, consFont=True)
 def VV6wRH(self, item, path, parent, destPath, VVDdTB):
  FFDiGG(self, BF(self.VVqJFx, item, path, parent, destPath), VVDdTB)
 def VVqJFx(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFGa2t(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FF3zFj("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFog5k(destPath, VVNQoM))
  cmd +=   sep
  cmd += "fi;"
  FF0I5A(self, cmd, VVAJlf=self.VVG86q, consFont=True)
 def VVDRTN(self, item, path, parent, destPath, VVDdTB):
  FFDiGG(self, BF(self.VVXQPf, item, path, parent, destPath), VVDdTB)
 def VVXQPf(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = destPath
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += "7za x '%s' -o'%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FF3zFj("7za", "p7zip", "P7Zip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFog5k(destPath, VVNQoM))
  cmd +=   sep
  cmd += "fi;"
  FF0I5A(self, cmd, VVAJlf=self.VVG86q, consFont=True)
 def VVUPHM(self, addSep=False):
  VVgktg = []
  if addSep:
   VVgktg.append(VVm7kE)
  VVgktg.append((VVyz0j + "View Script File"  , "script_View"  ))
  VVgktg.append((VVyz0j + "Execute Script File" , "script_Execute" ))
  VVgktg.append((VVyz0j + "Edit"     , "script_Edit"  ))
  return VVgktg
 def VVM8aG(self, path, selFile):
  FFBqvZ(self, BF(self.VVxMIE, path, selFile), title="Script File Options", VVgktg=self.VVUPHM())
 def VVxMIE(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFMf21(self, path)
   elif item == "script_Execute" : self.VVmQ8L(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CC0TyL(self, path, VVJ8mq=self.VVwY5T)
 def VVWp8u(self, addSep=False):
  VVgktg = []
  if addSep:
   VVgktg.append(VVm7kE)
  VVgktg.append((VVyz0j + "Browse IPTV Channels" , "m3u_Browse" ))
  VVgktg.append((VVyz0j + "Edit"     , "m3u_Edit" ))
  VVgktg.append((VVyz0j + "View"     , "m3u_View" ))
  return VVgktg
 def VVqZu5(self, path, selFile):
  FFBqvZ(self, BF(self.VV9dAm, path, selFile), title="M3U/M3U8 File Options", VVgktg=self.VVWp8u())
 def VV9dAm(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFkWFV(self, BF(self.session.open, CCul6W, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CC0TyL(self, path, VVJ8mq=self.VVwY5T)
   elif item == "m3u_View"  : FFMf21(self, path)
 def VVvp7M(self, path):
  if fileExists(path) : FFkWFV(self, BF(CCmJil.VVnQil, self, path, BF(self.VVa3SC, path)), title="Loading Codecs ...")
  else    : FFcMQr(self, path)
 def VVa3SC(self, path, item=None):
  if item:
   FFMf21(self, path, encLst=item)
 def VVest2(self, path, title, asUtf8):
  if fileExists(path) : FFkWFV(self, BF(CCmJil.VVnQil, self, path, BF(self.VVdH6k, path, title, asUtf8), title="Original Encoding"), title="Loading Codecs ...")
  else    : FFcMQr(self, path)
 def VVdH6k(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8: self.VVIdKq(path, title, fromEnc, "UTF-8")
   else  : CCmJil.VVgJeJ(self, BF(self.VVIdKq, path, title, fromEnc), title="Convert to Encoding")
 def VVIdKq(self, path, title, fromEnc, item):
  if item:
   txt, toEnc, ndx = item
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FF1YQ7("Successful\n\n", VVNQoM)
      txt += FF1YQ7("From Encoding (%s):\n" % fromEnc, VVChVP)
      txt += "%s\n\n" % path
      txt += FF1YQ7("To Encoding (%s):\n" % toEnc, VVChVP)
      txt += "%s\n\n" % outFile
      FF8ShK(self, txt, title=title)
    except:
     FFG2mq(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FFpIgV(self, "Cannot open file", 2000)
   self.VVG86q()
 def VVIkAL(self, path):
  title = "File Line-Break Conversion"
  FFDiGG(self, BF(self.VVqh8y, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVqh8y(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FF1YQ7("File converted:", VVNQoM), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FF27fq(self, txt, title=title)
  else:
   FFcMQr(self, path, title=title)
 def VVXb8r(self, path, selFile, newChmod):
  FFDiGG(self, BF(self.VVxfgj, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVxfgj(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVLVyg)
  result = FFdHIn(cmd)
  if result == "Successful" : FF27fq(self, result)
  else      : FFG2mq(self, result)
 def VVT8ux(self, path, selFile):
  parent = FFMiJ8(path, False)
  self.session.openWithCallback(self.VVsjpZ, BF(CCyssW, mode=CCyssW.VVaEvY, VV9Esa=parent, VVxuyD="Create Symlink here"))
 def VVsjpZ(self, newPath):
  if len(newPath) > 0:
   target = self.VVPQtX(self.VVW0lj())
   target = FFTgmt(target)
   linkName = FFBBEq(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFGa2t(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFG2mq(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFDiGG(self, BF(self.VVSbFj, target, link), "Create Soft Link ?\n\n%s" % txt, VVm2Fj=True)
 def VVSbFj(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVLVyg)
  result = FFdHIn(cmd)
  if result == "Successful" : FF27fq(self, result)
  else      : FFG2mq(self, result)
 def VVI27u(self, path, selFile):
  lastPart = FFBBEq(path)
  FF8ISk(self, BF(self.VVwAbM, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVwAbM(self, path, selFile, VVDhxg):
  if VVDhxg:
   parent = FFMiJ8(path, True)
   if os.path.isdir(path):
    path = FFTgmt(path)
   newName = parent + VVDhxg
   cmd = "mv '%s' '%s' %s" % (path, newName, VVLVyg)
   if VVDhxg:
    if selFile != VVDhxg:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFDiGG(self, BF(self.VVEJP7, cmd), message, title="Rename file?")
    else:
     FFG2mq(self, "Cannot use same name!", title="Rename")
 def VVEJP7(self, cmd):
  result = FFdHIn(cmd)
  if "Fail" in result:
   FFG2mq(self, result)
  self.VVG86q()
 def VVB2zI(self, preserve):
  title="Archive to .tar.gz"
  self.session.open(CCKX0k, barTheme=CCKX0k.VVzy8h, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVbJSk, title, preserve)
      , VVJ8mq = BF(self.VVEBOO, title))
 def VVbJSk(self, title, preserve, VVzRAM):
  totSel = self["myMenu"].VVqDOA()
  totOk = totFail = 0
  VVzRAM.VVGeXq(totSel)
  VVzRAM.VVgo83 = ["", totSel, totOk, totFail, ""]
  VVzRAM.VVyYoz("Prepareing targz file")
  curDir = self["myMenu"].VVs67s()
  lastPart = FFBBEq(curDir) or "archive"
  outF = os.path.join(curDir, lastPart + ".tar.gz")
  c = 0
  while fileExists(outF):
   c += 1
   outF = os.path.join(curDir, lastPart + "_%d.tar.gz" % c)
  totOk = totFail = 0
  path = ""
  try:
   with iTar.open(outF, mode="w:gz") as tarF:
    for row in self["myMenu"].list:
     if not VVzRAM or VVzRAM.isCancelled:
      return
     if row[2][6]:
      VVzRAM.VVu4eE(1)
      name  = FFTgmt(row[0][0])
      lastPath = FFBBEq(name)
      path  = os.path.join(curDir, name)
      tarF.add(path, arcname=None if preserve else lastPath)
      totOk += 1
      if VVzRAM:
       VVzRAM.VVgo83 = [outF, totSel, totOk, totFail, path]
       VVzRAM.VVsrWH(totOk, lastPath)
  except:
   totFail += 1
   if VVzRAM:
    VVzRAM.VVgo83 = [outF, totSel, totOk, totFail, path]
 def VVEBOO(self, title, VV4mF1, VVgo83, threadCounter, threadTotal, threadErr):
  outF, totSel, totOk, totFail, path = VVgo83
  txt  = "%s:\n%s\n\n"   % (FF1YQ7("Output File", VVNQoM), outF)
  txt += "Total\t: %d\n"  % totSel
  txt += "Archived\t: %d\n" % totOk
  if totFail   : txt += FF1YQ7("Failed\t: %d\n" % totFail, VVf8NN)
  if not VV4mF1: txt += "%s\n%s" % (FF1YQ7("\nCancelled while copying:", VVf8NN), path)
  FF8ShK(self, txt, title=title)
  self.VVG86q()
 def VVepTh(self, isMove):
  self.session.openWithCallback(BF(self.VVPUQN, isMove), BF(CCyssW, mode=CCyssW.VVaEvY, VV9Esa=self["myMenu"].VVs67s(), VVxuyD="Move to here" if isMove else "Paste here"))
 def VVPUQN(self, isMove, newPath):
  if newPath:
   if isMove : title, action = "Move Items", "Moved"
   else  : title, action = "Copy Items", "Copied"
   self.session.open(CCKX0k, barTheme=CCKX0k.VVzy8h, titleBg="#22003344", bodyBg="#22001122"
       , titlePrefix = title
       , fncToRun  = BF(self.VVn98c, title, action, isMove, newPath)
       , VVJ8mq = BF(self.VVg4zQ, title, action, isMove, newPath))
 def VVn98c(self, title, action, isMove, newPath, VVzRAM):
  curDir = self["myMenu"].VVs67s()
  totOk = totFail = 0
  totSel = self["myMenu"].VVqDOA()
  if isMove: cmd = "mv -f"
  else  : cmd = "cp -frp"
  VVzRAM.VVGeXq(totSel)
  VVzRAM.VVgo83 = [totSel, totOk, totFail, ""]
  for row in self["myMenu"].list:
   if not VVzRAM or VVzRAM.isCancelled:
    return
   if row[2][6]:
    VVzRAM.VVu4eE(1)
    VVzRAM.VVLKr2(action, totOk, FFBBEq(row[0][0]))
    path = os.path.join(curDir, row[0][0])
    lastPart = FFBBEq(path)
    if os.path.isdir(path): path = FFTgmt(path)
    dest = os.path.join(newPath, lastPart)
    if FFLgW2("%s '%s' '%s'" % (cmd, path, dest)) : totOk += 1
    else            : totFail += 1
    if VVzRAM:
     VVzRAM.VVgo83 = [totSel, totOk, totFail, path]
     VVzRAM.VVLKr2(action, totOk, FFBBEq(row[0][0]))
 def VVg4zQ(self, title, action, isMove, newPath, VV4mF1, VVgo83, threadCounter, threadTotal, threadErr):
  totSel, totOk, totFail, path = VVgo83
  txt  = "Total\t: %d\n" % totSel
  txt += "%s\t: %d\n"  % (action, totOk)
  if totFail   : txt += FF1YQ7("Failed\t: %d\n" % totFail, VVf8NN)
  if not VV4mF1: txt += "%s\n%s" % (FF1YQ7("\nCancelled while copying:", VVf8NN), path)
  FF8ShK(self, txt, title=title)
  self.VVG86q()
 def VVa99j(self):
  tot = self["myMenu"].VVqDOA()
  FFDiGG(self, BF(FFkWFV, self, self.VV3T9t, title="Deleting ...", clearMsg=False), "Delete %d item%s ?" % (tot, FFLFel(tot)), title="Delete Selection")
 def VV3T9t(self):
  path = self["myMenu"].VVs67s()
  for row in self["myMenu"].list:
   if row[2][6]:
    FFEnJ0(os.path.join(path, row[0][0]))
  FFpIgV(self)
  self.VVG86q()
 def VVLehh(self, path, isMove):
  self.session.openWithCallback(BF(self.VVmVin, isMove, path), BF(CCyssW, mode=CCyssW.VVaEvY, VV9Esa=FFMiJ8(path, False), VVxuyD="Move to here" if isMove else "Paste here"))
 def VVmVin(self, isMove, src, dst):
  if not dst:
   return
  action = "Move" if isMove else "Copy"
  src = FFTgmt(src)
  if os.path.isfile(src) or os.path.islink(src): isFile, srcSubj = True , "File"
  else           : isFile, srcSubj = False, "Directory"
  title = "%s %s" % (action, srcSubj)
  src = FFTgmt(src)
  dst = os.path.join(dst, FFBBEq(src))
  if src == dst:
   FFG2mq(self, "From:\n%s\n\n To:\n%s" % (src, dst), title=("Cannot %s %s to itself" % (action, srcSubj)).capitalize())
   return
  prams = title, isFile, isMove, srcSubj, src, dst
  if fileExists(dst) or pathExists(dst): FFDiGG(self, BF(self.VVphht, prams), "Overwrite Destination %s ?\n\n%s" % (srcSubj, dst), title=title)
  elif not isFile       : FFDiGG(self, BF(self.VVphht, prams), "Overwrite Destination Files", title=title)
  else         : self.VVphht(prams)
 def VVphht(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isMove and CCyssW.VVY84w(src) == CCyssW.VVY84w(dst):
   FFkWFV(self, BF(self.VVL6Ft, prams), title="Moving %s ..." % srcSubj)
  else:
   FFkWFV(self, BF(self.VVUo14, prams), title="Calculating Size ...")
 def VVL6Ft(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  res = FFdHIn("RES=$(mv -f '%s' '%s') && echo ok || echo $RES" % (src, dst))
  if res == "ok":
   self.VVG86q()
  else:
   FFG2mq(self, "Error : %s\n\n%s" % (res, src), title=title)
 def VVUo14(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isFile: size = FF1fFq(src)
  else  : size = FFN3lb(src)
  if size > -1:
   self.session.open(CCKX0k, barTheme=CCKX0k.VVzy8h, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Moving %s ..." % srcSubj if isMove else "Copying %s ..." % srcSubj
       , fncToRun  = BF(self.VVrHNY, prams, size)
       , VVJ8mq = BF(self.VVaQvQ, prams))
  else:
   FFG2mq(self, "Cannot get size for:\n\n%s" % src, title=title)
 def VVrHNY(self, prams, size, VVzRAM):
  title, isFile, isMove, srcSubj, src, dst = prams
  VVzRAM.VVGeXq(size)
  VVzRAM.VVgo83 = ("", "", False)
  def VVGlot(srcFile, dstFile):
   if os.path.islink(srcFile):
    if fileExists(dstFile):
     FFMc8G(dstFile)
    os.symlink(os.readlink(srcFile), dstFile)
   elif os.path.isfile(srcFile):
    with open(srcFile, "rb") as srcF:
     with open(dstFile, "wb") as dstF:
      while True:
       if not VVzRAM or VVzRAM.isCancelled:
        VVzRAM.VVgo83 = (srcFile, "", True)
        FFMc8G(dstFile)
        return False
       try:
        data = srcF.read(1024)
        if not data:
         break
        dstF.write(data)
        VVzRAM.VVu4eE(len(data))
       except Exception as e:
        VVzRAM.VVgo83 = (srcFile, str(e), False)
        FFMc8G(dstFile)
        return False
   if iCopymode: iCopymode(srcFile, dstFile)
   if isMove: FFMc8G(srcFile)
   return True
  if isFile:
   tot = 1
   VVGlot(src, dst)
  else:
   VVzRAM.VVyYoz("Calculating Dirs/Files ...")
   totDir, totFile, totLink = FFaAKb(src)
   if not VVzRAM or VVzRAM.isCancelled:
    VVzRAM.VVgo83 = ("", "", True)
    return
   tot = totFile + totLink
   fCount = 0
   for Dir, dirs, files in os.walk(src):
    files = os.listdir(Dir)
    dstDir = os.path.join(dst, Dir[len(src):].lstrip("/"))
    if not pathExists(dstDir):
     try:
      os.makedirs(dstDir)
     except Exception as e:
      VVzRAM.VVgo83 = (os.path.join(Dir, f), str(e), False)
    for f in files:
     srcFile = os.path.join(Dir, f)
     dstFile = os.path.join(dst, srcFile[len(src):].lstrip("/"))
     if os.path.islink(srcFile) or os.path.isfile(srcFile):
      fCount += 1
      VVzRAM.VVyYoz("File: %d/%d >> %s" % (fCount, tot, f))
      if not VVGlot(srcFile, dstFile):
       return
    if isMove and not os.listdir(Dir):
     FFLgW2("rm -fr '%s'" % Dir)
   if isMove:
    FFLgW2("rm -fr '%s'" % src)
 def VVaQvQ(self, prams, VV4mF1, VVgo83, threadCounter, threadTotal, threadErr):
  title, isFile, isMove, srcSubj, src, dst = prams
  lastFile, err, isCancelled = VVgo83
  if err:
   FFG2mq(self, "%s\n\n%s" % (err, lastFile), title=title + " ... Error")
  elif isCancelled:
   if isFile: FFpIgV(self, "Canelled", 1000)
   else  : FFG2mq(self, "Cancelled at file:\n\n%s" % lastFile if lastFile else "Process Stopped.", title=title + " ... Cancelled")
  else:
   FFpIgV(self, "Done", 1500, isGrn=True)
  if VV4mF1 and isMove:
   self.VVG86q()
 def VV9xd6(self, path, fileName):
  path = FFTgmt(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFDiGG(self, BF(FFkWFV, self, BF(self.VVCwWI, path), title="Deleting ...", clearMsg=False), "%s\n\nDelete %s ?" % (path, pathType), title="Delete %s" % pathType)
 def VVCwWI(self, path):
  FFEnJ0(path)
  FFpIgV(self)
  self.VVG86q()
 def VVfTCc(self, path, isFile):
  dirName = FFGa2t(os.path.dirname(path))
  if isFile : objName, VVDhxg = "File"  , self.edited_newFile
  else  : objName, VVDhxg = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FF8ISk(self, BF(self.VVr883, dirName, isFile, title), title=title, defaultText=VVDhxg, message="Enter %s Name:" % objName)
 def VVr883(self, dirName, isFile, title, VVDhxg):
  if VVDhxg:
   if isFile : self.edited_newFile = VVDhxg
   else  : self.edited_newDir  = VVDhxg
   path = dirName + VVDhxg
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVLVyg)
    else  : cmd = "mkdir '%s' %s" % (path, VVLVyg)
    result = FFdHIn(cmd)
    if "Fail" in result:
     FFG2mq(self, result)
    self.VVG86q()
   else:
    FFG2mq(self, "Name already exists !\n\n%s" % path, title)
 def VVoS8D(self, path, selFile):
  c1, c2, c3 = VVo8aK, VVyz0j, VVeksK
  VVgktg = []
  VVgktg.append((c1 + "List Package Files"         , "VVhmsd"     ))
  VVgktg.append((c1 + "Package Information"         , "VVTlR8"     ))
  VVgktg.append(VVm7kE)
  VVgktg.append((c2 + "Install Package"          , "VVDLZo_CheckVersion" ))
  VVgktg.append((c2 + "Install Package (force reinstall)"     , "VVDLZo_ForceReinstall" ))
  VVgktg.append((c2 + "Install Package (force overwrite)"     , "VVDLZo_ForceOverwrite" ))
  VVgktg.append((c2 + "Install Package (force downgrade)"     , "VVDLZo_ForceDowngrade" ))
  VVgktg.append((c2 + "Install Package (ignore failed dependencies)"  , "VVDLZo_IgnoreDepends" ))
  VVgktg.append(VVm7kE)
  VVgktg.append((c3 + "Remove Related Package"        , "VVuykg_ExistingPackage" ))
  VVgktg.append((c3 + "Remove Related Package (force remove)"    , "VVuykg_ForceRemove"  ))
  VVgktg.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VVuykg_IgnoreDepends" ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Extract Files"           , "VVNEN2"     ))
  VVgktg.append(("Unbuild Package"           , "VVCmhK"     ))
  FFBqvZ(self, BF(self.VVAfA2, path, selFile), VVgktg=VVgktg)
 def VVAfA2(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVhmsd"      : self.VVhmsd(path, selFile)
   elif item == "VVTlR8"      : self.VVTlR8(path)
   elif item == "VVDLZo_CheckVersion"  : self.VVDLZo(path, selFile, VVEdih     )
   elif item == "VVDLZo_ForceReinstall" : self.VVDLZo(path, selFile, VVg1cm )
   elif item == "VVDLZo_ForceOverwrite" : self.VVDLZo(path, selFile, VVEgPl )
   elif item == "VVDLZo_ForceDowngrade" : self.VVDLZo(path, selFile, VVz2tU )
   elif item == "VVDLZo_IgnoreDepends" : self.VVDLZo(path, selFile, VVHnoT )
   elif item == "VVuykg_ExistingPackage" : self.VVuykg(path, selFile, VVvpx9     )
   elif item == "VVuykg_ForceRemove"  : self.VVuykg(path, selFile, VVv695  )
   elif item == "VVuykg_IgnoreDepends"  : self.VVuykg(path, selFile, VVlF8r )
   elif item == "VVNEN2"     : self.VVNEN2(path, selFile)
   elif item == "VVCmhK"     : self.VVCmhK(path, selFile)
 def VVhmsd(self, path, selFile):
  if FFGqL5("ar") : cmd = "allOK='1';"
  else    : cmd  = FFNkgD()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (SEP, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (SEP, SEP)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFfu76(self, cmd, VVAJlf=self.VVG86q)
 def VVNEN2(self, path, selFile):
  lastPart = FFBBEq(path)
  dest  = FFMiJ8(path, True) + selFile[:-4]
  cmd  =  FFNkgD()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFhkCt("mkdir '%s'" % dest)
  cmd +=    FFhkCt("cd '%s'" % dest)
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFog5k(dest, VVNQoM))
  cmd += "fi;"
  FF20zH(self, cmd, VVAJlf=self.VVG86q)
 def VVCmhK(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVAWjc = os.path.splitext(path)[0]
  else        : VVAWjc = path + "_"
  if path.endswith(".deb")   : VVcZHS = "DEBIAN"
  else        : VVcZHS = "CONTROL"
  cmd  = FFNkgD()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -rf '%s' > /dev/null 2>&1;" % VVAWjc
  cmd += "  mkdir '%s';"      % VVAWjc
  cmd += "  CONTPATH='%s/%s';"    % (VVAWjc, VVcZHS)
  cmd += '  mkdir "$CONTPATH";'
  cmd += "  cd '%s';"       % VVAWjc
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"      % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVAWjc, VVAWjc)
  cmd += "  FILE='%s/control.tar.gz'; [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVAWjc
  cmd += "  FILE='%s/data.tar.xz';    [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVAWjc, VVAWjc)
  cmd += "  FILE='%s/control.tar.xz'; [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVAWjc
  cmd += "  FILE='%s/debian-binary';  [ -f \"$FILE\" ]                                        && rm -f \"$FILE\";" %  VVAWjc
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e '\nOutput Directory:\n%s' %s;" % (VVAWjc, FFog5k(VVAWjc, VVNQoM))
  cmd += "fi;"
  FF20zH(self, cmd, VVAJlf=self.VVG86q)
 def VVTlR8(self, path):
  listCmd  = FFnyVC(VVnFKX, "")
  infoCmd  = FFjDaF(VVDKlz , "")
  filesCmd = FFjDaF(VVqQqK, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFMGJW(VVChVP)
   notInst = "Package not installed."
   cmd  = FF9KyJ("File Info", VVChVP)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FF9KyJ("System Info", VVChVP)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFog5k(notInst, VVf8NN))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FF9KyJ("Related Files", VVChVP)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFTKzr(self, cmd)
  else:
   FFEPUu(self)
 def VVDLZo(self, path, selFile, cmdOpt):
  cmd = FFjDaF(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFDiGG(self, BF(FF20zH, self, cmd, VVAJlf=FFxmPl), "Install Package ?\n\n%s" % selFile)
  else:
   FFEPUu(self)
 def VVuykg(self, path, selFile, cmdOpt):
  listCmd  = FFnyVC(VVnFKX, "")
  infoCmd  = FFjDaF(VVDKlz, "")
  instRemCmd = FFjDaF(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFog5k(errTxt, VVf8NN))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFog5k(cannotTxt, VVf8NN))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFog5k(tryTxt, VVf8NN))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFDiGG(self, BF(FF20zH, self, cmd, VVAJlf=FFxmPl), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFEPUu(self)
 def VV98Lp(self, path):
  hostName = FFdHIn("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVwh72(self, path, isDir):
  txt1 = "Archive to "
  txt2 = "Archive (Preserve Path Structure) to "
  VVgktg = []
  VVgktg.append(("%s.tar"  % txt1 , "archDir_tar"  ))
  VVgktg.append(("%s.tar.gz" % txt1 , "archDir_tar_gz" ))
  VVgktg.append(("%s.tar.xz" % txt1 , "archDir_tar_xz" ))
  VVgktg.append(("%s.tar.bz2" % txt1 , "archDir_tar_bz2" ))
  VVgktg.append(("%s.zip"  % txt1 , "archDir_zip"  ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("%s.tar"  % txt2 , "archPath_tar" ))
  VVgktg.append(("%s.tar.gz" % txt2 , "archPath_tar_gz" ))
  VVgktg.append(("%s.tar.xz" % txt2 , "archPath_tar_xz" ))
  VVgktg.append(("%s.tar.bz2" % txt2 , "archPath_tar_bz2"))
  VVgktg.append(("%s.zip"  % txt2 , "archPath_zip" ))
  if isDir and not self.multiSelectState:
   VVgktg.append(VVm7kE)
   VVgktg.append(('Convert to ".ipk" Package', "convertDirToIpk" ))
   VVgktg.append(('Convert to ".deb" Package', "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFBqvZ(self, BF(self.VVYeQ3, path, isDir, title), VVgktg=VVgktg, title=title, VVrcFy=c1, VVZZ3c=c2)
 def VVYeQ3(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"  : self.VVhcbk(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz" : self.VVhcbk(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz" : self.VVhcbk(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2" : self.VVhcbk(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"  : self.VVhcbk(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"  : self.VVhcbk(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz" : self.VVhcbk(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz" : self.VVhcbk(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2" : self.VVhcbk(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"  : self.VVhcbk(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk" : self.VVdBLS(path, False)
   elif item == "convertDirToDeb" : self.VVdBLS(path, True)
 def VVdBLS(self, path, VVYfey):
  self.session.openWithCallback(self.VVG86q, BF(CCtQ7C, path=path, VVYfey=VVYfey))
 def VVhcbk(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FFMiJ8(path, True)
  lastPart = FFBBEq(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FF3zFj("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FF3zFj("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FF3zFj("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % SEP
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFhkCt("rm -f '%s'" % archFile)
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFog5k(failed, VVWgbP))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFog5k(srcTxt, VV4aa0))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFog5k("Output", VVNQoM))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFog5k(failed, VVYZPJ))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFfu76(self, cmd, VVAJlf=self.VVG86q, title=title)
 def VVgb7j(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CCyssW.VVJ7X2(FFMiJ8(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CCMyrC(self, self, title, BF(self.VV0zRI, pathLst))
 def VV0zRI(self, pathLst):
  return CCMyrC.VVYYRX(pathLst)
 def VVE85P(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VV9WBE, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFDiGG(self, BF(FFkWFV, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFkWFV(self, fnc, title=txt)
  else:
   FFG2mq(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VV9WBE(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, "w:gz") as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FF8ShK(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VVG86q()
  else:
   FFMc8G(tarPath)
   FFG2mq(self, "Error while converting.", title=title)
 def VVI8u8(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVeWzK, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFDiGG(self, BF(FFkWFV, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFkWFV(self, fnc, title=txt)
  else:
   FFG2mq(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVeWzK(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FF8ShK(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VVG86q()
  else:
   FFMc8G(zipPath)
   FFG2mq(self, "Error while converting.", title=title)
 def VVHwYd(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FFGa2t(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  FFLgW2("rm -f '%s' '%s'" % (m1v, mvi))
  if FFLgW2("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)) and fileExists(m1v):
   FFLgW2("mv -f '%s' '%s'" % (m1v, mvi))
   self.VVG86q()
   FF27fq(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FFG2mq(self, "Cannot convert this file !", title=title)
 def VVYUYv(self, path):
  title = "Set as PIcon for current channel"
  pPath = CCQVwA.VVzkHI()
  if pathExists(pPath):
   if CCqxHs.VVCz7t(self, title, False, cbFnc=BF(self.VVYUYv, path)):
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
    picon = "%s%s.png" % (pPath, refCode.strip(":").replace(":", "_").upper())
    VVgktg = []
    for item in ((50,30),(96,64),(100,60),(220,132),(400,160),(400,240),(500,300)):
     VVgktg.append(("%d x %d" % (item), item))
    VVdi3l = self.VVPMSZ
    VV2qPD = ("Stretch", BF(self.VVWV7c, title, path, picon))
    VVVYOp = FFBqvZ(self, BF(self.VVRa2i, title, path, picon, False), VVgktg=VVgktg, width=700, title='PIcon Max. Size', VVdi3l=VVdi3l, VV2qPD=VV2qPD, barText="OK = Fit within size")
    VVVYOp.VVI0nr(3)
  else:
   FFG2mq(self, "PIcons path not found:\n\n%s\n\n( You can change it in Settings )" % pPath, title=title)
 def VVWV7c(self, title, path, picon, selectionObj, item):
  self.VVRa2i(title, path, picon, True, item)
  selectionObj.cancel()
 def VVRa2i(self, title, path, picon, stretch, sz=None):
  if sz:
   try:
    from PIL import Image
    im = Image.open(path)
    if stretch: im = im.resize(sz, Image.ANTIALIAS)
    else   : im.thumbnail(sz)
    im.save(picon)
    FFPrkv(self, fncMode=CCXzVR.VV0WSU)
   except Exception as e:
    FFG2mq(self, "Image Processing error:\n\n%s" % e)
 def VVPMSZ(self, VVVYOp, txt, ref, ndx):
  FFxVrN(self, "_help_resize", "Picture File Resizing")
 def VVZl02(self, path):
  FFBqvZ(self, BF(self.VVenwH, path), VVgktg=CCul6W.VVApKt(), width=650, title="Select Player", VVrcFy="#11220000", VVZZ3c="#11220000")
 def VVenwH(self, path, rType=None):
  if rType:
   FFkWFV(self, BF(self.VVkN1L, self, path, rType), title="Playing Media ...")
 @staticmethod
 def VVkN1L(SELF, path, rType=""):
  try:
   if   rType     : prefix = rType
   elif path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCppT7.VVkxsS(SELF.session, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVOVMO(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFGa2t(fDir), fName
  return "", "", ""
 @staticmethod
 def VV3pfV(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVeQ1N(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VV1ctA(size, mode=0):
  txt = CCyssW.VVQ14n(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVQ14n(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VVk88F(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VVfwhn(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FFG2mq(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VVmb5b():
  tDict = CC7kl8.VVBUKY()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVJ7X2(path):
  lst = []
  for ext in CCyssW.VVmb5b():
   lst.extend(FFcJlI(path, "*.%s" % ext))
  return sorted(lst, key=FFCmv7(FFVQmS))
 @staticmethod
 def VV4AIW(path):
  return FFLgW2("tar -tzf '%s'" % path)
 @staticmethod
 def VVY84w(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
 @staticmethod
 def VVqYVb(lst, fromFind=True):
  if len(lst) == 1 and lst[0] == VVeucV:
   return VVeucV
  elif fromFind:
   for line in lst:
    span = iSearch(r"find:\s*(.+):\s*Input\/output error", line, IGNORECASE)
    if span:
     return 'Filesystem Error in:\n\n%s' % span.group(1)
  return ""
class CC7kl8(MenuList):
 VVY96C   = 0
 VV0SUh   = 1
 VVYq2D   = 2
 VV7aBd   = 3
 VVCXdp   = 4
 VVFGm7   = 5
 VVORpR   = 6
 VV93uw   = 7
 VVyozw   = "<List of Storage Devices>"
 VV4vML  = "<Parent Directory>"
 VV4fhy   = 0
 VVJcuN   = 1
 VVlEfi = 2
 VVChPo  = 3
 VVuTru   = 4
 VV19kp   = 5
 FILE_TYPE_LINK   = 6
 VVmAvR  = 7
 PROHIBITED_FILES  = ["/%s/" % x for x in ("DEBIAN","bin","boot","dev","etc","hdd","home","lib","media","mnt","network","proc","run","sbin","sys","tmp","usr","var")]
 def __init__(self, VVWR88=False, directory="/", VV0nST=True, VVX1av=True, VVuCsD=True, VVGaPA=None, VVjkXT=False, VVDYF2=False, VVziSv=False, isTop=False, VVHhN8=None, VVo2w3=1000, VVvi36=30, VVaKvA=30):
  MenuList.__init__(self, list, VVWR88, eListboxPythonMultiContent)
  self.VV0nST  = VV0nST
  self.VVX1av    = VVX1av
  self.VVuCsD  = VVuCsD
  self.VVGaPA  = VVGaPA
  self.VVjkXT   = VVjkXT
  self.VVDYF2   = VVDYF2 or []
  self.VVziSv   = VVziSv or []
  self.isTop     = isTop
  self.additional_extensions = VVHhN8
  self.VVo2w3    = VVo2w3
  self.VVvi36    = VVvi36
  self.VVaKvA    = VVaKvA
  self.EXTENSIONS    = CC7kl8.VVBUKY()
  self.VVnXy1   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.multiSelect_color  = FFe2hp("#11ff4444")
  self.l.setFont(0, gFont(VVwRnH, self.VVvi36))
  self.l.setItemHeight(self.VVaKvA)
  self.png_mem   = CC7kl8.VV4ail("mem")
  self.png_usb   = CC7kl8.VV4ail("usb")
  self.png_fil   = CC7kl8.VV4ail("fil")
  self.png_dir   = CC7kl8.VV4ail("dir")
  self.png_dirup   = CC7kl8.VV4ail("dirup")
  self.png_srv   = CC7kl8.VV4ail("srv")
  self.png_slwfil   = CC7kl8.VV4ail("slwfil")
  self.png_slbfil   = CC7kl8.VV4ail("slbfil")
  self.png_slwdir   = CC7kl8.VV4ail("slwdir")
  self.VVkDfX()
  self.VVFX3C(directory)
 @staticmethod
 def VV4ail(category):
  return LoadPixmap("%s%s.png" % (VVkwgw, category), getDesktop(0))
 @staticmethod
 def VVBUKY():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","stream","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"p7z":("7z"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVRYfY(self, name, absolute=None, isDir=False, typ=None, png=None):
  if absolute and isDir:
   path = absolute
   path = FFTgmt(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FF1YQ7(" -> " , VVChVP) + FF1YQ7(os.readlink(path), VVNQoM)
  tableRow = [ (absolute, isDir, typ) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVaKvA + 10, 0, self.VVo2w3, self.VVaKvA, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   tableRow.append(CCo9yf.VVa1FY(0, 2, self.VVaKvA-4, self.VVaKvA-4, png))
  return tableRow
 def VVTCyR(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVkDfX(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VV8LkG(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVhpHT(self, file):
  if os.path.realpath(file) == file:
   return self.VV8LkG(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VV8LkG(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VV8LkG(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVazbP(self):
  ndx = self.l.getCurrentSelectionIndex()
  row = self.list[ndx]
  bg = self.multiSelect_color if row[2][6] == None else None
  ndx = self.getSelectionIndex()
  if ndx < len(self.list) - 1:
   self.moveToIndex(self.getSelectionIndex() + 1)
  iconData = self.VVuDLf(row, bg)
  if iconData:
   row[2] = iconData
   self.l.setList(self.list)
   return True
  else:
   return False
 def VVprL8(self, isSel):
  bg = self.multiSelect_color if isSel else None
  for ndx, row in enumerate(self.list):
   iconData = self.VVuDLf(row, bg)
   if iconData:
    row[2] = iconData
  self.l.setList(self.list)
 def VVuDLf(self, row, bg):
  if self.VVxkPd(row):
   iconData = list(row[2])
   iconData[6] = bg
   iconData[7] = bg
   return tuple(iconData)
  else:
   return None
 def VVxkPd(self, row):
  if not row[0][0] in self.mountpoints:
   if   row[0][2] in (self.VV19kp, self.FILE_TYPE_LINK): return True
   elif row[0][2] == self.VVuTru:
    if   VVbMcv           : return True
    elif not row[0][0] in self.PROHIBITED_FILES    : return True
  return False
 def VVJKtv(self):
  return self.VVxkPd(self.list[self.l.getCurrentSelectionIndex()])
 def VVqDOA(self):
  tot = 0
  for row in self.list:
   if row[2][6]:
    tot += 1
  return tot
 def VVuQ19(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVFX3C(self, directory, selItem=None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VVuCsD:
    self.current_mountpoint = self.VVhpHT(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VVuCsD:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VVziSv and not self.VVuQ19(path, self.VVDYF2):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VVRYfY(name=p.description, absolute=path, isDir=True, typ=self.VV4fhy, png=png))
    path = "/"
    if path not in self.VVziSv and not self.VVuQ19(path, self.VVDYF2):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VVRYfY(name="INTERNAL FLASH", absolute="/", isDir=True, typ=self.VVJcuN, png=self.png_mem))
  elif self.VVjkXT:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVnXy1 = eServiceCenter.getInstance()
   list = VVnXy1.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VV0nST and not self.isTop:
   if directory == self.current_mountpoint and self.VVuCsD:
    self.list.append(self.VVRYfY(name=self.VVyozw, absolute=None, isDir=True, typ=self.VVlEfi, png=self.png_dirup))
   elif (directory != "/") and not (self.VVziSv and self.VV8LkG(directory) in self.VVziSv):
    self.list.append(self.VVRYfY(name=self.VV4vML, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, typ=self.VVChPo, png=self.png_dirup))
  if self.VV0nST:
   for x in directories:
    if not (self.VVziSv and self.VV8LkG(x) in self.VVziSv) and not self.VVuQ19(x, self.VVDYF2):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVRYfY(name=name, absolute=x, isDir=True, typ=self.FILE_TYPE_LINK if os.path.islink(FFTgmt(x)) else self.VVuTru, png=png))
  if self.VVX1av:
   for x in files:
    if self.VVjkXT:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(target):
        png = self.png_slwfil
        name += FF1YQ7(" -> " , VVChVP) + FF1YQ7(target, VVNQoM)
       else:
        png = self.png_slbfil
        name += FF1YQ7(" -> " , VVChVP) + FF1YQ7(target, VVYZPJ)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVTCyR(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVkwgw, category))
    if (self.VVGaPA is None) or iCompile(self.VVGaPA[0], flags=self.VVGaPA[1]).search(path):
     self.list.append(self.VVRYfY(name=name, absolute=x , isDir=False, typ=self.VV19kp, png=png))
  if self.VVuCsD and len(self.list) == 0:
   self.list.append(self.VVRYfY(name=FF1YQ7("No USB connected", VVdl3O), absolute=None, isDir=False, typ=self.VVmAvR, png=self.png_usb))
  self.l.setList(self.list)
  self.VVs3rt()
  if selItem is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference): p = p.getPath()
    if p == selItem: self.moveToIndex(i)
    i += 1
 def VVs67s(self):
  return self.current_directory
 def VVmriY(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VV5ARR(self):
  return self.VVIxo0() and self.VVs67s()
 def VVIxo0(self):
  return self.list[0][1][7] in (self.VVyozw, self.VV4vML)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVFX3C(self.getSelection()[0], self.current_directory)
 def VVubQY(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVNB6l)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVNB6l)
 def VVNB6l(self, action, device):
  self.VVkDfX()
  if self.current_directory is None:
   self.VVnaun()
 def VVnaun(self):
  tDict = {}
  for row in self.list:
   if row[2][6]:
    tDict[row[0][0]] = 1
  self.VVFX3C(self.current_directory, self.VVubQY())
  isSel = 0
  if tDict:
   for row in self.list:
    if tDict.get(row[0][0], 0):
     row[2] = list(row[2])
     row[2][6] = row[2][7] = self.multiSelect_color
     row[2] = tuple(row[2])
     isSel = 1
   self.l.setList(self.list)
  return isSel
 def VV1WSM(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVY96C : nameAlpMode, nameAlpTxt = self.VV0SUh, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVY96C, sAZ
  if mode == self.VVYq2D : nameNumMode, nameNumTxt = self.VV7aBd, s90
  else       : nameNumMode, nameNumTxt = self.VVYq2D, s09
  if mode == self.VVCXdp : dateMode, dateTxt = self.VVFGm7, sON
  else       : dateMode, dateTxt = self.VVCXdp, sNO
  if mode == self.VVORpR : typeMode, typeTxt = self.VV93uw, sZA
  else       : typeMode, typeTxt = self.VVORpR, sAZ
  if   mode in (self.VVY96C, self.VV0SUh): txt = "Name (%s)" % (sAZ if mode == self.VVY96C else sZA)
  elif mode in (self.VVYq2D, self.VV7aBd): txt = "Name (%s)" % (s09 if mode == self.VVY96C else s90)
  elif mode in (self.VVCXdp, self.VVFGm7): txt = "Date (%s)" % (sNO if mode == self.VVCXdp else sON)
  elif mode in (self.VVORpR, self.VV93uw): txt = "Type (%s)" % (sAZ if mode == self.VVORpR else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VVs3rt(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FFeLB8(CFG.browserSortMode, mode)
   FFeLB8(CFG.browserSortMix, isMix)
  if self.list:
   if self.VVIxo0() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VVY96C, self.VV0SUh):
    rev = True if mode == self.VV0SUh else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VVYq2D, self.VV7aBd):
    rev = True if mode == self.VV7aBd else False
    self.list = sorted(self.list[item0:], key=FFCmv7(BF(self.VVhmZp, isMix, rev)), reverse=rev)
   elif mode in (self.VVCXdp, self.VVFGm7):
    rev = True if mode == self.VVFGm7 else False
    self.list = sorted(self.list[item0:], key=FFCmv7(BF(self.VVZWOO, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VV93uw else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VVhmZp(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FFVQmS(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FFfQKQ(dir2, dir1) or FFVQmS(name1, name2)
 def VVZWOO(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FFfQKQ(stat2.st_ctime, stat1.st_ctime)
    else : return FFfQKQ(dir2, dir1) or FFfQKQ(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CCXTPW(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FFdP4M(VVYTfH, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VV9gTz   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VV5qMO(defFG, "#00FFFFFF")
  self.defBG   = self.VV5qMO(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFj3mb(self, self.Title)
  self["keyRed"].show()
  FFuetT(self["keyGreen"] , "< > Transp.")
  FFuetT(self["keyYellow"], "Foreground")
  FFuetT(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(VVKDoB,
  {
   "ok"   : self.VVtmib     ,
   "green"   : self.VVtmib     ,
   "yellow"  : BF(self.VVtCsY, False)  ,
   "blue"   : BF(self.VVtCsY, True)  ,
   "up"   : self.VVRAom       ,
   "down"   : self.VVOgNQ      ,
   "left"   : self.VVvxS4      ,
   "right"   : self.VV3Elm      ,
   "last"   : BF(self.VVQYwf, -5) ,
   "next"   : BF(self.VVQYwf, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVgr8g)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFeNfF(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFeNfF(self["keyRed"] , c)
  FFeNfF(self["keyGreen"] , c)
  self.VVJczo()
  self.VVwZwj()
  FFfLQO(self["myColorTst"], self.defFG)
  FFeNfF(self["myColorTst"], self.defBG)
 def VV5qMO(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVwZwj(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVQQvU(0, 0)
     return
 def VVtmib(self):
  self.close(self.defFG, self.defBG)
 def VVRAom(self): self.VVQQvU(-1, 0)
 def VVOgNQ(self): self.VVQQvU(1, 0)
 def VVvxS4(self): self.VVQQvU(0, -1)
 def VV3Elm(self): self.VVQQvU(0, 1)
 def VVQQvU(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVd2TI()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VViwmu()
 def VVJczo(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VViwmu(self):
  color = self.VVd2TI()
  if self.isBgMode: FFeNfF(self["myColorTst"], color)
  else   : FFfLQO(self["myColorTst"], color)
 def VVtCsY(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VVJczo()
   self.VVwZwj()
 def VVQYwf(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVQQvU(0, 0)
 def VVCY7z(self):
  return hex(self.transp)[2:].zfill(2)
 def VVd2TI(self):
  return ("#%s%s" % (self.VVCY7z(), self.colors[self.curRow][self.curCol])).upper()
class CC81AE(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFdP4M(VVHjhJ, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FFj3mb(self, title="%s%s%s" % (self.Title, " " * 10, FF1YQ7("Change values with Up , Down, < , 0 , >", VVdl3O)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(VVKDoB,
  {
   "ok"  : self.VV96hS      ,
   "cancel" : self.VVs00w      ,
   "info"  : self.VVU0St    ,
   "red"  : self.VVn8Qu  ,
   "green"  : self.VVPeCj   ,
   "yellow" : BF(self.VV3AQD, 0)  ,
   "blue"  : self.VVkiN2    ,
   "menu"  : self.VV1Qef      ,
   "left"  : self.VVvxS4      ,
   "right"  : self.VV3Elm      ,
   "last"  : self.VVhaBy     ,
   "next"  : self.VVsMTt     ,
   "0"   : self.VVLVmz    ,
   "up"  : self.VVRAom       ,
   "down"  : self.VVOgNQ      ,
   "pageUp" : BF(self.VVmQjV, True) ,
   "pageDown" : BF(self.VVmQjV, False) ,
   "chanUp" : BF(self.VVmQjV, True) ,
   "chanDown" : BF(self.VVmQjV, False) ,
   "play"  : BF(self.VVKpUA, "pause")  ,
   "pause"  : BF(self.VVKpUA, "pause")  ,
   "playPause" : BF(self.VVKpUA, "pause")  ,
   "stop"  : BF(self.VVKpUA, "pause")  ,
   "audio"  : BF(self.VVKpUA, "audio")  ,
   "subtitle" : BF(self.VVKpUA, "subtitle") ,
   "rewind" : BF(self.VVKpUA, "rewind" ) ,
   "forward" : BF(self.VVKpUA, "forward" ) ,
   "rewindDm" : BF(self.VVKpUA, "rewindDm") ,
   "forwardDm" : BF(self.VVKpUA, "forwardDm")
  }, -1)
  self.VVAscg()
  self.onShown.append(self.VVgr8g)
  self.onClose.append(self.VVqQ87)
 def VVAscg(self):
  lst = []
  for fil in FFcJlI(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VVUTqI:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VVgr8g(self):
  self.onShown.remove(self.VVgr8g)
  FF2kyZ(self)
  FFIl1A(self)
  for i in range(3):
   self["mySubt%d" % i].hide()
  self.VVjQxG()
  self.VVNAgj()
  self.VVMC1E()
 def VVqQ87(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VV1ZV5(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FFeNfF(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VV1Lvx()
 def VVjQxG(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FFeNfF(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VV96hS(self):
  if self.settingShown:
   confItem = self.VVPKfz()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVgktg = []
   if isinstance(lst[0], tuple): VVgktg = [(x[1], x[0]) for x in lst]
   else      : VVgktg = [(x, x) for x in lst]
   VVVYOp = FFBqvZ(self, self.VVfsa4, VVgktg=VVgktg, width=700, title=title, VVrcFy="#33221111", VVZZ3c="#33110011")
   VVVYOp.VVfFH1(confItem.getText())
  else:
   self.close("subtExit")
 def VVfsa4(self, item=None):
  if item:
   self.VVPKfz()[self.CursorPos].setValue(item)
   self.VV1Lvx()
   self.VVNAgj()
   self.VVRyTg(True)
 def VVs00w(self):
  for confItem in self.VVPKfz():
   if confItem.isChanged():
    FFDiGG(self, BF(self.VV5ZnA, cbFnc=self.VV7LQD), "Save Changes ?", callBack_No=self.VVwZnT, title=self.Title)
    break
  else:
   self.VV7LQD()
 def VV7LQD(self):
   if self.settingShown: self.VVjQxG()
   else    : self.close("subtExit")
 def VV1Qef(self):
  if self.settingShown: self.VVygKb()
  else    : self.VV1ZV5()
 def VVvxS4(self): self.VVRdBm(-1)
 def VV3Elm(self): self.VVRdBm(1)
 def VVRdBm(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VVqEjK()
   if pos == -1: ndx = self.VVEvNc(posVal)
   else  : ndx = self.VVzWw7(posVal)
   if   ndx < 0      : FFpIgV(self, "Not found" , 500)
   elif ndx == 0      : FFpIgV(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FFpIgV(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VVKM2I(frmSec)
    if allow:
     self.VV3AQD(delay, True)
     self.VVRyTg(force=True)
     CChhP9(self.session, "Changed Delay to %d sec" % delay, timeout=500, fonSize=35)
    else:
     FFpIgV(self, "Delay out of range", 800)
 def VVmQjV(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VVKpUA(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVhaBy(self) : self.VVTU1f(5)
 def VVsMTt(self) : self.VVTU1f(6)
 def VVLVmz(self) : self.VVTU1f(-1)
 def VVRAom(self):
  if self.settingShown: self.VVTU1f(1)
  else    : self.VVmQjV(True)
 def VVOgNQ(self):
  if self.settingShown: self.VVTU1f(0)
  else    : self.VVmQjV(False)
 def VVTU1f(self, direction):
  if self.settingShown:
   confItem = self.VVPKfz()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VV1Lvx()
   self.VVNAgj()
   self.VVRyTg(True)
 def VVPKfz(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VVwZnT(self):
  for confItem in self.VVPKfz(): confItem.cancel()
  self.VV1Lvx()
  self.VVNAgj()
  self.VVjQxG()
 def VVn8Qu(self):
  if self.settingShown:
   FFDiGG(self, self.VVLFFA, "Reset Subtitle Settings to default ?", title=self.Title)
 def VVLFFA(self):
  for confItem in self.VVPKfz(): confItem.setValue(confItem.default)
  self.VV5ZnA()
  self.VV1Lvx()
  self.VVNAgj()
 def VV3AQD(self, delay, force=False):
  if self.settingShown or force:
   FFeLB8(CFG.subtDelaySec, delay)
   self.VVHPbl()
   self.VV1Lvx()
   self.VVNAgj()
   if self.settingShown:
    FFpIgV(self, 'Reset to "0"', 800, isGrn=True)
 def VVPeCj(self):
  if self.settingShown:
   self.VV5ZnA()
   self.VVjQxG()
 def VV5ZnA(self, cbFnc=None):
  for confItem in self.VVPKfz(): confItem.save()
  configfile.save()
  self.VVHPbl()
  FFpIgV(self, "Saved", 1000, isGrn=True)
  if cbFnc:
   cbFnc()
 def VV1Lvx(self):
  cfgLst = self.VVPKfz()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VVNAgj(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   FFA3nY(path, fnt, isRepl=1)
  else:
   fnt = VVwRnH
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FFfvBi(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFfLQO(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FFeNfF(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    lineH = FF0NHz(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FFfvBi(CFG.subtVerticalPos.getValue(), 0, 100, 0, FFfQyb()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  FFLVLw(self, winW, winH)
 def VVU0St(self):
  sp = "    "
  txt  = "%s\n"   % FF1YQ7("Subtitle File:", VVyz0j)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FF1YQ7("Subtitle Settings:", VVyz0j)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VVqEjK()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FFGcFN(frmSec1)
   time2 = FFGcFN(toSec2)
   txt += "\n"
   txt += "%s\n"       % FF1YQ7("Timing:", VVyz0j)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FFGcFN(durVal)
   txt += sp + "Progress\t: %s\n" % FFGcFN(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FF1YQ7("Subtitle end reached.", VVWgbP)
  FF8ShK(self, txt, title="Current Subtitle")
 def VVMC1E(self, path="", delay=0, enc=""):
  FFkWFV(self, BF(self.VVi2Kx, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VVi2Kx(self, path="", delay=0, enc=""):
  FFpIgV(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVODBx(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VV1Lvx()
     self.VVlhMq()
   else:
    path, delay, enc = CC81AE.VVqILt(self)
    if path:
     self.VVMC1E(path=path, delay=delay, enc=enc)
    else:
     self.VVygKb()
  except:
   pass
 def VVlhMq(self):
  posVal, durVal = self.VVqEjK()
  if self.VVA7bx(posVal):
   return
  CC81AE.VVFF0X(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVRyTg)
  except:
   self.timerUpdate.callback.append(self.VVRyTg)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVHMxW)
  except:
   self.timerEndText.callback.append(self.VVHMxW)
  FFpIgV(self, "Subtitle started", 700, isGrn=True)
 def VVA7bx(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CC81AE.VVU6hr(self)
   FFMc8G(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VVygKb(self):
  c1, c2, c3, c4, c5 = "", VVyz0j, VVifMr, VVeksK, VVWgbP
  VVgktg = []
  VVgktg.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVgktg.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVgktg.append(VVm7kE)
  VVgktg.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVgktg.append(VVm7kE)
  VVgktg.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVgktg.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVgktg.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVgktg.append(VVm7kE)
   VVgktg.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVgktg.append(VVm7kE)
   VVgktg.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVgktg.append(VVm7kE)
   VVgktg.append(("Help (Keys)"        , "help"  ))
  FFBqvZ(self, self.VVDJIB, VVgktg=VVgktg, width=700, title='Find Subtitle ".srt" File', VVrcFy="#33221111", VVZZ3c="#33110011")
 def VVDJIB(self, item=None):
  if item:
   if   item == "allSrt"   : self.VVnqz4(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VVnqz4(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    sDir = "/"
    for path in (CFG.lastFileManFindSrt.getValue(), CFG.MovieDownloadPath.getValue(), "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VV9m8D, BF(CCyssW, patternMode="srt", VV9Esa=sDir))
   elif item.startswith("sugSrt") : self.VVnqz4(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FFkWFV(self, BF(CCmJil.VVnQil, self, self.lastSubtFile, self.VVm14n, self.lastSubtEnc or CFG.subtDefaultEnc.getValue()), title="Loading Codecs ...")
    else             : FFpIgV(self, "SRT File error", 1000)
   elif item == "disab":
    FFMc8G(CC81AE.VVU6hr(self))
    self.close("subtExit")
   elif item == "help"    : FFxVrN(self, "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VVm14n(self, item=None):
  if item:
   FFkWFV(self, BF(self.VVMC1E, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VV9m8D(self, path):
  if path:
   FFeLB8(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VVMC1E(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VVnqz4(self, defSrt="", mode=0, coeff=0.25):
  FFkWFV(self, BF(self.VVfRnO, defSrt, mode=mode, coeff=coeff), title="Searching for srt files")
 def VVfRnO(self, defSrt="", mode=0, coeff=0.25):
  if mode == 1:
   srtList = CC81AE.VVAsh1(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FFa467('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFZu9n(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VVR1Mr(srtList, coeff)
     if err:
      if self.settingShown: FFrKlA(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VVUl7I = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FFGa2t(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVUl7I.append((fName, Dir))
   VVp0o5  = ("Select"    , self.VVBRIi     , [])
   VVIcAB = self.VVy6WC
   VVq5Be = (""     , self.VVQJDW       , [])
   VVgDd7 = (""     , BF(self.VVPhaT, defSrt, False) , [])
   VVkY0R = ("Find Current File" , BF(self.VVPhaT, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FF69ky(self, None, title=title, header=header, VV9gTz=VVUl7I, VVYiuZ=widths, VVvi36=28, VVp0o5=VVp0o5, VVIcAB=VVIcAB, VVq5Be=VVq5Be, VVgDd7=VVgDd7, VVkY0R=VVkY0R, lastFindConfigObj=CFG.lastFindSubtitle
     , VVrcFy="#11002222", VVZZ3c="#33001111", VVRr4z="#33001111", VVsykS="#11ffff00", VVLwCQ="#11445544", VVhvzQ="#22222222", VVEjwd="#11002233")
  elif self.settingShown : FFrKlA(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VVy6WC(self, VVkINB):
  VVkINB.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VVQJDW(self, VVkINB, title, txt, colList):
  fName, Dir = colList
  FF8ShK(VVkINB, "%s\n\n%s%s" % (FF1YQ7("Path:", VVyz0j), Dir, fName), title=title)
 def VVPhaT(self, path, VVT0Gn, VVkINB, title, txt, colList):
  for ndx, row in enumerate(VVkINB.VV3rlI()):
   if path == row[1].strip() + row[0].strip():
    VVkINB.VV2NBO(ndx)
    break
  else:
   if VVT0Gn:
    FFpIgV(VVkINB, "Not in list !", 1000)
 def VVBRIi(self, VVkINB, title, txt, colList):
  VVkINB.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VVMC1E(path=path)
 def VVR1Mr(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCjxcj.VVCaOX(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName:
   if evName and CFG.epgLangTitle.getValue():
    CCjxcj.VVU1IA(evName, "en")[0] or evName
   lst, err = CC81AE.VVU6oW(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVODBx(self, path, enc=None):
  if enc and CCmJil.VVhium(path, enc)      : enc = enc
  elif CCmJil.VVhium(path, CFG.subtDefaultEnc.getValue()): enc = CFG.subtDefaultEnc.getValue()
  else                   : enc = None
  if not fileExists(path):
   return [], "File not found"
  if (FF1fFq(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FFjqdo(path, encLst=enc)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVzndp(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VVIgZz(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVHPbl()
  return subtList, ""
 def VVIgZz(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VVzndp(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVHPbl(self):
  path = CC81AE.VVU6hr(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVRyTg(self, force=False):
  posVal, durVal = self.VVqEjK()
  if self.VVA7bx(posVal):
   return
  curIndex = self.VVFku9(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVHMxW()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFfLQO(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VVqEjK(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCppT7.VVUA6s(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCjxcj.VVCaOX(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VVFku9(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VVEvNc(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VVzWw7(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VVHMxW(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFfLQO(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VVkiN2(self):
  FFkWFV(self, self.VVfWhS, title="Loading Lines ...")
 def VVfWhS(self):
  VVUl7I = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VVUl7I.append((cap, FFGcFN(frm), str(frm), firstLine))
  if VVUl7I:
   title = "Select Current Subtitle Line"
   VV1MrT  = self.VVNlBd
   VVIcAB = self.VV2BmR
   VVp0o5  = ("Select"   , self.VVtrv3 , [title])
   VVkY0R = ("Current Line" , self.VV769k , [True])
   VVW1zM = ("Reset Delay" , self.VVpwrZ , [])
   VVM4el = ("New Delay"  , self.VVjPgz   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VVwZxf  = (CENTER , CENTER, CENTER , LEFT    )
   VVkINB = FF69ky(self, None, title=title, header=header, VV9gTz=VVUl7I, VVwZxf=VVwZxf, VVYiuZ=widths, VVvi36=28, VV1MrT=VV1MrT, VVIcAB=VVIcAB, VVp0o5=VVp0o5, VVkY0R=VVkY0R, VVW1zM=VVW1zM, VVM4el=VVM4el
          , VVrcFy="#33002222", VVZZ3c="#33001111", VVRr4z="#33110011", VVsykS="#11ffff00", VVLwCQ="#0a334455", VVhvzQ="#22222222", VVEjwd="#33002233")
  else:
   FFrKlA(self, "Cannot read lines !", 2000)
 def VVNlBd(self, VVkINB):
  self.subtLinesTable = VVkINB
  if CFG.subtDelaySec.getValue():
   VVkINB["keyYellow"].show()
   VVkINB["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVkINB["keyYellow"].hide()
  VVkINB["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FFeNfF(VVkINB["keyBlue"], "#22222222")
  VVkINB.VVxHVQ(BF(self.VV4HAx, VVkINB))
  self.VV769k(VVkINB, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVgF8v)
  except:
   self.timerSubtLines.callback.append(self.VVgF8v)
  self.timerSubtLines.start(1000, False)
 def VV2BmR(self, VVkINB):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVkINB.cancel()
 def VVgF8v(self):
  if self.subtLinesTable:
   VVkINB = self.subtLinesTable
   posVal, durVal = self.VVqEjK()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVFku9(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVkINB.VV68fw(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVkINB.VVp9X7(self.subtLinesTableNdx, row)
     row = VVkINB.VV68fw(curIndex)
     row[0] = color + row[0]
     VVkINB.VVp9X7(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VVtrv3(self, VVkINB, Title):
  delay, color, allow = self.VVJ8WC(VVkINB)
  if allow:
   self.VV2BmR(VVkINB)
   self.VV3AQD(delay, True)
  else:
   FFpIgV(VVkINB, "Delay out of range", 1500)
 def VV769k(self, VVkINB, VVT0Gn, onlyColor=False):
  if VVkINB:
   posVal, durVal = self.VVqEjK()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVFku9(posVal)
    if curIndex > -1:
     VVkINB.VV2NBO(curIndex)
    else:
     ndx = self.VVEvNc(posVal)
     if ndx > -1:
      VVkINB.VV2NBO(ndx)
 def VVpwrZ(self, VVkINB, title, txt, colList):
  if VVkINB["keyYellow"].getVisible():
   self.VV3AQD(0, True)
   VVkINB["keyYellow"].hide()
   self.VV769k(VVkINB, False)
 def VV4HAx(self, VVkINB):
  delay, color, allow = self.VVJ8WC(VVkINB)
  VVkINB["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VVJ8WC(self, VVkINB):
  lineTime = float(VVkINB.VVw0xB()[2].strip())
  return self.VVKM2I(lineTime)
 def VVKM2I(self, lineTime):
  posVal, durVal = self.VVqEjK()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VVo8aK
   else     : allow, color = False, VVWgbP
   delay = FF5kC0(val, -600, 600)
  return delay, color, allow
 def VVjPgz(self, VVkINB, title, txt, colList):
  pass
 @staticmethod
 def VV6BhP(SELF):
  path, delay, enc = CC81AE.VVqILt(SELF)
  return True if path else False
 @staticmethod
 def VVqILt(SELF):
  path, delay, enc = CC81AE.VVX79o(SELF)
  if not path:
   path = CC81AE.VVU5Q2(SELF)
  return path, delay, enc
 @staticmethod
 def VVX79o(SELF):
  srtCfgPath = CC81AE.VVU6hr(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FFjqdo(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VVU6hr(SELF):
  fPath, fDir, fName = CCyssW.VVOVMO(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCjxcj.VVCaOX(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFkbEk(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VVU5Q2(SELF):
  bestRatio = 0
  fPath, fDir, fName = CCyssW.VVOVMO(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CC81AE.VVAsh1(SELF)
    bLst, err = CC81AE.VVU6oW(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVAsh1(SELF):
  fPath, fDir, fName = CCyssW.VVOVMO(SELF)
  if pathExists(fDir):
   files = FFcJlI(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VVU6oW(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VVimlw():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVFF0X(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CC81AE.VVtHYI()
 @staticmethod
 def VVtHYI():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CCF1f8(ScrollLabel):
 def __init__(self, parentSELF, text="", VVKjkL=True):
  ScrollLabel.__init__(self, text)
  self.VVKjkL   = VVKjkL
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VVmUo7  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.pageLines    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.fontFamily    = None
  self.VVvi36    = None
  self.parentW    = None
  self.parentH    = None
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(VVKDoB,
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VVcxq8 ,
   "green"   : self.VVLJ5Z ,
   "yellow"  : self.VVdt6s ,
   "blue"   : self.VVDtvp ,
   "up"   : self.VVjNzZ   ,
   "down"   : self.VViXre  ,
   "left"   : self.VVjNzZ   ,
   "right"   : self.VViXre  ,
   "last"   : BF(self.VVTP0c, 0) ,
   "0"    : BF(self.VVTP0c, 1) ,
   "next"   : BF(self.VVTP0c, 2) ,
   "pageUp"  : self.VVZ3hk   ,
   "chanUp"  : self.VVZ3hk   ,
   "pageDown"  : self.VVaYjD   ,
   "chanDown"  : self.VVaYjD
  }, -1)
 def VVdp3X(self, isResizable=True, VVHrLx=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFfLQO(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FFeNfF(self.parentSELF["keyRedTop"], "#113A5365")
  FF2kyZ(self.parentSELF, True)
  self.isResizable = isResizable
  if VVHrLx:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVvi36  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFeNfF(self, color)
 def VVkKJD(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  VVaKvA  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  self.pageLines = int(self.long_text.size().height() / VVaKvA)
  margin   = int(VVaKvA / 6)
  self.pageHeight = int(self.pageLines * VVaKvA)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVmUo7 - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVgtiu()
 def VVjNzZ(self):
  if self.VVmUo7 > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def VViXre(self):
  if self.VVmUo7 > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVZ3hk(self):
  self.setPos(0)
 def VVaYjD(self):
  self.setPos(self.VVmUo7-self.pageHeight)
 def VVtrWC(self):
  return self.VVmUo7 <= self.pageHeight or self.curPos == self.VVmUo7 - self.pageHeight
 def getText(self):
  return self.message
 def VVgtiu(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVmUo7, 3))
   start = int((100 - vis) * self.curPos / (self.VVmUo7 - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVMXNv=VVrJOZ):
  old_VVtrWC = self.VVtrWC()
  self.message = str(text)
  if self.pageHeight:
   if len(self.message.splitlines()) < self.pageLines - 2:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.message = self.message.rstrip() + "\n"
   self.long_text.setText(self.message)
   self.VVmUo7 = self.long_text.calculateSize().height()
   if self.VVKjkL and self.VVmUo7 > self.pageHeight:
    self.scrollbar.show()
    self.VVgtiu()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
    pageWidth  = self.instance.size().width() - w
    self.long_text.resize(eSize(pageWidth, self.VVmUo7))
    self.VVmUo7 = self.long_text.calculateSize().height()
    self.long_text.resize(eSize(pageWidth, self.VVmUo7))
   else:
    self.scrollbar.hide()
   if   VVMXNv == VVyFvO: self.setPos(0)
   elif VVMXNv == VVCUL7 : self.VVaYjD()
   elif old_VVtrWC    : self.VVaYjD()
 def appendText(self, text, VVMXNv=VVCUL7):
  self.setText(self.message + str(text), VVMXNv=VVMXNv)
 def VVdt6s(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVTLT5(size)
 def VVDtvp(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVTLT5(size)
 def VVLJ5Z(self):
  self.VVTLT5(self.VVvi36)
 def VVTLT5(self, VVvi36):
  self.long_text.setFont(gFont(self.fontFamily, VVvi36))
  self.setText(self.message, VVMXNv=VVrJOZ)
  self.VVVjqa()
 def VVTP0c(self, align):
  self.long_text.setHAlign(align)
 def VVcxq8(self):
  VVgktg = []
  VVgktg.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Align Left" , "left" ))
  VVgktg.append(("Align Center" , "center" ))
  VVgktg.append(("Align Right" , "right" ))
  if self.outputFileToSave:
   VVgktg.append(VVm7kE)
   VVgktg.append((FF1YQ7("Save to File", VVyz0j), "save"))
  VVgktg.append(VVm7kE)
  VVgktg.append(("Keys (Shortcuts)", "help"))
  FFBqvZ(self.parentSELF, self.VV9VXV, VVgktg=VVgktg, title="Text Option", width=500)
 def VV9VXV(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VVTP0c(0)
   elif item == "center" : self.VVTP0c(1)
   elif item == "right" : self.VVTP0c(2)
   elif item == "save"  : self.VV4zNG()
   elif item == "help"  : FFxVrN(self.parentSELF, "_help_txt", "Text Viewer (Keys)")
 def VV4zNG(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FFGa2t(expPath), self.outputFileToSave, FF4Fnb())
   with open(outF, "w") as f:
    f.write(FFOD7l(self.message))
   FF27fq(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FFG2mq(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVVjqa(self, minHeight=0):
  if self.isResizable:
   VVaKvA = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont()))
   textH = min(self.pageHeight, VVaKvA * (len(self.message.splitlines()) + 1))
   if textH < self.pageHeight and self.VVmUo7 < self.pageHeight:
    textH = max(textH, self.VVmUo7)
   self.resize(eSize(*(self.instance.size().width(), textH + 6)))
   diff = self.pageHeight - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   if minHeight > 0:
    newH = max(newH, minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, min(self.parentH, newH))))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
