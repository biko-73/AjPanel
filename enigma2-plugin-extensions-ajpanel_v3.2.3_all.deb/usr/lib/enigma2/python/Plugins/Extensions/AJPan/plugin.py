import os
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import ceil as iCeil
from time      import localtime, mktime, strftime, sleep as iSleep
from time      import time as iTime
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVLiaM   = "v3.2.3"
VVPQwH    = "08-12-2021"
EASY_MODE    = 0
VVrkVU   = 0
VVsJXJ   = 0
VVnwNP  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVTuBV  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVHCIO    = "/media/usb/"
VVfmhV    = "/usr/share/enigma2/picon/"
VVg7D5   = "/etc/enigma2/"
VVWJxc  = "ajpanel_update_url"
VVGbBr   = "AJPan"
VVlZ7S    = "AUTO FIND"
VVsQRi    = ""
VV20Ap    = "Regular"
VV06tg      = "-" * 80;
VVn6Em    = ("-" * 100, )
VVQNCe    = ""
VVm2pM   = " && echo 'Successful' || echo 'Failed!'"
VVBx6k    = []
VVMIFu  = "Cannot continue (No Enough Memory) !"
VV9a8x     = 0
VVjSuI    = ""
VV3ToJ  = False
VVD4Tf  = False
VVdXwL     = 0
VVbuSy    = 1
VVPKsb    = 2
VVoWNM   = 3
VVS35S    = 4
VV4yLp    = 5
VVDOy7 = 6
VVUyHt = 7
VV8Guw  = 8
VVWDbm   = 9
VVCFB2   = 10
VVWjru   = 11
VVzyq9  = 12
VVUHRS  = 13
VVP2Jc    = 14
VVtR0a   = 15
VVQYBD   = 16
VV6Hg0    = 17
VVfaAE    = 18
VVEpGj  = 15
VVrOxe   = 0
VVmSww   = 1
VVxUhY   = 2
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices = [ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices = [ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices = [ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices = [ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsPath    = ConfigDirectory(default=VVlZ7S, visible_width=51)
CFG.PIconsPath     = ConfigDirectory(default=VVfmhV, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVHCIO, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
def FFpJJC():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVD5VC  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VV9UAV = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVD5VC  : return 0
  elif VV9UAV : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVA115 = FFpJJC()
VVvQSh = VViEcp = VVDbaf = VVUqrB = VVlVvm = VVx9g6 = VV0Tnk = VVvgWJ = COLOR_CONS_BRIGHT_YELLOW = VVbaBa = VVkwvG = VV011v = ""
def FFUtlG(FFUtlGText="", addSep=True):
 if VVrkVU:
  FFUtlGText = str(FFUtlGText)
  if "\n" in FFUtlGText: FFUtlGText = "\n" + FFUtlGText
  txt = VV06tg + "\n" if addSep else ""
  txt += ">>>> %s >>  %s" % (PLUGIN_NAME, str(FFUtlGText))
  os.system("cat << '_EOF' \n" + txt + "\n_EOF")
def FFtOrG(txt, isAppend=True, ignoreErr=False):
 if VVrkVU:
  tm = FFDajM()
  err = ""
  if not ignoreErr:
   try:
    from traceback import format_exc, format_stack
    trace = format_exc()
    if trace and len(trace) > 5:
     stack = format_stack()[:-1]
     sep = "*" * 70
     err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
     err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   except:
    pass
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFUtlG(err)
  FFUtlG("Output Log File : %s" % fileName)
VVBx6k = []
def FFhaOv(win):
 global VVBx6k
 if not win in VVBx6k:
  VVBx6k.append(win)
def FFVS4w(*args):
 global VVBx6k
 for win in VVBx6k:
  try:
   win.close()
  except:
   pass
 VVBx6k = []
def FFdUvp():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVPBo9 = FFdUvp()
def getDescriptor(fnc, where, name=PLUGIN_NAME):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=True, name=name, description=PLUGIN_DESCRIPTION, icon=icon)
def FFBjhM()      : return getDescriptor(FFHtex   , [ PluginDescriptor.WHERE_PLUGINMENU  ] )
def FFiYzf()   : return getDescriptor(FFHtex   , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] )
def FFYcOr()   : return getDescriptor(FFxgDu , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager")
def FFNhz9()  : return getDescriptor(FFftf2 , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Live Log (OSCam/NCam)")
def FFY9x7(): return getDescriptor(FFXCOy , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player")
def FFDd55()  : return getDescriptor(FFXsDD  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV")
def FFcfsi()     : return getDescriptor(FFK2Zp , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info.")
def FFpdj4()       : return getDescriptor(FF848q  , [ PluginDescriptor.WHERE_MENU    ] )
def FFZTbV()     : return PluginDescriptor(fnc=FFKYCC, where=[PluginDescriptor.WHERE_SESSIONSTART])
def Plugins(**kwargs):
 result = [ FFBjhM() , FFpdj4() , FFZTbV() , FFcfsi()]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFiYzf())
  result.append(FFYcOr())
  result.append(FFNhz9())
  result.append(FFY9x7())
  result.append(FFDd55())
 return result
def FFKYCC(reason, **kwargs):
 if reason == 0:
  FFUwoz()
  if "session" in kwargs:
   session = kwargs["session"]
   FFXidZ(session)
   CCMpsE(session)
def FF848q(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFHtex, PLUGIN_NAME, 45)]
 else:
  return []
def FFHtex(session, **kwargs):
 session.open(Main_Menu)
def FFxgDu(session, **kwargs):
 session.open(CCNIug)
def FFftf2(session, **kwargs):
 FFIkMD(session, CCv9Lb.VVoJum)
def FFXCOy(session, **kwargs):
 FFIUUW(session, isFromSession=True)
def FFXsDD(session, **kwargs):
 session.open(CCqLir)
def FFK2Zp(session, **kwargs):
 session.open(CC9cgb, fncMode=CC9cgb.VV69ha)
def FFtNpV():
 pluginList   = iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU)
 descrPanel   = FFiYzf()
 descrFileMan  = FFYcOr()
 descrCamLog   = FFNhz9()
 descrSignalPlayer = FFY9x7()
 descrIptvMenu  = FFDd55()
 try:
  if CFG.showInExtensionMenu.getValue():
   if not descrPanel in pluginList   : iPlugins.addPlugin(descrPanel)
   if not descrFileMan in pluginList  : iPlugins.addPlugin(descrFileMan)
   if not descrCamLog in pluginList  : iPlugins.addPlugin(descrCamLog)
   if not descrSignalPlayer in pluginList : iPlugins.addPlugin(descrSignalPlayer)
   if not descrIptvMenu in pluginList  : iPlugins.addPlugin(descrIptvMenu)
  else:
   if descrPanel in pluginList    : iPlugins.removePlugin(descrPanel)
   if descrFileMan in pluginList   : iPlugins.removePlugin(descrFileMan)
   if descrCamLog in pluginList   : iPlugins.removePlugin(descrCamLog)
   if descrSignalPlayer in pluginList  : iPlugins.removePlugin(descrSignalPlayer)
   if descrIptvMenu in pluginList   : iPlugins.removePlugin(descrIptvMenu)
 except:
  pass
VVYpDI = None
def FFUwoz():
 try:
  global VVYpDI
  if VVYpDI is None:
   VVYpDI    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFF0hB
  ChannelContextMenu.FFTM3I = FFTM3I
 except:
  pass
def FFF0hB(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVYpDI(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFTM3I, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFTM3I, title1, csel, isFind=True))))
def FFTM3I(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFmJHI(refCode)
 except:
  pass
 self.session.open(boundFunction(CCsxxS, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFXidZ(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FFv2t5, session, "lok")
 hk.actions['longCancel'] = boundFunction(FFv2t5, session, "lesc")
 hk.actions['longRed']  = boundFunction(FFv2t5, session, "lred")
def FFv2t5(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFIUUW(session, isFromSession=True)
def FFnDik(SELF, title="", addLabel=False, addScrollLabel=False, VVRJT5=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FF6oMc()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 if SELF.skinParam["topRightBtns"] > 0:
  SELF["keyMenu2F"]  = Label()
  SELF["keyMenu2"]  = Label("Menu")
  if SELF.skinParam["topRightBtns"] > 1:
   SELF["keyMenu1F"] = Label()
   SELF["keyMenu1"] = Label("Info")
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CC2t1H(SELF)
 if VVRJT5:
  SELF["myMenu"] = MenuList(VVRJT5)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVDa6H        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFKcR0(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FF3sIW, SELF, "0") ,
  "1"    : boundFunction(FF3sIW, SELF, "1") ,
  "2"    : boundFunction(FF3sIW, SELF, "2") ,
  "3"    : boundFunction(FF3sIW, SELF, "3") ,
  "4"    : boundFunction(FF3sIW, SELF, "4") ,
  "5"    : boundFunction(FF3sIW, SELF, "5") ,
  "6"    : boundFunction(FF3sIW, SELF, "6") ,
  "7"    : boundFunction(FF3sIW, SELF, "7") ,
  "8"    : boundFunction(FF3sIW, SELF, "8") ,
  "9"    : boundFunction(FF3sIW, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FFKP19, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FF3sIW(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VV011v:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VV011v + SELF.keyPressed + VViEcp)
    txt = VViEcp + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFdxmx(SELF, txt)
def FFKP19(SELF, tableObj, colNum):
 FFdxmx(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     tableObj.moveToIndex(i)
     SELF.VV9qhr()
     break
 except:
  pass
def FFnvKh(SELF, setMenuAction=True):
 if setMenuAction:
  global VVQNCe
  VVQNCe = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FF6oMc():
 return ("  %s" % VVQNCe)
def FFKY2X(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FF2A5P(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFXNey(color):
 return parseColor(color).argb()
def FF0Lke(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFfaVA(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFPdRE(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFyIHF(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VV011v)
 else:
  return ""
def FFp6br(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VV06tg, word, VV06tg, VV011v)
 else : return "echo -e '%s\n--- %s\n%s';" % (VV06tg, word, VV06tg)
def FF5Q6H(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VV011v
def FFWBhT(color):
 if color: return "echo -e '%s' %s;" % (VV06tg, FFyIHF(VV06tg, VVvgWJ))
 else : return "echo -e '%s';" % VV06tg
def FFjBJQ(title, color):
 title = "%s\n%s\n%s\n" % (VV06tg, title, VV06tg)
 return FF5Q6H(title, color)
def FF0xrD(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFzmOF(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFsV3D(callBackFunction):
 tCons = CCMduL()
 tCons.ePopen("echo", boundFunction(FFKEsL, callBackFunction))
def FFKEsL(callBackFunction, result, retval):
 callBackFunction()
def FFikZL(SELF, fnc, title="Processing ...", clearMsg=True):
 FFdxmx(SELF, title)
 tCons = CCMduL()
 tCons.ePopen("echo", boundFunction(FFnG4Y, SELF, fnc, clearMsg))
def FFnG4Y(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFdxmx(SELF)
def FFPaF1(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVMIFu
  else       : return ""
def FFo8V2(cmd):
 txt = FFPaF1(cmd)
 if txt:
  txt.strip()
  if "\n" in txt:
   txt = txt.splitlines()
   return list(map(str.strip, txt))
  else:
   return [txt]
 else:
  return []
def FF7GV9(cmd):
 lines = FFo8V2(cmd)
 if lines: return lines[0]
 else : return ""
def FFszcq(SELF, cmd):
 lines = FFo8V2(cmd)
 VVbqDw = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVbqDw.append((key, val))
  elif line:
   VVbqDw.append((line, ""))
 if VVbqDw:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FF8HHs(SELF, None, header=header, VVPIPy=VVbqDw, VVZt3N=widths, VVdfkW=28)
 else:
  FFEkLg(SELF, cmd)
def FFEkLg(    SELF, cmd, **kwargs): SELF.session.open(CCiaT1, VVhenW=cmd, VVv6wd=True, VVGjos=VVmSww, **kwargs)
def FFAkgz(  SELF, cmd, **kwargs): SELF.session.open(CCiaT1, VVhenW=cmd, **kwargs)
def FFMX6s(   SELF, cmd, **kwargs): SELF.session.open(CCiaT1, VVhenW=cmd, VVilYQ=True, VVOQjd=True, VVGjos=VVmSww, **kwargs)
def FF6xaZ(  SELF, cmd, **kwargs): SELF.session.open(CCiaT1, VVhenW=cmd, VVilYQ=True, VVOQjd=True, VVGjos=VVxUhY, **kwargs)
def FFjY30(  SELF, cmd, **kwargs): SELF.session.open(CCiaT1, VVhenW=cmd, VVPAsI=True , **kwargs)
def FF2ODe( SELF, cmd, **kwargs): SELF.session.open(CCiaT1, VVhenW=cmd, VVDbHQ=True   , **kwargs)
def FFnyIj( SELF, cmd, **kwargs): SELF.session.open(CCiaT1, VVhenW=cmd, VVpbux=True  , **kwargs)
def FF3WD3(cmd):
 return cmd + " > /dev/null 2>&1"
def FF0Ztc():
 return " > /dev/null 2>&1"
def FFJyiB(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFyECp(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFJw6G():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FF7GV9(cmd)
VVhCBi     = 0
VVUYN1      = 1
VVuLSB   = 2
VVU6ij      = 3
VVIUZY      = 4
VVFVo9     = 5
VVJjEM     = 6
VVNhZF  = 7
VVMKBv = 8
VVOyEf  = 9
VVRIKQ     = 10
VVvmPf  = 11
VVVLRI  = 12
def FFbwyV(parmNum, grepTxt):
 if   parmNum == VVhCBi  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVUYN1   : param = ["list"   , "apt list" ]
 elif parmNum == VVuLSB: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFJw6G()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FF1oa1(parmNum, package):
 if   parmNum == VVU6ij      : param = ["info"      , "apt show"         ]
 elif parmNum == VVIUZY      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVFVo9     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVJjEM     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVNhZF  : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVMKBv : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVOyEf  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVRIKQ     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVvmPf  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVVLRI  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFJw6G()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFYsPW():
 result = FF7GV9("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FF1oa1(VVJjEM , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FF3WD3("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FF3WD3("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFyIHF(failed1, VVvgWJ))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFyIHF(failed2, VVvgWJ))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFyIHF(failed3, VVDbaf))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFUpCM(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FF1oa1(VVJjEM , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FF3WD3("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFyIHF(failed1, VVvgWJ))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFyIHF(failed2, VVDbaf))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFWcRy(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FF3WD3('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FF3WD3("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FF83qF(path, maxSize=-1):
 from io import open as ioOpen
 encodings = (None, "utf-8", "ISO8859-15", 'iso6937', "windows-1250", "windows-1252")
 txt = ""
 for enc in encodings:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFxmgd(path, keepends=False, maxSize=-1):
 lines = FF83qF(path, maxSize)
 return lines.splitlines(keepends)
def FFOlvf(SELF, path):
 title = os.path.basename(path)
 if fileExists(path):
  fSize = os.path.getsize(path)
  maxSize = 60000
  if (fSize > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFxmgd(path, maxSize=maxSize)
  if lines: FFSnuH(SELF, lines, title=title, VVGjos=VVmSww)
  else : FF0Gb5(SELF, path, title=title)
 else:
  FFAPN6(SELF, path, title)
def FFyuNh(SELF, path, title):
 if fileExists(path):
  txt = FF83qF(path)
  txt = txt.replace("#W#", VV011v)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VViEcp)
  txt = txt.replace("#C#", VVbaBa)
  txt = txt.replace("#P#", VVUqrB)
  FFSnuH(SELF, txt, title=title)
 else:
  FFAPN6(SELF, path, title)
def FFT5aP(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FFoT9I(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFkUaP(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFq2Op(parent)
 else    : return FFDv1k(parent)
def FFu2jr(path):
 try:
  return os.path.getsize(path)
 except:
  return 0
def FFq2Op(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFDv1k(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FF4CZ6():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVnwNP)
 paths.append(VVnwNP.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFoT9I(ba)
 for p in list:
  p = ba + p + VVnwNP
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVGbBr, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVnwNP, VVGbBr , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VV2rzf, VVoMgi = FF4CZ6()
def FFxsSD():
 def VV2wPQ(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 iPath = CFG.iptvHostsPath.getValue()
 if not iPath == VVlZ7S and not pathExists(iPath):
  CFG.iptvHostsPath.setValue(VVlZ7S)
  CFG.iptvHostsPath.save()
  oldIptvHostsPath = VVlZ7S
 else:
  oldIptvHostsPath = ""
 VVXXAF  = VV2wPQ(CFG.backupPath, CCzzpK.VVrRTE())
 VVIi07  = VV2wPQ(CFG.downloadedPackagesPath, t)
 VVkHS2 = VV2wPQ(CFG.exportedTablesPath, t)
 VV8ott = VV2wPQ(CFG.exportedPIconsPath, t)
 VVBSCr  = VV2wPQ(CFG.packageOutputPath, t)
 global VVHCIO
 VVHCIO = FFq2Op(CFG.backupPath.getValue())
 if VVXXAF or VVBSCr or VVIi07 or VVkHS2 or VV8ott or oldIptvHostsPath:
  configfile.save()
 return VVXXAF, VVBSCr, VVIi07, VVkHS2, VV8ott, oldIptvHostsPath
def FF0L3k(path):
 path = FFDv1k(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFbnE7(SELF, pathList, tarFileName, addTimeStamp=True):
 VVPIPy = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVPIPy.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVPIPy.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVPIPy.append(path)
 if not VVPIPy:
  FF2nrW(SELF, "Files not found!")
 elif not pathExists(VVHCIO):
  FF2nrW(SELF, "Path not found!\n\n%s" % VVHCIO)
 else:
  VVVLrl = FFq2Op(VVHCIO)
  tarFileName = "%s%s" % (VVVLrl, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FF8AiB())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVPIPy:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VV06tg
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFyIHF(tarFileName, VV0Tnk))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFyIHF(failed, VV0Tnk))
  cmd += "fi;"
  cmd +=  sep
  FFAkgz(SELF, cmd)
def FFaysk(SELF, title, VVnjxi):
 SELF.session.open(boundFunction(CChofK, Title=title, VVnjxi=VVnjxi))
def FFjQE2(labelObj, VVnjxi):
 if VVnjxi and fileExists(VVnjxi):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VV1YUx(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VV1YUx)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VVnjxi)
   return True
  except:
   pass
 return False
def FFQVWS(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFY3yp(satNum)
  return satName
def FFY3yp(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFHTWG(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFQVWS(val)
  else  : sat = FFY3yp(val)
 return sat
def FFOGxT(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFQVWS(num)
 except:
  pass
 return sat
def FFGigL(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFFuTJ(SELF, isFromSession=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFiV0Z(info, iServiceInformation.sServiceref)
   prov = FFiV0Z(info, iServiceInformation.sProvider)
   state = str(FFiV0Z(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FF7Q2V(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FF2vZ6(refCode)
 return info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFiV0Z(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFwA9I(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFmJHI(refCode):
 info = FFYyoV(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFIZ4H(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFRTaU(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFYyoV(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVNGnm = eServiceCenter.getInstance()
  if VVNGnm:
   info = VVNGnm.info(service)
 return info
def FFKIZZ(SELF, refCode, VVOeQH=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  FFsEEz(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVOeQH:
   FFIUUW(SELF, isFromSession)
 try:
  VVWLmo = InfoBar.instance
  if VVWLmo:
   VVp9th = VVWLmo.servicelist
   if VVp9th:
    servRef = eServiceReference(refCode)
    VVp9th.saveChannel(servRef)
 except:
  pass
def FFsEEz(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFuTJ(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CC04b0()
    if pr.VVo4qE(refCode, chName, decodedUrl, iptvRef):
     pr.VVKDRp(SELF, isFromSession)
def FF7Q2V(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FF2vZ6(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFxclk(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFbI82(userBfile):
 txt = ""
 bFile = VVg7D5 + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVg7D5 + userBfile):
  fTxt = FF83qF(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FF7GV9('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
 return
def FFxclk(url):
 if iUnquote : return iUnquote(url)
 else  : return url
def FF8kZC(url):
 if iQuote : return iQuote(url)
 else  : return url
def FFZqKW(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FF3oSl(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FF8SDW(txt):
 try:
  return FFZqKW(FF3oSl(txt)) == txt
 except:
  return False
def FFIUUW(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFuTJ(SELF, isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCkdPb, isFromExternal=isFromSession)
 else      : FFQwPg(session, reopen=True)
def FFQwPg(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFQwPg, session), CCvsCJ)
  except:
   try:
    FFAIat(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFzKuC(refCode):
 tp = CCj4wy()
 if tp.VVRQJP(refCode) : return True
 else        : return False
def FFK9ce(refCode, isHide):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFhJZy():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FFeLh9():
 VVWLmo = InfoBar.instance
 if VVWLmo:
  VVp9th = VVWLmo.servicelist
  if VVp9th:
   return VVp9th.getBouquetList()
 return None
def FFBWjQ():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFeowy():
 path = FFBWjQ()
 if path:
  txt = FF83qF(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FF6ji1(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVNGnm = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVNGnm.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FFsvLo():
 VV0h7I = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVtuJi = list(VV0h7I)
 return VVtuJi, VV0h7I
def FF80hJ():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFIkMD(session, VVEdR1):
 VVGdae, VVGFyG, VVOdB5, camCommand = FFWTkD()
 if VVGFyG:
  runLog = False
  if   VVEdR1 == CCv9Lb.VVZxH3 : runLog = True
  elif VVEdR1 == CCv9Lb.VVuhR8 : runLog = True
  elif not VVOdB5          : FFAIat(session, message="SoftCam not started yet!")
  elif fileExists(VVOdB5)        : runLog = True
  else             : FFAIat(session, message="File not found !\n\n%s" % VVOdB5)
  if runLog:
   session.open(boundFunction(CCv9Lb, VVGdae=VVGdae, VVGFyG=VVGFyG, VVOdB5=VVOdB5, VVEdR1=VVEdR1))
 else:
  FFAIat(session, message="No active OSCam/NCam found !", title="Live Log")
def FFWTkD():
 VVGdae = "/etc/tuxbox/config/"
 VVGFyG = None
 VVOdB5  = None
 camCommand = FF7GV9("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVGFyG = "oscam"
 elif "ncam"  in camCommand : VVGFyG = "ncam"
 if VVGFyG:
  path = FF7GV9(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFq2Op(path)
  if pathExists(path):
   VVGdae = path
  tFile = VVGdae + VVGFyG + ".conf"
  tFile = FF7GV9("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVOdB5 = tFile
 return VVGdae, VVGFyG, VVOdB5, camCommand
def FFAQH0(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFdno1():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FF8AiB():
 return FFdno1().replace(" ", "_").replace("-", "").replace(":", "")
def FFUwdx(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFDajM():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFj4ge(url, outFile, timeout=3):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCqLir.VV5dpo(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCqLir.VVwKkN(fName)
     phpFile = tmpDir + fName + ext
     os.system(FF3WD3("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFSJyj(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFIc1P(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFPJ7d():
 return int(FFPaF1("cat /proc/meminfo | grep MemFree | awk '{print $2}'"))
def FFHTOM():
 global VV9a8x_TIME, VVjSuI
 VVjSuI  = int(FFPJ7d())
 VV9a8x_TIME = iTime()
def FFzaw7():
 elapsed = iTime() - VV9a8x_TIME
 elapsed = "{:.6f}".format(elapsed).rstrip("0").rstrip(".")
 mem  = FFPJ7d() - VVjSuI
 FFUtlG(">>>>>> Elapsed\t: {} seconds ... Memory\t: {} bytes".format(elapsed, mem))
def FFrerH(SELF, message, title=""):
 SELF.session.open(boundFunction(CCmijH, title=title, message=message, VVVEcz=True))
def FFSnuH(SELF, message, title="", VVGjos=VVmSww, **kwargs):
 SELF.session.open(boundFunction(CCmijH, title=title, message=message, VVGjos=VVGjos, **kwargs))
def FF2nrW(SELF, message, title="")  : FFAIat(SELF.session, message, title)
def FFAPN6(SELF, path, title="") : FFAIat(SELF.session, "File not found !\n\n%s" % path, title)
def FF0Gb5(SELF, path, title="") : FFAIat(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFJSkq(SELF, title="")  : FFAIat(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFAIat(session, message, title="") : session.open(boundFunction(CCutwz, title=title, message=message))
def FFzere(SELF, VVRVdr, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVRVdr, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVRVdr, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVRVdr, boundFunction(CCL3CQ, title=title, message=message, VVckRP=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FF2nrW(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFjphE(SELF, callBack_Yes, VV2i71, callBack_No=None, title="", VVzwqf=False, VVEals=True):
 SELF.session.openWithCallback(boundFunction(FFHu8U, callBack_Yes, callBack_No)
        , boundFunction(CC6QNO, title=title, VV2i71=VV2i71, VVEals=VVEals, VVzwqf=VVzwqf))
def FFHu8U(callBack_Yes, callBack_No, FFjphEed):
 if FFjphEed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFdxmx(SELF, message="", milliSeconds=0):
 try:
  SELF["myInfoBody"].setText(str(message))
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFE7k8(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFTrJK(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVGYth = eTimer()
def FFE7k8(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFkAOw, SELF))
 fnc = boundFunction(FFkAOw, SELF)
 try:
  t = VVGYth.timeout.connect(fnc)
 except:
  VVGYth.callback.append(fnc)
 VVGYth.start(milliSeconds, 1)
def FFkAOw(SELF):
 VVGYth.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FF8HHs(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCJFlR, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCJFlR, **kwargs))
  FFhaOv(win)
  return win
 except:
  return None
def FF4JCK(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCbENj, **kwargs))
 FFhaOv(win)
 return win
def FFFhkT(SELF, **kwargs):
 SELF.session.open(CC9cgb, **kwargs)
def FFiD9O(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   obj = SELF[name]
   SELF[name].instance.setBorderColor(parseColor("#000000"))
   SELF[name].instance.setBorderWidth(3)
   SELF[name].instance.setNoWrap(True)
  except:
   pass
def FFgfbz(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VV20Ap, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFJAKu(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFgfbz(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFkSIV():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FF3Vbc(VVdfkW):
 screenSize  = FFkSIV()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVdfkW)
 return bodyFontSize
def FFx7Im(VVdfkW, extraSpace):
 font = gFont(VV20Ap, VVdfkW)
 VVYdZK = fontRenderClass.getInstance().getLineHeight(font) or (VVdfkW * 1.25)
 return int(VVYdZK + VVYdZK * extraSpace)
def FFWjwm(fontName):
 fList = None
 try:
  from enigma import getFontFaces
  fList = getFontFaces()
 except:
  try:
   from skin import getFontFaces
   fList = getFontFaces()
  except:
   pass
 if fList and fontName in fList : return fontName
 else       : return VV20Ap
def FFXEzn(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFkSIV()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * VVEpGj)
 bodyFontStr  = 'font="%s;%d"' % (VV20Ap, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFx7Im(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VV20Ap, titleFontSize, alignLeftCenter)
 if winType == VVdXwL or winType == VVbuSy:
  if winType == VVbuSy : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVfaAE:
  pass
 elif winType == VVP2Jc:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FFrerHL = b2Left2 + timeW + marginLeft
  FFrerHW = b2Left3 - marginLeft - FFrerHL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FFrerHL  , b2Top, FFrerHW , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00aa7777", "#00aa7777", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
 elif winType == VVtR0a:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVS35S:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVPKsb:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVoWNM:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VV20Ap, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VV20Ap, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVCFB2:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFrerHH = int(bodyH * 0.5)
  inpTop = bodyTop + FFrerHH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFrerHH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VV20Ap, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VV20Ap, mapF, alignCenter)
 elif winType == VVWjru:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVzyq9:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VV20Ap, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVQYBD:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VV20Ap, fontH, alignCenter)
 elif winType == VVUHRS:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VV20Ap, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VV20Ap, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VV20Ap, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VV6Hg0:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 else:
  if   winType == VVUyHt : align = alignLeftCenter
  elif winType == VVDOy7 : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVWDbm:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VV4yLp:
   moreParams = ""
  else:
   fontStr = bodyFontStr
   if usefixedFont and winType == VVDOy7:
    fontStr = 'font="%s;%d"' % (FFWjwm("Fixed"), bodyFontSize)
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" %s %s ' % (bodyColor, fontStr, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVdfkW = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VV20Ap, VVdfkW, alignCenter)
 if topRightBtns > 0:
  btnW = int(ratioW * 80)
  btnH = int(titleH * 0.7)
  btnTop = int(titleH * 0.15)
  btnLeft = width - (btnW + btnTop)
  btnFont = int(btnH * 0.6)
  tmp += '<widget name="keyMenu2F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
  tmp += '<widget name="keyMenu2"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VV20Ap, btnFont, alignCenter)
  if topRightBtns > 1:
   btnLeft = btnLeft - btnW - 8
   tmp += '<widget name="keyMenu1F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="keyMenu1"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VV20Ap, btnFont, alignCenter)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVKZRt = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VV20Ap, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVKZRt[i], VV20Ap, barFont, alignCenter)
   left += btnW + gap
 if winType == VVDOy7:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVKZRt = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVKZRt[i], VV20Ap, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFXEzn(VVdXwL, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.hiddenMenuPass = ""
  self.themsList  = []
  VVRJT5 = []
  if VVsJXJ:
   VVRJT5.append(("-- MY TEST --"    , "myTest"   ))
  VVRJT5.append(("  File Manager"     , "FileManager"  ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("  Services/Channels"    , "ChannelsTools" ))
  VVRJT5.append(("  IPTV"       , "IptvTools"  ))
  VVRJT5.append(("  PIcons"       , "PIconsTools"  ))
  VVRJT5.append(("  SoftCam"      , "SoftCam"   ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("  Plugins"      , "PluginsTools" ))
  VVRJT5.append(("  Terminal"      , "Terminal"  ))
  VVRJT5.append(("  Backup & Restore"    , "BackupRestore" ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("  Date/Time"      , "Date_Time"  ))
  VVRJT5.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVRJT5)
  FFnDik(self, VVRJT5=VVRJT5)
  FFKY2X(self["keyRed"] , "Exit")
  FFKY2X(self["keyGreen"] , "Settings")
  FFKY2X(self["keyYellow"], "Dev. Info.")
  FFKY2X(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VV7a4o       ,
   "yellow"  : self.VVivuJ       ,
   "blue"   : self.VVwIW5       ,
   "info"   : self.VVwIW5       ,
   "last"   : self.VVQtVS      ,
   "next"   : self.VVCRys       ,
   "menu"   : self.VVenhe     ,
   "0"    : boundFunction(self.VVLHaC, 0) ,
   "1"    : boundFunction(self.VVXNpT, 1)   ,
   "2"    : boundFunction(self.VVXNpT, 2)   ,
   "3"    : boundFunction(self.VVXNpT, 3)   ,
   "4"    : boundFunction(self.VVXNpT, 4)   ,
   "5"    : boundFunction(self.VVXNpT, 5)   ,
   "6"    : boundFunction(self.VVXNpT, 6)   ,
   "7"    : boundFunction(self.VVXNpT, 7)   ,
   "8"    : boundFunction(self.VVXNpT, 8)   ,
   "9"    : boundFunction(self.VVXNpT, 9)
  })
  self.onShown.append(self.VVciax)
  self.onClose.append(self.onExit)
  global VV3ToJ, VVD4Tf
  VV3ToJ = VVD4Tf = False
 def VVDa6H(self):
  item = FFnvKh(self)
  self.VVXNpT(item)
 def VVXNpT(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVaRoL()
   elif item in ("FileManager"  , 1) : self.session.open(CCNIug)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCRv1a)
   elif item in ("IptvTools"  , 3) : self.session.open(CCqLir)
   elif item in ("PIconsTools"  , 4) : self.VVzyAu()
   elif item in ("SoftCam"   , 5) : self.session.open(CCvjc6)
   elif item in ("PluginsTools" , 6) : self.session.open(CCbDLI)
   elif item in ("Terminal"  , 7) : self.session.open(CCX20v)
   elif item in ("BackupRestore" , 8) : self.session.open(CCeo0i)
   elif item in ("Date_Time"  , 9) : self.session.open(CCSsQj)
   elif item in ("CheckInternet" , 10) : self.session.open(CCDnMZ)
   else         : self.close()
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  FF0xrD(self["myMenu"])
  FFJAKu(self)
  FFiD9O(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVLiaM)
  self["myTitle"].setText(title)
  VVXXAF, VVBSCr, VVIi07, VVkHS2, VV8ott, oldIptvHostsPath = FFxsSD()
  self.VVm0Ug()
  if VVXXAF or VVBSCr or VVIi07 or VVkHS2 or VV8ott or oldIptvHostsPath:
   VVxNnv = lambda path, subj: "%s:\n%s\n\n" % (subj, FF5Q6H(path, VVDbaf)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVxNnv(oldIptvHostsPath  , "IPTV Hosts Files Path"   )
   txt += VVxNnv(VVXXAF   , "Backup/Restore Path"    )
   txt += VVxNnv(VVBSCr  , "Created Package Files (IPK/DEB)" )
   txt += VVxNnv(VVIi07  , "Download Packages (from feeds)" )
   txt += VVxNnv(VVkHS2 , "Exported Tables"     )
   txt += VVxNnv(VV8ott , "Exported PIcons"     )
   txt += "\nYou can change paths from Settings.\n"
   FFSnuH(self, txt, title="Settings Paths")
  if (EASY_MODE or VVrkVU or VVsJXJ):
   FFfaVA(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFdxmx(self, "Welcome", 300)
  FFsV3D(boundFunction(self.VVYrPc, title))
 def VVYrPc(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCzzpK.VVU1zS()
   if url:
    newWebVer = CCzzpK.VV53JM(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FF3WD3("rm /tmp/ajpanel*"))
 def VVLHaC(self, digit):
  self.hiddenMenuPass += str(digit)
  if len(self.hiddenMenuPass) == 4:
   if self.hiddenMenuPass == "0" * 4:
    global VV3ToJ
    VV3ToJ = True
    FFfaVA(self["myTitle"], "#800080")
   else:
    self.hiddenMenuPass = "x"
 def VVCRys(self):
  self.hiddenMenuPass += ">"
  if self.hiddenMenuPass == "0" * 4 + ">" * 2:
   global VVD4Tf
   VVD4Tf = True
   FFfaVA(self["myTitle"], "#dd5588")
 def VVQtVS(self):
  self.hiddenMenuPass += "<"
  if self.hiddenMenuPass == "0" * 4 + "<" * 2:
   fontFile = "/usr/share/fonts/ae_AlMateen.ttf"
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    color  = "#dd5500"
    try:
     addFont(fontFile, fontName, 100, True)
     FFfaVA(self["myTitle"], color)
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      FFfaVA(self["myTitle"], color)
     except:
      pass
 def VVzyAu(self):
  found = False
  pPath = CCgeLj.VVqTSU()
  if pathExists(pPath):
   for fName, fType in CCgeLj.VVbQGy(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCgeLj)
  else:
   VVRJT5 = []
   VVRJT5.append(("PIcons Manager" , "CCgeLj" ))
   VVRJT5.append(VVn6Em)
   VVRJT5.append(CCgeLj.VVrge0())
   VVRJT5.append(VVn6Em)
   VVRJT5 += CCgeLj.VVjeLw()
   FF4JCK(self, self.VV8y2p, VVRJT5=VVRJT5)
 def VV8y2p(self, item=None):
  if item:
   if   item == "CCgeLj"   : self.session.open(CCgeLj)
   elif item == "VVwywT"  : CCgeLj.VVwywT(self)
   elif item == "VVnIMK"  : CCgeLj.VVnIMK(self)
   elif item == "findPiconBrokenSymLinks" : CCgeLj.VVu4NQ(self, True)
   elif item == "FindAllBrokenSymLinks" : CCgeLj.VVu4NQ(self, False)
 def VV7a4o(self):
  self.session.open(CCzzpK)
 def VVivuJ(self):
  self.session.open(CCFrQO)
 def VVwIW5(self):
  changeLogFile = VVoMgi + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FFxmgd(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FF5Q6H("\n%s\n%s\n%s" % (VV06tg, line, VV06tg), VVUqrB, VV011v)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FF5Q6H(line, VViEcp, VV011v)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFSnuH(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VVLiaM), VVdfkW=26)
 def VVenhe(self):
  VVRJT5 = []
  VVRJT5.append(("Title Colors"   , "title" ))
  VVRJT5.append(("Menu Area Colors"  , "body" ))
  VVRJT5.append(("Menu Pointer Colors" , "cursor" ))
  VVRJT5.append(("Bottom Bar Colors" , "bar"  ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Reset"    , "reset" ))
  FF4JCK(self, self.VVCxrT, VVRJT5=VVRJT5, width=500, title="Main Menu Colors")
 def VVCxrT(self, item=None):
  if item:
   if item == "reset":
    os.system(FF3WD3("rm %s" % self.VVF3Lm()))
    self.close()
   else:
    tDict = self.VVulC3()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VVR39O, tDict, item), CC5fl3, defFG=fg, defBG=bg)
 def VVF3Lm(self):
  return VVHCIO + "ajpanel_colors"
 def VVulC3(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVF3Lm()
  if fileExists(p):
   txt = FF83qF(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVR39O(self, tDict, item, fg, bg):
  if fg:
   self.VVZT27(item, fg)
   self.VVhceP(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVrulU(tDict)
 def VVrulU(self, tDict):
   p = self.VVF3Lm()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVZT27(self, item, fg):
  if   item == "title" : FF0Lke(self["myTitle"], fg)
  elif item == "body"  :
   FF0Lke(self["myMenu"], fg)
   FF0Lke(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFfaVA(self["myBar"], fg)
   FF0Lke(self["keyRed"], fg)
   FF0Lke(self["keyGreen"], fg)
   FF0Lke(self["keyYellow"], fg)
   FF0Lke(self["keyBlue"], fg)
 def VVhceP(self, item, bg):
  if   item == "title" : FFfaVA(self["myTitle"], bg)
  elif item == "body"  :
   FFfaVA(self["myMenu"], bg)
   FFfaVA(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFfaVA(self["myBar"], bg)
 def VVm0Ug(self):
  tDict = self.VVulC3()
  self.VVY4Yw(tDict, "title")
  self.VVY4Yw(tDict, "body")
  self.VVY4Yw(tDict, "cursor")
  self.VVY4Yw(tDict, "bar")
 def VVY4Yw(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVZT27(name, fg)
  if bg: self.VVhceP(name, bg)
 def VVaRoL(self):
  pass
class CCFrQO(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFXEzn(VVdXwL, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVRJT5 = []
  VVRJT5.append(("Settings File"        , "SettingsFile"   ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Box Info"          , "VV49Bx"    ))
  VVRJT5.append(("Tuners Info"         , "VVjuxt"   ))
  VVRJT5.append(("Python Version"        , "VV0Ias"   ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Screen Size"         , "ScreenSize"    ))
  VVRJT5.append(("Locale"          , "Locale"     ))
  VVRJT5.append(("Processor"         , "Processor"    ))
  VVRJT5.append(("Operating System"        , "OperatingSystem"   ))
  VVRJT5.append(("Drivers"          , "drivers"     ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("System Users"         , "SystemUsers"    ))
  VVRJT5.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVRJT5.append(("Uptime"          , "Uptime"     ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Host Name"         , "HostName"    ))
  VVRJT5.append(("MAC Address"         , "MACAddress"    ))
  VVRJT5.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVRJT5.append(("Network Status"        , "NetworkStatus"   ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Disk Usage"         , "VVJwZq"    ))
  VVRJT5.append(("Mount Points"         , "MountPoints"    ))
  VVRJT5.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVRJT5.append(("USB Devices"         , "USB_Devices"    ))
  VVRJT5.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVRJT5.append(("Directory Size"        , "DirectorySize"   ))
  VVRJT5.append(("Memory"          , "Memory"     ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVRJT5.append(("Running Processes"       , "RunningProcesses"  ))
  VVRJT5.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFnDik(self, VVRJT5=VVRJT5, title="Device Information")
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  FF0xrD(self["myMenu"])
  FFJAKu(self)
 def VVDa6H(self):
  global VVQNCe
  VVQNCe = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCq72K)
   elif item == "VV49Bx"    : self.VV49Bx()
   elif item == "VVjuxt"   : self.VVjuxt()
   elif item == "VV0Ias"   : self.VV0Ias()
   elif item == "ScreenSize"    : FFSnuH(self, "Width\t: %s\nHeight\t: %s" % (FFkSIV()[0], FFkSIV()[1]))
   elif item == "Locale"     : self.VV8bRd()
   elif item == "Processor"    : self.VVC0gZ()
   elif item == "OperatingSystem"   : FFEkLg(self, "uname -a"        )
   elif item == "drivers"     : self.VVTBLk()
   elif item == "SystemUsers"    : FFEkLg(self, "id"          )
   elif item == "LoggedInUsers"   : FFEkLg(self, "who -a"         )
   elif item == "Uptime"     : FFEkLg(self, "uptime"         )
   elif item == "HostName"     : FFEkLg(self, "hostname"        )
   elif item == "MACAddress"    : self.VVYI2x()
   elif item == "NetworkConfiguration"  : FFEkLg(self, "ifconfig %s %s" % (FFyIHF("HWaddr", VVkwvG), FFyIHF("addr:", VVvgWJ)))
   elif item == "NetworkStatus"   : FFEkLg(self, "netstat -tulpn"       )
   elif item == "VVJwZq"    : self.VVJwZq()
   elif item == "MountPoints"    : FFEkLg(self, "mount %s" % (FFyIHF(" on ", VVvgWJ)))
   elif item == "FileSystemTable"   : FFEkLg(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFEkLg(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFEkLg(self, "blkid"         )
   elif item == "DirectorySize"   : FFEkLg(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VV3iCe="Reading size ...")
   elif item == "Memory"     : FFEkLg(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVbJmn()
   elif item == "RunningProcesses"   : FFEkLg(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFEkLg(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVzY2s()
   else         : self.close()
 def VVYI2x(self):
  res = FFPaF1("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFSnuH(self, txt)
  else:
   FFEkLg(self, "ip link")
 def VVBaEt(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFo8V2(cmd)
  return lines
 def VVndX6(self, lines, headerRepl, widths, VVJRZ2):
  VVbqDw = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVbqDw.append(parts)
  if VVbqDw and len(header) == len(widths):
   VVbqDw.sort(key=lambda x: x[0].lower())
   FF8HHs(self, None, header=header, VVPIPy=VVbqDw, VVJRZ2=VVJRZ2, VVZt3N=widths, VVdfkW=28, VV9Auz=True)
   return True
  else:
   return False
 def VVJwZq(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VVBaEt(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVJRZ2 = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VVndX6(lines, headerRepl, widths, VVJRZ2)
  if not allOK:
   lines = FFo8V2(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFDv1k(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VV0Tnk:
     note = "\n%s" % FF5Q6H("Green = Mounted Partitions", VV0Tnk)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVvgWJ
     elif line.endswith(mountList) : color = VV0Tnk
     else       : color = VViEcp
     txt += FF5Q6H(line, color) + "\n"
    FFSnuH(self, txt + note)
   else:
    FF2nrW(self, "Not data from system !")
 def VVbJmn(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVBaEt(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVJRZ2 = (LEFT , CENTER, LEFT )
  allOK = self.VVndX6(lines, headerRepl, widths, VVJRZ2)
  if not allOK:
   FFEkLg(self, cmd)
 def VV8bRd(self):
  from locale import getdefaultlocale
  loc = getdefaultlocale()
  FFSnuH(self, "Language\t: %s\nEncoding\t: %s" % (loc[0], loc[1]))
 def VVTBLk(self):
  cmd = FFbwyV(VVuLSB, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFEkLg(self, cmd)
  else : FFJSkq(self)
 def VVC0gZ(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFEkLg(self, cmd)
 def VVzY2s(self):
  cmd = FFbwyV(VVUYN1, "| grep secondstage")
  if cmd : FFEkLg(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFJSkq(self)
 def VV49Bx(self):
  c = VV0Tnk
  VVPIPy = []
  VVPIPy.append((FF5Q6H("Box Type"  , c), FF5Q6H(self.VVz2fw("boxtype").upper(), c)))
  VVPIPy.append((FF5Q6H("Board Version", c), FF5Q6H(self.VVz2fw("board_revision") , c)))
  VVPIPy.append((FF5Q6H("Chipset"  , c), FF5Q6H(self.VVz2fw("chipset")  , c)))
  VVPIPy.append((FF5Q6H("S/N"   , c), FF5Q6H(self.VVz2fw("sn")    , c)))
  VVPIPy.append((FF5Q6H("Version"  , c), FF5Q6H(self.VVz2fw("version")  , c)))
  VVnY7k   = []
  VVPpBZ = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVPpBZ = SystemInfo[key]
     else:
      VVnY7k.append((FF5Q6H(str(key), VVbaBa), FF5Q6H(str(SystemInfo[key]), VVbaBa)))
  except:
   pass
  if VVPpBZ:
   VVA5cn = self.VVO7S1(VVPpBZ)
   if VVA5cn:
    VVA5cn.sort(key=lambda x: x[0].lower())
    VVPIPy += VVA5cn
  if VVnY7k:
   VVnY7k.sort(key=lambda x: x[0].lower())
   VVPIPy += VVnY7k
  if VVPIPy:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FF8HHs(self, None, header=header, VVPIPy=VVPIPy, VVZt3N=widths, VVdfkW=28, VV9Auz=True)
  else:
   FFSnuH(self, "Could not read info!")
 def VVz2fw(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFxmgd(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVO7S1(self, mbDict):
  try:
   mbList = list(mbDict)
   VVPIPy = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVPIPy.append((FF5Q6H(subject, VVvgWJ), FF5Q6H(value, VVvgWJ)))
  except:
   pass
  return VVPIPy
 def VVjuxt(self):
  txt = self.VVyVUl("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVyVUl("/proc/bus/nim_sockets")
  if not txt: txt = self.VVxlPx()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFSnuH(self, txt)
 def VVxlPx(self):
  txt = ""
  VVxNnv = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVxNnv("Slot Name" , slot.getSlotName())
     txt += FF5Q6H(slotName, VVvgWJ)
     txt += VVxNnv("Description"  , slot.getFullDescription())
     txt += VVxNnv("Frontend ID"  , slot.frontend_id)
     txt += VVxNnv("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVyVUl(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFxmgd(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FF5Q6H(line, VVvgWJ)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VV0Ias(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFSnuH(self, txt)
class CCq72K(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFXEzn(VVdXwL, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVRJT5 = []
  VVRJT5.append(("Settings (All)"   , "Settings_All"   ))
  VVRJT5.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVRJT5.append(("Settings (FHDG-17)"  , "Settings_FHDG_17"  ))
  VVRJT5.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVRJT5.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVRJT5.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVRJT5.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVRJT5.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFnDik(self, VVRJT5=VVRJT5)
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  FF0xrD(self["myMenu"])
  FFJAKu(self)
 def VVDa6H(self):
  global VVQNCe
  VVQNCe = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFEkLg(self, cmd                )
   elif item == "Settings_HotKeys"   : FFEkLg(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFEkLg(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFEkLg(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFEkLg(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFEkLg(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFEkLg(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFEkLg(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCvjc6(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFXEzn(VVdXwL, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVGdae, VVGFyG, VVOdB5, camCommand = FFWTkD()
  self.VVGFyG = VVGFyG
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVRJT5 = []
  VVRJT5.append(("OSCam Files"        , "OSCamFiles"  ))
  VVRJT5.append(("NCam Files"        , "NCamFiles"  ))
  VVRJT5.append(("CCcam Files"        , "CCcamFiles"  ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVRJT5.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVRJT5.append(VVn6Em)
  if VVGFyG:
   if   "oscam" in VVGFyG : camName = "OSCam"
   elif "ncam"  in VVGFyG : camName = "NCam"
   VVRJT5.append((camName + " Info."      , "camInfo"   ))
   VVRJT5.append((camName + " Live Status"    , "camLiveStatus" ))
   VVRJT5.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVRJT5.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVRJT5.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFnDik(self, VVRJT5=VVRJT5)
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  FF0xrD(self["myMenu"])
  FFJAKu(self)
 def VVDa6H(self):
  global VVQNCe
  VVQNCe = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCZRJ8, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCZRJ8, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCZRJ8, "cccam"))
   elif item == "OSCamReaders"  : self.VVhodY("os")
   elif item == "NSCamReaders"  : self.VVhodY("n")
   elif item == "camInfo"   : FFszcq(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFIkMD(self.session, CCv9Lb.VVZxH3)
   elif item == "camLiveReaders" : FFIkMD(self.session, CCv9Lb.VVuhR8)
   elif item == "camLiveLog"  : FFIkMD(self.session, CCv9Lb.VVoJum)
   else       : self.close()
 def VVhodY(self, camPrefix):
  VVbqDw = self.VVMab2(camPrefix)
  if VVbqDw:
   VVbqDw.sort(key=lambda x: int(x[0]))
   if self.VVGFyG and self.VVGFyG.startswith(camPrefix):
    VVg6wQ = ("Toggle State", self.VVhYcU, [camPrefix], "Changing State ...")
   else:
    VVg6wQ = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVJRZ2  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FF8HHs(self, None, header=header, VVPIPy=VVbqDw, VVJRZ2=VVJRZ2, VVZt3N=widths, VVdfkW=26, VVg6wQ=VVg6wQ, VVSFYp=True)
 def VVMab2(self, camPrefix):
  readersFile = self.VVGdae + camPrefix + "cam.server"
  VVbqDw = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFxmgd(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVbqDw.append((str(len(VVbqDw) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVbqDw:
    FF2nrW(self, "No readers found !")
  else:
   FFAPN6(self, readersFile)
  return VVbqDw
 def VVhYcU(self, VVkjiR, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVGdae, camPrefix)
  readerState  = VVkjiR.VVfyIm(1)
  readerLabel  = VVkjiR.VVfyIm(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCvjc6.VVhzj0(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVkjiR.VVGwFc()
    FF2nrW(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVbqDw = self.VVMab2(camPrefix)
   if VVbqDw:
    VVkjiR.VVRlUS(VVbqDw)
 @staticmethod
 def VVhzj0(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFxmgd(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FF2nrW(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FF2nrW(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFAPN6(SELF, confFile)
   return None
  if not iRequest:
   FF2nrW(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FF2nrW(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FF2nrW(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCZRJ8(Screen):
 def __init__(self, VVK5aQ, session, args=0):
  self.skin, self.skinParam = FFXEzn(VVdXwL, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVGdae, VVGFyG, VVOdB5, camCommand = FFWTkD()
  if   VVK5aQ == "ncam" : self.prefix = "n"
  elif VVK5aQ == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVRJT5 = []
  if self.prefix == "":
   VVRJT5.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVRJT5.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVRJT5.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVRJT5.append(("constant.cw"         , "x_constant_cw" ))
   VVRJT5.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVRJT5.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVRJT5.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVRJT5.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVRJT5.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVRJT5.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVRJT5.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVRJT5.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVRJT5.append(VVn6Em)
   VVRJT5.append(("SoftCam.Key"         , "x_SoftCam_Key" ))
   VVRJT5.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVRJT5.append(VVn6Em)
   VVRJT5.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVRJT5.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVRJT5.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFnDik(self, VVRJT5=VVRJT5)
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  FF0xrD(self["myMenu"])
  FFJAKu(self)
 def VVDa6H(self):
  global VVQNCe
  VVQNCe = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFOlvf(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFOlvf(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFOlvf(self, self.VVGdae + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFOlvf(self, self.VVGdae + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VV8j0b("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VV8j0b("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VV8j0b("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VV8j0b("cam.provid"        )
   elif item == "x_cam_server"  : self.VV8j0b("cam.server"        )
   elif item == "x_cam_services" : self.VV8j0b("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VV8j0b("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VV8j0b("cam.user"        )
   elif item == "x_VV06tg"   : pass
   elif item == "x_SoftCam_Key" : FFOlvf(self, self.VVGdae + "SoftCam.Key"   )
   elif item == "x_CCcam_cfg"  : FFOlvf(self, self.VVGdae + "CCcam.cfg"    )
   elif item == "x_VV06tg"   : pass
   elif item == "x_cam_log"  : FFOlvf(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFOlvf(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFOlvf(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VV8j0b(self, fileName):
  FFOlvf(self, self.VVGdae + self.prefix + fileName)
class CCv9Lb(Screen):
 VVZxH3  = 0
 VVuhR8 = 1
 VVoJum = 2
 def __init__(self, session, VVGdae="", VVGFyG="", VVOdB5="", VVEdR1=VVZxH3):
  self.skin, self.skinParam = FFXEzn(VVDOy7, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVOdB5   = VVOdB5
  self.VVEdR1  = VVEdR1
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVGdae + VVGFyG + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVGFyG : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVGdae, self.camPrefix)
  if self.VVEdR1 == self.VVZxH3:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVEdR1 == self.VVuhR8:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFnDik(self, self.Title, addScrollLabel=True)
  FFKY2X(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VV7gt3
  self.onShown.append(self.VVciax)
  self.onClose.append(self.onExit)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  self["myLabel"].VVOdRf(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFiD9O(self)
  self.VV7gt3()
 def onExit(self):
  self.timer.stop()
 def VV48bH(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVb3Uf)
  except:
   self.timer.callback.append(self.VVb3Uf)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFdxmx(self, "Started", 1000)
 def VV8GVz(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVb3Uf)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFdxmx(self, "Stopped", 1000)
 def VV7gt3(self):
  if self.timerRunning:
   self.VV8GVz()
  else:
   self.VV48bH()
   if self.VVEdR1 == self.VVZxH3 or self.VVEdR1 == self.VVuhR8:
    if self.VVEdR1 == self.VVZxH3 : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCvjc6.VVhzj0(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFsV3D(self.VVcVDT)
    else:
     self.close()
   else:
    self.VVbcGZ()
 def VVb3Uf(self):
  if self.timerRunning:
   if   self.VVEdR1 == self.VVZxH3 : self.VVpcUY()
   elif self.VVEdR1 == self.VVuhR8 : self.VVpcUY()
   else            : self.VVbcGZ()
 def VVbcGZ(self):
  if fileExists(self.VVOdB5):
   fTime = FFAQH0(os.path.getmtime(self.VVOdB5))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVvwZq(), VVGjos=VVxUhY)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVOdB5)
 def VVcVDT(self):
  self.VVpcUY()
 def VVpcUY(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FF5Q6H("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVUqrB))
   self.camWebIfErrorFound = True
   self.VV8GVz()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVEdR1 == self.VVZxH3 : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FF5Q6H("Error while parsing data elements !\n\nError = %s" % str(e), VVDbaf)
   self.camWebIfErrorFound = True
   self.VV8GVz()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVBM0q(root)
  self["myLabel"].setText(txt, VVGjos=VVxUhY)
  self["myBar"].setText("Last Update : %s" % FFdno1())
 def VVBM0q(self, rootElement):
  def VVxNnv(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVEdR1 == self.VVZxH3:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FF5Q6H(status, VV0Tnk)
    else          : status = FF5Q6H(status, VVDbaf)
    txt += VV06tg + "\n"
    txt += VVxNnv("Name"  , name)
    txt += VVxNnv("Description" , desc)
    txt += VVxNnv("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVxNnv("Protocol" , protocol)
    txt += VVxNnv("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FF5Q6H("Yes", VV0Tnk)
    else    : enabTxt = FF5Q6H("No", VVDbaf)
    txt += VV06tg + "\n"
    txt += VVxNnv("Label"  , label)
    txt += VVxNnv("Protocol" , protocol)
    txt += VVxNnv("Enabled" , enabTxt)
  return txt
 def VVvwZq(self):
  wordsDict = self.VVDZg9()
  color = [ VVvgWJ, VVkwvG, VV0Tnk, VVDbaf, VVbaBa, VVlVvm]
  lines = FFo8V2("tail -n %d %s" % (100, self.VVOdB5))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVUqrB + line[:19] + VViEcp + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VV011v + line[ndx + 3:] + VViEcp
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVvgWJ + line[ndx + 8 : ndx1 + 4] + VViEcp + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VViEcp)
   elif line.startswith("----") or ">>" in line:
    line = FF5Q6H(line, VVvgWJ)
   txt += line + "\n"
  return txt
 def VVDZg9(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFxmgd(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCeo0i(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFXEzn(VVdXwL, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVRJT5 = []
  VVRJT5.append(("Backup Channels"        , "VVIjP7"   ))
  VVRJT5.append(("Restore Channels"        , "Restore_Channels"  ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Backup SoftCAM Files"       , "VVJsfD" ))
  VVRJT5.append(("Restore SoftCAM Files"      , "Restore_SoftCAM_Files" ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Backup Tuner Settings"      , "Backup_TunerDiSEqC"  ))
  VVRJT5.append(("Restore Tuner Settings"      , "Restore_TunerDiSEqC"  ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Backup HotKeys & FHDG17 Settings"    , "Backup_Hotkey_FHDG17" ))
  VVRJT5.append(("Restore HotKeys & FHDG17 Settings"   , "Restore_Hotkey_FHDG17" ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Backup Network Settings"      , "VVrhTr"   ))
  VVRJT5.append(("Restore Network Settings"      , "Restore_Network"   ))
  if VVD4Tf:
   VVRJT5.append(VVn6Em)
   VVRJT5.append((VVUqrB + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME , "VVrB0r"   ))
   VVRJT5.append((VV0Tnk + "2- Create %s for IPK"   % PLUGIN_NAME , "createMyIpk"   ))
   VVRJT5.append((VV0Tnk + "3- Create %s for DEB"   % PLUGIN_NAME , "createMyDeb"   ))
   VVRJT5.append((VVbaBa + "Create %s TAR (Absolute Path)" % PLUGIN_NAME , "createMyTar"   ))
   VVRJT5.append((VVbaBa + "Decode %s Crash Report"   % PLUGIN_NAME , "VVrm5N" ))
  FFnDik(self, VVRJT5=VVRJT5)
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  FF0xrD(self["myMenu"])
  FFJAKu(self)
 def VVDa6H(self):
  global VVQNCe
  VVQNCe = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVIjP7"    : self.VVIjP7()
   elif item == "Restore_Channels"    : self.VVTzEI("channels_backup*.tar.gz", self.VVWgxE)
   elif item == "VVJsfD"   : self.VVJsfD()
   elif item == "Restore_SoftCAM_Files"  : self.VVTzEI("softcam_backup*.tar.gz", self.VVrYra)
   elif item == "Backup_TunerDiSEqC"   : self.VVvH4p("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVTzEI("tuner_backup*.backup", boundFunction(self.VVSH8a, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVvH4p("hotkey_fhdg17_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVTzEI("hotkey_fhdg17_backup*.backup", boundFunction(self.VVSH8a, "misc"))
   elif item == "VVrhTr"    : self.VVrhTr()
   elif item == "Restore_Network"    : self.VVTzEI("network_backup*.tar.gz", self.VVFYVU)
   elif item == "VVrB0r"     : FFjphE(self, boundFunction(FFikZL, self, boundFunction(CCeo0i.VVrB0r, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVjPRF(False)
   elif item == "createMyDeb"     : self.VVjPRF(True)
   elif item == "createMyTar"     : self.VVH9XZ()
   elif item == "VVrm5N"   : self.VVrm5N()
 @staticmethod
 def VVrB0r(SELF):
  OBF_Path = VV2rzf + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VV2rzf, VVLiaM, VVPQwH)
   if err : FF2nrW(SELF, err)
   else : FFSnuH(SELF, txt)
  else:
   FFAPN6(SELF, OBF_Path)
 def VVjPRF(self, VVCSkY):
  OBF_Path = VV2rzf + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FF2nrW(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VV2rzf)
  os.system("mv -f %s %s" % (VV2rzf + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VV2rzf + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VV2rzf + "plugin.py"))
  self.session.openWithCallback(self.VVjPRF1, boundFunction(CCFLqD, path=VV2rzf, VVCSkY=VVCSkY))
 def VVjPRF1(self):
  os.system("mv -f %s %s" % (VV2rzf + "OBF/main.py"  , VV2rzf))
  os.system("mv -f %s %s" % (VV2rzf + "OBF/plugin.py" , VV2rzf))
 def VVrm5N(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FF2nrW(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FF2nrW(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVE2sb("%s*.list" % path)
  if err:
   FFAPN6(self, path + "*.list")
   return
  srcF, err = self.VVE2sb("%s*main_final.py" % path)
  if err:
   FFAPN6(self, path + "*.final.py")
   return
  VVPIPy = []
  for f in files:
   f = os.path.basename(f)
   VVPIPy.append((f, f))
  FF4JCK(self, boundFunction(self.VVsTrL, path, codF, srcF), VVRJT5=VVPIPy)
 def VVsTrL(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFAPN6(self, logF)
   else     : FFikZL(self, boundFunction(self.VVgcx3, logF, codF, srcF))
 def VVgcx3(self, logF, codF, srcF):
  lst  = []
  lines = FFxmgd(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FF2nrW(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVrI47(lst, logF, newLogF)
  totSrc  = self.VVrI47(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFSnuH(self, txt)
 def VVE2sb(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVrI47(self, lst, f1, f2):
  txt = FF83qF(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVH9XZ(self):
  VVPIPy = []
  VVPIPy.append("%s%s" % (VV2rzf, "*.py"))
  VVPIPy.append("%s%s" % (VV2rzf, "*.png"))
  VVPIPy.append("%s%s" % (VV2rzf, "*.xml"))
  VVPIPy.append("%s"  % (VVoMgi))
  FFbnE7(self, VVPIPy, "%s_%s" % (PLUGIN_NAME, VVLiaM), addTimeStamp=False)
 def VVIjP7(self):
  path1 = VVg7D5
  path2 = "/etc/tuxbox/"
  VVPIPy = []
  VVPIPy.append("%s%s" % (path1, "*.tv"))
  VVPIPy.append("%s%s" % (path1, "*.radio"))
  VVPIPy.append("%s%s" % (path1, "*list"))
  VVPIPy.append("%s%s" % (path1, "lamedb*"))
  VVPIPy.append("%s%s" % (path2, "*.xml"))
  FFbnE7(self, VVPIPy, "channels_backup", addTimeStamp=True)
 def VVJsfD(self):
  VVPIPy = []
  VVPIPy.append("/etc/tuxbox/config/")
  VVPIPy.append("/usr/keys/")
  VVPIPy.append("/usr/scam/")
  VVPIPy.append("/etc/CCcam.cfg")
  FFbnE7(self, VVPIPy, "softcam_backup", addTimeStamp=True)
 def VVrhTr(self):
  VVPIPy = []
  VVPIPy.append("/etc/hostname")
  VVPIPy.append("/etc/default_gw")
  VVPIPy.append("/etc/resolv.conf")
  VVPIPy.append("/etc/wpa_supplicant*.conf")
  VVPIPy.append("/etc/network/interfaces")
  VVPIPy.append("/etc/enigma2/nameserversdns.conf")
  FFbnE7(self, VVPIPy, "network_backup", addTimeStamp=True)
 def VVWgxE(self, fileName):
  if fileName:
   FFjphE(self, boundFunction(self.VVhMTc, fileName), "Overwrite current channels ?")
 def VVhMTc(self, fileName):
  path = "%s%s" % (VVHCIO, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCRv1a.VVQg9w()
   lamedb5File, diabled5File = CCRv1a.VV0aLe()
   cmd = ""
   cmd += FF3WD3("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FF3WD3("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFhJZy()
   if res == 0 : FFrerH(self, "Channels Restored.")
   else  : FF2nrW(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFAPN6(self, path)
 def VVrYra(self, fileName):
  if fileName:
   FFjphE(self, boundFunction(self.VVF0xC, fileName), "Overwrite SoftCAM files ?")
 def VVF0xC(self, fileName):
  fileName = "%s%s" % (VVHCIO, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VV06tg
   note = "You may need to restart your SoftCAM."
   FF6xaZ(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFyIHF(note, VVvgWJ), sep))
  else:
   FFAPN6(self, fileName)
 def VVFYVU(self, fileName):
  if fileName:
   FFjphE(self, boundFunction(self.VVA5fU, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVA5fU(self, fileName):
  fileName = "%s%s" % (VVHCIO, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFjY30(self,  cmd)
  else:
   FFAPN6(self, fileName)
 def VVTzEI(self, pattern, callBackFunction, isTuner=False):
  title = FF6oMc()
  if pathExists(VVHCIO):
   myFiles = iGlob("%s%s" % (VVHCIO, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVPIPy = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVPIPy.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVZZ8a = ("Sat. List", self.VVlWrV)
    else  : VVZZ8a = None
    FF4JCK(self, callBackFunction, title=title, VVRJT5=VVPIPy, VVZZ8a=VVZZ8a)
   else:
    FF2nrW(self, "No files found in:\n\n%s" % VVHCIO, title)
  else:
   FF2nrW(self, "Path not found:\n\n%s" % VVHCIO, title)
 def VVvH4p(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCMduL()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VVthGn, filePrefix))
 def VVthGn(self, filePrefix, result, retval):
  title = FF6oMc()
  if pathExists(VVHCIO):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FF2nrW(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVHCIO, filePrefix, FF8AiB())
    try:
     VVPIPy = str(result.strip()).split()
     if VVPIPy:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVPIPy:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VV06tg, FF5Q6H(fName, VVvgWJ), VV06tg)
       FFSnuH(self, txt, title=title, VVGjos=VVxUhY)
      else:
       FF2nrW(self, "File creation failed!", title)
     else:
      FF2nrW(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FF3WD3("rm %s" % fName))
     FF2nrW(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FF3WD3("rm %s" % fName))
     FF2nrW(self, "Error while writing file.")
  else:
   FF2nrW(self, "Path not found:\n\n%s" % VVHCIO, title)
 def VVSH8a(self, mode, path):
  if path:
   path = "%s%s" % (VVHCIO, path)
   if fileExists(path):
    lines = FFxmgd(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys/FHDG17"
     FFjphE(self, boundFunction(self.VVnQga, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FF0Gb5(self, path, title=FF6oMc())
   else:
    FFAPN6(self, path)
 def VVnQga(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVhenW = []
  VVhenW.append("echo -e 'Reading current settings ...'")
  VVhenW.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVhenW.append("echo -e 'Preparing new settings ...'")
  VVhenW.append(settingsLines)
  VVhenW.append("echo -e 'Applying new settings ...'")
  VVhenW.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFnyIj(self, VVhenW)
 def VVlWrV(self, VVw3blObj, path):
  if not path:
   return
  path = VVHCIO + path
  if not fileExists(path):
   FFAPN6(self, path)
   return
  txt = FF83qF(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVPIPy  = []
   for item in satList:
    VVPIPy.append("%s\t%s" % (item[0], FFQVWS(item[1])))
   FFSnuH(self, VVPIPy, title="  Satellites List")
  else:
   FF2nrW(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCbDLI(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFXEzn(VVdXwL, 850, 700, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVRJT5 = []
  VVRJT5.append(("Plugins Browser List"       , "VVXI0P"   ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVRJT5.append(("Remove Packages (show all)"     , "VVSqb4sAll"   ))
  VVRJT5.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Update List of Available Packages"   , "VVHcQd"   ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Packaging Tool"        , "VV40LM"    ))
  VVRJT5.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFnDik(self, VVRJT5=VVRJT5)
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  FF0xrD(self["myMenu"])
  FFJAKu(self)
 def VVDa6H(self):
  global VVQNCe
  VVQNCe = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVXI0P"   : self.VVXI0P()
   elif item == "pluginsDirList"    : self.VV1X6h()
   elif item == "downloadInstallPackages"  : FFikZL(self, boundFunction(self.VVj724, 0, ""))
   elif item == "VVSqb4sAll"   : FFikZL(self, boundFunction(self.VVj724, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFikZL(self, boundFunction(self.VVj724, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVHcQd"   : self.VVHcQd()
   elif item == "VV40LM"    : self.VV40LM()
   elif item == "packagesFeeds"    : self.VVekvt()
   else          : self.close()
 def VV1X6h(self):
  extDirs  = FFoT9I(VVnwNP)
  sysDirs  = FFoT9I(VVTuBV)
  VVPIPy  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVPIPy.append((item, VVnwNP + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVPIPy.append((item, VVTuBV + item))
  if VVPIPy:
   VVPIPy = sorted(VVPIPy, key=lambda x: x[0].lower())
   VV4CnB = ("Package Info.", self.VVy5WE, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FF8HHs(self, None, header=header, VVPIPy=VVPIPy, VVZt3N=widths, VVdfkW=28, VV4CnB=VV4CnB)
  else:
   FF2nrW(self, "Nothing found!")
 def VVy5WE(self, VVkjiR, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVnwNP) : loc = "extensions"
  elif path.startswith(VVTuBV) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVwZmk(package)
  else:
   FF2nrW(self, "No info!")
 def VVekvt(self):
  pkg = FFJw6G()
  if pkg : FFEkLg(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFJSkq(self)
 def VVXI0P(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVxNnv(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VV06tg + "\n"
    txt += VVxNnv("Number"   , str(c))
    txt += VVxNnv("Name"   , FF5Q6H(str(p.name), VVvgWJ))
    txt += VVxNnv("Path"  , p.path  )
    txt += VVxNnv("Description" , p.description )
    txt += VVxNnv("Icon"  , p.iconstr  )
    txt += VVxNnv("Wakeup Fnc" , p.wakeupfnc )
    txt += VVxNnv("NeedsRestart", p.needsRestart)
    txt += VVxNnv("Internal" , p.internal )
    txt += VVxNnv("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFSnuH(self, txt)
 def VVHcQd(self):
  cmd = FFbwyV(VVhCBi, "")
  if cmd : FFjY30(self, cmd, checkNetAccess=True)
  else : FFJSkq(self)
 def VV40LM(self):
  pkg = FFJw6G()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFrerH(self, txt)
 def VVj724(self, mode, grep, VVkjiR=None, title=""):
  if   mode == 0: cmd = FFbwyV(VVUYN1    , grep)
  elif mode == 1: cmd = FFbwyV(VVuLSB , grep)
  elif mode == 2: cmd = FFbwyV(VVuLSB , grep)
  if not cmd:
   FFJSkq(self)
   return
  VVbqDw = FFo8V2(cmd)
  if not VVbqDw:
   if VVkjiR: VVkjiR.VVGwFc()
   FF2nrW(self, "No packages found!")
   return
  elif len(VVbqDw) == 1 and VVbqDw[0] == VVMIFu:
   FF2nrW(self, VVMIFu)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVPIPy  = []
  for item in VVbqDw:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVPIPy.append((name, package, version))
  if mode > 0:
   extensions = FFo8V2("ls %s -l | grep '^d' | awk '{print $9}'" % VVnwNP)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVPIPy:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVPIPy.append((name, VVnwNP + item, "-"))
   systemPlugins = FFo8V2("ls %s -l | grep '^d' | awk '{print $9}'" % VVTuBV)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVPIPy:
      if item.lower() == row[0].lower():
       break
     else:
      VVPIPy.append((item, VVTuBV + item, "-"))
  if not VVPIPy:
   FF2nrW(self, "No packages found!")
   return
  if VVkjiR:
   VVPIPy.sort(key=lambda x: x[0].lower())
   VVkjiR.VVRlUS(VVPIPy, title)
  else:
   widths = (20, 50, 30)
   VVg6wQ = None
   VVqvqX = None
   if mode == 0:
    VVRPnY = ("Install" , self.VVUzjg   , [])
    VVg6wQ = ("Download" , self.VV58bS   , [])
    VVqvqX = ("Filter"  , self.VVlmnx , [])
   elif mode == 1:
    VVRPnY = ("Uninstall", self.VVSqb4, [])
   elif mode == 2:
    VVRPnY = ("Uninstall", self.VVSqb4, [])
    widths= (18, 57, 25)
   VVPIPy = sorted(VVPIPy, key=lambda x: x[0].lower())
   VV4CnB = ("Package Info.", self.VVNzih, [])
   header   = ("Name" ,"Package" , "Version" )
   FF8HHs(self, None, header=header, VVPIPy=VVPIPy, VVZt3N=widths, VVdfkW=28, VVRPnY=VVRPnY, VVg6wQ=VVg6wQ, VV4CnB=VV4CnB, VVqvqX=VVqvqX, VV48q3=self.lastSelectedRow
     , VVgzpW="#22110011", VVTK1M="#22191111", VVKZRt="#22191111", VVPQde="#00003030", VVXHiK="#00333333")
 def VVNzih(self, VVkjiR, title, txt, colList):
  package = colList[1]
  self.VVwZmk(package)
 def VVlmnx(self, VVkjiR, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVRJT5 = []
  VVRJT5.append(("All Packages", "all"))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVRJT5.append(VVn6Em)
  for word in words:
   VVRJT5.append((word, word))
  FF4JCK(self, boundFunction(self.VVlzNu, VVkjiR), VVRJT5=VVRJT5, title="Select Filter")
 def VVlzNu(self, VVkjiR, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFikZL(VVkjiR, boundFunction(self.VVj724, 0, grep, VVkjiR, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVSqb4(self, VVkjiR, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVnwNP, VVTuBV)):
   FFjphE(self, boundFunction(self.VVrjet, VVkjiR, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVRJT5 = []
   VVRJT5.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVRJT5.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVRJT5.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FF4JCK(self, boundFunction(self.VV6Zeb, VVkjiR, package), VVRJT5=VVRJT5)
 def VVrjet(self, VVkjiR, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVm2pM)
  FFjY30(self, cmd, VVFQVU=boundFunction(self.VVlqdb, VVkjiR))
 def VV6Zeb(self, VVkjiR, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVRIKQ
   elif item == "remove_ForceRemove"  : cmdOpt = VVvmPf
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVVLRI
   FFjphE(self, boundFunction(self.VVjJuE, VVkjiR, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVjJuE(self, VVkjiR, package, cmdOpt):
  self.lastSelectedRow = VVkjiR.VVuJp4()
  cmd = FF1oa1(cmdOpt, package)
  if cmd : FFjY30(self, cmd, VVFQVU=boundFunction(self.VVlqdb, VVkjiR))
  else : FFJSkq(self)
 def VVlqdb(self, VVkjiR):
  VVkjiR.cancel()
  FF80hJ()
 def VVUzjg(self, VVkjiR, title, txt, colList):
  package  = colList[1]
  VVRJT5 = []
  VVRJT5.append(("Install Package"         , "install_CheckVersion" ))
  VVRJT5.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVRJT5.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVRJT5.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FF4JCK(self, boundFunction(self.VVmCtu, package), VVRJT5=VVRJT5)
 def VVmCtu(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVJjEM
   elif item == "install_ForceReinstall" : cmdOpt = VVNhZF
   elif item == "install_ForceDowngrade" : cmdOpt = VVMKBv
   elif item == "install_IgnoreDepends" : cmdOpt = VVOyEf
   FFjphE(self, boundFunction(self.VV8yEJ, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VV8yEJ(self, package, cmdOpt):
  cmd = FF1oa1(cmdOpt, package)
  if cmd : FFjY30(self, cmd, VVFQVU=FF80hJ, checkNetAccess=True)
  else : FFJSkq(self)
 def VV58bS(self, VVkjiR, title, txt, colList):
  package  = colList[1]
  FFjphE(self, boundFunction(self.VVQbF7, package), "Download Package ?\n\n%s" % package)
 def VVQbF7(self, package):
  if FFWcRy():
   cmd = FF1oa1(VVFVo9, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFyIHF(success, VV0Tnk))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFyIHF(fail, VVDbaf))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFjY30(self, cmd, VV4CJh=[VVDbaf, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFJSkq(self)
  else:
   FF2nrW(self, "No internet connection !")
 def VVwZmk(self, package):
  infoCmd  = FF1oa1(VVU6ij, package)
  filesCmd = FF1oa1(VVIUZY, package)
  listInstCmd = FFbwyV(VVuLSB, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFWBhT(VVvgWJ)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFyIHF(notInst, VVUqrB))
   cmd += "else "
   cmd +=   FFp6br("System Info", VVvgWJ)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFp6br("Related Files", VVvgWJ)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFMX6s(self, cmd)
  else:
   FFJSkq(self)
class CCRv1a(Screen):
 VViXzW  = 0
 VVjxIO = 1
 VV0GU2  = 2
 VVBQwk  = 3
 VVIyvx = 4
 VVboHa = 5
 VVULLW = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFXEzn(VVdXwL, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VV35dT = None
  self.lastfilterUsed  = None
  VVRJT5 = self.VVMB2Y()
  FFnDik(self, VVRJT5=VVRJT5, title="Services/Channels")
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self["myMenu"].setList(self.VVMB2Y())
  FF0xrD(self["myMenu"])
  FFJAKu(self)
 def VVMB2Y(self):
  VVRJT5 = []
  VVRJT5.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VVRJT5.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Services (Reference)"      , "lameDB_allChannels_with_refCode"  ))
  VVRJT5.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVRJT5.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVRJT5.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVRJT5.append(("Services with PIcons for the System"  , "VVqKIn"     ))
  VVRJT5.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVRJT5.append(VVn6Em)
  lamedbFile, disabledFile = CCRv1a.VVQg9w()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVRJT5.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVRJT5.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVRJT5.append(("Reset Parental Control Settings"   , "VVtNOp"    ))
  VVRJT5.append(("Delete Channels with no names"   , "VVvjqx"    ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Reload Channels and Bouquets"    , "VVU1oq"      ))
  return VVRJT5
 def VVDa6H(self):
  global VVQNCe
  VVQNCe = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFIUUW(self)
   elif item == "currentServiceInfo"     : FFFhkT(self, fncMode=CC9cgb.VV69ha)
   elif item == "TranspondersStats"     : FFikZL(self, self.VVtexu     )
   elif item == "lameDB_allChannels_with_refCode"  : FFikZL(self, self.VVZjzn )
   elif item == "lameDB_allChannels_with_tranaponder" : FFikZL(self, self.VVxaED)
   elif item == "lameDB_allChannels_with_details"  : FFikZL(self, self.VVh8zn )
   elif item == "parentalControlChannels"    : FFikZL(self, self.VVQt1u   )
   elif item == "showHiddenChannels"     : FFikZL(self, self.VVVlT3     )
   elif item == "VVqKIn"     : FFikZL(self, self.VV6nyt     )
   elif item == "servicesWithMissingPIcons"   : FFikZL(self, self.VVcqx3   )
   elif item == "enableHiddenChannels"     : self.VVEnmz(True)
   elif item == "disableHiddenChannels"    : self.VVEnmz(False)
   elif item == "VVtNOp"    : FFjphE(self, self.VVtNOp, "Reset and Restart ?" )
   elif item == "VVvjqx"    : FFikZL(self, self.VVvjqx)
   elif item == "VVU1oq"      : FFikZL(self, boundFunction(CCRv1a.VVU1oq, self))
   else            : self.close()
 @staticmethod
 def VVU1oq(SELF):
  FFhJZy()
  FFrerH(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVZjzn(self):
  self.VV35dT = None
  self.lastfilterUsed  = None
  self.filterObj   = CCQrIW(self)
  VVbqDw = CCRv1a.VV5Ca2(self, self.VViXzW)
  if VVbqDw:
   VVbqDw.sort(key=lambda x: x[0].lower())
   VV5Dm0  = ("Zap"   , self.VVkFqO     , [])
   VVBfeb = (""    , self.VVyOXQ   , [])
   VV4CnB = ("Options"  , self.VVWn8I , [])
   VVg6wQ = ("Current Service", self.VVnuD9 , [])
   VVqvqX = ("Filter"   , self.VVdAel  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVJRZ2  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FF8HHs(self, None, header=header, VVPIPy=VVbqDw, VVJRZ2=VVJRZ2, VVZt3N=widths, VVdfkW=26, VV5Dm0=VV5Dm0, VVBfeb=VVBfeb, VVg6wQ=VVg6wQ, VV4CnB=VV4CnB, VVqvqX=VVqvqX)
 def VVxaED(self):
  self.VV35dT = None
  self.lastfilterUsed  = None
  self.filterObj   = CCQrIW(self)
  VVbqDw = CCRv1a.VV5Ca2(self, self.VVjxIO)
  if VVbqDw:
   VVbqDw.sort(key=lambda x: x[0].lower())
   VV5Dm0  = ("Zap"   , self.VVkFqO      , [])
   VVBfeb = (""    , self.VVyOXQ    , [])
   VVg6wQ = ("Current Service", self.VVnuD9  , [])
   VV4CnB = ("Options"  , self.VVyYRa , [])
   VVqvqX = ("Filter"   , self.VVHOJz  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVJRZ2  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FF8HHs(self, None, header=header, VVPIPy=VVbqDw, VVJRZ2=VVJRZ2, VVZt3N=widths, VVdfkW=26, VV5Dm0=VV5Dm0, VVBfeb=VVBfeb, VVg6wQ=VVg6wQ, VV4CnB=VV4CnB, VVqvqX=VVqvqX)
 def VVWn8I(self, VVkjiR, title, txt, colList):
  servName = colList[0]
  refCode  = colList[3]
  pcState  = colList[4]
  hidState = colList[5]
  mSel  = CCYqwy(self, VVkjiR, 3)
  mSel.VV2aNV(servName, refCode, pcState, hidState)
 def VVyYRa(self, VVkjiR, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CCYqwy(self, VVkjiR, 3)
  mSel.VVyX2M(servName, refCode)
 def VV0gKM(self, VVkjiR, refCode, isAddToBlackList):
  self.VV35dT = None
  self.lastfilterUsed  = None
  VVkjiR.VV8Yq9("Changing state ...")
  path = "/etc/enigma2/blacklist"
  if not fileExists(path):
   os.system("echo '' > %s" % path)
  if fileExists(path):
   if not refCode.endswith(":"):
    refCode += ":"
   if isAddToBlackList :
    os.system("sed -i '/%s/d' %s" % (refCode, path))
    os.system("echo '%s' >> %s" % (refCode, path))
   else:
    os.system("sed -i '/%s/d' %s" % (refCode, path))
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   if refCode.endswith(":"):
    refCode = refCode[:-1]
   FFikZL(self, boundFunction(self.VVV5GH, VVkjiR, refCode))
  else:
   FFAPN6(self, path)
 def VVOKPo(self, VVkjiR, refCode, isHide):
  self.VV35dT = None
  self.lastfilterUsed  = None
  VVkjiR.VV8Yq9("Changing state ...")
  if FFzKuC(refCode):
   ret = FFK9ce(refCode, isHide)
   if ret : FFikZL(self, boundFunction(self.VVV5GH, VVkjiR, refCode))
   else : FF2nrW(self, "Cannot Hide/Unhide this channel.")
  else:
   FF2nrW(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)")
 def VVV5GH(self, VVkjiR, refCode):
  VVbqDw = CCRv1a.VV5Ca2(self, self.VViXzW, VVpYX3=[3, [refCode], False])
  done = False
  if VVbqDw:
   data = VVbqDw[0]
   if data[3] == refCode:
    done = VVkjiR.VVffu3(data)
  if not done:
   self.VVTWue(VVkjiR, VVkjiR.VVuNA3(), self.VViXzW)
  VVkjiR.VVGwFc()
 def VVdAel(self, VVkjiR, title, txt, colList):
  self.filterObj.VVzHLy(1, VVkjiR, 2, boundFunction(self.VVlaa5, VVkjiR))
 def VVlaa5(self, VVkjiR, item):
  self.VV8ipQ(VVkjiR, item, 2, self.VViXzW)
 def VVHOJz(self, VVkjiR, title, txt, colList):
  self.filterObj.VVzHLy(2, VVkjiR, 4, boundFunction(self.VVIgPm, VVkjiR))
 def VVIgPm(self, VVkjiR, item):
  self.VV8ipQ(VVkjiR, item, 4, self.VVjxIO)
 def VV7fDN(self, VVkjiR, title, txt, colList):
  self.filterObj.VVzHLy(0, VVkjiR, 4, boundFunction(self.VV2uxd, VVkjiR))
 def VV2uxd(self, VVkjiR, item):
  self.VV8ipQ(VVkjiR, item, 4, self.VV0GU2)
 def VV8ipQ(self, VVkjiR, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVkjiR.VVfyIm(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VV35dT = None
  else:
   words, asPrefix = CCQrIW.VVqWPa(words)
   self.VV35dT = [col, words, asPrefix]
  if words: FFikZL(self, boundFunction(self.VVTWue, VVkjiR, title, mode), title="Reading Services ...")
  else : FFdxmx(VVkjiR, "Incorrect filter", 2000)
 def VVTWue(self, VVkjiR, title, mode):
  VVbqDw = CCRv1a.VV5Ca2(self, mode, VVpYX3=self.VV35dT, VVMvwR=False)
  if VVbqDw:
   VVbqDw.sort(key=lambda x: x[0].lower())
   VVkjiR.VVRlUS(VVbqDw, title)
  else:
   VVkjiR.VVGwFc()
   FFdxmx(VVkjiR, "Not found!", 1500)
 def VVIdyG(self, VVPIPy, VV5Dm0=None, VVBfeb=None, VVRPnY=None, VVg6wQ=None, VV4CnB=None, VVqvqX=None):
  VVg6wQ = ("Current Service", self.VVnuD9, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVJRZ2 = (LEFT  , LEFT  , CENTER, LEFT    )
  FF8HHs(self, None, header=header, VVPIPy=VVPIPy, VVJRZ2=VVJRZ2, VVZt3N=widths, VVdfkW=26, VV5Dm0=VV5Dm0, VVBfeb=VVBfeb, VVRPnY=VVRPnY, VVg6wQ=VVg6wQ, VV4CnB=VV4CnB, VVqvqX=VVqvqX)
 def VVnuD9(self, VVkjiR, title, txt, colList):
  self.VVPBvw(VVkjiR)
 def VVDven(self, VVkjiR, title, txt, colList):
  self.VVPBvw(VVkjiR, True)
 def VVPBvw(self, VVkjiR, isFromDetails=False):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFuTJ(self)
  if refCode:
   if isFromDetails:
    chName  = info.getName()
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVkjiR.VVg3Na(colDict, VVxCvy=True)
   else:
    VVkjiR.VVEKIJ(3, refCode, True)
   return
  FF2nrW(self, "Colud not read current Reference Code !")
 def VVh8zn(self):
  self.VV35dT = None
  self.lastfilterUsed  = None
  self.filterObj   = CCQrIW(self)
  VVbqDw = CCRv1a.VV5Ca2(self, self.VV0GU2)
  if VVbqDw:
   VVbqDw.sort(key=lambda x: x[0].lower())
   VVBfeb = (""    , self.VVNVyj , []      )
   VVg6wQ = ("Current Service", self.VVDven  , []      )
   VVqvqX = ("Filter"   , self.VV7fDN   , [], "Loading Filters ..." )
   VV5Dm0  = ("Zap"   , self.VVFAaD      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVJRZ2  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FF8HHs(self, None, header=header, VVPIPy=VVbqDw, VVJRZ2=VVJRZ2, VVZt3N=widths, VVdfkW=26, VV5Dm0=VV5Dm0, VVBfeb=VVBfeb, VVg6wQ=VVg6wQ, VVqvqX=VVqvqX)
 def VVNVyj(self, VVkjiR, title, txt, colList):
  refCode  = self.VVYFy2(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFFhkT(self, fncMode=CC9cgb.VVPbQH, refCode=refCode, chName=chName, text=txt)
 def VVFAaD(self, VVkjiR, title, txt, colList):
  refCode = self.VVYFy2(colList)
  FFKIZZ(self, refCode)
 def VVkFqO(self, VVkjiR, title, txt, colList):
  FFKIZZ(self, colList[3])
 def VVYFy2(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VV5Ca2(SELF, mode, VVpYX3=None, VVMvwR=True, VVRKaR=True):
  lamedbFile, disabledFile = CCRv1a.VVQg9w()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVpYX3:
    filterCol = VVpYX3[0]
    filterWords = VVpYX3[1]
    asPrefix = VVpYX3[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCRv1a.VViXzW:
    blackList = None
    path = "/etc/enigma2/blacklist"
    if fileExists(path):
     blackList = FFxmgd(path)
     if blackList:
      blackList = set(blackList)
   elif mode == CCRv1a.VVjxIO:
    tp = CCj4wy()
   VVtuJi, VV0h7I = FFsvLo()
   tagFound  = False
   if mode in (CCRv1a.VVboHa, CCRv1a.VVULLW):
    VVbqDw = {}
   else:
    VVbqDw = []
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFY3yp(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CCRv1a.VV0GU2:
        if sTypeInt in VVtuJi:
         STYPE = VV0h7I[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVbqDw.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVbqDw.append(tRow)
        else:
         VVbqDw.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCRv1a.VVboHa:
         VVbqDw[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCRv1a.VVULLW:
         VVbqDw[chName] = refCode
        elif mode == CCRv1a.VViXzW:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVbqDw.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVbqDw.append(tRow)
         else:
          VVbqDw.append(tRow)
        elif mode == CCRv1a.VVjxIO:
         if sTypeInt in VVtuJi:
          STYPE = VV0h7I[sTypeInt]
         freq, pol, fec, sr, syst = tp.VVUOQI(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVbqDw.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVbqDw.append(tRow)
         else:
          VVbqDw.append(tRow)
        elif mode == CCRv1a.VVBQwk:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VVbqDw.append((chName, chProv, sat, refCode))
        elif mode == CCRv1a.VVIyvx:
         VVbqDw.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VVbqDw and VVMvwR:
    FF2nrW(SELF, "No services found!")
   return VVbqDw
  else:
   if VVRKaR:
    FFAPN6(SELF, lamedbFile)
   return None
 def VVQt1u(self):
  path = "/etc/enigma2/blacklist"
  if fileExists(path):
   lines = FFxmgd(path)
   if lines:
    newRows  = []
    VVbqDw = CCRv1a.VV5Ca2(self, self.VVIyvx)
    if VVbqDw:
     lines = set(lines)
     for item in VVbqDw:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVbqDw = newRows
      VVbqDw.sort(key=lambda x: x[0].lower())
      VVBfeb = ("", self.VVyOXQ, [])
      VV5Dm0 = ("Zap", self.VVkFqO, [])
      self.VVIdyG(VVPIPy=VVbqDw, VV5Dm0=VV5Dm0, VVBfeb=VVBfeb)
     else:
      FFSnuH(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVbqDw)))
   else:
    FFrerH(self, "No active Parental Control services.", FF6oMc())
  else:
   FFAPN6(self, path)
 def VVVlT3(self):
  VVbqDw = CCRv1a.VV5Ca2(self, self.VVBQwk)
  if VVbqDw:
   VVbqDw.sort(key=lambda x: x[0].lower())
   VVBfeb = ("" , self.VVyOXQ, [])
   VV5Dm0  = ("Zap", self.VVkFqO, [])
   self.VVIdyG(VVPIPy=VVbqDw, VV5Dm0=VV5Dm0, VVBfeb=VVBfeb)
  else:
   FFrerH(self, "No hidden services.", FF6oMc())
 def VVtexu(self):
  totT, totC, totA, totS, totS2, satList = self.VV2qUI()
  txt = FF5Q6H("Total Transponders:\n\n", VVbaBa)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FF5Q6H("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVbaBa)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFGigL(item), satList.count(item))
  FFSnuH(self, txt)
 def VV2qUI(self):
  lamedbFile, disabledFile = CCRv1a.VVQg9w()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFAPN6(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VV6nyt(self)   : self.VVqKIn(True)
 def VVcqx3(self) : self.VVqKIn(False)
 def VVqKIn(self, isWithPIcons):
  piconsPath = CCgeLj.VVqTSU()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCgeLj.VVbQGy(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVbqDw = CCRv1a.VV5Ca2(self, self.VVIyvx)
    if VVbqDw:
     channels = []
     for (chName, chProv, sat, refCode) in VVbqDw:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFRTaU(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVbqDw)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVxNnv(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVxNnv("PIcons Path"  , piconsPath)
     txt += VVxNnv("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVxNnv("Total services" , totalServices)
     txt += VVxNnv("With PIcons"  , totalWithPIcons)
     txt += VVxNnv("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFSnuH(self, txt)
     else:
      VVBfeb     = (""      , self.VVyOXQ , [])
      if isWithPIcons : VVqvqX = ("Export Current PIcon", self.VVf34v  , [])
      else   : VVqvqX = None
      VV4CnB     = ("Statistics", FFSnuH, [txt])
      VV5Dm0      = ("Zap", self.VVkFqO, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVIdyG(VVPIPy=channels, VV5Dm0=VV5Dm0, VVBfeb=VVBfeb, VV4CnB=VV4CnB, VVqvqX=VVqvqX)
   else:
    FF2nrW(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FF2nrW(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVyOXQ(self, VVkjiR, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFFhkT(self, fncMode=CC9cgb.VVPbQH, refCode=refCode, chName=chName, text=txt)
 def VVf34v(self, VVkjiR, title, txt, colList):
  png, path = CCgeLj.VVJdpf(colList[3], colList[0])
  if path:
   CCgeLj.VVC0Rt(self, png, path)
 @staticmethod
 def VVQg9w():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VV0aLe():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVEnmz(self, isEnable):
  lamedbFile, disabledFile = CCRv1a.VVQg9w()
  if isEnable and not fileExists(disabledFile):
   FFrerH(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FF2nrW(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFjphE(self, boundFunction(self.VV25rq, isEnable), "%s Hidden Channels ?" % word)
 def VV25rq(self, isEnable):
  lamedbFile , disabledFile = CCRv1a.VVQg9w()
  lamedb5File, diabled5File = CCRv1a.VV0aLe()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FFhJZy()
  if res == 0 : FFrerH(self, "Hidden List %s" % word)
  else  : FF2nrW(self, "Error while restoring:\n\n%s" % fileName)
 def VVtNOp(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFnyIj(self, cmd)
 def VVvjqx(self):
  lamedbFile, disabledFile = CCRv1a.VVQg9w()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FF3WD3("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFxmgd(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FF3WD3("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FFhJZy()
   FFSnuH(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFAPN6(self, lamedbFile)
class CC9cgb(Screen):
 VV69ha  = 0
 VViUAq   = 1
 VVk4Wt   = 2
 VVPbQH    = 3
 VVgRhd    = 4
 VVInci   = 5
 VVPSgX   = 6
 VV1LFz    = 7
 VVF41L   = 8
 VVKR1g   = 9
 VVQafY   = 10
 VVW4R8   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFXEzn(VVDOy7, 1400, 800, 50, 30, 20, "#110B2830", "#050B242c", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VV69ha)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FF5Q6H("%s\n", VVvQSh) % VV06tg
  FFnDik(self, title="Channel Info", addScrollLabel=True)
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  self["myLabel"].VVOdRf(textOutFile="chann_info")
  if   self.fncMode == self.VV69ha : fnc = self.VVCW9W_VV69ha
  elif self.fncMode == self.VViUAq  : fnc = self.VVCW9W_VV69ha
  elif self.fncMode == self.VVk4Wt  : fnc = self.VVCW9W_VV69ha
  elif self.fncMode == self.VVPbQH  : fnc = self.VVCW9W_VVPbQH
  elif self.fncMode == self.VVgRhd  : fnc = self.VVCW9W_VVgRhd
  elif self.fncMode == self.VVInci  : fnc = self.VVCW9W_VVInci
  elif self.fncMode == self.VVPSgX  : fnc = self.VVCW9W_VVPSgX
  elif self.fncMode == self.VV1LFz  : fnc = self.VVCW9W_VV1LFz
  elif self.fncMode == self.VVF41L  : fnc = self.VVCW9W_VVF41L
  elif self.fncMode == self.VVKR1g : fnc = self.VVCW9W_VVKR1g
  elif self.fncMode == self.VVQafY  : fnc = self.VVCW9W_VVQafY
  elif self.fncMode == self.VVW4R8 : fnc = self.VVCW9W_VVW4R8
  self["myLabel"].setText("\n   Reading Info ...")
  FFsV3D(fnc)
 def VVs20Z(self, err):
  self["myLabel"].setText(err)
  FFfaVA(self["myTitle"], "#22200000")
  FFfaVA(self["myBody"], "#22200000")
  self["myLabel"].FFfaVAColor("#22200000")
  self["myLabel"].VVR1jP()
 def VVCW9W_VV69ha(self):
  try:
   dum = self.session
  except:
   return
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFuTJ(self)
  self.refCode = refCode
  self.VVHnqt(chName)
 def VVCW9W_VVPbQH(self):
  self.VVHnqt(self.chName)
 def VVCW9W_VVgRhd(self):
  self.VVHnqt(self.chName)
 def VVCW9W_VVInci(self):
  self.VVHnqt(self.chName)
 def VVCW9W_VVPSgX(self):
  self.VVHnqt("Picon Info")
 def VVCW9W_VV1LFz(self):
  self.VVHnqt(self.chName)
 def VVCW9W_VVF41L(self):
  self.VVHnqt(self.chName)
 def VVCW9W_VVKR1g(self):
  self.VVHnqt(self.chName)
 def VVCW9W_VVQafY(self):
  self.chUrl = self.refCode + self.callingSELF.VVMnCj(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVHnqt(self.chName)
 def VVCW9W_VVW4R8(self):
  self.VVHnqt(self.chName)
 def VVHnqt(self, title):
  self.VVZlVQ(title)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFuTJ(self)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVi6F5(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FF5Q6H(self.VV5nJZ(tUrl), VViEcp)
  if not self.epg:
   epg = self.VVsGu2(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVE3Ny(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCgeLj.VVJdpf(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVE3Ny(path)
  self.VVWA4B()
  self.VVfEaT()
  self["myLabel"].setText(self.text, VVGjos=VVmSww)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVR1jP(minHeight=minH)
 def VVfEaT(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FF7Q2V(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVo7TM(FFxclk(url))
  if epg:
   self.text += "\n" + FFjBJQ("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVWA4B()
 def VVWA4B(self):
  if not self.piconShown and self.picUrl:
   path, err = FFj4ge(self.picUrl, "ajpanel_tmp.png", timeout=2)
   if path:
    self.piconShown = self.VVE3Ny(path)
    if self.piconShown and self.refCode:
     self.VVtPXy(path, self.refCode)
 def VVtPXy(self, path, refCode):
  if path and fileExists(path) and os.system(FF3WD3("which ffmpeg")) == 0:
   pPath = CCgeLj.VVqTSU()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
    cmd += FF3WD3("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVE3Ny(self, path):
  if path and fileExists(path):
   err, w, h = self.VV5kFI(path)
   if not err:
    if h > w:
     self.VVevyn(self["myPicF"], w, h, True)
     self.VVevyn(self["myPic"] , w, h, False)
   allOK = FFjQE2(self["myPic"], path)
   if allOK:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVevyn(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VV5kFI(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FF7GV9(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVZlVQ(self, chName):
  if chName:
   self["myTitle"].setText("  " + chName + "  ")
 def VVi6F5(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FF5Q6H(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVxNnv(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FF5Q6H(state, VVUqrB)
   txt += "State\t: %s\n" % state
  w = FFiV0Z(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFiV0Z(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVYWay(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVxNnv(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVxNnv(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVxNnv(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  isIptv = len(iptvRef) > 0
  if iptvRef:
   txt += "Service Type\t: %s\n" % FF5Q6H("IPTV", VVbaBa)
   txt += self.VVcXEU(iptvRef)
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not refCode:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    path = serv.getPath()
    if path:
     txt += "Path\t: %s\n" % path
  txt += "\n"
  txt += self.VVqKGW(refCode, iptvRef, chName)
  if not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCj4wy()
    tpTxt, namespace = tp.VVysoZ(refCode)
    del tp
    if tpTxt:
     txt += FF5Q6H("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FF5Q6H("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVxNnv(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVxNnv(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVxNnv(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVxNnv(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVxNnv(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVxNnv(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVxNnv(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVxNnv(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVxNnv(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVYWay(info):
  if info:
   aspect = FFiV0Z(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVxNnv(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFiV0Z(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVBoeG(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVBoeG(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVqKGW(self, refCode, iptvRef, chName):
  refCode = FFwA9I(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FF83qF(VVg7D5 + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FF83qF(VVg7D5 + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VVPIPy = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVg7D5 + item
   if fileExists(path):
    txt = FF83qF(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVPIPy.append(bName)
  txt = self.Sep
  if VVPIPy:
   if len(VVPIPy) == 1:
    txt += "%s\t: %s\n" % (FF5Q6H("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VVPIPy[0])
   else:
    txt += FF5Q6H("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VVPIPy):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVsGu2(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVidwL(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVidwL(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVidwL(event, 0)
     except:
      pass
  return epg
 def VVidwL(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName().strip()    or ""
   evTime = event.getBeginTime()      or ""
   evDur = event.getDuration()      or ""
   evShort = event.getShortDescription() .strip() or ""
   evDesc = event.getExtendedDescription().strip() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = self.VVBU5u(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FF5Q6H(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FF5Q6H(evNameTransl, COLOR_CONS_BRIGHT_YELLOW))
    if evTime           : txt += "Start Time\t: %s\n" % FFAQH0(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFAQH0(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFUwdx(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFUwdx(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFUwdx(evTime - now)
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FF5Q6H(evShort, VViEcp)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FF5Q6H(evDesc , VViEcp)
    if txt:
     txt = FF5Q6H("\n%s\n%s Event:\n%s\n" % (VV06tg, ("Current", "Next")[evNum], VV06tg), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVcXEU(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FF2vZ6(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CC2X6C()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV12ZR(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FF5Q6H("URL:", VVbaBa) + "\n%s\n" % self.VV5nJZ(decodedUrl)
  else:
   txt = "\n"
   txt += FF5Q6H("Reference:", VVbaBa) + "\n%s\n" % refCode
  return txt
 def VV5nJZ(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VV3ToJ:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VVo7TM(self, decodedUrl):
  if not FFWcRy():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCqLir.VV5dpo(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (not a subscription ULR) !"
  if   uType == "live" : qUrl = "%s/player_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uHost, uUser, uPass, uId)
  elif uType == "movie" : qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCqLir.VVru3x(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVhYsK(tDict)
   elif uType == "movie" : epg, picUrl = self.VVQEJG(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVhYsK(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCqLir.VVQ0IT(item, "title"    , is_base64=True )
     lang    = CCqLir.VVQ0IT(item, "lang"         ).upper()
     description   = CCqLir.VVQ0IT(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCqLir.VVQ0IT(item, "start_timestamp" , isDate=True  )
     stop_timestamp  = CCqLir.VVQ0IT(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCqLir.VVQ0IT(item, "stop_timestamp"       )
     now_playing   = CCqLir.VVQ0IT(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VV011v, ""
      else     : color, txt = VVUqrB , "    (CURRENT EVENT)"
      epg += FF5Q6H("_" * 32 + "\n", VVvQSh)
      epg += FF5Q6H("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      epg += "Description:\n%s\n" % FF5Q6H(description, VViEcp)
      evNum += 1
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VVQEJG(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCqLir.VVQ0IT(item, "movie_image" )
    genre  = CCqLir.VVQ0IT(item, "genre"   ) or "-"
    plot  = CCqLir.VVQ0IT(item, "plot"   ) or "-"
    cast  = CCqLir.VVQ0IT(item, "cast"   ) or "-"
    rating  = CCqLir.VVQ0IT(item, "rating"   ) or "-"
    director = CCqLir.VVQ0IT(item, "director"  ) or "-"
    releasedate = CCqLir.VVQ0IT(item, "releasedate" ) or "-"
    duration = CCqLir.VVQ0IT(item, "duration"  ) or "-"
    try:
     lang = CCqLir.VVQ0IT(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FF5Q6H(cast, VViEcp)
    epg += "Plot:\n%s"    % FF5Q6H(self.VVBU5u(plot), VViEcp)
   except:
    pass
  return epg, movie_image
 def VVBU5u(self, evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = self.VV7DZO(evTxt, lang)
   return self.VVUFSv(txt).strip() or evTxt
 def VVUFSv(self, txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VV7DZO(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FF8kZC(txt))
   txt, err = CCqLir.VVru3x(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFxclk(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
class CC2X6C():
 def __init__(self):
  self.VVJNUV  = ""
  self.VVpo1f   = ""
  self.VVo8Ng  = ""
  self.colored_user  = "#f#11ffffaa#User"
  self.colored_server  = "#f#11aaffff#Server"
 def VVTexO(self, url, mac, VVxCvy=True):
  self.VVJNUV = ""
  self.VVpo1f  = ""
  self.VVo8Ng = ""
  host = self.VVtseP(url)
  if not host:
   if VVxCvy:
    self.VVxCvyor("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVgPUx(mac)
  if not host:
   if VVxCvy:
    self.VVxCvyor("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVJNUV = host
  self.VVpo1f  = mac
  self.VVo8Ng = ""
  return True
 def VVKhYN(self):
  res, err = self.VVbZaq(self.VVJNUV, useCookies=False)
  if err:
   self.VVxCvyor(err, "Connect to Portal")
   return False
  if (res.status_code == 301):
   title = "Redirection"
   newUrl = res.headers['location']
   res, err = self.VVbZaq(newUrl, res.cookies)
   if err:
    self.VVxCvyor(err, "URL Redirection")
    return False
   else:
    host = self.VVtseP(newUrl)
    if not host:
     self.VVxCvyor("Incorrect Redirection-URL Format !\n\n%s" % newUrl)
     return False
    self.VVJNUV = host
  token, profile = self.VV5T76()
  if not token:
   return False
  return True
 def VVtseP(self, url):
  ndx = url.lower().find("mac=")
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ ")
  return url
 def VVgPUx(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VV5T76(self, VVxCvy=True):
  try:
   token = self.VVyjZs()
   if token:
    self.VVo8Ng = token
   else:
    if VVxCvy:
     self.VVxCvyor("Could not get Token from server !")
    return "", ""
   return token, self.VVFrld()
  except:
   return "", ""
 def VVyjZs(self):
  token  = ""
  res, err = self.VVbZaq(self.VVL2OR())
  if not err:
   try:
    tDict = jLoads(res.text)
    token = CCqLir.VVQ0IT(tDict["js"], "token")
   except:
    pass
  return token.strip()
 def VVFrld(self):
  res, err = self.VVbZaq(self.VVDd9P())
  if not err:
   try:
    profJson = jLoads(res.text)
    return profJson
   except:
    pass
  return ""
 def VVQP8z(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVO1zs()
  if len(rows) < 10:
   rows = self.VVivwf()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVJNUV ))
   rows.append(("MAC (from URL)" , self.VVpo1f ))
   rows.append(("Token"   , self.VVo8Ng ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VVpo1f ))
   rows.append(("2", self.colored_server, "Host" , self.VVJNUV ))
   rows.append(("2", self.colored_server, "Token" , self.VVo8Ng ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVzmGX(self):
  token, profile = self.VV5T76()
  if not token:
   return ""
  m3u_Url = ""
  url = self.VV8xqH()
  res, err = self.VVbZaq(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCqLir.VVQ0IT(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = span.group(2)
     pass1 = span.group(3)
     m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
   except:
    pass
  return m3u_Url
 def VVO1zs(self):
  m3u_Url = self.VVzmGX()
  rows = []
  if m3u_Url:
   res, err = self.VVbZaq(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFAQH0(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFAQH0(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVivwf(self):
  token, profile = self.VV5T76()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FF8SDW(val): val = FF3oSl(val.decode("UTF-8"))
     else     : val = self.VVpo1f
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFAQH0(int(parts[1]))
      if parts[2] : ends = FFAQH0(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFAQH0(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVMnCj(self, mode, chCm, epNum, epId):
  crLinkUrl = self.VVbnlD(mode, chCm, epNum, epId)
  token, profile = self.VV5T76(VVxCvy=False)
  if not token:
   return ""
  res, err = self.VVbZaq(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCqLir.VVQ0IT(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  return chUrl
 def VVRfrg(self):
  return self.VVJNUV + "/server/load.php?"
 def VVL2OR(self):
  return self.VVRfrg() + "type=stb&action=handshake&token=&mac=%s" % self.VVpo1f
 def VVDd9P(self):
  return self.VVRfrg() + "type=stb&action=get_profile"
 def VVlkfQ(self, mode):
  url = self.VVRfrg() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVbJAM(self, catID):
  return self.VVRfrg() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVU37j(self, mode, catID, page):
  url = self.VVRfrg() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "series" : url += "category=%s" % catID
  else    : url += "genre=%s&force_ch_link_check=" % catID
  return url
 def VV2JMa(self, mode, searchName, page):
  return self.VVRfrg() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VVa76A(self, mode, catID):
  return self.VVRfrg() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVbnlD(self, mode, chCm, serCode, serId):
  url = self.VVRfrg() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VV8xqH(self):
  return self.VVRfrg() + "type=itv&action=create_link"
 def VVeG8v(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVNuOx(catID, stID, chNum)
  query = self.VVf9lt(mode, FFZqKW(host), FFZqKW(mac), serCode, serId, chCm)
  chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVf9lt(self, mode, host, mac, serCode, serId, chCm):
  query = "mode=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VV12ZR(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVf9lt(mode, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FF3oSl(host)
  mac   = FF3oSl(mac)
  valid = False
  if self.VVtseP(playHost) and self.VVtseP(host) and self.VVtseP(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVbZaq(self, url, useCookies=True):
  err = ""
  try:
   import requests
   cookies = { "mac" : self.VVpo1f, "stb_lang" : "en" }
   headers = { 'User-Agent':  'Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3', }
   if self.VVo8Ng:
    headers["Authorization"] = "Bearer %s" % self.VVo8Ng
   if useCookies : res = requests.get(url, headers=headers, allow_redirects=False, timeout=2, cookies=cookies)
   else   : res = requests.get(url, headers=headers, allow_redirects=False, timeout=2)
   res.raise_for_status()
   return res, ""
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.exceptions.HTTPError as e  : err = "HTTP Error"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[120]
  return "", err + "\n\n" + url
 @staticmethod
 def VVBzlG(host, mac, tType, action, keysList=[]):
  myPortal = CC2X6C()
  ok = myPortal.VVTexO(host, mac)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile = myPortal.VV5T76()
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s/server/load.php?type=%s&action=%s" % (host, tType, action)
  res, err = myPortal.VVbZaq(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVKaHm(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVKaHm(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVxCvyor(self, err, title="Portal Browser"):
  FF2nrW(self, str(err), title=title)
 def VVgDy0(self, mode):
  if   mode in ("itv"  , CCqLir.VVLcYV , CCqLir.VV16eS)  : return "Live"
  elif mode in ("vod"  , CCqLir.VVTNFe , CCqLir.VVBTM4)  : return "VOD"
  elif mode in ("series" , CCqLir.VVzsnQ , CCqLir.VVMyFT) : return "Series"
  else                          : return "IPTV"
 def VVpUDe(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVgDy0(mode), searchName)
 def VVAaN8(self, catchup=False):
  VVRJT5 = []
  VVRJT5.append(("Live"    , "live"  ))
  VVRJT5.append(("VOD"    , "vod"   ))
  VVRJT5.append(("Series"   , "series"  ))
  if catchup:
   VVRJT5.append(VVn6Em)
   VVRJT5.append(("Catchup TV" , "catchup"  ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Account Info." , "accountInfo" ))
  return VVRJT5
class CC04b0(CC2X6C):
 def __init__(self):
  CC2X6C.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVo4qE(self, refCode, chName, decodedUrl, iptvRef):
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = self.VV12ZR(decodedUrl)
  if valid:
   if self.VVTexO(host, mac, VVxCvy=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVKDRp(self, passedSELF=None, isFromSession=False):
  chUrl = self.VVMnCj(self.mode, self.chCm, self.epNum, self.epId)
  if not chUrl:
   return
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = self.refCode + chUrl.strip() + ":" + self.chName
  newIptvRef = ""
  ndx = chUrl.find("play_token=")
  if ndx > -1:
   ndx = chUrl.find(":", ndx)
   if ndx > -1:
    left  = chUrl[:ndx]
    right  = chUrl[ndx:]
    newIptvRef = left + "&" + self.query + right
  if newIptvRef:
   success = self.VVsENf(self.iptvRef, newIptvRef)
   if passedSELF:
    FFKIZZ(passedSELF, newIptvRef, VVOeQH=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFKIZZ(self, newIptvRef, VVOeQH=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VVsENf(self, oldCode, newCode):
  bPath = FFBWjQ()
  if bPath:
   txt = FF83qF(bPath)
   if oldCode in txt:
    txt = txt.replace(oldCode, newCode)
    with open(bPath, "w") as f:
     f.write(txt)
    FFhJZy()
    return True
  return False
class CCunJh(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFXEzn(VVfaAE, 10, 10, 50, 30, 20, "#22002020", "#22001122", 30)
  self.session = session
  FFnDik(self, "")
  self.close()
class CCMpsE(CC04b0):
 def __init__(self, passedSession):
  CC04b0.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.timer1   = eTimer()
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={ iPlayableService.evEnd: self.VV9SkV})
  except:
   pass
 def VV9SkV(self):
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVuBni)
  except:
   self.timer1.callback.append(self.VVuBni)
  self.timer1.start(100, True)
 def VVuBni(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFuTJ(self.passedSession, isFromSession=True)
  valid = False
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if not ref == self.lastRef:
     valid = self.VVo4qE(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if not CCkdPb.PLAYER_INSTANCE:
       self.VVKDRp(self.passedSession, isFromSession=True)
class CChTqt():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.adultWords  = ("adult", "sex", "porn", "xxx", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.nameTagPatt = r"(?:\s*[(|:]\s*)?[A-Z]{2}\s*.?\s*[)|:]\s*(?:.+[|:]\s*)*(.+)"
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
 def VVk2UI(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCqLir.VVRF0R(name):
   return CCqLir.VVLNHU(name)
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name, IGNORECASE)
   if span:
    name = span.group(1)
  return name.strip() or name
 def VVz4Nk(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  span = iSearch(self.nameTagPatt, name, IGNORECASE)
  if span:
   name = span.group(1)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVoH8n(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  else:
   return name.strip()
 def VVDLSn(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVWe90(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCUv7m(CC2X6C):
 def __init__(self):
  CC2X6C.__init__(self)
 def VVYbz7(self):
  try:
   import requests
   FFikZL(self, self.VVWKck, title="Searching ...")
  except:
   FFjphE(self, self.VVvgwZ, '"Requests Library" is required to read Portal.\n\nInstall the library ?')
 def VVsyEW(self, winSession, url, mac):
  if self.VVTexO(url, mac):
   FFikZL(winSession, self.VVDFps, title="Checking Server ...")
  else:
   FF2nrW(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVvgwZ(self):
  from sys import version_info
  cmdUpd = FFbwyV(VVhCBi, "")
  if cmdUpd:
   cmdInst = FF1oa1(VVJjEM, "python-requests")
   if version_info[0] >= 3:
    cmdInst = cmdInst.replace("python-", "python3-")
   cmd = cmdUpd + " && " + cmdInst
   FFjY30(self, cmd, checkNetAccess=True, title="Installing Requests Library")
  else:
   FFJSkq(self)
 def VVWKck(self):
  path = CCqLir.VVlyCf()
  lines = FFo8V2('find %s %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % (path, FFyECp(1)))
  if lines:
   lines.sort()
   VVRJT5 = []
   for line in lines:
    VVRJT5.append((line, line))
   OKBtnFnc = self.VVjTDG
   FF4JCK(self, None, title="Select Portals File", VVRJT5=VVRJT5, width=1200, OKBtnFnc=OKBtnFnc)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FF2nrW(self, 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt)
 def VVjTDG(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   self.session.open(CCi8Vp, barTheme=CCi8Vp.VV3KQm
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VV6pho, path)
       , VVRVdr = boundFunction(self.VVQzVl, menuInstance, path))
 def VV6pho(self, path, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  lines  = FFxmgd(path)
  progBarObj.VVxjCs(len(lines))
  progBarObj.VVNZTI = []
  import time
  for lineNum, line in enumerate(lines, start=1):
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVaQEg(1, True)
   iSleep(0.0001)
   line = line.strip()
   if not line or "password" in line:
    continue
   span = iSearch(urlMacPatt, line, IGNORECASE)
   if span:
    c  += 1
    subj = span.group(1).strip() or "-"
    url  = span.group(2).strip()
    mac  = span.group(3).strip().replace(" ", "").upper()
    info = span.group(4).strip() or "-"
    host = self.VVtseP(url)
    mac  = self.VVgPUx(mac)
    if host and mac and progBarObj:
     progBarObj.VVNZTI.append((str(c), str(lineNum), subj, host, mac, info))
    url  = ""
    continue
   if not url:
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if not span:
     span = iSearch(urlOnlyPatt, line, IGNORECASE)
     if span:
      url = span.group(1).split(" ")[0]
   else:
    span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     mac  = span.group(2).strip().replace(" ", "").upper()
     info = span.group(3).strip() or "-"
     host = self.VVtseP(url)
     mac  = self.VVgPUx(mac)
     if host and mac and not mac.startswith("AC") and progBarObj:
      progBarObj.VVNZTI.append((str(c), str(lineNum), "-", host, mac, info))
    else:
     span = iSearch(urlOnlyPatt, line, IGNORECASE)
     if span:
      url = span.group(1).split(" ")[0]
 def VVQzVl(self, menuInstance, path, VVxBnX, VVNZTI, threadCounter, threadTotal, threadErr):
  title = "Portals List File"
  if VVNZTI:
   VVRPnY  = ("Home Menu", FFVS4w, [])
   VVqvqX  = None #("Check & Filter" , boundFunction(self.filterPortalAuthorizedServers, path), [])
   VV4CnB = ("Edit File" , boundFunction(self.VVYbPy, path) , [])
   VV5Dm0  = ("Select"  , self.VVsyEW_fromMacFiles   , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVJRZ2  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVkjiR = FF8HHs(self, None, title=title, header=header, VVPIPy=VVNZTI, VVJRZ2=VVJRZ2, VVZt3N=widths, VVdfkW=26, VV5Dm0=VV5Dm0, VVRPnY=VVRPnY, VV4CnB=VV4CnB, VVqvqX=VVqvqX, VVgzpW="#0a001111", VVTK1M="#0a001122", VVKZRt="#0a001122", VVPQde="#00000000", VVSFYp=True, searchCol=1)
   if not VVxBnX:
    FFdxmx(VVkjiR, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVxBnX:
    FF2nrW(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVsyEW_fromMacFiles(self, VVkjiR, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVsyEW(VVkjiR, url, mac)
 def VVYbPy(self, path, VVkjiR, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCqxmc(self, path, VVRVdr=boundFunction(self.VVLUt4, VVkjiR), curRowNum=rowNum)
  else    : FFAPN6(self, path)
 def VVLUt4(self, VVkjiR, fileChanged):
  if fileChanged:
   VVkjiR.cancel()
 def VVhTNs(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FF3oSl(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVDFps(self):
  if self.VVKhYN():
   VVRJT5  = self.VVAaN8()
   OKBtnFnc = self.VVV0yK
   VVrFC4 = ("Home Menu", FFVS4w)
   FF4JCK(self, None, title="Portal Resources (MAC=%s)" % self.VVpo1f, VVRJT5=VVRJT5, OKBtnFnc=OKBtnFnc, VVrFC4=VVrFC4)
 def VVV0yK(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFikZL(menuInstance, boundFunction(self.VVVqzU, mode), title="Reading Categories ...")
   else : FFikZL(menuInstance, boundFunction(self.VVcd8A, menuInstance, title), title="Reading Account ...")
 def VVcd8A(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVQP8z(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVpo1f)
  VVRPnY  = ("Home Menu" , FFVS4w, [])
  if totCols == 2:
   VVqvqX = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
   VVqvqX = ("More Info.", boundFunction(self.VVE9IG, menuInstance) , [])
  FF8HHs(self, None, title=title, width=1200, header=header, VVPIPy=rows, VVZt3N=widths, VVdfkW=26, VVRPnY=VVRPnY, VVqvqX=VVqvqX, VVgzpW="#0a00292B", VVTK1M="#0a002126", VVKZRt="#0a002126", VVPQde="#00000000", searchCol=searchCol)
 def VVE9IG(self, menuInstance, VVkjiR, title, txt, colList):
  VVkjiR.cancel()
  FFikZL(menuInstance, boundFunction(self.VVcd8A, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVVqzU(self, mode):
  token, profile = self.VV5T76()
  if not token:
   return
  res, err = self.VVbZaq(self.VVlkfQ(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CChTqt()
     chList = tDict["js"]
     for item in chList:
      Id   = CCqLir.VVQ0IT(item, "id"       )
      Title  = CCqLir.VVQ0IT(item, "title"      )
      censored = CCqLir.VVQ0IT(item, "censored"     )
      Title = processChanName.VVoH8n(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VV3ToJ:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVgDy0(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVgzpW, VVTK1M, VVKZRt, VVPQde = self.VVzunr(mode)
   mName = self.VVgDy0(mode)
   VV5Dm0   = ("Show List"  , boundFunction(self.VVX9Fa, mode) , [])
   VVRPnY  = ("Home Menu"   , FFVS4w         , [])
   if mode in ("vod", "series"):
    VV4CnB = ("Find in %s" % mName , boundFunction(self.VVCz5T, mode), [])
   else:
    VV4CnB = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FF8HHs(self, None, title=title, width=1200, header=header, VVPIPy=list, VVZt3N=widths, VVdfkW=30, VVRPnY=VVRPnY, VV4CnB=VV4CnB, VV5Dm0=VV5Dm0, VVgzpW=VVgzpW, VVTK1M=VVTK1M, VVKZRt=VVKZRt, VVPQde=VVPQde)
  else:
   FF2nrW(self, "Could not get Categories from server!", title=title)
 def VVJGzE(self, mode, VVkjiR, title, txt, colList):
  FFikZL(VVkjiR, boundFunction(self.VVoHrk, mode, VVkjiR, title, txt, colList), title="Downloading ...")
 def VVoHrk(self, mode, VVkjiR, title, txt, colList):
  token, profile = self.VV5T76()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVbZaq(self.VVbJAM(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCqLir.VVQ0IT(item, "id"    )
      actors   = CCqLir.VVQ0IT(item, "actors"   )
      added   = CCqLir.VVQ0IT(item, "added"   )
      age    = CCqLir.VVQ0IT(item, "age"   )
      category_id  = CCqLir.VVQ0IT(item, "category_id" )
      description  = CCqLir.VVQ0IT(item, "description" )
      director  = CCqLir.VVQ0IT(item, "director"  )
      genres_str  = CCqLir.VVQ0IT(item, "genres_str"  )
      name   = CCqLir.VVQ0IT(item, "name"   )
      path   = CCqLir.VVQ0IT(item, "path"   )
      screenshot_uri = CCqLir.VVQ0IT(item, "screenshot_uri" )
      series   = CCqLir.VVQ0IT(item, "series"   )
      cmd    = CCqLir.VVQ0IT(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VV5Dm0  = ("Play"  , boundFunction(self.VVo8rB, mode, False)      , [])
   VVBfeb = (""   , boundFunction(self.VVWcwa, mode)      , [])
   VVRPnY = ("Home Menu" , FFVS4w                , [])
   VVg6wQ = ("Download PIcons" , boundFunction(self.VVhB4x, mode)      , [])
   VV4CnB = ("Add ALL to Bouquet" , boundFunction(self.VVXypx, mode, seriesName) , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVJRZ2  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FF8HHs(self, None, title=seriesName, width=1200, header=header, VVPIPy=list, VVJRZ2=VVJRZ2, VVZt3N=widths, VVdfkW=26, VVRPnY=VVRPnY, VVg6wQ=VVg6wQ, VV4CnB=VV4CnB, VV5Dm0=VV5Dm0, VVBfeb=VVBfeb, VVgzpW="#0a00292B", VVTK1M="#0a002126", VVKZRt="#0a002126", VVPQde="#00000000")
  else:
   FF2nrW(self, "Could not get Episodes from server!", title=seriesName)
 def VVCz5T(self, mode, VVkjiR, title, txt, colList):
  VVRJT5 = []
  VVRJT5.append(("Keyboard"  , "manualEntry"))
  VVRJT5.append(("From Filter" , "fromFilter"))
  FF4JCK(self, boundFunction(self.VVxFBQ, VVkjiR, mode), title="Input Type", VVRJT5=VVRJT5, width=400)
 def VVxFBQ(self, VVkjiR, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFzere(self, boundFunction(self.VVRSRQ, VVkjiR, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCQrIW(self)
    filterObj.VVxbBu(boundFunction(self.VVRSRQ, VVkjiR, mode))
 def VVRSRQ(self, VVkjiR, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VVpUDe(mode, searchName)
   if len(searchName) < 3:
    FF2nrW(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CChTqt()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVDLSn([searchName]):
     FF2nrW(self, processChanName.VVWe90(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VVej4R(mode, searchName, "", searchName)
 def VVX9Fa(self, mode, VVkjiR, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVej4R(mode, bName, catID, "")
 def VVej4R(self, mode, bName, catID, searchName):
  self.session.open(CCi8Vp, barTheme=CCi8Vp.VVtojm
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVLWmq, mode, bName, catID, searchName)
      , VVRVdr = boundFunction(self.VVJ1Bq, mode, bName, catID, searchName))
 def VVJ1Bq(self, mode, bName, catID, searchName, VVxBnX, VVNZTI, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVpUDe(mode, searchName)
  else   : title = "%s : %s" % (self.VVgDy0(mode), bName)
  if VVNZTI:
   if mode == "series":
    VVgzpW, VVTK1M, VVKZRt, VVPQde = self.VVzunr("series2")
    VV5Dm0  = ("Episodes", boundFunction(self.VVJGzE, mode) , [])
    VVg6wQ = None
    VV4CnB = None
   else:
    VVgzpW, VVTK1M, VVKZRt, VVPQde = self.VVzunr("")
    VV5Dm0  = ("Play"    , boundFunction(self.VVo8rB, mode, False)   , [])
    VVg6wQ = ("Download PIcons" , boundFunction(self.VVhB4x, mode)     , [])
    VV4CnB = ("Add ALL to Bouquet" , boundFunction(self.VVXypx, mode, bName) , [])
   VVBfeb = (""      , boundFunction(self.VVJ8Uo, mode)    , [])
   VVRPnY = ("Home Menu"    , FFVS4w             , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVJRZ2  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , CENTER)
   VVkjiR = FF8HHs(self, None, title=title, header=header, VVPIPy=VVNZTI, VVJRZ2=VVJRZ2, VVZt3N=widths, VVdfkW=26, VVRPnY=VVRPnY, VVg6wQ=VVg6wQ, VV4CnB=VV4CnB, VV5Dm0=VV5Dm0, VVBfeb=VVBfeb, VVgzpW=VVgzpW, VVTK1M=VVTK1M, VVKZRt=VVKZRt, VVPQde=VVPQde, VVSFYp=True, searchCol=1)
   if not VVxBnX:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVkjiR.VVLWMK(VVkjiR.VVuNA3() + tot)
    if threadErr: FFdxmx(VVkjiR, "Error while reading !", 2000)
    else  : FFdxmx(VVkjiR, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FF2nrW(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FF2nrW(self, "Could not get list from server !", title=title)
 def VVJ8Uo(self, mode, VVkjiR, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFFhkT(self, fncMode=CC9cgb.VVW4R8, portalHost=self.VVJNUV, portalMac=self.VVpo1f, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVMStP(mode, VVkjiR, title, txt, colList)
 def VVWcwa(self, mode, VVkjiR, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FF5Q6H(colList[10], VViEcp)
  txt += "Description:\n%s" % FF5Q6H(colList[11], VViEcp)
  self.VVMStP(mode, VVkjiR, title, txt, colList)
 def VVMStP(self, mode, VVkjiR, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VViGpg(mode, colList)
  refCode, chUrl = self.VVeG8v(self.VVJNUV, self.VVpo1f, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFFhkT(self, fncMode=CC9cgb.VVQafY, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVLWmq(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile = self.VV5T76()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VVNZTI, total_items, max_page_items, err = self.VVPkdc(mode, catID, 1, 1, searchName)
   if progBarObj.isCancelled:
    return
   if progBarObj.VVNZTI and total_items > -1 and max_page_items > -1:
    progBarObj.VVxjCs(total_items)
    progBarObj.VVaQEg(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVPkdc(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VVshfS()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VVNZTI += list
      progBarObj.VVaQEg(len(list), True)
  except:
   pass
 def VVPkdc(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url =self.VV2JMa(mode, searchName, page)
  else   : url =self.VVU37j(mode, catID, page)
  res, err = self.VVbZaq(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVZoJ2(CCqLir.VVQ0IT(item, "total_items" ))
     max_page_items = self.VVZoJ2(CCqLir.VVQ0IT(item, "max_page_items" ))
     processChanName = CChTqt()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCqLir.VVQ0IT(item, "id"    )
      name   = CCqLir.VVQ0IT(item, "name"   )
      tv_genre_id  = CCqLir.VVQ0IT(item, "tv_genre_id" )
      number   = CCqLir.VVQ0IT(item, "number"   ) or str(counter)
      logo   = CCqLir.VVQ0IT(item, "logo"   )
      screenshot_uri = CCqLir.VVQ0IT(item, "screenshot_uri" )
      cmd    = CCqLir.VVQ0IT(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      if mode == "itv" and not cmdStr in cmd:
       span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
      picon   = logo or screenshot_uri
      counter += 1
      name = processChanName.VVk2UI(name)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVXypx(self, mode, bName, VVkjiR, title, txt, colList):
  FFikZL(VVkjiR, boundFunction(self.VVmb88, mode, bName, VVkjiR, title, txt, colList), title="Adding Channels ...")
 def VVmb88(self, mode, bName, VVkjiR, title, txt, colList):
  bNameFile = CCqLir.VVwKkN(bName)
  num  = 0
  path = VVg7D5 + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVg7D5 + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVkjiR.VVpWYB():
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VViGpg(mode, row)
    refCode, chUrl = self.VVeG8v(self.VVJNUV, self.VVpo1f, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
    totChange += 1
  FFbI82(os.path.basename(path))
  self.VVSmgj(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVZoJ2(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVo8rB(self, mode, fromPlayer, VVkjiR, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VViGpg(mode, colList)
  refCode, chUrl = self.VVeG8v(self.VVJNUV, self.VVpo1f, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if fromPlayer:
   self.VVYDWI(mode, VVkjiR, chUrl)
  elif self.VVRF0R(chName):
   FFdxmx(VVkjiR, "This is a marker!", 300)
  else:
   FFikZL(VVkjiR, boundFunction(self.VVYDWI, mode, VVkjiR, chUrl), title="Playing ...")
 def VVYDWI(self, mode, VVkjiR, chUrl):
  FFKIZZ(self, chUrl, VVOeQH=False)
  self.session.open(CCkdPb, portalTableParam=(self, VVkjiR, mode))
 def VViGpg(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName, catID, stID, chNum, chCm, serCode, serId, picUrl
class CCqLir(Screen, CCUv7m):
 VVxbYt = 0
 VVaArF = 1
 VVZNGa = 2
 VVhQSi = 3
 VV3AHB  = 4
 VVVz23  = 5
 VV4puG  = 6
 VVGruW  = 7
 VVIWdR   = 8
 VVXWvJ  = 9
 VVcYU0  = 10
 VVcAK0  = 11
 VVtS4G  = 12
 VVvDoX   = 13
 VV2ORE   = 14
 VVnSbZ   = 15
 VVRUSO   = 16
 VVduEd   = 17
 VVeI6s    = 0
 VVLcYV   = 1
 VVTNFe   = 2
 VVzsnQ   = 3
 VVelPj  = 4
 VV5vob  = 5
 VV16eS   = 6
 VVBTM4   = 7
 VVMyFT  = 8
 VVGypT  = 9
 VVBsDR  = 10
 def __init__(self, session):
  self.skin, self.skinParam = FFXEzn(VVdXwL, 1000, 1050, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.VVkjiR  = None
  self.tableTitle   = "IPTV Channels List"
  self.VVhRN2Data  = {}
  self.lastFindIptvName = ""
  CCUv7m.__init__(self)
  VVRJT5= self.VVorzL()
  FFnDik(self, title="IPTV", VVRJT5=VVRJT5)
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  FF0xrD(self["myMenu"])
  FFJAKu(self)
  FFhaOv(self)
 def VVorzL(self):
  files = self.VVjdyK()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"    , "VVhRN2_fromPlayList" ))
  tList.append(("IPTV Server Browser (from Portal File)"    , "VVhRN2_fromMac"  ))
  tList.append(("IPTV Server Browser (from M3U File)"     , "VVhRN2_fromM3u"  ))
  qUrl, iptvRef = self.VVyxE7()
  if qUrl:
   tList.append(("IPTV Server Browser (from Current Channel)"  , "VVhRN2_fromCurrChan" ))
  VVRJT5 = []
  if files:
   if self.VVkjiR:
    VVRJT5.append(("Add Current List to a New Bouquet"      , "VVMREB"  ))
    VVRJT5.append(VVn6Em)
    VVRJT5.append(("Change Current List References to Unique Codes"   , "VV1kui"))
    VVRJT5.append(("Change Current List References to Identical Codes"  , "VVOeZB_rows" ))
    VVRJT5.append(VVn6Em)
    VVRJT5.append(("Share Reference with Satellite/C/T Service (manual entry)", "VVMfZg"   ))
    VVRJT5.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VVa6hJ"   ))
   else:
    VVRJT5 += tList
    VVRJT5.append(VVn6Em)
    VVRJT5.append(("Local IPTV Channels"          , "iptvTable_all"   ))
    VVRJT5.append(VVn6Em)
    VVRJT5.append(("Count Available IPTV Channels"       , "VVPXFa"    ))
    VVRJT5.append(("Check Reference Codes Format"        , "VVvrPw"   ))
    VVRJT5.append(("Check System Acceptable Reference Types"     , "VVpcZn"   ))
    VVRJT5.append(VVn6Em)
    VVRJT5.append(("Share Reference with Sat./C/T (Only Matching Names)"  , "VVl78Y" ))
    VVRJT5.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VV7RmT"  ))
    VVRJT5.append(("Change ALL References to Unique Codes"     , "VVfbDh" ))
    VVRJT5.append(("Change ALL References to Identical Codes"     , "VVOeZB_all" ))
  if not self.VVkjiR:
   if not files:
    VVRJT5 += tList
   VVRJT5.append(VVn6Em)
   VVRJT5.append(("Analyse m3u File"            , "VVt5v9"   ))
   VVRJT5.append(("Convert m3u File to Bouquet (from File Manager)"    , "VVxF4j" ))
   VVRJT5.append(("Convert m3u File to Bouquet (from m3u File List)"    , "VV9mz9" ))
   VVRJT5.append(('Convert m3u File to Bouquet (Download from "Play Lists")'  , "VVA8pJ" ))
   VVRJT5.append(VVn6Em)
   VVRJT5.append(("Reload Channels and Bouquets"         , "VVU1oq"   ))
  return VVRJT5
 def VVXNpT(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   if   item == "VVMREB"   : FFzere(self, self.VVMREB, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VV1kui" : FFjphE(self, boundFunction(FFikZL, self.VVkjiR, self.VV1kui ), "Change Current List References to Unique Codes ?")
   elif item == "VVOeZB_rows" : FFjphE(self, boundFunction(FFikZL, self.VVkjiR, self.VVOeZB   ), "Change Current List References to Identical Codes ?")
   elif item == "VVMfZg"   : self.VVMfZg(tTitle)
   elif item == "VVa6hJ"   : self.VVa6hJ(tTitle)
   elif item == "VVhRN2_fromPlayList" : FFikZL(self, boundFunction(self.VVFk63, True), title="Searching ...")
   elif item == "VVhRN2_fromM3u"  : FFikZL(self, boundFunction(self.VVyiV1, 0), title="Searching ...")
   elif item == "VVhRN2_fromMac"  : self.VVYbz7()
   elif item == "VVhRN2_fromCurrChan" : self.VVsyEW_fromCurrChan()
   elif item == "iptvTable_live"   : FFikZL(self, boundFunction(self.VVZ1mE, self.VVGruW ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFikZL(self, boundFunction(self.VVZ1mE, self.VVxbYt) , title="Loading Channels ...")
   elif item == "VVPXFa"    : FFikZL(self, self.VVPXFa)
   elif item == "VVvrPw"    : FFikZL(self, self.VVvrPw)
   elif item == "VVpcZn"   : FFikZL(self, self.VVpcZn)
   elif item == "VVl78Y"  : FFjphE(self, boundFunction(FFikZL, self, self.VVl78Y ), "Continue ?")
   elif item == "VV7RmT"  : self.VV7RmT()
   elif item == "VVfbDh" : FFjphE(self, boundFunction(FFikZL, self, self.VVfbDh ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVOeZB_all" : FFjphE(self, boundFunction(FFikZL, self, self.VVOeZB  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "VVt5v9"   : FFikZL(self, boundFunction(self.VVyiV1, 1), title="Searching ...")
   elif item == "VVxF4j" : self.VVxF4j()
   elif item == "VV9mz9" : FFikZL(self, boundFunction(self.VVyiV1, 2), title="Searching ...")
   elif item == "VVA8pJ" : FFikZL(self, boundFunction(self.VVFk63, False), title="Searching ...")
   elif item == "VVU1oq"   : FFikZL(self, boundFunction(CCRv1a.VVU1oq, self))
 def VVDa6H(self):
  global VVQNCe
  VVQNCe = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVXNpT(item)
 def VVZ1mE(self, mode):
  VVbqDw = self.VVxty7(mode)
  if VVbqDw:
   VVg6wQ = ("Current Service", self.VVmUk9    , [])
   VV4CnB = ("Options"  , self.VVydDO      , [])
   VVqvqX = ("Filter"   , self.VVAW6q       , [])
   VV5Dm0  = ("Play"   , boundFunction(self.VVc4hX, False) , [])
   VVBfeb = (""    , self.VVPGc4       , [])
   VV1FjN = (""    , self.VVOe6k        , [])
   VVRPWD = (""    , self.VVZAWv       , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVJRZ2  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FF8HHs(self, None, header=header, VVPIPy=VVbqDw, VVJRZ2=VVJRZ2, VVZt3N=widths, VVdfkW=26
     , VV5Dm0=VV5Dm0, VVg6wQ=VVg6wQ, VV4CnB=VV4CnB, VVqvqX=VVqvqX, VVBfeb=VVBfeb, VV1FjN=VV1FjN
     , VVgzpW="#0a00292B", VVTK1M="#0a002126", VVKZRt="#0a002126", VVPQde="#00000000", VVSFYp=True, searchCol=1)
  else:
   if mode == self.VVGruW: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FF2nrW(self, err)
 def VVOe6k(self, VVkjiR, title, txt, colList):
  self.VVkjiR = VVkjiR
 def VVZAWv(self, VVkjiR):
  self.VVkjiR = None
 def VVydDO(self, VVkjiR, title, txt, colList):
  VVRJT5= self.VVorzL()
  FF4JCK(self, self.VVXNpT, title="IPTV Tools", VVRJT5=VVRJT5)
 def VVAW6q(self, VVkjiR, title, txt, colList):
  VVRJT5 = []
  VVRJT5.append(("All"         , "all"   ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Prefix of Selected Channel"   , "sameName" ))
  VVRJT5.append(("Suggest Words from Selected Channel" , "partName" ))
  VVRJT5.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Live TV"        , "live"  ))
  VVRJT5.append(("VOD"         , "vod"   ))
  VVRJT5.append(("Series"        , "series"  ))
  VVRJT5.append(("Uncategorised"      , "uncat"  ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Video"        , "video"  ))
  VVRJT5.append(("Audio"        , "audio"  ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("MKV"         , "MKV"   ))
  VVRJT5.append(("MP4"         , "MP4"   ))
  VVRJT5.append(("MP3"         , "MP3"   ))
  VVRJT5.append(("AVI"         , "AVI"   ))
  VVRJT5.append(("FLV"         , "FLV"   ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVtzgY()
  if bNames:
   bNames.sort()
   VVRJT5.append(VVn6Em)
   for item in bNames:
    VVRJT5.append((item, "__b__" + item))
  filterObj = CCQrIW(self)
  filterObj.VVekvZ(VVRJT5, VVRJT5, boundFunction(self.VVR5gU, VVkjiR))
 def VVR5gU(self, VVkjiR, item=None):
  prefix = VVkjiR.VVfyIm(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVxbYt, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVaArF , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVZNGa , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVhQSi , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVGruW  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVIWdR   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVXWvJ  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVcYU0  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVcAK0  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVtS4G  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVvDoX   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VV2ORE   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVnSbZ   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVRUSO   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVduEd   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VV4puG  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VV3AHB  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVVz23  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVZNGa:
   VVRJT5 = []
   chName = VVkjiR.VVfyIm(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVRJT5.append((item, item))
    if not VVRJT5 and chName:
     VVRJT5.append((chName, chName))
    FF4JCK(self, boundFunction(self.VVmho9_partOfName, title), title="Words from Current Selection", VVRJT5=VVRJT5)
   else:
    VVkjiR.VVWnVY("Invalid Channel Name")
  else:
   words, asPrefix = CCQrIW.VVqWPa(words)
   if not words and mode in (self.VV3AHB, self.VVVz23):
    FFdxmx(self.VVkjiR, "Incorrect filter", 2000)
   else:
    FFikZL(self.VVkjiR, boundFunction(self.VVrSaf, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVmho9_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFikZL(self.VVkjiR, boundFunction(self.VVrSaf, self.VVZNGa, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVLNHU(txt):
  return "#f#11ffff00#" + txt
 def VVrSaf(self, mode, words, asPrefix, title):
  VVbqDw = self.VVxty7(mode=mode, words=words, asPrefix=asPrefix)
  if VVbqDw : self.VVkjiR.VVRlUS(VVbqDw, title)
  else  : self.VVkjiR.VVWnVY("Not found")
 def VVxty7(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VVbqDw = []
  files  = self.VVjdyK()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FF83qF(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVGEPj = span.group(1)
    else : VVGEPj = ""
    VVGEPj_lCase = VVGEPj.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVRF0R(chName): chNameMod = self.VVLNHU(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVGEPj, chType, refCode, url)
     ok = False
     tUrl = FFxclk(url).lower()
     if mode == self.VVxbYt       : ok = True
     elif mode == self.VV4puG       : ok = True
     elif mode == self.VVcAK0:
      if CCqLir.VV5dpo(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVtS4G:
      if CCqLir.VV5dpo(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVGruW:
      if CCqLir.VV5dpo(tUrl, compareType="live")  : ok = True
     elif mode == self.VVIWdR:
      if CCqLir.VV5dpo(tUrl, compareType="movie") : ok = True
     elif mode == self.VVXWvJ:
      if CCqLir.VV5dpo(tUrl, compareType="series") : ok = True
     elif mode == self.VVcYU0:
      if CCqLir.VV5dpo(tUrl, compareType="")   : ok = True
     elif mode == self.VVvDoX:
      if CCqLir.VV5dpo(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VV2ORE:
      if CCqLir.VV5dpo(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVnSbZ:
      if CCqLir.VV5dpo(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVRUSO:
      if CCqLir.VV5dpo(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVduEd:
      if CCqLir.VV5dpo(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVaArF:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVZNGa:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVhQSi:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VV3AHB:
      if words[0] == VVGEPj_lCase:
       ok = True
     elif mode == self.VVVz23:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VVbqDw.append(row)
      chNum += 1
  if VVbqDw and mode == self.VV4puG:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VVbqDw)
   for item in VVbqDw:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VVbqDw = newRows
  return VVbqDw
 def VVMREB(self, bName):
  if bName:
   FFikZL(self.VVkjiR, boundFunction(self.VVxIo2, bName), title="Adding Channels ...")
 def VVxIo2(self, bName):
  num = 0
  path = VVg7D5 + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVg7D5 + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVkjiR.VVpWYB():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FF2A5P(row[1]))
    totChange += 1
  FFbI82(os.path.basename(path))
  self.VVSmgj(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VV7RmT(self):
  txt = "Stream Type "
  VVRJT5 = []
  VVRJT5.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVRJT5.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVRJT5.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVRJT5.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVRJT5.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVRJT5.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FF4JCK(self, self.VVbE3H, title="Change Reference Types to:", VVRJT5=VVRJT5)
 def VVbE3H(self, item=None):
  if item:
   if   item == "RT_1"  : self.VV1TSZ("1"   )
   elif item == "RT_4097" : self.VV1TSZ("4097")
   elif item == "RT_5001" : self.VV1TSZ("5001")
   elif item == "RT_5002" : self.VV1TSZ("5002")
   elif item == "RT_8192" : self.VV1TSZ("8192")
   elif item == "RT_8193" : self.VV1TSZ("8193")
 def VV1TSZ(self, rType):
  FFjphE(self, boundFunction(FFikZL, self, boundFunction(self.VVeYCC, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVeYCC(self, refType):
  totChange = 0
  files  = self.VVjdyK()
  if files:
   for path in files:
    txt = FF83qF(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFbI82(os.path.basename(path))
  self.VVSmgj(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVPXFa(self):
  totFiles = 0
  files  = self.VVjdyK()
  if files:
   totFiles = len(files)
  totChans = 0
  VVbqDw = self.VVxty7()
  if VVbqDw:
   totChans = len(VVbqDw)
  FFSnuH(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVvrPw(self):
  files  = self.VVjdyK()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FF83qF(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VV0Tnk
   else    : color = VVUqrB
   totInvalid = FF5Q6H(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FF5Q6H("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFSnuH(self, txt, title="Check IPTV References")
 def VVpcZn(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVg7D5 + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFbI82(os.path.basename(path))
  FFhJZy()
  acceptedList = []
  VVYxtS = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVYxtS:
   VV9Xua = FF6ji1(VVYxtS)
   if VV9Xua:
    for service in VV9Xua:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVg7D5 + userBName
  bFile = VVg7D5 + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FF3WD3("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FF3WD3("rm -f '%s'" % path)
  os.system(cmd)
  FFhJZy()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VV0Tnk
    else     : res, color = "No" , VVUqrB
    txt += "    %s\t: %s\n" % (item, FF5Q6H(res, color))
   FFSnuH(self, txt, title=title)
  else:
   txt = FF2nrW(self, "Could not complete the test on your system!", title=title)
 def VVl78Y(self):
  lameDbChans = CCRv1a.VV5Ca2(self, CCRv1a.VVULLW)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVjdyK():
    toSave = False
    txt = FF83qF(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVSmgj(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FF2nrW(self, 'No channels in "lamedb" !')
 def VVfbDh(self):
  files  = self.VVjdyK()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFxmgd(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVIAJP(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVSmgj(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VV1kui(self):
  iptvRefList = []
  files  = self.VVjdyK()
  if files:
   for path in files:
    txt = FF83qF(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVkjiR.VV398i(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVIAJP(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVjdyK()
  if files:
   for path in files:
    lines = FFxmgd(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVSmgj(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVIAJP(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVOeZB(self):
  list = None
  if self.VVkjiR:
   list = []
   for row in self.VVkjiR.VVpWYB():
    list.append(row[4] + row[5])
  files  = self.VVjdyK()
  totChange = 0
  if files:
   for path in files:
    lines = FFxmgd(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVSmgj(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVSmgj(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFhJZy()
   if refreshTable and self.VVkjiR:
    VVbqDw = self.VVxty7()
    if VVbqDw and self.VVkjiR:
     self.VVkjiR.VVRlUS(VVbqDw, self.tableTitle)
     self.VVkjiR.VVWnVY(txt)
   FFSnuH(self, txt, title=title)
  else:
   FFrerH(self, "No changes.")
 def VVtzgY(self):
  files = self.VVjdyK()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with open(path, "r") as f:
     span = iSearch(r"#NAME\s+(.*)", f.readline(), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VVFtwu = FFeLh9()
    if VVFtwu:
     for b in VVFtwu:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVjdyK(self):
  return CCqLir.VVVD4v(self)
 @staticmethod
 def VVVD4v(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVg7D5 + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FF83qF(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVPGc4(self, VVkjiR, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFxclk(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFFhkT(self, fncMode=CC9cgb.VV1LFz, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVc4hX(self, fromPlayer, VVkjiR, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  self.VVfqBH(fromPlayer, VVkjiR, chName, chUrl, "localIptv")
 def VVe2ks(self, mode, fromPlayer, VVkjiR, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVQB5k(mode, colList)
  self.VVfqBH(fromPlayer, VVkjiR, chName, chUrl, mode)
 def VVfqBH(self, fromPlayer, VVkjiR, chName, chUrl, playerFlag):
  chName = FF2A5P(chName)
  if fromPlayer:
   self.VVLZ4i(VVkjiR, chUrl, playerFlag)
  elif self.VVRF0R(chName):
   FFdxmx(VVkjiR, "This is a marker!", 300)
  else:
   FFikZL(VVkjiR, boundFunction(self.VVLZ4i, VVkjiR, chUrl, playerFlag), title="Playing ...")
 def VVLZ4i(self, VVkjiR, chUrl, playerFlag):
  FFKIZZ(self, chUrl, VVOeQH=False)
  self.session.open(CCkdPb, portalTableParam=(self, VVkjiR, playerFlag))
 @staticmethod
 def VVRF0R(chName):
  mark = ("--", "__", "==", "##", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVmUk9(self, VVkjiR, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFuTJ(self)
  if refCode:
   bName = FFeowy()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFwA9I(refCode, origUrl, chName) }
   VVkjiR.VVg3Na_partial(colDict, VVxCvy=True)
 def VVxF4j(self):
  self.session.open(CCNIug)
  self.close()
 def VVyiV1(self, m3uMode):
  path = CCqLir.VVlyCf()
  lines = FFo8V2("find %s %s -iname '*.m3u' | grep -i '.m3u'" % (path, FFyECp(1)))
  if lines:
   lines.sort()
   VVRJT5 = []
   for line in lines:
    VVRJT5.append((line, line))
   if   m3uMode == 0 : title = "Browse Server from M3U URLs"
   elif m3uMode == 1 : title = "Analyse M3U File"
   else    : title = "Convert M3U File to Bouquet"
   if m3uMode in [0, 2]: VVuTHu = ("All to Playlist", self.VVBYPg)
   else    : VVuTHu = None
   OKBtnFnc = boundFunction(self.VVAdcL, m3uMode, title)
   VVZZ8a = ("Show Full Path", self.VVAm7C)
   FF4JCK(self, None, title=title, VVRJT5=VVRJT5, OKBtnFnc=OKBtnFnc, VVZZ8a=VVZZ8a, VVuTHu=VVuTHu)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n\n%s" % path
   FF2nrW(self, 'No ".m3u" files found %s' % txt)
 def VVAm7C(self, VVw3blObj, url):
  FFSnuH(self, url, title="Full Path")
 def VVAdcL(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if   m3uMode == 0 : FFikZL(menuInstance, boundFunction(self.VVdBOe, title, path))
   elif m3uMode == 1 : self.VVt5v9(title, path)
   else    : self.VV2IrI(menuInstance, path)
 def VVBYPg(self, VVw3blObj, item=None):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVw3blObj.VVRJT5):
    path = item[1]
    if fileExists(path):
     with open(path, "r") as f:
      for line in f:
       url = self.VVqiYf(line)
       if url:
        if not url in pList : pList.append(url)
        else    : dupl += 1
        break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCqLir.VVlyCf()
    if path == "/":
     path = CFG.exportedTablesPath.getValue()
    pListF = "%sPlaylist_%s.txt" % (FFq2Op(path), FF8AiB())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVw3blObj.VVRJT5)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFSnuH(self, txt, title=title)
   else:
    FF2nrW(self, "Could not obtain URLs from this file list !", title=title)
 def VVt5v9(self, title, path):
  if fileExists(path):
   self.session.open(CCi8Vp, barTheme=CCi8Vp.VV3KQm
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VV032r, path)
       , VVRVdr = boundFunction(self.VVEStt, title, path))
  else:
   FF2nrW(SELF, "Cannot open file :\n\n%s" % path, title=title)
 def VVEStt(self, title, path, VVxBnX, VVNZTI, threadCounter, threadTotal, threadErr):
  if VVxBnX:
   FFSnuH(self, VVNZTI, title=title)
 def VV032r(self, path, progBarObj):
  totChan   = 0
  totLive   = 0
  totVod   = 0
  totSeries  = 0
  totUncat  = 0
  totVideo  = 0
  totAudio  = 0
  txt = FF83qF(path)
  lst = iFindall(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?((.+)(:[^:\/]+$)|.+)", txt, IGNORECASE)
  txt = ""
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVNZTI = ""
  progBarObj.VVxjCs(len(lst))
  for item in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVaQEg(1, True)
   totChan += 1
   chName  = item[0].strip()
   fullUrl  = item[1].strip()
   urlPart1 = item[2]
   if urlPart1 : tUrl = urlPart1
   else  : tUrl = fullUrl
   tUrl = FFxclk(tUrl).lower()
   chType, host, username, password, streamId, chName = CCqLir.VV5dpo(tUrl)
   if   chType == "live" : totLive += 1
   elif chType == "movie" : totVod += 1
   elif chType == "series" : totSeries += 1
   else     : totUncat += 1
   aud_vid = CCqLir.VV5dpo(tUrl, getAudVid=True)
   if   aud_vid == "vid" : totVideo += 1
   elif aud_vid == "aud" : totAudio += 1
  txt = ""
  txt += FF5Q6H("File:\n", VVbaBa)
  txt += "    %s\n"   % path
  txt += "\n"
  txt += FF5Q6H("Channels:\n", VVbaBa)
  if lst:
   txt += "    Total\t: %d\n" % totChan
   txt += "\n"
   txt += FF5Q6H("Category:\n", VVbaBa)
   txt += "    Live\t: %d\n" % totLive
   txt += "    VOD\t: %d\n" % totVod
   txt += "    Series\t: %d\n" % totSeries
   txt += "    Uncat.\t: %d\n" % totUncat
   txt += "\n"
   txt += FF5Q6H("Content:\n", VVbaBa)
   txt += "    Video\t: %d\n" % totVideo
   txt += "    Audio\t: %d\n" % totAudio
   txt += "\n"
  else:
   txt += "    No channels  (or invalid file file format)"
  if progBarObj:
   progBarObj.VVNZTI = txt
 def VVFk63(self, isBrowseServer):
  path = CCqLir.VVlyCf()
  lines = FFo8V2('find %s %s -iname "*playlist*" | grep -i ".txt"' % (path, FFyECp(1)))
  if lines:
   lines.sort()
   VVRJT5 = []
   for line in lines:
    VVRJT5.append((line, line))
   OKBtnFnc = boundFunction(self.VVXljs, isBrowseServer)
   FF4JCK(self, None, title="Select Playlist File", VVRJT5=VVRJT5, width=1200, OKBtnFnc=OKBtnFnc)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FF2nrW(self, 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt)
 def VVXljs(self, isBrowseServer, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFikZL(menuInstance, boundFunction(self.VVJxQi, menuInstance, path, isBrowseServer), title="Processing File ...")
 def VVJxQi(self, fileMenuInstance, path, isBrowseServer):
  VVRJT5 = []
  lines = FFxmgd(path)
  for line in lines:
   line = line.strip()
   span = iSearch(r"(http.+php.+username=.+password=.+)(?:[&]+)*", line, IGNORECASE)
   if span:
    VVRJT5.append((span.group(1), span.group(1)))
   else:
    span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
    if span:
     host = FFq2Op(span.group(1).strip())
     user1 = span.group(2).strip()
     pass1 = span.group(3).strip()
     line = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
     VVRJT5.append((line, line))
  if VVRJT5:
   if isBrowseServer : title = "Select Server URL  (Total = %d)" % len(VVRJT5)
   else    : title = "Convert to Bouquet"
   OKBtnFnc  = boundFunction(self.VV14mz, isBrowseServer, title)
   VVrFC4  = ("Home Menu"  , FFVS4w)
   VVZZ8a  = ("Show URL"  , self.VVSyMB)
   VVuTHu   = ("Check & Filter" , boundFunction(self.VVTjny, fileMenuInstance, path, isBrowseServer))
   FF4JCK(self, None, title=title, VVRJT5=VVRJT5, width=1200, OKBtnFnc=OKBtnFnc, VVrFC4=VVrFC4, VVZZ8a=VVZZ8a, VVuTHu=VVuTHu)
  else:
   FF2nrW(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVSyMB(self, VVw3blObj, url):
  FFSnuH(self, url, title="URL")
 def VV14mz(self, isBrowseServer, title, item=None):
  if item:
   menuInstance, txt, url, ndx = item
   if isBrowseServer:
    FFikZL(menuInstance, boundFunction(self.VVErKz, title, url), title="Checking Server ...")
   else:
    FFjphE(self, boundFunction(FFikZL, menuInstance, boundFunction(self.VVHDOB, menuInstance, url), title="Downloading ..."), "Download m3u file from this URL ?\n\n%s" % url, title=title)
 def VVHDOB(self, menuInstance, url):
  path, err = FFj4ge(url, "ajpanel_tmp.m3u", timeout=3)
  title = "Download Problem"
  if err:
   FF2nrW(self, err, title=title)
  else:
   if fileExists(path):
    txt = FF83qF(path)
    if '{"user_info":{"auth":0}}' in txt:
     FF2nrW(self, "Unauthorized", title=title)
     os.system(FF3WD3("rm -f '%s'" % path))
     return
   self.VV2IrI(menuInstance, path)
 def VVMfZg(self, title):
  curChName = self.VVkjiR.VVfyIm(1)
  FFzere(self, boundFunction(self.VVHNOD, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVHNOD(self, title, name):
  if name:
   lameDbChans = CCRv1a.VV5Ca2(self, CCRv1a.VVIyvx, VVMvwR=False, VVRKaR=False)
   list = []
   if lameDbChans:
    processChanName = CChTqt()
    name = processChanName.VVz4Nk(name)
    ratio = "1"
    for item in lameDbChans:
     if name in item[0].lower():
      list.append((item[0], FFOGxT(item[2]), item[3], ratio))
   if list : self.VV1iMN(list, title)
   else : FF2nrW(self, "Not found:\n\n%s" % name, title=title)
 def VVa6hJ(self, title):
  curChName = self.VVkjiR.VVfyIm(1)
  self.session.open(CCi8Vp, barTheme=CCi8Vp.VV3KQm
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVNLyZ
      , VVRVdr = boundFunction(self.VVGuxp, title, curChName))
 def VVNLyZ(self, progBarObj):
  curChName = self.VVkjiR.VVfyIm(1)
  lameDbChans = CCRv1a.VV5Ca2(self, CCRv1a.VVboHa, VVMvwR=False, VVRKaR=False)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVNZTI = []
  progBarObj.VVxjCs(len(lameDbChans))
  processChanName = CChTqt()
  curCh = processChanName.VVz4Nk(curChName)
  for refCode in lameDbChans:
   chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
   ratio = CCgeLj.VVmXQu(chName.lower(), curCh)
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVaQEg(1, True)
   if ratio > 50:
    progBarObj.VVNZTI.append((chName, FFOGxT(sat), refCode.replace("_", ":"), str(ratio)))
 def VVGuxp(self, title, curChName, VVxBnX, VVNZTI, threadCounter, threadTotal, threadErr):
  if VVNZTI : self.VV1iMN(VVNZTI, title)
  elif VVxBnX : FF2nrW(self, "No similar names found for:\n\n%s" % curChName, title)
 def VV1iMN(self, VVbqDw, title):
  curChName = self.VVkjiR.VVfyIm(1)
  curRefCode = self.VVkjiR.VVfyIm(4)
  curUrl  = self.VVkjiR.VVfyIm(5)
  VVbqDw = sorted(VVbqDw, key=lambda x: (100-int(x[3]), x[0].lower()))
  VV5Dm0  = ("Share Sat/C/T Ref.", boundFunction(self.VVXmG1, title, curChName, curRefCode, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FF8HHs(self, None, title=title, header=header, VVPIPy=VVbqDw, VVZt3N=widths, VVdfkW=26, VV5Dm0=VV5Dm0, VVgzpW="#0a00112B", VVTK1M="#0a001126", VVKZRt="#0a001126", VVPQde="#00000000")
 def VVXmG1(self, newtitle, curChName, curRefCode, curUrl, VVkjiR, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFjphE(self.VVkjiR, boundFunction(FFikZL, self.VVkjiR, boundFunction(self.VVVFZG, VVkjiR, data)), ques, title=newtitle, VVzwqf=True)
 def VVVFZG(self, VVkjiR, data):
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  if curFullUrl and newFullUrl:
   for path in self.VVjdyK():
    txt = FF83qF(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFhJZy()
    newRow = []
    for i in range(6):
     newRow.append(self.VVkjiR.VVfyIm(i))
    newRow[4] = newRefCode
    done = self.VVkjiR.VVffu3(newRow)
    FFrerH(self, "Done", title=title)
   else:
    FF2nrW(self, "Not found in IPTV files !", title=title)
  else:
   FF2nrW(self, "Could not read channel info !", title=title)
  VVkjiR.cancel()
 def VVTjny(self, fileMenuInstance, path, isBrowseServer, urlMenuInstance, item):
  self.session.open(CCi8Vp, barTheme=CCi8Vp.VV3KQm
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VVu4jk, urlMenuInstance)
      , VVRVdr = boundFunction(self.VVkjp0, fileMenuInstance, path, isBrowseServer, urlMenuInstance))
 def VVu4jk(self, urlMenuInstance, progBarObj):
  progBarObj.VVxjCs(len(urlMenuInstance.VVRJT5))
  progBarObj.VVNZTI = []
  for ndx, item in enumerate(urlMenuInstance.VVRJT5):
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVaQEg(1, True)
   qUrl = self.VVPQGe(self.VVeI6s, item[0])
   txt, err = self.VVru3x(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVQ0IT(item, "auth") == "0":
       progBarObj.VVNZTI.append(qUrl)
    except:
     pass
 def VVkjp0(self, fileMenuInstance, path, isBrowseServer, urlMenuInstance, VVxBnX, VVNZTI, threadCounter, threadTotal, threadErr):
  if VVxBnX:
   list = VVNZTI
   title = "Authorized Servers"
   if list:
    totChk = len(urlMenuInstance.VVRJT5)
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FF8AiB()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVFk63(isBrowseServer)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FF5Q6H(str(totAuth), VV0Tnk)
     txt += "%s\n\n%s"     %  (FF5Q6H("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFSnuH(self, txt, title=title)
     urlMenuInstance.close()
     fileMenuInstance.close()
    else:
     FFrerH(self, "All URLs are authorized.", title=title)
   else:
    FF2nrW(self, "No authorized URL found !", title=title)
 def VV2IrI(self, parentInstant, path):
  files = CCqLir.VVVD4v(self, atLeastOne=True)
  if files: exitCurWin = False
  else : exitCurWin = True
  CCqLir.VVlamL(parentInstant, path, exitCurWin)
 @staticmethod
 def VVlamL(SELF, path, exitCurWin):
  FFjphE(SELF, boundFunction(FFikZL, SELF, boundFunction(CCqLir.VV8uYG, SELF, path, exitCurWin), title="Converting ...")
    , "Convert file to bouquet ?\n\n%s" % path, title="Convert m3u file")
 @staticmethod
 def VV8uYG(SELF, path, exitCurWin):
  SID = TSID = ONID = 0
  MAX = 65535
  title = "Convert m3u File to Bouquet"
  if not fileExists(path):
   FF2nrW(SELF, "Cannot open file :\n\n%s" % path, title=title)
   return
  bName  = os.path.basename(path)
  bName  = os.path.splitext(bName)[0]
  bName   = CCqLir.VVwKkN(bName)
  bName  = "IPTV_" + bName
  bFileName = "userbouquet.%s.tv" % bName
  if fileExists(VVg7D5 + bFileName):
   while True:
    SID += 1
    tmpBName = "%s_%d" % (bName, SID)
    bFileName = "userbouquet.%s.tv" % tmpBName
    if not fileExists(VVg7D5 + bFileName):
     bName = tmpBName
     break
  txt = FF83qF(path)
  pattern = r"#EXTINF.+,(.+)\n(.+)"
  span = iSearch(r"#EXTINF.+,(.+)\n(.+)", txt, IGNORECASE)
  if span:
   with open(VVg7D5 + bFileName, "w") as f:
    totChan = 0
    f.write("#NAME %s\n" % bName.replace("IPTV_", "IPTV - ", 1))
    for match in iFinditer(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?(.+)", txt, IGNORECASE):
     TSID += 1
     if TSID > MAX:
      TSID = MAX
      ONID += 1
      if ONID > MAX:
       ONID = 0
     chName = match.group(1).strip()
     url  = FF8kZC(match.group(2).strip())
     rType = CFG.iptvAddToBouquetRefType.getValue()
     refCode = "%s:0:1:%s:%s:%s:0:0:0:0:" % (rType, hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:])
     line1 = "#SERVICE %s%s\n" % (refCode.upper(), url)
     line2 = "#DESCRIPTION %s\n" % chName
     f.write(line1 + line2)
     totChan += 1
   FFbI82(bFileName)
   FFhJZy()
   FFrerH(SELF, 'New Bouquet = %s\n\nTotal Channels = %d' % (bName, totChan), title=title)
  else:
   FF2nrW(SELF, "No channels found in file (or invalid file format) !\n\n%s" % path, title=title)
  if exitCurWin:
   SELF.close()
 @staticmethod
 def VVru3x(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   res = res.read().decode("UTF-8")
   if res:
    if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server !"
    else           : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VV2TSV(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VV5dpo(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = parts[1]
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVPQGe(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VV2TSV(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVeI6s   : return "%s"            % url
  elif mode == self.VVLcYV   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVTNFe   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVzsnQ  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVelPj  : return "%s&action=get_live_categories"     % url
  elif mode == self.VV5vob : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VV16eS   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVBTM4    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVMyFT  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVBsDR : return "%s&action=get_live_streams"      % url
  elif mode == self.VVGypT  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVQ0IT(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFAQH0(int(val))
    elif is_base64 : val = FF3oSl(val)
    elif isToHHMMSS : val = FFUwdx(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVdBOe(self, title, path):
  if fileExists(path):
   qUrl = ""
   with open(path, "r") as f:
    for line in f:
     qUrl = self.VVqiYf(line)
     if qUrl:
      break
   if qUrl : self.VVErKz(title, qUrl)
   else : FF2nrW(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FF2nrW(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVsyEW_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVyxE7()
  if qUrl:
   host, mac, isPortalUrl = self.VVhTNs(iptvRef)
   if isPortalUrl:
    if host and mac : self.VVsyEW(self, host, mac)
    else   : FF2nrW(self, "Error in current channel URL/MAC !", title=title)
   else:
    FFikZL(self, boundFunction(self.VVErKz, title, qUrl), title="Checking Server ...")
  else:
   FF2nrW(self, "Error in current channel URL !", title=title)
 def VVyxE7(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFuTJ(self)
  qUrl = self.VVqiYf(decodedUrl)
  return qUrl, iptvRef
 def VVqiYf(self, url):
  if url.startswith("#"):
   return ""
  url = url.lstrip(" /").rstrip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) >= 2 : return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else    : return ""
 def VVErKz(self, title, url):
  self.VVhRN2Data = {}
  qUrl = self.VVPQGe(self.VVeI6s, url)
  txt, err = self.VVru3x(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVhRN2Data = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVhRN2Data["username"    ] = self.VVQ0IT(item, "username"        )
    self.VVhRN2Data["password"    ] = self.VVQ0IT(item, "password"        )
    self.VVhRN2Data["message"    ] = self.VVQ0IT(item, "message"        )
    self.VVhRN2Data["auth"     ] = self.VVQ0IT(item, "auth"         )
    self.VVhRN2Data["status"    ] = self.VVQ0IT(item, "status"        )
    self.VVhRN2Data["exp_date"    ] = self.VVQ0IT(item, "exp_date"    , isDate=True )
    self.VVhRN2Data["is_trial"    ] = self.VVQ0IT(item, "is_trial"        )
    self.VVhRN2Data["active_cons"   ] = self.VVQ0IT(item, "active_cons"       )
    self.VVhRN2Data["created_at"   ] = self.VVQ0IT(item, "created_at"   , isDate=True )
    self.VVhRN2Data["max_connections"  ] = self.VVQ0IT(item, "max_connections"      )
    self.VVhRN2Data["allowed_output_formats"] = self.VVQ0IT(item, "allowed_output_formats"    )
    lst = []
    key = "allowed_output_formats"
    if key in item:
     for item in item[key]:
      lst.append(str(item))
     self.VVhRN2Data[key] = lst
    item = tDict["server_info"]
    self.VVhRN2Data["url"    ] = self.VVQ0IT(item, "url"        )
    self.VVhRN2Data["port"    ] = self.VVQ0IT(item, "port"        )
    self.VVhRN2Data["https_port"  ] = self.VVQ0IT(item, "https_port"      )
    self.VVhRN2Data["server_protocol" ] = self.VVQ0IT(item, "server_protocol"     )
    self.VVhRN2Data["rtmp_port"   ] = self.VVQ0IT(item, "rtmp_port"       )
    self.VVhRN2Data["timezone"   ] = self.VVQ0IT(item, "timezone"       )
    self.VVhRN2Data["timestamp_now"  ] = self.VVQ0IT(item, "timestamp_now"  , isDate=True )
    self.VVhRN2Data["time_now"   ] = self.VVQ0IT(item, "time_now"       )
    VVRJT5  = self.VVAaN8(True)
    OKBtnFnc = self.VVhRN2Options
    VVrFC4 = ("Home Menu", FFVS4w)
    FF4JCK(self, None, title="IPTV Server Resources", VVRJT5=VVRJT5, OKBtnFnc=OKBtnFnc, VVrFC4=VVrFC4)
   else:
    err = "Could not get data from server !"
  if err:
   FF2nrW(self, err, title=title)
  FFdxmx(self)
 def VVhRN2Options(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFikZL(menuInstance, boundFunction(self.VVVdAf, self.VVLcYV  , title=title), title=wTxt)
   elif ref == "vod"   : FFikZL(menuInstance, boundFunction(self.VVVdAf, self.VVTNFe  , title=title), title=wTxt)
   elif ref == "series"  : FFikZL(menuInstance, boundFunction(self.VVVdAf, self.VVzsnQ , title=title), title=wTxt)
   elif ref == "catchup"  : FFikZL(menuInstance, boundFunction(self.VVVdAf, self.VVelPj , title=title), title=wTxt)
   elif ref == "accountInfo" : FFikZL(menuInstance, boundFunction(self.VVatDt           , title=title), title=wTxt)
 def VVatDt(self, title):
  rows = []
  for key, val in self.VVhRN2Data.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VVRPnY = ("Home Menu", FFVS4w, [])
  header   = ("Num", "User/Server" , "Subject" , "Value" )
  widths   = (0 , 15   , 35  , 50  )
  FF8HHs(self, None, title=title, width=1200, header=header, VVPIPy=rows, VVZt3N=widths, VVdfkW=26, VVRPnY=VVRPnY, VVgzpW="#0a00292B", VVTK1M="#0a002126", VVKZRt="#0a002126", VVPQde="#00000000", searchCol=2)
 def VVIEBG(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CChTqt()
    if mode in (self.VV16eS, self.VVGypT):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVQ0IT(item, "num"         )
      name     = self.VVQ0IT(item, "name"        )
      stream_id    = self.VVQ0IT(item, "stream_id"       )
      stream_icon    = self.VVQ0IT(item, "stream_icon"       )
      epg_channel_id   = self.VVQ0IT(item, "epg_channel_id"      )
      added     = self.VVQ0IT(item, "added"    , isDate=True )
      is_adult    = self.VVQ0IT(item, "is_adult"       )
      category_id    = self.VVQ0IT(item, "category_id"       )
      tv_archive    = self.VVQ0IT(item, "tv_archive"       )
      name = processChanName.VVk2UI(name)
      if name:
       if mode == self.VV16eS or mode == self.VVGypT and tv_archive == "1":
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVBTM4:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVQ0IT(item, "num"         )
      name    = self.VVQ0IT(item, "name"        )
      stream_id   = self.VVQ0IT(item, "stream_id"       )
      stream_icon   = self.VVQ0IT(item, "stream_icon"       )
      added    = self.VVQ0IT(item, "added"    , isDate=True )
      is_adult   = self.VVQ0IT(item, "is_adult"       )
      category_id   = self.VVQ0IT(item, "category_id"       )
      container_extension = self.VVQ0IT(item, "container_extension"     ) or "mp4"
      name = processChanName.VVk2UI(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVMyFT:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVQ0IT(item, "num"        )
      name    = self.VVQ0IT(item, "name"       )
      series_id   = self.VVQ0IT(item, "series_id"      )
      cover    = self.VVQ0IT(item, "cover"       )
      genre    = self.VVQ0IT(item, "genre"       )
      episode_run_time = self.VVQ0IT(item, "episode_run_time"    )
      category_id   = self.VVQ0IT(item, "category_id"      )
      container_extension = self.VVQ0IT(item, "container_extension"    ) or "mp4"
      name = processChanName.VVk2UI(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVVdAf(self, mode, title):
  cList, err = self.VVM06S(mode)
  if cList and mode == self.VVelPj:
   cList = self.VVIHf1(cList)
  if err:
   FF2nrW(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVgzpW, VVTK1M, VVKZRt, VVPQde = self.VVzunr(mode)
   mName = self.VVgDy0(mode)
   if   mode == self.VVLcYV  : fMode = self.VV16eS
   elif mode == self.VVTNFe  : fMode = self.VVBTM4
   elif mode == self.VVzsnQ : fMode = self.VVMyFT
   elif mode == self.VVelPj : fMode = self.VVGypT
   if mode == self.VVelPj:
    VV4CnB = None
   else:
    VV4CnB = ("Find in %s" % mName , boundFunction(self.VV6PQ1, fMode) , [])
   VV5Dm0   = ("Show List"   , boundFunction(self.VVwxI2, mode) , [])
   VVRPnY  = ("Home Menu"   , FFVS4w          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FF8HHs(self, None, title=title, width=1200, header=header, VVPIPy=cList, VVZt3N=widths, VVdfkW=30, VVRPnY=VVRPnY, VV4CnB=VV4CnB, VV5Dm0=VV5Dm0, VVgzpW=VVgzpW, VVTK1M=VVTK1M, VVKZRt=VVKZRt, VVPQde=VVPQde)
  else:
   FF2nrW(self, "No list from server !", title=title)
  FFdxmx(self)
 def VVM06S(self, mode):
  qUrl  = self.VVPQGe(mode, self.VVhRN2Data["playListURL"])
  txt, err = self.VVru3x(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    processChanName = CChTqt()
    for item in tDict:
     category_id  = self.VVQ0IT(item, "category_id"  )
     category_name = self.VVQ0IT(item, "category_name" )
     parent_id  = self.VVQ0IT(item, "parent_id"  )
     category_name = processChanName.VVoH8n(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVIHf1(self, catList):
  mode  = self.VVGypT
  qUrl  = self.VVPQGe(mode, self.VVhRN2Data["playListURL"])
  txt, err = self.VVru3x(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVIEBG(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVwxI2(self, mode, VVkjiR, title, txt, colList):
  title = colList[1]
  FFikZL(VVkjiR, boundFunction(self.VVSbXZ, mode, VVkjiR, title, txt, colList), title="Downloading ...")
 def VVSbXZ(self, mode, VVkjiR, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVgDy0(mode) + " : "+ bName
  if   mode == self.VVLcYV  : mode = self.VV16eS
  elif mode == self.VVTNFe  : mode = self.VVBTM4
  elif mode == self.VVzsnQ : mode = self.VVMyFT
  elif mode == self.VVelPj : mode = self.VVGypT
  qUrl  = self.VVPQGe(mode, self.VVhRN2Data["playListURL"], catID)
  txt, err = self.VVru3x(qUrl)
  list  = []
  if not err and mode in (self.VV16eS, self.VVBTM4, self.VVMyFT, self.VVGypT):
   list, err = self.VVIEBG(mode, txt)
  if err:
   FF2nrW(self, err, title=title)
  elif list:
   VVRPnY  = ("Home Menu"   , FFVS4w             , [])
   if mode in (self.VV16eS, self.VVGypT):
    VVgzpW, VVTK1M, VVKZRt, VVPQde = self.VVzunr(mode)
    VVBfeb = (""     , boundFunction(self.VVESzl, mode)     , [])
    VVg6wQ = ("Download PIcons" , boundFunction(self.VVhB4x, mode)     , [])
    VV4CnB = ("Add ALL to Bouquet" , boundFunction(self.VV3uuF, mode, bName)  , [])
    if mode == self.VV16eS:
     VV5Dm0 = ("Play"    , boundFunction(self.VVe2ks, mode, False)   , [])
    elif mode == self.VVGypT:
     VV5Dm0  = ("Programs", boundFunction(self.VVAJpR, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVJRZ2  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVBTM4:
    VVgzpW, VVTK1M, VVKZRt, VVPQde = self.VVzunr(mode)
    VV5Dm0  = ("Play"    , boundFunction(self.VVe2ks, mode, False)  , [])
    VVBfeb = (""     , boundFunction(self.VVESzl, mode)    , [])
    VVg6wQ = ("Download PIcons" , boundFunction(self.VVhB4x, mode)    , [])
    VV4CnB = ("Add ALL to Bouquet" , boundFunction(self.VV3uuF, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVJRZ2  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVMyFT:
    VVgzpW, VVTK1M, VVKZRt, VVPQde = self.VVzunr("series2")
    VV5Dm0  = ("Show Seasons", boundFunction(self.VVeKHc, mode) , [])
    VVBfeb = ("", boundFunction(self.VVm3st, mode)  , [])
    VVg6wQ = None
    VV4CnB = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVJRZ2  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FF8HHs(self, None, title=title, header=header, VVPIPy=list, VVJRZ2=VVJRZ2, VVZt3N=widths, VVdfkW=26, VV5Dm0=VV5Dm0, VVRPnY=VVRPnY, VVg6wQ=VVg6wQ, VV4CnB=VV4CnB, VVBfeb=VVBfeb, VVgzpW=VVgzpW, VVTK1M=VVTK1M, VVKZRt=VVKZRt, VVPQde=VVPQde, VVSFYp=True, searchCol=1)
  else:
   FF2nrW(self, "No Channels found !", title=title)
  FFdxmx(self)
 def VVAJpR(self, mode, bName, VVkjiR, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVhRN2Data["playListURL"]
  ok_fnc  = boundFunction(self.VVEDpo, hostUrl, chName, catId, streamId)
  FFikZL(VVkjiR, boundFunction(CCqLir.VVCw0P, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVEDpo(self, chUrl, chName, catId, streamId, VVkjiR, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCqLir.VV2TSV(chUrl)
   chNum = "333"
   refCode = CCqLir.VVNuOx(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFKIZZ(self, chUrl, VVOeQH=False)
   self.session.open(CCkdPb)
  else:
   FF2nrW(self, "Incorrect Timestamp", pTitle)
 def VVeKHc(self, mode, VVkjiR, title, txt, colList):
  title = colList[1]
  FFikZL(VVkjiR, boundFunction(self.VVU0Ys, mode, VVkjiR, title, txt, colList), title="Downloading ...")
 def VVU0Ys(self, mode, VVkjiR, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVPQGe(self.VV5vob, self.VVhRN2Data["playListURL"], series_id)
  txt, err = self.VVru3x(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVQ0IT(tDict["info"], "name"   )
      category_id = self.VVQ0IT(tDict["info"], "category_id" )
      icon  = self.VVQ0IT(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVQ0IT(EP, "id"     )
        episode_num   = self.VVQ0IT(EP, "episode_num"   )
        epTitle    = self.VVQ0IT(EP, "title"     )
        container_extension = self.VVQ0IT(EP, "container_extension" )
        seasonNum   = self.VVQ0IT(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FF2nrW(self, err, title=title)
  elif list:
   VVRPnY = ("Home Menu"   , FFVS4w            , [])
   VVg6wQ = ("Download PIcons" , boundFunction(self.VVhB4x , mode)   , [])
   VV4CnB = ("Add ALL to Bouquet" , boundFunction(self.VV3uuF, mode, title) , [])
   VVBfeb = (""     , boundFunction(self.VVESzl, mode)    , [])
   VV5Dm0  = ("Play"    , boundFunction(self.VVe2ks, mode, False)  , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVJRZ2  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FF8HHs(self, None, title=title, header=header, VVPIPy=list, VVJRZ2=VVJRZ2, VVZt3N=widths, VVdfkW=26, VVRPnY=VVRPnY, VVg6wQ=VVg6wQ, VV5Dm0=VV5Dm0, VVBfeb=VVBfeb, VV4CnB=VV4CnB, VVgzpW="#0a00292B", VVTK1M="#0a002126", VVKZRt="#0a002126", VVPQde="#00000000")
  else:
   FF2nrW(self, "No Channels found !", title=title)
  FFdxmx(self)
 def VV6PQ1(self, mode, VVkjiR, title, txt, colList):
  VVRJT5 = []
  VVRJT5.append(("Keyboard"  , "manualEntry"))
  VVRJT5.append(("From Filter" , "fromFilter"))
  FF4JCK(self, boundFunction(self.VVrK3T, VVkjiR, mode), title="Input Type", VVRJT5=VVRJT5, width=400)
 def VVrK3T(self, VVkjiR, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFzere(self, boundFunction(self.VVBLqo, VVkjiR, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCQrIW(self)
    filterObj.VVxbBu(boundFunction(self.VVBLqo, VVkjiR, mode))
 def VVBLqo(self, VVkjiR, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CChTqt()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVDLSn(words):
     FF2nrW(self, processChanName.VVWe90(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CCi8Vp, barTheme=CCi8Vp.VV3KQm
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VV20kz, VVkjiR, mode, title, words, toFind, asPrefix, processChanName)
         , VVRVdr = boundFunction(self.VVoktc, mode, toFind, title))
   else:
    FF2nrW(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VV20kz(self, VVkjiR, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVxjCs(VVkjiR.VVzWF7())
  progBarObj.VVNZTI = []
  for row in VVkjiR.VVpWYB():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVaQEg(1)
   progBarObj.VVIh7J_fromIptvFind(catName)
   qUrl  = self.VVPQGe(mode, self.VVhRN2Data["playListURL"], catID)
   txt, err = self.VVru3x(qUrl)
   if not err:
    tList, err = self.VVIEBG(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VVk2UI(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VV16eS:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VVNZTI.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVBTM4:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VVNZTI.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVMyFT:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VVNZTI.append((num, name, catID, ID, genre, catName, ext, cover))
 def VVoktc(self, mode, toFind, title, VVxBnX, VVNZTI, threadCounter, threadTotal, threadErr):
  if VVNZTI:
   title = self.VVpUDe(mode, toFind)
   if mode == self.VV16eS or mode == self.VVBTM4:
    bName   = CCqLir.VVwKkN(toFind)
    VV5Dm0  = ("Play"     , boundFunction(self.VVe2ks, mode, False)  , [])
    VV4CnB = ("Add ALL to Bouquet" , boundFunction(self.VV3uuF, mode, bName) , [])
    VVg6wQ = ("Download PIcons" , boundFunction(self.VVhB4x, mode)    , [])
   elif mode == self.VVMyFT:
    VV5Dm0  = ("Show Seasons"  , boundFunction(self.VVeKHc, mode)    , [])
    VV4CnB = None
    VVg6wQ = None
   VVBfeb = (""   , boundFunction(self.VVESzl, mode) , [])
   VVRPnY = ("Home Menu" , FFVS4w         , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVJRZ2  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVkjiR = FF8HHs(self, None, title=title, header=header, VVPIPy=VVNZTI, VVJRZ2=VVJRZ2, VVZt3N=widths, VVdfkW=26, VV5Dm0=VV5Dm0, VVRPnY=VVRPnY, VVg6wQ=VVg6wQ, VV4CnB=VV4CnB, VVBfeb=VVBfeb, VVgzpW="#0a00292B", VVTK1M="#0a002126", VVKZRt="#0a002126", VVPQde="#00000000", VVSFYp=True, searchCol=1)
   if not VVxBnX:
    FFdxmx(VVkjiR, "Stopped" , 1000)
  else:
   if VVxBnX:
    FF2nrW(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVQB5k(self, mode, colList):
  if mode in (self.VV16eS, self.VVGypT):
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVBTM4:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FF2A5P(chName)
  url = self.VVhRN2Data["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VV2TSV(url)
  refCode = self.VVNuOx(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVESzl(self, mode, VVkjiR, title, txt, colList):
  FFikZL(VVkjiR, boundFunction(self.VVeAv9, mode, VVkjiR, title, txt, colList))
 def VVeAv9(self, mode, VVkjiR, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVQB5k(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFFhkT(self, fncMode=CC9cgb.VVF41L, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVm3st(self, mode, VVkjiR, title, txt, colList):
  FFikZL(VVkjiR, boundFunction(self.VVkcM0, mode, VVkjiR, title, txt, colList))
 def VVkcM0(self, mode, VVkjiR, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFFhkT(self, fncMode=CC9cgb.VVKR1g, chName=name, text=txt, picUrl=Cover)
 def VV3uuF(self, mode, bName, VVkjiR, title, txt, colList):
  FFikZL(VVkjiR, boundFunction(self.VVWWeZ, mode, bName, VVkjiR, title, txt, colList), title="Adding Channels ...")
 def VVWWeZ(self, mode, bName, VVkjiR, title, txt, colList):
  url = self.VVhRN2Data["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VV2TSV(url)
  bNameFile = CCqLir.VVwKkN(bName)
  num  = 0
  path = VVg7D5 + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVg7D5 + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVkjiR.VVpWYB():
    chName, chUrl, picUrl, refCode = self.VVQB5k(mode, row)
    f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
    f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
    totChange += 1
  FFbI82(os.path.basename(path))
  self.VVSmgj(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVhB4x(self, mode, VVkjiR, title, txt, colList):
  if os.system(FF3WD3("which ffmpeg")) == 0:
   self.session.open(CCi8Vp, barTheme=CCi8Vp.VVjfMv
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VVeN3F, VVkjiR, mode)
       , VVRVdr = self.VVVTjr)
  else:
   FFjphE(self, self.VV6HdO, '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?')
 def VVVTjr(self, VVxBnX, VVNZTI, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVNZTI["proces"], VVNZTI["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVNZTI["ok"], VVNZTI["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVNZTI["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVNZTI["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVNZTI["badURL"]
  txt += "PIcons Path\t\t: %s\n"    % VVNZTI["path"]
  if not VVxBnX  : color = "#11402000"
  elif VVNZTI["err"]: color = "#11201000"
  else     : color = None
  if VVNZTI["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVNZTI["err"], txt)
  title = "PIcons Download Result"
  if not VVxBnX:
   title += "  (cancelled)"
  FFSnuH(self, txt, title=title, VVKZRt=color)
 def VVeN3F(self, VVkjiR, mode, progBarObj):
  totRows = VVkjiR.VVzWF7()
  progBarObj.VVxjCs(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CCgeLj.VVqTSU()
  progBarObj.VVNZTI = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for row in VVkjiR.VVpWYB():
    if progBarObj.isCancelled:
     break
    progBarObj.VVNZTI["proces"] += 1
    progBarObj.VVaQEg(1)
    if mode in ("itv", "vod", "series"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VViGpg(mode, row)
     refCode = CCqLir.VVNuOx(catID, stID, chNum)
    else:
     chName, chUrl, picUrl, refCode = self.VVQB5k(mode, row)
    if picUrl:
     picon = refCode.replace(":", "_").rstrip("_") + ".png"
     if not fileExists(pPath + picon):
      progBarObj.VVNZTI["attempt"] += 1
      path, err = FFj4ge(picUrl, picon, timeout=1)
      if path:
       progBarObj.VVNZTI["ok"] += 1
       if FFu2jr(path) > 0:
        cmd = ""
        if not mode == CCqLir.VV16eS:
         cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
        cmd += FF3WD3("mv -f '%s' '%s'" % (path, pPath)) + ";"
        os.system(cmd)
       else:
        progBarObj.VVNZTI["size0"] += 1
        os.system(FF3WD3("rm -f '%s'" % path))
      elif err:
       progBarObj.VVNZTI["fail"] += 1
       if any(x in err.lower() for x in ("time-out", "unauthorized")):
        progBarObj.VVNZTI["err"] = err.title()
        break
     else:
      progBarObj.VVNZTI["exist"] += 1
    else:
     progBarObj.VVNZTI["badURL"] += 1
  except:
   pass
 def VV6HdO(self):
  cmd = FF1oa1(VVJjEM, "ffmpeg")
  if cmd : FFjY30(self, cmd, title="Installing FFmpeg")
  else : FFJSkq(self)
 @staticmethod
 def VVNuOx(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCqLir.VVmi5Z(catID, MAX_4b)
  TSID = CCqLir.VVmi5Z(chNum, MAX_4b)
  ONID = CCqLir.VVmi5Z(chNum, MAX_4b)
  NS  = CCqLir.VVmi5Z(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVmi5Z(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVwKkN(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVzunr(mode):
  if   mode in ("itv"  , CCqLir.VVLcYV)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCqLir.VVTNFe)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCqLir.VVzsnQ) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCqLir.VVelPj) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCqLir.VVGypT    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 @staticmethod
 def VVlyCf():
  path = CFG.iptvHostsPath.getValue()
  if not pathExists(path) or path == VVlZ7S: return "/"
  else          : return FFq2Op(path)
 @staticmethod
 def VVCw0P(SELF, hostUrl, chName, streamId, ok_fnc):
  title = "Catchup TV Programs"
  pList, err = CCqLir.VVeVSq(hostUrl, streamId)
  if err:
   FF2nrW(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVgzpW, VVTK1M, VVKZRt, VVPQde = CCqLir.VVzunr("")
   VVRPnY = ("Home Menu" , FFVS4w, [])
   VV5Dm0  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVJRZ2  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FF8HHs(SELF, None, title="Programs for : " + chName, header=header, VVPIPy=pList, VVJRZ2=VVJRZ2, VVZt3N=widths, VVdfkW=24, VV5Dm0=VV5Dm0, VVRPnY=VVRPnY, VVgzpW=VVgzpW, VVTK1M=VVTK1M, VVKZRt=VVKZRt, VVPQde=VVPQde)
  else:
   FF2nrW(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVeVSq(chUrl, streamId):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCqLir.VV2TSV(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCqLir.VVru3x(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCqLir.VVQ0IT(item, "description" , is_base64=True ).replace("\n", " .. ")
    has_archive   = CCqLir.VVQ0IT(item, "has_archive"      )
    lang    = CCqLir.VVQ0IT(item, "lang"        ).upper()
    now_playing   = CCqLir.VVQ0IT(item, "now_playing"      )
    start    = CCqLir.VVQ0IT(item, "start"        )
    start_timestamp  = CCqLir.VVQ0IT(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCqLir.VVQ0IT(item, "start_timestamp"     )
    stop_timestamp  = CCqLir.VVQ0IT(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCqLir.VVQ0IT(item, "stop_timestamp"      )
    tTitle    = CCqLir.VVQ0IT(item, "title"   , is_base64=True )
    skip = False
    dur  = "45"
    try:
     if float(start_timestamp_unix) > iTime():
      skip = True
     dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
    except:
     pass
    if not skip:
     pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
  except:
   return "", "Cannot parse received data !"
  return pList, ""
class CCsxxS(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFXEzn(VVdXwL, 700, 700, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVduC4  = 0
  self.VVgFYt = 1
  self.VVX9DD  = 2
  VVRJT5 = []
  VVRJT5.append(("Find All (from filter)"    , "VVTlJN" ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Find All"        , "VVCDoy"    ))
  VVRJT5.append(("Find TV"        , "VVOaoR"    ))
  VVRJT5.append(("Find Radio"       , "VVyCR7"   ))
  if self.VVWOkw():
   VVRJT5.append(VVn6Em)
   VVRJT5.append(("Hide Channel: %s" % self.servName , "VVNFuK"   ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Zap History"       , "VVUbu8"    ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("PIcons Tools"       , "PIconsTools"     ))
  VVRJT5.append(("Channels Tools"      , "ChannelsTools"    ))
  FFnDik(self, VVRJT5=VVRJT5, title=title)
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  FF0xrD(self["myMenu"])
  FFJAKu(self)
  if self.isFindMode:
   self.VVSTq2(self.VVs8fJ())
 def VVDa6H(self):
  global VVQNCe
  VVQNCe = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVCDoy"    : self.VVCDoy()
   elif item == "VVTlJN" : self.VVTlJN()
   elif item == "VVOaoR"    : self.VVOaoR()
   elif item == "VVyCR7"   : self.VVyCR7()
   elif item == "VVNFuK"   : self.VVNFuK()
   elif item == "VVUbu8"    : self.VVUbu8()
   elif item == "PIconsTools"     : self.session.open(CCgeLj)
   elif item == "ChannelsTools"    : self.session.open(CCRv1a)
 def VVOaoR(self) : self.VVSTq2(self.VVduC4)
 def VVyCR7(self) : self.VVSTq2(self.VVgFYt)
 def VVCDoy(self) : self.VVSTq2(self.VVX9DD)
 def VVSTq2(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFzere(self, boundFunction(self.VVxPKV, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVTlJN(self):
  filterObj = CCQrIW(self)
  filterObj.VVxbBu(self.VVzZp7)
 def VVzZp7(self, item):
  self.VVxPKV(self.VVX9DD, item)
 def VVWOkw(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FF7Q2V(self.refCode)        : return False
  return True
 def VVxPKV(self, mode, VVuVsE):
  FFikZL(self, boundFunction(self.VVZ4p0, mode, VVuVsE), title="Searching ...")
 def VVZ4p0(self, mode, VVuVsE):
  if VVuVsE:
   self.findTxt = VVuVsE
   if   mode == self.VVduC4  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVgFYt : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVuVsE)
   if len(title) > 55:
    title = title[:55] + ".."
   VVbqDw = self.VVJMOp(VVuVsE, servTypes)
   if self.isFindMode or mode == self.VVX9DD:
    VVbqDw += self.VVnkcP(VVuVsE)
   if VVbqDw:
    VVbqDw.sort(key=lambda x: x[0].lower())
    VVRPWD = self.VVuaMB
    VV5Dm0  = ("Zap"   , self.VVpBwd    , [])
    VVg6wQ = ("Current Service", self.VVfQeu , [])
    VV4CnB = ("Options"  , self.VVAV4n , [])
    VVBfeb = (""    , self.VVvK7V , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVJRZ2  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FF8HHs(self, None, title=title, header=header, VVPIPy=VVbqDw, VVJRZ2=VVJRZ2, VVZt3N=widths, VVdfkW=26, VV5Dm0=VV5Dm0, VVRPWD=VVRPWD, VVg6wQ=VVg6wQ, VV4CnB=VV4CnB, VVBfeb=VVBfeb)
   else:
    self.VVSTq2(self.VVs8fJ())
    FFrerH(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVJMOp(self, VVuVsE, servTypes):
  VVNGnm  = eServiceCenter.getInstance()
  VVABqb   = '%s ORDER BY name' % servTypes
  VVxhNt   = eServiceReference(VVABqb)
  VVnbLV = VVNGnm.list(VVxhNt)
  if VVnbLV: VVPIPy = VVnbLV.getContent("CN", False)
  else     : VVPIPy = None
  VVbqDw = []
  if VVPIPy:
   VVtuJi, VV0h7I = FFsvLo()
   tp   = CCj4wy()
   words, asPrefix = CCQrIW.VVqWPa(VVuVsE)
   colorYellow  = CCBmOP.VVKSIH(VVvgWJ)
   colorWhite  = CCBmOP.VVKSIH(VV011v)
   for s in VVPIPy:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFHTWG(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVtuJi:
        STYPE = VV0h7I[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVUOQI(refCode)
       if not "-S" in syst:
        sat = syst
       VVbqDw.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVbqDw
 def VVnkcP(self, VVuVsE):
  VVuVsE = VVuVsE.lower()
  VVFtwu = FFeLh9()
  VVbqDw = []
  colorYellow  = CCBmOP.VVKSIH(VVvgWJ)
  colorWhite  = CCBmOP.VVKSIH(VV011v)
  if VVFtwu:
   for b in VVFtwu:
    VVGEPj  = b[0]
    VViY4o  = b[1].toString()
    VVYxtS = eServiceReference(VViY4o)
    VV9Xua = FF6ji1(VVYxtS)
    for service in VV9Xua:
     refCode  = service[0]
     if FF7Q2V(refCode):
      servName = service[1]
      if VVuVsE in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VVuVsE), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VVbqDw.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVbqDw
 def VVs8fJ(self):
  VVWLmo = InfoBar.instance
  if VVWLmo:
   VVp9th = VVWLmo.servicelist
   if VVp9th:
    return VVp9th.mode == 1
  return self.VVX9DD
 def VVuaMB(self, VVkjiR):
  self.close()
  VVkjiR.cancel()
 def VVpBwd(self, VVkjiR, title, txt, colList):
  FFKIZZ(VVkjiR, colList[2], VVOeQH=False, checkParentalControl=True)
 def VVfQeu(self, VVkjiR, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFuTJ(VVkjiR)
  if refCode:
   VVkjiR.VVEKIJ(2, FFwA9I(refCode, iptvRef, chName), True)
 def VVAV4n(self, VVkjiR, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CCYqwy(self, VVkjiR, 2)
  mSel.VVyX2M(servName, refCode)
 def VVvK7V(self, VVkjiR, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFFhkT(self, fncMode=CC9cgb.VVgRhd, refCode=refCode, chName=chName, text=txt)
 def VVNFuK(self):
  FFjphE(self, self.VVTDLm, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVTDLm(self):
  ret = FFK9ce(self.refCode, True)
  if ret:
   self.VVtW1T()
   self.close()
  else:
   FFdxmx(self, "Cannot change state" , 1000)
 def VVtW1T(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVzPH7()
  except:
   self.VVuNjV()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFsEEz(self, serviceRef)
 def VV76em(self):
  VVWLmo = InfoBar.instance
  if VVWLmo:
   VVp9th = VVWLmo.servicelist
   if VVp9th:
    VVp9th.setMode()
 def VVzPH7(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVWLmo = InfoBar.instance
   if VVWLmo:
    VVp9th = VVWLmo.servicelist
    if VVp9th:
     hList = VVp9th.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVp9th.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVp9th.history  = newList
       VVp9th.history_pos = pos
 def VVuNjV(self):
  VVWLmo = InfoBar.instance
  if VVWLmo:
   VVp9th = VVWLmo.servicelist
   if VVp9th:
    VVp9th.history  = []
    VVp9th.history_pos = 0
 def VVUbu8(self):
  VVWLmo = InfoBar.instance
  VVbqDw = []
  if VVWLmo:
   VVp9th = VVWLmo.servicelist
   if VVp9th:
    VVtuJi, VV0h7I = FFsvLo()
    for chParams in VVp9th.history:
     refCode = chParams[-1].toString()
     chName = FFmJHI(refCode)
     isIptv = FF7Q2V(refCode)
     if isIptv: sat = "-"
     else  : sat = FFHTWG(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVtuJi:
       STYPE = VV0h7I[sTypeInt]
     VVbqDw.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVbqDw:
   VV5Dm0  = ("Zap"   , self.VVBA6z   , [])
   VV4CnB = ("Clear History" , self.VVHey2   , [])
   VVBfeb = (""    , self.VVCW9WFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVJRZ2  = (LEFT    , LEFT   , CENTER , LEFT   )
   FF8HHs(self, None, title=title, header=header, VVPIPy=VVbqDw, VVJRZ2=VVJRZ2, VVZt3N=widths, VVdfkW=28, VV5Dm0=VV5Dm0, VV4CnB=VV4CnB, VVBfeb=VVBfeb)
  else:
   FFrerH(self, "Not found", title=title)
 def VVBA6z(self, VVkjiR, title, txt, colList):
  FFKIZZ(VVkjiR, colList[3], VVOeQH=False, checkParentalControl=True)
 def VVHey2(self, VVkjiR, title, txt, colList):
  FFjphE(self, boundFunction(self.VVT0iR, VVkjiR), "Clear Zap History ?")
 def VVT0iR(self, VVkjiR):
  self.VVuNjV()
  VVkjiR.cancel()
 def VVCW9WFromZapHistory(self, VVkjiR, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFFhkT(self, fncMode=CC9cgb.VVInci, refCode=refCode, chName=chName, text=txt)
class CCgeLj(Screen):
 VVgS5M   = 0
 VVqT6o  = 1
 VVTQjj  = 2
 VVSwOu  = 3
 VV0CyU  = 4
 VVFzCH  = 5
 VV07tt  = 6
 VVfgkm  = 7
 VVpjxX = 8
 VVf2dE = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFXEzn(VVUHRS, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFnDik(self, self.Title)
  FFKY2X(self["keyRed"] , "OK = Zap")
  FFKY2X(self["keyGreen"] , "Current Service")
  FFKY2X(self["keyYellow"], "Page Options")
  FFKY2X(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCgeLj.VVqTSU()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVPIPy    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVRJ40        ,
   "green"   : self.VVvgPD       ,
   "yellow"  : self.VVnTva        ,
   "blue"   : self.VVfwq4        ,
   "menu"   : self.VVVZVG        ,
   "info"   : self.VVCW9W         ,
   "up"   : self.VVm2yv          ,
   "down"   : self.VVjuLJ         ,
   "left"   : self.VVcHvU         ,
   "right"   : self.VVltG8         ,
   "pageUp"  : boundFunction(self.VVBKpH, True) ,
   "chanUp"  : boundFunction(self.VVBKpH, True) ,
   "pageDown"  : boundFunction(self.VVBKpH, False) ,
   "chanDown"  : boundFunction(self.VVBKpH, False) ,
   "next"   : self.VVOqMN        ,
   "last"   : self.VVpP9Y         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  FFiD9O(self)
  FFfaVA(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFikZL(self, boundFunction(self.VVVsTK, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVVZVG(self):
  if not self.isBusy:
   VVRJT5 = []
   VVRJT5.append(("Statistics"           , "VVfgk6"    ))
   VVRJT5.append(VVn6Em)
   VVRJT5.append(("Suggest PIcons for Current Channel"     , "VVOmDk"   ))
   VVRJT5.append(("Set to Current Channel (copy file)"     , "VVGUCP_file"  ))
   VVRJT5.append(("Set to Current Channel (as SymLink)"     , "VVGUCP_link"  ))
   VVRJT5.append(VVn6Em)
   VVRJT5.append(CCgeLj.VVrge0())
   VVRJT5.append(VVn6Em)
   VVRJT5.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVRA1p"  ))
   VVRJT5.append(VVn6Em)
   VVRJT5 += CCgeLj.VVjeLw()
   VVRJT5.append(VVn6Em)
   VVRJT5.append(("RCU Keys Help"          , "VV7Eb8"    ))
   FF4JCK(self, self.VVXNpT, title=self.Title, VVRJT5=VVRJT5)
 def VVXNpT(self, item=None):
  if item is not None:
   if   item == "VVfgk6"     : self.VVfgk6()
   elif item == "VVOmDk"    : self.VVOmDk()
   elif item == "VVGUCP_file"   : self.VVGUCP(0)
   elif item == "VVGUCP_link"   : self.VVGUCP(1)
   elif item == "VVtsYI_file"  : self.VVtsYI(0)
   elif item == "VVtsYI_link"  : self.VVtsYI(1)
   elif item == "VVph17"   : self.VVph17()
   elif item == "VVmVhN"  : self.VVmVhN()
   elif item == "VVAPBC"   : self.VVAPBC()
   elif item == "VVRA1p"   : self.VVRA1p()
   elif item == "VVwywT"   : CCgeLj.VVwywT(self)
   elif item == "VVnIMK"   : CCgeLj.VVnIMK(self)
   elif item == "findPiconBrokenSymLinks"  : CCgeLj.VVu4NQ(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCgeLj.VVu4NQ(self, False)
   elif item == "VV7Eb8"      : self.VV7Eb8()
 def VVnTva(self):
  if not self.isBusy:
   VVRJT5 = []
   VVRJT5.append(("Go to First PIcon"  , "VV8J5k"  ))
   VVRJT5.append(("Go to Last PIcon"   , "VVFybB"  ))
   VVRJT5.append(VVn6Em)
   VVRJT5.append(("Sort by Channel Name"     , "sortByChan" ))
   VVRJT5.append(("Sort by File Name"  , "sortByFile" ))
   VVRJT5.append(VVn6Em)
   VVRJT5.append(("Find from File List .." , "VVgOYx" ))
   FF4JCK(self, self.VVyMyZ, title=self.Title, VVRJT5=VVRJT5)
 def VVyMyZ(self, item=None):
  if item is not None:
   if   item == "VV8J5k"   : self.VV8J5k()
   elif item == "VVFybB"   : self.VVFybB()
   elif item == "sortByChan"  : self.VV1DGw(2)
   elif item == "sortByFile"  : self.VV1DGw(0)
   elif item == "VVgOYx"  : self.VVgOYx()
 def VV7Eb8(self):
  FFyuNh(self, VVoMgi + "_help_picons", "PIcons Manager (Keys Help)")
 def VVm2yv(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVFybB()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVJ6Xr()
 def VVjuLJ(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV8J5k()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVJ6Xr()
 def VVcHvU(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVFybB()
  else:
   self.curCol -= 1
   self.VVJ6Xr()
 def VVltG8(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV8J5k()
  else:
   self.curCol += 1
   self.VVJ6Xr()
 def VVpP9Y(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVJ6Xr(True)
 def VVOqMN(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVJ6Xr(True)
 def VV8J5k(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVJ6Xr(True)
 def VVFybB(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVJ6Xr(True)
 def VVgOYx(self):
  VVRJT5 = []
  for item in self.VVPIPy:
   VVRJT5.append((item[0], item[0]))
  FF4JCK(self, self.VVlFhW, title='PIcons ".png" Files', VVRJT5=VVRJT5, VVu3Pn=True)
 def VVlFhW(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVTEWW(ndx)
 def VVRJ40(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVFbEW()
   if refCode:
    FFKIZZ(self, refCode)
    self.VVeetv()
    self.VVe5S9()
 def VVBKpH(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVeetv()
   self.VVe5S9()
  except:
   pass
 def VVvgPD(self):
  if self["keyGreen"].getVisible():
   self.VVTEWW(self.curChanIndex)
 def VVTEWW(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVJ6Xr(True)
  else:
   FFdxmx(self, "Not found", 1000)
 def VV1DGw(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFikZL(self, boundFunction(self.VVVsTK, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVGUCP(self, mode):
  title = "Change Current Channel PIcon"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFuTJ(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVFbEW()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVRJT5 = []
     VVRJT5.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVRJT5.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FF4JCK(self, boundFunction(self.VVXfrt, mode, curChF, selPiconF), VVRJT5=VVRJT5, title="Current Channel PIcon (already exists)")
    else:
     self.VVXfrt(mode, curChF, selPiconF, "overwrite")
   else:
    FF2nrW(self, "Cannot change PIcon to itself !", title=title)
  else:
   FF2nrW(self, "Could not read current channel info. !", title=title)
 def VVXfrt(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFikZL(self, boundFunction(self.VVVsTK, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVtsYI(self, mode):
  pass
 def VVph17(self):
  pass
 def VVmVhN(self):
  pass
 def VVAPBC(self):
  pass
 def VVRA1p(self):
  lines = FFo8V2("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFjphE(self, boundFunction(self.VV0IeE, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVzwqf=True)
  else:
   FFrerH(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VV0IeE(self, fList):
  os.system(FF3WD3("find -L '%s' -type l -delete" % self.pPath))
  FFrerH(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVCW9W(self):
  FFikZL(self, self.VVxl3Z)
 def VVxl3Z(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVFbEW()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FF5Q6H("PIcon Directory:\n", VVbaBa)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FF0L3k(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FF0L3k(path)
   txt += FF5Q6H("PIcon File:\n", VVbaBa)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFo8V2(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FF5Q6H("Found %d SymLink%s to this file from:\n" % (tot, s), VVbaBa)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFmJHI(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FF5Q6H(tChName, VV0Tnk)
     else  : tChName = ""
     txt += "  %s%s\n" % (FF5Q6H(line, VViEcp), tChName)
    txt += "\n"
   if chName:
    txt += FF5Q6H("Channel:\n", VVbaBa)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FF5Q6H(chName, VV0Tnk)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FF5Q6H("Remarks:\n", VVbaBa)
    txt += "  %s\n" % FF5Q6H("Unused", VVUqrB)
  else:
   txt = "No info found"
  FFFhkT(self, fncMode=CC9cgb.VVPSgX, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVFbEW(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVPIPy[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFOGxT(sat)
  return fName, refCode, chName, sat, inDB
 def VVeetv(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFuTJ(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVPIPy):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVe5S9(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVFbEW()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FF5Q6H("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVbaBa))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVFbEW()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FF5Q6H(self.curChanName, VVvgWJ)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVfgk6(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VVPIPy:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FF7GV9("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFSnuH(self, txt, title=self.Title)
 def VVfwq4(self):
  if not self.isBusy:
   VVRJT5 = []
   VVRJT5.append(("All"         , "all"   ))
   VVRJT5.append(VVn6Em)
   VVRJT5.append(("Used by Channels"      , "used"  ))
   VVRJT5.append(("Unused PIcons"      , "unused"  ))
   VVRJT5.append(VVn6Em)
   VVRJT5.append(("PIcons Files"       , "pFiles"  ))
   VVRJT5.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVRJT5.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVRJT5.append(VVn6Em)
   VVRJT5.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVRJT5.append(VVn6Em)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFY3yp(val)
      VVRJT5.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCQrIW(self)
   filterObj.VVn3I1(VVRJT5, self.nsList, self.VVpQsr)
 def VVpQsr(self, item=None):
  if item is not None:
   self.VVmho9(item)
 def VVmho9(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVgS5M   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVqT6o   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVTQjj  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVSwOu  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VV0CyU  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVFzCH  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VV07tt   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVfgkm   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVpjxX , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVFzCH:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFo8V2("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFdxmx(self, "Not found", 1000)
     return
   elif mode == self.VVf2dE:
    return
   else:
    words, asPrefix = CCQrIW.VVqWPa(words)
   if not words and mode in (self.VVfgkm, self.VVpjxX):
    FFdxmx(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFikZL(self, boundFunction(self.VVVsTK, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVOmDk(self):
  self.session.open(CCi8Vp, barTheme=CCi8Vp.VV3KQm
      , titlePrefix = ""
      , fncToRun  = self.VVGsrb
      , VVRVdr = self.VVbLVL)
 def VVGsrb(self, progBarObj):
  lameDbChans = CCRv1a.VV5Ca2(self, CCRv1a.VVboHa, VVMvwR=False, VVRKaR=False)
  files = []
  words = []
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVNZTI = []
  progBarObj.VVxjCs(len(lameDbChans))
  if lameDbChans:
   processChanName = CChTqt()
   curCh = processChanName.VVz4Nk(self.curChanName)
   for refCode in lameDbChans:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVaQEg(1, True)
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCgeLj.VVmXQu(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCgeLj.VVLiFo(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       progBarObj.VVNZTI.append(f.replace(".png", ""))
 def VVbLVL(self, VVxBnX, VVNZTI, threadCounter, threadTotal, threadErr):
  if VVNZTI:
   self.timer = eTimer()
   fnc = boundFunction(FFikZL, self, boundFunction(self.VVVsTK, mode=self.VVf2dE, words=VVNZTI), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FFdxmx(self, "Not found", 2000)
 def VVVsTK(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVDEeh(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCRv1a.VV5Ca2(self, CCRv1a.VVboHa, VVMvwR=False, VVRKaR=False)
  iptvRefList = self.VVufSr()
  tList = []
  for fName, fType in CCgeLj.VVbQGy(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVgS5M:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVqT6o  and chName         : isAdd = True
   elif mode == self.VVTQjj and not chName        : isAdd = True
   elif mode == self.VVSwOu  and fType == 0        : isAdd = True
   elif mode == self.VV0CyU  and fType == 1        : isAdd = True
   elif mode == self.VVFzCH  and fName in words       : isAdd = True
   elif mode == self.VVf2dE and fName in words       : isAdd = True
   elif mode == self.VV07tt  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVfgkm  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVpjxX:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVPIPy   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FFdxmx(self)
  else:
   self.isBusy = False
   FFdxmx(self, "Not found", 1000)
   return
  self.VVPIPy.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVeetv()
  self.totalPIcons = len(self.VVPIPy)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVJ6Xr(True)
 def VVDEeh(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCgeLj.VVbQGy(self.pPath):
    if fName:
     return True
   if isFirstTime : FF2nrW(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFdxmx(self, "Not found", 1000)
  else:
   FF2nrW(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVufSr(self):
  VVbqDw = {}
  files  = CCqLir.VVVD4v(self)
  if files:
   for path in files:
    txt = FF83qF(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVbqDw[refCode] = item[1]
  return VVbqDw
 def VVJ6Xr(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VV6Tvt = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VV6Tvt: self.curPage = VV6Tvt
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVbRlY()
  if self.curPage == VV6Tvt:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVe5S9()
  filName, refCode, chName, sat, inDB = self.VVFbEW()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVbRlY(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVPIPy[ndx]
   fName = self.VVPIPy[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FF5Q6H(chName, VV0Tnk))
    else : lbl.setText("-")
   except:
    lbl.setText(FF5Q6H(chName, VVkwvG))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVmXQu(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVrge0():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVwywT"   )
 @staticmethod
 def VVjeLw():
  VVRJT5 = []
  VVRJT5.append(("Find SymLinks (to PIcon Directory)"   , "VVnIMK"   ))
  VVRJT5.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVRJT5.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVRJT5
 @staticmethod
 def VVwywT(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFuTJ(SELF)
  png, path = CCgeLj.VVJdpf(refCode)
  if path : CCgeLj.VVC0Rt(SELF, png, path)
  else : FF2nrW(SELF, "No PIcon found for current channel in:\n\n%s" % CCgeLj.VVqTSU())
 @staticmethod
 def VVnIMK(SELF):
  if VVvgWJ:
   sed1 = FFyIHF("->", VVvgWJ)
   sed2 = FFyIHF("picon", VVUqrB)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVkwvG, VV011v)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFMX6s(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFyECp(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVu4NQ(SELF, isPIcon):
  sed1 = FFyIHF("->", VVkwvG)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFyIHF("picon", VVUqrB)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFMX6s(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFyECp(), grep, sed1, sed2))
 @staticmethod
 def VVbQGy(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVqTSU():
  path = CFG.PIconsPath.getValue()
  return FFq2Op(path)
 @staticmethod
 def VVJdpf(refCode, chName=None):
  if FF7Q2V(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FF2vZ6(refCode)
  allPath, fName, refCodeFile, pList = CCgeLj.VVLiFo(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVC0Rt(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFyIHF("%s%s" % (dest, png), VV0Tnk))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFyIHF(errTxt, VVDbaf))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFEkLg(SELF, cmd)
 @staticmethod
 def VVLiFo(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCgeLj.VVqTSU()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FF2A5P(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CC2Tpz():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVXghA  = None
  self.VVbxoG = ""
  self.VVAPyV  = noService
  self.VV2o3F = 0
  self.VVVhh3  = noService
  self.VVydT6 = 0
  self.VVK0ID  = "-"
  self.VVyYxi = 0
  self.VV81a6  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVS7It(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVXghA = frontEndStatus
     self.VViEPJ()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VViEPJ(self):
  if self.VVXghA:
   val = self.VVXghA.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVbxoG = "%3.02f dB" % (val / 100.0)
   else         : self.VVbxoG = ""
   val = self.VVXghA.get("tuner_signal_quality", 0) * 100 / 65536
   self.VV2o3F = int(val)
   self.VVAPyV  = "%d%%" % val
   val = self.VVXghA.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVydT6 = int(val)
   self.VVVhh3  = "%d%%" % val
   val = self.VVXghA.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVK0ID  = "%d" % val
   val = int(val * 100 / 500)
   self.VVyYxi = min(500, val)
   val = self.VVXghA.get("tuner_locked", 0)
   if val == 1 : self.VV81a6 = "Locked"
   else  : self.VV81a6 = "Not locked"
 def VVGutw(self)   : return self.VVbxoG
 def VViBok(self)   : return self.VVAPyV
 def VVujYz(self)  : return self.VV2o3F
 def VVMv86(self)   : return self.VVVhh3
 def VVLKv4(self)  : return self.VVydT6
 def VVCqyL(self)   : return self.VVK0ID
 def VVGlJJ(self)  : return self.VVyYxi
 def VVk9GV(self)   : return self.VV81a6
 def VVGaCn(self) : return self.serviceName
class CCj4wy():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VV4P8s(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFIZ4H(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVZ6ku(self.ORPOS  , mod=1   )
      self.sat2  = self.VVZ6ku(self.ORPOS  , mod=2   )
      self.freq  = self.VVZ6ku(self.FREQ  , mod=3   )
      self.sr   = self.VVZ6ku(self.SR   , mod=4   )
      self.inv  = self.VVZ6ku(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVZ6ku(self.POL  , self.D_POL )
      self.fec  = self.VVZ6ku(self.FEC  , self.D_FEC )
      self.syst  = self.VVZ6ku(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVZ6ku("modulation" , self.D_MOD )
       self.rolof = self.VVZ6ku("rolloff"  , self.D_ROLOF )
       self.pil = self.VVZ6ku("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVZ6ku("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVZ6ku("pls_code"  )
       self.iStId = self.VVZ6ku("is_id"   )
       self.t2PlId = self.VVZ6ku("t2mi_plp_id" )
       self.t2PId = self.VVZ6ku("t2mi_pid"  )
 def VVZ6ku(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFY3yp(val)
  elif mod == 2   : return FFQVWS(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVysoZ(self, refCode):
  txt = ""
  self.VV4P8s(refCode)
  if self.data:
   def VVxNnv(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVxNnv("System"   , self.syst)
    txt += VVxNnv("Satellite"  , self.sat2)
    txt += VVxNnv("Frequency"  , self.freq)
    txt += VVxNnv("Inversion"  , self.inv)
    txt += VVxNnv("Symbol Rate"  , self.sr)
    txt += VVxNnv("Polarization" , self.pol)
    txt += VVxNnv("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVxNnv("Modulation" , self.mod)
     txt += VVxNnv("Roll-Off" , self.rolof)
     txt += VVxNnv("Pilot"  , self.pil)
     txt += VVxNnv("Input Stream", self.iStId)
     txt += VVxNnv("T2MI PLP ID" , self.t2PlId)
     txt += VVxNnv("T2MI PID" , self.t2PId)
     txt += VVxNnv("PLS Mode" , self.plsMod)
     txt += VVxNnv("PLS Code" , self.plsCod)
   else:
    txt += VVxNnv("System"   , self.txMedia)
    txt += VVxNnv("Frequency"  , self.freq)
  return txt, self.namespace
 def VVqiXk(self, refCode):
  txt = "Transpoder : ?"
  self.VV4P8s(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VVbaBa + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVUOQI(self, refCode):
  self.data = None
  servRef = eServiceReference(refCode)
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFIZ4H(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVZ6ku(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVZ6ku(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVZ6ku(self.SYST, self.D_SYS_S)
     freq = self.VVZ6ku(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVZ6ku(self.POL , self.D_POL)
      fec = self.VVZ6ku(self.FEC , self.D_FEC)
      sr = self.VVZ6ku(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVRQJP(self, refCode):
  self.data = None
  self.VV4P8s(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCqxmc():
 def __init__(self, VVB9OK, path, VVRVdr=None, curRowNum=-1):
  self.VVB9OK  = VVB9OK
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVRVdr  = VVRVdr
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FF3WD3("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVLeYO(curRowNum)
  else:
   FF2nrW(self.VVB9OK, "Error while preparing edit!")
 def VVLeYO(self, curRowNum):
  VVbqDw = self.VVsmiw()
  VVRPnY = None #("Delete Line" , self.deleteLine  , [])
  VVg6wQ = ("Save Changes" , self.VVu4Ka   , [])
  VV5Dm0  = ("Edit Line"  , self.VV9gKA    , [])
  VVqvqX = ("Line Options" , self.VV98xe   , [])
  VV1FjN = (""    , self.VVGIqP , [])
  VVRPWD = self.VV93b2
  VVkv8J  = self.VVYGNE
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVJRZ2  = (CENTER  , LEFT  )
  VVkjiR = FF8HHs(self.VVB9OK, None, title=self.Title, header=header, VVPIPy=VVbqDw, VVJRZ2=VVJRZ2, VVZt3N=widths, VVdfkW=26, VVRPnY=VVRPnY, VVg6wQ=VVg6wQ, VV5Dm0=VV5Dm0, VVqvqX=VVqvqX, VVRPWD=VVRPWD, VVkv8J=VVkv8J, VV1FjN=VV1FjN, VVSFYp=True
    , VVgzpW   = "#11001111"
    , VVTK1M   = "#11001111"
    , VVKZRt   = "#11001111"
    , VVPQde  = "#05333333"
    , VVXHiK  = "#00222222"
    , VVi5es  = "#11331133"
    )
  VVkjiR.VVt2ck(curRowNum)
 def VV98xe(self, VVkjiR, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVkjiR.VVWhHx()
  VVRJT5 = []
  VVRJT5.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVRJT5.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVNril"  ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVsQRi:
   VVRJT5.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(  ("Delete Line"         , "deleteLine"   ))
  FF4JCK(self.VVB9OK, boundFunction(self.VVqOba, VVkjiR, lineNum), VVRJT5=VVRJT5, title="Line Options")
 def VVqOba(self, VVkjiR, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVTUw4("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVkjiR)
   elif item == "VVNril"  : self.VVNril(VVkjiR, lineNum)
   elif item == "copyToClipboard"  : self.VVmDdu(VVkjiR, lineNum)
   elif item == "pasteFromClipboard" : self.VVvHe5(VVkjiR, lineNum)
   elif item == "deleteLine"   : self.VVTUw4("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVkjiR)
 def VVYGNE(self, VVkjiR):
  VVkjiR.VVpEhX()
 def VVGIqP(self, VVkjiR, title, txt, colList):
  if   self.insertMode == 1: VVkjiR.VVs8Fm()
  elif self.insertMode == 2: VVkjiR.VV56SP()
  self.insertMode = 0
 def VVNril(self, VVkjiR, lineNum):
  if lineNum == VVkjiR.VVWhHx():
   self.insertMode = 1
   self.VVTUw4("echo '' >> '%s'" % self.tmpFile, VVkjiR)
  else:
   self.insertMode = 2
   self.VVTUw4("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVkjiR)
 def VVmDdu(self, VVkjiR, lineNum):
  global VVsQRi
  VVsQRi = FF7GV9("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVkjiR.VVWnVY("Copied to clipboard")
 def VVu4Ka(self, VVkjiR, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FF3WD3("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FF3WD3("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVkjiR.VVWnVY("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVkjiR.VVpEhX()
    else:
     FF2nrW(self.VVB9OK, "Cannot save file!")
   else:
    FF2nrW(self.VVB9OK, "Cannot create backup copy of original file!")
 def VV93b2(self, VVkjiR):
  if self.fileChanged:
   FFjphE(self.VVB9OK, boundFunction(self.VVB1k4, VVkjiR), "Cancel changes ?")
  else:
   finalOK = os.system(FF3WD3("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVB1k4(VVkjiR)
 def VVB1k4(self, VVkjiR):
  VVkjiR.cancel()
  os.system(FF3WD3("rm -f '%s'" % self.tmpFile))
  if self.VVRVdr:
   self.VVRVdr(self.fileSaved)
 def VV9gKA(self, VVkjiR, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VV011v + "ORIGINAL TEXT:\n" + VViEcp + lineTxt
  FFzere(self.VVB9OK, boundFunction(self.VVb5oA, lineNum, VVkjiR), title="File Line", defaultText=lineTxt, message=message)
 def VVb5oA(self, lineNum, VVkjiR, VVckRP):
  if not VVckRP is None:
   if VVkjiR.VVWhHx() <= 1:
    self.VVTUw4("echo %s > '%s'" % (VVckRP, self.tmpFile), VVkjiR)
   else:
    self.VVjWJ8(VVkjiR, lineNum, VVckRP)
 def VVvHe5(self, VVkjiR, lineNum):
  if lineNum == VVkjiR.VVWhHx() and VVkjiR.VVWhHx() == 1:
   self.VVTUw4("echo %s >> '%s'" % (VVsQRi, self.tmpFile), VVkjiR)
  else:
   self.VVjWJ8(VVkjiR, lineNum, VVsQRi)
 def VVjWJ8(self, VVkjiR, lineNum, newTxt):
  VVkjiR.VV8Yq9("Saving ...")
  lines = FFxmgd(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVkjiR.VVVhJ8()
  VVbqDw = self.VVsmiw()
  VVkjiR.VVRlUS(VVbqDw)
 def VVTUw4(self, cmd, VVkjiR):
  tCons = CCMduL()
  tCons.ePopen(cmd, boundFunction(self.VVLQEf, VVkjiR))
  self.fileChanged = True
  VVkjiR.VVVhJ8()
 def VVLQEf(self, VVkjiR, result, retval):
  VVbqDw = self.VVsmiw()
  VVkjiR.VVRlUS(VVbqDw)
 def VVsmiw(self):
  if fileExists(self.tmpFile):
   lines = FFxmgd(self.tmpFile)
   VVbqDw = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVbqDw.append((str(ndx), line.strip()))
   if not VVbqDw:
    VVbqDw.append((str(1), ""))
   return VVbqDw
  else:
   FFAPN6(self.VVB9OK, self.tmpFile)
class CCQrIW():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVRJT5   = []
  self.satList   = []
 def VVxbBu(self, VVRVdr):
  self.VVRJT5 = []
  VVRJT5, VVdWlw = self.VVFgi6(False, True)
  if VVRJT5:
   self.VVRJT5 += VVRJT5
   self.VVh5tT(VVRVdr, VVdWlw)
 def VVzHLy(self, mode, VVkjiR, satCol, VVRVdr):
  VVkjiR.VV8Yq9("Loading Filters ...")
  self.VVRJT5 = []
  self.VVRJT5.append(("All Services" , "all"))
  if mode == 1:
   self.VVRJT5.append(VVn6Em)
   self.VVRJT5.append(("Parental Control", "parentalControl"))
   self.VVRJT5.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVRJT5.append(VVn6Em)
   self.VVRJT5.append(("Selected Transponder"   , "selectedTP" ))
   self.VVRJT5.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVrwuN(VVkjiR, satCol)
  VVRJT5, VVdWlw = self.VVFgi6(True, False)
  if VVRJT5:
   VVRJT5.insert(0, VVn6Em)
   self.VVRJT5 += VVRJT5
  VVkjiR.VVGwFc()
  self.VVh5tT(VVRVdr, VVdWlw)
 def VVn3I1(self, VVRJT5, sats, VVRVdr):
  self.VVRJT5 = VVRJT5
  VVRJT5, VVdWlw = self.VVFgi6(True, False)
  if VVRJT5:
   self.VVRJT5.append(VVn6Em)
   self.VVRJT5 += VVRJT5
  self.VVh5tT(VVRVdr, VVdWlw)
 def VVekvZ(self, VVRJT5, sats, VVRVdr):
  self.VVRJT5 = VVRJT5
  VVRJT5, VVdWlw = self.VVFgi6(True, False)
  if VVRJT5:
   self.VVRJT5.append(VVn6Em)
   self.VVRJT5 += VVRJT5
  self.VVh5tT(VVRVdr, VVdWlw)
 def VVh5tT(self, VVRVdr, VVdWlw):
  VVZZ8a = ("Edit Filter", boundFunction(self.VVZG45, VVdWlw))
  VVuTHu  = ("Filter Help", boundFunction(self.VVcxj3, VVdWlw))
  FF4JCK(self.callingSELF, boundFunction(self.VV1KxZ, VVRVdr), VVRJT5=self.VVRJT5, title="Select Filter", VVZZ8a=VVZZ8a, VVuTHu=VVuTHu)
 def VV1KxZ(self, VVRVdr, item):
  if item:
   VVRVdr(item)
 def VVZG45(self, VVdWlw, VVw3blObj, sel):
  if fileExists(VVdWlw) : CCqxmc(self.callingSELF, VVdWlw, VVRVdr=None)
  else       : FFAPN6(self.callingSELF, VVdWlw)
  VVw3blObj.cancel()
 def VVcxj3(self, VVdWlw, VVw3blObj, sel):
  FFyuNh(self.callingSELF, VVoMgi + "_help_service_filter", "Service Filter")
 def VVrwuN(self, VVkjiR, satColNum):
  if not self.satList:
   satList = VVkjiR.VV398i(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFOGxT(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VVn6Em)
  if self.VVRJT5:
   self.VVRJT5 += self.satList
 def VVFgi6(self, addTag, VVxCvy):
  FFxsSD()
  fileName  = "ajpanel_services_filter"
  VVdWlw = VVHCIO + fileName
  VVRJT5  = []
  if not fileExists(VVdWlw):
   os.system(FF3WD3("cp -f '%s' '%s'" % (VVoMgi + fileName, VVdWlw)))
  fileFound = False
  if fileExists(VVdWlw):
   fileFound = True
   lines = FFxmgd(VVdWlw)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVRJT5.append((line, "__w__" + line))
       else  : VVRJT5.append((line, line))
  if VVxCvy:
   if   not fileFound : FFAPN6(self.callingSELF , VVdWlw)
   elif not VVRJT5 : FF0Gb5(self.callingSELF , VVdWlw)
  return VVRJT5, VVdWlw
 @staticmethod
 def VVqWPa(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CCYqwy():
 def __init__(self, callingSELF, VVkjiR, refCodeColNum):
  self.callingSELF = callingSELF
  self.VVkjiR = VVkjiR
  self.refCodeColNum = refCodeColNum
  self.VVRJT5 = []
  iMulSel = self.VVkjiR.VVNkuj()
  if iMulSel : self.VVRJT5.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVRJT5.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVkjiR.VVN0xD()
  self.VVRJT5.append(    ("Select all"    , "selectAll"  ))
  if tot > 0:
   self.VVRJT5.append(   ("Unselect all"    , "unselectAll"  ))
  self.VVRJT5.append(VVn6Em)
 def VVyX2M(self, servName, refCode):
  tot = self.VVkjiR.VVN0xD()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVRJT5.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VV3CcD_multi" ))
  else    : self.VVRJT5.append( ("Add to Bouquet : %s"      % servName , "VV3CcD_one" ))
  self.VVib8T(servName, refCode)
 def VV2aNV(self, servName, refCode, pcState, hidState):
  self.VVRJT5 = []
  if pcState == "No" : self.VVRJT5.append(("Add to Parental Control"  , "parentalControl_add"  ))
  else    : self.VVRJT5.append(("Remove from Parental Control" , "parentalControl_remove" ))
  if hidState == "No" : self.VVRJT5.append(("Add to Hidden Services"  , "hiddenServices_add"  ))
  else    : self.VVRJT5.append(("Remove from Hidden Services" , "hiddenServices_remove" ))
  self.VVib8T(servName, refCode)
 def VVib8T(self, servName, refCode):
  FF4JCK(self.callingSELF, boundFunction(self.VVTH3p, servName, refCode), title="Options", VVRJT5=self.VVRJT5)
 def VVTH3p(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"    : self.VVkjiR.VVfEwH(True)
   elif item == "MultSelDisab"    : self.VVkjiR.VVfEwH(False)
   elif item == "selectAll"    : self.VVkjiR.VV2VJ1()
   elif item == "unselectAll"    : self.VVkjiR.VVoscE()
   elif item == "parentalControl_add"  : self.callingSELF.VV0gKM(self.VVkjiR, refCode, True)
   elif item == "parentalControl_remove" : self.callingSELF.VV0gKM(self.VVkjiR, refCode, False)
   elif item == "hiddenServices_add"  : self.callingSELF.VVOKPo(self.VVkjiR, refCode, True)
   elif item == "hiddenServices_remove" : self.callingSELF.VVOKPo(self.VVkjiR, refCode, False)
   elif item == "VV3CcD_multi" : self.VV3CcD(refCode, True)
   elif item == "VV3CcD_one" : self.VV3CcD(refCode, False)
 def VV3CcD(self, refCode, isMulti):
  bouquets = FFeLh9()
  if bouquets:
   VVRJT5 = []
   for item in bouquets:
    VVRJT5.append((item[0], item[1].toString()))
   VVZZ8a = ("Create New", boundFunction(self.VVqKMp, refCode, isMulti))
   FF4JCK(self.callingSELF, boundFunction(self.VVZAli, refCode, isMulti), VVRJT5=VVRJT5, title="Add to Bouquet", VVZZ8a=VVZZ8a, VVu3Pn=True, VVmt0g=True)
  else:
   FFjphE(self.callingSELF, boundFunction(self.VVHoPY, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVZAli(self, refCode, isMulti, bName=None):
  if bName:
   FFikZL(self.VVkjiR, boundFunction(self.VVMzuq, refCode, isMulti, bName), title="Adding Channels ...")
 def VVMzuq(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVPLd5(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVWLmo = InfoBar.instance
    if VVWLmo:
     VVp9th = VVWLmo.servicelist
     if VVp9th:
      mutableList = VVp9th.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVkjiR.VVGwFc()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFrerH(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FF2nrW(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVPLd5(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVkjiR.VVVQj7(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VVqKMp(self, refCode, isMulti, VVw3blObj, path):
  self.VVHoPY(refCode, isMulti)
 def VVHoPY(self, refCode, isMulti):
  FFzere(self.callingSELF, boundFunction(self.VVQHPJ, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVQHPJ(self, refCode, isMulti, name):
  if name:
   FFikZL(self.VVkjiR, boundFunction(self.VVkhj7, refCode, isMulti, name), title="Adding Channels ...")
 def VVkhj7(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVPLd5(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVWLmo = InfoBar.instance
    if VVWLmo:
     VVp9th = VVWLmo.servicelist
     if VVp9th:
      try:
       VVp9th.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVp9th.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVkjiR.VVGwFc()
   title = "Add to Bouquet"
   if allOK: FFrerH(self.callingSELF, "Added to : %s" % name, title=title)
   else : FF2nrW(self.callingSELF, "Nothing added!", title=title)
class CCSsQj(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFXEzn(VVoWNM, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFnDik(self)
  FFKY2X(self["keyRed"]  , "Exit")
  FFKY2X(self["keyGreen"]  , "Save")
  FFKY2X(self["keyYellow"] , "Refresh")
  FFKY2X(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VV4ONu  ,
   "green"   : self.VVf6vv ,
   "yellow"  : self.VVsKHJ  ,
   "blue"   : self.VVfdc0   ,
   "up"   : self.VVm2yv    ,
   "down"   : self.VVjuLJ   ,
   "left"   : self.VVcHvU   ,
   "right"   : self.VVltG8   ,
   "cancel"  : self.VV4ONu
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVsKHJ()
  self.VV3PFz()
  FFiD9O(self)
 def VV4ONu(self) : self.close(True)
 def VVxBQC(self) : self.close(False)
 def VVfdc0(self):
  self.session.openWithCallback(self.VVlmPh, boundFunction(CCwuRK))
 def VVlmPh(self, closeAll):
  if closeAll:
   self.close()
 def VVm2yv(self):
  self.VVFA3T(1)
 def VVjuLJ(self):
  self.VVFA3T(-1)
 def VVcHvU(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VV3PFz()
 def VVltG8(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VV3PFz()
 def VVFA3T(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVnA2z(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVnA2z(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVnA2z(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VV61rQ(year)):
   days += 1 #29 days in a leap year February
  return days
 def VV61rQ(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VV3PFz(self):
  for obj in self.list:
   FFfaVA(obj, "#11404040")
  FFfaVA(self.list[self.index], "#11ff8000")
 def VVsKHJ(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVf6vv(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCMduL()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVQwVx)
 def VVQwVx(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFrerH(self, "Nothing returned from the system!")
  else:
   FFrerH(self, str(result))
class CCwuRK(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFXEzn(VVUyHt, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFnDik(self, addLabel=True)
  FFKY2X(self["keyRed"]  , "Exit")
  FFKY2X(self["keyGreen"]  , "Sync")
  FFKY2X(self["keyYellow"] , "Refresh")
  FFKY2X(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VV4ONu   ,
   "green"   : self.VVYCrL  ,
   "yellow"  : self.VVarfW ,
   "blue"   : self.VVmsy2  ,
   "cancel"  : self.VV4ONu
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVH4hl()
  self.onShow.append(self.start)
 def start(self):
  FFsV3D(self.refresh)
  FFiD9O(self)
 def refresh(self):
  self.VVgTFj()
  self.VVAhIQ(False)
 def VV4ONu(self)  : self.close(True)
 def VVmsy2(self) : self.close(False)
 def VVH4hl(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVgTFj(self):
  self.VVkQBr()
  self.VVayKk()
  self.VVpovy()
  self.VVwqkP()
 def VVarfW(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVH4hl()
   self.VVgTFj()
   FFsV3D(self.refresh)
 def VVYCrL(self):
  if len(self["keyGreen"].getText()) > 0:
   FFjphE(self, self.VVzLa1, "Synchronize with Internet Date/Time ?")
 def VVzLa1(self):
  self.VVgTFj()
  FFsV3D(boundFunction(self.VVAhIQ, True))
 def VVkQBr(self)  : self["keyRed"].show()
 def VVSkqj(self)  : self["keyGreen"].show()
 def VVOcWw(self) : self["keyYellow"].show()
 def VVqmVu(self)  : self["keyBlue"].show()
 def VVayKk(self)  : self["keyGreen"].hide()
 def VVpovy(self) : self["keyYellow"].hide()
 def VVwqkP(self)  : self["keyBlue"].hide()
 def VVAhIQ(self, sync):
  localTime = FFdno1()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVXpK5(server)
   if epoch_time is not None:
    ntpTime = FFAQH0(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCMduL()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVQwVx, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVOcWw()
  self.VVqmVu()
  if ok:
   self.VVSkqj()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVQwVx(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVAhIQ(False)
  except:
   pass
 def VVXpK5(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFWcRy():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCDnMZ(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFXEzn(VV8Guw, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFnDik(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  FFsV3D(self.VVEdbM)
 def VVEdbM(self):
  if FFWcRy(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFfaVA(self["myBody"], color)
   FFfaVA(self["myLabel"], color)
  except:
   pass
class CCvsCJ(Screen):
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFkSIV()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFXEzn(VVzyq9, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCwMhT(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCwMhT(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCwMhT(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CC2Tpz()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFnDik(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVm2yv          ,
   "down"  : self.VVjuLJ         ,
   "left"  : self.VVcHvU         ,
   "right"  : self.VVltG8         ,
   "info"  : self.VVz90o        ,
   "epg"  : self.VVz90o        ,
   "menu"  : self.VV7Eb8         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "last"  : boundFunction(self.VVS8Ei, -1)  ,
   "next"  : boundFunction(self.VVS8Ei, 1)  ,
   "pageUp" : boundFunction(self.VVDchO, True) ,
   "chanUp" : boundFunction(self.VVDchO, True) ,
   "pageDown" : boundFunction(self.VVDchO, False) ,
   "chanDown" : boundFunction(self.VVDchO, False) ,
   "0"   : boundFunction(self.VVS8Ei, 0)  ,
   "1"   : boundFunction(self.VViwcy, pos=1) ,
   "2"   : boundFunction(self.VViwcy, pos=2) ,
   "3"   : boundFunction(self.VViwcy, pos=3) ,
   "4"   : boundFunction(self.VViwcy, pos=4) ,
   "5"   : boundFunction(self.VViwcy, pos=5) ,
   "6"   : boundFunction(self.VViwcy, pos=6) ,
   "7"   : boundFunction(self.VViwcy, pos=7) ,
   "8"   : boundFunction(self.VViwcy, pos=8) ,
   "9"   : boundFunction(self.VViwcy, pos=9) ,
  }, -1)
  self.onShown.append(self.VVciax)
  self.onClose.append(self.onExit)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  self.sliderSNR.VVufEp()
  self.sliderAGC.VVufEp()
  self.sliderBER.VVufEp(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VViwcy()
  self.VV61rHInfo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV61rH)
  except:
   self.timer.callback.append(self.VV61rH)
  self.timer.start(500, False)
 def VV61rHInfo(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVS7It(service)
  serviceName = self.tunerInfo.VVGaCn()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFuTJ(self)
  tp = CCj4wy()
  txt = tp.VVqiXk(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VV61rH(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVS7It(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVGutw())
   self["mySNR"].setText(self.tunerInfo.VViBok())
   self["myAGC"].setText(self.tunerInfo.VVMv86())
   self["myBER"].setText(self.tunerInfo.VVCqyL())
   self.sliderSNR.VVFhcR(self.tunerInfo.VVujYz())
   self.sliderAGC.VVFhcR(self.tunerInfo.VVLKv4())
   self.sliderBER.VVFhcR(self.tunerInfo.VVGlJJ())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVFhcR(0)
   self.sliderAGC.VVFhcR(0)
   self.sliderBER.VVFhcR(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFuTJ(self)
    if state and not state == "Tuned":
     FFdxmx(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVz90o(self):
  FFFhkT(self, fncMode=CC9cgb.VViUAq)
 def VV7Eb8(self):
  FFyuNh(self, VVoMgi + "_help_signal", "Signal Monitor (Keys)")
 def VVm2yv(self)  : self.VViwcy(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVjuLJ(self) : self.VViwcy(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVcHvU(self) : self.VViwcy(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVltG8(self) : self.VViwcy(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VViwcy(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVS8Ei(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFSJyj(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVDchO(self, isUp):
  FFdxmx(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VV61rHInfo()
  except:
   pass
class CCwMhT(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVufEp(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFfaVA(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVoMgi +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFfaVA(self.covObj, self.covColor)
   else:
    FFfaVA(self.covObj, "#00006688")
    self.isColormode = True
  self.VVFhcR(0)
 def VVFhcR(self, val):
  val  = FFSJyj(val, self.minN, self.maxN)
  width = int(FFIc1P(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFSJyj(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCi8Vp(Screen):
 VV3KQm    = 0
 VVjfMv = 1
 VVtojm = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVRVdr=None, barTheme=VV3KQm):
  ratio = self.VVa9On(barTheme)
  self.skin, self.skinParam = FFXEzn(VVQYBD, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVRVdr = VVRVdr
  self.isCancelled = False
  self.isError  = False
  self.curValue  = 0
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVNZTI = None
  self.timer   = eTimer()
  self.myThread  = None
  FFnDik(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVciax)
  self.onClose.append(self.onExit)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  self.VVVkkN()
  self["myProgBarVal"].setText("0%")
  FFfaVA(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVzrCO()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVzrCO)
  except:
   self.timer.callback.append(self.VVzrCO)
  self.timer.start(300, False)
  from threading import Thread as iThread
  self.myThread = iThread(name="threadFnc", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def onExit(self):
  self.timer.stop()
 def VVxjCs(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVIh7J_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVNZTI), self.counter, self.maxValue, catName)
 def VVaQEg(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VVNZTI), self.counter, self.maxValue)
  except:
   pass
 def VVshfS(self):
  self.isError = True
  self.cancel()
 def cancel(self):
  FFdxmx(self, "Cancelling ...")
  self.isCancelled = True
  if self.VVRVdr:
   self.VVRVdr(False, self.VVNZTI, self.counter, self.maxValue, self.isError)
  self.close()
 def VVzrCO(self):
  val = FFSJyj(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFIc1P(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if self.VVRVdr and not self.isCancelled:
    self.VVRVdr(True, self.VVNZTI, self.counter, self.maxValue, self.isError)
   self.close()
 def VVVkkN(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme == self.VVjfMv:
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
  elif self.barTheme == self.VVtojm:
   pass
 def VVa9On(self, barTheme):
  if   barTheme == self.VVjfMv : return 0.8
  elif barTheme == self.VVtojm : return 1
  else              : return 1
class CCMduL(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVRVdr = {}
  self.commandRunning = False
  self.VVCSkY  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVRVdr, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVRVdr[name] = VVRVdr
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVCSkY:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVvroT, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVhWcj , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVvroT, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVhWcj , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVhWcj(name, retval)
  return True
 def VVvroT(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVhWcj(self, name, retval):
  if not self.VVCSkY:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVRVdr[name]:
   self.VVRVdr[name](self.appResults[name], retval)
  del self.VVRVdr[name]
 def VV07x7(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCiaT1(Screen):
 def __init__(self, session, title="", VVhenW=None, VVv6wd=False, VVOQjd=False, VVDbHQ=False, VVpbux=False, VVilYQ=False, VVPAsI=False, VVGjos=VVrOxe, VVFQVU=None, VVk9XJ=False, VV4CJh=None, VV3iCe="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFXEzn(VVDOy7, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFnDik(self, addScrollLabel=True)
  if not VV3iCe:
   VV3iCe = "Processing ..."
  self["myLabel"].setText("   %s" % VV3iCe)
  self.VVv6wd   = VVv6wd
  self.VVOQjd   = VVOQjd
  self.VVDbHQ   = VVDbHQ
  self.VVpbux  = VVpbux
  self.VVilYQ = VVilYQ
  self.VVPAsI = VVPAsI
  self.VVGjos   = VVGjos
  self.VVFQVU = VVFQVU
  self.VVk9XJ  = VVk9XJ
  self.VV4CJh  = VV4CJh
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCMduL()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FF6oMc()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVhenW, str):
   self.VVhenW = [VVhenW]
  else:
   self.VVhenW = VVhenW
  if self.VVDbHQ or self.VVpbux:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VV06tg, VV06tg)
   self.VVhenW.append("echo -e '\n%s\n' %s" % (restartNote, FFyIHF(restartNote, VVvgWJ)))
   if self.VVDbHQ:
    self.VVhenW.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVhenW.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVilYQ:
   FFdxmx(self, "Processing ...")
  self.onLayoutFinish.append(self.VVCN7h)
  self.onClose.append(self.VV0KDL)
 def VVCN7h(self):
  self["myLabel"].VVOdRf(textOutFile="console" if self.enableSaveRes else "")
  if self.VVv6wd:
   self["myLabel"].VVR1jP()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVGTOx()
  else:
   self.VVAJsH()
 def VVGTOx(self):
  if FFWcRy():
   self["myLabel"].setText("Processing ...")
   self.VVAJsH()
  else:
   self["myLabel"].setText(FF5Q6H("\n   No connection to internet!", VVUqrB))
 def VVAJsH(self):
  allOK = self.container.ePopen(self.VVhenW[0], self.VVmf3c, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVmf3c("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVPAsI or self.VVDbHQ or self.VVpbux:
    self["myLabel"].setText(FFjBJQ("STARTED", VVvgWJ) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VV4CJh:
   colorWhite = CCBmOP.VVKSIH(VV011v)
   color  = CCBmOP.VVKSIH(self.VV4CJh[0])
   words  = self.VV4CJh[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVGjos=self.VVGjos)
 def VVmf3c(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVhenW):
   allOK = self.container.ePopen(self.VVhenW[self.cmdNum], self.VVmf3c, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVmf3c("Cannot connect to Console!", -1)
  else:
   if self.VVilYQ and FFTrJK(self):
    FFdxmx(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVPAsI:
    self["myLabel"].appendText("\n" + FFjBJQ("FINISHED", VVvgWJ), self.VVGjos)
   if self.VVv6wd or self.VVOQjd:
    self["myLabel"].VVR1jP()
   if self.VVFQVU is not None:
    self.VVFQVU()
   if not retval and self.VVk9XJ:
    self.VV0KDL()
 def VV0KDL(self):
  if self.container.VV07x7():
   self.container.killAll()
class CCX20v(Screen):
 def __init__(self, session, VVhenW=None, VVilYQ=False):
  self.skin, self.skinParam = FFXEzn(VVDOy7, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVHCIO + "ajpanel_terminal.history"
  self.customCommandsFile = VVHCIO + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FF7GV9("pwd") or "/home/root"
  self.container   = CCMduL()
  FFnDik(self, addScrollLabel=True)
  FFKY2X(self["keyRed"] , "Exit = Stop Command")
  FFKY2X(self["keyGreen"] , "OK = History")
  FFKY2X(self["keyYellow"], "Menu = Custom Cmds")
  FFKY2X(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVmQfR ,
   "cancel" : self.VVWcQv  ,
   "menu"  : self.VVyfu6 ,
   "last"  : self.VVa6CC  ,
   "next"  : self.VVa6CC  ,
   "1"   : self.VVa6CC  ,
   "2"   : self.VVa6CC  ,
   "3"   : self.VVa6CC  ,
   "4"   : self.VVa6CC  ,
   "5"   : self.VVa6CC  ,
   "6"   : self.VVa6CC  ,
   "7"   : self.VVa6CC  ,
   "8"   : self.VVa6CC  ,
   "9"   : self.VVa6CC  ,
   "0"   : self.VVa6CC
  })
  self.onLayoutFinish.append(self.VVciax)
  self.onClose.append(self.VVz0EC)
 def VVciax(self):
  self["myLabel"].VVOdRf(isResizable=False, textOutFile="terminal")
  FF0Lke(self["keyRed"]  , "#00ff8000")
  FFfaVA(self["keyRed"]  , self.skinParam["titleColor"])
  FFfaVA(self["keyGreen"]  , self.skinParam["titleColor"])
  FFfaVA(self["keyYellow"] , self.skinParam["titleColor"])
  FFfaVA(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVt1Bt(FF7GV9("date"), 5)
  result = FF7GV9("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VV75FX()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVoMgi + "LinuxCommands.lst"
   newTemplate = VVoMgi + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FF3WD3("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FF3WD3("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVz0EC(self):
  if self.container.VV07x7():
   self.container.killAll()
   self.VVt1Bt("Process killed\n", 4)
   self.VV75FX()
 def VVWcQv(self):
  if self.container.VV07x7():
   self.VVz0EC()
  else:
   FFjphE(self, self.close, "Exit ?", VVEals=False)
 def VV75FX(self):
  self.VVt1Bt(self.prompt, 1)
  self["keyRed"].hide()
 def VVt1Bt(self, txt, mode):
  if   mode == 1 : color = VVvgWJ
  elif mode == 2 : color = VVbaBa
  elif mode == 3 : color = VV011v
  elif mode == 4 : color = VVUqrB
  elif mode == 5 : color = VViEcp
  elif mode == 6 : color = VVvQSh
  else   : color = VV011v
  try:
   self["myLabel"].appendText(FF5Q6H(txt, color))
  except:
   pass
 def VVO0vU(self, cmd):
  self["keyRed"].show()
  cmd = cmd.strip()
  if "#" in cmd:
   parts = cmd.split("#")
   left  = FF5Q6H(parts[0].strip(), VVbaBa)
   right = FF5Q6H("#" + parts[1].strip(), VVvQSh)
   txt = "%s    %s\n" % (left, right)
  else:
   txt = "%s\n" % cmd
  self.VVt1Bt(txt, 2)
  lastLine = self.VVDnjd()
  if not lastLine or not cmd == lastLine:
   self.lastCommand = cmd
   self.VVbxTE(cmd)
  span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
  if span:
   self.curDir = span.group(1)
  allOK = self.container.ePopen(cmd, self.VVmf3c, dataAvailFnc=self.dataAvail, curDir=self.curDir)
  if not allOK:
   FF2nrW(self, "Cannot connect to Console!")
  self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVt1Bt(data, 3)
 def VVmf3c(self, data, retval):
  if not retval == 0:
   self.VVt1Bt("Exit Code : %d\n" % retval, 4)
  self.VV75FX()
 def VVmQfR(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVDnjd() == "":
   self.VVbxTE("cd /tmp")
   self.VVbxTE("ls")
  VVbqDw = []
  if fileExists(self.commandHistoryFile):
   lines  = FFxmgd(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVbqDw.append((str(c), line, str(lNum)))
   self.VVkHes(VVbqDw, title, self.commandHistoryFile, isHistory=True)
  else:
   FFAPN6(self, self.commandHistoryFile, title=title)
 def VVDnjd(self):
  lastLine = FF7GV9("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVbxTE(self, cmd):
  os.system("echo '%s' >> %s" % (cmd, self.commandHistoryFile))
 def VVyfu6(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFxmgd(self.customCommandsFile)
   lastLineIsSep = False
   VVbqDw = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVbqDw.append((str(c), line, str(lNum)))
   self.VVkHes(VVbqDw, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFAPN6(self, self.customCommandsFile, title=title)
 def VVkHes(self, VVbqDw, title, filePath=None, isHistory=False):
  if VVbqDw:
   VVPQde = "#05333333"
   if isHistory: VVgzpW = VVTK1M = VVKZRt = "#11000020"
   else  : VVgzpW = VVTK1M = VVKZRt = "#06002020"
   VV4CnB = VVqvqX = None
   VV5Dm0   = ("Send"   , self.VVZgT5        , [])
   VVg6wQ  = ("Modify & Send" , self.VVpkDz        , [])
   if isHistory:
    VV4CnB = ("Clear History" , self.VVkX5R        , [])
   elif filePath:
    VVqvqX = ("Edit File"  , boundFunction(self.VVhjoG, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVJRZ2     = (CENTER  , LEFT   , CENTER )
   FF8HHs(self, None, title=title, header=header, VVPIPy=VVbqDw, VVJRZ2=VVJRZ2, VVZt3N=widths, VVdfkW=26, VV5Dm0=VV5Dm0, VVg6wQ=VVg6wQ, VV4CnB=VV4CnB, VVqvqX=VVqvqX, VVSFYp=True
     , VVgzpW   = VVgzpW
     , VVTK1M   = VVTK1M
     , VVKZRt   = VVKZRt
     , VVpFk3  = "#05ffff00"
     , VVPQde  = VVPQde
    )
  else:
   FF0Gb5(self, filePath, title=title)
 def VVZgT5(self, VVkjiR, title, txt, colList):
  cmd = colList[1].strip()
  VVkjiR.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVt1Bt("\n%s\n" % cmd, 6)
   self.VVt1Bt(self.prompt, 1)
  else:
   if cmd.startswith("passwd"):
    self.VVt1Bt(cmd, 2)
    self.VVt1Bt("\nCannot change passwrod from Console this way. Try using:\n", 4)
    txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
    for ch in txt:
     if not ch == "#":
      self.VVt1Bt(ch, 0)
    self.VVt1Bt("\nor\n", 4)
    self.VVt1Bt("echo root:NEW_PASSWORD | chpasswd\n", 0)
    self.VV75FX()
   else:
    self.VVO0vU(cmd)
 def VVpkDz(self, VVkjiR, title, txt, colList):
  cmd = colList[1]
  self.VVi00v(VVkjiR, cmd)
 def VVkX5R(self, VVkjiR, title, txt, colList):
  FFjphE(self, boundFunction(self.VVZk2A, VVkjiR), "Reset History File ?", title="Command History")
 def VVZk2A(self, VVkjiR):
  os.system(FF3WD3("echo '' > %s" % self.commandHistoryFile))
  VVkjiR.cancel()
 def VVhjoG(self, filePath, VVkjiR, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCqxmc(self, filePath, VVRVdr=boundFunction(self.VVrLg8, VVkjiR), curRowNum=rowNum)
  else     : FFAPN6(self, filePath)
 def VVrLg8(self, VVkjiR, fileChanged):
  if fileChanged:
   VVkjiR.cancel()
   FFsV3D(self.VVyfu6)
 def VVa6CC(self):
  self.VVi00v(None, self.lastCommand)
 def VVi00v(self, VVkjiR, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFzere(self, boundFunction(self.VVSaGw, VVkjiR), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVSaGw(self, VVkjiR, cmd):
  if cmd and len(cmd) > 0:
   self.VVO0vU(cmd)
   if VVkjiR:
    VVkjiR.cancel()
class CCL3CQ(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVckRP="", VVvzKF=False, VVAWMZ=False, isTrimEnds=True):
  self.skin, self.skinParam = FFXEzn(VVCFB2, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFnDik(self, title, addLabel=True)
  FFKY2X(self["keyRed"] , "Up/Down = Change")
  FFKY2X(self["keyGreen"] , "Overwrite")
  FFKY2X(self["keyYellow"], "Pick Key Map")
  FFKY2X(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVAWMZ   = VVAWMZ
  self.VVvzKF  = VVvzKF
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVckRP, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VV0Ujv      ,
   "green"    : self.VV0jRz    ,
   "yellow"   : self.VVMhoO      ,
   "blue"    : self.VV5OEm     ,
   "menu"    : self.VV52Ll     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVZ96E, True) ,
   "down"    : boundFunction(self.VVZ96E, False) ,
   "left"    : self.VVRcUr       ,
   "right"    : self.VVAVBy       ,
   "home"    : self.VVH0oA       ,
   "end"    : self.VV8ryA       ,
   "next"    : self.VVOfgW      ,
   "last"    : self.VVFuro      ,
   "deleteForward"  : self.VVOfgW      ,
   "deleteBackward" : self.VVFuro      ,
   "tab"    : self.VVRRlj       ,
   "toggleOverwrite" : self.VV0jRz    ,
   "0"     : self.VVS4vv     ,
   "1"     : self.VVS4vv     ,
   "2"     : self.VVS4vv     ,
   "3"     : self.VVS4vv     ,
   "4"     : self.VVS4vv     ,
   "5"     : self.VVS4vv     ,
   "6"     : self.VVS4vv     ,
   "7"     : self.VVS4vv     ,
   "8"     : self.VVS4vv     ,
   "9"     : self.VVS4vv
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVIsYr()
  self.onShown.append(self.VVciax)
  self.onClose.append(self.onExit)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  self["myLabel"].setText(self.message)
  self.VVXKXt()
  if self.VVvzKF : self.VV0jRz()
  else    : self.VVS3yh()
  FFiD9O(self)
  FFfaVA(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVMGZV)
  except:
   self.timer.callback.append(self.VVMGZV)
 def onExit(self):
  self.timer.stop()
 def VV0Ujv(self):
  self.VV7XFb()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VV7XFb()
  self.close(None)
 def VV52Ll(self):
  VVRJT5 = []
  VVRJT5.append(("Home"         , "home"    ))
  VVRJT5.append(("End"         , "end"     ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Clear All"       , "clearAll"   ))
  VVRJT5.append(("Clear To Home"      , "clearToHome"   ))
  VVRJT5.append(("Clear To End"       , "clearToEnd"   ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVsQRi:
   VVRJT5.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("To Capital Letters"     , "toCapital"   ))
  VVRJT5.append(("To Small Letters"      , "toSmall"    ))
  FF4JCK(self, self.VVPDLw, title="Edit Options", VVRJT5=VVRJT5)
 def VVPDLw(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVH0oA()
   elif item == "end"     : self.VV8ryA()
   elif item == "clearAll"    : self.VVSMx1()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVH0oA()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVsQRi
    VVsQRi = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVsQRi)
    self.VVH0oA()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVMGZV(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VV0jRz(self):
  self["myInput"].toggleOverwrite()
  self.VVS3yh()
 def VVMhoO(self):
  self.session.openWithCallback(self.VV4UCD, boundFunction(CC63xK, mode=self.charMode, VVAWMZ=self.VVAWMZ))
 def VV4UCD(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVXKXt()
 def VVS3yh(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVIsYr(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VV7XFb(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVgkhX(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVRcUr(self)     : self.VVJKEG(self["myInput"].left)
 def VVAVBy(self)     : self.VVJKEG(self["myInput"].right)
 def VVOfgW(self)     : self.VVJKEG(self["myInput"].delete)
 def VVH0oA(self)     : self.VVJKEG(self["myInput"].home)
 def VV8ryA(self)     : self.VVJKEG(self["myInput"].end)
 def VVFuro(self)    : self.VVJKEG(self["myInput"].deleteBackward)
 def VVRRlj(self)     : self.VVJKEG(self["myInput"].tab)
 def VVSMx1(self)     : self["myInput"].setText("")
 def VVJKEG(self, fnc):
  fnc()
  self.VVMGZV()
 def VVS4vv(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVgkhX(newChar, overwrite)
   self.VVPpTP(newChar, self["myInput"].mapping[number])
 def VVZ96E(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CC63xK.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CC63xK.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVgkhX(newChar, True)
   for group in groups:
    if newChar in group:
     self.VVPpTP(newChar, group)
     break
 def VVPpTP(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VV011v:
    group = VViEcp + group.replace(newChar, FF5Q6H(newChar, VV011v, VViEcp))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VV5OEm(self):
  if self.VVAWMZ : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVXKXt()
 def VVXKXt(self):
  self["myInput"].mapping = CC63xK.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CC63xK.RCU_MAP_TITLES[self.charMode])
class CC63xK(Screen):
 VVZbV6  = 0
 VVFUw3  = 1
 VV02Sw  = 2
 VVK8tc  = 3
 VV62wK = 4
 VV2D3h = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols, arabic_nums1, arabic1)
       , ( symbols, arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A" , u"\u0628")
       , (u"\u0647" , u"\u062A")
       )
 def __init__(self, session, mode=VVZbV6, VVAWMZ=False):
  self.skin, self.skinParam = FFXEzn(VVWjru, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVAWMZ  = VVAWMZ
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFnDik(self, title=self.Title)
  FFKY2X(self["keyRed"] ,"OK = Select")
  FFKY2X(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVhKKn     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVLmw4, -1) ,
   "next"  : boundFunction(self.VVLmw4, +1) ,
   "left"  : boundFunction(self.VVLmw4, -1) ,
   "right"  : boundFunction(self.VVLmw4, +1) ,
  }, -1)
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  FFfaVA(self["keyRed"], "#11222222")
  FFfaVA(self["keyGreen"], "#11222222")
  self.VVXzK1()
 def VVXzK1(self):
  self.VVT2nJ()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVT2nJ(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVLmw4(self, direction):
  if self.VVAWMZ : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVXzK1()
 def VVhKKn(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCmijH(Screen):
 def __init__(self, session, title="", message="", VVGjos=VVrOxe, VVVEcz=False, VVKZRt=None, VVdfkW=30):
  self.skin, self.skinParam = FFXEzn(VVDOy7, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVdfkW)
  self.session   = session
  FFnDik(self, title, addScrollLabel=True)
  self.VVGjos   = VVGjos
  self.VVVEcz   = VVVEcz
  self.VVKZRt   = VVKZRt
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  self["myLabel"].VVOdRf(VVVEcz=self.VVVEcz)
  self["myLabel"].setText(self.message, self.VVGjos)
  if self.VVKZRt:
   FFfaVA(self["myBody"], self.VVKZRt)
   FFfaVA(self["myLabel"], self.VVKZRt)
   FFPdRE(self["myLabel"], self.VVKZRt)
  self["myLabel"].VVR1jP()
class CCutwz(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFXEzn(VVWDbm, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFnDik(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  path = VVoMgi + "err.png"
  if fileExists(path):
   self["errPic"].instance.setScale(1)
   self["errPic"].instance.setPixmapFromFile(path)
class CCkdPb(Screen, CC04b0):
 PLAYER_INSTANCE = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False):
  self.skin, self.skinParam = FFXEzn(VVP2Jc, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CC04b0.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  FFnDik(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVTIdy())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVDa6H         ,
   "info"  : self.VVz90o        ,
   "epg"  : self.VVz90o        ,
   "menu"  : self.FF4JCK         ,
   "cancel" : self.cancel         ,
   "blue"  : self.VVdSbI        ,
   "green"  : boundFunction(self.VVn7QQ, True),
   "yellow" : self.VV3bcr   ,
   "left"  : boundFunction(self.VVnTm8, -1)   ,
   "right"  : boundFunction(self.VVnTm8,  1)   ,
   "play"  : self.VVQVJR        ,
   "pause"  : self.VVQVJR        ,
   "playPause" : self.VVQVJR        ,
   "stop"  : self.VVQVJR        ,
   "rewind" : self.VV3HA3        ,
   "forward" : self.VVd2Dr        ,
   "rewindDm" : self.VV3HA3        ,
   "forwardDm" : self.VVd2Dr        ,
   "last"  : boundFunction(self.VVg9Ik, 0)    ,
   "next"  : self.VVjo7D        ,
   "pageUp" : boundFunction(self.VV5gRS, True) ,
   "pageDown" : boundFunction(self.VV5gRS, False) ,
   "chanUp" : boundFunction(self.VV5gRS, True) ,
   "chanDown" : boundFunction(self.VV5gRS, False) ,
   "up"  : boundFunction(self.VV5gRS, True) ,
   "down"  : boundFunction(self.VV5gRS, False) ,
   "0"   : boundFunction(self.VVPVnA , 10)  ,
   "1"   : boundFunction(self.VVPVnA , 1)  ,
   "2"   : boundFunction(self.VVPVnA , 2)  ,
   "3"   : boundFunction(self.VVPVnA , 3)  ,
   "4"   : boundFunction(self.VVPVnA , 4)  ,
   "5"   : boundFunction(self.VVPVnA , 5)  ,
   "6"   : boundFunction(self.VVPVnA , 6)  ,
   "7"   : boundFunction(self.VVPVnA , 7)  ,
   "8"   : boundFunction(self.VVPVnA , 8)  ,
   "9"   : boundFunction(self.VVPVnA , 9)
  }, -1)
  self.onShown.append(self.VVciax)
  self.onClose.append(self.onExit)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  if not CCkdPb.PLAYER_INSTANCE or self.portalTableParam:
   CCkdPb.PLAYER_INSTANCE = self
  else:
   self.close()
  self.VVKWJA()
  self.instance.move(ePoint(40, 40))
  self.VV86lB(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVlAz7)
  except:
   self.timer.callback.append(self.VVlAz7)
  self.timer.start(250, False)
  self.VVlAz7("Checking ...")
  self.VVn7QQ()
 def onExit(self):
  self.timer.stop()
  CCkdPb.PLAYER_INSTANCE = None
 def VVKWJA(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFuTJ(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl:
   color = "#1120002a"
   self["myPlayGrn"].show()
  else:
   color = "#1100202a"
   self["myPlayGrn"].hide()
  FFfaVA(self["myTitle"], color)
 def FF4JCK(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFuTJ(self)
  VVRJT5 = []
  if self.isFromExternal:
   VVRJT5.append(("IPTV Menu"  , "iptv" ))
   VVRJT5.append(VVn6Em)
  if not "&end=" in decodedUrl:
   VVRJT5.append(("Catchup Programs" , "catchup" ))
   VVRJT5.append(VVn6Em)
  VVRJT5.append(("Move to Top"   , "top"  ))
  VVRJT5.append(("Move to Bottom"  , "botm" ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Help"     , "help" ))
  FF4JCK(self, self.VVeNUv, VVRJT5=VVRJT5, width=500, title="Options")
 def VVeNUv(self, item=None):
  if item:
   if item == "iptv"  :
    self.session.open(CCqLir)
    self.close()
   elif item == "catchup" : self.VV3bcr()
   elif item == "botm"  : self.VV86lB(0)
   elif item == "top"  : self.VV86lB(1)
   elif item == "help"  : FFyuNh(self, VVoMgi + "_help_player", "Player Controller (Keys)")
 def VV86lB(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VVDa6H(self):
  if self.isManualSeek:
   self.VVtc7z()
   self.VVg9Ik(self.manualSeekPts)
  else:
   if self.shown: self.hide()
   else   : self.show()
 def cancel(self):
  if self.isManualSeek:
   self.VVtc7z()
  else:
   self.close()
 def VVz90o(self):
  FFFhkT(self, fncMode=CC9cgb.VVk4Wt)
 def VVQVJR(self):
  try:
   InfoBar.instance.playpauseService()
  except Exception as e:
   pass
  self.VVlAz7("Toggling Play/Pause ...")
 def VVtc7z(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVnTm8(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVG4um()
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.jumpMinutes * 60.0
   else:
    self.manualSeekSec += direc * self.jumpMinutes * 60.0
    self.manualSeekSec = FFSJyj(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFIc1P(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFUwdx(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVPVnA(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   FFKY2X(self["myPlayJmp"], self.VVTIdy())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVlAz7("Changed Jump Minutes to : %d" % val)
 def VVTIdy(self):
  return "Jump:%dm" % self.jumpMinutes
 def VVlAz7(self, stateTxt=""):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFuTJ(self)
  fr = res = ""
  if info:
   w = FFiV0Z(info, iServiceInformation.sVideoWidth) or -1
   h = FFiV0Z(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFiV0Z(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CC9cgb.VVYWay(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVG4um()
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FFSJyj(percVal, 0, 100)
    width = int(FFIc1P(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   FF0Lke(self["myPlayMsg"], "#00ff8066")
   self["myPlayMsg"].setText("-" if decodedUrl else FFHTWG(refCode, True))
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not durTxt:
   self["myPlayVal"].setText(">>>>>")
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText(prov)
  if not posTxt:
   self["myPlayPos"].setText("")
  if not remTxt:
   self["myPlayRem"].setText("")
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VVQVu1() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   FF0Lke(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VV3qg5()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VVg9Ik(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
  state = self.VVeXSf()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FF0Lke(self["myPlayMsg"], "#0000ff00")
  else     : FF0Lke(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVG4um(self):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = self.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFUwdx(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFUwdx(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal
      remTxt = FFUwdx(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVdSbI(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VVQVu1()
   if cList:
    VVRJT5 = []
    for pts, what in cList:
     txt = FFUwdx(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVRJT5.append((txt, pts))
    FF4JCK(self, self.VVTaJo, VVRJT5=VVRJT5, title="Cut List")
   else:
    self.VVlAz7("No Cut-List for this channel !")
 def VVTaJo(self, item=None):
  if item:
   self.VVg9Ik(item)
 def VVQVu1(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVd2Dr(self) : self.VVVtn1(self.jumpMinutes)
 def VV3HA3(self) : self.VVVtn1(-self.jumpMinutes)
 def VVVtn1(self, mins):
  try:
   inst = InfoBar.instance
   inst.doSeekRelative(mins * 60 * 90000)
   inst.hide()
   if   mins > 0 : self.VVlAz7("Forawrd (%d min) ..." % self.jumpMinutes)
   elif mins < 0 : self.VVlAz7("Rewind (%d min) ..." % self.jumpMinutes)
  except:
   self.VVlAz7("Cannot jump")
 def VVT7GF(self):
  InfoBar.instance.VVT7GF()
 def VVg9Ik(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVlAz7("Changing Time ...")
 def VVjo7D(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVG4um()
   if durVal > 0:
    pts = int(durVal * 60 * 90000)
    InfoBar.instance.doSeek(pts)
    self.VVlAz7("Jumping to end ...")
  except:
   pass
 def VV3qg5(self):
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVeXSf(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VV5gRS(self, isUp):
  if self.enableZapping:
   self.VVlAz7("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVtc7z()
   if self.portalTableParam:
    self.VVBN43(isUp)
   else:
    try:
     if isUp : InfoBar.instance.zapDown()
     else : InfoBar.instance.zapUp()
    except:
     pass
    self.lastPlayPos = 0
    self.VVKWJA()
    self.VVn7QQ()
 def VVBN43(self, isUp):
  CCqLir_inatance, VVkjiR, mode = self.portalTableParam
  if isUp : VVkjiR.VVmGSS()
  else : VVkjiR.VVnrfA()
  FFikZL(VVkjiR, boundFunction(self.VVf7YB, mode, VVkjiR, CCqLir_inatance), title="Playing ...")
 def VVf7YB(self, mode, VVkjiR, CCqLir_inatance):
  colList = VVkjiR.VVKzHE()
  if mode == "localIptv":
   CCqLir_inatance.VVc4hX(True, VVkjiR, "", "", colList)
  elif isinstance(mode, int):
   CCqLir_inatance.VVe2ks(mode, True, VVkjiR, "", "", colList)
  else:
   CCqLir_inatance.VVo8rB(mode, True, VVkjiR, "", "", colList)
  self.close()
 def VVn7QQ(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVG4um()
    if posTxt:
     return
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFuTJ(self)
   if not self.VVo4qE(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVlAz7("Refreshing Portal")
   FFsV3D(self.VVhePo)
  except:
   pass
 def VVhePo(self):
  self.restoreLastPlayPos = self.VVKDRp()
 def VV3bcr(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFuTJ(self)
  if not decodedUrl or any(x in decodedUrl for x in ("/movie/", "/series/")):
   self.VVlAz7("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.index(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCqLir.VV5dpo(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVlAz7("Reading Program List ...")
   ok_fnc = boundFunction(self.VV4UfV, refCode, chName, streamId, uHost, uUser, uPass)
   FFsV3D(boundFunction(CCqLir.VVCw0P, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVlAz7("Cannot process this channel")
 def VV4UfV(self, refCode, chName, streamId, uHost, uUser, uPass, VVkjiR, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVkjiR.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVlAz7("Changing Program ...")
   FFsV3D(boundFunction(self.VV9vta, chUrl))
  else:
   self.VVlAz7("Incorrect Timestamp !")
 def VV9vta(self, chUrl):
   FFKIZZ(self, chUrl, VVOeQH=False)
   self.lastPlayPos = 0
   self.VVKWJA()
class CC6QNO(Screen):
 def __init__(self, session, title="", VV2i71="Continue?", VVEals=True, VVzwqf=False):
  self.skin, self.skinParam = FFXEzn(VVS35S, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VV2i71 = VV2i71
  self.VVzwqf = VVzwqf
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVEals : VVRJT5 = [no , yes]
  else   : VVRJT5 = [yes, no ]
  FFnDik(self, title, VVRJT5=VVRJT5, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVDa6H ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VV2i71)
  if self.VVzwqf:
   self["myLabel"].instance.setHAlign(0)
  self.VV5TR3()
  FF0xrD(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFzmOF(self["myMenu"])
  FFgfbz(self, self["myMenu"])
 def VVDa6H(self):
  item = FFnvKh(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VV5TR3(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCbENj(Screen):
 def __init__(self, session, title="", VVRJT5=None, width=1000, OKBtnFnc=None, VVrFC4=None, VV6P3U=None, VVZZ8a=None, VVuTHu=None, VVu3Pn=False, VVmt0g=False):
  self.skin, self.skinParam = FFXEzn(VVdXwL, width, 850, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVRJT5   = VVRJT5
  self.OKBtnFnc   = OKBtnFnc
  self.VVrFC4   = VVrFC4
  self.VV6P3U  = VV6P3U
  self.VVZZ8a  = VVZZ8a
  self.VVuTHu   = VVuTHu
  self.VVu3Pn  = VVu3Pn
  self.VVmt0g  = VVmt0g
  FFnDik(self, title, VVRJT5=VVRJT5)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVDa6H          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVbn8C         ,
   "green"  : self.VVbF4k         ,
   "yellow" : self.VVbKIK         ,
   "blue"  : self.VVy6Iu         ,
   "pageUp" : self.VVhy6p       ,
   "chanUp" : self.VVhy6p       ,
   "pageDown" : self.VVmbHM        ,
   "chanDown" : self.VVmbHM
  }, -1)
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  FF0xrD(self["myMenu"])
  FFJAKu(self)
  self.VVB8Zh(self["keyRed"]  , self.VVrFC4 )
  self.VVB8Zh(self["keyGreen"] , self.VV6P3U )
  self.VVB8Zh(self["keyYellow"] , self.VVZZ8a )
  self.VVB8Zh(self["keyBlue"]  , self.VVuTHu )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFiD9O(self)
 def VVB8Zh(self, btnObj, btnFnc):
  if btnFnc:
   FFKY2X(btnObj, btnFnc[0])
 def VVDa6H(self):
  item = FFnvKh(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVu3Pn: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVbn8C(self)  : self.VVJKEG(self.VVrFC4)
 def VVbF4k(self) : self.VVJKEG(self.VV6P3U)
 def VVbKIK(self) : self.VVJKEG(self.VVZZ8a)
 def VVy6Iu(self) : self.VVJKEG(self.VVuTHu)
 def VVJKEG(self, btnFnc):
  if btnFnc:
   item = FFnvKh(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVmt0g:
    self.cancel()
 def VVuYJG(self, VVRJT5):
  if len(VVRJT5) > 0:
   newList = []
   for item in VVRJT5:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVn4DY(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVhy6p(self):
  self["myMenu"].moveToIndex(0)
 def VVmbHM(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCJFlR(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VVPIPy=None, VVJRZ2=None, VVZt3N=None, VVdfkW=26, VVSFYp=False, VV5Dm0=None, VVBfeb=None, VVRPnY=None, VVg6wQ=None, VV4CnB=None, VVqvqX=None, VVkv8J=None, VV1FjN=None, VVRPWD=None, VV48q3=-1, VV9Auz=False, searchCol=0, VVgzpW=None, VVTK1M=None, VV5bYq="#00dddddd", VVKZRt="#11002233", VVpFk3="#00ff8833", VVPQde="#11111111", VVXHiK="#0a555555", VVoPTh="#0affffff", VVi5es="#11552200", VVzfnx="#0055ff55"):
  self.skin, self.skinParam = FFXEzn(VVPKsb, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFnDik(self, title)
  self.header     = header
  self.VVPIPy     = VVPIPy
  self.totalCols    = len(VVPIPy[0])
  self.VV6jUG   = 0
  self.lastSortModeIsReverese = False
  self.VVSFYp   = VVSFYp
  self.VVPL9V   = 0.01
  self.VVJlol   = 0.02
  self.VVHgXj  = 1
  self.VVZt3N = VVZt3N
  self.colWidthPixels   = []
  self.VV5Dm0   = VV5Dm0
  self.OKButtonObj   = None
  self.VVBfeb   = VVBfeb
  self.VVRPnY   = VVRPnY
  self.VVg6wQ   = VVg6wQ
  self.VV4CnB  = VV4CnB
  self.VVqvqX   = VVqvqX
  self.VVkv8J    = VVkv8J
  self.VV1FjN   = VV1FjN
  self.VVRPWD  = VVRPWD
  self.VV48q3    = VV48q3
  self.VV9Auz   = VV9Auz
  self.searchCol    = searchCol
  self.VVJRZ2    = VVJRZ2
  self.keyPressed    = -1
  self.VVdfkW    = FF3Vbc(VVdfkW)
  self.VVYdZK    = FFx7Im(self.VVdfkW, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVgzpW    = VVgzpW
  self.VVTK1M      = VVTK1M
  self.VV5bYq    = FFXNey(VV5bYq)
  self.VVKZRt    = FFXNey(VVKZRt)
  self.VVpFk3    = FFXNey(VVpFk3)
  self.VVPQde    = FFXNey(VVPQde)
  self.VVXHiK   = FFXNey(VVXHiK)
  self.VVoPTh    = FFXNey(VVoPTh)
  self.VVi5es    = FFXNey(VVi5es)
  self.VVzfnx   = FFXNey(VVzfnx)
  self.VVP0TW  = False
  self.selectedItems   = 0
  self.VVP0bi   = FFXNey("#01fefe01")
  self.VVW4zv   = FFXNey("#11400040")
  self.VVNZDY  = self.VVP0bi
  self.VVRi7k  = self.VVPQde
  if self.VV9Auz:
   self["keyMenu1F"].hide()
   self["keyMenu1"].hide()
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV3SzY  ,
   "red"   : self.VVHS7k  ,
   "green"   : self.VVyPwN ,
   "yellow"  : self.VV6Aa1 ,
   "blue"   : self.VVle9s  ,
   "menu"   : self.VVBE1C ,
   "info"   : self.VVNfdA  ,
   "cancel"  : self.VVnFts  ,
   "up"   : self.VVnrfA    ,
   "down"   : self.VVmGSS  ,
   "left"   : self.VVpP9Y   ,
   "right"   : self.VVOqMN  ,
   "pageUp"  : self.VVpVFO  ,
   "chanUp"  : self.VVpVFO  ,
   "pageDown"  : self.VV56SP  ,
   "chanDown"  : self.VV56SP
  }, -1)
  FFKcR0(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  try:
   self.VVO7qr()
  except Exception as err:
   FF2nrW(self, str(err))
   self.close(None)
 def VVO7qr(self):
  FFiD9O(self)
  if self.VVgzpW:
   FFfaVA(self["myTitle"], self.VVgzpW)
  if self.VVTK1M:
   FFfaVA(self["myBody"] , self.VVTK1M)
   FFfaVA(self["myTableH"] , self.VVTK1M)
   FFfaVA(self["myTable"] , self.VVTK1M)
   FFfaVA(self["myBar"]  , self.VVTK1M)
  self.VVB8Zh(self.VVRPnY  , self["keyRed"])
  self.VVB8Zh(self.VVg6wQ  , self["keyGreen"])
  self.VVB8Zh(self.VV4CnB , self["keyYellow"])
  self.VVB8Zh(self.VVqvqX  , self["keyBlue"])
  if self.VV5Dm0:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VV5Dm0[0])
    FFfaVA(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVYdZK)
  self["myTableH"].l.setFont(0, gFont(VV20Ap, self.VVdfkW))
  self["myTable"].l.setItemHeight(self.VVYdZK)
  self["myTable"].l.setFont(0, gFont(VV20Ap, self.VVdfkW))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVYdZK)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVYdZK))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVYdZK)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVYdZK
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVYdZK * len(self.VVPIPy) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVZt3N:
   self.VVZt3N = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVZt3N)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVJRZ2:
   self.VVJRZ2 = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVJRZ2
   self.VVJRZ2 = []
   for item in tmpList:
    self.VVJRZ2.append(item | RT_VALIGN_CENTER)
  self.VV92tu()
  if self.VVkv8J:
   self.VVkv8J(self)
 def VVB8Zh(self, btnFnc, btn):
  if btnFnc : FFKY2X(btn, btnFnc[0])
  else  : FFKY2X(btn, "")
 def VV19cf(self, waitTxt):
  FFikZL(self, self.VV92tu, title=waitTxt)
 def VV92tu(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVWQYY(0, self.header, self.VVoPTh, self.VVi5es, self.VVoPTh, self.VVi5es, self.VVzfnx)])
   rows = []
   for c, row in enumerate(self.VVPIPy):
    rows.append(self.VVWQYY(c, row, self.VV5bYq, self.VVKZRt, self.VVpFk3, self.VVPQde, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VV48q3 > -1:
    self["myTable"].moveToIndex(self.VV48q3 )
   self.VV9qhr()
   if self.VV9Auz:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVYdZK * len(self.VVPIPy)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VV1FjN:
    self.VVJKEG(self.VV1FjN, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FF2nrW(self, str(err))
    self.close()
   except:
    pass
 def VVWQYY(self, keyIndex, columns, VV5bYq, VVKZRt, VVpFk3, VVPQde, VVzfnx):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVzfnx and ndx == self.VV6jUG : textColor = VVzfnx
   else           : textColor = VV5bYq
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFXNey(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVKZRt = c
    entry = span.group(3)
   if self.VVJRZ2[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVYdZK)
           , font   = 0
           , flags   = self.VVJRZ2[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVKZRt
           , color_sel  = VVpFk3
           , backcolor_sel = VVPQde
           , border_width = 1
           , border_color = self.VVXHiK
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVNfdA(self):
  rowData = self.VVrk9A()
  if rowData:
   title, txt, colList = rowData
   if self.VVBfeb:
    fnc  = self.VVBfeb[1]
    params = self.VVBfeb[2]
    fnc(self, title, txt, colList)
   else:
    FFSnuH(self, txt, title)
 def VV3SzY(self):
  if   self.VVP0TW : self.VVlrx4(self.VVuJp4(), mode=2)
  elif self.VV5Dm0  : self.VVJKEG(self.VV5Dm0, None)
  else      : self.VVNfdA()
 def VVHS7k(self) : self.VVJKEG(self.VVRPnY , self["keyRed"])
 def VVyPwN(self) : self.VVJKEG(self.VVg6wQ , self["keyGreen"])
 def VV6Aa1(self): self.VVJKEG(self.VV4CnB , self["keyYellow"])
 def VVle9s(self) : self.VVJKEG(self.VVqvqX , self["keyBlue"])
 def VVJKEG(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFdxmx(self, buttonFnc[3])
    FFsV3D(boundFunction(self.VVYFRZ, buttonFnc))
   else:
    self.VVYFRZ(buttonFnc)
 def VVYFRZ(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVrk9A()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVlrx4(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VVPIPy[ndx]
   isSelected = row[1][9] == self.VVP0bi
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVWQYY(ndx, item, self.VV5bYq, self.VVKZRt, self.VVpFk3, self.VVPQde, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVWQYY(ndx, item, self.VVP0bi, self.VVW4zv, self.VVNZDY, self.VVRi7k, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VV9qhr()
 def VV2VJ1(self):
  FFikZL(self, self.VVeGKZ, title="Selecting all ...")
 def VVeGKZ(self):
  self.VVfEwH(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVP0bi
   if not isSelected:
    item = self.VVPIPy[ndx]
    newRow = self.VVWQYY(ndx, item, self.VVP0bi, self.VVW4zv, self.VVNZDY, self.VVRi7k, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VV9qhr()
  self.VVdhu2()
 def VVoscE(self):
  FFikZL(self, self.VVTCh4, title="Unselecting all ...")
 def VVTCh4(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVP0bi:
    item = self.VVPIPy[ndx]
    newRow = self.VVWQYY(ndx, item, self.VV5bYq, self.VVKZRt, self.VVpFk3, self.VVPQde, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VV9qhr()
  self.VVdhu2()
 def VVdhu2(self):
  self.hide()
  self.show()
 def VVrk9A(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVZt3N[i] > 1 or self.VVZt3N[i] == self.VVPL9V:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VVPIPy))
   return rowNum, txt, colList
  else:
   return None
 def VVnFts(self):
  if self.VVRPWD : self.VVRPWD(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVuNA3(self):
  return self["myTitle"].getText().strip()
 def VVLWMK(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VV8Yq9(self, txt):
  FFdxmx(self, txt)
 def VVWnVY(self, txt):
  FFdxmx(self, txt, 1000)
 def VVGwFc(self):
  FFdxmx(self)
 def VVWhHx(self):
  return len(self.VVPIPy)
 def VVVhJ8(self): self["keyGreen"].show()
 def VVpEhX(self): self["keyGreen"].hide()
 def VVuJp4(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVzWF7(self):
  return len(self["myTable"].list)
 def VVfEwH(self, isOn):
  self.VVP0TW = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   if self.VVqvqX: self["keyBlue"].hide()
   if self.VV5Dm0 and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
   if self.VVqvqX: self["keyBlue"].show()
   if self.VV5Dm0 and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VV5Dm0[0])
   self.VVoscE()
  FFfaVA(self["myTitle"], color)
  FFfaVA(self["myBar"]  , color)
 def VVNkuj(self):
  return self.VVP0TW
 def VVN0xD(self):
  return self.selectedItems
 def VVt2ck(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VV9qhr()
 def VVs8Fm(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VV9qhr()
 def VVOOvt(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VVPIPy:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVd3AP(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVWhHx()
  txt += FFjBJQ("Total Unique Items", VVUqrB)
  for i in range(self.totalCols):
   if self.VVZt3N[i - 1] > 1 or self.VVZt3N[i - 1] == self.VVPL9V:
    name, tot = self.VVOOvt(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFSnuH(self, txt)
 def VVfyIm(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVKzHE(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVRlUS(self, newList, newTitle=""):
  if newList:
   self.VVPIPy = newList
   if self.VVSFYp and self.VV6jUG == 0:
    self.VVPIPy = sorted(self.VVPIPy, key=lambda x: int(x[self.VV6jUG])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VVPIPy = sorted(self.VVPIPy, key=lambda x: x[self.VV6jUG].lower(), reverse=self.lastSortModeIsReverese)
   self.VV19cf("Refreshing ...")
   if newTitle:
    self.VVLWMK(newTitle)
  else:
   FF2nrW(self, "Cannot refresh list")
   self.cancel()
 def VVffu3(self, data):
  ndx = self.VVuJp4()
  newRow = self.VVWQYY(ndx, data, self.VV5bYq, self.VVKZRt, self.VVpFk3, self.VVPQde, None)
  if newRow:
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VV9qhr()
   return True
  else:
   return False
 def VVEKIJ(self, colNum, textToFind, VVxCvy=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VV9qhr()
    break
  else:
   if VVxCvy:
    FFdxmx(self, "Not found", 1000)
 def VVg3Na(self, colDict, VVxCvy=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VV9qhr()
    return
  if VVxCvy:
   FFdxmx(self, "Not found", 1000)
 def VVg3Na_partial(self, colDict, VVxCvy=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VV9qhr()
    return
  if VVxCvy:
   FFdxmx(self, "Not found", 1000)
 def VV398i(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVVQj7(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVP0bi:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVpWYB(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVBE1C(self):
  if not self["keyMenu2F"].getVisible() or self.VV9Auz:
   return
  VVRJT5 = []
  VVRJT5.append(("Table Statistcis"             , "tableStat"  ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append((FF5Q6H("Export Table to .html"     , VVUqrB) , "VVu6EA" ))
  VVRJT5.append((FF5Q6H("Export Table to .csv"     , VVUqrB) , "VVjLzE" ))
  VVRJT5.append((FF5Q6H("Export Table to .txt (Tab Separated)", VVUqrB) , "VVM6pS" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVZt3N[i] > 1 or self.VVZt3N[i] == self.VVJlol:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVRJT5.append(VVn6Em)
   if tot == 1 : VVRJT5.append(("Sort", sList[0][1]))
   else  : VVRJT5 += sList
  FF4JCK(self, self.VVy7ij, VVRJT5=VVRJT5, title=self.VVuNA3())
 def VVy7ij(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVd3AP()
   elif item == "VVu6EA": FFikZL(self, self.VVu6EA, title=title)
   elif item == "VVjLzE" : FFikZL(self, self.VVjLzE , title=title)
   elif item == "VVM6pS" : FFikZL(self, self.VVM6pS , title=title)
   else:
    isReversed = False
    if self.VV6jUG == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVSFYp and item == 0:
     self.VVPIPy = sorted(self.VVPIPy, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VVPIPy = sorted(self.VVPIPy, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VV6jUG = item
    self.VV19cf("Sorting ...")
 def VVnrfA(self):
  self["myTable"].up()
  self.VV9qhr()
 def VVmGSS(self):
  self["myTable"].down()
  self.VV9qhr()
 def VVpP9Y(self):
  self["myTable"].pageUp()
  self.VV9qhr()
 def VVOqMN(self):
  self["myTable"].pageDown()
  self.VV9qhr()
 def VVpVFO(self):
  self["myTable"].moveToIndex(0)
  self.VV9qhr()
 def VV56SP(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VV9qhr()
 def VVM6pS(self):
  expFile = self.VVvEpZ() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVjep3()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VVPIPy:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVZt3N[ndx] > self.VVHgXj:
      col = self.VVlJNr(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVSTj5(expFile)
 def VVjLzE(self):
  expFile = self.VVvEpZ() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVjep3()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VVPIPy:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVZt3N[ndx] > self.VVHgXj:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVlJNr(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVSTj5(expFile)
 def VVu6EA(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVuNA3(), PLUGIN_NAME, VVLiaM)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVuNA3()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVjep3()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVZt3N:
   colgroup += '   <colgroup>'
   for w in self.VVZt3N:
    if w > self.VVHgXj:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVvEpZ() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VVPIPy:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVZt3N[ndx] > self.VVHgXj:
      col = self.VVlJNr(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVSTj5(expFile)
 def VVjep3(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVZt3N[ndx] > self.VVHgXj:
     newRow.append(col.strip())
  return newRow
 def VVlJNr(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  return FF2A5P(col)
 def VVvEpZ(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVuNA3())
  fileName = fileName.replace("__", "_")
  path  = FFq2Op(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FF8AiB()
  return expFile
 def VVSTj5(self, expFile):
  FFrerH(self, "File exported to:\n\n%s" % expFile, title=self.VVuNA3())
 def VV9qhr(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CChofK(Screen):
 def __init__(self, session, Title="", VVnjxi=None):
  self.skin, self.skinParam = FFXEzn(VV4yLp, 1400, 800, 50, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FFnDik(self, Title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VVnjxi = VVnjxi
  if len(Title) == 0 : Title = FF6oMc()
  else    : Title = "File : %s" % VVnjxi
  self["myTitle"] = Label("  %s" % Title)
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  allOK = FFjQE2(self["myLabel"], self.VVnjxi)
  if not allOK:
   FF2nrW(self, "Could not view this picture file")
   self.close()
class CCzzpK(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFXEzn(VVbuSy, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 28, barHeight=40, topRightBtns=1)
  self.session  = session
  FFnDik(self)
  FFKY2X(self["keyGreen"], "Save")
  self.VVPIPy = []
  self.VVPIPy.append(getConfigListEntry("Show in Main Menu"         , CFG.showInMainMenu   ))
  self.VVPIPy.append(getConfigListEntry("Show in Extensions Menu"        , CFG.showInExtensionMenu  ))
  self.VVPIPy.append(getConfigListEntry("Show in Channel List Context Menu"     , CFG.showInChannelListMenu  ))
  self.VVPIPy.append(getConfigListEntry("Input Type"           , CFG.keyboard     ))
  self.VVPIPy.append(getConfigListEntry("Signal & Player Cotroller Hotkey"     , CFG.hotkey_signal    ))
  if VV3ToJ:
   self.VVPIPy.append(getConfigListEntry("EPG Translation Language"      , CFG.epgLanguage    ))
  self.VVPIPy.append(getConfigListEntry(VV06tg *2            ,         ))
  self.VVPIPy.append(getConfigListEntry("Default IPTV Reference Type"       , CFG.iptvAddToBouquetRefType ))
  self.VVPIPy.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"    , CFG.hideIptvServerAdultWords ))
  self.VVPIPy.append(getConfigListEntry('Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)' , CFG.hideIptvServerChannPrefix ))
  self.VVPIPy.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"  , CFG.iptvHostsPath    ))
  self.VVPIPy.append(getConfigListEntry(VV06tg *2            ,         ))
  self.VVPIPy.append(getConfigListEntry("PIcons Path"           , CFG.PIconsPath    ))
  self.VVPIPy.append(getConfigListEntry(VV06tg *2            ,         ))
  self.VVPIPy.append(getConfigListEntry("Backup/Restore Path"         , CFG.backupPath    ))
  self.VVPIPy.append(getConfigListEntry("Created Package Files (IPK/DEB)"      , CFG.packageOutputPath   ))
  self.VVPIPy.append(getConfigListEntry("Downloaded Packages (from feeds)"     , CFG.downloadedPackagesPath ))
  self.VVPIPy.append(getConfigListEntry("Exported Tables"          , CFG.exportedTablesPath  ))
  self.VVPIPy.append(getConfigListEntry("Exported PIcons"          , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, self.VVPIPy, session)
  self["setupActions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard", "OkCancelActions"],
  {
   "ok"  : self.VVDa6H   ,
   "OK"  : self.VVDa6H   ,
   "green"  : self.VVuEwY  ,
   "menu"  : self.VVQ5Lc ,
   "cancel" : self.VVUwA2
  }, -1)
  self.titleText = "  Settings"
  self["myTitle"].setText(self.titleText)
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  FF0xrD(self["config"])
  FFJAKu(self,  self["config"])
  FFiD9O(self)
 def VVDa6H(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsPath   : self.VV6ldZ()
   elif item == CFG.PIconsPath    : self.VVi55b(item)
   elif item == CFG.backupPath    : self.VVi55b(item)
   elif item == CFG.packageOutputPath  : self.VVi55b(item)
   elif item == CFG.downloadedPackagesPath : self.VVi55b(item)
   elif item == CFG.exportedTablesPath  : self.VVi55b(item)
   elif item == CFG.exportedPIconsPath  : self.VVi55b(item)
 def VV6ldZ(self):
  VVRJT5 = []
  VVRJT5.append(("Auto Find" , "auto"))
  VVRJT5.append(("Custom Path" , "path"))
  FF4JCK(self, self.VVVRnk, VVRJT5=VVRJT5, title="IPTV Hosts Files Path")
 def VVVRnk(self, item=None):
  if item:
   if   item == "auto": CFG.iptvHostsPath.setValue(VVlZ7S)
   elif item == "path": self.VVi55b(CFG.iptvHostsPath)
 def VVi55b(self, configObj):
  sDir = configObj.getValue()
  if sDir == VVlZ7S:
   sDir = "/"
  self.session.openWithCallback(boundFunction(self.VVix2b, configObj)
         , boundFunction(CCNIug, mode=CCNIug.VVSQ2B, VVBEkA=sDir))
 def VVix2b(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVUwA2(self):
  if CFG.showInMainMenu.isChanged()    or \
   CFG.showInExtensionMenu.isChanged()   or \
   CFG.showInChannelListMenu.isChanged()  or \
   CFG.keyboard.isChanged()     or \
   CFG.hotkey_signal.isChanged()    or \
   CFG.epgLanguage.isChanged()     or \
   CFG.iptvAddToBouquetRefType.isChanged()  or \
   CFG.hideIptvServerAdultWords.isChanged() or \
   CFG.hideIptvServerChannPrefix.isChanged() or \
   CFG.iptvHostsPath.isChanged()    or \
   CFG.PIconsPath.isChanged()     or \
   CFG.backupPath.isChanged()     or \
   CFG.packageOutputPath.isChanged()   or \
   CFG.downloadedPackagesPath.isChanged()  or \
   CFG.exportedTablesPath.isChanged()   or \
   CFG.exportedPIconsPath.isChanged():
    FFjphE(self, self.VVuEwY, "Save Changes ?", callBack_No=self.cancel)
  else:
   self.cancel()
 def VVuEwY(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVpE7j()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVQ5Lc(self):
  VVRJT5 = []
  VVRJT5.append(("Use Backup directory in all other paths"      , "VV6Ep8"   ))
  VVRJT5.append(("Reset all to default (including File Manager bookmarks)"  , "VVont1"   ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Backup %s Settings" % PLUGIN_NAME        , "VV9K6p"  ))
  VVRJT5.append(("Restore %s Settings" % PLUGIN_NAME       , "VVxC2g"  ))
  if fileExists(VVHCIO + VVWJxc):
   VVRJT5.append(VVn6Em)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVRJT5.append(('%s Checking for Update' % txt1       , txt2     ))
   VVRJT5.append(("Reinstall %s" % PLUGIN_NAME        , "VVM9DN"  ))
   VVRJT5.append(("Update %s" % PLUGIN_NAME        , "VV0cpW"   ))
  FF4JCK(self, self.VVHXOh, VVRJT5=VVRJT5, title="Config. Options")
 def VVHXOh(self, item=None):
  if item:
   if   item == "VV6Ep8"  : FFjphE(self, self.VV6Ep8 , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVont1"  : FFjphE(self, self.VVont1, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCBmOP)
   elif item == "VV9K6p" : self.VV9K6p()
   elif item == "VVxC2g" : FFikZL(self, self.VVxC2g, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVFdIC(True)
   elif item == "disableChkUpdate" : self.VVFdIC(False)
   elif item == "VVM9DN" : FFikZL(self, self.VVM9DN , "Checking Server ...")
   elif item == "VV0cpW"  : FFikZL(self, self.VV0cpW  , "Checking Server ...")
 def VV9K6p(self):
  path = "%sajpanel_settings_%s" % (VVHCIO, FF8AiB())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFrerH(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVxC2g(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFo8V2("find / %s -iname '%s*' | grep %s" % (FFyECp(1), name, name))
  if lines:
   lines.sort()
   VVRJT5 = []
   for line in lines:
    VVRJT5.append((line, line))
   FF4JCK(self, boundFunction(self.VVt1JZ, title), title=title, VVRJT5=VVRJT5, width=1200)
  else:
   FF2nrW(self, "No settings files found !", title=title)
 def VVt1JZ(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFxmgd(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVpE7j()
    FFxsSD()
   else:
    FFAPN6(SELF, path, title=title)
 def VVFdIC(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VV6Ep8(self):
  newPath = FFq2Op(VVHCIO)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVpE7j()
 @staticmethod
 def VVrRTE():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVont1(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.epgLanguage.setValue("off")
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.iptvHostsPath.setValue(VVlZ7S)
  CFG.PIconsPath.setValue(VVfmhV)
  CFG.backupPath.setValue(CCzzpK.VVrRTE())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  CFG.showInMainMenu.save()
  CFG.showInExtensionMenu.save()
  CFG.showInChannelListMenu.save()
  CFG.keyboard.save()
  CFG.hotkey_signal.save()
  CFG.epgLanguage.save()
  CFG.iptvAddToBouquetRefType.save()
  CFG.hideIptvServerAdultWords.save()
  CFG.hideIptvServerChannPrefix.save()
  CFG.iptvHostsPath.save()
  CFG.PIconsPath.save()
  CFG.backupPath.save()
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  CFG.browserStartPath.save()
  CFG.browserBookmarks.save()
  self.VVpE7j()
  self.close()
 def VVpE7j(self):
  configfile.save()
  global VVHCIO
  VVHCIO = CFG.backupPath.getValue()
  FFtNpV()
 def VV0cpW(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVPmtR(title)
  if webVer:
   FFjphE(self, boundFunction(FFikZL, self, boundFunction(self.VVzPkX, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVM9DN(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVPmtR(title, True)
  if webVer:
   FFjphE(self, boundFunction(FFikZL, self, boundFunction(self.VVzPkX, webVer, title)), "Install and Restart ?", title=title)
 def VVzPkX(self, webVer, title):
  url = self.VVU1zS(self, title)
  if url:
   VVCSkY = FFJw6G() == "dpkg"
   if VVCSkY == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVCSkY else "ipk")
   path, err = FFj4ge(url + fName, fName, timeout=2)
   if path:
    cmd = FF1oa1(VVNhZF, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFjY30(self, cmd)
    else:
     FFJSkq(self, title=title)
   else:
    FF2nrW(self, err, title=title)
 def VVPmtR(self, title, anyVer=False):
  url = self.VVU1zS(self, title)
  if not url:
   return ""
  path, err = FFj4ge(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FF2nrW(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FF83qF(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FF2nrW(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVLiaM.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFo8V2(cmd)
   if list and curVer == list[0]:
    return webVer
  FFrerH(self, FF5Q6H("No update required.", VV0Tnk) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVU1zS(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVHCIO + VVWJxc
  if fileExists(path):
   span = iSearch(r"(http.+)", FF83qF(path), IGNORECASE)
   if span : url = FFq2Op(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FF2nrW(SELF, err, title)
  return url
 @staticmethod
 def VV53JM(url):
  path, err = FFj4ge(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FF83qF(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVLiaM.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFo8V2(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCBmOP(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFXEzn(VVtR0a, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVA115
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFnDik(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVZOjl("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVZOjl("\c00888888", i) + sp + "GREY\n"
   txt += self.VVZOjl("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVZOjl("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVZOjl("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVZOjl("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVZOjl("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVZOjl("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVZOjl("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVZOjl("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVZOjl("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVZOjl("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVDa6H ,
   "green"   : self.VVDa6H ,
   "left"   : self.VVcHvU ,
   "right"   : self.VVltG8 ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  self.VVuZzh()
 def VVDa6H(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFjphE(self, self.VV6Kbd, "Change to : %s" % txt, title=self.Title)
 def VV6Kbd(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVA115
  VVA115 = self.cursorPos
  self.VVinIV()
  self.close()
 def VVcHvU(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVuZzh()
 def VVltG8(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVuZzh()
 def VVuZzh(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVZOjl(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVKSIH(color):
  if VVvgWJ: return "\\" + color
  else    : return ""
 @staticmethod
 def VVinIV():
  global VVvQSh, VViEcp, VVDbaf, VVUqrB, VVlVvm, VVx9g6, VV0Tnk, VVvgWJ, COLOR_CONS_BRIGHT_YELLOW, VVbaBa, VVkwvG, VV011v
  VV011v   = CCBmOP.VVZOjl("\c00FFFFFF", VVA115)
  VViEcp    = CCBmOP.VVZOjl("\c00888888", VVA115)
  VVvQSh  = CCBmOP.VVZOjl("\c005A5A5A", VVA115)
  VVx9g6    = CCBmOP.VVZOjl("\c00FF0000", VVA115)
  VVDbaf   = CCBmOP.VVZOjl("\c00FF5000", VVA115)
  VVvgWJ   = CCBmOP.VVZOjl("\c00FFFF00", VVA115)
  COLOR_CONS_BRIGHT_YELLOW = CCBmOP.VVZOjl("\c00FFFFAA", VVA115)
  VV0Tnk   = CCBmOP.VVZOjl("\c0000FF00", VVA115)
  VVlVvm    = CCBmOP.VVZOjl("\c000066FF", VVA115)
  VVbaBa    = CCBmOP.VVZOjl("\c0000FFFF", VVA115)
  VVkwvG   = CCBmOP.VVZOjl("\c00FA55E7", VVA115)
  VVUqrB    = CCBmOP.VVZOjl("\c00FF8F5F", VVA115)
CCBmOP.VVinIV()
class CCFLqD(Screen):
 def __init__(self, session, path, VVCSkY):
  self.skin, self.skinParam = FFXEzn(VVUyHt, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVoUEl   = path
  self.VVcjQD   = ""
  self.VVGXoL   = ""
  self.VVCSkY    = VVCSkY
  self.VVuaux    = ""
  self.VVREKy  = ""
  self.VVdSAh    = False
  self.VV2HBv  = False
  self.postInstAcion   = 0
  self.VVgQAz  = "enigma2-plugin-extensions"
  self.VVHbea  = "enigma2-plugin-systemplugins"
  self.VVHeP4 = "enigma2"
  self.VVIT48  = 0
  self.VV3aP1  = 1
  self.VVkciU  = 2
  if pathExists(self.Path + "DEBIAN") : self.VV1x3O = "DEBIAN"
  else        : self.VV1x3O = "CONTROL"
  self.controlPath = self.Path + self.VV1x3O
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVCSkY:
   self.packageExt  = ".deb"
   self.VVKZRt  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVKZRt  = "#11001020"
  FFnDik(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFKY2X(self["keyRed"] , "Create")
  FFKY2X(self["keyGreen"] , "Post Install")
  FFKY2X(self["keyYellow"], "Installation Path")
  FFKY2X(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVWpK5  ,
   "green"   : self.VViQOj ,
   "yellow"  : self.VVrbhR  ,
   "blue"   : self.VVOOKm  ,
   "cancel"  : self.VV4ONu
  }, -1)
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  FFiD9O(self)
  if self.VVKZRt:
   FFfaVA(self["myBody"], self.VVKZRt)
   FFfaVA(self["myLabel"], self.VVKZRt)
  self.VVNOkf(True)
  self.VVCW9W(True)
 def VVCW9W(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVmsUv()
  if isFirstTime:
   if   package.startswith(self.VVgQAz) : self.VVoUEl = VVnwNP + self.VVuaux + "/"
   elif package.startswith(self.VVHbea) : self.VVoUEl = VVTuBV + self.VVuaux + "/"
   else            : self.VVoUEl = self.Path
  if self.VVdSAh : myColor = VVUqrB
  else    : myColor = VV011v
  txt  = ""
  txt += "Source Path\t: %s\n" % FF5Q6H(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FF5Q6H(self.VVoUEl, VVvgWJ)
  if self.VVGXoL : txt += "Package File\t: %s\n" % FF5Q6H(self.VVGXoL, VViEcp)
  elif errTxt   : txt += "Warning\t: %s\n"  % FF5Q6H("Check Control File fields : %s" % errTxt, VVDbaf)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FF5Q6H("Restart GUI", VVUqrB)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FF5Q6H("Reboot Device", VVUqrB)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FF5Q6H("Post Install", VV0Tnk), act)
  if not errTxt and VVDbaf in controlInfo:
   txt += "Warning\t: %s\n" % FF5Q6H("Errors in control file may affect the result package.", VVDbaf)
  txt += "\nControl File\t: %s\n" % FF5Q6H(self.controlFile, VViEcp)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VViQOj(self):
  VVRJT5 = []
  VVRJT5.append(("No Action"    , "noAction"  ))
  VVRJT5.append(("Restart GUI"    , "VVDbHQ"  ))
  VVRJT5.append(("Reboot Device"   , "rebootDev"  ))
  FF4JCK(self, self.VVvMJl, title="Package Installation Option (after completing installation)", VVRJT5=VVRJT5)
 def VVvMJl(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVDbHQ"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVNOkf(False)
   self.VVCW9W()
 def VVrbhR(self):
  rootPath = FF5Q6H("/%s/" % self.VVuaux, VVvQSh)
  VVRJT5 = []
  VVRJT5.append(("Current Path"        , "toCurrent"  ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Extension Path"       , "toExtensions" ))
  VVRJT5.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVRJT5.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FF4JCK(self, self.VVMqgK, title="Installation Path", VVRJT5=VVRJT5)
 def VVMqgK(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VV0Gnu(FFkUaP(self.Path, True))
   elif item == "toExtensions"  : self.VV0Gnu(VVnwNP)
   elif item == "toSystemPlugins" : self.VV0Gnu(VVTuBV)
   elif item == "toRootPath"  : self.VV0Gnu("/")
   elif item == "toRoot"   : self.VV0Gnu("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVShI8, boundFunction(CCNIug, mode=CCNIug.VVSQ2B, VVBEkA=VVHCIO))
 def VVShI8(self, path):
  if len(path) > 0:
   self.VV0Gnu(path)
 def VV0Gnu(self, parent, withPackageName=True):
  if withPackageName : self.VVoUEl = parent + self.VVuaux + "/"
  else    : self.VVoUEl = "/"
  mode = self.VVaGeZ()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVa3d4(mode), self.controlFile))
  self.VVCW9W()
 def VVOOKm(self):
  if fileExists(self.controlFile):
   lines = FFxmgd(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFzere(self, self.VV7gId, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FF2nrW(self, "Version not found or incorrectly set !")
  else:
   FFAPN6(self, self.controlFile)
 def VV7gId(self, VVckRP):
  if VVckRP:
   version, color = self.VVu5XG(VVckRP, False)
   if color == VVbaBa:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVckRP, self.controlFile))
    self.VVCW9W()
   else:
    FF2nrW(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VV4ONu(self):
  if self.newControlPath:
   if self.VVdSAh:
    self.VVKdOS()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FF5Q6H(self.newControlPath, VViEcp)
    txt += FF5Q6H("Do you want to keep these files ?", VVvgWJ)
    FFjphE(self, self.close, txt, callBack_No=self.VVKdOS, title="Create Package", VVzwqf=True)
  else:
   self.close()
 def VVKdOS(self):
  os.system(FF3WD3("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVa3d4(self, mode):
  if   mode == self.VV3aP1 : prefix = self.VVgQAz
  elif mode == self.VVkciU : prefix = self.VVHbea
  else        : prefix = self.VVHeP4
  return prefix + "-" + self.VVREKy
 def VVaGeZ(self):
  if   self.VVoUEl.startswith(VVnwNP) : return self.VV3aP1
  elif self.VVoUEl.startswith(VVTuBV) : return self.VVkciU
  else            : return self.VVIT48
 def VVNOkf(self, isFirstTime):
  self.VVuaux   = os.path.basename(os.path.normpath(self.Path))
  self.VVuaux   = "_".join(self.VVuaux.split())
  self.VVREKy = self.VVuaux.lower()
  self.VVdSAh = self.VVREKy == VVGbBr.lower()
  if self.VVdSAh and self.VVREKy.endswith("ajpan"):
   self.VVREKy += "el"
  if self.VVdSAh : self.VVcjQD = VVHCIO
  else    : self.VVcjQD = CFG.packageOutputPath.getValue()
  self.VVcjQD = FFq2Op(self.VVcjQD)
  if not pathExists(self.controlPath):
   os.system(FF3WD3("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVdSAh : t = PLUGIN_NAME
  else    : t = self.VVuaux
  self.VVVn7Q(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VV2rzf.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVdSAh : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVVn7Q(self.postrmFile, txt)
  if self.VVdSAh:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVLiaM)
   self.VVVn7Q(self.preinstFile, txt)
  else:
   self.VVVn7Q(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVuaux)
  mode = self.VVaGeZ()
  if isFirstTime and not mode == self.VVIT48:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VV06tg
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVVn7Q(self.postinstFile, txt, VVvzKF=True)
  os.system(FF3WD3("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVdSAh : version, descripton, maintainer = VVLiaM , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVuaux , self.VVuaux
   txt = ""
   txt += "Package: %s\n"  % self.VVa3d4(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVVn7Q(self, path, lines, VVvzKF=False):
  if not fileExists(path) or VVvzKF:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVmsUv(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFxmgd(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FF5Q6H(line, VVDbaf)
     elif not line.startswith(" ")    : line = FF5Q6H(line, VVDbaf)
     else          : line = FF5Q6H(line, VVbaBa)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVbaBa
   else   : color = VVDbaf
   descr = FF5Q6H(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVDbaf
     elif line.startswith((" ", "\t")) : color = VVDbaf
     elif line.startswith("#")   : color = VViEcp
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVu5XG(val, True)
      elif key == "Version"  : version, color = self.VVu5XG(val, False)
      elif key == "Maintainer" : maint  , color = val, VVbaBa
      elif key == "Architecture" : arch  , color = val, VVbaBa
      else:
       color = VVbaBa
      if not key == "OE" and not key.istitle():
       color = VVDbaf
     else:
      color = VVUqrB
     txt += FF5Q6H(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVGXoL = self.VVcjQD + packageName
   self.VV2HBv = True
   errTxt = ""
  else:
   self.VVGXoL  = ""
   self.VV2HBv = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVu5XG(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVbaBa
  else          : return val, VVDbaf
 def VVWpK5(self):
  if not self.VV2HBv:
   FF2nrW(self, "Please fix Control File errors first.")
   return
  if self.VVCSkY: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFkUaP(self.VVoUEl, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVuaux
  symlinkTo  = FFDv1k(self.Path)
  dataDir   = self.VVoUEl.rstrip("/")
  removePorjDir = FF3WD3("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FF3WD3("rm -f '%s'" % self.VVGXoL) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFYsPW()
  if self.VVCSkY:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFUpCM("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVdSAh:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVoUEl == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VV1x3O)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVGXoL, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVGXoL
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVGXoL, FFyIHF(result  , VV0Tnk))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVoUEl, FFyIHF(instPath, VVbaBa))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFyIHF(failed, VVDbaf))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFjY30(self, cmd)
class CCNIug(Screen):
 VVCSbg   = 0
 VVSQ2B  = 1
 VVYSuD = 20
 def __init__(self, session, VVBEkA="/", mode=VVCSbg, VVmkIG="Select", VVdfkW=30):
  self.skin, self.skinParam = FFXEzn(VVdXwL, 1400, 820, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFnDik(self)
  FFKY2X(self["keyRed"] , "Exit")
  FFKY2X(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVmkIG = VVmkIG
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  if   self.mode == self.VVCSbg  : VVFw8R, self.VVBEkA = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVSQ2B : VVFw8R, self.VVBEkA = False, VVBEkA
  else           : VVFw8R, self.VVBEkA = True , VVBEkA
  VVBEkA = FFq2Op(VVBEkA)
  self["myMenu"] = CCwp2U(  directory   = "/"
         , VVFw8R   = VVFw8R
         , VVhuuh = True
         , VVvvA9   = self.skinParam["width"]
         , VVdfkW   = self.skinParam["bodyFontSize"]
         , VVYdZK  = self.skinParam["bodyLineH"]
         , VVmWrz  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVDa6H      ,
   "red"    : self.cancel      ,
   "green"    : self.VV9ceO    ,
   "yellow"   : self.VVpnvU   ,
   "blue"    : self.VVwFPA   ,
   "menu"    : self.VVj2Dj    ,
   "info"    : self.VVYxK6    ,
   "cancel"   : self.VVAOB9     ,
   "pageUp"   : self.VVAOB9     ,
   "chanUp"   : self.VVAOB9
  }, -1)
  FFKcR0(self, self["myMenu"])
  self.onShown.append(self.start)
  self["myMenu"].onSelectionChanged.append(self.VV3PFz)
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VV3PFz)
  FF0xrD(self["myMenu"], bg="#06003333")
  FFiD9O(self)
  self.maxTitleWidth = self["keyMenu1"].getPosition()[0] - 40
  if self.mode == self.VVSQ2B:
   FFKY2X(self["keyGreen"], self.VVmkIG)
   color = "#22000022"
   FFfaVA(self["myBody"], color)
   FFfaVA(self["myMenu"], color)
   color = "#22220000"
   FFfaVA(self["myTitle"], color)
   FFfaVA(self["myBar"], color)
  self.VV3PFz()
  if self.VVtlnn(self.VVBEkA) > self.bigDirSize:
   FFdxmx(self, "Changing directory...")
   FFsV3D(self.VVx52u)
  else:
   self.VVx52u()
 def VVx52u(self):
  self["myMenu"].VVUps6(self.VVBEkA)
 def VV6ZOq(self):
  self["myMenu"].refresh()
  FF80hJ()
 def VVtlnn(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VVDa6H(self):
  if self["myMenu"].VVcJQh():
   path = self.VV4sGG(self.VVw3bl())
   if self.VVtlnn(path) > self.bigDirSize:
    FFdxmx(self, "Changing directory...")
    FFsV3D(self.VVoA4K)
   else:
    self.VVoA4K()
  else:
   self.VVJJm5()
 def VVoA4K(self):
  self["myMenu"].descent()
  self["myMenu"].moveToIndex(0)
  self.VV3PFz()
 def VVAOB9(self):
  if self["myMenu"].VVxnci():
   self["myMenu"].moveToIndex(0)
   self.VVoA4K()
 def cancel(self):
  if not FFTrJK(self):
   self.close("")
 def VV9ceO(self):
  if self.mode == self.VVSQ2B:
   path = self.VV4sGG(self.VVw3bl())
   self.close(path)
 def VVYxK6(self):
  FFikZL(self, self.VVvYLH, title="Calculating size ...")
 def VVvYLH(self):
  path = self.VV4sGG(self.VVw3bl())
  param = self.VVK9dl(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = ""
   if typeChar == "d":
    result = FF7GV9("myDir='%s'; totDirs=$(find $myDir -type d | wc -l); totFiles=$(find $myDir ! -type d | wc -l); echo $totDirs','$totFiles" % path)
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents  = "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
    size = FF7GV9("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    size = int(size)
   if size >= 1024 : size = "%s  ( %s bytes )" % (self.VVWHJa(size), format(size, ',d'))
   else   : size = "%s" % self.VVWHJa(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FF5Q6H(pathTxt, VVUqrB) + "\n"
   if slBroken : fileTime = self.VV0C6T(path)
   else  : fileTime = self.VV3gCA(path)
   def VVBU5P(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVBU5P("Path"    , pathTxt)
   txt += VVBU5P("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVBU5P("Target"   , slTarget)
   txt += VVBU5P("Size"    , "%s" % size)
   txt += contents
   txt += "\n"
   txt += VVBU5P("Owner"    , owner)
   txt += VVBU5P("Group"    , group)
   txt += VVBU5P("Perm. (User)"  , permUser)
   txt += VVBU5P("Perm. (Group)"  , permGroup)
   txt += VVBU5P("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVBU5P("Perm. (Ext.)" , permExtra)
   txt += VVBU5P("iNode"    , iNode)
   txt += VVBU5P("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VV06tg, VV06tg)
    txt += hLinkedFiles
   txt += self.VVsHyT(path)
  else:
   FF2nrW(self, "Cannot access information !")
  if len(txt) > 0:
   FFSnuH(self, txt)
 def VVK9dl(self, path):
  path = path.strip()
  path = FFDv1k(path)
  result = FF7GV9("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVGSRH(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVGSRH(perm, 1, 4)
   permGroup = VVGSRH(perm, 4, 7)
   permOther = VVGSRH(perm, 7, 10)
   permExtra = VVGSRH(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFPaF1("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVsHyT(self, path):
  txt  = ""
  res  = FF7GV9("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FF5Q6H("File Attributes:", VVkwvG), txt)
  return txt
 def VV3gCA(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFAQH0(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFAQH0(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFAQH0(os.path.getctime(path))
  return txt
 def VV0C6T(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FF7GV9("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FF7GV9("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FF7GV9("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVWHJa(self, size):
  power = 1024.0
  n = 0
  power_labels = {0 : 'B', 1: 'kB', 2: 'MB', 3: 'GB', 4: 'TB'}
  while size > power:
   size /= power
   n += 1
  size = "%.1f" % size
  if size.endswith(".0"):
   size = size[:-2]
  return "%s %s" % (size, power_labels[n])
 def VV4sGG(self, currentSel):
  currentDir  = self["myMenu"].VVxnci()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVcJQh():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVw3bl(self):
  return self["myMenu"].getSelection()[0]
 def VV3PFz(self):
  FFdxmx(self)
  path = self.VV4sGG(self.VVw3bl())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VVPIPy = self.VVYz3S()
  if VVPIPy and len(VVPIPy) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VV8fCy(path)
  if self.mode == self.VVCSbg and len(path) > 0:
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
  else:
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
 def VV8fCy(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VV58Qm(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVj2Dj(self):
  if self.mode == self.VVCSbg:
   path  = self.VV4sGG(self.VVw3bl())
   isDir  = os.path.isdir(path)
   VVRJT5 = []
   VVRJT5.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVN6xq(path):
     sepShown = True
     VVRJT5.append(VVn6Em)
     VVRJT5.append( (VVUqrB + "Archiving / Packaging"      , "VV4vz4"  ))
    if self.VVtPLN(path):
     if not sepShown:
      VVRJT5.append(VVn6Em)
     VVRJT5.append( (VVUqrB + "Read Backup information"     , "VV0nHy"  ))
     VVRJT5.append( (VVUqrB + "Compress Octagon Image (to zip File)"  , "VV1ufL" ))
   elif os.path.isfile(path):
    selFile = self.VVw3bl()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip"))   : VVRJT5.extend(self.VV4hVV(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVRJT5.extend(self.VVFcwq(True))
    elif selFile.endswith(".m3u")              : VVRJT5.extend(self.VVlIZE(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FFT5aP(path):
     VVRJT5.append(VVn6Em)
     VVRJT5.append((VVUqrB + "View" , "text_View" ))
     VVRJT5.append((VVUqrB + "Edit" , "text_Edit" ))
    if len(txt) > 0:
     VVRJT5.append(VVn6Em)
     VVRJT5.append(   (VVUqrB + txt      , "VVJJm5"  ))
   VVRJT5.append(VVn6Em)
   VVRJT5.append(     ("Create SymLink"       , "VVwTkd" ))
   if not self.VVN6xq(path):
    VVRJT5.append(   ("Rename"          , "VV4jvD" ))
    VVRJT5.append(   ("Copy"           , "copyFileOrDir" ))
    VVRJT5.append(   ("Move"           , "moveFileOrDir" ))
    VVRJT5.append(   ("DELETE"          , "VVK2Qf" ))
    if fileExists(path):
     VVRJT5.append(VVn6Em)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVRJT5.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVRJT5.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVRJT5.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVRJT5.append(VVn6Em)
   VVRJT5.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVRJT5.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   VVRJT5.append(VVn6Em)
   VVRJT5.append(    ("Set current directory as \"Startup Path\"" , "VVu5tr" ))
   FF4JCK(self, self.VVyg0s, title="Options", VVRJT5=VVRJT5)
 def VVyg0s(self, item=None):
  if self.mode == self.VVCSbg:
   if item is not None:
    path = self.VV4sGG(self.VVw3bl())
    selFile = self.VVw3bl()
    if   item == "properties"    : self.VVYxK6()
    elif item == "VV4vz4"  : self.VV4vz4(path)
    elif item == "VV0nHy"  : self.VV0nHy(path)
    elif item == "VV1ufL" : self.VV1ufL(path)
    elif item.startswith("extract_")  : self.VVuPyc(path, selFile, item)
    elif item.startswith("script_")   : self.VVlsTB(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVXNpTItem_m3u(path, selFile, item)
    elif item.startswith("text_View")  : FFOlvf(self, path)
    elif item.startswith("text_Edit")  : CCqxmc(self, path)
    elif item == "chmod644"     : self.VV4A3d(path, selFile, "644")
    elif item == "chmod755"     : self.VV4A3d(path, selFile, "755")
    elif item == "chmod777"     : self.VV4A3d(path, selFile, "777")
    elif item == "VVwTkd"   : self.VVwTkd(path, selFile)
    elif item == "VV4jvD"   : self.VV4jvD(path, selFile)
    elif item == "copyFileOrDir"   : self.VVl9bP(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVl9bP(path, selFile, True)
    elif item == "VVK2Qf"   : self.VVK2Qf(path, selFile)
    elif item == "createNewFile"   : self.VVQ7u4(path, True)
    elif item == "createNewDir"    : self.VVQ7u4(path, False)
    elif item == "VVu5tr"   : self.VVu5tr(path)
    elif item == "VVJJm5"    : self.VVJJm5()
    else         : self.close()
 def VVJJm5(self):
  selFile = self.VVw3bl()
  path  = self.VV4sGG(selFile)
  if os.path.isfile(path):
   VVhenW = []
   category = self["myMenu"].VV14GI(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVGGY3(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FFaysk(self, selFile, path)
   elif category == "txt"         : FFOlvf(self, path)
   elif category in ("tar", "zip")       : self.VVCc1K(path, selFile)
   elif category == "scr"         : self.VVToWk(path, selFile)
   elif category == "m3u"         : self.VVckx7(path, selFile)
   elif category in ("ipk", "deb")       : self.VVEsn7(path, selFile)
   elif category == "mus"         : self.VVJlNq(path)
   elif category == "mov"         : self.VVJlNq(path)
   elif not FFT5aP(path)        : FFOlvf(self, path)
 def VVJlNq(self, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   FFKIZZ(self, refCode)
  except:
   pass
 def VVpnvU(self):
  path = self.VV4sGG(self.VVw3bl())
  action = self.VV8fCy(path)
  if action == 1:
   self.VVscqm(path)
   FFdxmx(self, "Added", 500)
  elif action == -1:
   self.VVdQjW(path)
   FFdxmx(self, "Removed", 500)
  self.VV8fCy(path)
 def VVscqm(self, path):
  VVPIPy = self.VVYz3S()
  if not VVPIPy:
   VVPIPy = []
  if len(VVPIPy) >= self.VVYSuD:
   FF2nrW(SELF, "Max bookmarks reached (max=%d)." % self.VVYSuD)
  elif not path in VVPIPy:
   VVPIPy = [path] + VVPIPy
   self.VVO3gj(VVPIPy)
 def VVwFPA(self):
  VVPIPy = self.VVYz3S()
  if VVPIPy:
   newList = []
   for line in VVPIPy:
    newList.append((line, line))
   VVrFC4  = ("Delete"  , self.VVtNcb )
   VVZZ8a = ("Move Up"   , self.VVtTyU )
   VVuTHu  = ("Move Down" , self.VVdc2N )
   self.bookmarkMenu = FF4JCK(self, self.VV1960, title="Bookmarks", VVRJT5=newList, VVrFC4=VVrFC4, VVZZ8a=VVZZ8a, VVuTHu=VVuTHu)
 def VVtNcb(self, VVw3blObj, path):
  if self.bookmarkMenu:
   VVPIPy = self.VVdQjW(path)
   self.bookmarkMenu.VVuYJG(VVPIPy)
 def VVtTyU(self, VVw3blObj, path):
  if self.bookmarkMenu:
   VVPIPy = self.bookmarkMenu.VVn4DY(True)
   if VVPIPy:
    self.VVO3gj(VVPIPy)
 def VVdc2N(self, VVw3blObj, path):
  if self.bookmarkMenu:
   VVPIPy = self.bookmarkMenu.VVn4DY(False)
   if VVPIPy:
    self.VVO3gj(VVPIPy)
 def VV1960(self, folder=None):
  if folder:
   if not folder.endswith("/"):
    folder += "/"
   self["myMenu"].VVUps6(folder)
   self["myMenu"].moveToIndex(0)
  self.VV3PFz()
 def VVYz3S(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VV58Qm(self, path):
  VVPIPy = self.VVYz3S()
  if VVPIPy and path in VVPIPy:
   return True
  else:
   return False
 def VVR1ZF(self):
  if VVYz3S():
   return True
  else:
   return False
 def VVO3gj(self, VVPIPy):
  line = ",".join(VVPIPy)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVdQjW(self, path):
  VVPIPy = self.VVYz3S()
  if VVPIPy:
   while path in VVPIPy:
    VVPIPy.remove(path)
   self.VVO3gj(VVPIPy)
   return VVPIPy
 def VVu5tr(self, path):
  if not os.path.isdir(path):
   path = FFkUaP(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVGGY3(self, selFile, VV2i71, command):
  FFjphE(self, boundFunction(FFjY30, self, command, VVFQVU=self.VV6ZOq), "%s\n\n%s" % (VV2i71, selFile))
 def VV4hVV(self, path, calledFromMenu):
  destPath = self.VVaZ9h(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVRJT5 = []
  if calledFromMenu:
   VVRJT5.append(VVn6Em)
   color = VVUqrB
  else:
   color = ""
  VVRJT5.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVRJT5.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVRJT5.append((color + "Extract Here"            , "extract_here"  ))
  if VVD4Tf and path.endswith(".tar.gz"):
   VVRJT5.append(VVn6Em)
   VVRJT5.append((color + 'Convert to ".ipk" Package' , "VVI3Mj"  ))
   VVRJT5.append((color + 'Convert to ".deb" Package' , "VVyI0Q"  ))
  return VVRJT5
 def VVCc1K(self, path, selFile):
  FF4JCK(self, boundFunction(self.VVuPyc, path, selFile), title="Tar File Options", VVRJT5=self.VV4hVV(path, False))
 def VVuPyc(self, path, selFile, item=None):
  if item is not None:
   parent  = FFkUaP(path, False)
   destPath = self.VVaZ9h(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VV06tg
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += "echo '';"
     cmd += "unzip -l '%s';" % path
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VV06tg, VV06tg)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFMX6s(self, cmd)
   elif path.endswith(".zip"):
    self.VVtdoM(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FF3WD3("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVGGY3(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVGGY3(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFkUaP(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVGGY3(selFile, "Extract Here ?"      , cmd)
   elif item == "VVI3Mj" : self.VVI3Mj(path)
   elif item == "VVyI0Q" : self.VVyI0Q(path)
 def VVaZ9h(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVtdoM(self, item, path, parent, destPath, VV2i71):
  FFjphE(self, boundFunction(self.VVz9ej, item, path, parent, destPath), VV2i71)
 def VVz9ej(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VV06tg
  cmd  = FFUpCM("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFyIHF(destPath, VV0Tnk))
  cmd +=   sep
  cmd += "fi;"
  FF6xaZ(self, cmd, VVFQVU=self.VV6ZOq)
 def VVFcwq(self, addSep=False):
  VVRJT5 = []
  if addSep:
   VVRJT5.append(VVn6Em)
  VVRJT5.append((VVUqrB + "View Script File"  , "script_View"  ))
  VVRJT5.append((VVUqrB + "Execute Script File" , "script_Execute" ))
  VVRJT5.append((VVUqrB + "Edit"     , "script_Edit" ))
  return VVRJT5
 def VVToWk(self, path, selFile):
  FF4JCK(self, boundFunction(self.VVlsTB, path, selFile), title="Script File Options", VVRJT5=self.VVFcwq())
 def VVlsTB(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFOlvf(self, path)
   elif item == "script_Execute" : self.VVGGY3(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCqxmc(self, path)
 def VVlIZE(self, addSep=False):
  VVRJT5 = []
  if addSep:
   VVRJT5.append(VVn6Em)
  VVRJT5.append((VVUqrB + "View"      , "m3u_View" ))
  VVRJT5.append((VVUqrB + "Edit"      , "m3u_Edit" ))
  VVRJT5.append((VVUqrB + "Convert to IPTV Bouquet" , "m3u_Convert" ))
  return VVRJT5
 def VVckx7(self, path, selFile):
  FF4JCK(self, boundFunction(self.VVXNpTItem_m3u, path, selFile), title="M3U File Options", VVRJT5=self.VVlIZE())
 def VVXNpTItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_View"  : FFOlvf(self, path)
   elif item == "m3u_Edit"  : CCqxmc(self, path)
   elif item == "m3u_Convert" : CCqLir.VVlamL(self, path, False)
 def VV4A3d(self, path, selFile, newChmod):
  FFjphE(self, boundFunction(self.VVFTDz, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVFTDz(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVm2pM)
  result = FF7GV9(cmd)
  if result == "Successful" : FFrerH(self, result)
  else      : FF2nrW(self, result)
 def VVwTkd(self, path, selFile):
  parent = FFkUaP(path, False)
  self.session.openWithCallback(self.VV8jBO, boundFunction(CCNIug, mode=CCNIug.VVSQ2B, VVBEkA=parent, VVmkIG="Create Symlink here"))
 def VV8jBO(self, newPath):
  if len(newPath) > 0:
   target = self.VV4sGG(self.VVw3bl())
   target = FFDv1k(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFq2Op(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FF2nrW(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFjphE(self, boundFunction(self.VVtepv, target, link), "Create Soft Link ?\n\n%s" % txt, VVzwqf=True)
 def VVtepv(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVm2pM)
  result = FF7GV9(cmd)
  if result == "Successful" : FFrerH(self, result)
  else      : FF2nrW(self, result)
 def VV4jvD(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFzere(self, boundFunction(self.VVuXW1, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVuXW1(self, path, selFile, VVckRP):
  if VVckRP:
   parent = FFkUaP(path, True)
   if os.path.isdir(path):
    path = FFDv1k(path)
   newName = parent + VVckRP
   cmd = "mv '%s' '%s' %s" % (path, newName, VVm2pM)
   if VVckRP:
    if selFile != VVckRP:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFjphE(self, boundFunction(self.VVcIk1, cmd), message, title="Rename file?")
    else:
     FF2nrW(self, "Cannot use same name!", title="Rename")
 def VVcIk1(self, cmd):
  result = FF7GV9(cmd)
  if "Fail" in result:
   FF2nrW(self, result)
  self.VV6ZOq()
 def VVl9bP(self, path, selFile, isMove):
  if isMove : VVmkIG = "Move to here"
  else  : VVmkIG = "Copy to here"
  parent = FFkUaP(path, False)
  self.session.openWithCallback(boundFunction(self.VVEiSJ, isMove, path, selFile)
         , boundFunction(CCNIug, mode=CCNIug.VVSQ2B, VVBEkA=parent, VVmkIG=VVmkIG))
 def VVEiSJ(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFDv1k(path)
   newPath = FFq2Op(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFjphE(self, boundFunction(FFEkLg, self, cmd, VVFQVU=self.VV6ZOq), txt, VVzwqf=True)
   else:
    FF2nrW(self, "Cannot %s to same directory !" % action.lower())
 def VVK2Qf(self, path, fileName):
  path = FFDv1k(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFjphE(self, boundFunction(self.VVYMV6, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVYMV6(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VV6ZOq()
 def VVN6xq(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VV3ToJ and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVQ7u4(self, path, isFile):
  dirName = FFq2Op(os.path.dirname(path))
  if isFile : objName, VVckRP = "File"  , self.edited_newFile
  else  : objName, VVckRP = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFzere(self, boundFunction(self.VVo41V, dirName, isFile, title), title=title, defaultText=VVckRP, message="Enter %s Name:" % objName)
 def VVo41V(self, dirName, isFile, title, VVckRP):
  if VVckRP:
   if isFile : self.edited_newFile = VVckRP
   else  : self.edited_newDir  = VVckRP
   path = dirName + VVckRP
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVm2pM)
    else  : cmd = "mkdir '%s' %s" % (path, VVm2pM)
    result = FF7GV9(cmd)
    if "Fail" in result:
     FF2nrW(self, result)
    self.VV6ZOq()
   else:
    FF2nrW(self, "Name already exists !\n\n%s" % path, title)
 def VVEsn7(self, path, selFile):
  VVRJT5 = []
  VVRJT5.append(("List Package Files"          , "VV0PfL"     ))
  VVRJT5.append(("Package Information"          , "VV8Qpk"     ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Install Package"           , "VVVjoV_CheckVersion" ))
  VVRJT5.append(("Install Package (force reinstall)"      , "VVVjoV_ForceReinstall" ))
  VVRJT5.append(("Install Package (force downgrade)"      , "VVVjoV_ForceDowngrade" ))
  VVRJT5.append(("Install Package (ignore failed dependencies)"    , "VVVjoV_IgnoreDepends" ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Remove Related Package"         , "VViRl1_ExistingPackage" ))
  VVRJT5.append(("Remove Related Package (force remove)"     , "VViRl1_ForceRemove"  ))
  VVRJT5.append(("Remove Related Package (ignore failed dependencies)"  , "VViRl1_IgnoreDepends" ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("Extract Files"           , "VVDse8"     ))
  VVRJT5.append(("Unbuild Package"           , "VVekUv"     ))
  FF4JCK(self, boundFunction(self.VVBoCb, path, selFile), VVRJT5=VVRJT5)
 def VVBoCb(self, path, selFile, item=None):
  if item is not None:
   if   item == "VV0PfL"      : self.VV0PfL(path, selFile)
   elif item == "VV8Qpk"      : self.VV8Qpk(path)
   elif item == "VVVjoV_CheckVersion"  : self.VVVjoV(path, selFile, VVJjEM     )
   elif item == "VVVjoV_ForceReinstall" : self.VVVjoV(path, selFile, VVNhZF )
   elif item == "VVVjoV_ForceDowngrade" : self.VVVjoV(path, selFile, VVMKBv )
   elif item == "VVVjoV_IgnoreDepends" : self.VVVjoV(path, selFile, VVOyEf )
   elif item == "VViRl1_ExistingPackage" : self.VViRl1(path, selFile, VVRIKQ     )
   elif item == "VViRl1_ForceRemove"  : self.VViRl1(path, selFile, VVvmPf  )
   elif item == "VViRl1_IgnoreDepends"  : self.VViRl1(path, selFile, VVVLRI )
   elif item == "VVDse8"     : self.VVDse8(path, selFile)
   elif item == "VVekUv"     : self.VVekUv(path, selFile)
   else           : self.close()
 def VV0PfL(self, path, selFile):
  if FFJyiB("ar") : cmd = "allOK='1';"
  else    : cmd  = FFYsPW()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VV06tg, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VV06tg, VV06tg)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFAkgz(self, cmd, VVFQVU=self.VV6ZOq)
 def VVDse8(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFkUaP(path, True) + selFile[:-4]
  cmd  =  FFYsPW()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FF3WD3("mkdir '%s'" % dest) + ";"
  cmd +=    FF3WD3("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFyIHF(dest, VV0Tnk))
  cmd += "fi;"
  FFjY30(self, cmd, VVFQVU=self.VV6ZOq)
 def VVekUv(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVVLrl = os.path.splitext(path)[0]
  else        : VVVLrl = path + "_"
  if path.endswith(".deb")   : VV1x3O = "DEBIAN"
  else        : VV1x3O = "CONTROL"
  cmd  = FFYsPW()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVVLrl, FF0Ztc())
  cmd += "  mkdir '%s';"    % VVVLrl
  cmd += "  CONTPATH='%s/%s';"  % (VVVLrl, VV1x3O)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVVLrl
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVVLrl, VVVLrl)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVVLrl
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVVLrl, VVVLrl)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVVLrl
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVVLrl
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVVLrl, FFyIHF(VVVLrl, VV0Tnk))
  cmd += "fi;"
  FFjY30(self, cmd, VVFQVU=self.VV6ZOq)
 def VV8Qpk(self, path):
  listCmd  = FFbwyV(VVuLSB, "")
  infoCmd  = FF1oa1(VVU6ij , "")
  filesCmd = FF1oa1(VVIUZY, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFWBhT(VVvgWJ)
   notInst = "Package not installed."
   cmd  = FFp6br("File Info", VVvgWJ)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFp6br("System Info", VVvgWJ)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFyIHF(notInst, VVUqrB))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFp6br("Related Files", VVvgWJ)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFMX6s(self, cmd)
  else:
   FFJSkq(self)
 def VVVjoV(self, path, selFile, cmdOpt):
  cmd = FF1oa1(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFjphE(self, boundFunction(FFjY30, self, cmd, VVFQVU=FF80hJ), "Install Package ?\n\n%s" % selFile)
  else:
   FFJSkq(self)
 def VViRl1(self, path, selFile, cmdOpt):
  listCmd  = FFbwyV(VVuLSB, "")
  infoCmd  = FF1oa1(VVU6ij, "")
  instRemCmd = FF1oa1(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFyIHF(errTxt, VVUqrB))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFyIHF(cannotTxt, VVUqrB))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFyIHF(tryTxt, VVUqrB))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFjphE(self, boundFunction(FFjY30, self, cmd, VVFQVU=FF80hJ), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFJSkq(self)
 def VVWUGt(self, path):
  hostName = FF7GV9("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVtPLN(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVWUGt(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VV4vz4(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVRJT5 = []
  VVRJT5.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVRJT5.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVRJT5.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVRJT5.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVRJT5.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVRJT5.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVRJT5.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVRJT5.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVRJT5.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVRJT5.append(VVn6Em)
  VVRJT5.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVRJT5.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FF4JCK(self, boundFunction(self.VV4U6X, path), VVRJT5=VVRJT5)
 def VV4U6X(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVimRg(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVimRg(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVimRg(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVimRg(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVimRg(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVimRg(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVimRg(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVimRg(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVimRg(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVimRg(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VV13pr(path, False)
   elif item == "convertDirToDeb"   : self.VV13pr(path, True)
   else         : self.close()
 def VV13pr(self, path, VVCSkY):
  self.session.openWithCallback(self.VV6ZOq, boundFunction(CCFLqD, path=path, VVCSkY=VVCSkY))
 def VVimRg(self, path, fileExt, preserveDirStruct):
  parent  = FFkUaP(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFUpCM("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFUpCM("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFUpCM("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VV06tg
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FF3WD3("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FFyIHF(resultFile, VV0Tnk))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FFyIHF(failed, VVDbaf))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFAkgz(self, cmd, VVFQVU=self.VV6ZOq)
 def VV0nHy(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFOlvf(self, versionFile)
 def VV1ufL(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVWUGt(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FF2nrW(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFxmgd(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFkUaP(path, False)
  VVVLrl = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FFyIHF(errCmd, VVDbaf))
  installCmd = FF1oa1(VVJjEM , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VVVLrl, VVVLrl)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VVVLrl
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VVVLrl
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VVVLrl, VVVLrl)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFjY30(self, cmd, VVFQVU=self.VV6ZOq)
 def VVI3Mj(self, path):
  FF2nrW(self, "Under Construction.")
 def VVyI0Q(self, path):
  FF2nrW(self, "Under Construction.")
class CCwp2U(MenuList):
 def __init__(self, VVhuuh=False, directory="/", VVD6op=True, VVFw8R=True, VVT2OO=True, VVUZL1=None, VV9xBW=False, VVGpU7=False, VVBxxb=False, isTop=False, VVBe0e=None, VVvvA9=1000, VVdfkW=30, VVYdZK=30, VVmWrz="#00000000"):
  MenuList.__init__(self, list, VVhuuh, eListboxPythonMultiContent)
  self.VVD6op  = VVD6op
  self.VVFw8R    = VVFw8R
  self.VVT2OO  = VVT2OO
  self.VVUZL1  = VVUZL1
  self.VV9xBW   = VV9xBW
  self.VVGpU7   = VVGpU7 or []
  self.VVBxxb   = VVBxxb or []
  self.isTop     = isTop
  self.additional_extensions = VVBe0e
  self.VVvvA9    = VVvvA9
  self.VVdfkW    = VVdfkW
  self.VVYdZK    = VVYdZK
  self.pngBGColor    = FFXNey(VVmWrz)
  self.EXTENSIONS    = self.VVr0fX()
  self.VVNGnm   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VV20Ap, self.VVdfkW))
  self.l.setItemHeight(self.VVYdZK)
  self.png_mem   = self.VVnnNS("mem")
  self.png_usb   = self.VVnnNS("usb")
  self.png_fil   = self.VVnnNS("fil")
  self.png_dir   = self.VVnnNS("dir")
  self.png_dirup   = self.VVnnNS("dirup")
  self.png_srv   = self.VVnnNS("srv")
  self.png_slwfil   = self.VVnnNS("slwfil")
  self.png_slbfil   = self.VVnnNS("slbfil")
  self.png_slwdir   = self.VVnnNS("slwdir")
  self.VVEBpw()
  self.VVUps6(directory)
 def VVnnNS(self, category):
  return LoadPixmap("%s%s.png" % (VVoMgi, category), getDesktop(0))
 def VVr0fX(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u"
  }
 def VV1RSI(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFDv1k(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FF5Q6H(" -> " , VVvgWJ) + FF5Q6H(os.readlink(path), VV0Tnk)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVYdZK + 10, 0, self.VVvvA9, self.VVYdZK, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVPBo9: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVYdZK-4, self.VVYdZK-4, png, self.pngBGColor, self.pngBGColor, VVPBo9))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVYdZK-4, self.VVYdZK-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VV14GI(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVEBpw(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVY9eW(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVPRHk(self, file):
  if os.path.realpath(file) == file:
   return self.VVY9eW(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVY9eW(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVY9eW(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VV7z9G(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVNGnm.info(l[0][0]).getEvent(l[0][0])
 def VVZyy6(self):
  return self.list
 def VVhKUo(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVUps6(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVT2OO:
    self.current_mountpoint = self.VVPRHk(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVT2OO:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVBxxb and not self.VVhKUo(path, self.VVGpU7):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VV1RSI(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VV9xBW:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVNGnm = eServiceCenter.getInstance()
   list = VVNGnm.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVD6op and not self.isTop:
   if directory == self.current_mountpoint and self.VVT2OO:
    self.list.append(self.VV1RSI(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVBxxb and self.VVY9eW(directory) in self.VVBxxb):
    self.list.append(self.VV1RSI(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVD6op:
   for x in directories:
    if not (self.VVBxxb and self.VVY9eW(x) in self.VVBxxb) and not self.VVhKUo(x, self.VVGpU7):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VV1RSI(name = name, absolute = x, isDir = True, png = png))
  if self.VVFw8R:
   for x in files:
    if self.VV9xBW:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FF5Q6H(" -> " , VVvgWJ) + FF5Q6H(target, VV0Tnk)
       else:
        png = self.png_slbfil
        name += FF5Q6H(" -> " , VVvgWJ) + FF5Q6H(target, VVDbaf)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VV14GI(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVoMgi, category))
    if (self.VVUZL1 is None) or iCompile(self.VVUZL1).search(path):
     self.list.append(self.VV1RSI(name = name, absolute = x , isDir = False, png = png))
  if self.VVT2OO and len(self.list) == 0:
   self.list.append(self.VV1RSI(name = FF5Q6H("No USB connected", VViEcp), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVxnci(self):
  return self.current_directory
 def VVcJQh(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVUps6(self.getSelection()[0], select = self.current_directory)
 def VVkSrE(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVDL26(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VV7qDK)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VV7qDK)
 def refresh(self):
  self.VVUps6(self.current_directory, self.VVkSrE())
 def VV7qDK(self, action, device):
  self.VVEBpw()
  if self.current_directory is None:
   self.refresh()
class CC5fl3(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FFXEzn(VV6Hg0, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVPIPy   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVAu22(defFG, "#00FFFFFF")
  self.defBG   = self.VVAu22(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFnDik(self, self.Title)
  self["keyRed"].show()
  FFKY2X(self["keyGreen"] , "< > Transp.")
  FFKY2X(self["keyYellow"], "Foreground")
  FFKY2X(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVmYyT        ,
   "yellow"   : boundFunction(self.VVacbU, False)  ,
   "blue"   : boundFunction(self.VVacbU, True)  ,
   "up"   : self.VVm2yv          ,
   "down"   : self.VVjuLJ         ,
   "left"   : self.VVcHvU         ,
   "right"   : self.VVltG8         ,
   "last"   : boundFunction(self.VVhkek, -5) ,
   "next"   : boundFunction(self.VVhkek, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVciax)
 def VVciax(self):
  self.onShown.remove(self.VVciax)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFfaVA(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFfaVA(self["keyRed"] , c)
  FFfaVA(self["keyGreen"] , c)
  self.VVM51E()
  self.VVwu7p()
  FF0Lke(self["myColorTst"], self.defFG)
  FFfaVA(self["myColorTst"], self.defBG)
 def VVAu22(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVwu7p(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVku0r(0, 0)
     return
 def VVmYyT(self):
  self.close(self.defFG, self.defBG)
 def VVm2yv(self): self.VVku0r(-1, 0)
 def VVjuLJ(self): self.VVku0r(1, 0)
 def VVcHvU(self): self.VVku0r(0, -1)
 def VVltG8(self): self.VVku0r(0, 1)
 def VVku0r(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVZb2t()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVRW1u()
 def VVM51E(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVRW1u(self):
  color = self.VVZb2t()
  if self.isBgMode: FFfaVA(self["myColorTst"], color)
  else   : FF0Lke(self["myColorTst"], color)
 def VVacbU(self, isBg):
  self.isBgMode = isBg
  self.VVM51E()
  self.VVwu7p()
 def VVhkek(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVku0r(0, 0)
 def VVyWOk(self):
  return hex(self.transp)[2:].zfill(2)
 def VVZb2t(self):
  return ("#%s%s" % (self.VVyWOk(), self.colors[self.curRow][self.curCol])).upper()
class CC2t1H(ScrollLabel):
 def __init__(self, parentSELF, text="", VV2Q1B=True):
  ScrollLabel.__init__(self, text)
  self.VV2Q1B=VV2Q1B
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVGsVO  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVdfkW    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close   ,
   "cancel"  : parentSELF.close   ,
   "red"   : self.VVZJJd   ,
   "green"   : self.VVhVTr  ,
   "yellow"  : self.VVyk4w  ,
   "blue"   : self.VVGl0X  ,
   "up"   : self.pageUp    ,
   "down"   : self.pageDown    ,
   "left"   : self.pageUp    ,
   "right"   : self.pageDown    ,
   "pageUp"  : self.VVqhkB    ,
   "chanUp"  : self.VVqhkB    ,
   "pageDown"  : self.VV6Tvt    ,
   "chanDown"  : self.VV6Tvt
  }, -1)
 def VVOdRf(self, isResizable=True, VVVEcz=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FFiD9O(self.parentSELF, True)
  self.isResizable = isResizable
  if VVVEcz:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVdfkW  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFfaVA(self, color)
 def FFfaVAColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVGsVO - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVEgIm()
 def pageUp(self):
  if self.VVGsVO > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVGsVO > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVqhkB(self):
  self.setPos(0)
 def VV6Tvt(self):
  self.setPos(self.VVGsVO-self.pageHeight)
 def VVxbEW(self):
  return self.VVGsVO <= self.pageHeight or self.curPos == self.VVGsVO - self.pageHeight
 def VVEgIm(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVGsVO, 3))
   start = int((100 - vis) * self.curPos / (self.VVGsVO - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVGjos=VVrOxe):
  old_VVxbEW = self.VVxbEW()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VVGsVO = self.long_text.calculateSize().height()
   if self.VV2Q1B and self.VVGsVO > self.pageHeight:
    self.scrollbar.show()
    self.VVEgIm()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVGsVO))
   if   VVGjos == VVmSww: self.setPos(0)
   elif VVGjos == VVxUhY : self.VV6Tvt()
   elif old_VVxbEW    : self.VV6Tvt()
 def appendText(self, text, VVGjos=VVxUhY):
  self.setText(self.message + str(text), VVGjos)
 def VVyk4w(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVahpV(size)
 def VVGl0X(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVahpV(size)
 def VVhVTr(self):
  self.VVahpV(self.VVdfkW)
 def VVahpV(self, VVdfkW):
  self.long_text.setFont(gFont(self.fontFamily, VVdfkW))
  self.setText(self.message, VVGjos=VVrOxe)
  self.VVR1jP(calledFromFontSizer=True)
 def VVZJJd(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FFq2Op(expPath), self.textOutFile, FF8AiB())
    with open(outF, "w") as f:
     f.write(FF2A5P(self.message))
    FFrerH(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FF2nrW(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVR1jP(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVGsVO > 0 and self.pageHeight > 0:
   if self.VVGsVO < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVGsVO
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
