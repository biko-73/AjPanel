import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVg2tB   = "v5.4.2"
VVKiwb    = "16-06-2022"
EASY_MODE    = 0
VVCy2B   = 0
VVzhgw   = 0
VVggHj  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVvV4V  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVNnjH    = "/media/usb/"
VVkKH6    = "/usr/share/enigma2/picon/"
VVWVDT = "/etc/enigma2/blacklist"
VVf9y4   = "/etc/enigma2/"
VVez4Y  = "ajpanel_update_url"
VVhBuB   = "AJPan"
VVRVLV    = "AUTO FIND"
VVsWst    = ""
VVmpyI    = "Regular"
VV9gSb      = "-" * 80
VVZYy7    = ("-" * 100, )
VVWK7p    = ""
VV5iXK   = " && echo 'Successful' || echo 'Failed!'"
VV4grE    = []
VVnT2K  = "Cannot continue (No Enough Memory) !"
VVs8GF  = False
VVIUAA  = False
VV2GoD = False
VVycF3     = 0
VVyKke    = 1
VVnpW4    = 2
VVX2yX   = 3
VVxTu6    = 4
VVTS1Q    = 5
VVMlUC = 6
VVLiFQ = 7
VVSd7Q  = 8
VV67W3   = 9
VV6tuu   = 10
VVyKDR   = 11
VVokoY  = 12
VVGhHa  = 13
VV8osc    = 14
VVLjNu   = 15
VViW94   = 16
VVuBsi    = 17
WINDOW_SUBTITLE    = 18
VVkLOo  = 19
VV0Sy0   = 0
VVKyDE   = 1
VVRjSm   = 2
def FFZVCr():
 fList = None
 try:
  from enigma import getFontFaces
  return set(getFontFaces())
 except:
  try:
   from skin import getFontFaces
   return set(getFontFaces())
  except:
   pass
 return [VVmpyI]
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices=[ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.forceUtf8Encoding   = ConfigYesNo(default=True)
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsPath    = ConfigDirectory(default=VVRVLV, visible_width=51)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=51)
CFG.PIconsPath     = ConfigDirectory(default=VVkKH6, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVNnjH, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
tmp = [("srt", "From SRT File"), ("#FFFFFF", "White"), ("#C0C0C0", "Silver"), ("#808080", "Gray"), ("#000000", "Black"), ("#FF0000", "Red"), ("#800000", "Maroon"), ("#FFFF00", "Yellow"), ("#808000", "Olive"), ("#00FF00", "Lime"), ("#008000", "Green"), ("#00FFFF", "Aqua"), ("#008080", "Teal"), ("#0000FF", "Blue"), ("#000080", "Navy"), ("#FF00FF", "Fuchsia"), ("#800080", "Purple")]
CFG.subtDelay     = ConfigSelection(default="0.0", choices=[ (str(x/10.0),  str(x/10.0)) for x in range(-600, 600, 5) ])
CFG.subtTextFg     = ConfigSelection(default="srt", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVmpyI, choices=[ (x,  x) for x in FFZVCr() ])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=80, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[ ("0", "Left"), ("1", "Center"), ("2", "Right") ])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=0, stepwidth=10, min=-140, max=140, wraparound=False)
del tmp
def FFEVs5():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVVY9Y  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVML4l = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVVY9Y  : return 0
  elif VVML4l : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVmnwB = FFEVs5()
VVZERI = VV7bzw = VVahL2 = VVaqQK = VVeSCc = VV15r0 = VVeO4o = VVg4jx = COLOR_CONS_BRIGHT_YELLOW = VV3UWE = VVzeuF = VVIXzm = VV3rkc = ""
def FFXbZh()  : FFsb9f(FFsGJW())
def FFNqBn()  : FFsb9f(FF2its())
def FFSeMc(tDict): FFsb9f(iDumps(tDict, indent=4, sort_keys=True))
def FFcsGS(*args): FFMhy0(True, False, *args)
def FFsb9f(*args) : FFMhy0(True , True , *args)
def FFDQ6c(*args): FFMhy0(False, True , *args)
def FFMhy0(addSep=True, oneLine=True, *args):
 if VVCy2B:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if oneLine:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  else:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item:
      txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FF5Iml(txt, isAppend=True, ignoreErr=False):
 if VVCy2B:
  tm = FFt1xA()
  err = ""
  if not ignoreErr:
   err = FF2its()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFsb9f(err)
  FFsb9f("Output Log File : %s" % fileName)
def FF2its():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFt1xA()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except Exception as e:
  return "Cannot Trace !"
def FFsGJW():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VV4grE = []
def FFLm4N(win):
 global VV4grE
 if not win in VV4grE:
  VV4grE.append(win)
def FFpYsh(*args):
 global VV4grE
 for win in VV4grE:
  try:
   win.close()
  except:
   pass
 VV4grE = []
def FFjIK4():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VViXzU = FFjIK4()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFirih()     : return PluginDescriptor(fnc=FFJs4V, where=[PluginDescriptor.WHERE_SESSIONSTART] , needsRestart=True   , description="AJPanel Startup")
def FFk6Oi()      : return getDescriptor(FFXcEW   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFWfrO()       : return getDescriptor(FFZu7A  , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFpHEW()   : return getDescriptor(FFWpb8 , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFlhWw(): return getDescriptor(FFnINH , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player"  , descr="Signal Monitor / Player")
def FFy3cH()  : return getDescriptor(FF2oyh  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV"     , descr="IPTV Menu")
def FF4549()     : return getDescriptor(FFTGrw , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info."    , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFk6Oi() , FFWfrO() , FFirih() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFpHEW())
  result.append(FFlhWw())
  result.append(FFy3cH())
 if CFG.EventsInfoMenu.getValue():
  result.append(FF4549())
 return result
def FFJs4V(reason, **kwargs):
 if reason == 0:
  FFW2F4()
  if "session" in kwargs:
   session = kwargs["session"]
   FFNN4Q(session)
   CCdiPb(session)
  CCo0R4.VVaxbv()
def FFZu7A(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFXcEW, PLUGIN_NAME, 45)]
 else:
  return []
def FFXcEW(session, **kwargs):
 session.open(Main_Menu)
def FFWpb8(session, **kwargs):
 session.open(CCs7ea)
def FFnINH(session, **kwargs):
 FFbhRG(session, isFromSession=True)
def FF2oyh(session, **kwargs):
 session.open(CC4M3v)
def FFTGrw(session, **kwargs):
 session.open(CC6WQp, fncMode=CC6WQp.VVJ0jF)
def FFKhdh():
 FFUg8d(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFpHEW(), FFlhWw(), FFy3cH() ])
 FFUg8d(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FF4549() ])
def FFUg8d(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VVDKkK = None
def FFW2F4():
 try:
  global VVDKkK
  if VVDKkK is None:
   VVDKkK    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFzAsI
  ChannelContextMenu.FFUtHz = FFUtHz
 except:
  pass
def FFzAsI(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVDKkK(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFUtHz, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFUtHz, title1, csel, isFind=True))))
def FFUtHz(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFlcEP(refCode)
 except:
  pass
 self.session.open(boundFunction(CCqJfY, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFNN4Q(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FF3w8Y, session, "lok")
 hk.actions['longCancel'] = boundFunction(FF3w8Y, session, "lesc")
 hk.actions['longRed']  = boundFunction(FF3w8Y, session, "lred")
def FF3w8Y(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFbhRG(session, isFromSession=True)
def FFNPyH(SELF, title="", addLabel=False, addScrollLabel=False, VVlZjX=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFCSyQ()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCmUeJ(SELF)
 if VVlZjX:
  SELF["myMenu"] = MenuList(VVlZjX)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVEvnY        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFNteF(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FFd5Hf, SELF, "0") ,
  "1"    : boundFunction(FFd5Hf, SELF, "1") ,
  "2"    : boundFunction(FFd5Hf, SELF, "2") ,
  "3"    : boundFunction(FFd5Hf, SELF, "3") ,
  "4"    : boundFunction(FFd5Hf, SELF, "4") ,
  "5"    : boundFunction(FFd5Hf, SELF, "5") ,
  "6"    : boundFunction(FFd5Hf, SELF, "6") ,
  "7"    : boundFunction(FFd5Hf, SELF, "7") ,
  "8"    : boundFunction(FFd5Hf, SELF, "8") ,
  "9"    : boundFunction(FFd5Hf, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FF6l8h, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFd5Hf(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VV3rkc:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VV3rkc + SELF.keyPressed + VV7bzw)
    txt = VV7bzw + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFLk1N(SELF, txt)
def FF6l8h(SELF, tableObj, colNum):
 FFLk1N(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     SELF.VVSHbm(i)
     break
 except:
  pass
def FFr1Kw(SELF, setMenuAction=True):
 if setMenuAction:
  global VVWK7p
  VVWK7p = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFCSyQ():
 return ("  %s" % VVWK7p)
def FFkV23(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFnTaU(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FF0hYc(color):
 return parseColor(color).argb()
def FF3XWe(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFxTkM(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFvX01(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFFlx3(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VV3rkc)
 else:
  return ""
def FFP3Rx(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VV9gSb, word, VV9gSb, VV3rkc)
 else : return "echo -e '%s\n--- %s\n%s';" % (VV9gSb, word, VV9gSb)
def FF0hQa(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VV3rkc
def FFNyBL(color):
 if color: return "echo -e '%s' %s;" % (VV9gSb, FFFlx3(VV9gSb, VVg4jx))
 else : return "echo -e '%s';" % VV9gSb
def FFiu6i(title, color):
 title = "%s\n%s\n%s\n" % (VV9gSb, title, VV9gSb)
 return FF0hQa(title, color)
def FFhGNA(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFn0Kf(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FF3K6t(callBackFunction):
 tCons = CCL7H9()
 tCons.ePopen("echo", boundFunction(FFOomY, callBackFunction))
def FFOomY(callBackFunction, result, retval):
 callBackFunction()
def FF1SeM(SELF, fnc, title="Processing ...", clearMsg=True):
 FFLk1N(SELF, title)
 tCons = CCL7H9()
 tCons.ePopen("echo", boundFunction(FFBuJk, SELF, fnc, clearMsg))
def FFBuJk(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFLk1N(SELF)
def FFgabI(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVnT2K
  else       : return ""
def FFfDK7(cmd):
 txt = FFgabI(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFmclR(cmd):
 lines = FFfDK7(cmd)
 if lines: return lines[0]
 else : return ""
def FFHj1R(SELF, cmd):
 lines = FFfDK7(cmd)
 VVXJa5 = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVXJa5.append((key, val))
  elif line:
   VVXJa5.append((line, ""))
 if VVXJa5:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FF1Vl3(SELF, None, header=header, VVKQR8=VVXJa5, VVrZ8Z=widths, VVbh3O=28)
 else:
  FFovqt(SELF, cmd)
def FFovqt(    SELF, cmd, **kwargs): SELF.session.open(CCr5s8, VVYqjI=cmd, VV9cjl=True, VVuKKh=VVKyDE, **kwargs)
def FFmNHK(  SELF, cmd, **kwargs): SELF.session.open(CCr5s8, VVYqjI=cmd, **kwargs)
def FFWNH3(   SELF, cmd, **kwargs): SELF.session.open(CCr5s8, VVYqjI=cmd, VVZPUB=True, VVzsLb=True, VVuKKh=VVKyDE, **kwargs)
def FFx5U2(  SELF, cmd, **kwargs): SELF.session.open(CCr5s8, VVYqjI=cmd, VVZPUB=True, VVzsLb=True, VVuKKh=VVRjSm, **kwargs)
def FFLwr1(  SELF, cmd, **kwargs): SELF.session.open(CCr5s8, VVYqjI=cmd, VV7wIQ=True , **kwargs)
def FFTonU( SELF, cmd, **kwargs): SELF.session.open(CCr5s8, VVYqjI=cmd, VVvjub=True   , **kwargs)
def FFWZYT( SELF, cmd, **kwargs): SELF.session.open(CCr5s8, VVYqjI=cmd, VV8QD9=True  , **kwargs)
def FFA9Vj(cmd):
 return cmd + " > /dev/null 2>&1"
def FF006U():
 return " > /dev/null 2>&1"
def FFqVus(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFVC1u(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFfVBP():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFmclR(cmd)
VV6NZu     = 0
VVboDa      = 1
VVKJja   = 2
VV7MAA      = 3
VVJjw0      = 4
VVzK8Y     = 5
VV3kNP     = 6
VVFpOM = 7
VVDZdr = 8
VVsUnv = 9
VVGLms  = 10
VV6CjH     = 11
VV1bXh  = 12
VVgRfs  = 13
def FFWjY7(parmNum, grepTxt):
 if   parmNum == VV6NZu  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVboDa   : param = ["list"   , "apt list" ]
 elif parmNum == VVKJja: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFfVBP()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFlY7a(parmNum, package):
 if   parmNum == VV7MAA      : param = ["info"      , "apt show"         ]
 elif parmNum == VVJjw0      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVzK8Y     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VV3kNP     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVFpOM : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVDZdr : param = ["install --force-overwrite" , "dpkg -i --force-overwrite -y"    ]
 elif parmNum == VVsUnv : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVGLms  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VV6CjH     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VV1bXh  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVgRfs  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFfVBP()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FF7ojp():
 result = FFmclR("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFlY7a(VV3kNP , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFA9Vj("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFA9Vj("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFFlx3(failed1, VVg4jx))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFFlx3(failed2, VVg4jx))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFFlx3(failed3, VVahL2))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFXdt2(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFlY7a(VV3kNP , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFA9Vj("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFFlx3(failed1, VVg4jx))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFFlx3(failed2, VVahL2))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFLgxI(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFA9Vj('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFA9Vj("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFeIec(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCo0R4.VVnNCk()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFW1ru(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFeIec(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFhuLL(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFRl9s(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFeIec(path, maxSize=maxSize, encLst=encLst)
  if lines: FFn7o1(SELF, lines, title=title, VVuKKh=VVKyDE)
  else : FF2vkZ(SELF, path, title=title)
 else:
  FFGmd5(SELF, path, title)
def FFepKH(SELF, path, title):
 if fileExists(path):
  txt = FFeIec(path)
  txt = txt.replace("#W#", VV3rkc)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VV7bzw)
  txt = txt.replace("#C#", VV3UWE)
  txt = txt.replace("#P#", VVaqQK)
  FFn7o1(SELF, txt, title=title)
 else:
  FFGmd5(SELF, path, title)
def FFfE1j(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FFtS24(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FF5bbC(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFRZql(parent)
 else    : return FFClhq(parent)
def FFRl9s(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFRZql(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFClhq(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FF3N7x():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVggHj)
 paths.append(VVggHj.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFtS24(ba)
 for p in list:
  p = ba + p + VVggHj
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVhBuB, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVggHj, VVhBuB , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VV0Wds, VV05tg = FF3N7x()
def FFKAmt():
 def VVihyF(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 iPath = CFG.iptvHostsPath.getValue()
 if not iPath == VVRVLV and not pathExists(iPath):
  CFG.iptvHostsPath.setValue(VVRVLV)
  CFG.iptvHostsPath.save()
  oldIptvHostsPath = VVRVLV
 else:
  oldIptvHostsPath = ""
 oldMovieDownloadPath = VVihyF(CFG.MovieDownloadPath, CCsRnB.VVhiFq())
 VV24AV   = VVihyF(CFG.backupPath, CCyCKB.VVyy1X())
 VVsG3J   = VVihyF(CFG.downloadedPackagesPath, t)
 VVubYQ  = VVihyF(CFG.exportedTablesPath, t)
 VVn0Vw  = VVihyF(CFG.exportedPIconsPath, t)
 VVmgiy   = VVihyF(CFG.packageOutputPath, t)
 global VVNnjH
 VVNnjH = FFRZql(CFG.backupPath.getValue())
 if VV24AV or VVmgiy or VVsG3J or VVubYQ or VVn0Vw or oldIptvHostsPath or oldMovieDownloadPath:
  configfile.save()
 return VV24AV, VVmgiy, VVsG3J, VVubYQ, VVn0Vw, oldIptvHostsPath, oldMovieDownloadPath
def FFvMsU(path):
 path = FFClhq(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFeN7w(SELF, pathList, tarFileName, addTimeStamp=True):
 VVKQR8 = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVKQR8.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVKQR8.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVKQR8.append(path)
 if not VVKQR8:
  FFcgS7(SELF, "Files not found!")
 elif not pathExists(VVNnjH):
  FFcgS7(SELF, "Path not found!\n\n%s" % VVNnjH)
 else:
  VVowXg = FFRZql(VVNnjH)
  tarFileName = "%s%s" % (VVowXg, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFdfSu())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVKQR8:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VV9gSb
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFFlx3(tarFileName, VVeO4o))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFFlx3(failed, VVeO4o))
  cmd += "fi;"
  cmd +=  sep
  FFmNHK(SELF, cmd)
def FFXHxA(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFhwWb(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFhwWb(SELF["keyInfo"], "info")
def FFhwWb(barObj, fName):
 path = "%s%s%s" % (VV05tg, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFJsjN(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFMf9K(satNum)
  return satName
def FFMf9K(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFru8i(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFJsjN(val)
  else  : sat = FFMf9K(val)
 return sat
def FFsWCY(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFJsjN(num)
 except:
  pass
 return sat
def FFyqHT(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FF7qBd(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFplQi(info, iServiceInformation.sServiceref)
   prov = FFplQi(info, iServiceInformation.sProvider)
   state = str(FFplQi(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFS5Go(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFvST6(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFplQi(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFW7yf(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFlcEP(refCode):
 info = FFGMzX(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFWBCU(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFZv6x(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFGMzX(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVaQEh = eServiceCenter.getInstance()
  if VVaQEh:
   info = VVaQEh.info(service)
 return info
def FFvYTu(SELF, refCode, VVonEU=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFTZUA(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVonEU:
   FFbhRG(SELF, isFromSession)
 try:
  VVSQ4S = InfoBar.instance
  if VVSQ4S:
   VVOVrd = VVSQ4S.servicelist
   if VVOVrd:
    servRef = eServiceReference(refCode)
    VVOVrd.saveChannel(servRef)
 except:
  pass
def FFTZUA(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCmugO()
    if pr.VVsBck(refCode, chName, decodedUrl, iptvRef):
     pr.VVaXNh(SELF, isFromSession)
def FFS5Go(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFVVjP(url): return FFam7W(url) or FFI6Dp(url)
def FFam7W(url)  : return any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFI6Dp(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FFvST6(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFAhi4(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFAhi4(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFGlin(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFTD0h(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFrR0L(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFkuxS(txt):
 try:
  return FFTD0h(FFrR0L(txt)) == txt
 except:
  return False
def FFbhRG(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCG8uj, isFromExternal=isFromSession)
 else      : FFr3nS(session, reopen=True, isFromExternal=isFromSession)
def FFr3nS(session, reopen=False, isFromExternal=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFr3nS, session, isFromExternal=isFromExternal), boundFunction(CC5iP3, isFromExternal=isFromExternal))
  except:
   try:
    FF2BMr(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFDNNZ(refCode):
 tp = CC37SE()
 if tp.VVCs57(refCode) : return True
 else        : return False
def FF0zlK(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFRfFm():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FFojgY():
 VVSQ4S = InfoBar.instance
 if VVSQ4S:
  VVOVrd = VVSQ4S.servicelist
  if VVOVrd:
   return VVOVrd.getBouquetList()
 return []
def FFGpvX():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFVrp5():
 path = FFGpvX()
 if path:
  txt = FFeIec(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FFDa4p(userBfile):
 txt = ""
 bFile = VVf9y4 + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVf9y4 + userBfile):
  fTxt = FFeIec(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFmclR('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
def FF1fee():
 return FFjNff(InfoBar.instance.servicelist.getRoot())
def FFjNff(root):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVaQEh = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVaQEh.info(service)
    lst.append((service.toString(), info.getName(service)))
 except:
  pass
 return lst
def FFigNV():
 VVsqeV = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVzNl1 = list(VVsqeV)
 return VVzNl1, VVsqeV
def FFfRw4():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFqBxV(session, VV0IG2):
 VV6n7I, VV5QQI, VV2z91, camCommand = FFzLdY()
 if VV5QQI:
  runLog = False
  if   VV0IG2 == CC6csD.VVk2Nt : runLog = True
  elif VV0IG2 == CC6csD.VV48KM : runLog = True
  elif not VV2z91          : FF2BMr(session, message="SoftCam not started yet!")
  elif fileExists(VV2z91)        : runLog = True
  else             : FF2BMr(session, message="File not found !\n\n%s" % VV2z91)
  if runLog:
   session.open(boundFunction(CC6csD, VV6n7I=VV6n7I, VV5QQI=VV5QQI, VV2z91=VV2z91, VV0IG2=VV0IG2))
 else:
  FF2BMr(session, message="No active OSCam/NCam found !", title="Live Log")
def FFzLdY():
 VV6n7I = "/etc/tuxbox/config/"
 VV5QQI = None
 VV2z91  = None
 camCommand = FFmclR("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VV5QQI = "oscam"
 elif "ncam"  in camCommand : VV5QQI = "ncam"
 if VV5QQI:
  path = FFmclR(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFRZql(path)
  if pathExists(path):
   VV6n7I = path
  tFile = VV6n7I + VV5QQI + ".conf"
  tFile = FFmclR("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VV2z91 = tFile
 return VV6n7I, VV5QQI, VV2z91, camCommand
def FFscD6(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFRW7X():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFdfSu():
 return FFRW7X().replace(" ", "_").replace("-", "").replace(":", "")
def FFgN2Y(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFt1xA():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFDt8N(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CC4M3v.VVMlKY(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CC4M3v.VV7A0S_forBouquet(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFA9Vj("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFBMJx(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFbtd6(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
VV2Ies = 0
def FFFcCy():
 global VV2Ies
 VV2Ies = iTime()
def FFtyqp():
 FFsb9f(">>>>>> Elapsed\t: {:.6f} seconds".format(iTime() - VV2Ies).rstrip("0").rstrip("."))
def FFkpHN(SELF, message, title=""):
 SELF.session.open(boundFunction(CCfxpJ, title=title, message=message, VVlwD9=True))
def FFn7o1(SELF, message, title="", VVuKKh=VVKyDE, **kwargs):
 SELF.session.open(boundFunction(CCfxpJ, title=title, message=message, VVuKKh=VVuKKh, **kwargs))
def FFcgS7(SELF, message, title="")  : FF2BMr(SELF.session, message, title)
def FFGmd5(SELF, path, title="") : FF2BMr(SELF.session, "File not found !\n\n%s" % path, title)
def FF2vkZ(SELF, path, title="") : FF2BMr(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFMiwh(SELF, title="")  : FF2BMr(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FF2BMr(session, message, title="") : session.open(boundFunction(CCIByc, title=title, message=message))
def FFZyEN(SELF, VVs5HI, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVs5HI, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVs5HI, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVs5HI, boundFunction(CCZGJp, title=title, message=message, VVF1lw=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFcgS7(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFixrz(SELF, callBack_Yes, VV9Uka, callBack_No=None, title="", VVEkk8=False, VVcGkw=True):
 SELF.session.openWithCallback(boundFunction(FFbhJW, callBack_Yes, callBack_No)
        , boundFunction(CCciQF, title=title, VV9Uka=VV9Uka, VVcGkw=VVcGkw, VVEkk8=VVEkk8))
def FFbhJW(callBack_Yes, callBack_No, FFixrzed):
 if FFixrzed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFLk1N(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFxTkM(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFd0fy(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFPRFL(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVo1nk = eTimer()
def FFd0fy(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFWDOp, SELF))
 fnc = boundFunction(FFWDOp, SELF)
 try:
  t = VVo1nk.timeout.connect(fnc)
 except:
  VVo1nk.callback.append(fnc)
 VVo1nk.start(milliSeconds, 1)
def FFWDOp(SELF):
 VVo1nk.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FF1Vl3(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCqbW9, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCqbW9, **kwargs))
  FFLm4N(win)
  return win
 except:
  return None
def FFqaQ9(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCUZrk, **kwargs))
 FFLm4N(win)
 return win
def FFqUR7(SELF, **kwargs):
 SELF.session.open(CC6WQp, **kwargs)
def FFZH71(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FF6TuE(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVmpyI, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFwAWu(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FF6TuE(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFaMwD():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFB2V8(VVbh3O):
 screenSize  = FFaMwD()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVbh3O)
 return bodyFontSize
def FF4gcJ(VVbh3O, extraSpace):
 font = gFont(VVmpyI, VVbh3O)
 VV786P = fontRenderClass.getInstance().getLineHeight(font) or (VVbh3O * 1.25)
 return int(VV786P + VV786P * extraSpace)
def FF8X8q(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFaMwD()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVmpyI, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FF4gcJ(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVmpyI, titleFontSize, alignLeftCenter)
 if winType == VVycF3 or winType == VVyKke:
  if winType == VVyKke : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVkLOo:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == WINDOW_SUBTITLE:
  lineH = int((height - 8) / 3.0)
  top = 2
  tmp += '<widget name="mySubtFr" position="0,0" size="%d,%d" zPosition="10" backgroundColor="#00FFFF00" />' % (width, height)
  for i in range(3):
   tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="11" foregroundColor="#ffffff" shadowColor="#555555" shadowOffset="-2,-2" backgroundColor="#ff000000" %s %s />' % (i, top + 2, width - 2, lineH - 2, bodyFontStr, alignCenter)
   top += lineH
 elif winType == VV8osc:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FFkpHNL = b2Left2 + timeW + marginLeft
  FFkpHNW = b2Left3 - marginLeft - FFkpHNL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FFkpHNL  , b2Top, FFkpHNW , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
 elif winType == VVLjNu:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVxTu6:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVnpW4:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVX2yX:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVmpyI, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVmpyI, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VV6tuu:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFkpHNH = int(bodyH * 0.5)
  inpTop = bodyTop + FFkpHNH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFkpHNH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVmpyI, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVmpyI, mapF, alignCenter)
 elif winType == VVyKDR:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVokoY:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVmpyI, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VViW94:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVmpyI, fontH, alignCenter)
 elif winType == VVGhHa:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVmpyI, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVmpyI, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVmpyI, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVuBsi:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVTS1Q:
  tmp += '<widget name="myPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (marginLeft, bodyTop, bodyW, bodyH)
 else:
  if   winType == VVLiFQ : align = alignLeftCenter
  elif winType == VVMlUC : align = alignLeftTop
  else          : align = alignCenter
  if winType == VV67W3:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVmpyI
  if usefixedFont and winType == VVMlUC:
   fnt = "Fixed"
   if fnt in FFZVCr():
    fontName = "Fixed"
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVbh3O = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVmpyI, VVbh3O, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVc1Ml = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVmpyI, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVc1Ml[i], VVmpyI, barFont, alignCenter)
   left += btnW + gap
 if winType == VVMlUC:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVc1Ml = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVc1Ml[i], VVmpyI, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF8X8q(VVycF3, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.VVw8gH = ""
  self.themsList  = []
  VVlZjX = []
  if VVzhgw:
   VVlZjX.append(("-- MY TEST --"    , "myTest"   ))
  VVlZjX.append(("  File Manager"     , "FileManager"  ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("  Services/Channels"    , "ChannelsTools" ))
  VVlZjX.append(("  IPTV"       , "IptvTools"  ))
  VVlZjX.append(("  PIcons"       , "PIconsTools"  ))
  VVlZjX.append(("  SoftCam"      , "SoftCam"   ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("  Plugins"      , "PluginsTools" ))
  VVlZjX.append(("  Terminal"      , "Terminal"  ))
  VVlZjX.append(("  Backup & Restore"    , "BackupRestore" ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("  Date/Time"      , "Date_Time"  ))
  VVlZjX.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVlZjX)
  FFNPyH(self, VVlZjX=VVlZjX)
  FFkV23(self["keyRed"] , "Exit")
  FFkV23(self["keyGreen"] , "Settings")
  FFkV23(self["keyYellow"], "Dev. Info.")
  FFkV23(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VVblb5       ,
   "yellow"  : self.VVqy7v       ,
   "blue"   : self.VVgWlP       ,
   "info"   : self.VVgWlP       ,
   "next"   : self.VVsQSa       ,
   "menu"   : self.VVGXu5     ,
   "text"   : self.VVnHSa      ,
   "0"    : boundFunction(self.VVSMkI, 0) ,
   "1"    : boundFunction(self.VVzaO1, 1)   ,
   "2"    : boundFunction(self.VVzaO1, 2)   ,
   "3"    : boundFunction(self.VVzaO1, 3)   ,
   "4"    : boundFunction(self.VVzaO1, 4)   ,
   "5"    : boundFunction(self.VVzaO1, 5)   ,
   "6"    : boundFunction(self.VVzaO1, 6)   ,
   "7"    : boundFunction(self.VVzaO1, 7)   ,
   "8"    : boundFunction(self.VVzaO1, 8)   ,
   "9"    : boundFunction(self.VVzaO1, 9)
  })
  self.onShown.append(self.VVYZus)
  self.onClose.append(self.onExit)
  global VVs8GF, VVIUAA, VV2GoD
  VVs8GF = VVIUAA = VV2GoD = False
 def VVEvnY(self):
  item = FFr1Kw(self)
  self.VVzaO1(item)
 def VVzaO1(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVRR6H()
   elif item in ("FileManager"  , 1) : self.session.open(CCs7ea)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCYAlZ)
   elif item in ("IptvTools"  , 3) : self.session.open(CC4M3v)
   elif item in ("PIconsTools"  , 4) : self.VVZSG8()
   elif item in ("SoftCam"   , 5) : self.session.open(CCRhRy)
   elif item in ("PluginsTools" , 6) : self.session.open(CC70XN)
   elif item in ("Terminal"  , 7) : self.session.open(CCX72r)
   elif item in ("BackupRestore" , 8) : self.session.open(CCsLr1)
   elif item in ("Date_Time"  , 9) : self.session.open(CCrkB3)
   elif item in ("CheckInternet" , 10) : self.session.open(CCCqQd)
   else         : self.close()
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FFhGNA(self["myMenu"])
  FFwAWu(self)
  FFZH71(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVg2tB)
  self["myTitle"].setText(title)
  VV24AV, VVmgiy, VVsG3J, VVubYQ, VVn0Vw, oldIptvHostsPath, oldMovieDownloadPath = FFKAmt()
  self.VVdvkT()
  if VV24AV or VVmgiy or VVsG3J or VVubYQ or VVn0Vw or oldIptvHostsPath or oldMovieDownloadPath:
   VVPdAh = lambda path, subj: "%s:\n%s\n\n" % (subj, FF0hQa(path, VVahL2)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVPdAh(oldIptvHostsPath  , "IPTV Hosts Files Path"   )
   txt += VVPdAh(VV24AV   , "Backup/Restore Path"    )
   txt += VVPdAh(VVmgiy  , "Created Package Files (IPK/DEB)" )
   txt += VVPdAh(VVsG3J  , "Download Packages (from feeds)" )
   txt += VVPdAh(VVubYQ , "Exported Tables"     )
   txt += VVPdAh(VVn0Vw , "Exported PIcons"     )
   txt += VVPdAh(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFn7o1(self, txt, title="Settings Paths")
  if (EASY_MODE or VVCy2B or VVzhgw):
   FFxTkM(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFLk1N(self, "Welcome", 300)
  FF3K6t(boundFunction(self.VVA5re, title))
 def VVA5re(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCyCKB.VVhVmf()
   if url:
    newWebVer = CCyCKB.VV24fn(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFA9Vj("rm /tmp/ajpanel*"))
  global VVs8GF, VVIUAA, VV2GoD
  VVs8GF = VVIUAA = VV2GoD = False
 def VVSMkI(self, digit):
  self.VVw8gH += str(digit)
  ln = len(self.VVw8gH)
  global VVs8GF, VV2GoD
  if ln == 4:
   if self.VVw8gH == "0" * ln:
    VVs8GF = True
    FFxTkM(self["myTitle"], "#800080")
   else:
    self.VVw8gH = "x"
  elif self.VVw8gH == "0" * 8:
   VV2GoD = True
 def VVsQSa(self):
  self.VVw8gH += ">"
  if self.VVw8gH == "0" * 4 + ">" * 2:
   global VVIUAA
   VVIUAA = True
   FFxTkM(self["myTitle"], "#dd5588")
 def VVnHSa(self):
  if self.VVw8gH == "0" * 4:
   ok = False
   fnt = "ae_AlMateen.ttf"
   fontFile = "/usr/share/fonts/%s" % fnt
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    try:
     addFont(fontFile, fontName, 100, True)
     ok = True
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      ok = True
     except:
      pass
   if ok: txt = 'Added Font: "%s"' % fnt
   else : txt = '"%s" Not Found' % fnt
   FFLk1N(self, txt, 2000, isGrn=ok)
 def VVZSG8(self):
  found = False
  pPath = CCwdjc.VVW1YO()
  if pathExists(pPath):
   for fName, fType in CCwdjc.VVDSPs(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCwdjc)
  else:
   VVlZjX = []
   VVlZjX.append(("PIcons Manager" , "CCwdjc" ))
   VVlZjX.append(VVZYy7)
   VVlZjX.append(CCwdjc.VVmgZx())
   VVlZjX.append(VVZYy7)
   VVlZjX += CCwdjc.VVJqC5()
   FFqaQ9(self, self.VVEE33, VVlZjX=VVlZjX)
 def VVEE33(self, item=None):
  if item:
   if   item == "CCwdjc"   : self.session.open(CCwdjc)
   elif item == "VVfGFJ"  : CCwdjc.VVfGFJ(self)
   elif item == "VVonFB"  : CCwdjc.VVonFB(self)
   elif item == "findPiconBrokenSymLinks" : CCwdjc.VVKuWE(self, True)
   elif item == "FindAllBrokenSymLinks" : CCwdjc.VVKuWE(self, False)
 def VVblb5(self):
  self.session.open(CCyCKB)
 def VVqy7v(self):
  self.session.open(CCgPzN)
 def VVgWlP(self):
  changeLogFile = VV05tg + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FFW1ru(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FF0hQa("\n%s\n%s\n%s" % (VV9gSb, line, VV9gSb), VVg4jx, VV3rkc)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FF0hQa(line, VV7bzw, VV3rkc)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFn7o1(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVg2tB, PLUGIN_DESCRIPTION), VVbh3O=26)
 def VVGXu5(self):
  VVlZjX = []
  VVlZjX.append(("Title Colors"   , "title" ))
  VVlZjX.append(("Menu Area Colors"  , "body" ))
  VVlZjX.append(("Menu Pointer Colors" , "cursor" ))
  VVlZjX.append(("Bottom Bar Colors" , "bar"  ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Reset Colors"   , "reset" ))
  title = "Main Menu Colors"
  FFqaQ9(self, boundFunction(self.VVsqse, title), VVlZjX=VVlZjX, width=500, title=title)
 def VVsqse(self, title, item=None):
  if item:
   if item == "reset":
    FFixrz(self, self.VVwZcw, "Reset to default colors ?", title=title)
   else:
    tDict = self.VVKyyd()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VVWECq, tDict, item), CCR5s5, defFG=fg, defBG=bg)
 def VVq2PK(self):
  return VVNnjH + "ajpanel_colors"
 def VVKyyd(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVq2PK()
  if fileExists(p):
   txt = FFeIec(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVWECq(self, tDict, item, fg, bg):
  if fg:
   self.VVBGVO(item, fg)
   self.VV3B36(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVITIi(tDict)
 def VVITIi(self, tDict):
   p = self.VVq2PK()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVBGVO(self, item, fg):
  if   item == "title" : FF3XWe(self["myTitle"], fg)
  elif item == "body"  :
   FF3XWe(self["myMenu"], fg)
   FF3XWe(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFxTkM(self["myBar"], fg)
   FF3XWe(self["keyRed"], fg)
   FF3XWe(self["keyGreen"], fg)
   FF3XWe(self["keyYellow"], fg)
   FF3XWe(self["keyBlue"], fg)
 def VV3B36(self, item, bg):
  if   item == "title" : FFxTkM(self["myTitle"], bg)
  elif item == "body"  :
   FFxTkM(self["myMenu"], bg)
   FFxTkM(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFxTkM(self["myBar"], bg)
 def VVwZcw(self):
  os.system(FFA9Vj("rm %s" % self.VVq2PK()))
  self.close()
 def VVdvkT(self):
  tDict = self.VVKyyd()
  self.VVNQ8L(tDict, "title")
  self.VVNQ8L(tDict, "body")
  self.VVNQ8L(tDict, "cursor")
  self.VVNQ8L(tDict, "bar")
 def VVNQ8L(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVBGVO(name, fg)
  if bg: self.VV3B36(name, bg)
 def VVRR6H(self):
  FFqUR7(self, fncMode=CC6WQp.VVJ0jF)
class CCo0R4():
 @staticmethod
 def VVnNCk():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVaxbv(isApply=False):
  global VVrPSH, VVVSQr
  VVrPSH  = True
  VVVSQr = CCo0R4.VVtoIi()
  CCo0R4.VVsk6x()
 @staticmethod
 def VVsk6x():
  if VVVSQr:
   global VVrPSH
   if CFG.forceUtf8Encoding.getValue():
    if CCo0R4.VVYRfB() : VVrPSH = True
    else        : VVrPSH = False
   else:
    CCo0R4.VVuks3()
    VVrPSH = False
 @staticmethod
 def VVtoIi(isApply=False):
  from sys import version_info
  if version_info[0] >= 3 and version_info[1] >= 10:
   path = "/etc/issue"
   if fileExists(path):
    path = "/etc/issue"
    if fileExists(path):
     txt = FFeIec(path)
     span = iSearch(r"open.?vision", txt, IGNORECASE)
     if span:
      return True
  return False
 @staticmethod
 def VVYRfB():
  import locale
  enc = locale.getdefaultlocale()[1]
  span = iSearch(r"UTF.?8", enc, IGNORECASE)
  if not span:
   try:
    import locale
    return locale.setlocale(locale.LC_ALL, "en_GB.UTF-8")
   except:
    pass
  return None
 @staticmethod
 def VVuks3():
  try:
   import locale
   return locale.setlocale(locale.LC_ALL, "")
  except:
   return None
 @staticmethod
 def VV3FCX(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FF1Vl3(SELF, None, VVKQR8=lst, VVbh3O=30, VVs65B=True)
 @staticmethod
 def VVp85V(path, SELF=None):
  for enc in CCo0R4.VVnNCk():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFcgS7(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVeOSJ(SELF, path, cbFnc, defEnc="", pos=0):
  FFLk1N(SELF)
  lst = CCo0R4.VVAZxG(path)
  if lst:
   VVlZjX = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if defEnc == enc:
     txt = FF0hQa(txt, VVeO4o)
    VVlZjX.append((txt, enc))
   win = FFqaQ9(SELF, cbFnc, title="Select Encoding", VVlZjX=VVlZjX, width=900, height=500 if pos == 1 else 0)
   if pos == 1:
    win.instance.move(ePoint(40, 40))
  else:
   FFLk1N(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVAZxG(path):
  encLst = []
  cPath = VV05tg + "codecs"
  if fileExists(cPath):
   lines = FFW1ru(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCo0R4.VVnNCk())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    try:
     with ioOpen(path, "r", encoding=enc) as f:
      for line in f:
       pass
     lst.append((item[0], enc))
    except:
     pass
  return lst
class CCgPzN(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF8X8q(VVycF3, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVlZjX = []
  VVlZjX.append(("Settings File"        , "SettingsFile"   ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Box Info"          , "VVVzSK"    ))
  VVlZjX.append(("Tuners Info"         , "VV1bgo"   ))
  VVlZjX.append(("Python Version"        , "VV9PlB"   ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Screen Size"         , "ScreenSize"    ))
  VVlZjX.append(("Language/Locale"        , "Locale"     ))
  VVlZjX.append(("Processor"         , "Processor"    ))
  VVlZjX.append(("Operating System"        , "OperatingSystem"   ))
  VVlZjX.append(("Drivers"          , "drivers"     ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("System Users"         , "SystemUsers"    ))
  VVlZjX.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVlZjX.append(("Uptime"          , "Uptime"     ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Host Name"         , "HostName"    ))
  VVlZjX.append(("MAC Address"         , "MACAddress"    ))
  VVlZjX.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVlZjX.append(("Network Status"        , "NetworkStatus"   ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Disk Usage"         , "VVHFxa"    ))
  VVlZjX.append(("Mount Points"         , "MountPoints"    ))
  VVlZjX.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVlZjX.append(("USB Devices"         , "USB_Devices"    ))
  VVlZjX.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVlZjX.append(("Directory Size"        , "DirectorySize"   ))
  VVlZjX.append(("Memory"          , "Memory"     ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVlZjX.append(("Running Processes"       , "RunningProcesses"  ))
  VVlZjX.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFNPyH(self, VVlZjX=VVlZjX, title="Device Information")
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FFhGNA(self["myMenu"])
  FFwAWu(self)
 def VVEvnY(self):
  global VVWK7p
  VVWK7p = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CC20j9)
   elif item == "VVVzSK"    : self.VVVzSK()
   elif item == "VV1bgo"   : self.VV1bgo()
   elif item == "VV9PlB"   : self.VV9PlB()
   elif item == "ScreenSize"    : FFn7o1(self, "Width\t: %s\nHeight\t: %s" % (FFaMwD()[0], FFaMwD()[1]))
   elif item == "Locale"     : CCo0R4.VV3FCX(self)
   elif item == "Processor"    : self.VVZ4AK()
   elif item == "OperatingSystem"   : FFovqt(self, "uname -a"        )
   elif item == "drivers"     : self.VVZyf1()
   elif item == "SystemUsers"    : FFovqt(self, "id"          )
   elif item == "LoggedInUsers"   : FFovqt(self, "who -a"         )
   elif item == "Uptime"     : FFovqt(self, "uptime"         )
   elif item == "HostName"     : FFovqt(self, "hostname"        )
   elif item == "MACAddress"    : self.VVSaZZ()
   elif item == "NetworkConfiguration"  : FFovqt(self, "ifconfig %s %s" % (FFFlx3("HWaddr", VVIXzm), FFFlx3("addr:", VVg4jx)))
   elif item == "NetworkStatus"   : FFovqt(self, "netstat -tulpn"       )
   elif item == "VVHFxa"    : self.VVHFxa()
   elif item == "MountPoints"    : FFovqt(self, "mount %s" % (FFFlx3(" on ", VVg4jx)))
   elif item == "FileSystemTable"   : FFovqt(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFovqt(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFovqt(self, "blkid"         )
   elif item == "DirectorySize"   : FFovqt(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVgzsB="Reading size ...")
   elif item == "Memory"     : FFovqt(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVCJrN()
   elif item == "RunningProcesses"   : FFovqt(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFovqt(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVzSMg()
   else         : self.close()
 def VVSaZZ(self):
  res = FFgabI("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFn7o1(self, txt)
  else:
   FFovqt(self, "ip link")
 def VVTAyC(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFfDK7(cmd)
  return lines
 def VV4565(self, lines, headerRepl, widths, VVDhPS):
  VVXJa5 = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVXJa5.append(parts)
  if VVXJa5 and len(header) == len(widths):
   VVXJa5.sort(key=lambda x: x[0].lower())
   FF1Vl3(self, None, header=header, VVKQR8=VVXJa5, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=28, VVs65B=True)
   return True
  else:
   return False
 def VVHFxa(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFgabI(cmd)
  if not "invalid option" in txt:
   lines  = self.VVTAyC(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VVDhPS = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VV4565(lines, headerRepl, widths, VVDhPS)
  else:
   cmd = "df -h"
   lines  = self.VVTAyC(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VVDhPS = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VV4565(lines, headerRepl, widths, VVDhPS)
  if not allOK:
   lines = FFfDK7(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFClhq(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVeO4o:
     note = "\n%s" % FF0hQa("Green = Mounted Partitions", VVeO4o)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVg4jx
     elif line.endswith(mountList) : color = VVeO4o
     else       : color = VV7bzw
     txt += FF0hQa(line, color) + "\n"
    FFn7o1(self, txt + note)
   else:
    FFcgS7(self, "Not data from system !")
 def VVCJrN(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVTAyC(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVDhPS = (LEFT , CENTER, LEFT )
  allOK = self.VV4565(lines, headerRepl, widths, VVDhPS)
  if not allOK:
   FFovqt(self, cmd)
 def VVZyf1(self):
  cmd = FFWjY7(VVKJja, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFovqt(self, cmd)
  else : FFMiwh(self)
 def VVZ4AK(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFovqt(self, cmd)
 def VVzSMg(self):
  cmd = FFWjY7(VVboDa, "| grep secondstage")
  if cmd : FFovqt(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFMiwh(self)
 def VVVzSK(self):
  c = VVeO4o
  VVKQR8 = []
  VVKQR8.append((FF0hQa("Box Type"  , c), FF0hQa(self.VVgyfq("boxtype").upper(), c)))
  VVKQR8.append((FF0hQa("Board Version", c), FF0hQa(self.VVgyfq("board_revision") , c)))
  VVKQR8.append((FF0hQa("Chipset"  , c), FF0hQa(self.VVgyfq("chipset")  , c)))
  VVKQR8.append((FF0hQa("S/N"   , c), FF0hQa(self.VVgyfq("sn")    , c)))
  VVKQR8.append((FF0hQa("Version"  , c), FF0hQa(self.VVgyfq("version")  , c)))
  VVHp1U   = []
  VVt2EA = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVt2EA = SystemInfo[key]
     else:
      VVHp1U.append((FF0hQa(str(key), VV3UWE), FF0hQa(str(SystemInfo[key]), VV3UWE)))
  except:
   pass
  if VVt2EA:
   VVBI95 = self.VV4on7(VVt2EA)
   if VVBI95:
    VVBI95.sort(key=lambda x: x[0].lower())
    VVKQR8 += VVBI95
  if VVHp1U:
   VVHp1U.sort(key=lambda x: x[0].lower())
   VVKQR8 += VVHp1U
  if VVKQR8:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FF1Vl3(self, None, header=header, VVKQR8=VVKQR8, VVrZ8Z=widths, VVbh3O=28, VVs65B=True)
  else:
   FFn7o1(self, "Could not read info!")
 def VVgyfq(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFW1ru(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VV4on7(self, mbDict):
  try:
   mbList = list(mbDict)
   VVKQR8 = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVKQR8.append((FF0hQa(subject, VVg4jx), FF0hQa(value, VVg4jx)))
  except:
   pass
  return VVKQR8
 def VV1bgo(self):
  txt = self.VVovQc("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVovQc("/proc/bus/nim_sockets")
  if not txt: txt = self.VVngyx()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFn7o1(self, txt)
 def VVngyx(self):
  txt = ""
  VVPdAh = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVPdAh("Slot Name" , slot.getSlotName())
     txt += FF0hQa(slotName, VVg4jx)
     txt += VVPdAh("Description"  , slot.getFullDescription())
     txt += VVPdAh("Frontend ID"  , slot.frontend_id)
     txt += VVPdAh("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVovQc(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFW1ru(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FF0hQa(line, VVg4jx)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VV9PlB(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFn7o1(self, txt)
class CC20j9(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF8X8q(VVycF3, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVlZjX = []
  VVlZjX.append(("Settings (All)"   , "Settings_All"   ))
  VVlZjX.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  if VVIUAA:
   VVlZjX.append(("Settings (FHDG-17)" , "Settings_FHDG_17"  ))
  VVlZjX.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVlZjX.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVlZjX.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVlZjX.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVlZjX.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFNPyH(self, VVlZjX=VVlZjX)
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FFhGNA(self["myMenu"])
  FFwAWu(self)
 def VVEvnY(self):
  global VVWK7p
  VVWK7p = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFovqt(self, cmd                )
   elif item == "Settings_HotKeys"   : FFovqt(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFovqt(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFovqt(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFovqt(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFovqt(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFovqt(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFovqt(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCRhRy(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF8X8q(VVycF3, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VV6n7I, VV5QQI, VV2z91, camCommand = FFzLdY()
  self.VV5QQI = VV5QQI
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVlZjX = []
  VVlZjX.append(("OSCam Files"        , "OSCamFiles"  ))
  VVlZjX.append(("NCam Files"        , "NCamFiles"  ))
  VVlZjX.append(("CCcam Files"        , "CCcamFiles"  ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVlZjX.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVlZjX.append(VVZYy7)
  if VV5QQI:
   if   "oscam" in VV5QQI : camName = "OSCam"
   elif "ncam"  in VV5QQI : camName = "NCam"
   VVlZjX.append((camName + " Info."      , "camInfo"   ))
   VVlZjX.append((camName + " Live Status"    , "camLiveStatus" ))
   VVlZjX.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVlZjX.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVlZjX.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFNPyH(self, VVlZjX=VVlZjX)
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FFhGNA(self["myMenu"])
  FFwAWu(self)
 def VVEvnY(self):
  global VVWK7p
  VVWK7p = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCnwrh, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCnwrh, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCnwrh, "cccam"))
   elif item == "OSCamReaders"  : self.VV2W6P("os")
   elif item == "NSCamReaders"  : self.VV2W6P("n")
   elif item == "camInfo"   : FFHj1R(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFqBxV(self.session, CC6csD.VVk2Nt)
   elif item == "camLiveReaders" : FFqBxV(self.session, CC6csD.VV48KM)
   elif item == "camLiveLog"  : FFqBxV(self.session, CC6csD.VVSSkC)
   else       : self.close()
 def VV2W6P(self, camPrefix):
  VVXJa5 = self.VVR2aD(camPrefix)
  if VVXJa5:
   VVXJa5.sort(key=lambda x: int(x[0]))
   if self.VV5QQI and self.VV5QQI.startswith(camPrefix):
    VVx7qK = ("Toggle State", self.VVr9CP, [camPrefix], "Changing State ...")
   else:
    VVx7qK = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVDhPS  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FF1Vl3(self, None, header=header, VVKQR8=VVXJa5, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=26, VVx7qK=VVx7qK, VVwgKR=True)
 def VVR2aD(self, camPrefix):
  readersFile = self.VV6n7I + camPrefix + "cam.server"
  VVXJa5 = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFW1ru(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVXJa5.append((str(len(VVXJa5) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVXJa5:
    FFcgS7(self, "No readers found !")
  else:
   FFGmd5(self, readersFile)
  return VVXJa5
 def VVr9CP(self, VVpjES, camPrefix):
  confFile  = "%s%scam.conf" % (self.VV6n7I, camPrefix)
  readerState  = VVpjES.VVvMZR(1)
  readerLabel  = VVpjES.VVvMZR(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCRhRy.VVfP30(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVpjES.VVgLcP()
    FFcgS7(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVXJa5 = self.VVR2aD(camPrefix)
   if VVXJa5:
    VVpjES.VV3EJ0(VVXJa5)
 @staticmethod
 def VVfP30(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFW1ru(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFcgS7(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFcgS7(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFGmd5(SELF, confFile)
   return None
  if not iRequest:
   FFcgS7(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FFcgS7(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FFcgS7(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCnwrh(Screen):
 def __init__(self, VVm6cn, session, args=0):
  self.skin, self.skinParam = FF8X8q(VVycF3, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VV6n7I, VV5QQI, VV2z91, camCommand = FFzLdY()
  if   VVm6cn == "ncam" : self.prefix = "n"
  elif VVm6cn == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVlZjX = []
  if self.prefix == "":
   VVlZjX.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVlZjX.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVlZjX.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVlZjX.append(("constant.cw"         , "x_constant_cw" ))
   VVlZjX.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVlZjX.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVlZjX.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVlZjX.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVlZjX.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVlZjX.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVlZjX.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVlZjX.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVlZjX.append(VVZYy7)
   VVlZjX.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVlZjX.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVlZjX.append(VVZYy7)
   VVlZjX.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVlZjX.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVlZjX.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFNPyH(self, VVlZjX=VVlZjX)
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FFhGNA(self["myMenu"])
  FFwAWu(self)
 def VVEvnY(self):
  global VVWK7p
  VVWK7p = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFhuLL(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFhuLL(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFhuLL(self, self.VV6n7I + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFhuLL(self, self.VV6n7I + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVhXhK("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVhXhK("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVhXhK("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVhXhK("cam.provid"        )
   elif item == "x_cam_server"  : self.VVhXhK("cam.server"        )
   elif item == "x_cam_services" : self.VVhXhK("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVhXhK("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVhXhK("cam.user"        )
   elif item == "x_VV9gSb"   : pass
   elif item == "x_SoftCam_Key" : self.VV0gbl()
   elif item == "x_CCcam_cfg"  : FFhuLL(self, self.VV6n7I + "CCcam.cfg"    )
   elif item == "x_VV9gSb"   : pass
   elif item == "x_cam_log"  : FFhuLL(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFhuLL(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFhuLL(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVhXhK(self, fileName):
  FFhuLL(self, self.VV6n7I + self.prefix + fileName)
 def VV0gbl(self):
  path = self.VV6n7I + "SoftCam.Key"
  if fileExists(path) : FFhuLL(self, path)
  else    : FFhuLL(self, path.replace(".Key", ".key"))
class CC6csD(Screen):
 VVk2Nt  = 0
 VV48KM = 1
 VVSSkC = 2
 def __init__(self, session, VV6n7I="", VV5QQI="", VV2z91="", VV0IG2=VVk2Nt):
  self.skin, self.skinParam = FF8X8q(VVMlUC, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VV2z91   = VV2z91
  self.VV0IG2  = VV0IG2
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VV6n7I + VV5QQI + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VV5QQI : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VV6n7I, self.camPrefix)
  if self.VV0IG2 == self.VVk2Nt:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VV0IG2 == self.VV48KM:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFNPyH(self, self.Title, addScrollLabel=True)
  FFkV23(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVWCYQ
  self.onShown.append(self.VVYZus)
  self.onClose.append(self.onExit)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  self["myLabel"].VVBS02(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFZH71(self)
  self.VVWCYQ()
 def onExit(self):
  self.timer.stop()
 def VVG4SH(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVbNJP)
  except:
   self.timer.callback.append(self.VVbNJP)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFLk1N(self, "Started", 1000)
 def VVh2xX(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVbNJP)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFLk1N(self, "Stopped", 1000)
 def VVWCYQ(self):
  if self.timerRunning:
   self.VVh2xX()
  else:
   self.VVG4SH()
   if self.VV0IG2 == self.VVk2Nt or self.VV0IG2 == self.VV48KM:
    if self.VV0IG2 == self.VVk2Nt : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCRhRy.VVfP30(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FF3K6t(self.VVNOPL)
    else:
     self.close()
   else:
    self.VVnSDe()
 def VVbNJP(self):
  if self.timerRunning:
   if   self.VV0IG2 == self.VVk2Nt : self.VVLowm()
   elif self.VV0IG2 == self.VV48KM : self.VVLowm()
   else            : self.VVnSDe()
 def VVnSDe(self):
  if fileExists(self.VV2z91):
   fTime = FFscD6(os.path.getmtime(self.VV2z91))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVM34P(), VVuKKh=VVRjSm)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VV2z91)
 def VVNOPL(self):
  self.VVLowm()
 def VVLowm(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FF0hQa("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVaqQK))
   self.camWebIfErrorFound = True
   self.VVh2xX()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VV0IG2 == self.VVk2Nt : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FF0hQa("Error while parsing data elements !\n\nError = %s" % str(e), VVahL2)
   self.camWebIfErrorFound = True
   self.VVh2xX()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVYB1g(root)
  self["myLabel"].setText(txt, VVuKKh=VVRjSm)
  self["myBar"].setText("Last Update : %s" % FFRW7X())
 def VVYB1g(self, rootElement):
  def VVPdAh(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VV0IG2 == self.VVk2Nt:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FF0hQa(status, VVeO4o)
    else          : status = FF0hQa(status, VVahL2)
    txt += VV9gSb + "\n"
    txt += VVPdAh("Name"  , name)
    txt += VVPdAh("Description" , desc)
    txt += VVPdAh("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVPdAh("Protocol" , protocol)
    txt += VVPdAh("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FF0hQa("Yes", VVeO4o)
    else    : enabTxt = FF0hQa("No", VVahL2)
    txt += VV9gSb + "\n"
    txt += VVPdAh("Label"  , label)
    txt += VVPdAh("Protocol" , protocol)
    txt += VVPdAh("Enabled" , enabTxt)
  return txt
 def VVM34P(self):
  wordsDict = self.VVi2dF()
  color = [ VVg4jx, VVIXzm, VVeO4o, VVahL2, VV3UWE, VVeSCc]
  lines = FFfDK7("tail -n %d %s" % (100, self.VV2z91))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVaqQK + line[:19] + VV7bzw + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VV3rkc + line[ndx + 3:] + VV7bzw
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVg4jx + line[ndx + 8 : ndx1 + 4] + VV7bzw + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VV7bzw)
   elif line.startswith("----") or ">>" in line:
    line = FF0hQa(line, VVg4jx)
   txt += line + "\n"
  return txt
 def VVi2dF(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFW1ru(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCsLr1(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF8X8q(VVycF3, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVlZjX = []
  VVlZjX.append(("Backup Channels"    , "VVqbn0"   ))
  VVlZjX.append(("Restore Channels"    , "Restore_Channels"  ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Backup SoftCAM Files"   , "VVb2Zd" ))
  VVlZjX.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVlZjX.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVlZjX.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Backup Network Settings"  , "VVhRdp"   ))
  VVlZjX.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVIUAA:
   VVlZjX.append(VVZYy7)
   VVlZjX.append((VVaqQK + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VV0SzM"   ))
   VVlZjX.append((VVeO4o + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVKiwb) , "createMyIpk"   ))
   VVlZjX.append((VVeO4o + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVKiwb) , "createMyDeb"   ))
   VVlZjX.append((VV3UWE + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVlZjX.append((VV3UWE + "Decode %s Crash Report"   % PLUGIN_NAME     , "VVvtVz" ))
  FFNPyH(self, VVlZjX=VVlZjX)
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FFhGNA(self["myMenu"])
  FFwAWu(self)
 def VVEvnY(self):
  global VVWK7p
  VVWK7p = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVqbn0"    : self.VVqbn0()
   elif item == "Restore_Channels"    : self.VV1sKW("channels_backup*.tar.gz", self.VVXzwg)
   elif item == "VVb2Zd"   : self.VVb2Zd()
   elif item == "Restore_SoftCAM_Files"  : self.VV1sKW("softcam_backup*.tar.gz", self.VVm0Kd)
   elif item == "Backup_TunerDiSEqC"   : self.VVhvxr("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VV1sKW("tuner_backup*.backup", boundFunction(self.VVkEoI, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVhvxr("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VV1sKW("hotkey_*backup*.backup", boundFunction(self.VVkEoI, "misc"))
   elif item == "VVhRdp"    : self.VVhRdp()
   elif item == "Restore_Network"    : self.VV1sKW("network_backup*.tar.gz", self.VV5maJ)
   elif item == "VV0SzM"     : FFixrz(self, boundFunction(FF1SeM, self, boundFunction(CCsLr1.VV0SzM, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVxClF(False)
   elif item == "createMyDeb"     : self.VVxClF(True)
   elif item == "createMyTar"     : self.VVUxjA()
   elif item == "VVvtVz"   : self.VVvtVz()
 @staticmethod
 def VV0SzM(SELF):
  OBF_Path = VV0Wds + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VV0Wds, VVg2tB, VVKiwb)
   if err : FFcgS7(SELF, err)
   else : FFn7o1(SELF, txt)
  else:
   FFGmd5(SELF, OBF_Path)
 def VVxClF(self, VV4tpv):
  OBF_Path = VV0Wds + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFcgS7(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VV0Wds)
  os.system("mv -f %s %s" % (VV0Wds + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VV0Wds + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VV0Wds + "plugin.py"))
  self.session.openWithCallback(self.VVxClF1, boundFunction(CCrjmi, path=VV0Wds, VV4tpv=VV4tpv))
 def VVxClF1(self):
  os.system("mv -f %s %s" % (VV0Wds + "OBF/main.py"  , VV0Wds))
  os.system("mv -f %s %s" % (VV0Wds + "OBF/plugin.py" , VV0Wds))
 def VVvtVz(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFcgS7(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFcgS7(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVqx1F("%s*.list" % path)
  if err:
   FFGmd5(self, path + "*.list")
   return
  srcF, err = self.VVqx1F("%s*main_final.py" % path)
  if err:
   FFGmd5(self, path + "*.final.py")
   return
  VVKQR8 = []
  for f in files:
   f = os.path.basename(f)
   VVKQR8.append((f, f))
  FFqaQ9(self, boundFunction(self.VVI3uA, path, codF, srcF), VVlZjX=VVKQR8)
 def VVI3uA(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFGmd5(self, logF)
   else     : FF1SeM(self, boundFunction(self.VVXEny, logF, codF, srcF))
 def VVXEny(self, logF, codF, srcF):
  lst  = []
  lines = FFW1ru(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFcgS7(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVmCPx(lst, logF, newLogF)
  totSrc  = self.VVmCPx(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFn7o1(self, txt)
 def VVqx1F(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVmCPx(self, lst, f1, f2):
  txt = FFeIec(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVUxjA(self):
  VVKQR8 = []
  VVKQR8.append("%s%s" % (VV0Wds, "*.py"))
  VVKQR8.append("%s%s" % (VV0Wds, "*.png"))
  VVKQR8.append("%s%s" % (VV0Wds, "*.xml"))
  VVKQR8.append("%s"  % (VV05tg))
  FFeN7w(self, VVKQR8, "%s_%s" % (PLUGIN_NAME, VVg2tB), addTimeStamp=False)
 def VVqbn0(self):
  path1 = VVf9y4
  path2 = "/etc/tuxbox/"
  VVKQR8 = []
  VVKQR8.append("%s%s" % (path1, "*.tv"))
  VVKQR8.append("%s%s" % (path1, "*.radio"))
  VVKQR8.append("%s%s" % (path1, "*list"))
  VVKQR8.append("%s%s" % (path1, "lamedb*"))
  VVKQR8.append("%s%s" % (path2, "*.xml"))
  FFeN7w(self, VVKQR8, "channels_backup", addTimeStamp=True)
 def VVb2Zd(self):
  VVKQR8 = []
  VVKQR8.append("/etc/tuxbox/config/")
  VVKQR8.append("/usr/keys/")
  VVKQR8.append("/usr/scam/")
  VVKQR8.append("/etc/CCcam.cfg")
  FFeN7w(self, VVKQR8, "softcam_backup", addTimeStamp=True)
 def VVhRdp(self):
  VVKQR8 = []
  VVKQR8.append("/etc/hostname")
  VVKQR8.append("/etc/default_gw")
  VVKQR8.append("/etc/resolv.conf")
  VVKQR8.append("/etc/wpa_supplicant*.conf")
  VVKQR8.append("/etc/network/interfaces")
  VVKQR8.append("/etc/enigma2/nameserversdns.conf")
  FFeN7w(self, VVKQR8, "network_backup", addTimeStamp=True)
 def VVXzwg(self, fileName=None):
  if fileName:
   FFixrz(self, boundFunction(self.VVToeM, fileName), "Overwrite current channels ?")
 def VVToeM(self, fileName):
  path = "%s%s" % (VVNnjH, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCYAlZ.VVgOuj()
   lamedb5File, diabled5File = CCYAlZ.VVo3Ep()
   cmd = ""
   cmd += FFA9Vj("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFA9Vj("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFRfFm()
   if res == 0 : FFkpHN(self, "Channels Restored.")
   else  : FFcgS7(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFGmd5(self, path)
 def VVm0Kd(self, fileName=None):
  if fileName:
   FFixrz(self, boundFunction(self.VVznCY, fileName), "Overwrite SoftCAM files ?")
 def VVznCY(self, fileName):
  fileName = "%s%s" % (VVNnjH, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VV9gSb
   note = "You may need to restart your SoftCAM."
   FFx5U2(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFFlx3(note, VVg4jx), sep))
  else:
   FFGmd5(self, fileName)
 def VV5maJ(self, fileName=None):
  if fileName:
   FFixrz(self, boundFunction(self.VV22Da, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VV22Da(self, fileName):
  fileName = "%s%s" % (VVNnjH, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFLwr1(self,  cmd)
  else:
   FFGmd5(self, fileName)
 def VV1sKW(self, pattern, callBackFunction, isTuner=False):
  title = FFCSyQ()
  if pathExists(VVNnjH):
   myFiles = iGlob("%s%s" % (VVNnjH, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVKQR8 = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVKQR8.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVG5AR = ("Sat. List", self.VVzVih)
    else  : VVG5AR = None
    VVWQj7 = ("Delete File", self.VVDGb9)
    FFqaQ9(self, callBackFunction, title=title, VVlZjX=VVKQR8, VVG5AR=VVG5AR, VVWQj7=VVWQj7)
   else:
    FFcgS7(self, "No files found in:\n\n%s" % VVNnjH, title)
  else:
   FFcgS7(self, "Path not found:\n\n%s" % VVNnjH, title)
 def VVDGb9(self, VV2FRKObj, path):
  FFixrz(self, boundFunction(self.VV7L8g, VV2FRKObj, path), "Delete this file ?\n\n%s" % path)
 def VV7L8g(self, VV2FRKObj, path):
  path = VVNnjH + path
  os.system(FFA9Vj("rm -f '%s'" % path))
  if fileExists(path) : FFLk1N(VV2FRKObj, "Not deleted", 1000)
  else    : VV2FRKObj.VVlGAm()
 def VVhvxr(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCL7H9()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VVq7aj, filePrefix))
 def VVq7aj(self, filePrefix, result, retval):
  title = FFCSyQ()
  if pathExists(VVNnjH):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFcgS7(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVNnjH, filePrefix, FFdfSu())
    try:
     VVKQR8 = str(result.strip()).split()
     if VVKQR8:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVKQR8:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VV9gSb, FF0hQa(fName, VVg4jx), VV9gSb)
       FFn7o1(self, txt, title=title, VVuKKh=VVRjSm)
      else:
       FFcgS7(self, "File creation failed!", title)
     else:
      FFcgS7(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFA9Vj("rm %s" % fName))
     FFcgS7(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFA9Vj("rm %s" % fName))
     FFcgS7(self, "Error while writing file.")
  else:
   FFcgS7(self, "Path not found:\n\n%s" % VVNnjH, title)
 def VVkEoI(self, mode, path=None):
  if path:
   path = "%s%s" % (VVNnjH, path)
   if fileExists(path):
    lines = FFW1ru(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFixrz(self, boundFunction(self.VVshBN, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FF2vkZ(self, path, title=FFCSyQ())
   else:
    FFGmd5(self, path)
 def VVshBN(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVYqjI = []
  VVYqjI.append("echo -e 'Reading current settings ...'")
  VVYqjI.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVYqjI.append("echo -e 'Preparing new settings ...'")
  VVYqjI.append(settingsLines)
  VVYqjI.append("echo -e 'Applying new settings ...'")
  VVYqjI.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFWZYT(self, VVYqjI)
 def VVzVih(self, VV2FRKObj, path):
  if not path:
   return
  path = VVNnjH + path
  if not fileExists(path):
   FFGmd5(self, path)
   return
  txt = FFeIec(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVKQR8  = []
   for item in satList:
    VVKQR8.append("%s\t%s" % (item[0], FFJsjN(item[1])))
   FFn7o1(self, VVKQR8, title="  Satellites List")
  else:
   FFcgS7(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CC70XN(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF8X8q(VVycF3, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVlZjX = []
  VVlZjX.append(("Plugins Browser List"       , "VVObco"   ))
  VVlZjX.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVlZjX.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVlZjX.append(("Remove Packages (show all)"     , "VVz9TqsAll"   ))
  VVlZjX.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Update List of Available Packages"   , "VVXA3m"   ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Packaging Tool"        , "VVu7eB"    ))
  VVlZjX.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFNPyH(self, VVlZjX=VVlZjX)
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FFhGNA(self["myMenu"])
  FFwAWu(self)
 def VVEvnY(self):
  global VVWK7p
  VVWK7p = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVObco"   : self.VVObco()
   elif item == "pluginsMenus"     : self.VV8Qlo(0)
   elif item == "pluginsStartup"    : self.VV8Qlo(1)
   elif item == "pluginsDirList"    : self.VVw3V0()
   elif item == "downloadInstallPackages"  : FF1SeM(self, boundFunction(self.VVdbe3, 0, ""))
   elif item == "VVz9TqsAll"   : FF1SeM(self, boundFunction(self.VVdbe3, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FF1SeM(self, boundFunction(self.VVdbe3, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVXA3m"   : self.VVXA3m()
   elif item == "VVu7eB"    : self.VVu7eB()
   elif item == "packagesFeeds"    : self.VVEXBB()
   else          : self.close()
 def VVw3V0(self):
  extDirs  = FFtS24(VVggHj)
  sysDirs  = FFtS24(VVvV4V)
  VVKQR8  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVKQR8.append((item, VVggHj + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVKQR8.append((item, VVvV4V + item))
  if VVKQR8:
   VVKQR8 = sorted(VVKQR8, key=lambda x: x[0].lower())
   VVhD2a = ("Package Info.", self.VVh7q4, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FF1Vl3(self, None, header=header, VVKQR8=VVKQR8, VVrZ8Z=widths, VVbh3O=28, VVhD2a=VVhD2a)
  else:
   FFcgS7(self, "Nothing found!")
 def VVh7q4(self, VVpjES, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVggHj) : loc = "extensions"
  elif path.startswith(VVvV4V) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVFy16(package)
  else:
   FFcgS7(self, "No info!")
 def VVEXBB(self):
  pkg = FFfVBP()
  if pkg : FFovqt(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFMiwh(self)
 def VVObco(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVPdAh(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VV9gSb + "\n"
    txt += VVPdAh("Number"   , str(c))
    txt += VVPdAh("Name"   , FF0hQa(str(p.name), VVg4jx))
    txt += VVPdAh("Path"  , p.path  )
    txt += VVPdAh("Description" , p.description )
    txt += VVPdAh("Icon"  , p.iconstr  )
    txt += VVPdAh("Wakeup Fnc" , p.wakeupfnc )
    txt += VVPdAh("NeedsRestart", p.needsRestart)
    txt += VVPdAh("Internal" , p.internal )
    txt += VVPdAh("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFn7o1(self, txt)
 def VV8Qlo(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVKQR8 = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVKQR8.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVKQR8:
   VVKQR8.sort(key=lambda x: x[0].lower())
   header  = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths  = (19  , 25 , 20  , 27   , 9  )
   FF1Vl3(self, None, title=title, header=header, VVKQR8=VVKQR8, VVrZ8Z=widths, VVbh3O=26)
  else:
   FFcgS7(self, "Nothing Found", title=title)
 def VVXA3m(self):
  cmd = FFWjY7(VV6NZu, "")
  if cmd : FFLwr1(self, cmd, checkNetAccess=True)
  else : FFMiwh(self)
 def VVu7eB(self):
  pkg = FFfVBP()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFkpHN(self, txt)
 def VVdbe3(self, mode, grep, VVpjES=None, title=""):
  if   mode == 0: cmd = FFWjY7(VVboDa    , grep)
  elif mode == 1: cmd = FFWjY7(VVKJja , grep)
  elif mode == 2: cmd = FFWjY7(VVKJja , grep)
  if not cmd:
   FFMiwh(self)
   return
  VVXJa5 = FFfDK7(cmd)
  if not VVXJa5:
   if VVpjES: VVpjES.VVgLcP()
   FFcgS7(self, "No packages found!")
   return
  elif len(VVXJa5) == 1 and VVXJa5[0] == VVnT2K:
   FFcgS7(self, VVnT2K)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVKQR8  = []
  for item in VVXJa5:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVKQR8.append((name, package, version))
  if mode > 0:
   extensions = FFfDK7("ls %s -l | grep '^d' | awk '{print $9}'" % VVggHj)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVKQR8:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVKQR8.append((name, VVggHj + item, "-"))
   systemPlugins = FFfDK7("ls %s -l | grep '^d' | awk '{print $9}'" % VVvV4V)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVKQR8:
      if item.lower() == row[0].lower():
       break
     else:
      VVKQR8.append((item, VVvV4V + item, "-"))
  if not VVKQR8:
   FFcgS7(self, "No packages found!")
   return
  if VVpjES:
   VVKQR8.sort(key=lambda x: x[0].lower())
   VVpjES.VV3EJ0(VVKQR8, title)
  else:
   widths = (20, 50, 30)
   VVx7qK = None
   VV1php = None
   if mode == 0:
    VVyKSB = ("Install" , self.VVYM8n   , [])
    VVx7qK = ("Download" , self.VVnwRb   , [])
    VV1php = ("Filter"  , self.VV4vJT , [])
   elif mode == 1:
    VVyKSB = ("Uninstall", self.VVz9Tq, [])
   elif mode == 2:
    VVyKSB = ("Uninstall", self.VVz9Tq, [])
    widths= (18, 57, 25)
   VVKQR8 = sorted(VVKQR8, key=lambda x: x[0].lower())
   VVhD2a = ("Package Info.", self.VVc3e0, [])
   header   = ("Name" ,"Package" , "Version" )
   FF1Vl3(self, None, header=header, VVKQR8=VVKQR8, VVrZ8Z=widths, VVbh3O=28, VVyKSB=VVyKSB, VVx7qK=VVx7qK, VVhD2a=VVhD2a, VV1php=VV1php, VVdlpd=self.lastSelectedRow
     , VVmxJZ="#22110011", VVEDc7="#22191111", VVc1Ml="#22191111", VVZoDW="#00003030", VVwpfj="#00333333")
 def VVc3e0(self, VVpjES, title, txt, colList):
  package = colList[1]
  self.VVFy16(package)
 def VV4vJT(self, VVpjES, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVlZjX = []
  VVlZjX.append(("All Packages", "all"))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVlZjX.append(VVZYy7)
  for word in words:
   VVlZjX.append((word, word))
  FFqaQ9(self, boundFunction(self.VVJTLw, VVpjES), VVlZjX=VVlZjX, title="Select Filter")
 def VVJTLw(self, VVpjES, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FF1SeM(VVpjES, boundFunction(self.VVdbe3, 0, grep, VVpjES, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVz9Tq(self, VVpjES, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVggHj, VVvV4V)):
   FFixrz(self, boundFunction(self.VVsGYH, VVpjES, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVlZjX = []
   VVlZjX.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVlZjX.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVlZjX.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFqaQ9(self, boundFunction(self.VVT0PZ, VVpjES, package), VVlZjX=VVlZjX)
 def VVsGYH(self, VVpjES, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VV5iXK)
  FFLwr1(self, cmd, VVnq9X=boundFunction(self.VVMkDK, VVpjES))
 def VVT0PZ(self, VVpjES, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VV6CjH
   elif item == "remove_ForceRemove"  : cmdOpt = VV1bXh
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVgRfs
   FFixrz(self, boundFunction(self.VVIVSp, VVpjES, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVIVSp(self, VVpjES, package, cmdOpt):
  self.lastSelectedRow = VVpjES.VV7oaa()
  cmd = FFlY7a(cmdOpt, package)
  if cmd : FFLwr1(self, cmd, VVnq9X=boundFunction(self.VVMkDK, VVpjES))
  else : FFMiwh(self)
 def VVMkDK(self, VVpjES):
  VVpjES.cancel()
  FFfRw4()
 def VVYM8n(self, VVpjES, title, txt, colList):
  package  = colList[1]
  VVlZjX = []
  VVlZjX.append(("Install Package"         , "install_CheckVersion" ))
  VVlZjX.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVlZjX.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VVlZjX.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVlZjX.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFqaQ9(self, boundFunction(self.VVuoYS, package), VVlZjX=VVlZjX)
 def VVuoYS(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VV3kNP
   elif item == "install_ForceReinstall" : cmdOpt = VVFpOM
   elif item == "install_ForceOverwrite" : cmdOpt = VVDZdr
   elif item == "install_ForceDowngrade" : cmdOpt = VVsUnv
   elif item == "install_IgnoreDepends" : cmdOpt = VVGLms
   FFixrz(self, boundFunction(self.VVKneF, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVKneF(self, package, cmdOpt):
  cmd = FFlY7a(cmdOpt, package)
  if cmd : FFLwr1(self, cmd, VVnq9X=FFfRw4, checkNetAccess=True)
  else : FFMiwh(self)
 def VVnwRb(self, VVpjES, title, txt, colList):
  package  = colList[1]
  FFixrz(self, boundFunction(self.VVtnEi, package), "Download Package ?\n\n%s" % package)
 def VVtnEi(self, package):
  if FFLgxI():
   cmd = FFlY7a(VVzK8Y, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFFlx3(success, VVeO4o))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFFlx3(fail, VVahL2))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFLwr1(self, cmd, VVup5x=[VVahL2, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFMiwh(self)
  else:
   FFcgS7(self, "No internet connection !")
 def VVFy16(self, package):
  infoCmd  = FFlY7a(VV7MAA, package)
  filesCmd = FFlY7a(VVJjw0, package)
  listInstCmd = FFWjY7(VVKJja, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFNyBL(VVg4jx)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFFlx3(notInst, VVaqQK))
   cmd += "else "
   cmd +=   FFP3Rx("System Info", VVg4jx)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFP3Rx("Related Files", VVg4jx)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFWNH3(self, cmd)
  else:
   FFMiwh(self)
class CCYAlZ(Screen):
 VVkfdR  = 0
 VVrst5 = 1
 VVDWXV  = 2
 VV3xrF  = 3
 VVrxQ8 = 4
 VVh2ac = 5
 VVMQKM = 6
 def __init__(self, session):
  self.skin, self.skinParam = FF8X8q(VVycF3, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVvxJY = None
  self.lastfilterUsed  = None
  VVlZjX = self.VVpexA()
  FFNPyH(self, VVlZjX=VVlZjX, title="Services/Channels")
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self["myMenu"].setList(self.VVpexA())
  FFhGNA(self["myMenu"])
  FFwAWu(self)
 def VVpexA(self):
  VVlZjX = []
  VVlZjX.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VVlZjX.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Services (Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVlZjX.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVlZjX.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVlZjX.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVlZjX.append(("Services with PIcons for the System"  , "VVvuSS"     ))
  VVlZjX.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVlZjX.append(VVZYy7)
  lamedbFile, disabledFile = CCYAlZ.VVgOuj()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVlZjX.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVlZjX.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVlZjX.append(("Reset Parental Control Settings"   , "VVv3z0"    ))
  VVlZjX.append(("Delete Channels with no names"   , "VV3IFh"    ))
  VVlZjX.append(('Export Services to "channels.xml"'  , "VVNq9C"      ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Reload Channels and Bouquets"    , "VVlvTI"      ))
  return VVlZjX
 def VVEvnY(self):
  global VVWK7p
  VVWK7p = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFbhRG(self)
   elif item == "currentServiceInfo"     : FFqUR7(self, fncMode=CC6WQp.VVJ0jF)
   elif item == "TranspondersStats"     : FF1SeM(self, self.VVcA5O     )
   elif item == "lameDB_allChannels_with_refCode"  : FF1SeM(self, self.VVn3n6 )
   elif item == "lameDB_allChannels_with_tranaponder" : FF1SeM(self, self.VVh0Ql)
   elif item == "lameDB_allChannels_with_details"  : FF1SeM(self, self.VV3ghU )
   elif item == "parentalControlChannels"    : FF1SeM(self, self.VVJiQp   )
   elif item == "showHiddenChannels"     : FF1SeM(self, self.VV7plv     )
   elif item == "VVvuSS"     : FF1SeM(self, self.VVutqg     )
   elif item == "servicesWithMissingPIcons"   : FF1SeM(self, self.VV5KlI   )
   elif item == "enableHiddenChannels"     : self.VVzknF(True)
   elif item == "disableHiddenChannels"    : self.VVzknF(False)
   elif item == "VVv3z0"    : FFixrz(self, self.VVv3z0, "Reset and Restart ?" )
   elif item == "VV3IFh"    : FF1SeM(self, self.VV3IFh)
   elif item == "VVNq9C"      : self.VVNq9C()
   elif item == "VVlvTI"      : FF1SeM(self, boundFunction(CCYAlZ.VVlvTI, self))
   else            : self.close()
 def VVNq9C(self):
  VVlZjX = []
  VVlZjX.append(("All Sat/C/T Services", "all"))
  VVlZjX.append(("--[ BOUQUETS ]" + "-" * 100, ))
  bouquets = FFojgY()
  if bouquets:
   for item in bouquets:
    VVlZjX.append((item[0], item[1].toString()))
  FFqaQ9(self, self.VVVWBp, VVlZjX=VVlZjX, title="", VVsug5=True)
 def VVVWBp(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCYAlZ.VV6Q6P("1:7:")
   else   : lst = FFjNff(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFru8i(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFS5Go(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FFRZql(CFG.exportedTablesPath.getValue()), FFdfSu())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FFkpHN(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFLk1N(self, "No Services found !", 1500)
 @staticmethod
 def VVlvTI(SELF):
  FFRfFm()
  FFkpHN(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVn3n6(self):
  self.VVvxJY = None
  self.lastfilterUsed  = None
  self.filterObj   = CCPqp9(self)
  VVXJa5 = CCYAlZ.VV8ipk(self, self.VVkfdR)
  if VVXJa5:
   VVXJa5.sort(key=lambda x: x[0].lower())
   VVxwOk  = ("Zap"   , self.VVuJe1     , [])
   VVsbBT = (""    , self.VV0Ypx   , [])
   VVhD2a = ("Options"  , self.VVlkCV , [])
   VVx7qK = ("Current Service", self.VVVVME , [])
   VV1php = ("Filter"   , self.VVKTw5  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVDhPS  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FF1Vl3(self, None, header=header, VVKQR8=VVXJa5, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=26, VVxwOk=VVxwOk, VVsbBT=VVsbBT, VVx7qK=VVx7qK, VVhD2a=VVhD2a, VV1php=VV1php)
 def VVh0Ql(self):
  self.VVvxJY = None
  self.lastfilterUsed  = None
  self.filterObj   = CCPqp9(self)
  VVXJa5 = CCYAlZ.VV8ipk(self, self.VVrst5)
  if VVXJa5:
   VVXJa5.sort(key=lambda x: x[0].lower())
   VVxwOk  = ("Zap"   , self.VVuJe1      , [])
   VVsbBT = (""    , self.VV0Ypx    , [])
   VVx7qK = ("Current Service", self.VVVVME  , [])
   VVhD2a = ("Options"  , self.VV9DTF , [])
   VV1php = ("Filter"   , self.VVaymo  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVDhPS  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FF1Vl3(self, None, header=header, VVKQR8=VVXJa5, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=26, VVxwOk=VVxwOk, VVsbBT=VVsbBT, VVx7qK=VVx7qK, VVhD2a=VVhD2a, VV1php=VV1php)
 def VVlkCV(self, VVpjES, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel  = CCTy7H(self, VVpjES, 3)
  mSel.VVrlyn(servName, refCode, pcState, hidState)
 def VV9DTF(self, VVpjES, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CCTy7H(self, VVpjES, 3)
  mSel.VVul6f(servName, refCode)
 def VVDhAk(self, VVpjES, refCode, isAddToBlackList):
  VVpjES.VVRuBW("Processing ...")
  FF3K6t(boundFunction(self.VVTNBQ, VVpjES, [refCode], isAddToBlackList))
 def VVmK2P(self, VVpjES, isAddToBlackList):
  refCodeList = VVpjES.VVqRoL(3)
  if not refCodeList:
   FFcgS7(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVpjES.VVRuBW("Processing ...")
  FF3K6t(boundFunction(self.VVTNBQ, VVpjES, refCodeList, isAddToBlackList))
 def VVTNBQ(self, VVpjES, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVWVDT, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVWVDT):
   lines = FFW1ru(VVWVDT)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVWVDT, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVpjES.VVZkVN
   if isMulti:
    self.VVEP3z(VVpjES, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVskse(VVpjES, refCode)
    VVpjES.VVgLcP()
  else:
   VVpjES.VVLvlZ("No changes")
 def VVOjxm(self, VVpjES, refCode, isHide):
  title = "Change Hidden State"
  if FFDNNZ(refCode):
   VVpjES.VVRuBW("Processing ...")
   ret = FF0zlK(refCode, isHide)
   if ret : FF1SeM(self, boundFunction(self.VVskse, VVpjES, refCode))
   else : FFcgS7(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFcgS7(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVskse(self, VVpjES, refCode):
  VVXJa5 = CCYAlZ.VV8ipk(self, self.VVkfdR, VVJjHU=[3, [refCode], False])
  done = False
  if VVXJa5:
   data = VVXJa5[0]
   if data[3] == refCode:
    done = VVpjES.VVocRR(data)
  if not done:
   self.VVPce5(VVpjES, VVpjES.VVbfvv(), self.VVkfdR)
  VVpjES.VVgLcP()
 def VVEP3z(self, VVpjES, totRefCodes):
  VVXJa5 = CCYAlZ.VV8ipk(self, self.VVkfdR, VVJjHU=self.VVvxJY)
  VVpjES.VV3EJ0(VVXJa5)
  VVpjES.VVLcVH(False)
  VVpjES.VVLvlZ("%d Processed" % totRefCodes)
 def VVV6eY(self, VVpjES, isHide):
  refCodeList = VVpjES.VVqRoL(3)
  if not refCodeList:
   FFcgS7(self, "Nothing selected", title="Change Hidden State")
   return
  VVpjES.VVRuBW("Processing ...")
  FF3K6t(boundFunction(self.VVyeSG, VVpjES, refCodeList, isHide))
 def VVyeSG(self, VVpjES, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FF0zlK(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   db = eDVBDB.getInstance()
   if db:
    db.saveServicelist()
    db.reloadServicelist()
    db.reloadBouquets()
   self.VVEP3z(VVpjES, len(refCodeList))
  else:
   VVpjES.VVLvlZ("No changes")
 def VVKTw5(self, VVpjES, title, txt, colList):
  self.filterObj.VV1RlU(1, VVpjES, 2, boundFunction(self.VV8vT0, VVpjES))
 def VV8vT0(self, VVpjES, item):
  self.VVtF6i(VVpjES, item, 2, self.VVkfdR)
 def VVaymo(self, VVpjES, title, txt, colList):
  self.filterObj.VV1RlU(2, VVpjES, 4, boundFunction(self.VV6lHk, VVpjES))
 def VV6lHk(self, VVpjES, item):
  self.VVtF6i(VVpjES, item, 4, self.VVrst5)
 def VVMjbK(self, VVpjES, title, txt, colList):
  self.filterObj.VV1RlU(0, VVpjES, 4, boundFunction(self.VV0kXH, VVpjES))
 def VV0kXH(self, VVpjES, item):
  self.VVtF6i(VVpjES, item, 4, self.VVDWXV)
 def VVtF6i(self, VVpjES, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVpjES.VVvMZR(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVvxJY = None
  else:
   words, asPrefix = CCPqp9.VVn2jm(words)
   self.VVvxJY = [col, words, asPrefix]
  if words: FF1SeM(self, boundFunction(self.VVPce5, VVpjES, title, mode), title="Reading Services ...")
  else : FFLk1N(VVpjES, "Incorrect filter", 2000)
 def VVPce5(self, VVpjES, title, mode):
  VVXJa5 = CCYAlZ.VV8ipk(self, mode, VVJjHU=self.VVvxJY, VVuW8O=False)
  if VVXJa5:
   VVXJa5.sort(key=lambda x: x[0].lower())
   VVpjES.VV3EJ0(VVXJa5, title)
  else:
   VVpjES.VVgLcP()
   FFLk1N(VVpjES, "Not found!", 1500)
 def VVMUKd(self, VVKQR8, VVxwOk=None, VVsbBT=None, VVyKSB=None, VVx7qK=None, VVhD2a=None, VV1php=None):
  VVx7qK = ("Current Service", self.VVVVME, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVDhPS = (LEFT  , LEFT  , CENTER, LEFT    )
  FF1Vl3(self, None, header=header, VVKQR8=VVKQR8, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=26, VVxwOk=VVxwOk, VVsbBT=VVsbBT, VVyKSB=VVyKSB, VVx7qK=VVx7qK, VVhD2a=VVhD2a, VV1php=VV1php)
 def VVVVME(self, VVpjES, title, txt, colList):
  self.VVe0XV(VVpjES)
 def VVwn8C(self, VVpjES, title, txt, colList):
  self.VVe0XV(VVpjES, True)
 def VVe0XV(self, VVpjES, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVpjES.VVLOwP(colDict, VVuqoX=True)
   else:
    VVpjES.VVkrJW(3, refCode, True)
   return
  FFcgS7(self, "Colud not read current Reference Code !")
 def VV3ghU(self):
  self.VVvxJY = None
  self.lastfilterUsed  = None
  self.filterObj   = CCPqp9(self)
  VVXJa5 = CCYAlZ.VV8ipk(self, self.VVDWXV)
  if VVXJa5:
   VVXJa5.sort(key=lambda x: x[0].lower())
   VVsbBT = (""    , self.VVQMOP , []      )
   VVx7qK = ("Current Service", self.VVwn8C  , []      )
   VV1php = ("Filter"   , self.VVMjbK   , [], "Loading Filters ..." )
   VVxwOk  = ("Zap"   , self.VVSoe1      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVDhPS  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FF1Vl3(self, None, header=header, VVKQR8=VVXJa5, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=26, VVxwOk=VVxwOk, VVsbBT=VVsbBT, VVx7qK=VVx7qK, VV1php=VV1php)
 def VVQMOP(self, VVpjES, title, txt, colList):
  refCode  = self.VV7Cas(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFqUR7(self, fncMode=CC6WQp.VVgF7T, refCode=refCode, chName=chName, text=txt)
 def VVSoe1(self, VVpjES, title, txt, colList):
  refCode = self.VV7Cas(colList)
  FFvYTu(self, refCode)
 def VVuJe1(self, VVpjES, title, txt, colList):
  FFvYTu(self, colList[3])
 def VV7Cas(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VV8ipk(SELF, mode, VVJjHU=None, VVuW8O=True, VVDRQS=True):
  lamedbFile, disabledFile = CCYAlZ.VVgOuj()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVJjHU:
    filterCol = VVJjHU[0]
    filterWords = VVJjHU[1]
    asPrefix = VVJjHU[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCYAlZ.VVkfdR:
    blackList = None
    if fileExists(VVWVDT):
     blackList = FFW1ru(VVWVDT)
     if blackList:
      blackList = set(blackList)
   elif mode == CCYAlZ.VVrst5:
    tp = CC37SE()
   VVzNl1, VVsqeV = FFigNV()
   tagFound  = False
   if mode in (CCYAlZ.VVh2ac, CCYAlZ.VVMQKM):
    VVXJa5 = {}
   else:
    VVXJa5 = []
   with ioOpen(lamedbFile, "r", encoding="utf-8") as f:
    lines = []
    for line in f:
     line = str(line).strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFMf9K(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CCYAlZ.VVDWXV:
        if sTypeInt in VVzNl1:
         STYPE = VVsqeV[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVXJa5.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVXJa5.append(tRow)
        else:
         VVXJa5.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCYAlZ.VVh2ac:
         VVXJa5[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCYAlZ.VVMQKM:
         VVXJa5[chName] = refCode
        elif mode == CCYAlZ.VVkfdR:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVXJa5.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVXJa5.append(tRow)
         else:
          VVXJa5.append(tRow)
        elif mode == CCYAlZ.VVrst5:
         if sTypeInt in VVzNl1:
          STYPE = VVsqeV[sTypeInt]
         freq, pol, fec, sr, syst = tp.VVS5CI(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVXJa5.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVXJa5.append(tRow)
         else:
          VVXJa5.append(tRow)
        elif mode == CCYAlZ.VV3xrF:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VVXJa5.append((chName, chProv, sat, refCode))
        elif mode == CCYAlZ.VVrxQ8:
         VVXJa5.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VVXJa5 and VVuW8O:
    FFcgS7(SELF, "No services found!")
   return VVXJa5
  else:
   if VVDRQS:
    FFGmd5(SELF, lamedbFile)
   return None
 def VVJiQp(self):
  if fileExists(VVWVDT):
   lines = FFW1ru(VVWVDT)
   if lines:
    newRows  = []
    VVXJa5 = CCYAlZ.VV8ipk(self, self.VVrxQ8)
    if VVXJa5:
     lines = set(lines)
     for item in VVXJa5:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVXJa5 = newRows
      VVXJa5.sort(key=lambda x: x[0].lower())
      VVsbBT = ("", self.VV0Ypx, [])
      VVxwOk = ("Zap", self.VVuJe1, [])
      self.VVMUKd(VVKQR8=VVXJa5, VVxwOk=VVxwOk, VVsbBT=VVsbBT)
     else:
      FFn7o1(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVXJa5)))
   else:
    FFkpHN(self, "No active Parental Control services.", FFCSyQ())
  else:
   FFGmd5(self, VVWVDT)
 def VV7plv(self):
  VVXJa5 = CCYAlZ.VV8ipk(self, self.VV3xrF)
  if VVXJa5:
   VVXJa5.sort(key=lambda x: x[0].lower())
   VVsbBT = ("" , self.VV0Ypx, [])
   VVxwOk  = ("Zap", self.VVuJe1, [])
   self.VVMUKd(VVKQR8=VVXJa5, VVxwOk=VVxwOk, VVsbBT=VVsbBT)
  else:
   FFkpHN(self, "No hidden services.", FFCSyQ())
 def VVcA5O(self):
  totT, totC, totA, totS, totS2, satList = self.VVGWOe()
  txt = FF0hQa("Total Transponders:\n\n", VV3UWE)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FF0hQa("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VV3UWE)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFyqHT(item), satList.count(item))
  FFn7o1(self, txt)
 def VVGWOe(self):
  lamedbFile, disabledFile = CCYAlZ.VVgOuj()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with ioOpen(lamedbFile, "r", encoding="utf-8") as f:
    lines = []
    for line in f:
     line = str(line).strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFGmd5(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VVutqg(self)   : self.VVvuSS(True)
 def VV5KlI(self) : self.VVvuSS(False)
 def VVvuSS(self, isWithPIcons):
  piconsPath = CCwdjc.VVW1YO()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCwdjc.VVDSPs(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVXJa5 = CCYAlZ.VV8ipk(self, self.VVrxQ8)
    if VVXJa5:
     channels = []
     for (chName, chProv, sat, refCode) in VVXJa5:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFZv6x(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVXJa5)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVPdAh(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVPdAh("PIcons Path"  , piconsPath)
     txt += VVPdAh("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVPdAh("Total services" , totalServices)
     txt += VVPdAh("With PIcons"  , totalWithPIcons)
     txt += VVPdAh("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFn7o1(self, txt)
     else:
      VVsbBT     = (""      , self.VV0Ypx , [])
      if isWithPIcons : VV1php = ("Export Current PIcon", self.VVr4pG  , [])
      else   : VV1php = None
      VVhD2a     = ("Statistics", FFn7o1, [txt])
      VVxwOk      = ("Zap", self.VVuJe1, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVMUKd(VVKQR8=channels, VVxwOk=VVxwOk, VVsbBT=VVsbBT, VVhD2a=VVhD2a, VV1php=VV1php)
   else:
    FFcgS7(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFcgS7(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VV0Ypx(self, VVpjES, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFqUR7(self, fncMode=CC6WQp.VVgF7T, refCode=refCode, chName=chName, text=txt)
 def VVr4pG(self, VVpjES, title, txt, colList):
  png, path = CCwdjc.VVy4tq(colList[3], colList[0])
  if path:
   CCwdjc.VV5Val(self, png, path)
 @staticmethod
 def VVgOuj():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVo3Ep():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVzknF(self, isEnable):
  lamedbFile, disabledFile = CCYAlZ.VVgOuj()
  if isEnable and not fileExists(disabledFile):
   FFkpHN(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FFcgS7(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFixrz(self, boundFunction(self.VVz5uU, isEnable), "%s Hidden Channels ?" % word)
 def VVz5uU(self, isEnable):
  lamedbFile , disabledFile = CCYAlZ.VVgOuj()
  lamedb5File, diabled5File = CCYAlZ.VVo3Ep()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FFRfFm()
  if res == 0 : FFkpHN(self, "Hidden List %s" % word)
  else  : FFcgS7(self, "Error while restoring:\n\n%s" % fileName)
 def VVv3z0(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFWZYT(self, cmd)
 def VV3IFh(self):
  lamedbFile, disabledFile = CCYAlZ.VVgOuj()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFA9Vj("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFW1ru(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFA9Vj("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FFRfFm()
   FFn7o1(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFGmd5(self, lamedbFile)
 @staticmethod
 def VV6Q6P(servTypes):
  VVaQEh  = eServiceCenter.getInstance()
  VVuhdf   = '%s ORDER BY name' % servTypes
  VVcsxA   = eServiceReference(VVuhdf)
  VViIqO = VVaQEh.list(VVcsxA)
  if VViIqO: return VViIqO.getContent("CN", False)
  else     : return []
class CC6WQp(Screen):
 VVJ0jF  = 0
 VVjHf0   = 1
 VV6Poo   = 2
 VVgF7T    = 3
 VVIMd0    = 4
 VVqm9R   = 5
 VV4N6S   = 6
 VVCrG7    = 7
 VV5Qo4   = 8
 VVUeMj   = 9
 VVxpJX   = 10
 VV3eY6   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FF8X8q(VVMlUC, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVJ0jF)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FF0hQa("%s\n", VVZERI) % VV9gSb
  self.picViewer  = None
  FFNPyH(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVVduH })
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVYZus)
  self.onClose.append(self.onExit)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  self["myLabel"].VVBS02(textOutFile="chann_info")
  if   self.fncMode == self.VVJ0jF : fnc = self.VVBzyk_VVJ0jF
  elif self.fncMode == self.VVjHf0  : fnc = self.VVBzyk_VVJ0jF
  elif self.fncMode == self.VV6Poo  : fnc = self.VVBzyk_VVJ0jF
  elif self.fncMode == self.VVgF7T  : fnc = self.VVBzyk_VVgF7T
  elif self.fncMode == self.VVIMd0  : fnc = self.VVBzyk_VVIMd0
  elif self.fncMode == self.VVqm9R  : fnc = self.VVBzyk_VVqm9R
  elif self.fncMode == self.VV4N6S  : fnc = self.VVBzyk_VV4N6S
  elif self.fncMode == self.VVCrG7  : fnc = self.VVBzyk_VVCrG7
  elif self.fncMode == self.VV5Qo4  : fnc = self.VVBzyk_VV5Qo4
  elif self.fncMode == self.VVUeMj : fnc = self.VVBzyk_VVUeMj
  elif self.fncMode == self.VVxpJX  : fnc = self.VVBzyk_VVxpJX
  elif self.fncMode == self.VV3eY6 : fnc = self.VVBzyk_VV3eY6
  self["myLabel"].setText("\n   Reading Info ...")
  FF3K6t(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVZcPZ()
 def VVyG2k(self, err):
  self["myLabel"].setText(err)
  FFxTkM(self["myTitle"], "#22200000")
  FFxTkM(self["myBody"], "#22200000")
  self["myLabel"].FFxTkMColor("#22200000")
  self["myLabel"].VVmP3I()
 def VVBzyk_VVJ0jF(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self)
  self.refCode = refCode
  self.VVPhWF(chName)
 def VVBzyk_VVgF7T(self):
  self.VVPhWF(self.chName)
 def VVBzyk_VVIMd0(self):
  self.VVPhWF(self.chName)
 def VVBzyk_VVqm9R(self):
  self.VVPhWF(self.chName)
 def VVBzyk_VV4N6S(self):
  self.VVPhWF("Picon Info")
 def VVBzyk_VVCrG7(self):
  self.VVPhWF(self.chName)
 def VVBzyk_VV5Qo4(self):
  self.VVPhWF(self.chName)
 def VVBzyk_VVUeMj(self):
  self.VVPhWF(self.chName)
 def VVBzyk_VVxpJX(self):
  self.chUrl = self.refCode + self.callingSELF.VVLkPg(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVPhWF(self.chName)
 def VVBzyk_VV3eY6(self):
  self.VVPhWF(self.chName)
 def VVPhWF(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FF7qBd(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVLTav(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FF0hQa(self.VVQbiz(tUrl), VV7bzw)
  if not self.epg:
   epg = self.VVwQKx(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VV9pId(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCwdjc.VVy4tq(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VV9pId(path)
  self.VVr30k()
  self.VV9cAZ()
  self["myLabel"].setText(self.text, VVuKKh=VVKyDE)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVmP3I(minHeight=minH)
 def VV9cAZ(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFS5Go(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVU2gN(FFAhi4(url))
  if epg:
   self.text += "\n" + FFiu6i("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVr30k()
 def VVr30k(self):
  if not self.piconShown and self.picUrl:
   path, err = FFDt8N(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VV9pId(path)
    if self.piconShown and self.refCode:
     self.VVzu6Y(path, self.refCode)
 def VVzu6Y(self, path, refCode):
  if path and fileExists(path) and os.system(FFA9Vj("which ffmpeg")) == 0:
   pPath = CCwdjc.VVW1YO()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
    cmd += FFA9Vj("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VV9pId(self, path):
  if path and fileExists(path):
   err, w, h = self.VVBSpW(path)
   if not err:
    if h > w:
     self.VV3FHw(self["myPicF"], w, h, True)
     self.VV3FHw(self["myPic"] , w, h, False)
   self.picViewer = CCvUQZ.VV3C0T(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VV3FHw(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVBSpW(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFmclR(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVLTav(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FF0hQa(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVPdAh(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FF0hQa(state, VVaqQK)
   txt += "State\t: %s\n" % state
  w = FFplQi(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFplQi(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVOt7u(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVPdAh(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVPdAh(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVPdAh(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVfnO4()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVohnH()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CC6WQp.VVfVcc(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FF0hQa("IPTV", VV3UWE)
   txt += self.VVx4CA(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVtHOh(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CC37SE()
    tpTxt, namespace = tp.VVxRXm(refCode)
    del tp
    if tpTxt:
     txt += FF0hQa("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FF0hQa("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVPdAh(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVPdAh(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVPdAh(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVPdAh(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVPdAh(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVPdAh(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVPdAh(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVPdAh(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVPdAh(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVOt7u(info):
  if info:
   aspect = FFplQi(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVPdAh(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFplQi(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VV16ZV(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VV16ZV(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVfnO4(self):
  try:
   service = self.session.nav.getCurrentService()
   audio = service and service.audioTracks()
   return audio and audio.getNumberOfTracks() or 0
  except:
   pass
  return -1
 def VVohnH(self):
  try:
   service   = self.session.nav.getCurrentService()
   subtitle  = service and service.subtitle()
   subtitlelist = subtitle and subtitle.getSubtitleList()
   return len(subtitlelist)
  except:
   pass
  return -1
 def VVtHOh(self, refCode, iptvRef, chName):
  refCode = FFW7yf(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFeIec(VVf9y4 + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFeIec(VVf9y4 + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VVKQR8 = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVf9y4 + item
   if fileExists(path):
    txt = FFeIec(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVKQR8.append(bName)
  txt = self.Sep
  if VVKQR8:
   if len(VVKQR8) == 1:
    txt += "%s\t: %s\n" % (FF0hQa("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VVKQR8[0])
   else:
    txt += FF0hQa("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VVKQR8):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVwQKx(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVXha2(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVXha2(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVXha2(event, 0)
     except:
      pass
  return epg
 def VVXha2(self, event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CC6WQp.VV5KEM(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = self.VVSLXI(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FF0hQa(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FF0hQa(evNameTransl, COLOR_CONS_BRIGHT_YELLOW))
    if evTime           : txt += "Start Time\t: %s\n" % FFscD6(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFscD6(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFgN2Y(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFgN2Y(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFgN2Y(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FF0hQa(evShort, VVzeuF)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FF0hQa(evDesc , VVzeuF)
    if txt:
     txt = FF0hQa("\n%s\n%s Event:\n%s\n" % (VV9gSb, ("Current", "Next")[evNum], VV9gSb), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVx4CA(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFvST6(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCIsu8()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV9sXV(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FF0hQa("URL:", VV3UWE) + "\n%s\n" % self.VVQbiz(decodedUrl)
  else:
   txt = "\n"
   txt += FF0hQa("Reference:", VV3UWE) + "\n%s\n" % refCode
  return txt
 def VVQbiz(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVIUAA:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VVU2gN(self, decodedUrl):
  if not FFLgxI():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CC4M3v.VVMlKY(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CC4M3v.VVSLDf(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVGLlR(tDict)
   elif uType == "movie" : epg, picUrl = self.VVXHPP(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVGLlR(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CC4M3v.VVrtEf(item, "title"    , is_base64=True )
     lang    = CC4M3v.VVrtEf(item, "lang"         ).upper()
     description   = CC4M3v.VVrtEf(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CC4M3v.VVrtEf(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CC4M3v.VVrtEf(item, "start_timestamp"      )
     stop_timestamp  = CC4M3v.VVrtEf(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CC4M3v.VVrtEf(item, "stop_timestamp"       )
     now_playing   = CC4M3v.VVrtEf(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VV3rkc, ""
      else     : color, txt = VVaqQK , "    (CURRENT EVENT)"
      epg += FF0hQa("_" * 32 + "\n", VVZERI)
      epg += FF0hQa("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FF0hQa(description, VV7bzw)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVMRmW(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VVXHPP(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CC4M3v.VVrtEf(item, "movie_image" )
    genre  = CC4M3v.VVrtEf(item, "genre"   ) or "-"
    plot  = CC4M3v.VVrtEf(item, "plot"   ) or "-"
    cast  = CC4M3v.VVrtEf(item, "cast"   ) or "-"
    rating  = CC4M3v.VVrtEf(item, "rating"   ) or "-"
    director = CC4M3v.VVrtEf(item, "director"  ) or "-"
    releasedate = CC4M3v.VVrtEf(item, "releasedate" ) or "-"
    duration = CC4M3v.VVrtEf(item, "duration"  ) or "-"
    try:
     lang = CC4M3v.VVrtEf(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FF0hQa(cast, VV7bzw)
    epg += "Plot:\n%s"    % FF0hQa(self.VVSLXI(plot), VV7bzw)
   except:
    pass
  return epg, movie_image
 def VVSLXI(self, evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = self.VV0eg1(evTxt, lang)
   return CC6WQp.VVXRfH(txt).strip() or evTxt
 def VVVduH(self):
  if VVIUAA:
   def VVPdAh(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVPdAh(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCIsu8()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV9sXV(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVPdAh(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (VV9gSb, txt))
   FFLk1N(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVXRfH(txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VVlfBB(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CC6WQp.VV5KEM(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VV5KEM(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CC6WQp.VVwtZP(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VV0eg1(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFGlin(txt))
   txt, err = CC4M3v.VVSLDf(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFAhi4(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVMRmW(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
 @staticmethod
 def VVNlos(SELF):
  if not CCUxkq.VVEdgn(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(SELF)
  err = url =  fSize = resumable = ""
  if FFVVjP(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCIsu8.VVFwRF(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCIsu8.VVScCgHeader(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FFcgS7(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCs7ea.VVxfhW(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FF0hQa(" (M3U/M3U8 File)", VV7bzw)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCsRnB.VV4Zfe(resp) else "No"
   except requests.Timeout as e     : err = "Connection Timeout"
   except Exception as e       : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVOpU1(subj, val):
   return "%s\n%s\n\n" % (FF0hQa("%s:" % subj, COLOR_CONS_BRIGHT_YELLOW), val)
  title = "File Size"
  txt  = VVOpU1(title , fSize or "?")
  txt += VVOpU1("Name" , chName)
  txt += VVOpU1("URL" , url)
  if resumable: txt += VVOpU1("Supports Download-Resume", resumable)
  if err  : txt += FF0hQa("Error:\n", VVaqQK) + err
  FFn7o1(SELF, txt, title=title)
 @staticmethod
 def VVfVcc(SELF):
  fPath, fDir, fName = CCs7ea.VVhTh0(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg", "mvi"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVwtZP(event):
  genre = PR = ""
  try:
   genre  = CC6WQp.VVjleN(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CC6WQp.VV76TL(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VV76TL(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVjleN(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CC6WQp.VVvfJh()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVvfJh():
  path = VV05tg + "genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFeIec(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFeIec(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
class CCIsu8():
 def __init__(self):
  self.VV6ARo   = ""
  self.VVbM8z    = ""
  self.VV1yAd   = ""
  self.portal_moreAuthRand = ""
  self.portal_moreAuthMsg  = ""
  self.portal_moreAuthType = 0
  self.portal_php    = ""
  self.colored_user   = "#f#11ffffaa#User"
  self.colored_server   = "#f#11aaffff#Server"
 def VViUgY(self, url, mac, ph1="", VVuqoX=True):
  self.VV6ARo   = ""
  self.VVbM8z    = ""
  self.VV1yAd   = ""
  self.portal_moreAuthRand = ""
  self.portal_moreAuthMsg  = ""
  self.portal_moreAuthType = 0
  self.portal_php    = {"s": "/server/load.php", "p": "/portal.php"}.get(ph1, "")
  host = self.VVKI6y(url)
  if not host:
   if VVuqoX:
    self.VVuqoXor("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VV3qoa(mac)
  if not host:
   if VVuqoX:
    self.VVuqoXor("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VV6ARo = host
  self.VVbM8z  = mac
  return True
 def VVKI6y(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VV3qoa(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVv96A(self):
  res, err = self.VVuWhA(self.VVtSwf())
  urlPath = "/stalker_portal"
  if "404" in err and urlPath in self.VV6ARo:
   self.VV6ARo = self.VV6ARo.replace(urlPath, "")
   res, err = self.VVuWhA(self.VVtSwf())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CC4M3v.VVrtEf(tDict["js"], "token")
    rand  = CC4M3v.VVrtEf(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVxnfN(self, VVuqoX=True):
  if not self.portal_php:
   self.portal_php = self.VVNlBt()
  err = blkMsg = FFkpHNTxt = ""
  try:
   token, rand, err = self.VVv96A()
   if token:
    self.VV1yAd = token
    self.portal_moreAuthRand = rand
    if rand:
     self.portal_moreAuthType = 2
    prof, retTxt = self.VVFUrf(True)
    if prof:
     self.portal_moreAuthMsg = retTxt
     if "device_id mismatch" in retTxt:
      self.portal_moreAuthType = 3
      prof, retTxt = self.VVFUrf(False)
      if retTxt:
       self.portal_moreAuthMsg = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFkpHNTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFkpHNTxt: tErr += "\n%s" % FFkpHNTxt
  if VVuqoX:
   self.VVuqoXor(tErr)
  return "", "", tErr
 def VVNlBt(self):
  try:
   import requests
   res = requests.get("%s/c/xpcom.common.js" % self.VV6ARo, headers=CCIsu8.VVScCgHeader(), stream=True, timeout=2)
   if res.ok :
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       return span.group(1)
  except:
   pass
  return ""
 def VVFUrf(self, capMac):
  res, err = self.VVuWhA(self.VVs0vN(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CC4M3v.VVrtEf(tDict["js"], "block_%s" % word)
    FFkpHNTxt = CC4M3v.VVrtEf(tDict["js"], word)
    return tDict, FFkpHNTxt.strip() or blkMsg.strip()
   except Exception as e:
    pass
  return "", ""
 def VVs0vN(self, capMac):
  if self.portal_moreAuthMsg or self.portal_moreAuthRand:
   import hashlib
   if capMac: mac = self.VVbM8z.upper()
   else  : mac = self.VVbM8z.lower()
   macUtf8 = mac.encode('utf-8')
   sn = hashlib.md5(macUtf8).hexdigest().upper()[:13]
   Id = hashlib.sha256(macUtf8).hexdigest().upper()
   sig = hashlib.sha256((sn + mac).encode('utf-8')).hexdigest().upper()
   param  = ""
   param += "&sn=%s"   % sn
   param += "&device_id=%s" % Id
   param += "&device_id2=%s" % Id
   param += "&signature=%s" % sig
   param += '&auth_second_step=1'
   param += '&hw_version=2.17-IB-00&hw_version_2=62'
   param += '&metrics={"mac":"%s","sn":"%s","type":"STB","model":"MAG250","random":"%s"}' % (self.VVbM8z, sn, self.portal_moreAuthRand)
  else:
   param = ""
  return self.VVbQWV() + "type=stb&action=get_profile" + param
 def VVkkV9(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVuhAM()
  if len(rows) < 10:
   rows = self.VV8wqA()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VV6ARo ))
   rows.append(("MAC (from URL)" , self.VVbM8z ))
   rows.append(("Token"   , self.VV1yAd ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VVbM8z ))
   rows.append(("2", self.colored_server, "Host" , self.VV6ARo ))
   rows.append(("2", self.colored_server, "Token" , self.VV1yAd ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVJLp3(self, isPhp=True, VVuqoX=False):
  token, profile, tErr = self.VVxnfN(VVuqoX)
  if not token:
   return "", tErr
  m3u_Url = ""
  url = self.VVbRsS()
  res, err = self.VVuWhA(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CC4M3v.VVrtEf(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFGlin(span.group(2))
     pass1 = FFGlin(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, err
 def VVuhAM(self):
  m3u_Url, err = self.VVJLp3()
  rows = []
  if m3u_Url:
   res, err = self.VVuWhA(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFscD6(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFscD6(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VV8wqA(self):
  token, profile, tErr = self.VVxnfN()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFkuxS(val): val = FFrR0L(val.decode("UTF-8"))
     else     : val = self.VVbM8z
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFscD6(int(parts[1]))
      if parts[2] : ends = FFscD6(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFscD6(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVLkPg(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVxnfN(VVuqoX=False)
  if not token:
   return ""
  crLinkUrl = self.VVQ0El(mode, chCm, epNum, epId)
  res, err = self.VVuWhA(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CC4M3v.VVrtEf(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVbQWV(self):
  return self.VV6ARo + (self.portal_php or "/server/load.php") + "?"
 def VVtSwf(self):
  return self.VVbQWV() + "type=stb&action=handshake&token=&mac=%s" % self.VVbM8z
 def VVjxoo(self, mode):
  url = self.VVbQWV() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VV6iZ2(self, catID):
  return self.VVbQWV() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVIBr9(self, mode, catID, page):
  url = self.VVbQWV() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VV6h3c(self, mode, searchName, page):
  return self.VVbQWV() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VVU3F2(self, mode, catID):
  return self.VVbQWV() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVQ0El(self, mode, chCm, serCode, serId):
  url = self.VVbQWV() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=false" % (mode, chCm)
  return url
 def VVbRsS(self):
  return self.VVbQWV() + "type=itv&action=create_link"
 def VVImmn(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VV9uqR(catID, stID, chNum)
  query = self.VVks7u(mode, self.portal_php[1:2], FFTD0h(host), FFTD0h(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVks7u(self, mode, ph1, host, mac, serCode, serId, chCm):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VV9sXV(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVks7u(mode, ph1, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFrR0L(host)
  mac   = FFrR0L(mac)
  valid = False
  if self.VVKI6y(playHost) and self.VVKI6y(host) and self.VVKI6y(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVuWhA(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCIsu8.VVScCgHeader()
   if self.VV1yAd:
    headers["Authorization"] = "Bearer %s" % self.VV1yAd
   if useCookies : cookies = {"mac": self.VVbM8z, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok : return res, ""
   else  : err = "Err-%d : %s" % (res.status_code, res.reason or "Unknown")
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVk8TQ(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCIsu8.VVScCgHeader(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVScCgHeader():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVIOB8(host, mac, tType, action, keysList=[]):
  myPortal = CCIsu8()
  ph1 = "s"
  pref = "/portal.php" if par == "p" else "/server/load.php"
  ok = myPortal.VViUgY(host, mac, ph1)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVxnfN(VVuqoX=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s%s?type=%s&action=%s" % (host, ph1, tType, action)
  res, err = myPortal.VVuWhA(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VV43Np(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VV43Np(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVuqoXor(self, err, title="Portal Browser"):
  FFcgS7(self, str(err), title=title)
 def VVuB9i(self, mode):
  if   mode in ("itv"  , CC4M3v.VVpALX , CC4M3v.VVqCaD)  : return "Live"
  elif mode in ("vod"  , CC4M3v.VVl6y9 , CC4M3v.VVfGhP)  : return "VOD"
  elif mode in ("series" , CC4M3v.VVR64G , CC4M3v.VVxVCt) : return "Series"
  else                          : return "IPTV"
 def VVALvf(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVuB9i(mode), searchName)
 def VVDtY7(self, catchup=False):
  VVlZjX = []
  VVlZjX.append(("Live"    , "live"  ))
  VVlZjX.append(("VOD"    , "vod"   ))
  VVlZjX.append(("Series"   , "series"  ))
  if catchup:
   VVlZjX.append(VVZYy7)
   VVlZjX.append(("Catchup TV" , "catchup"  ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Account Info." , "accountInfo" ))
  return VVlZjX
 @staticmethod
 def VVfVR2(decodedUrl):
  m3u_Url = ""
  p = CCIsu8()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV9sXV(decodedUrl)
  if valid:
   ok = p.VViUgY(host, mac, ph1, VVuqoX=False)
   if ok:
    m3u_Url, err = p.VVJLp3(isPhp=False, VVuqoX=False)
    span = iSearch(r".+ch\/(.+)_", decodedUrl, IGNORECASE)
    if span:
     m3u_Url += span.group(1)
  return m3u_Url
 @staticmethod
 def VVFwRF(decodedUrl):
  p = CCIsu8()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV9sXV(decodedUrl)
  if valid:
   if CCIsu8.VVVFkJ(chCm):
    return FFAhi4(chCm)
   else:
    ok = p.VViUgY(host, mac, ph1, VVuqoX=False)
    if ok:
     try:
      chUrl = p.VVLkPg(mode, chCm, epNum, epId)
      return FFAhi4(chUrl)
     except Exception as e:
      pass
  return ""
 @staticmethod
 def VVVFkJ(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
class CCmugO(CCIsu8):
 def __init__(self):
  CCIsu8.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVsBck(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = self.VV9sXV(decodedUrl)
  if valid:
   if self.VViUgY(host, mac, ph1, VVuqoX=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVaXNh(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVLkPg(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CCIsu8.VVVFkJ(self.chCm):
   chUrl = FFAhi4(self.chCm)
   chUrl = FFGlin(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
   isDirect = True
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
   isDirect = True
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVHuSz(chUrl)
  if newIptvRef:
   success = self.VVCm61(self.iptvRef, newIptvRef, isDirect)
   if passedSELF:
    FFvYTu(passedSELF, newIptvRef, VVonEU=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFvYTu(self, newIptvRef, VVonEU=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VVHuSz(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVCm61(self, oldCode, newCode, isDirect):
  bPath = FFGpvX()
  if bPath:
   if isDirect:
    patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
    span = iSearch(patt, newCode, IGNORECASE)
    if span:
     newRef = span.group(1)
     newPar = span.group(2)
     lines = FFW1ru(bPath)
     for ndx, line in enumerate(lines):
      span = iSearch(patt, line, IGNORECASE)
      if span and newRef == span.group(1) and newPar == span.group(2):
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f:
        for line in lines:
         f.write(line + "\n")
       FFRfFm()
       return True
   else:
    txt = FFeIec(bPath)
    if oldCode in txt:
     txt = txt.replace(oldCode, newCode)
     with open(bPath, "w") as f:
      f.write(txt)
     FFRfFm()
     return True
  return False
class CCdiPb(CCmugO):
 def __init__(self, passedSession):
  CCmugO.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.isFromEOF  = False
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVd7RY, iPlayableService.evEOF: self.VVIkTI, iPlayableService.evEnd: self.VVYVl0})
  except:
   pass
 def VVd7RY(self):
  self.startTime = iTime()
 def VVIkTI(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self.passedSession, isFromSession=True)
    if iptvRef and not FFVVjP(decodedUrl):
     self.isFromEOF = True
     CCaqvh(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVYVl0(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVV9OI)
  except:
   self.timer1.callback.append(self.VVV9OI)
  self.timer1.start(100, True)
 def VVV9OI(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVsBck(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCG8uj.VVp5Y4:
       self.isFromEOF = False
       self.VVaXNh(self.passedSession, isFromSession=True)
class CCAigr():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.nameTagPatt = r"\s*.{1,2}\s*[\[(|:]{1,2}\s*(.+)|\s*[\[(|:].{1,5}[\])|:](.+)|\s*(?:[^a-z]+:)*(.+)"
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.missingUtf8 = VVVSQr and not VVrPSH
  self.adultWords  = ("adult", "aduld", "sex", "porn", "xxx", "xxi", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.adultWords2 = ("\u042d\u0440\u043e\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0435", "dla doros\u0142ych")
 def VVPrIw(self, name,  censored=""):
  if self.missingUtf8:
   name = str(name.encode('ascii', 'replace').decode('utf-8'))
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CC4M3v.VVJzST(name):
   return CC4M3v.VV34An(name)
  name = self.VVHzwq(name)
  return name.strip() or name
 def VVHzwq(self, name):
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    return span.group(1) or span.group(2) or span.group(3)
  return name
 def VV4urn(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVHzwq(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VV4Vl6(self, name):
  if self.hideAdult:
   if any(x in name.lower() for x in self.adultWords):
    return ""
   elif any(x in name.encode('ascii', 'backslashreplace').decode('utf-8').lower() for x in self.adultWords2):
    return ""
  return name.strip()
 def VVCydI(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVZHxP(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCUxkq(CCIsu8):
 def __init__(self):
  CCIsu8.__init__(self)
 def VVxFz9(self):
  if CCUxkq.VVEdgn(self):
   FF1SeM(self, self.VVYPeX, title="Searching ...")
 def VVVckI(self, winSession, url, mac):
  if CCUxkq.VVEdgn(self):
   if self.VViUgY(url, mac):
    FF1SeM(winSession, self.VVrkhS, title="Checking Server ...")
   else:
    FFcgS7(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVYPeX(self):
  path = CC4M3v.VVd5MC()
  lines = FFfDK7('find %s %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % (path, FFVC1u(1)))
  if lines:
   if len(lines) == 1 and lines[0] == VVnT2K:
    FFcgS7(self, VVnT2K)
   else:
    lines.sort()
    VVlZjX = []
    for line in lines:
     VVlZjX.append((line, line))
    OKBtnFnc  = self.VVd0UC
    VVWQj7 = ("Delete File", self.VVbSQ0)
    FFqaQ9(self, None, title="Select Portals File", VVlZjX=VVlZjX, width=1200, OKBtnFnc=OKBtnFnc, VVWQj7=VVWQj7)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFcgS7(self, 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt)
 def VVbSQ0(self, VV2FRKObj, path):
  FFixrz(self, boundFunction(self.VVGwoz, VV2FRKObj, path), "Delete this file ?\n\n%s" % path)
 def VVGwoz(self, VV2FRKObj, path):
  os.system(FFA9Vj("rm -f '%s'" % path))
  if fileExists(path) : FFLk1N(VV2FRKObj, "Not deleted", 1000)
  else    : VV2FRKObj.VVlGAm()
 def VVd0UC(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = CCo0R4.VVp85V(path, self)
   if enc == -1:
    return
   self.session.open(CCbQK1, barTheme=CCbQK1.VVMxXb
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VVUttK, path, enc)
       , VVs5HI = boundFunction(self.VVjE5R, menuInstance, path))
 def VVUttK(self, path, enc, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  progBarObj.VVuznc(totLines)
  progBarObj.VVZTL8 = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVBfFC(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVKI6y(url)
     mac  = self.VV3qoa(mac)
     if host and mac and progBarObj:
      progBarObj.VVZTL8.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVKI6y(url)
      mac  = self.VV3qoa(mac)
      if host and mac and not mac.startswith("AC") and progBarObj:
       progBarObj.VVZTL8.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVjE5R(self, menuInstance, path, VV9SAG, VVZTL8, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVZTL8:
   VVyKSB  = ("Home Menu"  , FFpYsh               , [])
   VVhD2a = ("Edit File"  , boundFunction(self.VVexj7, path)       , [])
   VVx7qK = ("Open as M3U" , self.VVKww2           , [])
   VV1php = ("Check & Filter" , boundFunction(self.VVfW6a, menuInstance, path) , [])
   VVxwOk  = ("Select"   , self.VVVckI_fromMacFiles         , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVDhPS  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVpjES = FF1Vl3(self, None, title=title, header=header, VVKQR8=VVZTL8, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=26, VVxwOk=VVxwOk, VVyKSB=VVyKSB, VVx7qK=VVx7qK, VVhD2a=VVhD2a, VV1php=VV1php, VVmxJZ="#0a001122", VVEDc7="#0a001122", VVc1Ml="#0a001122", VVZoDW="#00004455", VVwpfj="#0a333333", VVQ4sb="#11331100", VVwgKR=True, searchCol=1)
   if not VV9SAG:
    FFLk1N(VVpjES, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VV9SAG:
    FFcgS7(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVKww2(self, VVpjES, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  FF1SeM(VVpjES, boundFunction(self.VVOkyz, VVpjES, host, mac), title="Checking Server ...")
 def VVOkyz(self, VVpjES, host, mac):
  p = CCIsu8()
  m3u_Url = ""
  ok = p.VViUgY(host, mac, VVuqoX=False)
  err = ""
  if ok:
   m3u_Url, err = p.VVJLp3(VVuqoX=False)
  title = "Browsing M3U Server from Portal Data"
  if m3u_Url:
   self.VVEfqD(title, m3u_Url)
  else:
   FFcgS7(self, err or "No response from Server !", title=title)
 def VVVckI_fromMacFiles(self, VVpjES, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVVckI(VVpjES, url, mac)
 def VVexj7(self, path, VVpjES, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCkrAL(self, path, VVs5HI=boundFunction(self.VVZQhH, VVpjES), curRowNum=rowNum)
  else    : FFGmd5(self, path)
 def VVfW6a(self, menuInstance, path, VVpjES, title, txt, colList):
  self.session.open(CCbQK1, barTheme=CCbQK1.VVlj0K
      , titlePrefix = "Checking Portals"
      , fncToRun  = boundFunction(self.VVyBmo, VVpjES)
      , VVs5HI = boundFunction(self.VVziNX, menuInstance, VVpjES, path))
 def VVyBmo(self, VVpjES, progBarObj):
  progBarObj.VVZTL8 = []
  progBarObj.VVuznc(VVpjES.VV9oe5())
  for row in VVpjES.VVbYXo():
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVBfFC(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VViUgY(host, mac, VVuqoX=False):
    token, profile, tErr = self.VVxnfN(VVuqoX=False)
    if token and progBarObj and not progBarObj.isCancelled:
     res, err = self.VVuWhA(self.VVjxoo("itv"))
     if res and progBarObj and not progBarObj.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       progBarObj.VVBfFC(0, showFound=True)
       progBarObj.VVZTL8.append((titl, host, mac, cmnt))
      except:
       pass
   if not progBarObj:
    return
 def VVziNX(self, menuInstance, VVpjES, path, VV9SAG, VVZTL8, threadCounter, threadTotal, threadErr):
  if VVZTL8:
   VVpjES.close()
   menuInstance.close()
   newPath = "%s_OK_%s.txt" % (path, FFdfSu())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVZTL8:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FF0hQa(str(threadCounter), VVaqQK)
    skipped = FF0hQa(str(threadTotal - threadCounter), VVaqQK)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVZTL8)
   txt += "%s\n\n%s"    %  (FF0hQa("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
   FFn7o1(self, txt, title="Accessible Portals")
  elif VV9SAG:
   FFcgS7(self, "No portal access found !", title="Accessible Portals")
 def VVaoZT(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFrR0L(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVrkhS(self):
  token, profile, tErr = self.VVxnfN()
  if token:
   dots = "." * self.portal_moreAuthType
   dots += "+" if self.portal_php[1:2] == "p" else ""
   VVlZjX  = self.VVDtY7()
   OKBtnFnc = self.VVmcxz
   VVmAmL = ("Home Menu", FFpYsh)
   VVXqVm = ("Bookmark Server", boundFunction(CC4M3v.VVQRH5, self, True, self.VV6ARo + "\t" + self.VVbM8z))
   FFqaQ9(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVbM8z, dots), VVlZjX=VVlZjX, OKBtnFnc=OKBtnFnc, VVmAmL=VVmAmL, VVXqVm=VVXqVm)
 def VVmcxz(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FF1SeM(menuInstance, boundFunction(self.VVGZCk, mode), title="Reading Categories ...")
   else : FF1SeM(menuInstance, boundFunction(self.VVZMsB, menuInstance, title), title="Reading Account ...")
 def VVZMsB(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVkkV9(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVbM8z)
  VVyKSB  = ("Home Menu" , FFpYsh            , [])
  VVx7qK  = None
  if VVs8GF:
   VVx7qK = ("Get JS"  , boundFunction(self.VVrWOV, self.VV6ARo) , [])
  if totCols == 2:
   VV1php = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VV1php = ("More Info.", boundFunction(self.VVRLck, menuInstance) , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FF1Vl3(self, None, title=title, width=1200, header=header, VVKQR8=rows, VVrZ8Z=widths, VVbh3O=26, VVyKSB=VVyKSB, VVx7qK=VVx7qK, VV1php=VV1php, VVmxJZ="#0a00292B", VVEDc7="#0a002126", VVc1Ml="#0a002126", VVZoDW="#00000000", searchCol=searchCol)
 def VVrWOV(self, url, VVpjES, title, txt, colList):
  FF1SeM(VVpjES, boundFunction(self.VVBbTU, url), title="Getting JS ...")
 def VVBbTU(self, url):
  txt = "// Host\t: %s\n" % url
  res, err = self.VVuWhA("%s/c/version.js" % url)
  if not err: ver = res.text
  else   : ver = "Error: %s" % err
  txt += "// Version\t: %s\n" % ver
  res, err = self.VVuWhA("%s/c/xpcom.common.js" % url)
  if not err: js = res.text
  else   : js = "Error: %s" % err
  txt += "\n%s" % js
  FFn7o1(self, txt, title="JS Info", canSaveToFile="Server_xpcom.common.js")
 def VVRLck(self, menuInstance, VVpjES, title, txt, colList):
  VVpjES.cancel()
  FF1SeM(menuInstance, boundFunction(self.VVZMsB, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVGZCk(self, mode):
  token, profile, tErr = self.VVxnfN()
  if not token:
   return
  res, err = self.VVuWhA(self.VVjxoo(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CCAigr()
     chList = tDict["js"]
     for item in chList:
      Id   = CC4M3v.VVrtEf(item, "id"       )
      Title  = CC4M3v.VVrtEf(item, "title"      )
      censored = CC4M3v.VVrtEf(item, "censored"     )
      Title = processChanName.VV4Vl6(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVs8GF:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVuB9i(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVmxJZ, VVEDc7, VVc1Ml, VVZoDW = self.VVBNqN(mode)
   mName = self.VVuB9i(mode)
   VVxwOk   = ("Show List"   , boundFunction(self.VVhmdT, mode) , [])
   VVyKSB  = ("Home Menu"   , FFpYsh         , [])
   if mode in ("vod", "series"):
    VVhD2a = ("Find in %s" % mName , boundFunction(self.VVwspX, mode), [])
   else:
    VVhD2a = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FF1Vl3(self, None, title=title, width=1200, header=header, VVKQR8=list, VVrZ8Z=widths, VVbh3O=30, VVyKSB=VVyKSB, VVhD2a=VVhD2a, VVxwOk=VVxwOk, VVmxJZ=VVmxJZ, VVEDc7=VVEDc7, VVc1Ml=VVc1Ml, VVZoDW=VVZoDW)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.portal_moreAuthMsg:
     txt += "\n\n( %s )" % self.portal_moreAuthMsg
   else:
    txt = "Could not get Categories from server!"
   FFcgS7(self, txt, title=title)
 def VVx0bS(self, mode, VVpjES, title, txt, colList):
  FF1SeM(VVpjES, boundFunction(self.VV13r9, mode, VVpjES, title, txt, colList), title="Downloading ...")
 def VV13r9(self, mode, VVpjES, title, txt, colList):
  token, profile, tErr = self.VVxnfN()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVuWhA(self.VV6iZ2(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CC4M3v.VVrtEf(item, "id"    )
      actors   = CC4M3v.VVrtEf(item, "actors"   )
      added   = CC4M3v.VVrtEf(item, "added"   )
      age    = CC4M3v.VVrtEf(item, "age"   )
      category_id  = CC4M3v.VVrtEf(item, "category_id" )
      description  = CC4M3v.VVrtEf(item, "description" )
      director  = CC4M3v.VVrtEf(item, "director"  )
      genres_str  = CC4M3v.VVrtEf(item, "genres_str"  )
      name   = CC4M3v.VVrtEf(item, "name"   )
      path   = CC4M3v.VVrtEf(item, "path"   )
      screenshot_uri = CC4M3v.VVrtEf(item, "screenshot_uri" )
      series   = CC4M3v.VVrtEf(item, "series"   )
      cmd    = CC4M3v.VVrtEf(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VVxwOk  = ("Play"    , boundFunction(self.VV56C2, mode)       , [])
   VVsbBT = (""     , boundFunction(self.VVHQ0M, mode)     , [])
   VVyKSB = ("Home Menu"   , FFpYsh               , [])
   VVx7qK = ("Download Options" , boundFunction(self.VVI39w, mode, "sp", seriesName) , [])
   VVhD2a = ("Options" , boundFunction(self.VVuoYE, 0, "pEp", mode, seriesName)  , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVDhPS  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FF1Vl3(self, None, title=seriesName, width=1200, header=header, VVKQR8=list, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=26, VVyKSB=VVyKSB, VVx7qK=VVx7qK, VVhD2a=VVhD2a, VVxwOk=VVxwOk, VVsbBT=VVsbBT, VVmxJZ="#0a00292B", VVEDc7="#0a002126", VVc1Ml="#0a002126", VVZoDW="#00000000")
  else:
   FFcgS7(self, "Could not get Episodes from server!", title=seriesName)
 def VVwspX(self, mode, VVpjES, title, txt, colList):
  VVlZjX = []
  VVlZjX.append(("Keyboard"  , "manualEntry"))
  VVlZjX.append(("From Filter" , "fromFilter"))
  FFqaQ9(self, boundFunction(self.VVhjY4, VVpjES, mode), title="Input Type", VVlZjX=VVlZjX, width=400)
 def VVhjY4(self, VVpjES, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFZyEN(self, boundFunction(self.VVPNFi, VVpjES, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCPqp9(self)
    filterObj.VVbIsl(boundFunction(self.VVPNFi, VVpjES, mode))
 def VVPNFi(self, VVpjES, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VVALvf(mode, searchName)
   if len(searchName) < 3:
    FFcgS7(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CCAigr()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVCydI([searchName]):
     FFcgS7(self, processChanName.VVZHxP(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VVli1D(mode, searchName, "", searchName)
 def VVhmdT(self, mode, VVpjES, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVli1D(mode, bName, catID, "")
 def VVli1D(self, mode, bName, catID, searchName):
  self.session.open(CCbQK1, barTheme=CCbQK1.VVMxXb
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVHDtE, mode, bName, catID, searchName)
      , VVs5HI = boundFunction(self.VVC7tu, mode, bName, catID, searchName))
 def VVC7tu(self, mode, bName, catID, searchName, VV9SAG, VVZTL8, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVALvf(mode, searchName)
  else   : title = "%s : %s" % (self.VVuB9i(mode), bName)
  if VVZTL8:
   VVx7qK = None
   VVhD2a = None
   if mode == "series":
    VVmxJZ, VVEDc7, VVc1Ml, VVZoDW = self.VVBNqN("series2")
    VVxwOk  = ("Episodes", boundFunction(self.VVx0bS, mode) , [])
   else:
    VVmxJZ, VVEDc7, VVc1Ml, VVZoDW = self.VVBNqN("")
    VVxwOk  = ("Play"    , boundFunction(self.VV56C2, mode)           , [])
    VVx7qK = ("Download Options" , boundFunction(self.VVI39w, mode, "vp" if mode == "vod" else "", "") , [])
    VVhD2a = ("Options"   , boundFunction(self.VVuoYE, 1, "pCh", mode, bName)      , [])
   VVsbBT = (""      , boundFunction(self.VVvPDY, mode)          , [])
   VVyKSB = ("Home Menu"    , FFpYsh                   , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVDhPS  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT )
   VVpjES = FF1Vl3(self, None, title=title, header=header, VVKQR8=VVZTL8, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=26, VVyKSB=VVyKSB, VVx7qK=VVx7qK, VVhD2a=VVhD2a, VVxwOk=VVxwOk, VVsbBT=VVsbBT, VVmxJZ=VVmxJZ, VVEDc7=VVEDc7, VVc1Ml=VVc1Ml, VVZoDW=VVZoDW, VVwgKR=True, searchCol=1)
   if not VV9SAG:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVpjES.VVahDS(VVpjES.VVbfvv() + tot)
    if threadErr: FFLk1N(VVpjES, "Error while reading !", 2000)
    else  : FFLk1N(VVpjES, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFcgS7(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFcgS7(self, "Could not get list from server !", title=title)
 def VVvPDY(self, mode, VVpjES, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFqUR7(self, fncMode=CC6WQp.VV3eY6, portalHost=self.VV6ARo, portalMac=self.VVbM8z, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVX7rA(mode, VVpjES, title, txt, colList)
 def VVHQ0M(self, mode, VVpjES, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FF0hQa(colList[10], VV7bzw)
  txt += "Description:\n%s" % FF0hQa(colList[11], VV7bzw)
  self.VVX7rA(mode, VVpjES, title, txt, colList)
 def VVX7rA(self, mode, VVpjES, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV8Ej2(mode, colList)
  refCode, chUrl = self.VVImmn(self.VV6ARo, self.VVbM8z, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFqUR7(self, fncMode=CC6WQp.VVxpJX, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVHDtE(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile, tErr = self.VVxnfN()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VVZTL8, total_items, max_page_items, err = self.VVxNPm(mode, catID, 1, 1, searchName)
   if progBarObj.isCancelled:
    return
   if progBarObj.VVZTL8 and total_items > -1 and max_page_items > -1:
    progBarObj.VVuznc(total_items)
    progBarObj.VVBfFC(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVxNPm(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VV6VG2()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VVZTL8 += list
      progBarObj.VVBfFC(len(list), True)
  except:
   pass
 def VVxNPm(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VV6h3c(mode, searchName, page)
  else   : url = self.VVIBr9(mode, catID, page)
  res, err = self.VVuWhA(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVrK8e(CC4M3v.VVrtEf(item, "total_items" ))
     max_page_items = self.VVrK8e(CC4M3v.VVrtEf(item, "max_page_items" ))
     processChanName = CCAigr()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CC4M3v.VVrtEf(item, "id"    )
      name   = CC4M3v.VVrtEf(item, "name"   )
      o_name   = CC4M3v.VVrtEf(item, "o_name"   )
      tv_genre_id  = CC4M3v.VVrtEf(item, "tv_genre_id" )
      number   = CC4M3v.VVrtEf(item, "number"   ) or str(counter)
      logo   = CC4M3v.VVrtEf(item, "logo"   )
      screenshot_uri = CC4M3v.VVrtEf(item, "screenshot_uri" )
      cmd    = CC4M3v.VVrtEf(item, "cmd"   )
      censored  = CC4M3v.VVrtEf(item, "censored"  )
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       span = iSearch(r"stream=(.+)&", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
       else:
        span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VV6ARo + picon).replace(sp * 2, sp)
      counter += 1
      name = processChanName.VVPrIw(name, censored)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVJfrK(self, mode, bName, VVpjES, title, txt, colList):
  bNameFile = CC4M3v.VV7A0S_forBouquet(bName)
  num  = 0
  path = VVf9y4 + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVf9y4 + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   isMulti = VVpjES.VVZkVN
   for ndx, row in enumerate(VVpjES.VVbYXo()):
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV8Ej2(mode, row)
    refCode, chUrl = self.VVImmn(self.VV6ARo, self.VVbM8z, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    if not isMulti or VVpjES.VVVT4o(ndx):
     f.write("#SERVICE %s\n"  % chUrl)
     f.write("#DESCRIPTION %s\n" % chName)
     totChange += 1
  FFDa4p(os.path.basename(path))
  self.VV1mXo(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVrK8e(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VV56C2(self, mode, VVpjES, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV8Ej2(mode, colList)
  refCode, chUrl = self.VVImmn(self.VV6ARo, self.VVbM8z, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVJzST(chName):
   FFLk1N(VVpjES, "This is a marker!", 300)
  else:
   FF1SeM(VVpjES, boundFunction(self.VV5AuY, mode, VVpjES, chUrl), title="Playing ...")
 def VV5AuY(self, mode, VVpjES, chUrl):
  FFvYTu(self, chUrl, VVonEU=False)
  self.session.open(CCG8uj, portalTableParam=(self, VVpjES, mode))
 def VVa8tZ(self, mode, VVpjES, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV8Ej2(mode, colList)
  refCode, chUrl = self.VVImmn(self.VV6ARo, self.VVbM8z, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VV8Ej2(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVEdgn(SELF):
  try:
   import requests
   return True
  except:
   title = 'Install "Requests"'
   VVlZjX = []
   VVlZjX.append((title        , "inst" ))
   VVlZjX.append(("Update Packages then %s" % title , "updInst" ))
   FFqaQ9(SELF, boundFunction(CCUxkq.VVFxue, SELF), title='This requires Python "Requests" library', VVlZjX=VVlZjX)
   return False
 @staticmethod
 def VVFxue(SELF, item=None):
  if item:
   from sys import version_info
   cmdUpd = FFWjY7(VV6NZu, "")
   if cmdUpd:
    cmdInst = FFlY7a(VV3kNP, "python-requests")
    if version_info[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFLwr1(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library')
   else:
    FFMiwh(SELF)
class CC4M3v(Screen, CCUxkq):
 VVcuhD    = 0
 VVGHj7    = 1
 VVCNat    = 2
 VVq1JE    = 3
 VV24WV     = 4
 VVBpTI     = 5
 VVArOm     = 6
 VVElJi     = 7
 VVgYPt      = 8
 VVSICT     = 9
 VV8iTf     = 10
 VVt2gm     = 11
 VVRsh3     = 12
 VVBOYB      = 13
 VVaZEz      = 14
 VVsZ9b      = 15
 VVlp74      = 16
 VVgcUK      = 17
 VV1nqW    = 0
 VVpALX   = 1
 VVl6y9   = 2
 VVR64G   = 3
 VVnErL  = 4
 VV0AfO  = 5
 VVqCaD   = 6
 VVfGhP   = 7
 VVxVCt  = 8
 VV6ZOq  = 9
 VVkX8M  = 10
 VVX1de = 0
 VVwmoP = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FF8X8q(VVycF3, 1000, 1000, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.m3uOrM3u8File  = m3uOrM3u8File
  self.m3uOrM3u8BName  = ""
  self.VVpjES  = None
  self.tableTitle   = "IPTV Channels List"
  self.VVGvduData  = {}
  self.lastFindIptvName = ""
  CCUxkq.__init__(self)
  VVlZjX = []
  VVlZjX.append(("IPTV Server Browser (from Playlists)"      , "VVGvdu_fromPlayList" ))
  VVlZjX.append(("IPTV Server Browser (from Portal List)"     , "VVGvdu_fromMac"  ))
  VVlZjX.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)" , "VVGvdu_fromM3u"  ))
  qUrl, iptvRef = self.VVdved()
  if qUrl or "chCode" in iptvRef:
   VVlZjX.append(("IPTV Server Browser (from Current Channel)"    , "VVGvdu_fromCurrChan" ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("M3U/M3U8 File Browser"          , "VVHd5w"   ))
  files = self.VVDbxn()
  if files:
   VVlZjX.append(("Local IPTV Channels"          , "iptvTable_all"   ))
  if qUrl or "chCode" in iptvRef:
   VVlZjX.append(VVZYy7)
   VVlZjX.append(("Update Current Bouquet EPG (from IPTV Server)"   , "refreshIptvEPG"   ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Check System Acceptable Reference Types"      , "VV63md"   ))
  if files:
   VVlZjX.append(("Count Available IPTV Channels"       , "VViFqE"    ))
   VVlZjX.append(("Check Reference Codes Format"        , "VViNJP"   ))
   VVlZjX.append(VVZYy7)
   VVlZjX.append(("Share Reference with Sat./C/T (Only Matching Names)"  , "VVAexj" ))
   VVlZjX.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVw877"  ))
   VVlZjX.append(("Change ALL References to Unique Codes"     , "VVVXlb" ))
   VVlZjX.append(("Change ALL References to Identical Codes"     , "VVFbUI_all" ))
  if not CCsRnB.VVU3Sj():
   VVlZjX.append(VVZYy7)
   VVlZjX.append(("Download Manager"           , "dload_stat"    ))
  FFNPyH(self, title="IPTV", VVlZjX=VVlZjX)
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FFhGNA(self["myMenu"])
  FFwAWu(self)
  FFLm4N(self)
  if self.m3uOrM3u8File:
   self.VVCHQc(self.m3uOrM3u8File)
 def VVzaO1(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVnnQG"   : FFZyEN(self, self.VVnnQG, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVN2E1" : FFixrz(self, boundFunction(FF1SeM, self.VVpjES, self.VVN2E1 ), "Change Current List References to Unique Codes ?")
   elif item == "VVFbUI_rows" : FFixrz(self, boundFunction(FF1SeM, self.VVpjES, self.VVFbUI   ), "Change Current List References to Identical Codes ?")
   elif item == "VVJ1uG"   : self.VVJ1uG(tTitle)
   elif item == "VV5jVL"   : self.VV5jVL(tTitle)
   elif item == "VVGvdu_fromPlayList" : FF1SeM(self, self.VVKylW, title=title)
   elif item == "VVGvdu_fromM3u"  : FF1SeM(self, boundFunction(self.VVUqd8, 0), title=title)
   elif item == "VVGvdu_fromMac"  : self.VVxFz9()
   elif item == "VVGvdu_fromCurrChan" : self.VVVckI_fromCurrChan()
   elif item == "VVHd5w"   : self.VVHd5w()
   elif item == "iptvTable_live"   : FF1SeM(self, boundFunction(self.VVIoxm, self.VVElJi ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FF1SeM(self, boundFunction(self.VVIoxm, self.VVcuhD) , title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VV2i1d()
   elif item == "VViFqE"    : FF1SeM(self, self.VViFqE)
   elif item == "VViNJP"    : FF1SeM(self, self.VViNJP)
   elif item == "VV63md"   : FF1SeM(self, self.VV63md)
   elif item == "VVAexj"  : FFixrz(self, boundFunction(FF1SeM, self, self.VVAexj ), "Continue ?")
   elif item == "VVw877"  : self.VVw877()
   elif item == "VVVXlb" : FFixrz(self, boundFunction(FF1SeM, self, self.VVVXlb ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVFbUI_all" : FFixrz(self, boundFunction(FF1SeM, self, self.VVFbUI  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "dload_stat"    : CCsRnB.VVyzTQ(self)
   elif item == "VVlvTI"   : FF1SeM(self, boundFunction(CCYAlZ.VVlvTI, self))
 def VVHd5w(self):
  if CCUxkq.VVEdgn(self):
   FF1SeM(self, boundFunction(self.VVUqd8, 1), title="Searching ...")
 def VVEvnY(self):
  global VVWK7p
  VVWK7p = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVzaO1(item)
 def VVIoxm(self, mode):
  VVXJa5 = self.VVmexx(mode)
  if VVXJa5:
   VVx7qK = ("Current Service", self.VVQFxU  , [])
   VVhD2a = ("Options"  , self.VV7gpy    , [])
   VV1php = ("Filter"   , self.VVINpK    , [])
   VVxwOk  = ("Play"   , boundFunction(self.VV3esU) , [])
   VVsbBT = (""    , self.VVSG7i     , [])
   VV8Bqk = (""    , self.VV3DA0      , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVDhPS  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FF1Vl3(self, None, header=header, VVKQR8=VVXJa5, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=26
     , VVxwOk=VVxwOk, VVx7qK=VVx7qK, VVhD2a=VVhD2a, VV1php=VV1php, VVsbBT=VVsbBT, VV8Bqk=VV8Bqk
     , VVmxJZ="#0a00292B", VVEDc7="#0a002126", VVc1Ml="#0a002126", VVZoDW="#00000000", VVwgKR=True, searchCol=1)
  else:
   if mode == self.VVElJi: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFcgS7(self, err)
 def VV3DA0(self, VVpjES, title, txt, colList):
  self.VVpjES = VVpjES
 def VV7gpy(self, VVpjES, title, txt, colList):
  VVlZjX = []
  VVlZjX.append(("Add Current List to a New Bouquet"      , "VVnnQG"  ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Change Current List References to Unique Codes"   , "VVN2E1"))
  VVlZjX.append(("Change Current List References to Identical Codes"  , "VVFbUI_rows" ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Share Reference with Satellite/C/T Service (manual entry)", "VVJ1uG"   ))
  VVlZjX.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VV5jVL"   ))
  FFqaQ9(self, self.VVzaO1, title="IPTV Tools", VVlZjX=VVlZjX)
 def VVINpK(self, VVpjES, title, txt, colList):
  VVlZjX = []
  VVlZjX.append(("All"         , "all"   ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Prefix of Selected Channel"   , "sameName" ))
  VVlZjX.append(("Suggest Words from Selected Channel" , "partName" ))
  VVlZjX.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Live TV"        , "live"  ))
  VVlZjX.append(("VOD"         , "vod"   ))
  VVlZjX.append(("Series"        , "series"  ))
  VVlZjX.append(("Uncategorised"      , "uncat"  ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Video"        , "video"  ))
  VVlZjX.append(("Audio"        , "audio"  ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("MKV"         , "MKV"   ))
  VVlZjX.append(("MP4"         , "MP4"   ))
  VVlZjX.append(("MP3"         , "MP3"   ))
  VVlZjX.append(("AVI"         , "AVI"   ))
  VVlZjX.append(("FLV"         , "FLV"   ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVighj()
  if bNames:
   bNames.sort()
   VVlZjX.append(VVZYy7)
   for item in bNames:
    VVlZjX.append((item, "__b__" + item))
  filterObj = CCPqp9(self)
  filterObj.VVGlra(VVlZjX, VVlZjX, boundFunction(self.VVtLZQ, VVpjES))
 def VVtLZQ(self, VVpjES, item=None):
  prefix = VVpjES.VVvMZR(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVcuhD, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVGHj7 , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVCNat , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVq1JE , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVElJi  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVgYPt   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVSICT  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VV8iTf  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVt2gm  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVRsh3  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVBOYB   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVaZEz   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVsZ9b   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVlp74   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVgcUK   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVArOm  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VV24WV  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVBpTI  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVCNat:
   VVlZjX = []
   chName = VVpjES.VVvMZR(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVlZjX.append((item, item))
    if not VVlZjX and chName:
     VVlZjX.append((chName, chName))
    FFqaQ9(self, boundFunction(self.VV0hYn_partOfName, title), title="Words from Current Selection", VVlZjX=VVlZjX)
   else:
    VVpjES.VVLvlZ("Invalid Channel Name")
  else:
   words, asPrefix = CCPqp9.VVn2jm(words)
   if not words and mode in (self.VV24WV, self.VVBpTI):
    FFLk1N(self.VVpjES, "Incorrect filter", 2000)
   else:
    FF1SeM(self.VVpjES, boundFunction(self.VVcr5K, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VV0hYn_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FF1SeM(self.VVpjES, boundFunction(self.VVcr5K, self.VVCNat, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VV34An(txt):
  return "#f#11ffff00#" + txt
 def VVcr5K(self, mode, words, asPrefix, title):
  VVXJa5 = self.VVmexx(mode=mode, words=words, asPrefix=asPrefix)
  if VVXJa5 : self.VVpjES.VV3EJ0(VVXJa5, title)
  else  : self.VVpjES.VVLvlZ("Not found")
 def VVmexx(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VVXJa5 = []
  files  = self.VVDbxn()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFeIec(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVnBh0 = span.group(1)
    else : VVnBh0 = ""
    VVnBh0_lCase = VVnBh0.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVJzST(chName): chNameMod = self.VV34An(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVnBh0, chType, refCode, url)
     ok = False
     tUrl = FFAhi4(url).lower()
     if mode == self.VVcuhD       : ok = True
     elif mode == self.VVArOm       : ok = True
     elif mode == self.VVt2gm:
      if CC4M3v.VVMlKY(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVRsh3:
      if CC4M3v.VVMlKY(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVElJi:
      if CC4M3v.VVMlKY(tUrl, compareType="live")  : ok = True
     elif mode == self.VVgYPt:
      if CC4M3v.VVMlKY(tUrl, compareType="movie") : ok = True
     elif mode == self.VVSICT:
      if CC4M3v.VVMlKY(tUrl, compareType="series") : ok = True
     elif mode == self.VV8iTf:
      if CC4M3v.VVMlKY(tUrl, compareType="")   : ok = True
     elif mode == self.VVBOYB:
      if CC4M3v.VVMlKY(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVaZEz:
      if CC4M3v.VVMlKY(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVsZ9b:
      if CC4M3v.VVMlKY(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVlp74:
      if CC4M3v.VVMlKY(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVgcUK:
      if CC4M3v.VVMlKY(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVGHj7:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVCNat:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVq1JE:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VV24WV:
      if words[0] == VVnBh0_lCase:
       ok = True
     elif mode == self.VVBpTI:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VVXJa5.append(row)
      chNum += 1
  if VVXJa5 and mode == self.VVArOm:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VVXJa5)
   for item in VVXJa5:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VVXJa5 = newRows
  return VVXJa5
 def VVnnQG(self, bName):
  if bName:
   FF1SeM(self.VVpjES, boundFunction(self.VVi137, bName), title="Adding Channels ...")
 def VVi137(self, bName):
  num = 0
  path = VVf9y4 + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVf9y4 + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVpjES.VVbYXo():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFnTaU(row[1]))
    totChange += 1
  FFDa4p(os.path.basename(path))
  self.VV1mXo(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVw877(self):
  txt = "Stream Type "
  VVlZjX = []
  VVlZjX.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVlZjX.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVlZjX.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVlZjX.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVlZjX.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVlZjX.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFqaQ9(self, self.VVTLDy, title="Change Reference Types to:", VVlZjX=VVlZjX)
 def VVTLDy(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVrH3d("1"   )
   elif item == "RT_4097" : self.VVrH3d("4097")
   elif item == "RT_5001" : self.VVrH3d("5001")
   elif item == "RT_5002" : self.VVrH3d("5002")
   elif item == "RT_8192" : self.VVrH3d("8192")
   elif item == "RT_8193" : self.VVrH3d("8193")
 def VVrH3d(self, rType):
  FFixrz(self, boundFunction(FF1SeM, self, boundFunction(self.VVNygz, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVNygz(self, refType):
  totChange = 0
  files  = self.VVDbxn()
  if files:
   for path in files:
    txt = FFeIec(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFDa4p(os.path.basename(path))
  self.VV1mXo(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VViFqE(self):
  totFiles = 0
  files  = self.VVDbxn()
  if files:
   totFiles = len(files)
  totChans = 0
  VVXJa5 = self.VVmexx()
  if VVXJa5:
   totChans = len(VVXJa5)
  FFn7o1(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VViNJP(self):
  files  = self.VVDbxn()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFeIec(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVeO4o
   else    : color = VVaqQK
   totInvalid = FF0hQa(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FF0hQa("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFn7o1(self, txt, title="Check IPTV References")
 def VV63md(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVf9y4 + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFDa4p(os.path.basename(path))
  FFRfFm()
  acceptedList = []
  VVMd2a = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVMd2a:
   VVXfmg = FFjNff(VVMd2a)
   if VVXfmg:
    for service in VVXfmg:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVf9y4 + userBName
  bFile = VVf9y4 + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFA9Vj("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFA9Vj("rm -f '%s'" % path)
  os.system(cmd)
  FFRfFm()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVeO4o
    else     : res, color = "No" , VVaqQK
    txt += "    %s\t: %s\n" % (item, FF0hQa(res, color))
   FFn7o1(self, txt, title=title)
  else:
   txt = FFcgS7(self, "Could not complete the test on your system!", title=title)
 def VVAexj(self):
  lameDbChans = CCYAlZ.VV8ipk(self, CCYAlZ.VVMQKM)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVDbxn():
    toSave = False
    txt = FFeIec(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VV1mXo(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFcgS7(self, 'No channels in "lamedb" !')
 def VVVXlb(self):
  files  = self.VVDbxn()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFW1ru(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVu1vi(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VV1mXo(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVN2E1(self):
  iptvRefList = []
  files  = self.VVDbxn()
  if files:
   for path in files:
    txt = FFeIec(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVpjES.VVdyDU(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVu1vi(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVDbxn()
  if files:
   for path in files:
    lines = FFW1ru(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VV1mXo(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVu1vi(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVFbUI(self):
  list = None
  if self.VVpjES:
   list = []
   for row in self.VVpjES.VVbYXo():
    list.append(row[4] + row[5])
  files  = self.VVDbxn()
  totChange = 0
  if files:
   for path in files:
    lines = FFW1ru(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VV1mXo(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VV1mXo(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFRfFm()
   if refreshTable and self.VVpjES:
    VVXJa5 = self.VVmexx()
    if VVXJa5 and self.VVpjES:
     self.VVpjES.VV3EJ0(VVXJa5, self.tableTitle)
     self.VVpjES.VVLvlZ(txt)
   FFn7o1(self, txt, title=title)
  else:
   FFkpHN(self, "No changes.")
 def VVighj(self):
  files = self.VVDbxn()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with ioOpen(path, "r", encoding="utf-8") as f:
     span = iSearch(r"#NAME\s+(.*)", str(f.readline()), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    for b in FFojgY():
     sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVDbxn(self):
  return CC4M3v.VVy7Fy(self)
 @staticmethod
 def VVy7Fy(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVf9y4 + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFeIec(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVSG7i(self, VVpjES, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFAhi4(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFqUR7(self, fncMode=CC6WQp.VVCrG7, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVac0M(self, VVpjES, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VV3esU(self, VVpjES, title, txt, colList):
  chName, chUrl = self.VVac0M(VVpjES, colList)
  self.VVWpgF(VVpjES, chName, chUrl, "localIptv")
 def VVlm3E(self, mode, VVpjES, colList):
  chName, chUrl, picUrl, refCode = self.VVv7Pu(mode, colList)
  return chName, chUrl
 def VVtBnb(self, mode, VVpjES, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVv7Pu(mode, colList)
  self.VVWpgF(VVpjES, chName, chUrl, mode)
 def VVWpgF(self, VVpjES, chName, chUrl, playerFlag):
  chName = FFnTaU(chName)
  if self.VVJzST(chName):
   FFLk1N(VVpjES, "This is a marker!", 300)
  else:
   FF1SeM(VVpjES, boundFunction(self.VVpZVJ, VVpjES, chUrl, playerFlag), title="Playing ...")
 def VVpZVJ(self, VVpjES, chUrl, playerFlag):
  FFvYTu(self, chUrl, VVonEU=False)
  self.session.open(CCG8uj, portalTableParam=(self, VVpjES, playerFlag))
 @staticmethod
 def VVJzST(chName):
  mark = ("--", "__", "==", "##",  "**", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVQFxU(self, VVpjES, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self)
  if refCode:
   bName = FFVrp5()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFW7yf(refCode, origUrl, chName) }
   VVpjES.VVLOwP_partial(colDict, VVuqoX=True)
 def VVUqd8(self, m3uMode):
  path = CC4M3v.VVd5MC()
  lines = FFfDK7("find %s %s -iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'" % (path, FFVC1u(1)))
  if lines:
   lines.sort()
   VVlZjX = []
   for line in lines:
    VVlZjX.append((line, line))
   if m3uMode == self.VVX1de:
    title = "Browse Server from M3U URLs"
    VVXqVm = ("All to Playlist", self.VVLgL8)
   else:
    title = "M3U/M3U8 File Browser"
    VVXqVm = None
   OKBtnFnc = boundFunction(self.VVv406, m3uMode, title)
   VVG5AR  = ("Show Full Path", self.VVD6qF)
   VVWQj7 = ("Delete File", self.VVbSQ0)
   FFqaQ9(self, None, title=title, VVlZjX=VVlZjX, width=1200, OKBtnFnc=OKBtnFnc, VVG5AR=VVG5AR, VVWQj7=VVWQj7, VVXqVm=VVXqVm)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n\n%s" % path
   FFcgS7(self, 'No ".m3u" files found %s' % txt)
 def VVD6qF(self, VV2FRKObj, url):
  FFn7o1(self, url, title="Full Path")
 def VVv406(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == self.VVX1de:
    FF1SeM(menuInstance, boundFunction(self.VVWgw6, title, path))
   else:
    FF1SeM(menuInstance, boundFunction(self.VVCHQc, path))
 def VVCHQc(self, srcPath):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFeIec(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  processChanName = CCAigr()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VVEPvR(propLine, "group-title") or "-"
   if not group == "-" and processChanName.VVPrIw(group):
    groups.add(group)
  VVXJa5 = []
  if len(groups) > 0:
   title = "Groups"
   for group in groups:
    VVXJa5.append((group, group))
   VVXJa5.append(("ALL", ""))
   VVXJa5.sort(key=lambda x: x[0].lower())
   VV4h63 = self.VVjW2C
   VVxwOk  = ("Select" , boundFunction(self.VV6KE8, srcPath), [])
   widths   = (100  , 0)
   VVDhPS  = (LEFT  , LEFT)
   FF1Vl3(self, None, title=title, width= 800, header=None, VVKQR8=VVXJa5, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=30, VVxwOk=VVxwOk, VV4h63=VV4h63
     , VVmxJZ="#11110022", VVEDc7="#11110022", VVc1Ml="#11110022", VVZoDW="#00444400")
  else:
   txt = FFeIec(srcPath)
   self.VVLvFW(txt, filterGroup="")
 def VV6KE8(self, srcPath, VVpjES, title, txt, colList):
  group = colList[1]
  txt = FFeIec(srcPath)
  self.VVLvFW(txt, filterGroup=group)
 def VVLvFW(self, txt, filterGroup=""):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = "Group : %s" % (filterGroup or "ALL")
  if lst:
   self.session.open(CCbQK1, barTheme=CCbQK1.VVMxXb
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VVi1zR, lst, filterGroup)
       , VVs5HI = boundFunction(self.VVSffI, title, bName))
  else:
   self.VVdkxl("No valid lines found !", title)
 def VVi1zR(self, lst, filterGroup, progBarObj):
  progBarObj.VVZTL8 = []
  progBarObj.VVuznc(len(lst))
  processChanName = CCAigr()
  num = 0
  for cols in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVBfFC(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VVEPvR(propLine, "tvg-logo")
   group = self.VVEPvR(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if group and not processChanName.VVPrIw(group) : skip = True
    if chName and not processChanName.VVPrIw(chName): skip = True
    if not skip and progBarObj:
     num += 1
     progBarObj.VVZTL8.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if progBarObj:
   progBarObj.VVfO7V_forcedUpdate("Loading %d Channels" % len(progBarObj.VVZTL8))
 def VVSffI(self, title, bName, VV9SAG, VVZTL8, threadCounter, threadTotal, threadErr):
  if VVZTL8:
   VV4h63 = self.VVjW2C
   VVxwOk  = ("Select"    , boundFunction(self.VVWtEu, title) , [])
   VVsbBT = (""     , self.VVLNlt         , [])
   VVx7qK = ("Download PIcons" , self.VVjpGG        , [])
   VVhD2a = ("Options" , boundFunction(self.VVuoYE, 1, "m3Ch", "", bName)  , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVDhPS  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FF1Vl3(self, None, title=title, header=header, VVKQR8=VVZTL8, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=28, VVxwOk=VVxwOk, VV4h63=VV4h63, VVsbBT=VVsbBT, VVx7qK=VVx7qK, VVhD2a=VVhD2a, VVwgKR=True, searchCol=1
     , VVmxJZ="#0a00192B", VVEDc7="#0a00192B", VVc1Ml="#0a00192B", VVZoDW="#00000000")
  else:
   self.VVdkxl("No valid lines found !", title)
 def VVjpGG(self, VVpjES, title, txt, colList):
  self.VVWJfS(VVpjES, "m3u/m3u8")
 def VVEEBX(self, mode, bName, VVpjES, title, txt, colList):
  bNameFile = CC4M3v.VV7A0S_forBouquet(bName)
  num  = 0
  path = VVf9y4 + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVf9y4 + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   catID = "33"
   rowNum = 0
   isMulti = VVpjES.VVZkVN
   for ndx, row in enumerate(VVpjES.VVbYXo()):
    chName = row[1].strip()
    url  = row[3].strip()
    chUrl = self.VVGd7p(rowNum, url, chName)
    rowNum += 1
    if not isMulti or VVpjES.VVVT4o(ndx):
     f.write("#SERVICE %s\n"  % chUrl)
     f.write("#DESCRIPTION %s\n" % chName)
     totChange += 1
  FFDa4p(os.path.basename(path))
  self.VV1mXo(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVGd7p(self, rowNum, url, chName):
  refCode = self.VVO7Ko(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFGlin(url), chName)
  return chUrl
 def VVO7Ko(self, rowNum, url, chName):
  span = iSearch(r"\/(\d{2,})", url, IGNORECASE)
  if span : stID = span.group(1)
  else : stID = "444"
  catID = "333"
  chNum = str(rowNum + 1)
  refCode = self.VV9uqR(catID, stID, chNum)
  return refCode
 def VVEPvR(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVWtEu(self, Title, VVpjES, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FF1SeM(VVpjES, boundFunction(self.VVaLWc, Title, VVpjES, colList), title="Checking Server ...")
  else:
   self.VVFstx(VVpjES, url, chName)
 def VVaLWc(self, title, VVpjES, colList):
  if not CCUxkq.VVEdgn(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCIsu8.VVk8TQ(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVlZjX = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CC4M3v.VVzW3M(url, fPath)
     VVlZjX.append((resol, fullUrl))
    if VVlZjX:
     if len(VVlZjX) > 1:
      FFqaQ9(self, boundFunction(self.VVUSRx, VVpjES, chName), VVlZjX=VVlZjX, title="Resolution", VVsug5=True, VVc7Gm=True)
     else:
      self.VVFstx(VVpjES, VVlZjX[0][1], chName)
    else:
     self.VVuqoXor("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVLvFW(txt, filterGroup="")
      return
    self.VVFstx(VVpjES, url, chName)
   else:
    self.VVdkxl("Cannot process this channel !", title)
  else:
   self.VVdkxl(err, title)
 def VVUSRx(self, VVpjES, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVFstx(VVpjES, resolUrl, chName)
 def VVFstx(self, VVpjES, url, chName):
  FF1SeM(VVpjES, boundFunction(self.VVOaqM, VVpjES, url, chName), title="Playing ...")
 def VVOaqM(self, VVpjES, url, chName):
  chUrl = self.VVGd7p(VVpjES.VV7oaa(), url, chName)
  FFvYTu(self, chUrl, VVonEU=False)
  self.session.open(CCG8uj, portalTableParam=(self, VVpjES, "m3u/m3u8"))
 def VVjqHd(self, VVpjES, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVGd7p(VVpjES.VV7oaa(), url, chName)
  return chName, chUrl
 def VVLNlt(self, VVpjES, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFqUR7(self, fncMode=CC6WQp.VVCrG7, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVdkxl(self, err, title):
  FFcgS7(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVjW2C(self, VVpjES):
  if self.m3uOrM3u8File:
   self.close()
  VVpjES.cancel()
 def VVLgL8(self, VV2FRKObj, item=None):
  FF1SeM(VV2FRKObj, boundFunction(self.VVJz9C, VV2FRKObj, item))
 def VVJz9C(self, VV2FRKObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VV2FRKObj.VVlZjX):
    path = item[1]
    if fileExists(path):
     enc = CCo0R4.VVp85V(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = self.VVLew8(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CC4M3v.VVd5MC(orExportPath=True)
    pListF = "%sPlaylist_%s.txt" % (path, FFdfSu())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VV2FRKObj.VVlZjX)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFn7o1(self, txt, title=title)
   else:
    FFcgS7(self, "Could not obtain URLs from this file list !", title=title)
 def VVKylW(self):
  path = CC4M3v.VVd5MC()
  lines = FFfDK7('find %s %s -iname "*playlist*" | grep -i ".txt"' % (path, FFVC1u(1)))
  if lines:
   lines.sort()
   VVlZjX = []
   for line in lines:
    VVlZjX.append((line, line))
   OKBtnFnc  = self.VVGyuv
   VVWQj7 = ("Delete File", self.VVbSQ0)
   FFqaQ9(self, None, title="Select Playlist File", VVlZjX=VVlZjX, width=1200, OKBtnFnc=OKBtnFnc, VVWQj7=VVWQj7)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFcgS7(self, 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt)
 def VVGyuv(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FF1SeM(menuInstance, boundFunction(self.VVz602, menuInstance, path), title="Processing File ...")
 def VVz602(self, fileMenuInstance, path):
  enc = CCo0R4.VVp85V(path, self)
  if enc == -1:
   return
  VVXJa5 = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0]
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFRZql(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC4M3v.VVwjXv(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVXJa5:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(filter(None, [item[5], item[0]]))
     num += 1
     VVXJa5.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVXJa5:
   title = "Playlist File : %s" % os.path.basename(path)
   VVxwOk  = ("Start"    , boundFunction(self.VVZdXC, "Playlist File"), [])
   VVyKSB = ("Home Menu"   , FFpYsh          , [])
   VVx7qK = ("Download M3U File" , self.VVMtm9      , [])
   VVhD2a = ("Edit File"   , boundFunction(self.VVayU2, path)  , [])
   VV1php = ("Check & Filter"  , boundFunction(self.VVYIv2, fileMenuInstance, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVDhPS  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FF1Vl3(self, None, title=title, header=header, VVKQR8=VVXJa5, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=26, VVxwOk=VVxwOk, VVyKSB=VVyKSB, VV1php=VV1php, VVx7qK=VVx7qK, VVhD2a=VVhD2a, VVmxJZ="#11001116", VVEDc7="#11001116", VVc1Ml="#11001116", VVZoDW="#00003635", VVwpfj="#0a333333", VVQ4sb="#11331100", VVwgKR=True)
  else:
   FFcgS7(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVMtm9(self, VVpjES, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFixrz(self, boundFunction(FF1SeM, VVpjES, boundFunction(self.VVieY9, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVieY9(self, title, url):
  path, err = FFDt8N(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFcgS7(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFeIec(path)
   if '{"user_info":{"auth":0}}' in txt:
    os.system(FFA9Vj("rm -f '%s'" % path))
    FFcgS7(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    os.system(FFA9Vj("rm -f '%s'" % path))
    FFcgS7(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CC4M3v.VVd5MC(orExportPath=True) + fName
    os.system(FFA9Vj("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FFkpHN(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFcgS7(self, "Could not download the M3U file!", title=errTitle)
 def VVZdXC(self, Title, VVpjES, title, txt, colList):
  url = colList[6]
  FF1SeM(VVpjES, boundFunction(self.VVEfqD, Title, url), title="Checking Server ...")
 def VVayU2(self, path, VVpjES, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCkrAL(self, path, VVs5HI=boundFunction(self.VVZQhH, VVpjES), curRowNum=rowNum)
  else    : FFGmd5(self, path)
 def VVZQhH(self, VVpjES, fileChanged):
  if fileChanged:
   VVpjES.cancel()
 def VVJ1uG(self, title):
  curChName = self.VVpjES.VVvMZR(1)
  FFZyEN(self, boundFunction(self.VVDir8, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVDir8(self, title, name):
  if name:
   lameDbChans = CCYAlZ.VV8ipk(self, CCYAlZ.VVrxQ8, VVuW8O=False, VVDRQS=False)
   list = []
   if lameDbChans:
    processChanName = CCAigr()
    name = processChanName.VV4urn(name)
    ratio = "1"
    for item in lameDbChans:
     if name in item[0].lower():
      list.append((item[0], FFsWCY(item[2]), item[3], ratio))
   if list : self.VVkenP(list, title)
   else : FFcgS7(self, "Not found:\n\n%s" % name, title=title)
 def VV5jVL(self, title):
  curChName = self.VVpjES.VVvMZR(1)
  self.session.open(CCbQK1, barTheme=CCbQK1.VVMxXb
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVfJLB
      , VVs5HI = boundFunction(self.VVjhnQ, title, curChName))
 def VVfJLB(self, progBarObj):
  curChName = self.VVpjES.VVvMZR(1)
  lameDbChans = CCYAlZ.VV8ipk(self, CCYAlZ.VVh2ac, VVuW8O=False, VVDRQS=False)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVZTL8 = []
  progBarObj.VVuznc(len(lameDbChans))
  processChanName = CCAigr()
  curCh = processChanName.VV4urn(curChName)
  for refCode in lameDbChans:
   chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
   ratio = CCwdjc.VVyvma(chName.lower(), curCh)
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVBfFC(1, True)
   if progBarObj and ratio > 50:
    progBarObj.VVZTL8.append((chName, FFsWCY(sat), refCode.replace("_", ":"), str(ratio)))
 def VVjhnQ(self, title, curChName, VV9SAG, VVZTL8, threadCounter, threadTotal, threadErr):
  if VVZTL8: self.VVkenP(VVZTL8, title)
  elif VV9SAG: FFcgS7(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVkenP(self, VVXJa5, title):
  curChName = self.VVpjES.VVvMZR(1)
  curRefCode = self.VVpjES.VVvMZR(4)
  curUrl  = self.VVpjES.VVvMZR(5)
  VVXJa5 = sorted(VVXJa5, key=lambda x: (100-int(x[3]), x[0].lower()))
  VVxwOk  = ("Share Sat/C/T Ref.", boundFunction(self.VVSf32, title, curChName, curRefCode, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FF1Vl3(self, None, title=title, header=header, VVKQR8=VVXJa5, VVrZ8Z=widths, VVbh3O=26, VVxwOk=VVxwOk, VVmxJZ="#0a00112B", VVEDc7="#0a001126", VVc1Ml="#0a001126", VVZoDW="#00000000")
 def VVSf32(self, newtitle, curChName, curRefCode, curUrl, VVpjES, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFixrz(self.VVpjES, boundFunction(FF1SeM, self.VVpjES, boundFunction(self.VVjofI, VVpjES, data)), ques, title=newtitle, VVEkk8=True)
 def VVjofI(self, VVpjES, data):
  VVpjES.cancel()
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVDbxn():
    txt = FFeIec(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFRfFm()
    newRow = []
    for i in range(6):
     newRow.append(self.VVpjES.VVvMZR(i))
    newRow[4] = newRefCode
    done = self.VVpjES.VVocRR(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FF3K6t(boundFunction(FFkpHN , self, resTxt, title=title))
  elif resErr: FF3K6t(boundFunction(FFcgS7 , self, resErr, title=title))
 def VVYIv2(self, fileMenuInstance, path, VVpjES, title, txt, colList):
  self.session.open(CCbQK1, barTheme=CCbQK1.VVlj0K
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VVuFYB, VVpjES)
      , VVs5HI = boundFunction(self.VVBK23, fileMenuInstance, path, VVpjES))
 def VVuFYB(self, VVpjES, progBarObj):
  progBarObj.VVuznc(VVpjES.VVt9eq())
  progBarObj.VVZTL8 = []
  for row in VVpjES.VVbYXo():
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVBfFC(1, True)
   qUrl = self.VVSjFt(self.VV1nqW, row[6])
   txt, err = self.VVSLDf(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVrtEf(item, "auth") == "0":
       progBarObj.VVZTL8.append(qUrl)
    except:
     pass
 def VVBK23(self, fileMenuInstance, path, VVpjES, VV9SAG, VVZTL8, threadCounter, threadTotal, threadErr):
  if VV9SAG:
   list = VVZTL8
   title = "Authorized Servers"
   if list:
    totChk = VVpjES.VVt9eq()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFdfSu()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVKylW()
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FF0hQa(str(totAuth), VVeO4o)
     txt += "%s\n\n%s"    %  (FF0hQa("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFn7o1(self, txt, title=title)
     VVpjES.close()
     fileMenuInstance.close()
    else:
     FFkpHN(self, "All URLs are authorized.", title=title)
   else:
    FFcgS7(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVSLDf(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   cont = res.headers.get("Content-Type")
   if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
    return "", "Unexpected server data type ( %s )" % cont
   res = res.read().decode("UTF-8")
   if res:
    if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server !"
    else           : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVwjXv(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVMlKY(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVSjFt(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVwjXv(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VV1nqW   : return "%s"            % url
  elif mode == self.VVpALX   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVl6y9   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVR64G  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVnErL  : return "%s&action=get_live_categories"     % url
  elif mode == self.VV0AfO : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVqCaD   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVfGhP    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVxVCt  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVkX8M : return "%s&action=get_live_streams"      % url
  elif mode == self.VV6ZOq  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVrtEf(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFscD6(int(val))
    elif is_base64 : val = FFrR0L(val)
    elif isToHHMMSS : val = FFgN2Y(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVWgw6(self, title, path):
  if fileExists(path):
   enc = CCo0R4.VVp85V(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = self.VVLew8(line)
     if qUrl:
      break
   if qUrl : self.VVEfqD(title, qUrl)
   else : FFcgS7(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFcgS7(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVVckI_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVdved()
  if qUrl or "chCode" in iptvRef:
   p = CCIsu8()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV9sXV(iptvRef)
   if valid:
    self.VVVckI(self, host, mac)
    return
   elif qUrl:
    FF1SeM(self, boundFunction(self.VVEfqD, title, qUrl), title="Checking Server ...")
    return
  FFcgS7(self, "Error in current channel URL !", title=title)
 def VVdved(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self)
  qUrl = self.VVLew8(decodedUrl)
  return qUrl, iptvRef
 def VVLew8(self, url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVEfqD(self, title, url):
  self.VVGvduData = {}
  qUrl = self.VVSjFt(self.VV1nqW, url)
  txt, err = self.VVSLDf(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVGvduData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVGvduData["username"    ] = self.VVrtEf(item, "username"        )
    self.VVGvduData["password"    ] = self.VVrtEf(item, "password"        )
    self.VVGvduData["message"    ] = self.VVrtEf(item, "message"        )
    self.VVGvduData["auth"     ] = self.VVrtEf(item, "auth"         )
    self.VVGvduData["status"    ] = self.VVrtEf(item, "status"        )
    self.VVGvduData["exp_date"    ] = self.VVrtEf(item, "exp_date"    , isDate=True )
    self.VVGvduData["is_trial"    ] = self.VVrtEf(item, "is_trial"        )
    self.VVGvduData["active_cons"   ] = self.VVrtEf(item, "active_cons"       )
    self.VVGvduData["created_at"   ] = self.VVrtEf(item, "created_at"   , isDate=True )
    self.VVGvduData["max_connections"  ] = self.VVrtEf(item, "max_connections"      )
    self.VVGvduData["allowed_output_formats"] = self.VVrtEf(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVGvduData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVGvduData["url"    ] = self.VVrtEf(item, "url"        )
    self.VVGvduData["port"    ] = self.VVrtEf(item, "port"        )
    self.VVGvduData["https_port"  ] = self.VVrtEf(item, "https_port"      )
    self.VVGvduData["server_protocol" ] = self.VVrtEf(item, "server_protocol"     )
    self.VVGvduData["rtmp_port"   ] = self.VVrtEf(item, "rtmp_port"       )
    self.VVGvduData["timezone"   ] = self.VVrtEf(item, "timezone"       )
    self.VVGvduData["timestamp_now"  ] = self.VVrtEf(item, "timestamp_now"  , isDate=True )
    self.VVGvduData["time_now"   ] = self.VVrtEf(item, "time_now"       )
    VVlZjX  = self.VVDtY7(True)
    OKBtnFnc = self.VVGvduOptions
    VVmAmL = ("Home Menu", FFpYsh)
    VVXqVm = ("Bookmark Server", boundFunction(CC4M3v.VVQRH5, self, False, self.VVGvduData["playListURL"]))
    FFqaQ9(self, None, title="IPTV Server Resources", VVlZjX=VVlZjX, OKBtnFnc=OKBtnFnc, VVmAmL=VVmAmL, VVXqVm=VVXqVm)
   else:
    err = "Could not get data from server !"
  if err:
   FFcgS7(self, err, title=title)
  FFLk1N(self)
 def VVGvduOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FF1SeM(menuInstance, boundFunction(self.VVIb7R, self.VVpALX  , title=title), title=wTxt)
   elif ref == "vod"   : FF1SeM(menuInstance, boundFunction(self.VVIb7R, self.VVl6y9  , title=title), title=wTxt)
   elif ref == "series"  : FF1SeM(menuInstance, boundFunction(self.VVIb7R, self.VVR64G , title=title), title=wTxt)
   elif ref == "catchup"  : FF1SeM(menuInstance, boundFunction(self.VVIb7R, self.VVnErL , title=title), title=wTxt)
   elif ref == "accountInfo" : FF1SeM(menuInstance, boundFunction(self.VVzu8z           , title=title), title=wTxt)
 def VVzu8z(self, title):
  rows = []
  for key, val in self.VVGvduData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VVyKSB  = ("Home Menu", FFpYsh, [])
  VVx7qK  = None
  if VVs8GF:
   VVx7qK = ("Get JS" , boundFunction(self.VVrWOV, "/".join(self.VVGvduData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FF1Vl3(self, None, title=title, width=1200, header=header, VVKQR8=rows, VVrZ8Z=widths, VVbh3O=26, VVyKSB=VVyKSB, VVx7qK=VVx7qK, VVmxJZ="#0a00292B", VVEDc7="#0a002126", VVc1Ml="#0a002126", VVZoDW="#00000000", searchCol=2)
 def VVi64a(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CCAigr()
    if mode in (self.VVqCaD, self.VV6ZOq):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVrtEf(item, "num"         )
      name     = self.VVrtEf(item, "name"        )
      stream_id    = self.VVrtEf(item, "stream_id"       )
      stream_icon    = self.VVrtEf(item, "stream_icon"       )
      epg_channel_id   = self.VVrtEf(item, "epg_channel_id"      )
      added     = self.VVrtEf(item, "added"    , isDate=True )
      is_adult    = self.VVrtEf(item, "is_adult"       )
      category_id    = self.VVrtEf(item, "category_id"       )
      tv_archive    = self.VVrtEf(item, "tv_archive"       )
      name = processChanName.VVPrIw(name)
      if name:
       if mode == self.VVqCaD or mode == self.VV6ZOq and tv_archive == "1":
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVfGhP:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVrtEf(item, "num"         )
      name    = self.VVrtEf(item, "name"        )
      stream_id   = self.VVrtEf(item, "stream_id"       )
      stream_icon   = self.VVrtEf(item, "stream_icon"       )
      added    = self.VVrtEf(item, "added"    , isDate=True )
      is_adult   = self.VVrtEf(item, "is_adult"       )
      category_id   = self.VVrtEf(item, "category_id"       )
      container_extension = self.VVrtEf(item, "container_extension"     ) or "mp4"
      name = processChanName.VVPrIw(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVxVCt:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVrtEf(item, "num"        )
      name    = self.VVrtEf(item, "name"       )
      series_id   = self.VVrtEf(item, "series_id"      )
      cover    = self.VVrtEf(item, "cover"       )
      genre    = self.VVrtEf(item, "genre"       )
      episode_run_time = self.VVrtEf(item, "episode_run_time"    )
      category_id   = self.VVrtEf(item, "category_id"      )
      container_extension = self.VVrtEf(item, "container_extension"    ) or "mp4"
      name = processChanName.VVPrIw(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVIb7R(self, mode, title):
  cList, err = self.VV0IQm(mode)
  if cList and mode == self.VVnErL:
   cList = self.VVujdv(cList)
  if err:
   FFcgS7(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVmxJZ, VVEDc7, VVc1Ml, VVZoDW = self.VVBNqN(mode)
   mName = self.VVuB9i(mode)
   if   mode == self.VVpALX  : fMode = self.VVqCaD
   elif mode == self.VVl6y9  : fMode = self.VVfGhP
   elif mode == self.VVR64G : fMode = self.VVxVCt
   elif mode == self.VVnErL : fMode = self.VV6ZOq
   if mode == self.VVnErL:
    VVhD2a = None
   else:
    VVhD2a = ("Find in %s" % mName , boundFunction(self.VVXgGj, fMode) , [])
   VVxwOk   = ("Show List"   , boundFunction(self.VVkXnW, mode) , [])
   VVyKSB  = ("Home Menu"   , FFpYsh          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FF1Vl3(self, None, title=title, width=1200, header=header, VVKQR8=cList, VVrZ8Z=widths, VVbh3O=30, VVyKSB=VVyKSB, VVhD2a=VVhD2a, VVxwOk=VVxwOk, VVmxJZ=VVmxJZ, VVEDc7=VVEDc7, VVc1Ml=VVc1Ml, VVZoDW=VVZoDW)
  else:
   FFcgS7(self, "No list from server !", title=title)
  FFLk1N(self)
 def VV0IQm(self, mode):
  qUrl  = self.VVSjFt(mode, self.VVGvduData["playListURL"])
  txt, err = self.VVSLDf(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    processChanName = CCAigr()
    for item in tDict:
     category_id  = self.VVrtEf(item, "category_id"  )
     category_name = self.VVrtEf(item, "category_name" )
     parent_id  = self.VVrtEf(item, "parent_id"  )
     category_name = processChanName.VV4Vl6(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVujdv(self, catList):
  mode  = self.VV6ZOq
  qUrl  = self.VVSjFt(mode, self.VVGvduData["playListURL"])
  txt, err = self.VVSLDf(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVi64a(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVkXnW(self, mode, VVpjES, title, txt, colList):
  title = colList[1]
  FF1SeM(VVpjES, boundFunction(self.VVLh6W, mode, VVpjES, title, txt, colList), title="Downloading ...")
 def VVLh6W(self, mode, VVpjES, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVuB9i(mode) + " : "+ bName
  if   mode == self.VVpALX  : mode = self.VVqCaD
  elif mode == self.VVl6y9  : mode = self.VVfGhP
  elif mode == self.VVR64G : mode = self.VVxVCt
  elif mode == self.VVnErL : mode = self.VV6ZOq
  qUrl  = self.VVSjFt(mode, self.VVGvduData["playListURL"], catID)
  txt, err = self.VVSLDf(qUrl)
  list  = []
  if not err and mode in (self.VVqCaD, self.VVfGhP, self.VVxVCt, self.VV6ZOq):
   list, err = self.VVi64a(mode, txt)
  if err:
   FFcgS7(self, err, title=title)
  elif list:
   VVyKSB  = ("Home Menu"   , FFpYsh             , [])
   if mode in (self.VVqCaD, self.VV6ZOq):
    VVmxJZ, VVEDc7, VVc1Ml, VVZoDW = self.VVBNqN(mode)
    VVsbBT = (""     , boundFunction(self.VVNHfV, mode)     , [])
    VVx7qK = ("Download Options" , boundFunction(self.VVI39w, mode, "", "")  , [])
    VVhD2a = ("Options" , boundFunction(self.VVuoYE, 1, "lv", mode, bName)  , [])
    if mode == self.VVqCaD:
     VVxwOk = ("Play"    , boundFunction(self.VVtBnb, mode)     , [])
    elif mode == self.VV6ZOq:
     VVxwOk  = ("Programs", boundFunction(self.VVjoBU_fromIptvTable, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVDhPS  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVfGhP:
    VVmxJZ, VVEDc7, VVc1Ml, VVZoDW = self.VVBNqN(mode)
    VVxwOk  = ("Play"    , boundFunction(self.VVtBnb, mode)    , [])
    VVsbBT = (""     , boundFunction(self.VVNHfV, mode)    , [])
    VVx7qK = ("Download Options" , boundFunction(self.VVI39w, mode, "v", ""), [])
    VVhD2a = ("Options" , boundFunction(self.VVuoYE, 1, "v", mode, bName)  , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVDhPS  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVxVCt:
    VVmxJZ, VVEDc7, VVc1Ml, VVZoDW = self.VVBNqN("series2")
    VVxwOk  = ("Show Seasons", boundFunction(self.VVElww, mode) , [])
    VVsbBT = ("", boundFunction(self.VVjpyQ, mode)  , [])
    VVx7qK = None
    VVhD2a = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVDhPS  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FF1Vl3(self, None, title=title, header=header, VVKQR8=list, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=26, VVxwOk=VVxwOk, VVyKSB=VVyKSB, VVx7qK=VVx7qK, VVhD2a=VVhD2a, VVsbBT=VVsbBT, VVmxJZ=VVmxJZ, VVEDc7=VVEDc7, VVc1Ml=VVc1Ml, VVZoDW=VVZoDW, VVwgKR=True, searchCol=1)
  else:
   FFcgS7(self, "No Channels found !", title=title)
  FFLk1N(self)
 def VVjoBU_fromIptvTable(self, mode, bName, VVpjES, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVGvduData["playListURL"]
  ok_fnc  = boundFunction(self.VVf3Tb, hostUrl, chName, catId, streamId)
  FF1SeM(VVpjES, boundFunction(CC4M3v.VVjoBU, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVf3Tb(self, chUrl, chName, catId, streamId, VVpjES, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC4M3v.VVwjXv(chUrl)
   chNum = "333"
   refCode = CC4M3v.VV9uqR(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFvYTu(self, chUrl, VVonEU=False)
   self.session.open(CCG8uj)
  else:
   FFcgS7(self, "Incorrect Timestamp", pTitle)
 def VVElww(self, mode, VVpjES, title, txt, colList):
  title = colList[1]
  FF1SeM(VVpjES, boundFunction(self.VVm7FY, mode, VVpjES, title, txt, colList), title="Downloading ...")
 def VVm7FY(self, mode, VVpjES, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVSjFt(self.VV0AfO, self.VVGvduData["playListURL"], series_id)
  txt, err = self.VVSLDf(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVrtEf(tDict["info"], "name"   )
      category_id = self.VVrtEf(tDict["info"], "category_id" )
      icon  = self.VVrtEf(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      processChanName = CCAigr()
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVrtEf(EP, "id"     )
        episode_num   = self.VVrtEf(EP, "episode_num"   )
        epTitle    = self.VVrtEf(EP, "title"     )
        container_extension = self.VVrtEf(EP, "container_extension" )
        seasonNum   = self.VVrtEf(EP, "season"    )
        epTitle = processChanName.VVPrIw(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFcgS7(self, err, title=title)
  elif list:
   VVyKSB = ("Home Menu"   , FFpYsh             , [])
   VVx7qK = ("Download Options" , boundFunction(self.VVI39w, mode, "s", title) , [])
   VVhD2a = ("Options" , boundFunction(self.VVuoYE, 0, "s", mode, title)  , [])
   VVsbBT = (""     , boundFunction(self.VVNHfV, mode)     , [])
   VVxwOk  = ("Play"    , boundFunction(self.VVtBnb, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVDhPS  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FF1Vl3(self, None, title=title, header=header, VVKQR8=list, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=26, VVyKSB=VVyKSB, VVx7qK=VVx7qK, VVxwOk=VVxwOk, VVsbBT=VVsbBT, VVhD2a=VVhD2a, VVmxJZ="#0a00292B", VVEDc7="#0a002126", VVc1Ml="#0a002126", VVZoDW="#00000000")
  else:
   FFcgS7(self, "No Channels found !", title=title)
  FFLk1N(self)
 def VVXgGj(self, mode, VVpjES, title, txt, colList):
  VVlZjX = []
  VVlZjX.append(("Keyboard"  , "manualEntry"))
  VVlZjX.append(("From Filter" , "fromFilter"))
  FFqaQ9(self, boundFunction(self.VV66Pa, VVpjES, mode), title="Input Type", VVlZjX=VVlZjX, width=400)
 def VV66Pa(self, VVpjES, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFZyEN(self, boundFunction(self.VVAsMm, VVpjES, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCPqp9(self)
    filterObj.VVbIsl(boundFunction(self.VVAsMm, VVpjES, mode))
 def VVAsMm(self, VVpjES, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CCAigr()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVCydI(words):
     FFcgS7(self, processChanName.VVZHxP(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CCbQK1, barTheme=CCbQK1.VVMxXb
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VVEjmg, VVpjES, mode, title, words, toFind, asPrefix, processChanName)
         , VVs5HI = boundFunction(self.VVBEng, mode, toFind, title))
   else:
    FFcgS7(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VVEjmg(self, VVpjES, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVuznc(VVpjES.VV9oe5())
  progBarObj.VVZTL8 = []
  for row in VVpjES.VVbYXo():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVBfFC(1)
   progBarObj.VVfO7V_fromIptvFind(catName)
   qUrl  = self.VVSjFt(mode, self.VVGvduData["playListURL"], catID)
   txt, err = self.VVSLDf(qUrl)
   if not err:
    tList, err = self.VVi64a(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VVPrIw(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VVqCaD:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VVZTL8.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVfGhP:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VVZTL8.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVxVCt:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VVZTL8.append((num, name, catID, ID, genre, catName, ext, cover))
 def VVBEng(self, mode, toFind, title, VV9SAG, VVZTL8, threadCounter, threadTotal, threadErr):
  if VVZTL8:
   title = self.VVALvf(mode, toFind)
   if mode == self.VVqCaD or mode == self.VVfGhP:
    if mode == self.VVfGhP : typ = "v"
    else          : typ = ""
    bName   = CC4M3v.VV7A0S_forBouquet(toFind)
    VVxwOk  = ("Play"     , boundFunction(self.VVtBnb, mode)    , [])
    VVx7qK = ("Download Options" , boundFunction(self.VVI39w, mode, typ, ""), [])
    VVhD2a = ("Options" , boundFunction(self.VVuoYE, 1, "fnd", mode, bName)  , [])
   elif mode == self.VVxVCt:
    VVxwOk  = ("Show Seasons"  , boundFunction(self.VVElww, mode)    , [])
    VVhD2a = None
    VVx7qK = None
   VVsbBT  = (""     , boundFunction(self.VVNHfV, mode)    , [])
   VVyKSB  = ("Home Menu"   , FFpYsh            , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVDhPS  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVpjES = FF1Vl3(self, None, title=title, header=header, VVKQR8=VVZTL8, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=26, VVxwOk=VVxwOk, VVyKSB=VVyKSB, VVx7qK=VVx7qK, VVhD2a=VVhD2a, VVsbBT=VVsbBT, VVmxJZ="#0a00292B", VVEDc7="#0a002126", VVc1Ml="#0a002126", VVZoDW="#00000000", VVwgKR=True, searchCol=1)
   if not VV9SAG:
    FFLk1N(VVpjES, "Stopped" , 1000)
  else:
   if VV9SAG:
    FFcgS7(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVv7Pu(self, mode, colList):
  if mode in (self.VVqCaD, self.VV6ZOq):
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVfGhP:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFnTaU(chName)
  url = self.VVGvduData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVwjXv(url)
  refCode = self.VV9uqR(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVNHfV(self, mode, VVpjES, title, txt, colList):
  FF1SeM(VVpjES, boundFunction(self.VVhFBT, mode, VVpjES, title, txt, colList))
 def VVhFBT(self, mode, VVpjES, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVv7Pu(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFqUR7(self, fncMode=CC6WQp.VV5Qo4, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVjpyQ(self, mode, VVpjES, title, txt, colList):
  FF1SeM(VVpjES, boundFunction(self.VVQlE2, mode, VVpjES, title, txt, colList))
 def VVQlE2(self, mode, VVpjES, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFqUR7(self, fncMode=CC6WQp.VVUeMj, chName=name, text=txt, picUrl=Cover)
 def VVYGJw(self, mode, bName, VVpjES, title, txt, colList):
  url = self.VVGvduData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVwjXv(url)
  bNameFile = CC4M3v.VV7A0S_forBouquet(bName)
  num  = 0
  path = VVf9y4 + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVf9y4 + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   isMulti = VVpjES.VVZkVN
   for ndx, row in enumerate(VVpjES.VVbYXo()):
    chName, chUrl, picUrl, refCode = self.VVv7Pu(mode, row)
    if not isMulti or VVpjES.VVVT4o(ndx):
     f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
     f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
     totChange += 1
  FFDa4p(os.path.basename(path))
  self.VV1mXo(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVI39w(self, mode, typ, seriesName, VVpjES, title, txt, colList):
  VVlZjX = []
  isMulti = VVpjES.VVZkVN
  tot  = VVpjES.VVY5cz()
  if isMulti:
   if tot < 1:
    FFLk1N(VVpjES, "Select rows first.", 1000)
    return
   else:
    s = "s" if tot > 1 else ""
    name = "%d Selected" % tot
  else:
   s = "s"
   name = "ALL"
  VVlZjX.append(("Download %s PIcon%s" % (name, s), "dnldPicons" ))
  if typ:
   VVlZjX.append(VVZYy7)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVlZjX.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVlZjX.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVlZjX.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCsRnB.VVU3Sj():
    VVlZjX.append(VVZYy7)
    VVlZjX.append(("Download Manager"      , "dload_stat" ))
  FFqaQ9(self, boundFunction(self.VVzaO1_VVgPwP, VVpjES, mode, typ, seriesName, colList), title="Download Options", VVlZjX=VVlZjX)
 def VVzaO1_VVgPwP(self, VVpjES, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVWJfS(VVpjES, mode)
   elif item == "dnldSel"  : self.VVppmW(VVpjES, mode, typ, colList, True)
   elif item == "addSel"  : self.VVppmW(VVpjES, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVd9rH(VVpjES, mode, typ, seriesName)
   elif item == "dload_stat" : CCsRnB.VVyzTQ(self)
 def VVppmW(self, VVpjES, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVbF4B(mode, typ, colList)
  if startDnld:
   CCsRnB.VVFgCz_url(self, decodedUrl)
  else:
   self.VVgPwP_FFixrz(VVpjES, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVd9rH(self, VVpjES, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVpjES.VVbYXo():
   chName, decodedUrl = self.VVbF4B(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVgPwP_FFixrz(VVpjES, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVgPwP_FFixrz(self, VVpjES, title, chName, decodedUrl_list, startDnld):
  FFixrz(self, boundFunction(self.VVSR9j, VVpjES, decodedUrl_list, startDnld), chName, title=title)
 def VVSR9j(self, VVpjES, decodedUrl_list, startDnld):
  added, skipped = CCsRnB.VVNBh2List(decodedUrl_list)
  FFLk1N(VVpjES, "Added", 1000)
 def VVbF4B(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVv7Pu(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV8Ej2(mode, colList)
   refCode, chUrl = self.VVImmn(self.VV6ARo, self.VVbM8z, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFvST6(chUrl)
  return chName, decodedUrl
 def VVWJfS(self, VVpjES, mode):
  if os.system(FFA9Vj("which ffmpeg")) == 0:
   self.session.open(CCbQK1, barTheme=CCbQK1.VVlj0K
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VVDKeu, VVpjES, mode)
       , VVs5HI = self.VVALgx)
  else:
   FFixrz(self, boundFunction(CC4M3v.VVJ3MZ, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVALgx(self, VV9SAG, VVZTL8, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVZTL8["proces"], VVZTL8["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVZTL8["ok"], VVZTL8["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVZTL8["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVZTL8["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVZTL8["badURL"]
  txt += "Download Failure\t: %d\n"   % VVZTL8["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVZTL8["path"]
  if not VV9SAG  : color = "#11402000"
  elif VVZTL8["err"]: color = "#11201000"
  else     : color = None
  if VVZTL8["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVZTL8["err"], txt)
  title = "PIcons Download Result"
  if not VV9SAG:
   title += "  (cancelled)"
  FFn7o1(self, txt, title=title, VVc1Ml=color)
 def VVDKeu(self, VVpjES, mode, progBarObj):
  isMulti = VVpjES.VVZkVN
  if isMulti : totRows = VVpjES.VVY5cz()
  else  : totRows = VVpjES.VV9oe5()
  progBarObj.VVuznc(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CCwdjc.VVW1YO()
  progBarObj.VVZTL8 = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for rowNum, row in enumerate(VVpjES.VVbYXo()):
    if progBarObj.isCancelled:
     break
    if not isMulti or VVpjES.VVVT4o(rowNum):
     progBarObj.VVZTL8["proces"] += 1
     progBarObj.VVBfFC(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV8Ej2(mode, row)
      refCode = CC4M3v.VV9uqR(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVO7Ko(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVv7Pu(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       progBarObj.VVZTL8["attempt"] += 1
       path, err = FFDt8N(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        progBarObj.VVZTL8["ok"] += 1
        if FFRl9s(path) > 0:
         cmd = ""
         if not mode == CC4M3v.VVqCaD:
          cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
         cmd += FFA9Vj("mv -f '%s' '%s'" % (path, pPath)) + ";"
         os.system(cmd)
        else:
         progBarObj.VVZTL8["size0"] += 1
         os.system(FFA9Vj("rm -f '%s'" % path))
       elif err:
        progBarObj.VVZTL8["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         progBarObj.VVZTL8["err"] = err.title()
         break
      else:
       progBarObj.VVZTL8["exist"] += 1
     else:
      progBarObj.VVZTL8["badURL"] += 1
  except:
   pass
 @staticmethod
 def VVJ3MZ(SELF):
  cmd = FFlY7a(VV3kNP, "ffmpeg")
  if cmd : FFLwr1(SELF, cmd, title="Installing FFmpeg")
  else : FFMiwh(SELF)
 def VV2i1d(self):
  self.session.open(CCbQK1, barTheme=CCbQK1.VVlj0K
      , titlePrefix = ""
      , fncToRun  = self.VVjk67
      , VVs5HI = self.VVHRcT)
 def VVjk67(self, progBarObj):
  bName = FFVrp5()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  progBarObj.VVZTL8 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = FF1fee()
  if not progBarObj or progBarObj.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   progBarObj.VVuznc(totCh)
   for serv in services:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVBfFC(1)
    progBarObj.VVfO7V_fromImportEPG(totEpgOK, uChName)
    fullRef  = serv[0]
    if FFS5Go(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFvST6(fullRef)
     span = iSearch(r"(mode=.+end=)", fullRef, IGNORECASE)
     if span:
      m3u_Url = CCIsu8.VVfVR2(fullRef)
      uType, uHost, uUser, uPass, uId, uChName  = CC4M3v.VVMlKY(fullRef)
      uType, uHost, uUser, uPass, uId, uChName1 = CC4M3v.VVMlKY(m3u_Url)
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CC4M3v.VVMlKY(m3u_Url)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CC4M3v.VVkKQF(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CC6WQp.VVMRmW(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
      else:
       pass
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if progBarObj:
     progBarObj.VVZTL8 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   progBarObj.VVZTL8 = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VVHRcT(self, VV9SAG, VVZTL8, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVZTL8
  title = "IPTV EPG Import"
  if err:
   FFcgS7(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FF0hQa(str(totNotIptv), VVaqQK)
    if totServErr : txt += "Server Errors\t: %s\n" % FF0hQa(str(totServErr) + t1, VVaqQK)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FF0hQa(str(totInv), VVaqQK)
   if not VV9SAG:
    title += "  (stopped)"
   FFn7o1(self, txt, title=title)
 @staticmethod
 def VVkKQF(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC4M3v.VVwjXv(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CC4M3v.VVSLDf(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CC4M3v.VVrtEf(item, "description" , is_base64=True ).replace("\n", " .. ")
    has_archive   = CC4M3v.VVrtEf(item, "has_archive"      )
    lang    = CC4M3v.VVrtEf(item, "lang"        ).upper()
    now_playing   = CC4M3v.VVrtEf(item, "now_playing"      )
    start    = CC4M3v.VVrtEf(item, "start"        )
    start_timestamp  = CC4M3v.VVrtEf(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CC4M3v.VVrtEf(item, "start_timestamp"     )
    stop_timestamp  = CC4M3v.VVrtEf(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CC4M3v.VVrtEf(item, "stop_timestamp"      )
    tTitle    = CC4M3v.VVrtEf(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VV9uqR(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CC4M3v.VV9aEX(catID, MAX_4b)
  TSID = CC4M3v.VV9aEX(chNum, MAX_4b)
  ONID = CC4M3v.VV9aEX(chNum, MAX_4b)
  NS  = CC4M3v.VV9aEX(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VV9aEX(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VV7A0S_forBouquet(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVBNqN(mode):
  if   mode in ("itv"  , CC4M3v.VVpALX)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CC4M3v.VVl6y9)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CC4M3v.VVR64G) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CC4M3v.VVnErL) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CC4M3v.VV6ZOq    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 @staticmethod
 def VVd5MC(orExportPath=False):
  path = CFG.iptvHostsPath.getValue()
  if not pathExists(path) or path == VVRVLV:
   if orExportPath : path = CFG.exportedTablesPath.getValue()
   else   : path ="/"
  return FFRZql(path)
 @staticmethod
 def VVjoBU(SELF, hostUrl, chName, streamId, ok_fnc):
  title = "Catchup TV Programs"
  pList, err = CC4M3v.VVkKQF(hostUrl, streamId, True)
  if err:
   FFcgS7(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVmxJZ, VVEDc7, VVc1Ml, VVZoDW = CC4M3v.VVBNqN("")
   VVyKSB = ("Home Menu" , FFpYsh, [])
   VVxwOk  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVDhPS  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FF1Vl3(SELF, None, title="Programs for : " + chName, header=header, VVKQR8=pList, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=24, VVxwOk=VVxwOk, VVyKSB=VVyKSB, VVmxJZ=VVmxJZ, VVEDc7=VVEDc7, VVc1Ml=VVc1Ml, VVZoDW=VVZoDW)
  else:
   FFcgS7(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVzW3M(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 @staticmethod
 def VVQRH5(SELF, isPortal, line, VV2FRKObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CC4M3v.VVd5MC(orExportPath=True)
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFcgS7(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFkpHN(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFcgS7(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVuoYE(self, nameCol, source, mode, bName, VVpjES, title, txt, colList):
  isMulti = VVpjES.VVZkVN
  mSel = CCTy7H(self, VVpjES, nameCol, addSep=False)
  title = ""
  if isMulti:
   tot = VVpjES.VVY5cz()
   if tot > 0:
    s = "s" if tot > 1 else ""
    title = "Add %d Service%s to Bouquet" % (tot, s)
  else:
   title = "Add ALL to Bouquet"
  if title:
   mSel.VVlZjX.append(VVZYy7)
   mSel.VVlZjX.append((title        , "addToBoquet"))
  FFqaQ9(self, boundFunction(self.VVJJUy, mSel, source, mode, bName, VVpjES, title, txt, colList), title="Options", VVlZjX=mSel.VVlZjX)
 def VVJJUy(self, mSelObj, source, mode, bName, VVpjES, title, txt, colList, item):
  if item:
   if   item == "multSelEnab"     : mSelObj.VVpjES.VVLcVH(True)
   elif item == "MultSelDisab"     : mSelObj.VVpjES.VVLcVH(False)
   elif item == "selectAll"     : mSelObj.VVpjES.VVASNB()
   elif item == "unselectAll"     : mSelObj.VVpjES.VVMKmc()
   elif item == "addToBoquet"     :
    if   source == "pEp" : fnc = self.VVJfrK
    elif source == "pCh" : fnc = self.VVJfrK
    elif source == "m3Ch" : fnc = self.VVEEBX
    elif source == "lv"  : fnc = self.VVYGJw
    elif source == "v"  : fnc = self.VVYGJw
    elif source == "s"  : fnc = self.VVYGJw
    elif source == "fnd" : fnc = self.VVYGJw
    else     : return
    FF1SeM(VVpjES, boundFunction(fnc, mode, bName, VVpjES, title, txt, colList), title="Adding Channels ...")
class CCqJfY(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FF8X8q(VVycF3, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVFAoQ  = 0
  self.VV52W0 = 1
  self.VVCxn7  = 2
  VVlZjX = []
  VVlZjX.append(("Find in All Service (from filter)" , "VVomVG" ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Find in All (Manual Entry)"   , "VVygZp"    ))
  VVlZjX.append(("Find in TV"       , "VVqVAH"    ))
  VVlZjX.append(("Find in Radio"      , "VVE9sG"   ))
  if self.VVWrTz():
   VVlZjX.append(VVZYy7)
   VVlZjX.append(("Hide Channel: %s" % self.servName , "VVLuQu"   ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Zap History"       , "VVD3QX"    ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("IPTV Tools"       , "iptv"      ))
  VVlZjX.append(("PIcons Tools"       , "PIconsTools"     ))
  VVlZjX.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FFNPyH(self, VVlZjX=VVlZjX, title=title)
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FFhGNA(self["myMenu"])
  FFwAWu(self)
  if self.isFindMode:
   self.VV0BCo(self.VVWUzH())
 def VVEvnY(self):
  global VVWK7p
  VVWK7p = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVygZp"    : self.VVygZp()
   elif item == "VVomVG" : self.VVomVG()
   elif item == "VVqVAH"    : self.VVqVAH()
   elif item == "VVE9sG"   : self.VVE9sG()
   elif item == "VVLuQu"   : self.VVLuQu()
   elif item == "VVD3QX"    : self.VVD3QX()
   elif item == "iptv"       : self.session.open(CC4M3v)
   elif item == "PIconsTools"     : self.session.open(CCwdjc)
   elif item == "ChannelsTools"    : self.session.open(CCYAlZ)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVqVAH(self) : self.VV0BCo(self.VVFAoQ)
 def VVE9sG(self) : self.VV0BCo(self.VV52W0)
 def VVygZp(self) : self.VV0BCo(self.VVCxn7)
 def VV0BCo(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFZyEN(self, boundFunction(self.VVfuAk, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVomVG(self):
  filterObj = CCPqp9(self)
  filterObj.VVbIsl(self.VV9nr8)
 def VV9nr8(self, item):
  self.VVfuAk(self.VVCxn7, item)
 def VVWrTz(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFS5Go(self.refCode)        : return False
  return True
 def VVfuAk(self, mode, VVFAil):
  FF1SeM(self, boundFunction(self.VVaP7i, mode, VVFAil), title="Searching ...")
 def VVaP7i(self, mode, VVFAil):
  if VVFAil:
   self.findTxt = VVFAil
   if   mode == self.VVFAoQ  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VV52W0 : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVFAil)
   if len(title) > 55:
    title = title[:55] + ".."
   VVXJa5 = self.VVkiZR(VVFAil, servTypes)
   if self.isFindMode or mode == self.VVCxn7:
    VVXJa5 += self.VVCqhz(VVFAil)
   if VVXJa5:
    VVXJa5.sort(key=lambda x: x[0].lower())
    VV4h63 = self.VVQ1qA
    VVxwOk  = ("Zap"   , self.VVOh68    , [])
    VVx7qK = ("Current Service", self.VVf0Yx , [])
    VVhD2a = ("Options"  , self.VVK6lr , [])
    VVsbBT = (""    , self.VVItGT , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVDhPS  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FF1Vl3(self, None, title=title, header=header, VVKQR8=VVXJa5, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=26, VVxwOk=VVxwOk, VV4h63=VV4h63, VVx7qK=VVx7qK, VVhD2a=VVhD2a, VVsbBT=VVsbBT)
   else:
    self.VV0BCo(self.VVWUzH())
    FFkpHN(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVkiZR(self, VVFAil, servTypes):
  VVXJa5 = []
  if CCYAlZ.VV6Q6P(servTypes):
   VVzNl1, VVsqeV = FFigNV()
   tp   = CC37SE()
   words, asPrefix = CCPqp9.VVn2jm(VVFAil)
   colorYellow  = CCN5Bb.VVpL5B(VVg4jx)
   colorWhite  = CCN5Bb.VVpL5B(VV3rkc)
   for s in VVKQR8:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFru8i(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVzNl1:
        STYPE = VVsqeV[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVS5CI(refCode)
       if not "-S" in syst:
        sat = syst
       VVXJa5.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVXJa5
 def VVCqhz(self, VVFAil):
  VVFAil = VVFAil.lower()
  VVXJa5 = []
  colorYellow  = CCN5Bb.VVpL5B(VVg4jx)
  colorWhite  = CCN5Bb.VVpL5B(VV3rkc)
  for b in FFojgY():
   VVnBh0  = b[0]
   VVv3fH  = b[1].toString()
   VVMd2a = eServiceReference(VVv3fH)
   VVXfmg = FFjNff(VVMd2a)
   for service in VVXfmg:
    refCode  = service[0]
    if FFS5Go(refCode):
     servName = service[1]
     if VVFAil in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVFAil), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVXJa5.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVXJa5
 def VVWUzH(self):
  VVSQ4S = InfoBar.instance
  if VVSQ4S:
   VVOVrd = VVSQ4S.servicelist
   if VVOVrd:
    return VVOVrd.mode == 1
  return self.VVCxn7
 def VVQ1qA(self, VVpjES):
  self.close()
  VVpjES.cancel()
 def VVOh68(self, VVpjES, title, txt, colList):
  FFvYTu(VVpjES, colList[2], VVonEU=False, checkParentalControl=True)
 def VVf0Yx(self, VVpjES, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(VVpjES)
  if refCode:
   VVpjES.VVkrJW(2, FFW7yf(refCode, iptvRef, chName), True)
 def VVK6lr(self, VVpjES, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CCTy7H(self, VVpjES, 2)
  mSel.VVul6f(servName, refCode)
 def VVItGT(self, VVpjES, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFqUR7(self, fncMode=CC6WQp.VVIMd0, refCode=refCode, chName=chName, text=txt)
 def VVLuQu(self):
  FFixrz(self, self.VVzwu8, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVzwu8(self):
  ret = FF0zlK(self.refCode, True)
  if ret:
   self.VVTDMl()
   self.close()
  else:
   FFLk1N(self, "Cannot change state" , 1000)
 def VVTDMl(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVk8vo()
  except:
   self.VVFo3G()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFTZUA(self, serviceRef)
 def VVFaMl(self):
  VVSQ4S = InfoBar.instance
  if VVSQ4S:
   VVOVrd = VVSQ4S.servicelist
   if VVOVrd:
    VVOVrd.setMode()
 def VVk8vo(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVSQ4S = InfoBar.instance
   if VVSQ4S:
    VVOVrd = VVSQ4S.servicelist
    if VVOVrd:
     hList = VVOVrd.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVOVrd.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVOVrd.history  = newList
       VVOVrd.history_pos = pos
 def VVFo3G(self):
  VVSQ4S = InfoBar.instance
  if VVSQ4S:
   VVOVrd = VVSQ4S.servicelist
   if VVOVrd:
    VVOVrd.history  = []
    VVOVrd.history_pos = 0
 def VVD3QX(self):
  VVSQ4S = InfoBar.instance
  VVXJa5 = []
  if VVSQ4S:
   VVOVrd = VVSQ4S.servicelist
   if VVOVrd:
    VVzNl1, VVsqeV = FFigNV()
    for chParams in VVOVrd.history:
     refCode = chParams[-1].toString()
     chName = FFlcEP(refCode)
     isIptv = FFS5Go(refCode)
     if isIptv: sat = "-"
     else  : sat = FFru8i(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVzNl1:
       STYPE = VVsqeV[sTypeInt]
     VVXJa5.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVXJa5:
   VVxwOk  = ("Zap"   , self.VVRBqo   , [])
   VVhD2a = ("Clear History" , self.VVJpgS   , [])
   VVsbBT = (""    , self.VVBzykFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVDhPS  = (LEFT    , LEFT   , CENTER , LEFT   )
   FF1Vl3(self, None, title=title, header=header, VVKQR8=VVXJa5, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=28, VVxwOk=VVxwOk, VVhD2a=VVhD2a, VVsbBT=VVsbBT)
  else:
   FFkpHN(self, "Not found", title=title)
 def VVRBqo(self, VVpjES, title, txt, colList):
  FFvYTu(VVpjES, colList[3], VVonEU=False, checkParentalControl=True)
 def VVJpgS(self, VVpjES, title, txt, colList):
  FFixrz(self, boundFunction(self.VVXY2S, VVpjES), "Clear Zap History ?")
 def VVXY2S(self, VVpjES):
  self.VVFo3G()
  VVpjES.cancel()
 def VVBzykFromZapHistory(self, VVpjES, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFqUR7(self, fncMode=CC6WQp.VVqm9R, refCode=refCode, chName=chName, text=txt)
class CCwdjc(Screen):
 VVV493   = 0
 VVAjaD  = 1
 VVl3Wz  = 2
 VVGmY2  = 3
 VVFtWL  = 4
 VV0KvZ  = 5
 VVNoJV  = 6
 VVrQPN  = 7
 VVlv60 = 8
 VVsgGh = 9
 def __init__(self, session):
  self.skin, self.skinParam = FF8X8q(VVGhHa, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFNPyH(self, self.Title)
  FFkV23(self["keyRed"] , "OK = Zap")
  FFkV23(self["keyGreen"] , "Current Service")
  FFkV23(self["keyYellow"], "Page Options")
  FFkV23(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCwdjc.VVW1YO()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVKQR8    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVZ2vX        ,
   "green"   : self.VVrRzg       ,
   "yellow"  : self.VVMkIt        ,
   "blue"   : self.VVT5Ei        ,
   "menu"   : self.VVpoCD        ,
   "info"   : self.VVBzyk         ,
   "up"   : self.VVUTv0          ,
   "down"   : self.VVtNKR         ,
   "left"   : self.VVCwsY         ,
   "right"   : self.VVNcXN         ,
   "pageUp"  : boundFunction(self.VVUNmC, True) ,
   "chanUp"  : boundFunction(self.VVUNmC, True) ,
   "pageDown"  : boundFunction(self.VVUNmC, False) ,
   "chanDown"  : boundFunction(self.VVUNmC, False) ,
   "next"   : self.VVfM08        ,
   "last"   : self.VVUFJo         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FFXHxA(self)
  FFZH71(self)
  FFxTkM(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FF1SeM(self, boundFunction(self.VVA36Y, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVpoCD(self):
  if not self.isBusy:
   VVlZjX = []
   VVlZjX.append(("Statistics"           , "VVmdyd"    ))
   VVlZjX.append(VVZYy7)
   VVlZjX.append(("Suggest PIcons for Current Channel"     , "VVWR64"   ))
   VVlZjX.append(("Set to Current Channel (copy file)"     , "VVEsH9_file"  ))
   VVlZjX.append(("Set to Current Channel (as SymLink)"     , "VVEsH9_link"  ))
   VVlZjX.append(VVZYy7)
   VVlZjX.append(CCwdjc.VVmgZx())
   VVlZjX.append(VVZYy7)
   if self.filterTitle == "PIcons without Channels":
    c = VVaqQK
    VVlZjX.append((FF0hQa("Move Unused PIcons to a Directory", c) , "VVqkL6"  ))
    VVlZjX.append((FF0hQa("DELETE Unused PIcons", c)    , "VV1iGF" ))
    VVlZjX.append(VVZYy7)
   VVlZjX.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVZb5p"  ))
   VVlZjX.append(VVZYy7)
   VVlZjX += CCwdjc.VVJqC5()
   VVlZjX.append(VVZYy7)
   VVlZjX.append(("RCU Keys Help"          , "VVDtQr"    ))
   FFqaQ9(self, self.VVzaO1, title=self.Title, VVlZjX=VVlZjX)
 def VVzaO1(self, item=None):
  if item is not None:
   if   item == "VVmdyd"     : self.VVmdyd()
   elif item == "VVWR64"    : self.VVWR64()
   elif item == "VVEsH9_file"   : self.VVEsH9(0)
   elif item == "VVEsH9_link"   : self.VVEsH9(1)
   elif item == "VVYYcL_file"  : self.VVYYcL(0)
   elif item == "VVYYcL_link"  : self.VVYYcL(1)
   elif item == "VVzeZG"   : self.VVzeZG()
   elif item == "VVyRre"  : self.VVyRre()
   elif item == "VVqkL6"    : self.VVqkL6()
   elif item == "VV1iGF"   : self.VV1iGF()
   elif item == "VVZb5p"   : self.VVZb5p()
   elif item == "VVfGFJ"   : CCwdjc.VVfGFJ(self)
   elif item == "VVonFB"   : CCwdjc.VVonFB(self)
   elif item == "findPiconBrokenSymLinks"  : CCwdjc.VVKuWE(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCwdjc.VVKuWE(self, False)
   elif item == "VVDtQr"      : self.VVDtQr()
 def VVMkIt(self):
  if not self.isBusy:
   VVlZjX = []
   VVlZjX.append(("Go to First PIcon"  , "VV4uFD"  ))
   VVlZjX.append(("Go to Last PIcon"   , "VVs0tI"  ))
   VVlZjX.append(VVZYy7)
   VVlZjX.append(("Sort by Channel Name"     , "sortByChan" ))
   VVlZjX.append(("Sort by File Name"  , "sortByFile" ))
   VVlZjX.append(VVZYy7)
   VVlZjX.append(("Find from File List .." , "VV6PcP" ))
   FFqaQ9(self, self.VVUv6O, title=self.Title, VVlZjX=VVlZjX)
 def VVUv6O(self, item=None):
  if item is not None:
   if   item == "VV4uFD"   : self.VV4uFD()
   elif item == "VVs0tI"   : self.VVs0tI()
   elif item == "sortByChan"  : self.VVGiKM(2)
   elif item == "sortByFile"  : self.VVGiKM(0)
   elif item == "VV6PcP"  : self.VV6PcP()
 def VVDtQr(self):
  FFepKH(self, VV05tg + "_help_picons", "PIcons Manager (Keys Help)")
 def VVUTv0(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVs0tI()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVyCSA()
 def VVtNKR(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV4uFD()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVyCSA()
 def VVCwsY(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVs0tI()
  else:
   self.curCol -= 1
   self.VVyCSA()
 def VVNcXN(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV4uFD()
  else:
   self.curCol += 1
   self.VVyCSA()
 def VVUFJo(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVyCSA(True)
 def VVfM08(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVyCSA(True)
 def VV4uFD(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVyCSA(True)
 def VVs0tI(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVyCSA(True)
 def VV6PcP(self):
  VVlZjX = []
  for item in self.VVKQR8:
   VVlZjX.append((item[0], item[0]))
  FFqaQ9(self, self.VVbqrV, title='PIcons ".png" Files', VVlZjX=VVlZjX, VVsug5=True)
 def VVbqrV(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVh1ZJ(ndx)
 def VVZ2vX(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVqIaj()
   if refCode:
    FFvYTu(self, refCode)
    self.VV4dPv()
    self.VVotfs()
 def VVUNmC(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VV4dPv()
   self.VVotfs()
  except:
   pass
 def VVrRzg(self):
  if self["keyGreen"].getVisible():
   self.VVh1ZJ(self.curChanIndex)
 def VVh1ZJ(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVyCSA(True)
  else:
   FFLk1N(self, "Not found", 1000)
 def VVGiKM(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FF1SeM(self, boundFunction(self.VVA36Y, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVEsH9(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVqIaj()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVlZjX = []
     VVlZjX.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVlZjX.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFqaQ9(self, boundFunction(self.VVMMWF, mode, curChF, selPiconF), VVlZjX=VVlZjX, title="Current Channel PIcon (already exists)")
    else:
     self.VVMMWF(mode, curChF, selPiconF, "overwrite")
   else:
    FFcgS7(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFcgS7(self, "Could not read current channel info. !", title=title)
 def VVMMWF(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FF1SeM(self, boundFunction(self.VVA36Y, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVYYcL(self, mode):
  pass
 def VVzeZG(self):
  pass
 def VVyRre(self):
  pass
 def VVqkL6(self):
  defDir = FFRZql(CCwdjc.VVW1YO() + "picons_backup")
  os.system(FFA9Vj("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(boundFunction(self.VV03aK, defDir), boundFunction(CCs7ea
         , mode=CCs7ea.VVIOWu, VVuLbb=CCwdjc.VVW1YO()))
 def VV03aK(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCwdjc.VVW1YO():
    FFcgS7(self, "Cannot move to same directory !", title=title)
   else:
    if not FFRZql(path) == FFRZql(defDir):
     self.VVkOZi(defDir)
    FFixrz(self, boundFunction(FF1SeM, self, boundFunction(self.VVV14U, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVKQR8), path), title=title)
  else:
   self.VVkOZi(defDir)
 def VVV14U(self, title, defDir, toPath):
  try:
   from shutil import move as iMove
  except:
   self.VVkOZi(defDir)
   FFcgS7(self, 'Could not load "shutil" module !', title=title)
   return
  toPath = FFRZql(toPath)
  pPath = CCwdjc.VVW1YO()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVKQR8:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVKQR8)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFn7o1(self, txt, title=title, VVc1Ml="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VV0hYn("all")
 def VVkOZi(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VV1iGF(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVKQR8)
  s = "s" if tot > 1 else ""
  FFixrz(self, boundFunction(FF1SeM, self, boundFunction(self.VVfRa9, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, s), title=title)
 def VVfRa9(self, title):
  pPath = CCwdjc.VVW1YO()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVKQR8:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVKQR8)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FF0hQa(str(totErr), VVaqQK)
  FFn7o1(self, txt, title=title)
 def VVZb5p(self):
  lines = FFfDK7("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFixrz(self, boundFunction(self.VV8amB, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVEkk8=True)
  else:
   FFkpHN(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VV8amB(self, fList):
  os.system(FFA9Vj("find -L '%s' -type l -delete" % self.pPath))
  FFkpHN(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVBzyk(self):
  FF1SeM(self, self.VVcsgW)
 def VVcsgW(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVqIaj()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FF0hQa("PIcon Directory:\n", VV3UWE)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FFvMsU(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFvMsU(path)
   txt += FF0hQa("PIcon File:\n", VV3UWE)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFfDK7(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FF0hQa("Found %d SymLink%s to this file from:\n" % (tot, s), VV3UWE)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFlcEP(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FF0hQa(tChName, VVeO4o)
     else  : tChName = ""
     txt += "  %s%s\n" % (FF0hQa(line, VV7bzw), tChName)
    txt += "\n"
   if chName:
    txt += FF0hQa("Channel:\n", VV3UWE)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FF0hQa(chName, VVeO4o)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FF0hQa("Remarks:\n", VV3UWE)
    txt += "  %s\n" % FF0hQa("Unused", VVaqQK)
  else:
   txt = "No info found"
  FFqUR7(self, fncMode=CC6WQp.VV4N6S, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVqIaj(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVKQR8[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFsWCY(sat)
  return fName, refCode, chName, sat, inDB
 def VV4dPv(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVKQR8):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVotfs(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVqIaj()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FF0hQa("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VV3UWE))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVqIaj()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FF0hQa(self.curChanName, VVg4jx)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVmdyd(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VVKQR8:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFmclR("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFn7o1(self, txt, title=self.Title)
 def VVT5Ei(self):
  if not self.isBusy:
   VVlZjX = []
   VVlZjX.append(("All"         , "all"   ))
   VVlZjX.append(VVZYy7)
   VVlZjX.append(("Used by Channels"      , "used"  ))
   VVlZjX.append(("Unused PIcons"      , "unused"  ))
   VVlZjX.append(VVZYy7)
   VVlZjX.append(("PIcons Files"       , "pFiles"  ))
   VVlZjX.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVlZjX.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVlZjX.append(VVZYy7)
   VVlZjX.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVlZjX.append(VVZYy7)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFMf9K(val)
      VVlZjX.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCPqp9(self)
   filterObj.VVGlra(VVlZjX, self.nsList, self.VVGvby)
 def VVGvby(self, item=None):
  if item is not None:
   self.VV0hYn(item)
 def VV0hYn(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVV493   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVAjaD   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVl3Wz  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVGmY2  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVFtWL  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VV0KvZ  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVNoJV   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVrQPN   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVlv60 , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VV0KvZ:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFfDK7("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFLk1N(self, "Not found", 1000)
     return
   elif mode == self.VVsgGh:
    return
   else:
    words, asPrefix = CCPqp9.VVn2jm(words)
   if not words and mode in (self.VVrQPN, self.VVlv60):
    FFLk1N(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FF1SeM(self, boundFunction(self.VVA36Y, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVWR64(self):
  self.session.open(CCbQK1, barTheme=CCbQK1.VVMxXb
      , titlePrefix = ""
      , fncToRun  = self.VVSAnC
      , VVs5HI = self.VVLX2u)
 def VVSAnC(self, progBarObj):
  lameDbChans = CCYAlZ.VV8ipk(self, CCYAlZ.VVh2ac, VVuW8O=False, VVDRQS=False)
  files = []
  words = []
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVZTL8 = []
  progBarObj.VVuznc(len(lameDbChans))
  if lameDbChans:
   processChanName = CCAigr()
   curCh = processChanName.VV4urn(self.curChanName)
   for refCode in lameDbChans:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVBfFC(1, True)
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCwdjc.VVyvma(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCwdjc.VV6Cnp(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       progBarObj.VVZTL8.append(f.replace(".png", ""))
 def VVLX2u(self, VV9SAG, VVZTL8, threadCounter, threadTotal, threadErr):
  if VVZTL8:
   self.timer = eTimer()
   fnc = boundFunction(FF1SeM, self, boundFunction(self.VVA36Y, mode=self.VVsgGh, words=VVZTL8), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FFLk1N(self, "Not found", 2000)
 def VVA36Y(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVKjkq(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCYAlZ.VV8ipk(self, CCYAlZ.VVh2ac, VVuW8O=False, VVDRQS=False)
  iptvRefList = self.VVU3Cw()
  tList = []
  for fName, fType in CCwdjc.VVDSPs(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVV493:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVAjaD  and chName         : isAdd = True
   elif mode == self.VVl3Wz and not chName        : isAdd = True
   elif mode == self.VVGmY2  and fType == 0        : isAdd = True
   elif mode == self.VVFtWL  and fType == 1        : isAdd = True
   elif mode == self.VV0KvZ  and fName in words       : isAdd = True
   elif mode == self.VVsgGh and fName in words       : isAdd = True
   elif mode == self.VVNoJV  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVrQPN  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVlv60:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVKQR8   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FFLk1N(self)
  else:
   self.isBusy = False
   FFLk1N(self, "Not found", 1000)
   return
  self.VVKQR8.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VV4dPv()
  self.totalPIcons = len(self.VVKQR8)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVyCSA(True)
 def VVKjkq(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCwdjc.VVDSPs(self.pPath):
    if fName:
     return True
   if isFirstTime : FFcgS7(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFLk1N(self, "Not found", 1000)
  else:
   FFcgS7(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVU3Cw(self):
  VVXJa5 = {}
  files  = CC4M3v.VVy7Fy(self)
  if files:
   for path in files:
    txt = FFeIec(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVXJa5[refCode] = item[1]
  return VVXJa5
 def VVyCSA(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVc8ra = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVc8ra: self.curPage = VVc8ra
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVwgzE()
  if self.curPage == VVc8ra:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVotfs()
  filName, refCode, chName, sat, inDB = self.VVqIaj()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVwgzE(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVKQR8[ndx]
   fName = self.VVKQR8[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FF0hQa(chName, VVeO4o))
    else : lbl.setText("-")
   except:
    lbl.setText(FF0hQa(chName, VVIXzm))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVyvma(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVmgZx():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVfGFJ"   )
 @staticmethod
 def VVJqC5():
  VVlZjX = []
  VVlZjX.append(("Find SymLinks (to PIcon Directory)"   , "VVonFB"   ))
  VVlZjX.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVlZjX.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVlZjX
 @staticmethod
 def VVfGFJ(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(SELF)
  png, path = CCwdjc.VVy4tq(refCode)
  if path : CCwdjc.VV5Val(SELF, png, path)
  else : FFcgS7(SELF, "No PIcon found for current channel in:\n\n%s" % CCwdjc.VVW1YO())
 @staticmethod
 def VVonFB(SELF):
  if VVg4jx:
   sed1 = FFFlx3("->", VVg4jx)
   sed2 = FFFlx3("picon", VVaqQK)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVIXzm, VV3rkc)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFWNH3(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFVC1u(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVKuWE(SELF, isPIcon):
  sed1 = FFFlx3("->", VVIXzm)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFFlx3("picon", VVaqQK)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFWNH3(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFVC1u(), grep, sed1, sed2))
 @staticmethod
 def VVDSPs(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVW1YO():
  path = CFG.PIconsPath.getValue()
  return FFRZql(path)
 @staticmethod
 def VVy4tq(refCode, chName=None):
  if FFS5Go(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFvST6(refCode)
  allPath, fName, refCodeFile, pList = CCwdjc.VV6Cnp(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VV5Val(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFFlx3("%s%s" % (dest, png), VVeO4o))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFFlx3(errTxt, VVahL2))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFovqt(SELF, cmd)
 @staticmethod
 def VV6Cnp(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCwdjc.VVW1YO()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFnTaU(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCTsy2():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VV8aUV  = None
  self.VVLweq = ""
  self.VVnL9Y  = noService
  self.VVU0M3 = 0
  self.VV1LBS  = noService
  self.VVieeu = 0
  self.VVZ3Cv  = "-"
  self.VVngnD = 0
  self.VVtz0O  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVNnVH(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VV8aUV = frontEndStatus
     self.VVFLO4()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVFLO4(self):
  if self.VV8aUV:
   val = self.VV8aUV.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVLweq = "%3.02f dB" % (val / 100.0)
   else         : self.VVLweq = ""
   val = self.VV8aUV.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVU0M3 = int(val)
   self.VVnL9Y  = "%d%%" % val
   val = self.VV8aUV.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVieeu = int(val)
   self.VV1LBS  = "%d%%" % val
   val = self.VV8aUV.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVZ3Cv  = "%d" % val
   val = int(val * 100 / 500)
   self.VVngnD = min(500, val)
   val = self.VV8aUV.get("tuner_locked", 0)
   if val == 1 : self.VVtz0O = "Locked"
   else  : self.VVtz0O = "Not locked"
 def VVZHos(self)   : return self.VVLweq
 def VVy7MI(self)   : return self.VVnL9Y
 def VV3tgj(self)  : return self.VVU0M3
 def VVw1UN(self)   : return self.VV1LBS
 def VVJHrz(self)  : return self.VVieeu
 def VVVfUc(self)   : return self.VVZ3Cv
 def VVtJzq(self)  : return self.VVngnD
 def VV8WAE(self)   : return self.VVtz0O
 def VVQxpx(self) : return self.serviceName
class CC37SE():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVGx2z(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFWBCU(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVaR3t(self.ORPOS  , mod=1   )
      self.sat2  = self.VVaR3t(self.ORPOS  , mod=2   )
      self.freq  = self.VVaR3t(self.FREQ  , mod=3   )
      self.sr   = self.VVaR3t(self.SR   , mod=4   )
      self.inv  = self.VVaR3t(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVaR3t(self.POL  , self.D_POL )
      self.fec  = self.VVaR3t(self.FEC  , self.D_FEC )
      self.syst  = self.VVaR3t(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVaR3t("modulation" , self.D_MOD )
       self.rolof = self.VVaR3t("rolloff"  , self.D_ROLOF )
       self.pil = self.VVaR3t("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVaR3t("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVaR3t("pls_code"  )
       self.iStId = self.VVaR3t("is_id"   )
       self.t2PlId = self.VVaR3t("t2mi_plp_id" )
       self.t2PId = self.VVaR3t("t2mi_pid"  )
 def VVaR3t(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFMf9K(val)
  elif mod == 2   : return FFJsjN(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVxRXm(self, refCode):
  txt = ""
  self.VVGx2z(refCode)
  if self.data:
   def VVPdAh(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVPdAh("System"   , self.syst)
    txt += VVPdAh("Satellite"  , self.sat2)
    txt += VVPdAh("Frequency"  , self.freq)
    txt += VVPdAh("Inversion"  , self.inv)
    txt += VVPdAh("Symbol Rate"  , self.sr)
    txt += VVPdAh("Polarization" , self.pol)
    txt += VVPdAh("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVPdAh("Modulation" , self.mod)
     txt += VVPdAh("Roll-Off" , self.rolof)
     txt += VVPdAh("Pilot"  , self.pil)
     txt += VVPdAh("Input Stream", self.iStId)
     txt += VVPdAh("T2MI PLP ID" , self.t2PlId)
     txt += VVPdAh("T2MI PID" , self.t2PId)
     txt += VVPdAh("PLS Mode" , self.plsMod)
     txt += VVPdAh("PLS Code" , self.plsCod)
   else:
    txt += VVPdAh("System"   , self.txMedia)
    txt += VVPdAh("Frequency"  , self.freq)
  return txt, self.namespace
 def VVG5aS(self, refCode):
  txt = "Transpoder : ?"
  self.VVGx2z(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VV3UWE + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVS5CI(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFWBCU(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVaR3t(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVaR3t(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVaR3t(self.SYST, self.D_SYS_S)
     freq = self.VVaR3t(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVaR3t(self.POL , self.D_POL)
      fec = self.VVaR3t(self.FEC , self.D_FEC)
      sr = self.VVaR3t(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVCs57(self, refCode):
  self.data = None
  self.VVGx2z(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCkrAL():
 def __init__(self, VV7LMd, path, VVs5HI=None, curRowNum=-1):
  self.VV7LMd  = VV7LMd
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVs5HI  = VVs5HI
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFA9Vj("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVnwax(curRowNum)
  else:
   FFcgS7(self.VV7LMd, "Error while preparing edit!")
 def VVnwax(self, curRowNum):
  VVXJa5 = self.VV7A06()
  VVyKSB = None #("Delete Line" , self.deleteLine  , [])
  VVx7qK = ("Save Changes" , self.VVAQ77   , [])
  VVxwOk  = ("Edit Line"  , self.VVnPoD    , [])
  VV1php = ("Line Options" , self.VVGoan   , [])
  VV8Bqk = (""    , self.VVbEVV , [])
  VV4h63 = self.VVd1Qh
  VV6mX2  = self.VVCJvB
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVDhPS  = (CENTER  , LEFT  )
  VVpjES = FF1Vl3(self.VV7LMd, None, title=self.Title, header=header, VVKQR8=VVXJa5, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=26, VVyKSB=VVyKSB, VVx7qK=VVx7qK, VVxwOk=VVxwOk, VV1php=VV1php, VV4h63=VV4h63, VV6mX2=VV6mX2, VV8Bqk=VV8Bqk, VVwgKR=True
    , VVmxJZ   = "#11001111"
    , VVEDc7   = "#11001111"
    , VVc1Ml   = "#11001111"
    , VVZoDW  = "#05333333"
    , VVwpfj  = "#00222222"
    , VVQ4sb  = "#11331133"
    )
  VVpjES.VVkixk(curRowNum)
 def VVGoan(self, VVpjES, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVpjES.VVt9eq()
  VVlZjX = []
  VVlZjX.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVlZjX.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVEsNY"  ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVsWst:
   VVlZjX.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(  ("Delete Line"         , "deleteLine"   ))
  FFqaQ9(self.VV7LMd, boundFunction(self.VVdFgg, VVpjES, lineNum), VVlZjX=VVlZjX, title="Line Options")
 def VVdFgg(self, VVpjES, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VV6kxE("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVpjES)
   elif item == "VVEsNY"  : self.VVEsNY(VVpjES, lineNum)
   elif item == "copyToClipboard"  : self.VVvdmO(VVpjES, lineNum)
   elif item == "pasteFromClipboard" : self.VVgR0K(VVpjES, lineNum)
   elif item == "deleteLine"   : self.VV6kxE("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVpjES)
 def VVCJvB(self, VVpjES):
  VVpjES.VV8dsT()
 def VVbEVV(self, VVpjES, title, txt, colList):
  if   self.insertMode == 1: VVpjES.VVPWrP()
  elif self.insertMode == 2: VVpjES.VVg41v()
  self.insertMode = 0
 def VVEsNY(self, VVpjES, lineNum):
  if lineNum == VVpjES.VVt9eq():
   self.insertMode = 1
   self.VV6kxE("echo '' >> '%s'" % self.tmpFile, VVpjES)
  else:
   self.insertMode = 2
   self.VV6kxE("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVpjES)
 def VVvdmO(self, VVpjES, lineNum):
  global VVsWst
  VVsWst = FFmclR("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVpjES.VVLvlZ("Copied to clipboard")
 def VVAQ77(self, VVpjES, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFA9Vj("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFA9Vj("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVpjES.VVLvlZ("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVpjES.VV8dsT()
    else:
     FFcgS7(self.VV7LMd, "Cannot save file!")
   else:
    FFcgS7(self.VV7LMd, "Cannot create backup copy of original file!")
 def VVd1Qh(self, VVpjES):
  if self.fileChanged:
   FFixrz(self.VV7LMd, boundFunction(self.VVuBi7, VVpjES), "Cancel changes ?")
  else:
   finalOK = os.system(FFA9Vj("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVuBi7(VVpjES)
 def VVuBi7(self, VVpjES):
  VVpjES.cancel()
  os.system(FFA9Vj("rm -f '%s'" % self.tmpFile))
  if self.VVs5HI:
   self.VVs5HI(self.fileSaved)
 def VVnPoD(self, VVpjES, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VV3rkc + "ORIGINAL TEXT:\n" + VV7bzw + lineTxt
  FFZyEN(self.VV7LMd, boundFunction(self.VVMkXP, lineNum, VVpjES), title="File Line", defaultText=lineTxt, message=message)
 def VVMkXP(self, lineNum, VVpjES, VVF1lw):
  if not VVF1lw is None:
   if VVpjES.VVt9eq() <= 1:
    self.VV6kxE("echo %s > '%s'" % (VVF1lw, self.tmpFile), VVpjES)
   else:
    self.VVvhMC(VVpjES, lineNum, VVF1lw)
 def VVgR0K(self, VVpjES, lineNum):
  if lineNum == VVpjES.VVt9eq() and VVpjES.VVt9eq() == 1:
   self.VV6kxE("echo %s >> '%s'" % (VVsWst, self.tmpFile), VVpjES)
  else:
   self.VVvhMC(VVpjES, lineNum, VVsWst)
 def VVvhMC(self, VVpjES, lineNum, newTxt):
  VVpjES.VVRuBW("Saving ...")
  lines = FFW1ru(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVpjES.VVvrSs()
  VVXJa5 = self.VV7A06()
  VVpjES.VV3EJ0(VVXJa5)
 def VV6kxE(self, cmd, VVpjES):
  tCons = CCL7H9()
  tCons.ePopen(cmd, boundFunction(self.VV7GLF, VVpjES))
  self.fileChanged = True
  VVpjES.VVvrSs()
 def VV7GLF(self, VVpjES, result, retval):
  VVXJa5 = self.VV7A06()
  VVpjES.VV3EJ0(VVXJa5)
 def VV7A06(self):
  if fileExists(self.tmpFile):
   lines = FFW1ru(self.tmpFile)
   VVXJa5 = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVXJa5.append((str(ndx), line.strip()))
   if not VVXJa5:
    VVXJa5.append((str(1), ""))
   return VVXJa5
  else:
   FFGmd5(self.VV7LMd, self.tmpFile)
class CCPqp9():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVlZjX   = []
  self.satList   = []
 def VVbIsl(self, VVs5HI):
  self.VVlZjX = []
  VVlZjX, VVhrUW = self.VVHWp6(False, True)
  if VVlZjX:
   self.VVlZjX += VVlZjX
   self.VVasds(VVs5HI, VVhrUW)
 def VV1RlU(self, mode, VVpjES, satCol, VVs5HI):
  VVpjES.VVRuBW("Loading Filters ...")
  self.VVlZjX = []
  self.VVlZjX.append(("All Services" , "all"))
  if mode == 1:
   self.VVlZjX.append(VVZYy7)
   self.VVlZjX.append(("Parental Control", "parentalControl"))
   self.VVlZjX.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVlZjX.append(VVZYy7)
   self.VVlZjX.append(("Selected Transponder"   , "selectedTP" ))
   self.VVlZjX.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVGt6Y(VVpjES, satCol)
  VVlZjX, VVhrUW = self.VVHWp6(True, False)
  if VVlZjX:
   VVlZjX.insert(0, VVZYy7)
   self.VVlZjX += VVlZjX
  VVpjES.VVgLcP()
  self.VVasds(VVs5HI, VVhrUW)
 def VVGlra(self, VVlZjX, sats, VVs5HI):
  self.VVlZjX = VVlZjX
  VVlZjX, VVhrUW = self.VVHWp6(True, False)
  if VVlZjX:
   self.VVlZjX.append(VVZYy7)
   self.VVlZjX += VVlZjX
  self.VVasds(VVs5HI, VVhrUW)
 def VVasds(self, VVs5HI, VVhrUW):
  VVWQj7 = ("Edit Filter", boundFunction(self.VVjlM9, VVhrUW))
  VVXqVm  = ("Filter Help", boundFunction(self.VV9gXh, VVhrUW))
  FFqaQ9(self.callingSELF, boundFunction(self.VVH23E, VVs5HI), VVlZjX=self.VVlZjX, title="Select Filter", VVWQj7=VVWQj7, VVXqVm=VVXqVm)
 def VVH23E(self, VVs5HI, item):
  if item:
   VVs5HI(item)
 def VVjlM9(self, VVhrUW, VV2FRKObj, sel):
  if fileExists(VVhrUW) : CCkrAL(self.callingSELF, VVhrUW, VVs5HI=None)
  else       : FFGmd5(self.callingSELF, VVhrUW)
  VV2FRKObj.cancel()
 def VV9gXh(self, VVhrUW, VV2FRKObj, sel):
  FFepKH(self.callingSELF, VV05tg + "_help_service_filter", "Service Filter")
 def VVGt6Y(self, VVpjES, satColNum):
  if not self.satList:
   satList = VVpjES.VVdyDU(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFsWCY(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VVZYy7)
  if self.VVlZjX:
   self.VVlZjX += self.satList
 def VVHWp6(self, addTag, VVuqoX):
  FFKAmt()
  fileName  = "ajpanel_services_filter"
  VVhrUW = VVNnjH + fileName
  VVlZjX  = []
  if not fileExists(VVhrUW):
   os.system(FFA9Vj("cp -f '%s' '%s'" % (VV05tg + fileName, VVhrUW)))
  fileFound = False
  if fileExists(VVhrUW):
   fileFound = True
   lines = FFW1ru(VVhrUW)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVlZjX.append((line, "__w__" + line))
       else  : VVlZjX.append((line, line))
  if VVuqoX:
   if   not fileFound : FFGmd5(self.callingSELF , VVhrUW)
   elif not VVlZjX : FF2vkZ(self.callingSELF , VVhrUW)
  return VVlZjX, VVhrUW
 @staticmethod
 def VVn2jm(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CCTy7H():
 def __init__(self, callingSELF, VVpjES, refCodeColNum, addSep=True):
  self.callingSELF = callingSELF
  self.VVpjES = VVpjES
  self.refCodeColNum = refCodeColNum
  self.VVlZjX = []
  iMulSel = self.VVpjES.VVQnOh()
  if iMulSel : self.VVlZjX.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVlZjX.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVpjES.VVY5cz()
  self.VVlZjX.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVlZjX.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVlZjX.append(VVZYy7)
 def VV4Ayo(self, servName):
  tot = self.VVpjES.VVY5cz()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVlZjX.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVPjOB_multi" ))
  else    : self.VVlZjX.append( ("Add to Bouquet : %s"      % servName , "VVPjOB_one" ))
 def VVul6f(self, servName, refCode):
  self.VV4Ayo(servName)
  self.VVP2cC(servName, refCode)
 def VVrlyn(self, servName, refCode, pcState, hidState):
  isMulti = self.VVpjES.VVZkVN
  if isMulti:
   refCodeList = self.VVpjES.VVqRoL(3)
   if refCodeList:
    self.VVlZjX.append(("Add Selection to Parental Control"    , "parentalControl_sel_add"  ))
    self.VVlZjX.append(("Remove Selection from Parental Control"   , "parentalControl_sel_remove" ))
    self.VVlZjX.append(VVZYy7)
    self.VVlZjX.append(("Add Selection to Hidden Services"    , "hiddenServices_sel_add"  ))
    self.VVlZjX.append(("Remove Selection from Hidden Services"   , "hiddenServices_sel_remove" ))
   else:
    self.VVlZjX.pop(len(self.VVlZjX) - 1)
  else:
   if pcState == "No" : self.VVlZjX.append(("Add to Parental Control"  , "parentalControl_add"   ))
   else    : self.VVlZjX.append(("Remove from Parental Control" , "parentalControl_remove"  ))
   self.VVlZjX.append(VVZYy7)
   if hidState == "No" : self.VVlZjX.append(("Add to Hidden Services"  , "hiddenServices_add"   ))
   else    : self.VVlZjX.append(("Remove from Hidden Services" , "hiddenServices_remove"  ))
  self.VVlZjX.append(VVZYy7)
  self.VV4Ayo(servName)
  self.VVP2cC(servName, refCode)
 def VVP2cC(self, servName, refCode):
  FFqaQ9(self.callingSELF, boundFunction(self.VVZPue, servName, refCode), title="Options", VVlZjX=self.VVlZjX)
 def VVZPue(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"     : self.VVpjES.VVLcVH(True)
   elif item == "MultSelDisab"     : self.VVpjES.VVLcVH(False)
   elif item == "selectAll"     : self.VVpjES.VVASNB()
   elif item == "unselectAll"     : self.VVpjES.VVMKmc()
   elif item == "parentalControl_add"   : self.callingSELF.VVDhAk(self.VVpjES, refCode, True)
   elif item == "parentalControl_remove"  : self.callingSELF.VVDhAk(self.VVpjES, refCode, False)
   elif item == "hiddenServices_add"   : self.callingSELF.VVOjxm(self.VVpjES, refCode, True)
   elif item == "hiddenServices_remove"  : self.callingSELF.VVOjxm(self.VVpjES, refCode, False)
   elif item == "parentalControl_sel_add"  : self.callingSELF.VVmK2P(self.VVpjES, True)
   elif item == "parentalControl_sel_remove" : self.callingSELF.VVmK2P(self.VVpjES, False)
   elif item == "hiddenServices_sel_add"  : self.callingSELF.VVV6eY(self.VVpjES, True)
   elif item == "hiddenServices_sel_remove" : self.callingSELF.VVV6eY(self.VVpjES, False)
   elif item == "VVPjOB_multi"  : self.VVPjOB(refCode, True)
   elif item == "VVPjOB_one"  : self.VVPjOB(refCode, False)
 def VVmPnO(self, VVpjES):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  mSel   = CCTy7H(self, VVpjES, 3)
  mSel.VVul6f(servName, refCode)
 def VVPjOB(self, refCode, isMulti):
  bouquets = FFojgY()
  if bouquets:
   VVlZjX = []
   for item in bouquets:
    VVlZjX.append((item[0], item[1].toString()))
   VVWQj7 = ("Create New", boundFunction(self.VVb3x8, refCode, isMulti))
   FFqaQ9(self.callingSELF, boundFunction(self.VVgHaC, refCode, isMulti), VVlZjX=VVlZjX, title="Add to Bouquet", VVWQj7=VVWQj7, VVsug5=True, VVc7Gm=True)
  else:
   FFixrz(self.callingSELF, boundFunction(self.VV9REc, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVgHaC(self, refCode, isMulti, bName=None):
  if bName:
   FF1SeM(self.VVpjES, boundFunction(self.VVaXN7, refCode, isMulti, bName), title="Adding Channels ...")
 def VVaXN7(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVi7Bg(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVSQ4S = InfoBar.instance
    if VVSQ4S:
     VVOVrd = VVSQ4S.servicelist
     if VVOVrd:
      mutableList = VVOVrd.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVpjES.VVgLcP()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFkpHN(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FFcgS7(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVi7Bg(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVpjES.VVqRoL(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VVb3x8(self, refCode, isMulti, VV2FRKObj, path):
  self.VV9REc(refCode, isMulti)
 def VV9REc(self, refCode, isMulti):
  FFZyEN(self.callingSELF, boundFunction(self.VVqOiJ, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVqOiJ(self, refCode, isMulti, name):
  if name:
   FF1SeM(self.VVpjES, boundFunction(self.VVFBTn, refCode, isMulti, name), title="Adding Channels ...")
 def VVFBTn(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVi7Bg(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVSQ4S = InfoBar.instance
    if VVSQ4S:
     VVOVrd = VVSQ4S.servicelist
     if VVOVrd:
      try:
       VVOVrd.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVOVrd.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVpjES.VVgLcP()
   title = "Add to Bouquet"
   if allOK: FFkpHN(self.callingSELF, "Added to : %s" % name, title=title)
   else : FFcgS7(self.callingSELF, "Nothing added!", title=title)
class CCrkB3(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF8X8q(VVX2yX, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFNPyH(self)
  FFkV23(self["keyRed"]  , "Exit")
  FFkV23(self["keyGreen"]  , "Save")
  FFkV23(self["keyYellow"] , "Refresh")
  FFkV23(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVKEbv  ,
   "green"   : self.VVzoft ,
   "yellow"  : self.VV4JVm  ,
   "blue"   : self.VVaGD7   ,
   "up"   : self.VVUTv0    ,
   "down"   : self.VVtNKR   ,
   "left"   : self.VVCwsY   ,
   "right"   : self.VVNcXN   ,
   "cancel"  : self.VVKEbv
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VV4JVm()
  self.VVaXB7()
  FFZH71(self)
 def VVKEbv(self) : self.close(True)
 def VVsk7k(self) : self.close(False)
 def VVaGD7(self):
  self.session.openWithCallback(self.VV8e3S, boundFunction(CCZezn))
 def VV8e3S(self, closeAll):
  if closeAll:
   self.close()
 def VVUTv0(self):
  self.VVnPNL(1)
 def VVtNKR(self):
  self.VVnPNL(-1)
 def VVCwsY(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVaXB7()
 def VVNcXN(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVaXB7()
 def VVnPNL(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVWi6G(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVWi6G(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVWi6G(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VV1zZp(year)):
   days += 1 #29 days in a leap year February
  return days
 def VV1zZp(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVaXB7(self):
  for obj in self.list:
   FFxTkM(obj, "#11404040")
  FFxTkM(self.list[self.index], "#11ff8000")
 def VV4JVm(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVzoft(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCL7H9()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVbDSa)
 def VVbDSa(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFkpHN(self, "Nothing returned from the system!")
  else:
   FFkpHN(self, str(result))
class CCZezn(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF8X8q(VVLiFQ, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFNPyH(self, addLabel=True)
  FFkV23(self["keyRed"]  , "Exit")
  FFkV23(self["keyGreen"]  , "Sync")
  FFkV23(self["keyYellow"] , "Refresh")
  FFkV23(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVKEbv   ,
   "green"   : self.VVu4fC  ,
   "yellow"  : self.VV8HKo ,
   "blue"   : self.VVRuzf  ,
   "cancel"  : self.VVKEbv
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVyNqA()
  self.onShow.append(self.start)
 def start(self):
  FF3K6t(self.refresh)
  FFZH71(self)
 def refresh(self):
  self.VVXvqO()
  self.VVkmzN(False)
 def VVKEbv(self)  : self.close(True)
 def VVRuzf(self) : self.close(False)
 def VVyNqA(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVXvqO(self):
  self.VV0JNl()
  self.VVAAvz()
  self.VVYGYQ()
  self.VVfTWj()
 def VV8HKo(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVyNqA()
   self.VVXvqO()
   FF3K6t(self.refresh)
 def VVu4fC(self):
  if len(self["keyGreen"].getText()) > 0:
   FFixrz(self, self.VVbeki, "Synchronize with Internet Date/Time ?")
 def VVbeki(self):
  self.VVXvqO()
  FF3K6t(boundFunction(self.VVkmzN, True))
 def VV0JNl(self)  : self["keyRed"].show()
 def VV7Z0Z(self)  : self["keyGreen"].show()
 def VV8zY5(self) : self["keyYellow"].show()
 def VVi9ME(self)  : self["keyBlue"].show()
 def VVAAvz(self)  : self["keyGreen"].hide()
 def VVYGYQ(self) : self["keyYellow"].hide()
 def VVfTWj(self)  : self["keyBlue"].hide()
 def VVkmzN(self, sync):
  localTime = FFRW7X()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVHVbk(server)
   if epoch_time is not None:
    ntpTime = FFscD6(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCL7H9()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVbDSa, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VV8zY5()
  self.VVi9ME()
  if ok:
   self.VV7Z0Z()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVbDSa(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVkmzN(False)
  except:
   pass
 def VVHVbk(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFLgxI():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCCqQd(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF8X8q(VVSd7Q, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFNPyH(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FF3K6t(self.VVibdb)
 def VVibdb(self):
  if FFLgxI(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFxTkM(self["myBody"], color)
   FFxTkM(self["myLabel"], color)
  except:
   pass
class CC5iP3(Screen):
 def __init__(self, session, isFromExternal=False):
  size = CFG.signalSize.getValue()
  screenW = FFaMwD()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FF8X8q(VVokoY, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self.isFromExternal  = isFromExternal
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCK86d(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCK86d(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCK86d(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCTsy2()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFNPyH(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVUTv0          ,
   "down"  : self.VVtNKR         ,
   "left"  : self.VVCwsY         ,
   "right"  : self.VVNcXN         ,
   "info"  : self.VVqmH4        ,
   "epg"  : self.VVqmH4        ,
   "menu"  : self.VVDtQr         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "blue"  : self.VVM7z5       ,
   "last"  : boundFunction(self.VVpCUO, -1)  ,
   "next"  : boundFunction(self.VVpCUO, 1)  ,
   "pageUp" : boundFunction(self.VVdGzo, True) ,
   "chanUp" : boundFunction(self.VVdGzo, True) ,
   "pageDown" : boundFunction(self.VVdGzo, False) ,
   "chanDown" : boundFunction(self.VVdGzo, False) ,
   "0"   : boundFunction(self.VVpCUO, 0)  ,
   "1"   : boundFunction(self.VVbZTt, pos=1) ,
   "2"   : boundFunction(self.VVbZTt, pos=2) ,
   "3"   : boundFunction(self.VVbZTt, pos=3) ,
   "4"   : boundFunction(self.VVbZTt, pos=4) ,
   "5"   : boundFunction(self.VVbZTt, pos=5) ,
   "6"   : boundFunction(self.VVbZTt, pos=6) ,
   "7"   : boundFunction(self.VVbZTt, pos=7) ,
   "8"   : boundFunction(self.VVbZTt, pos=8) ,
   "9"   : boundFunction(self.VVbZTt, pos=9) ,
  }, -1)
  self.onShown.append(self.VVYZus)
  self.onClose.append(self.onExit)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  self.sliderSNR.VVnL83()
  self.sliderAGC.VVnL83()
  self.sliderBER.VVnL83(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVbZTt()
  self.VV7k1CInfo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV7k1C)
  except:
   self.timer.callback.append(self.VV7k1C)
  self.timer.start(500, False)
 def VV7k1CInfo(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVNnVH(service)
  serviceName = self.tunerInfo.VVQxpx()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self)
  tp = CC37SE()
  txt = tp.VVG5aS(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VV7k1C(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVNnVH(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVZHos())
   self["mySNR"].setText(self.tunerInfo.VVy7MI())
   self["myAGC"].setText(self.tunerInfo.VVw1UN())
   self["myBER"].setText(self.tunerInfo.VVVfUc())
   self.sliderSNR.VVnrVc(self.tunerInfo.VV3tgj())
   self.sliderAGC.VVnrVc(self.tunerInfo.VVJHrz())
   self.sliderBER.VVnrVc(self.tunerInfo.VVtJzq())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVnrVc(0)
   self.sliderAGC.VVnrVc(0)
   self.sliderBER.VVnrVc(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self)
    if state and not state == "Tuned":
     FFLk1N(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVqmH4(self):
  FFqUR7(self, fncMode=CC6WQp.VVjHf0)
 def VVDtQr(self):
  FFepKH(self, VV05tg + "_help_signal", "Signal Monitor (Keys)")
 def VVM7z5(self):
  self.session.open(CCG8uj, isFromExternal=self.isFromExternal)
  self.close()
 def VVUTv0(self)  : self.VVbZTt(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVtNKR(self) : self.VVbZTt(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVCwsY(self) : self.VVbZTt(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVNcXN(self) : self.VVbZTt(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVbZTt(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVpCUO(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFBMJx(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVdGzo(self, isUp):
  FFLk1N(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VV7k1CInfo()
  except:
   pass
class CCK86d(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVnL83(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFxTkM(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VV05tg +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFxTkM(self.covObj, self.covColor)
   else:
    FFxTkM(self.covObj, "#00006688")
    self.isColormode = True
  self.VVnrVc(0)
 def VVnrVc(self, val):
  val  = FFBMJx(val, self.minN, self.maxN)
  width = int(FFbtd6(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFBMJx(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCbQK1(Screen):
 VVMxXb    = 0
 VVlj0K = 1
 VVUIYp = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVs5HI=None, barTheme=VVMxXb):
  ratio = self.VVztHC(barTheme)
  self.skin, self.skinParam = FF8X8q(VViW94, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVs5HI = VVs5HI
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVZTL8 = None
  self.timer   = eTimer()
  self.myThread  = None
  FFNPyH(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVYZus)
  self.onClose.append(self.onExit)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  self.VV5rrb()
  self["myProgBarVal"].setText("0%")
  FFxTkM(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVpeY0()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVpeY0)
  except:
   self.timer.callback.append(self.VVpeY0)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def VVuznc(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVfO7V_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVZTL8), self.counter, self.maxValue, catName)
 def VVfO7V_fromImportEPG(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVfO7V_forcedUpdate(self, title):
  self.newTitle = title
  try:
   self.VVpeY0()
  except:
   pass
 def VVBfFC(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VVZTL8), self.counter, self.maxValue)
  except:
   pass
 def VVRFLP(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVNgrF(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VV6VG2(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFLk1N(self, "Cancelling ...")
  self.isCancelled = True
  self.VV3oaZ(False)
 def VV3oaZ(self, isDone):
  if self.VVs5HI:
   self.VVs5HI(isDone, self.VVZTL8, self.counter, self.maxValue, self.isError)
  self.close()
 def VVpeY0(self):
  val = FFBMJx(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFbtd6(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VV3oaZ(True)
 def VV5rrb(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVlj0K, self.VVUIYp):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVztHC(self, barTheme):
  if   barTheme == self.VVlj0K : return 0.7
  if   barTheme == self.VVUIYp : return 0.5
  else             : return 1
class CCL7H9(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVs5HI = {}
  self.commandRunning = False
  self.VV4tpv  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVs5HI, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVs5HI[name] = VVs5HI
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VV4tpv:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVO56l, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVOEdq , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVO56l, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVOEdq , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVOEdq(name, retval)
  return True
 def VVO56l(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVOEdq(self, name, retval):
  if not self.VV4tpv:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVs5HI[name]:
   self.VVs5HI[name](self.appResults[name], retval)
  del self.VVs5HI[name]
 def VVEfyA(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCr5s8(Screen):
 def __init__(self, session, title="", VVYqjI=None, VV9cjl=False, VVzsLb=False, VVvjub=False, VV8QD9=False, VVZPUB=False, VV7wIQ=False, VVuKKh=VV0Sy0, VVnq9X=None, VVWJD4=False, VVup5x=None, VVgzsB="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FF8X8q(VVMlUC, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFNPyH(self, addScrollLabel=True)
  if not VVgzsB:
   VVgzsB = "Processing ..."
  self["myLabel"].setText("   %s" % VVgzsB)
  self.VV9cjl   = VV9cjl
  self.VVzsLb   = VVzsLb
  self.VVvjub   = VVvjub
  self.VV8QD9  = VV8QD9
  self.VVZPUB = VVZPUB
  self.VV7wIQ = VV7wIQ
  self.VVuKKh   = VVuKKh
  self.VVnq9X = VVnq9X
  self.VVWJD4  = VVWJD4
  self.VVup5x  = VVup5x
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCL7H9()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFCSyQ()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVYqjI, str):
   self.VVYqjI = [VVYqjI]
  else:
   self.VVYqjI = VVYqjI
  if self.VVvjub or self.VV8QD9:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VV9gSb, VV9gSb)
   self.VVYqjI.append("echo -e '\n%s\n' %s" % (restartNote, FFFlx3(restartNote, VVg4jx)))
   if self.VVvjub:
    self.VVYqjI.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVYqjI.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVZPUB:
   FFLk1N(self, "Processing ...")
  self.onLayoutFinish.append(self.VV0GoP)
  self.onClose.append(self.VVEfCc)
 def VV0GoP(self):
  self["myLabel"].VVBS02(textOutFile="console" if self.enableSaveRes else "")
  if self.VV9cjl:
   self["myLabel"].VVmP3I()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVieTa()
  else:
   self.VVX5fg()
 def VVieTa(self):
  if FFLgxI():
   self["myLabel"].setText("Processing ...")
   self.VVX5fg()
  else:
   self["myLabel"].setText(FF0hQa("\n   No connection to internet!", VVaqQK))
 def VVX5fg(self):
  allOK = self.container.ePopen(self.VVYqjI[0], self.VV0LmF, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VV0LmF("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VV7wIQ or self.VVvjub or self.VV8QD9:
    self["myLabel"].setText(FFiu6i("STARTED", VVg4jx) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVup5x:
   colorWhite = CCN5Bb.VVpL5B(VV3rkc)
   color  = CCN5Bb.VVpL5B(self.VVup5x[0])
   words  = self.VVup5x[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVuKKh=self.VVuKKh)
 def VV0LmF(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVYqjI):
   allOK = self.container.ePopen(self.VVYqjI[self.cmdNum], self.VV0LmF, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VV0LmF("Cannot connect to Console!", -1)
  else:
   if self.VVZPUB and FFPRFL(self):
    FFLk1N(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VV7wIQ:
    self["myLabel"].appendText("\n" + FFiu6i("FINISHED", VVg4jx), self.VVuKKh)
   if self.VV9cjl or self.VVzsLb:
    self["myLabel"].VVmP3I()
   if self.VVnq9X is not None:
    self.VVnq9X()
   if not retval and self.VVWJD4:
    self.VVEfCc()
 def VVEfCc(self):
  if self.container.VVEfyA():
   self.container.killAll()
class CCX72r(Screen):
 def __init__(self, session, VVYqjI=None, VVZPUB=False):
  self.skin, self.skinParam = FF8X8q(VVMlUC, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVNnjH + "ajpanel_terminal.history"
  self.customCommandsFile = VVNnjH + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFmclR("pwd") or "/home/root"
  self.container   = CCL7H9()
  FFNPyH(self, addScrollLabel=True)
  FFkV23(self["keyRed"] , "Exit = Stop Command")
  FFkV23(self["keyGreen"] , "OK = History")
  FFkV23(self["keyYellow"], "Menu = Custom Cmds")
  FFkV23(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVZQuM ,
   "cancel" : self.VVZCbx  ,
   "menu"  : self.VVdzUo ,
   "last"  : self.VVM5tU  ,
   "next"  : self.VVM5tU  ,
   "1"   : self.VVM5tU  ,
   "2"   : self.VVM5tU  ,
   "3"   : self.VVM5tU  ,
   "4"   : self.VVM5tU  ,
   "5"   : self.VVM5tU  ,
   "6"   : self.VVM5tU  ,
   "7"   : self.VVM5tU  ,
   "8"   : self.VVM5tU  ,
   "9"   : self.VVM5tU  ,
   "0"   : self.VVM5tU
  })
  self.onLayoutFinish.append(self.VVYZus)
  self.onClose.append(self.VVtQSn)
 def VVYZus(self):
  self["myLabel"].VVBS02(isResizable=False, textOutFile="terminal")
  FF3XWe(self["keyRed"]  , "#00ff8000")
  FFxTkM(self["keyRed"]  , self.skinParam["titleColor"])
  FFxTkM(self["keyGreen"]  , self.skinParam["titleColor"])
  FFxTkM(self["keyYellow"] , self.skinParam["titleColor"])
  FFxTkM(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVcLSp(FFmclR("date"), 5)
  result = FFmclR("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVyL9V()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VV05tg + "LinuxCommands.lst"
   newTemplate = VV05tg + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFA9Vj("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFA9Vj("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVtQSn(self):
  if self.container.VVEfyA():
   self.container.killAll()
   self.VVcLSp("Process killed\n", 4)
   self.VVyL9V()
 def VVZCbx(self):
  if self.container.VVEfyA():
   self.VVtQSn()
  else:
   FFixrz(self, self.close, "Exit ?", VVcGkw=False)
 def VVyL9V(self):
  self.VVcLSp(self.prompt, 1)
  self["keyRed"].hide()
 def VVcLSp(self, txt, mode):
  if   mode == 1 : color = VVg4jx
  elif mode == 2 : color = VV3UWE
  elif mode == 3 : color = VV3rkc
  elif mode == 4 : color = VVaqQK
  elif mode == 5 : color = VV7bzw
  elif mode == 6 : color = VVZERI
  else   : color = VV3rkc
  try:
   self["myLabel"].appendText(FF0hQa(txt, color))
  except:
   pass
 def VVw3BO(self, cmd):
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVcLSp(cmd, 2)
   self.VVcLSp("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVcLSp(ch, 0)
   self.VVcLSp("\nor\n", 4)
   self.VVcLSp("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVyL9V()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FF0hQa(parts[0].strip(), VV3UWE)
    right = FF0hQa("#" + parts[1].strip(), VVZERI)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVcLSp(txt, 2)
   lastLine = self.VVjq7E()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVivfg(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VV0LmF, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFcgS7(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVcLSp(data, 3)
 def VV0LmF(self, data, retval):
  if not retval == 0:
   self.VVcLSp("Exit Code : %d\n" % retval, 4)
  self.VVyL9V()
 def VVZQuM(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVjq7E() == "":
   self.VVivfg("cd /tmp")
   self.VVivfg("ls")
  VVXJa5 = []
  if fileExists(self.commandHistoryFile):
   lines  = FFW1ru(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVXJa5.append((str(c), line, str(lNum)))
   self.VVB1xY(VVXJa5, title, self.commandHistoryFile, isHistory=True)
  else:
   FFGmd5(self, self.commandHistoryFile, title=title)
 def VVjq7E(self):
  lastLine = FFmclR("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVivfg(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVdzUo(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFW1ru(self.customCommandsFile)
   lastLineIsSep = False
   VVXJa5 = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVXJa5.append((str(c), line, str(lNum)))
   self.VVB1xY(VVXJa5, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFGmd5(self, self.customCommandsFile, title=title)
 def VVB1xY(self, VVXJa5, title, filePath=None, isHistory=False):
  if VVXJa5:
   VVZoDW = "#05333333"
   if isHistory: VVmxJZ = VVEDc7 = VVc1Ml = "#11000020"
   else  : VVmxJZ = VVEDc7 = VVc1Ml = "#06002020"
   VVhD2a = VV1php = None
   VVxwOk   = ("Send"   , self.VVoLAW        , [])
   VVx7qK  = ("Modify & Send" , self.VVkIss        , [])
   if isHistory:
    VVhD2a = ("Clear History" , self.VVjQEu        , [])
   elif filePath:
    VV1php = ("Edit File"  , boundFunction(self.VV18QN, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVDhPS     = (CENTER  , LEFT   , CENTER )
   FF1Vl3(self, None, title=title, header=header, VVKQR8=VVXJa5, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=26, VVxwOk=VVxwOk, VVx7qK=VVx7qK, VVhD2a=VVhD2a, VV1php=VV1php, VVwgKR=True
     , VVmxJZ   = VVmxJZ
     , VVEDc7   = VVEDc7
     , VVc1Ml   = VVc1Ml
     , VVnMUd  = "#05ffff00"
     , VVZoDW  = VVZoDW
    )
  else:
   FF2vkZ(self, filePath, title=title)
 def VVoLAW(self, VVpjES, title, txt, colList):
  cmd = colList[1].strip()
  VVpjES.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVcLSp("\n%s\n" % cmd, 6)
   self.VVcLSp(self.prompt, 1)
  else:
   self.VVw3BO(cmd)
 def VVkIss(self, VVpjES, title, txt, colList):
  cmd = colList[1]
  self.VVmKaN(VVpjES, cmd)
 def VVjQEu(self, VVpjES, title, txt, colList):
  FFixrz(self, boundFunction(self.VVC7vZ, VVpjES), "Reset History File ?", title="Command History")
 def VVC7vZ(self, VVpjES):
  os.system(FFA9Vj("echo '' > %s" % self.commandHistoryFile))
  VVpjES.cancel()
 def VV18QN(self, filePath, VVpjES, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCkrAL(self, filePath, VVs5HI=boundFunction(self.VVrFti, VVpjES), curRowNum=rowNum)
  else     : FFGmd5(self, filePath)
 def VVrFti(self, VVpjES, fileChanged):
  if fileChanged:
   VVpjES.cancel()
   FF3K6t(self.VVdzUo)
 def VVM5tU(self):
  self.VVmKaN(None, self.lastCommand)
 def VVmKaN(self, VVpjES, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFZyEN(self, boundFunction(self.VVWzpf, VVpjES), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVWzpf(self, VVpjES, cmd):
  if cmd and len(cmd) > 0:
   self.VVw3BO(cmd)
   if VVpjES:
    VVpjES.cancel()
class CCZGJp(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVF1lw="", VVkbS3=False, VViCxH=False, isTrimEnds=True):
  self.skin, self.skinParam = FF8X8q(VV6tuu, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFNPyH(self, title, addLabel=True)
  FFkV23(self["keyRed"] , "Up/Down = Change")
  FFkV23(self["keyGreen"] , "Overwrite")
  FFkV23(self["keyYellow"], "Pick Key Map")
  FFkV23(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VViCxH   = VViCxH
  self.VVkbS3  = VVkbS3
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVF1lw, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVSPRj      ,
   "green"    : self.VVef10    ,
   "yellow"   : self.VVTReN      ,
   "blue"    : self.VVsPES     ,
   "menu"    : self.VVy9JZ     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVDNIK, True) ,
   "down"    : boundFunction(self.VVDNIK, False) ,
   "left"    : self.VVvEZM       ,
   "right"    : self.VVXK3q       ,
   "home"    : self.VVHgrI       ,
   "end"    : self.VVCHgB       ,
   "next"    : self.VVf1fe      ,
   "last"    : self.VVuXlA      ,
   "deleteForward"  : self.VVf1fe      ,
   "deleteBackward" : self.VVuXlA      ,
   "tab"    : self.VVQawv       ,
   "toggleOverwrite" : self.VVef10    ,
   "0"     : self.VVN39y     ,
   "1"     : self.VVN39y     ,
   "2"     : self.VVN39y     ,
   "3"     : self.VVN39y     ,
   "4"     : self.VVN39y     ,
   "5"     : self.VVN39y     ,
   "6"     : self.VVN39y     ,
   "7"     : self.VVN39y     ,
   "8"     : self.VVN39y     ,
   "9"     : self.VVN39y
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VV5g4o()
  self.onShown.append(self.VVYZus)
  self.onClose.append(self.onExit)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FFXHxA(self)
  self["myLabel"].setText(self.message)
  self.VVpe6Y()
  if self.VVkbS3 : self.VVef10()
  else    : self.VV5L4g()
  FFZH71(self)
  FFxTkM(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVX3OF)
  except:
   self.timer.callback.append(self.VVX3OF)
 def onExit(self):
  self.timer.stop()
 def VVSPRj(self):
  self.VV0Pd9()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VV0Pd9()
  self.close(None)
 def VVy9JZ(self):
  VVlZjX = []
  VVlZjX.append(("Home"         , "home"    ))
  VVlZjX.append(("End"         , "end"     ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Clear All"       , "clearAll"   ))
  VVlZjX.append(("Clear To Home"      , "clearToHome"   ))
  VVlZjX.append(("Clear To End"       , "clearToEnd"   ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVsWst:
   VVlZjX.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("To Capital Letters"     , "toCapital"   ))
  VVlZjX.append(("To Small Letters"      , "toSmall"    ))
  FFqaQ9(self, self.VVgnBs, title="Edit Options", VVlZjX=VVlZjX)
 def VVgnBs(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVHgrI()
   elif item == "end"     : self.VVCHgB()
   elif item == "clearAll"    : self.VVTIAf()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVHgrI()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVsWst
    VVsWst = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVsWst)
    self.VVHgrI()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVX3OF(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVef10(self):
  self["myInput"].toggleOverwrite()
  self.VV5L4g()
 def VVTReN(self):
  self.session.openWithCallback(self.VVE7GW, boundFunction(CCibSj, mode=self.charMode, VViCxH=self.VViCxH))
 def VVE7GW(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVpe6Y()
 def VV5L4g(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VV5g4o(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VV0Pd9(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVPzyf(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVvEZM(self)     : self.VVwfC4(self["myInput"].left)
 def VVXK3q(self)     : self.VVwfC4(self["myInput"].right)
 def VVf1fe(self)     : self.VVwfC4(self["myInput"].delete)
 def VVHgrI(self)     : self.VVwfC4(self["myInput"].home)
 def VVCHgB(self)     : self.VVwfC4(self["myInput"].end)
 def VVuXlA(self)    : self.VVwfC4(self["myInput"].deleteBackward)
 def VVQawv(self)     : self.VVwfC4(self["myInput"].tab)
 def VVTIAf(self)     : self["myInput"].setText("")
 def VVwfC4(self, fnc):
  fnc()
  self.VVX3OF()
 def VVN39y(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVPzyf(newChar, overwrite)
   self.VVIdqA(newChar, self["myInput"].mapping[number])
 def VVDNIK(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCibSj.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCibSj.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVPzyf(newChar, True)
   for group in groups:
    if newChar in group:
     self.VVIdqA(newChar, group)
     break
 def VVIdqA(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VV3rkc:
    group = VV7bzw + group.replace(newChar, FF0hQa(newChar, VV3rkc, VV7bzw))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVsPES(self):
  if self.VViCxH : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVpe6Y()
 def VVpe6Y(self):
  self["myInput"].mapping = CCibSj.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCibSj.RCU_MAP_TITLES[self.charMode])
class CCibSj(Screen):
 VVmMqy  = 0
 VVubVu  = 1
 VVgwsp  = 2
 VVOiRt  = 3
 VVz7bf = 4
 VV4beq = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols , arabic_nums1, arabic1)
       , ( symbols , arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A", u"\u0628")
       , (u"\u0647", u"\u062A")
       )
 def __init__(self, session, mode=VVmMqy, VViCxH=False):
  self.skin, self.skinParam = FF8X8q(VVyKDR, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VViCxH  = VViCxH
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFNPyH(self, title=self.Title)
  FFkV23(self["keyRed"] ,"OK = Select")
  FFkV23(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVat9s     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VV1szq, -1) ,
   "next"  : boundFunction(self.VV1szq, +1) ,
   "left"  : boundFunction(self.VV1szq, -1) ,
   "right"  : boundFunction(self.VV1szq, +1) ,
  }, -1)
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FFxTkM(self["keyRed"], "#11222222")
  FFxTkM(self["keyGreen"], "#11222222")
  self.VVQlZM()
 def VVQlZM(self):
  self.VVvedo()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVvedo(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VV1szq(self, direction):
  if self.VViCxH : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVQlZM()
 def VVat9s(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCfxpJ(Screen):
 def __init__(self, session, title="", message="", VVuKKh=VV0Sy0, VVlwD9=False, VVc1Ml=None, VVbh3O=30, canSaveToFile=""):
  self.skin, self.skinParam = FF8X8q(VVMlUC, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVbh3O)
  self.session   = session
  FFNPyH(self, title, addScrollLabel=True)
  self.VVuKKh   = VVuKKh
  self.VVlwD9   = VVlwD9
  self.VVc1Ml   = VVc1Ml
  self.canSaveToFile  = canSaveToFile
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  self["myLabel"].VVBS02(VVlwD9=self.VVlwD9, textOutFile=self.canSaveToFile)
  self["myLabel"].setText(self.message, self.VVuKKh)
  if self.VVc1Ml:
   FFxTkM(self["myBody"], self.VVc1Ml)
   FFxTkM(self["myLabel"], self.VVc1Ml)
   FFvX01(self["myLabel"], self.VVc1Ml)
  self["myLabel"].VVmP3I()
class CCIByc(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FF8X8q(VV67W3, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFNPyH(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FFhwWb(self["errPic"], "err")
class CCtgbF(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FF8X8q(VVkLOo, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", 20)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FFNPyH(self, " ", addCloser=True)
class CCaqvh():
 def __init__(self, session, txt):
  self.win = session.instantiateDialog(CCtgbF, txt)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  self.session = session
  self.timer  = eTimer()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVApyp)
  except:
   self.timer.callback.append(self.VVApyp)
  self.timer.start(1500, True)
 def VVApyp(self):
  self.session.deleteDialog(self.win)
class CCsRnB():
 VV2uZx    = 0
 VVlOoO  = 1
 VVjTom   = ""
 VVNvUZ    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVpjES   = None
  self.timer     = eTimer()
  self.VVl7qq   = 0
  self.VVHC8U  = 1
  self.VV59uD  = 2
  self.VVrPS0   = 3
  self.VVsV5E   = 4
  VVXJa5 = self.VVMYcF()
  if VVXJa5:
   self.VVpjES = self.VVCbVN(VVXJa5)
  if not VVXJa5 and mode == self.VV2uZx:
   self.VVuqoXor("Download list is empty !")
   self.cancel()
  if mode == self.VVlOoO:
   FF1SeM(self.VVpjES or self.SELF, boundFunction(self.VVy3XG, startDnld, decodedUrl), title="Checking Server ...")
  self.VVKfGo(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVKfGo)
  except:
   self.timer.callback.append(self.VVKfGo)
  self.timer.start(1000, False)
 def VVCbVN(self, VVXJa5):
  VVXJa5.sort(key=lambda x: int(x[0]))
  VV4h63 = self.VV1bWu
  VVxwOk  = ("Play"  , self.VVMerq , [])
  VVsbBT = (""   , self.VVuMdt  , [])
  VVyKSB = ("Stop"  , self.VVSKpw  , [])
  VVx7qK = ("Resume"  , self.VVjKuj , [])
  VVhD2a = ("Options" , self.VVpoCD  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVDhPS  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FF1Vl3(self.SELF, None, title=self.Title, header=header, VVKQR8=VVXJa5, VVDhPS=VVDhPS, VVrZ8Z=widths, VVbh3O=26, VVxwOk=VVxwOk, VVsbBT=VVsbBT, VV4h63=VV4h63, VVyKSB=VVyKSB, VVx7qK=VVx7qK, VVhD2a=VVhD2a, VVEDc7="#11110011", VVmxJZ="#11220022", VVc1Ml="#11110011", VVnMUd="#00ffff00", VVZoDW="#00223025", VVwpfj="#0a333333", VVQ4sb="#0a400040", VVwgKR=True, searchCol=1)
 def VVMYcF(self):
  lines = CCsRnB.VVs7el()
  VVXJa5 = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",")
     left  = parts[0].strip()
     decodedUrl = ",".join(parts[1:]).strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVgnmL(decodedUrl)
      if fName:
       if   FFam7W(decodedUrl) : sType = "Movie"
       elif FFI6Dp(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVtJuE(decodedUrl, fName)
       if size > -1: sizeTxt = CCs7ea.VVxfhW(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVXJa5.append((str(len(VVXJa5) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVXJa5
 def VV3MPn(self):
  VVXJa5 = self.VVMYcF()
  if VVXJa5:
   if self.VVpjES : self.VVpjES.VV3EJ0(VVXJa5, VVyNqAMsg=False)
   else     : self.VVpjES = self.VVCbVN(VVXJa5)
  else:
   self.cancel()
 def VVKfGo(self, force=False):
  if self.VVpjES:
   thrList = self.VVSdQT()
   VVXJa5 = []
   changed = False
   for ndx, row in enumerate(self.VVpjES.VVbYXo()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVl7qq
    if m3u8Log:
     percent = self.VVarBu(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVrPS0 , "%.2f %%" % percent
      else   : flag, progr = self.VVsV5E , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFRl9s(mPath)
     if curSize > -1:
      fSize = CCs7ea.VVxfhW(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCs7ea.VVxfhW(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFRl9s(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVrPS0 , "%.2f %%" % percent
       else   : flag, progr = self.VVsV5E , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCs7ea.VVxfhW(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrList:
     flag = self.VV59uD
     if m3u8Log :
      if not speed and not force : flag = self.VVHC8U
      elif curSize == -1   : self.VVelXZ(False)
    elif flag == self.VVl7qq  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVl7qq  : color2 = "#f#00555555#"
    elif flag == self.VVHC8U : color2 = "#f#0000FFFF#"
    elif flag == self.VV59uD : color2 = "#f#0000FFFF#"
    elif flag == self.VVrPS0  : color2 = "#f#00FF8000#"
    elif flag == self.VVsV5E  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVFvsS(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVXJa5.append(row)
   if changed or force:
    self.VVpjES.VV3EJ0(VVXJa5, VVyNqAMsg=False)
 def VVFvsS(self, flag):
  tDict = self.VV8ZB3()
  return tDict.get(flag, "?")
 def VVlS8t(self, state):
  for flag, txt in self.VV8ZB3().items():
   if txt == state:
    return flag
  return -1
 def VV8ZB3(self):
  return { self.VVl7qq: "Not started", self.VVHC8U: "Connecting", self.VV59uD: "Downloading", self.VVrPS0: "Stopped", self.VVsV5E: "Completed" }
 def VVOosx(self, title):
  colList = self.VVpjES.VVl8Td()
  path = colList[6]
  url  = colList[8]
  if self.VVA0yd() : self.VVuqoXor("Cannot delete !\n\nFile is downloading.")
  else      : FFixrz(self.SELF, boundFunction(self.VVZjdk, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVZjdk(self, path, url):
  m3u8Log = self.VVpjES.VVl8Td()[12].strip()
  if m3u8Log : os.system(FFA9Vj("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFA9Vj("rm -r '%s'" % path))
  self.VVfTbx(False)
  self.VV3MPn()
 def VVfTbx(self, VVuqoX=True):
  if self.VVA0yd():
   FFLk1N(self.VVpjES, self.VVFvsS(self.VV59uD), 500)
  else:
   colList  = self.VVpjES.VVl8Td()
   state  = colList[4].strip()
   decodedUrl = colList[9].strip()
   if self.VVlS8t(state) in (self.VVl7qq, self.VVsV5E, self.VVrPS0):
    lines = CCsRnB.VVs7el()
    newLines = []
    found = False
    for line in lines:
     if CCsRnB.VVZKwe(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VV77S6(newLines)
     self.VV3MPn()
     FFLk1N(self.VVpjES, "Removed.", 1000)
    else:
     FFLk1N(self.VVpjES, "Not found.", 1000)
   elif VVuqoX:
    self.VVuqoXor("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VV0OYF(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFixrz(self.SELF, boundFunction(self.VVbfzY, flag), ques, title=title)
 def VVbfzY(self, flag):
  list = []
  for ndx, row in enumerate(self.VVpjES.VVbYXo()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVlS8t(state)
   if   flag == flagVal == self.VVsV5E: list.append(decodedUrl)
   elif flag == flagVal == self.VVl7qq : list.append(decodedUrl)
  lines = CCsRnB.VVs7el()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VV77S6(newLines)
   self.VV3MPn()
   FFLk1N(self.VVpjES, "%d removed." % totRem, 1000)
  else:
   FFLk1N(self.VVpjES, "Not found.", 1000)
 def VVRRdI(self):
  colList  = self.VVpjES.VVl8Td()
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFLk1N(self.VVpjES, "Poster exists", 1500)
  else    : FF1SeM(self.VVpjES, boundFunction(self.VVdxF5, decodedUrl, path, png), title="Checking Server ...")
 def VVdxF5(self, decodedUrl, path, png):
  err = self.VVDwTR(decodedUrl, path, png)
  if err:
   FFcgS7(self.SELF, err, title="Poster Download")
 def VVDwTR(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCIsu8.VVFwRF(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CC4M3v.VVMlKY(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CC4M3v.VVSLDf(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CC4M3v.VVrtEf(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFDt8N(pUrl, "ajpanel_tmp%s", timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   os.system(FFA9Vj("mv -f '%s' '%s'" % (tPath, png)))
   CCdNIB.VVrD1V(self.SELF, VViJTE=png, showGrnMsg="Downloaded")
   return ""
 def VVuMdt(self, VVpjES, title, txt, colList):
  def VVOpU1(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVPdAh(key, val) : return "\n%s:\n%s\n" % (FF0hQa(key, COLOR_CONS_BRIGHT_YELLOW), val.strip())
  heads  = self.VVpjES.VVO9eE()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVOpU1(heads[i]  , CCs7ea.VVxfhW(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVOpU1("Downloaded" , CCs7ea.VVxfhW(int(curSize), mode=0))
   else:
    txt += VVOpU1(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVPdAh(heads[i], colList[i])
  FFn7o1(self.SELF, txt, title=title)
 def VVMerq(self, VVpjES, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCs7ea.VVsf1m(self.SELF, path)
  else    : FFLk1N(self.VVpjES, "File not found", 1000)
 def VV1bWu(self, VVpjES):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVpjES:
   self.VVpjES.cancel()
  del self
 def VVpoCD(self, VVpjES, title, txt, colList):
  decodedUrl = colList[9].strip()
  if CFG.downloadAutoResume.getValue(): resumeTxt = "Disable"
  else        : resumeTxt = "Enable"
  VVlZjX = []
  VVlZjX.append(("Remove current row"      , "VVfTbx"  ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(('Remove all "Completed"'     , "remFinished"    ))
  VVlZjX.append(('Remove all "Not started"'     , "remPending"    ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Delete the file (and remove from list)" , "VVOosx" ))
  if FFam7W(decodedUrl):
   VVlZjX.append(VVZYy7)
   VVlZjX.append(("Download Movie Poster (from server)" , "VVRRdI"   ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append((resumeTxt + " Auto Resume"     , "VVz0XC"  ))
  FFqaQ9(self.SELF, self.VVLZUe, VVlZjX=VVlZjX, title=self.Title, VVsug5=True, VVc7Gm=True)
 def VVLZUe(self, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVfTbx"  : self.VVfTbx()
   elif ref == "remFinished"   : self.VV0OYF(self.VVsV5E, txt)
   elif ref == "remPending"   : self.VV0OYF(self.VVl7qq, txt)
   elif ref == "VVOosx" : self.VVOosx(txt)
   elif ref == "VVRRdI"  : self.VVRRdI()
   elif ref == "VVz0XC"  : self.VVz0XC()
 def VVy3XG(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCIsu8.VVFwRF(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVuqoXor("Could not get download link !\n\nTry again later.")
     return
  for line in CCsRnB.VVs7el():
   if CCsRnB.VVZKwe(decodedUrl, line):
    self.VVtjqT(decodedUrl)
    FF3K6t(boundFunction(FFLk1N, self.VVpjES, "Already listed !", 2000))
    break
  else:
   params = self.VVnX2L(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVuqoXor(params[0])
   elif len(params) == 2:
    FFixrz(self.SELF, boundFunction(self.VVuJxe, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCs7ea.VVxfhW(fSize)
    FFixrz(self.SELF, boundFunction(self.VVP7Hw, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVP7Hw(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCsRnB.VVv9TT(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VV3MPn()
  if self.VVpjES:
   self.VVpjES.VVg41v()
  if startDnld:
   threadName = self.VVNvUZ + decodedUrl
   self.VVGfVV(threadName, url, decodedUrl, path, resp)
 def VVtjqT(self, decodedUrl):
  for ndx, row in enumerate(self.VVpjES.VVbYXo()):
   decodedUrl2 = row[9].strip()
   if decodedUrl == decodedUrl2 and self.VVpjES:
    self.VVpjES.VVSHbm(ndx)
    break
 def VVnX2L(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVgnmL(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVtJuE(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCIsu8.VVFwRF(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCIsu8.VVScCgHeader()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCsRnB.VV4Zfe(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCsRnB.VVCCGA(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVuJxe(self, resp, decodedUrl):
  if not os.system(FFA9Vj("which ffmpeg")) == 0:
   FFixrz(self.SELF, boundFunction(CC4M3v.VVJ3MZ, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVgnmL(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVA0Cm(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFixrz(self.SELF, boundFunction(self.VVpLGf, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVpLGf(rTxt, rUrl)
  else:
   self.VVuqoXor("Cannot process m3u8 file !")
 def VVA0Cm(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVlZjX = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CC4M3v.VVzW3M(rUrl, fPath)
   VVlZjX.append((resol, fullUrl))
  if VVlZjX:
   FFqaQ9(self.SELF, self.VVRZo6, VVlZjX=VVlZjX, title="Resolution", VVsug5=True, VVc7Gm=True)
  else:
   self.VVuqoXor("Cannot get Resolutions list from server !")
 def VVRZo6(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFixrz(self.SELF, boundFunction(FF3K6t, boundFunction(self.VVJ5An, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FF3K6t(boundFunction(self.VVJ5An, resolUrl))
 def VVJ5An(self, resolUrl):
  txt, err = CCIsu8.VVk8TQ(resolUrl)
  if err : self.VVuqoXor(err)
  else : self.VVpLGf(txt, resolUrl)
 def VV9EI3(self, logF, decodedUrl):
  found = False
  lines = CCsRnB.VVs7el()
  with open(CCsRnB.VVv9TT(), "w") as f:
   for line in lines:
    if CCsRnB.VVZKwe(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCsRnB.VVv9TT(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VV3MPn()
  if self.VVpjES:
   self.VVpjES.VVg41v()
 def VVpLGf(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CC4M3v.VVzW3M(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVuqoXor("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VV9EI3(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFA9Vj("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = self.VVNvUZ + decodedUrl
  myThread = iThread(name=threadName, target=boundFunction(os.system, cmd))
  myThread.start()
 def VVarBu(self, dnldLog):
  if fileExists(dnldLog):
   dur = self.VVZfdU(dnldLog)
   if dur > -1:
    tim = self.VVBYAe(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 def VVZfdU(self, dnldLog):
  lines = FFfDK7("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVBYAe(self, dnldLog):
  lines = FFfDK7("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVtJuE(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFI6Dp(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFA9Vj("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVGfVV(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVpjES.VVl8Td()[7].strip())
  myThread = iThread(name=threadName, target=boundFunction(self.VVsSNZ, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVsSNZ(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if CCsRnB.VVjTom == path:
       break
     else:
      break
  except:
   return
  if CCsRnB.VVjTom:
   CCsRnB.VVjTom = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFRl9s(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVnX2L(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVsSNZ(url, decodedUrl, path, resp, totFileSize, True)
 def VVSKpw(self, VVpjES, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VV5seY() : FFLk1N(self.VVpjES, self.VVFvsS(self.VVsV5E), 500)
  elif not self.VVA0yd() : FFLk1N(self.VVpjES, self.VVFvsS(self.VVrPS0), 500)
  elif m3u8Log      : FFixrz(self.SELF, self.VVelXZ, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVSdQT():
    CCsRnB.VVjTom = colList[6]
    FFLk1N(self.VVpjES, "Stopping ...", 1000)
   else:
    FFLk1N(self.VVpjES, "Stopped", 500)
 def VVelXZ(self, withMsg=True):
  if withMsg:
   FFLk1N(self.VVpjES, "Stopping ...", 1000)
  os.system(FFA9Vj("killall -INT ffmpeg"))
 def VVz0XC(self):
  CFG.downloadAutoResume.setValue(not CFG.downloadAutoResume.getValue())
  CFG.downloadAutoResume.save()
  configfile.save()
 def VVjKuj(self, *args):
  if   self.VV5seY() : FFLk1N(self.VVpjES, self.VVFvsS(self.VVsV5E) , 500)
  elif self.VVA0yd() : FFLk1N(self.VVpjES, self.VVFvsS(self.VV59uD), 500)
  else:
   resume = False
   m3u8Log = self.VVpjES.VVl8Td()[12].strip()
   if m3u8Log:
    if fileExists(m3u8Log) : FFixrz(self.SELF, boundFunction(self.VVETN9, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVLp3w():
    resume = True
   if resume: FF1SeM(self.VVpjES, boundFunction(self.VVPjoI), title="Checking Server ...")
   else  : FFLk1N(self.VVpjES, "Cannot resume !", 500)
 def VVETN9(self, m3u8Log):
  os.system(FFA9Vj("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FF1SeM(self.VVpjES, boundFunction(self.VVPjoI), title="Checking Server ...")
 def VVPjoI(self):
  colList  = self.VVpjES.VVl8Td()
  path  = colList[6].strip()
  size  = colList[7].strip()
  decodedUrl = colList[9].strip()
  if "j.php" in decodedUrl:
   url = CCIsu8.VVFwRF(decodedUrl)
   if url:
    decodedUrl = self.VVXKHv(decodedUrl, url)
   else:
    self.VVuqoXor("Could not get download link !\n\nTry again later.")
    return
  curSize = FFRl9s(path)
  params = self.VVnX2L(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVuqoXor(params[0])
   return
  elif len(params) == 2:
   self.VVuJxe(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVXKHv(decodedUrl, url, fSize)
  threadName = self.VVNvUZ + decodedUrl
  if resumable: self.VVGfVV(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVuqoXor("Cannot resume from server !")
 def VVgnmL(self, decodedUrl):
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(http:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   x = decodedUrl.find("&mode")
   if x > -1: url = decodedUrl[:x]
   fName = ".mp4"
   x = decodedUrl.find("&end=")
   if x > -1: chName = decodedUrl[x+5:]
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + ".mp4"
     fixName = False
     ok  = True
   if not ok and FFVVjP(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + ".mp4"
     fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    fName =  mix.split(":")[0]
    chName = ":".join(mix.split(":")[1:])
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVuqoXor(self, txt):
  FFcgS7(self.SELF, txt, title=self.Title)
 def VVSdQT(self):
  thrList = []
  for thr in iEnumerate():
   if self.VVNvUZ in thr.name:
    thrList.append(thr.name.replace(self.VVNvUZ, ""))
  return thrList
 def VVA0yd(self):
  decodedUrl = self.VVpjES.VVl8Td()[9].strip()
  return decodedUrl in self.VVSdQT()
 def VV5seY(self):
  colList = self.VVpjES.VVl8Td()
  path = colList[6].strip()
  size = colList[7].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFRl9s(path)) == size
 def VVLp3w(self):
  colList = self.VVpjES.VVl8Td()
  path = colList[6].strip()
  size = int(colList[7].strip())
  curSize = FFRl9s(path)
  if curSize > -1:
   size -= curSize
  err = CCsRnB.VVCCGA(size)
  if err:
   FFcgS7(self.SELF, err, title=self.Title)
   return False
  return True
 def VV77S6(self, list):
  with open(CCsRnB.VVv9TT(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVXKHv(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCsRnB.VVs7el()
  url = decodedUrl
  with open(CCsRnB.VVv9TT(), "w") as f:
   for line in lines:
    if CCsRnB.VVZKwe(decodedUrl, line):
     parts = line.split(",")
     oldUrl = ",".join(parts[1:]).strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VV3MPn()
  return url
 @staticmethod
 def VVs7el():
  list = []
  if fileExists(CCsRnB.VVv9TT()):
   for line in FFW1ru(CCsRnB.VVv9TT()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVZKwe(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVCCGA(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCs7ea.VVULf4(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCs7ea.VVxfhW(size), CCs7ea.VVxfhW(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVwCQe(SELF):
  tot = CCsRnB.VVCtVs()
  if tot:
   FFcgS7(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVCtVs():
  c = 0
  for thread in iEnumerate():
   if thread.name.startswith(CCsRnB.VVNvUZ):
    c += 1
  return c
 @staticmethod
 def VVU3Sj():
  return len(CCsRnB.VVs7el()) == 0
 @staticmethod
 def VVZLdj():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVhiFq():
  mPoints = CCsRnB.VVZLdj()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFA9Vj("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVv9TT():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVyzTQ(SELF):
  CCsRnB.VVRkQZ(SELF, CCsRnB.VV2uZx)
 @staticmethod
 def VVFgCz_cur(SELF):
  CCsRnB.VVRkQZ(SELF, CCsRnB.VVlOoO, startDnld=True)
 @staticmethod
 def VVFgCz_url(SELF, url):
  CCsRnB.VVRkQZ(SELF, CCsRnB.VVlOoO, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVNBh2Current(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(SELF)
  added, skipped = CCsRnB.VVNBh2List([decodedUrl])
  FFLk1N(SELF, "Added", 1000)
 @staticmethod
 def VVNBh2List(list):
  added = skipped = 0
  for line in CCsRnB.VVs7el():
   for ndx, url in enumerate(list):
    if url and CCsRnB.VVZKwe(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCsRnB.VVv9TT(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVRkQZ(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCUxkq.VVEdgn(SELF):
   return
  if mode == CCsRnB.VV2uZx and CCsRnB.VVU3Sj():
   FFcgS7(SELF, "Download list is empty !", title=title)
  else:
   inst = CCsRnB(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VV4Zfe(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCG8uj(Screen, CCmugO):
 VVp5Y4 = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False, enableDownloadMenu=True):
  self.skin, self.skinParam = FF8X8q(VV8osc, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCmugO.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  self.SubtWin    = None
  FFNPyH(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVv2dP())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVEvnY         ,
   "info"  : self.VVqmH4        ,
   "epg"  : self.VVqmH4        ,
   "menu"  : self.VVWXUP       ,
   "cancel" : self.cancel         ,
   "blue"  : self.VVi7Yi        ,
   "green"  : self.VVagI5    ,
   "yellow" : self.VVrgYI   ,
   "left"  : boundFunction(self.VVpPxW, -1)   ,
   "right"  : boundFunction(self.VVpPxW,  1)   ,
   "play"  : self.VVwiE7        ,
   "pause"  : self.VVwiE7        ,
   "playPause" : self.VVwiE7        ,
   "stop"  : self.VVwiE7        ,
   "rewind" : self.VV3s0N        ,
   "forward" : self.VVo7wj        ,
   "rewindDm" : self.VV3s0N        ,
   "forwardDm" : self.VVo7wj        ,
   "last"  : self.VVx9mc        ,
   "next"  : self.VVPab2        ,
   "pageUp" : boundFunction(self.VVenRP, True) ,
   "pageDown" : boundFunction(self.VVenRP, False) ,
   "chanUp" : boundFunction(self.VVenRP, True) ,
   "chanDown" : boundFunction(self.VVenRP, False) ,
   "up"  : boundFunction(self.VVenRP, True) ,
   "down"  : boundFunction(self.VVenRP, False) ,
   "audio"  : boundFunction(self.VV7yey, True) ,
   "subtitle" : boundFunction(self.VV7yey, False) ,
   "0"   : boundFunction(self.VVQbQG , 10)  ,
   "1"   : boundFunction(self.VVQbQG , 1)  ,
   "2"   : boundFunction(self.VVQbQG , 2)  ,
   "3"   : boundFunction(self.VVQbQG , 3)  ,
   "4"   : boundFunction(self.VVQbQG , 4)  ,
   "5"   : boundFunction(self.VVQbQG , 5)  ,
   "6"   : boundFunction(self.VVQbQG , 6)  ,
   "7"   : boundFunction(self.VVQbQG , 7)  ,
   "8"   : boundFunction(self.VVQbQG , 8)  ,
   "9"   : boundFunction(self.VVQbQG , 9)
  }, -1)
  self.onShown.append(self.VVYZus)
  self.onClose.append(self.onExit)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FFXHxA(self)
  if not CCG8uj.VVp5Y4:
   CCG8uj.VVp5Y4 = self
  else:
   self.close()
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFhwWb(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFhwWb(self["myPlayRpt"], "rpt")
  self.VVQX1X()
  self.instance.move(ePoint(40, 40))
  self.VVGbGz(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVTTjh)
  except:
   self.timer.callback.append(self.VVTTjh)
  self.timer.start(250, False)
  self.VVTTjh("Checking ...")
  self.VVNgX1()
 def VVagI5(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self)
  if "chCode" in iptvRef:
   if CCUxkq.VVEdgn(self):
    self.VVNgX1(True)
 def VVQX1X(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl:
   if "get_download_link" in origUrl: color = "#1120101a"
   else        : color = "#1120002a"
   self["myPlayGrn"].show()
  else:
   color = "#1100202a"
   self["myPlayGrn"].hide()
  FFxTkM(self["myTitle"], color)
 def VVWXUP(self):
  if self.SubtWin:
   self.SubtWin.VV4yyl()
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self)
  VVlZjX = []
  if self.isFromExternal:
   VVlZjX.append(("IPTV Menu"     , "iptv"  ))
   VVlZjX.append(VVZYy7)
  if FFS5Go(iptvRef) and not "&end=" in decodedUrl and not FFVVjP(decodedUrl):
   uType, uHost, uUser, uPass, uId, uChName = CC4M3v.VVMlKY(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVlZjX.append(("Catchup Programs"   , "catchup"  ))
    VVlZjX.append(VVZYy7)
  VVlZjX.append(("Stop Current Service"    , "stop"  ))
  VVlZjX.append(("Restart Current Service"   , "restart"  ))
  VVlZjX.append(VVZYy7)
  FFam7WSeries = FFVVjP(decodedUrl)
  if FFam7WSeries:
   VVlZjX.append(("File Size"     , "fileSize" ))
   VVlZjX.append(VVZYy7)
  if self.enableDownloadMenu:
   addSep = False
   if FFS5Go(iptvRef) and FFam7WSeries:
    VVlZjX.append(("Start Download"   , "dload_cur" ))
    VVlZjX.append(("Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCsRnB.VVU3Sj():
    VVlZjX.append(("Download Manager"   , "dload_stat" ))
    addSep = True
   if addSep:
    VVlZjX.append(VVZYy7)
  fPath, fDir, fName = CCs7ea.VVhTh0(self)
  if fPath:
   if not CCs7ea.VVQiB5:
    VVlZjX.append((VVg4jx + "Open path in File Manager", "VVbvbx" ))
   VVlZjX.append((VVg4jx + 'Add to "My Movies" Bouquet' , "VVvBr1" ))
   VVlZjX.append(("%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVYI1b" ))
   VVlZjX.append(VVZYy7)
  enabl = False
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCG8uj.VVNK0R(self)
  if posVal and durVal:
   enabl = True
  else:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CC6WQp.VVlfBB(self)
   enabl = evName and evTime and evDur
  if enabl:
   VVlZjX.append((VVg4jx + "Start Subtitle"    , "VVhek4"  ))
   VVlZjX.append(VVZYy7)
  if CFG.playerPos.getValue() : VVlZjX.append(("Move Bar to Bottom"  , "botm"  ))
  else      : VVlZjX.append(("Move Bar to Top"  , "top"   ))
  VVlZjX.append(("Help"             , "help"  ))
  FFqaQ9(self, self.VVg2KW, VVlZjX=VVlZjX, width=550, title="Options")
 def VVg2KW(self, item=None):
  if item:
   if item == "iptv"     : self.VVPTSR()
   elif item == "catchup"    : self.VVrgYI()
   elif item == "stop"     : self.VVmkgY(0)
   elif item == "restart"    : self.VVmkgY(1)
   elif item == "fileSize"    : FF1SeM(self, boundFunction(CC6WQp.VVNlos, self), title="Checking Server")
   elif item == "dload_cur"   : CCsRnB.VVFgCz_cur(self)
   elif item == "addToDload"   : CCsRnB.VVNBh2Current(self)
   elif item == "dload_stat"   : CCsRnB.VVyzTQ(self)
   elif item == "VVbvbx" : self.VVbvbx()
   elif item == "VVvBr1" : FF1SeM(self, self.VVvBr1)
   elif item == "VVhek4"  : self.VVhek4(CCxsSP.VVq5pM)
   elif item == "VVYI1b"  : self.VVYI1b()
   elif item == "botm"     : self.VVGbGz(0)
   elif item == "top"     : self.VVGbGz(1)
   elif item == "help"     : FFepKH(self, VV05tg + "_help_player", "Player Controller (Keys)")
 def onExit(self):
  self.timer.stop()
  CCG8uj.VVp5Y4 = None
  self.VVNFKf()
 def VVPvO4(self):
  if CCG8uj.VVp5Y4:
   self.session.open(CCG8uj, enableZapping= False, enableDownloadMenu=False)
  self.close()
 def VVbvbx(self):
  self.session.open(CCs7ea, gotoMovie=True)
  self.VVPvO4()
 def VVPTSR(self):
  self.session.open(CC4M3v)
  self.VVPvO4()
 def VVmkgY(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.close()
   elif typ == 1:
    self.VVTTjh("Restarting Service ...")
    FF3K6t(boundFunction(self.VVlbjR, serv))
 def VVlbjR(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self)
  if "&end=" in decodedUrl: boundFunction(self.VVNgX1, True)
  else     : self.session.nav.playService(serv)
 def VVvBr1(self):
  title = "Add Movie to Bouquet"
  bName = "My Movies"
  path  = VVf9y4 + "userbouquet.my_local_movies.tv"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self)
  fPath, fDir, fName = CCs7ea.VVhTh0(self)
  if not fPath or not chName:
   FFcgS7(self, "Cannot read Path or Channel Name", title=title)
   return
  isNew = False
  if not fileExists(path):
   isNew = True
   with open(path, "w") as f:
    f.write("#NAME %s\n" % bName)
  catID, stID, chNum = "1638", "6", "6"
  refCode = CC4M3v.VV9uqR(catID, stID, chNum)
  if not isNew:
   fTxt = FFeIec(path)
   chUrl_noRef = "%s:%s" % (fPath, chName)
   if chUrl_noRef in fTxt:
    FFcgS7(self, "Already added to bouquet:\n\n%s" % bName, title=title)
    return
   for ns in range(1, 65535 - 1):
    catID, stID, chNum = "1638", str(ns), "6"
    refCode = CC4M3v.VV9uqR(catID, stID, chNum)
    if not refCode in fTxt:
     break
   else:
    FFcgS7(self, "Cannot create a unique Reference Code", title=title)
    return
  if refCode and fPath and chName:
   chUrl = "%s%s:%s" % (refCode, fPath, chName)
   with open(path, "a") as f:
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
   piconOk = self.VVVh8v(refCode)
   FFDa4p(os.path.basename(path))
   FFRfFm()
   FFkpHN(self, "Added to bouquet:\n\n%s" % bName, title=title + (" (with PIcon)" if piconOk else ""))
  else:
   FFcgS7(self, "Cannot create a unique Reference Code", title=title)
   return
 def VVYI1b(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCG8uj.VVNK0R(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVTTjh(txt, highlight=ok)
 def VVhek4(self, mode, useSubtFile=""):
  self.hide()
  self.SubtWin = self.session.instantiateDialog(CCxsSP, mode=mode, endCallback=self.VVTO3M)
  self.SubtWin.show()
  self.SubtWin.VVvTAI(useSubtFile)
 def VVTO3M(self, err):
  if err:
   if err == "noResume": self.VVNFKf(False)
   else    : self.VVNFKf(True)
   if   err == "noResume" : return
   if   err == "noErr"  : return
   elif err == "noAutoSrt" : CCxsSP.VVFsQr(self, self.VVSE1v)
   else      : FFLk1N(self, err, 2000)
 def VVSE1v(self, path):
  if path:
   self.VVhek4(CCxsSP.VVq5pM, useSubtFile=path)
 def VVVh8v(self, refCode):
  fPath, fDir, fName, picFile = CC6WQp.VVfVcc(self)
  pPath = CCwdjc.VVW1YO()
  if fileExists(pPath) and pathExists(picFile):
   pFile = refCode.replace(":", "_").strip("_") + ".png"
   dest = os.path.join(pPath, pFile)
   os.system(FFA9Vj("cp -f '%s' '%s'" % (picFile, dest)))
   os.system(FFA9Vj("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (dest, dest)))
   return True
  return False
 def VVGbGz(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VVEvnY(self):
  if self.isManualSeek:
   self.VVano3()
   self.VV4gkT(self.manualSeekPts)
  else:
   if self.shown:
    self.hide()
    self.VVhek4(CCxsSP.VVEfuT)
   else:
    self.VVNFKf()
 def VVNFKf(self, showBar=True):
  if self.SubtWin:
   self.session.deleteDialog(self.SubtWin)
   self.SubtWin = None
  if showBar:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVano3()
  elif self.SubtWin : self.VVNFKf()
  else    : self.close()
 def VVqmH4(self):
  if self.SubtWin:
   self.SubtWin.VVMQGc("noErr")
  FFqUR7(self, fncMode=CC6WQp.VV6Poo)
 def VVwiE7(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except Exception as e:
   pass
  self.VVTTjh("Toggling Play/Pause ...")
 def VVano3(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVpPxW(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCG8uj.VVNK0R(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVjb9W()
   else:
    self.manualSeekSec += direc * self.VVjb9W()
    self.manualSeekSec = FFBMJx(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFbtd6(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFgN2Y(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVQbQG(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVv2dP())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVTTjh("Changed Seek Time to : %d%s" % (val, self.VVrBcn()))
 def VVv2dP(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVrBcn())
 def VVrBcn(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVp81h(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVjb9W(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVTTjh(self, stateTxt="", highlight=False):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FF7qBd(self, addInfoObj=True)
  fr = res = ""
  if info:
   w = FFplQi(info, iServiceInformation.sVideoWidth) or -1
   h = FFplQi(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFplQi(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CC6WQp.VVOt7u(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCG8uj.VVNK0R(self)
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FFBMJx(percVal, 0, 100)
    width = int(FFbtd6(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not posTxt: self["myPlayPos"].setText("")
  if not remTxt: self["myPlayRem"].setText("")
  if not durTxt:
   if   prov : txt = prov
   elif posTxt : txt = ">>>>"
   else  : txt = "...."
   self["myPlayVal"].setText(txt)
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText("")
   FFxTkM(self["myPlayBarBG"], "#1100202a")
   self["myPlayBarF"].hide()
  else:
   FFxTkM(self["myPlayBarBG"], "#11000000")
   self["myPlayBarF"].show()
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VVes5n() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   if highlight: FF3XWe(self["myPlayMsg"], "#0000ffff")
   else  : FF3XWe(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   self["myPlayMsg"].setText("-" if decodedUrl else FFru8i(refCode, True))
   FF3XWe(self["myPlayMsg"], "#00ff8066")
  tot = CCsRnB.VVCtVs()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVy6dX()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VV4gkT(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVx9mc()
  state = self.VVwhEG()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FF3XWe(self["myPlayMsg"], "#0000ff00")
  else     : FF3XWe(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 @staticmethod
 def VVNK0R(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFgN2Y(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFgN2Y(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFgN2Y(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVy6dX(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVi7Yi(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VVes5n()
   if cList:
    VVlZjX = []
    for pts, what in cList:
     txt = FFgN2Y(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVlZjX.append((txt, pts))
    FFqaQ9(self, self.VV51yd, VVlZjX=VVlZjX, title="Cut List")
   else:
    self.VVTTjh("No Cut-List for this channel !")
 def VV51yd(self, item=None):
  if item:
   self.VV4gkT(item)
 def VVes5n(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVo7wj(self) : self.VVP0WR(1)
 def VV3s0N(self) : self.VVP0WR(-1)
 def VVP0WR(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCG8uj.VVNK0R(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVjb9W() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVp81h())
    self.VVTTjh(txt)
  except:
   self.VVTTjh("Cannot jump")
 def VV4gkT(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVTTjh("Changing Time ...")
 def VVx9mc(self):
  self.VVmkgY(1)
  self.VVTTjh("Replaying ...")
  self.VVano3()
 def VVPab2(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCG8uj.VVNK0R(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVTTjh("Jumping to end ...")
  except:
   pass
 def VVwhEG(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVenRP(self, isUp):
  if self.enableZapping:
   self.VVTTjh("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVano3()
   if self.portalTableParam:
    FF3K6t(boundFunction(self.VV7ILx, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self)
    if "/timeshift/" in decodedUrl:
     self.VVTTjh("Cannot Zap Catcup TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVs6ry()
 def VVs6ry(self):
  self.lastPlayPos = 0
  self.VVQX1X()
  self.VVNgX1()
 def VV7ILx(self, isUp):
  CC4M3v_inatance, VVpjES, mode = self.portalTableParam
  if isUp : VVpjES.VVktPX()
  else : VVpjES.VVejQW()
  colList = VVpjES.VVl8Td()
  if mode == "localIptv":
   chName, chUrl = CC4M3v_inatance.VVac0M(VVpjES, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CC4M3v_inatance.VVjqHd(VVpjES, colList)
  elif isinstance(mode, int):
   chName, chUrl = CC4M3v_inatance.VVlm3E(mode, VVpjES, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CC4M3v_inatance.VVa8tZ(mode, VVpjES, colList)
  else:
   self.VVTTjh("Cannot Zap")
   return
  FFvYTu(self, chUrl, VVonEU=False)
  self.VVs6ry()
 def VVNgX1(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCG8uj.VVNK0R(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self)
   if not self.VVsBck(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVTTjh("Refreshing Portal")
   FF3K6t(self.VV5d5X)
  except:
   pass
 def VV5d5X(self):
  self.restoreLastPlayPos = self.VVaXNh()
 def VVrgYI(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self)
  if not decodedUrl or FFVVjP(decodedUrl):
   self.VVTTjh("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CC4M3v.VVMlKY(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVTTjh("Reading Program List ...")
   ok_fnc = boundFunction(self.VVpDfA, refCode, chName, streamId, uHost, uUser, uPass)
   FF3K6t(boundFunction(CC4M3v.VVjoBU, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVTTjh("Cannot process this channel")
 def VVpDfA(self, refCode, chName, streamId, uHost, uUser, uPass, VVpjES, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVpjES.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVTTjh("Changing Program ...")
   FF3K6t(boundFunction(self.VVpuLd, chUrl))
  else:
   self.VVTTjh("Incorrect Timestamp !")
 def VVpuLd(self, chUrl):
   FFvYTu(self, chUrl, VVonEU=False)
   self.lastPlayPos = 0
   self.VVQX1X()
 def VV7yey(self, isAudio):
  try:
   VVSQ4S = InfoBar.instance
   if VVSQ4S:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVSQ4S)
    else  : self.session.open(SubtitleSelection, VVSQ4S)
  except:
   pass
class CCciQF(Screen):
 def __init__(self, session, title="", VV9Uka="Continue?", VVcGkw=True, VVEkk8=False):
  self.skin, self.skinParam = FF8X8q(VVxTu6, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VV9Uka = VV9Uka
  self.VVEkk8 = VVEkk8
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVcGkw : VVlZjX = [no , yes]
  else   : VVlZjX = [yes, no ]
  FFNPyH(self, title, VVlZjX=VVlZjX, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVEvnY ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VV9Uka)
  if self.VVEkk8:
   self["myLabel"].instance.setHAlign(0)
  self.VVBkf4()
  FFhGNA(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFn0Kf(self["myMenu"])
  FF6TuE(self, self["myMenu"])
 def VVEvnY(self):
  item = FFr1Kw(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVBkf4(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCUZrk(Screen):
 def __init__(self, session, title="", VVlZjX=None, width=1000, height=0, OKBtnFnc=None, VVmAmL=None, VVG5AR=None, VVWQj7=None, VVXqVm=None, VVsug5=False, VVc7Gm=False):
  if height == 0: height = 850
  self.skin, self.skinParam = FF8X8q(VVycF3, width, height, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVlZjX   = VVlZjX
  self.OKBtnFnc   = OKBtnFnc
  self.VVmAmL   = VVmAmL
  self.VVG5AR  = VVG5AR
  self.VVWQj7  = VVWQj7
  self.VVXqVm   = VVXqVm
  self.VVsug5  = VVsug5
  self.VVc7Gm  = VVc7Gm
  FFNPyH(self, title, VVlZjX=VVlZjX)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVEvnY          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVylB1         ,
   "green"  : self.VVBMqz         ,
   "yellow" : self.VV8wGU         ,
   "blue"  : self.VV2wAA         ,
   "pageUp" : self.VVm88o       ,
   "chanUp" : self.VVm88o       ,
   "pageDown" : self.VVSUsx        ,
   "chanDown" : self.VVSUsx
  }, -1)
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FFhGNA(self["myMenu"])
  FFwAWu(self)
  self.VVlWPE(self["keyRed"]  , self.VVmAmL )
  self.VVlWPE(self["keyGreen"] , self.VVG5AR )
  self.VVlWPE(self["keyYellow"] , self.VVWQj7 )
  self.VVlWPE(self["keyBlue"]  , self.VVXqVm )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFZH71(self)
 def VVlWPE(self, btnObj, btnFnc):
  if btnFnc:
   FFkV23(btnObj, btnFnc[0])
 def VVEvnY(self):
  item = FFr1Kw(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVsug5: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVylB1(self)  : self.VVwfC4(self.VVmAmL)
 def VVBMqz(self) : self.VVwfC4(self.VVG5AR)
 def VV8wGU(self) : self.VVwfC4(self.VVWQj7)
 def VV2wAA(self) : self.VVwfC4(self.VVXqVm)
 def VVwfC4(self, btnFnc):
  if btnFnc:
   item = FFr1Kw(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVc7Gm:
    self.cancel()
 def VVlGAm(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVlZjX = self["myMenu"].list
  VVlZjX.pop(ndx)
  if len(VVlZjX) > 0: self["myMenu"].setList(VVlZjX)
  else    : self.close()
 def VVp3TA(self, VVlZjX):
  if len(VVlZjX) > 0:
   newList = []
   for item in VVlZjX:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVssO6(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVm88o(self):
  self["myMenu"].moveToIndex(0)
 def VVSUsx(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCqbW9(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VVKQR8=None, VVDhPS=None, VVrZ8Z=None, VVbh3O=26, VVwgKR=False, VVxwOk=None, VVsbBT=None, VVyKSB=None, VVx7qK=None, VVhD2a=None, VV1php=None, VV6mX2=None, VV8Bqk=None, VV4h63=None, VVdlpd=-1, VVs65B=False, searchCol=0, VVmxJZ=None, VVEDc7=None, VVw6oj="#00dddddd", VVc1Ml="#11002233", VVnMUd="#00ff8833", VVZoDW="#11111111", VVwpfj="#0a555555", VVVsOm="#0affffff", VVQ4sb="#11552200", VVjiab="#0055ff55"):
  self.skin, self.skinParam = FF8X8q(VVnpW4, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFNPyH(self, title)
  self.header     = header
  self.VVKQR8     = VVKQR8
  self.totalCols    = len(VVKQR8[0])
  self.VVtQZQ   = 0
  self.lastSortModeIsReverese = False
  self.VVwgKR   = VVwgKR
  self.VVFEGZ   = 0.01
  self.VVBY7t   = 0.02
  self.VVztXt = 0.03
  self.VV2JEa  = 1
  self.VVrZ8Z = VVrZ8Z
  self.colWidthPixels   = []
  self.VVxwOk   = VVxwOk
  self.OKButtonObj   = None
  self.VVsbBT   = VVsbBT
  self.VVyKSB   = VVyKSB
  self.VVx7qK   = VVx7qK
  self.VVhD2a  = VVhD2a
  self.VV1php   = VV1php
  self.VV6mX2    = VV6mX2
  self.VV8Bqk   = VV8Bqk
  self.VV4h63  = VV4h63
  self.VVdlpd    = VVdlpd
  self.VVs65B   = VVs65B
  self.searchCol    = searchCol
  self.VVDhPS    = VVDhPS
  self.keyPressed    = -1
  self.VVbh3O    = FFB2V8(VVbh3O)
  self.VV786P    = FF4gcJ(self.VVbh3O, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVmxJZ    = VVmxJZ
  self.VVEDc7      = VVEDc7
  self.VVw6oj    = FF0hYc(VVw6oj)
  self.VVc1Ml    = FF0hYc(VVc1Ml)
  self.VVnMUd    = FF0hYc(VVnMUd)
  self.VVZoDW    = FF0hYc(VVZoDW)
  self.VVwpfj   = FF0hYc(VVwpfj)
  self.VVVsOm    = FF0hYc(VVVsOm)
  self.VVQ4sb    = FF0hYc(VVQ4sb)
  self.VVjiab   = FF0hYc(VVjiab)
  self.VVZkVN  = False
  self.selectedItems   = 0
  self.VVXZTA   = FF0hYc("#01fefe01")
  self.VVnY6M   = FF0hYc("#11400040")
  self.VVhtVe  = self.VVXZTA
  self.VVlqOL  = self.VVZoDW
  if self.VVs65B:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV65cy  ,
   "red"   : self.VVn060  ,
   "green"   : self.VVzOu9 ,
   "yellow"  : self.VVsy37 ,
   "blue"   : self.VVFXJo  ,
   "menu"   : self.VVq7iq ,
   "info"   : self.VVd2nk  ,
   "cancel"  : self.VVSDcl  ,
   "up"   : self.VVejQW    ,
   "down"   : self.VVktPX  ,
   "left"   : self.VVUFJo   ,
   "right"   : self.VVfM08  ,
   "pageUp"  : self.VVWn12  ,
   "chanUp"  : self.VVWn12  ,
   "pageDown"  : self.VVg41v  ,
   "chanDown"  : self.VVg41v
  }, -1)
  FFNteF(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FFXHxA(self)
  try:
   self.VV7Mdi()
  except Exception as err:
   FFcgS7(self, str(err))
   self.close(None)
 def VV7Mdi(self):
  FFZH71(self)
  if self.VVmxJZ:
   FFxTkM(self["myTitle"], self.VVmxJZ)
  if self.VVEDc7:
   FFxTkM(self["myBody"] , self.VVEDc7)
   FFxTkM(self["myTableH"] , self.VVEDc7)
   FFxTkM(self["myTable"] , self.VVEDc7)
   FFxTkM(self["myBar"]  , self.VVEDc7)
  self.VVlWPE(self.VVyKSB  , self["keyRed"])
  self.VVlWPE(self.VVx7qK  , self["keyGreen"])
  self.VVlWPE(self.VVhD2a , self["keyYellow"])
  self.VVlWPE(self.VV1php  , self["keyBlue"])
  if self.VVxwOk:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVxwOk[0])
    FFxTkM(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VV786P)
  self["myTableH"].l.setFont(0, gFont(VVmpyI, self.VVbh3O))
  self["myTable"].l.setItemHeight(self.VV786P)
  self["myTable"].l.setFont(0, gFont(VVmpyI, self.VVbh3O))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VV786P)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VV786P))
   self["myTable"].instance.resize(eSize(*(w, h - self.VV786P)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VV786P
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VV786P * len(self.VVKQR8) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVrZ8Z:
   self.VVrZ8Z = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVrZ8Z)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVDhPS:
   self.VVDhPS = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVDhPS
   self.VVDhPS = []
   for item in tmpList:
    self.VVDhPS.append(item | RT_VALIGN_CENTER)
  self.VVbaXM()
  if self.VV6mX2:
   self.VV6mX2(self)
 def VVlWPE(self, btnFnc, btn):
  if btnFnc : FFkV23(btn, btnFnc[0])
  else  : FFkV23(btn, "")
 def VVU61Y(self, waitTxt):
  FF1SeM(self, self.VVbaXM, title=waitTxt)
 def VVbaXM(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVrfRO(0, self.header, self.VVVsOm, self.VVQ4sb, self.VVVsOm, self.VVQ4sb, self.VVjiab)])
   rows = []
   for c, row in enumerate(self.VVKQR8):
    rows.append(self.VVrfRO(c, row, self.VVw6oj, self.VVc1Ml, self.VVnMUd, self.VVZoDW, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVdlpd > -1:
    self["myTable"].moveToIndex(self.VVdlpd )
   self.VVQzoC()
   if self.VVs65B:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VV786P * len(self.VVKQR8)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VV8Bqk:
    self.VVwfC4(self.VV8Bqk, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFcgS7(self, str(err))
    self.close()
   except:
    pass
 def VVrfRO(self, keyIndex, columns, VVw6oj, VVc1Ml, VVnMUd, VVZoDW, VVjiab):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVjiab and ndx == self.VVtQZQ : textColor = VVjiab
   else           : textColor = VVw6oj
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FF0hYc(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVc1Ml = c
    entry = span.group(3)
   if self.VVDhPS[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VV786P)
           , font   = 0
           , flags   = self.VVDhPS[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVc1Ml
           , color_sel  = VVnMUd
           , backcolor_sel = VVZoDW
           , border_width = 1
           , border_color = self.VVwpfj
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVd2nk(self):
  rowData = self.VVUSln()
  if rowData:
   title, txt, colList = rowData
   if self.VVsbBT:
    fnc  = self.VVsbBT[1]
    params = self.VVsbBT[2]
    fnc(self, title, txt, colList)
   else:
    FFn7o1(self, txt, title)
 def VV65cy(self):
  if   self.VVZkVN : self.VVye7Z(self.VV7oaa(), mode=2)
  elif self.VVxwOk  : self.VVwfC4(self.VVxwOk, None)
  else      : self.VVd2nk()
 def VVn060(self) : self.VVwfC4(self.VVyKSB , self["keyRed"])
 def VVzOu9(self) : self.VVwfC4(self.VVx7qK , self["keyGreen"])
 def VVsy37(self): self.VVwfC4(self.VVhD2a , self["keyYellow"])
 def VVFXJo(self) : self.VVwfC4(self.VV1php , self["keyBlue"])
 def VVwfC4(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFLk1N(self, buttonFnc[3])
    FF3K6t(boundFunction(self.VV1gBy, buttonFnc))
   else:
    self.VV1gBy(buttonFnc)
 def VV1gBy(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVUSln()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVye7Z(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VVKQR8[ndx]
   isSelected = row[1][9] == self.VVXZTA
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVrfRO(ndx, item, self.VVw6oj, self.VVc1Ml, self.VVnMUd, self.VVZoDW, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVrfRO(ndx, item, self.VVXZTA, self.VVnY6M, self.VVhtVe, self.VVlqOL, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVQzoC()
 def VVASNB(self):
  FF1SeM(self, self.VVkdnW, title="Selecting all ...")
 def VVkdnW(self):
  self.VVLcVH(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVXZTA
   if not isSelected:
    item = self.VVKQR8[ndx]
    newRow = self.VVrfRO(ndx, item, self.VVXZTA, self.VVnY6M, self.VVhtVe, self.VVlqOL, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVQzoC()
  self.VVHY6y()
 def VVMKmc(self):
  FF1SeM(self, self.VV59fG, title="Unselecting all ...")
 def VV59fG(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVXZTA:
    item = self.VVKQR8[ndx]
    newRow = self.VVrfRO(ndx, item, self.VVw6oj, self.VVc1Ml, self.VVnMUd, self.VVZoDW, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVQzoC()
  self.VVHY6y()
 def VVHY6y(self):
  self.hide()
  self.show()
 def VVUSln(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVrZ8Z[i] > 1 or self.VVrZ8Z[i] == self.VVFEGZ or self.VVrZ8Z[i] == self.VVztXt:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VVKQR8))
   return rowNum, txt, colList
  else:
   return None
 def VVSDcl(self):
  if self.VV4h63 : self.VV4h63(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVbfvv(self):
  return self["myTitle"].getText().strip()
 def VVO9eE(self):
  return self.header
 def VVahDS(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVRuBW(self, txt):
  FFLk1N(self, txt)
 def VVLvlZ(self, txt):
  FFLk1N(self, txt, 1000)
 def VVgLcP(self):
  FFLk1N(self)
 def VVt9eq(self):
  return len(self.VVKQR8)
 def VVvrSs(self): self["keyGreen"].show()
 def VV8dsT(self): self["keyGreen"].hide()
 def VV7oaa(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VV9oe5(self):
  return len(self["myTable"].list)
 def VVLcVH(self, isOn):
  self.VVZkVN = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu"].hide()
   if self.VV1php: self["keyBlue"].hide()
   if self.VVxwOk and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VV1php: self["keyBlue"].show()
   if self.VVxwOk and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVxwOk[0])
   self.VVMKmc()
  FFxTkM(self["myTitle"], color)
  FFxTkM(self["myBar"]  , color)
 def VVQnOh(self):
  return self.VVZkVN
 def VVY5cz(self):
  return self.selectedItems
 def VVkixk(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VVQzoC()
 def VVPWrP(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVQzoC()
 def VVLMiY(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VVKQR8:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VV7tO9(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVt9eq()
  txt += FFiu6i("Total Unique Items", VVaqQK)
  for i in range(self.totalCols):
   if self.VVrZ8Z[i - 1] > 1 or self.VVrZ8Z[i - 1] == self.VVFEGZ or self.VVrZ8Z[i - 1] == self.VVztXt:
    name, tot = self.VVLMiY(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFn7o1(self, txt)
 def VVvMZR(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVl8Td(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VV3EJ0(self, newList, newTitle="", VVyNqAMsg=True):
  if newList:
   self.VVKQR8 = newList
   if self.VVwgKR and self.VVtQZQ == 0:
    self.VVKQR8 = sorted(self.VVKQR8, key=lambda x: int(x[self.VVtQZQ])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VVKQR8 = sorted(self.VVKQR8, key=lambda x: x[self.VVtQZQ].lower(), reverse=self.lastSortModeIsReverese)
   if VVyNqAMsg : self.VVU61Y("Refreshing ...")
   else   : self.VVbaXM()
   if newTitle:
    self.VVahDS(newTitle)
  else:
   FFcgS7(self, "Cannot refresh list")
   self.cancel()
 def VVocRR(self, data):
  ndx = self.VV7oaa()
  newRow = self.VVrfRO(ndx, data, self.VVw6oj, self.VVc1Ml, self.VVnMUd, self.VVZoDW, None)
  if newRow:
   self.VVKQR8[ndx] = data
   self["myTable"].list[ndx] = newRow
   self.VVQzoC()
   return True
  else:
   return False
 def VVkrJW(self, colNum, textToFind, VVuqoX=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVQzoC()
    break
  else:
   if VVuqoX:
    FFLk1N(self, "Not found", 1000)
 def VVLOwP(self, colDict, VVuqoX=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVQzoC()
    return
  if VVuqoX:
   FFLk1N(self, "Not found", 1000)
 def VVLOwP_partial(self, colDict, VVuqoX=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVQzoC()
    return
  if VVuqoX:
   FFLk1N(self, "Not found", 1000)
 def VVdyDU(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVqRoL(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVXZTA:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVVT4o(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VVXZTA: return True
  else        : return False
 def VVbYXo(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVq7iq(self):
  if not self["keyMenu"].getVisible() or self.VVs65B:
   return
  VVlZjX = []
  VVlZjX.append(("Table Statistcis"             , "tableStat"  ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append((FF0hQa("Export Table to .html"     , VVaqQK) , "VVjQ2V" ))
  VVlZjX.append((FF0hQa("Export Table to .csv"     , VVaqQK) , "VVX0Pm" ))
  VVlZjX.append((FF0hQa("Export Table to .txt (Tab Separated)", VVaqQK) , "VVMvNT" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVrZ8Z[i] > 1 or self.VVrZ8Z[i] == self.VVBY7t:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVlZjX.append(VVZYy7)
   if tot == 1 : VVlZjX.append(("Sort", sList[0][1]))
   else  : VVlZjX += sList
  FFqaQ9(self, self.VV40pP, VVlZjX=VVlZjX, title=self.VVbfvv())
 def VV40pP(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VV7tO9()
   elif item == "VVjQ2V": FF1SeM(self, self.VVjQ2V, title=title)
   elif item == "VVX0Pm" : FF1SeM(self, self.VVX0Pm , title=title)
   elif item == "VVMvNT" : FF1SeM(self, self.VVMvNT , title=title)
   else:
    isReversed = False
    if self.VVtQZQ == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVwgKR and item == 0:
     self.VVKQR8 = sorted(self.VVKQR8, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VVKQR8 = sorted(self.VVKQR8, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVtQZQ = item
    self.VVU61Y("Sorting ...")
 def VVejQW(self):
  self["myTable"].up()
  self.VVQzoC()
 def VVktPX(self):
  self["myTable"].down()
  self.VVQzoC()
 def VVUFJo(self):
  self["myTable"].pageUp()
  self.VVQzoC()
 def VVfM08(self):
  self["myTable"].pageDown()
  self.VVQzoC()
 def VVWn12(self):
  self["myTable"].moveToIndex(0)
  self.VVQzoC()
 def VVg41v(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVQzoC()
 def VVSHbm(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVQzoC()
 def VVMvNT(self):
  expFile = self.VVxTiP() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VV2XT2()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VVKQR8:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVrZ8Z[ndx] > self.VV2JEa or self.VVrZ8Z[ndx] == self.VVztXt:
      col = self.VVBLij(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVGFIN(expFile)
 def VVX0Pm(self):
  expFile = self.VVxTiP() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VV2XT2()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VVKQR8:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVrZ8Z[ndx] > self.VV2JEa or self.VVrZ8Z[ndx] == self.VVztXt:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVBLij(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVGFIN(expFile)
 def VVjQ2V(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVbfvv(), PLUGIN_NAME, VVg2tB)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVbfvv()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VV2XT2()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVrZ8Z:
   colgroup += '   <colgroup>'
   for w in self.VVrZ8Z:
    if w > self.VV2JEa or w == self.VVztXt:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVxTiP() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VVKQR8:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVrZ8Z[ndx] > self.VV2JEa or self.VVrZ8Z[ndx] == self.VVztXt:
      col = self.VVBLij(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVGFIN(expFile)
 def VV2XT2(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVrZ8Z[ndx] > self.VV2JEa or self.VVrZ8Z[ndx] == self.VVztXt:
     newRow.append(col.strip())
  return newRow
 def VVBLij(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFnTaU(col)
 def VVxTiP(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVbfvv())
  fileName = fileName.replace("__", "_")
  path  = FFRZql(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFdfSu()
  return expFile
 def VVGFIN(self, expFile):
  FFkpHN(self, "File exported to:\n\n%s" % expFile, title=self.VVbfvv())
 def VVQzoC(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCvUQZ():
 def __init__(self, pixmapObj, picPath):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
 def VVmc3b(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVq5Pj)
    except Exception as e:
     self.picLoad.PictureData.get().append(self.VVq5Pj)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, "#2200002a"])
    self.picLoad.startDecode(self.picPath)
    return True
   except Exception as e:
    pass
  return False
 def VVq5Pj(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    self.pixmapObj.instance.setPixmap(ptr)
 def VVZcPZ(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VV3C0T(pixmapObj, path):
  cl = CCvUQZ(pixmapObj, path)
  ok = cl.VVmc3b()
  if ok: return cl
  else : return None
class CCdNIB(Screen):
 def __init__(self, session, title="", VViJTE=None, showGrnMsg=""):
  self.skin, self.skinParam = FF8X8q(VVTS1Q, 1400, 800, 30, 40, 20, "#22000060", "#2200002a", 30)
  if not title:
   title = os.path.basename(VViJTE),
  self.session = session
  FFNPyH(self, title, addCloser=True)
  self["myPic"]  = Pixmap()
  self.VViJTE = VViJTE
  self.showGrnMsg  = showGrnMsg
  self.picViewer  = None
  self.onShown.append(self.VVYZus)
  self.onClose.append(self.onExit)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  self.picViewer = CCvUQZ.VV3C0T(self["myPic"], self.VViJTE)
  if self.picViewer:
   if self.showGrnMsg:
    FFLk1N(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFcgS7(self, "Cannot view picture file:\n\n%s" % self.VViJTE)
   self.close()
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVZcPZ()
 @staticmethod
 def VVrD1V(SELF, VViJTE, title="", showGrnMsg=""):
  SELF.session.open(boundFunction(CCdNIB, title=title, VViJTE=VViJTE, showGrnMsg=showGrnMsg))
class CCyCKB(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FF8X8q(VVyKke, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 26, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFNPyH(self, title=self.Title)
  FFkV23(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Signal & Player Cotroller Hotkey"       , CFG.hotkey_signal    ))
  if VV2GoD:
   lst.append(getConfigListEntry("EPG Translation Language"        , CFG.epgLanguage    ))
  if VVVSQr:
   lst.append(getConfigListEntry("Force UTF-8 Encoding (only OpenVision Python-3.10.2+)" , CFG.forceUtf8Encoding   ))
  lst.append(getConfigListEntry(VV9gSb *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type"         , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsPath    ))
  lst.append(getConfigListEntry("Movie/Series Download Path"         , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(VV9gSb *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(VV9gSb *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB)"        , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons"            , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVFGsh()
  self.onShown.append(self.VVYZus)
 def VVFGsh(self):
  kList = {
    "ok"  : self.VVEvnY    ,
    "green"  : self.VVZ4zQ   ,
    "menu"  : self.VVDjRc  ,
    "cancel" : self.VVv8JR  ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"]  = boundFunction(self["config"].handleKey, kLeft)
   kList["right"]  = boundFunction(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = boundFunction(self["config"].VVbkVm, 0)
     kList["chanDown"] = boundFunction(self["config"].VVbkVm, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FFXHxA(self)
  FFhGNA(self["config"])
  FFwAWu(self, self["config"])
  FFZH71(self)
 def VVEvnY(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsPath   : self.VVot1h()
   elif item == CFG.MovieDownloadPath   : self.VVPCGe(item, self["config"].getCurrent()[0])
   elif item == CFG.PIconsPath    : self.VV3iX5(item)
   elif item == CFG.backupPath    : self.VV3iX5(item)
   elif item == CFG.packageOutputPath  : self.VV3iX5(item)
   elif item == CFG.downloadedPackagesPath : self.VV3iX5(item)
   elif item == CFG.exportedTablesPath  : self.VV3iX5(item)
   elif item == CFG.exportedPIconsPath  : self.VV3iX5(item)
 def VVPCGe(self, item, title):
  tot = CCsRnB.VVCtVs()
  if tot : FFcgS7(self, "Cannot change while downloading.", title=title)
  else : self.VV3iX5(item)
 def VVot1h(self):
  VVlZjX = []
  VVlZjX.append(("Auto Find" , "auto"))
  VVlZjX.append(("Custom Path" , "path"))
  FFqaQ9(self, self.VVRxt9, VVlZjX=VVlZjX, title="IPTV Hosts Files Path")
 def VVRxt9(self, item=None):
  if item:
   if   item == "auto": CFG.iptvHostsPath.setValue(VVRVLV)
   elif item == "path": self.VV3iX5(CFG.iptvHostsPath)
 def VV3iX5(self, configObj):
  sDir = configObj.getValue()
  if sDir == VVRVLV:
   sDir = "/"
  self.session.openWithCallback(boundFunction(self.VVggg9, configObj)
         , boundFunction(CCs7ea, mode=CCs7ea.VVIOWu, VVuLbb=sDir))
 def VVggg9(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVv8JR(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFixrz(self, self.VVZ4zQ, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVZ4zQ(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVIUhA()
  self.VVE1zN()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVE1zN(self):
  CCo0R4.VVsk6x()
 def VVDjRc(self):
  VVlZjX = []
  VVlZjX.append(("Use Backup directory in all other paths"      , "VV9MOv"   ))
  VVlZjX.append(("Reset all to default (including File Manager bookmarks)"  , "VVLHJq"   ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Backup %s Settings" % PLUGIN_NAME        , "VVuRVn"  ))
  VVlZjX.append(("Restore %s Settings" % PLUGIN_NAME       , "VVoQ7Q"  ))
  if fileExists(VVNnjH + VVez4Y):
   VVlZjX.append(VVZYy7)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVlZjX.append(('%s Checking for Update' % txt1       , txt2     ))
   VVlZjX.append(("Reinstall %s" % PLUGIN_NAME        , "VV3eHK"  ))
   VVlZjX.append(("Update %s" % PLUGIN_NAME        , "VVybU2"   ))
  FFqaQ9(self, self.VVCEBo, VVlZjX=VVlZjX, title="Config. Options")
 def VVCEBo(self, item=None):
  if item:
   if   item == "VV9MOv"  : FFixrz(self, self.VV9MOv , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVLHJq"  : FFixrz(self, self.VVLHJq, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCN5Bb)
   elif item == "VVuRVn" : self.VVuRVn()
   elif item == "VVoQ7Q" : FF1SeM(self, self.VVoQ7Q, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVXKZX(True)
   elif item == "disableChkUpdate" : self.VVXKZX(False)
   elif item == "VV3eHK" : FF1SeM(self, self.VV3eHK , "Checking Server ...")
   elif item == "VVybU2"  : FF1SeM(self, self.VVybU2  , "Checking Server ...")
 def VVuRVn(self):
  path = "%sajpanel_settings_%s" % (VVNnjH, FFdfSu())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFkpHN(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVoQ7Q(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFfDK7("find / %s -iname '%s*' | grep %s" % (FFVC1u(1), name, name))
  if lines:
   lines.sort()
   VVlZjX = []
   for line in lines:
    VVlZjX.append((line, line))
   FFqaQ9(self, boundFunction(self.VVAjmA, title), title=title, VVlZjX=VVlZjX, width=1200)
  else:
   FFcgS7(self, "No settings files found !", title=title)
 def VVAjmA(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFW1ru(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVIUhA()
    FFKAmt()
   else:
    FFGmd5(SELF, path, title=title)
 def VVXKZX(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VV9MOv(self):
  newPath = FFRZql(VVNnjH)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVIUhA()
 @staticmethod
 def VVyy1X():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVLHJq(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.EventsInfoMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.epgLanguage.setValue("off")
  CFG.forceUtf8Encoding.setValue(True)
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.autoResetFrozenIptvChan.setValue(True)
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.iptvHostsPath.setValue(VVRVLV)
  CFG.MovieDownloadPath.setValue(CCsRnB.VVhiFq())
  CFG.PIconsPath.setValue(VVkKH6)
  CFG.backupPath.setValue(CCyCKB.VVyy1X())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVIUhA()
  self.close()
 def VVIUhA(self):
  configfile.save()
  global VVNnjH
  VVNnjH = CFG.backupPath.getValue()
  FFKhdh()
 def VVybU2(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVVZ6L(title)
  if webVer:
   FFixrz(self, boundFunction(FF1SeM, self, boundFunction(self.VV8O1O, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VV3eHK(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVVZ6L(title, True)
  if webVer:
   FFixrz(self, boundFunction(FF1SeM, self, boundFunction(self.VV8O1O, webVer, title, True)), "Install and Restart ?", title=title)
 def VV8O1O(self, webVer, title, isReinst=False):
  url = self.VVhVmf(self, title)
  if url:
   VV4tpv = FFfVBP() == "dpkg"
   if VV4tpv == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VV4tpv else "ipk")
   path, err = FFDt8N(url + fName, fName, timeout=2)
   if path:
    if isReinst : cmd = FFlY7a(VVFpOM, path)
    else  : cmd = FFlY7a(VVDZdr, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFLwr1(self, cmd)
    else:
     FFMiwh(self, title=title)
   else:
    FFcgS7(self, err, title=title)
 def VVVZ6L(self, title, anyVer=False):
  url = self.VVhVmf(self, title)
  if not url:
   return ""
  path, err = FFDt8N(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFcgS7(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFeIec(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFcgS7(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVg2tB.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFfDK7(cmd)
   if list and curVer == list[0]:
    return webVer
  FFkpHN(self, FF0hQa("No update required.", VVeO4o) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVhVmf(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVNnjH + VVez4Y
  if fileExists(path):
   span = iSearch(r"(http.+)", FFeIec(path), IGNORECASE)
   if span : url = FFRZql(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFcgS7(SELF, err, title)
  return url
 @staticmethod
 def VV24fn(url):
  path, err = FFDt8N(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFeIec(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVg2tB.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFfDK7(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCN5Bb(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FF8X8q(VVLjNu, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVmnwB
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFNPyH(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVmjR4("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVmjR4("\c00888888", i) + sp + "GREY\n"
   txt += self.VVmjR4("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVmjR4("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVmjR4("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVmjR4("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVmjR4("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVmjR4("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVmjR4("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVmjR4("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVmjR4("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVmjR4("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVEvnY ,
   "green"   : self.VVEvnY ,
   "left"   : self.VVCwsY ,
   "right"   : self.VVNcXN ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  self.VVXx5w()
 def VVEvnY(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFixrz(self, self.VVSia8, "Change to : %s" % txt, title=self.Title)
 def VVSia8(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVmnwB
  VVmnwB = self.cursorPos
  self.VVbV9l()
  self.close()
 def VVCwsY(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVXx5w()
 def VVNcXN(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVXx5w()
 def VVXx5w(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVmjR4(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVpL5B(color):
  if VVg4jx: return "\\" + color
  else    : return ""
 @staticmethod
 def VVbV9l():
  global VVZERI, VV7bzw, VVahL2, VVaqQK, VVeSCc, VV15r0, VVeO4o, VVg4jx, COLOR_CONS_BRIGHT_YELLOW, VV3UWE, VVzeuF, VVIXzm, VV3rkc
  VV3rkc   = CCN5Bb.VVmjR4("\c00FFFFFF", VVmnwB)
  VV7bzw    = CCN5Bb.VVmjR4("\c00888888", VVmnwB)
  VVZERI  = CCN5Bb.VVmjR4("\c005A5A5A", VVmnwB)
  VV15r0    = CCN5Bb.VVmjR4("\c00FF0000", VVmnwB)
  VVahL2   = CCN5Bb.VVmjR4("\c00FF5000", VVmnwB)
  VVg4jx   = CCN5Bb.VVmjR4("\c00FFFF00", VVmnwB)
  COLOR_CONS_BRIGHT_YELLOW = CCN5Bb.VVmjR4("\c00FFFFAA", VVmnwB)
  VVeO4o   = CCN5Bb.VVmjR4("\c0000FF00", VVmnwB)
  VVeSCc    = CCN5Bb.VVmjR4("\c000066FF", VVmnwB)
  VV3UWE    = CCN5Bb.VVmjR4("\c0000FFFF", VVmnwB)
  VVzeuF  = CCN5Bb.VVmjR4("\c00DSFFFF", VVmnwB)  #
  VVIXzm   = CCN5Bb.VVmjR4("\c00FA55E7", VVmnwB)
  VVaqQK    = CCN5Bb.VVmjR4("\c00FF8F5F", VVmnwB)
CCN5Bb.VVbV9l()
class CCrjmi(Screen):
 def __init__(self, session, path, VV4tpv):
  self.skin, self.skinParam = FF8X8q(VVLiFQ, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVesOS   = path
  self.VVuQFL   = ""
  self.VVyfsg   = ""
  self.VV4tpv    = VV4tpv
  self.VVdE8e    = ""
  self.VVxesw  = ""
  self.VVJ86e    = False
  self.VVSimY  = False
  self.postInstAcion   = 0
  self.VVLiml  = "enigma2-plugin-extensions"
  self.VVWQPF  = "enigma2-plugin-systemplugins"
  self.VVcCSG = "enigma2"
  self.VViWKU  = 0
  self.VV2fbU  = 1
  self.VVwVRb  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVBfiI = "DEBIAN"
  else        : self.VVBfiI = "CONTROL"
  self.controlPath = self.Path + self.VVBfiI
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VV4tpv:
   self.packageExt  = ".deb"
   self.VVc1Ml  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVc1Ml  = "#11001020"
  FFNPyH(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFkV23(self["keyRed"] , "Create")
  FFkV23(self["keyGreen"] , "Post Install")
  FFkV23(self["keyYellow"], "Installation Path")
  FFkV23(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVveWy  ,
   "green"   : self.VVX1nz ,
   "yellow"  : self.VVB9Ql  ,
   "blue"   : self.VVe9DV  ,
   "cancel"  : self.VVKEbv
  }, -1)
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FFZH71(self)
  if self.VVc1Ml:
   FFxTkM(self["myBody"], self.VVc1Ml)
   FFxTkM(self["myLabel"], self.VVc1Ml)
  self.VVePOk(True)
  self.VVBzyk(True)
 def VVBzyk(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVjcL2()
  if isFirstTime:
   if   package.startswith(self.VVLiml) : self.VVesOS = VVggHj + self.VVdE8e + "/"
   elif package.startswith(self.VVWQPF) : self.VVesOS = VVvV4V + self.VVdE8e + "/"
   else            : self.VVesOS = self.Path
  if self.VVJ86e : myColor = VVaqQK
  else    : myColor = VV3rkc
  txt  = ""
  txt += "Source Path\t: %s\n" % FF0hQa(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FF0hQa(self.VVesOS, VVg4jx)
  if self.VVyfsg : txt += "Package File\t: %s\n" % FF0hQa(self.VVyfsg, VV7bzw)
  elif errTxt   : txt += "Warning\t: %s\n"  % FF0hQa("Check Control File fields : %s" % errTxt, VVahL2)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FF0hQa("Restart GUI", VVaqQK)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FF0hQa("Reboot Device", VVaqQK)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FF0hQa("Post Install", VVeO4o), act)
  if not errTxt and VVahL2 in controlInfo:
   txt += "Warning\t: %s\n" % FF0hQa("Errors in control file may affect the result package.", VVahL2)
  txt += "\nControl File\t: %s\n" % FF0hQa(self.controlFile, VV7bzw)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVX1nz(self):
  VVlZjX = []
  VVlZjX.append(("No Action"    , "noAction"  ))
  VVlZjX.append(("Restart GUI"    , "VVvjub"  ))
  VVlZjX.append(("Reboot Device"   , "rebootDev"  ))
  FFqaQ9(self, self.VVfuAl, title="Package Installation Option (after completing installation)", VVlZjX=VVlZjX)
 def VVfuAl(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVvjub"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVePOk(False)
   self.VVBzyk()
 def VVB9Ql(self):
  rootPath = FF0hQa("/%s/" % self.VVdE8e, VVZERI)
  VVlZjX = []
  VVlZjX.append(("Current Path"        , "toCurrent"  ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Extension Path"       , "toExtensions" ))
  VVlZjX.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVlZjX.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFqaQ9(self, self.VVGo3G, title="Installation Path", VVlZjX=VVlZjX)
 def VVGo3G(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVPHJ6(FF5bbC(self.Path, True))
   elif item == "toExtensions"  : self.VVPHJ6(VVggHj)
   elif item == "toSystemPlugins" : self.VVPHJ6(VVvV4V)
   elif item == "toRootPath"  : self.VVPHJ6("/")
   elif item == "toRoot"   : self.VVPHJ6("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVGtyh, boundFunction(CCs7ea, mode=CCs7ea.VVIOWu, VVuLbb=VVNnjH))
 def VVGtyh(self, path):
  if len(path) > 0:
   self.VVPHJ6(path)
 def VVPHJ6(self, parent, withPackageName=True):
  if withPackageName : self.VVesOS = parent + self.VVdE8e + "/"
  else    : self.VVesOS = "/"
  mode = self.VVx4yK()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVNh5y(mode), self.controlFile))
  self.VVBzyk()
 def VVe9DV(self):
  if fileExists(self.controlFile):
   lines = FFW1ru(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFZyEN(self, self.VVmL18, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFcgS7(self, "Version not found or incorrectly set !")
  else:
   FFGmd5(self, self.controlFile)
 def VVmL18(self, VVF1lw):
  if VVF1lw:
   version, color = self.VVhIP8(VVF1lw, False)
   if color == VV3UWE:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVF1lw, self.controlFile))
    self.VVBzyk()
   else:
    FFcgS7(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVKEbv(self):
  if self.newControlPath:
   if self.VVJ86e:
    self.VVjl6G()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FF0hQa(self.newControlPath, VV7bzw)
    txt += FF0hQa("Do you want to keep these files ?", VVg4jx)
    FFixrz(self, self.close, txt, callBack_No=self.VVjl6G, title="Create Package", VVEkk8=True)
  else:
   self.close()
 def VVjl6G(self):
  os.system(FFA9Vj("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVNh5y(self, mode):
  if   mode == self.VV2fbU : prefix = self.VVLiml
  elif mode == self.VVwVRb : prefix = self.VVWQPF
  else        : prefix = self.VVcCSG
  return prefix + "-" + self.VVxesw
 def VVx4yK(self):
  if   self.VVesOS.startswith(VVggHj) : return self.VV2fbU
  elif self.VVesOS.startswith(VVvV4V) : return self.VVwVRb
  else            : return self.VViWKU
 def VVePOk(self, isFirstTime):
  self.VVdE8e   = os.path.basename(os.path.normpath(self.Path))
  self.VVdE8e   = "_".join(self.VVdE8e.split())
  self.VVxesw = self.VVdE8e.lower()
  self.VVJ86e = self.VVxesw == VVhBuB.lower()
  if self.VVJ86e and self.VVxesw.endswith("ajpan"):
   self.VVxesw += "el"
  if self.VVJ86e : self.VVuQFL = VVNnjH
  else    : self.VVuQFL = CFG.packageOutputPath.getValue()
  self.VVuQFL = FFRZql(self.VVuQFL)
  if not pathExists(self.controlPath):
   os.system(FFA9Vj("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVJ86e : t = PLUGIN_NAME
  else    : t = self.VVdE8e
  self.VVsOmy(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VV0Wds.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVJ86e : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVsOmy(self.postrmFile, txt)
  if self.VVJ86e:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVg2tB)
   self.VVsOmy(self.preinstFile, txt)
  else:
   self.VVsOmy(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVdE8e)
  mode = self.VVx4yK()
  if isFirstTime and not mode == self.VViWKU:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VV9gSb
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVsOmy(self.postinstFile, txt, VVkbS3=True)
  os.system(FFA9Vj("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVJ86e : version, descripton, maintainer = VVg2tB , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVdE8e , self.VVdE8e
   txt = ""
   txt += "Package: %s\n"  % self.VVNh5y(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVsOmy(self, path, lines, VVkbS3=False):
  if not fileExists(path) or VVkbS3:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVjcL2(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFW1ru(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FF0hQa(line, VVahL2)
     elif not line.startswith(" ")    : line = FF0hQa(line, VVahL2)
     else          : line = FF0hQa(line, VV3UWE)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VV3UWE
   else   : color = VVahL2
   descr = FF0hQa(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVahL2
     elif line.startswith((" ", "\t")) : color = VVahL2
     elif line.startswith("#")   : color = VV7bzw
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVhIP8(val, True)
      elif key == "Version"  : version, color = self.VVhIP8(val, False)
      elif key == "Maintainer" : maint  , color = val, VV3UWE
      elif key == "Architecture" : arch  , color = val, VV3UWE
      else:
       color = VV3UWE
      if not key == "OE" and not key.istitle():
       color = VVahL2
     else:
      color = VVaqQK
     txt += FF0hQa(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVyfsg = self.VVuQFL + packageName
   self.VVSimY = True
   errTxt = ""
  else:
   self.VVyfsg  = ""
   self.VVSimY = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVhIP8(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VV3UWE
  else          : return val, VVahL2
 def VVveWy(self):
  if not self.VVSimY:
   FFcgS7(self, "Please fix Control File errors first.")
   return
  if self.VV4tpv: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FF5bbC(self.VVesOS, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVdE8e
  symlinkTo  = FFClhq(self.Path)
  dataDir   = self.VVesOS.rstrip("/")
  removePorjDir = FFA9Vj("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFA9Vj("rm -f '%s'" % self.VVyfsg) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FF7ojp()
  if self.VV4tpv:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFXdt2("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVJ86e:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVesOS == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVBfiI)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVyfsg, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVyfsg
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVyfsg, FFFlx3(result  , VVeO4o))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVesOS, FFFlx3(instPath, VV3UWE))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFFlx3(failed, VVahL2))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFLwr1(self, cmd)
class CCs7ea(Screen):
 VVto1M   = 0
 VVIOWu  = 1
 VVXeJh = 20
 VVQiB5  = None
 def __init__(self, session, VVuLbb="/", mode=VVto1M, VVTPJq="Select", VVbh3O=30, gotoMovie=False):
  self.skin, self.skinParam = FF8X8q(VVycF3, 1400, 920, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFNPyH(self)
  FFkV23(self["keyRed"] , "Exit")
  FFkV23(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVTPJq = VVTPJq
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  CCs7ea.VVQiB5 = self
  if   self.gotoMovie        : VVDcET, self.VVuLbb = True , CCs7ea.VVhTh0(self)[1] or "/"
  elif self.mode == self.VVto1M  : VVDcET, self.VVuLbb = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVIOWu : VVDcET, self.VVuLbb = False, VVuLbb
  else           : VVDcET, self.VVuLbb = True , VVuLbb
  self.VVuLbb = FFRZql(self.VVuLbb)
  self["myMenu"] = CCBYWY(  directory   = "/"
         , VVDcET   = VVDcET
         , VVmFNs = True
         , VVAwMt   = self.skinParam["width"]
         , VVbh3O   = self.skinParam["bodyFontSize"]
         , VV786P  = self.skinParam["bodyLineH"]
         , VVYnvh  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVEvnY      ,
   "red"    : self.VVuHgo     ,
   "green"    : self.VVpagF    ,
   "yellow"   : self.VVZipe   ,
   "blue"    : self.VVJASc   ,
   "menu"    : self.VVEDAd    ,
   "info"    : self.VViUzj    ,
   "cancel"   : self.VVwz5v     ,
   "pageUp"   : self.VVwz5v     ,
   "chanUp"   : self.VVwz5v
  }, -1)
  FFNteF(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVaXB7)
 def onExit(self):
  CCs7ea.VVQiB5 = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVaXB7)
  FFXHxA(self)
  FFhGNA(self["myMenu"], bg="#06003333")
  FFZH71(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode == self.VVIOWu:
   FFkV23(self["keyGreen"], self.VVTPJq)
   color = "#22000022"
   FFxTkM(self["myBody"], color)
   FFxTkM(self["myMenu"], color)
   color = "#22220000"
   FFxTkM(self["myTitle"], color)
   FFxTkM(self["myBar"], color)
  self.VVaXB7()
  if self.VVbCVz(self.VVuLbb) > self.bigDirSize:
   FFLk1N(self, "Changing directory...")
   FF3K6t(self.VV8fa2)
  else:
   self.VV8fa2()
 def VV8fa2(self):
  self["myMenu"].VV12WS(self.VVuLbb)
  if self.gotoMovie:
   self.VVm9v6(chDir=False)
 def VVSHbm(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VV0uaN(self):
  self["myMenu"].refresh()
  FFfRw4()
 def VVbCVz(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VVEvnY(self):
  if self["myMenu"].VVxP73():
   path = self.VVYuaX(self.VV2FRK())
   if self.VVbCVz(path) > self.bigDirSize:
    FFLk1N(self, "Changing directory...")
    FF3K6t(self.VVAkNM)
   else:
    self.VVAkNM()
  else:
   self.VVGMSA()
 def VVAkNM(self):
  self["myMenu"].descent()
  self.VVaXB7()
 def VVwz5v(self):
  if self["myMenu"].VV0Q2u():
   self["myMenu"].moveToIndex(0)
   self.VVAkNM()
 def VVuHgo(self):
  if not FFPRFL(self):
   self.close("")
 def VVpagF(self):
  if self.mode == self.VVIOWu:
   path = self.VVYuaX(self.VV2FRK())
   self.close(path)
 def VViUzj(self):
  FF1SeM(self, self.VVzYHf, title="Calculating size ...")
 def VVzYHf(self):
  path = self.VVYuaX(self.VV2FRK())
  param = self.VVy7Q0(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFmclR("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCs7ea.VVjCgH(path)
     freeSize = CCs7ea.VVULf4(path)
     size = totSize - freeSize
     totSize  = CCs7ea.VVxfhW(totSize)
     freeSize = CCs7ea.VVxfhW(freeSize)
    else:
     size = FFmclR("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CCs7ea.VVxfhW(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FF0hQa(pathTxt, VVaqQK) + "\n"
   if slBroken : fileTime = self.VVIWuW(path)
   else  : fileTime = self.VV3Rf2(path)
   def VVOpU1(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVOpU1("Path"    , pathTxt)
   txt += VVOpU1("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVOpU1("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVOpU1("Total Size"   , "%s" % totSize)
    txt += VVOpU1("Used Size"   , "%s" % usedSize)
    txt += VVOpU1("Free Size"   , "%s" % freeSize)
   else:
    txt += VVOpU1("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVOpU1("Owner"    , owner)
   txt += VVOpU1("Group"    , group)
   txt += VVOpU1("Perm. (User)"  , permUser)
   txt += VVOpU1("Perm. (Group)"  , permGroup)
   txt += VVOpU1("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVOpU1("Perm. (Ext.)" , permExtra)
   txt += VVOpU1("iNode"    , iNode)
   txt += VVOpU1("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VV9gSb, VV9gSb)
    txt += hLinkedFiles
   txt += self.VV9BgF(path)
  else:
   FFcgS7(self, "Cannot access information !")
  if len(txt) > 0:
   FFn7o1(self, txt)
 def VVy7Q0(self, path):
  path = path.strip()
  path = FFClhq(path)
  result = FFmclR("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVvdaa(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVvdaa(perm, 1, 4)
   permGroup = VVvdaa(perm, 4, 7)
   permOther = VVvdaa(perm, 7, 10)
   permExtra = VVvdaa(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFgabI("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VV9BgF(self, path):
  txt  = ""
  res  = FFmclR("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FF0hQa("File Attributes:", VVIXzm), txt)
  return txt
 def VV3Rf2(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFscD6(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFscD6(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFscD6(os.path.getctime(path))
  return txt
 def VVIWuW(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFmclR("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFmclR("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFmclR("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVYuaX(self, currentSel):
  currentDir  = self["myMenu"].VV0Q2u()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVxP73():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VV2FRK(self):
  return self["myMenu"].getSelection()[0]
 def VVaXB7(self):
  FFLk1N(self)
  path = self.VVYuaX(self.VV2FRK())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VVKQR8 = self.VVwEN4()
  if VVKQR8 and len(VVKQR8) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VVcS3B(path)
  if self.mode == self.VVto1M and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
 def VVcS3B(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVHqCV(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVEDAd(self):
  if self.mode == self.VVto1M:
   path  = self.VVYuaX(self.VV2FRK())
   isDir  = os.path.isdir(path)
   VVlZjX = []
   VVlZjX.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVnSk9(path):
     sepShown = True
     VVlZjX.append(VVZYy7)
     VVlZjX.append( (VVaqQK + "Archiving / Packaging"      , "VVJmWS"  ))
    if self.VVV4UN(path):
     if not sepShown:
      VVlZjX.append(VVZYy7)
     VVlZjX.append( (VVaqQK + "Read Backup information"     , "VVaQB3"  ))
     VVlZjX.append( (VVaqQK + "Compress Octagon Image (to zip File)"  , "VVuDgt" ))
   elif os.path.isfile(path):
    selFile = self.VV2FRK()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar")) : VVlZjX.extend(self.VVBaUn(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVlZjX.extend(self.VVgntG(True))
    elif selFile.endswith(".m3u")              : VVlZjX.extend(self.VV31OI(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FFfE1j(path):
     VVlZjX.append(VVZYy7)
     VVlZjX.append((VVaqQK + "View"     , "textView_def" ))
     VVlZjX.append((VVaqQK + "View (Select Encoder)" , "textView_enc" ))
     VVlZjX.append((VVaqQK + "Edit"     , "text_Edit"  ))
    if len(txt) > 0:
     VVlZjX.append(VVZYy7)
     VVlZjX.append(   (VVaqQK + txt      , "VVGMSA"  ))
   VVlZjX.append(VVZYy7)
   VVlZjX.append(     ("Create SymLink"       , "VVCU0E" ))
   if not self.VVnSk9(path):
    VVlZjX.append(   ("Rename"          , "VV3Yek" ))
    VVlZjX.append(   ("Copy"           , "copyFileOrDir" ))
    VVlZjX.append(   ("Move"           , "moveFileOrDir" ))
    VVlZjX.append(   ("DELETE"          , "VVuvGF" ))
    if fileExists(path):
     VVlZjX.append(VVZYy7)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVlZjX.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVlZjX.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVlZjX.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVlZjX.append(VVZYy7)
   VVlZjX.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVlZjX.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCs7ea.VVhTh0(self)
   if fPath:
    VVlZjX.append(VVZYy7)
    VVlZjX.append(   (VVg4jx + "Go to current movie"  , "VVm9v6"))
   VVlZjX.append(VVZYy7)
   VVlZjX.append(    ("Set current directory as \"Startup Path\"" , "VV4OZN" ))
   FFqaQ9(self, self.VVwsLk, title="Options", VVlZjX=VVlZjX)
 def VVwsLk(self, item=None):
  if self.mode == self.VVto1M:
   if item is not None:
    path = self.VVYuaX(self.VV2FRK())
    selFile = self.VV2FRK()
    if   item == "properties"    : self.VViUzj()
    elif item == "VVJmWS"  : self.VVJmWS(path)
    elif item == "VVaQB3"  : self.VVaQB3(path)
    elif item == "VVuDgt" : self.VVuDgt(path)
    elif item.startswith("extract_")  : self.VVLc4X(path, selFile, item)
    elif item.startswith("script_")   : self.VViqi3(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVzaO1Item_m3u(path, selFile, item)
    elif item.startswith("textView_def") : FFhuLL(self, path)
    elif item.startswith("textView_enc") : self.VVYHSk(path)
    elif item.startswith("text_Edit")  : CCkrAL(self, path)
    elif item == "chmod644"     : self.VVaY2o(path, selFile, "644")
    elif item == "chmod755"     : self.VVaY2o(path, selFile, "755")
    elif item == "chmod777"     : self.VVaY2o(path, selFile, "777")
    elif item == "VVCU0E"   : self.VVCU0E(path, selFile)
    elif item == "VV3Yek"   : self.VV3Yek(path, selFile)
    elif item == "copyFileOrDir"   : self.VV9bLe(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VV9bLe(path, selFile, True)
    elif item == "VVuvGF"   : self.VVuvGF(path, selFile)
    elif item == "createNewFile"   : self.VVJS7C(path, True)
    elif item == "createNewDir"    : self.VVJS7C(path, False)
    elif item == "VVm9v6"   : self.VVm9v6()
    elif item == "VV4OZN"   : self.VV4OZN(path)
    elif item == "VVGMSA"    : self.VVGMSA()
    else         : self.close()
 def VVGMSA(self):
  selFile = self.VV2FRK()
  path  = self.VVYuaX(selFile)
  if os.path.isfile(path):
   VVYqjI = []
   category = self["myMenu"].VVui5G(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVzayA(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : CCdNIB.VVrD1V(self, path)
   elif category == "txt"         : FFhuLL(self, path)
   elif category in ("tar", "zip", "rar")     : self.VVmWJ0(path, selFile)
   elif category == "scr"         : self.VVQSde(path, selFile)
   elif category == "m3u"         : self.VVQLYP(path, selFile)
   elif category in ("ipk", "deb")       : self.VVRIkr(path, selFile)
   elif category == "mus"         : self.VVsf1m(self, path)
   elif category == "mov"         : self.VVsf1m(self, path)
   elif not FFfE1j(path)        : FFhuLL(self, path)
 def VVZipe(self):
  path = self.VVYuaX(self.VV2FRK())
  action = self.VVcS3B(path)
  if action == 1:
   self.VVun2S(path)
   FFLk1N(self, "Added", 500)
  elif action == -1:
   self.VVsKiz(path)
   FFLk1N(self, "Removed", 500)
  self.VVcS3B(path)
 def VVun2S(self, path):
  VVKQR8 = self.VVwEN4()
  if not VVKQR8:
   VVKQR8 = []
  if len(VVKQR8) >= self.VVXeJh:
   FFcgS7(SELF, "Max bookmarks reached (max=%d)." % self.VVXeJh)
  elif not path in VVKQR8:
   VVKQR8 = [path] + VVKQR8
   self.VVzhgv(VVKQR8)
 def VVJASc(self):
  VVKQR8 = self.VVwEN4()
  if VVKQR8:
   newList = []
   for line in VVKQR8:
    newList.append((line, line))
   VVmAmL  = ("Delete"  , self.VV6l2M )
   VVWQj7 = ("Move Up"   , self.VVoFGQ )
   VVXqVm  = ("Move Down" , self.VVYxqK )
   self.bookmarkMenu = FFqaQ9(self, self.VV09E7, title="Bookmarks", VVlZjX=newList, VVmAmL=VVmAmL, VVWQj7=VVWQj7, VVXqVm=VVXqVm)
 def VV6l2M(self, VV2FRKObj, path):
  if self.bookmarkMenu:
   VVKQR8 = self.VVsKiz(path)
   self.bookmarkMenu.VVp3TA(VVKQR8)
 def VVoFGQ(self, VV2FRKObj, path):
  if self.bookmarkMenu:
   VVKQR8 = self.bookmarkMenu.VVssO6(True)
   if VVKQR8:
    self.VVzhgv(VVKQR8)
 def VVYxqK(self, VV2FRKObj, path):
  if self.bookmarkMenu:
   VVKQR8 = self.bookmarkMenu.VVssO6(False)
   if VVKQR8:
    self.VVzhgv(VVKQR8)
 def VV09E7(self, folder=None):
  if folder:
   folder = FFRZql(folder)
   self["myMenu"].VV12WS(folder)
   self["myMenu"].moveToIndex(0)
  self.VVaXB7()
 def VVwEN4(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVHqCV(self, path):
  VVKQR8 = self.VVwEN4()
  if VVKQR8 and path in VVKQR8:
   return True
  else:
   return False
 def VVi9ua(self):
  if VVwEN4():
   return True
  else:
   return False
 def VVzhgv(self, VVKQR8):
  line = ",".join(VVKQR8)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVsKiz(self, path):
  VVKQR8 = self.VVwEN4()
  if VVKQR8:
   while path in VVKQR8:
    VVKQR8.remove(path)
   self.VVzhgv(VVKQR8)
   return VVKQR8
 def VVm9v6(self, chDir=True):
  fPath, fDir, fName = CCs7ea.VVhTh0(self)
  if fPath:
   if chDir:
    self["myMenu"].VV12WS(fDir)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFLk1N(self, "Not found", 1000)
 def VV4OZN(self, path):
  if not os.path.isdir(path):
   path = FF5bbC(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVzayA(self, selFile, VV9Uka, command):
  FFixrz(self, boundFunction(FFLwr1, self, command, VVnq9X=self.VV0uaN), "%s\n\n%s" % (VV9Uka, selFile))
 def VVBaUn(self, path, calledFromMenu):
  destPath = self.VVZmwG(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVlZjX = []
  if calledFromMenu:
   VVlZjX.append(VVZYy7)
   color = VVaqQK
  else:
   color = ""
  VVlZjX.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVlZjX.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVlZjX.append((color + "Extract Here"            , "extract_here"  ))
  if VVIUAA and path.endswith(".tar.gz"):
   VVlZjX.append(VVZYy7)
   VVlZjX.append((color + 'Convert to ".ipk" Package' , "VV4t3u"  ))
   VVlZjX.append((color + 'Convert to ".deb" Package' , "VV55eu"  ))
  return VVlZjX
 def VVmWJ0(self, path, selFile):
  FFqaQ9(self, boundFunction(self.VVLc4X, path, selFile), title="Compressed File Options", VVlZjX=self.VVBaUn(path, False))
 def VVLc4X(self, path, selFile, item=None):
  if item is not None:
   parent  = FF5bbC(path, False)
   destPath = self.VVZmwG(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VV9gSb
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFXdt2("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFXdt2("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VV9gSb, VV9gSb)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFWNH3(self, cmd)
   elif path.endswith(".zip"):
    self.VVu0YB(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif path.endswith(".rar"):
    self.VVurmp(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFA9Vj("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVzayA(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVzayA(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FF5bbC(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVzayA(selFile, "Extract Here ?"      , cmd)
   elif item == "VV4t3u" : self.VV4t3u(path)
   elif item == "VV55eu" : self.VV55eu(path)
 def VVZmwG(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVu0YB(self, item, path, parent, destPath, VV9Uka):
  FFixrz(self, boundFunction(self.VVW22R, item, path, parent, destPath), VV9Uka)
 def VVW22R(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VV9gSb
  cmd  = FFXdt2("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFFlx3(destPath, VVeO4o))
  cmd +=   sep
  cmd += "fi;"
  FFx5U2(self, cmd, VVnq9X=self.VV0uaN)
 def VVurmp(self, item, path, parent, destPath, VV9Uka):
  FFixrz(self, boundFunction(self.VVdlSm, item, path, parent, destPath), VV9Uka)
 def VVdlSm(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFRZql(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VV9gSb
  cmd  = FFXdt2("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFFlx3(destPath, VVeO4o))
  cmd +=   sep
  cmd += "fi;"
  FFx5U2(self, cmd, VVnq9X=self.VV0uaN)
 def VVgntG(self, addSep=False):
  VVlZjX = []
  if addSep:
   VVlZjX.append(VVZYy7)
  VVlZjX.append((VVaqQK + "View Script File"  , "script_View"  ))
  VVlZjX.append((VVaqQK + "Execute Script File" , "script_Execute" ))
  VVlZjX.append((VVaqQK + "Edit"     , "script_Edit" ))
  return VVlZjX
 def VVQSde(self, path, selFile):
  FFqaQ9(self, boundFunction(self.VViqi3, path, selFile), title="Script File Options", VVlZjX=self.VVgntG())
 def VViqi3(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFhuLL(self, path)
   elif item == "script_Execute" : self.VVzayA(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCkrAL(self, path)
 def VV31OI(self, addSep=False):
  VVlZjX = []
  if addSep:
   VVlZjX.append(VVZYy7)
  VVlZjX.append((VVaqQK + "Browse IPTV Channels"  , "m3u_Browse" ))
  VVlZjX.append((VVaqQK + "Edit"      , "m3u_Edit" ))
  VVlZjX.append((VVaqQK + "View"      , "m3u_View" ))
  return VVlZjX
 def VVQLYP(self, path, selFile):
  FFqaQ9(self, boundFunction(self.VVzaO1Item_m3u, path, selFile), title="M3U/M3U8 File Options", VVlZjX=self.VV31OI())
 def VVzaO1Item_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FF1SeM(self, boundFunction(self.session.open, CC4M3v, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCkrAL(self, path)
   elif item == "m3u_View"  : FFhuLL(self, path)
 def VVYHSk(self, path):
  if fileExists(path) : FF1SeM(self, boundFunction(CCo0R4.VVeOSJ, self, path, boundFunction(self.VVAAKZ, path), defEnc=None), title="Loading Codecs ...", clearMsg=False)
  else    : FFGmd5(self, path)
 def VVAAKZ(self, path, item=None):
  if item:
   FFhuLL(self, path, encLst=item)
 def VVaY2o(self, path, selFile, newChmod):
  FFixrz(self, boundFunction(self.VVGuHX, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVGuHX(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VV5iXK)
  result = FFmclR(cmd)
  if result == "Successful" : FFkpHN(self, result)
  else      : FFcgS7(self, result)
 def VVCU0E(self, path, selFile):
  parent = FF5bbC(path, False)
  self.session.openWithCallback(self.VVrBuV, boundFunction(CCs7ea, mode=CCs7ea.VVIOWu, VVuLbb=parent, VVTPJq="Create Symlink here"))
 def VVrBuV(self, newPath):
  if len(newPath) > 0:
   target = self.VVYuaX(self.VV2FRK())
   target = FFClhq(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFRZql(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFcgS7(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFixrz(self, boundFunction(self.VV7ebz, target, link), "Create Soft Link ?\n\n%s" % txt, VVEkk8=True)
 def VV7ebz(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VV5iXK)
  result = FFmclR(cmd)
  if result == "Successful" : FFkpHN(self, result)
  else      : FFcgS7(self, result)
 def VV3Yek(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFZyEN(self, boundFunction(self.VVyvVh, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVyvVh(self, path, selFile, VVF1lw):
  if VVF1lw:
   parent = FF5bbC(path, True)
   if os.path.isdir(path):
    path = FFClhq(path)
   newName = parent + VVF1lw
   cmd = "mv '%s' '%s' %s" % (path, newName, VV5iXK)
   if VVF1lw:
    if selFile != VVF1lw:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFixrz(self, boundFunction(self.VVh6Dm, cmd), message, title="Rename file?")
    else:
     FFcgS7(self, "Cannot use same name!", title="Rename")
 def VVh6Dm(self, cmd):
  result = FFmclR(cmd)
  if "Fail" in result:
   FFcgS7(self, result)
  self.VV0uaN()
 def VV9bLe(self, path, selFile, isMove):
  if isMove : VVTPJq = "Move to here"
  else  : VVTPJq = "Copy to here"
  parent = FF5bbC(path, False)
  self.session.openWithCallback(boundFunction(self.VVy97V, isMove, path, selFile)
         , boundFunction(CCs7ea, mode=CCs7ea.VVIOWu, VVuLbb=parent, VVTPJq=VVTPJq))
 def VVy97V(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFClhq(path)
   newPath = FFRZql(newPath)
   dest = newPath + lastPart
   if os.path.isdir(path) and os.path.isdir(dest):
    if isMove:
     FFcgS7(self, 'Same directory already exists:\n\n%s\n\n( Try to copy then delete the source )' % dest)
     return
    else:
     dest = newPath
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFixrz(self, boundFunction(FFovqt, self, cmd, VVnq9X=self.VV0uaN), txt, VVEkk8=True)
   else:
    FFcgS7(self, "Cannot %s to same directory !" % action.lower())
 def VVuvGF(self, path, fileName):
  path = FFClhq(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFixrz(self, boundFunction(self.VV9uya, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VV9uya(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VV0uaN()
 def VVnSk9(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVs8GF and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVJS7C(self, path, isFile):
  dirName = FFRZql(os.path.dirname(path))
  if isFile : objName, VVF1lw = "File"  , self.edited_newFile
  else  : objName, VVF1lw = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFZyEN(self, boundFunction(self.VVqPxB, dirName, isFile, title), title=title, defaultText=VVF1lw, message="Enter %s Name:" % objName)
 def VVqPxB(self, dirName, isFile, title, VVF1lw):
  if VVF1lw:
   if isFile : self.edited_newFile = VVF1lw
   else  : self.edited_newDir  = VVF1lw
   path = dirName + VVF1lw
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VV5iXK)
    else  : cmd = "mkdir '%s' %s" % (path, VV5iXK)
    result = FFmclR(cmd)
    if "Fail" in result:
     FFcgS7(self, result)
    self.VV0uaN()
   else:
    FFcgS7(self, "Name already exists !\n\n%s" % path, title)
 def VVRIkr(self, path, selFile):
  VVlZjX = []
  VVlZjX.append(("List Package Files"          , "VVACo7"     ))
  VVlZjX.append(("Package Information"          , "VVXusK"     ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Install Package"           , "VVSy8w_CheckVersion" ))
  VVlZjX.append(("Install Package (force reinstall)"      , "VVSy8w_ForceReinstall" ))
  VVlZjX.append(("Install Package (force overwrite)"      , "VVSy8w_ForceOverwrite" ))
  VVlZjX.append(("Install Package (force downgrade)"      , "VVSy8w_ForceDowngrade" ))
  VVlZjX.append(("Install Package (ignore failed dependencies)"    , "VVSy8w_IgnoreDepends" ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Remove Related Package"         , "VVpvVb_ExistingPackage" ))
  VVlZjX.append(("Remove Related Package (force remove)"     , "VVpvVb_ForceRemove"  ))
  VVlZjX.append(("Remove Related Package (ignore failed dependencies)"  , "VVpvVb_IgnoreDepends" ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("Extract Files"           , "VVc01P"     ))
  VVlZjX.append(("Unbuild Package"           , "VV2yJE"     ))
  FFqaQ9(self, boundFunction(self.VVvhgs, path, selFile), VVlZjX=VVlZjX)
 def VVvhgs(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVACo7"      : self.VVACo7(path, selFile)
   elif item == "VVXusK"      : self.VVXusK(path)
   elif item == "VVSy8w_CheckVersion"  : self.VVSy8w(path, selFile, VV3kNP     )
   elif item == "VVSy8w_ForceReinstall" : self.VVSy8w(path, selFile, VVFpOM )
   elif item == "VVSy8w_ForceOverwrite" : self.VVSy8w(path, selFile, VVDZdr )
   elif item == "VVSy8w_ForceDowngrade" : self.VVSy8w(path, selFile, VVsUnv )
   elif item == "VVSy8w_IgnoreDepends" : self.VVSy8w(path, selFile, VVGLms )
   elif item == "VVpvVb_ExistingPackage" : self.VVpvVb(path, selFile, VV6CjH     )
   elif item == "VVpvVb_ForceRemove"  : self.VVpvVb(path, selFile, VV1bXh  )
   elif item == "VVpvVb_IgnoreDepends"  : self.VVpvVb(path, selFile, VVgRfs )
   elif item == "VVc01P"     : self.VVc01P(path, selFile)
   elif item == "VV2yJE"     : self.VV2yJE(path, selFile)
   else           : self.close()
 def VVACo7(self, path, selFile):
  if FFqVus("ar") : cmd = "allOK='1';"
  else    : cmd  = FF7ojp()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VV9gSb, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VV9gSb, VV9gSb)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFmNHK(self, cmd, VVnq9X=self.VV0uaN)
 def VVc01P(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FF5bbC(path, True) + selFile[:-4]
  cmd  =  FF7ojp()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFA9Vj("mkdir '%s'" % dest) + ";"
  cmd +=    FFA9Vj("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFFlx3(dest, VVeO4o))
  cmd += "fi;"
  FFLwr1(self, cmd, VVnq9X=self.VV0uaN)
 def VV2yJE(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVowXg = os.path.splitext(path)[0]
  else        : VVowXg = path + "_"
  if path.endswith(".deb")   : VVBfiI = "DEBIAN"
  else        : VVBfiI = "CONTROL"
  cmd  = FF7ojp()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVowXg, FF006U())
  cmd += "  mkdir '%s';"    % VVowXg
  cmd += "  CONTPATH='%s/%s';"  % (VVowXg, VVBfiI)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVowXg
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVowXg, VVowXg)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVowXg
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVowXg, VVowXg)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVowXg
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVowXg
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVowXg, FFFlx3(VVowXg, VVeO4o))
  cmd += "fi;"
  FFLwr1(self, cmd, VVnq9X=self.VV0uaN)
 def VVXusK(self, path):
  listCmd  = FFWjY7(VVKJja, "")
  infoCmd  = FFlY7a(VV7MAA , "")
  filesCmd = FFlY7a(VVJjw0, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFNyBL(VVg4jx)
   notInst = "Package not installed."
   cmd  = FFP3Rx("File Info", VVg4jx)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFP3Rx("System Info", VVg4jx)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFFlx3(notInst, VVaqQK))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFP3Rx("Related Files", VVg4jx)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFWNH3(self, cmd)
  else:
   FFMiwh(self)
 def VVSy8w(self, path, selFile, cmdOpt):
  cmd = FFlY7a(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFixrz(self, boundFunction(FFLwr1, self, cmd, VVnq9X=FFfRw4), "Install Package ?\n\n%s" % selFile)
  else:
   FFMiwh(self)
 def VVpvVb(self, path, selFile, cmdOpt):
  listCmd  = FFWjY7(VVKJja, "")
  infoCmd  = FFlY7a(VV7MAA, "")
  instRemCmd = FFlY7a(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFFlx3(errTxt, VVaqQK))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFFlx3(cannotTxt, VVaqQK))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFFlx3(tryTxt, VVaqQK))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFixrz(self, boundFunction(FFLwr1, self, cmd, VVnq9X=FFfRw4), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFMiwh(self)
 def VVXCKR(self, path):
  hostName = FFmclR("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVV4UN(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVXCKR(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVJmWS(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVlZjX = []
  VVlZjX.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVlZjX.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVlZjX.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVlZjX.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVlZjX.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVlZjX.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVlZjX.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVlZjX.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVlZjX.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVlZjX.append(VVZYy7)
  VVlZjX.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVlZjX.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FFqaQ9(self, boundFunction(self.VVUNFV, path), VVlZjX=VVlZjX)
 def VVUNFV(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVwDG0(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVwDG0(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVwDG0(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVwDG0(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVwDG0(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVwDG0(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVwDG0(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVwDG0(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVwDG0(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVwDG0(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVH5r6(path, False)
   elif item == "convertDirToDeb"   : self.VVH5r6(path, True)
   else         : self.close()
 def VVH5r6(self, path, VV4tpv):
  self.session.openWithCallback(self.VV0uaN, boundFunction(CCrjmi, path=path, VV4tpv=VV4tpv))
 def VVwDG0(self, path, fileExt, preserveDirStruct):
  parent  = FF5bbC(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFXdt2("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFXdt2("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFXdt2("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VV9gSb
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFA9Vj("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FFFlx3(resultFile, VVeO4o))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FFFlx3(failed, VVahL2))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFmNHK(self, cmd, VVnq9X=self.VV0uaN)
 def VVaQB3(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFhuLL(self, versionFile)
 def VVuDgt(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVXCKR(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFcgS7(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFW1ru(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FF5bbC(path, False)
  VVowXg = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FFFlx3(errCmd, VVahL2))
  installCmd = FFlY7a(VV3kNP , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VVowXg, VVowXg)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VVowXg
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VVowXg
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VVowXg, VVowXg)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFLwr1(self, cmd, VVnq9X=self.VV0uaN)
 def VV4t3u(self, path):
  FFcgS7(self, "Under Construction.")
 def VV55eu(self, path):
  FFcgS7(self, "Under Construction.")
 @staticmethod
 def VVsf1m(SELF, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   SELF.session.open(CCG8uj, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVhTh0(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFRZql(fDir), fName
  return "", "", ""
 @staticmethod
 def VVjCgH(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVULf4(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVxfhW(size, mode=0):
  txt = CCs7ea.VV67yX(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VV67yX(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
class CCBYWY(MenuList):
 def __init__(self, VVmFNs=False, directory="/", VV5u6H=True, VVDcET=True, VVFHxP=True, VV98Va=None, VVtQJV=False, VVIBpz=False, VVGwyq=False, isTop=False, VVVPhz=None, VVAwMt=1000, VVbh3O=30, VV786P=30, VVYnvh="#00000000"):
  MenuList.__init__(self, list, VVmFNs, eListboxPythonMultiContent)
  self.VV5u6H  = VV5u6H
  self.VVDcET    = VVDcET
  self.VVFHxP  = VVFHxP
  self.VV98Va  = VV98Va
  self.VVtQJV   = VVtQJV
  self.VVIBpz   = VVIBpz or []
  self.VVGwyq   = VVGwyq or []
  self.isTop     = isTop
  self.additional_extensions = VVVPhz
  self.VVAwMt    = VVAwMt
  self.VVbh3O    = VVbh3O
  self.VV786P    = VV786P
  self.pngBGColor    = FF0hYc(VVYnvh)
  self.EXTENSIONS    = self.VVQ26L()
  self.VVaQEh   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVmpyI, self.VVbh3O))
  self.l.setItemHeight(self.VV786P)
  self.png_mem   = self.VVeOjb("mem")
  self.png_usb   = self.VVeOjb("usb")
  self.png_fil   = self.VVeOjb("fil")
  self.png_dir   = self.VVeOjb("dir")
  self.png_dirup   = self.VVeOjb("dirup")
  self.png_srv   = self.VVeOjb("srv")
  self.png_slwfil   = self.VVeOjb("slwfil")
  self.png_slbfil   = self.VVeOjb("slbfil")
  self.png_slwdir   = self.VVeOjb("slwdir")
  self.VV0jbb()
  self.VV12WS(directory)
 def VVeOjb(self, category):
  return LoadPixmap("%s%s.png" % (VV05tg, category), getDesktop(0))
 def VVQ26L(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "rar" : "rar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u" ,
   "m3u8" : "m3u"
  }
 def VVxrgs(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFClhq(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FF0hQa(" -> " , VVg4jx) + FF0hQa(os.readlink(path), VVeO4o)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VV786P + 10, 0, self.VVAwMt, self.VV786P, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VViXzU: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV786P-4, self.VV786P-4, png, self.pngBGColor, self.pngBGColor, VViXzU))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV786P-4, self.VV786P-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVui5G(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VV0jbb(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVVdGz(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVUgJm(self, file):
  if os.path.realpath(file) == file:
   return self.VVVdGz(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVVdGz(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVVdGz(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVn2b7(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVaQEh.info(l[0][0]).getEvent(l[0][0])
 def VVmZXJ(self):
  return self.list
 def VVPi8U(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VV12WS(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVFHxP:
    self.current_mountpoint = self.VVUgJm(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVFHxP:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVGwyq and not self.VVPi8U(path, self.VVIBpz):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVxrgs(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVtQJV:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVaQEh = eServiceCenter.getInstance()
   list = VVaQEh.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VV5u6H and not self.isTop:
   if directory == self.current_mountpoint and self.VVFHxP:
    self.list.append(self.VVxrgs(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVGwyq and self.VVVdGz(directory) in self.VVGwyq):
    self.list.append(self.VVxrgs(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VV5u6H:
   for x in directories:
    if not (self.VVGwyq and self.VVVdGz(x) in self.VVGwyq) and not self.VVPi8U(x, self.VVIBpz):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVxrgs(name = name, absolute = x, isDir = True, png = png))
  if self.VVDcET:
   for x in files:
    if self.VVtQJV:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FF0hQa(" -> " , VVg4jx) + FF0hQa(target, VVeO4o)
       else:
        png = self.png_slbfil
        name += FF0hQa(" -> " , VVg4jx) + FF0hQa(target, VVahL2)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVui5G(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VV05tg, category))
    if (self.VV98Va is None) or iCompile(self.VV98Va).search(path):
     self.list.append(self.VVxrgs(name = name, absolute = x , isDir = False, png = png))
  if self.VVFHxP and len(self.list) == 0:
   self.list.append(self.VVxrgs(name = FF0hQa("No USB connected", VV7bzw), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VV0Q2u(self):
  return self.current_directory
 def VVxP73(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VV12WS(self.getSelection()[0], select = self.current_directory)
 def VVOu4G(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVjrux(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVqOLg)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVqOLg)
 def refresh(self):
  self.VV12WS(self.current_directory, self.VVOu4G())
 def VVqOLg(self, action, device):
  self.VV0jbb()
  if self.current_directory is None:
   self.refresh()
class CCR5s5(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FF8X8q(VVuBsi, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVKQR8   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VV3lZ1(defFG, "#00FFFFFF")
  self.defBG   = self.VV3lZ1(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFNPyH(self, self.Title)
  self["keyRed"].show()
  FFkV23(self["keyGreen"] , "< > Transp.")
  FFkV23(self["keyYellow"], "Foreground")
  FFkV23(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVlIkF        ,
   "yellow"   : boundFunction(self.VVd6XR, False)  ,
   "blue"   : boundFunction(self.VVd6XR, True)  ,
   "up"   : self.VVUTv0          ,
   "down"   : self.VVtNKR         ,
   "left"   : self.VVCwsY         ,
   "right"   : self.VVNcXN         ,
   "last"   : boundFunction(self.VV2cCT, -5) ,
   "next"   : boundFunction(self.VV2cCT, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFxTkM(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFxTkM(self["keyRed"] , c)
  FFxTkM(self["keyGreen"] , c)
  self.VVfqyY()
  self.VVaPqr()
  FF3XWe(self["myColorTst"], self.defFG)
  FFxTkM(self["myColorTst"], self.defBG)
 def VV3lZ1(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVaPqr(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVNmeG(0, 0)
     return
 def VVlIkF(self):
  self.close(self.defFG, self.defBG)
 def VVUTv0(self): self.VVNmeG(-1, 0)
 def VVtNKR(self): self.VVNmeG(1, 0)
 def VVCwsY(self): self.VVNmeG(0, -1)
 def VVNcXN(self): self.VVNmeG(0, 1)
 def VVNmeG(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVXkjo()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVba1i()
 def VVfqyY(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVba1i(self):
  color = self.VVXkjo()
  if self.isBgMode: FFxTkM(self["myColorTst"], color)
  else   : FF3XWe(self["myColorTst"], color)
 def VVd6XR(self, isBg):
  self.isBgMode = isBg
  self.VVfqyY()
  self.VVaPqr()
 def VV2cCT(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVNmeG(0, 0)
 def VVmXAP(self):
  return hex(self.transp)[2:].zfill(2)
 def VVXkjo(self):
  return ("#%s%s" % (self.VVmXAP(), self.colors[self.curRow][self.curCol])).upper()
class CCxsSP(Screen):
 VVq5pM  = 0
 VVEfuT = 1
 def __init__(self, session, mode, endCallback):
  self.session  = session
  margin    = 50
  screenSize   = FFaMwD()
  w     = int(screenSize[0] - margin)
  h     = int(screenSize[1] / 2.0)
  self.skin, self.skinParam = FF8X8q(WINDOW_SUBTITLE, w, h, 35, 20, 30, "#ff000000", "#ff000000", 60)
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.currentIndex  = -1
  self.subtitleMode  = mode
  self.defaultY   = 0
  self.endCallback  = endCallback
  FFNPyH(self)
  self["myTitle"].hide()
  self["mySubtFr"] = Label()
  self["mySubtFr"].hide()
  for i in range(3):
   self["mySubt%d" % i] = Label()
  self.onClose.append(self.VVMQGc)
 def VVvTAI(self, path=""):
  if path :
   self.VV1s9l()
   FF1SeM(self, boundFunction(self.VVk2Vk, path), title="Checking file ...", clearMsg=False)
  else:
   self.VVk2Vk()
 def VVk2Vk(self, path=""):
  if path:
   subtList, err = self.VVdR75(path)
   if err    : self.VVMQGc(err)
   elif not subtList : self.VVMQGc("Invalid srt file")
   else    :
    self.subtList = subtList
    self.VVr7AM()
  else:
   if self.VVJViX():
    self.VVr7AM()
   elif self.subtitleMode == CCxsSP.VVEfuT:
    self.VVMQGc("noResume")
   else:
    if self.VVV4fq(): self.VVr7AM()
    else         : self.VVMQGc("noAutoSrt")
 def VVr7AM(self):
  try:
   InfoBar.instance.enableSubtitle(None)
  except:
   try:
    InfoBar.instance.setSubtitlesEnable(False)
   except:
    pass
  FFLk1N(self, "Subtitle started", 1000, isGrn=True)
  self.VV1s9l()
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVdzOx)
  except:
   self.timerUpdate.callback.append(self.VVdzOx)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVVCIN)
  except:
   self.timerEndText.callback.append(self.VVVCIN)
  self.VVXx8q(True)
 def VVMQGc(self, res=""):
  self.timerUpdate.stop()
  self.timerEndText.stop()
  self.VVXx8q(False)
  self.endCallback(res)
 def VVXx8q(self, isAdd):
  lst = [CFG.subtDelay, CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextSize, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtShadowSize, CFG.subtVerticalPos]
  notifier = self.VV1s9l
  for item in lst:
   if isAdd:
    item.addNotifier(notifier, initial_call=False)
   else:
    try:
     item.removeNotifier(notifier)
    except:
     try:
      notifier in item.notifiers and item.notifiers.remove(notifier)
      notifier in item.notifiers_final and item.notifiers_final.remove(notifier)
     except Exception as e:
      pass
 def VVJViX(self):
  path = self.VVvJE6()
  if path:
   if fileExists(path):
    lines = FFW1ru(path)
    srt = delay = enc = ""
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : srtPath = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay   = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc   = line.split("=")[1].strip()
    if srtPath and fileExists(srtPath):
     subtList, err = self.VVdR75(srtPath, enc)
     if subtList:
      self.lastSubtEnc = enc
      self.subtList = subtList
      try:
       CFG.subtDelay.setValue("%.1f" % float(delay))
      except:
       pass
      return True
  return False
 def VVV4fq(self):
  bestSrt, bestRatio = CCxsSP.VVCZr1(self)
  if bestSrt and bestRatio > 40:
   subtList, err = self.VVdR75(bestSrt)
   if subtList:
    self.subtList = subtList
    return True
  return False
 def VV4yyl(self):
  VVlZjX = []
  if self.lastSubtFile:
   VVlZjX.append(("Settings"      , "set"  ))
   VVlZjX.append(("Change Encoding"    , "enc"  ))
   VVlZjX.append(("Disable Current Subtitle"  , "disab" ))
   VVlZjX.append(VVZYy7)
  VVlZjX.append(("Find all srt file"    , "findSrt" ))
  lst = CCxsSP.VVbsTk(self)
  if lst:
   VVlZjX.append(VVZYy7)
   for item in lst:
    fName = os.path.basename(item)
    if self.lastSubtFile == item:
     fName = FF0hQa(fName, VVeO4o)
    VVlZjX.append((fName, item))
  win = FFqaQ9(self, self.VVEm3y, VVlZjX=VVlZjX, width=1200, title="Subtitle Options")
  win.instance.move(ePoint(40, 40))
 def VVEm3y(self, item=None):
  if item:
   if item == "set":
    self["mySubtFr"].show()
    for i in range(3):
     FFxTkM(self["mySubt%d" % i], "#55000000")
    self.session.openWithCallback(self.VV9VsM, CCNRIn)
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile):
     FF1SeM(self, boundFunction(CCo0R4.VVeOSJ, self, self.lastSubtFile, self.VV1vgK, defEnc=self.lastSubtEnc, pos=1), title="Loading Codecs ...", clearMsg=False)
    else:
     FFLk1N(self, "SRT File error", 1000)
   elif item == "disab":
    path = self.VVvJE6()
    os.system(FFA9Vj("rm -f '%s'" % path))
    self.VVMQGc("noErr")
   elif item == "findSrt":
    CCxsSP.VVFsQr(self, self.VVtAN9, defSrt=self.lastSubtFile, pos=1)
   else:
    self.VVtAN9(item)
 def VV9VsM(self, res):
  self["mySubtFr"].hide()
  for i in range(3):
   FFxTkM(self["mySubt%d" % i], "#FF000000")
  if res:
   self.VV8uAt()
   self.VV1s9l()
 def VV1s9l(self, configElement=None):
  fnt = CFG.subtTextFont.getValue()
  if not fnt in FFZVCr():
   fnt = VVmpyI
  lineH = 0
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FF3XWe(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    inst.setHAlign(int(CFG.subtTextAlign.getValue()))
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    inst.setNoWrap(True)
    lineH = FF4gcJ(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    inst.move(ePoint(int(inst.position().x()), int(lineH * i + 1)))
  except:
   pass
  try:
   height = lineH * 3 + 2
   if not self.defaultY:
    self.defaultY = int(getDesktop(0).size().height() - height - self.skinParam["marginTop"])
   if lineH:
    self.instance.resize(eSize(*(int(self.instance.size().width()), height)))
   y = int(self.defaultY + CFG.subtVerticalPos.getValue())
   y = min(y, getDesktop(0).size().height() - height - 5)
   self.instance.move(ePoint(int(self.instance.position().x()), int(y)))
   inst = self["myInfoFrame"].instance
   inst.move(ePoint(int(inst.position().x()), 2))
   inst = self["myInfoBody"].instance
   inst.move(ePoint(int(inst.position().x()), 4))
  except:
   pass
 def VVtAN9(self, path, enc=None):
  self.timerUpdate.stop()
  subtList, err = self.VVdR75(path, enc)
  if err    : FFLk1N(self, err, 2000)
  elif not subtList : FFLk1N(self, "Invalid SRT file", 2000)
  else    :
   self.subtList  = subtList
   self.lastSubtInfo = ""
   self.lastSubtEnc = ""
   self.currentIndex = 0
   CFG.subtDelay.setValue("0.0")
   for i in range(3):
    FF3XWe(self["mySubt%d" % i], "#ffffff")
    self["mySubt%d" % i].setText("")
   FFLk1N(self, "Subtitle started", 1000, isGrn=True)
  self.timerUpdate.start(500, False)
 def VV1vgK(self, item=None):
  if item:
   self.VVtAN9(self.lastSubtFile, item)
 @staticmethod
 def VVbsTk(SELF):
  fPath, fDir, fName = CCs7ea.VVhTh0(SELF)
  if pathExists(fDir):
   files = iGlob("%s*.srt" % fDir)
   if files:
    return files
  return []
 @staticmethod
 def VVCZr1(SELF):
  bestSrt = ""
  bestRatio = 0
  fPath, fDir, fName = CCs7ea.VVhTh0(SELF)
  if fName:
   movName = os.path.splitext(fName)[0].lower()
   files = CCxsSP.VVbsTk(SELF)
   for path in files:
    fName = os.path.basename(path)
    fName = os.path.splitext(fName)[0]
    ratio = CCwdjc.VVyvma(movName.lower(), fName.lower())
    if ratio > bestRatio:
     bestRatio = ratio
     bestSrt = path
  return bestSrt, bestRatio
 def VVkIZC(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVdR75(self, path, enc=None):
  if not fileExists(path):
   return [], "File not found"
  if (FFRl9s(path) > 1024 * 700):
   return [], "File too big"
  capNum = frmSec = toSec = bold = italic = under = 0
  color  = ""
  subtLines = []
  subtList = []
  capFound = False
  lines  = FFW1ru(path, encLst=enc if enc else None)
  for line in lines:
   line = line.strip()
   if line:
    if not capFound and line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVkIZC(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      subtLines.append((line.strip(), color, bold, italic, under))
   else:
    if (toSec - frmSec) > 0:
     subtList.append((capNum, frmSec, toSec, subtLines))
    capFound = False
    subtLines = []
    color = ""
    capNum = frmSec = toSec = bold = italic = under = 0
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VV8uAt()
  return subtList, ""
 def VV8uAt(self):
  path = self.VVvJE6()
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelay.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVvJE6(self):
  fPath, fDir, fName = CCs7ea.VVhTh0(self)
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7qBd(self)
   if iptvRef: fPath = "/tmp/" + chName
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CC6WQp.VVlfBB(self)
   if evName and evTime and evDur: fPath = "/tmp/" + evName
  if fPath: return fPath + ".ajp"
  else : return ""
 def VVdzOx(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCG8uj.VVNK0R(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CC6WQp.VVlfBB(self)
   if evTime and evDur:
    posVal = iTime() - evTime
  self.VVl0Te(posVal)
  if self.currentIndex == -2:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[self.currentIndex]
   if not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    for i in range(3):
     FF3XWe(self["mySubt%d" % i], "#ffffff")
     self["mySubt%d" % i].setText("")
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
     txtDur = int(toSec * 1000 - frmSec * 1000)
     if txtDur > 0:
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        line = line.replace(u"\u202A", "")
        line = line.replace(u"\u202B", "")
        line = line.replace(u"\u202C", "")
        line = str(line)
        if newColor:
         FF3XWe(self["mySubt%d" % ndx], newColor)
        self["mySubt%d" % ndx].setText(line)
      self.timerEndText.start(txtDur, True)
 def VVl0Te(self, posVal):
  if posVal > 0:
   delay = float(CFG.subtDelay.getValue())
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     self.currentIndex = ndx
     return
  self.currentIndex = -2
 def VVVCIN(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
 @staticmethod
 def VVFsQr(SELF, cbFnc, defSrt="", pos=0):
  FF1SeM(SELF, boundFunction(CCxsSP.VVNcef, SELF, cbFnc, defSrt, pos), title="Searching for srt files", clearMsg=False)
 @staticmethod
 def VVNcef(SELF, cbFnc, defSrt="", pos=0):
  FFLk1N(SELF)
  lines = FFfDK7('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFVC1u(1)))
  if lines:
   lines.sort()
   VVlZjX = []
   for item in lines:
    VVlZjX.append(((VVeO4o if defSrt == item else "") + item, item))
   VVG5AR = ("Show Full Path", CCxsSP.VVD6qF)
   win = FFqaQ9(SELF, boundFunction(CCxsSP.VVIUYk, cbFnc), title="Subtitle Files", VVlZjX=VVlZjX, width=1200, height=500 if pos == 1 else 900, VVG5AR=VVG5AR)
   if pos == 1:
    win.instance.move(ePoint(40, 40))
  else:
   FFLk1N(SELF, "No srt files found !", 2000)
 @staticmethod
 def VVD6qF(VV2FRKObj, path):
  FFn7o1(VV2FRKObj, path, title="Full Path")
 @staticmethod
 def VVIUYk(cbFnc, item):
  if item:
   cbFnc(item)
 @staticmethod
 def VVtGwZ():
  c = s = m = h = 0
  with open(VVNnjH + "AJPanel_test.srt", "w") as f:
   for i in range(1, 5401):
    s += 2
    if s >= 60:
     s = 0
     m += 1
     if m >= 60:
      m = 0
      h += 1
    if i < 6:
     txt  = '<font color="#ffff00">Created by AJPanel</font>\n'
     txt += '<font color="#00ffff">Testing Subtitle Files</font>\n'
     txt += '<font color="#00ff00">Line - %d</font>\n\n' % i
    else:
     txt = '<font color="#ffffbb">Subtitle Line - %d</font>\n\n' % i
    f.write("%d\n" % i)
    f.write("%02d:%02d:%02d,001 --> %02d:%02d:%02d,001\n" % (h, m, s, h, m, s+1))
    f.write(txt)
class CCNRIn(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FF8X8q(VVyKke, 600, 600, 40, 30, 10, "#11331010", "#11442020", 30, barHeight=40)
  self.session  = session
  self.Title   = "Subtitle Settings"
  FFNPyH(self, title=self.Title)
  FFkV23(self["keyRed"] , "Exit")
  FFkV23(self["keyGreen"] , "Save")
  FFkV23(self["keyYellow"], "Reset")
  self.confList = []
  self.confList.append(getConfigListEntry("Delay (current movie)" , CFG.subtDelay   ))
  self.confList.append(getConfigListEntry(VV9gSb *2     ,       ))
  self.confList.append(getConfigListEntry("Text Color"   , CFG.subtTextFg  ))
  self.confList.append(getConfigListEntry("Text Font"    , CFG.subtTextFont  ))
  self.confList.append(getConfigListEntry("Text Size"    , CFG.subtTextSize  ))
  self.confList.append(getConfigListEntry("Alignment"    , CFG.subtTextAlign  ))
  self.confList.append(getConfigListEntry("Shadow Color"   , CFG.subtShadowColor ))
  self.confList.append(getConfigListEntry("Shadow Size"   , CFG.subtShadowSize ))
  self.confList.append(getConfigListEntry(VV9gSb *2     ,       ))
  self.confList.append(getConfigListEntry("Vertical Pos"   , CFG.subtVerticalPos ))
  ConfigListScreen.__init__(self, self.confList, session)
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVv8JR  ,
   "green"   : self.VVZ4zQ   ,
   "yellow"  : boundFunction(FFixrz, self, self.VVLHJq, "Reset Subtitle Settings to default ?", title="Subtitle Settings"),
   "cancel"  : self.VVv8JR
  }, -1)
  self.onShown.append(self.VVYZus)
 def VVYZus(self):
  self.onShown.remove(self.VVYZus)
  FFhGNA(self["config"])
  FFwAWu(self, self["config"])
  FFZH71(self)
  self.instance.move(ePoint(40, 40))
 def VVv8JR(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFixrz(self, self.VVZ4zQ, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVZ4zQ(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  configfile.save()
  self.close(True)
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close(False)
 def VVLHJq(self):
  CFG.subtDelay.setValue("0.0")
  CFG.subtTextFg.setValue("srt")
  CFG.subtTextFont.setValue(VVmpyI)
  CFG.subtTextSize.setValue(50)
  CFG.subtTextAlign.setValue("1")
  CFG.subtShadowColor.setValue("#000080")
  CFG.subtShadowSize.setValue(5)
  CFG.subtVerticalPos.setValue(0)
  self.VVZ4zQ()
class CCmUeJ(ScrollLabel):
 def __init__(self, parentSELF, text="", VVjLg0=True):
  ScrollLabel.__init__(self, text)
  self.VVjLg0   = VVjLg0
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VVxxDd  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVbh3O    = None
  self.parentW    = None
  self.parentH    = None
  self.firstTime    = True
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close     ,
   "cancel"  : parentSELF.close     ,
   "red"   : self.VVEgnY     ,
   "green"   : self.VVkXRO    ,
   "yellow"  : self.VVgEc0    ,
   "blue"   : self.VV8tt7    ,
   "up"   : self.pageUp      ,
   "down"   : self.pageDown      ,
   "left"   : self.pageUp      ,
   "right"   : self.pageDown      ,
   "last"   : boundFunction(self.VVngyj, 0) ,
   "next"   : boundFunction(self.VVngyj, 2) ,
   "0"    : boundFunction(self.VVngyj, 1) ,
   "pageUp"  : self.VVyy9e      ,
   "chanUp"  : self.VVyy9e      ,
   "pageDown"  : self.VVc8ra      ,
   "chanDown"  : self.VVc8ra
  }, -1)
 def VVBS02(self, isResizable=True, VVlwD9=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FFZH71(self.parentSELF, True)
  self.isResizable = isResizable
  if VVlwD9:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVbh3O  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFxTkM(self, color)
 def FFxTkMColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  lineheight  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  lines   = int(self.long_text.size().height() / lineheight)
  margin   = int(lineheight / 6)
  self.pageHeight = int(lines * lineheight)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  self.setText(self.message)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVxxDd - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VV2Oh6()
 def pageUp(self):
  if self.VVxxDd > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVxxDd > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVyy9e(self):
  self.setPos(0)
 def VVc8ra(self):
  self.setPos(self.VVxxDd-self.pageHeight)
 def VVWbEI(self):
  return self.VVxxDd <= self.pageHeight or self.curPos == self.VVxxDd - self.pageHeight
 def getText(self):
  return self.message
 def VV2Oh6(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVxxDd, 3))
   start = int((100 - vis) * self.curPos / (self.VVxxDd - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVuKKh=VV0Sy0):
  old_VVWbEI = self.VVWbEI()
  self.message = str(text)
  if self.pageHeight:
   self.long_text.setText(self.message)
   self.VVxxDd = self.long_text.calculateSize().height()
   if self.VVjLg0 and self.VVxxDd > self.pageHeight:
    self.scrollbar.show()
    self.VV2Oh6()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVxxDd))
   if   VVuKKh == VVKyDE: self.setPos(0)
   elif VVuKKh == VVRjSm : self.VVc8ra()
   elif old_VVWbEI    : self.VVc8ra()
   if self.firstTime and len(self.message) > 0:
    self.firstTime = False
    self.setText(self.message, VVuKKh=VVuKKh)
 def appendText(self, text, VVuKKh=VVRjSm):
  self.setText(self.message + str(text), VVuKKh=VVuKKh)
 def VVgEc0(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVomgZ(size)
 def VV8tt7(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVomgZ(size)
 def VVkXRO(self):
  self.VVomgZ(self.VVbh3O)
 def VVomgZ(self, VVbh3O):
  self.long_text.setFont(gFont(self.fontFamily, VVbh3O))
  self.setText(self.message, VVuKKh=VV0Sy0)
  self.VVmP3I(calledFromFontSizer=True)
 def VVngyj(self, align):
  self.long_text.setHAlign(align)
 def VVEgnY(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FFRZql(expPath), self.textOutFile, FFdfSu())
    with open(outF, "w") as f:
     f.write(FFnTaU(self.message))
    FFkpHN(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FFcgS7(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVmP3I(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVxxDd > 0 and self.pageHeight > 0:
   if self.VVxxDd < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVxxDd
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
