import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from base64      import b64encode, b64decode
from sys      import version_info as pyVersion
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile
except: iMove = iCopyfile = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVx2ku   = "v8.3.0"
VV15XO    = "01-01-2023"
EASY_MODE    = 0
VVXgPr   = 0
VVbs7s   = 0
VVlZ1l  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVSVA6  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVCkxr    = "/media/usb/"
VV2lhT    = "/usr/share/enigma2/picon/"
VVNl6N = "/etc/enigma2/blacklist"
VVLOHV   = "/etc/enigma2/"
VV29es   = "AJPan"
VVVXZj  = "AUTO FIND"
VVegOc  = "Custom"
VVwd4B    = ""
VVm9KW = "Regular"
VVXkV7 = "Fixed"
VVlaqR  = "AJP_Main"
VVNAJh = "AJP_Terminal"
VVpOwn = "AJP_System"
VVPvAG  = VVm9KW
VVI8D8      = "-" * 80
VVswUs    = ("-" * 100, )
VVdxhd    = ""
VVeBpK   = " && echo 'Successful' || echo 'Failed!'"
VVLpMM    = []
VVRgbf  = "Cannot continue (No Enough Memory) !"
BAR_BUTTONS_COLORS  = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
VVpn8D  = False
VV5W0y  = False
VV2F6v     = 0
VVZCe3    = 1
VVZXjU    = 2
VVz79X   = 3
VVI2hq    = 4
VVrG8C    = 5
VVnxJO = 6
VVZBN4 = 7
VVbQmI  = 8
VVc4fk   = 9
VVQjBR  = 10
VVNy0r  = 11
VVDpax = 12
VV8C6U    = 13
VViJhZ   = 14
VV2Qvp   = 15
VVpl04    = 16
VV4Vk8    = 17
VVYP3F  = 18
VVDCZ9    = 19
VVKznu   = 0
VVXinG   = 1
VVnJeb   = 2
def FF6b3q():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VVPvAG
  if VVlaqR in lst and CFG.fontPathMain.getValue(): VVPvAG = VVlaqR
  else               : VVPvAG = VVm9KW
  return lst
 else:
  return [VVm9KW]
def FFr0nN(path, alias, scale=100, isRepl=0):
 try:
  addFont(path, alias, scale, isRepl)
  return True
 except:
  try:
   addFont(path, alias, scale, isRepl, 0)
   return True
  except:
   pass
 return False
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[("v", "Virtual Keyboard"),("s", "System Default")])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[("d", "Directory Up"),("e", "Exit File Manage")])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[("off", "Disable"),("lok", "Long-OK"),("lesc", "Long-Exit"),("lred", "Long-Red")])
CFG.screenshotFType    = ConfigSelection(default="jpg", choices=[("off", "Disable"),("jpg", "JPG"),("png", "PNG"),("bmp", "BMP")])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[("1", "1 (DVB Stream)"),("4097", "4097 (servicemp3)"),("5001", "5001 (GST Player)"),("5002", "5002 (Ext-3 EPlayer)"),("8192", "8192 (HDMI input)"),("8193", "8193 (eServiceUri)")])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVVXZj, visible_width=45)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.PIconsPath     = ConfigDirectory(default=VV2lhT, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVCkxr, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindMovie    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
CFG.transpColorMovies   = ConfigText(default="#11404040")
CFG.epgLangTitle    = ConfigText(default="")
CFG.epgLangDescr    = ConfigText(default="")
CFG.lastFtpLocalPath   = ConfigText(default="")
CFG.lastNetworkDevice   = ConfigInteger(default=0)
tmp = [("srt", "FROM SRT FILE"),("#00FFFF", "Aqua"),("#000000", "Black"),("#0000FF", "Blue"),("#FF00FF", "Fuchsia"),("#808080", "Gray"),("#008000", "Green"),("#00FF00", "Lime"),("#800000", "Maroon"),("#000080", "Navy"),("#808000", "Olive"),("#800080", "Purple"),("#FF0000", "Red"),("#C0C0C0", "Silver"),("#008080", "Teal"),("#FFFFFF", "White"),("#FFFF00", "Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVPvAG, choices=[(x,  x) for x in FF6b3q()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[("0", "Left"),("1", "Center"),("2", "Right")])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FFNfvo():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVC00F  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVQ8vN = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVC00F  : return 0
  elif VVQ8vN : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
COLOR_SCHEME_NUM = FFNfvo()
VVQasA = VVBh5X = VVAgOb = VV6yYu = VV9ZlA = VVPpUd = VVuULh = VVBZfW = VVlfrr = VVTMjp = VVzCWu = VVJ2KG = VV5cg1 = VVW6qu = VVHiet = VV0Duj = ""
def FFsbXJ()  : FF18Lp(FFUuOR())
def FFVzxQ()  : FF18Lp(FFqHso())
def FFenKH(tDict): FF18Lp(iDumps(tDict, indent=4, sort_keys=True))
def FFuKHY(*args): FF8xgR(True, True, *args)
def FF18Lp(*args) : FF8xgR(True , False , *args)
def FFn7p0(*args): FF8xgR(False, False, *args)
def FF8xgR(addSep=True, isArray=True, *args):
 if VVXgPr:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(str(key).ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FF1KPO(fnc):
 def VVzhJS(*args, **kwargs):
  t1 = iTime()
  fnc(*args, **kwargs)
  FF18Lp(">>>>>> Elapsed : %s sec\nargs = %s\nkwargs = %s" % (("%.6f" % (iTime() - t1)).rstrip("0"), args, kwargs))
 return VVzhJS
def FFXjg3(*args):
 if VVXgPr:
  path = "/tmp/ajp_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FFn7p0("Added to : %s" % path)
def FFqhEC(txt, isAppend=True, ignoreErr=False):
 if VVXgPr:
  tm = FFROHW()
  err = ""
  if not ignoreErr:
   err = FFqHso()
  fileName = "/tmp/ajp_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FF18Lp(err)
  FF18Lp("Output Log File : %s" % fileName)
def FFqHso():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFROHW()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFUuOR():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVvvRs = 0
def FFi1B1():
 global VVvvRs
 VVvvRs = iTime()
def FFs6lT(txt=""):
 FF18Lp(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VVvvRs)).rstrip("0"), txt))
VVLpMM = []
def FFUZsn(win):
 global VVLpMM
 if not win in VVLpMM:
  VVLpMM.append(win)
def FFJAbK(*args):
 global VVLpMM
 for win in VVLpMM:
  try:
   win.close()
  except:
   pass
 VVLpMM = []
def FFHx8g():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVDXCW = FFHx8g()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFjNHf()    : return PluginDescriptor(fnc=FF47BZ, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FFYM1c()      : return getDescriptor(FFqtEz , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFr1E4()     : return getDescriptor(FFc6sU  , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FF9rBu()  : return getDescriptor(FFdXxr, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFqBz6() : return getDescriptor(FFLXHS , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FFWWHJ()  : return getDescriptor(FFnyNQ , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FFNPk0()  : return getDescriptor(FFC8Fn  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FFTlse()    : return getDescriptor(FFsIyC, [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFr1E4() , FFYM1c() , FFjNHf() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FF9rBu())
  result.append(FFqBz6())
  result.append(FFWWHJ())
  result.append(FFNPk0())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFTlse())
 return result
def FF47BZ(reason, **kwargs):
 if reason == 0:
  FFr9u3()
  if "session" in kwargs:
   session = kwargs["session"]
   FF5ebk(session)
   CCdHvm(session)
def FFqtEz(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFc6sU, PLUGIN_NAME, 45)]
 else:
  return []
def FFc6sU(session, **kwargs):
 session.open(Main_Menu)
def FFdXxr(session, **kwargs):
 session.open(CCbI7Z)
def FFLXHS(session, **kwargs):
 session.open(CCgg3d)
def FFnyNQ(session, **kwargs):
 CCXzGX.VVmA7N(session, isFromExternal=True)
def FFC8Fn(session, **kwargs):
 FFQ9QB(session, reopen=True)
def FFsIyC(session, **kwargs):
 session.open(CCsydO, fncMode=CCsydO.VVPCQS)
def FF4EPr():
 FFcjbw(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FF9rBu(), FFqBz6(), FFWWHJ(), FFNPk0() ])
 FFcjbw(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFTlse() ])
def FFcjbw(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VVfvlq = None
def FFr9u3():
 try:
  global VVfvlq
  if VVfvlq is None:
   VVfvlq    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFb8t3
  ChannelContextMenu.FFfASh = FFfASh
 except:
  pass
def FFb8t3(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVfvlq(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , BF(SELF.FFfASh, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , BF(SELF.FFfASh, title1, csel, isFind=True))))
def FFfASh(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFIKk3(refCode)
 except:
  pass
 self.session.open(BF(CCMX60, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FF5ebk(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions["longOK"] = BF(FFWuu2, session, "lok")
 hk.actions["longCancel"]= BF(FFWuu2, session, "lesc")
 hk.actions["longRed"] = BF(FFWuu2, session, "lred")
 for k in (CCXLqT.VVTfqN, CCXLqT.VV6cOl, CCXLqT.VVpclZ):
  hk.actions[k] = BF(CCXLqT.VVYhxr, session, k)
def FFWuu2(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CCH0fw.VVfVjM:
    CCH0fw.VVfVjM.close()
   if not CCXzGX.VV2jNU:
    CCXzGX.VVmA7N(session, isFromExternal=True)
  except:
   pass
def FFxMsu(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FFwLhV(SELF, title="", addLabel=False, addScrollLabel=False, VVW1xb=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFwHka()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCHGCV(SELF)
 if VVW1xb:
  SELF["myMenu"] = MenuList(VVW1xb)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.VVi1M6 ,
   "cancel": SELF.close ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.close,
   "cancel": SELF.close,
   "red" : SELF.close
  }, -1)
def FFoiwi(SELF, tableObj, colNum=0, isMenu=False):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FFndrK, SELF, "0"),
  "1" : BF(FFndrK, SELF, "1"),
  "2" : BF(FFndrK, SELF, "2"),
  "3" : BF(FFndrK, SELF, "3"),
  "4" : BF(FFndrK, SELF, "4"),
  "5" : BF(FFndrK, SELF, "5"),
  "6" : BF(FFndrK, SELF, "6"),
  "7" : BF(FFndrK, SELF, "7"),
  "8" : BF(FFndrK, SELF, "8"),
  "9" : BF(FFndrK, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFhxs7, SELF, tableObj, colNum, isMenu))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFndrK(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VV0Duj:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VV0Duj + SELF.keyPressed + VVBh5X)
    txt = VVBh5X + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FF1ojr(SELF, txt)
def FFhxs7(SELF, tableObj, colNum, isMenu):
 FF1ojr(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    if isMenu: item = tableObj.list[i][colNum].strip()
    else  : item = tableObj.list[i][colNum + 1][7].strip()
    item = FFyZAn(item).encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     if isMenu: SELF.VVUaDE(i)
     else  : SELF.VV9fSx(i)
     break
 except:
  pass
def FFwHka():
 return ("  %s" % VVdxhd)
def FFxDER(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFyZAn(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFVPH4(color):
 return parseColor(color).argb()
def FFLsU4(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FF0e9t(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FF2dGH(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFfLXZ(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VV0Duj)
 else:
  return ""
def FF6CJ2(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVI8D8, word, VVI8D8, VV0Duj)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVI8D8, word, VVI8D8)
def FFY7FT(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VV0Duj
def FFuYac(color):
 if color: return "echo -e '%s' %s;" % (VVI8D8, FFfLXZ(VVI8D8, VVzCWu))
 else : return "echo -e '%s';" % VVI8D8
def FFh5T1(title, color):
 title = "%s\n%s\n%s\n" % (VVI8D8, title, VVI8D8)
 return FFY7FT(title, color)
def FFKauM(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FF81Cg(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFWlvR(callBackFunction):
 tCons = CCXype()
 tCons.ePopen("echo", BF(FFRGgx, callBackFunction))
def FFRGgx(callBackFunction, result, retval):
 callBackFunction()
def FF7Xva(SELF, fnc, title="Processing ...", clearMsg=True):
 FF1ojr(SELF, title)
 tCons = CCXype()
 tCons.ePopen("echo", BF(FFSHtr, SELF, fnc, clearMsg))
def FFSHtr(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FF1ojr(SELF)
def FFuVMf(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVRgbf
  else       : return ""
def FF94gP(cmd):
 txt = FFuVMf(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFyJfo(cmd):
 lines = FF94gP(cmd)
 if lines: return lines[0]
 else : return ""
def FF1WOg(SELF, cmd):
 lines = FF94gP(cmd)
 VVuV68 = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVuV68.append((key, val))
  elif line:
   VVuV68.append((line, ""))
 if VVuV68:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFEM8S(SELF, None, header=header, VV6fdw=VVuV68, VVHqY6=widths, VVJmZ8=28)
 else:
  FFYpRN(SELF, cmd)
def FFYpRN(    SELF, cmd, **kwargs): SELF.session.open(CCPdSb, VVKINn=cmd, VVM4Ot=True, VVpV1e=VVXinG, **kwargs)
def FFhS2c(  SELF, cmd, **kwargs): SELF.session.open(CCPdSb, VVKINn=cmd, **kwargs)
def FFmzjA(   SELF, cmd, **kwargs): SELF.session.open(CCPdSb, VVKINn=cmd, VV4YEE=True, VVOEl1=True, VVpV1e=VVXinG, **kwargs)
def FFDbYu(  SELF, cmd, **kwargs): SELF.session.open(CCPdSb, VVKINn=cmd, VV4YEE=True, VVOEl1=True, VVpV1e=VVnJeb, **kwargs)
def FFsZIz(  SELF, cmd, **kwargs): SELF.session.open(CCPdSb, VVKINn=cmd, VVV4pF=True , **kwargs)
def FFgXLo(  session, cmd, **kwargs):      session.open(CCPdSb, VVKINn=cmd, VVV4pF=True , **kwargs)
def FFrytJ( SELF, cmd, **kwargs): SELF.session.open(CCPdSb, VVKINn=cmd, VV0auT=True   , **kwargs)
def FFNdGr( SELF, cmd, **kwargs): SELF.session.open(CCPdSb, VVKINn=cmd, VVWuBN=True  , **kwargs)
def FFQe93(cmd):
 return cmd + " > /dev/null 2>&1"
def FFHR0m(cmd):
 return cmd + " 2> /dev/null"
def FFyH5d():
 return " > /dev/null 2>&1"
def FFeWq1(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFiZoB(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFvwHi():
 cmd = "if [ -f /etc/apt/apt.conf ]; then echo dpkg; else if [ -f /etc/opkg/opkg.conf ]; then echo opkg; else if which dpkg; then echo dpkg; else if which opkg; then echo opkg; else if which ipkg; then echo ipkg; else echo ''; fi; fi; fi; fi; fi"
 return FFyJfo(cmd)
VVJknE     = 0
VVwD6Q      = 1
VVcsXy   = 2
VV1xDE      = 3
VVUWWs      = 4
VVXp0Z     = 5
VVkKCu     = 6
VVzgm4 = 7
VVDBBb = 8
VVd1HZ = 9
VVVG8q  = 10
VVdbf3     = 11
VVYyAT  = 12
VV0w22  = 13
def FFrkEH(parmNum, grepTxt):
 if   parmNum == VVJknE  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVwD6Q   : param = ["list"   , "apt list" ]
 elif parmNum == VVcsXy: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFvwHi()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFkjia(parmNum, package):
 if   parmNum == VV1xDE      : param = ["info"      , "apt show"         ]
 elif parmNum == VVUWWs      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVXp0Z     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVkKCu     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVzgm4 : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVDBBb : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VVd1HZ : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVVG8q  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVdbf3     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVYyAT  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VV0w22  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFvwHi()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFwwi6():
 result = FFyJfo("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFkjia(VVkKCu , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFQe93("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFQe93("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFfLXZ(failed1, VVzCWu))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFfLXZ(failed2, VVzCWu))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFfLXZ(failed3, VVAgOb))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFsl4Z(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFkjia(VVkKCu , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFQe93("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFfLXZ(failed1, VVzCWu))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFfLXZ(failed2, VVAgOb))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFqXAw(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCAUx4.VV0czc()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FFFfvw(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFqXAw(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFxRdc(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFPYZx(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFqXAw(path, maxSize=maxSize, encLst=encLst)
  if lines: FFyv2f(SELF, lines, title=title, VVpV1e=VVXinG, width=1600, height=1000, titleFontSize=30)
  else : FFRjyo(SELF, path, title=title)
 else:
  FFRYkM(SELF, path, title)
def FFsiZl(SELF, fName, title):
 path = VV9dcF + fName
 if fileExists(path):
  txt = FFqXAw(path)
  txt = txt.replace("#W#", VV0Duj)
  txt = txt.replace("#Y#", VVJ2KG)
  txt = txt.replace("#G#", VVBh5X)
  txt = txt.replace("#C#", VV5cg1)
  txt = txt.replace("#P#", VV9ZlA)
  FFyv2f(SELF, txt, title=title)
 else:
  FFRYkM(SELF, path, title)
def FFMVgU(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFSahc(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFnWu0(parent)
 else    : return FFddC4(parent)
def FFmKBR(path):
 return os.path.basename(os.path.normpath(path))
def FFPYZx(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFioKk(path):
 size = 0
 for Dir, dirs, files in os.walk(path):
  for f in files:
   fp = os.path.join(Dir, f)
   try:
    size += os.path.getsize(fp)
   except:
    pass
 return size
def FFGWxS(path):
 try:
  os.remove(path)
 except:
  pass
def FFbwkF(path):
 return os.system(FFQe93("chattr -AacDdijsStu '%s'" % path) + ";" + FFQe93("rm -fr '%s'" % path))
def FFnWu0(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFddC4(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFBr5Z():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVlZ1l)
 paths.append(VVlZ1l.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFMVgU(ba)
 for p in list:
  p = ba + p + VVlZ1l
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VV29es, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVlZ1l, VV29es , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VV0Kjx, VV9dcF = FFBr5Z()
def FFtQST():
 def VVtSSo(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VVqCY4   = VVtSSo(CFG.backupPath, CCYJYU.VVNez3())
 VVGiin   = VVtSSo(CFG.downloadedPackagesPath, t)
 VVkYuU  = VVtSSo(CFG.exportedTablesPath, t)
 VVmc5V  = VVtSSo(CFG.exportedPIconsPath, t)
 VVcJaj   = VVtSSo(CFG.packageOutputPath, t)
 global VVCkxr
 VVCkxr = FFnWu0(CFG.backupPath.getValue())
 if VVqCY4 or VVcJaj or VVGiin or VVkYuU or VVmc5V or oldMovieDownloadPath:
  configfile.save()
 return VVqCY4, VVcJaj, VVGiin, VVkYuU, VVmc5V, oldMovieDownloadPath
def FFojdy(path):
 path = FFddC4(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFP17E(SELF, pathList, tarFileName, addTimeStamp=True):
 VV6fdw = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VV6fdw.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VV6fdw.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VV6fdw.append(path)
 if not VV6fdw:
  FFa349(SELF, "Files not found!")
 elif not pathExists(VVCkxr):
  FFa349(SELF, "Path not found!\n\n%s" % VVCkxr)
 else:
  VVEuWS = FFnWu0(VVCkxr)
  tarFileName = "%s%s" % (VVEuWS, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFJCyp())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VV6fdw:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVI8D8
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFfLXZ(tarFileName, VVlfrr))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFfLXZ(failed, VVlfrr))
  cmd += "fi;"
  cmd +=  sep
  FFhS2c(SELF, cmd)
def FF8TfI(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FF3Gwy(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FF3Gwy(SELF["keyInfo"], "info")
def FF3Gwy(barObj, fName):
 path = "%s%s%s" % (VV9dcF, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFvD21(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFKJmy(satNum)
  return satName
def FFKJmy(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFP3va(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFvD21(val)
  else  : sat = FFKJmy(val)
 return sat
def FFuzCW(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFvD21(num)
 except:
  pass
 return sat
def FFpXIw(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFSXdj(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFxRrg(info, iServiceInformation.sServiceref)
   prov = FFxRrg(info, iServiceInformation.sProvider)
   state = str(FFxRrg(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFDOE0(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFTSbj(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFxRrg(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFxv8F(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFIKk3(refCode):
 info = FF08G0(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFn1G7(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FFjOJJ(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FF08G0(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVjSyF = eServiceCenter.getInstance()
  if VVjSyF:
   info = VVjSyF.info(service)
 return info
def FFqi6V(SELF, refCode, VVEPKV=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFzHPJ(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVEPKV:
   FFvuNg(SELF, isFromSession)
 try:
  VVPWYL = InfoBar.instance
  if VVPWYL:
   VVEmtn = VVPWYL.servicelist
   if VVEmtn:
    servRef = eServiceReference(refCode)
    VVEmtn.saveChannel(servRef)
 except:
  pass
def FFzHPJ(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCrYKH()
    if pr.VVBesS(refCode, chName, decodedUrl, iptvRef):
     pr.VVPczX(SELF, isFromSession)
def FFDOE0(refCode):
 return True if iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE) else False
def FFTxso(ref):
 if "chcm=" in ref.lower(): return False
 else      : return True if iSearch(r"https?([:]|%3a)\/\/(127.0.0.\d|0.0.0.0|192.168.\d.\d|localhost).+", ref, IGNORECASE) else False
def FF6GnB(url): return FFyDhZ(url) or FF50pb(url)
def FFyDhZ(url)  : return any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FF50pb(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FFTSbj(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFdOos(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFdOos(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFgbDs(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFe9aJ(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FF5dpp(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFM2at(txt):
 try:
  return FFe9aJ(FF5dpp(txt)) == txt
 except:
  return False
def FFKZAp(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FFnWu0(newPath), patt))
def FFvuNg(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: CCXzGX.VVmA7N(session, isFromExternal=isFromSession)
 else      : FFQ9QB(session, reopen=True)
def FFQ9QB(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FFQ9QB, session), CCH0fw)
  except:
   try:
    FFsXs9(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFX2Cs(refCode):
 tp = CCEpHi()
 if tp.VVO8kZ(refCode) : return True
 else        : return False
def FFV9Z7(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFNh5K(True)
     return True
 return False
def FFNh5K(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FFO2NI()
def FFO2NI():
 VVPWYL = InfoBar.instance
 if VVPWYL:
  VVEmtn = VVPWYL.servicelist
  if VVEmtn:
   VVEmtn.setMode()
def FFqMsP(root):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVjSyF = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVjSyF.info(service)
    lst.append((service.toString(), info.getName(service)))
 except:
  pass
 return lst
def FFsOE4():
 VV8J1C = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVwf7y = list(VV8J1C)
 return VVwf7y, VV8J1C
def FFppy1():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFDLHE(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FFXtJp(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFIDlG():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFJCyp():
 return FFIDlG().replace(" ", "_").replace("-", "").replace(":", "")
def FFCiZs(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFROHW():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFjmFi(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCgg3d.VVHvuJ(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCgg3d.VV9jHr(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFQe93("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFvBVl(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FFmJCK(num):
 return "s" if num > 1 else ""
def FFoooc(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFfFjr(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFT3sR(a, b):
 return (a > b) - (a < b)
def FF2f45(a, b):
 def VV2BIO(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VV2BIO(a)
 b = VV2BIO(b)
 return (a > b) - (a < b)
def FFKEcC(mycmp):
 class CCJktz(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CCJktz
def FF5nWa(SELF, message, title="", VVnRGv=None):
 SELF.session.openWithCallback(VVnRGv, CCzRkq, title=title, message=message, VVttKB=True)
def FFyv2f(SELF, message, title="", VVpV1e=VVXinG, VVnRGv=None, **kwargs):
 SELF.session.openWithCallback(VVnRGv, CCzRkq, title=title, message=message, VVpV1e=VVpV1e, **kwargs)
def FFa349(SELF, message, title="")  : FFsXs9(SELF.session, message, title)
def FFRYkM(SELF, path, title="") : FFsXs9(SELF.session, "File not found !\n\n%s" % path, title)
def FFRjyo(SELF, path, title="") : FFsXs9(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFPsN3(SELF, title="")  : FFsXs9(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFsXs9(session, message, title="") : session.open(BF(CCIHiL, title=title, message=message))
def FFsShb(SELF, VVnRGv, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVnRGv, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVnRGv, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFa349(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FF8XzP(SELF, callBack_Yes, VVusVD, callBack_No=None, title="", VVJRkN=False, VVMmvg=True, isFromExternal=False):
 session = SELF if isFromExternal else SELF.session
 return session.openWithCallback(BF(FFknt9, callBack_Yes, callBack_No)
         , BF(CCS94s, title=title, VVusVD=VVusVD, VVMmvg=VVMmvg, VVJRkN=VVJRkN))
def FFknt9(callBack_Yes, callBack_No, FF8XzPed):
 if FF8XzPed : callBack_Yes()
 elif callBack_No: callBack_No()
def FF1ojr(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FF0e9t(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFLStR(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFRNqp(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VV9NJ2 = eTimer()
def FFLStR(SELF, milliSeconds=1000):
 SELF.onClose.append(BF(FF6seR, SELF))
 fnc = BF(FF6seR, SELF)
 try:
  t = VV9NJ2.timeout.connect(fnc)
 except:
  VV9NJ2.callback.append(fnc)
 VV9NJ2.start(milliSeconds, 1)
def FF6seR(SELF):
 VV9NJ2.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFEM8S(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCZovh, **kwargs))
  else   : win = SELF.session.open(BF(CCZovh, **kwargs))
  FFUZsn(win)
  return win
 except:
  return None
def FFLFXy(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CCQ6xF, **kwargs))
 FFUZsn(win)
 return win
def FFzfpO(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FFr9gS(SELF, **kwargs):
 SELF.session.open(CCsydO, **kwargs)
def FFvDt2(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFTlDF(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FFwpS7(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVPvAG, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFVUwm(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFwpS7(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize = winInst.size()
 FFOMWW(SELF, winSize.width(), winSize.height())
def FFOMWW(SELF, w, h):
 fSize = SELF["myInfoFrame"].instance.size()
 bSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((w - fSize.width()) // 2, (h - fSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((w - bSize.width()) // 2, (h - bSize.height()) // 2))
def FFcmgn():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFRuMz(VVJmZ8):
 screenSize  = FFcmgn()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVJmZ8)
 return bodyFontSize
def FFbSpu(VVJmZ8, extraSpace):
 font = gFont(VVPvAG, VVJmZ8)
 VVJ5AH = fontRenderClass.getInstance().getLineHeight(font) or (VVJmZ8 * 1.25)
 return int(VVJ5AH + VVJ5AH * extraSpace)
def FFXh6Y(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, vSliderW=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True, menuLabel=0):
 screenSize = FFcmgn()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 extraPar  = None
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 vSliderW  = int(ratioW  * vSliderW)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVPvAG, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFbSpu(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0" size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb"  %s />' % (width, titleH, titleColor, VVPvAG, titleFontSize, alignLeftCenter)
 if winType in (VV2F6v, VVZCe3):
  if winType == VVZCe3 : menuName = "config"
  else      : menuName = "myMenu"
  menuW = bodyW - int(bodyW * menuLabel / 100.0) - marginLeft if menuLabel else bodyW
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, menuW, bodyH, bodyColor, bodyLineH)
  if menuLabel:
   param = 'backgroundColor="%s" foregroundColor="#ffffff" %s' % (bodyColor, bodyFontStr)
   x, w, gap = menuW + marginLeft * 2, bodyW - menuW - marginLeft, int(marginLeft / 2.0)
   tmp += '<widget name="myLabelFrm" position="%d,%d" size="%d,%d" zPosition="3" %s />' % (x - gap, bodyTop, w + gap * 2, bodyH, param)
   tmp += '<widget name="myLabelTit" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + 10, w, titleH, alignCenter, param)
   tmp += '<widget name="myLabelTxt" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + titleH + gap , w, bodyH - titleH - gap * 2, alignLeftCenter, param)
 elif winType == VVYP3F:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == VV4Vk8:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VVPvAG, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d"    position="1,%d" size="%d,%d" zPosition="6" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VV8C6U:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FF5nWaL = b2Left2 + timeW + marginLeft
  FF5nWaW = b2Left3 - marginLeft - FF5nWaL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FF5nWaL , b2Top, FF5nWaW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VViJhZ:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVI2hq:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVZXjU:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVz79X:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVPvAG, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVPvAG, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVQjBR:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVPvAG, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VV2Qvp:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVPvAG, fontH, alignCenter)
 elif winType in (VVNy0r, VVDpax):
  if winType == VVNy0r: totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  else         : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + 2
  boxW = int((width - vSliderW)  / totCols)
  boxH = int((height - barHeight - boxT) / totRows)
  picH = int(boxH * picR)
  lblH = int(boxH * lblR) - 2
  lblT = boxT + picH + 2
  lblFont = int(lblH * 0.65)
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVNy0r:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h, fg, bg[i]  , VVPvAG, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h, fg, bg[i+3], VVPvAG, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VVPvAG, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VVPvAG, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h , fg, bg, VVPvAG, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h , fg, bg, VVPvAG, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00FFFF00"/>' % (0, boxT, boxW, boxH)
  extraPar = (boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2, transpBG)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVPvAG, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVpl04:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVrG8C:
  tmp += '<widget name="myPic" position="0,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (bodyTop, bodyW+3, bodyH+3)
 else:
  if   winType == VVZBN4 : align = alignLeftCenter
  elif winType == VVnxJO : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVc4fk:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVPvAG
  if usefixedFont and winType == VVnxJO:
   fLst = FF6b3q()
   if   VVNAJh in fLst and CFG.fontPathTerm.getValue(): fontName = VVNAJh
   elif VVXkV7 in fLst         : fontName = VVXkV7
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVJmZ8 = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVPvAG, VVJmZ8, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVPvAG, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, BAR_BUTTONS_COLORS[i], VVPvAG, barFont, alignCenter)
   left += btnW + gap
 if vSliderW:
  par = 'position="0,0" size="20,20"'
  tmp += '<widget name="mySbFrm" zPosition="13" %s />' % par
  tmp += '<widget name="mySbBak" zPosition="14" %s />' % par
  tmp += '<widget name="mySbSld" zPosition="15" %s />' % par
 if winType == VVnxJO:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, BAR_BUTTONS_COLORS[i], VVPvAG, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap, "extraPar":extraPar}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFXh6Y(VV2F6v, 800, 950, 40, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VVRzIU = ""
  self.themsList  = []
  self.Title   = "%s - %s" % (PLUGIN_NAME, VVx2ku)
  VVW1xb = []
  if VVbs7s:
   VVW1xb.append(("-- MY TEST --", "myTest" ))
  VVW1xb.append(("File Manager"  , "fMan" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("IPTV"    , "iptv" ))
  VVW1xb.append(("Movies Browser" , "movie" ))
  VVW1xb.append(("Services/Channels", "chan" ))
  VVW1xb.append(("PIcons"   , "picon" ))
  VVW1xb.append(("EPG"    , "epg"  ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Terminal"   , "term" ))
  VVW1xb.append(("SoftCam"   , "soft" ))
  VVW1xb.append(("Plugins"   , "plug" ))
  VVW1xb.append(("Backup & Restore" , "bakup" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Date/Time"  , "date" ))
  VVW1xb.append(("Network"   , "net"  ))
  for ndx, item in enumerate(VVW1xb):
   item = list(item)
   item[0] = "  %s" % item[0]
   VVW1xb[ndx] = tuple(item)
  FFwLhV(self, title=self.Title, VVW1xb=VVW1xb)
  FFxDER(self["keyRed"] , "Exit")
  FFxDER(self["keyGreen"] , "Settings")
  FFxDER(self["keyYellow"], "Dev. Info.")
  FFxDER(self["keyBlue"] , "Color/Font")
  self["myActionMap"].actions.update({
   "red" : self.close       ,
   "green" : self.VVQBIT      ,
   "yellow": self.VV3kkI      ,
   "blue" : self.VVw2U9     ,
   "info" : BF(FF7Xva, self, self.VVuVA1) ,
   "text" : self.VVnv9R      ,
   "menu" : self.VVcyBa    ,
   "0"  : BF(self.VVqb4W, 0)   ,
   "1"  : BF(self.VVZKlw, "fMan")   ,
   "2"  : BF(self.VVZKlw, "iptv")   ,
   "3"  : BF(self.VVZKlw, "movie")   ,
   "4"  : BF(self.VVZKlw, "chan")   ,
   "5"  : BF(self.VVZKlw, "picon")   ,
   "6"  : BF(self.VVZKlw, "epg")   ,
   "7"  : BF(self.VVZKlw, "term")   ,
   "8"  : BF(self.VVZKlw, "soft")   ,
   "9"  : BF(self.VVZKlw, "plug")   ,
   "last" : BF(self.VVZKlw, "bakup")   ,
   "next" : BF(self.VVZKlw, "date")
  })
  self.onShown.append(self.VVfcAc)
  self.onClose.append(self.onExit)
  global VVpn8D, VV5W0y
  VVpn8D = VV5W0y = False
 def VVi1M6(self):
  self.VVZKlw(self["myMenu"].l.getCurrentSelection()[1])
 def VVZKlw(self, item):
  if item is not None:
   for ndx, param in enumerate(self["myMenu"].list):
    if len(param) > 1 and param[1] == item:
     self["myMenu"].moveToIndex(ndx)
     break
   global VVdxhd
   VVdxhd = self["myMenu"].l.getCurrentSelection()[0].strip()
   if   item == "myTest" : self.VVUiE4()
   elif item == "fMan"  : self.session.open(CCbI7Z)
   elif item == "iptv"  : self.session.open(CCgg3d)
   elif item == "movie" : FF7Xva(self, BF(CCoeUI.VVZAbM, self))
   elif item == "chan"  : self.session.open(CCyEBX)
   elif item == "picon" : self.VV8PNf()
   elif item == "epg"  : self.session.open(CCos4Q)
   elif item == "term"  : self.session.open(CCDYaB)
   elif item == "soft"  : self.session.open(CCaICB)
   elif item == "plug"  : self.session.open(CCZSFD)
   elif item == "bakup" : self.session.open(CCaEH2)
   elif item == "date"  : self.session.open(CCWtyZ)
   elif item == "net"  : self.session.open(CCCRLh)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FFKauM(self["myMenu"])
  FFVUwm(self)
  FFvDt2(self)
  FF8TfI(self)
  VVqCY4, VVcJaj, VVGiin, VVkYuU, VVmc5V, oldMovieDownloadPath = FFtQST()
  if VVqCY4 or VVcJaj or VVGiin or VVkYuU or VVmc5V or oldMovieDownloadPath:
   VV5vDG = lambda path, subj: "%s:\n%s\n\n" % (subj, FFY7FT(path, VV6yYu)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VV5vDG(VVqCY4   , "Backup/Restore Path"    )
   txt += VV5vDG(VVcJaj  , "Created Package Files (IPK/DEB)" )
   txt += VV5vDG(VVGiin  , "Download Packages (from feeds)" )
   txt += VV5vDG(VVkYuU , "Exported Tables"     )
   txt += VV5vDG(VVmc5V , "Exported PIcons"     )
   txt += VV5vDG(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFyv2f(self, txt, title="Settings Paths")
  self.VVgWhe()
  if (EASY_MODE or VVXgPr or VVbs7s):
   FF0e9t(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FF1ojr(self, "Welcome", 300)
  FFWlvR(self.VV3Hqa)
 def VV3Hqa(self):
  if CFG.checkForUpdateAtStartup.getValue():
   curVer, webVer, url, isHigher, err = CCYJYU.VVd4TV()
   if webVer and isHigher:
    self["myTitle"].setText("  %s (v%s available)" % (self.Title, webVer))
 def onExit(self):
  os.system(FFQe93("rm /tmp/ajp_*"))
  global VVpn8D, VV5W0y
  VVpn8D = VV5W0y = False
 def VVqb4W(self, digit):
  self.VVRzIU += str(digit)
  ln = len(self.VVRzIU)
  global VVpn8D
  if ln == 4:
   if self.VVRzIU == "0" * ln:
    VVpn8D = True
    FF0e9t(self["myTitle"], "#11805040")
   else:
    self.VVRzIU = "x"
 def VVnv9R(self):
  self.VVRzIU += "t"
  if self.VVRzIU == "0" * 4 + "t" * 2:
   global VV5W0y
   VV5W0y = True
   FF0e9t(self["myTitle"], "#dd5588")
 def VV8PNf(self):
  found = False
  pPath = CCMxom.VVVqXw()
  if pathExists(pPath):
   for fName, fType in CCMxom.VVmE5k(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCMxom)
  else:
   VVW1xb = []
   VVW1xb.append(("PIcons Tools" , "CCMxom" ))
   VVW1xb.append(VVswUs)
   VVW1xb.append(CCMxom.VV06vI())
   VVW1xb.append(VVswUs)
   VVW1xb += CCMxom.VVIGZ4()
   FFLFXy(self, self.VVJGVc, VVW1xb=VVW1xb)
 def VVJGVc(self, item=None):
  if item:
   if   item == "CCMxom"   : self.session.open(CCMxom)
   elif item == "VVbEG8"  : CCMxom.VVbEG8(self)
   elif item == "VVmc5P"  : CCMxom.VVmc5P(self)
   elif item == "findPiconBrokenSymLinks" : CCMxom.VVvuHC(self, True)
   elif item == "FindAllBrokenSymLinks" : CCMxom.VVvuHC(self, False)
 def VVuVA1(self):
  changeLogFile = VV9dcF + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FFFfvw(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFY7FT("\n%s\n%s\n%s" % (VVI8D8, line, VVI8D8), VVzCWu, VV0Duj)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FFY7FT(line, VVBh5X, VV0Duj)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFyv2f(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVx2ku, PLUGIN_DESCRIPTION), VVJmZ8=28, width=1600, height=1000)
 def VVcyBa(self):
  VVW1xb = []
  VVW1xb.append(("%s Requirements" % PLUGIN_NAME, "libr"))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Keys Help"     , "hlp" ))
  FFLFXy(self, self.VVHzZw, VVW1xb=VVW1xb, width=650, title="Options")
 def VVHzZw(self, item=None):
  if item:
   if   item == "libr" : FF7Xva(self, BF(self.VVZ05j))
   elif item == "hlp" : FFsiZl(self, "_help_main", "Main Page (Keys Help)")
 def VVQBIT(self) : self.session.open(CCYJYU)
 def VV3kkI(self) : self.session.open(CCLeKE)
 def VVw2U9(self):
  title = "Colors and Fonts"
  c1, c2, c3, c4 = VVTMjp, VV6yYu, VVJ2KG, VVPpUd
  VVW1xb = []
  VVW1xb.append((c1 + "Change Title Colors"   , "title"  ))
  VVW1xb.append((c1 + "Change Menu Area Colors"  , "body"  ))
  VVW1xb.append((c1 + "Change Menu Pointer Colors" , "cursor"  ))
  VVW1xb.append((c1 + "Change Bottom Bar Colors" , "bar"   ))
  VVW1xb.append((c2 + "Reset Colors"    , "resetColor" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append((c3 + "Change %s Font" % PLUGIN_NAME, "mainFont" ))
  VVW1xb.append((c3 + "Change Termianl Font"   , "termFont" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append((c4 + "Change System Font"    , "sysFont"  ))
  FFLFXy(self, BF(self.VVxuwx, title), VVW1xb=VVW1xb, width=600, title=title)
 def VVxuwx(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VVJCUp()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVWSsj, tDict, item), CCN1iw, defFG=fg, defBG=bg)
   elif item == "resetColor" : FF8XzP(self, self.VVUHKI, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVp1j6(VVlaqR  )
   elif item == "termFont"  : self.VVp1j6(VVNAJh)
   elif item == "sysFont"  : self.VVp1j6(VVpOwn  )
 def VVZ05j(self):
  title = "%s requirements (for some features)" % PLUGIN_NAME
  VVuV68, pkgs = self.VVQRTd()
  VVsTsL = ("Install", BF(self.VVvjuI, title, pkgs)  , [])
  VVmmwr  = ("Update Sys. Packages", self.VVCcKz , [])
  header  = ("Library", "State", "Usage" )
  widths  = (20   , 25  , 55  )
  VVI7B0 = (LEFT  , CENTER , LEFT  )
  VVXOwS = FFEM8S(self, None, title=title, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=28, width=1350, VVsTsL=VVsTsL, VVmmwr=VVmmwr, VVKhj2="#00ffffaa", VVimZ8=1)
 def VVvjuI(self, Title, pkgs, VVXOwS, title, txt, colList):
  if "Not" in colList[1]:
   cbFnc = BF(self.VVfpCh, VVXOwS)
   item = colList[0]
   if   item == "requests" : CCTs8V.VVMo6T(self, cbFnc=cbFnc)
   elif item == "Imaging" : CCXLqT.VVqbOL(self, Title, False, cbFnc=cbFnc)
   elif item == "ar"  : FFsZIz(self, FFwwi6(), VVvcJy=cbFnc)
   elif item in pkgs  : FFsZIz(self, FFsl4Z(item, item, item.capitalize()), VVvcJy=cbFnc)
  else:
   FF1ojr(VVXOwS, "Already installed.", 700, isGrn=True)
 def VVCcKz(self, VVXOwS, title, txt, colList):
  CCZSFD.VVKUPH(self)
 def VVfpCh(self, VVXOwS):
  VVuV68, pkgs = self.VVQRTd()
  VVXOwS.VV8NVY(VVuV68[VVXOwS.VVRJth()])
 def VVQRTd(self):
  tDict = {}
  path = VV9dcF + "_sup_lib"
  if fileExists(path):
   for line in FFFfvw(path):
    lib, eq, txt = line.partition("=")
    tDict[lib] = txt
  def VV5vDG(lib, ok):
   txt = tDict.get(lib, "")
   if ok: return (lib, FFY7FT("Installed", VVlfrr), txt)
   else : return (lib, FFY7FT("Not installed", VVAgOb), txt)
  pkgs = ("xz", "zip", "unrar", "bzip2", "ffmpeg")
  VVuV68 = []
  VVuV68.append(VV5vDG("requests", CCTs8V.VVMo6T(self, install=False)))
  VVuV68.append(VV5vDG("Imaging" , CCXLqT.VVqbOL(self, "", False, install=False)))
  VVuV68.append(VV5vDG("ar"   , os.system("if [[ \"$(ar -V 2> /dev/null | grep 'GNU ar')\" ]]; then exit 1; else exit 0; fi")))
  for item in pkgs: VVuV68.append(VV5vDG(item, FFeWq1(item)))
  VVuV68.sort(key=lambda x: x[0].lower())
  return VVuV68, pkgs
 def VVMmSt(self):
  return VVCkxr + "ajpanel_colors"
 def VVJCUp(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVMmSt()
  if fileExists(p):
   txt = FFqXAw(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVWSsj(self, tDict, item, fg, bg):
  if fg:
   self.VVO1Ug(item, fg)
   self.VVs39E(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVA3PJ(tDict)
 def VVA3PJ(self, tDict):
   p = self.VVMmSt()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVO1Ug(self, item, fg):
  if   item == "title" : FFLsU4(self["myTitle"], fg)
  elif item == "body"  :
   FFLsU4(self["myMenu"], fg)
   FFLsU4(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   for item in ("myBar", "keyRed", "keyGreen", "keyYellow", "keyBlue"): FFLsU4(self[item], fg)
 def VVs39E(self, item, bg):
  if   item == "title" : FF0e9t(self["myTitle"], bg)
  elif item == "body"  :
   FF0e9t(self["myMenu"], bg)
   FF0e9t(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FF0e9t(self["myBar"], bg)
 def VVUHKI(self):
  os.system(FFQe93("rm %s" % self.VVMmSt()))
  self.close()
 def VVgWhe(self):
  tDict = self.VVJCUp()
  for item in ("title", "body", "cursor", "bar"):
   self.VV00vH(tDict, item)
 def VV00vH(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVO1Ug(name, fg)
  if bg: self.VVs39E(name, bg)
 def VVp1j6(self, which):
  if   which == VVlaqR  : rest, defFnt, title = False, CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif which == VVNAJh : rest, defFnt, title = False, CFG.fontPathTerm.getValue(), "Terminal "
  elif which == VVpOwn  : rest, defFnt, title = True , CFG.fontPathSys.getValue() , "System"
  CCowQI.VVDzgX(self, "Change %s Font" % title, defFnt, rest, BF(self.VVYpDh, which))
 def VVYpDh(self, which, path=None):
  if path:
   path = "" if path == "DEFAULT" else path
   if   which == VVlaqR  : FFxMsu(CFG.fontPathMain, path)
   elif which == VVNAJh: FFxMsu(CFG.fontPathTerm, path)
   elif which == VVpOwn  : FFxMsu(CFG.fontPathSys , path)
   err = Main_Menu.VVJLXo(which)
   if err          : FFa349(self, err, title=title)
   elif which == VVlaqR   : self.close()
   elif which == VVNAJh  : FF1ojr(self, "Terminal font applied", 1500, isGrn=True)
   elif which == VVpOwn and path: FF1ojr(self, "System font applied", 1500, isGrn=True)
   elif which == VVpOwn   : FF8XzP(self, BF(Main_Menu.VV0auT, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VV0auT(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVJLXo(name):
  if   name == VVlaqR : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VVNAJh: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VVpOwn : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FF6b3q()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VVpOwn:
   nameLst = []
   for nm in FF6b3q():
    if not nm in (VVlaqR, VVNAJh):
     nameLst.append(nm)
  else:
   nameLst = [name]
  totDone = 0
  for fntName in nameLst:
   if FFr0nN(path, fntName, isRepl=repl):
    totDone += 1
  if totDone > 0: FF6b3q()
  else    : return "Could not add font"
 def VVUiE4(self):
  self.session.open(NetworkBrowser)
class CCCRLh(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFXh6Y(VV2F6v, 800, 950, 40, 50, 30, "#22300030", "#0a202020", 33)
  self.session  = session
  self.netEntryFile = "%s%s" % (VVCkxr, "ajpanel_network")
  c1, c2 = VVJ2KG, VVTMjp
  VVW1xb = []
  VVW1xb.append((c1 + "Network Devices"     , "dev" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Network Scanner (ping)"    , "ping"))
  VVW1xb.append(("Port Scanner (scan for famous ports)" , "port"))
  VVW1xb.append(VVswUs)
  VVW1xb.append((c2 + "Check Internet Connection"  , "intr"))
  FFwLhV(self, title="Network Tools", VVW1xb=VVW1xb)
  FFwLhV(self, VVW1xb=VVW1xb)
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FFKauM(self["myMenu"])
  FFVUwm(self)
 def VVi1M6(self):
  global VVdxhd
  VVdxhd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if   item == "dev" : FF7Xva(self, self.VVahnA, title="REading Devices ...")
  elif item == "ping" : FF7Xva(self, self.VVD1lb, title="Scanning ...")
  elif item == "port" : CCkcR1.VVF53M(self, self.VVIeQo, title="Select host to scan")
  elif item == "intr" : self.session.open(CCpVm4)
 def VVahnA(self, canCencel=False):
  title = "Network Devices"
  VVuV68 = self.VVSxKV()
  if VVuV68:
   bg = "#0a223333"
   VVuV68.sort(key=lambda x: x[0].lower())
   VV6iCg = BF(self.VV7573, canCencel)
   VVVi12  = ("Start FTP"   , self.VVFR2o    , [])
   VVQR2V = ("Entry Options"  , self.VVFhLG  , [])
   VVmmwr = ("Scan for Devices" , self.VV5GCa , [])
   header  = ("Num" , "IP-Address", "Username", "Password", "Default Path", "Remarks" )
   widths  = (7  , 25   , 19  , 19  , 0.01   , 30  )
   VVI7B0 = (CENTER , LEFT   , LEFT  , LEFT  , LEFT   , LEFT  )
   VVXOwS = FFEM8S(self, None, title=title, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, width=1500, height=900, VVHqY6=widths, VVJmZ8=28, VVVi12=VVVi12, VV6iCg=VV6iCg, VVQR2V=VVQR2V, VVmmwr=VVmmwr
       , VVgchu=bg, VVn4Mh=bg, VVMqKH=bg, VVKhj2="#11ffff00", VVntre="#11220000", VV3VhT="#00333333", VVwlSC="#11400040")
   ndx = CFG.lastNetworkDevice.getValue()
   if isinstance(ndx, int):
    VVXOwS.VV9fSx(ndx)
  else:
   FF8XzP(self, BF(FF7Xva, self, BF(self.VVQ7Fe, canCencel=canCencel), title="Scanning ..."), "No devices found !\n\nScan network ?", callBack_No=BF(self.VV7573, canCencel), title=title)
 def VVFhLG(self, VVXOwS, title, txt, colList):
  VVW1xb = []
  VVW1xb.append(("Change Username"   , "user"))
  VVW1xb.append(("Change Password"   , "pass"))
  VVW1xb.append(("Change Remarks"   , "rem"))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Remove Selected Server" , "del"))
  FFLFXy(self, BF(self.VVxuH8, VVXOwS), VVW1xb=VVW1xb, title="Entry Options")
 def VVxuH8(self, VVXOwS, item=None):
  if item:
   if   item == "user" : self.VVlyEh("u", VVXOwS)
   elif item == "pass" : self.VVlyEh("p", VVXOwS)
   elif item == "rem" : self.VVlyEh("r", VVXOwS)
   elif item == "del" : FF8XzP(self, BF(FF7Xva, self, BF(self.VVVCc8, VVXOwS), title="Deleting ..."), "Continue ?", title="Delete Entry")
 def VV7573(self, canCencel, VVXOwS=None):
  if VVXOwS: VVXOwS.cancel()
  if canCencel : self.close()
 def VVFR2o(self, VVXOwS, title, txt, colList):
  num, ip, u, p, path, rem = colList
  entry = (ip, u, p, path, rem)
  FFxMsu(CFG.lastNetworkDevice, VVXOwS.VVRJth())
  self.session.openWithCallback(BF(self.VV9SX0, entry, VVXOwS), CCk2Z8, entry)
 def VV9SX0(self, entry, VVXOwS, newPath=None):
  if newPath:
   ip, u, p, path, rem = entry
   if path != newPath:
    self.VVi3sq("d", newPath, ip, u, p, path, rem)
    self.VVN7bo(VVXOwS)
 def VV5GCa(self, VVXOwS, title, txt, colList):
  FF7Xva(VVXOwS, BF(self.VVQ7Fe, mainTableInst=VVXOwS), title="Scanning Network ...")
 def VVQ7Fe(self, canCencel=False, mainTableInst=None):
  ftpLst = CCkcR1.VVc4wU(CCkcR1.VVNdUx)
  telLst = CCkcR1.VVc4wU(CCkcR1.VVyfIg)
  tLst = list(set(ftpLst + telLst))
  lst = []
  for item in tLst:
   typ = []
   if item in ftpLst: typ.append("FTP")
   if item in telLst: typ.append("Telnet")
   lst.append((item[0], item[1], " / ".join(typ)))
  ftpLst = telLst = tLst = None
  title = "Network Devices"
  if lst:
   def VVHKFI(p1, p2): return FF2f45(p1[0], p2[0])
   lst.sort(key=FFKEcC(VVHKFI))
   bg = "#0a202020"
   VV6iCg = BF(self.VV7573, canCencel)
   VVVi12  = ("Add to Devices" , BF(self.VVf0tg, mainTableInst, canCencel) , [])
   header  = ("IP-Address" , "MAC-Address" , "Open Ports" )
   widths  = (40   , 34   , 26   )
   VVI7B0 = (LEFT   , CENTER   , CENTER  )
   FFEM8S(self, None, title=title, header=header, VV6fdw=lst, VVI7B0=VVI7B0, VVHqY6=widths, width=1200, VVJmZ8=30, VVVi12=VVVi12, VV6iCg=VV6iCg, VVimZ8=2
     , VVgchu=bg, VVn4Mh=bg, VVMqKH=bg, VVKhj2="#11ffffaa", VVntre="#0a225555", VVwlSC="#11403040")
  else:
   FFa349(self, "No devices found !", title=title)
 def VVD1lb(self):
  lst = CCkcR1.VVc4wU(-1)
  title = 'Hosts that responded to "ping"'
  if lst:
   def VVHKFI(p1, p2): return FF2f45(p1[0], p2[0])
   lst.sort(key=FFKEcC(VVHKFI))
   bg = "#0a202020"
   header  = ("IP-Address" , "MAC-Address" )
   widths  = (50   , 50   )
   VVI7B0 = (LEFT   , LEFT   )
   FFEM8S(self, None, title=title, header=header, VV6fdw=lst, VVI7B0=VVI7B0, VVHqY6=widths, width=1000, height=700, VVJmZ8=30
     , VVgchu=bg, VVn4Mh=bg, VVMqKH=bg, VVKhj2="#11ffffaa", VVntre="#0a225555", VVwlSC="#11403040")
  else:
   FFa349(self, "Network scanning failed !", title=title)
 def VVIeQo(self, ip=None):
  if ip:
   FF7Xva(self, BF(self.VVa80z, ip), title="Scanning %s" % ip)
 def VVa80z(self, ip):
  dct = {20: "FTP Data Transfer", 21: "FTP Control", 22: "SSH", 23: "Telnet", 25: "SMTP (eMail)", 80: "HTTP", 443: "HTTPS"}
  txt  = "IP:\n   %s\n\n" % ip
  txt += "Ping Result:\n   %s\n\n" % ("OK" if CCkcR1.VVgEWA(ip) else "Failed")
  txt += "Available Ports:\n"
  ports = ""
  for port, subj in dct.items():
   ok = CCkcR1.VVvN8u(ip, port, timeout=0.5)
   if ok:
    ports += "   %d : %s\n" % (port, subj)
  FFyv2f(self, txt + (ports or "   None"), title="Scanned ports : %s" % str(list(dct)).strip("[]"))
 def VVSxKV(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFqXAw(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVHKFI(p1, p2): return FF2f45(p1[0], p2[0])
  tLst.sort(key=FFKEcC(VVHKFI))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVSxKV(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFqXAw(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVHKFI(p1, p2): return FF2f45(p1[0], p2[0])
  tLst.sort(key=FFKEcC(VVHKFI))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVf0tg(self, mainTableInst, canCencel, VVXOwS, title, txt, colList):
  ip, mac, typ = VVXOwS.VVJsov(VVXOwS.VVRJth())
  if "Own" in ip:
   FF1ojr(VVXOwS, "Cannot add your device", 1500)
  else:
   gw = "Gateway"
   if gw in ip : ip, u, p, path, rem = ip.split()[0].strip(), "admin", "123456", "/", gw
   else  : ip, u, p, path, rem = ip, "root", "dreambox", "/", "No-name"
   for entry in self.VVSxKV():
    num1, ip1, u1, p1, path1, rem1 = entry
    if (ip, u, p, path, rem) == (ip1, u1, p1, path1, rem1):
     break
   else:
    if fileExists(self.netEntryFile):
     CCRtNz.VVC8zY(self.netEntryFile)
    with open(self.netEntryFile, "a") as f:
     f.write(self.VV2yVD(ip, u, p, path, rem))
   if mainTableInst: self.VVN7bo(mainTableInst, [ip, u, p, path, rem])
   else   : self.VVahnA(canCencel)
   VVXOwS.cancel()
 def VV2yVD(self, ip, u, p, path, rem):
  return "host=%s,user=%s,pass=%s,path=%s,rem=%s\n" % (ip, u, p, path, rem)
 def VVVCc8(self, VVXOwS):
  num, ip, u, p, path, rem = VVXOwS.VVJsov(VVXOwS.VVRJth())
  lst = self.VVSxKV()
  tot = 0
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if not (ip1, u1, p1, path1, rem1) == (ip, u, p, path, rem):
     f.write(self.VV2yVD(ip1, u1, p1, path1, rem1))
     tot += 1
  if tot:
   self.VVN7bo(VVXOwS)
  else:
   VVXOwS.cancel()
 def VVlyEh(self, col, VVXOwS):
  num, ip, u, p, path, rem = VVXOwS.VVJsov(VVXOwS.VVRJth())
  if   col == "u": orig, subj = u  , "User"
  elif col == "p": orig, subj = p  , "Password"
  elif col == "r": orig, subj = rem, "Remarks"
  FFsShb(self, BF(self.VVlZjy, col, orig, VVXOwS, num, ip, u, p, path, rem), defaultText=orig, title="Change %s" % subj, message="Enter %s:" % subj)
 def VVlZjy(self, col, orig, VVXOwS, num, ip, u, p, path, rem, newTxt):
  if not newTxt == None:
   newTxt = newTxt.strip()
   if orig == newTxt:
    FF1ojr(VVXOwS, "No change", 1500)
   elif not newTxt and col == "u":
    FF1ojr(VVXOwS, "No user !", 2000)
   else:
    self.VVi3sq(col, newTxt, ip, u, p, path, rem)
    self.VVN7bo(VVXOwS)
 def VVi3sq(self, col, newTxt, ip, u, p, path, rem):
  lst = self.VVSxKV()
  oldItem = (ip, u, p, path, rem)
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if (ip1, u1, p1, path1, rem1) == oldItem:
     if   col == "u": u1  = newTxt
     elif col == "p": p1  = newTxt
     elif col == "d": path1 = newTxt
     elif col == "r": rem1 = newTxt
    f.write(self.VV2yVD(ip1, u1, p1, path1, rem1))
 def VVN7bo(self, VVXOwS, newEntry=None):
  VVuV68 = self.VVSxKV()
  if VVuV68 : VVXOwS.VVOFDI(VVuV68, tableRefreshCB=BF(self.VVglDb, newEntry))
  else  : VVXOwS.cancel()
 def VVglDb(self, newEntry, VVXOwS, title, txt, colList):
  if newEntry:
   for ndx, row in enumerate(VVXOwS.VVWsuW()):
    if row[1:] == newEntry:
     VVXOwS.VV9fSx(ndx)
 def VV7573(self, canCencel, VVXOwS=None):
  if VVXOwS: VVXOwS.cancel()
  if canCencel : self.close()
class CCkcR1():
 VVNdUx = 21
 VVyfIg = 23
 def __init__(self):
  self.VV5lfh()
 def VV5lfh(self):
  self.ftp  = None
  self.ftpIp  = ""
  self.ftpUser = ""
  self.ftpPass = ""
  self.ftpSys  = ""
 def VVZY77(self, ip, User, Pass, timeout=5):
  myIp = CCkcR1.VVl8ft()
  if ip != myIp:
   if CCkcR1.VVvN8u(ip, CCkcR1.VVNdUx):
    self.VV5lfh()
    err = ""
    try:
     from ftplib import FTP
     self.ftp  = FTP(ip, user=User, passwd=Pass, timeout=timeout)
     self.ftpIp  = ip
     self.ftpUser = User
     self.ftpPass = Pass
    except Exception as e:
     err = str(e)
   else:
    err = "Connection timed out !\n\n%s" % ip
  else:
   err = "Cannot FTP to to your Device-IP:\n\n%s" % ip
  return err
 def VVg4vE(self):
  try: return self.ftp.sendcmd("SYST")
  except: return ""
 def VVH6Rj(self):
  try:
   return self.ftp.sendcmd("NOOP")
   return True
  except:
   return False
 def VVFkj7(self):
  try: return self.ftp.sendcmd("STAT")
  except: return ""
 def VVHrS8(self, Dir, isLong=False):
  files, err = [], ""
  if self.ftp and self.VVsoI3(Dir):
   try:
    if isLong: self.ftp.dir(files.append)
    else  : self.ftp.nlst()
   except Exception as e:
    err = str(e)
  else:
   err = "No FTP Connection !"
  return files, err
 def VVxdy7(self):
  try: return self.ftp.pwd()
  except: return ""
 def VVI9Ms(self, path):
  try:
   size = self.ftp.sendcmd("SIZE %s" % path)
   return "f"
  except:
   curDir = self.VVxdy7()
   if self.VVsoI3(path) : typ = "d"
   else      : typ = "b"
   self.VVsoI3(curDir)
   return typ
 def VVYFUn(self, path):
  try: return self.ftp.size(path)
  except: return -1
 def VVsoI3(self, path):
  try:
   self.ftp.cwd(path)
   return True
  except:
   return False
 def VVtjvE(self, path):
  try:
   self.ftp.mkd(path)
   return True
  except:
   return False
 def VVXEVb(self, path, flag):
  try:
   if flag == "d" : self.ftp.rmd(path)
   else   : self.ftp.delete(path)
   return True
  except Exception as e:
   return False
 def VVBGh7(self, fromN, toN):
  try:
   self.ftp.rename(fromN, toN)
   return True
  except:
   return False
 def VVWsJm(self, remFile, locFile="", maxSz=10000000):
  sz = self.VVYFUn(remFile)
  if   sz == -1 : return "", sz, "Cannot read file size."
  elif sz > maxSz : return "", sz, "File too big."
  else   : err= ""
  locFile = locFile or "/tmp/%s" % os.path.basename(remFile)
  try:
   self.ftp.retrbinary("RETR %s" % remFile, open(locFile, "wb").write)
   if fileExists(locFile) : return locFile, sz, ""
   else     : return "", sz, "Download Failed."
  except Exception as e:
   FFGWxS(locFile)
   return "", sz, str(e)
 def VVfPLB(self):
  if self.ftp:
   try: self.ftp.quit()
   except: pass
  self.VV5lfh()
 @staticmethod
 def VV434j():
  from uuid import getnode
  return ':'.join(iFindall('..', '%012x' % getnode())).upper()
 @staticmethod
 def VVl8ft():
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_DGRAM
  try:
   setdefaulttimeout(1)
   s = socket(AF_INET, SOCK_DGRAM)
   s.connect(("1.1.1.1", 80))
   ip = s.getsockname()[0]
   s.close()
   return ip
  except:
   return ""
 @staticmethod
 def VVtynf():
  myIp = CCkcR1.VVl8ft()
  if myIp.count(".") == 3:
   parts = myIp.split('.')
   return ".".join(parts[:3]) + "."
  return ""
 @staticmethod
 def VVyakT():
  span = iSearch(r"((?:\d+.){3}\.\d+)", FFyJfo("ip route | grep default"), IGNORECASE)
  return span.group(1) if span else ""
 @staticmethod
 def VVlkcz(port=-1):
  lst = []
  def VV97RI(ip):
   if port > -1: ok = CCkcR1.VVvN8u(ip, port)
   else  : ok = CCkcR1.VVgEWA(ip)
   if ok:
    lst.append(ip)
  baseIp = CCkcR1.VVtynf()
  thLst  = []
  for num in range(1, 255):
   ip = "%s%d" % (baseIp, num)
   th = iThread(name="ajp_scanIp%d" % num, target=BF(VV97RI, ip))
   th.start()
   thLst.append(th)
  for th in thLst: th.join()
  return lst
 @staticmethod
 def VVc4wU(port):
  myIp = CCkcR1.VVl8ft()
  myGw = CCkcR1.VVyakT()
  tDict = { myIp: CCkcR1.VV434j() }
  for ip in CCkcR1.VVlkcz(port):
   span = iSearch(r"((?:\d+.){3}\.\d+).+\s+((?:[a-f\d]{2}:){5}[a-f\d]{2})", FFuVMf("arp -n %s" % ip), IGNORECASE)
   if span    : tDict[ip] = span.group(2).upper()
   elif not ip == myIp : tDict[ip] = ""
  lst = []
  for key, val in tDict.items():
   if   key == myIp: txt = " %s Own" % VVJ2KG
   elif key == myGw: txt = " %s Gateway" % VVJ2KG
   else   : txt = ""
   lst.append((key + txt, val))
  return lst
 @staticmethod
 def VVgEWA(ip):
  return True if os.system(FFQe93("ping -W1 -q -c1 %s" % ip)) == 0 else False
 @staticmethod
 def VVvN8u(host, port, timeout=1.0):
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
  setdefaulttimeout(timeout)
  try:
   socket(AF_INET, SOCK_STREAM).connect((host, port))
   return True
  except:
   return False
 @staticmethod
 def VVGFKI(ip="1.1.1.1", timeout=1):
  if CCkcR1.VVvN8u(ip, 53, timeout):
   return True
  if CCkcR1.VVgEWA(ip):
   return True
  return os.system(FFQe93("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
 @staticmethod
 def VVF53M(SELF, okFnc, title):
  baseIp = CCkcR1.VVtynf()
  lst = []
  for num in range(1, 255):
   item = "%s%d" % (baseIp, num)
   lst.append((item, item))
  FFLFXy(SELF, okFnc, VVW1xb=lst, width=600, title=title, VVgchu="#222222", VVn4Mh="#222222")
class CCk2Z8(Screen, CCkcR1):
 def __init__(self, session, entry):
  self.skin, self.skinParam = FFXh6Y(VV2F6v, 1400, 920, 40, 50, 30, "#11333344", "#08303030", 30, barHeight=40, topRightBtns=2)
  self.session  = session
  self.ftpEntry  = entry
  self.VVJmZ8  = self.skinParam["bodyFontSize"]
  self.VVJ5AH  = self.skinParam["bodyLineH"]
  self.VVExc6  = self.skinParam["width"]
  self.curDir   = "/"
  self.list   = []
  self.png_fil  = CCDiIK.VVAgne("fil")
  self.png_dir  = CCDiIK.VVAgne("dir")
  self.png_dirup  = CCDiIK.VVAgne("dirup")
  self.png_slwfil  = CCDiIK.VVAgne("slwfil")
  self.png_slbfil  = CCDiIK.VVAgne("slbfil")
  self.png_slwdir  = CCDiIK.VVAgne("slwdir")
  self.serverOrigData = None
  self.Title   = "FTP (%s)" % entry[0]
  CCkcR1.__init__(self)
  VVW1xb = [("Item-%d" % x,) for x in range(50)]
  FFwLhV(self, title=self.Title, VVW1xb=VVW1xb)
  FFxDER(self["keyRed"] , "Exit")
  self["myMenu"] = MenuList(VVW1xb, True, eListboxPythonMultiContent)
  self["myMenu"].l.setFont(0, gFont(VVPvAG, self.VVJmZ8))
  self["myMenu"].l.setItemHeight(self.VVJ5AH)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VVOJpx   ,
   "ok" : self.VVi1M6   ,
   "cancel": self.VVOJpx   ,
   "menu" : self.VVoSaS  ,
   "info" : self.VVS75f ,
   "pageUp": self.VVJ0Yi   ,
   "chanUp": self.VVJ0Yi
  })
  self.onShown.append(self.VVfcAc)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVgLNF)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FFKauM(self["myMenu"])
  FFVUwm(self)
  FFvDt2(self)
  FF8TfI(self)
  FF0e9t(self["keyBlue"], "#11333333")
  FF7Xva(self, self.VVB8In, title="Connecting ...")
 def VVB8In(self):
  ip, u, p, path, rem = self.ftpEntry
  err = self.VVZY77(ip, u, p)
  if err:
   FFa349(self, err, title=self.Title)
   FFxDER(self["keyBlue"] , "")
   self.close()
  elif self.ftp:
   FFxDER(self["keyBlue"], self.ftpIp)
   if not self.VVsoI3(path):
    path = "/"
   self.VVuEL9(path)
   self.serverOrigData = (ip, u, p, path, rem)
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.VVH6Rj():
   self.VVfPLB()
 def VVi1M6(self):
  if self.VVQDRQ():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    if   flag == "d" or targetState == "d" : self.VVuEL9(os.path.join(self.curDir, name))
    elif flag == "x"      : self.VVJ0Yi()
    else         : self.VVPHXr(os.path.join(self.curDir, name))
 def VVOJpx(self):
  if CFG.FileManagerExit.getValue() == "e": self.close(self.curDir)
  else         : self.VVJ0Yi()
 def VVQDRQ(self):
  if self.VVH6Rj():
   return True
  else:
   FFa349(self, "FTP Server is now diconnected !", title=self.Title)
   return False
 def VVPHXr(self, path):
  cat = self.VVaYnF(path)
  if cat in ("pic"):
   FF7Xva(self, BF(self.VVRDEK, path))
  elif cat in ("mov", "mus"):
   if CCXzGX.VVJEHr("5002"):
    url = "ftp%%3a//%s%%3a%s@%s%s" % (self.ftpUser, self.ftpPass, self.ftpIp, path)
    rType = "5002"
   else:
    rType = CFG.iptvAddToBouquetRefType.getValue()
    url = "http%%3a//%s/file?file=%s" % (self.ftpIp, path)
   FF7Xva(self, BF(CCbI7Z.VV7vnp, self, url, rType=rType), title="Playing Media ...")
 def VVRDEK(self, path):
  locFile, size, err = self.VVWsJm(path)
  if err: FFa349(self, err, title="View Picture File")
  else  : CCFA9F.VVK9Qe(self, locFile, fakePath="ftp:/%s" % path, cbFnc=BF(FFGWxS))
 def VVgLNF(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel: title = "  %s  " % os.path.join(self.curDir, "" if sel[0][0] == CCDiIK.VVCZHz else sel[0][0])
  else  : title=  VVAgOb + "  No Files Found !"
  self["myTitle"].setText(title)
 def VVJ0Yi(self):
  if self.VVQDRQ():
   lastPart = FFmKBR(self.curDir)
   parentDir = os.path.abspath(os.path.join(self.curDir, os.pardir))
   self.VVuEL9(parentDir, lastPart, "d")
 def VVuEL9(self, Dir, moveTo="", moveToType=""):
  FF7Xva(self, BF(self.VVhUeh, Dir, moveTo, moveToType))
 def VVhUeh(self, Dir, moveTo, moveToType):
  files, err = self.VVHrS8(Dir, isLong=True)
  self.curDir = self.VVxdy7() or "/"
  self.VV1MzX(files)
  if moveTo:
   for ndx, item in enumerate(self.list):
    name, target, targetState, flag, sortSeq = item[0]
    if moveTo == name:
     if not moveToType or moveToType == flag:
      self["myMenu"].moveToIndex(ndx)
      break
  else:
   self["myMenu"].moveToIndex(0)
 def VV1MzX(self, files):
  self.list = []
  if self.curDir != "/":
   self.list.append(self.VVkYxM(CCDiIK.VVCZHz, CCDiIK.VVCZHz, "", "", "x"))
  for item in files:
   linkTo = ""
   isDir = isFile = isLink = False
   item = item.strip()
   if   item.startswith("l")     : flag = "l"
   elif item.startswith("d") or "<DIR>" in item: flag = "d"
   else          : flag = "f"
   gaps = 3 if item[:1].isdigit() else 8
   name = item.split(None, gaps)[gaps]
   linkSep = " -> "
   origName = name
   target = targetState = ""
   if linkSep in name:
    flag = "l"
    name, _, target = name.partition(linkSep)
    if not target.startswith("/"):
     target = "/" + target
    targetState = self.VVI9Ms(target)
    color = VVAgOb if targetState == "b" else VVlfrr
    origName = name + VVzCWu + linkSep + color + " "+ target
   self.list.append(self.VVkYxM(origName, name, target, targetState, flag))
  self.list.sort(key=lambda x: (x[0][4], x[0][0]))
  self["myMenu"].l.setList(self.list)
 def VVkYxM(self, origName, name, target, targetState, flag):
  if flag == "f":
   png = self.png_fil
   ext = os.path.splitext(name)[1]
   if ext:
    cat = self.VVaYnF(name)
    if cat: png = LoadPixmap("%s%s.png" % (VV9dcF, cat))
  elif flag == "d": png = self.png_dir
  elif flag == "l":
   if   targetState == "f" : png = self.png_slwfil
   elif targetState == "d" : png = self.png_slwdir
   elif targetState == "b" : png = self.png_slbfil
   else      : png = self.png_slwfil
  elif flag == "x": png = self.png_dirup
  else   : png = self.png_fil
  if   origName == CCDiIK.VVCZHz: sortSeq = 0
  elif flag == "d" or targetState == "d"  : sortSeq = 1
  else          : sortSeq = 2
  tableRow = [ (name, target, targetState, flag, sortSeq) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVJ5AH + 10, 0, self.VVExc6, self.VVJ5AH, 0, LEFT | RT_VALIGN_CENTER, origName))
  if VVDXCW: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVJ5AH-4, self.VVJ5AH-4, png, None, None, VVDXCW))
  else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVJ5AH-4, self.VVJ5AH-4, png, None, None))
  return tableRow
 def VVaYnF(self, path):
  ext = os.path.splitext(path)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in CCDiIK.VVGjn5().items():
    if ext in lst:
     return cat
  return ""
 def VVoSaS(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel : name, target, targetState, flag, sortSeq = sel[0]
  else : name = target = targetState = flag = ""
  isTop  = name == CCDiIK.VVCZHz
  isDir  = flag == "d" or targetState == "d"
  isFile = flag == "f" or targetState == "f"
  def VVc4Hw(titl, ref, chk, color=""):
   if chk: return VVW1xb.append((color + titl, ref))
   else  : return VVW1xb.append((titl, ))
  VVW1xb = []
  VVc4Hw("Properties", "VVS75f", not isTop)
  c = VVJ2KG
  VVW1xb.append(VVswUs)
  VVc4Hw("Download Selected File ..."    , "FFjmFiFromServer", isFile, c)
  VVc4Hw("Upload a Local File to Remote Server ...", "VV2k9i" , True  , c)
  VVW1xb.append(VVswUs)
  VVc4Hw("Create new directory", "VV3HAK", True)
  VVc4Hw("Rename", "VVvZCZ", not isTop)
  VVc4Hw("DELETE", "VVwVsx", not isTop, VV9ZlA)
  VVW1xb.append(VVswUs)
  VVc4Hw("FTP Server Information", "VV2z5e", True)
  VVW1xb.append(VVswUs)
  VVc4Hw("Refresh File List", "refresh", True)
  FFLFXy(self, self.VVBp1z, VVW1xb=VVW1xb, title="Options")
 def VVBp1z(self, item=None):
  if item:
   if   item == "VVS75f"     : self.VVS75f()
   elif item == "FFjmFiFromServer"   : self.FFjmFiFromServer()
   elif item == "VV2k9i"   : self.VV2k9i()
   elif item == "VV3HAK"   : self.VV3HAK()
   elif item == "VVvZCZ"   : self.VVvZCZ()
   elif item == "VVwVsx"   : self.VVwVsx()
   elif item == "VV2z5e"    : self.VV2z5e()
   elif item == "refresh"and self.VVQDRQ() : self.VVuEL9(self.curDir)
 def VVS75f(self):
  if self.VVQDRQ():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    path = os.path.join(self.curDir, name)
    txt = "%s:\n%s\n\n" % (FFY7FT("Path", VVJ2KG), path)
    typ = {"d": "Directory", "f": "File", "l": "SymLink", "x": ""}.get(flag, "")
    if typ: txt += "Type\t: %s%s\n" % (typ, " (Broken)" if targetState == "b" else "")
    if target: txt += "Target\t: %s\n" % target
    sz = self.VVYFUn(path)
    if sz > -1: txt += "Size\t: %s" % CCbI7Z.VVr8MR(sz)
   else:
    txt = "Nothing selected"
   FFyv2f(self, txt, title="Properties")
 def VV2z5e(self):
  if self.VVQDRQ():
   Sys  = self.VVg4vE() or " -"
   txt = "%s\n  %s\n\n" % (FFY7FT("System:", VVJ2KG), Sys[4:] if Sys.startswith("215 ") else Sys)
   Stat = self.VVFkj7() or " -"
   txt += "%s\n" % (FFY7FT("Status:", VVJ2KG))
   for line in Stat.splitlines():
    txt += "  %s\n" % (line[4:] if line.startswith("211-") or line.startswith("211 ") else line)
   FFyv2f(self, txt, title="FTP Server Information")
 def VV3HAK(self, name=""):
  if self.VVQDRQ():
   title = "Add New Directory"
   FFsShb(self, BF(self.VVGFgX, title), defaultText=name, title=title, message="Enter Directory name")
 def VVGFgX(self, title, name):
  if name and name.strip():
   if self.VVtjvE(name) : self.VVuEL9(self.curDir, name, "d")
   else     : FFa349(self, "Failed to create : %s" % name, title)
 def VVvZCZ(self):
  if self.VVQDRQ():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Rename"
    name, target, targetState, flag, sortSeq = sel[0]
    FFsShb(self, BF(self.VV40r3, title, name, flag), defaultText=name, title=title, message="Enter new name")
 def VV40r3(self, title, name, flag, newName):
  if newName and newName.strip():
   if self.VVBGh7(name, newName.strip()) : self.VVuEL9(self.curDir, newName, flag)
   else          : FFa349(self, "Failed to rename to : %s" % newName, title)
 def VVwVsx(self):
  if self.VVQDRQ():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    FF8XzP(self, BF(FF7Xva, self, BF(self.VVO4Ce, name, flag), title="Deleting ..."), "Delete ?\n\n%s" % name, title="Delete")
 def VVO4Ce(self, name, flag):
  if self.VVXEVb(name, flag) : self.VVuEL9(self.curDir)
  else         : FFa349(self, "Failed to delete:\n\n%s" % name, "Delete")
 def FFjmFiFromServer(self):
  if self.VVQDRQ():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Download File"
    name, target, targetState, flag, sortSeq = sel[0]
    remFile = os.path.join(self.curDir, name)
    size = self.VVYFUn(remFile)
    if size == -1:
     FFa349(self, "Cannot get file size for:\n\n%s" % remFile, title=title)
    else:
     Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVCkxr
     self.session.openWithCallback(BF(self.VVh92W, title, remFile, name, size), BF(CCbI7Z, mode=CCbI7Z.VVIet0, VVVp3O="Download here", VVetf7=Dir, width=1200, height=840, pickTitleBG="#11002222", pickBodyBG="#11003333", cursorBG="#11005566"))
 def VVh92W(self, title, remFile, name, size, locPath):
  if locPath:
   FFxMsu(CFG.lastFtpLocalPath, locPath)
   locFile = os.path.join(locPath, name)
   self.session.open(CCvBnC, barTheme=CCvBnC.VVjpsh, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Downloading ..."
       , fncToRun  = BF(self.VVoHz7, remFile, size, locFile)
       , VVnRGv = BF(self.VVLlUK, remFile, size, locFile))
 def VVoHz7(self, remFile, size, locFile, VVhsRS):
  VVhsRS.VVBrFN(size)
  VVhsRS.VVLNy3 = ""
  with open(locFile, "wb") as locFileObj:
   try:
    def VVfnGe(data):
     if not VVhsRS or VVhsRS.isCancelled:
      return
     locFileObj.write(data)
     VVhsRS.VVwvD4(len(data))
    self.ftp.retrbinary("RETR %s" % remFile, VVfnGe)
   except Exception as e:
    VVhsRS.VVLNy3 = str(e)
 def VVLlUK(self, remFile, size, locFile, VVL4pA, VVLNy3, threadCounter, threadTotal, threadErr):
  title = "File Download"
  delF = False
  if VVLNy3:
   FFa349(self, "%s\n\nftp:/%s" % (VVLNy3, remFile), title="Download Error")
   delF = True
  elif not VVL4pA:
   FFa349(self, "Download cancelled for:\n\nftp:/%s" % remFile, title=title)
   delF = True
  else:
   if size == FFPYZx(locFile):
    txt = "Successfully downloaded to:\n\n%s" % locFile
    FF5nWa(self, txt, title=title)
   else:
    FFa349(self, "Incorrect downloaded file size for:\n\nftp:/%s" % remFile, title=title)
    delF = True
  if delF:
   FFGWxS(locFile)
 def VV2k9i(self):
  if self.VVQDRQ():
   Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVCkxr
   self.session.openWithCallback(self.VVCPMa, BF(CCbI7Z, VVVp3O="Upload selected file", VVetf7=Dir, patternMode="all", width=1200, height=850, pickTitleBG="#11001122", pickBodyBG="#11330033", cursorBG="#11662200"))
 def VVCPMa(self, locFile):
  if locFile:
   title = "Upload File to Remote Server"
   FFxMsu(CFG.lastFtpLocalPath, os.path.dirname(locFile))
   size = FFPYZx(locFile)
   if size == -1:
    FFa349(self, "Cannot get file size for:\n\n%s" % locFile, title=title)
   else:
    remFile = os.path.join(self.curDir, os.path.basename(locFile))
    self.session.open(CCvBnC, barTheme=CCvBnC.VVjpsh, titleBg="#22220022", bodyBg="#22220022"
        , titlePrefix = "Uploading ..."
        , fncToRun  = BF(self.VVpU7p, locFile, size, remFile)
        , VVnRGv = BF(self.VVc0p8, locFile, size, remFile))
 def VVpU7p(self, locFile, size, remFile, VVhsRS):
  VVhsRS.VVBrFN(size)
  VVhsRS.VVLNy3 = ""
  with open(locFile, "rb") as locFileObj:
   try:
    def VVHI6F(data):
     if not VVhsRS or VVhsRS.isCancelled:
      return
     VVhsRS.VVwvD4(len(data))
    self.ftp.storbinary("STOR %s" % remFile, locFileObj, callback=VVHI6F)
   except Exception as e:
    VVhsRS.VVLNy3 = str(e)
 def VVc0p8(self, locFile, size, remFile, VVL4pA, VVLNy3, threadCounter, threadTotal, threadErr):
  title = "File Upload"
  delF = False
  if VVLNy3:
   FFa349(self, "%s\n\nftp:/%s" % (VVLNy3, remFile), title="Upload Error")
   delF = True
  elif not VVL4pA:
   FFa349(self, "Upload cancelled for:\n\nftp:/%s" % remFile, title=title)
   delF = True
  else:
   if size == FFPYZx(locFile):
    txt = "Successfully uploaded to:\n\n%s" % remFile
    FF5nWa(self, txt, title=title)
    self.VVuEL9(self.curDir)
   else:
    FFa349(self, "Incorrect uploaded file size for:\n\nftp:/%s" % remFile, title=title)
    delF = True
  if delF:
   self.VVh1Nl(remFile)
class CCXLqT():
 VVTfqN  = "all"
 VV6cOl = "vid"
 VVpclZ  = "osd"
 @staticmethod
 def VVYhxr(session, k):
  if not CFG.screenshotFType.getValue() == "off":
   title = "%s Screenshot" % PLUGIN_NAME
   if FFeWq1("grab"):
    winShown = session.current_dialog.shown
    if k == CCXLqT.VV6cOl and winShown: session.current_dialog.hide()
    FFWlvR(BF(CCXLqT.VVnVwD, title, session, k, winShown))
   else:
    FFsXs9(session, "No Grab command !", title=title)
 @staticmethod
 def VVnVwD(title, session, k, winShown):
  fTitle = skinName = ""
  x = y = w = h = 0
  if k == CCXLqT.VVpclZ:
   if not winShown:
    FFsXs9(session, "No Window to capture !", title=title)
    return
   if not CCXLqT.VVqbOL(session, title, True):
    return
   valid, origTitle, clnTitle, skinName, x, y, w, h = CCXLqT.VVDAcI(session)
   fTitle = "%s_(%s)" % (clnTitle, skinName)
   if not valid:
    FFsXs9(session, "Cannot get Window Dimensions !", title=title)
    return
  if not fTitle:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(session, isFromSession=True)
   chName = iSub(r"[^A-z0-9]" ,"-" , chName.strip())
   fTitle = chName or refCode.replace(":", "_")
  ext = CFG.screenshotFType.getValue()
  if   ext == "jpg": typ = "-j 100"
  elif ext == "png": typ = "-p"
  else    : typ = ""
  path = "%sscreenshot_%s_%s.%s" % (FFnWu0(CFG.exportedPIconsPath.getValue()), fTitle, FFJCyp(), ext)
  res = os.system(FFHR0m("grab -q -s %s > '%s'" % (typ, path)))
  if k == CCXLqT.VV6cOl and winShown:
   session.current_dialog.show()
  elif k == CCXLqT.VVpclZ:
   ok = CCXLqT.VVLL6M(path, x, y, w, h)
   if not ok:
    FFGWxS(path)
    FFsXs9(session, "Error while cropping image file !", title=title)
    return
  if res == 0 and fileExists(path): session.open(BF(CCFA9F, title=path, VVUlwB=path))
  else       : FFsXs9(session, "Error while capturing screen !", title=title)
 @staticmethod
 def VVqbOL(SELF, title, isFromExternal, install=True, cbFnc=None):
  try:
   from PIL import Image
   return True
  except:
   if install:
    FF8XzP(SELF, BF(CCXLqT.VVmgw9, SELF, isFromExternal, cbFnc=cbFnc), "Imaging Library is required.\n\nInstall ?", title=title, isFromExternal=isFromExternal)
   return False
 @staticmethod
 def VVmgw9(SELF, isFromExternal, cbFnc=None):
  if pyVersion[0] >= 3: name = "python3-pillow"
  else    : name = "python-imaging"
  if isFromExternal: fnc = BF(FFgXLo, VVvcJy=cbFnc)
  else    : fnc = BF(FFsZIz , VVvcJy=cbFnc)
  fnc(SELF, FFkjia(VVkKCu, name), checkNetAccess=True, title="Installing Imaging Library")
 @staticmethod
 def VVDAcI(session, repl="-"):
  valid = False
  origTitle = clnTitle = skinName = ""
  x = y = w = h = 0
  obj = session.current_dialog
  if obj:
   inst = obj.instance
   skinName = obj.skinName
   if inst:
    origTitle = inst.getTitle()
    pos, size = inst.position(), inst.size()
    x, y, w, h = pos.x(), pos.y(), size.width(), size.height()
    valid = w != 0 and h !=0
    clnTitle = iSub(r"[^A-z0-9]" ,repl , origTitle.strip())
  return valid, origTitle, clnTitle, skinName, x, y, w, h
 @staticmethod
 def VVLL6M(path, x, y, w, h, scaleToScreen=True):
  try:
   from PIL import Image
   im = Image.open(path)
   x1 = w + x
   y1 = h + y
   if scaleToScreen:
    scrW, scrH = FFcmgn()
    w, h = im.size
    if w != scrW or h != scrH:
     x  = FFfFjr(x , 0, scrW, 0, w)
     y  = FFfFjr(y , 0, scrH, 0, h)
     x1 = FFfFjr(x1, 0, scrW, 0, w)
     y1 = FFfFjr(y1, 0, scrH, 0, h)
   im = im.crop((x, y, x1, y1))
   im.save(path)
   return True
  except:
   return False
 @staticmethod
 def VVWuew(path):
  size = FFPYZx(path)
  sizeTxt = CCbI7Z.VVr8MR(size) if size > -1 else ""
  try:
   from PIL import Image
   im = Image.open(path)
   form = im.format
   mode = im.mode
   resTxt = "%d x %d" % im.size
  except:
   resTxt = form = mode = ""
  return size, sizeTxt, resTxt, form, mode
class CCowQI(Screen):
 def __init__(self, session, title, fontsList, defFnt, withRestart):
  self.skin, self.skinParam = FFXh6Y(VV2F6v, 1400, 1000, 40, 40, 30, "#0a001100", "#10110000", 30, barHeight=220)
  self.session  = session
  self.fontsList  = fontsList
  self.defFnt   = defFnt
  txt = FFY7FT(" (Requires GUI Restart)", VVPpUd) if withRestart else ""
  VVW1xb = []
  for path in self.fontsList:
   VVW1xb.append((os.path.splitext(os.path.basename(path))[0], path))
  VVW1xb.sort(key=lambda x: x[0].lower())
  VVW1xb.insert(0, VVswUs)
  VVW1xb.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if self.defFnt:
   for ndx, item in enumerate(VVW1xb):
    if len(item) == 2 and item[1] == self.defFnt:
     VVW1xb[ndx] = (VVlfrr + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVW1xb[curIndex] = (VVlfrr + VVW1xb[curIndex][0], VVW1xb[curIndex][1])
  FFwLhV(self, VVW1xb=VVW1xb, title=title)
  self["myActionMap"].actions.update({"cancel": self.cancel})
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FFKauM(self["myMenu"])
  FFVUwm(self)
  self["myMenu"].onSelectionChanged.append(self.VVpzTO)
  self["myBar"].setText(self.VVx9iB())
  self["myBar"].instance.setHAlign(1)
  self.VVpzTO()
 def VVi1M6(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVpzTO(self):
  path = self["myMenu"].l.getCurrentSelection()[1]
  if fileExists(path):
   fnt = "AJP_Sample"
   FFr0nN(path, fnt, isRepl=1)
  else:
   fnt = VVm9KW
  self["myMenu"].instance.setFont(gFont(fnt, self.skinParam["bodyFontSize"]))
  self["myMenu"].instance.invalidate()
  self["myBar"].instance.setFont(gFont(fnt, int(self.skinParam["bodyFontSize"] * 1.3)))
  self["myBar"].instance.invalidate()
 def VVx9iB(self):
  txt = ""
  for i in range(65, 91): txt += chr(i)
  txt += "\n"
  for i in range(97, 123): txt += chr(i)
  txt += "  "
  for i in range(48, 58): txt += chr(i)
  txt += "\n"
  txt += u"\u0623\u0628\u062c\u062f \u0647\u0648\u0632 \u062d\u0637\u064a \u0643\u0644\u0645\u0646 \u0633\u0639\u0641\u0635 \u0642\u0631\u0634\u062a \u062b\u062e\u0630 \u0636\u0638\u063a  \u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
  return str(txt)
 @staticmethod
 def VVDzgX(SELF, title, defFnt, rest, VVnRGv):
  fntPath = resolveFilename(SCOPE_FONTS)
  fontsList = FFKZAp(fntPath, "*.[tToO][tT][fF]")
  if fontsList: SELF.session.openWithCallback(VVnRGv, CCowQI, title, fontsList, defFnt, rest)
  else  : FFa349(self, "No fonts found in:\n\n%s" % fntPath, title=title)
class CCEBis(Screen):
 def __init__(self, session, path, VVW1xb, title):
  self.skin, self.skinParam = FFXh6Y(VV2F6v, 1700, 1000, 40, 40, 30, "#11001122", "#11002233", 30, menuLabel=50)
  self.session = session
  self.path  = path
  FFwLhV(self, VVW1xb=VVW1xb, title=title)
  self["myLabelFrm"] = Label()
  self["myLabelTit"] = Label("Result Sample")
  self["myLabelTxt"] = Label()
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVi1M6   ,
   "cancel" : self.cancel   ,
   "pageUp" : self.VVKm3z,
   "chanUp" : self.VVKm3z,
   "pageDown" : self.VV5wdm ,
   "chanDown" : self.VV5wdm ,
  }, -1)
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FFKauM(self["myMenu"])
  FFVUwm(self)
  FF0e9t(self["myLabelFrm"], "#11110000")
  FF0e9t(self["myLabelTit"], "#11663322")
  FF0e9t(self["myLabelTxt"], "#11110000")
  self["myLabelTxt"].instance.setNoWrap(True)
  self["myMenu"].onSelectionChanged.append(self.VV2nUc)
  self.VV2nUc()
 def VV2nUc(self):
  if fileExists(self.path): txt = FFqXAw(self.path, maxSize=1000, encLst=[self["myMenu"].l.getCurrentSelection()[1]])
  else     : txt = "Review error !"
  self["myLabelTxt"].setText(txt.strip())
 def VVi1M6(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVKm3z(self) : self["myMenu"].moveToIndex(0)
 def VV5wdm(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCAUx4():
 @staticmethod
 def VV0czc():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVyljk(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFEM8S(SELF, None, VV6fdw=lst, VVJmZ8=30, VVimZ8=1)
 @staticmethod
 def VVx4Et(path, SELF=None):
  for enc in CCAUx4.VV0czc():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFa349(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVqaxk(SELF, path, cbFnc, defEnc="utf8", onlyWorkingEnc=True, title="Select Encoding"):
  FF1ojr(SELF)
  lst = CCAUx4.VV9kym(path, onlyWorkingEnc=onlyWorkingEnc)
  if lst:
   VVW1xb = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if defEnc == enc:
     txt = FFY7FT(txt, VVlfrr)
    VVW1xb.append((txt, enc))
   if onlyWorkingEnc: SELF.session.openWithCallback(cbFnc, CCEBis, path, VVW1xb, title)
   else    : FFLFXy(SELF, cbFnc, title=title, VVW1xb=VVW1xb, width=900, VVgchu="#22220000", VVn4Mh="#22220000")
  else:
   FF1ojr(SELF, "No proper encoding", 2000)
 @staticmethod
 def VV9kym(path, onlyWorkingEnc=True):
  encLst = []
  cPath = VV9dcF + "_sup_codecs"
  if fileExists(cPath):
   lines = FFFfvw(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCAUx4.VV0czc())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if onlyWorkingEnc:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CCLeKE(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFXh6Y(VV2F6v, 900, 950, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVW1xb = []
  VVW1xb.append(("Settings File"   , "SettingsFile"  ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Box Info"     , "VVCXu1"   ))
  VVW1xb.append(("Tuners Info"    , "VV74oK"  ))
  VVW1xb.append(("Python Version"   , "VV6vpx"  ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Screen Size"    , "ScreenSize"   ))
  VVW1xb.append(("Language/Locale"   , "Locale"    ))
  VVW1xb.append(("Processor"    , "Processor"   ))
  VVW1xb.append(("Operating System"   , "OperatingSystem"  ))
  VVW1xb.append(("Drivers"     , "drivers"    ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("System Users"    , "SystemUsers"   ))
  VVW1xb.append(("Logged-in Users"   , "LoggedInUsers"  ))
  VVW1xb.append(("Uptime"     , "Uptime"    ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Host Name"    , "HostName"   ))
  VVW1xb.append(("MAC Address"    , "MACAddress"   ))
  VVW1xb.append(("Network Configuration" , "NetworkConfiguration"))
  VVW1xb.append(("Network Status"   , "NetworkStatus"  ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Disk Usage"    , "VVfSEU"   ))
  VVW1xb.append(("Mount Points"    , "MountPoints"   ))
  VVW1xb.append(("File System Table (FSTAB)", "FileSystemTable"  ))
  VVW1xb.append(("USB Devices"    , "USB_Devices"   ))
  VVW1xb.append(("List Block-Devices"  , "listBlockDevices" ))
  VVW1xb.append(("Directory Size"   , "DirectorySize"  ))
  VVW1xb.append(("Memory"     , "Memory"    ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Loaded Kernel Modules" , "LoadedKernelModules" ))
  VVW1xb.append(("Running Processes"  , "RunningProcesses" ))
  VVW1xb.append(("Processes with open files", "ProcessesOpenFiles" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"))
  FFwLhV(self, VVW1xb=VVW1xb, title="Device Information")
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FFKauM(self["myMenu"])
  FFVUwm(self)
 def VVi1M6(self):
  global VVdxhd
  VVdxhd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"   : self.session.open(CCrx0K)
   elif item == "VVCXu1"   : self.VVCXu1()
   elif item == "VV74oK"  : self.VV74oK()
   elif item == "VV6vpx"  : self.VV6vpx()
   elif item == "ScreenSize"   : FFyv2f(self, "Width\t: %s\nHeight\t: %s" % (FFcmgn()[0], FFcmgn()[1]))
   elif item == "Locale"    : CCAUx4.VVyljk(self)
   elif item == "Processor"   : self.VVsE3K()
   elif item == "OperatingSystem"  : FFYpRN(self, "uname -a")
   elif item == "drivers"    : self.VVeomH()
   elif item == "SystemUsers"   : FFYpRN(self, "id")
   elif item == "LoggedInUsers"  : FFYpRN(self, "who -a")
   elif item == "Uptime"    : FFYpRN(self, "uptime")
   elif item == "HostName"    : FFYpRN(self, "hostname")
   elif item == "MACAddress"   : self.VVsm2t()
   elif item == "NetworkConfiguration" : FFYpRN(self, "ifconfig %s %s" % (FFfLXZ("HWaddr", VVHiet), FFfLXZ("addr:", VVzCWu)))
   elif item == "NetworkStatus"  : FFYpRN(self, "netstat -tulpn"       )
   elif item == "VVfSEU"   : self.VVfSEU()
   elif item == "MountPoints"   : FFYpRN(self, "mount %s" % (FFfLXZ(" on ", VVzCWu)))
   elif item == "FileSystemTable"  : FFYpRN(self, "cat /etc/fstab")
   elif item == "USB_Devices"   : FFYpRN(self, "lsusb")
   elif item == "listBlockDevices"  : FFYpRN(self, "blkid")
   elif item == "DirectorySize"  : FFYpRN(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVxtVg="Reading size ...")
   elif item == "Memory"    : FFYpRN(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules" : self.VVcihd()
   elif item == "RunningProcesses"  : FFYpRN(self, "ps")
   elif item == "ProcessesOpenFiles" : FFYpRN(self, "lsof")
   elif item == "DreamBoxBootloader"  : self.VVNsz9()
   else        : self.close()
 def VVsm2t(self):
  res = FFuVMf("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFyv2f(self, txt)
  else:
   FFYpRN(self, "ip link")
 def VV1mxT(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FF94gP(cmd)
  return lines
 def VVzDyr(self, lines, headerRepl, widths, VVI7B0):
  VVuV68 = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVuV68.append(parts)
  if VVuV68 and len(header) == len(widths):
   VVuV68.sort(key=lambda x: x[0].lower())
   FFEM8S(self, None, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=28, VVimZ8=1)
   return True
  else:
   return False
 def VVfSEU(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFuVMf(cmd)
  if not "invalid option" in txt:
   lines  = self.VV1mxT(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VVI7B0 = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVzDyr(lines, headerRepl, widths, VVI7B0)
  else:
   cmd = "df -h"
   lines  = self.VV1mxT(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VVI7B0 = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVzDyr(lines, headerRepl, widths, VVI7B0)
  if not allOK:
   lines = FF94gP(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFddC4(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVlfrr:
     note = "\n%s" % FFY7FT("Green = Mounted Partitions", VVlfrr)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVzCWu
     elif line.endswith(mountList) : color = VVlfrr
     else       : color = VVBh5X
     txt += FFY7FT(line, color) + "\n"
    FFyv2f(self, txt + note)
   else:
    FFa349(self, "Not data from system !")
 def VVcihd(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VV1mxT(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVI7B0 = (LEFT , CENTER, LEFT )
  allOK = self.VVzDyr(lines, headerRepl, widths, VVI7B0)
  if not allOK:
   FFYpRN(self, cmd)
 def VVeomH(self):
  cmd = FFrkEH(VVcsXy, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFYpRN(self, cmd)
  else : FFPsN3(self)
 def VVsE3K(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFYpRN(self, cmd)
 def VVNsz9(self):
  cmd = FFrkEH(VVwD6Q, "| grep secondstage")
  if cmd : FFYpRN(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFPsN3(self)
 def VVCXu1(self):
  c = VVlfrr
  VV6fdw = []
  VV6fdw.append((FFY7FT("Box Type"  , c), FFY7FT(self.VVyZMz("boxtype").upper(), c)))
  VV6fdw.append((FFY7FT("Board Version", c), FFY7FT(self.VVyZMz("board_revision") , c)))
  VV6fdw.append((FFY7FT("Chipset"  , c), FFY7FT(self.VVyZMz("chipset")  , c)))
  VV6fdw.append((FFY7FT("S/N"   , c), FFY7FT(self.VVyZMz("sn")    , c)))
  VV6fdw.append((FFY7FT("Version"  , c), FFY7FT(self.VVyZMz("version")  , c)))
  VVarUF   = []
  VVBbFp = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVBbFp = SystemInfo[key]
     else:
      VVarUF.append((FFY7FT(str(key), VV5cg1), FFY7FT(str(SystemInfo[key]), VV5cg1)))
  except:
   pass
  if VVBbFp:
   VVzvCB = self.VVDPdD(VVBbFp)
   if VVzvCB:
    VVzvCB.sort(key=lambda x: x[0].lower())
    VV6fdw += VVzvCB
  if VVarUF:
   VVarUF.sort(key=lambda x: x[0].lower())
   VV6fdw += VVarUF
  if VV6fdw:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFEM8S(self, None, header=header, VV6fdw=VV6fdw, VVHqY6=widths, VVJmZ8=28, VVimZ8=1)
  else:
   FFyv2f(self, "Could not read info!")
 def VVyZMz(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFFfvw(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVDPdD(self, mbDict):
  try:
   mbList = list(mbDict)
   VV6fdw = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VV6fdw.append((FFY7FT(subject, VVzCWu), FFY7FT(value, VVzCWu)))
  except:
   pass
  return VV6fdw
 def VV74oK(self):
  txt = self.VVecyf("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVecyf("/proc/bus/nim_sockets")
  if not txt: txt = self.VVydVJ()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFyv2f(self, txt)
 def VVydVJ(self):
  txt = ""
  VV5vDG = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VV5vDG("Slot Name" , slot.getSlotName())
     txt += FFY7FT(slotName, VVzCWu)
     txt += VV5vDG("Description"  , slot.getFullDescription())
     txt += VV5vDG("Frontend ID"  , slot.frontend_id)
     txt += VV5vDG("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVecyf(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFFfvw(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFY7FT(line, VVzCWu)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VV6vpx(self):
  major   = pyVersion[0]
  minor   = pyVersion[1]
  micro   = pyVersion[2]
  releaselevel = pyVersion[3]
  serial   = pyVersion[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFyv2f(self, txt)
 @staticmethod
 def VVXDcC():
  def VV5vDG(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VV5vDG(v,0), "/etc/issue.net": VV5vDG(v,1), "/etc/image-version": VV5vDG(v,2)}
  for p1, d in v.items():
   img = CCLeKE.VV35d9(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VV5vDG(v,0), p + "Plugins/": VV5vDG(v,1), VVSVA6: VV5vDG(v,2), VVlZ1l: VV5vDG(v,3)}
  for p1, d in v.items():
   img = CCLeKE.VVC22W(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VV35d9(path, d):
  if fileExists(path):
   txt = FFqXAw(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VVC22W(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CCrx0K(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFXh6Y(VV2F6v, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVW1xb = []
  VVW1xb.append(("Settings (All)"   , "Settings_All"   ))
  VVW1xb.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVW1xb.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVW1xb.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVW1xb.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVW1xb.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVW1xb.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VV5W0y:
   VVW1xb.append(VVswUs)
   VVW1xb.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVW1xb.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FFwLhV(self, VVW1xb=VVW1xb)
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FFKauM(self["myMenu"])
  FFVUwm(self)
 def VVi1M6(self):
  global VVdxhd
  VVdxhd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %ssettings" % VVLOHV
   grep = " | grep "
   if   item == "Settings_All"   : FFYpRN(self, cmd)
   elif item == "Settings_HotKeys"  : FFYpRN(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'")
   elif item == "Settings_ajp"   : FFYpRN(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME)
   elif item == "Settings_FHDG_17"  : FFYpRN(self, cmd + grep + "'config.plugins.setupGlass17.'")
   elif item == "Settings_Tuner_DiSEqC": FFYpRN(self, cmd + grep + "'config.Nims.'")
   elif item == "Settings_Plugins"  : FFYpRN(self, cmd + grep + "'.plugins.\|config.TS'")
   elif item == "Settings_Usage"  : FFYpRN(self, cmd + grep + "'.usage.'")
   elif item == "Settings_TimeZone" : FFYpRN(self, cmd + grep + "'.timezone.'")
   elif item == "Settings_Skin"  : FFYpRN(self, cmd + grep + "'.skin.'")
   else        : self.close()
class CCaICB(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFXh6Y(VV2F6v, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVnqWY, VVEG0E, VVEfyR, camCommand = CCaICB.VVW8ne()
  self.VVEG0E = VVEG0E
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VVEG0E:
   c = VVTMjp if VVEfyR else VVW6qu
   if   "oscam" in VVEG0E : camName, oC = "OSCam", c
   elif "ncam"  in VVEG0E : camName, nC = "NCam" , c
  VVW1xb = []
  VVW1xb.append(("OSCam Files" , "OSCamFiles" ))
  VVW1xb.append(("NCam Files" , "NCamFiles" ))
  VVW1xb.append(("CCcam Files" , "CCcamFiles" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append((VVJ2KG + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VVesow" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVW1xb.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVW1xb.append(VVswUs)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  if VVEG0E: VVW1xb.append((c + txt  , "camInfo" ))
  else  : VVW1xb.append((txt  ,    ))
  VVW1xb.append(VVswUs)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VVEG0E:
   for item in camLst: VVW1xb.append(item)
  else:
   for item in camLst: VVW1xb.append((item[0], ))
  FFwLhV(self, VVW1xb=VVW1xb)
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FFKauM(self["myMenu"])
  FFVUwm(self)
 def VVi1M6(self):
  global VVdxhd
  VVdxhd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CCiaxe, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CCiaxe, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CCiaxe, "cccam"))
   elif item == "VVesow" : self.VVesow()
   elif item == "OSCamReaders"  : self.VVyMbi("os")
   elif item == "NSCamReaders"  : self.VVyMbi("n")
   elif item == "camInfo"   : FF1WOg(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CCaICB.VVqnxT(self.session, CC8nsk.VVClxL)
   elif item == "camLiveReaders" : CCaICB.VVqnxT(self.session, CC8nsk.VVXr9L)
   elif item == "camLiveLog"  : CCaICB.VVqnxT(self.session, CC8nsk.VVnLJ4)
   else       : self.close()
 def VVesow(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VVCkxr, FFJCyp())
  if fileExists(path):
   lines = FFFfvw("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VV5vDG = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VV5vDG("label"    , "CCcam-Line-%d" % ndx))
      f.write(VV5vDG("description"  , "CCcam-Line-%d" % ndx))
      f.write(VV5vDG("protocol"   , "cccam"))
      f.write(VV5vDG("device"    , "%s,%s" % (host, port)))
      f.write(VV5vDG("user"    , User))
      f.write(VV5vDG("password"   , Pass))
      f.write(VV5vDG("fallback"   , "1"))
      f.write(VV5vDG("group"    , "64"))
      f.write(VV5vDG("cccversion"   , "2.3.2"))
      f.write(VV5vDG("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FF5nWa(self, "Output = %d Reader%s in:\n\n%s" % (tot, FFmJCK(tot), outFile))
   else:
    FF1ojr(self, "No valid CCcam lines", 1500)
  else:
   FF1ojr(self, "%s not found" % path, 1500)
 def VVyMbi(self, camPrefix):
  VVuV68 = self.VVftz8(camPrefix)
  if VVuV68:
   VVuV68.sort(key=lambda x: int(x[0]))
   if self.VVEG0E and self.VVEG0E.startswith(camPrefix):
    VVsTsL = ("Toggle State", self.VVIvmS, [camPrefix], "Changing State ...")
   else:
    VVsTsL = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVI7B0  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFEM8S(self, None, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26, VVsTsL=VVsTsL, VVhmtx=True)
 def VVftz8(self, camPrefix):
  readersFile = self.VVnqWY + camPrefix + "cam.server"
  VVuV68 = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFFfvw(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVuV68.append((str(len(VVuV68) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVuV68:
    FFa349(self, "No readers found !")
  else:
   FFRYkM(self, readersFile)
  return VVuV68
 def VVIvmS(self, VVXOwS, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVnqWY, camPrefix)
  readerState  = VVXOwS.VVRuNe(1)
  readerLabel  = VVXOwS.VVRuNe(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCaICB.VVPKav(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVXOwS.VVwDYX()
    FFa349(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVuV68 = self.VVftz8(camPrefix)
   if VVuV68:
    VVXOwS.VVOFDI(VVuV68)
  else:
   VVXOwS.VVwDYX()
 @staticmethod
 def VVPKav(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFFfvw(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFa349(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFa349(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFRYkM(SELF, confFile)
   return None
  if not iRequest:
   FFa349(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CCaICB.VVYcTc(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FFa349(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VVYcTc(SELF):
  if iElem:
   return True
  else:
   FFa349(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVqnxT(session, VVrawK):
  VVnqWY, VVEG0E, VVEfyR, camCommand = CCaICB.VVW8ne()
  if VVEG0E:
   runLog = False
   if   VVrawK == CC8nsk.VVClxL : runLog = True
   elif VVrawK == CC8nsk.VVXr9L : runLog = True
   elif not VVEfyR          : FFsXs9(session, message="SoftCam not started yet!")
   elif fileExists(VVEfyR)        : runLog = True
   else             : FFsXs9(session, message="File not found !\n\n%s" % VVEfyR)
   if runLog:
    session.open(BF(CC8nsk, VVnqWY=VVnqWY, VVEG0E=VVEG0E, VVEfyR=VVEfyR, VVrawK=VVrawK))
  else:
   FFsXs9(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VVW8ne():
  VVnqWY = "/etc/tuxbox/config/"
  VVEG0E = None
  VVEfyR  = None
  camCommand = FFyJfo("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VVEG0E = "oscam"
   elif camCmd.startswith("ncam") : VVEG0E = "ncam"
  if VVEG0E:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FFqXAw(path), IGNORECASE)
     if span:
      VVnqWY = FFnWu0(span.group(1))
      break
   else:
    path = FFyJfo(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FFnWu0(path)
    if pathExists(path):
     VVnqWY = path
   tFile = FFnWu0(VVnqWY) + VVEG0E + ".conf"
   tFile = FFyJfo("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VVEfyR = tFile
  return VVnqWY, VVEG0E, VVEfyR, camCommand
class CCiaxe(Screen):
 def __init__(self, VV9wrB, session, args=0):
  self.skin, self.skinParam = FFXh6Y(VV2F6v, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVnqWY, VVEG0E, VVEfyR, camCommand = CCaICB.VVW8ne()
  if   VV9wrB == "ncam" : self.prefix = "n"
  elif VV9wrB == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVW1xb = []
  if self.prefix == "":
   VVW1xb.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVW1xb.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVW1xb.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVW1xb.append(("constant.cw"         , "x_constant_cw" ))
   VVW1xb.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVW1xb.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVW1xb.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVW1xb.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVW1xb.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVW1xb.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVW1xb.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVW1xb.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVW1xb.append(VVswUs)
   VVW1xb.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVW1xb.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVW1xb.append(VVswUs)
   VVW1xb.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVW1xb.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVW1xb.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFwLhV(self, VVW1xb=VVW1xb)
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FFKauM(self["myMenu"])
  FFVUwm(self)
 def VVi1M6(self):
  global VVdxhd
  VVdxhd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFxRdc(self, "/var/etc/CCcam.cfg")
   elif item == "c_ecm_info"  : FFxRdc(self, "/tmp/ecm.info")
   elif item == "x_AutoRoll_Key" : FFxRdc(self, self.VVnqWY + "AutoRoll.Key")
   elif item == "x_constant_cw" : FFxRdc(self, self.VVnqWY + "constant.cw")
   elif item == "x_cam_ccache"  : self.VVoeqM("cam.ccache")
   elif item == "x_cam_conf"  : self.VVoeqM("cam.conf")
   elif item == "x_cam_dvbapi"  : self.VVoeqM("cam.dvbapi")
   elif item == "x_cam_provid"  : self.VVoeqM("cam.provid")
   elif item == "x_cam_server"  : self.VVoeqM("cam.server")
   elif item == "x_cam_services" : self.VVoeqM("cam.services")
   elif item == "x_cam_srvid2"  : self.VVoeqM("cam.srvid2")
   elif item == "x_cam_user"  : self.VVoeqM("cam.user")
   elif item == "x_VVI8D8"   : pass
   elif item == "x_SoftCam_Key" : self.VVUVtl()
   elif item == "x_CCcam_cfg"  : FFxRdc(self, self.VVnqWY + "CCcam.cfg")
   elif item == "x_VVI8D8"   : pass
   elif item == "x_cam_log"  : FFxRdc(self, pathTmp + self.prefix + "cam.log")
   elif item == "x_cam_log_prev" : FFxRdc(self, pathTmp + self.prefix + "cam.log-prev")
   elif item == "x_cam_pid"  : FFxRdc(self, pathTmp + self.prefix + "cam.pid")
   else       : self.close()
 def VVoeqM(self, fileName):
  FFxRdc(self, self.VVnqWY + self.prefix + fileName)
 def VVUVtl(self):
  path = self.VVnqWY + "SoftCam.Key"
  if fileExists(path) : FFxRdc(self, path)
  else    : FFxRdc(self, path.replace(".Key", ".key"))
class CC8nsk(Screen):
 VVClxL  = 0
 VVXr9L = 1
 VVnLJ4 = 2
 def __init__(self, session, VVnqWY="", VVEG0E="", VVEfyR="", VVrawK=VVClxL):
  self.skin, self.skinParam = FFXh6Y(VVnxJO, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVEfyR   = VVEfyR
  self.VVrawK  = VVrawK
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVnqWY + VVEG0E + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVEG0E : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVnqWY, self.camPrefix)
  if self.VVrawK == self.VVClxL:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVrawK == self.VVXr9L:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFwLhV(self, self.Title, addScrollLabel=True)
  FFxDER(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVi99f
  self.onShown.append(self.VVfcAc)
  self.onClose.append(self.onExit)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  self["myLabel"].VVYV4X(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFvDt2(self)
  self.VVi99f()
 def onExit(self):
  self.timer.stop()
 def VVMH0G(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVnx8i)
  except:
   self.timer.callback.append(self.VVnx8i)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FF1ojr(self, "Started", 1000)
 def VVyYeQ(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVnx8i)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FF1ojr(self, "Stopped", 1000)
 def VVi99f(self):
  if self.timerRunning:
   self.VVyYeQ()
  else:
   self.VVMH0G()
   if self.VVrawK == self.VVClxL or self.VVrawK == self.VVXr9L:
    if self.VVrawK == self.VVClxL : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCaICB.VVPKav(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFWlvR(self.VVKPwo)
    else:
     self.close()
   else:
    self.VVuyX8()
 def VVnx8i(self):
  if self.timerRunning:
   if   self.VVrawK == self.VVClxL : self.VVh5JA()
   elif self.VVrawK == self.VVXr9L : self.VVh5JA()
   else            : self.VVuyX8()
 def VVuyX8(self):
  if fileExists(self.VVEfyR):
   fTime = FFXtJp(os.path.getmtime(self.VVEfyR))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVSWo7(), VVpV1e=VVnJeb)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVEfyR)
 def VVKPwo(self):
  self.VVh5JA()
 def VVh5JA(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFY7FT("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VV9ZlA))
   self.camWebIfErrorFound = True
   self.VVyYeQ()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVrawK == self.VVClxL : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFY7FT("Error while parsing data elements !\n\nError = %s" % str(e), VVAgOb)
   self.camWebIfErrorFound = True
   self.VVyYeQ()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VV9GQC(root)
  self["myLabel"].setText(txt, VVpV1e=VVnJeb)
  self["myBar"].setText("Last Update : %s" % FFIDlG())
 def VV9GQC(self, rootElement):
  def VV5vDG(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVrawK == self.VVClxL:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFY7FT(status, VVlfrr)
    else          : status = FFY7FT(status, VVAgOb)
    txt += VVI8D8 + "\n"
    txt += VV5vDG("Name"  , name)
    txt += VV5vDG("Description" , desc)
    txt += VV5vDG("IP/Port"  , "%s : %s" % (ip, port))
    txt += VV5vDG("Protocol" , protocol)
    txt += VV5vDG("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFY7FT("Yes", VVlfrr)
    else    : enabTxt = FFY7FT("No", VVAgOb)
    txt += VVI8D8 + "\n"
    txt += VV5vDG("Label"  , label)
    txt += VV5vDG("Protocol" , protocol)
    txt += VV5vDG("Enabled" , enabTxt)
  return txt
 def VVSWo7(self):
  lines = FF94gP("tail -n %d %s" % (100, self.VVEfyR))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VVPpUd + line[:19] + VVBh5X + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VVuULh + "WebIf" + VVBh5X)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VV5cg1 + h1 + h2 + VVBh5X + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VVlfrr + span.group(2) + VVJ2KG + span.group(3) + VVBh5X + span.group(4)
    line = self.VV42aV(line, VVJ2KG, ("(webif)", ))
    line = self.VV42aV(line, VVJ2KG, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VV42aV(line, VVlfrr, ("OSCam", "NCam", "log switched"))
    line = self.VV42aV(line, VV6yYu, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVzCWu + line[ndx + 3:] + VVBh5X
   elif line.startswith("----") or ">>" in line:
    line = FFY7FT(line, VV0Duj)
   txt += line + "\n"
  return txt
 def VV42aV(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVBh5X + t3
  return line
class CCaEH2(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFXh6Y(VV2F6v, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVW1xb = []
  VVW1xb.append(("Backup Channels"    , "VVw1E8"   ))
  VVW1xb.append(("Restore Channels"    , "Restore_Channels"  ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Backup SoftCAM Files"   , "VVo5Jp" ))
  VVW1xb.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVW1xb.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVW1xb.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Backup Network Settings"  , "VVLoMY"   ))
  VVW1xb.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VV5W0y:
   VVW1xb.append(VVswUs)
   VVW1xb.append((VV9ZlA + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VVyqgj"   ))
   VVW1xb.append((VVlfrr + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VV15XO) , "createMyIpk"   ))
   VVW1xb.append((VVlfrr + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VV15XO) , "createMyDeb"   ))
   VVW1xb.append((VV5cg1 + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVW1xb.append((VV5cg1 + "Decode %s Crash Report"   % PLUGIN_NAME     , "VVOLHL" ))
  FFwLhV(self, VVW1xb=VVW1xb)
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FFKauM(self["myMenu"])
  FFVUwm(self)
 def VVi1M6(self):
  global VVdxhd
  VVdxhd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVw1E8"    : self.VVw1E8()
   elif item == "Restore_Channels"    : self.VVvGpZ("channels_backup*.tar.gz", self.VVow3j, isChan=True)
   elif item == "VVo5Jp"   : self.VVo5Jp()
   elif item == "Restore_SoftCAM_Files"  : self.VVvGpZ("softcam_backup*.tar.gz", self.VVU7Lm)
   elif item == "Backup_TunerDiSEqC"   : self.VVmScY("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVvGpZ("tuner_backup*.backup", BF(self.VVUgnV, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVmScY("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVvGpZ("hotkey_*backup*.backup", BF(self.VVUgnV, "misc"))
   elif item == "VVLoMY"    : self.VVLoMY()
   elif item == "Restore_Network"    : self.VVvGpZ("network_backup*.tar.gz", self.VVy0wU)
   elif item == "VVyqgj"     : FF8XzP(self, BF(FF7Xva, self, BF(CCaEH2.VVyqgj, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VViU2k(False)
   elif item == "createMyDeb"     : self.VViU2k(True)
   elif item == "createMyTar"     : self.VVBUzY()
   elif item == "VVOLHL"   : self.VVOLHL()
 @staticmethod
 def VVyqgj(SELF):
  OBF_Path = VV0Kjx + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VV0Kjx, VVx2ku, VV15XO)
   if err : FFa349(SELF, err)
   else : FFyv2f(SELF, txt)
  else:
   FFRYkM(SELF, OBF_Path)
 def VViU2k(self, VV4kar):
  OBF_Path = VV0Kjx + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFa349(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VV0Kjx)
  os.system("mv -f %s %s" % (VV0Kjx + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VV0Kjx + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VV0Kjx + "plugin.py"))
  self.session.openWithCallback(self.VVBYeo, BF(CCMxVV, path=VV0Kjx, VV4kar=VV4kar))
 def VVBYeo(self):
  os.system("mv -f %s %s" % (VV0Kjx + "OBF/main.py"  , VV0Kjx))
  os.system("mv -f %s %s" % (VV0Kjx + "OBF/plugin.py" , VV0Kjx))
 def VVOLHL(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFa349(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFa349(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VV4PB3("%s*.list" % path)
  if err:
   FFRYkM(self, path + "*.list")
   return
  srcF, err = self.VV4PB3("%s*main_final.py" % path)
  if err:
   FFRYkM(self, path + "*.final.py")
   return
  VV6fdw = []
  for f in files:
   f = os.path.basename(f)
   VV6fdw.append((f, f))
  FFLFXy(self, BF(self.VVDdU3, path, codF, srcF), VVW1xb=VV6fdw)
 def VVDdU3(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFRYkM(self, logF)
   else     : FF7Xva(self, BF(self.VV7NF4, logF, codF, srcF))
 def VV7NF4(self, logF, codF, srcF):
  lst  = []
  lines = FFFfvw(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFa349(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVgcdj(lst, logF, newLogF)
  totSrc  = self.VVgcdj(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFyv2f(self, txt)
 def VV4PB3(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVgcdj(self, lst, f1, f2):
  txt = FFqXAw(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVBUzY(self):
  VV6fdw = []
  VV6fdw.append("%s%s" % (VV0Kjx, "*.py"))
  VV6fdw.append("%s%s" % (VV0Kjx, "*.png"))
  VV6fdw.append("%s%s" % (VV0Kjx, "*.xml"))
  VV6fdw.append("%s"  % (VV9dcF))
  FFP17E(self, VV6fdw, "%s_%s" % (PLUGIN_NAME, VVx2ku), addTimeStamp=False)
 def VVw1E8(self):
  path1 = VVLOHV
  path2 = "/etc/tuxbox/"
  VV6fdw = []
  VV6fdw.append("%s%s" % (path1, "*.tv"))
  VV6fdw.append("%s%s" % (path1, "*.radio"))
  VV6fdw.append("%s%s" % (path1, "*list"))
  VV6fdw.append("%s%s" % (path1, "lamedb*"))
  VV6fdw.append("%s%s" % (path2, "*.xml"))
  FFP17E(self, VV6fdw, self.VV1srf("channels_backup"), addTimeStamp=True)
 def VVo5Jp(self):
  VV6fdw = []
  VV6fdw.append("/etc/tuxbox/config/")
  VV6fdw.append("/usr/keys/")
  VV6fdw.append("/usr/scam/")
  VV6fdw.append("/etc/CCcam.cfg")
  FFP17E(self, VV6fdw, self.VV1srf("softcam_backup"), addTimeStamp=True)
 def VVLoMY(self):
  VV6fdw = []
  VV6fdw.append("/etc/hostname")
  VV6fdw.append("/etc/default_gw")
  VV6fdw.append("/etc/resolv.conf")
  VV6fdw.append("/etc/wpa_supplicant*.conf")
  VV6fdw.append("/etc/network/interfaces")
  VV6fdw.append("%snameserversdns.conf" % VVLOHV)
  FFP17E(self, VV6fdw, self.VV1srf("network_backup"), addTimeStamp=True)
 def VV1srf(self, fName):
  img = CCLeKE.VVXDcC()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VVow3j(self, fileName=None):
  if fileName:
   FF8XzP(self, BF(FF7Xva, self, BF(self.VVTRHn, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VVTRHn(self, fileName):
  path = "%s%s" % (VVCkxr, fileName)
  if fileExists(path):
   if CCbI7Z.VVEdXH(path):
    VVekD9 , VVRLP2 = CCyEBX.VVeusg()
    VVpHHH, VVWlUh = CCyEBX.VVWncM()
    cmd  = FFQe93("cd %s" % VVLOHV) + ";"
    cmd += FFQe93("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VVRLP2, VVWlUh))+ ";"
    cmd += "tar -xzf '%s' -C /" % path
    res = os.system(cmd)
    FFNh5K()
    if res == 0 : FF5nWa(self, "Channels Restored.")
    else  : FFa349(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FFa349(self, "Invalid tar file:\n\n%s" % path)
  else:
   FFRYkM(self, path)
 def VVU7Lm(self, fileName=None):
  if fileName:
   FF8XzP(self, BF(self.VVHRe1, fileName), "Overwrite SoftCAM files ?")
 def VVHRe1(self, fileName):
  fileName = "%s%s" % (VVCkxr, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVI8D8
   note = "You may need to restart your SoftCAM."
   FFDbYu(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFfLXZ(note, VVzCWu), sep))
  else:
   FFRYkM(self, fileName)
 def VVy0wU(self, fileName=None):
  if fileName:
   FF8XzP(self, BF(self.VVwgbU, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVwgbU(self, fileName):
  fileName = "%s%s" % (VVCkxr, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFsZIz(self,  cmd)
  else:
   FFRYkM(self, fileName)
 def VVvGpZ(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FFwHka()
  if pathExists(VVCkxr):
   myFiles = FFKZAp(VVCkxr, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VV6fdw = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VV6fdw.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VV0vau = ("Sat. List", self.VVcjfM)
    elif isChan and iTar: VV0vau = ("Bouquets Importer", CCchNl.VVhgJB)
    else    : VV0vau = None
    FFLFXy(self, callBackFunction, title=title, width=1200, VVW1xb=VV6fdw, VV0vau=VV0vau, yellowBasePath=VVCkxr)
   else:
    FFa349(self, "No files found in:\n\n%s" % VVCkxr, title)
  else:
   FFa349(self, "Path not found:\n\n%s" % VVCkxr, title)
 def VVmScY(self, filePrefix, wordsFilter):
  settingFile = "%ssettings" % VVLOHV
  tCons = CCXype()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), BF(self.VVrq4R, filePrefix))
 def VVrq4R(self, filePrefix, result, retval):
  title = FFwHka()
  if pathExists(VVCkxr):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFa349(self, "Cannot read settings file", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVCkxr, filePrefix, self.VV1srf(""), FFJCyp())
    try:
     VV6fdw = str(result.strip()).split()
     if VV6fdw:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VV6fdw:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVI8D8, FFY7FT(fName, VVzCWu), VVI8D8)
       FFyv2f(self, txt, title=title, VVpV1e=VVnJeb)
      else:
       FFa349(self, "File creation failed!", title)
     else:
      FFa349(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFQe93("rm %s" % fName))
     FFa349(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFQe93("rm %s" % fName))
     FFa349(self, "Error while writing file.")
  else:
   FFa349(self, "Path not found:\n\n%s" % VVCkxr, title)
 def VVUgnV(self, mode, path=None):
  if path:
   path = "%s%s" % (VVCkxr, path)
   if fileExists(path):
    lines = FFFfvw(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FF8XzP(self, BF(self.VVVoJc, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFRjyo(self, path, title=FFwHka())
   else:
    FFRYkM(self, path)
 def VVVoJc(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  isVTi = pathExists(VVSVA6 + "VTIPanel")
  finalList = []
  for line in newList:
   if line.strip() and not line in finalList:
    if isVTi and ".dvbs." in line: pass
    else       : finalList.append(line)
  VVKINn = []
  sFile = "/etc/enigma2/settings"
  tFile = "/tmp/ajp_tmp"
  VVKINn.append("echo -e 'Reading current settings ...'")
  VVKINn.append("cat %s | grep -v '%s' > %s" % (sFile, grepFilter, tFile))
  settingsLines = "echo -e '"
  for line in finalList:
   settingsLines += line
  settingsLines = settingsLines.strip()
  settingsLines += "' >> %s" % tFile
  VVKINn.append("echo -e 'Preparing new settings ...'")
  VVKINn.append(settingsLines)
  VVKINn.append("echo -e 'Applying new settings ...'")
  VVKINn.append("mv -f %s %s" % (tFile, sFile))
  FFNdGr(self, VVKINn)
 def VVcjfM(self, VVlAViObj, path):
  if not path:
   return
  path = VVCkxr + path
  if not fileExists(path):
   FFRYkM(self, path)
   return
  txt = FFqXAw(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   txt = ""
   for item in satList:
    txt += "%s\t%s\n" % (item[0], FFvD21(item[1]))
   FFyv2f(self, txt, title="Satellites List")
  else:
   FFa349(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCchNl():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VVhgJB(SELF, fName):
  bi = CCchNl(SELF)
  bi.instance = bi
  bi.VVdvVv(SELF, fName)
 @staticmethod
 def VVdlUE(SELF):
  bi = CCchNl(SELF)
  bi.instance = bi
  bi.VVtHF7()
 def VVdvVv(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VVCkxr + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FF7Xva(waitObg, self.VVNPbJ, title="Reading bouquets ...")
  else      : self.VVpPUZ(self.filePath)
 def VVYjXn(self, txt) : FFa349(self.SELF, txt, title=self.Title)
 def VVik2e(self, txt)  : FF1ojr(self, txt, 1500)
 def VVpPUZ(self, path) : FFRYkM(self.SELF, path, title=self.Title)
 def VVtHF7(self):
  if pathExists(VVCkxr):
   lst = FFKZAp(VVCkxr, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VVg2oF())
   if len(lst) > 0:
    VVW1xb = []
    for item in lst:
     item = os.path.basename(item)
     txt = FFY7FT(item, VVJ2KG) if item.endswith(".zip") else item
     VVW1xb.append((txt, item))
    VVW1xb.sort(key=lambda x: x[1].lower())
    OKBtnFnc = self.VVvpEB
    FFLFXy(self.SELF, self.VVDfYd, minRows=3, title=self.Title, width=1200, VVW1xb=VVW1xb, OKBtnFnc=OKBtnFnc, yellowBasePath=VVCkxr, VVgchu="#22111111", VVn4Mh="#22111111")
   else:
    self.VVYjXn("No valid backup files found in:\n\n%s" % VVCkxr)
  else:
   self.VVYjXn("Backup Directory not found:\n\n%s" % VVCkxr)
 def VVvpEB(self, item=None):
  if item:
   menuInstance, txt, fName, ndx = item
   self.VVdvVv(menuInstance, fName)
 def VVDfYd(self, item=None):
  if not item and self.instance:
   del self.instance
 def VVg2oF(self):
  files = FFKZAp(VVCkxr, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VVNPbJ(self):
  lines, err = CCchNl.VVm51H(self.filePath, "bouquets.tv")
  if err:
   self.VVYjXn(err)
   return
  bTvSortLst  = self.VVToG0(lines)
  lines, err = CCchNl.VVm51H(self.filePath, "bouquets.radio")
  if err:
   self.VVYjXn(err)
   return
  bRadSortLst = self.VVToG0(lines)
  VVuV68 = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VVhSYt(f, mode, len(VVuV68), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VVuV68.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VVhSYt(f, mode, len(VVuV68), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VVhSYt(f, mode, len(VVuV68), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VVuV68.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VVhSYt(f, mode, len(VVuV68), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VVuV68:
   VVuV68.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VVuV68): VVuV68[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VVuV68):
     if key == os.path.basename(row[9]):
      VVuV68 = VVuV68[:ndx+1] + lst + VVuV68[ndx+1:]
      break
   for ndx, item in enumerate(VVuV68): VVuV68[ndx][0] = str(ndx + 1)
   VVMqKH = "#11000600"
   VVVi12  = ("Show Services" , self.VVdLFe  , [], "Reading ..." )
   VVd4CR = (""    , self.VVqvGO, [])
   VVQR2V = ("Options"  , self.VV3w62, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "S.Relay" , "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 36   , 7  , 7   , 7  , 7  , 7   , 7   , 7   , 8   ,  0.01 )
   VVI7B0  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER , CENTER ,  LEFT )
   FFEM8S(self.SELF, None, title=self.Title, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=24, VVVi12=VVVi12, VVd4CR=VVd4CR, VVQR2V=VVQR2V, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVgchu=VVMqKH, VVn4Mh=VVMqKH, VVMqKH=VVMqKH, VVKhj2="#11ffffff", VVntre="#00004455", VV3VhT="#0a282828")
  else:
   self.VVYjXn("No valid bouquets in:\n\n%s" % self.filePath)
 def VVToG0(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VVqvGO(self, VVXOwS, title, txt, colList):
  FFyv2f(self.SELF, FFyZAn(txt), title=title)
 def VV3w62(self, VVXOwS, title, txt, colList):
  mSel = CCTHuN(self.SELF, VVXOwS)
  if VVXOwS.VVyKav:
   totSel = VVXOwS.VVYRl7()
   if totSel: VVW1xb = [("Import %s Bouquet%s" % (FFY7FT(str(totSel), VVlfrr), FFmJCK(totSel)), "imp")]
   else  : VVW1xb = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FFY7FT(bName, VVlfrr)
   VVW1xb = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FF7Xva, VVXOwS, BF(CCchNl.VVdgw2, self.SELF, VVXOwS, self.filePath))}
  mSel.VVoxj8(VVW1xb, cbFncDict)
 def VVdLFe(self, VVXOwS, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CCchNl.VVm51H(self.filePath, "lamedb")
   if err:
    self.VVYjXn(err)
    return
   dbServLst = CCyEBX.VVuYd1(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName = VVXOwS.VVsaDG()
   lines, err = CCchNl.VVm51H(self.filePath, os.path.basename(fName))
   if err:
    self.VVYjXn(err)
    return
   VVuV68 = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VVuV68.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VVuV68.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VVuV68.append((span.group(1).strip() or "-", "Stream Relay" if FFTxso(line) else "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VVuV68.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VVuV68.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CCyEBX.VV8qP6(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VVuV68.append((name.strip() or "-", FFP3va(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VVuV68):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CCchNl.VVm51H(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VVuV68[ndx] = (bName, descr)
   if VVuV68:
    VVMqKH = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VVI7B0 = (LEFT  , CENTER)
    FFEM8S(self.SELF, None, title="Services in : %s" % bName, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=28, VVgchu=VVMqKH, VVn4Mh=VVMqKH, VVMqKH=VVMqKH, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FF1ojr(VVXOwS, err, 1500)
  else : VVXOwS.VVwDYX()
 def VVhSYt(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totSRelay = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VVYjXn("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif FFTxso(line)             : totSRelay += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VVObU9(var):
   return str(var) if var else VVQasA + str(var)
  totItem = VVzCWu + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VV9ZlA   , str(totBnb)
  elif isSubB : bColor, totBnb  = VVJ2KG, "Sub-B."
  else  : bColor, totBnb = ""      , VVObU9(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VVObU9(totDVB), VVObU9(totIptv), VVObU9(totSRelay), VVObU9(totLoc), VVObU9(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VVdgw2(SELF, VVXOwS, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVLOHV + "bouquets.tv"
  radBouquetFile = VVLOHV + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FFRYkM(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FFRYkM(SELF, radBouquetFile, title=title)
   return
  isMulti = VVXOwS.VVyKav
  if isMulti : rows = VVXOwS.VVqVcu()
  else  : rows = [VVXOwS.VVsaDG()]
  for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FFa349(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FFyZAn(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FFyZAn(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVLOHV + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVLOHV + newFile
    CCchNl.VVX936(archPath, fName, VVLOHV, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   CCRtNz.VVC8zY(tvBouquetFile)
   CCRtNz.VVC8zY(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CCchNl.VVzXbM(SELF, archPath, bList)
   FFNh5K()
  txt  = FFY7FT("Added:\n", VVJ2KG)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FFY7FT("Imported to lamedab:\n", VVJ2KG)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FFY7FT("Missing from archived lamedb:\n", VV9ZlA)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FFyv2f(SELF, txt, title=title, width=1000)
 @staticmethod
 def VVzXbM(SELF, archPath, bList):
  VVekD9, err = CCyEBX.VVDJAJ(SELF, VVvSQT=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CCyEBX.VVK2WE(VVekD9, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FFFfvw(VVLOHV + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CCyEBX.VV8qP6(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CCyEBX.VVBDw2(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CCchNl.VVRAgR(archPath, dbName)
   CCchNl.VVX936(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CCyEBX.VVK2WE(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CCyEBX.VVK2WE(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CCyEBX.VVK2WE(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CCyEBX.VVK2WE(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FFGWxS(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VVekD9 + ".tmp"
   lines   = FFFfvw(VVekD9)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   os.system(FFQe93("mv -f '%s' '%s'" % (tmpDbFile, VVekD9)))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VVcb7l(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VVRAgR(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VVX936(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VVm51H(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CCZSFD(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFXh6Y(VV2F6v, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVW1xb = []
  VVW1xb.append(("Plugins Browser List"       , "VVfVUX"  ))
  VVW1xb.append(("Plugins Additional Menus"      , "pluginsMenus"   ))
  VVW1xb.append(("Startup Plugins"        , "pluginsStartup"   ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Extensions and System Plugins"    , "pluginsDirList"   ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Download/Install Packages (from image feeds)" , "downloadInstallPackages" ))
  VVW1xb.append(("Remove Packages (show all)"     , "VVOtIHsAll"  ))
  VVW1xb.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Update Packages List from Feed"    , "VVKUPH"  ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Packaging Tool"        , "VVTSoy"   ))
  VVW1xb.append(("Packages Feeds"        , "packagesFeeds"   ))
  FFwLhV(self, VVW1xb=VVW1xb)
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FFKauM(self["myMenu"])
  FFVUwm(self)
 def VVi1M6(self):
  global VVdxhd
  VVdxhd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVfVUX"   : self.VVfVUX()
   elif item == "pluginsMenus"     : self.VVRyJi(0)
   elif item == "pluginsStartup"    : self.VVRyJi(1)
   elif item == "pluginsDirList"    : self.VV9KG0()
   elif item == "downloadInstallPackages"  : FF7Xva(self, BF(self.VVtKii, 0, ""))
   elif item == "VVOtIHsAll"   : FF7Xva(self, BF(self.VVtKii, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FF7Xva(self, BF(self.VVtKii, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVKUPH"   : CCZSFD.VVKUPH(self)
   elif item == "VVTSoy"    : self.VVTSoy()
   elif item == "packagesFeeds"    : self.VVSkAx()
   else          : self.close()
 def VV9KG0(self):
  extDirs  = FFMVgU(VVlZ1l)
  sysDirs  = FFMVgU(VVSVA6)
  VV6fdw  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VV6fdw.append((item, VVlZ1l + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VV6fdw.append((item, VVSVA6 + item))
  if VV6fdw:
   VV6fdw.sort(key=lambda x: x[0].lower())
   VVQR2V = ("Package Info.", self.VVTflZ, [])
   VVmmwr = ("Open in File Manager", BF(self.VVprOD, 1), [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFEM8S(self, None, header=header, VV6fdw=VV6fdw, VVHqY6=widths, VVJmZ8=28, VVQR2V=VVQR2V, VVmmwr=VVmmwr)
  else:
   FFa349(self, "Nothing found!")
 def VVTflZ(self, VVXOwS, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVlZ1l) : loc = "extensions"
  elif path.startswith(VVSVA6) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVig9v(package)
  else:
   FFa349(self, "No info!")
 def VVSkAx(self):
  pkg = FFvwHi()
  if pkg : FFYpRN(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFPsN3(self)
 def VVfVUX(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VV5vDG(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVI8D8 + "\n"
    txt += VV5vDG("Number"   , str(c))
    txt += VV5vDG("Name"   , FFY7FT(str(p.name), VVzCWu))
    txt += VV5vDG("Path"  , p.path  )
    txt += VV5vDG("Description" , p.description )
    txt += VV5vDG("Icon"  , p.iconstr  )
    txt += VV5vDG("Wakeup Fnc" , p.wakeupfnc )
    txt += VV5vDG("NeedsRestart", p.needsRestart)
    txt += VV5vDG("Internal" , p.internal )
    txt += VV5vDG("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFyv2f(self, txt)
 def VVRyJi(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VV6fdw = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VV6fdw.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VV6fdw:
   VV6fdw.sort(key=lambda x: x[0].lower())
   VVmmwr = ("Open in File Manager", BF(self.VVprOD, 4), [])
   header   = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths   = (19  , 25 , 20  , 27   , 9  )
   FFEM8S(self, None, title=title, header=header, VV6fdw=VV6fdw, VVHqY6=widths, VVJmZ8=26, VVmmwr=VVmmwr)
  else:
   FFa349(self, "Nothing Found", title=title)
 def VVprOD(self, pathColNum, VVXOwS, title, txt, colList):
  path = colList[pathColNum].strip()
  if pathExists(path) : self.session.open(CCbI7Z, mode=CCbI7Z.VVWYHZ, VVetf7=path)
  else    : FF1ojr(VVXOwS, "Path not found !", 1500)
 @staticmethod
 def VVKUPH(SELF):
  cmd = FFrkEH(VVJknE, "")
  if cmd : FFsZIz(SELF, cmd, checkNetAccess=True)
  else : FFPsN3(SELF)
 def VVTSoy(self):
  pkg = FFvwHi()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FF5nWa(self, txt)
 def VVtKii(self, mode, grep, VVXOwS=None, title=""):
  if   mode == 0: cmd = FFrkEH(VVwD6Q    , grep)
  elif mode == 1: cmd = FFrkEH(VVcsXy , grep)
  elif mode == 2: cmd = FFrkEH(VVcsXy , grep)
  if not cmd:
   FFPsN3(self)
   return
  VVuV68 = FF94gP(cmd)
  if VVuV68:
   err = CCbI7Z.VVPSgD(VVuV68, fromFind=False)
   if err:
    FFa349(self, err)
    return
  else:
   if VVXOwS: VVXOwS.VVwDYX()
   FFa349(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VV6fdw  = []
  for item in VVuV68:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VV6fdw.append((name, package, version))
  if mode > 0:
   extensions = FF94gP("ls %s -l | grep '^d' | awk '{print $9}'" % VVlZ1l)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VV6fdw:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VV6fdw.append((name, VVlZ1l + item, "-"))
   systemPlugins = FF94gP("ls %s -l | grep '^d' | awk '{print $9}'" % VVSVA6)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VV6fdw:
      if item.lower() == row[0].lower():
       break
     else:
      VV6fdw.append((item, VVSVA6 + item, "-"))
  if not VV6fdw:
   FFa349(self, "No packages found!")
   return
  if VVXOwS:
   VV6fdw.sort(key=lambda x: x[0].lower())
   VVXOwS.VVOFDI(VV6fdw, title)
  else:
   widths = (20, 50, 30)
   VVsTsL = None
   VVmmwr = None
   if mode == 0:
    VVQcug = ("Install" , self.VVYwpG   , [])
    VVsTsL = ("Download" , self.VVU0b8   , [])
    VVmmwr = ("Filter"  , self.VVhStE , [])
   elif mode == 1:
    VVQcug = ("Uninstall", self.VVOtIH, [])
   elif mode == 2:
    VVQcug = ("Uninstall", self.VVOtIH, [])
    widths= (18, 57, 25)
   VV6fdw.sort(key=lambda x: x[0].lower())
   VVQR2V = ("Package Info.", self.VVBWi0, [])
   header   = ("Name" ,"Package" , "Version" )
   FFEM8S(self, None, header=header, VV6fdw=VV6fdw, VVHqY6=widths, VVJmZ8=28, VVQcug=VVQcug, VVsTsL=VVsTsL, VVQR2V=VVQR2V, VVmmwr=VVmmwr, VVlMOs=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVgchu="#22110011", VVn4Mh="#22191111", VVMqKH="#22191111", VVntre="#00003030", VV3VhT="#00333333")
 def VVBWi0(self, VVXOwS, title, txt, colList):
  package = colList[1]
  self.VVig9v(package)
 def VVhStE(self, VVXOwS, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVW1xb = []
  VVW1xb.append(("All Packages", "all"))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVW1xb.append(VVswUs)
  for word in words:
   VVW1xb.append((word, word))
  FFLFXy(self, BF(self.VV6QO2, VVXOwS), VVW1xb=VVW1xb, title="Select Filter")
 def VV6QO2(self, VVXOwS, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FF7Xva(VVXOwS, BF(self.VVtKii, 0, grep, VVXOwS, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVOtIH(self, VVXOwS, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVlZ1l, VVSVA6)):
   FF8XzP(self, BF(self.VVKVmV, VVXOwS, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVW1xb = []
   VVW1xb.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVW1xb.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVW1xb.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFLFXy(self, BF(self.VVm6Ek, VVXOwS, package), VVW1xb=VVW1xb)
 def VVKVmV(self, VVXOwS, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVeBpK)
  FFsZIz(self, cmd, VVvcJy=BF(self.VVePHu, VVXOwS))
 def VVm6Ek(self, VVXOwS, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVdbf3
   elif item == "remove_ForceRemove"  : cmdOpt = VVYyAT
   elif item == "remove_IgnoreDepends"  : cmdOpt = VV0w22
   FF8XzP(self, BF(self.VVroNV, VVXOwS, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVroNV(self, VVXOwS, package, cmdOpt):
  self.lastSelectedRow = VVXOwS.VVRJth()
  cmd = FFkjia(cmdOpt, package)
  if cmd : FFsZIz(self, cmd, VVvcJy=BF(self.VVePHu, VVXOwS))
  else : FFPsN3(self)
 def VVePHu(self, VVXOwS):
  VVXOwS.cancel()
  FFppy1()
 def VVYwpG(self, VVXOwS, title, txt, colList):
  package  = colList[1]
  VVW1xb = []
  VVW1xb.append(("Install Package"        , "install_CheckVersion" ))
  VVW1xb.append(("Install Package (force reinstall)"   , "install_ForceReinstall" ))
  VVW1xb.append(("Install Package (force overwrite)"   , "install_ForceOverwrite" ))
  VVW1xb.append(("Install Package (force downgrade)"   , "install_ForceDowngrade" ))
  VVW1xb.append(("Install Package (ignore failed dependencies)" , "install_IgnoreDepends" ))
  FFLFXy(self, BF(self.VVs1UL, package), VVW1xb=VVW1xb)
 def VVs1UL(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVkKCu
   elif item == "install_ForceReinstall" : cmdOpt = VVzgm4
   elif item == "install_ForceOverwrite" : cmdOpt = VVDBBb
   elif item == "install_ForceDowngrade" : cmdOpt = VVd1HZ
   elif item == "install_IgnoreDepends" : cmdOpt = VVVG8q
   FF8XzP(self, BF(self.VVVM2J, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVVM2J(self, package, cmdOpt):
  cmd = FFkjia(cmdOpt, package)
  if cmd : FFsZIz(self, cmd, VVvcJy=FFppy1, checkNetAccess=True)
  else : FFPsN3(self)
 def VVU0b8(self, VVXOwS, title, txt, colList):
  package  = colList[1]
  FF8XzP(self, BF(self.VVcrmD, package), "Download Package ?\n\n%s" % package)
 def VVcrmD(self, package):
  if CCkcR1.VVGFKI():
   cmd = FFkjia(VVXp0Z, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFfLXZ(success, VVlfrr))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFfLXZ(fail, VVAgOb))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFsZIz(self, cmd, VV3RFM=[VVAgOb, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFPsN3(self)
  else:
   FFa349(self, "No internet connection !")
 def VVig9v(self, package):
  infoCmd  = FFkjia(VV1xDE, package)
  filesCmd = FFkjia(VVUWWs, package)
  listInstCmd = FFrkEH(VVcsXy, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFuYac(VVzCWu)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFfLXZ(notInst, VV9ZlA))
   cmd += "else "
   cmd +=   FF6CJ2("System Info", VVzCWu)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FF6CJ2("Related Files", VVzCWu)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFmzjA(self, cmd)
  else:
   FFPsN3(self)
class CCrLEQ():
 def VVRlhs(self, isRef, onlyEpg=False):
  self.shareIsRef   = isRef
  self.onlyEpg   = onlyEpg
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VVJlas()
 def VVJlas(self):
  files = FFKZAp(VVCkxr, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVW1xb = []
   for fil in files:
    VVW1xb.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVgchu, VVn4Mh = "#22221133", "#22221133"
   else    : VVgchu, VVn4Mh = "#22003344", "#22002233"
   VV0vau  = ("Add new File", self.VVanwC)
   FFLFXy(self, self.VVJcQY, VVW1xb=VVW1xb, width=1100, VV0vau=VV0vau, yellowBasePath="", minRows=4, VVgchu=VVgchu, VVn4Mh=VVn4Mh)
  else:
   FF8XzP(self, self.VVRbZB, "No files found.\n\nCreate a new file ?")
 def VVRbZB(self):
  path = self.VVRbP9()
  if fileExists(path) : self.VVJlas()
  else    : FF1ojr(self, "Cannot create file", 1500)
 def VVanwC(self, menuInstance, path):
  path = self.VVRbP9()
  menuInstance.VVw1VR((os.path.basename(path), path), isSort=True)
 def VVRbP9(self):
  path = "%s%s%s.xml" % (VVCkxr, self.shareFilePrefix, FFJCyp())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VVJcQY(self, path=None):
  if path:
   FF7Xva(self, BF(self.VVjAbW, path))
 def VVjAbW(self, path):
  if not fileExists(path):
   FFRYkM(self, path)
   return
  elif not CCbI7Z.VV8ERc(self, path, FFwHka()):
   return
  else:
   self.shareFilePath = path
  if not CCaICB.VVYcTc(self):
   return
  tree = CCyEBX.VVSNpB(self, self.shareFilePath)
  if not tree:
   return
  refLst = CCRtNz.VVzS3E()
  def VV5vDG(refCode):
   if   FFX2Cs(refCode): return FFY7FT("DVB", VVTMjp)
   elif refCode in refLst     : return FFY7FT("IPTV", VVTMjp)
   else         : return ""
  VVuV68= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VV2YD0(ch)
   if ok:
    srcTxt = VV5vDG(srcRef)
    dstTxt = VV5vDG(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VVuV68:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VVuV68.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VVuV68:
   if self.shareIsRef : VVgchu, VVn4Mh, optTxt = "#22221133", "#22221133", "Share Reference"
   else    : VVgchu, VVn4Mh, optTxt = "#1a003344", "#1a002233", "Copy EPG" if self.onlyEpg else "Copy EPG/PIcons"
   VVH2MF = (""    , BF(self.VVRJPC, dupl), [])
   VVd4CR = (""    , self.VVChJe    , [])
   VVQcug = ("Delete Entry" , self.VVOSIO   , [])
   VVsTsL = ("Add Entry"  , self.VVGLIj   , [])
   VVQR2V = (optTxt   , self.VV8LRJ  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VVI7B0 = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVXOwS = FFEM8S(self, None, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=24, VVH2MF=VVH2MF, VVd4CR=VVd4CR, VVQcug=VVQcug, VVsTsL=VVsTsL, VVQR2V=VVQR2V, VVhmtx=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVgchu=VVgchu, VVn4Mh=VVn4Mh, VVMqKH=VVn4Mh, VVKhj2="#00ffffaa", VVntre="#0a000000")
  else:
   FFa349(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VVRJPC(self, dupl, VVXOwS, title, txt, colList):
  if dupl:
   VVXOwS.VVbkCu("Skipped %d duplicate%s" % (dupl, FFmJCK(dupl)), 2000)
 def VVChJe(self, VVXOwS, title, txt, colList):
  def VV5vDG(key, val): return "%s\t: %s\n" % (key, val or FFY7FT("?", VV6yYu))
  Keys = VVXOwS.VVJIaa()
  Vals = VVXOwS.VVsaDG()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VV5vDG(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VVlfrr, VV6yYu
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FFyv2f(self, txt + txt1, title=title)
 def VV2YD0(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VVOSIO(self, VVXOwS, title, txt, colList):
  if VVXOwS.VVRJth() == 0 and VVXOwS.VV9Wh4() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FF8XzP(self, BF(self.VVuNu9, isLast, VVXOwS), ques)
 def VVuNu9(self, isLast, VVXOwS):
  if isLast:
   FFGWxS(self.shareFilePath)
   VVXOwS.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVXOwS.VVsaDG()
   if self.VVFVAk(srcName, srcRef, dstName, dstRef):
    VVXOwS.VVXlip()
    VVXOwS.VVwGhX()
    FF1ojr(VVXOwS, "Deleted", 500, isGrn=True)
   else:
    FF1ojr(VVXOwS, "Cannot delete from file", 2000)
 def VVGLIj(self, VVXOwS, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VVVtUQ(VVXOwS, isDvb=True)
  else    : self.VVulfM(VVXOwS, "Source Channel", "#22003344", "#22002233")
 def VVulfM(self, mainTableInst, title, VVgchu, VVn4Mh):
  FFLFXy(self, BF(self.VVe4l0, mainTableInst, title), VVW1xb=[("DVB", "DVB"), ("IPTV / Stream Relay", "IPTV")], title=title + " Type", width=800, VVgchu=VVgchu, VVn4Mh=VVn4Mh)
 def VVe4l0(self, mainTableInst, title, item=None):
  if item:
   FF7Xva(mainTableInst, BF(self.VV5XuQ, mainTableInst, title, item), clearMsg=False)
 def VV5XuQ(self, mainTableInst, title, item):
  FF1ojr(mainTableInst)
  if item == "DVB": self.VVVtUQ(mainTableInst, isDvb=True)
  else   : self.VVVtUQ(mainTableInst, isDvb=False)
 def VViy5W(self, mainTableInst, chType, VVXOwS, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVXOwS.VVRJth()
  if   chType == "DVB" : FFxMsu(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FFxMsu(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VVWsuW()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FFa349(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VV7rzz(srcName, srcRef, dstName, dstRef):
      mainTableInst.VV5Kna((str(mainTableInst.VV9Wh4() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FF1ojr(mainTableInst, "Added", 500, isGrn=True)
     else:
      FF1ojr(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FF1ojr(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VVVtUQ(mainTableInst, isDvb=False)
   else    : FFWlvR(BF(self.VVulfM, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVXOwS.cancel()
 def VVivHQ(self, item, VVXOwS, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVXOwS.VV9fSx(ndx)
 def VVVtUQ(self, VVXOwS, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VViy5W, VVXOwS, typ)
  doneFnc = BF(self.VVivHQ, typ)
  if isDvb: CCrLEQ.VVusLv(VVXOwS , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CCrLEQ.VVT1gB(VVXOwS, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VVusLv(SELF, title, okFnc, doneFnc=None):
  FF7Xva(SELF, BF(CCrLEQ.VVsSa2, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VVsSa2(SELF, title, okFnc, doneFnc=None):
  VVuV68, err = CCyEBX.VVCZgt(SELF, CCyEBX.VVlqFe)
  if VVuV68:
   color = "#0a000022"
   VVuV68.sort(key=lambda x: x[0].lower())
   VVVi12 = ("Select" , okFnc, [])
   VVH2MF= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VVI7B0 = (LEFT  , LEFT  , CENTER, LEFT    )
   FFEM8S(SELF, None, title=title, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26, VVgchu=color, VVn4Mh=color, VVMqKH=color, VVVi12=VVVi12, VVH2MF=VVH2MF, lastFindConfigObj=CFG.lastFindServices)
  else:
   FFa349(SELF, "No DVB Services !")
 @staticmethod
 def VVT1gB(SELF, title, okFnc, doneFnc=None):
  FF7Xva(SELF, BF(CCrLEQ.VV5D4A, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VV5D4A(SELF, title, okFnc, doneFnc=None):
  VVuV68 = CCrLEQ.VVVlfV()
  if VVuV68:
   color = "#0a112211"
   VVuV68.sort(key=lambda x: x[0].lower())
   VVVi12 = ("Select" , okFnc, [])
   VVH2MF= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FFEM8S(SELF, None, title=title, header=header, VV6fdw=VVuV68, VVHqY6=widths, VVJmZ8=26, VVgchu=color, VVn4Mh=color, VVMqKH=color, VVVi12=VVVi12, VVH2MF=VVH2MF, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFa349(SELF, "No IPTV Services !")
 @staticmethod
 def VVVlfV():
  VVuV68 = []
  files  = CCgg3d.VVROqm()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFqXAw(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVgTOR = span.group(1)
    else : VVgTOR = ""
    VVgTOR_lCase = VVgTOR.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VVuV68.append((chName, VVgTOR, url, refCode))
  return VVuV68
 def VV7rzz(self, srcName, srcRef, dstName, dstRef):
  tree = CCyEBX.VVSNpB(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VV13gY(tree, root)
  return True
 def VVFVAk(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CCyEBX.VVSNpB(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VV2YD0(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VV13gY(tree, root)
  return found
 def VV13gY(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CCyEBX.VVtBR5(xmlTxt)
  parser = CCyEBX.CC76P0()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VV8LRJ(self, VVXOwS, title, txt, colList):
  if self.onlyEpg:
   self.VVqQvn(VVXOwS, "epg")
  else:
   if self.shareIsRef:
    FF8XzP(self, BF(FF7Xva, VVXOwS, BF(self.VVgCZj, VVXOwS)), "Copy all References from Source to Destination ?")
   else:
    VVW1xb = []
    VVW1xb.append(("Copy EPG\t (All List)" , "epg"  ))
    VVW1xb.append(("Copy Picons\t (All List)" , "picon" ))
    FFLFXy(self, BF(self.VVqQvn, VVXOwS), VVW1xb=VVW1xb, width=1000)
 def VVqQvn(self, VVXOwS, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VVZmrz  , "EPG"
   elif item == "picon": fnc, txt = self.VVRdOm , "PIcons"
   title = "Copy %s" % txt
   tot   = VVXOwS.VV9Wh4()
   FF8XzP(self, BF(FF7Xva, VVXOwS, BF(fnc, VVXOwS, title)), "Overwrite %s for %d Service%s ?" % (FFY7FT(txt, VVzCWu), tot, FFmJCK(tot)), title=title)
 def VVgCZj(self, VVXOwS):
  files = CCgg3d.VVROqm()
  totChange = 0
  if files:
   for path in files:
    txt = FFqXAw(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVXOwS.VVWsuW():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFNh5K()
  tot = VVXOwS.VV9Wh4()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FFyv2f(self, txt)
 def VVRdOm(self, VVXOwS, title):
  if not iCopyfile:
   FFa349(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CCMxom.VVVqXw()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVXOwS.VVWsuW():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVXOwS.VV9Wh4()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FFyv2f(self, txt, title=title)
 def VVZmrz(self, VVXOwS, title):
  txt, err = CCos4Q.VVrjLN(VVXOwS, title)
  if err : FFa349(self, err, title=title)
  else : FFyv2f(self, txt, title=title)
 class CC76P0(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VVSNpB(SELF, path, withComments=True, title=""):
  try:
   if withComments : parser = iElem.XMLParser(target=CCyEBX.CC76P0())
   else   : parser = None
   return iElem.parse(path, parser=parser)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FFY7FT("XML Parse Error in:", VV6yYu), path)
   txt += "%s\n%s\n\n" % (FFY7FT("Error:", VV6yYu), str(e))
   FFyv2f(SELF, txt, VVMqKH="#11220000", title=title)
   return None
 @staticmethod
 def VVtBR5(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
class CCos4Q(Screen, CCrLEQ):
 VVkDxv  = "BDTSE"
 VVHiDs   = "save"
 VVVvEd   = "load"
 VVc4Ik  = "flushEPG"
 def __init__(self, session):
  self.skin, self.skinParam = FFXh6Y(VV2F6v, 950, 800, 50, 40, 30, "#22110011", "#22110022", 30)
  self.session  = session
  valid, path, sz, szTxt = CCos4Q.VVSjDb()
  qUrl, iptvRef = CCgg3d.VVitjq(self)
  VVW1xb = []
  VVW1xb.append((VVTMjp + "Cache File Info." , "inf"))
  VVW1xb.append(VVswUs)
  fTxt = " (%s)" % os.path.basename(path) if valid else ""
  t1 = "Save EPG to File%s" % fTxt
  t2 = "Load EPG from File%s" % fTxt
  if valid:
   VVW1xb.append((t1, self.VVHiDs))
   VVW1xb.append((t2, self.VVVvEd))
  else:
   VVW1xb.append((t1, ))
   VVW1xb.append((t2, ))
  VVW1xb.append(VVswUs)
  VVW1xb.append((VV9ZlA + "Delete EPG (from RAM only)", self.VVc4Ik))
  VVW1xb.append(VVswUs)
  txt = "Update Current Bouquet EPG (from IPTV Server)"
  if qUrl or "chCode" in iptvRef: VVW1xb.append((txt, "refreshIptvEPG" ))
  else        : VVW1xb.append((txt,     ))
  VVW1xb.append(("Copy EPG between Channels (from xml file)", "copyEpg" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Translate Current Channel EPG %s(Experimental)" % VV9ZlA, "VVqMJB"))
  FFwLhV(self, VVW1xb=VVW1xb)
  self.onShown.append(self.VVfcAc)
 def VVi1M6(self):
  global VVdxhd
  VVdxhd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "inf"    : self.VV1ZG5()
   elif item in (self.VVHiDs, self.VVVvEd, self.VVc4Ik):
    reset = item == self.VVVvEd
    FF8XzP(self, BF(FF7Xva, self, BF(self.VVa52R, item, reset)), VVusVD="Continue ?")
   elif item == "refreshIptvEPG"  : CCgg3d.VVNJtp(self)
   elif item == "VVqMJB" : self.VVqMJB()
   elif item == "copyEpg"    : self.VVRlhs(False, onlyEpg=True)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FFKauM(self["myMenu"])
  FFVUwm(self)
 def VVa52R(self, act, reset=False):
  ok = CCos4Q.VVkNvi(act)
  if ok:
   if reset:
    CCos4Q.VVFrCw(self)
   FF5nWa(self, "Done")
  else:
   FF5nWa(self, "Failed!")
 def VV1ZG5(self):
  title = "EPG Cache File"
  valid, path, sz, szTxt = CCos4Q.VVSjDb()
  if path:
   if valid: txt = "File Path\t: %s\n\nFile Size\t: %s\n" % (path, szTxt or "?")
   else : txt = "System Settings: %s\n\n%s" % (path, FFY7FT("File not found (check System EPG settings).", VV9ZlA))
   FFyv2f(self, txt, title=title)
  else:
   FFa349(self, "Cannot read Path Settings !", title=title)
 @staticmethod
 def VVTzqS():
  return [("", "Disable"),("af","Afrikaans"),("sq","Albanian"),("am","Amharic"),("ar","Arabic"),("hy","Armenian"),("as","Assamese"),("ay","Aymara"),("az","Azerbaijani"),("bm","Bambara"),("eu","Basque"),("be","Belarusian"),("bn","Bengali"),("bho","Bhojpuri"),("bs","Bosnian"),("bg","Bulgarian"),("ca","Catalan"),("ceb","Cebuano"),("ny","Chichewa"),("zh-CN","Chinese (Simplified)"),("zh-TW","Chinese (Traditional)"),("co","Corsican"),("hr","Croatian"),("cs","Czech"),("da","Danish"),("dv","Dhivehi"),("doi","Dogri"),("nl","Dutch"),("en","English"),("eo","Esperanto"),("et","Estonian"),("ee","Ewe"),("tl","Filipino"),("fi","Finnish"),("fr","French"),("fy","Frisian"),("gl","Galician"),("ka","Georgian"),("de","German"),("el","Greek"),("gn","Guarani"),("gu","Gujarati"),("ht","Haitian Creole"),("ha","Hausa"),("haw","Hawaiian"),("iw","Hebrew"),("hi","Hindi"),("hmn","Hmong"),("hu","Hungarian"),("is","Icelandic"),("ig","Igbo"),("ilo","Ilocano"),("id","Indonesian"),("ga","Irish"),("it","Italian"),("ja","Japanese"),("jw","Javanese"),("kn","Kannada"),("kk","Kazakh"),("km","Khmer"),("rw","Kinyarwanda"),("gom","Konkani"),("ko","Korean"),("kri","Krio"),("ku","Kurdish (Kurmanji)"),("ckb","Kurdish (Sorani)"),("ky","Kyrgyz"),("lo","Lao"),("la","Latin"),("lv","Latvian"),("ln","Lingala"),("lt","Lithuanian"),("lg","Luganda"),("lb","Luxembourgish"),("mk","Macedonian"),("mai","Maithili"),("mg","Malagasy"),("ms","Malay"),("ml","Malayalam"),("mt","Maltese"),("mi","Maori"),("mr","Marathi"),("mni-Mtei","Meiteilon (Manipuri)"),("lus","Mizo"),("mn","Mongolian"),("my","Myanmar (Burmese)"),("ne","Nepali"),("no","Norwegian"),("or","Odia (Oriya)"),("om","Oromo"),("ps","Pashto"),("fa","Persian"),("pl","Polish"),("pt","Portuguese"),("pa","Punjabi"),("qu","Quechua"),("ro","Romanian"),("ru","Russian"),("sm","Samoan"),("sa","Sanskrit"),("gd","Scots Gaelic"),("nso","Sepedi"),("sr","Serbian"),("st","Sesotho"),("sn","Shona"),("sd","Sindhi"),("si","Sinhala"),("sk","Slovak"),("sl","Slovenian"),("so","Somali"),("es","Spanish"),("su","Sundanese"),("sw","Swahili"),("sv","Swedish"),("tg","Tajik"),("ta","Tamil"),("tt","Tatar"),("te","Telugu"),("th","Thai"),("ti","Tigrinya"),("ts","Tsonga"),("tr","Turkish"),("tk","Turkmen"),("ak","Twi"),("uk","Ukrainian"),("ur","Urdu"),("ug","Uyghur"),("uz","Uzbek"),("vi","Vietnamese"),("cy","Welsh"),("xh","Xhosa"),("yi","Yiddish"),("yo","Yoruba"),("zu","Zulu")]
 def VVqMJB(self):
  title = "Translate Current Channel EPG"
  bg = "#11101010"
  VVVi12  = (""  , BF(self.VV1mUr, title, True) , [])
  VVsTsL = ("Start" , BF(self.VV1mUr, title, False), [])
  VVmmwr = ("Change Language", self.VVU3Dd      , [])
  widths  = (70 , 30)
  VVI7B0 = (LEFT , CENTER)
  FFEM8S(self, None, title=title, VV6fdw=self.VVXKrA(), VVI7B0=VVI7B0, VVHqY6=widths, width=1200, vMargin=20, VVJmZ8=30, VVVi12=VVVi12, VVsTsL=VVsTsL, VVmmwr=VVmmwr, VVimZ8=2
    , VVgchu="#11201010", VVn4Mh=bg, VVMqKH=bg, VVKhj2="#00ffffaa", VVntre="#00004455", VV3VhT=bg)
 def VVXKrA(self):
  Def, ch = "DISABLED", dict(CCos4Q.VVTzqS())
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  VV6fdw = [("Event Name Language", ch.get(tVal, Def)), ("Description Language", ch.get(dVal, Def))]
  return VV6fdw
 def VVU3Dd(self, VVXOwS, title, txt, colList):
  ndx = VVXOwS.VVRJth()
  title = colList[0]
  confItem = CFG.epgLangTitle if ndx == 0 else CFG.epgLangDescr
  CCYJYU.VVczFh(self, confItem, title, lst=CCos4Q.VVTzqS(), cbFnc=BF(self.VVPA4t, VVXOwS))
 def VVPA4t(self, VVXOwS):
  for ndx, row in enumerate(self.VVXKrA()):
   VVXOwS.VVxVqL(ndx, row)
 def VV1mUr(self, Title, isAsk, VVXOwS, title, txt, colList):
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  if not (tVal or dVal):
   FF1ojr(VVXOwS, "Change Language", 700)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self)
   refCode, evList, err = CCos4Q.VVii0C(refCode)
   fnc = BF(self.VVf9Bc, Title, refCode, evList, VVXOwS)
   if   err : FFa349(self, err, title=Title)
   elif isAsk : FF8XzP(self, fnc, "Start ?", title=Title)
   else  : fnc()
 def VVf9Bc(self, title, refCode, evList, VVXOwS):
  self.session.open(CCvBnC, barTheme=CCvBnC.VVjpsh, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVszsm, evList)
      , VVnRGv = BF(self.VV69QF, title, refCode))
  VVXOwS.cancel()
 def VVszsm(self, evList, VVhsRS):
  totEv = len(evList)
  newLst = []
  totErrName = totErrShort = totErrLong = totSkip = 0
  VVhsRS.VVBrFN(totEv)
  VVhsRS.VVLNy3 = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
  lang = CFG.epgLangDescr.getValue()
  for ev in evList:
   trName, trShort, trLong, errName, errShort, errLong = CCos4Q.VVER1A(*ev[2:5])
   totErrName  += errName
   totErrShort += errShort
   totErrLong  += errLong
   if not VVhsRS or VVhsRS.isCancelled:
    return
   VVhsRS.VVwvD4(1)
   VVhsRS.VV8itz(len(newLst), ev[2] if len(ev[2]) < 22 else ev[2][:22] + " ...")
   name1, short1, long1 = ev[2:5]
   if (name1, short1, long1) != (trName, trShort, trLong):
    item = list(ev)
    item[2], item[3], item[4] = trName, trShort, trLong
    item.append(1)
    newLst.append(tuple(item))
   else:
    totSkip += 1
   VVhsRS.VVLNy3 = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
 def VV69QF(self, title, refCode, VVL4pA, VVLNy3, threadCounter, threadTotal, threadErr):
  newLst, totEv, totErrName, totErrShort, totErrLong, totSkip = VVLNy3
  if newLst: totEv, totOK = CCos4Q.VVsRne(refCode, newLst)
  else  : totOK = 0
  if totOK:
   CCos4Q.VVHHlQ()
   CCos4Q.VVFrCw(self)
  txt  = "Events\t: %d\n"  % totEv
  txt += "Processed\t: %d\n" % len(newLst)
  txt += "Changed\t: %d\n" % totOK
  if totSkip : txt += "Skipped\t: %d \t... Same language\n" % totSkip
  if any((totErrName, totErrShort, totErrLong)):
   txt += "\nErrors:\n"
   if totErrName : txt += "  Event Name\t: %d\n" % totErrName
   if totErrShort: txt += "  Description\t: %d\n" % totErrShort
   if totErrLong : txt += "  Description\t: %d\n" % totErrLong
  FFyv2f(self, txt, title=title)
 @staticmethod
 def VVER1A(eName, eShort, eLong):
  eName, eShort, eLong = eName.strip(), eShort.strip(), eLong.strip()
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  lang, lst, resLst, errLst = (tVal, dVal, dVal), (eName, eShort, eLong), ["", "", ""], [0, 0, 0]
  def VV5vDG(ndx):
   if lst[ndx] and lang[ndx]:
    txt, err = CCos4Q.VVz1sV(lst[ndx], lang[ndx])
    resLst[ndx], errLst[ndx] = txt, 1 if err else 0
  thLst = []
  for ndx in range(3):
   th = iThread(name="ajp_%d" % ndx, target=BF(VV5vDG, ndx))
   th.start()
   thLst.append(th)
  for th in thLst: th.join()
  trName, trShort, trLong = resLst[0] or eName, resLst[1] or eShort, resLst[2] or eLong
  errName, errShort, errLong = errLst
  return trName, trShort, trLong, errName, errShort, errLong
 @staticmethod
 def VVz1sV(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "%s%s&q=%s" % ("=lt&otua=ls&?m/moc.elgoog.etalsnart//:sptth"[::-1], toLang, FFgbDs(txt))
   txt, err = CCgg3d.VVTXoD(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFdOos(txt)
    ndx  = txt.find('<div class="result-container">')
    if ndx > -1:
     txt = txt[ndx + 30:]
     ndx  = txt.find("</div>")
     if ndx > -1:
      return str(CCos4Q.VVFXZn(txt[:ndx])).strip(), ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVSjDb():
  path = szTxt = ""
  valid = sz = 0
  try: path = config.misc.epgcache_filename.getValue()
  except: pass
  if fileExists(path):
   valid = 1
   sz = FFPYZx(path)
   szTxt = CCbI7Z.VVr8MR(sz) if sz > -1 else ""
  return valid, path, sz, szTxt
 @staticmethod
 def VVUmLr():
  try:
   from enigma import eEPGCache
   return eEPGCache, eEPGCache.getInstance()
  except:
   return None, None
 @staticmethod
 def VVHHlQ(): CCos4Q.VVkNvi(CCos4Q.VVHiDs)
 @staticmethod
 def VVkNvi(act):
  ec, inst = CCos4Q.VVUmLr()
  if inst and hasattr(ec, act):
   try:
    exec("inst.%s()" % act)
    return True
   except:
    pass
  return False
 @staticmethod
 def VVFrCw(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   SELF.session.nav.stopService()
   SELF.session.nav.playService(serv)
 @staticmethod
 def VVii0C(refCode):
  ec, inst = CCos4Q.VVUmLr()
  if inst:
   try:
    evList = inst.lookupEvent([CCos4Q.VVkDxv, (refCode, 0, -1, 20160)])
    if evList: return refCode, evList, ""
    else  : return refCode, [], "System returned empty EPG list"
   except:
    return refCode, [], "EPG Read-Error !"
  else:
   return refCode, [], "Cannot read EPG Cache !"
 @staticmethod
 def VVsRne(refCode, events, longDescDays=0):
  ec, inst = CCos4Q.VVUmLr()
  totEv, totOK, fnc = 0, 0, None
  if inst:
   if   hasattr(ec, "importEvents"): fnc = inst.importEvents
   elif hasattr(ec, "importEvent") : fnc = inst.importEvent
  if fnc:
   for data in events:
    totEv += 1
    try:
     if longDescDays and data[0] > iTime() + 86400 * longDescDays:
      data = data[:4] + ("",) + data[5:]
     fnc(refCode, (data,))
     totOK += 1
    except:
     pass
  return totEv, totOK
 @staticmethod
 def VVuKUK(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   ec, inst = CCos4Q.VVUmLr()
   if ec:
    event = inst.lookupEventTime(serv, -1, 0)
    if event:
     return CCos4Q.VVjmVI(event)
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CCsydO.CCos4Q(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVjmVI(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCos4Q.VVnfpd(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVh7UH(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   ec, inst = CCos4Q.VVUmLr()
   try:
    if inst:
     for evNum in range(2):
      event = inst.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CCos4Q.VVjmVI(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FFXtJp(evTime)
       evEndTxt  = FFXtJp(evEnd)
       evDurTxt  = FFCiZs(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FFCiZs(evPos)
        evRem = evEnd - now
        evRemTxt = FFCiZs(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FFCiZs(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VVnfpd(event):
  genre = PR = ""
  try:
   genre  = CCos4Q.VVdUWG(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCos4Q.VVbObu(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVbObu(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVdUWG(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCos4Q.VVXrUj()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVXrUj():
  path = VV9dcF + "_sup_genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFqXAw(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFqXAw(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVrjLN(VVXOwS, title):
  ec, inst = CCos4Q.VVUmLr()
  if not inst:
   return "", "Cannot access EPG Cache !"
  totFound = totEvents = totSuccess = totInvalid = totEvErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVXOwS.VVWsuW():
   if remark == "0":
    try:
     evList = inst.lookupEvent([CCos4Q.VVkDxv, (srcRef, 0, -1, 20160)])
    except:
     totEvErr += 1
     evList = []
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CCos4Q.VVsRne(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CCos4Q.VVHHlQ()
  txt  = "Services\t: %d\n"  % VVXOwS.VV9Wh4()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  if totEvErr:
   txt += "EPG Errors\t: %d" % totEvErr
  return txt, ""
 @staticmethod
 def VVSTU8(info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += CCos4Q.VV1Ian(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += CCos4Q.VV1Ian(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += CCos4Q.VV1Ian(event, 0)
     except:
      pass
  return epg
 @staticmethod
 def VV1Ian(event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCos4Q.VVjmVI(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    trName, trShort, trLong, errName, errShort, errLong = CCos4Q.VVER1A(evName, evShort, evDesc)
    evShort, evDesc = trShort, trLong
    evNameTransl = trName if evName and trName and evName != trName else ""
    if evName          : txt += "Name\t: %s\n"   % FFY7FT(evName, VVJ2KG)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (CFG.epgLangDescr.getValue().upper(), FFY7FT(evNameTransl, VVJ2KG))
    if evTime           : txt += "Start Time\t: %s\n" % FFXtJp(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFXtJp(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFCiZs(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFCiZs(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFCiZs(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFY7FT(evShort, VVW6qu)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFY7FT(evDesc , VVW6qu)
    if txt:
     txt = FFY7FT("\n%s\n%s Event:\n%s\n" % (VVI8D8, ("Current", "Next")[evNum], VVI8D8), VVJ2KG) + txt
  return txt
 @staticmethod
 def VVFXZn(txt):
  try:
   from HTMLParser import HTMLParser
   return HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
class CCyEBX(Screen, CCrLEQ):
 VVNsZH  = 0
 VV6P4Z = 1
 VVwOm9  = 2
 VV5iLb  = 3
 VVQcI8 = 4
 VVH7VT = 5
 VVayYH = 6
 VVlqFe   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FFXh6Y(VV2F6v, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VV4NJL = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVW1xb = self.VVoatf()
  FFwLhV(self, VVW1xb=VVW1xb, title="Services/Channels")
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self["myMenu"].setList(self.VVoatf())
  FFKauM(self["myMenu"])
  FFVUwm(self)
 def VVoatf(self):
  VVW1xb = []
  c = VVTMjp
  VVW1xb.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVW1xb.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVW1xb.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVW1xb.append(VVswUs)
  c = VVJ2KG
  VVW1xb.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVW1xb.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVW1xb.append((VV6yYu + "More tables ..."     , "VVdg2i"    ))
  c = VVW6qu
  VVW1xb.append(VVswUs)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVW1xb.append((c + txt          , "VVdlUE"  ))
  else : VVW1xb.append((txt           ,          ))
  VVW1xb.append((c + 'Export Services to "channels.xml"'    , "VVw1BS"      ))
  VVW1xb.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VVPpUd
  VVW1xb.append(VVswUs)
  VVW1xb.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVW1xb.append((c + "Invalid Services Cleaner"       , "VVcIlH"    ))
  c = VVPpUd
  VVW1xb.append(VVswUs)
  VVW1xb.append((c + "Delete Channels with no names"     , "VVgh7x"    ))
  VVW1xb.append((c + "Delete Empty Bouquets"       , "VVl17o"     ))
  VVW1xb.append(VVswUs)
  VVekD9, VVRLP2 = CCyEBX.VVeusg()
  if fileExists(VVekD9):
   enab = fileExists(VVRLP2)
   if enab: VVW1xb.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVW1xb.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVW1xb.append(("Reset Parental Control Settings"      , "VV6oxh"    ))
  VVW1xb.append(("Reload Channels and Bouquets"       , "VVTDcy"      ))
  return VVW1xb
 def VVi1M6(self):
  global VVdxhd
  VVdxhd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCXzGX.VVmA7N(self.session)
   elif item == "openSignal"       : FFQ9QB(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FFr9gS(self, fncMode=CCsydO.VVPCQS)
   elif item == "lameDB_allChannels_with_refCode"  : FF7Xva(self, self.VVSwHR)
   elif item == "lameDB_allChannels_with_tranaponder" : FF7Xva(self, self.VVuKB5)
   elif item == "VVdg2i"     : self.VVdg2i()
   elif item == "VVdlUE"  : CCchNl.VVdlUE(self)
   elif item == "VVw1BS"      : self.VVw1BS()
   elif item == "copyEpgPicons"      : self.VVRlhs(False)
   elif item == "SatellitesCleaner"     : FF7Xva(self, self.FF7Xva_SatellitesCleaner)
   elif item == "VVcIlH"    : FF7Xva(self, BF(self.VVcIlH))
   elif item == "VVgh7x"    : FF7Xva(self, self.VVgh7x)
   elif item == "VVl17o"     : self.VVl17o(self)
   elif item == "enableHiddenChannels"     : self.VV2TXd(True)
   elif item == "disableHiddenChannels"    : self.VV2TXd(False)
   elif item == "VV6oxh"    : FF8XzP(self, self.VV6oxh, "Reset and Restart ?")
   elif item == "VVTDcy"      : FF7Xva(self, BF(CCyEBX.VVTDcy, self))
 def VVdg2i(self):
  VVW1xb = []
  VVW1xb.append(("Services (IDs)"       , "lameDB_allChannels_with_details" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Services (Parental-Control List)"   , "parentalControlChannels"   ))
  VVW1xb.append(("Services (Hidden List)"     , "showHiddenChannels"    ))
  VVW1xb.append(("Services with PIcons for the System"  , "VVi2P3"    ))
  VVW1xb.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"  ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Transponders (Statistics)"    , "TranspondersStats"    ))
  VVW1xb.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"    ))
  FFLFXy(self, self.VVRHWp, VVW1xb=VVW1xb, title="Service Information", VVxhca=True)
 def VVRHWp(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FF7Xva(self, BF(self.VVjjo1, title))
   elif ref == "parentalControlChannels"   : FF7Xva(self, BF(self.VVv8Ed, title))
   elif ref == "showHiddenChannels"    : FF7Xva(self, BF(self.VVcmTa, title))
   elif ref == "VVi2P3"    : FF7Xva(self, BF(self.VVJ89i, title))
   elif ref == "servicesWithMissingPIcons"   : FF7Xva(self, BF(self.VVcWYm, title))
   elif ref == "TranspondersStats"     : FF7Xva(self, BF(self.VV8Jd8, title))
   elif ref == "SatellitesXmlStats"    : FF7Xva(self, BF(self.VVkUsZ, title))
 def VVw1BS(self):
  VVW1xb = []
  VVW1xb.append(("All DVB-S/C/T Services", "all"))
  VVW1xb.extend(CCRtNz.VV6Ees())
  FFLFXy(self, self.VVs4ZI, VVW1xb=VVW1xb, title="", VVxhca=True)
 def VVs4ZI(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCyEBX.VVKpWw("1:7:")
   else   : lst = FFqMsP(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFP3va(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFTxso(r)  : sat = "Stream Relay"
       elif FFDOE0(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FFnWu0(CFG.exportedTablesPath.getValue()), FFJCyp())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FF5nWa(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FF1ojr(self, "No Services found !", 1500)
 @staticmethod
 def VVTDcy(SELF):
  FFNh5K()
  FF5nWa(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVSwHR(self):
  self.VV4NJL = None
  self.lastfilterUsed  = None
  self.filterObj   = CCuF2O(self)
  VVuV68, err = CCyEBX.VVCZgt(self, self.VVNsZH)
  if VVuV68:
   VVuV68.sort(key=lambda x: x[0].lower())
   VVVi12  = ("Zap"   , self.VVQES3     , [])
   VVd4CR = (""    , self.VVbVGK   , [])
   VVQR2V = ("Options"  , self.VVKdOF , [])
   VVsTsL = ("Current Service", self.VVAEi9 , [])
   VVmmwr = ("Filter"   , self.VV2SPQ  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVI7B0  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFEM8S(self, None, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26, VVVi12=VVVi12, VVd4CR=VVd4CR, VVsTsL=VVsTsL, VVQR2V=VVQR2V, VVmmwr=VVmmwr, lastFindConfigObj=CFG.lastFindServices)
 def VVuKB5(self):
  self.VV4NJL = None
  self.lastfilterUsed  = None
  self.filterObj   = CCuF2O(self)
  VVuV68, err = CCyEBX.VVCZgt(self, self.VV6P4Z)
  if VVuV68:
   VVuV68.sort(key=lambda x: x[0].lower())
   VVVi12  = ("Zap"   , self.VVQES3      , [])
   VVd4CR = (""    , self.VVbVGK    , [])
   VVsTsL = ("Current Service", self.VVAEi9  , [])
   VVQR2V = ("Options"  , self.VV2Pt6 , [])
   VVmmwr = ("Filter"   , self.VVlRuX  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVI7B0  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFEM8S(self, None, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26, VVVi12=VVVi12, VVd4CR=VVd4CR, VVsTsL=VVsTsL, VVQR2V=VVQR2V, VVmmwr=VVmmwr, lastFindConfigObj=CFG.lastFindServices)
 def VVKdOF(self, VVXOwS, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CCTHuN(self, VVXOwS)
  VVW1xb = []
  isMulti = VVXOwS.VVyKav
  if isMulti:
   refCodeList = VVXOwS.VVrdFQ(3)
   if refCodeList:
    VVW1xb.append(("Add Selection to Parental Control"  , "parentalControl_sel_add"  ))
    VVW1xb.append(("Remove Selection from Parental Control" , "parentalControl_sel_remove" ))
    VVW1xb.append(VVswUs)
    VVW1xb.append(("Add Selection to Hidden Services"   , "hiddenServices_sel_add"  ))
    VVW1xb.append(("Remove Selection from Hidden Services" , "hiddenServices_sel_remove" ))
    VVW1xb.append(VVswUs)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVW1xb.append((txt1, "parentalControl_add" ))
    VVW1xb.append((txt2,        ))
   else:
    VVW1xb.append((txt1,       ))
    VVW1xb.append((txt2, "parentalControl_remove" ))
   VVW1xb.append(VVswUs)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVW1xb.append((txt1, "hiddenServices_add"  ))
    VVW1xb.append((txt2,       ))
   else:
    VVW1xb.append((txt1,        ))
    VVW1xb.append((txt2, "hiddenServices_remove" ))
   VVW1xb.append(VVswUs)
  cbFncDict = { "parentalControl_add"   : BF(self.VVQdmx, VVXOwS, refCode, True)
     , "parentalControl_remove"  : BF(self.VVQdmx, VVXOwS, refCode, False)
     , "hiddenServices_add"   : BF(self.VVt50V, VVXOwS, refCode, True)
     , "hiddenServices_remove"  : BF(self.VVt50V, VVXOwS, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVk99Y, VVXOwS, True)
     , "parentalControl_sel_remove" : BF(self.VVk99Y, VVXOwS, False)
     , "hiddenServices_sel_add"  : BF(self.VV0JmE, VVXOwS, True)
     , "hiddenServices_sel_remove" : BF(self.VV0JmE, VVXOwS, False)
     }
  VVW1xb1, cbFncDict1 = CCyEBX.VV6MvZ(self, VVXOwS, servName, 3)
  VVW1xb.extend(VVW1xb1)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VVoxj8(VVW1xb, cbFncDict)
 def VV2Pt6(self, VVXOwS, title, txt, colList):
  servName = colList[0]
  mSel = CCTHuN(self, VVXOwS)
  VVW1xb, cbFncDict = CCyEBX.VV6MvZ(self, VVXOwS, servName, 3)
  mSel.VVoxj8(VVW1xb, cbFncDict)
 @staticmethod
 def VV6MvZ(SELF, VVXOwS, servName, refCodeCol):
  tot = VVXOwS.VVYRl7()
  if tot > 0:
   sTxt = FFY7FT("%d Service%s" % (tot, FFmJCK(tot)), VVJ2KG)
   VVW1xb = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FFyZAn(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FFY7FT(servName, VVJ2KG)
   VVW1xb = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CCyEBX.VVcHYX, SELF, VVXOwS, refCodeCol, True)
     , "addToBouquet_one" : BF(CCyEBX.VVcHYX, SELF, VVXOwS, refCodeCol, False)
     }
  return VVW1xb, cbFncDict
 @staticmethod
 def VVcHYX(SELF, VVXOwS, refCodeCol, isMulti):
  picker = CCRtNz(SELF, VVXOwS, "Add to Bouquet", BF(CCyEBX.VVdy0p, VVXOwS, refCodeCol, isMulti))
 @staticmethod
 def VVdy0p(VVXOwS, refCodeCol, isMulti):
  if isMulti : refCodeList = VVXOwS.VVrdFQ(refCodeCol)
  else  : refCodeList = [VVXOwS.VVsaDG()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VVQdmx(self, VVXOwS, refCode, isAddToBlackList):
  VVXOwS.VV5MPV("Processing ...")
  FFWlvR(BF(self.VVT0Mw, VVXOwS, [refCode], isAddToBlackList))
 def VVk99Y(self, VVXOwS, isAddToBlackList):
  refCodeList = VVXOwS.VVrdFQ(3)
  if not refCodeList:
   FFa349(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVXOwS.VV5MPV("Processing ...")
  FFWlvR(BF(self.VVT0Mw, VVXOwS, refCodeList, isAddToBlackList))
 def VVT0Mw(self, VVXOwS, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVNl6N, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVNl6N):
   lines = FFFfvw(VVNl6N)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVNl6N, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVXOwS.VVyKav
   if isMulti:
    self.VVFMUC(VVXOwS, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVmIOx(VVXOwS, refCode)
    VVXOwS.VVwDYX()
  else:
   VVXOwS.VVbkCu("No changes")
 def VVt50V(self, VVXOwS, refCode, isHide):
  title = "Change Hidden State"
  if FFX2Cs(refCode):
   VVXOwS.VV5MPV("Processing ...")
   ret = FFV9Z7(refCode, isHide)
   if ret : FF7Xva(self, BF(self.VVmIOx, VVXOwS, refCode))
   else : FFa349(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFa349(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVmIOx(self, VVXOwS, refCode):
  VVuV68, err = CCyEBX.VVCZgt(self, self.VVNsZH, VVKI5z=[3, [refCode], False])
  done = False
  if VVuV68:
   data = VVuV68[0]
   if data[3] == refCode:
    done = VVXOwS.VV8NVY(data)
  if not done:
   self.VVe6ux(VVXOwS, VVXOwS.VVXYEj(), self.VVNsZH)
  VVXOwS.VVwDYX()
 def VVFMUC(self, VVXOwS, totRefCodes):
  VVuV68, err = CCyEBX.VVCZgt(self, self.VVNsZH, VVKI5z=self.VV4NJL)
  VVXOwS.VVOFDI(VVuV68)
  VVXOwS.VVl5wx(False)
  VVXOwS.VVbkCu("%d Processed" % totRefCodes)
 def VV0JmE(self, VVXOwS, isHide):
  refCodeList = VVXOwS.VVrdFQ(3)
  if not refCodeList:
   FFa349(self, "Nothing selected", title="Change Hidden State")
   return
  VVXOwS.VV5MPV("Processing ...")
  FFWlvR(BF(self.VVOw0a, VVXOwS, refCodeList, isHide))
 def VVOw0a(self, VVXOwS, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFV9Z7(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFNh5K(True)
   self.VVFMUC(VVXOwS, len(refCodeList))
  else:
   VVXOwS.VVbkCu("No changes")
 def VV2SPQ(self, VVXOwS, title, txt, colList):
  inFilterFnc = BF(self.VVCBPg, VVXOwS) if self.VV4NJL else None
  self.filterObj.VVlXFC(1, VVXOwS, 2, BF(self.VVnJoB, VVXOwS), inFilterFnc=inFilterFnc)
 def VVnJoB(self, VVXOwS, item):
  self.VVgFqm(VVXOwS, False, item, 2, self.VVNsZH)
 def VVCBPg(self, VVXOwS, menuInstance, item):
  self.VVgFqm(VVXOwS, True, item, 2, self.VVNsZH)
 def VVlRuX(self, VVXOwS, title, txt, colList):
  inFilterFnc = BF(self.VVVy5c, VVXOwS) if self.VV4NJL else None
  self.filterObj.VVlXFC(2, VVXOwS, 4, BF(self.VVl4zb, VVXOwS), inFilterFnc=inFilterFnc)
 def VVl4zb(self, VVXOwS, item):
  self.VVgFqm(VVXOwS, False, item, 4, self.VV6P4Z)
 def VVVy5c(self, VVXOwS, menuInstance, item):
  self.VVgFqm(VVXOwS, True, item, 4, self.VV6P4Z)
 def VV079j(self, VVXOwS, title, txt, colList):
  inFilterFnc = BF(self.VVWWxR, VVXOwS) if self.VV4NJL else None
  self.filterObj.VVlXFC(0, VVXOwS, 4, BF(self.VVAvQ4, VVXOwS), inFilterFnc=inFilterFnc)
 def VVAvQ4(self, VVXOwS, item):
  self.VVgFqm(VVXOwS, False, item, 4, self.VVwOm9)
 def VVWWxR(self, VVXOwS, menuInstance, item):
  self.VVgFqm(VVXOwS, True, item, 4, self.VVwOm9)
 def VVgFqm(self, VVXOwS, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVXOwS.VVRuNe(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VV4NJL = None
  else:
   words, asPrefix = CCuF2O.VVUxc8(words)
   self.VV4NJL = [col, words, asPrefix]
  if words: FF7Xva(VVXOwS, BF(self.VVe6ux, VVXOwS, title, mode), clearMsg=False)
  else : FF1ojr(VVXOwS, "Incorrect filter", 2000)
 def VVe6ux(self, VVXOwS, title, mode):
  VVuV68, err = CCyEBX.VVCZgt(self, mode, VVKI5z=self.VV4NJL, VVaGwb=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVXOwS.VVWsuW():
    try:
     ndx = VVuV68.index(tuple(list(map(str.strip, row))))
     lst.append(VVuV68[ndx])
    except:
     pass
   VVuV68 = lst
  if VVuV68:
   VVuV68.sort(key=lambda x: x[0].lower())
   VVXOwS.VVOFDI(VVuV68, title)
  else:
   FF1ojr(VVXOwS, "Not found!", 1500)
 def VVvoqt(self, title, VV6fdw, VVVi12=None, VVd4CR=None, VVQcug=None, VVsTsL=None, VVQR2V=None, VVmmwr=None):
  VVsTsL = ("Current Service", self.VVAEi9, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVI7B0 = (LEFT  , LEFT  , CENTER, LEFT    )
  FFEM8S(self, None, title=title, header=header, VV6fdw=VV6fdw, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26, VVVi12=VVVi12, VVd4CR=VVd4CR, VVQcug=VVQcug, VVsTsL=VVsTsL, VVQR2V=VVQR2V, VVmmwr=VVmmwr, lastFindConfigObj=CFG.lastFindServices)
 def VVAEi9(self, VVXOwS, title, txt, colList):
  self.VV9guY(VVXOwS)
 def VVlGek(self, VVXOwS, title, txt, colList):
  self.VV9guY(VVXOwS, True)
 def VV9guY(self, VVXOwS, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVXOwS.VV1ZDk(colDict, VVik2e=True)
   else:
    VVXOwS.VV71dE(3, refCode, True)
   return
  FFa349(self, "Cannot read current Reference Code !")
 def VVjjo1(self, title):
  self.VV4NJL = None
  self.lastfilterUsed  = None
  self.filterObj   = CCuF2O(self)
  VVuV68, err = CCyEBX.VVCZgt(self, self.VVwOm9)
  if VVuV68:
   VVuV68.sort(key=lambda x: x[0].lower())
   VVd4CR = (""    , self.VV02iq , []      )
   VVsTsL = ("Current Service", self.VVlGek  , []      )
   VVmmwr = ("Filter"   , self.VV079j   , [], "Loading Filters ..." )
   VVVi12  = ("Zap"   , self.VVksRq      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVI7B0  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFEM8S(self, None, title=title, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26, VVVi12=VVVi12, VVd4CR=VVd4CR, VVsTsL=VVsTsL, VVmmwr=VVmmwr, lastFindConfigObj=CFG.lastFindServices)
 def VV02iq(self, VVXOwS, title, txt, colList):
  refCode  = self.VVVIij(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFr9gS(self, fncMode=CCsydO.VVaGCy, refCode=refCode, chName=chName, text=txt)
 def VVksRq(self, VVXOwS, title, txt, colList):
  refCode = self.VVVIij(colList)
  FFqi6V(self, refCode)
 def VVQES3(self, VVXOwS, title, txt, colList):
  FFqi6V(self, colList[3])
 def VVVIij(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVK2WE(VVekD9, mode=0):
  lines = FFFfvw(VVekD9, encLst=["UTF-8"])
  return CCyEBX.VVuYd1(lines, mode)
 @staticmethod
 def VVuYd1(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VVCZgt(SELF, mode, VVKI5z=None, VVaGwb=True, VVvSQT=True):
  VVekD9, err = CCyEBX.VVDJAJ(SELF, VVvSQT)
  if err:
   return None, err
  asPrefix = False
  if VVKI5z:
   filterCol = VVKI5z[0]
   filterWords = VVKI5z[1]
   asPrefix = VVKI5z[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCyEBX.VVNsZH:
   blackList = None
   if fileExists(VVNl6N):
    blackList = FFFfvw(VVNl6N)
    if blackList:
     blackList = set(blackList)
  elif mode == CCyEBX.VV6P4Z:
   tp = CCEpHi()
  VVwf7y, VV8J1C = FFsOE4()
  if mode in (CCyEBX.VVH7VT, CCyEBX.VVayYH):
   VVuV68 = {}
  else:
   VVuV68 = []
  tagFound = False
  with ioOpen(VVekD9, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FFKJmy(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCyEBX.VVwOm9:
       if sTypeInt in VVwf7y:
        STYPE = VV8J1C[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVuV68.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVuV68.append(tRow)
       else:
        VVuV68.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCyEBX.VVlqFe:
        VVuV68.append((chName, chProv, sat, refCode))
       elif mode == CCyEBX.VVH7VT:
        VVuV68[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCyEBX.VVayYH:
        VVuV68[chName] = refCode
       elif mode == CCyEBX.VVNsZH:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVuV68.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVuV68.append(tRow)
        else:
         VVuV68.append(tRow)
       elif mode == CCyEBX.VV6P4Z:
        if sTypeInt in VVwf7y:
         STYPE = VV8J1C[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVtkIs(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVuV68.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVuV68.append(tRow)
        else:
         VVuV68.append(tRow)
       elif mode == CCyEBX.VV5iLb:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVuV68.append((chName, chProv, sat, refCode))
       elif mode == CCyEBX.VVQcI8:
        VVuV68.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVuV68 and VVaGwb:
   FFa349(SELF, "No services found!")
  return VVuV68, ""
 def VVv8Ed(self, title):
  if fileExists(VVNl6N):
   lines = FFFfvw(VVNl6N)
   if lines:
    newRows = []
    VVuV68, err = CCyEBX.VVCZgt(self, self.VVQcI8)
    if VVuV68:
     lines = set(lines)
     for item in VVuV68:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVuV68 = newRows
      VVuV68.sort(key=lambda x: x[0].lower())
      VVd4CR = ("", self.VVbVGK, [])
      VVVi12 = ("Zap", self.VVQES3, [])
      self.VVvoqt(title, VVuV68, VVVi12=VVVi12, VVd4CR=VVd4CR)
     else:
      FFyv2f(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVuV68)))
   else:
    FF5nWa(self, "No active Parental Control services.", FFwHka())
  else:
   FFRYkM(self, VVNl6N)
 def VVcmTa(self, title):
  VVuV68, err = CCyEBX.VVCZgt(self, self.VV5iLb)
  if VVuV68:
   VVuV68.sort(key=lambda x: x[0].lower())
   VVd4CR = ("" , self.VVbVGK, [])
   VVVi12  = ("Zap", self.VVQES3, [])
   self.VVvoqt(title, VVuV68, VVVi12=VVVi12, VVd4CR=VVd4CR)
  elif err:
   pass
  else:
   FF5nWa(self, "No hidden services.", FFwHka())
 def VVcIlH(self):
  title = "Services unused in Tuner Configuration"
  VVekD9, err = CCyEBX.VVDJAJ(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CCyEBX.VVuEJD()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VVx3Zn(str(item[0]))
    nsLst.add(ns)
  sysLst = CCyEBX.VVKpWw("1:7:")
  tpLst  = CCyEBX.VVK2WE(VVekD9, mode=1)
  VVuV68 = []
  for refCode, chName in sysLst:
   servID = CCyEBX.VV8qP6(refCode)
   tpID = CCyEBX.VVBDw2(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VVuV68.append((chName, FFP3va(refCode, False), refCode, servID))
  if VVuV68:
   VVuV68.sort(key=lambda x: x[0].lower())
   VVQR2V = ("Options"   , BF(self.VVtUoH, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VVI7B0  = (LEFT  , CENTER , LEFT   , CENTER   )
   FFEM8S(self, None, title=title, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26, VVQR2V=VVQR2V, VVgchu="#0a001122", VVn4Mh="#0a001122", VVMqKH="#0a001122", VVntre="#00004455", VV3VhT="#0a333333", VVwlSC="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FF5nWa(self, "No invalid service found !", title=title)
 def VVtUoH(self, Title, VVXOwS, title, txt, colList):
  mSel = CCTHuN(self, VVXOwS)
  isMulti = VVXOwS.VVyKav
  if isMulti : txt = "Remove %s Services" % FFY7FT(str(VVXOwS.VVYRl7()), VV6yYu)
  else  : txt = "Remove : %s" % FFY7FT(VVXOwS.VVsaDG()[0], VV6yYu)
  VVW1xb = [(txt, "del")]
  cbFncDict = {"del": BF(FF7Xva, VVXOwS, BF(self.VVgJ6A, VVXOwS, Title))}
  mSel.VVoxj8(VVW1xb, cbFncDict)
 def VVgJ6A(self, VVXOwS, title):
  VVekD9, err = CCyEBX.VVDJAJ(self, title=title)
  if err:
   return
  isMulti = VVXOwS.VVyKav
  skipLst = []
  if isMulti : skipLst = VVXOwS.VVrdFQ(3)
  else  : skipLst = [VVXOwS.VVsaDG()[3]]
  tpLst = CCyEBX.VVK2WE(VVekD9, mode=0)
  servLst = CCyEBX.VVK2WE(VVekD9, mode=10)
  tmpDbFile = VVekD9 + ".tmp"
  lines   = FFFfvw(VVekD9)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  os.system(FFQe93("mv -f '%s' '%s'" % (tmpDbFile, VVekD9)))
  VVuV68 = []
  for row in VVXOwS.VVWsuW():
   if not row[3] in skipLst:
    VVuV68.append(row)
  FFNh5K()
  FFyv2f(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VVuV68:
   VVXOwS.VVOFDI(VVuV68, title)
   VVXOwS.VVl5wx(False)
  else:
   VVXOwS.cancel()
 def VV8Jd8(self, title):
  VVekD9, err = CCyEBX.VVDJAJ(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VV3cCk(VVekD9)
  txt = FFY7FT("Total Transponders:\n\n", VV5cg1)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFY7FT("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VV5cg1)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFpXIw(item), satList.count(item))
  FFyv2f(self, txt, title)
 def VV3cCk(self, VVekD9):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VVekD9, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVkUsZ(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FFRYkM(self, path, title=title)
   return
  elif not CCbI7Z.VV8ERc(self, path, title):
   return
  if not CCaICB.VVYcTc(self):
   return
  tree = CCyEBX.VVSNpB(self, path, title=title)
  if not tree:
   return
  VVuV68 = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FFKJmy(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVuV68.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVuV68:
   VVuV68.sort(key=lambda x: int(x[1]))
   VVsTsL = ("Current Satellite", BF(self.VVt3Td, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VVI7B0  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FFEM8S(self, None, title=title, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=25, VVA0qQ=1, VVsTsL=VVsTsL, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFa349(self, "No data found !", title=title)
 def VVt3Td(self, satCol, VVXOwS, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self)
  sat = FFP3va(refCode, False)
  for ndx, row in enumerate(VVXOwS.VVWsuW()):
   if sat == row[satCol].strip():
    VVXOwS.VV9fSx(ndx)
    break
  else:
   FF1ojr(VVXOwS, "No listed !", 1500)
 def FF7Xva_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FFa349(self, "No Satellites found !")
   return
  usedSats = CCyEBX.VVuEJD()
  VVuV68 = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VVuV68.append((sat[1], posTxt, FFKJmy(sat[0]), tuners, str(posVal)))
  if VVuV68:
   VVMqKH = "#11222222"
   VVuV68.sort(key=lambda x: int(x[1]))
   VVsTsL = ("Current Satellite" , BF(self.VVt3Td, 2) , [])
   VVQR2V = ("Options"   , self.VV8MQB  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VVI7B0  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FFEM8S(self, None, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=28, VVsTsL=VVsTsL, VVQR2V=VVQR2V, VVgchu=VVMqKH, VVn4Mh=VVMqKH, VVMqKH=VVMqKH, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFa349(self, "No data found !")
 def VV8MQB(self, VVXOwS, title, txt, colList):
  mSel = CCTHuN(self, VVXOwS)
  isMulti = VVXOwS.VVyKav
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FFY7FT(str(VVXOwS.VVYRl7()), VV6yYu)
  else  : txt = "Remove ALL Services on : %s" % FFY7FT(VVXOwS.VVsaDG()[0], VV6yYu)
  VVW1xb = []
  VVW1xb.append((txt, "deleteSat"))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Delete Empty Bouquets", "VVl17o"))
  cbFncDict = { "deleteSat"   : BF(FF7Xva, VVXOwS, BF(self.VV8Lp7, VVXOwS))
     , "VVl17o" : BF(self.VVl17o, VVXOwS)
     }
  mSel.VVoxj8(VVW1xb, cbFncDict)
 def VV8Lp7(self, VVXOwS):
  posLst = []
  isMulti = VVXOwS.VVyKav
  posLst = []
  if isMulti : posLst = VVXOwS.VVrdFQ(4)
  else  : posLst = [VVXOwS.VVsaDG()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VVx3Zn(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VV3ttv(nsLst)
  FFNh5K(True)
  FFyv2f(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VVl17o(self, winObj):
  title = "Delete Empty Bouquets"
  FF8XzP(self, BF(FF7Xva, winObj, BF(self.VVl683, title)), "Delete bouquets with no services ?", title=title)
 def VVl683(self, title):
  bList = CCRtNz.VVU9Ld()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CCRtNz.VVFETu(bRef)
    bPath = VVLOHV + bFile
    FFGWxS(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVLOHV + fil
     if fileExists(path):
      lines = FFFfvw(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFNh5K(True)
  if bNames: txt = "%s\n\n%s" % (FFY7FT("Deleted Bouquets:", VVJ2KG), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FFyv2f(self, txt, title=title)
 def VVx3Zn(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VV3ttv(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVLOHV)
  for srcF in files:
   if fileExists(srcF):
    lines = FFFfvw(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFn1G7(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VVJ89i(self, title)   : self.VVi2P3(title, True)
 def VVcWYm(self, title) : self.VVi2P3(title, False)
 def VVi2P3(self, title, isWithPIcons):
  piconsPath = CCMxom.VVVqXw()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCMxom.VVmE5k(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVuV68, err = CCyEBX.VVCZgt(self, self.VVQcI8)
    if VVuV68:
     channels = []
     for (chName, chProv, sat, refCode) in VVuV68:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFjOJJ(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVuV68)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VV5vDG(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VV5vDG("PIcons Path"  , piconsPath)
     txt += VV5vDG("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VV5vDG("Total services" , totalServices)
     txt += VV5vDG("With PIcons"  , totalWithPIcons)
     txt += VV5vDG("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFyv2f(self, txt)
     else:
      VVd4CR     = (""      , self.VVbVGK , [])
      if isWithPIcons : VVmmwr = ("Export Current PIcon", self.VVNlLW  , [])
      else   : VVmmwr = None
      VVQR2V     = ("Statistics", FFyv2f, [txt])
      VVVi12      = ("Zap", self.VVQES3, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VVvoqt(title, channels, VVVi12=VVVi12, VVd4CR=VVd4CR, VVQR2V=VVQR2V, VVmmwr=VVmmwr)
   else:
    FFa349(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFa349(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVbVGK(self, VVXOwS, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFr9gS(self, fncMode=CCsydO.VVaGCy, refCode=refCode, chName=chName, text=txt)
 def VVNlLW(self, VVXOwS, title, txt, colList):
  png, path = CCMxom.VVscgM(colList[3], colList[0])
  if path:
   CCMxom.VVPyLa(self, png, path)
 @staticmethod
 def VVeusg():
  VVekD9  = "%slamedb" % VVLOHV
  VVRLP2 = "%slamedb.disabled" % VVLOHV
  return VVekD9, VVRLP2
 @staticmethod
 def VVWncM():
  VVpHHH  = "%slamedb5" % VVLOHV
  VVWlUh = "%slamedb5.disabled" % VVLOHV
  return VVpHHH, VVWlUh
 def VV2TXd(self, isEnable):
  VVekD9, VVRLP2 = CCyEBX.VVeusg()
  if isEnable and not fileExists(VVRLP2):
   FF5nWa(self, "Aready enabled.")
  elif not isEnable and not fileExists(VVekD9):
   FFa349(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FF8XzP(self, BF(self.VVrjFJ, isEnable), "%s Hidden Channels ?" % word)
 def VVrjFJ(self, isEnable):
  VVekD9 , VVRLP2 = CCyEBX.VVeusg()
  VVpHHH, VVWlUh = CCyEBX.VVWncM()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVRLP2, VVRLP2, VVekD9)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVWlUh, VVWlUh, VVpHHH)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVekD9  , VVekD9 , VVRLP2)
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVpHHH , VVpHHH, VVWlUh)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVRLP2, VVekD9 )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVWlUh, VVpHHH)
  res = os.system(cmd)
  FFNh5K()
  if res == 0 : FF5nWa(self, "Hidden List %s" % word)
  else  : FFa349(self, "Error while restoring:\n\n%s" % fileName)
 def VV6oxh(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %ssettings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVLOHV
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %ssettings" % VVLOHV
  FFNdGr(self, cmd)
 def VVgh7x(self):
  VVekD9, err = CCyEBX.VVDJAJ(self)
  if err:
   return
  tmpFile = "/tmp/ajp_lamedb"
  FFGWxS(tmpFile)
  totChan = totRemoved = 0
  lines = FFFfvw(VVekD9, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FF8XzP(self, BF(FF7Xva, self, BF(self.VVaycf, tmpFile, VVekD9, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FFmJCK(totRemoved), totChan, FFmJCK(totChan))
      , callBack_No=BF(self.VV8UY6, tmpFile))
  else:
   FFyv2f(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VVaycf(self, tmpFile, VVekD9, totRemoved, totChan):
  os.system(FFQe93("mv -f '%s' '%s'" % (tmpFile, VVekD9)))
  FFNh5K()
  FFyv2f(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VV8UY6(self, tmpFile):
  FFGWxS(tmpFile)
 @staticmethod
 def VVDJAJ(SELF, VVvSQT=True, title=""):
  VVekD9, VVRLP2 = CCyEBX.VVeusg()
  if   not fileExists(VVekD9)       : err = "File not found !\n\n%s" % VVekD9
  elif not CCbI7Z.VV8ERc(SELF, VVekD9) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VVvSQT:
   FFa349(SELF, err, title=title)
  return VVekD9, err
 @staticmethod
 def VVBDw2(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VV8qP6(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VVKpWw(servTypes):
  VVjSyF  = eServiceCenter.getInstance()
  VVX3JY   = '%s ORDER BY name' % servTypes
  VVDepC   = eServiceReference(VVX3JY)
  VVmPvx = VVjSyF.list(VVDepC)
  if VVmPvx: return VVmPvx.getContent("CN", False)
  else     : return []
 @staticmethod
 def VVuEJD():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CCsydO(Screen):
 VVPCQS  = 0
 VVaNQw   = 1
 VV2AHk   = 2
 VVaGCy    = 3
 VVRwEk    = 4
 VV5FUA   = 5
 VVVuvA   = 6
 VVlfcQ    = 7
 VVY4BY   = 8
 VVP677   = 9
 VVn327   = 10
 VV76s6   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFXh6Y(VVnxJO, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVPCQS)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFY7FT("%s\n", VVQasA) % VVI8D8
  self.picViewer  = None
  FFwLhV(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVfl2R })
  self["myPicF"] = Label()
  self["myPicB"] = Label()
  self["myPic"] = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVfcAc)
  self.onClose.append(self.onExit)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  self["myLabel"].VVYV4X(outputFileToSave="chann_info")
  if   self.fncMode == self.VVPCQS : fnc = self.VV82Tq
  elif self.fncMode == self.VVaNQw  : fnc = self.VV82Tq
  elif self.fncMode == self.VV2AHk  : fnc = self.VV82Tq
  elif self.fncMode == self.VVaGCy  : fnc = self.VVEpLq
  elif self.fncMode == self.VVRwEk  : fnc = self.VVi8iF
  elif self.fncMode == self.VV5FUA  : fnc = self.VVfCJ3
  elif self.fncMode == self.VVVuvA  : fnc = self.VV7Zdq
  elif self.fncMode == self.VVlfcQ  : fnc = self.VVK0P4
  elif self.fncMode == self.VVY4BY  : fnc = self.VVEwtg
  elif self.fncMode == self.VVP677 : fnc = self.VVRfDS
  elif self.fncMode == self.VVn327  : fnc = self.VVgJsX
  elif self.fncMode == self.VV76s6 : fnc = self.VVFwbU
  self["myLabel"].setText("\n   Reading Info ...")
  FFWlvR(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVNMsK()
 def VV6p96(self, err):
  self["myLabel"].setText(err)
  FF0e9t(self["myTitle"], "#22200000")
  FF0e9t(self["myBody"], "#22200000")
  self["myLabel"].VVWUAw("#22200000")
  self["myLabel"].VV8D9h()
 def VV82Tq(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self)
  self.refCode = refCode
  self.VVSPzR(chName)
 def VVEpLq(self):
  self.VVSPzR(self.chName)
 def VVi8iF(self):
  self.VVSPzR(self.chName)
 def VVfCJ3(self):
  self.VVSPzR(self.chName)
 def VV7Zdq(self):
  self.VVSPzR("Picon Info")
 def VVK0P4(self):
  self.VVSPzR(self.chName)
 def VVEwtg(self):
  self.VVSPzR(self.chName)
 def VVRfDS(self):
  self.VVSPzR(self.chName)
 def VVgJsX(self):
  self.chUrl = self.refCode + self.callingSELF.VVpw0C(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVSPzR(self.chName)
 def VVFwbU(self):
  self.VVSPzR(self.chName)
 def VVSPzR(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFSXdj(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVsY5k(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFY7FT(self.VVNK4c(tUrl), VVBh5X)
  if not self.epg:
   epg = CCos4Q.VVSTU8(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVm2jc(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCMxom.VVscgM(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVm2jc(path)
  self.VVXpkA()
  self.VVwpDa()
  self["myLabel"].setText(self.text or "   No active service", VVpV1e=VVXinG)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VV8D9h(minHeight=minH)
 def VVwpDa(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFDOE0(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVS1sA(FFdOos(url))
  if epg:
   self.text += "\n" + FFh5T1("EPG:", VVJ2KG) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVXpkA()
 def VVXpkA(self):
  if not self.piconShown and self.picUrl:
   path, err = FFjmFi(self.picUrl, "ajp_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVm2jc(path)
    if self.piconShown and self.refCode:
     self.VV8Tr9(path, self.refCode)
 def VV8Tr9(self, path, refCode):
  if path and fileExists(path) and os.system(FFQe93("which ffmpeg")) == 0:
   pPath = CCMxom.VVVqXw()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CCsydO.VVgxpk(path)
    cmd += FFQe93("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVm2jc(self, path):
  if path and fileExists(path):
   err, w, h = self.VVTOOl(path)
   if not err:
    if h > w:
     self.VVPGQw(self["myPicF"], w, h, True)
     self.VVPGQw(self["myPicB"], w, h, False)
     self.VVPGQw(self["myPic"] , w, h, False)
   self.picViewer = CChvOR.VVrzHP(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VVPGQw(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVTOOl(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFyJfo(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVsY5k(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFY7FT(chName, VVJ2KG)
  txt += self.VV5vDG(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFY7FT(state, VV9ZlA)
   txt += "State\t: %s\n" % state
  w = FFxRrg(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFxRrg(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVXzKq(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VV5vDG(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VV5vDG(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VV5vDG(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VV0ot9()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VV9naW()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCsydO.VVP9uN(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFY7FT("Stream-Relay" if FFTxso(decodedUrl) else "IPTV", VV5cg1)
   txt += self.VVLia3(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVg8z5(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCEpHi()
    tpTxt, namespace = tp.VVg9nN(refCode)
    if tpTxt:
     txt += FFY7FT("Tuner:\n", VVJ2KG)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFY7FT("Codes:\n", VVJ2KG)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VV5vDG(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VV5vDG(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VV5vDG(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VV5vDG(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VV5vDG(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VV5vDG(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VV5vDG(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VV5vDG(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VV5vDG(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVXzKq(info):
  if info:
   aspect = FFxRrg(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VV5vDG(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFxRrg(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVMWrg(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVMWrg(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VV0ot9(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VV9naW(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVg8z5(self, refCode, iptvRef, chName):
  refCode = FFxv8F(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFqXAw(VVLOHV + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFqXAw(VVLOHV + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VV6fdw = []
  tmpRefCode = FFdOos(refCode)
  for item in fList:
   path = VVLOHV + item
   if fileExists(path):
    txt = FFqXAw(path)
    if tmpRefCode in FFdOos(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VV6fdw.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VV6fdw:
   if len(VV6fdw) == 1:
    txt += "%s\t: %s%s\n" % (FFY7FT("Bouquet", VVJ2KG), VV6fdw[0][0], " (%s)" % VV6fdw[0][1] if VVpn8D else "")
   else:
    txt += FFY7FT("Bouquets:\n", VVJ2KG)
    for ndx, item in enumerate(VV6fdw):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVpn8D else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVLia3(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFTSbj(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CC2WTV()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV3YVQ(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFY7FT("URL:", VV5cg1) + "\n%s\n" % self.VVNK4c(decodedUrl)
  else:
   txt = "\n"
   txt += FFY7FT("Reference:", VV5cg1) + "\n%s\n" % refCode
  return txt
 def VVNK4c(self, url):
  if not FFTxso(url):
   span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
   if span:
    url = span.group(1)
   if not VV5W0y:
    url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return FFdOos(url)
 def VVS1sA(self, decodedUrl):
  if not CCkcR1.VVGFKI():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCgg3d.VVHvuJ(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCgg3d.VVTXoD(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVvabu(tDict)
   elif uType == "movie" : epg, picUrl = CCsydO.VVBvRq(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVvabu(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCgg3d.VVgvLY(item, "title"    , is_base64=True )
     lang    = CCgg3d.VVgvLY(item, "lang"         ).upper()
     description   = CCgg3d.VVgvLY(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCgg3d.VVgvLY(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCgg3d.VVgvLY(item, "start_timestamp"      )
     stop_timestamp  = CCgg3d.VVgvLY(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCgg3d.VVgvLY(item, "stop_timestamp"       )
     now_playing   = CCgg3d.VVgvLY(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VV0Duj, ""
      else     : color, txt = VV9ZlA , "    (CURRENT EVENT)"
      epg += FFY7FT("_" * 32 + "\n", VVQasA)
      epg += FFY7FT("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFY7FT(description, VVBh5X)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = CCos4Q.VVsRne(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)], longDescDays=7)
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VVBvRq(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCgg3d.VVgvLY(item, "movie_image" )
    genre  = CCgg3d.VVgvLY(item, "genre"   ) or "-"
    plot  = CCgg3d.VVgvLY(item, "plot"   ) or "-"
    cast  = CCgg3d.VVgvLY(item, "cast"   ) or "-"
    rating  = CCgg3d.VVgvLY(item, "rating"   ) or "-"
    director = CCgg3d.VVgvLY(item, "director"  ) or "-"
    releasedate = CCgg3d.VVgvLY(item, "releasedate" ) or "-"
    duration = CCgg3d.VVgvLY(item, "duration"  ) or "-"
    try:
     lang = CCgg3d.VVgvLY(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFY7FT(cast, VVBh5X)
    epg += "Plot:\n%s"    % FFY7FT(plot, VVBh5X)
   except:
    pass
  return epg, movie_image
 def VVfl2R(self):
  if VV5W0y:
   def VV5vDG(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VV5vDG(n[i], v[i])
   if "chCode" in iptvRef:
    p = CC2WTV()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV3YVQ(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VV5vDG(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (VVI8D8, txt))
   FF1ojr(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VV3T5J(SELF):
  if not CCTs8V.VVMo6T(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(SELF)
  err = url =  fSize = resumable = ""
  if FF6GnB(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CC2WTV.VVWwnk(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CC2WTV.VVZSNI(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FFa349(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCbI7Z.VVr8MR(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFY7FT(" (M3U/M3U8 File)", VVBh5X)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCXCxH.VVfqRa(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVObU9(subj, val):
   return "%s\n%s\n\n" % (FFY7FT("%s:" % subj, VVJ2KG), val)
  title = "File Size"
  txt  = VVObU9(title , fSize or "?")
  txt += VVObU9("Name" , chName)
  txt += VVObU9("URL" , url)
  if resumable: txt += VVObU9("Supports Download-Resume", resumable)
  if err  : txt += FFY7FT("Error:\n", VV9ZlA) + err
  FFyv2f(SELF, txt, title=title)
 @staticmethod
 def VVP9uN(SELF):
  fPath, fDir, fName = CCbI7Z.VVzTch(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVgxpk(path):
  return "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
 @staticmethod
 def VVQQzv(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CCMxom.VVVqXw() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VVf5x2(serv):
  isLocal = isIptv = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if FFDOE0(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFn1G7(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CC2WTV():
 def __init__(self):
  self.VVHe9L()
  self.VVDeuh    = ""
  self.VVLhpI   = "#f#11ffffaa#User"
  self.VVs59H   = "#f#11aaffff#Server"
 def VVHe9L(self):
  self.VVGVRb   = ""
  self.VVnueZ    = ""
  self.VVNu9N   = ""
  self.VVLfo3 = ""
  self.VVDkUc  = ""
  self.VVjz2H = 0
 def VVmNne(self, url, mac, ph1="", VVik2e=True):
  self.VVHe9L()
  self.VVDeuh = {"s": "/server/load.php", "p": "/portal.php"}.get(ph1, "")
  host = self.VVVxJm(url)
  if not host:
   if VVik2e:
    self.VVYjXn("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVjJTl(mac)
  if not host:
   if VVik2e:
    self.VVYjXn("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVGVRb = host
  self.VVnueZ  = mac
  return True
 def VVVxJm(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVjJTl(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVwHee(self):
  res, err = self.VVGfUW(self.VVud1G())
  if "404" in err or res and res.status_code == 200 and not res.text.strip():
   if self.VVGVRb.endswith("/c"):
    self.VVGVRb = self.VVGVRb[:-2]
    res, err = self.VVGfUW(self.VVud1G())
   elif self.VVGVRb.endswith("/stalker_portal"):
    self.VVGVRb = self.VVGVRb[:-15]
    res, err = self.VVGfUW(self.VVud1G())
   else:
    self.VVGVRb += "/c"
    res, err = self.VVGfUW(self.VVud1G())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCgg3d.VVgvLY(tDict["js"], "token")
    rand  = CCgg3d.VVgvLY(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVZGHX(self, VVik2e=True):
  if not self.VVDeuh:
   self.VV6Rui()
  err = blkMsg = FF5nWaTxt = ""
  try:
   token, rand, err = self.VVwHee()
   if token:
    self.VVNu9N = token
    self.VVLfo3 = rand
    if rand:
     self.VVjz2H = 2
    prof, retTxt = self.VVQzpz(True)
    if prof:
     self.VVDkUc = retTxt
     if any(x in retTxt for x in ("device_id mismatch", "old firmware")):
      self.VVjz2H = 3
      prof, retTxt = self.VVQzpz(False)
      if retTxt:
       self.VVDkUc = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FF5nWaTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FF5nWaTxt: tErr += "\n%s" % FF5nWaTxt
  if VVik2e:
   self.VVYjXn(tErr)
  return "", "", tErr
 def VV6Rui(self):
  try:
   import requests
   url = self.VV0TPr()
   jsFile = "xpcom.common.js"
   res = requests.get("%s/stalker_portal/c/%s" % (url, jsFile), headers=CC2WTV.VVZSNI(), stream=True, timeout=2)
   if not res.ok or not "javascript" in res.headers.get("content-type"):
    res = requests.get("%s/c/%s" % (url, jsFile), headers=CC2WTV.VVZSNI(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    patt = ""
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r"\s*var\s+pattern\s*=\s*\/(.+)\/\s*;", line, IGNORECASE)
      if span:
       patt = span.group(1)
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       if "portal_path" in line:
        if patt.endswith("*\/(.)*") : url += "/c"
        else      : url += "/stalker_portal"
       self.VVGVRb = url
       self.VVDeuh = span.group(1)
       return
  except:
   pass
  self.VVDeuh = "/server/load.php"
 def VV0TPr(self):
  url = self.VVGVRb.rstrip("/")
  if url.endswith("/c")    : url = url[:-2]
  if url.endswith("/stalker_portal") : url = url[:-15]
  if url.endswith("/c")    : url = url[:-2]
  return url
 def VV872v(self, url, isJsFile=False):
  import requests
  jsFile = "xpcom.common.js" if isJsFile else "version.js"
  res, err = self.VVGfUW("%s/stalker_portal/c/%s" % (url, jsFile))
  if not res or not "javascript" in res.headers.get("content-type"):
   res, err = self.VVGfUW("%s/c/%s" % (url, jsFile))
  if res and "javascript" in res.headers.get("content-type"):
   if isJsFile:
    return str(res.content), ""
   else:
    span = iSearch(r"var\s+ver\s*=\s*'(.+)'", res.text, IGNORECASE)
    if span:
     return span.group(1), ""
  return "", err
 def VVQzpz(self, capMac):
  res, err = self.VVGfUW(self.VVvAvL(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCgg3d.VVgvLY(tDict["js"], "block_%s" % word)
    FF5nWaTxt = CCgg3d.VVgvLY(tDict["js"], word)
    return tDict, FF5nWaTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVvAvL(self, capMac):
  param = ""
  if self.VVDkUc or self.VVLfo3:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVnueZ.upper() if capMac else self.VVnueZ.lower(), self.VVLfo3))
  return self.VV0Fse() + "type=stb&action=get_profile" + param
 exec(FF5dpp("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gPSAiJmF1dGhfc2Vjb25kX3N0ZXA9MSZod192ZXJzaW9uPTIuMTctSUItMDAmaHdfdmVyc2lvbl8yPTYyJnNuPSVzJmRldmljZV9pZD0lcyZkZXZpY2VfaWQyPSVzJnNpZ25hdHVyZT0lcyIgJSAoSWRbMF0sIElkWzFdLCBJZFsxXSwgSWRbMl0pDQogcmV0dXJuIHBhcmFtICsgJyZ2ZXI9UGxheWVyIEVuZ2luZSB2ZXJzaW9uOiAweDU4YyZtZXRyaWNzPXsibWFjIjoiJXMiLCJzbiI6IiVzIiwidHlwZSI6IlNUQiIsIm1vZGVsIjoiTUFHMjUwIiwicmFuZG9tIjoiJXMifScgJSAoSWRbM10sIElkWzBdLCBJZFs0XSkNCmRlZiBnZXRNb3JlQXV0aF9JRHMoc2VsZiwgbSwgcik6DQogaW1wb3J0IGhhc2hsaWINCiBtYWNVdGY4ID0gbS5lbmNvZGUoJ3V0Zi04JykNCiBzID0gaGFzaGxpYi5tZDUobWFjVXRmOCkuaGV4ZGlnZXN0KCkudXBwZXIoKVs6MTNdDQogcmV0dXJuIHMsIGhhc2hsaWIuc2hhMjU2KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKCksIGhhc2hsaWIuc2hhMjU2KChzICsgbSkuZW5jb2RlKCd1dGYtOCcpKS5oZXhkaWdlc3QoKS51cHBlcigpLCBtLCBy"))
 def VV968I(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVi1UA()
  if len(rows) < 10:
   rows = self.VV77t6()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVGVRb ))
   rows.append(("MAC (from URL)" , self.VVnueZ ))
   rows.append(("Token"   , self.VVNu9N ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VVLhpI  , "MAC" , self.VVnueZ ))
   rows.append(("2", self.VVs59H, "Host" , self.VVGVRb ))
   rows.append(("2", self.VVs59H, "Token" , self.VVNu9N ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VV0rkX(self, isPhp=True, VVik2e=False):
  token, profile, tErr = self.VVZGHX(VVik2e)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VVw9yA()
  res, err = self.VVGfUW(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCgg3d.VVgvLY(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFgbDs(span.group(2))
     pass1 = FFgbDs(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VVi1UA(self):
  m3u_Url, host, user1, pass1, err = self.VV0rkX()
  rows = []
  if m3u_Url:
   res, err = self.VVGfUW(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFXtJp(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VVLhpI, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFXtJp(int(val))
      else      : val = str(val)
      rows.append(("2", self.VVs59H, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VV77t6(self):
  token, profile, tErr = self.VVZGHX()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFM2at(val): val = FF5dpp(val.decode("UTF-8"))
     else     : val = self.VVnueZ
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFXtJp(int(parts[1]))
      if parts[2] : ends = FFXtJp(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFXtJp(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVpw0C(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVZGHX(VVik2e=False)
  if not token:
   return ""
  crLinkUrl = self.VV0Kb7(mode, chCm, epNum, epId)
  res, err = self.VVGfUW(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCgg3d.VVgvLY(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VV0Fse(self):
  return self.VVGVRb + self.VVDeuh + "?"
 def VVud1G(self):
  return self.VV0Fse() + "type=stb&action=handshake&token=&mac=%s" % self.VVnueZ
 def VV6d3l(self, mode):
  url = self.VV0Fse() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VV2YCW(self, catID):
  return self.VV0Fse() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVYsu3(self, mode, catID, page):
  url = self.VV0Fse() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVuL9I(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VV0Fse() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVmI8f(self, mode, catID):
  return self.VV0Fse() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VV0Kb7(self, mode, chCm, serCode, serId):
  url = self.VV0Fse() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=0&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVw9yA(self):
  return self.VV0Fse() + "type=itv&action=create_link"
 def VVRnJM(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVbRWT(catID, stID, chNum)
  query = self.VV4ZPb(mode, self.VVDeuh[1:2], FFe9aJ(host), FFe9aJ(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VV4ZPb(self, mode, ph1, host, mac, serCode, serId, chCm):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VV3YVQ(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VV4ZPb(mode, ph1, host, mac, epNum, epId, FFgbDs(chCm))
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FF5dpp(host)
  mac   = FF5dpp(mac)
  valid = False
  if self.VVVxJm(playHost) and self.VVVxJm(host) and self.VVVxJm(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVGfUW(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CC2WTV.VVZSNI()
   if self.VVNu9N:
    headers["Authorization"] = "Bearer %s" % self.VVNu9N
   if useCookies : cookies = {"mac": self.VVnueZ, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok:
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVGRLW(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CC2WTV.VVZSNI(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVZSNI():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVVPrB(host, mac, tType, action, keysList=None):
  myPortal = CC2WTV()
  ph1 = "s"
  pref = "/portal.php" if par == "p" else "/server/load.php"
  ok = myPortal.VVmNne(host, mac, ph1)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVZGHX(VVik2e=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s%s?type=%s&action=%s" % (host, ph1, tType, action)
  res, err = myPortal.VVGfUW(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVDjXd(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVDjXd(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVYjXn(self, err, title="Portal Browser"):
  FFa349(self, str(err), title=title)
 def VVbPwt(self, mode):
  if   mode in ("itv"  , CCgg3d.VVdkUS , CCgg3d.VVi2Nw)  : return "Live"
  elif mode in ("vod"  , CCgg3d.VV6MCx , CCgg3d.VVNXbt)  : return "VOD"
  elif mode in ("series" , CCgg3d.VVxW0j , CCgg3d.VVKLUx) : return "Series"
  else                          : return "IPTV"
 def VVYHPj(self, mode, searchName):
  return 'Find in %s : %s' % (self.VVbPwt(mode), FFY7FT(searchName, VVBh5X))
 def VVq42K(self, catchup=False):
  VVW1xb = []
  VVW1xb.append(("Live"    , "live"  ))
  VVW1xb.append(("VOD"    , "vod"   ))
  VVW1xb.append(("Series"   , "series"  ))
  if catchup:
   VVW1xb.append(VVswUs)
   VVW1xb.append(("Catch-up TV" , "catchup"  ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Account Info." , "accountInfo" ))
  return VVW1xb
 @staticmethod
 def VViiHf(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CC2WTV()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV3YVQ(decodedUrl)
  if valid:
   ok = p.VVmNne(host, mac, ph1, VVik2e=False)
   if ok:
    m3u_Url, host, user1, pass1, err = p.VV0rkX(isPhp=False, VVik2e=False)
    streamId = CC2WTV.VVEJX8(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err
 @staticmethod
 def VVEJX8(decodedUrl):
  p = CC2WTV()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV3YVQ(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FF5dpp(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVWwnk(decodedUrl):
  p = CC2WTV()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV3YVQ(decodedUrl)
  if valid:
   if CC2WTV.VV9XTT(chCm):
    return FFdOos(chCm)
   else:
    ok = p.VVmNne(host, mac, ph1, VVik2e=False)
    if ok:
     try:
      chUrl = p.VVpw0C(mode, chCm, epNum, epId)
      return FFdOos(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VV9XTT(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
class CCrYKH(CC2WTV):
 def __init__(self):
  CC2WTV.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVBesS(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = self.VV3YVQ(decodedUrl)
  if valid:
   if self.VVmNne(host, mac, ph1, VVik2e=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVPczX(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVpw0C(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CC2WTV.VV9XTT(self.chCm):
   chUrl = FFdOos(self.chCm)
   chUrl = FFgbDs(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVgetT(chUrl)
  bPath = CCRtNz.VVEd4a()
  if newIptvRef:
   if passedSELF:
    FFqi6V(passedSELF, newIptvRef, VVEPKV=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFqi6V(self, newIptvRef, VVEPKV=False, fromPrtalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VVVVtl(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VVgetT(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVVVtl(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("&ph1=s", "&ph1=p", "&ph1=")
   for param in params: newPar = newPar.replace(param, "")
   lines = FFFfvw(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for param in params: filePar = filePar.replace(param, "")
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFNh5K()
class CCdHvm(CCrYKH):
 def __init__(self, passedSession):
  CCrYKH.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVJLXo(VVlaqR  )
  Main_Menu.VVJLXo(VVNAJh)
  Main_Menu.VVJLXo(VVpOwn  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVIHNu, iPlayableService.evEOF: self.VV50dq, iPlayableService.evEnd: self.VVeY8N})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVum9I)
  except:
   self.timer2.callback.append(self.VVum9I)
  self.timer2.start(3000, False)
  self.VVum9I()
 def VVum9I(self):
  if not CFG.downloadMonitor.getValue():
   self.VVrqlo()
   return
  lst = CCXCxH.VVWfZP()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FFPYZx(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCXCxH.VVCnA6(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin:
    self.dnldWin = self.passedSession.instantiateDialog(CCFLAA, txt, 30)
    self.dnldWin.instance.move(ePoint(30, 20))
    self.dnldWin.show()
    FFTlDF(self.dnldWin["myWinTitle"], "#440000", 1)
   else:
    self.dnldWin["myWinTitle"].setText(txt)
  elif self.dnldWin:
   self.VVrqlo()
 def VVrqlo(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVIHNu(self):
  self.startTime = iTime()
 def VV50dq(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self.passedSession, isFromSession=True)
    if iptvRef and not "file?file" in iptvRef and not ":ftp%3a//" in iptvRef and not FF6GnB(decodedUrl):
     self.isFromEOF = True
     CCCSgg(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVeY8N(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVXznB)
  except:
   self.timer1.callback.append(self.VVXznB)
  self.timer1.start(100, True)
 def VVXznB(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVBesS(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCXzGX.VV2jNU:
       self.isFromEOF = False
       self.VVPczX(self.passedSession, isFromSession=True)
class CCJU0G():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-z0-9\/\-._:|\]\[]+[\])|:](.+)")
  self.adultWords  = ("adult","aduld","sex","porn","xxx","xxi","erotic","x-rated","xrated","skin flick","dirty movie","dirty film","blue movie","blue film","18+","+18","r18 movie","r18 film","r-18 movie","r-18 film","r-17 movie","r-17 film")
  self.adultWords2 = ("\u042d\u0440\u043e\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0435", "dla doros\u0142ych")
 def VVaoP0(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCgg3d.VVKc8C(name):
   return CCgg3d.VV4Azf(name)
  name = self.VV1UPl(name)
  return name.strip() or name
 def VV1UPl(self, name):
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     return tName
  return name
 def VVrwsf(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VV1UPl(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVf5ab(self, name):
  if self.hideAdult:
   if any(x in name.lower() for x in self.adultWords):
    return ""
   elif any(x in name.encode('ascii', 'backslashreplace').decode('utf-8').lower() for x in self.adultWords2):
    return ""
  return name.strip()
 def VV3FFy(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVQ3aK(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCTs8V(CC2WTV):
 def __init__(self):
  CC2WTV.__init__(self)
 def VVU7bT(self):
  if CCTs8V.VVMo6T(self):
   FF7Xva(self, BF(self.VVDsRp, 2), title="Searching ...")
 def VV7HZ9(self, winSession, url, mac):
  self.curUrl = url
  if CCTs8V.VVMo6T(self):
   if self.VVmNne(url, mac):
    FF7Xva(winSession, self.VVdAfk, title="Checking Server ...")
   else:
    FFa349(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VV5AwT(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = CCAUx4.VVx4Et(path, self)
   if enc == -1:
    return
   self.session.open(CCvBnC, barTheme=CCvBnC.VVrdqg
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VV4BSr, path, enc)
       , VVnRGv = BF(self.VVxeB3, menuInstance, path))
 def VV4BSr(self, path, enc, VVhsRS):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVhsRS.VVBrFN(totLines)
  VVhsRS.VVLNy3 = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVhsRS or VVhsRS.isCancelled:
     return
    VVhsRS.VVwvD4(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVVxJm(url)
     mac  = self.VVjJTl(mac)
     if host and mac and VVhsRS:
      VVhsRS.VVLNy3.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVVxJm(url)
      mac  = self.VVjJTl(mac)
      if host and mac and not mac.startswith("AC") and VVhsRS:
       VVhsRS.VVLNy3.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVxeB3(self, menuInstance, path, VVL4pA, VVLNy3, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVLNy3:
   VVQcug  = ("Home Menu"  , FFJAbK            , [])
   VVQR2V = ("Edit File"  , BF(self.VVOtwd, path)       , [])
   VVsTsL = ("M3U Options" , self.VV3z8V         , [])
   VVmmwr = ("Check & Filter" , BF(self.VVsANI, menuInstance, path), [])
   VVVi12  = ("Select"   , self.VVNds4      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVI7B0  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVXOwS = FFEM8S(self, None, title=title, header=header, VV6fdw=VVLNy3, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26, VVVi12=VVVi12, VVQcug=VVQcug, VVsTsL=VVsTsL, VVQR2V=VVQR2V, VVmmwr=VVmmwr, VVgchu="#0a001122", VVn4Mh="#0a001122", VVMqKH="#0a001122", VVntre="#00004455", VV3VhT="#0a333333", VVwlSC="#11331100", VVhmtx=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VVL4pA:
    FF1ojr(VVXOwS, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVL4pA:
    FFa349(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VV3z8V(self, VVXOwS, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVW1xb = []
  VVW1xb.append(("Browse as M3U"  , "browse"))
  VVW1xb.append(("Download M3U File" , "downld"))
  FFLFXy(self, BF(self.VVkmwv, VVXOwS, host, mac), title=title, VVW1xb=VVW1xb, width=600, VVxhca=True)
 def VVkmwv(self, VVXOwS, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FF7Xva(VVXOwS, BF(self.VVQ8YP, VVXOwS, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FF8XzP(self, BF(FF7Xva, VVXOwS, BF(self.VVQ8YP, VVXOwS, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVQ8YP(self, VVXOwS, title, host, mac, item):
  p = CC2WTV()
  m3u_Url = ""
  ok = p.VVmNne(host, mac, VVik2e=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VV0rkX(VVik2e=False)
  if m3u_Url:
   if   item == "browse": self.VVeNEH(title, m3u_Url)
   elif item == "downld": self.VVcKDG(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FFa349(self, err or "No response from Server !", title=title)
 def VVNds4(self, VVXOwS, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VV7HZ9(VVXOwS, url, mac)
 def VVOtwd(self, path, VVXOwS, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCtuLp(self, path, VVnRGv=BF(self.VVAf3z, VVXOwS), curRowNum=rowNum)
  else    : FFRYkM(self, path)
 def VVsANI(self, menuInstance, path, VVXOwS, title, txt, colList):
  self.session.open(CCvBnC, barTheme=CCvBnC.VVjpsh
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VVYN22, VVXOwS)
      , VVnRGv = BF(self.VV2LT6, menuInstance, VVXOwS, path))
 def VVYN22(self, VVXOwS, VVhsRS):
  VVhsRS.VVLNy3 = []
  VVhsRS.VVBrFN(VVXOwS.VV9Wh4())
  for row in VVXOwS.VVWsuW():
   if not VVhsRS or VVhsRS.isCancelled:
    return
   VVhsRS.VVwvD4(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVmNne(host, mac, VVik2e=False):
    token, profile, tErr = self.VVZGHX(VVik2e=False)
    if token and VVhsRS and not VVhsRS.isCancelled:
     res, err = self.VVGfUW(self.VV6d3l("itv"))
     if res and VVhsRS and not VVhsRS.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVhsRS.VVwvD4(0, showFound=True)
       VVhsRS.VVLNy3.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVhsRS:
    return
 def VV2LT6(self, menuInstance, VVXOwS, path, VVL4pA, VVLNy3, threadCounter, threadTotal, threadErr):
  if VVLNy3:
   VVXOwS.close()
   menuInstance.close()
   newPath = "%s_OK_%s.txt" % (path, FFJCyp())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVLNy3:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FFY7FT(str(threadCounter), VV9ZlA)
    skipped = FFY7FT(str(threadTotal - threadCounter), VV9ZlA)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVLNy3)
   txt += "%s\n\n%s"    %  (FFY7FT("Result File:", VVJ2KG), newPath)
   FFyv2f(self, txt, title="Accessible Portals")
  elif VVL4pA:
   FFa349(self, "No portal access found !", title="Accessible Portals")
 def VVcSkZ(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FF5dpp(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVdAfk(self):
  token, profile, tErr = self.VVZGHX()
  if token:
   dots = "." * self.VVjz2H
   dots += "+" if self.VVDeuh[1:2] == "p" else ""
   dots += "*" if not self.VVGVRb == self.curUrl else ""
   VVW1xb  = self.VVq42K()
   OKBtnFnc = self.VVgF3Z
   infoBtnFnc = self.VVUvtB
   VVszaU = ("Home Menu", FFJAbK)
   VVa3i0= ("Add to Menu", BF(CCgg3d.VV2HYx, self, True, self.VVGVRb + "\t" + self.VVnueZ))
   VVkjyo = ("Bookmark Server", BF(CCgg3d.VVlyBr, self, True, self.VVGVRb + "\t" + self.VVnueZ))
   FFLFXy(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVnueZ, dots), VVW1xb=VVW1xb, OKBtnFnc=OKBtnFnc, infoBtnFnc=infoBtnFnc, VVszaU=VVszaU, VVa3i0=VVa3i0, VVkjyo=VVkjyo)
 def VVgF3Z(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FF7Xva(menuInstance, BF(self.VV8hhn, mode), title="Reading Categories ...")
   else : FF7Xva(menuInstance, BF(self.VVKRD8, menuInstance, title), title="Reading Account ...")
 def VVKRD8(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VV968I(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVnueZ)
  VVQcug  = ("Home Menu" , FFJAbK           , [])
  VVsTsL  = None
  if VV5W0y:
   VVsTsL = ("Get JS"  , BF(self.VVcRoQ, self.VV0TPr()) , [])
  if totCols == 2:
   VVmmwr = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVmmwr = ("More Info.", BF(self.VVG3Q8, menuInstance)    , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFEM8S(self, None, title=title, width=1200, header=header, VV6fdw=rows, VVHqY6=widths, VVJmZ8=26, VVQcug=VVQcug, VVsTsL=VVsTsL, VVmmwr=VVmmwr, VVgchu="#0a00292B", VVn4Mh="#0a002126", VVMqKH="#0a002126", VVntre="#00000000", searchCol=searchCol)
 def VVcRoQ(self, url, VVXOwS, title, txt, colList):
  FF7Xva(VVXOwS, BF(self.VVq0RI, url), title="Getting JS ...")
 def VVq0RI(self, url):
  txt  = "// Host\t: %s\t%s\n" % (url, self.VVnueZ)
  ver, err = self.VV872v(url)
  txt += "// Version\t: %s\n\n" % (ver or err)
  js , err = self.VV872v(url, isJsFile=True)
  if err: txt += "Error : %s" % err
  else  : txt += js
  FFyv2f(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VVG3Q8(self, menuInstance, VVXOwS, title, txt, colList):
  VVXOwS.cancel()
  FF7Xva(menuInstance, BF(self.VVKRD8, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VV8hhn(self, mode):
  token, profile, tErr = self.VVZGHX()
  if not token:
   return
  res, err = self.VVGfUW(self.VV6d3l(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     VVX1Oz = CCJU0G()
     chList = tDict["js"]
     for item in chList:
      Id   = CCgg3d.VVgvLY(item, "id"       )
      Title  = CCgg3d.VVgvLY(item, "title"      )
      censored = CCgg3d.VVgvLY(item, "censored"     )
      Title = VVX1Oz.VVf5ab(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVpn8D:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVbPwt(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVgchu, VVn4Mh, VVMqKH, VVntre = self.VVYCkd(mode)
   mName = self.VVbPwt(mode)
   VVVi12   = ("Show List"   , BF(self.VVJZ7a, mode)   , [])
   VVQcug  = ("Home Menu"   , FFJAbK        , [])
   if mode in ("vod", "series"):
    VVQR2V = ("Find in %s" % mName , BF(self.VVpSJW, mode, False), [])
    VVmmwr = ("Find in Selected" , BF(self.VVpSJW, mode, True) , [])
   else:
    VVQR2V = None
    VVmmwr = None
   header   = None
   widths   = (100   , 0  )
   FFEM8S(self, None, title=title, width=1200, header=header, VV6fdw=list, VVHqY6=widths, VVJmZ8=30, VVQcug=VVQcug, VVQR2V=VVQR2V, VVmmwr=VVmmwr, VVVi12=VVVi12, VVgchu=VVgchu, VVn4Mh=VVn4Mh, VVMqKH=VVMqKH, VVntre=VVntre, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VVDkUc:
     txt += "\n\n( %s )" % self.VVDkUc
   else:
    txt = "Could not get Categories from server!"
   FFa349(self, txt, title=title)
 def VVoLIc(self, mode, VVXOwS, title, txt, colList):
  FF7Xva(VVXOwS, BF(self.VV9vua, mode, VVXOwS, title, txt, colList), title="Downloading ...")
 def VV9vua(self, mode, VVXOwS, title, txt, colList):
  token, profile, tErr = self.VVZGHX()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVGfUW(self.VV2YCW(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCgg3d.VVgvLY(item, "id"    )
      actors   = CCgg3d.VVgvLY(item, "actors"   )
      added   = CCgg3d.VVgvLY(item, "added"   )
      age    = CCgg3d.VVgvLY(item, "age"   )
      category_id  = CCgg3d.VVgvLY(item, "category_id" )
      description  = CCgg3d.VVgvLY(item, "description" )
      director  = CCgg3d.VVgvLY(item, "director"  )
      genres_str  = CCgg3d.VVgvLY(item, "genres_str"  )
      name   = CCgg3d.VVgvLY(item, "name"   )
      path   = CCgg3d.VVgvLY(item, "path"   )
      screenshot_uri = CCgg3d.VVgvLY(item, "screenshot_uri" )
      series   = CCgg3d.VVgvLY(item, "series"   )
      cmd    = CCgg3d.VVgvLY(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VVVi12  = ("Play"    , BF(self.VVI13p, mode)       , [])
   VVd4CR = (""     , BF(self.VVtQHw, mode)     , [])
   VVQcug = ("Home Menu"   , FFJAbK            , [])
   VVsTsL = ("Download Options" , BF(self.VV5MoD, mode, "sp", seriesName) , [])
   VVQR2V = ("Options"   , BF(self.VVuADS, "pEp", mode, seriesName) , [])
   VVmmwr = ("Posters Mode"  , BF(self.VVXmqL, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVI7B0  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFEM8S(self, None, title=seriesName, width=1200, header=header, VV6fdw=list, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26, VVVi12=VVVi12, VVd4CR=VVd4CR, VVQcug=VVQcug, VVsTsL=VVsTsL, VVQR2V=VVQR2V, VVmmwr=VVmmwr, lastFindConfigObj=CFG.lastFindIptv, VVgchu="#0a00292B", VVn4Mh="#0a002126", VVMqKH="#0a002126", VVntre="#00000000")
  else:
   FFa349(self, "Could not get Episodes from server!", title=seriesName)
 def VVpSJW(self, mode, searchInCat, VVXOwS, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVW1xb = []
  VVW1xb.append(("Keyboard"  , "manualEntry"))
  VVW1xb.append(("From Filter" , "fromFilter"))
  FFLFXy(self, BF(self.VVbUGo, VVXOwS, mode, searchCatId), title="Input Type", VVW1xb=VVW1xb, width=400)
 def VVbUGo(self, VVXOwS, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFsShb(self, BF(self.VVmvz6, VVXOwS, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCuF2O(self)
    filterObj.VVpFrx(BF(self.VVmvz6, VVXOwS, mode, searchCatId))
 def VVmvz6(self, VVXOwS, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FFxMsu(CFG.lastFindIptv, searchName)
   title = self.VVYHPj(mode, searchName)
   if "," in searchName : FFa349(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FFa349(self, "Enter at least 3 characters.", title=title)
   else     :
    VVX1Oz = CCJU0G()
    if CFG.hideIptvServerAdultWords.getValue() and VVX1Oz.VV3FFy([searchName]):
     FFa349(self, VVX1Oz.VVQ3aK(), title=title)
    else:
     self.VVdLuL(mode, searchName, "", searchName, searchCatId)
 def VVJZ7a(self, mode, VVXOwS, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVdLuL(mode, bName, catID, "", "")
 def VVdLuL(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CCvBnC, barTheme=CCvBnC.VVrdqg
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVjEqr, mode, bName, catID, searchName, searchCatId)
      , VVnRGv = BF(self.VVtpDZ, mode, bName, catID, searchName, searchCatId))
 def VVtpDZ(self, mode, bName, catID, searchName, searchCatId, VVL4pA, VVLNy3, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVYHPj(mode, searchName)
  else   : title = "%s : %s" % (self.VVbPwt(mode), bName)
  if VVLNy3:
   VVsTsL = None
   VVQR2V = None
   if mode == "series":
    VVgchu, VVn4Mh, VVMqKH, VVntre = self.VVYCkd("series2")
    VVVi12  = ("Episodes"   , BF(self.VVoLIc, mode)           , [])
   else:
    VVgchu, VVn4Mh, VVMqKH, VVntre = self.VVYCkd("")
    VVVi12  = ("Play"    , BF(self.VVI13p, mode)           , [])
    VVsTsL = ("Download Options" , BF(self.VV5MoD, mode, "vp" if mode == "vod" else "", "") , [])
    VVQR2V = ("Options"   , BF(self.VVuADS, "pCh", mode, bName)      , [])
   VVd4CR = (""      , BF(self.VVg3y9, mode)         , [])
   VVQcug = ("Home Menu"    , FFJAbK                , [])
   VVmmwr = ("Posters Mode"   , BF(self.VVXmqL, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Category/Genre" , "Logo")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25    , 6  )
   VVI7B0  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT    , CENTER)
   VVXOwS = FFEM8S(self, None, title=title, header=header, VV6fdw=VVLNy3, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26, VVQcug=VVQcug, VVsTsL=VVsTsL, VVQR2V=VVQR2V, VVmmwr=VVmmwr, lastFindConfigObj=CFG.lastFindIptv, VVVi12=VVVi12, VVd4CR=VVd4CR, VVgchu=VVgchu, VVn4Mh=VVn4Mh, VVMqKH=VVMqKH, VVntre=VVntre, VVhmtx=True, searchCol=1)
   if not VVL4pA:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVXOwS.VVjEWc(VVXOwS.VVXYEj() + tot)
    if threadErr: FF1ojr(VVXOwS, "Error while reading !", 2000)
    else  : FF1ojr(VVXOwS, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFa349(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFa349(self, "Could not get list from server !", title=title)
 def VVg3y9(self, mode, VVXOwS, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFr9gS(self, fncMode=CCsydO.VV76s6, portalHost=self.VVGVRb, portalMac=self.VVnueZ, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVuMh2(mode, VVXOwS, title, txt, colList)
 def VVtQHw(self, mode, VVXOwS, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFY7FT(colList[10], VVBh5X)
  txt += "Description:\n%s" % FFY7FT(colList[11], VVBh5X)
  self.VVuMh2(mode, VVXOwS, title, txt, colList)
 def VVuMh2(self, mode, VVXOwS, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVbMmd(mode, colList)
  refCode, chUrl = self.VVRnJM(self.VVGVRb, self.VVnueZ, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFr9gS(self, fncMode=CCsydO.VVn327, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVjEqr(self, mode, bName, catID, searchName, searchCatId, VVhsRS):
  try:
   token, profile, tErr = self.VVZGHX()
   if not token:
    return
   if VVhsRS.isCancelled:
    return
   VVhsRS.VVLNy3, total_items, max_page_items, err = self.VV0NDX(mode, catID, 1, 1, searchName, searchCatId)
   if VVhsRS.isCancelled:
    return
   if VVhsRS.VVLNy3 and total_items > -1 and max_page_items > -1:
    VVhsRS.VVBrFN(total_items)
    VVhsRS.VVwvD4(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVhsRS.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VV0NDX(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVhsRS.VV6mXU()
     if VVhsRS.isCancelled:
      return
     if list:
      VVhsRS.VVLNy3 += list
      VVhsRS.VVwvD4(len(list), True)
  except:
   pass
 def VV0NDX(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVuL9I(mode, searchName, searchCatId, page)
  else   : url = self.VVYsu3(mode, catID, page)
  res, err = self.VVGfUW(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVZCp5(CCgg3d.VVgvLY(item, "total_items" ))
     max_page_items = self.VVZCp5(CCgg3d.VVgvLY(item, "max_page_items" ))
     VVX1Oz = CCJU0G()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCgg3d.VVgvLY(item, "id"    )
      name   = CCgg3d.VVgvLY(item, "name"   )
      o_name   = CCgg3d.VVgvLY(item, "o_name"   )
      tv_genre_id  = CCgg3d.VVgvLY(item, "tv_genre_id" )
      number   = CCgg3d.VVgvLY(item, "number"   ) or str(counter)
      logo   = CCgg3d.VVgvLY(item, "logo"   )
      screenshot_uri = CCgg3d.VVgvLY(item, "screenshot_uri" )
      cmd    = CCgg3d.VVgvLY(item, "cmd"   )
      censored  = CCgg3d.VVgvLY(item, "censored"  )
      genres_str  = CCgg3d.VVgvLY(item, "genres_str"  )
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       span = iSearch(r"stream=(.+)&", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
       else:
        span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      isIcon = "Yes" if picon else ""
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVGVRb + picon).replace(sp * 2, sp)
      counter += 1
      name = VVX1Oz.VVaoP0(name, censored)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd, genres_str, isIcon))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVZCp5(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVI13p(self, mode, VVXOwS, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVbMmd(mode, colList)
  refCode, chUrl = self.VVRnJM(self.VVGVRb, self.VVnueZ, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVKc8C(chName):
   FF1ojr(VVXOwS, "This is a marker!", 300)
  else:
   FF7Xva(VVXOwS, BF(self.VVeYxF, mode, VVXOwS, chUrl), title="Playing ...")
 def VVeYxF(self, mode, VVXOwS, chUrl):
  FFqi6V(self, chUrl, VVEPKV=False)
  CCXzGX.VVmA7N(self.session, iptvTableParams=(self, VVXOwS, mode))
 def VVEijA(self, mode, VVXOwS, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVbMmd(mode, colList)
  refCode, chUrl = self.VVRnJM(self.VVGVRb, self.VVnueZ, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVbMmd(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVMo6T(SELF, install=True, cbFnc=None):
  try:
   import requests
   return True
  except:
   if install:
    title = 'Install "Requests"'
    VVW1xb = []
    VVW1xb.append((title        , "inst" ))
    VVW1xb.append(("Update Packages then %s" % title , "updInst" ))
    FFLFXy(SELF, BF(CCTs8V.VV3kA9, SELF, cbFnc=cbFnc), title='This requires Python "Requests" library', VVW1xb=VVW1xb)
   return False
 @staticmethod
 def VV3kA9(SELF, item=None, cbFnc=None):
  if item:
   cmdUpd = FFrkEH(VVJknE, "")
   if cmdUpd:
    cmdInst = FFkjia(VVkKCu, "python-requests")
    if pyVersion[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFsZIz(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library', VVvcJy=cbFnc)
   else:
    FFPsN3(SELF)
class CCgg3d(Screen, CCTs8V, CCrLEQ):
 VVAjOv    = 0
 VVqijj    = 1
 VVHKAN    = 2
 VVtNOV    = 3
 VVPPWU     = 4
 VVcGb7     = 5
 VVbxgb     = 6
 VVKVBc     = 7
 VVRQ0a     = 8
 VVn4Sb     = 9
 VV8ZOT      = 10
 VVujMT     = 11
 VVM7ri     = 12
 VVctvO     = 13
 VV9mIu     = 14
 VVue0a      = 15
 VVt7BC      = 16
 VVzJWf      = 17
 VVcddh      = 18
 VVf0Ri      = 19
 VV0ZLM    = 0
 VVdkUS   = 1
 VV6MCx   = 2
 VVxW0j   = 3
 VV6QSZ  = 4
 VVmYdg  = 5
 VVi2Nw   = 6
 VVNXbt   = 7
 VVKLUx  = 8
 VVTUuW  = 9
 VVgiFj  = 10
 VVJqS7 = 0
 VVckYA = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFXh6Y(VV2F6v, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28, topRightBtns=1)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVXOwS    = None
  self.tableTitle     = "IPTV Channels List"
  self.VVpACXData    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CCgg3d.VVROqm(atLeastOne=True)
  self.isFirstTime    = True
  self.curUrl      = ""
  CCTs8V.__init__(self)
  VVW1xb = self.VVoatf()
  FFwLhV(self, title="IPTV", VVW1xb=VVW1xb)
  self["myActionMap"].actions.update({
   "menu" : self.VVAncd
  })
  self["myMenu"].onSelectionChanged.append(self.VVKRbo)
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self["myMenu"].setList(self.VVoatf())
  FFVUwm(self)
  FF8TfI(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FFKauM(self["myMenu"])
   FFUZsn(self)
   if self.m3uOrM3u8File:
    self.VVkZoK(self.m3uOrM3u8File, (0, (), False, ""))
 def VVKRbo(self):
  if self["myMenu"].getCurrent()[1] in ("VVCG6S", "VVSDkEPortal") : self["keyMenu"].show()
  else                      : self["keyMenu"].hide()
 def VVAncd(self):
  if self["myMenu"].getVisible():
   title = self["myMenu"].getCurrent()[0]
   item  = self["myMenu"].getCurrent()[1]
   if   item == "VVSDkEPortal" : confItem = CFG.favServerPortal
   elif item == "VVCG6S" : confItem = CFG.favServerPlaylist
   else         : return
   FF8XzP(self, BF(self.VVekMJ, confItem), 'Remove from menu ?', title=title)
 def VVekMJ(self, confItem):
  FFxMsu(confItem, "")
  self.VVfcAc()
 def VVoatf(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VVPpUd
  VVW1xb = []
  if isFav1: VVW1xb.append((c +  "Favourite Playlist Server"   , "VVCG6S" ))
  if isFav2: VVW1xb.append((c +  "Favourite Portal Server"    , "VVSDkEPortal" ))
  VVW1xb.append(("IPTV Server Browser (from Playlists)"     , "VVpACX_fromPlayList" ))
  VVW1xb.append(("IPTV Server Browser (from Portal List)"    , "VVpACX_fromMac"  ))
  VVW1xb.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VVpACX_fromM3u"  ))
  qUrl, iptvRef = CCgg3d.VVitjq(self)
  item = "IPTV Server Browser (from Current Channel)"
  if qUrl or "chCode" in iptvRef : VVW1xb.append((item     , "VVpACX_fromCurrChan" ))
  else       : VVW1xb.append((item     ,       ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("M3U/M3U8 File Browser"        , "VV1Puu"   ))
  if self.iptvFileAvailable:
   VVW1xb.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVW1xb.append(VVswUs)
  item1 = "Update Current Bouquet EPG (from IPTV Server)"
  item2 = "Update Current Bouquet PIcons (from IPTV Server)"
  if qUrl or "chCode" in iptvRef:
   VVW1xb.append((item1            , "refreshIptvEPG"   ))
   VVW1xb.append((item2            , "refreshIptvPicons"  ))
  else:
   VVW1xb.append((item1            ,       ))
   VVW1xb.append((item2            ,       ))
  if self.iptvFileAvailable:
   VVW1xb.append(VVswUs)
   c1, c2 = VVW6qu, VVJ2KG
   t1 = FFY7FT("auto-match names", VVPpUd)
   t2 = FFY7FT("from xml file"  , VVPpUd)
   VVW1xb.append((c1 + "Count Available IPTV Channels"    , "VV8KMG"    ))
   VVW1xb.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVW1xb.append(VVswUs)
   VVW1xb.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVW1xb.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VVWvbn" ))
   VVW1xb.append((VV6yYu + "More Reference Tools ..."  , "VV3kK2"   ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Reload Channels and Bouquets"       , "VVTDcy"   ))
  VVW1xb.append(VVswUs)
  if not CCXCxH.VVLWM5():
   VVW1xb.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVW1xb.append(("Download Manager ... No donwloads"    ,       ))
  return VVW1xb
 def VVZKlw(self, item):
  self.curUrl = ""
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVqkaI"   : self.VVqkaI()
   elif item == "VVgyNd" : FF8XzP(self, self.VVgyNd, "Change Current List References to Unique Codes ?")
   elif item == "VV0ypM_rows" : FF8XzP(self, BF(FF7Xva, self.VVXOwS, self.VV0ypM), "Change Current List References to Identical Codes ?")
   elif item == "VVJ7rd"   : self.VVJ7rd(tTitle)
   elif item == "VVKjz3"   : self.VVKjz3(tTitle)
   elif item == "VVCG6S" : self.VVSDkE(False)
   elif item == "VVSDkEPortal" : self.VVSDkE(True)
   elif item == "VVpACX_fromPlayList" : FF7Xva(self, BF(self.VVDsRp, 1), title=title)
   elif item == "VVpACX_fromM3u"  : FF7Xva(self, BF(self.VV3vqm, CCgg3d.VVJqS7), title=title)
   elif item == "VVpACX_fromMac"  : self.VVU7bT()
   elif item == "VVpACX_fromCurrChan" : self.VVC1fB()
   elif item == "VV1Puu"   : self.VV1Puu()
   elif item == "iptvTable_all"   : FF7Xva(self, BF(self.VVoEmX, self.VVAjOv), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : CCgg3d.VVNJtp(self)
   elif item == "refreshIptvPicons"  : self.VV3kxH()
   elif item == "VV8KMG"    : FF7Xva(self, self.VV8KMG)
   elif item == "copyEpgPicons"   : self.VVRlhs(False)
   elif item == "renumIptvRef_fromFile" : self.VVRlhs(True)
   elif item == "VVWvbn" : FF8XzP(self, BF(FF7Xva, self, self.VVWvbn), VVusVD="Continue ?")
   elif item == "VV3kK2"    : self.VV3kK2()
   elif item == "VVTDcy"   : FF7Xva(self, BF(CCyEBX.VVTDcy, self))
   elif item == "dload_stat"    : CCXCxH.VVLg6m(self)
 def VV1Puu(self):
  if CCTs8V.VVMo6T(self):
   FF7Xva(self, BF(self.VV3vqm, CCgg3d.VVckYA), title="Searching ...")
 def VVi1M6(self):
  global VVdxhd
  VVdxhd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVZKlw(item)
 def VVoEmX(self, mode):
  VVuV68 = self.VVAROt(mode)
  if VVuV68:
   VVsTsL = ("Current Service", self.VVy4Vb , [])
   VVQR2V = ("Options"  , self.VVeN64   , [])
   VVmmwr = ("Filter"   , self.VV0Vtb   , [])
   VVVi12  = ("Play"   , BF(self.VVQJht)  , [])
   VVd4CR = (""    , self.VVGZd2    , [])
   VVH2MF = (""    , self.VVb5ca     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VVI7B0  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FFEM8S(self, None, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26
     , VVVi12=VVVi12, VVsTsL=VVsTsL, VVQR2V=VVQR2V, VVmmwr=VVmmwr, VVd4CR=VVd4CR, VVH2MF=VVH2MF
     , VVgchu="#0a00292B", VVn4Mh="#0a002126", VVMqKH="#0a002126", VVntre="#00000000", VVhmtx=True, searchCol=1)
  else:
   if mode == self.VVn4Sb: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFa349(self, err)
 def VVb5ca(self, VVXOwS, title, txt, colList):
  self.VVXOwS = VVXOwS
 def VVeN64(self, VVXOwS, title, txt, colList):
  VVW1xb = []
  VVW1xb.append(("Add Current List to a New Bouquet"    , "VVqkaI"  ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Change Current List References to Unique Codes" , "VVgyNd"))
  VVW1xb.append(("Change Current List References to Identical Codes", "VV0ypM_rows" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Share Reference with DVB Service (manual entry)" , "VVJ7rd"   ))
  VVW1xb.append(("Share Reference with DVB Service (auto-find)"  , "VVKjz3"   ))
  FFLFXy(self, self.VVZKlw, title="IPTV Tools", VVW1xb=VVW1xb)
 def VV0Vtb(self, VVXOwS, title, txt, colList):
  VVW1xb = []
  VVW1xb.append(("All"         , "all"   ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Prefix of Selected Channel"   , "sameName" ))
  VVW1xb.append(("Suggest Words from Selected Channel" , "partName" ))
  VVW1xb.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVW1xb.append(("Duplicate References"     , "depRef"  ))
  VVW1xb.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVW1xb.append(("Stream Relay"       , "SRelay"  ))
  VVW1xb.append(FFzfpO("Category"))
  VVW1xb.append(("Live TV"        , "live"  ))
  VVW1xb.append(("VOD"         , "vod"   ))
  VVW1xb.append(("Series"        , "series"  ))
  VVW1xb.append(("Uncategorised"      , "uncat"  ))
  VVW1xb.append(FFzfpO("Media"))
  VVW1xb.append(("Video"        , "video"  ))
  VVW1xb.append(("Audio"        , "audio"  ))
  VVW1xb.append(FFzfpO("File Type"))
  VVW1xb.append(("MKV"         , "MKV"   ))
  VVW1xb.append(("MP4"         , "MP4"   ))
  VVW1xb.append(("MP3"         , "MP3"   ))
  VVW1xb.append(("AVI"         , "AVI"   ))
  VVW1xb.append(("FLV"         , "FLV"   ))
  VVW1xb.extend(CCRtNz.VV6Ees(prefix="__b__"))
  inFilterFnc = BF(self.VVik38, VVXOwS) if VVXOwS.VVXYEj().startswith("IPTV Filter ") else None
  filterObj = CCuF2O(self)
  filterObj.VVK44o(VVW1xb, VVW1xb, BF(self.VV7BHd, VVXOwS, False), inFilterFnc=inFilterFnc)
 def VVik38(self, VVXOwS, menuInstance, item):
  self.VV7BHd(VVXOwS, True, item)
 def VV7BHd(self, VVXOwS, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVXOwS.VVRuNe(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVAjOv , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVqijj , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVHKAN , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVtNOV , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVbxgb  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VVKVBc  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "SRelay"   : mode, words, title = self.VVRQ0a  , ""  , f + "= Stream Relay"
   elif item == "live"    : mode, words, title = self.VVn4Sb  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VV8ZOT   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVujMT  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVM7ri  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVctvO  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VV9mIu  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVue0a   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVt7BC   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVzJWf   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVcddh   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVf0Ri   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVPPWU  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVcGb7  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVHKAN:
   VVW1xb = []
   chName = VVXOwS.VVRuNe(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVW1xb.append((item, item))
    if not VVW1xb and chName:
     VVW1xb.append((chName, chName))
    FFLFXy(self, BF(self.VV37jB, title), title="Words from Current Selection", VVW1xb=VVW1xb)
   else:
    VVXOwS.VVbkCu("Invalid Channel Name")
  else:
   words, asPrefix = CCuF2O.VVUxc8(words)
   if not words and mode in (self.VVPPWU, self.VVcGb7):
    FF1ojr(self.VVXOwS, "Incorrect filter", 2000)
   else:
    FF7Xva(self.VVXOwS, BF(self.VVn2Nt, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VV37jB(self, title, word=None):
  if word:
   words = [word.lower()]
   FF7Xva(self.VVXOwS, BF(self.VVn2Nt, self.VVHKAN, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VV4Azf(txt):
  return "#f#11ffff00#" + txt
 def VVn2Nt(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVuV68 = self.VVNhdR(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVuV68 = self.VVAROt(mode=mode, words=words, asPrefix=asPrefix)
  if VVuV68 : self.VVXOwS.VVOFDI(VVuV68, title)
  else  : self.VVXOwS.VVbkCu("Not found")
 def VVNhdR(self, mode=0, words=None, asPrefix=False):
  VVuV68 = []
  for row in self.VVXOwS.VVWsuW():
   row = list(map(str.strip, row))
   chNum, chName, VVgTOR, chType, refCode, url = row
   if self.VVthkF(mode, refCode, FFdOos(url).lower(), chName, words, VVgTOR.lower(), asPrefix):
    VVuV68.append(row)
  VVuV68 = self.VVpDDh(mode, VVuV68)
  return VVuV68
 def VVAROt(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VVuV68 = []
  files  = self.VVxYBv()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFqXAw(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVgTOR = span.group(1)
    else : VVgTOR = ""
    VVgTOR_lCase = VVgTOR.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVKc8C(chName): chNameMod = self.VV4Azf(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVgTOR, chType + (" SRel" if FFTxso(url) else ""), refCode, url)
     if self.VVthkF(mode, refCode, FFdOos(url).lower(), chName, words, VVgTOR_lCase, asPrefix):
      VVuV68.append(row)
      chNum += 1
  VVuV68 = self.VVpDDh(mode, VVuV68)
  return VVuV68
 def VVpDDh(self, mode, VVuV68):
  newRows = []
  if VVuV68 and mode == self.VVbxgb:
   from collections import Counter
   counted  = Counter(elem[4] for elem in VVuV68)
   for item in VVuV68:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVuV68
 def VVthkF(self, mode, refCode, tUrl, chName, words, VVgTOR_lCase, asPrefix):
  if   mode == self.VVAjOv : return True
  elif mode == self.VVbxgb : return True
  elif mode == self.VVKVBc  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VVRQ0a : return FFTxso(tUrl)
  elif mode == self.VVctvO  : return CCgg3d.VVHvuJ(tUrl, getAudVid=True) == "vid"
  elif mode == self.VV9mIu  : return CCgg3d.VVHvuJ(tUrl, getAudVid=True) == "aud"
  elif mode == self.VVn4Sb  : return CCgg3d.VVHvuJ(tUrl, compareType="live")
  elif mode == self.VV8ZOT  : return CCgg3d.VVHvuJ(tUrl, compareType="movie")
  elif mode == self.VVujMT : return CCgg3d.VVHvuJ(tUrl, compareType="series")
  elif mode == self.VVM7ri  : return CCgg3d.VVHvuJ(tUrl, compareType="")
  elif mode == self.VVue0a  : return CCgg3d.VVHvuJ(tUrl, compareExt="mkv")
  elif mode == self.VVt7BC  : return CCgg3d.VVHvuJ(tUrl, compareExt="mp4")
  elif mode == self.VVzJWf  : return CCgg3d.VVHvuJ(tUrl, compareExt="mp3")
  elif mode == self.VVcddh  : return CCgg3d.VVHvuJ(tUrl, compareExt="avi")
  elif mode == self.VVf0Ri  : return CCgg3d.VVHvuJ(tUrl, compareExt="flv")
  elif mode == self.VVqijj: return chName.lower().startswith(words[0])
  elif mode == self.VVHKAN: return words[0] in chName.lower()
  elif mode == self.VVtNOV: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVPPWU : return words[0] == VVgTOR_lCase
  elif mode == self.VVcGb7 :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVqkaI(self):
  picker = CCRtNz(self, self.VVXOwS, "Add to Bouquet", self.VVmKYh)
 def VVmKYh(self):
  chUrlLst = []
  for row in self.VVXOwS.VVWsuW():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VV3kK2(self):
  c1 = VVTMjp
  t1 = FFY7FT("Bouquet", VVPpUd)
  t2 = FFY7FT("ALL", VVPpUd)
  refTxt = "(1/4097/5001/5002/8192/8193)"
  VVW1xb = []
  VVW1xb.append((c1 + "Check System Acceptable Reference Types" , "VVIcbS"    ))
  if self.iptvFileAvailable:
   VVW1xb.append((c1 + "Check Reference Codes Format"  , "VViIuY"    ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(('Change %s Ref. Types to %s ..' % (t1, refTxt) , "VVFMoK" ))
  VVW1xb.append(('Change %s Ref. Types to %s ..' % (t2, refTxt) , "VV50LD_all"  ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Change %s References to Unique Codes" % t2 , "VVOklU"  ))
  VVW1xb.append(("Change %s References to Identical Codes" % t2 , "VV0ypM_all"  ))
  OKBtnFnc = self.VVq8Mq
  FFLFXy(self, None, width=1200, title="Reference Tools", VVW1xb=VVW1xb, OKBtnFnc=OKBtnFnc)
 def VVq8Mq(self, item=None):
  if item:
   ques = "Continue ?"
   menuInstance, txt, item, ndx = item
   if   item == "VVIcbS"    : FF7Xva(menuInstance, self.VVIcbS)
   elif item == "VViIuY"     : FF7Xva(menuInstance, self.VViIuY)
   elif item == "VVFMoK" : self.VVFMoK(menuInstance)
   elif item == "VV50LD_all"  : self.VVkWkr(menuInstance, None, None)
   elif item == "VVOklU"  : FF8XzP(self, BF(self.VVOklU , menuInstance, txt), title=txt, VVusVD=ques)
   elif item == "VV0ypM_all"  : FF8XzP(self, BF(FF7Xva, menuInstance, self.VV0ypM), title=txt, VVusVD=ques)
 def VVkWkr(self, menuInstance, bName, bPath):
  txt = "Stream Type "
  VVW1xb = []
  VVW1xb.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVW1xb.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVW1xb.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVW1xb.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVW1xb.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))  #
  VVW1xb.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFLFXy(self, BF(self.VVWIof, menuInstance, bName, bPath), VVW1xb=VVW1xb, width=750, title="Change Reference Types to:")
 def VVWIof(self, menuInstance, bName, bPath, item=None):
  if item:
   if   item == "RT_1"  : self.VVndIH(menuInstance, bName, bPath, "1"   )
   elif item == "RT_4097" : self.VVndIH(menuInstance, bName, bPath, "4097")
   elif item == "RT_5001" : self.VVndIH(menuInstance, bName, bPath, "5001")
   elif item == "RT_5002" : self.VVndIH(menuInstance, bName, bPath, "5002")
   elif item == "RT_8192" : self.VVndIH(menuInstance, bName, bPath, "8192")
   elif item == "RT_8193" : self.VVndIH(menuInstance, bName, bPath, "8193")
 def VVFMoK(self, menuInstance):
  VVW1xb = CCRtNz.VV6Ees()
  if VVW1xb:
   FFLFXy(self, BF(self.VVaW1Q, menuInstance), VVW1xb=VVW1xb, title="IPTV Bouquets", VVxhca=True)
  else:
   FF1ojr(menuInstance, "No bouquets Found !", 1500)
 def VVaW1Q(self, menuInstance, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVLOHV + span.group(1)
    if fileExists(bPath): self.VVkWkr(menuInstance, bName, bPath)
    else    : FF1ojr(menuInstance, "Bouquet file not found!", 2000)
   else:
    FF1ojr(menuInstance, "Cannot process bouquet !", 2000)
 def VVndIH(self, menuInstance, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FFY7FT(bName, VVzCWu)
  else : title = "Change for %s" % FFY7FT("All IPTV Services", VVzCWu)
  FF8XzP(self, BF(FF7Xva, menuInstance, BF(self.VV4i0N, menuInstance, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FFY7FT(rType, VVzCWu), title=title)
 def VV4i0N(self, menuInstance, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = self.VVxYBv()
  if files:
   newRType = rType + ":"
   piconPath = CCMxom.VVVqXw()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CCbI7Z.VV8ERc(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FFa349(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           os.system(FFQe93("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png")))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    os.system(FFQe93(cmd))
  self.VVCZdz(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VV8KMG(self):
  totFiles = 0
  files  = self.VVxYBv()
  if files:
   totFiles = len(files)
  totChans = 0
  VVuV68 = self.VVAROt()
  if VVuV68:
   totChans = len(VVuV68)
  FFyv2f(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VViIuY(self):
  files  = self.VVxYBv()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFqXAw(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVlfrr
   else    : color = VV9ZlA
   totInvalid = FFY7FT(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFY7FT("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFyv2f(self, txt, title="Check IPTV References")
 def VVIcbS(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  chUrlLst  = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CCRtNz.VV05zS(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VVlP6s = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVlP6s:
   VVDmhR = FFqMsP(VVlP6s)
   if VVDmhR:
    for service in VVDmhR:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVLOHV + userBName
  bFile = VVLOHV + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFQe93("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFQe93("rm -f '%s'" % path)
  os.system(cmd)
  FFNh5K()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVlfrr
    else     : res, color = "No" , VV9ZlA
    txt += "    %s\t: %s\n" % (item, FFY7FT(res, color))
   FFyv2f(self, txt, title=title)
  else:
   txt = FFa349(self, "Could not complete the test on your system!", title=title)
 def VVWvbn(self):
  VVs61U, err = CCyEBX.VVCZgt(self, CCyEBX.VVayYH)
  if VVs61U:
   totChannels = 0
   totChange = 0
   for path in self.VVxYBv():
    toSave = False
    txt = FFqXAw(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVs61U.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVCZdz(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFa349(self, 'No channels in "lamedb" !')
 def VVOklU(self, menuInstance, title):
  bFiles = self.VVxYBv()
  if bFiles:
   self.session.open(CCvBnC, barTheme=CCvBnC.VVjpsh
       , titlePrefix = "Renumbering References"
       , fncToRun  = BF(self.VV5PFI, bFiles)
       , VVnRGv = BF(self.VV4tMW, title))
  else:
   FF1ojr(menuInstance, "No bouquets files !", 1500)
 def VV5PFI(self, bFiles, VVhsRS):
  VVhsRS.VVLNy3 = ""
  VVhsRS.VVhwt2("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FFFfvw(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVhsRS or VVhsRS.isCancelled:
   return
  elif not totLines:
   VVhsRS.VVLNy3 = "No IPTV Services !"
   return
  else:
   VVhsRS.VVBrFN(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVhsRS or VVhsRS.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FFFfvw(path)
    for ndx, line in enumerate(lines):
     if not VVhsRS or VVhsRS.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVhsRS:
       VVhsRS.VVhwt2("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVhsRS:
       VVhsRS.VVwvD4(1)
      refCode, startId, startNS = CCRtNz.VV8V9G(rType, CCRtNz.VVIZO0, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVhsRS:
        VVhsRS.VVLNy3 = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VV4tMW(self, title, VVL4pA, VVLNy3, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VVLNy3:
   txt += "\n\n%s\n%s" % (FFY7FT("Ended with Error:", VV9ZlA), VVLNy3)
  self.VVCZdz(True, title, txt)
 def VVgyNd(self):
  bFiles = self.VVxYBv()
  if not bFiles:
   FF1ojr(self.VVXOwS, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVXOwS.VVWsuW():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FF1ojr(self.VVXOwS, "Cannot read list", 1500)
   return
  self.session.open(CCvBnC, barTheme=CCvBnC.VVjpsh
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVjRjO, bFiles, tableRefList)
      , VVnRGv = BF(self.VV4tMW, "Change Current List References to Unique Codes"))
 def VVjRjO(self, bFiles, tableRefList, VVhsRS):
  VVhsRS.VVLNy3 = ""
  VVhsRS.VVhwt2("Reading System References ...")
  refLst = CCRtNz.VVnOH0(CCRtNz.VVIZO0, stripRType=True)
  if not VVhsRS or VVhsRS.isCancelled:
   return
  VVhsRS.VVBrFN(len(tableRefList))
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVhsRS or VVhsRS.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFqXAw(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVhsRS or VVhsRS.isCancelled:
     return
    VVhsRS.VVhwt2("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVhsRS or VVhsRS.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVhsRS.VVwvD4(1)
      refCode, startId, startNS = CCRtNz.VV8V9G(rType, CCRtNz.VVIZO0, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVhsRS:
        VVhsRS.VVLNy3 = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VV0ypM(self):
  list = None
  if self.VVXOwS:
   list = []
   for row in self.VVXOwS.VVWsuW():
    list.append(row[4] + row[5])
  files  = self.VVxYBv()
  totChange = 0
  if files:
   for path in files:
    lines = FFFfvw(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VVCZdz(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVCZdz(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFNh5K()
   if refreshTable and self.VVXOwS:
    VVuV68 = self.VVAROt()
    if VVuV68 and self.VVXOwS:
     self.VVXOwS.VVOFDI(VVuV68, self.tableTitle)
     self.VVXOwS.VVbkCu(txt)
   FFyv2f(self, txt, title=title)
  else:
   FF5nWa(self, "No changes.")
 def VVxYBv(self):
  return CCgg3d.VVROqm()
 @staticmethod
 def VVROqm(atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVLOHV + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFqXAw(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVGZd2(self, VVXOwS, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFdOos(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFr9gS(self, fncMode=CCsydO.VVlfcQ, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVP3GG(self, VVXOwS, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVQJht(self, VVXOwS, title, txt, colList):
  chName, chUrl = self.VVP3GG(VVXOwS, colList)
  self.VVExjH(VVXOwS, chName, chUrl, "localIptv")
 def VVlFq7(self, mode, VVXOwS, colList):
  chName, chUrl, picUrl, refCode = self.VVd8ay(mode, colList)
  return chName, chUrl
 def VVlIxZ(self, mode, VVXOwS, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVd8ay(mode, colList)
  self.VVExjH(VVXOwS, chName, chUrl, mode)
 def VVExjH(self, VVXOwS, chName, chUrl, playerFlag):
  chName = FFyZAn(chName)
  if self.VVKc8C(chName):
   FF1ojr(VVXOwS, "This is a marker!", 300)
  else:
   FF7Xva(VVXOwS, BF(self.VVCfFM, VVXOwS, chUrl, playerFlag), title="Playing ...")
 def VVCfFM(self, VVXOwS, chUrl, playerFlag):
  FFqi6V(self, chUrl, VVEPKV=False)
  CCXzGX.VVmA7N(self.session, iptvTableParams=(self, VVXOwS, playerFlag))
 @staticmethod
 def VVKc8C(chName):
  mark = ("--", "__", "==", "##",  "**", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVy4Vb(self, VVXOwS, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self)
  if refCode:
   url1 = FFdOos(origUrl.strip())
   for ndx, row in enumerate(VVXOwS.VVWsuW()):
    if refCode in row[4]:
     tableRow = FFdOos(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVXOwS.VV9fSx(ndx)
      break
   else:
    FF1ojr(VVXOwS, "No found", 1000)
 def VV3vqm(self, m3uMode):
  lines = self.VVF5BS(3)
  if lines:
   lines.sort()
   VVW1xb = []
   for line in lines:
    VVW1xb.append((line, line))
   if m3uMode == CCgg3d.VVJqS7:
    title = "Browse Server from M3U URLs"
    VVkjyo = ("All to Playlist", self.VVFHUD)
   else:
    title = "M3U/M3U8 File Browser"
    VVkjyo = None
   OKBtnFnc = BF(self.VV7cKH, m3uMode, title)
   infoBtnFnc = self.VVJj3k
   FFLFXy(self, None, title=title, VVW1xb=VVW1xb, width=1200, OKBtnFnc=OKBtnFnc, infoBtnFnc=infoBtnFnc, yellowBasePath="", VVkjyo=VVkjyo, VVgchu="#11221122", VVn4Mh="#11221122")
 def VV7cKH(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == CCgg3d.VVJqS7:
    FF7Xva(menuInstance, BF(self.VVNta5, title, path))
   else:
    self.VV510F(menuInstance, path)
 def VV510F(self, menuInstance, path=None):
  if path:
   VVW1xb = []
   VVW1xb.append(("All"      , "all"  ))
   VVW1xb.append(FFzfpO("Category"))
   VVW1xb.append(("Live TV"     , "live" ))
   VVW1xb.append(("VOD"      , "vod"  ))
   VVW1xb.append(("Series"     , "series" ))
   VVW1xb.append(("Uncategorised"   , "uncat" ))
   VVW1xb.append(FFzfpO("Media"))
   VVW1xb.append(("Video"     , "video" ))
   VVW1xb.append(("Audio"     , "audio" ))
   VVW1xb.append(FFzfpO("File Type"))
   VVW1xb.append(("MKV"      , "MKV"  ))
   VVW1xb.append(("MP4"      , "MP4"  ))
   VVW1xb.append(("MP3"      , "MP3"  ))
   VVW1xb.append(("AVI"      , "AVI"  ))
   VVW1xb.append(("FLV"      , "FLV"  ))
   filterObj = CCuF2O(self, VVgchu="#11552233", VVn4Mh="#11552233")
   filterObj.VVK44o(VVW1xb, [], BF(self.VVp9S1, menuInstance, path), inFilterFnc=None)
 def VVp9S1(self, menuInstance, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VVAjOv , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VVn4Sb  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VV8ZOT  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VVujMT  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VVM7ri  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VVctvO  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VV9mIu  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VVue0a  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VVt7BC  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VVzJWf  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVcddh  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VVf0Ri  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVcGb7  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CCuF2O.VVUxc8(words)
   if not mode == self.VVAjOv:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FFY7FT(fTitle, VVBh5X)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FF7Xva(menuInstance, BF(self.VVkZoK, path, m3uFilterParam))
 def VVkZoK(self, srcPath, m3uFilterParam):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFqXAw(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  VVX1Oz = CCJU0G()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VV8QaF(propLine, "group-title") or "-"
   if not group == "-" and VVX1Oz.VVaoP0(group):
    groups.add(group)
  span = iSearch(r"#EXTINF:.+\n(.+)\n.+", txt, IGNORECASE)
  if span:
   self.curUrl = span.group(1)
  VVuV68 = []
  if len(groups) > 0:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   for group in groups:
    VVuV68.append((group, group))
   VVuV68.append(("ALL", ""))
   VVuV68.sort(key=lambda x: x[0].lower())
   VV6iCg = self.VV4SP5
   VVVi12  = ("Select" , BF(self.VVdFgV, srcPath, m3uFilterParam), [])
   widths   = (100  , 0)
   VVI7B0  = (LEFT  , LEFT)
   FFEM8S(self, None, title=title, width= 1000, header=None, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=30, VVVi12=VVVi12, VV6iCg=VV6iCg, lastFindConfigObj=CFG.lastFindIptv
     , VVgchu="#11110022", VVn4Mh="#11110022", VVMqKH="#11110022", VVntre="#00444400")
  else:
   txt = FFqXAw(srcPath)
   self.VV7CfI(txt, "", m3uFilterParam)
 def VVdFgV(self, srcPath, m3uFilterParam, VVXOwS, title, txt, colList):
  group = colList[1]
  txt = FFqXAw(srcPath)
  self.VV7CfI(txt, group, m3uFilterParam)
 def VV7CfI(self, txt, filterGroup="", m3uFilterParam=None):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CCvBnC, barTheme=CCvBnC.VVrdqg
       , titlePrefix = "Reading File Lines", endTitle="Loading channels ..."
       , fncToRun  = BF(self.VVwz7n, lst, filterGroup, m3uFilterParam)
       , VVnRGv = BF(self.VVooDF, title, bName))
  else:
   self.VVUnin("Not valid lines found !", title)
 def VVwz7n(self, lst, filterGroup, m3uFilterParam, VVhsRS):
  VVhsRS.VVLNy3 = []
  VVhsRS.VVBrFN(len(lst))
  VVX1Oz = CCJU0G()
  num = 0
  for cols in lst:
   if not VVhsRS or VVhsRS.isCancelled:
    return
   VVhsRS.VVwvD4(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VV8QaF(propLine, "tvg-logo")
   group = self.VV8QaF(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not VVX1Oz.VVaoP0(group) : skip = True
    elif chName and not VVX1Oz.VVaoP0(chName) : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VVthkF(mode, "", FFdOos(url).lower(), chName, words, "", asPrefix)
    if not skip and VVhsRS:
     num += 1
     VVhsRS.VVLNy3.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
 def VVooDF(self, title, bName, VVL4pA, VVLNy3, threadCounter, threadTotal, threadErr):
  if VVLNy3:
   VV6iCg = self.VV4SP5
   VVVi12  = ("Select"   , BF(self.VVahuw, title)   , [])
   VVd4CR = (""    , self.VVS9Dc        , [])
   VVsTsL = ("Download PIcons", self.VVRS7r       , [])
   VVQR2V = ("Options"  , BF(self.VVuADS, "m3Ch", "", bName) , [])
   VVmmwr = ("Posters Mode" , BF(self.VVXmqL, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVI7B0  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFEM8S(self, None, title=title, header=header, VV6fdw=VVLNy3, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=28, VVVi12=VVVi12, VV6iCg=VV6iCg, VVd4CR=VVd4CR, VVsTsL=VVsTsL, VVQR2V=VVQR2V, VVmmwr=VVmmwr, lastFindConfigObj=CFG.lastFindIptv, VVhmtx=True, searchCol=1
     , VVgchu="#0a00192B", VVn4Mh="#0a00192B", VVMqKH="#0a00192B", VVntre="#00000000")
  else:
   self.VVUnin("Not found !", title)
 def VVRS7r(self, VVXOwS, title, txt, colList):
  self.VVs04a(VVXOwS, "m3u/m3u8")
 def VVungR(self, rowNum, url, chName):
  refCode = self.VVR6gB(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFgbDs(url), chName)
  return chUrl
 def VVR6gB(self, rowNum, url, chName):
  fName = os.path.basename(url)
  catID = "333"
  stID  =  "444"
  if fName:
   num = os.path.splitext(fName)[0]
   if num.isdigit() and int(num) < 0xeeee0000:
    stID = num
  chNum = str(rowNum + 1)
  refCode = self.VVbRWT(catID, stID, chNum)
  return refCode
 def VV8QaF(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVahuw(self, Title, VVXOwS, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FF7Xva(VVXOwS, BF(self.VVLkrA, Title, VVXOwS, colList), title="Checking Server ...")
  else:
   self.VVTyji(VVXOwS, url, chName)
 def VVLkrA(self, title, VVXOwS, colList):
  if not CCTs8V.VVMo6T(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CC2WTV.VVGRLW(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVW1xb = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCgg3d.VVg0OK(url, fPath)
     VVW1xb.append((resol, fullUrl))
    if VVW1xb:
     if len(VVW1xb) > 1:
      FFLFXy(self, BF(self.VV4OYv, VVXOwS, chName), VVW1xb=VVW1xb, title="Resolution", VVxhca=True, VVuwvk=True)
     else:
      self.VVTyji(VVXOwS, VVW1xb[0][1], chName)
    else:
     span = iSearch(r"(http.+)", txt, IGNORECASE)
     if span:
      self.VVTyji(VVXOwS, span.group(1), chName)
     else:
      span = iSearch(r"#EXT-X-STREAM-INF.*\n(.+)", txt, IGNORECASE)
      if span:
       fullUrl = CCgg3d.VVg0OK(url, span.group(1))
       self.VVTyji(VVXOwS, fullUrl, chName)
      else:
       self.VVYjXn("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VV7CfI(txt, filterGroup="")
      return
    self.VVTyji(VVXOwS, url, chName)
   else:
    self.VVUnin("Cannot process this channel !", title)
  else:
   self.VVUnin(err, title)
 def VV4OYv(self, VVXOwS, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVTyji(VVXOwS, resolUrl, chName)
 def VVTyji(self, VVXOwS, url, chName):
  FF7Xva(VVXOwS, BF(self.VVmOvY, VVXOwS, url, chName), title="Playing ...")
 def VVmOvY(self, VVXOwS, url, chName):
  chUrl = self.VVungR(VVXOwS.VVRJth(), url, chName)
  FFqi6V(self, chUrl, VVEPKV=False)
  CCXzGX.VVmA7N(self.session, iptvTableParams=(self, VVXOwS, "m3u/m3u8"))
 def VV9KTV(self, VVXOwS, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVungR(VVXOwS.VVRJth(), url, chName)
  return chName, chUrl
 def VVS9Dc(self, VVXOwS, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFr9gS(self, fncMode=CCsydO.VVlfcQ, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVUnin(self, err, title):
  FFa349(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VV4SP5(self, VVXOwS):
  if self.m3uOrM3u8File:
   self.close()
  VVXOwS.cancel()
 def VVFHUD(self, VVlAViObj, item=None):
  FF7Xva(VVlAViObj, BF(self.VVILlr, VVlAViObj, item))
 def VVILlr(self, VVlAViObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVlAViObj.VVW1xb):
    path = item[1]
    if fileExists(path):
     enc = CCAUx4.VVx4Et(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = CCgg3d.VVpaCr(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCgg3d.VVmtsl()
    pListF = "%sPlaylist_%s.txt" % (path, FFJCyp())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVlAViObj.VVW1xb)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFyv2f(self, txt, title=title)
   else:
    FFa349(self, "Could not obtain URLs from this file list !", title=title)
 def VVDsRp(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VVZV6f
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VV5AwT
  lines = self.VVF5BS(mode)
  if lines:
   lines.sort()
   VVW1xb = []
   for line in lines:
    VVW1xb.append((FFY7FT(line, VVJ2KG) if "Bookmarks" in line else line, line))
   infoBtnFnc = self.VVJj3k
   FFLFXy(self, None, title=title, VVW1xb=VVW1xb, width=1200, OKBtnFnc=okFnc, infoBtnFnc=infoBtnFnc, yellowBasePath="")
 def VVJj3k(self, menuInstance, txt, ref, ndx):
  txt = ref
  sz = FFPYZx(ref)
  if sz > 0:
   txt += "\n\nSize: %s" % CCbI7Z.VVr8MR(sz)
  FFyv2f(self, txt, title="File Path")
 def VVZV6f(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FF7Xva(menuInstance, BF(self.VVoOQn, menuInstance, path), title="Processing File ...")
 def VVoOQn(self, VVb0Di, path):
  enc = CCAUx4.VVx4Et(path, self)
  if enc == -1:
   return
  VVuV68 = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFnWu0(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCgg3d.VVJGCM(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVuV68:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVuV68.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVuV68:
   title = "Playlist File : %s" % os.path.basename(path)
   VVVi12  = ("Start"    , BF(self.VVHwuL, "Playlist File")      , [])
   VVQcug = ("Home Menu"   , FFJAbK             , [])
   VVsTsL = ("Download M3U File" , self.VVsZEg         , [])
   VVQR2V = ("Edit File"   , BF(self.VVBiN9, path)        , [])
   VVmmwr = ("Check & Filter"  , BF(self.VVY4Rm, VVb0Di, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVI7B0  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFEM8S(self, None, title=title, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26, VVVi12=VVVi12, VVQcug=VVQcug, VVmmwr=VVmmwr, VVsTsL=VVsTsL, VVQR2V=VVQR2V, VVgchu="#11001116", VVn4Mh="#11001116", VVMqKH="#11001116", VVntre="#00003635", VV3VhT="#0a333333", VVwlSC="#11331100", VVhmtx=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FFa349(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVsZEg(self, VVXOwS, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FF8XzP(self, BF(FF7Xva, VVXOwS, BF(self.VVcKDG, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVcKDG(self, title, url):
  path, err = FFjmFi(url, "ajp_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFa349(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFqXAw(path)
   if '{"user_info":{"auth":0}}' in txt:
    FFGWxS(path)
    FFa349(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FFGWxS(path)
    FFa349(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCgg3d.VVmtsl() + fName
    os.system(FFQe93("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FF5nWa(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFa349(self, "Could not download the M3U file!", title=errTitle)
 def VVHwuL(self, Title, VVXOwS, title, txt, colList):
  url = colList[6]
  FF7Xva(VVXOwS, BF(self.VVeNEH, Title, url), title="Checking Server ...")
 def VVBiN9(self, path, VVXOwS, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCtuLp(self, path, VVnRGv=BF(self.VVAf3z, VVXOwS), curRowNum=rowNum)
  else    : FFRYkM(self, path)
 def VVAf3z(self, VVXOwS, fileChanged):
  if fileChanged:
   VVXOwS.cancel()
 def VVJ7rd(self, title):
  curChName = self.VVXOwS.VVRuNe(1)
  FFsShb(self, BF(self.VVv3FG, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVv3FG(self, title, name):
  if name:
   VVs61U, err = CCyEBX.VVCZgt(self, CCyEBX.VVQcI8, VVaGwb=False, VVvSQT=False)
   list = []
   if VVs61U:
    VVX1Oz = CCJU0G()
    name = VVX1Oz.VVrwsf(name)
    ratio = "1"
    for item in VVs61U:
     if name in item[0].lower():
      list.append((item[0], FFuzCW(item[2]), item[3], ratio))
   if list : self.VVVTBC(list, title)
   else : FFa349(self, "Not found:\n\n%s" % name, title=title)
 def VVKjz3(self, title):
  curChName = self.VVXOwS.VVRuNe(1)
  self.session.open(CCvBnC, barTheme=CCvBnC.VVrdqg
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVatut
      , VVnRGv = BF(self.VVab3W, title, curChName))
 def VVatut(self, VVhsRS):
  curChName = self.VVXOwS.VVRuNe(1)
  VVs61U, err = CCyEBX.VVCZgt(self, CCyEBX.VVH7VT, VVaGwb=False, VVvSQT=False)
  if not VVs61U or not VVhsRS or VVhsRS.isCancelled:
   return
  VVhsRS.VVLNy3 = []
  VVhsRS.VVBrFN(len(VVs61U))
  VVX1Oz = CCJU0G()
  curCh = VVX1Oz.VVrwsf(curChName)
  for refCode in VVs61U:
   chName, sat, inDB = VVs61U.get(refCode, ("", "", 0))
   ratio = CCMxom.VVbItS(chName.lower(), curCh)
   if not VVhsRS or VVhsRS.isCancelled:
    return
   VVhsRS.VVwvD4(1, True)
   if VVhsRS and ratio > 50:
    VVhsRS.VVLNy3.append((chName, FFuzCW(sat), refCode.replace("_", ":"), str(ratio)))
 def VVab3W(self, title, curChName, VVL4pA, VVLNy3, threadCounter, threadTotal, threadErr):
  if VVLNy3: self.VVVTBC(VVLNy3, title)
  elif VVL4pA: FFa349(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVVTBC(self, VVuV68, title):
  curChName = self.VVXOwS.VVRuNe(1)
  VVotyZ = self.VVXOwS.VVRuNe(4)
  curUrl  = self.VVXOwS.VVRuNe(5)
  VVuV68.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVVi12  = ("Share Sat/C/T Ref.", BF(self.VVLrVA, title, curChName, VVotyZ, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFEM8S(self, None, title=title, header=header, VV6fdw=VVuV68, VVHqY6=widths, VVJmZ8=26, VVVi12=VVVi12, VVgchu="#0a00112B", VVn4Mh="#0a001126", VVMqKH="#0a001126", VVntre="#00000000")
 def VVLrVA(self, newtitle, curChName, VVotyZ, curUrl, VVXOwS, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVotyZ, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FF8XzP(self.VVXOwS, BF(FF7Xva, self.VVXOwS, BF(self.VVfA6x, VVXOwS, data)), ques, title=newtitle, VVJRkN=True)
 def VVfA6x(self, VVXOwS, data):
  VVXOwS.cancel()
  title, curChName, VVotyZ, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVotyZ = VVotyZ.strip()
  newRefCode = newRefCode.strip()
  if not VVotyZ.endswith(":") : VVotyZ += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVotyZ, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVotyZ + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVxYBv():
    txt = FFqXAw(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFNh5K()
    newRow = []
    for i in range(6):
     newRow.append(self.VVXOwS.VVRuNe(i))
    newRow[4] = newRefCode
    done = self.VVXOwS.VV8NVY(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFWlvR(BF(FF5nWa , self, resTxt, title=title))
  elif resErr: FFWlvR(BF(FFa349, self, resErr, title=title))
 def VVY4Rm(self, VVb0Di, path, VVXOwS, title, txt, colList):
  self.session.open(CCvBnC, barTheme=CCvBnC.VVjpsh
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVIgsB, VVXOwS)
      , VVnRGv = BF(self.VVQINv, VVb0Di, path, VVXOwS))
 def VVIgsB(self, VVXOwS, VVhsRS):
  VVhsRS.VVBrFN(VVXOwS.VVqBOo())
  VVhsRS.VVLNy3 = []
  for row in VVXOwS.VVWsuW():
   if not VVhsRS or VVhsRS.isCancelled:
    return
   VVhsRS.VVwvD4(1, True)
   qUrl = self.VVmfsw(self.VV0ZLM, row[6])
   txt, err = self.VVTXoD(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVgvLY(item, "auth") == "0":
       VVhsRS.VVLNy3.append(qUrl)
    except:
     pass
 def VVQINv(self, VVb0Di, path, VVXOwS, VVL4pA, VVLNy3, threadCounter, threadTotal, threadErr):
  if VVL4pA:
   list = VVLNy3
   title = "Authorized Servers"
   if list:
    totChk = VVXOwS.VVqBOo()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFJCyp()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVDsRp(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFY7FT(str(totAuth), VVlfrr)
     txt += "%s\n\n%s"    %  (FFY7FT("Result File:", VVJ2KG), newPath)
     FFyv2f(self, txt, title=title)
     VVXOwS.close()
     VVb0Di.close()
    else:
     FF5nWa(self, "All URLs are authorized.", title=title)
   else:
    FFa349(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVTXoD(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVJGCM(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVHvuJ(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CCDiIK.VVGjn5()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VVJ7MV(decodedUrl):
  return CCgg3d.VVHvuJ(decodedUrl, justRetDotExt=True)
 def VVmfsw(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVJGCM(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VV0ZLM   : return "%s"            % url
  elif mode == self.VVdkUS   : return "%s&action=get_live_categories"     % url
  elif mode == self.VV6MCx   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVxW0j  : return "%s&action=get_series_categories"     % url
  elif mode == self.VV6QSZ  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVmYdg : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVi2Nw   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVNXbt    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVKLUx  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVgiFj : return "%s&action=get_live_streams"      % url
  elif mode == self.VVTUuW  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVgvLY(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFXtJp(int(val))
    elif is_base64 : val = FF5dpp(val)
    elif isToHHMMSS : val = FFCiZs(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVNta5(self, title, path):
  if fileExists(path):
   enc = CCAUx4.VVx4Et(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = CCgg3d.VVpaCr(line)
     if qUrl:
      break
   if qUrl : self.VVeNEH(title, qUrl)
   else : FFa349(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFa349(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVC1fB(self):
  title = "Current Channel Server"
  qUrl, iptvRef = CCgg3d.VVitjq(self)
  if qUrl or "chCode" in iptvRef:
   p = CC2WTV()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV3YVQ(iptvRef)
   if valid:
    self.VV7HZ9(self, host, mac)
    return
   elif qUrl:
    FF7Xva(self, BF(self.VVeNEH, title, qUrl), title="Checking Server ...")
    return
  FFa349(self, "Error in current channel URL !", title=title)
 @staticmethod
 def VVitjq(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(SELF)
  qUrl = CCgg3d.VVpaCr(decodedUrl)
  return qUrl, iptvRef
 @staticmethod
 def VVpaCr(url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVeNEH(self, title, url):
  self.curUrl = url
  self.VVpACXData = {}
  qUrl = self.VVmfsw(self.VV0ZLM, url)
  txt, err = self.VVTXoD(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVpACXData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVpACXData["username"    ] = self.VVgvLY(item, "username"        )
    self.VVpACXData["password"    ] = self.VVgvLY(item, "password"        )
    self.VVpACXData["message"    ] = self.VVgvLY(item, "message"        )
    self.VVpACXData["auth"     ] = self.VVgvLY(item, "auth"         )
    self.VVpACXData["status"    ] = self.VVgvLY(item, "status"        )
    self.VVpACXData["exp_date"    ] = self.VVgvLY(item, "exp_date"    , isDate=True )
    self.VVpACXData["is_trial"    ] = self.VVgvLY(item, "is_trial"        )
    self.VVpACXData["active_cons"   ] = self.VVgvLY(item, "active_cons"       )
    self.VVpACXData["created_at"   ] = self.VVgvLY(item, "created_at"   , isDate=True )
    self.VVpACXData["max_connections"  ] = self.VVgvLY(item, "max_connections"      )
    self.VVpACXData["allowed_output_formats"] = self.VVgvLY(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVpACXData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVpACXData["url"    ] = self.VVgvLY(item, "url"        )
    self.VVpACXData["port"    ] = self.VVgvLY(item, "port"        )
    self.VVpACXData["https_port"  ] = self.VVgvLY(item, "https_port"      )
    self.VVpACXData["server_protocol" ] = self.VVgvLY(item, "server_protocol"     )
    self.VVpACXData["rtmp_port"   ] = self.VVgvLY(item, "rtmp_port"       )
    self.VVpACXData["timezone"   ] = self.VVgvLY(item, "timezone"       )
    self.VVpACXData["timestamp_now"  ] = self.VVgvLY(item, "timestamp_now"  , isDate=True )
    self.VVpACXData["time_now"   ] = self.VVgvLY(item, "time_now"       )
    VVW1xb  = self.VVq42K(True)
    OKBtnFnc = self.VV3DzW
    infoBtnFnc = self.VVUvtB
    VVszaU = ("Home Menu", FFJAbK)
    VVa3i0= ("Add to Menu", BF(CCgg3d.VV2HYx, self, False, self.VVpACXData["playListURL"]))
    VVkjyo = ("Bookmark Server", BF(CCgg3d.VVlyBr, self, False, self.VVpACXData["playListURL"]))
    FFLFXy(self, None, title="IPTV Server Resources", VVW1xb=VVW1xb, OKBtnFnc=OKBtnFnc, infoBtnFnc=infoBtnFnc, VVszaU=VVszaU, VVa3i0=VVa3i0, VVkjyo=VVkjyo)
   else:
    err = "Could not get data from server !"
  if err:
   FFa349(self, err, title=title)
  FF1ojr(self)
 def VV3DzW(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FF7Xva(menuInstance, BF(self.VV1eBW, self.VVdkUS  , title=title), title=wTxt)
   elif ref == "vod"   : FF7Xva(menuInstance, BF(self.VV1eBW, self.VV6MCx  , title=title), title=wTxt)
   elif ref == "series"  : FF7Xva(menuInstance, BF(self.VV1eBW, self.VVxW0j , title=title), title=wTxt)
   elif ref == "catchup"  : FF7Xva(menuInstance, BF(self.VV1eBW, self.VV6QSZ , title=title), title=wTxt)
   elif ref == "accountInfo" : FF7Xva(menuInstance, BF(self.VV7W3n           , title=title), title=wTxt)
 def VVUvtB(self, menuInstance, txt, ref, ndx):
  FF7Xva(menuInstance, self.VVST7Q)
 def VVST7Q(self):
  txt = self.curUrl
  if VV5W0y:
   ver, err = self.VV872v(self.VV0TPr())
   txt += "\n\n"
   txt += "Original\t: %s\n" % self.curUrl
   txt += "Modified\t: %s\n" % self.VVGVRb
   txt += "PHP\t: %s\n"  % self.VVDeuh
   txt += "Extra\t: %s\n"  % {2:"Big", 3:"Sml"}.get(self.VVjz2H, "-")
   txt += "Version\t: %s"  % (ver or err)
  FFyv2f(self, txt, title="Current Server URL")
 def VV7W3n(self, title):
  rows = []
  for key, val in self.VVpACXData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VVs59H
   else:
    num, part = "1", self.VVLhpI
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVQcug  = ("Home Menu", FFJAbK, [])
  VVsTsL  = None
  if VV5W0y:
   VVsTsL = ("Get JS" , BF(self.VVcRoQ, "/".join(self.VVpACXData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFEM8S(self, None, title=title, width=1200, header=header, VV6fdw=rows, VVHqY6=widths, VVJmZ8=26, VVQcug=VVQcug, VVsTsL=VVsTsL, VVgchu="#0a00292B", VVn4Mh="#0a002126", VVMqKH="#0a002126", VVntre="#00000000", searchCol=2)
 def VVPSWD(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    VVX1Oz = CCJU0G()
    if mode in (self.VVi2Nw, self.VVTUuW):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVgvLY(item, "num"         )
      name     = self.VVgvLY(item, "name"        )
      stream_id    = self.VVgvLY(item, "stream_id"       )
      stream_icon    = self.VVgvLY(item, "stream_icon"       )
      epg_channel_id   = self.VVgvLY(item, "epg_channel_id"      )
      added     = self.VVgvLY(item, "added"    , isDate=True )
      is_adult    = self.VVgvLY(item, "is_adult"       )
      category_id    = self.VVgvLY(item, "category_id"       )
      tv_archive    = self.VVgvLY(item, "tv_archive"       )
      direct_source   = self.VVgvLY(item, "direct_source"      )
      tv_archive_duration  = self.VVgvLY(item, "tv_archive_duration"     )
      name = VVX1Oz.VVaoP0(name, is_adult)
      if name:
       if mode == self.VVi2Nw or mode == self.VVTUuW and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VVNXbt:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVgvLY(item, "num"         )
      name    = self.VVgvLY(item, "name"        )
      stream_id   = self.VVgvLY(item, "stream_id"       )
      stream_icon   = self.VVgvLY(item, "stream_icon"       )
      added    = self.VVgvLY(item, "added"    , isDate=True )
      is_adult   = self.VVgvLY(item, "is_adult"       )
      category_id   = self.VVgvLY(item, "category_id"       )
      container_extension = self.VVgvLY(item, "container_extension"     ) or "mp4"
      name = VVX1Oz.VVaoP0(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VVKLUx:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVgvLY(item, "num"        )
      name    = self.VVgvLY(item, "name"       )
      series_id   = self.VVgvLY(item, "series_id"      )
      cover    = self.VVgvLY(item, "cover"       )
      genre    = self.VVgvLY(item, "genre"       )
      episode_run_time = self.VVgvLY(item, "episode_run_time"    )
      category_id   = self.VVgvLY(item, "category_id"      )
      container_extension = self.VVgvLY(item, "container_extension"    ) or "mp4"
      name = VVX1Oz.VVaoP0(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VV1eBW(self, mode, title):
  cList, err = self.VVrNa0(mode)
  if cList and mode == self.VV6QSZ:
   cList = self.VVyVaA(cList)
  if err:
   FFa349(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVgchu, VVn4Mh, VVMqKH, VVntre = self.VVYCkd(mode)
   mName = self.VVbPwt(mode)
   if   mode == self.VVdkUS  : fMode = self.VVi2Nw
   elif mode == self.VV6MCx  : fMode = self.VVNXbt
   elif mode == self.VVxW0j : fMode = self.VVKLUx
   elif mode == self.VV6QSZ : fMode = self.VVTUuW
   if mode == self.VV6QSZ:
    VVQR2V = None
    VVmmwr = None
   else:
    VVQR2V = ("Find in %s" % mName , BF(self.VVNvq1, fMode, True) , [])
    VVmmwr = ("Find in Selected" , BF(self.VVNvq1, fMode, False) , [])
   VVVi12   = ("Show List"   , BF(self.VVkhQV, mode)  , [])
   VVQcug  = ("Home Menu"   , FFJAbK         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFEM8S(self, None, title=title, width=1200, header=header, VV6fdw=cList, VVHqY6=widths, VVJmZ8=30, VVQcug=VVQcug, VVQR2V=VVQR2V, VVmmwr=VVmmwr, VVVi12=VVVi12, VVgchu=VVgchu, VVn4Mh=VVn4Mh, VVMqKH=VVMqKH, VVntre=VVntre, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFa349(self, "No list from server !", title=title)
  FF1ojr(self)
 def VVrNa0(self, mode):
  qUrl  = self.VVmfsw(mode, self.VVpACXData["playListURL"])
  txt, err = self.VVTXoD(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    VVX1Oz = CCJU0G()
    for item in tDict:
     category_id  = self.VVgvLY(item, "category_id"  )
     category_name = self.VVgvLY(item, "category_name" )
     parent_id  = self.VVgvLY(item, "parent_id"  )
     category_name = VVX1Oz.VVf5ab(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVyVaA(self, catList):
  mode  = self.VVTUuW
  qUrl  = self.VVmfsw(mode, self.VVpACXData["playListURL"])
  txt, err = self.VVTXoD(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVPSWD(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVkhQV(self, mode, VVXOwS, title, txt, colList):
  title = colList[1]
  FF7Xva(VVXOwS, BF(self.VVhfst, mode, VVXOwS, title, txt, colList), title="Downloading ...")
 def VVhfst(self, mode, VVXOwS, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVbPwt(mode) + " : "+ bName
  if   mode == self.VVdkUS  : mode = self.VVi2Nw
  elif mode == self.VV6MCx  : mode = self.VVNXbt
  elif mode == self.VVxW0j : mode = self.VVKLUx
  elif mode == self.VV6QSZ : mode = self.VVTUuW
  qUrl  = self.VVmfsw(mode, self.VVpACXData["playListURL"], catID)
  txt, err = self.VVTXoD(qUrl)
  list  = []
  if not err and mode in (self.VVi2Nw, self.VVNXbt, self.VVKLUx, self.VVTUuW):
   list, err = self.VVPSWD(mode, txt)
  if err:
   FFa349(self, err, title=title)
  elif list:
   VVQcug  = ("Home Menu"   , FFJAbK            , [])
   if mode in (self.VVi2Nw, self.VVTUuW):
    VVgchu, VVn4Mh, VVMqKH, VVntre = self.VVYCkd(mode)
    VVd4CR = (""     , BF(self.VVCaBi, mode)      , [])
    VVsTsL = ("Download Options" , BF(self.VV5MoD, mode, "", "")   , [])
    VVQR2V = ("Options"   , BF(self.VVuADS, "lv", mode, bName)   , [])
    VVmmwr = ("Posters Mode"  , BF(self.VVXmqL, mode, False)     , [])
    if mode == self.VVi2Nw:
     VVVi12 = ("Play"    , BF(self.VVlIxZ, mode)       , [])
    else:
     VVVi12 = ("Programs"   , BF(self.VVVsbQ, mode, bName) , [])
   elif mode == self.VVNXbt:
    VVgchu, VVn4Mh, VVMqKH, VVntre = self.VVYCkd(mode)
    VVVi12  = ("Play"    , BF(self.VVlIxZ, mode)       , [])
    VVd4CR = (""     , BF(self.VVCaBi, mode)      , [])
    VVsTsL = ("Download Options" , BF(self.VV5MoD, mode, "v", "")   , [])
    VVQR2V = ("Options"   , BF(self.VVuADS, "v", mode, bName)   , [])
    VVmmwr = ("Posters Mode"  , BF(self.VVXmqL, mode, False)     , [])
   elif mode == self.VVKLUx:
    VVgchu, VVn4Mh, VVMqKH, VVntre = self.VVYCkd("series2")
    VVVi12  = ("Show Seasons"  , BF(self.VV4z5d, mode)       , [])
    VVd4CR = (""     , BF(self.VVD2mH, mode)     , [])
    VVsTsL = None
    VVQR2V = None
    VVmmwr = ("Posters Mode"  , BF(self.VVXmqL, mode, True)      , [])
   header, widths, VVI7B0 = self.VVcftY(mode)
   FFEM8S(self, None, title=title, header=header, VV6fdw=list, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26, VVVi12=VVVi12, VVQcug=VVQcug, VVsTsL=VVsTsL, VVQR2V=VVQR2V, VVmmwr=VVmmwr, lastFindConfigObj=CFG.lastFindIptv, VVd4CR=VVd4CR, VVgchu=VVgchu, VVn4Mh=VVn4Mh, VVMqKH=VVMqKH, VVntre=VVntre, VVhmtx=True, searchCol=1)
  else:
   FFa349(self, "No Channels found !", title=title)
  FF1ojr(self)
 def VVcftY(self, mode):
  if mode in (self.VVi2Nw, self.VVTUuW):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VVI7B0  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VVNXbt:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VVI7B0  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VVKLUx:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VVI7B0  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VVI7B0
 def VVVsbQ(self, mode, bName, VVXOwS, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVpACXData["playListURL"]
  ok_fnc  = BF(self.VVxVJh, hostUrl, chName, catId, streamId)
  FF7Xva(VVXOwS, BF(CCgg3d.VVegXI, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVxVJh(self, chUrl, chName, catId, streamId, VVXOwS, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCgg3d.VVJGCM(chUrl)
   chNum = "333"
   refCode = CCgg3d.VVbRWT(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFqi6V(self, chUrl, VVEPKV=False)
   CCXzGX.VVmA7N(self.session)
  else:
   FFa349(self, "Incorrect Timestamp", pTitle)
 def VV4z5d(self, mode, VVXOwS, title, txt, colList):
  title = colList[1]
  FF7Xva(VVXOwS, BF(self.VVABWw, mode, VVXOwS, title, txt, colList), title="Downloading ...")
 def VVABWw(self, mode, VVXOwS, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVmfsw(self.VVmYdg, self.VVpACXData["playListURL"], series_id)
  txt, err = self.VVTXoD(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVgvLY(tDict["info"], "name"   )
      category_id = self.VVgvLY(tDict["info"], "category_id" )
      icon  = self.VVgvLY(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      VVX1Oz = CCJU0G()
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVgvLY(EP, "id"     )
        episode_num   = self.VVgvLY(EP, "episode_num"   )
        epTitle    = self.VVgvLY(EP, "title"     )
        container_extension = self.VVgvLY(EP, "container_extension" )
        seasonNum   = self.VVgvLY(EP, "season"    )
        epTitle = VVX1Oz.VVaoP0(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFa349(self, err, title=title)
  elif list:
   VVQcug = ("Home Menu"   , FFJAbK          , [])
   VVsTsL = ("Download Options" , BF(self.VV5MoD, mode, "s", title), [])
   VVQR2V = ("Options"   , BF(self.VVuADS, "s", mode, title) , [])
   VVmmwr = ("Posters Mode"  , BF(self.VVXmqL, mode, False)   , [])
   VVd4CR = (""     , BF(self.VVCaBi, mode)    , [])
   VVVi12  = ("Play"    , BF(self.VVlIxZ, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVI7B0  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFEM8S(self, None, title=title, header=header, VV6fdw=list, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26, VVQcug=VVQcug, VVsTsL=VVsTsL, VVVi12=VVVi12, VVd4CR=VVd4CR, VVQR2V=VVQR2V, VVmmwr=VVmmwr, lastFindConfigObj=CFG.lastFindIptv, VVgchu="#0a00292B", VVn4Mh="#0a002126", VVMqKH="#0a002126", VVntre="#00000000")
  else:
   FFa349(self, "No Channels found !", title=title)
  FF1ojr(self)
 def VVNvq1(self, mode, isAll, VVXOwS, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVW1xb = []
  VVW1xb.append(("Keyboard"  , "manualEntry"))
  VVW1xb.append(("From Filter" , "fromFilter"))
  FFLFXy(self, BF(self.VVMxRc, VVXOwS, mode, onlyCatID), title="Input Type", VVW1xb=VVW1xb, width=400)
 def VVMxRc(self, VVXOwS, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFsShb(self, BF(self.VVLLLx, VVXOwS, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCuF2O(self)
    filterObj.VVpFrx(BF(self.VVLLLx, VVXOwS, mode, onlyCatID))
 def VVLLLx(self, VVXOwS, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FFxMsu(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CCuF2O.VVUxc8(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FFa349(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FFa349(self, "All words must be at least 3 characters !", title=title)
        return
     VVX1Oz = CCJU0G()
     if CFG.hideIptvServerAdultWords.getValue() and VVX1Oz.VV3FFy(words):
      FFa349(self, VVX1Oz.VVQ3aK(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CCvBnC, barTheme=CCvBnC.VVrdqg
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVefEc, VVXOwS, mode, onlyCatID, title, words, toFind, asPrefix, VVX1Oz)
          , VVnRGv = BF(self.VV6p30, mode, toFind, title))
   if not words:
    FF1ojr(VVXOwS, "Nothing to find !", 1500)
 def VVefEc(self, VVXOwS, mode, onlyCatID, title, words, toFind, asPrefix, VVX1Oz, VVhsRS):
  VVhsRS.VVBrFN(VVXOwS.VV9Wh4() if onlyCatID is None else 1)
  VVhsRS.VVLNy3 = []
  for row in VVXOwS.VVWsuW():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVhsRS or VVhsRS.isCancelled:
    return
   VVhsRS.VVwvD4(1)
   VVhsRS.VV2RUn(catName)
   qUrl  = self.VVmfsw(mode, self.VVpACXData["playListURL"], catID)
   txt, err = self.VVTXoD(qUrl)
   if not err:
    tList, err = self.VVPSWD(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = VVX1Oz.VVaoP0(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       VVhsRS.VVLNy3.append(item)
 def VV6p30(self, mode, toFind, title, VVL4pA, VVLNy3, threadCounter, threadTotal, threadErr):
  if VVLNy3:
   title = self.VVYHPj(mode, toFind)
   if mode == self.VVi2Nw or mode == self.VVNXbt:
    if mode == self.VVNXbt : typ = "v"
    else          : typ = ""
    bName   = CCgg3d.VV9jHr(toFind)
    VVVi12  = ("Play"     , BF(self.VVlIxZ, mode)     , [])
    VVsTsL = ("Download Options" , BF(self.VV5MoD, mode, typ, "") , [])
    VVQR2V = ("Options"   , BF(self.VVuADS, "fnd", mode, bName), [])
    VVmmwr = ("Posters Mode"  , BF(self.VVXmqL, mode, False)   , [])
    VVd4CR = (""     , BF(self.VVCaBi, mode)    , [])
   elif mode == self.VVKLUx:
    VVVi12  = ("Show Seasons"  , BF(self.VV4z5d, mode)     , [])
    VVQR2V = None
    VVsTsL = None
    VVmmwr = ("Posters Mode"  , BF(self.VVXmqL, mode, True)    , [])
    VVd4CR = (""     , BF(self.VVD2mH, mode)   , [])
   VVQcug  = ("Home Menu"   , FFJAbK          , [])
   header, widths, VVI7B0 = self.VVcftY(mode)
   VVXOwS = FFEM8S(self, None, title=title, header=header, VV6fdw=VVLNy3, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26, VVVi12=VVVi12, VVQcug=VVQcug, VVsTsL=VVsTsL, VVQR2V=VVQR2V, VVmmwr=VVmmwr, VVd4CR=VVd4CR, VVgchu="#0a00292B", VVn4Mh="#0a002126", VVMqKH="#0a002126", VVntre="#00000000", VVhmtx=True, searchCol=1)
   if not VVL4pA:
    FF1ojr(VVXOwS, "Stopped" , 1000)
  else:
   if VVL4pA:
    FFa349(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVd8ay(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VVi2Nw, self.VVTUuW):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VVNXbt:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FFyZAn(chName)
  url = self.VVpACXData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVJGCM(url)
  refCode = self.VVbRWT(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVCaBi(self, mode, VVXOwS, title, txt, colList):
  FF7Xva(VVXOwS, BF(self.VV7vdj, mode, VVXOwS, title, txt, colList))
 def VV7vdj(self, mode, VVXOwS, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVd8ay(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFr9gS(self, fncMode=CCsydO.VVY4BY, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVD2mH(self, mode, VVXOwS, title, txt, colList):
  FF7Xva(VVXOwS, BF(self.VVF6bP, mode, VVXOwS, title, txt, colList))
 def VVF6bP(self, mode, VVXOwS, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFr9gS(self, fncMode=CCsydO.VVP677, chName=name, text=txt, picUrl=Cover)
 def VVXmqL(self, mode, isSerNames, VVXOwS, title, txt, colList):
  if   mode in ("itv"  , CCgg3d.VVi2Nw, CCgg3d.VVTUuW): category = "live"
  elif mode in ("vod"  , CCgg3d.VVNXbt )          : category = "vod"
  elif mode in ("series" , CCgg3d.VVKLUx)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VVi2Nw : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVTUuW : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVNXbt  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVKLUx : picCol, descCol, descTxt = 5, 0, "Season"
  FF7Xva(VVXOwS, BF(self.session.open, CC5dSb, VVXOwS, category, nameCol, picCol, descCol, descTxt))
 def VV5MoD(self, mode, typ, seriesName, VVXOwS, title, txt, colList):
  VVW1xb = []
  isMulti = VVXOwS.VVyKav
  tot  = VVXOwS.VVYRl7()
  if isMulti:
   if tot < 1:
    FF1ojr(VVXOwS, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVW1xb.append(("Download %s PIcon%s" % (name, FFmJCK(tot)), "dnldPicons" ))
  if typ:
   VVW1xb.append(VVswUs)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVW1xb.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVW1xb.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVW1xb.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCXCxH.VVLWM5():
    VVW1xb.append(VVswUs)
    VVW1xb.append(("Download Manager"      , "dload_stat" ))
  FFLFXy(self, BF(self.VV8gyM, VVXOwS, mode, typ, seriesName, colList), title="Download Options", VVW1xb=VVW1xb)
 def VV8gyM(self, VVXOwS, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVs04a(VVXOwS, mode)
   elif item == "dnldSel"  : self.VVYEAk(VVXOwS, mode, typ, colList, True)
   elif item == "addSel"  : self.VVYEAk(VVXOwS, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VViY1C(VVXOwS, mode, typ, seriesName)
   elif item == "dload_stat" : CCXCxH.VVLg6m(self)
 def VVYEAk(self, VVXOwS, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVpkFU(mode, typ, colList)
  if startDnld:
   CCXCxH.VV5h2B(self, decodedUrl)
  else:
   self.VVTOFg(VVXOwS, "Add to Download list", chName, [decodedUrl], startDnld)
 def VViY1C(self, VVXOwS, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVXOwS.VVWsuW():
   chName, decodedUrl = self.VVpkFU(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVTOFg(VVXOwS, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVTOFg(self, VVXOwS, title, chName, decodedUrl_list, startDnld):
  FF8XzP(self, BF(self.VVw134, VVXOwS, decodedUrl_list, startDnld), chName, title=title)
 def VVw134(self, VVXOwS, decodedUrl_list, startDnld):
  added, skipped = CCXCxH.VV3kFz(decodedUrl_list)
  FF1ojr(VVXOwS, "Added", 1000)
 def VVpkFU(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVd8ay(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVbMmd(mode, colList)
   refCode, chUrl = self.VVRnJM(self.VVGVRb, self.VVnueZ, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFTSbj(chUrl)
  return chName, decodedUrl
 def VVs04a(self, VVXOwS, mode):
  if os.system(FFQe93("which ffmpeg")) == 0:
   self.session.open(CCvBnC, barTheme=CCvBnC.VVjpsh
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VVEZZY, VVXOwS, mode)
       , VVnRGv = self.VVOmsN)
  else:
   FF8XzP(self, BF(CCgg3d.VV4Sso, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVOmsN(self, VVL4pA, VVLNy3, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVLNy3["proces"], VVLNy3["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVLNy3["ok"], VVLNy3["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVLNy3["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVLNy3["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVLNy3["badURL"]
  txt += "Download Failure\t: %d\n"   % VVLNy3["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVLNy3["path"]
  if not VVL4pA  : color = "#11402000"
  elif VVLNy3["err"]: color = "#11201000"
  else     : color = None
  if VVLNy3["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVLNy3["err"], txt)
  title = "PIcons Download Result"
  if not VVL4pA:
   title += "  (cancelled)"
  FFyv2f(self, txt, title=title, VVMqKH=color)
 def VVEZZY(self, VVXOwS, mode, VVhsRS):
  isMulti = VVXOwS.VVyKav
  if isMulti : totRows = VVXOwS.VVYRl7()
  else  : totRows = VVXOwS.VV9Wh4()
  VVhsRS.VVBrFN(totRows)
  VVhsRS.VVtYMO(0)
  counter     = VVhsRS.counter
  maxValue    = VVhsRS.maxValue
  pPath     = CCMxom.VVVqXw()
  VVhsRS.VVLNy3 = {   "total" : totRows
         , "proces" : 0
         , "attempt" : 0
         , "fail" : 0
         , "ok"  : 0
         , "size0" : 0
         , "exist" : 0
         , "badURL" : 0
         , "path" : pPath
         , "err"  : "" }
  try:
   for rowNum, row in enumerate(VVXOwS.VVWsuW()):
    if VVhsRS.isCancelled:
     break
    if not isMulti or VVXOwS.VVxegf(rowNum):
     VVhsRS.VVLNy3["proces"] += 1
     VVhsRS.VVwvD4(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVbMmd(mode, row)
      refCode = CCgg3d.VVbRWT(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVR6gB(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVd8ay(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVhsRS.VVLNy3["attempt"] += 1
       path, err = FFjmFi(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVhsRS:
         VVhsRS.VVLNy3["ok"] += 1
         VVhsRS.VVtYMO(VVhsRS.VVLNy3["ok"])
        if FFPYZx(path) > 0:
         cmd = CCsydO.VVgxpk(path)
         cmd += FFQe93("mv -f '%s' '%s'" % (path, pPath)) + ";"
         os.system(cmd)
        else:
         if VVhsRS:
          VVhsRS.VVLNy3["size0"] += 1
         FFGWxS(path)
       elif err:
        if VVhsRS:
         VVhsRS.VVLNy3["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVhsRS:
          VVhsRS.VVLNy3["err"] = err.title()
         break
      else:
       if VVhsRS:
        VVhsRS.VVLNy3["exist"] += 1
     else:
      if VVhsRS:
       VVhsRS.VVLNy3["badURL"] += 1
  except:
   pass
 def VV3kxH(self):
  title = "Download PIcons for Current Bouquet"
  if os.system(FFQe93("which ffmpeg")) == 0:
   self.session.open(CCvBnC, barTheme=CCvBnC.VVjpsh
       , titlePrefix = ""
       , fncToRun  = self.VVWS7k
       , VVnRGv = BF(self.VVj80V, title))
  else:
   FF8XzP(self, BF(CCgg3d.VV4Sso, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VVWS7k(self, VVhsRS):
  bName = CCRtNz.VVyJwc()
  pPath = CCMxom.VVVqXw()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVhsRS.VVLNy3 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CCRtNz.VV3TCa()
  if not VVhsRS or VVhsRS.isCancelled:
   return
  if not services or len(services) == 0:
   VVhsRS.VVLNy3 = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVhsRS.VVBrFN(totCh)
  VVhsRS.VVtYMO(0)
  for serv in services:
   if not VVhsRS or VVhsRS.isCancelled:
    return
   VVhsRS.VVLNy3 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVhsRS.VVwvD4(1)
   VVhsRS.VVtYMO(totPic)
   fullRef  = serv[0]
   if FFDOE0(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFTSbj(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CC2WTV.VViiHf(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CCgg3d.VVHvuJ(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInv += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCgg3d.VVTXoD(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CCsydO.VVBvRq(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFjmFi(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVhsRS:
     VVhsRS.VVtYMO(totPic)
    if FFPYZx(path) > 0:
     cmd = CCsydO.VVgxpk(path)
     cmd += FFQe93("mv -f '%s' '%s'" % (path, pPath)) + ";"
     os.system(cmd)
     totPicOK += 1
    else:
     totSize0
     FFGWxS(path)
  if VVhsRS:
   VVhsRS.VVLNy3 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVj80V(self, title, VVL4pA, VVLNy3, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VVLNy3
  if err:
   FFa349(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FFY7FT(str(totExist)  , VV9ZlA)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFY7FT(str(totNotIptv)  , VV9ZlA)
    if totServErr : txt += "Server Errors\t: %s\n" % FFY7FT(str(totServErr) + t1, VV9ZlA)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FFY7FT(str(totParseErr) , VV9ZlA)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FFY7FT(str(totInvServ)  , VV9ZlA)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FFY7FT(str(totInvPicUrl) , VV9ZlA)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FFY7FT(str(totSize0)  , VV9ZlA)
   if not VVL4pA:
    title += "  (stopped)"
   FFyv2f(self, txt, title=title)
 @staticmethod
 def VV4Sso(SELF):
  cmd = FFkjia(VVkKCu, "ffmpeg")
  if cmd : FFsZIz(SELF, cmd, title="Installing FFmpeg")
  else : FFPsN3(SELF)
 @staticmethod
 def VVNJtp(SELF):
  SELF.session.open(CCvBnC, barTheme=CCvBnC.VVjpsh
      , titlePrefix = ""
      , fncToRun  = CCgg3d.VVvKtx
      , VVnRGv = BF(CCgg3d.VVnXiW, SELF))
 @staticmethod
 def VVvKtx(VVhsRS):
  bName = CCRtNz.VVyJwc()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVhsRS.VVLNy3 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CCRtNz.VV3TCa()
  if not VVhsRS or VVhsRS.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVhsRS.VVBrFN(totCh)
   for serv in services:
    if not VVhsRS or VVhsRS.isCancelled:
     return
    VVhsRS.VVwvD4(1)
    fullRef = serv[0]
    if FFDOE0(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFTSbj(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     if span:
      valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CC2WTV.VViiHf(decodedUrl)
      if valid and mode == "itv" : uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
      else      : uHost = uUser = uPass = uId = uChName = ""
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCgg3d.VVHvuJ(m3u_Url)
     if VVhsRS:
      VVhsRS.VVoWvY(totEpgOK, uChName)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCgg3d.VVfSX2(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCos4Q.VVsRne(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if VVhsRS:
     VVhsRS.VVLNy3 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVhsRS.VVLNy3 = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 @staticmethod
 def VVnXiW(SELF, VVL4pA, VVLNy3, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVLNy3
  title = "IPTV EPG Import"
  if err:
   FFa349(SELF, err, title=title)
  else:
   if VVL4pA and totEpgOK > 0:
    CCos4Q.VVHHlQ()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFY7FT(str(totNotIptv), VV9ZlA)
    if totServErr : txt += "Server Errors\t: %s\n" % FFY7FT(str(totServErr) + t1, VV9ZlA)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFY7FT(str(totInv), VV9ZlA)
   if not VVL4pA:
    title += "  (stopped)"
   FFyv2f(SELF, txt, title=title)
 @staticmethod
 def VVfSX2(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCgg3d.VVJGCM(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCgg3d.VVTXoD(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCgg3d.VVgvLY(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CCgg3d.VVgvLY(item, "lang"        ).upper()
    now_playing   = CCgg3d.VVgvLY(item, "now_playing"      )
    start    = CCgg3d.VVgvLY(item, "start"        )
    start_timestamp  = CCgg3d.VVgvLY(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCgg3d.VVgvLY(item, "start_timestamp"     )
    stop_timestamp  = CCgg3d.VVgvLY(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCgg3d.VVgvLY(item, "stop_timestamp"      )
    tTitle    = CCgg3d.VVgvLY(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVbRWT(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCgg3d.VVeiYl(catID, MAX_4b)
  TSID = CCgg3d.VVeiYl(chNum, MAX_4b)
  ONID = CCgg3d.VVeiYl(chNum, MAX_4b)
  NS  = CCgg3d.VVeiYl(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVeiYl(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VV9jHr(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVYCkd(mode):
  if   mode in ("itv"  , CCgg3d.VVdkUS)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCgg3d.VV6MCx)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCgg3d.VVxW0j) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCgg3d.VV6QSZ) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCgg3d.VVTUuW    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVF5BS(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVVXZj:
   excl = FFiZoB(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FFa349(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FF94gP('find %s %s %s' % (path, excl, par))
  if files:
   err = CCbI7Z.VVPSgD(files)
   if err : FFa349(self, err + FFY7FT('\n\n( Change "IPTV Hosts Files Path" to "Custom" and try again )', VVJ2KG))
   else : return files
  else:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FFa349(self, err)
  return []
 @staticmethod
 def VVmtsl():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FFnWu0(path)
  return "/"
 @staticmethod
 def VVegXI(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CCgg3d.VVfSX2(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FFa349(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVgchu, VVn4Mh, VVMqKH, VVntre = CCgg3d.VVYCkd("")
   VVQcug = ("Home Menu" , FFJAbK, [])
   VVVi12  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVI7B0  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFEM8S(SELF, None, title="Programs for : " + chName, header=header, VV6fdw=pList, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=24, VVVi12=VVVi12, VVQcug=VVQcug, VVgchu=VVgchu, VVn4Mh=VVn4Mh, VVMqKH=VVMqKH, VVntre=VVntre)
  else:
   FFa349(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVg0OK(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VV2HYx(self, isPortal, line, VVlAViObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FF8XzP(self, BF(self.VV2Rei, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FFxMsu(confItem, line)
   FF5nWa(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VV2Rei(self, title, confItem):
  FFxMsu(confItem, "")
  FF5nWa(self, "Removed from IPTV Menu.", title=title)
 def VVSDkE(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VV7HZ9(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FF7Xva(self, BF(self.VVeNEH, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FFa349(self, "Incorrect server data !")
 @staticmethod
 def VVlyBr(SELF, isPortal, line, VVlAViObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCgg3d.VVmtsl()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFa349(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FF5nWa(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFa349(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVuADS(self, source, mode, curBName, VVXOwS, title, txt, colList):
  isMulti = VVXOwS.VVyKav
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVXOwS.VVYRl7()
   totTxt = "%d Service%s" % (tot, FFmJCK(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FFY7FT(totTxt, VVJ2KG)
  curBName2 = ""
  if self.curUrl:
   name = iUrlparse(self.curUrl).netloc
   if name:
    curBName2 = "%s (%s)" % (curBName, name.split(":")[0])
  title = "Add to Bouquet"
  mSel = CCTHuN(self, VVXOwS, addSep=False)
  thTxt = "Adding Services ..."
  VVW1xb, cbFncDict = [], None
  VVW1xb.append(VVswUs)
  if itemsOK:
   VVW1xb.append(("Add %s to New Bouquet : %s"    % (totTxt, FFY7FT(curBName , VVlfrr)), "addToCur1"))
   if curBName2: VVW1xb.append(("Add %s to New Bouquet : %s" % (totTxt, FFY7FT(curBName2, VV5cg1)) , "addToCur2"))
   VVW1xb.append(("Add %s to Existing Bouquet ..."   % (totTxt)            , "addToNew" ))
   cbFncDict = { "addToCur1": BF(FF7Xva, mSel.VVXOwS, BF(self.VVXhIm,source, mode, curBName , VVXOwS, title), title=thTxt)
      , "addToCur2": BF(FF7Xva, mSel.VVXOwS, BF(self.VVXhIm,source, mode, curBName2, VVXOwS, title), title=thTxt)
      , "addToNew" : BF(self.VV4UWF, source, mode, curBName, VVXOwS, title)
      }
  else:
   VVW1xb.append(("Add to Bouquet (nothing selected)", ))
  mSel.VVoxj8(VVW1xb, cbFncDict, width=1200)
 def VVXhIm(self, source, mode, curBName, VVXOwS, Title):
  chUrlLst = self.VVJQA6(source, mode, VVXOwS)
  CCRtNz.VV05zS(self, Title, curBName, "", chUrlLst)
 def VV4UWF(self, source, mode, curBName, VVXOwS, Title):
  picker = CCRtNz(self, VVXOwS, Title, BF(self.VVJQA6, source, mode, VVXOwS), defBName=curBName)
 def VVJQA6(self, source, mode, VVXOwS):
  totChange = 0
  isMulti = VVXOwS.VVyKav
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVXOwS.VVWsuW()):
   if not isMulti or VVXOwS.VVxegf(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVbMmd(mode, row)
     refCode, chUrl = self.VVRnJM(self.VVGVRb, self.VVnueZ, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VVungR(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VVd8ay(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
class CCLp6y(object):
 def __init__(self, SELF):
  SELF["mySbFrm"] = Label()
  SELF["mySbBak"] = Label()
  SELF["mySbSld"] = Label()
  self.frm, self.bak, self.sld = SELF["mySbFrm"], SELF["mySbBak"], SELF["mySbSld"]
  self.frmI = self.bakI = self.sldI = None
  self.sldX = self.sldY = self.sldW = self.sldH = 0
  for obj in (self.frm, self.bak, self.sld): obj.hide()
 def VVRQF4(self, x, y, w, h, bW=1, frmColor="#11aaaaaa", bakColor="#11003344", sldColor="#11ff8000"):
  x, y, w, h = int(x), int(y), int(w), int(h)
  FF0e9t(self.frm, frmColor)
  FF0e9t(self.bak, bakColor)
  FF0e9t(self.sld, sldColor)
  self.frmI, self.bakI, self.sldI = self.frm.instance, self.bak.instance, self.sld.instance
  self.frmI.move(ePoint(x, y))
  self.frmI.resize(eSize(w, h))
  self.bakI.move(ePoint(x + bW, y + bW))
  self.bakI.resize(eSize(w - bW * 2, h - bW * 2))
  self.sldX = x + bW
  self.sldY = y + bW
  self.sldW = w - bW * 2
  self.sldH = h - bW * 2
  self.sldI.move(ePoint(self.sldX, self.sldY))
  self.sldI.resize(eSize(self.sldW, self.sldH))
 def VVObmC(self, val, maxN):
  if maxN < 2:
   for obj in (self.frm, self.bak, self.sld): obj.hide()
  else:
   for obj in (self.frm, self.bak, self.sld): obj.show()
   visH = max(self.sldH / maxN, self.sldH * 0.05)
   self.sldI.resize(eSize(self.sldW, int(visH)))
   y = FFfFjr(val, 1, maxN, 0, self.sldH - visH)
   self.sldI.move(ePoint(self.sldX, int(self.sldY + y)))
class CCvFiA(CCLp6y):
 def __init__(self, rows, cols, colorCfg):
  self.TOTAL_ROWS   = rows
  self.TOTAL_COLS   = cols
  self.PAGE_ITEMS   = self.TOTAL_ROWS * self.TOTAL_COLS
  self.colorCfg   = colorCfg
  self.totalItems   = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.isBusy    = False
  CCLp6y.__init__(self, self)
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "up" : self.VVEmui   ,
   "down" : self.VV6joq  ,
   "left" : self.VVWsG2  ,
   "right" : self.VVYgav  ,
   "next" : self.VVSVHh ,
   "last" : self.VVL78B
  }, -1)
 def VVttYm(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
    self["myPosterLbl%d%d" % (row, col)].instance.setNoWrap(True)
  gap = int(self.skinParam["marginLeft"] / 1)
  topBox = self["myPosterPic%d%d" % (0, 0)].instance
  botBox = self["myPosterPic%d%d" % (self.TOTAL_ROWS - 1, self.TOTAL_COLS - 1)].instance
  w = 20
  y = topBox.position().y() - int(self.skinParam["marginTop"] / 2) + 2
  h = self.skinParam["height"] - self.skinParam["barHeight"] - y - 2
  x = self.skinParam["width"] - w - 2
  self.VVRQF4(x, y, w, h)
  self.VVVxnR()
 def VVICVL(self):
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > self.totalItems: f1 = self.totalItems
  if f2 > self.totalItems: f2 = self.totalItems
  return f1, f2
 def VVEmui(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VV0nhZ()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVvQCK()
 def VV6joq(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV9nLv()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVvQCK()
 def VVWsG2(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VV0nhZ()
  else:
   self.curCol -= 1
   self.VVvQCK()
 def VVYgav(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV9nLv()
  else:
   self.curCol += 1
   self.VVvQCK()
 def VVL78B(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVvQCK(True)
 def VVSVHh(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVvQCK(True)
 def VV9nLv(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVvQCK(True)
 def VV0nhZ(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVvQCK(True)
 def VVvQCK(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVyAaL = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVyAaL: self.curPage = VVyAaL
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  self.VVWVfW()
  self.VVObmC(self.curPage + 1, self.totalPages)
  FFWlvR(BF(self.VVlVmY, force or not oldPage == self.curPage, VVyAaL))
 def VVlVmY(self, force, VVyAaL):
  if force:
   self.VV8Fuf()
  if self.curPage == VVyAaL:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  self.curIndex = self.curPage * self.PAGE_ITEMS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVWVfW()
  boxT, boxW, boxH = self.skinParam["extraPar"]
  self["myPiconPtr"].instance.move(ePoint(int(boxW * self.curCol), int(boxT + boxH * self.curRow)))
  self["myPiconPtr"].show()
 def VV3mEF(self, ndx):
  if ndx > -1 and ndx < self.totalItems:
   self.curPage = int(ndx / self.PAGE_ITEMS)
   firstInPage  = self.curPage * self.PAGE_ITEMS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVvQCK(True)
  else:
   FF1ojr(self, "Not found", 1000)
 def VVKlVX(self):
  self.VV3mEF(self.totalItems - 1 if self.curIndex == 0 else 0)
 def VVYWW6(self):
  self["myPiconPtr"].hide()
 def VVaWjm(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)].hide()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
 def VV8tE4(self):
  fg = bg = self.colorCfg.getValue()
  self.session.openWithCallback(self.VV8pJx, CCN1iw, defFG=fg, defBG=bg, onlyBG=True)
 def VV8pJx(self, fg, bg):
  if bg:
   FFxMsu(self.colorCfg, bg)
   self.VVVxnR()
 def VVVxnR(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FF0e9t(self["myPosterRep%d%d" % (row, col)], self.colorCfg.getValue())
class CC5dSb(Screen, CCvFiA):
 def __init__(self, session, VVXOwS, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FFXh6Y(VVDpax, 1870, 1030, 50, 10, 10, "#33000000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "Server Browser"
  self.VVXOwS  = VVXOwS
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.VV6fdw    = []
  self.totPosterUrls  = 0
  self.totalItems   = 0
  FFwLhV(self, self.Title)
  CCvFiA.__init__(self, 2, 6, CFG.transpColorPosters)
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VVCkxr, subPath)
  if not pathExists(self.pPath):
   os.system(FFQe93("mkdir -p '%s'" % (self.pPath)))
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myAction"].actions.update(
  {
   "ok" : self.VVi1M6    ,
   "cancel": self.close    ,
   "menu" : self.VVRuqh ,
   "info" : self.VV3O7M  ,
   "0"  : self.VVKlVX
  })
  self.onShown.append(self.VVfcAc)
  self.onClose.append(self.onExit)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FF8TfI(self)
  FFvDt2(self)
  self["myPiconInf0"].instance.setNoWrap(True)
  self["myPiconInf1"].instance.setNoWrap(True)
  self.VVttYm()
  self.VV2fPf()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVRuqh(self):
  chName, subj, desc, fName, picUrl = self.VV6fdw[self.curIndex]
  VVW1xb = []
  txt1 = "Show Selected Picture"
  txt2 = "Copy Selected Picture to Export-Directory"
  txt3 = "Set Selected Picture as a Poster for a Local Media"
  if fName:
   VVW1xb.append((txt1, "VVICFs"   ))
   VVW1xb.append((txt2, "VV22YM"  ))
   VVW1xb.append((txt3, "VV87HK" ))
  else:
   VVW1xb.append((txt1, ))
   VVW1xb.append((txt2, ))
   VVW1xb.append((txt3, ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Cache details"       , "VVl4mI"  ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Change Poster/Picon Transparency Color" , "VV8tE4" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Help (Keys)"        , "help"     ))
  FFLFXy(self, self.VVn7v0, title=self.Title, VVW1xb=VVW1xb)
 def VVn7v0(self, item=None):
  if item is not None:
   if   item == "VVICFs"   : self.VVICFs()
   elif item == "VV22YM"   : self.VV22YM()
   elif item == "VV87HK"  : self.VV87HK()
   elif item == "VVl4mI"  : FF7Xva(self, self.VVl4mI, title="Calculating ...")
   elif item == "VV8tE4": self.VV8tE4()
   elif item == "help"     : FFsiZl(self, "_help_servBr", "Server Browser (Keys)")
 def VVi1M6(self):
  self.VVXOwS.VV9fSx(self.curIndex)
  self.VVXOwS.VV37JC()
 def VV3O7M(self):
  self.VVXOwS.VV9fSx(self.curIndex)
  self.VVXOwS.VVjb2M()
 def VV2fPf(self):
  for colList in self.VVXOwS.VVWsuW():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = os.path.basename(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VV6fdw.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalItems = len(self.VV6fdw)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  ndx = self.VVXOwS.VVRJth()
  self.curPage = int(ndx / self.PAGE_ITEMS)
  ndx     -= self.curPage * self.PAGE_ITEMS
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VVvQCK(True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVr48v)
  except:
   self.timer.callback.append(self.VVr48v)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VVLzuw)
  self.myThread.start()
 def VVLzuw(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VV6fdw):
    if not self.stopThread:
     if picUrl and not fName:
      fName = os.path.basename(picUrl)
      path, err = FFjmFi(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       os.system(FFQe93("mv -f '%s' '%s'" % (path, self.pPath + fName)))
       self.VV6fdw[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VVr48v(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VVAgOb + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalItems
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VV6fdw[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VV6fdw[ndx] = (chName, subj, desc, fName, "")
     try:
      CCoeUI.VVAmtb(self["myPosterPic%d%d" % (row, col)], path)
     except:
      pass
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VV8Fuf(self):
  self.VVaWjm()
  f1, f2 = self.VVICVL()
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VV6fdw[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.setText(chName)
   lbl.show()
   pic.show()
   path = ""
   if fName:
    path = self.pPath + fName
   if not fileExists(path):
    path = VV9dcF + "iptv.png"
   try:
    CCoeUI.VVAmtb(pic, path)
    pic.show()
   except:
    pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVWVfW(self):
  chName, subj, desc, fName, picUrl = self.VV6fdw[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVICFs(self):
  chName, subj, desc, fName, picUrl = self.VV6fdw[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CCFA9F.VVK9Qe(self, self.pPath + fName)
  else          : FF1ojr(self, "File not found", 1500)
 def VV22YM(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VV6fdw[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   res = os.system(FFQe93("cp -f '%s' '%s'" % (self.pPath + fName, dstF)))
   if res == 0 : FF5nWa(self, "File copied to:\n\n%s" % dstF, title=title)
   else  : FFa349(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FFa349(self, "No Poster/PIcon found", title=title)
 def VV87HK(self):
  self.session.openWithCallback(self.VVUqae, BF(CCbI7Z, patternMode="movies", VVetf7=CFG.MovieDownloadPath.getValue()))
 def VVUqae(self, path):
  if path:
   title = "Set Selected Picture as a Poster for a Local Media"
   chName, subj, desc, fName, picUrl = self.VV6fdw[self.curIndex]
   if fName:
    srcF = self.pPath + fName
    dstF = "%s%s" % (os.path.splitext(path)[0], os.path.splitext(srcF)[1])
    res = os.system(FFQe93("cp -f '%s' '%s'" % (srcF, dstF)))
    if res == 0 : FF5nWa(self, "File copied to:\n\n%s" % dstF, title=title)
    else  : FFa349(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstF), title=title)
    CCoeUI.VVysQH(dstF)
   else:
    FFa349(self, "No Poster/PIcon found", title=title)
 def VVl4mI(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VVCkxr, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FFyJfo("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CCbI7Z.VVr8MR(size)
   txt += "%s\n    %s\n\n" % (FFY7FT(path, VVJ2KG), size)
  mainPath = "%sPosters" % VVCkxr
  totFiles = FFyJfo("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FFmJCK(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FFY7FT("Total space used by Posters/PIcons%s:" % totFTxt, VVzCWu), CCbI7Z.VVr8MR(totSize))
  mountPath = CCbI7Z.VVPH4O(mainPath)
  if pathExists(mountPath):
   totSize  = CCbI7Z.VVznyV(mountPath)
   freeSize = CCbI7Z.VVREmO(mountPath)
   usedSize = CCbI7Z.VVr8MR(totSize - freeSize)
   totSize  = CCbI7Z.VVr8MR(totSize)
   freeSize = CCbI7Z.VVr8MR(freeSize)
   txt += "%s\n" % VVI8D8
   txt += FFY7FT("Media Space:\n", VVPpUd)
   txt += "    Media Path\t: %s\n" % FFY7FT(mountPath, VVW6qu)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FFyv2f(self, txt, title="Cache Used Size", height=1000)
class CCoeUI(Screen, CCvFiA):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFXh6Y(VVDpax, 1870, 1030, 50, 10, 10, "#33440000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = title
  self.VV6fdw    = lst
  FFwLhV(self, self.Title)
  CCvFiA.__init__(self, 2, 6, CFG.transpColorMovies)
  self["myAction"].actions.update(
  {
   "ok" : self.VVi1M6    ,
   "cancel": self.close    ,
   "menu" : self.VVQtM7 ,
   "info" : self.VVcNdz  ,
   "0"  : self.VVKlVX
  })
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FF8TfI(self)
  FFvDt2(self)
  self["myPiconInf0"].instance.setNoWrap(True)
  self["myPiconInf1"].instance.setNoWrap(True)
  self.VVttYm()
  self.totalItems = len(self.VV6fdw)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVvQCK(True)
 def VV8Fuf(self):
  self.VVaWjm()
  f1, f2 = self.VVICVL()
  mPath = CFG.MovieDownloadPath.getValue()
  row = col = 0
  for ndx in range(f1, f2):
   path, movie, poster = self.VV6fdw[ndx]
   path = os.path.join(mPath, path)
   path = os.path.join(path, movie)
   if poster: poster = os.path.join(os.path.dirname(path), poster)
   else  : poster = VV9dcF + "noPos.png"
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.setText(os.path.splitext(os.path.basename(path))[0])
   lbl.show()
   pic.show()
   try:
    self.VVAmtb(pic, poster)
   except:
    pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVYCzq(self):
  path, movie, poster = self.VV6fdw[self.curIndex]
  path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
  path = os.path.join(path, movie)
  if poster:
   poster = os.path.join(os.path.dirname(path), poster)
  return path, poster
 def VVWVfW(self):
  path, poster = self.VVYCzq()
  self["myPiconInf0"].setText("  " + os.path.splitext(os.path.basename(path))[0] + "  ")
  self["myPiconInf1"].setText("   " + os.path.dirname(path) + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVQtM7(self):
  path, poster = self.VVYCzq()
  VVW1xb = []
  VVW1xb.append(("Go to movie ...", "VVR0x5"))
  VVW1xb.append(VVswUs)
  txt1 = "Show Poster"
  txt2 = "Copy Poster to Export-Directory"
  if poster:
   VVW1xb.append((txt1, "VVICFs" ))
   VVW1xb.append((txt2, "VV22YM"))
  else:
   VVW1xb.append((txt1, ))
   VVW1xb.append((txt2, ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Change Poster/Picon Transparency Color"  , "VV8tE4" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Change Poster (from current movie path) ..." , "VVRRnf1"  ))
  VVW1xb.append(("Change Poster (locate manually) ..."   , "VVRRnf2"  ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Help (Keys)"         , "help"     ))
  FFLFXy(self, self.VVhFoK, title=self.Title, VVW1xb=VVW1xb)
 def VVhFoK(self, item=None):
  if item is not None:
   if   item == "VVR0x5"    : self.VVR0x5()
   elif item == "VV22YM"    : self.VV22YM()
   elif item == "VVICFs"    : self.VVICFs()
   elif item == "VV8tE4" : self.VV8tE4()
   elif item == "VVRRnf1"  : self.VVRRnf()
   elif item == "VVRRnf2"  : self.VVRRnf(True)
   elif item == "help"      : FFsiZl(self, "_help_movBr", "Movies Browser (Keys)")
 def VVR0x5(self):
  VVuV68 = []
  for ndx, item in enumerate(self.VV6fdw):
   path, movie, poster = item
   path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
   VVuV68.append((os.path.splitext(movie)[0], path, str(ndx)))
  VVuV68.sort(key=lambda x: x[0].lower())
  VVVi12 = ("Select" , self.VVQTcB, [])
  header  = ("Name" , "Path", "NDX.")
  widths  = (60  , 40 , 0  )
  FFEM8S(self, None, title="Select Movie", width=1800, height=1000, header=header, VV6fdw=VVuV68, VVHqY6=widths, VVJmZ8=26, VVVi12=VVVi12, lastFindConfigObj=CFG.lastFindMovie)
 def VVQTcB(self, VVXOwS, title, txt, colList):
  self.VV3mEF(int(colList[2].strip()))
  VVXOwS.cancel()
 def VVi1M6(self):
  path, poster = self.VVYCzq()
  FF7Xva(self, BF(CCbI7Z.VV7vnp, self, path), title="Playing Media ...")
 def VVcNdz(self):
  path, poster = self.VVYCzq()
  txt = "%s:\n%s\n\n" % (FFY7FT("Path", VVJ2KG), path)
  size = FFPYZx(path)
  if size > -1:
   txt += "%s:\n%s\n\n" % (FFY7FT("File Size", VVJ2KG), CCbI7Z.VVr8MR(size))
  if poster:
   txt += "%s:\n%s" % (FFY7FT("Poster", VVJ2KG), poster)
  FFyv2f(self, txt, title="Media File Information")
 def VVICFs(self):
  path, poster = self.VVYCzq()
  if fileExists(poster): CCFA9F.VVK9Qe(self, poster)
  else     : FF1ojr(self, "No Poster", 1500)
 def VV22YM(self):
  title = "Copy Poster"
  path, poster = self.VVYCzq()
  if poster:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = os.path.join(dstPath, os.path.basename(poster))
   res = os.system(FFQe93("cp -f '%s' '%s'" % (poster, dstF)))
   if res == 0 : FF5nWa(self, "File copied to:\n\n%s" % dstF, title=title)
   else  : FFa349(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (poster, dstPath), title=title)
  else:
   FF1ojr(self, "No Poster", 1500)
 def VVRRnf(self, isManual=False):
  path, poster = self.VVYCzq()
  sDir = FFnWu0(os.path.dirname(path))
  if isManual:
   self.session.openWithCallback(BF(self.VVXtTo, sDir, path), BF(CCbI7Z, patternMode="poster", VVetf7=sDir))
  else:
   VVW1xb = []
   for item in [f for f in os.listdir(sDir) if iSearch(r"^.*\.(jpg|png)", f, IGNORECASE)]:
    VVW1xb.append((os.path.basename(item), sDir + item))
   if VVW1xb:
    VVW1xb.sort(key=lambda x: x[0].lower())
    infoBtnFnc = self.VVPanX
    FFLFXy(self, BF(self.VVXtTo, sDir, path), VVW1xb=VVW1xb, title="Posters", infoBtnFnc=infoBtnFnc, yellowBasePath=sDir)
   else:
    FF1ojr(self, "No jpg/png in current dir", 1500)
 def VVPanX(self, menuInstance, txt, ref, ndx):
  CCFA9F.VVK9Qe(self, VVUlwB=ref)
 def VVXtTo(self, sDir, path, pPath=None):
  if pPath:
   newPath = sDir + os.path.splitext(os.path.basename(path))[0] + os.path.splitext(pPath)[1].lower()
   res = os.system(FFQe93("cp -f '%s' '%s'" % (pPath, newPath)))
   if res == 0 or pPath == newPath:
    self.VV6fdw[self.curIndex] = (self.VV6fdw[self.curIndex][0], self.VV6fdw[self.curIndex][1], os.path.basename(newPath))
    FF7Xva(self, self.VV8Fuf)
    CCoeUI.VVysQH(newPath)
   else:
    FF1ojr(self, "Cannot copy file", 1000)
 @staticmethod
 def VVysQH(path):
  if path.endswith(".png"):
   fileNoExt = path[:-4]
   jpgF = fileNoExt + ".jpg"
   if fileExists(jpgF):
    c = 1
    newF = "%s_%d.jpg" % (fileNoExt, c)
    while fileExists(newF):
     c += 1
     newF = "%s_%d.jpg" % (fileNoExt, c)
    os.system(FFQe93("mv -f '%s' '%s'" % (jpgF, newF)))
 @staticmethod
 def VVAmtb(pixObj, path):
  if path.endswith(".png"):
   pixObj.instance.setPixmapFromFile(path)
  else:
   png = LoadPixmap(path)
   pixObj.instance.setScale(1)
   pixObj.instance.setPixmap(png)
 @staticmethod
 def VVZAbM(SELF):
  eLst = CCDiIK.VVGjn5()["mov"]
  mPath = CFG.MovieDownloadPath.getValue()
  lst = []
  for (Dir, dirs, files) in os.walk(mPath):
   for f in files:
    if os.path.splitext(f)[1].lstrip(".").lower() in eLst:
     path = os.path.join(Dir, f)
     poster = ""
     for ext in ("jpg", "png"):
      pic = "%s.%s" % (os.path.splitext(path)[0], ext)
      if fileExists(pic):
       poster = os.path.basename(pic)
       break
     lst.append((os.path.dirname(path).replace(mPath, ""), os.path.basename(path), poster))
  title = "Movies Browser"
  lst.sort(key=lambda x: x[1].lower())
  if lst: SELF.session.open(CCoeUI, title, lst)
  else  : FFa349(SELF, "No movies found in:\n\n%s\n\nYou can change the path from settings." % mPath, title=title)
class CCMX60(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFXh6Y(VV2F6v, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVlvjj  = 0
  self.VVujo9 = 1
  self.VVX2jJ  = 2
  VVW1xb = []
  VVW1xb.append(("Find in All Service (from filter)" , "VVNUkn" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Find in All (Manual Entry)"   , "VVc4Ml"    ))
  VVW1xb.append(("Find in TV"       , "VVHNH2"    ))
  VVW1xb.append(("Find in Radio"      , "VVM0kX"   ))
  if self.VVHsyA():
   VVW1xb.append(VVswUs)
   VVW1xb.append(("Hide Channel: %s" % self.servName , "VV2JMW"   ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Zap History"       , "VVpoF8"    ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("IPTV Tools"       , "iptv"      ))
  VVW1xb.append(("PIcons Tools"       , "PIconsTools"     ))
  VVW1xb.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  VVW1xb.append(("EPG Tools"       , "epgTools"     ))
  FFwLhV(self, VVW1xb=VVW1xb, title=title)
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FFKauM(self["myMenu"])
  FFVUwm(self)
  if self.isFindMode:
   self.VVoKPc(self.VVh15H())
 def VVi1M6(self):
  global VVdxhd
  VVdxhd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVc4Ml"    : self.VVc4Ml()
   elif item == "VVNUkn" : self.VVNUkn()
   elif item == "VVHNH2"    : self.VVHNH2()
   elif item == "VVM0kX"   : self.VVM0kX()
   elif item == "VV2JMW"   : self.VV2JMW()
   elif item == "VVpoF8"    : self.VVpoF8()
   elif item == "iptv"       : self.session.open(CCgg3d)
   elif item == "PIconsTools"     : self.session.open(CCMxom)
   elif item == "ChannelsTools"    : self.session.open(CCyEBX)
   elif item == "epgTools"      : self.session.open(CCos4Q)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVHNH2(self) : self.VVoKPc(self.VVlvjj)
 def VVM0kX(self) : self.VVoKPc(self.VVujo9)
 def VVc4Ml(self) : self.VVoKPc(self.VVX2jJ)
 def VVoKPc(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFsShb(self, BF(self.VVMrkW, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VVNUkn(self):
  filterObj = CCuF2O(self)
  filterObj.VVpFrx(self.VVcB2Q)
 def VVcB2Q(self, item):
  self.VVMrkW(self.VVX2jJ, item)
 def VVHsyA(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFDOE0(self.refCode)        : return False
  return True
 def VVMrkW(self, mode, VV1F2L):
  FF7Xva(self, BF(self.VVmC7J, mode, VV1F2L), title="Searching ...")
 def VVmC7J(self, mode, VV1F2L):
  if VV1F2L:
   VV1F2L = VV1F2L.strip()
  if VV1F2L:
   self.findTxt = VV1F2L
   CFG.lastFindContextFind.setValue(VV1F2L)
   if   mode == self.VVlvjj  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVujo9 : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VV1F2L)
   if len(title) > 55:
    title = title[:55] + ".."
   VVuV68 = self.VVDQQ2(VV1F2L, servTypes)
   if self.isFindMode or mode == self.VVX2jJ:
    VVuV68 += self.VVKDRp(VV1F2L)
   if VVuV68:
    VVuV68.sort(key=lambda x: x[0].lower())
    VV6iCg = self.VVg99z
    VVVi12  = ("Zap"   , self.VVaju1    , [])
    VVsTsL = ("Current Service", self.VVR92j , [])
    VVQR2V = ("Options"  , self.VVudvR , [])
    VVd4CR = (""    , self.VVkFfy , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVI7B0  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFEM8S(self, None, title=title, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26, VVVi12=VVVi12, VV6iCg=VV6iCg, VVsTsL=VVsTsL, VVQR2V=VVQR2V, VVd4CR=VVd4CR, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVoKPc(self.VVh15H())
    FF5nWa(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVDQQ2(self, VV1F2L, servTypes):
  VV6fdw = CCyEBX.VVKpWw(servTypes)
  VVuV68 = []
  if VV6fdw:
   VVwf7y, VV8J1C = FFsOE4()
   tp = CCEpHi()
   words, asPrefix = CCuF2O.VVUxc8(VV1F2L)
   colorYellow  = CCkvru.VVnWwa(VVzCWu)
   colorWhite  = CCkvru.VVnWwa(VV0Duj)
   for s in VV6fdw:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFP3va(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVwf7y:
        STYPE = VV8J1C[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVtkIs(refCode)
       if not "-S" in syst:
        sat = syst
       VVuV68.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVuV68
 def VVKDRp(self, VV1F2L):
  VV1F2L = VV1F2L.lower()
  VVuV68 = []
  colorYellow  = CCkvru.VVnWwa(VVzCWu)
  colorWhite  = CCkvru.VVnWwa(VV0Duj)
  for b in CCRtNz.VVy9TS():
   VVgTOR  = b[0]
   VVvl14  = b[1].toString()
   VVlP6s = eServiceReference(VVvl14)
   VVDmhR = FFqMsP(VVlP6s)
   for service in VVDmhR:
    refCode  = service[0]
    if FFDOE0(refCode):
     servName = service[1]
     if VV1F2L in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VV1F2L), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVuV68.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVuV68
 def VVh15H(self):
  VVPWYL = InfoBar.instance
  if VVPWYL:
   VVEmtn = VVPWYL.servicelist
   if VVEmtn:
    return VVEmtn.mode == 1
  return self.VVX2jJ
 def VVg99z(self, VVXOwS):
  self.close()
  VVXOwS.cancel()
 def VVaju1(self, VVXOwS, title, txt, colList):
  FFqi6V(VVXOwS, colList[2], VVEPKV=False, checkParentalControl=True)
 def VVR92j(self, VVXOwS, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(VVXOwS)
  if refCode:
   VVXOwS.VV71dE(2, FFxv8F(refCode, iptvRef, chName), True)
 def VVudvR(self, VVXOwS, title, txt, colList):
  servName = colList[0]
  mSel = CCTHuN(self, VVXOwS)
  VVW1xb, cbFncDict = CCyEBX.VV6MvZ(self, VVXOwS, servName, 2)
  mSel.VVoxj8(VVW1xb, cbFncDict)
 def VVkFfy(self, VVXOwS, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFr9gS(self, fncMode=CCsydO.VVRwEk, refCode=refCode, chName=chName, text=txt)
 def VV2JMW(self):
  FF8XzP(self, self.VV13FI, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VV13FI(self):
  ret = FFV9Z7(self.refCode, True)
  if ret:
   self.VVJaFo()
   self.close()
  else:
   FF1ojr(self, "Cannot change state" , 1000)
 def VVJaFo(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VV5CgH()
  except:
   self.VV5dAr()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFzHPJ(self, serviceRef)
 def VV5CgH(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVPWYL = InfoBar.instance
   if VVPWYL:
    VVEmtn = VVPWYL.servicelist
    if VVEmtn:
     hList = VVEmtn.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVEmtn.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVEmtn.history  = newList
       VVEmtn.history_pos = pos
 def VV5dAr(self):
  VVPWYL = InfoBar.instance
  if VVPWYL:
   VVEmtn = VVPWYL.servicelist
   if VVEmtn:
    VVEmtn.history  = []
    VVEmtn.history_pos = 0
 def VVpoF8(self):
  VVPWYL = InfoBar.instance
  VVuV68 = []
  if VVPWYL:
   VVEmtn = VVPWYL.servicelist
   if VVEmtn:
    VVwf7y, VV8J1C = FFsOE4()
    for serv in VVEmtn.history:
     refCode = serv[-1].toString()
     chName = FFIKk3(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FFDOE0(refCode)
     isSRel = FFTxso(refCode)
     sat = "-" if isIptv and not isSRel or isLocal else FFP3va(refCode, True)
     if isIptv : STYPE = "Stream Relay" if isSRel else "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVwf7y:
       STYPE = VV8J1C[sTypeInt]
     VVuV68.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVuV68:
   VVVi12  = ("Zap"   , self.VVKPYo   , [])
   VVQR2V = ("Clear History" , self.VVlhvq   , [])
   VVd4CR = (""    , self.VVLH5M , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVI7B0  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFEM8S(self, None, title=title, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=28, VVVi12=VVVi12, VVQR2V=VVQR2V, VVd4CR=VVd4CR)
  else:
   FF5nWa(self, "Not found", title=title)
 def VVKPYo(self, VVXOwS, title, txt, colList):
  FFqi6V(VVXOwS, colList[3], VVEPKV=False, checkParentalControl=True)
 def VVlhvq(self, VVXOwS, title, txt, colList):
  FF8XzP(self, BF(self.VVRzUo, VVXOwS), "Clear Zap History ?")
 def VVRzUo(self, VVXOwS):
  self.VV5dAr()
  VVXOwS.cancel()
 def VVLH5M(self, VVXOwS, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFr9gS(self, fncMode=CCsydO.VV5FUA, refCode=refCode, chName=chName, text=txt)
class CCMxom(Screen, CCvFiA):
 VVX7mZ   = 0
 VV59WD  = 1
 VV7Y2b  = 2
 VVuti0  = 3
 VVwE5D  = 4
 VVlDM0  = 5
 VVveqk  = 6
 VV2Vcv  = 7
 VVzLEO = 8
 VVe16R = 9
 VV2hdT = 10
 VVcmph = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFXh6Y(VVNy0r, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "PIcons Tools"
  self.pPath    = CCMxom.VVVqXw()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VV6fdw    = []
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  FFwLhV(self, self.Title)
  FFxDER(self["keyRed"] , "OK = Zap")
  FFxDER(self["keyGreen"] , "Current Service")
  FFxDER(self["keyYellow"], "Page Options")
  FFxDER(self["keyBlue"] , "Filter")
  CCvFiA.__init__(self, 5, 7, CFG.transpColorPicons)
  self["myAction"].actions.update(
  {
   "ok"  : self.VVWA6B     ,
   "green"  : self.VVXomH    ,
   "yellow" : self.VVRF47     ,
   "blue"  : self.VVCIwa     ,
   "menu"  : self.VV7VsJ     ,
   "info"  : self.VV6rKa    ,
   "pageUp" : BF(self.VVloBY, True) ,
   "chanUp" : BF(self.VVloBY, True) ,
   "pageDown" : BF(self.VVloBY, False) ,
   "chanDown" : BF(self.VVloBY, False) ,
   "0"   : self.VVKlVX  ,
   "cancel" : self.close
  })
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FF8TfI(self)
  FFvDt2(self)
  FF0e9t(self["keyRed"], "#0a333333")
  self.VVttYm()
  self.VVYWW6()
  FF7Xva(self, BF(self.VVAgjO, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VV7VsJ(self):
  if not self.isBusy:
   VVW1xb = []
   VVW1xb.append(("Statistics"           , "VVYEKw"    ))
   VVW1xb.append(VVswUs)
   VVW1xb.append(("Suggest PIcons for Current Channel"     , "VVFWCN"   ))
   VVW1xb.append(("Set to Current Channel (copy file)"     , "VVmOXm_file"  ))
   VVW1xb.append(("Set to Current Channel (as SymLink)"     , "VVmOXm_link"  ))
   VVW1xb.append(VVswUs)
   VVW1xb.append(("Export Current File Names List"      , "VVveFn" ))
   VVW1xb.append(CCMxom.VV06vI())
   VVW1xb.append(VVswUs)
   movTxt = "Move Unused PIcons to a Directory"
   delTxt = "DELETE Unused PIcons"
   if self.filterTitle == "PIcons without Channels":
    c = VV6yYu
    VVW1xb.append((c + movTxt           , "VVqw6I"  ))
    VVW1xb.append((c + delTxt           , "VVcqYU" ))
   else:
    disTxt = " (Filter >> Unused PIcons)"
    VVW1xb.append((movTxt + disTxt         ,       ))
    VVW1xb.append((delTxt + disTxt         ,       ))
   VVW1xb.append(VVswUs)
   VVW1xb.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVuujk"  ))
   VVW1xb.append(VVswUs)
   VVW1xb += CCMxom.VVIGZ4()
   VVW1xb.append(VVswUs)
   VVW1xb.append(("Change Poster/Picon Transparency Color"    , "VV8tE4" ))
   VVW1xb.append(("Keys Help"           , "VVmAiU"    ))
   FFLFXy(self, self.VVZKlw, width=1100, height=1050, title=self.Title, VVW1xb=VVW1xb)
 def VVZKlw(self, item=None):
  if item is not None:
   if   item == "VVYEKw"    : self.VVYEKw()
   elif item == "VVFWCN"   : self.VVFWCN()
   elif item == "VVmOXm_file"  : self.VVmOXm(0)
   elif item == "VVmOXm_link"  : self.VVmOXm(1)
   elif item == "VVveFn"  : self.VVveFn()
   elif item == "VVbEG8"  : CCMxom.VVbEG8(self)
   elif item == "VVqw6I"   : self.VVqw6I()
   elif item == "VVcqYU"  : self.VVcqYU()
   elif item == "VVuujk"  : self.VVuujk()
   elif item == "VVmc5P"  : CCMxom.VVmc5P(self)
   elif item == "findPiconBrokenSymLinks" : CCMxom.VVvuHC(self, True)
   elif item == "FindAllBrokenSymLinks" : CCMxom.VVvuHC(self, False)
   elif item == "VV8tE4" : self.VV8tE4()
   elif item == "VVmAiU"     : FFsiZl(self, "_help_picons", "PIcons Tools (Keys Help)")
 def VVRF47(self):
  if not self.isBusy:
   VVW1xb = []
   VVW1xb.append(("Go to First PIcon"  , "VV9nLv"  ))
   VVW1xb.append(("Go to Last PIcon"   , "VV0nhZ"  ))
   VVW1xb.append(VVswUs)
   VVW1xb.append(("Sort by Channel Name"     , "sortByChan" ))
   VVW1xb.append(("Sort by File Name"  , "sortByFile" ))
   VVW1xb.append(VVswUs)
   VVW1xb.append(("Find from File List .." , "VVfdJg" ))
   FFLFXy(self, self.VVHNWA, title=self.Title, VVW1xb=VVW1xb)
 def VVHNWA(self, item=None):
  if item is not None:
   if   item == "VV9nLv"   : self.VV9nLv()
   elif item == "VV0nhZ"   : self.VV0nhZ()
   elif item == "sortByChan"  : self.VVrrPO(2)
   elif item == "sortByFile"  : self.VVrrPO(0)
   elif item == "VVfdJg"  : self.VVfdJg()
 def VVfdJg(self):
  VVW1xb = []
  for item in self.VV6fdw:
   VVW1xb.append((item[0], item[0]))
  FFLFXy(self, self.VVwHNH, title='PIcons ".png" Files', VVW1xb=VVW1xb, VVxhca=True)
 def VVwHNH(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VV3mEF(ndx)
 def VVWA6B(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VV9jjD()
   if refCode:
    FFqi6V(self, refCode)
    self.VV7Nt4()
    self.VVWVfW()
 def VVloBY(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VV7Nt4()
   self.VVWVfW()
  except:
   pass
 def VVXomH(self):
  if self["keyGreen"].getVisible():
   self.VV3mEF(self.curChanIndex)
 def VVrrPO(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FF7Xva(self, BF(self.VVAgjO, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVmOXm(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VV9jjD()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVW1xb = []
     VVW1xb.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVW1xb.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFLFXy(self, BF(self.VVy1dC, mode, curChF, selPiconF), VVW1xb=VVW1xb, title="Current Channel PIcon (already exists)")
    else:
     self.VVy1dC(mode, curChF, selPiconF, "overwrite")
   else:
    FFa349(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFa349(self, "Could not read current channel info. !", title=title)
 def VVy1dC(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FF7Xva(self, BF(self.VVAgjO, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVqw6I(self):
  defDir = FFnWu0(CCMxom.VVVqXw() + "picons_backup")
  os.system(FFQe93("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(BF(self.VVWNoL, defDir), BF(CCbI7Z
         , mode=CCbI7Z.VVIet0, VVetf7=CCMxom.VVVqXw()))
 def VVWNoL(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCMxom.VVVqXw():
    FFa349(self, "Cannot move to same directory !", title=title)
   else:
    if not FFnWu0(path) == FFnWu0(defDir):
     self.VVbU3a(defDir)
    FF8XzP(self, BF(FF7Xva, self, BF(self.VVDDv6, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VV6fdw), path), title=title)
  else:
   self.VVbU3a(defDir)
 def VVDDv6(self, title, defDir, toPath):
  if not iMove:
   self.VVbU3a(defDir)
   FFa349(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FFnWu0(toPath)
  pPath = CCMxom.VVVqXw()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VV6fdw:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VV6fdw)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFyv2f(self, txt, title=title, VVMqKH="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVGzIQ("all")
 def VVbU3a(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVcqYU(self):
  title = "Delete Unused PIcons"
  tot = len(self.VV6fdw)
  FF8XzP(self, BF(FF7Xva, self, BF(self.VVrzU3, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FFmJCK(tot)), title=title)
 def VVrzU3(self, title):
  pPath = CCMxom.VVVqXw()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VV6fdw:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VV6fdw)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFY7FT(str(totErr), VV9ZlA)
  FFyv2f(self, txt, title=title)
 def VVuujk(self):
  lines = FF94gP("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FF8XzP(self, BF(self.VVnUPs, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FFmJCK(tot)), VVJRkN=True)
  else:
   FF5nWa(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVnUPs(self, fList):
  os.system(FFQe93("find -L '%s' -type l -delete" % self.pPath))
  FF5nWa(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VV6rKa(self):
  FF7Xva(self, self.VV2eMq)
 def VV2eMq(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VV9jjD()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFY7FT("PIcon Directory:\n", VV5cg1)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FFojdy(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFojdy(path)
   txt += FFY7FT("PIcon File:\n", VV5cg1)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FFY7FT("Found %d SymLink%s to this file from:\n" % (tot, FFmJCK(tot)), VV5cg1)
     for fPath in slLst:
      txt += "  %s\n" % FFY7FT(fPath, VVBh5X)
     txt += "\n"
   if chName:
    txt += FFY7FT("Channel:\n", VV5cg1)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFY7FT(chName, VVlfrr)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FFY7FT("Remarks:\n", VV5cg1)
    txt += "  %s\n" % FFY7FT("Unused", VV9ZlA)
  else:
   txt = "No info found"
  FFr9gS(self, fncMode=CCsydO.VVVuvA, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VV9jjD(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalItems:
   fName, fType, chName, sat, inDB = self.VV6fdw[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFuzCW(sat)
  return fName, refCode, chName, sat, inDB
 def VV7Nt4(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VV6fdw):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVWVfW(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VV9jjD()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalItems)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFY7FT("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VV5cg1))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VV9jjD()[1]))
  if self.curChanIptvRef : typ = "Stream Relay" if FFTxso(self.curChanIptvRef) else "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFY7FT(self.curChanName, VVzCWu)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
  filName, refCode, chName, sat, inDB = self.VV9jjD()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVYEKw(self):
  VVwf7y, VV8J1C = FFsOE4()
  sTypeNameDict = {}
  for key, val in VV8J1C.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VV6fdw:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VV8J1C: sTypeDict[VV8J1C[stNum]] = sTypeDict.get(VV8J1C[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FFyJfo("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVuV68 = []
  c = "#b#11003333#"
  VVuV68.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalItems, totUsedFiles + totUsedLinks)))
  VVuV68.append((c + "Files" , "%d\tUsed = %s" % (self.totalItems - totSymLinks, totUsedFiles)))
  VVuV68.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVuV68.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVuV68.append((c + "Not In Database (lamedb)" , str(self.totalItems - totInDB)))
  VVuV68.append((c + "Satellites"    , str(len(self.nsList))))
  VVuV68.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVuV68.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVuV68.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVuV68.extend(sTypeRows)
  FFEM8S(self, None, title=self.Title, VV6fdw=VVuV68, VVJmZ8=28, VVntre="#00003333", VV3VhT="#00222222")
 def VVveFn(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FFnWu0(CFG.exportedTablesPath.getValue()), txt, FFJCyp())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VV6fdw:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FF5nWa(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVCIwa(self):
  if not self.isBusy:
   VVW1xb = []
   VVW1xb.append(("All"        , "all"  ))
   VVW1xb.append(VVswUs)
   VVW1xb.append(("Used by Channels"     , "used" ))
   VVW1xb.append(("Unused PIcons"     , "unused" ))
   VVW1xb.append(("IPTV PIcons"      , "iptv" ))
   VVW1xb.append(VVswUs)
   VVW1xb.append(("PIcons Files"      , "pFiles" ))
   VVW1xb.append(("SymLinks to PIcons"    , "pLinks" ))
   VVW1xb.append(("PIcons Files Targeted by SymLinks", "pTargets"))
   VVW1xb.append(("By Files Date ..."    , "pDate" ))
   VVW1xb.append(("By Service Type ..."    , "servType"))
   if self.nsList:
    VVW1xb.append(FFzfpO("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFKJmy(val)
      VVW1xb.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCuF2O(self)
   filterObj.VVK44o(VVW1xb, self.nsList, self.VVU8HY)
 def VVU8HY(self, item=None):
  if item is not None:
   self.VVGzIQ(item)
 def VVGzIQ(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVX7mZ   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VV59WD   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VV7Y2b  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVveqk   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVuti0  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVwE5D  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVlDM0  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VV2hdT , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VVcmph , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VV2Vcv   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVzLEO , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVlDM0:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FF94gP("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFmKBR(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FF1ojr(self, "Not found", 1000)
     return
   elif mode == self.VV2hdT:
    self.VVACZg(mode)
    return
   elif mode == self.VVcmph:
    self.VVTh3q(mode)
    return
   elif mode == self.VVe16R:
    return
   else:
    words, asPrefix = CCuF2O.VVUxc8(words)
   if not words and mode in (self.VV2Vcv, self.VVzLEO):
    FF1ojr(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FF7Xva(self, BF(self.VVAgjO, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVACZg(self, mode):
  VVW1xb = []
  VVW1xb.append(("Today"   , "today" ))
  VVW1xb.append(("Since Yesterday" , "yest" ))
  VVW1xb.append(("Since 7 days"  , "week" ))
  FFLFXy(self, BF(self.VVIETJ, mode), VVW1xb=VVW1xb, title="Filter by Added/Modified Date")
 def VVIETJ(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFDLHE(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFDLHE(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFDLHE(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FF7Xva(self, BF(self.VVAgjO, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVTh3q(self, mode):
  VVwf7y, VV8J1C = FFsOE4()
  lst = set()
  for key, val in VV8J1C.items():
   lst.add(val)
  VVW1xb = []
  for item in lst:
   VVW1xb.append((item, item))
  VVW1xb.sort(key=lambda x: x[0])
  FFLFXy(self, BF(self.VV0ufo, mode), VVW1xb=VVW1xb, title="Filter by Service Type")
 def VV0ufo(self, mode, item=None):
  if item:
   VVwf7y, VV8J1C = FFsOE4()
   sTypeList = []
   for key, val in VV8J1C.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FF7Xva(self, BF(self.VVAgjO, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVFWCN(self):
  self.session.open(CCvBnC, barTheme=CCvBnC.VVrdqg
      , titlePrefix = ""
      , fncToRun  = self.VVtkf3
      , VVnRGv = self.VV9jqT)
 def VVtkf3(self, VVhsRS):
  VVs61U, err = CCyEBX.VVCZgt(self, CCyEBX.VVH7VT, VVaGwb=False, VVvSQT=False)
  files = []
  words = []
  if not VVhsRS or VVhsRS.isCancelled:
   return
  VVhsRS.VVLNy3 = []
  VVhsRS.VVBrFN(len(VVs61U))
  if VVs61U:
   VVX1Oz = CCJU0G()
   curCh = VVX1Oz.VVrwsf(self.curChanName)
   for refCode in VVs61U:
    if not VVhsRS or VVhsRS.isCancelled:
     return
    VVhsRS.VVwvD4(1, True)
    chName, sat, inDB = VVs61U.get(refCode, ("", "", 0))
    ratio = CCMxom.VVbItS(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCMxom.VV2znH(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFmKBR(f)
       fil = f.replace(".png", "")
       if not fil in VVhsRS.VVLNy3:
        VVhsRS.VVLNy3.append(fil)
 def VV9jqT(self, VVL4pA, VVLNy3, threadCounter, threadTotal, threadErr):
  if VVLNy3 : FF7Xva(self, BF(self.VVAgjO, mode=self.VVe16R, words=VVLNy3), title="Loading ...")
  else   : FF1ojr(self, "Not found", 2000)
 def VVAgjO(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VVDr3w(isFirstTime):
   return
  self.isBusy = True
  VVvSQT = True if isFirstTime else False
  VVs61U, err = CCyEBX.VVCZgt(self, CCyEBX.VVH7VT, VVaGwb=False, VVvSQT=VVvSQT)
  if err:
   self.close()
  iptvRefList = self.VVkfWU()
  tList = []
  for fName, fType in CCMxom.VVmE5k(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVs61U:
    if fName in VVs61U:
     chName, sat, inDB = VVs61U.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVX7mZ:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VV59WD  and chName         : isAdd = True
   elif mode == self.VV7Y2b and not chName        : isAdd = True
   elif mode == self.VVuti0  and fType == 0        : isAdd = True
   elif mode == self.VVwE5D  and fType == 1        : isAdd = True
   elif mode == self.VVlDM0  and fName in words       : isAdd = True
   elif mode == self.VVe16R and fName in words       : isAdd = True
   elif mode == self.VVveqk  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VV2Vcv  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVzLEO:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VV2hdT:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VVcmph:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VV6fdw   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FF1ojr(self)
  else:
   self.isBusy = False
   FF1ojr(self, "Not found", 1000)
   return
  self.VV6fdw.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VV7Nt4()
  self.totalItems = len(self.VV6fdw)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self.isBusy = False
  self.VVvQCK(True)
 def VVDr3w(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCMxom.VVmE5k(self.pPath):
    if fName:
     return True
   if isFirstTime : FFa349(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FF1ojr(self, "Not found", 1000)
  else:
   FFa349(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVkfWU(self):
  VVuV68 = {}
  files  = CCgg3d.VVROqm()
  if files:
   for path in files:
    txt = FFqXAw(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVuV68[refCode] = item[1]
  return VVuV68
 def VV8Fuf(self):
  self.VVaWjm()
  f1, f2 = self.VVICVL()
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VV6fdw[ndx]
   fName = self.VV6fdw[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFY7FT(chName, VVlfrr))
    else : lbl.setText("-")
   except:
    lbl.setText(FFY7FT(chName, VVHiet))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVbItS(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VV06vI():
  return ("Copy Current Channel PIcon (to PIcons Export Path)", "VVbEG8")
 @staticmethod
 def VVIGZ4():
  VVW1xb = []
  VVW1xb.append(("Find SymLinks (to PIcon Directory)"   , "VVmc5P"  ))
  VVW1xb.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks" ))
  VVW1xb.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks" ))
  return VVW1xb
 @staticmethod
 def VVbEG8(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(SELF)
  png, path = CCMxom.VVscgM(refCode)
  if path : CCMxom.VVPyLa(SELF, png, path)
  else : FFa349(SELF, "No PIcon found for current channel in:\n\n%s" % CCMxom.VVVqXw())
 @staticmethod
 def VVmc5P(SELF):
  if VVzCWu:
   sed1 = FFfLXZ("->", VVzCWu)
   sed2 = FFfLXZ("picon", VV9ZlA)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVHiet, VV0Duj)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFmzjA(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFiZoB(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVvuHC(SELF, isPIcon):
  sed1 = FFfLXZ("->", VVHiet)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFfLXZ("picon", VV9ZlA)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFmzjA(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFiZoB(), grep, sed1, sed2))
 @staticmethod
 def VVmE5k(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVVqXw():
  path = CFG.PIconsPath.getValue()
  return FFnWu0(path)
 @staticmethod
 def VVscgM(refCode, chName=None):
  if FFDOE0(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFTSbj(refCode)
  allPath, fName, refCodeFile, pList = CCMxom.VV2znH(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVPyLa(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFfLXZ("%s%s" % (dest, png), VVlfrr))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFfLXZ(errTxt, VVAgOb))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFYpRN(SELF, cmd)
 @staticmethod
 def VV2znH(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCMxom.VVVqXw()
   pList = []
   lst = FFKZAp(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FFyZAn(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFmKBR(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCcJ7I():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVdlVr  = None
  self.VVjHlY = ""
  self.VVoVKN  = noService
  self.VVOPok = 0
  self.VVm9v9  = noService
  self.VVxM8f = 0
  self.VVtArB  = "-"
  self.VV6j3O = 0
  self.VVdpl0  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VV0qxB(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVdlVr = frontEndStatus
     self.VVi17k()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVi17k(self):
  if self.VVdlVr:
   val = self.VVdlVr.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVjHlY = "%3.02f dB" % (val / 100.0)
   else         : self.VVjHlY = ""
   val = self.VVdlVr.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVOPok = int(val)
   self.VVoVKN  = "%d%%" % val
   val = self.VVdlVr.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVxM8f = int(val)
   self.VVm9v9  = "%d%%" % val
   val = self.VVdlVr.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVtArB  = "%d" % val
   val = int(val * 100 / 500)
   self.VV6j3O = min(500, val)
   val = self.VVdlVr.get("tuner_locked", 0)
   if val == 1 : self.VVdpl0 = "Locked"
   else  : self.VVdpl0 = "Not locked"
 def VVQ8kJ(self)   : return self.VVjHlY
 def VVngy4(self)   : return self.VVoVKN
 def VV1xhw(self)  : return self.VVOPok
 def VVzceX(self)   : return self.VVm9v9
 def VVhZml(self)  : return self.VVxM8f
 def VV8Eq9(self)   : return self.VVtArB
 def VVlwZU(self)  : return self.VV6j3O
 def VV6Fe6(self)   : return self.VVdpl0
 def VVnYId(self) : return self.serviceName
class CCEpHi():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVasrh(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFn1G7(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVvCWg(self.ORPOS  , mod=1   )
      self.sat2  = self.VVvCWg(self.ORPOS  , mod=2   )
      self.freq  = self.VVvCWg(self.FREQ  , mod=3   )
      self.sr   = self.VVvCWg(self.SR   , mod=4   )
      self.inv  = self.VVvCWg(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVvCWg(self.POL  , self.D_POL )
      self.fec  = self.VVvCWg(self.FEC  , self.D_FEC )
      self.syst  = self.VVvCWg(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVvCWg("modulation" , self.D_MOD )
       self.rolof = self.VVvCWg("rolloff"  , self.D_ROLOF )
       self.pil = self.VVvCWg("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVvCWg("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVvCWg("pls_code"  )
       self.iStId = self.VVvCWg("is_id"   )
       self.t2PlId = self.VVvCWg("t2mi_plp_id" )
       self.t2PId = self.VVvCWg("t2mi_pid"  )
 def VVvCWg(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFKJmy(val)
  elif mod == 2   : return FFvD21(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VVg9nN(self, refCode):
  txt = ""
  self.VVasrh(refCode)
  if self.data:
   def VV5vDG(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VV5vDG("System"   , self.syst)
    txt += VV5vDG("Satellite"  , self.sat2)
    txt += VV5vDG("Frequency"  , self.freq)
    txt += VV5vDG("Inversion"  , self.inv)
    txt += VV5vDG("Symbol Rate"  , self.sr)
    txt += VV5vDG("Polarization" , self.pol)
    txt += VV5vDG("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VV5vDG("Modulation" , self.mod)
     txt += VV5vDG("Roll-Off" , self.rolof)
     txt += VV5vDG("Pilot"  , self.pil)
     txt += VV5vDG("Input Stream", self.iStId)
     txt += VV5vDG("T2MI PLP ID" , self.t2PlId)
     txt += VV5vDG("T2MI PID" , self.t2PId)
     txt += VV5vDG("PLS Mode" , self.plsMod)
     txt += VV5vDG("PLS Code" , self.plsCod)
   else:
    txt += VV5vDG("System"   , self.txMedia)
    txt += VV5vDG("Frequency"  , self.freq)
  return txt, self.namespace
 def VVgrTA(self, refCode):
  txt = "Transpoder : ?"
  self.VVasrh(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VVtkIs(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFn1G7(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVvCWg(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVvCWg(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVvCWg(self.SYST, self.D_SYS_S)
     freq = self.VVvCWg(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVvCWg(self.POL , self.D_POL)
      fec = self.VVvCWg(self.FEC , self.D_FEC)
      sr = self.VVvCWg(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVO8kZ(self, refCode):
  self.data = None
  self.VVasrh(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCtuLp():
 def __init__(self, VVuw7F, path, VVnRGv=None, curRowNum=-1):
  self.VVuw7F  = VVuw7F
  self.origFile   = path
  self.Title    = "File Editor: " + FFmKBR(path)
  self.VVnRGv  = VVnRGv
  self.tmpFile   = "/tmp/ajp_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  response = os.system(FFQe93("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVa56o(curRowNum)
  else:
   FFa349(self.VVuw7F, "Error while preparing edit!")
 def VVa56o(self, curRowNum):
  VVuV68 = self.VVwHCw()
  VVsTsL = ("Save Changes" , self.VVxEo4   , [])
  VVVi12  = ("Edit Line"  , self.VVAk1J    , [])
  VVQR2V = ("Go to Line Num" , self.VVoJU9   , [])
  VVmmwr = ("Line Options" , self.VVF0Si   , [])
  VVH2MF = (""    , self.VVY8A7 , [])
  VV6iCg = self.VVbkCc
  VVRzm2  = self.VVBP0K
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVI7B0  = (CENTER  , LEFT  )
  VVXOwS = FFEM8S(self.VVuw7F, None, title=self.Title, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26, VVsTsL=VVsTsL, VVVi12=VVVi12, VVQR2V=VVQR2V, VVmmwr=VVmmwr, VV6iCg=VV6iCg, VVRzm2=VVRzm2, VVH2MF=VVH2MF, VVhmtx=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
    , VVgchu   = "#11001111"
    , VVn4Mh   = "#11001111"
    , VVMqKH   = "#11001111"
    , VVntre  = "#05333333"
    , VV3VhT  = "#00222222"
    , VVwlSC  = "#11331133"
    )
  VVXOwS.VV9fSx(curRowNum)
 def VVoJU9(self, VVXOwS, title, txt, colList):
  totRows = VVXOwS.VV9Wh4()
  lineNum = VVXOwS.VVRJth() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FFsShb(self.VVuw7F, BF(self.VVCfpL, VVXOwS, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VVCfpL(self, VVXOwS, lineNum, totRows, VVsHNL):
  if VVsHNL:
   VVsHNL = VVsHNL.strip()
   if VVsHNL.isdigit():
    num = FFoooc(int(VVsHNL) - 1, 0, totRows)
    VVXOwS.VV9fSx(num)
    self.lastLineNum = num + 1
   else:
    FF1ojr(VVXOwS, "Incorrect number", 1500)
 def VVF0Si(self, VVXOwS, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVXOwS.VVqBOo()
  VVW1xb = []
  VVW1xb.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVW1xb.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVY8Yg"  ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVwd4B:
   VVW1xb.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(  ("Delete Line"         , "deleteLine"   ))
  FFLFXy(self.VVuw7F, BF(self.VVe6PJ, VVXOwS, lineNum), VVW1xb=VVW1xb, title="Line Options")
 def VVe6PJ(self, VVXOwS, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVHhKT("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVXOwS)
   elif item == "VVY8Yg"  : self.VVY8Yg(VVXOwS, lineNum)
   elif item == "copyToClipboard"  : self.VVsFmL(VVXOwS, lineNum)
   elif item == "pasteFromClipboard" : self.VVU6qw(VVXOwS, lineNum)
   elif item == "deleteLine"   : self.VVHhKT("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVXOwS)
 def VVBP0K(self, VVXOwS):
  VVXOwS.VV7RDm()
 def VVY8A7(self, VVXOwS, title, txt, colList):
  if   self.insertMode == 1: VVXOwS.VV3s15()
  elif self.insertMode == 2: VVXOwS.VVhksv()
  self.insertMode = 0
 def VVY8Yg(self, VVXOwS, lineNum):
  if lineNum == VVXOwS.VVqBOo():
   self.insertMode = 1
   self.VVHhKT("echo '' >> '%s'" % self.tmpFile, VVXOwS)
  else:
   self.insertMode = 2
   self.VVHhKT("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVXOwS)
 def VVsFmL(self, VVXOwS, lineNum):
  global VVwd4B
  VVwd4B = FFyJfo("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVXOwS.VVbkCu("Copied to clipboard")
 def VVxEo4(self, VVXOwS, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFQe93("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFQe93("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVXOwS.VVbkCu("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVXOwS.VV7RDm()
    else:
     FFa349(self.VVuw7F, "Cannot save file!")
   else:
    FFa349(self.VVuw7F, "Cannot create backup copy of original file!")
 def VVbkCc(self, VVXOwS):
  if self.fileChanged:
   FF8XzP(self.VVuw7F, BF(self.VVevme, VVXOwS), "Cancel changes ?")
  else:
   finalOK = os.system(FFQe93("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVevme(VVXOwS)
 def VVevme(self, VVXOwS):
  VVXOwS.cancel()
  FFGWxS(self.tmpFile)
  if self.VVnRGv:
   self.VVnRGv(self.fileSaved)
 def VVAk1J(self, VVXOwS, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VV0Duj + "ORIGINAL TEXT:\n" + VVBh5X + lineTxt
  FFsShb(self.VVuw7F, BF(self.VVcMu3, lineNum, VVXOwS), title="File Line", defaultText=lineTxt, message=message)
 def VVcMu3(self, lineNum, VVXOwS, VVsHNL):
  if not VVsHNL is None:
   if VVXOwS.VVqBOo() <= 1:
    self.VVHhKT("echo %s > '%s'" % (VVsHNL, self.tmpFile), VVXOwS)
   else:
    self.VVm0Gv(VVXOwS, lineNum, VVsHNL)
 def VVU6qw(self, VVXOwS, lineNum):
  if lineNum == VVXOwS.VVqBOo() and VVXOwS.VVqBOo() == 1:
   self.VVHhKT("echo %s >> '%s'" % (VVwd4B, self.tmpFile), VVXOwS)
  else:
   self.VVm0Gv(VVXOwS, lineNum, VVwd4B)
 def VVm0Gv(self, VVXOwS, lineNum, newTxt):
  VVXOwS.VV5MPV("Saving ...")
  lines = FFFfvw(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVXOwS.VVkTQq()
  VVuV68 = self.VVwHCw()
  VVXOwS.VVOFDI(VVuV68)
 def VVHhKT(self, cmd, VVXOwS):
  tCons = CCXype()
  tCons.ePopen(cmd, BF(self.VVGM3y, VVXOwS))
  self.fileChanged = True
  VVXOwS.VVkTQq()
 def VVGM3y(self, VVXOwS, result, retval):
  VVuV68 = self.VVwHCw()
  VVXOwS.VVOFDI(VVuV68)
 def VVwHCw(self):
  if fileExists(self.tmpFile):
   lines = FFFfvw(self.tmpFile)
   VVuV68 = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVuV68.append((str(ndx), line.strip()))
   if not VVuV68:
    VVuV68.append((str(1), ""))
   return VVuV68
  else:
   FFRYkM(self.VVuw7F, self.tmpFile)
class CCuF2O():
 def __init__(self, callingSELF, VVgchu="#22003344", VVn4Mh="#22002233"):
  self.callingSELF = callingSELF
  self.VVW1xb  = []
  self.satList  = []
  self.VVgchu  = VVgchu
  self.VVn4Mh   = VVn4Mh
 def VVpFrx(self, VVnRGv):
  self.VVW1xb = []
  VVW1xb, VVJhUQ = CCuF2O.VV3IJT(self.callingSELF, False, True)
  if VVW1xb:
   self.VVW1xb += VVW1xb
   self.VVkvSX(VVnRGv, VVJhUQ)
 def VVlXFC(self, mode, VVXOwS, satCol, VVnRGv, inFilterFnc=None):
  VVXOwS.VV5MPV("Loading Filters ...")
  self.VVW1xb = []
  self.VVW1xb.append(("All Services" , "all"))
  if mode == 1:
   self.VVW1xb.append(VVswUs)
   self.VVW1xb.append(("Parental Control", "parentalControl"))
   self.VVW1xb.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVW1xb.append(VVswUs)
   self.VVW1xb.append(("Selected Transponder"   , "selectedTP" ))
   self.VVW1xb.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVdZHm(VVXOwS, satCol)
  VVW1xb, VVJhUQ = CCuF2O.VV3IJT(self.callingSELF, True, False)
  if VVW1xb:
   VVW1xb.insert(0, FFzfpO("Custom Words"))
   self.VVW1xb += VVW1xb
  VVXOwS.VVwDYX()
  self.VVkvSX(VVnRGv, VVJhUQ, inFilterFnc)
 def VVK44o(self, VVW1xb, sats, VVnRGv, inFilterFnc=None):
  self.VVW1xb = VVW1xb
  VVW1xb, VVJhUQ = CCuF2O.VV3IJT(self.callingSELF, True, False)
  if VVW1xb:
   self.VVW1xb.append(FFzfpO("Custom Words"))
   self.VVW1xb += VVW1xb
  self.VVkvSX(VVnRGv, VVJhUQ, inFilterFnc)
 def VVkvSX(self, VVnRGv, VVJhUQ, inFilterFnc=None):
  VV0vau  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VVa3i0 = ("Edit Filter"  , BF(self.VVFYdx, VVJhUQ))
  VVkjyo  = ("Filter Help"  , BF(self.VV5eIE, VVJhUQ))
  FFLFXy(self.callingSELF, BF(self.VVtJLv, VVnRGv), VVW1xb=self.VVW1xb, title="Select Filter", VV0vau=VV0vau, VVa3i0=VVa3i0, VVkjyo=VVkjyo, VVuwvk=True, VVgchu=self.VVgchu, VVn4Mh=self.VVn4Mh)
 def VVtJLv(self, VVnRGv, item):
  if item:
   VVnRGv(item)
 def VVFYdx(self, VVJhUQ, VVlAViObj, sel):
  if fileExists(VVJhUQ) : CCtuLp(self.callingSELF, VVJhUQ, VVnRGv=None)
  else       : FFRYkM(self.callingSELF, VVJhUQ)
  VVlAViObj.cancel()
 def VV5eIE(self, VVJhUQ, VVlAViObj, sel):
  FFsiZl(self.callingSELF, "_help_service_filter", "Service Filter")
 def VVdZHm(self, VVXOwS, satColNum):
  if not self.satList:
   satList = VVXOwS.VVf87G(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFuzCW(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FFzfpO("Satellites"))
  if self.VVW1xb:
   self.VVW1xb += self.satList
 @staticmethod
 def VV3IJT(SELF, addTag, VVik2e):
  FFtQST()
  fileName  = "ajpanel_services_filter"
  VVJhUQ = VVCkxr + fileName
  VVW1xb  = []
  if not fileExists(VVJhUQ):
   os.system(FFQe93("cp -f '%s' '%s'" % (VV9dcF + fileName, VVJhUQ)))
  fileFound = False
  if fileExists(VVJhUQ):
   fileFound = True
   lines = FFFfvw(VVJhUQ)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVW1xb.append((line, "__w__" + line))
       else  : VVW1xb.append((line, line))
  if VVik2e:
   if   not fileFound : FFRYkM(SELF, VVJhUQ)
   elif not VVW1xb : FFRjyo(SELF, VVJhUQ)
  return VVW1xb, VVJhUQ
 @staticmethod
 def VVUxc8(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CCTHuN():
 def __init__(self, callingSELF, VVXOwS, addSep=True):
  self.callingSELF = callingSELF
  self.VVXOwS = VVXOwS
  self.VVW1xb = []
  iMulSel = self.VVXOwS.VV6hK1()
  if iMulSel : self.VVW1xb.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVW1xb.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVXOwS.VVYRl7()
  self.VVW1xb.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVW1xb.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVW1xb.append(VVswUs)
 def VVoxj8(self, extraMenu, cbFncDict, width=1000, okFnc=None):
  if extraMenu:
   self.VVW1xb.extend(extraMenu)
  FFLFXy(self.callingSELF, BF(self.VVCScd, cbFncDict, okFnc), width=width, title="Options", VVW1xb=self.VVW1xb)
 def VVCScd(self, cbFncDict, okFnc, item=None):
  if item:
   if   item == "multSelEnab" : self.VVXOwS.VVl5wx(True)
   elif item == "MultSelDisab" : self.VVXOwS.VVl5wx(False)
   elif item == "selectAll" : self.VVXOwS.VV5fgq()
   elif item == "unselectAll" : self.VVXOwS.VV74ul()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
   if okFnc:
    okFnc()
class CCWtyZ(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFXh6Y(VVz79X, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFwLhV(self)
  FFxDER(self["keyRed"]  , "Exit")
  FFxDER(self["keyGreen"]  , "Save")
  FFxDER(self["keyYellow"] , "Refresh")
  FFxDER(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VVDukd  ,
   "green" : self.VVhEwn ,
   "yellow": self.VVQxv5  ,
   "blue" : self.VVWSD6   ,
   "up" : self.VVEmui    ,
   "down" : self.VV6joq   ,
   "left" : self.VVWsG2   ,
   "right" : self.VVYgav   ,
   "cancel": self.VVDukd
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VVfcAc)
  self.onClose.append(self.onExit)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  self.VVQxv5()
  self.VV6jBj()
  FFvDt2(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV17bw)
  except:
   self.timer.callback.append(self.VV17bw)
  self.timer.start(1000, False)
  self.VV17bw()
 def onExit(self):
  self.timer.stop()
 def VVDukd(self) : self.close(True)
 def VVKilT(self) : self.close(False)
 def VVWSD6(self):
  self.session.openWithCallback(self.VVaEIN, BF(CCKDDc))
 def VVaEIN(self, closeAll):
  if closeAll:
   self.close()
 def VV17bw(self):
  self["curTime"].setText(str(FFXtJp(iTime())))
 def VVEmui(self):
  self.VVBEzs(1)
 def VV6joq(self):
  self.VVBEzs(-1)
 def VVWsG2(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VV6jBj()
 def VVYgav(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VV6jBj()
 def VVBEzs(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVUwnM(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVUwnM(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVUwnM(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VV548q(year)):
   days += 1
  return days
 def VV548q(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VV6jBj(self):
  for obj in self.list:
   FF0e9t(obj, "#11404040")
  FF0e9t(self.list[self.index], "#11ff8000")
 def VVQxv5(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVhEwn(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCXype()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVqjSk)
 def VVqjSk(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FF5nWa(self, "Nothing returned from the system!")
  else:
   FF5nWa(self, str(result))
class CCKDDc(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFXh6Y(VVZBN4, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFwLhV(self, addLabel=True)
  FFxDER(self["keyRed"]  , "Exit")
  FFxDER(self["keyGreen"]  , "Sync")
  FFxDER(self["keyYellow"] , "Refresh")
  FFxDER(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VVDukd   ,
   "green" : self.VVj69W  ,
   "yellow": self.VVIdGR ,
   "blue" : self.VVDe5C  ,
   "cancel": self.VVDukd
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVVeE9()
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  FFvDt2(self)
  FFWlvR(self.VVQXb0)
 def VVQXb0(self):
  self.VVt8Qh()
  self.VVyBuI(False)
 def VVDukd(self)  : self.close(True)
 def VVDe5C(self) : self.close(False)
 def VVVeE9(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVt8Qh(self):
  self.VVfj4o()
  self.VVvQfa()
  self.VVSoeh()
  self.VVuC13()
 def VVIdGR(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVVeE9()
   self.VVt8Qh()
   FFWlvR(self.VVQXb0)
 def VVj69W(self):
  if len(self["keyGreen"].getText()) > 0:
   FF8XzP(self, self.VVSIvO, "Synchronize with Internet Date/Time ?")
 def VVSIvO(self):
  self.VVt8Qh()
  FFWlvR(BF(self.VVyBuI, True))
 def VVfj4o(self)  : self["keyRed"].show()
 def VVi4So(self)  : self["keyGreen"].show()
 def VVf6qY(self) : self["keyYellow"].show()
 def VVZBbV(self)  : self["keyBlue"].show()
 def VVvQfa(self)  : self["keyGreen"].hide()
 def VVSoeh(self) : self["keyYellow"].hide()
 def VVuC13(self)  : self["keyBlue"].hide()
 def VVyBuI(self, sync):
  localTime = FFIDlG()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVRENU(server)
   if epoch_time is not None:
    ntpTime = FFXtJp(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCXype()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VVqjSk, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVf6qY()
  self.VVZBbV()
  if ok:
   self.VVi4So()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVqjSk(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVyBuI(False)
  except:
   pass
 def VVRENU(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if CCkcR1.VVGFKI():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCpVm4(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFXh6Y(VVbQmI, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FFwLhV(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FFWlvR(self.VVLXOV)
 def VVLXOV(self):
  if CCkcR1.VVGFKI() : color, txt = "#22002020", "Internet Connection = Successful."
  else     : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FF0e9t(self["myBody"], color)
   FF0e9t(self["myLabel"], color)
  except:
   pass
class CCH0fw(Screen):
 VVfVjM = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFcmgn()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFXh6Y(VVQjBR, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCcNzt(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCcNzt(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCcNzt(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCcJ7I()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFwLhV(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close      ,
   "up"  : self.VVEmui       ,
   "down"  : self.VV6joq      ,
   "left"  : self.VVWsG2      ,
   "right"  : self.VVYgav      ,
   "info"  : self.VVZM56     ,
   "epg"  : self.VVZM56     ,
   "menu"  : self.VVmAiU      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VVmODe, -1)  ,
   "next"  : BF(self.VVmODe, 1)  ,
   "pageUp" : BF(self.VVWpRc, True) ,
   "chanUp" : BF(self.VVWpRc, True) ,
   "pageDown" : BF(self.VVWpRc, False) ,
   "chanDown" : BF(self.VVWpRc, False) ,
   "0"   : BF(self.VVmODe, 0)  ,
   "1"   : BF(self.VV4MFB, pos=1) ,
   "2"   : BF(self.VV4MFB, pos=2) ,
   "3"   : BF(self.VV4MFB, pos=3) ,
   "4"   : BF(self.VV4MFB, pos=4) ,
   "5"   : BF(self.VV4MFB, pos=5) ,
   "6"   : BF(self.VV4MFB, pos=6) ,
   "7"   : BF(self.VV4MFB, pos=7) ,
   "8"   : BF(self.VV4MFB, pos=8) ,
   "9"   : BF(self.VV4MFB, pos=9) ,
  }, -1)
  self.onShown.append(self.VVfcAc)
  self.onClose.append(self.onExit)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  if not CCH0fw.VVfVjM:
   CCH0fw.VVfVjM = self
  self.sliderSNR.VVlJ81()
  self.sliderAGC.VVlJ81()
  self.sliderBER.VVlJ81(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VV4MFB()
  self.VVMscQ()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVySom)
  except:
   self.timer.callback.append(self.VVySom)
  self.timer.start(500, False)
 def VVMscQ(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VV0qxB(service)
  serviceName = self.tunerInfo.VVnYId()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self)
  tp = CCEpHi()
  tpTxt, satTxt = tp.VVgrTA(refCode)
  if tpTxt == "?" :
   tpTxt = FFY7FT("NO SIGNAL", VV6yYu)
  self["myTPInfo"].setText(tpTxt + "  " + FFY7FT(satTxt, VVJ2KG))
 def VVySom(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VV0qxB(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVQ8kJ())
   self["mySNR"].setText(self.tunerInfo.VVngy4())
   self["myAGC"].setText(self.tunerInfo.VVzceX())
   self["myBER"].setText(self.tunerInfo.VV8Eq9())
   self.sliderSNR.VVY8Ky(self.tunerInfo.VV1xhw())
   self.sliderAGC.VVY8Ky(self.tunerInfo.VVhZml())
   self.sliderBER.VVY8Ky(self.tunerInfo.VVlwZU())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVY8Ky(0)
   self.sliderAGC.VVY8Ky(0)
   self.sliderBER.VVY8Ky(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self)
    if state and not state == "Tuned":
     FF1ojr(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVZM56(self):
  FFr9gS(self, fncMode=CCsydO.VVaNQw)
 def VVmAiU(self):
  FFsiZl(self, "_help_signal", "Signal Monitor (Keys)")
 def VVEmui(self)  : self.VV4MFB(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VV6joq(self) : self.VV4MFB(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVWsG2(self) : self.VV4MFB(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVYgav(self) : self.VV4MFB(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VV4MFB(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FFxMsu(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVmODe(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFoooc(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FFxMsu(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CCH0fw.VVfVjM = None
 def VVWpRc(self, isUp):
  FF1ojr(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVMscQ()
  except:
   pass
class CCcNzt(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVlJ81(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FF0e9t(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VV9dcF +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FF0e9t(self.covObj, self.covColor)
   else:
    FF0e9t(self.covObj, "#00006688")
    self.isColormode = True
  self.VVY8Ky(0)
 def VVY8Ky(self, val):
  val  = FFoooc(val, self.minN, self.maxN)
  width = int(FFfFjr(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFoooc(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCvBnC(Screen):
 VVrdqg    = 0
 VVjpsh = 1
 VVfzHb = 2
 def __init__(self, session, titlePrefix="Processing ...", endTitle="Finishing ...", fncToRun=None, VVnRGv=None, barTheme=VVrdqg, titleBg="#0a042328", bodyBg="#0a042328"):
  ratio = self.VVezct(barTheme)
  self.skin, self.skinParam = FFXh6Y(VV2Qvp, 900, 200, 30, 40, 30, titleBg, bodyBg, 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.endTitle  = endTitle
  self.fncToRun  = fncToRun
  self.VVnRGv = VVnRGv
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVLNy3 = None
  self.timer   = eTimer()
  self.myThread  = None
  FFwLhV(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], { "cancel" : self.cancel }, -1)
  self.onShown.append(self.VVfcAc)
  self.onClose.append(self.onExit)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  self.VVS9TX()
  self["myProgBarVal"].setText("0%")
  FF0e9t(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVfti7()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVfti7)
  except:
   self.timer.callback.append(self.VVfti7)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VVBrFN(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VV2RUn(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVLNy3), self.counter, self.maxValue, catName)
 def VVoWvY(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVtYMO(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VV8itz(self, tot, evName):
  self.newTitle = "Translated: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, evName)
 def VVyVdp(self, action, tot, name):
  self.newTitle = "%s: %d   ... %d/%d >> %s" % (action, tot, self.counter, self.maxValue, name)
 def VVd8Ml(self, tot, name):
  self.newTitle = "Added: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, name)
 def VVhwt2(self, txt):
  self.newTitle = txt
 def VVwvD4(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VVLNy3), self.counter, self.maxValue)
  except:
   pass
 def VVdrnE(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVhX8y(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VV6mXU(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FF1ojr(self, "Cancelling ...")
  self.isCancelled = True
  self.VVlq59(False)
 def VVlq59(self, isDone):
  FFWlvR(BF(self.VVqk9E, isDone))
 def VVqk9E(self, isDone):
  if self.VVnRGv:
   self.VVnRGv(isDone, self.VVLNy3, self.counter, self.maxValue, self.isError)
  self.close()
 def VVfti7(self):
  val = FFoooc(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFfFjr(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self["myTitle"].setText("  %s  " % self.endTitle)
    self.VVlq59(True)
 def VVS9TX(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVjpsh, self.VVfzHb):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVezct(self, barTheme):
  if   barTheme == self.VVjpsh : return 0.7
  if   barTheme == self.VVfzHb : return 0.5
  else             : return 1
class CCXype(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVnRGv = {}
  self.commandRunning = False
  self.VV4kar  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVnRGv, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVnRGv[name] = VVnRGv
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VV4kar:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVCLDE, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VV53Qf , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVCLDE, name))
    self.appContainers[name].appClosed.append(BF(self.VV53Qf , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VV53Qf(name, retval)
  return True
 def VVCLDE(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FFY7FT("[UN-DECODED STRING]", VV6yYu))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VV53Qf(self, name, retval):
  if not self.VV4kar:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVnRGv[name]:
   self.VVnRGv[name](self.appResults[name], retval)
  del self.VVnRGv[name]
 def VVyIRR(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCPdSb(Screen):
 def __init__(self, session, title="", VVKINn=None, VVM4Ot=False, VVOEl1=False, VV0auT=False, VVWuBN=False, VV4YEE=False, VVV4pF=False, VVpV1e=VVKznu, VVvcJy=None, VVP1gy=False, VV3RFM=None, VVxtVg="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFXh6Y(VVnxJO, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFwLhV(self, addScrollLabel=True)
  if not VVxtVg:
   VVxtVg = "Processing ..."
  self["myLabel"].setText("   %s" % VVxtVg)
  self.VVM4Ot   = VVM4Ot
  self.VVOEl1   = VVOEl1
  self.VV0auT   = VV0auT
  self.VVWuBN  = VVWuBN
  self.VV4YEE = VV4YEE
  self.VVV4pF = VVV4pF
  self.VVpV1e   = VVpV1e
  self.VVvcJy = VVvcJy
  self.VVP1gy  = VVP1gy
  self.VV3RFM  = VV3RFM
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCXype()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFwHka()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVKINn, str):
   self.VVKINn = [VVKINn]
  else:
   self.VVKINn = VVKINn
  if self.VV0auT or self.VVWuBN:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVI8D8, VVI8D8)
   self.VVKINn.append("echo -e '\n%s\n' %s" % (restartNote, FFfLXZ(restartNote, VVzCWu)))
   if self.VV0auT:
    self.VVKINn.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVKINn.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VV4YEE:
   FF1ojr(self, "Processing ...")
  self.onLayoutFinish.append(self.VVVToc)
  self.onClose.append(self.VVBq75)
 def VVVToc(self):
  self["myLabel"].VVYV4X(outputFileToSave="console" if self.enableSaveRes else "")
  if self.VVM4Ot:
   self["myLabel"].VV8D9h()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVnu91()
  else:
   self.VVfpLz()
 def VVnu91(self):
  if CCkcR1.VVGFKI():
   self["myLabel"].setText("Processing ...")
   self.VVfpLz()
  else:
   self["myLabel"].setText(FFY7FT("\n   No connection to internet!", VV9ZlA))
 def VVfpLz(self):
  allOK = self.container.ePopen(self.VVKINn[0], self.VVwPsg, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVwPsg("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVV4pF or self.VV0auT or self.VVWuBN:
    self["myLabel"].setText(FFh5T1("STARTED", VVzCWu) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VV3RFM:
   colorWhite = CCkvru.VVnWwa(VV0Duj)
   color  = CCkvru.VVnWwa(self.VV3RFM[0])
   words  = self.VV3RFM[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVpV1e=self.VVpV1e)
 def VVwPsg(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVKINn):
   allOK = self.container.ePopen(self.VVKINn[self.cmdNum], self.VVwPsg, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVwPsg("Cannot connect to Console!", -1)
  else:
   if self.VV4YEE and FFRNqp(self):
    FF1ojr(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVV4pF:
    self["myLabel"].appendText("\n" + FFh5T1("FINISHED", VVzCWu), self.VVpV1e)
   if self.VVM4Ot or self.VVOEl1:
    self["myLabel"].VV8D9h()
   if self.VVvcJy is not None:
    self.VVvcJy()
   if not retval and self.VVP1gy:
    self.VVBq75()
 def VVBq75(self):
  if self.container.VVyIRR():
   self.container.killAll()
class CCDYaB(Screen):
 def __init__(self, session, VVKINn=None, VV4YEE=False):
  self.skin, self.skinParam = FFXh6Y(VVnxJO, 1650, 950, 40, 20, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVCkxr + "ajpanel_terminal.history"
  self.customCommandsFile = VVCkxr + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFyJfo("pwd") or "/home/root"
  self.container   = CCXype()
  self.commandsList  = []
  self.exitBtnText  = "Exit = Interrupt"
  FFwLhV(self, title="Terminal", addScrollLabel=True)
  FFxDER(self["keyRed"] , self.exitBtnText)
  FFxDER(self["keyGreen"] , "OK = History")
  FFxDER(self["keyYellow"], "Menu = Custom Cmds")
  FFxDER(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok" : self.VVuM36 ,
   "cancel": self.VV08aR  ,
   "menu" : self.VVzNtr ,
   "last" : self.VVoYXV  ,
   "next" : self.VVoYXV  ,
   "1"  : self.VVoYXV  ,
   "2"  : self.VVoYXV  ,
   "3"  : self.VVoYXV  ,
   "4"  : self.VVoYXV  ,
   "5"  : self.VVoYXV  ,
   "6"  : self.VVoYXV  ,
   "7"  : self.VVoYXV  ,
   "8"  : self.VVoYXV  ,
   "9"  : self.VVoYXV  ,
   "0"  : self.VVoYXV
  })
  self.onLayoutFinish.append(self.VVfcAc)
  self.onClose.append(self.VVSJet)
 def VVfcAc(self):
  self["myLabel"].VVYV4X(isResizable=False, outputFileToSave="terminal")
  FFLsU4(self["keyRed"]  , "#00ff8000")
  FF0e9t(self["keyRed"]  , self.skinParam["titleColor"])
  FF0e9t(self["keyGreen"]  , self.skinParam["titleColor"])
  FF0e9t(self["keyYellow"] , self.skinParam["titleColor"])
  FF0e9t(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVc7Cu(FFyJfo("date"), 5)
  result = FFyJfo("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVaZjw()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VV9dcF + "LinuxCommands.lst"
   newTemplate = VV9dcF + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFQe93("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFQe93("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVSJet(self):
  if self.container.VVyIRR():
   self.container.killAll()
   self.VVc7Cu("Process killed\n", 4)
   self.VVaZjw()
 def VV08aR(self):
  if self.container.VVyIRR():
   self.VVSJet()
  else:
   FF8XzP(self, self.close, "Exit ?", VVMmvg=False)
 def VVaZjw(self):
  self.VVc7Cu(self.prompt, 1)
  self["keyRed"].hide()
 def VVc7Cu(self, txt, mode):
  if   mode == 1 : color = VVzCWu
  elif mode == 2 : color = VV5cg1
  elif mode == 3 : color = VV0Duj
  elif mode == 4 : color = VV9ZlA
  elif mode == 5 : color = VVBh5X
  elif mode == 6 : color = VVQasA
  else   : color = VV0Duj
  try:
   self["myLabel"].appendText(FFY7FT(txt, color))
  except:
   pass
 def VVuM36(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVgw9s() == "":
   self.VV4laJ("cd /tmp")
   self.VV4laJ("ls")
  VVuV68 = []
  if fileExists(self.commandHistoryFile):
   lines  = FFFfvw(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVuV68.append((str(c), line, str(lNum)))
   self.VVkuMT(VVuV68, title, self.commandHistoryFile, isHistory=True)
  else:
   FFRYkM(self, self.commandHistoryFile, title=title)
 def VVgw9s(self):
  lastLine = FFyJfo("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VV4laJ(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVzNtr(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFFfvw(self.customCommandsFile)
   lastLineIsSep = False
   VVuV68 = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVuV68.append((str(c), line, str(lNum)))
   self.VVkuMT(VVuV68, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFRYkM(self, self.customCommandsFile, title=title)
 def VVkuMT(self, VVuV68, title, filePath=None, isHistory=False):
  if VVuV68:
   VVntre = "#05333333"
   if isHistory: VVgchu = VVn4Mh = VVMqKH = "#11000020"
   else  : VVgchu = VVn4Mh = VVMqKH = "#06002020"
   VVVi12   = ("Send"   , BF(self.VVVLwc, isHistory)  , [])
   VVsTsL  = ("Modify & Send" , self.VVPWkj     , [])
   if isHistory:
    VVQR2V = ("Clear History" , self.VVzLKJ     , [])
    VVmmwr = None
   elif filePath:
    VVQR2V = ("Options"  , self.VVb5Q3      , [])
    VVmmwr = ("Edit File"  , BF(self.VV0V8d, filePath) , [])
   header  = ("No." , "Commands", "LineNum" )
   widths  = (7  , 93   , 0    )
   VVI7B0 = (CENTER , LEFT   , CENTER )
   VVXOwS = FFEM8S(self, None, title=title, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26, VVVi12=VVVi12, VVsTsL=VVsTsL, VVQR2V=VVQR2V, VVmmwr=VVmmwr, lastFindConfigObj=CFG.lastFindTerminal, VVhmtx=True, searchCol=1
         , VVgchu=VVgchu, VVn4Mh=VVn4Mh, VVMqKH=VVMqKH, VVKhj2="#05ffff00", VVntre=VVntre)
   if not isHistory:
    VVXOwS.VV9fSx(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FFRjyo(self, filePath, title=title)
 def VVb5Q3(self, VVXOwS, title, txt, colList):
  mSel = CCTHuN(self, VVXOwS)
  if VVXOwS.VVyKav:
   totSel = VVXOwS.VVYRl7()
   totTxt = str(totSel)
   txt = "Send %s Command%s" % (FFY7FT(totTxt, VVzCWu) if totSel else totTxt, FFmJCK(totSel))
   VVW1xb = [(txt, "send")] if totSel else [(txt,)]
  else:
   VVW1xb = [("Send current line", "send")]
  cbFncDict = {"send": BF(self.VVVLwc, False, VVXOwS, title, txt, colList)}
  mSel.VVoxj8(VVW1xb, cbFncDict, okFnc=BF(self.VV8oZZ, VVXOwS))
 def VV8oZZ(self, VVXOwS):
  if VVXOwS.VVyKav : VVXOwS.VV7RDm()
  else        : VVXOwS.VVkTQq()
 def VVVLwc(self, isHistory, VVXOwS, title, txt, colList):
  if VVXOwS.VVyKav:
   lst = VVXOwS.VVrdFQ(1)
   curNdx = VVXOwS.VV6BuS()
  else:
   lst = [colList[1]]
   curNdx = VVXOwS.VVRJth()
  if not isHistory:
   FFxMsu(CFG.lastTerminalCustCmdLineNum, curNdx)
  self.commandsList = lst
  VVXOwS.cancel()
  FFWlvR(self.VVt57g)
 def VVt57g(self):
  if self.commandsList:
   cmd = self.commandsList[0]
   self.commandsList.pop(0)
   if not iMatch("^[a-zA-Z0-9_]", cmd):
    self.VVc7Cu("\n%s\n" % cmd, 6)
    self.VVc7Cu(self.prompt, 1)
    self.VVt57g()
   else:
    self.VVCPkp(cmd)
 def VVCPkp(self, cmd):
  tot = len(self.commandsList)
  self["keyRed"].setText("%s%s" % (self.exitBtnText, " (%s)" % tot if tot > 0 else ""))
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVc7Cu(cmd, 2)
   self.VVc7Cu("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVc7Cu(ch, 0)
   self.VVc7Cu("\nor\n", 4)
   self.VVc7Cu("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVaZjw()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFY7FT(parts[0].strip(), VV5cg1)
    right = FFY7FT("#" + parts[1].strip(), VVQasA)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVc7Cu(txt, 2)
   lastLine = self.VVgw9s()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VV4laJ(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVwPsg, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFa349(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVc7Cu(data, 3)
 def VVwPsg(self, data, retval):
  if not retval == 0:
   self.VVc7Cu("Exit Code : %d\n" % retval, 4)
  self.VVaZjw()
  if self.commandsList:
   self.VVt57g()
 def VVPWkj(self, VVXOwS, title, txt, colList):
  if VVXOwS.VVXUEy():
   cmd = colList[1]
   self.VV6Gvp(VVXOwS, cmd)
 def VVzLKJ(self, VVXOwS, title, txt, colList):
  FF8XzP(self, BF(self.VV2lt7, VVXOwS), "Reset History File ?", title="Command History")
 def VV2lt7(self, VVXOwS):
  os.system(FFQe93("echo '' > %s" % self.commandHistoryFile))
  VVXOwS.cancel()
 def VV0V8d(self, filePath, VVXOwS, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCtuLp(self, filePath, VVnRGv=BF(self.VV7N05, VVXOwS), curRowNum=rowNum)
  else     : FFRYkM(self, filePath)
 def VV7N05(self, VVXOwS, fileChanged):
  if fileChanged:
   VVXOwS.cancel()
   FFWlvR(self.VVzNtr)
 def VVoYXV(self):
  self.VV6Gvp(None, self.lastCommand)
 def VV6Gvp(self, VVXOwS, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFsShb(self, BF(self.VVmEfR, VVXOwS), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVmEfR(self, VVXOwS, cmd):
  if cmd and len(cmd) > 0:
   self.VVCPkp(cmd)
   if VVXOwS:
    VVXOwS.cancel()
class CCzRkq(Screen):
 def __init__(self, session, title="", message="", VVpV1e=VVKznu, width=1400, height=800, VVttKB=False, VVMqKH=None, VVJmZ8=30, titleFontSize=50, outputFileToSave=""):
  self.skin, self.skinParam = FFXh6Y(VVnxJO, width, height, titleFontSize, 30, 20, "#22002020", "#22001122", VVJmZ8)
  self.session   = session
  FFwLhV(self, title, addScrollLabel=True)
  self.VVpV1e   = VVpV1e
  self.VVttKB   = VVttKB
  self.VVMqKH   = VVMqKH
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  self["myLabel"].VVYV4X(VVttKB=self.VVttKB, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VVpV1e)
  if self.VVMqKH:
   FF0e9t(self["myBody"], self.VVMqKH)
   FF0e9t(self["myLabel"], self.VVMqKH)
   FF2dGH(self["myLabel"], self.VVMqKH)
  self["myLabel"].VV8D9h()
class CCIHiL(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFXh6Y(VVc4fk, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFwLhV(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FF3Gwy(self["errPic"], "err")
class CCFLAA(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFXh6Y(VVYP3F, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FFwLhV(self, " ", addCloser=True)
class CCCSgg():
 def __init__(self, session, txt, timeout=1500):
  self.win = session.instantiateDialog(CCFLAA, txt, 24)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  FFTlDF(self.win["myWinTitle"], "#440000", 2)
  self.session = session
  self.timer  = eTimer()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVxGD9)
  except:
   self.timer.callback.append(self.VVxGD9)
  self.timer.start(timeout, True)
 def VVxGD9(self):
  self.session.deleteDialog(self.win)
class CCXCxH():
 VVLE1v    = 0
 VV1bVL  = 1
 VVrsI3   = ""
 VVGV9U    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVXOwS   = None
  self.timer     = eTimer()
  self.VVlq8w   = 0
  self.VV1Xz5  = 1
  self.VVUYW7  = 2
  self.VVczsV   = 3
  self.VViEcN   = 4
  VVuV68 = self.VVZvbU()
  if VVuV68:
   self.VVXOwS = self.VVx73J(VVuV68)
  if not VVuV68 and mode == self.VVLE1v:
   self.VVYjXn("Download list is empty !")
   self.cancel()
  if mode == self.VV1bVL:
   FF7Xva(self.VVXOwS or self.SELF, BF(self.VV46pJ, startDnld, decodedUrl), title="Checking Server ...")
  self.VV7xDI(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV7xDI)
  except:
   self.timer.callback.append(self.VV7xDI)
  self.timer.start(1000, False)
 def VVx73J(self, VVuV68):
  VVuV68.sort(key=lambda x: int(x[0]))
  VV6iCg = self.VVE0CX
  VVVi12  = ("Play"  , self.VVLAID , [])
  VVd4CR = (""   , self.VVUt6u  , [])
  VVQcug = ("Stop"  , self.VVDshb  , [])
  VVsTsL = ("Resume"  , self.VV1jsE , [])
  VVQR2V = ("Options" , self.VV7VsJ  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVI7B0  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFEM8S(self.SELF, None, title=self.Title, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26, VVVi12=VVVi12, VVd4CR=VVd4CR, VV6iCg=VV6iCg, VVQcug=VVQcug, VVsTsL=VVsTsL, VVQR2V=VVQR2V, lastFindConfigObj=CFG.lastFindIptv, VVgchu="#11220022", VVn4Mh="#11110011", VVMqKH="#11110011", VVKhj2="#00ffff00", VVntre="#00223025", VV3VhT="#0a333333", VVwlSC="#0a400040", VVhmtx=True, searchCol=1)
 def VVZvbU(self):
  lines = CCXCxH.VVxqXC()
  VVuV68 = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVJm41(decodedUrl)
      if fName:
       if   FFyDhZ(decodedUrl) : sType = "Movie"
       elif FF50pb(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVvB6p(decodedUrl, fName)
       if size > -1: sizeTxt = CCbI7Z.VVr8MR(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVuV68.append((str(len(VVuV68) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVuV68
 def VVD9yz(self):
  VVuV68 = self.VVZvbU()
  if VVuV68:
   if self.VVXOwS : self.VVXOwS.VVOFDI(VVuV68, VVVeE9Msg=False)
   else     : self.VVXOwS = self.VVx73J(VVuV68)
  else:
   self.cancel()
 def VV7xDI(self, force=False):
  if self.VVXOwS:
   thrListUrls = self.VVj0gW()
   VVuV68 = []
   changed = False
   for ndx, row in enumerate(self.VVXOwS.VVWsuW()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVlq8w
    if m3u8Log:
     percent = CCXCxH.VVCnA6(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVczsV , "%.2f %%" % percent
      else   : flag, progr = self.VViEcN , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFPYZx(mPath)
     if curSize > -1:
      fSize = CCbI7Z.VVr8MR(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCbI7Z.VVr8MR(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFPYZx(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVczsV , "%.2f %%" % percent
       else   : flag, progr = self.VViEcN , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCbI7Z.VVr8MR(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VVUYW7
     if m3u8Log :
      if not speed and not force : flag = self.VV1Xz5
      elif curSize == -1   : self.VVHHNa(False)
    elif flag == self.VVlq8w  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVlq8w  : color2 = "#f#00555555#"
    elif flag == self.VV1Xz5 : color2 = "#f#0000FFFF#"
    elif flag == self.VVUYW7 : color2 = "#f#0000FFFF#"
    elif flag == self.VVczsV  : color2 = "#f#00FF8000#"
    elif flag == self.VViEcN  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVybZ0(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVuV68.append(row)
   if changed or force:
    self.VVXOwS.VVOFDI(VVuV68, VVVeE9Msg=False)
 def VVybZ0(self, flag):
  tDict = self.VVkco7()
  return tDict.get(flag, "?")
 def VVSqxP(self, state):
  for flag, txt in self.VVkco7().items():
   if txt == state:
    return flag
  return -1
 def VVkco7(self):
  return { self.VVlq8w: "Not started", self.VV1Xz5: "Connecting", self.VVUYW7: "Downloading", self.VVczsV: "Stopped", self.VViEcN: "Completed" }
 def VVkzoN(self, title):
  colList = self.VVXOwS.VVsaDG()
  path = colList[6]
  url  = colList[8]
  if self.VVb81j() : self.VVYjXn("Cannot delete !\n\nFile is downloading.")
  else      : FF8XzP(self.SELF, BF(self.VV2C2B, path, url), "Delete ?\n\n%s" % path, title=title)
 def VV2C2B(self, path, url):
  m3u8Log = self.VVXOwS.VVsaDG()[12]
  if m3u8Log : os.system(FFQe93("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFQe93("rm -r '%s'" % path))
  self.VVI4j9(False)
  self.VVD9yz()
 def VVI4j9(self, VVik2e=True):
  if self.VVb81j():
   FF1ojr(self.VVXOwS, self.VVybZ0(self.VVUYW7), 500)
  else:
   colList  = self.VVXOwS.VVsaDG()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VVSqxP(state) in (self.VVlq8w, self.VViEcN, self.VVczsV):
    lines = CCXCxH.VVxqXC()
    newLines = []
    found = False
    for line in lines:
     if CCXCxH.VVikft(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VV9VZH(newLines)
     self.VVD9yz()
     FF1ojr(self.VVXOwS, "Removed.", 1000)
    else:
     FF1ojr(self.VVXOwS, "Not found.", 1000)
   elif VVik2e:
    self.VVYjXn("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VV6rEK(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FF8XzP(self.SELF, BF(self.VVQmfk, flag), ques, title=title)
 def VVQmfk(self, flag):
  list = []
  for ndx, row in enumerate(self.VVXOwS.VVWsuW()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVSqxP(state)
   if   flag == flagVal == self.VViEcN: list.append(decodedUrl)
   elif flag == flagVal == self.VVlq8w : list.append(decodedUrl)
  lines = CCXCxH.VVxqXC()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VV9VZH(newLines)
   self.VVD9yz()
   FF1ojr(self.VVXOwS, "%d removed." % totRem, 1000)
  else:
   FF1ojr(self.VVXOwS, "Not found.", 1000)
 def VVa9wn(self):
  colList  = self.VVXOwS.VVsaDG()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FF1ojr(self.VVXOwS, "Poster exists", 1500)
  else    : FF7Xva(self.VVXOwS, BF(self.VVBz3D, decodedUrl, path, png), title="Checking Server ...")
 def VVBz3D(self, decodedUrl, path, png):
  err = self.VVqvtH(decodedUrl, path, png)
  if err:
   FFa349(self.SELF, err, title="Poster Download")
 def VVqvtH(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CC2WTV.VVWwnk(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCgg3d.VVHvuJ(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCgg3d.VVTXoD(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCgg3d.VVgvLY(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFjmFi(pUrl, "ajp_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   os.system(FFQe93("mv -f '%s' '%s'" % (tPath, png)))
   CCFA9F.VVK9Qe(self.SELF, VVUlwB=png, showGrnMsg="Downloaded")
   return ""
 def VVUt6u(self, VVXOwS, title, txt, colList):
  def VVObU9(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VV5vDG(key, val) : return "\n%s:\n%s\n" % (FFY7FT(key, VVJ2KG), val.strip())
  heads  = self.VVXOwS.VVJIaa()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVObU9(heads[i]  , CCbI7Z.VVr8MR(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVObU9("Downloaded" , CCbI7Z.VVr8MR(int(curSize), mode=0))
   else:
    txt += VVObU9(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VV5vDG(heads[i], colList[i])
  FFyv2f(self.SELF, txt, title=title)
 def VVLAID(self, VVXOwS, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCbI7Z.VV7vnp(self.SELF, path)
  else    : FF1ojr(self.VVXOwS, "File not found", 1000)
 def VVE0CX(self, VVXOwS):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVXOwS:
   self.VVXOwS.cancel()
  del self
 def VV7VsJ(self, VVXOwS, title, txt, colList):
  c1, c2, c3 = VVPpUd, VV9ZlA, VVJ2KG
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVW1xb = []
  VVW1xb.append((c1 + "Remove current row"       , "VVI4j9" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVW1xb.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVW1xb.append(VVswUs)
  VVW1xb.append((c2 + "Delete the file (and remove from list)"  , "VVkzoN"))
  VVW1xb.append(VVswUs)
  VVW1xb.append((resumeTxt + " Auto Resume"       , "VVUK8z" ))
  VVW1xb.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVW1xb.append(VVswUs)
  t = "Download Movie Poster "
  if FFyDhZ(decodedUrl): VVW1xb.append((c3 + "%s(from server)" % t , "VVa9wn"  ))
  else      : VVW1xb.append(("%s... Movies only" % t ,      ))
  if fileExists(path) : VVW1xb.append((c3 + "Open in File Manager" , "inFileMan,%s" % path ))
  else    : VVW1xb.append(("Open in File Manager"  ,      ))
  FFLFXy(self.SELF, BF(self.VVV0PL, VVXOwS), VVW1xb=VVW1xb, title=self.Title, VVxhca=True, width=800, VVuwvk=True, VVgchu="#1a001122", VVn4Mh="#1a001122")
 def VVV0PL(self, VVXOwS, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVI4j9"  : self.VVI4j9()
   elif ref == "remFinished"   : self.VV6rEK(self.VViEcN, txt)
   elif ref == "remPending"   : self.VV6rEK(self.VVlq8w, txt)
   elif ref == "VVkzoN" : self.VVkzoN(txt)
   elif ref == "VVa9wn"  : self.VVa9wn()
   elif ref == "VVUK8z"  : FFxMsu(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FFxMsu(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CCbI7Z, mode=CCbI7Z.VV3NWh, jumpToFile=path)
    else    : FF1ojr(VVXOwS, "Path not found !", 1500)
 def VV46pJ(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CC2WTV.VVWwnk(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVYjXn("Could not get download link !\n\nTry again later.")
     return
  for line in CCXCxH.VVxqXC():
   if CCXCxH.VVikft(decodedUrl, line):
    if self.VVXOwS:
     self.VVGnhl(decodedUrl)
     FFWlvR(BF(FF1ojr, self.VVXOwS, "Already listed !", 2000))
    break
  else:
   params = self.VV2TM1(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVYjXn(params[0])
   elif len(params) == 2:
    FF8XzP(self.SELF, BF(self.VV54sj, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCbI7Z.VVr8MR(fSize)
    FF8XzP(self.SELF, BF(self.VV5ZuV, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VV5ZuV(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCXCxH.VVWbHG(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVD9yz()
  if self.VVXOwS:
   self.VVXOwS.VVhksv()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCXCxH.VVGV9U, path, decodedUrl)
   self.VV0jBJ(threadName, url, decodedUrl, path, resp)
 def VVGnhl(self, decodedUrl):
  if self.VVXOwS:
   for ndx, row in enumerate(self.VVXOwS.VVWsuW()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVXOwS:
     self.VVXOwS.VV9fSx(ndx)
     break
 def VV2TM1(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVJm41(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVvB6p(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CC2WTV.VVWwnk(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CC2WTV.VVZSNI()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCXCxH.VVfqRa(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCXCxH.VVefsi(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VV54sj(self, resp, decodedUrl):
  if not os.system(FFQe93("which ffmpeg")) == 0:
   FF8XzP(self.SELF, BF(CCgg3d.VV4Sso, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVJm41(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVIZFl(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FF8XzP(self.SELF, BF(self.VVS1Mk, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVS1Mk(rTxt, rUrl)
  else:
   self.VVYjXn("Cannot process m3u8 file !")
 def VVIZFl(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVW1xb = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCgg3d.VVg0OK(rUrl, fPath)
   VVW1xb.append((resol, fullUrl))
  if VVW1xb:
   FFLFXy(self.SELF, self.VV3sKH, VVW1xb=VVW1xb, title="Resolution", VVxhca=True, VVuwvk=True)
  else:
   self.VVYjXn("Cannot get Resolutions list from server !")
 def VV3sKH(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FF8XzP(self.SELF, BF(FFWlvR, BF(self.VVNmEw, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFWlvR(BF(self.VVNmEw, resolUrl))
 def VVNmEw(self, resolUrl):
  txt, err = CC2WTV.VVGRLW(resolUrl)
  if err : self.VVYjXn(err)
  else : self.VVS1Mk(txt, resolUrl)
 def VVgHCe(self, logF, decodedUrl):
  found = False
  lines = CCXCxH.VVxqXC()
  with open(CCXCxH.VVWbHG(), "w") as f:
   for line in lines:
    if CCXCxH.VVikft(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCXCxH.VVWbHG(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVD9yz()
  if self.VVXOwS:
   self.VVXOwS.VVhksv()
 def VVS1Mk(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCgg3d.VVg0OK(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVYjXn("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVgHCe(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFQe93("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCXCxH.VVGV9U, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVCnA6(dnldLog):
  if fileExists(dnldLog):
   dur = CCXCxH.VVXXgn(dnldLog)
   if dur > -1:
    tim = CCXCxH.VVQR1i(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVXXgn(dnldLog):
  lines = FF94gP("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVQR1i(dnldLog):
  lines = FF94gP("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVvB6p(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FF50pb(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFQe93("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VV0jBJ(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVXOwS.VVsaDG()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VV9y4d, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VV9y4d(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVrsI3 == path:
       break
     else:
      break
  except:
   return
  if CCXCxH.VVrsI3:
   CCXCxH.VVrsI3 = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFPYZx(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VV2TM1(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VV9y4d(url, decodedUrl, path, resp, totFileSize, True)
 def VVDshb(self, VVXOwS, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVB720() : FF1ojr(self.VVXOwS, self.VVybZ0(self.VViEcN), 500)
  elif not self.VVb81j() : FF1ojr(self.VVXOwS, self.VVybZ0(self.VVczsV), 500)
  elif m3u8Log      : FF8XzP(self.SELF, self.VVHHNa, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVj0gW():
    CCXCxH.VVrsI3 = colList[6]
    FF1ojr(self.VVXOwS, "Stopping ...", 1000)
   else:
    FF1ojr(self.VVXOwS, "Stopped", 500)
 def VVHHNa(self, withMsg=True):
  if withMsg:
   FF1ojr(self.VVXOwS, "Stopping ...", 1000)
  os.system(FFQe93("killall -INT ffmpeg"))
 def VV1jsE(self, *args):
  if   self.VVB720() : FF1ojr(self.VVXOwS, self.VVybZ0(self.VViEcN) , 500)
  elif self.VVb81j() : FF1ojr(self.VVXOwS, self.VVybZ0(self.VVUYW7), 500)
  else:
   resume = False
   m3u8Log = self.VVXOwS.VVsaDG()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FF8XzP(self.SELF, BF(self.VVt3UX, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVEPqC():
    resume = True
   if resume: FF7Xva(self.VVXOwS, BF(self.VV26QW), title="Checking Server ...")
   else  : FF1ojr(self.VVXOwS, "Cannot resume !", 500)
 def VVt3UX(self, m3u8Log):
  os.system(FFQe93("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FF7Xva(self.VVXOwS, BF(self.VV26QW), title="Checking Server ...")
 def VV26QW(self):
  colList  = self.VVXOwS.VVsaDG()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CC2WTV.VVWwnk(decodedUrl)
   if url:
    decodedUrl = self.VVxfoi(decodedUrl, url)
   else:
    self.VVYjXn("Could not get download link !\n\nTry again later.")
    return
  curSize = FFPYZx(path)
  params = self.VV2TM1(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVYjXn(params[0])
   return
  elif len(params) == 2:
   self.VV54sj(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVxfoi(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCXCxH.VVGV9U, path, decodedUrl)
  if resumable: self.VV0jBJ(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVYjXn("Cannot resume from server !")
 def VVJm41(self, decodedUrl):
  fileExt = CCgg3d.VVJ7MV(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FF6GnB(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVYjXn(self, txt):
  FFa349(self.SELF, txt, title=self.Title)
 def VVj0gW(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCXCxH.VVGV9U, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VVb81j(self):
  decodedUrl = self.VVXOwS.VVsaDG()[9]
  return decodedUrl in self.VVj0gW()
 def VVB720(self):
  colList = self.VVXOwS.VVsaDG()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFPYZx(path)) == size
 def VVEPqC(self):
  colList = self.VVXOwS.VVsaDG()
  path = colList[6]
  size = int(colList[7])
  curSize = FFPYZx(path)
  if curSize > -1:
   size -= curSize
  err = CCXCxH.VVefsi(size)
  if err:
   FFa349(self.SELF, err, title=self.Title)
   return False
  return True
 def VV9VZH(self, list):
  with open(CCXCxH.VVWbHG(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVxfoi(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCXCxH.VVxqXC()
  url = decodedUrl
  with open(CCXCxH.VVWbHG(), "w") as f:
   for line in lines:
    if CCXCxH.VVikft(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVD9yz()
  return url
 @staticmethod
 def VVxqXC():
  list = []
  if fileExists(CCXCxH.VVWbHG()):
   for line in FFFfvw(CCXCxH.VVWbHG()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVikft(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVefsi(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCbI7Z.VVREmO(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCbI7Z.VVr8MR(size), CCbI7Z.VVr8MR(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVaLRz(SELF):
  tot = CCXCxH.VVxdC0()
  if tot:
   FFa349(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVxdC0():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCXCxH.VVGV9U):
    c += 1
  return c
 @staticmethod
 def VVWfZP():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCXCxH.VVGV9U, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VVLWM5():
  return len(CCXCxH.VVxqXC()) == 0
 @staticmethod
 def VVYInz():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVXfMC():
  mPoints = CCXCxH.VVYInz()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFQe93("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVWbHG():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVLg6m(SELF):
  CCXCxH.VVbDKO(SELF, CCXCxH.VVLE1v)
 @staticmethod
 def VVkfmM(SELF):
  CCXCxH.VVbDKO(SELF, CCXCxH.VV1bVL, startDnld=True)
 @staticmethod
 def VV5h2B(SELF, url):
  CCXCxH.VVbDKO(SELF, CCXCxH.VV1bVL, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVABac(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(SELF)
  added, skipped = CCXCxH.VV3kFz([decodedUrl])
  FF1ojr(SELF, "Added", 1000)
 @staticmethod
 def VV3kFz(list):
  added = skipped = 0
  for line in CCXCxH.VVxqXC():
   for ndx, url in enumerate(list):
    if url and CCXCxH.VVikft(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCXCxH.VVWbHG(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVbDKO(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCTs8V.VVMo6T(SELF):
   return
  if mode == CCXCxH.VVLE1v and CCXCxH.VVLWM5():
   FFa349(SELF, "Download list is empty !", title=title)
  else:
   inst = CCXCxH(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVfqRa(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCXzGX(Screen, CCrYKH):
 VV2jNU = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, isFromExternal=False, enableDownloadMenu=True, enableOpenInFMan=True):
  self.skin, self.skinParam = FFXh6Y(VV8C6U, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCrYKH.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.enableOpenInFMan  = enableOpenInFMan
  self.iptvTableParams  = iptvTableParams
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FFwLhV(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVQ1WS())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVi1M6       ,
   "info"  : self.VVZM56      ,
   "epg"  : self.VVZM56      ,
   "menu"  : self.VVaWR6     ,
   "cancel" : self.cancel       ,
   "red"  : self.VVgoCZ   ,
   "green"  : self.VVSh4y  ,
   "blue"  : self.VVuzaY      ,
   "yellow" : self.VV2eE4 ,
   "left"  : BF(self.VVRlFA, -1)    ,
   "right"  : BF(self.VVRlFA,  1)    ,
   "play"  : self.VVe4dU      ,
   "pause"  : self.VVe4dU      ,
   "playPause" : self.VVe4dU      ,
   "stop"  : self.VVe4dU      ,
   "rewind" : self.VVF7tz      ,
   "forward" : self.VVbx5i      ,
   "rewindDm" : self.VVF7tz      ,
   "forwardDm" : self.VVbx5i      ,
   "last"  : self.VV08cN      ,
   "next"  : self.VVBnQo      ,
   "pageUp" : BF(self.VVu9oz, True)  ,
   "pageDown" : BF(self.VVu9oz, False)  ,
   "chanUp" : BF(self.VVu9oz, True)  ,
   "chanDown" : BF(self.VVu9oz, False)  ,
   "up"  : BF(self.VVu9oz, True)  ,
   "down"  : BF(self.VVu9oz, False)  ,
   "audio"  : BF(self.VV8rJH, True)  ,
   "subtitle" : BF(self.VV8rJH, False)  ,
   "text"  : self.VVqKfT  ,
   "0"   : BF(self.VVn4ot , 10)   ,
   "1"   : BF(self.VVn4ot , 1)   ,
   "2"   : BF(self.VVn4ot , 2)   ,
   "3"   : BF(self.VVn4ot , 3)   ,
   "4"   : BF(self.VVn4ot , 4)   ,
   "5"   : BF(self.VVn4ot , 5)   ,
   "6"   : BF(self.VVn4ot , 6)   ,
   "7"   : BF(self.VVn4ot , 7)   ,
   "8"   : BF(self.VVn4ot , 8)   ,
   "9"   : BF(self.VVn4ot , 9)
  }, -1)
  self.onShown.append(self.VVfcAc)
  self.onClose.append(self.onExit)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FF8TfI(self)
  if not CCXzGX.VV2jNU:
   CCXzGX.VV2jNU = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FF3Gwy(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FF3Gwy(self["myPlayRpt"], "rpt")
  self.VVu0kH()
  self.instance.move(ePoint(40, 40))
  self.VVNGLV(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVylQ2)
  except:
   self.timer.callback.append(self.VVylQ2)
  self.timer.start(250, False)
  self.VVylQ2("Checking ...")
  self.VVmzE8()
 def VVSh4y(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self)
  self.lastSubtitle = CCdwmB.VVnwrW()
  if "chCode" in iptvRef:
   if CCTs8V.VVMo6T(self):
    self.VVmzE8(True)
  else:
   self.VVylQ2("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVu0kH(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVGyuG()
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VV6yYu + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FF0e9t(self["myTitle"], tColor)
  FF0e9t(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FF0e9t(self["myPlay%s" % item], tColor)
  picFile = CCsydO.VVQQzv(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CCsydO.VVP9uN(self)
  cl = CChvOR.VVrzHP(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VVylQ2(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCXCxH.VVxdC0()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVGyuG()
  if evName:
   evName = "    %s    " % FFY7FT(evName, VVBh5X)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVeE7o():
   FFLsU4(self["myPlayBlu"], "#00FFFFFF")
   FF0e9t(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFLsU4(self["myPlayBlu"], "#00FFFF88")
   FF0e9t(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FF0e9t(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FFoooc(percVal, 0, 100)
   width = int(FFfFjr(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FF0e9t(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFLsU4(self["myPlayMsg"], "#0000ffff")
   else  : FFLsU4(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFLsU4(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFLsU4(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVUUoQ()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VVHLZC(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CCdwmB.VVUdg7(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VV08cN()
  state = self.VVoYOu()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFLsU4(self["myPlayMsg"], "#0000ff00")
  else     : FFLsU4(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVGyuG(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFSXdj(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCXzGX.VVeLNP(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCsydO.VVf5x2(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CCEpHi()
   tpTxt, satTxt = tp.VVgrTA(refCode)
   self.satInfo_TP = tpTxt + "  " + FFY7FT(satTxt, VVW6qu)
  evName = evNameNext = ""
  evLst = CCos4Q.VVh7UH(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFxRrg(info, iServiceInformation.sVideoWidth) or -1
   h = FFxRrg(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFxRrg(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CCsydO.VVXzKq(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VVeLNP(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFCiZs(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFCiZs(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFCiZs(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVaWR6(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVGyuG()
  FFyDhZSeries = FF6GnB(decodedUrl)
  VVW1xb = []
  if self.isFromExternal:
   VVW1xb.append((VVW6qu + "IPTV Menu", "iptv"))
   VVW1xb.append(VVswUs)
  if isIptv and not "&end=" in decodedUrl and not FFyDhZSeries:
   uType, uHost, uUser, uPass, uId, uChName = CCgg3d.VVHvuJ(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVW1xb.append((VVW6qu + "Catchup Programs", "catchup" ))
    VVW1xb.append(VVswUs)
  if refCode:
   c = VV6yYu
   VVW1xb.append((c + "Stop Current Service"  , "stop"  ))
   VVW1xb.append((c + "Restart Current Service" , "restart"  ))
   txt = "Replay with ..."
   if isDvb: VVW1xb.append((txt     ,    ))
   else : VVW1xb.append((c + txt    , "replayWith" ))
   VVW1xb.append(VVswUs)
  if FFyDhZSeries:
   VVW1xb.append((VVW6qu + "File Size (on server)", "fileSize" ))
   VVW1xb.append(VVswUs)
  if self.enableDownloadMenu:
   c = VVW6qu
   addSep = False
   if isIptv and FFyDhZSeries:
    VVW1xb.append((c + "Start Download"  , "dload_cur" ))
    VVW1xb.append((c + "Add to Download List" , "addToDload" ))
    addSep = True
   if not CCXCxH.VVLWM5():
    VVW1xb.append((VVW6qu + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVW1xb.append(VVswUs)
  fPath, fDir, fName = CCbI7Z.VVzTch(self)
  if fPath:
   c = VVTMjp
   if self.enableOpenInFMan and not CCbI7Z.VV0Tdg:
    VVW1xb.append((c + "Open path in File Manager", "VVXE7s"))
   VVW1xb.append((c + "Add to Bouquet"             , "VVIbgp" ))
   VVW1xb.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVhK4T"  ))
   VVW1xb.append(VVswUs)
  if isDvb:
   VVW1xb.append((VVW6qu + "Signal Monitor", "sigMon"))
  if posTxt and durTxt:
   VVW1xb.append((VVJ2KG + "Start Subtitle", "VV7hmh"))
   VVW1xb.append(VVswUs)
  if CFG.playerPos.getValue() : VVW1xb.append(("Move Bar to Bottom" , "botm"))
  else      : VVW1xb.append(("Move Bar to Top" , "top" ))
  VVW1xb.append(("Help", "help"))
  FFLFXy(self, self.VVcL9T, VVW1xb=VVW1xb, width=600, title="Options")
 def VVcL9T(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VV2eE4()
   elif item == "stop"     : self.VVavZK(0)
   elif item == "restart"    : self.VVavZK(1)
   elif item == "replayWith"   : self.VV0fC2()
   elif item == "fileSize"    : FF7Xva(self, BF(CCsydO.VV3T5J, self), title="Checking Server")
   elif item == "dload_cur"   : CCXCxH.VVkfmM(self)
   elif item == "addToDload"   : CCXCxH.VVABac(self)
   elif item == "dload_stat"   : CCXCxH.VVLg6m(self)
   elif item == "VVXE7s" : self.close("close_openInFileMan")
   elif item == "VVIbgp" : self.VVIbgp()
   elif item == "VV7hmh"  : self.VVyrn3()
   elif item == "VVhK4T"  : self.VVhK4T()
   elif item == "botm"     : self.VVNGLV(0)
   elif item == "top"     : self.VVNGLV(1)
   elif item == "sigMon"    : self.VVgoCZ()
   elif item == "help"     : FFsiZl(self, "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCXzGX.VV2jNU = None
 def VVavZK(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VVu0kH()
   elif typ == 1:
    self.VVylQ2("Restarting Service ...")
    FFWlvR(BF(self.VVyxkB, serv))
 def VVyxkB(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self)
  if "&end=" in decodedUrl: BF(self.VVmzE8, True)
  else     : self.session.nav.playService(serv)
 def VV0fC2(self):
  FFLFXy(self, self.VVKlKx, VVW1xb=CCbI7Z.VVItJ2(), width=650, title="Select Player", VVgchu="#11220000", VVn4Mh="#11220000")
 def VVKlKx(self, rType=None):
  if rType:
   FFzHPJ(self, eServiceReference(rType + ":" + self.session.nav.getCurrentlyPlayingServiceReference().toString().split(":", 1)[1]))
 def VVIbgp(self):
  fPath, fDir, fName = CCbI7Z.VVzTch(self)
  if fPath: picker = CCRtNz(self, self, "Add Current Movie to a Bouquet", BF(self.VVtQMN, [fPath]))
  else : FF1ojr(self, "Path not found !", 1500)
 def VVtQMN(self, pathLst):
  return CCRtNz.VViQsh(pathLst)
 def VVhK4T(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCXzGX.VVeLNP(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVylQ2(txt, highlight=ok)
 def VVNGLV(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FFxMsu(CFG.playerPos, pos)
 def VVgoCZ(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCsydO.VVf5x2(serv)
   if isDvb: self.close("close_sig")
   else : self.VVylQ2("No Signal for Current Service")
 def VVyrn3(self):
  self.session.openWithCallback(self.VVZ2ik, BF(CCdwmB))
 def VVqKfT(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVGyuG()
   if posTxt and durTxt: self.VVyrn3()
   else    : self.VVylQ2("No duration Info. !")
 def VVZ2ik(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VVu9oz(True)
  elif reason == "subtZapDn" : self.VVu9oz(False)
  elif reason == "pause"  : self.VVe4dU()
  elif reason == "audio"  : self.VV8rJH(True)
  elif reason == "subtitle" : self.VV8rJH(False)
  elif reason == "rewind"     : self.VVF7tz()
  elif reason == "forward" : self.VVbx5i()
  elif reason == "rewindDm" : self.VVF7tz()
  elif reason == "forwardDm" : self.VVbx5i()
  else      : txt = reason
  if txt:
   FF1ojr(self, txt, 2000)
 def VVi1M6(self):
  if self.isManualSeek:
   self.VV7SRC()
   self.VVHLZC(self.manualSeekPts)
  elif self.shown:
   if CCdwmB.VVXyer(self): self.VVyrn3()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VV7SRC()
  else    : self.close()
 def VVZM56(self):
  FFr9gS(self, fncMode=CCsydO.VV2AHk)
 def VVe4dU(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VVylQ2("Toggling Play/Pause ...")
 def VV7SRC(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVRlFA(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCXzGX.VVeLNP(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVkIrk()
   else:
    self.manualSeekSec += direc * self.VVkIrk()
    self.manualSeekSec = FFoooc(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFfFjr(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFCiZs(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVn4ot(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVQ1WS())
   FFxMsu(CFG.playerJumpMin, self.jumpMinutes)
  self.VVylQ2("Changed Seek Time to : %d%s" % (val, self.VV6v3I()))
 def VVQ1WS(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VV6v3I())
 def VV6v3I(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVbsCK(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVkIrk(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVUUoQ(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVuzaY(self):
  cList = self.VVeE7o()
  if cList:
   VVW1xb = []
   for pts, what in cList:
    txt = FFCiZs(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVW1xb.append((txt, pts))
   FFLFXy(self, self.VVPoya, VVW1xb=VVW1xb, title="Cut List")
  else:
   self.VVylQ2("No Cut-List for this channel !")
 def VVPoya(self, item=None):
  if item:
   self.VVHLZC(item)
 def VVeE7o(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVbx5i(self) : self.VVc3z9(1)
 def VVF7tz(self) : self.VVc3z9(-1)
 def VVc3z9(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCXzGX.VVeLNP(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVkIrk() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVbsCK())
    self.VVylQ2(txt)
  except:
   self.VVylQ2("Cannot jump")
 def VVHLZC(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVylQ2("Changing Time ...")
 def VV08cN(self):
  self.VVavZK(1)
  self.VVylQ2("Replaying ...")
  self.VV7SRC()
 def VVBnQo(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCXzGX.VVeLNP(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVylQ2("Jumping to end ...")
  except:
   pass
 def VVoYOu(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVu9oz(self, isUp):
  if self.enableZapping:
   self.VVylQ2("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VV7SRC()
   if self.iptvTableParams:
    FFWlvR(BF(self.VVgsWm, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self)
    if "/timeshift/" in decodedUrl:
     self.VVylQ2("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVNrCu()
  else:
   self.VVylQ2("Zap Disabled !")
 def VVNrCu(self):
  self.lastPlayPos = 0
  self.VVu0kH()
  self.VVmzE8()
 def VVgsWm(self, isUp):
  CCgg3d_inatance, VVXOwS, mode = self.iptvTableParams
  if isUp : VVXOwS.VV89iP()
  else : VVXOwS.VVAQzd()
  colList = VVXOwS.VVsaDG()
  if mode == "localIptv":
   chName, chUrl = CCgg3d_inatance.VVP3GG(VVXOwS, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCgg3d_inatance.VV9KTV(VVXOwS, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCgg3d_inatance.VVlFq7(mode, VVXOwS, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCgg3d_inatance.VVEijA(mode, VVXOwS, colList)
  else:
   self.VVylQ2("Cannot Zap")
   return
  FFqi6V(self, chUrl, VVEPKV=False)
  self.VVNrCu()
 def VVmzE8(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCXzGX.VVeLNP(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self)
   if not self.VVBesS(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVylQ2("Refreshing Portal")
   FFWlvR(self.VV4yXv)
  except:
   pass
 def VV4yXv(self):
  self.restoreLastPlayPos = self.VVPczX()
 def VV2eE4(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self)
  if not decodedUrl or FF6GnB(decodedUrl):
   self.VVylQ2("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCgg3d.VVHvuJ(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVylQ2("Reading Program List ...")
   ok_fnc = BF(self.VVVGew, refCode, chName, streamId, uHost, uUser, uPass)
   FFWlvR(BF(CCgg3d.VVegXI, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVylQ2("Cannot process this channel")
 def VVVGew(self, refCode, chName, streamId, uHost, uUser, uPass, VVXOwS, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVXOwS.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVylQ2("Changing Program ...")
   FFWlvR(BF(self.VV4g1q, chUrl))
  else:
   self.VVylQ2("Incorrect Timestamp !")
 def VV4g1q(self, chUrl):
  FFqi6V(self, chUrl, VVEPKV=False)
  self.lastPlayPos = 0
  self.VVu0kH()
 def VV8rJH(self, isAudio):
  try:
   VVPWYL = InfoBar.instance
   if VVPWYL:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVPWYL)
    else  : self.session.open(SubtitleSelection, VVPWYL)
  except:
   pass
 @staticmethod
 def VVJEHr(rType):
  if   rType == "5001": return fileExists("/usr/bin/gstplayer_gst-1.0")
  elif rType == "5002": return fileExists("/usr/bin/exteplayer3")
  else    : return False
 @staticmethod
 def VVgjyS(session, mode=None):
  if   mode == "close_sig"   : FFQ9QB(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CCgg3d)
  elif mode == "close_openInFileMan" : session.open(CCbI7Z, gotoMovie=True)
 @staticmethod
 def VVmA7N(session, isFromExternal=False, **kwargs):
  session.openWithCallback(BF(CCXzGX.VVgjyS, session), CCXzGX, isFromExternal=isFromExternal, **kwargs)
class CCS94s(Screen):
 def __init__(self, session, title="", VVusVD="Continue?", VVMmvg=True, VVJRkN=False):
  self.skin, self.skinParam = FFXh6Y(VVI2hq, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVusVD = VVusVD
  self.VVJRkN = VVJRkN
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVMmvg : VVW1xb = [no , yes]
  else   : VVW1xb = [yes, no ]
  FFwLhV(self, title, VVW1xb=VVW1xb, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVi1M6 ,
   "cancel": self.cancel ,
   "red" : self.cancel ,
  }, -1)
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVusVD)
  if self.VVJRkN:
   self["myLabel"].instance.setHAlign(0)
  self.VV6guj()
  FFKauM(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FF81Cg(self["myMenu"])
  FFwpS7(self, self["myMenu"])
 def VVi1M6(self):
  item = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VV6guj(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCQ6xF(Screen):
 def __init__(self, session, title="", VVW1xb=None, width=1000, height=850, VVJmZ8=30, barText="", minRows=1, OKBtnFnc=None, infoBtnFnc=None, VVszaU=None, VV0vau=None, VVa3i0=None, VVkjyo=None, VVxhca=False, VVuwvk=False, yellowBasePath=None, rcuSearch=True, VVgchu="#22003344", VVn4Mh="#22002233"):
  self.skin, self.skinParam = FFXh6Y(VV2F6v, width, height, 50, 40, 30, VVgchu, VVn4Mh, VVJmZ8, barHeight=40, topRightBtns=3 if infoBtnFnc else 0)
  self.session   = session
  self.VVW1xb   = VVW1xb
  self.barText   = barText
  self.minRows   = minRows
  self.OKBtnFnc   = OKBtnFnc
  self.infoBtnFnc   = infoBtnFnc
  self.VVszaU   = VVszaU
  self.VV0vau  = VV0vau
  self.VVa3i0  = ("Delete File", BF(self.VVVwFF, yellowBasePath)) if not yellowBasePath is None else VVa3i0
  self.VVkjyo   = VVkjyo
  self.VVxhca  = VVxhca
  self.VVuwvk  = VVuwvk
  self.Title    = title
  FFwLhV(self, title, VVW1xb=VVW1xb)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVi1M6    ,
   "cancel" : self.cancel    ,
   "info"  : self.VVualQ   ,
   "red"  : self.VVDoMn   ,
   "green"  : self.VVjCxZ   ,
   "yellow" : self.VVjfJH   ,
   "blue"  : self.VV5bu7   ,
   "pageUp" : self.VVKm3z ,
   "chanUp" : self.VVKm3z ,
   "pageDown" : self.VV5wdm  ,
   "chanDown" : self.VV5wdm  ,
   "0"   : BF(self.VVPV1i, 0) ,
   "1"   : BF(self.VVPV1i, 1) ,
   "2"   : BF(self.VVPV1i, 2) ,
   "3"   : BF(self.VVPV1i, 3) ,
   "4"   : BF(self.VVPV1i, 4) ,
   "5"   : BF(self.VVPV1i, 5) ,
   "6"   : BF(self.VVPV1i, 6) ,
   "7"   : BF(self.VVPV1i, 7) ,
   "8"   : BF(self.VVPV1i, 8) ,
   "9"   : BF(self.VVPV1i, 9)
  }, -1)
  if rcuSearch:
   FFoiwi(self, self["myMenu"], isMenu=True)
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FFKauM(self["myMenu"])
  FFVUwm(self, minRows=self.minRows)
  FF8TfI(self)
  self.VVO0jC(self["keyRed"]  , self.VVszaU )
  self.VVO0jC(self["keyGreen"] , self.VV0vau )
  self.VVO0jC(self["keyYellow"] , self.VVa3i0 )
  self.VVO0jC(self["keyBlue"]  , self.VVkjyo )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFvDt2(self)
 def VVO0jC(self, btnObj, btnFnc):
  if btnFnc:
   FFxDER(btnObj, btnFnc[0])
 def VVBi8D(self, fnc=None):
  self.VV0vau = fnc
  if fnc : self.VVO0jC(self["keyGreen"], self.VV0vau)
  else : self["keyGreen"].hide()
 def VVPV1i(self, digit):
  digit = str(digit)
  VVW1xb = self["myMenu"].list
  for ndx, item in enumerate(VVW1xb):
   if len(item) == 2:
    span = iSearch(r"^\[(\d)\]\s.+", FFyZAn(item[0]), IGNORECASE)
    if span and span.group(1) == digit:
     self.VVUaDE(ndx)
     self.VVi1M6()
     break
 def VVi1M6(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if item is not None:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVxhca: self.close((txt, ref, ndx))
    else     : self.close(item)
 def VVualQ(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if self.infoBtnFnc and item:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   self.infoBtnFnc(self, txt, ref, ndx)
 def cancel(self):
  self.close(None)
 def VVDoMn(self)  : self.VVMWsE(self.VVszaU)
 def VVjCxZ(self) : self.VVMWsE(self.VV0vau)
 def VVjfJH(self) : self.VVMWsE(self.VVa3i0)
 def VV5bu7(self) : self.VVMWsE(self.VVkjyo)
 def VVMWsE(self, btnFnc):
  if btnFnc:
   item = self["myMenu"].l.getCurrentSelection()[1]
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVuwvk:
    self.cancel()
 def VVUaDE(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VV0M1x(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVW1xb = self["myMenu"].list
  VVW1xb.pop(ndx)
  if len(VVW1xb) > 0: self["myMenu"].setList(VVW1xb)
  else    : self.close()
 def VVVwFF(self, basePath, menuObj, fName):
  FF8XzP(self, BF(self.VVwave, basePath + fName), "Delete this file ?\n\n%s" % fName, title=self.Title)
 def VVwave(self, path):
  FFGWxS(path)
  if fileExists(path) : FF1ojr(self, "Not deleted", 1000)
  else    : self.VV0M1x()
 def VVMswT(self, VVW1xb):
  if len(VVW1xb) > 0:
   newList = []
   for item in VVW1xb:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FFVUwm(self, minRows=self.minRows)
  else:
   self.close("")
 def VVw1VR(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FFVUwm(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVDrwZ(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVKm3z(self) : self["myMenu"].moveToIndex(0)
 def VV5wdm(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCZovh(Screen):
 def __init__(self, session, title="", width=1600, height=900, vMargin=5, header=None, VV6fdw=None, VVI7B0=None, VVHqY6=None, VVJmZ8=26, VVhmtx=False, VVA0qQ=0, VVVi12=None, VVd4CR=None, VVQcug=None, VVsTsL=None, VVQR2V=None, VVmmwr=None, VVRzm2=None, VVH2MF=None, VV6iCg=None, VVlMOs=-1, VVimZ8=0, searchCol=0, lastFindConfigObj=None, VVgchu=None, VVn4Mh=None, VV2cB8="#00dddddd", VVMqKH="#11002233", VVKhj2="#00ff8833", VVntre="#11111111", VV3VhT="#0a555555", VVMp1a="#0affffff", VVwlSC="#11552200", VV99jU="#0055ff55", VV99jURev="#0000bbff"):
  self.skin, self.skinParam = FFXh6Y(VVZXjU, width, height, 50, 10, vMargin, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFwLhV(self, title)
  self.Title     = title
  self.header     = header
  self.VV6fdw     = VV6fdw
  self.totalCols    = len(VV6fdw[0])
  self.VVA0qQ   = VVA0qQ
  self.lastSortModeIsReverese = False
  self.VVhmtx   = VVhmtx
  self.VVMNjd   = 0.01
  self.VVVLEZ   = 0.02
  self.VVWiul = 0.03
  self.VVcaTG  = 1
  self.VVHqY6 = VVHqY6
  self.colWidthPixels   = []
  self.VVVi12   = VVVi12
  self.OKButtonObj   = None
  self.VVd4CR   = VVd4CR
  self.VVQcug   = VVQcug
  self.VVsTsL   = VVsTsL
  self.VVQR2V  = VVQR2V
  self.VVmmwr   = VVmmwr
  self.VVRzm2    = VVRzm2
  self.VVH2MF   = VVH2MF
  self.tableRefreshCB   = None
  self.VV6iCg  = VV6iCg
  self.VVlMOs    = VVlMOs
  self.VVimZ8   = VVimZ8
  self.searchCol    = searchCol
  self.VVI7B0    = VVI7B0
  self.keyPressed    = -1
  self.VVJmZ8    = FFRuMz(VVJmZ8)
  self.VVJ5AH    = FFbSpu(self.VVJmZ8, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVgchu    = VVgchu
  self.VVn4Mh      = VVn4Mh
  self.VV2cB8    = FFVPH4(VV2cB8)
  self.VVMqKH    = FFVPH4(VVMqKH)
  self.VVKhj2    = FFVPH4(VVKhj2)
  self.VVntre    = FFVPH4(VVntre)
  self.VV3VhT   = FFVPH4(VV3VhT)
  self.VVMp1a    = FFVPH4(VVMp1a)
  self.VVwlSC    = FFVPH4(VVwlSC)
  self.VV99jU   = FFVPH4(VV99jU)
  self.VV99jURev  = FFVPH4(VV99jURev)
  self.VVyKav  = False
  self.selectedItems   = 0
  self.VVnfOO   = FFVPH4("#01fefe01")
  self.VVItm6   = FFVPH4("#11400040")
  self.VVc7Vl  = self.VVnfOO
  self.VVtwMs  = self.VVntre
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VVimZ8:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   if self.VVimZ8 == 1: self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV37JC  ,
   "red"  : self.VVSFiu  ,
   "green"  : self.VVp2FW ,
   "yellow" : self.VVx1Ny ,
   "blue"  : self.VV2zbg  ,
   "menu"  : self.VV4j6c ,
   "info"  : self.VVjb2M  ,
   "cancel" : self.VV4gCE  ,
   "up"  : self.VVAQzd    ,
   "down"  : self.VV89iP  ,
   "left"  : self.VVL78B   ,
   "right"  : self.VVSVHh  ,
   "next"  : self.VVssKz  ,
   "last"  : self.VVf015  ,
   "home"  : self.VV3QEr  ,
   "pageUp" : self.VV3QEr  ,
   "chanUp" : self.VV3QEr  ,
   "end"  : self.VVhksv  ,
   "pageDown" : self.VVhksv  ,
   "chanDown" : self.VVhksv
  }, -1)
  FFoiwi(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FF8TfI(self)
  try:
   self.VVbYQP()
  except Exception as e:
   FFa349(self, str(e), title=self.Title)
   self.close(None)
 def VVbYQP(self):
  FFvDt2(self)
  if self.VVgchu:
   FF0e9t(self["myTitle"], self.VVgchu)
  if self.VVn4Mh:
   FF0e9t(self["myBody"] , self.VVn4Mh)
   FF0e9t(self["myTableH"] , self.VVn4Mh)
   FF0e9t(self["myTable"] , self.VVn4Mh)
   FF0e9t(self["myBar"]  , self.VVn4Mh)
  self.VVO0jC(self.VVQcug  , self["keyRed"])
  self.VVO0jC(self.VVsTsL  , self["keyGreen"])
  self.VVO0jC(self.VVQR2V , self["keyYellow"])
  self.VVO0jC(self.VVmmwr  , self["keyBlue"])
  if self.VVVi12:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj and self.VVVi12[0]:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVVi12[0])
    FF0e9t(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVJ5AH)
  self["myTableH"].l.setFont(0, gFont(VVPvAG, self.VVJmZ8))
  self["myTable"].l.setItemHeight(self.VVJ5AH)
  self["myTable"].l.setFont(0, gFont(VVPvAG, self.VVJmZ8))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w = self["myTable"].instance.size().width()
  h = self["myTable"].instance.size().height()
  pos = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVJ5AH)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVJ5AH))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVJ5AH)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVJ5AH
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVJ5AH * len(self.VV6fdw) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVHqY6:
   self.VVHqY6 = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVHqY6)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVI7B0:
   self.VVI7B0 = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVI7B0
   self.VVI7B0 = []
   for item in tmpList:
    self.VVI7B0.append(item | RT_VALIGN_CENTER)
  self.VVuDn9()
  if self.VVRzm2:
   self.VVRzm2(self)
 def VVO0jC(self, btnFnc, btn):
  if btnFnc : FFxDER(btn, btnFnc[0])
  else  : FFxDER(btn, "")
 def VVaL7x(self, waitTxt):
  FF7Xva(self, self.VVuDn9, title=waitTxt)
 def VVuDn9(self, onlyHeader=False):
  try:
   if self.header:
    sortedFg = self.VV99jURev if self.lastSortModeIsReverese else self.VV99jU
    self["myTableH"].setList([self.VVfn4Q(0, self.header, self.VVMp1a, self.VVwlSC, self.VVMp1a, self.VVwlSC, sortedFg)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VV6fdw):
    self["myTable"].list.append(self.VVfn4Q(c, row, self.VV2cB8, self.VVMqKH, self.VVKhj2, self.VVntre, None))
   self.VV6fdw = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVlMOs > -1:
    self["myTable"].moveToIndex(self.VVlMOs )
   self.VVx2hk()
   if self.VVimZ8:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVJ5AH * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
     FFOMWW(self, width, newH)
   if self.VVH2MF:
    self.VVMWsE(self.VVH2MF, None)
   if self.tableRefreshCB:
    self.VVMWsE(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FFa349(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VVfn4Q(self, keyIndex, columns, VV2cB8, VVMqKH, VVKhj2, VVntre, VV99jU):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VV99jU and ndx == self.VVA0qQ : textColor = VV99jU
   else           : textColor = VV2cB8
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFVPH4(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVMqKH = c
    entry = span.group(3)
   if self.VVI7B0[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVJ5AH)
           , font   = 0
           , flags   = self.VVI7B0[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVMqKH
           , color_sel  = VVKhj2
           , backcolor_sel = VVntre
           , border_width = 1
           , border_color = self.VV3VhT
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVjb2M(self):
  rowData = self.VVo84W()
  if rowData:
   title, txt, colList = rowData
   if self.VVd4CR:
    fnc  = self.VVd4CR[1]
    params = self.VVd4CR[2]
    fnc(self, title, txt, colList)
   else:
    FFyv2f(self, txt, title)
 def VV37JC(self):
  if   self.VVyKav : self.VVGU3C(self.VVRJth(), mode=2)
  elif self.VVVi12  : self.VVMWsE(self.VVVi12, None)
  else      : self.VVjb2M()
 def VVSFiu(self) : self.VVMWsE(self.VVQcug , self["keyRed"])
 def VVp2FW(self) : self.VVMWsE(self.VVsTsL , self["keyGreen"])
 def VVx1Ny(self): self.VVMWsE(self.VVQR2V , self["keyYellow"])
 def VV2zbg(self) : self.VVMWsE(self.VVmmwr , self["keyBlue"])
 def VVMWsE(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FF1ojr(self, buttonFnc[3])
    FFWlvR(BF(self.VVniOB, buttonFnc))
   else:
    self.VVniOB(buttonFnc)
 def VVniOB(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVo84W()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVGU3C(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][9] == self.VVnfOO
   newRow = self.VVsaDG()
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVfn4Q(ndx, newRow, self.VV2cB8, self.VVMqKH, self.VVKhj2, self.VVntre, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVfn4Q(ndx, newRow, self.VVnfOO, self.VVItm6, self.VVc7Vl, self.VVtwMs, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   if self.VVRJth() < len(self["myTable"].list) - 1:
    self.VV89iP()
   else:
    self.VVx2hk()
 def VV5fgq(self)  : FF7Xva(self, BF(self.VVHErt, True ), title="Selecting all ..."  )
 def VV74ul(self) : FF7Xva(self, BF(self.VVHErt, False), title="Unselecting all ...")
 def VVHErt(self, isSel=True):
  if isSel:
   fg, bg = self.VVnfOO, self.VVItm6
   self.selectedItems = len(self["myTable"].list)
   self.VVl5wx(True)
  else:
   fg, bg = self.VV2cB8, self.VVMqKH
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][9] == self.VVnfOO
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     param = list(self["myTable"].list[ndx][col])
     param[8]  = fg
     param[9]  = fg
     param[10] = bg
     self["myTable"].list[ndx][col] = tuple(param)
  self["myTable"].l.invalidate()
 def VVo84W(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVHqY6[i] > 1 or self.VVHqY6[i] == self.VVMNjd or self.VVHqY6[i] == self.VVWiul:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VV4gCE(self):
  if self.VV6iCg : self.VV6iCg(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VVXYEj(self):
  return self["myTitle"].getText().strip()
 def VVJIaa(self):
  return self.header
 def VVjEWc(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VV8ZLk(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFLsU4(self["myBar"], color)
 def VV5MPV(self, txt):
  FF1ojr(self, txt)
 def VVbkCu(self, txt, Time=1000):
  FF1ojr(self, txt, Time)
 def VVkTQq(self): self["keyGreen"].show()
 def VV7RDm(self): self["keyGreen"].hide()
 def VVXUEy(self): return self["keyGreen"].visible
 def VVwDYX(self):
  FF1ojr(self)
 def VVG6Py(self, fnc):
  self["myTable"].onSelectionChanged.append(fnc)
 def VVqBOo(self):
  return len(self["myTable"].list)
 def VVRJth(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VV9Wh4(self):
  return len(self["myTable"].list)
 def VVl5wx(self, isOn):
  self.VVyKav = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VVmmwr: self["keyBlue"].hide()
   if self.VVVi12 and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVmmwr: self["keyBlue"].show()
   if self.VVVi12 and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVVi12[0])
   self.VV74ul()
  FF0e9t(self["myTitle"], color)
  FF0e9t(self["myBar"]  , color)
 def VV6hK1(self):
  return self.VVyKav
 def VVYRl7(self):
  return self.selectedItems
 def VV3s15(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVx2hk()
 def VVLqem(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVx0Lv(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVqBOo()
  txt += FFh5T1("Total Unique Items", VV9ZlA)
  for i in range(self.totalCols):
   if self.VVHqY6[i - 1] > 1 or self.VVHqY6[i - 1] == self.VVMNjd or self.VVHqY6[i - 1] == self.VVWiul:
    name, tot = self.VVLqem(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFyv2f(self, txt)
 def VVRuNe(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVsaDG(self):
  return self.VVJsov(self["myTable"].l.getCurrentSelectionIndex())
 def VVJsov(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVOFDI(self, newList, newTitle="", VVVeE9Msg=True, tableRefreshCB=None):
  if newTitle:
   self.VVjEWc(newTitle)
  if newList:
   self.VV6fdw = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VVhmtx and self.VVA0qQ == 0:
    isNum = True
   else:
    for cols in self.VV6fdw:
     if not FFvBVl(cols[self.VVA0qQ]): break
    else:
     isNum = True
   if isNum: self.VV6fdw.sort(key=lambda x: int(x[self.VVA0qQ])  , reverse=self.lastSortModeIsReverese)
   else : self.VV6fdw.sort(key=lambda x: x[self.VVA0qQ].lower() , reverse=self.lastSortModeIsReverese)
   if VVVeE9Msg : self.VVaL7x("Refreshing ...")
   else   : self.VVuDn9()
  else:
   FFa349(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VV5Kna(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VVfn4Q(self.VV9Wh4(), row, self.VV2cB8, self.VVMqKH, self.VVKhj2, self.VVntre, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VVhksv()
 def VVXlip(self):
  self["myTable"].list.pop(self.VVRJth())
  self["myTable"].l.setList(self["myTable"].list)
 def VV8NVY(self, data):
  ndx = self.VVRJth()
  newRow = self.VVfn4Q(ndx, data, self.VV2cB8, self.VVMqKH, self.VVKhj2, self.VVntre, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVx2hk()
   return True
  else:
   return False
 def VVxVqL(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VVfn4Q(ndx, data, self.VV2cB8, self.VVMqKH, self.VVKhj2, self.VVntre, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VVEpIg()
 def VVEpIg(self):
  self["myTable"].l.setList(self["myTable"].list)
 def VVwGhX(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VV71dE(self, colNum, textToFind, VVik2e=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVx2hk()
    break
  else:
   if VVik2e:
    FF1ojr(self, "Not found", 1000)
 def VV1ZDk(self, colDict, VVik2e=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVx2hk()
    return
  if VVik2e:
   FF1ojr(self, "Not found", 1000)
 def VVf87G(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVQ0ev(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FFvBVl(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VVrdFQ(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVnfOO:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VV6BuS(self):
  if self.selectedItems:
   for ndx, row in enumerate(self["myTable"].list):
    if row[1][9] == self.VVnfOO:
     return ndx
  return -1
 def VVqVcu(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVnfOO:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VVxegf(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VVnfOO: return True
  else        : return False
 def VVWsuW(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VV4j6c(self):
  if not self["keyMenu"].getVisible() or self.VVimZ8:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVRJth()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVW1xb1, VVJhUQ = CCuF2O.VV3IJT(self, False, False)
  VVW1xb = []
  VVW1xb.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVW1xb.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVW1xb.append(("Find ...\t\t%s" % (FFY7FT(txt, VV5cg1) if txt else ""), "findNew"   ))
  VVW1xb.append(itemOf(bool(VVW1xb1)    , "Find (from Filter) ..."   , "filter"   ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Table Statistcis"             , "tableStat"  ))
  VVW1xb.append(VVswUs)
  VVW1xb.append((FFY7FT("Export Table to .html"     , VV9ZlA) , "VVcdyK" ))
  VVW1xb.append((FFY7FT("Export Table to .csv"     , VV9ZlA) , "VVshJB" ))
  VVW1xb.append((FFY7FT("Export Table to .txt (Tab Separated)", VV9ZlA) , "VV3gIN" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVHqY6[i] > 1 or self.VVHqY6[i] == self.VVVLEZ:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVW1xb.append(VVswUs)
   if tot == 1 : VVW1xb.append(("Sort", sList[0][1]))
   else  : VVW1xb += sList
  VVkjyo = ("Keys Help", self.FFEM8SHelp)
  FFLFXy(self, self.VVXC9o, VVW1xb=VVW1xb, title=self.VVXYEj(), VVkjyo=VVkjyo)
 def VVXC9o(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VVQcAQ()
   elif item == "findPrev"  : self.VVQcAQ(isPrev=True)
   elif item == "findNew"  : self.VVPQ81()
   elif item == "filter"  : self.VVOH7S()
   elif item == "tableStat" : self.VVx0Lv()
   elif item == "VVcdyK": FF7Xva(self, self.VVcdyK, title=title)
   elif item == "VVshJB" : FF7Xva(self, self.VVshJB , title=title)
   elif item == "VV3gIN" : FF7Xva(self, self.VV3gIN , title=title)
   else:
    if self.VVA0qQ == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVA0qQ, self.lastSortModeIsReverese = item, False
    if self.VVhmtx and self.VVA0qQ == 0 or self.VVQ0ev(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVuDn9(onlyHeader=True)
 def FFEM8SHelp(self, menuInstance, path):
  FFsiZl(self, "_help_table", "Table (Keys Help)")
 def VVAQzd(self):
  self["myTable"].up()
  self.VVx2hk()
 def VV89iP(self):
  self["myTable"].down()
  self.VVx2hk()
 def VVL78B(self):
  self["myTable"].pageUp()
  self.VVx2hk()
 def VVSVHh(self):
  self["myTable"].pageDown()
  self.VVx2hk()
 def VV3QEr(self):
  self["myTable"].moveToIndex(0)
  self.VVx2hk()
 def VVhksv(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVx2hk()
 def VV9fSx(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVx2hk()
 def VVssKz(self):
  if self.lastFindConfigObj.getValue():
   if self.VVRJth() == len(self["myTable"].list) - 1 : FF1ojr(self, "End reached", 1000)
   else              : self.VVQcAQ()
  else:
   FF1ojr(self, 'Set "Find" in Menu', 1500)
 def VVf015(self):
  if self.lastFindConfigObj.getValue():
   if self.VVRJth() == 0 : FF1ojr(self, "Top reached", 1000)
   else       : self.VVQcAQ(isPrev=True)
  else:
   FF1ojr(self, 'Set "Find" in Menu', 1500)
 def VVKMyy(self, txt):
  FFxMsu(self.lastFindConfigObj, txt)
 def VVPQ81(self):
  FFsShb(self, self.VV3ls5, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VV3ls5(self, VVsHNL):
  if not VVsHNL is None:
   txt = VVsHNL.strip()
   self.VVKMyy(txt)
   if VVsHNL: self.VVQcAQ(reset=True)
   else  : FF1ojr(self, "Nothing to find !", 1500)
 def VVOH7S(self):
  VVW1xb, VVJhUQ = CCuF2O.VV3IJT(self, False, False)
  VVa3i0 = ("Edit Filter", BF(self.VVBdvo, VVJhUQ))
  if VVW1xb : FFLFXy(self, self.VV99TD, VVW1xb=VVW1xb, VVa3i0=VVa3i0, title="Find from Filter")
  else  : FF1ojr(self, "Filter Error !", 1500)
 def VV99TD(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VVKMyy(txt)
    self.VVQcAQ(reset=True)
   else:
    FF1ojr(self, "No entry !", 1500)
 def VVBdvo(self, VVJhUQ, VVlAViObj, sel):
  if fileExists(VVJhUQ) : CCtuLp(self, VVJhUQ, VVnRGv=None)
  else       : FFRYkM(self, VVJhUQ)
  VVlAViObj.cancel()
 def VVQcAQ(self, reset=False, isPrev=False):
  curRow = self.VVRJth()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CCuF2O.VVUxc8(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VV9fSx(i)
      break
    elif any(x in line for x in tupl):
     self.VV9fSx(i)
     break
   else:
    FF1ojr(self, "Not found", 1000)
  else:
   FF1ojr(self, "Check your query", 1500)
 def VV3gIN(self):
  expFile = self.VVYWWk() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVqZE7()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VVJsov(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVHqY6[ndx] > self.VVcaTG or self.VVHqY6[ndx] == self.VVWiul:
      col = self.VVb95W(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VV4g9i(expFile)
 def VVshJB(self):
  expFile = self.VVYWWk() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVqZE7()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VVJsov(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVHqY6[ndx] > self.VVcaTG or self.VVHqY6[ndx] == self.VVWiul:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VVb95W(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VV4g9i(expFile)
 def VVcdyK(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVXYEj(), PLUGIN_NAME, VVx2ku)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVXYEj()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVqZE7()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVHqY6:
   colgroup += '   <colgroup>'
   for w in self.VVHqY6:
    if w > self.VVcaTG or w == self.VVWiul:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVYWWk() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VVJsov(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVHqY6[ndx] > self.VVcaTG or self.VVHqY6[ndx] == self.VVWiul:
      col = self.VVb95W(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VV4g9i(expFile)
 def VVqZE7(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVHqY6[ndx] > self.VVcaTG or self.VVHqY6[ndx] == self.VVWiul:
     newRow.append(col.strip())
  return newRow
 def VVb95W(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFyZAn(col)
 def VVYWWk(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVXYEj())
  fileName = fileName.replace("__", "_")
  path  = FFnWu0(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFJCyp()
  return expFile
 def VV4g9i(self, expFile):
  FF5nWa(self, "File exported to:\n\n%s" % expFile, title=self.VVXYEj())
 def VVx2hk(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CChvOR():
 def __init__(self, pixmapObj, picPath, VVMqKH=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VVMqKH  = VVMqKH or "#2200002a"
 def VVWKq2(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVGEAx)
    except:
     self.picLoad.PictureData.get().append(self.VVGEAx)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VVMqKH])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVGEAx(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVNMsK(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVrzHP(pixmapObj, path, VVMqKH=None):
  cl = CChvOR(pixmapObj, path, VVMqKH)
  ok = cl.VVWKq2()
  if ok: return cl
  else : return None
class CCFA9F(Screen):
 def __init__(self, session, VVUlwB, title="", showGrnMsg="", fileList=None, curIndex=0, fakePath=None, cbFnc=None):
  scrW, scrH = FFcmgn()
  w = 1700
  h = int(min(w * scrH / scrW + 51, 1040))
  self.skin, self.skinParam = FFXh6Y(VVrG8C, w, h, 30, 0, 0, "#22000060", "#2200002a", 30, topRightBtns=3)
  self.session  = session
  self.Title   = title
  self["myPic"]  = Pixmap()
  self.VVUlwB = VVUlwB
  self.showGrnMsg  = showGrnMsg
  self.fileList  = fileList
  self.curIndex  = curIndex
  self.fakePath  = fakePath
  self.cbFnc   = cbFnc
  self.picViewer  = None
  FFwLhV(self)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.close    ,
   "red" : self.close    ,
   "cancel": self.close    ,
   "info" : self.VVah87  ,
   "up" : BF(self.VVFB7l, -1),
   "down" : BF(self.VVFB7l,  1),
   "left" : BF(self.VVFB7l, -1),
   "right" : BF(self.VVFB7l,  1)
  }, -1)
  self.onShown.append(self.VVfcAc)
  self.onClose.append(self.onExit)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FF8TfI(self)
  self.VVgLNF()
  self.picViewer = CChvOR.VVrzHP(self["myPic"], self.VVUlwB)
  if self.picViewer:
   if self.showGrnMsg:
    FF1ojr(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFa349(self, "Cannot view picture file:\n\n%s" % self.VVUlwB)
   self.close()
 def onExit(self):
  if self.picViewer: self.picViewer.VVNMsK()
  if self.cbFnc  : self.cbFnc(self.VVUlwB)
 def VVFB7l(self, direc):
  if self.fileList:
   oldNdx = self.curIndex
   self.curIndex += direc
   if direc == -1 and self.curIndex < 0      : self.curIndex = len(self.fileList) - 1
   if direc ==  1 and self.curIndex > len(self.fileList) - 1 : self.curIndex = 0
   if not oldNdx == self.curIndex:
    fName = self.fileList[self.curIndex]
    self.VVUlwB = FFnWu0(os.path.dirname(self.VVUlwB)) + fName
    self.picViewer.picPath = self.VVUlwB
    self.picViewer.VVWKq2()
    self.VVgLNF()
 def VVah87(self):
  txt = "%s:\n  %s" % (FFY7FT("Path", VVJ2KG), self.fakePath or self.VVUlwB)
  size, sizeTxt, resTxt, form, mode = CCXLqT.VVWuew(self.VVUlwB)
  if any((size, sizeTxt, resTxt, form, mode)):
   txt += "\n\n%s:\n" % FFY7FT("Properties", VVJ2KG)
   if sizeTxt: txt += "  File Size\t: %s\n" % sizeTxt
   if resTxt : txt += "  Dimensions\t: %s\n" % resTxt
   if form   : txt += "  Format\t: %s\n"  % form
   if mode   : txt += "  Mode\t: %s\n"   % mode
  FFyv2f(self, txt, title="File Information")
 def VVgLNF(self):
  if self.fileList: title = "%d/%d : %s" % (self.curIndex + 1, len(self.fileList), self.fileList[self.curIndex])
  elif self.Title : title = self.Title
  else   : title = os.path.basename(self.VVUlwB)
  self["myTitle"].setText("  %s  " % title)
 @staticmethod
 def VVK9Qe(SELF, VVUlwB, **kwargs):
  SELF.session.open(CCFA9F, VVUlwB, **kwargs)
class CClprH(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FFXh6Y(VVDCZ9, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FFwLhV(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VVfcAc)
  self.onClose.append(self.onExit)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  res = os.system(FFQe93("showiframe %s" % self.mviFile))
  if not res == 0:
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VVKSBf(SELF, mviFile):
  SELF.session.openWithCallback(BF(CClprH.VV7xuo, SELF), CClprH, mviFile)
 @staticmethod
 def VV7xuo(SELF, reason=None):
  if reason == -1: FFa349(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CCYJYU(Screen, ConfigListScreen):
 VVlqzZ = "ajpanel_update_url"
 def __init__(self, session):
  self.skin, self.skinParam = FFXh6Y(VVZCe3, 1400, 1050, 50, 15, 15, "#11201010", "#11101010", 27, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFwLhV(self, title=self.Title)
  FFxDER(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("File Manage Exit-Button Action"        , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Player Bar Hotkey"           , CFG.hotkey_signal    ))
  lst.append(getConfigListEntry("Screenshot"             , CFG.screenshotFType   ))
  lst.append(getConfigListEntry(VVI8D8 *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type (defines the player)"   , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Local Movies and IPTV Download Path"       , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(VVI8D8 *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(VVI8D8 *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB)"        , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons/Screenshots/Pictures"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVw6DU()
  self.onShown.append(self.VVfcAc)
 def VVw6DU(self):
  kList = {
    "ok" : self.VVi1M6   ,
    "green" : self.VV4kI9 ,
    "menu" : self.VVgRkl ,
    "cancel": self.VVJ6Xa ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VV4Opd, 0)
     kList["chanDown"] = BF(self["config"].VV4Opd, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FF8TfI(self)
  FFKauM(self["config"])
  FFVUwm(self, self["config"])
  FFvDt2(self)
  self["config"].onSelectionChanged.append(self.VVDuLN)
  FF0e9t(self["keyRed"], "#11000000")
  self["keyRed"].show()
  self.VVDuLN()
 def VVDuLN(self):
  cfg = self["config"].getCurrent()[1]
  if   isinstance(cfg, ConfigDirectory): txt = "Change Path"
  else         : txt = "Show Choices"
  self["keyRed"].setText("OK = %s" % txt)
 def VVi1M6(self):
  title, item = self["config"].getCurrent()
  if item:
   if   item == CFG.iptvHostsMode   : self.VV28Xr()
   elif item == CFG.MovieDownloadPath   : self.VVIsLe(item, self["config"].getCurrent()[0])
   elif isinstance(item, ConfigDirectory) : self.VVmEMb(item)
   else         : CCYJYU.VVczFh(self, item, title)
 @staticmethod
 def VVczFh(SELF, confItem, title, lst=None, cbFnc=None):
  isBool = isinstance(confItem, ConfigYesNo)
  isLst  = isinstance(confItem, ConfigSelection)
  isTxt  = isinstance(confItem, ConfigText)
  if not lst:
   if   isBool : lst = [(True, "ON"), (False, "OFF")]
   elif isLst : lst = confItem.choices.choices
   else  : return
  curNdx = defNdx = -1
  VVW1xb = []
  for ndx, item in enumerate(lst):
   if len(item) == 1:
    val, txt = ("dum",VVI8D8)
   else:
    val, txt = item
    if   val == confItem.value : curNdx, txt = ndx, VV5cg1 + txt
    elif val == confItem.default: defNdx, txt = ndx, VVzCWu + txt
   VVW1xb.append((txt, val))
  if defNdx == -1: defNdx = curNdx
  VVkjyo  = ("Current", BF(CCYJYU.VVs8e5, curNdx))
  VVa3i0 = ("Default", BF(CCYJYU.VVs8e5, defNdx))
  menuInstance = FFLFXy(SELF, BF(CCYJYU.VV6bbm, confItem, cbFnc), VVW1xb=VVW1xb, width=1200, VVa3i0=VVa3i0, VVkjyo=VVkjyo, title=title, VVgchu="#33221111", VVn4Mh="#33110011")
  menuInstance.VVUaDE(curNdx)
 @staticmethod
 def VV6bbm(confItem, cbFnc, item=None):
  if not item is None:
   FFxMsu(confItem, item)
   if cbFnc:
    cbFnc()
 @staticmethod
 def VVs8e5(ndx, VVlAViObj, item):
  VVlAViObj.VVUaDE(ndx)
 @staticmethod
 def VV7bNS(confItem, lst):
  for ndx, item in enumerate(lst):
   if item[0] == confItem.value:
    return ndx
  return -1
 def VVIsLe(self, item, title):
  tot = CCXCxH.VVxdC0()
  if tot : FFa349(self, "Cannot change while downloading.", title=title)
  else : self.VVmEMb(item)
 def VV28Xr(self):
  VVW1xb = []
  VVW1xb.append(("Auto Find" , "auto"))
  VVW1xb.append(("Custom Path" , "cust"))
  FFLFXy(self, self.VV6MJc, VVW1xb=VVW1xb, title="IPTV Hosts Files Path")
 def VV6MJc(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVVXZj)
   elif item == "cust":
    VVuV68 = self.VVfz7V()
    if VVuV68 : self.VV4GAn(VVuV68)
    else  : self.session.openWithCallback(self.VVTSma, BF(CCbI7Z, mode=CCbI7Z.VVIet0, VVetf7="/"))
 def VV4GAn(self, VVuV68):
  VV6iCg = self.VV4gvg
  VVQcug = ("Remove"  , self.VVJr1p , [])
  VVQR2V = ("Add "  , self.VVpu2j, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VVI7B0  = (LEFT   , LEFT  )
  FFEM8S(self, None, title="IPTV Hosts Search Paths", header=header, VV6fdw=VVuV68, width=1200, height=700, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=26, VV6iCg=VV6iCg, VVQcug=VVQcug, VVQR2V=VVQR2V
    , VVgchu="#22220000", VVn4Mh="#22110000", VVMqKH="#22110011", VVKhj2="#11ffff00", VVntre="#11223025", VV3VhT="#0a333333", VVwlSC="#11400040")
 def VV4gvg(self, VVXOwS):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VVegOc)
  VVXOwS.cancel()
 def VVTSma(self, path):
  if path:
   FFxMsu(CFG.iptvHostsDirs, FFnWu0(path.strip()))
   VVuV68 = self.VVfz7V()
   if VVuV68 : self.VV4GAn(VVuV68)
   else  : FF1ojr(self, "Cannot add dir", 1500)
 def VVIXVw(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVVXZj:
   return []
  return lst
 def VVfz7V(self):
  lst = self.VVIXVw()
  if lst:
   VVuV68 = []
   for Dir in lst:
    VVuV68.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVuV68.sort(key=lambda x: x[0].lower())
   return VVuV68
  else:
   return []
 def VVpu2j(self, VVXOwS, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VVwk9b, VVXOwS)
         , BF(CCbI7Z, mode=CCbI7Z.VVIet0, VVetf7=sDir))
 def VVwk9b(self, VVXOwS, path):
  if path:
   path = FFnWu0(path.strip())
   if self.VVvLFQ(VVXOwS, path):
    FF1ojr(VVXOwS, "Already added", 1500)
   else:
    lst = self.VVIXVw()
    lst.append(path)
    FFxMsu(CFG.iptvHostsDirs, ",".join(lst))
    VVuV68 = self.VVfz7V()
    VVXOwS.VVOFDI(VVuV68, tableRefreshCB=BF(self.VVJTHU, path))
 def VVJTHU(self, path, VVXOwS, title, txt, colList):
  self.VVvLFQ(VVXOwS, path)
 def VVvLFQ(self, VVXOwS, path):
  for ndx, row in enumerate(VVXOwS.VVWsuW()):
   if row[0].strip() == path.strip():
    VVXOwS.VV9fSx(ndx)
    return True
  return False
 def VVJr1p(self, VVXOwS, title, txt, colList):
  path = colList[0]
  FF8XzP(self, BF(self.VV6Hbd, VVXOwS), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VV6Hbd(self, VVXOwS):
  row = VVXOwS.VVsaDG()
  path, rem = row[0], row[1]
  VVuV68 = []
  lst = []
  for ndx, row in enumerate(VVXOwS.VVWsuW()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVuV68.append((tPath, tRem))
  if len(VVuV68) > 0:
   FFxMsu(CFG.iptvHostsDirs, ",".join(lst))
   VVXOwS.VVOFDI(VVuV68)
   FF1ojr(VVXOwS, "Deleted", 1500)
  else:
   FFxMsu(CFG.iptvHostsMode, VVVXZj)
   FFxMsu(CFG.iptvHostsDirs, "")
   VVXOwS.cancel()
   FFWlvR(BF(FF1ojr, self, "Changed to Auto-Find", 1500))
 def VVmEMb(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VVviq0, configObj)
         , BF(CCbI7Z, mode=CCbI7Z.VVIet0, VVetf7=sDir))
 def VVviq0(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVJ6Xa(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FF8XzP(self, self.VV4kI9, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VV4kI9(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVSDso()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVgRkl(self):
  VVW1xb = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VVW1xb.append((txt    , "VVZJs2"   ))
  else        : VVW1xb.append((txt    ,       ))
  VVW1xb.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Reset %s Settings" % PLUGIN_NAME      , "VVrVjL"   ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Backup %s Settings" % PLUGIN_NAME      , "VVE5Z8"  ))
  VVW1xb.append(("Restore %s Settings" % PLUGIN_NAME     , "VVxeO1"  ))
  if fileExists(VVCkxr + CCYJYU.VVlqzZ):
   VVW1xb.append(VVswUs)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VVW1xb.append(('%s Checking for Update' % txt1     , txt2     ))
   VVW1xb.append(("Reinstall %s" % PLUGIN_NAME      , "VVoOna"  ))
   VVW1xb.append(("Update %s" % PLUGIN_NAME      , "VVz7lw"   ))
  FFLFXy(self, self.VVKof5, VVW1xb=VVW1xb, title="Config. Options")
 def VVKof5(self, item=None):
  if item:
   if   item == "VVZJs2"  : FF8XzP(self, self.VVZJs2 , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CCkvru)
   elif item == "VVrVjL"  : FF8XzP(self, BF(self.VVrVjL, True), "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VVE5Z8" : self.VVE5Z8()
   elif item == "VVxeO1" : FF7Xva(self, self.VVxeO1, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FFxMsu(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FFxMsu(CFG.checkForUpdateAtStartup, False)
   elif item == "VVoOna" : FF7Xva(self, BF(self.VVbYFb, True ), "Checking Server ...")
   elif item == "VVz7lw"  : FF7Xva(self, BF(self.VVbYFb, False), "Checking Server ...")
 def VVE5Z8(self):
  path = "%sajpanel_settings_%s" % (VVCkxr, FFJCyp())
  os.system("grep .%s. %ssettings > %s" % (PLUGIN_NAME, VVLOHV, path))
  FF5nWa(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVxeO1(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name  = "ajpanel_settings_"
  files = FF94gP("find / %s -iname '%s*' | grep %s" % (FFiZoB(1), name, name))
  if files:
   err = CCbI7Z.VVPSgD(files)
   if err:
    FF8XzP(self, BF(self.VVaScZ, title), "No valid settings files found !\n\nLocate Manually ?", title=title)
   else:
    files = sorted(files, key=lambda t: -os.stat(t).st_mtime)
    VVW1xb = []
    for line in files:
     VVW1xb.append((line, line))
    FFLFXy(self, BF(self.VV95DH, title), title=title, VVW1xb=VVW1xb, width=1200, yellowBasePath="")
  else:
   FFa349(self, "No settings files found !", title=title)
 def VVaScZ(self, title, path=None):
  sDir = "/"
  for path in (VVCkxr, "/media/usb/", "/media/hdd/", "/media/"):
   if pathExists(path):
    sDir = path
    break
  self.session.openWithCallback(BF(self.VV95DH, title), BF(CCbI7Z, patternMode="ajpSet", VVetf7=sDir))
 def VV95DH(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFFfvw(path)
    self.VVrVjL()
    for line in lines:
     name, _, val = line.partition("=")
     try:
      confItem = eval(name)
      if confItem is not None:
       if   isinstance(confItem, ConfigInteger)  : val = int(val)
       elif isinstance(confItem, ConfigSelectionNumber): val = int(val)
       elif isinstance(confItem, ConfigYesNo)   : val = { "true": True, "false": False }.get(val.lower())
       if not val is None:
        confItem.setValue(val)
        confItem.save()
     except:
      pass
    self.VVSDso()
    FFtQST()
    FF1ojr(self, "Apllied", 1500, isGrn=True)
   else:
    FFRYkM(self, path, title=title)
 def VVZJs2(self):
  newPath = FFnWu0(VVCkxr)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVSDso()
 @staticmethod
 def VVNez3():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVrVjL(self, exit=False):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVSDso()
  if exit:
   self.close()
 def VVSDso(self):
  configfile.save()
  global VVCkxr
  VVCkxr = CFG.backupPath.getValue()
  FF4EPr()
 def VVbYFb(self, force):
  pre = "Reinstall" if force else "Update"
  title = "%s %s (from server)" % (pre, PLUGIN_NAME)
  curVer, webVer, url, isHigher, err = CCYJYU.VVd4TV()
  if   err    : FFa349(self, err, title)
  elif isHigher or force : FF8XzP(self, BF(FF7Xva, self, BF(self.VVBoWc, webVer, url, title, force)), "%s v%s and Restart ?" % ("Reinstall" if force else "Upgrade to", webVer), title=title)
  else     : FF5nWa(self, FFY7FT("No update required.", VVlfrr) + "\n\nCurrent Version = v%s\n\nWeb Version = v%s" % (curVer, webVer), title)
 def VVBoWc(self, webVer, url, title, force):
  fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if FFvwHi() == "dpkg" else "ipk")
  path, err = FFjmFi(url + fName, fName, timeout=2)
  if path:
   if force: cmd = FFkjia(VVzgm4, path)
   else : cmd = FFkjia(VVDBBb, path)
   if cmd:
    cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
    FFsZIz(self, cmd, title=title)
   else:
    FFPsN3(self, title=title)
  else:
   FFa349(self, err, title=title)
 @staticmethod
 def VVd4TV():
  span = iSearch(r"v*(\d.\d.\d)", VVx2ku, IGNORECASE)
  if span : curVer = span.group(1)
  else : return "", "", "", False, "Incorrect local version format !"
  path = VVCkxr + CCYJYU.VVlqzZ
  if fileExists(path):
   span = iSearch(r"(http.+)", FFqXAw(path), IGNORECASE)
   if span : url = FFnWu0(span.group(1))
   else : return curVer, "", "", False, err
  else:
   return curVer, "", "", False, "Update File not found:\n\n%s" % path
  path, err = FFjmFi(url + "version", "ajp_tmp.ver", timeout=2)
  if err:
   return curVer, "", url, False, err
  if fileExists(path):
   txt  = FFqXAw(path).strip().replace(" ", "")
   FFGWxS(path)
   span = iSearch(r"v*(\d.\d.\d)", txt.partition("=")[2], IGNORECASE)
   if span:
    webVer = span.group(1)
    webTup = tuple(map(int, (webVer.split("."))))
    curTup = tuple(map(int, (curVer.split("."))))
    return curVer, webVer, url, True if webTup > curTup else False, ""
   else:
    return curVer, "", url, False, "Incorrect version format (from server) !"
  else:
   return curVer, "", url, False, "Cannot download Version File !"
class CCkvru(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFXh6Y(VViJhZ, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = COLOR_SCHEME_NUM
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFwLhV(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVTXNo("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVTXNo("\c00888888", i) + sp + "GREY\n"
   txt += self.VVTXNo("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVTXNo("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVTXNo("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVTXNo("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVTXNo("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVTXNo("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVTXNo("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVTXNo("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVTXNo("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVTXNo("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVi1M6 ,
   "green" : self.VVi1M6 ,
   "left" : self.VVWsG2 ,
   "right" : self.VVYgav ,
   "cancel": self.close
  }, -1)
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  self.VVBLoc()
 def VVi1M6(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FF8XzP(self, self.VVe6Jo, "Change to : %s" % txt, title=self.Title)
 def VVe6Jo(self):
  FFxMsu(CFG.mixedColorScheme, self.cursorPos)
  global COLOR_SCHEME_NUM
  COLOR_SCHEME_NUM = self.cursorPos
  self.VVm8Y4()
  self.close()
 def VVWsG2(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVBLoc()
 def VVYgav(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVBLoc()
 def VVBLoc(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVTXNo(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVnWwa(color):
  if VVzCWu: return "\\" + color
  else    : return ""
 @staticmethod
 def VVm8Y4():
  global VVQasA, VVBh5X, VVAgOb, VV6yYu, VV9ZlA, VVPpUd, VVuULh, VVBZfW, VVlfrr, VVTMjp, VVzCWu, VVJ2KG, VV5cg1, VVW6qu, VVHiet, VV0Duj
  VV0Duj   = CCkvru.VVTXNo("\c00FFFFFF", COLOR_SCHEME_NUM)
  VVBh5X    = CCkvru.VVTXNo("\c00888888", COLOR_SCHEME_NUM)
  VVQasA  = CCkvru.VVTXNo("\c005A5A5A", COLOR_SCHEME_NUM)
  VVBZfW    = CCkvru.VVTXNo("\c00FF0000", COLOR_SCHEME_NUM)
  VVAgOb   = CCkvru.VVTXNo("\c00FF5000", COLOR_SCHEME_NUM)
  VV6yYu   = CCkvru.VVTXNo("\c00FFBB66", COLOR_SCHEME_NUM)
  VVzCWu   = CCkvru.VVTXNo("\c00FFFF00", COLOR_SCHEME_NUM)
  VVJ2KG = CCkvru.VVTXNo("\c00FFFFAA", COLOR_SCHEME_NUM)
  VVlfrr   = CCkvru.VVTXNo("\c0000FF00", COLOR_SCHEME_NUM)
  VVTMjp  = CCkvru.VVTXNo("\c00AAFFAA", COLOR_SCHEME_NUM)
  VVuULh    = CCkvru.VVTXNo("\c000066FF", COLOR_SCHEME_NUM)
  VV5cg1    = CCkvru.VVTXNo("\c0000FFFF", COLOR_SCHEME_NUM)
  VVW6qu  = CCkvru.VVTXNo("\c00AAFFFF", COLOR_SCHEME_NUM)  #
  VVHiet   = CCkvru.VVTXNo("\c00FA55E7", COLOR_SCHEME_NUM)
  VV9ZlA    = CCkvru.VVTXNo("\c00FF8F5F", COLOR_SCHEME_NUM)
  VVPpUd  = CCkvru.VVTXNo("\c00FFC0C0", COLOR_SCHEME_NUM)
CCkvru.VVm8Y4()
class CCMxVV(Screen):
 def __init__(self, session, path, VV4kar):
  self.skin, self.skinParam = FFXh6Y(VVZBN4, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVyTvD   = path
  self.VVkJtB   = ""
  self.VVIhQ3   = ""
  self.VV4kar    = VV4kar
  self.VVnNbI    = ""
  self.VVzBga  = ""
  self.VVZAvg    = False
  self.VVSFU8  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VVRh6E  = "enigma2-plugin-extensions-"
  self.VVKQ6d  = "enigma2-plugin-systemplugins-"
  self.VVoJBl = "enigma2-"
  self.VV8kOd  = 0
  self.VVhXNN  = 1
  self.VVUt7n  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVKuhK = "DEBIAN"
  else        : self.VVKuhK = "CONTROL"
  self.controlPath = self.Path + self.VVKuhK
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VV4kar:
   self.packageExt  = ".deb"
   self.VVMqKH  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVMqKH  = "#11001020"
  FFwLhV(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFxDER(self["keyRed"] , "Create")
  FFxDER(self["keyGreen"] , "Post Install")
  FFxDER(self["keyYellow"], "Installation Path")
  FFxDER(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVkh3H  ,
   "green"   : self.VVPXXT ,
   "yellow"  : self.VVjDuP  ,
   "blue"   : self.VVEKq8  ,
   "cancel"  : self.VVDukd
  }, -1)
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FFvDt2(self)
  if self.VVMqKH:
   FF0e9t(self["myBody"], self.VVMqKH)
   FF0e9t(self["myLabel"], self.VVMqKH)
  self.VVfJCI(True)
  self.VVMK4F(True)
 def VVMK4F(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVEFCI()
  if isFirstTime:
   if   package.startswith(self.VVRh6E) : self.VVyTvD = VVlZ1l + self.VVnNbI + "/"
   elif package.startswith(self.VVKQ6d) : self.VVyTvD = VVSVA6 + self.VVnNbI + "/"
   else            : self.VVyTvD = self.Path
  if self.VVZAvg : myColor = VV9ZlA
  else    : myColor = VV0Duj
  txt  = ""
  txt += "Source Path\t: %s\n" % FFY7FT(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFY7FT(self.VVyTvD, VVzCWu)
  if self.VVIhQ3 : txt += "Package File\t: %s\n" % FFY7FT(self.VVIhQ3, VVBh5X)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFY7FT("Check Control File fields : %s" % errTxt, VVAgOb)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFY7FT("Restart GUI", VV9ZlA)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFY7FT("Reboot Device", VV9ZlA)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FFY7FT("Post Install", VVlfrr), act)
  if not errTxt and VVAgOb in controlInfo:
   txt += "Warning\t: %s\n" % FFY7FT("Errors in control file may affect the result package.", VVAgOb)
  txt += "\nControl File\t: %s\n" % FFY7FT(self.controlFile, VVBh5X)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVPXXT(self):
  if self["keyGreen"].getVisible():
   VVW1xb = []
   VVW1xb.append(("No Action"    , "noAction"  ))
   VVW1xb.append(("Restart GUI"    , "VV0auT"  ))
   VVW1xb.append(("Reboot Device"   , "rebootDev"  ))
   FFLFXy(self, self.VV7Ef5, title="Package Installation Option (after completing installation)", VVW1xb=VVW1xb)
 def VV7Ef5(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VV0auT"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVfJCI(False)
   self.VVMK4F()
 def VVjDuP(self):
  rootPath = FFY7FT("/%s/" % self.VVnNbI, VVJ2KG)
  VVW1xb = []
  VVW1xb.append(("Current Path"        , "toCurrent"  ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Extension Path"       , "toExtensions" ))
  VVW1xb.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVW1xb.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFLFXy(self, self.VVV29G, title="Installation Path", VVW1xb=VVW1xb)
 def VVV29G(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVbwkZ(FFSahc(self.Path, True))
   elif item == "toExtensions"  : self.VVbwkZ(VVlZ1l)
   elif item == "toSystemPlugins" : self.VVbwkZ(VVSVA6)
   elif item == "toRootPath"  : self.VVbwkZ("/")
   elif item == "toRoot"   : self.VVbwkZ("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVUgYn, BF(CCbI7Z, mode=CCbI7Z.VVIet0, VVetf7=VVCkxr))
 def VVUgYn(self, path):
  if len(path) > 0:
   self.VVbwkZ(path)
 def VVbwkZ(self, parent, withPackageName=True):
  if withPackageName : self.VVyTvD = parent + self.VVnNbI + "/"
  else    : self.VVyTvD = "/"
  mode = self.VV8dcU()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VV2iH7(mode), self.controlFile))
  self.VVMK4F()
 def VVEKq8(self):
  if fileExists(self.controlFile):
   lines = FFFfvw(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFsShb(self, self.VVlaUe, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFa349(self, "Version not found or incorrectly set !")
  else:
   FFRYkM(self, self.controlFile)
 def VVlaUe(self, VVsHNL):
  if VVsHNL:
   version, color = self.VV0zbF(VVsHNL, False)
   if color == VV5cg1:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVsHNL, self.controlFile))
    self.VVMK4F()
   else:
    FFa349(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVDukd(self):
  if self.newControlPath:
   if self.VVZAvg:
    self.VVgYU5()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFY7FT(self.newControlPath, VVBh5X)
    txt += FFY7FT("Do you want to keep these files ?", VVzCWu)
    FF8XzP(self, self.close, txt, callBack_No=self.VVgYU5, title="Create Package", VVJRkN=True)
  else:
   self.close()
 def VVgYU5(self):
  os.system(FFQe93("rm -r '%s'" % self.newControlPath))
  self.close()
 def VV2iH7(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VVzBga
  if package.startswith(self.VVoJBl):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VVoJBl, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VVhXNN : prefix = self.VVRh6E
  elif mode == self.VVUt7n : prefix = self.VVKQ6d
  return (prefix + name).lower()
 def VV8dcU(self):
  if   self.VVyTvD.startswith(VVlZ1l) : return self.VVhXNN
  elif self.VVyTvD.startswith(VVSVA6) : return self.VVUt7n
  else            : return self.VV8kOd
 def VVfJCI(self, isFirstTime):
  self.VVnNbI   = FFmKBR(self.Path)
  self.VVnNbI   = "_".join(self.VVnNbI.split())
  self.VVzBga = self.VVnNbI.lower()
  self.VVZAvg = self.VVzBga == VV29es.lower()
  if self.VVZAvg and self.VVzBga.endswith("ajpan"):
   self.VVzBga += "el"
  if self.VVZAvg : self.VVkJtB = VVCkxr
  else    : self.VVkJtB = CFG.packageOutputPath.getValue()
  self.VVkJtB = FFnWu0(self.VVkJtB)
  if not pathExists(self.controlPath):
   os.system(FFQe93("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VV8dcU()
  if fileExists(self.controlFile):
   lines = FFFfvw(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VVZAvg : version, descripton, maintainer = VVx2ku , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVnNbI , self.VVnNbI
   txt = ""
   txt += "Package: %s\n"  % self.VV2iH7(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VVZAvg : t = PLUGIN_NAME
  else    : t = self.VVnNbI
  self.VVZfr0(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VVZfr0(self.postrmFile, "echo 'Package removed.'\n")
  if self.VVZAvg : self.VVZfr0(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVx2ku))
  else    : self.VVZfr0(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVnNbI)
  if isFirstTime and not mode == self.VV8kOd:
   self.postInstAcion = 1
  txt = self.VVZ3yd(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFqXAw(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VVZ3yd(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  os.system(FFQe93("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
 def VVZfr0(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VVZ3yd(self, action):
  sep  = "echo '%s'\n" % VVI8D8
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VVEFCI(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFFfvw(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFY7FT(line, VVAgOb)
     elif not line.startswith(" ")    : line = FFY7FT(line, VVAgOb)
     else          : line = FFY7FT(line, VV5cg1)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VV5cg1
   else   : color = VVAgOb
   descr = FFY7FT(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVAgOb
     elif line.startswith((" ", "\t")) : color = VVAgOb
     elif line.startswith("#")   : color = VVBh5X
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VV0zbF(val, True)
      elif key == "Version"  : version, color = self.VV0zbF(val, False)
      elif key == "Maintainer" : maint  , color = val, VV5cg1
      elif key == "Architecture" : arch  , color = val, VV5cg1
      else:
       color = VV5cg1
      if not key == "OE" and not key.istitle():
       color = VVAgOb
     else:
      color = VV9ZlA
     txt += FFY7FT(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVIhQ3 = self.VVkJtB + packageName
   self.VVSFU8 = True
   errTxt = ""
  else:
   self.VVIhQ3  = ""
   self.VVSFU8 = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VV0zbF(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VV5cg1
  else          : return val, VVAgOb
 def VVkh3H(self):
  if not self.VVSFU8:
   FFa349(self, "Please fix Control File errors first.")
   return
  if self.VV4kar: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFSahc(self.VVyTvD, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVnNbI
  symlinkTo  = FFddC4(self.Path)
  dataDir   = self.VVyTvD.rstrip("/")
  removePorjDir = FFQe93("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFQe93("rm -f '%s'" % self.VVIhQ3) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFwwi6()
  if self.VV4kar:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFsl4Z("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVZAvg:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVyTvD == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVKuhK)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVIhQ3, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVIhQ3
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVIhQ3, FFfLXZ(result  , VVlfrr))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVyTvD, FFfLXZ(instPath, VV5cg1))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFfLXZ(failed, VVAgOb))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFsZIz(self, cmd)
class CCRtNz():
 VVuhHe  = "666"
 VVIZO0   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.menuInstance   = None
  self.VV4OkM()
 def VV4OkM(self):
  VVW1xb = CCRtNz.VV6Ees()
  if VVW1xb:
   VVa3i0 = ("Create New", self.VVDISG)
   self.menuInstance = FFLFXy(self.SELF, self.VVI0Fc, VVW1xb=VVW1xb, title=self.Title, VVa3i0=VVa3i0, VVxhca=True, VVgchu="#22222233", VVn4Mh="#22222233")
  else:
   self.VVDISG()
 def VVI0Fc(self, item):
  if item:
   bName, bRef, ndx = item
   self.VV6rcv(bName, bRef)
  else:
   CCRtNz.VVqOND(self)
 def VVDISG(self, VVlAViObj=None, item=None):
  FFsShb(self.SELF, BF(self.VVXN4d), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVXN4d(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.menuInstance:
     self.menuInstance.cancel()
    self.VV6rcv(bName, "")
   else:
    FF1ojr(self.menuInstance, "Incorrect Bouquet Name !", 2000)
    CCRtNz.VVqOND(self)
 def VV6rcv(self, bName, bRef):
  FF7Xva(self.waitMsgSELF, BF(self.VVmhqz, bName, bRef), title="Adding Services ...")
 def VVmhqz(self, bName, bRef):
  CCRtNz.VV05zS(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VVqOND(classObj):
  del classObj
 @staticmethod
 def VV05zS(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FFa349(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVLOHV + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FFRYkM(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CCRtNz.VVFETu(bRef)
   bPath = VVLOHV + bFile
  else:
   fName = CCgg3d.VV9jHr(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVLOHV + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVLOHV + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  CCRtNz.VVC8zY(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   CCRtNz.VVC8zY(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CCMxom.VVVqXw()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       os.system(FFQe93("cp -f '%s' '%s'" % (poster, picon)))
       os.system(CCsydO.VVgxpk(picon))
       break
  FFNh5K()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FFyv2f(SELF, txt, title=title)
 @staticmethod
 def VV6Ees(mode=2, showTitle=True, prefix=""):
  VVW1xb = []
  if mode in (0, 2): VVW1xb.extend(CCRtNz.VVzDLj(0, showTitle, prefix))
  if mode in (1, 2): VVW1xb.extend(CCRtNz.VVzDLj(1, showTitle, prefix))
  return VVW1xb
 @staticmethod
 def VVzDLj(mode, showTitle, prefix):
  VVW1xb = []
  lst = CCRtNz.VVfO6x(mode)
  if lst:
   if showTitle:
    VVW1xb.append(FFzfpO("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVW1xb.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVW1xb.append((item[0], item[1].toString()))
  return VVW1xb
 @staticmethod
 def VVy9TS():
  bLise = CCRtNz.VVfO6x(0)
  bLise.extend(CCRtNz.VVfO6x(1))
  return bLise
 @staticmethod
 def VVfO6x(mode=0):
  bList = []
  VVPWYL = InfoBar.instance
  VVEmtn = VVPWYL and VVPWYL.servicelist
  if VVEmtn:
   curMode = VVEmtn.mode
   CCRtNz.VVtcrb(VVEmtn, mode)
   bList.extend(VVEmtn.getBouquetList() or [])
   CCRtNz.VVtcrb(VVEmtn, curMode)
  return bList
 @staticmethod
 def VVtcrb(VVEmtn, mode):
  if not mode == VVEmtn.mode:
   if   mode == 0: VVEmtn.setModeTv()
   elif mode == 1: VVEmtn.setModeRadio()
 @staticmethod
 def VVC8zY(fPath):
  with open(fPath, "rb+") as f:
   try:
    f.seek(-1, 2)
    if ord(f.read(1)) not in (10, 13):
     f.write(b"\n")
   except:
    pass
 @staticmethod
 def VVFETu(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : ""
 @staticmethod
 def VVEd4a():
  try:
   fName = CCRtNz.VVFETu(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVLOHV, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VVyJwc():
  path = CCRtNz.VVEd4a()
  if path:
   txt = FFqXAw(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VV3TCa():
  return FFqMsP(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VVU9Ld():
  lst = []
  for b in CCRtNz.VVy9TS():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVLOHV + CCRtNz.VVFETu(bRef)
   if fileExists(path):
    lines = FFFfvw(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VVrQ8y(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VVnOH0(SID="", stripRType=False):
  if SID : patt = CCRtNz.VVrQ8y(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CCRtNz.VVy9TS():
   for service in FFqMsP(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VVzS3E():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CCRtNz.VVy9TS():
   for service in FFqMsP(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VV8V9G(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VViQsh(pathLst):
  refLst = CCRtNz.VVnOH0(CCRtNz.VVuhHe, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CCRtNz.VV8V9G(rType, CCRtNz.VVuhHe, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CCbI7Z(Screen):
 VV3NWh   = 0
 VVWYHZ  = 1
 VVIet0  = 2
 VVdmkz = 3
 VVZOID    = 20
 VV0Tdg  = None
 VVlzvY   = 0
 VVoX8x   = 1
 VVY8PX   = 2
 def __init__(self, session, VVetf7="/", mode=VV3NWh, VVVp3O="Select", width=1400, height=920, VVJmZ8=30, VVgchu="#22001111", VVn4Mh="#22000000", pickTitleBG="#11001144", pickBodyBG="#11002255", cursorBG="#06003333", gotoMovie=False, jumpToFile="", patternMode=""):
  self.skin, self.skinParam = FFXh6Y(VV2F6v, width, height, 30, 40, 20, VVgchu, VVn4Mh, VVJmZ8, barHeight=40, topRightBtns=2)
  self.session   = session
  self.VVgchu   = VVgchu
  self.VVn4Mh    = VVn4Mh
  self.pickTitleBG  = pickTitleBG
  self.pickBodyBG   = pickBodyBG
  FFwLhV(self)
  FFxDER(self["keyRed"] , "Exit")
  FFxDER(self["keyYellow"], "More Options")
  FFxDER(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVVp3O = VVVp3O
  self.jumpToFile   = jumpToFile
  self.patternMode  = patternMode
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = cursorBG
  self.multiSelectState = False
  CCbI7Z.VV0Tdg = self
  VVJLOl = None
  if patternMode:
   self.mode = self.VVdmkz
   if   patternMode == "srt"   : VVJLOl = ("^.*\.srt$"    , IGNORECASE)
   elif patternMode == "ajpSet": VVJLOl = ("^.*\/ajpanel_settings_" , 0    )
   elif patternMode == "poster": VVJLOl = ("^.*\.(jpg|png)$"    , IGNORECASE)
   elif patternMode == "movies": VVJLOl = ("^.*\.(%s)$" % "|".join(CCDiIK.VVGjn5()["mov"]), IGNORECASE)
   else      : VVJLOl = None
  if self.mode in (self.VVIet0, self.VVdmkz):
   FFxDER(self["keyRed"], "Cancel")
  if   self.jumpToFile       : VVWuP8, self.VVetf7 = True , FFSahc(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VVWuP8, self.VVetf7 = True , CCbI7Z.VVzTch(self)[1] or "/"
  elif self.mode == self.VV3NWh  : VVWuP8, self.VVetf7 = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVIet0 : VVWuP8, self.VVetf7 = False, VVetf7
  elif self.mode == self.VVdmkz : VVWuP8, self.VVetf7 = True , VVetf7
  else           : VVWuP8, self.VVetf7 = True , VVetf7
  self.VVetf7 = FFnWu0(self.VVetf7)
  self["myMenu"] = CCDiIK(  directory   = None
         , VVJLOl = VVJLOl
         , VVWuP8   = VVWuP8
         , VVCkTv = True
         , VVyCBb = True
         , VVExc6   = self.skinParam["width"]
         , VVJmZ8   = self.skinParam["bodyFontSize"]
         , VVJ5AH  = self.skinParam["bodyLineH"] )
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVi1M6    ,
   "red" : self.VV1BW5   ,
   "green" : self.VVY4h3,
   "yellow": self.VVKkdF  ,
   "blue" : self.VVL4MY ,
   "menu" : self.VVaDqn  ,
   "info" : self.VVWF7Q  ,
   "cancel": self.VVjNGE    ,
   "pageUp": self.VVN78d   ,
   "chanUp": self.VVN78d
  }, -1)
  FFoiwi(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VV6jBj)
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  CCbI7Z.VV0Tdg = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VV6jBj)
  FF8TfI(self)
  FFKauM(self["myMenu"], bg=self.cursorBG)
  FFvDt2(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVIet0, self.VVdmkz):
   FFxDER(self["keyGreen"], self.VVVp3O)
   self.VV8a3B(self.VVoX8x)
  self.VV6jBj()
  w  = self["myMenu"].instance.size().width()
  h  = self["myMenu"].instance.size().height()
  pos  = self["myMenu"].getPosition()
  part = self["myMenu"].instance.size().height() % self.skinParam["bodyLineH"]
  half = int(part / 2)
  self["myMenu"].instance.resize(eSize(*(w, h - part)))
  self["myMenu"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.VVcuMs(self.VVetf7) > self.bigDirSize: FF7Xva(self, self.VVCWjh, title="Changing directory...")
  else              : self.VVCWjh()
 def VVCWjh(self):
  if self.jumpToFile : self.VVf2v1(self.jumpToFile)
  elif self.gotoMovie : self.VV1YPe(chDir=False)
  else    : self["myMenu"].VVsove(self.VVetf7)
 def VV9fSx(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VV1IqV(self):
  FF7Xva(self, self.VV9YXs, title="Refreshing list ...")
 def VV9YXs(self):
  isSel = self["myMenu"].VVh50i()
  if not isSel:
   self.VVvpg3(False)
  FFppy1()
 def VVcuMs(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VVi1M6(self):
  if self.multiSelectState:
   ok = self["myMenu"].VVURdd()
   if ok : self["keyBlue"].setText(self.VVgwpa())
   else : FF1ojr(self, "Cannot select item", 500)
  elif self["myMenu"].VVyaCa(): self.VV8Qwh()
  else       : self.VVNwKD()
 def VVN78d(self):
  if self.multiSelectState:
   FF1ojr(self, "Disable Multi-Select first", 1000)
  else:
   self["myMenu"].moveToIndex(0)
   if self["myMenu"].VVwTWT():
    self.VV8Qwh()
 def VV8Qwh(self, isDirUp=False):
  if self["myMenu"].VVyaCa():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VVLQ1H(self.VVlAVi())
   if self.VVcuMs(path) > self.bigDirSize : FF7Xva(self, self.VVpd7Q, title="Changing directory...")
   else           : self.VVpd7Q()
 def VVpd7Q(self):
  self["myMenu"].descent()
  self.VV6jBj()
 def VVjNGE(self):
  if   self.multiSelectState     : self.VVvpg3(False, True)
  elif CFG.FileManagerExit.getValue() == "e" : self.VV1BW5()
  else          : self.VVN78d()
 def VV1BW5(self):
  if not FFRNqp(self):
   self.close("")
 def VVY4h3(self):
  path = self.VVLQ1H(self.VVlAVi())
  if self.mode == self.VVIet0:
   self.close(path)
  elif self.mode == self.VVdmkz:
   if os.path.isfile(path) : self.close(path)
   else     : FF1ojr(self, "Cannot access this file", 1000)
 def VVWF7Q(self):
  FF7Xva(self, self.VVUn9b, title="Calculating size ...")
 def VVUn9b(self):
  path = self.VVLQ1H(self.VVlAVi())
  param = self.VVf2CI(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFyJfo("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCbI7Z.VVznyV(path)
     freeSize = CCbI7Z.VVREmO(path)
     size = totSize - freeSize
     totSize  = CCbI7Z.VVr8MR(totSize)
     freeSize = CCbI7Z.VVr8MR(freeSize)
    else:
     size = FFioKk(path)
   usedSize = CCbI7Z.VVr8MR(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFY7FT(pathTxt, VV9ZlA) + "\n"
   if slBroken : fileTime = self.VV6P5W(path)
   else  : fileTime = self.VVG2WZ(path)
   def VVObU9(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVObU9("Path"    , pathTxt)
   txt += VVObU9("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVObU9("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVObU9("Total Size"   , "%s" % totSize)
    txt += VVObU9("Used Size"   , "%s" % usedSize)
    txt += VVObU9("Free Size"   , "%s" % freeSize)
   else:
    txt += VVObU9("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVObU9("Owner"    , owner)
   txt += VVObU9("Group"    , group)
   txt += VVObU9("Perm. (User)"  , permUser)
   txt += VVObU9("Perm. (Group)"  , permGroup)
   txt += VVObU9("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVObU9("Perm. (Ext.)" , permExtra)
   txt += VVObU9("iNode"    , iNode)
   txt += VVObU9("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVI8D8, VVI8D8)
    txt += hLinkedFiles
   txt += self.VVZHhh(path)
  else:
   FFa349(self, "Cannot access information !")
  if len(txt) > 0:
   FFyv2f(self, txt)
 def VVf2CI(self, path):
  path = path.strip()
  path = FFddC4(path)
  result = FFyJfo("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVPFQ3(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVPFQ3(perm, 1, 4)
   permGroup = VVPFQ3(perm, 4, 7)
   permOther = VVPFQ3(perm, 7, 10)
   permExtra = VVPFQ3(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFuVMf("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVZHhh(self, path):
  txt  = ""
  res  = FFyJfo("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFY7FT("File Attributes:", VVHiet), txt)
  return txt
 def VVG2WZ(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFXtJp(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFXtJp(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFXtJp(os.path.getctime(path))
  return txt
 def VV6P5W(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFyJfo("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFyJfo("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFyJfo("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVLQ1H(self, currentSel):
  currentDir  = self["myMenu"].VV2kM5()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVyaCa():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVlAVi(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VV6jBj(self):
  path = self.VVLQ1H(self.VVlAVi())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VVgFA7()
  if self.mode == self.VV3NWh:
   if len(path) > 0: self["keyMenu"].show()
   else   : self["keyMenu"].hide()
  if self.mode == self.VVdmkz:
   path = self.VVLQ1H(self.VVlAVi())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VVaDqn(self):
  color1 = VVPpUd
  color2 = VVJ2KG
  color3 = VVW6qu
  totSel = 0
  menuW = 1000
  title = "Options"
  VVW1xb= []
  if self.multiSelectState:
   menuW = 850
   totSel = self["myMenu"].VVSsXY()
   if totSel > 0:
    if iTar:
     txt1 = "Archive to .tar.gz"
     txt2 = " (Preserve Path Structure)"
     title = "Options  (%d item%s)" % (totSel, FFmJCK(totSel))
     VVW1xb.append((color1 + txt1     , "VVqbbK1" ))
     VVW1xb.append((color1 + txt1 + txt2   , "VVqbbK2" ))
     VVW1xb.append(VVswUs)
    VVW1xb.append(("[6] Copy"       , "copyBulk" ))
    VVW1xb.append(("[7] Move"       , "moveBulk" ))
    VVW1xb.append(("[8] %sDELETE" % VV9ZlA , "VVkovB" ))
   else:
    FF1ojr(self, "Nothing selected", 700)
    return
  elif self.mode in (self.VVIet0, self.VVdmkz):
   VVW1xb.append(("Properties"           , "properties" ))
   VVW1xb.append(VVswUs)
   VVW1xb.append((color3 + "Create New Directory (in current directory)" , "createNewDir"))
  else:
   menuW = 1000
   path  = self.VVLQ1H(self.VVlAVi())
   isEditable = self["myMenu"].VVs41A()
   VVW1xb.append(("Properties", "properties"))
   if os.path.isdir(path):
    if isEditable:
     VVW1xb.append(VVswUs)
     VVW1xb.append((color1 + "Archiving / Packaging", "VVPK7C_dir"))
   elif os.path.isfile(path):
    selFile = self.VVlAVi()
    isArch = selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar"))
    if not isArch:
     VVW1xb.append((color1 + "Archive ...", "VVPK7C_file"))
    isText = False
    txt = ""
    if   isArch            : VVW1xb.extend(self.VVSMyo(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith(".m3u")       : VVW1xb.extend(self.VVRsd0(True))
    elif selFile.endswith(".sh"):
     VVW1xb.extend(self.VVHo8b(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CCbI7Z.VVchO2(path):
     VVW1xb.append(VVswUs)
     VVW1xb.append((color2 + "View"     , "textView_def"))
     VVW1xb.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVW1xb.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VVVeDa(path) == "pic":
     VVW1xb.append(VVswUs)
     VVW1xb.append((color2 + "Set as PIcon for current channel" , "VVRWL1" ))
     if FFeWq1("ffmpeg") and selFile.lower().endswith((".jpg", ".png")):
      VVW1xb.append(VVswUs)
      VVW1xb.append((color2 + "Convert to MVI (1280 x 720 )" , "VVbvtUHd"   ))
      VVW1xb.append((color2 + "Convert to MVI (1920 x 1080)" , "VVbvtUFhd"   ))
    elif selFile.endswith(CCbI7Z.VVxgYx()):
     if selFile.endswith(".mvi"):
      if FFeWq1("showiframe"):
       VVW1xb.append(VVswUs)
       VVW1xb.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVW1xb.append(VVswUs)
      VVW1xb.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVW1xb.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
      VVW1xb.append((color2 + "Play with ..."       , "playWith"    ))
    if isText:
     VVW1xb.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVW1xb.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVW1xb.append((color1 + "Convert Line-Breaks to Unix Format..." , "VVoenj" ))
    if len(txt) > 0:
     VVW1xb.append(VVswUs)
     VVW1xb.append((color1 + txt, "VVNwKD"))
   VVW1xb.append(VVswUs)
   VVW1xb.append(("[4] Create SymLink", "VV6Oj0"))
   if isEditable:
    VVW1xb.append(("[5] Rename"      , "VV5G75" ))
    VVW1xb.append(("[6] Copy"       , "copyFileOrDir" ))
    VVW1xb.append(("[7] Move"       , "moveFileOrDir" ))
    VVW1xb.append(("[8] %sDELETE" % VV9ZlA , "VVkRLp" ))
    if fileExists(path):
     VVW1xb.append(VVswUs)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVW1xb.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVW1xb.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVW1xb.append((chmodTxt + "777)", "chmod777"))
   VVW1xb.append(VVswUs)
   VVW1xb.append((color3 + "Create New File (in current directory)"  , "createNewFile" ))
   VVW1xb.append((color3 + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCbI7Z.VVzTch(self)
   if fPath:
    VVW1xb.append(VVswUs)
    VVW1xb.append((color2 + "Go to Current Movie Dir", "VV1YPe"))
  FFLFXy(self, self.VVGfLJ, width=menuW, height=1050, title=title, VVW1xb=VVW1xb, rcuSearch=False, VVgchu="#00101020", VVn4Mh="#00101A2A")
 def VVGfLJ(self, item=None):
  if item is not None:
   path = self.VVLQ1H(self.VVlAVi())
   selFile = self.VVlAVi()
   if   item == "VVqbbK1"    : self.VVqbbK(False)
   if   item == "VVqbbK2"    : self.VVqbbK(True)
   elif item == "copyBulk"     : self.VVk1PZ(False)
   elif item == "moveBulk"     : self.VVk1PZ(True)
   elif item == "VVkovB"    : self.VVkovB()
   elif item == "properties"    : self.VVWF7Q()
   elif item == "VVPK7C_dir" : self.VVPK7C(path, True)
   elif item == "VVPK7C_file" : self.VVPK7C(path, False)
   elif item == "VVpkaP"  : self.VVpkaP(path)
   elif item == "VVtPMZ"  : self.VVtPMZ(path)
   elif item.startswith("extract_")  : self.VVxZHu(path, selFile, item)
   elif item.startswith("script_")   : self.VVHs4S(path, selFile, item)
   elif item.startswith("m3u_")   : self.VV0TgD(path, selFile, item)
   elif item.startswith("textView_def") : FFxRdc(self, path)
   elif item.startswith("textView_enc") : self.VVO1G1(path)
   elif item.startswith("text_Edit")  : FF7Xva(self, BF(CCtuLp, self, path), title="Opening File ...")
   elif item.startswith("textSave_encUtf8"): self.VVl8Wx(path, "Save as UTF-8"   , True)
   elif item.startswith("textSave_encOthr"): self.VVl8Wx(path, "Save as Other Encoding", False)
   elif item.startswith("VVoenj") : self.VVoenj(path)
   elif item == "viewAsBootlogo"   : self.VVcXpl(path, True)
   elif item == "addMovieToBouquet"  : self.VV9oQp(path, False)
   elif item == "addAllMoviesToBouquet" : self.VV9oQp(path, True)
   elif item == "playWith"     : self.VV2rUu(path)
   elif item == "VVRWL1" : self.VVRWL1(path)
   elif item == "VVbvtUHd"   : FF7Xva(self, BF(self.VVbvtU, path, False))
   elif item == "VVbvtUFhd"   : FF7Xva(self, BF(self.VVbvtU, path, True))
   elif item == "VV6Oj0"   : self.VV6Oj0(path, selFile)
   elif item == "VV5G75"   : self.VV5G75(path, selFile)
   elif item == "copyFileOrDir"   : self.VVJxHS(path, False)
   elif item == "moveFileOrDir"   : self.VVJxHS(path, True)
   elif item == "VVkRLp"   : self.VVkRLp(path, selFile)
   elif item == "chmod644"     : self.VVWRNF(path, selFile, "644")
   elif item == "chmod755"     : self.VVWRNF(path, selFile, "755")
   elif item == "chmod777"     : self.VVWRNF(path, selFile, "777")
   elif item == "createNewFile"   : self.VVVjhf(path, True)
   elif item == "createNewDir"    : self.VVVjhf(path, False)
   elif item == "VV1YPe"   : self.VV1YPe()
   elif item == "VVNwKD"    : self.VVNwKD()
 def VVNwKD(self):
  if self.mode == self.VVdmkz and not self.patternMode == "poster":
   return
  selFile = self.VVlAVi()
  path  = self.VVLQ1H(selFile)
  if os.path.isfile(path):
   VVKINn  = []
   category = self["myMenu"].VVVeDa(path)
   if   category == "pic"      : self.VVoSvH(path)
   elif category == "txt"      : FFxRdc(self, path)
   elif category in ("tar", "zip", "rar")  : self.VV7ivl(path, selFile)
   elif category == "scr"      : self.VVoCXg(path, selFile)
   elif category == "m3u"      : self.VVX3f2(path, selFile)
   elif category in ("ipk", "deb")    : self.VVri5m(path, selFile)
   elif category in ("mov", "mus")    : self.VVcXpl(path)
   elif not CCbI7Z.VVchO2(path) : FFxRdc(self, path)
 def VVoSvH(self, path):
  curIndex = 0
  curFile = os.path.basename(path)
  lst = []
  for item in self["myMenu"].list:
   if not item[0][1]:
    category = self["myMenu"].VVVeDa(item[1][7])
    if category == "pic":
     if curFile == item[1][7]:
      curIndex = len(lst)
     lst.append(item[1][7])
  CCFA9F.VVK9Qe(self, path, fileList=lst, curIndex=curIndex, cbFnc=self.VVrihk)
 def VVrihk(self, path):
  self.VVf2v1(path)
 def VVcXpl(self, path, asLogo=False):
  if asLogo : CClprH.VVKSBf(self, path)
  else  : FF7Xva(self, BF(self.VV7vnp, self, path), title="Playing Media ...")
 def VVL4MY(self):
  if self["keyBlue"].getVisible():
   VV6fdw = self.VVCtj1()
   if VV6fdw:
    path = self.VVLQ1H(self.VVlAVi())
    enableGreenBtn = False if path in self.VVCtj1() else True
    newList = []
    for line in VV6fdw:
     newList.append((line, line))
    VVszaU  = ("Delete"    , self.VVkUTB    )
    VV0vau  = ("Add Current Dir"   , BF(self.VV89kE, path) ) if enableGreenBtn else None
    VVa3i0 = ("Move Up"     , self.VVFBn1    )
    VVkjyo  = ("Move Down"   , self.VVZMQI    )
    self.bookmarkMenu = FFLFXy(self, self.VV6lzl, width=1200, title="Bookmarks", VVW1xb=newList, minRows=10 ,VVszaU=VVszaU, VV0vau=VV0vau, VVa3i0=VVa3i0, VVkjyo=VVkjyo, VVgchu="#00000022", VVn4Mh="#00000022")
 def VVkUTB(self, menuInstance=None, path=None):
  VV6fdw = self.VVCtj1()
  if VV6fdw:
   while path in VV6fdw:
    VV6fdw.remove(path)
   self.VVJJwe(VV6fdw)
  if self.bookmarkMenu:
   self.bookmarkMenu.VVMswT(VV6fdw)
   self.bookmarkMenu.VVBi8D(("Add Current Dir", BF(self.VV89kE, path)))
  else:
   FF1ojr(self, "Removed", 800)
  self.VVgFA7()
 def VV89kE(self, path, menuInstance=None, item=None):
  VV6fdw = self.VVCtj1()
  if len(VV6fdw) >= self.VVZOID:
   FFa349(SELF, "Max bookmarks reached (max=%d)." % self.VVZOID)
  elif not path in VV6fdw:
   newList = [path] + VV6fdw
   self.VVJJwe(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VVMswT(newList)
    self.bookmarkMenu.VVBi8D()
   else:
    FF1ojr(self, "Added", 800)
  self.VVgFA7()
 def VVFBn1(self, VVlAViObj, path):
  if self.bookmarkMenu:
   VV6fdw = self.bookmarkMenu.VVDrwZ(True)
   if VV6fdw:
    self.VVJJwe(VV6fdw)
 def VVZMQI(self, VVlAViObj, path):
  if self.bookmarkMenu:
   VV6fdw = self.bookmarkMenu.VVDrwZ(False)
   if VV6fdw:
    self.VVJJwe(VV6fdw)
 def VV6lzl(self, folder=None):
  if folder:
   folder = FFnWu0(folder)
   self["myMenu"].VVsove(folder)
   self["myMenu"].moveToIndex(0)
  self.VV6jBj()
 def VVCtj1(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VVnLL6(self):
  return True if VVCtj1() else False
 def VVJJwe(self, VV6fdw):
  line = ",".join(VV6fdw)
  FFxMsu(CFG.browserBookmarks, line)
 def VVf2v1(self, path):
  if fileExists(path):
   fDir  = FFnWu0(os.path.dirname(path))
   if fDir:
    self["myMenu"].VVsove(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FF1ojr(self, "Not found", 1000)
 def VV1YPe(self, chDir=True):
  fPath, fDir, fName = CCbI7Z.VVzTch(self)
  self.VVf2v1(fPath)
 def VVKkdF(self):
  path = self.VVLQ1H(self.VVlAVi())
  isAdd = False if path in self.VVCtj1() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  c1, c2 , c3 = VV5cg1, VVTMjp, VVJ2KG
  VVW1xb = []
  VVW1xb.append(("Find Files ..." , "find"))
  VVW1xb.append(("Sort ..."   , "sort"))
  VVW1xb.append(VVswUs)
  if isAdd: VVW1xb.append((c1 + "Add %s Dir to Bookmarks"  % dirTxt, "addBM"))
  else : VVW1xb.append((c1 + "Remove %s Dir from Bookmarks" % dirTxt, "remBM"))
  VVW1xb.append(VVswUs)
  VVW1xb.append(    (c2 + 'Set %s Dir as "Startup Dir"' % dirTxt, "start"))
  if self.mode == self.VV3NWh:
   VVW1xb.append(VVswUs)
   if self.multiSelectState: VVW1xb.append( (c3 + "Disable Multi-Select ", "multiOff"))
   else     : VVW1xb.append( (c3 + "Enable Multi-Select"  , "multiOn" ))
   VVW1xb.append(       (c3 + "Select all"    , "selAll"  ))
  FFLFXy(self, BF(self.VVTGrM, path), width=750, title="More Options", VVW1xb=VVW1xb, VVgchu="#00221111", VVn4Mh="#00221111")
 def VVTGrM(self, path, item):
  if item:
   if   item == "find"  : self.VVaChI(path)
   elif item == "sort"  : self.VVImg5()
   elif item == "addBM" : self.VV89kE(path)
   elif item == "remBM" : self.VVkUTB(None, path)
   elif item == "start" : self.VVW1ab(path)
   elif item == "multiOn" : self.VVvpg3(True)
   elif item == "multiOff" : self.VVvpg3(False)
   elif item == "selAll" : self.VVvpg3(True, True)
 def VVvpg3(self, isOn, isAll=False):
  self.multiSelectState = isOn
  if isAll or not isOn:
   FF7Xva(self, BF(self["myMenu"].VVRezb, isOn), title="Selecting ..." if isOn else "Unselecting ...")
  self.VV8a3B(self.VVY8PX if isOn else self.VVlzvY)
 def VV8a3B(self, mode=0):
  if   mode == self.VVoX8x : titBg, bodBg = self.pickTitleBG, self.pickBodyBG
  elif mode == self.VVY8PX: titBg, bodBg = "#01883366", "#11002233"
  else        : titBg, bodBg = self.VVgchu, self.VVn4Mh
  FF0e9t(self["myTitle"], titBg)
  FF0e9t(self["myBar"], titBg)
  FF0e9t(self["myBody"], bodBg)
  FF0e9t(self["myMenu"], bodBg)
  if self.multiSelectState: bg, txt = "#01883366", self.VVgwpa()
  else     : bg, txt = BAR_BUTTONS_COLORS[3], "Bookmarks"
  FFxDER(self["keyBlue"], txt)
  FF0e9t(self["keyBlue"], bg)
  self.VVgFA7()
 def VVgwpa(self):
  return "Selected Items = %d" % self["myMenu"].VVSsXY()
 def VVgFA7(self):
  if self.VVCtj1() or self.multiSelectState: self["keyBlue"].show()
  else            : self["keyBlue"].hide()
 def VVaChI(self, path):
  VVW1xb = []
  VVW1xb.append(("Find in Current Directory"    , "findCur"  ))
  VVW1xb.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVW1xb.append(("Find in all Storage Systems"    , "findAll"  ))
  FFLFXy(self, BF(self.VVEdUm, path), width=700, title="Find File/Pattern", VVW1xb=VVW1xb, VVxhca=True, VVuwvk=True, VVgchu="#00221111", VVn4Mh="#00221111")
 def VVEdUm(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VVX7oA(0, path, title)
   elif item == "findCurR" : self.VVX7oA(1, path, title)
   elif item == "findAll" : self.VVX7oA(2, path, title)
 def VVX7oA(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FFsShb(self, BF(self.VVJhUe, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VVJhUe(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FFxMsu(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FF1ojr(self, "No entery", 1500)
   elif badLst  : FF1ojr(self, "Too many file !", 1500)
   else   : FF7Xva(self, BF(self.VVLycq, mode, path, title, filePatt), title="Searching ...", clearMsg=False)
 def VVLycq(self, mode, path, title, filePatt):
  FF1ojr(self)
  lst = FF94gP(FFHR0m("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   err = CCbI7Z.VVPSgD(lst)
   if err:
    FFa349(self, err)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VVd4CR = (""     , self.VVSXpA , [])
    VVsTsL = ("Go to File Location", self.VVQRrI  , [])
    FFEM8S(self, None, title="%s : %s" % (title, filePatt), header=header, VV6fdw=lst, VVHqY6=widths, VVJmZ8=26, VVd4CR=VVd4CR, VVsTsL=VVsTsL)
  else:
   FF1ojr(self, "Not found !", 2000)
 def VVQRrI(self, VVXOwS, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVXOwS.cancel()
   self.VVf2v1(path)
  else:
   FF1ojr(VVXOwS, "Path not found !", 1000)
 def VVSXpA(self, VVXOwS, title, txt, colList):
  txt = "%s\n%s\n\n" % (FFY7FT("File:"  , VVJ2KG), colList[0])
  txt += "%s\n%s"  % (FFY7FT("Directory:", VVJ2KG), FFnWu0(colList[1]))
  FFyv2f(VVXOwS, txt, title=title)
 def VVImg5(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVSSzO()
  VVW1xb = []
  VVW1xb.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVW1xb.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVW1xb.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVW1xb.append(("Type\t%s" % typeTxt, "typeAlp"))
  VVkjyo = ("Mix", BF(self.VVVV2s, True))
  FFLFXy(self, BF(self.VV8h4A, False), barText=txt, width=650, title="Sort Options", VVW1xb=VVW1xb, VVkjyo=VVkjyo, VVuwvk=True, VVgchu="#00221111", VVn4Mh="#00221111")
 def VVVV2s(self, isMix, menuInstance, item):
  self.VV8h4A(True, item)
 def VV8h4A(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVSSzO()
   title = "Sorting ... "
   if   item == "nameAlp": FF7Xva(self, BF(self["myMenu"].VVDHdO, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FF7Xva(self, BF(self["myMenu"].VVDHdO, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FF7Xva(self, BF(self["myMenu"].VVDHdO, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FF7Xva(self, BF(self["myMenu"].VVDHdO, typeMode , isMix, False), title=title)
 def VVW1ab(self, path):
  if not os.path.isdir(path):
   path = FFSahc(path, True)
  FFxMsu(CFG.browserStartPath, path)
  FF1ojr(self, "Done", 500)
 def VVgIAd(self, selFile, VVusVD, command):
  FF8XzP(self, BF(FFsZIz, self, command, VVvcJy=self.VV1IqV), "%s\n\n%s" % (VVusVD, selFile))
 def VVSMyo(self, path, calledFromMenu):
  destPath = self.VV8Lxz(path)
  lastPart = FFmKBR(destPath)
  VVW1xb = []
  if calledFromMenu:
   VVW1xb.append(VVswUs)
   color = VVJ2KG
  else:
   color = ""
  VVW1xb.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVW1xb.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVW1xb.append((color + "Extract Here"            , "extract_here"  ))
  if iTar and iZip:
   if path.endswith(".zip"):
    if not calledFromMenu: VVW1xb.append(VVswUs)
    VVW1xb.append((color + "Convert .zip to .tar.gz"       , "VVpkaP" ))
   elif path.endswith(".tar.gz"):
    if not calledFromMenu: VVW1xb.append(VVswUs)
    VVW1xb.append((color + "Convert .tar.gz to .zip"       , "VVtPMZ" ))
  return VVW1xb
 def VV7ivl(self, path, selFile):
  FFLFXy(self, BF(self.VVxZHu, path, selFile), title="Compressed File Options", VVW1xb=self.VVSMyo(path, False))
 def VVxZHu(self, path, selFile, item=None):
  if item is not None:
   parent  = FFSahc(path, False)
   destPath = self.VV8Lxz(path)
   lastPart = FFmKBR(destPath)
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVI8D8
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFsl4Z("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFsl4Z("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVI8D8, VVI8D8)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFmzjA(self, cmd)
   elif path.endswith(".zip"):
    if item == "VVpkaP" : self.VVpkaP(path)
    else       : self.VVWlLG(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "VVtPMZ" and path.endswith(".tar.gz"):
    self.VVtPMZ(path)
   elif path.endswith(".rar"):
    self.VVD3bo(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFQe93("mkdir '%s'"   % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVgIAd(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVgIAd(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FFSahc(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVgIAd(selFile, "Extract Here ?"      , cmd)
 def VV8Lxz(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVWlLG(self, item, path, parent, destPath, VVusVD):
  FF8XzP(self, BF(self.VVvxMH, item, path, parent, destPath), VVusVD)
 def VVvxMH(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVI8D8
  cmd  = FFsl4Z("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFfLXZ(destPath, VVlfrr))
  cmd +=   sep
  cmd += "fi;"
  FFDbYu(self, cmd, VVvcJy=self.VV1IqV)
 def VVD3bo(self, item, path, parent, destPath, VVusVD):
  FF8XzP(self, BF(self.VVop1C, item, path, parent, destPath), VVusVD)
 def VVop1C(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFnWu0(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVI8D8
  cmd  = FFsl4Z("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFfLXZ(destPath, VVlfrr))
  cmd +=   sep
  cmd += "fi;"
  FFDbYu(self, cmd, VVvcJy=self.VV1IqV)
 def VVHo8b(self, addSep=False):
  VVW1xb = []
  if addSep:
   VVW1xb.append(VVswUs)
  VVW1xb.append((VVJ2KG + "View Script File"  , "script_View"  ))
  VVW1xb.append((VVJ2KG + "Execute Script File" , "script_Execute" ))
  VVW1xb.append((VVJ2KG + "Edit"     , "script_Edit"  ))
  return VVW1xb
 def VVoCXg(self, path, selFile):
  FFLFXy(self, BF(self.VVHs4S, path, selFile), title="Script File Options", VVW1xb=self.VVHo8b())
 def VVHs4S(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFxRdc(self, path)
   elif item == "script_Execute" : self.VVgIAd(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCtuLp(self, path)
 def VVRsd0(self, addSep=False):
  VVW1xb = []
  if addSep:
   VVW1xb.append(VVswUs)
  VVW1xb.append((VVJ2KG + "Browse IPTV Channels" , "m3u_Browse" ))
  VVW1xb.append((VVJ2KG + "Edit"     , "m3u_Edit" ))
  VVW1xb.append((VVJ2KG + "View"     , "m3u_View" ))
  return VVW1xb
 def VVX3f2(self, path, selFile):
  FFLFXy(self, BF(self.VV0TgD, path, selFile), title="M3U/M3U8 File Options", VVW1xb=self.VVRsd0())
 def VV0TgD(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FF7Xva(self, BF(self.session.open, CCgg3d, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCtuLp(self, path)
   elif item == "m3u_View"  : FFxRdc(self, path)
 def VVO1G1(self, path):
  if fileExists(path) : FF7Xva(self, BF(CCAUx4.VVqaxk, self, path, BF(self.VVhTwO, path)), title="Loading Codecs ...", clearMsg=False)
  else    : FFRYkM(self, path)
 def VVhTwO(self, path, item=None):
  if item:
   FFxRdc(self, path, encLst=item)
 def VVl8Wx(self, path, title, asUtf8):
  if fileExists(path) : FF7Xva(self, BF(CCAUx4.VVqaxk, self, path, BF(self.VViyBT, path, title, asUtf8), title="Original Encoding"), clearMsg=False, title="Loading Codecs ...")
  else    : FFRYkM(self, path)
 def VViyBT(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8 : self.VVpfIt(path, title, fromEnc, "UTF-8")
   else  : CCAUx4.VVqaxk(self, path,  BF(self.VVpfIt, path, title, fromEnc), onlyWorkingEnc=False, title="Convert to Encoding")
 def VVpfIt(self, path, title, fromEnc, toEnc):
  if toEnc:
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FFY7FT("Successful\n\n", VVlfrr)
      txt += FFY7FT("From Encoding (%s):\n" % fromEnc, VVzCWu)
      txt += "%s\n\n" % path
      txt += FFY7FT("To Encoding (%s):\n" % toEnc, VVzCWu)
      txt += "%s\n\n" % outFile
      FFyv2f(self, txt, title=title)
    except:
     FFa349(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FF1ojr(self, "Cannot open file", 2000)
  self.VV1IqV()
 def VVoenj(self, path):
  title = "File Line-Break Conversion"
  FF8XzP(self, BF(self.VV5bN4, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VV5bN4(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FFY7FT("File converted:", VVlfrr), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FF5nWa(self, txt, title=title)
  else:
   FFRYkM(self, path, title=title)
 def VVWRNF(self, path, selFile, newChmod):
  FF8XzP(self, BF(self.VVNvAv, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVNvAv(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVeBpK)
  result = FFyJfo(cmd)
  if result == "Successful" : FF5nWa(self, result)
  else      : FFa349(self, result)
 def VV6Oj0(self, path, selFile):
  parent = FFSahc(path, False)
  self.session.openWithCallback(self.VVv27M, BF(CCbI7Z, mode=CCbI7Z.VVIet0, VVetf7=parent, VVVp3O="Create Symlink here"))
 def VVv27M(self, newPath):
  if len(newPath) > 0:
   target = self.VVLQ1H(self.VVlAVi())
   target = FFddC4(target)
   linkName = FFmKBR(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFnWu0(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFa349(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FF8XzP(self, BF(self.VVGbcy, target, link), "Create Soft Link ?\n\n%s" % txt, VVJRkN=True)
 def VVGbcy(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVeBpK)
  result = FFyJfo(cmd)
  if result == "Successful" : FF5nWa(self, result)
  else      : FFa349(self, result)
 def VV5G75(self, path, selFile):
  lastPart = FFmKBR(path)
  FFsShb(self, BF(self.VVwLjp, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVwLjp(self, path, selFile, VVsHNL):
  if VVsHNL:
   parent = FFSahc(path, True)
   if os.path.isdir(path):
    path = FFddC4(path)
   newName = parent + VVsHNL
   cmd = "mv '%s' '%s' %s" % (path, newName, VVeBpK)
   if VVsHNL:
    if selFile != VVsHNL:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FF8XzP(self, BF(self.VVBJzy, cmd), message, title="Rename file?")
    else:
     FFa349(self, "Cannot use same name!", title="Rename")
 def VVBJzy(self, cmd):
  result = FFyJfo(cmd)
  if "Fail" in result:
   FFa349(self, result)
  self.VV1IqV()
 def VVqbbK(self, preserve):
  title="Archive to .tar.gz"
  self.session.open(CCvBnC, barTheme=CCvBnC.VVjpsh, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VV26sX, title, preserve)
      , VVnRGv = BF(self.VVmBrb, title))
 def VV26sX(self, title, preserve, VVhsRS):
  totSel = self["myMenu"].VVSsXY()
  totOk = totFail = 0
  VVhsRS.VVBrFN(totSel)
  VVhsRS.VVLNy3 = ["", totSel, totOk, totFail, ""]
  VVhsRS.VVhwt2("Prepareing targz file")
  curDir = self["myMenu"].VV2kM5()
  lastPart = FFmKBR(curDir) or "archive"
  outF = os.path.join(curDir, lastPart + ".tar.gz")
  c = 0
  while fileExists(outF):
   c += 1
   outF = os.path.join(curDir, lastPart + "_%d.tar.gz" % c)
  totOk = totFail = 0
  path = ""
  try:
   with iTar.open(outF, mode="w:gz") as tarF:
    for row in self["myMenu"].list:
     if not VVhsRS or VVhsRS.isCancelled:
      return
     if row[2][6]:
      VVhsRS.VVwvD4(1)
      name  = FFddC4(row[0][0])
      lastPath = FFmKBR(name)
      path  = os.path.join(curDir, name)
      tarF.add(path, arcname=None if preserve else lastPath)
      totOk += 1
      if VVhsRS:
       VVhsRS.VVLNy3 = [outF, totSel, totOk, totFail, path]
       VVhsRS.VVd8Ml(totOk, lastPath)
  except:
   totFail += 1
   if VVhsRS:
    VVhsRS.VVLNy3 = [outF, totSel, totOk, totFail, path]
 def VVmBrb(self, title, VVL4pA, VVLNy3, threadCounter, threadTotal, threadErr):
  outF, totSel, totOk, totFail, path = VVLNy3
  txt  = "%s:\n%s\n\n"   % (FFY7FT("Output File", VVlfrr), outF)
  txt += "Total\t: %d\n"  % totSel
  txt += "Archived\t: %d\n" % totOk
  if totFail   : txt += FFY7FT("Failed\t: %d\n" % totFail, VV9ZlA)
  if not VVL4pA: txt += "%s\n%s" % (FFY7FT("\nCancelled while copying:", VV9ZlA), path)
  FFyv2f(self, txt, title=title)
  self.VV1IqV()
 def VVk1PZ(self, isMove):
  self.session.openWithCallback(BF(self.VVXlCC, isMove), BF(CCbI7Z, mode=CCbI7Z.VVIet0, VVetf7=self["myMenu"].VV2kM5(), VVVp3O="Move to here" if isMove else "Paste here"))
 def VVXlCC(self, isMove, newPath):
  if newPath:
   if isMove : title, action = "Move Items", "Moved"
   else  : title, action = "Copy Items", "Copied"
   self.session.open(CCvBnC, barTheme=CCvBnC.VVjpsh, titleBg="#22003344", bodyBg="#22001122"
       , titlePrefix = title
       , fncToRun  = BF(self.VVzSe8, title, action, isMove, newPath)
       , VVnRGv = BF(self.VVqqH1, title, action, isMove, newPath))
 def VVzSe8(self, title, action, isMove, newPath, VVhsRS):
  curDir = self["myMenu"].VV2kM5()
  totOk = totFail = 0
  totSel = self["myMenu"].VVSsXY()
  if isMove: cmd = "mv -f"
  else  : cmd = "cp -frp"
  VVhsRS.VVBrFN(totSel)
  VVhsRS.VVLNy3 = [totSel, totOk, totFail, ""]
  for row in self["myMenu"].list:
   if not VVhsRS or VVhsRS.isCancelled:
    return
   if row[2][6]:
    VVhsRS.VVwvD4(1)
    VVhsRS.VVyVdp(action, totOk, FFmKBR(row[0][0]))
    path = os.path.join(curDir, row[0][0])
    lastPart = FFmKBR(path)
    if os.path.isdir(path): path = FFddC4(path)
    dest = os.path.join(newPath, lastPart)
    res = os.system(FFQe93("%s '%s' '%s'" % (cmd, path, dest)))
    if res == 0 : totOk += 1
    else  : totFail += 1
    if VVhsRS:
     VVhsRS.VVLNy3 = [totSel, totOk, totFail, path]
     VVhsRS.VVyVdp(action, totOk, FFmKBR(row[0][0]))
 def VVqqH1(self, title, action, isMove, newPath, VVL4pA, VVLNy3, threadCounter, threadTotal, threadErr):
  totSel, totOk, totFail, path = VVLNy3
  txt  = "Total\t: %d\n" % totSel
  txt += "%s\t: %d\n"  % (action, totOk)
  if totFail   : txt += FFY7FT("Failed\t: %d\n" % totFail, VV9ZlA)
  if not VVL4pA: txt += "%s\n%s" % (FFY7FT("\nCancelled while copying:", VV9ZlA), path)
  FFyv2f(self, txt, title=title)
  self.VV1IqV()
 def VVkovB(self):
  tot = self["myMenu"].VVSsXY()
  FF8XzP(self, BF(FF7Xva, self, self.VVZbFI, title="Deleting ...", clearMsg=False), "Delete %d item%s ?" % (tot, FFmJCK(tot)), title="Delete Selection")
 def VVZbFI(self):
  path = self["myMenu"].VV2kM5()
  for row in self["myMenu"].list:
   if row[2][6]:
    FFbwkF(os.path.join(path, row[0][0]))
  FF1ojr(self)
  self.VV1IqV()
 def VVJxHS(self, path, isMove):
  self.session.openWithCallback(BF(self.VVMYQL, isMove, path), BF(CCbI7Z, mode=CCbI7Z.VVIet0, VVetf7=FFSahc(path, False), VVVp3O="Move to here" if isMove else "Paste here"))
 def VVMYQL(self, isMove, path, newPath):
  if len(newPath) > 0:
   lastPart = FFmKBR(path)
   if os.path.isdir(path): path = FFddC4(path)
   newPath = FFnWu0(newPath)
   dest = newPath + lastPart
   if os.path.isdir(path) and os.path.isdir(dest):
    if isMove:
     FFa349(self, 'Same directory already exists:\n\n%s\n\n( Try to copy then delete the source )' % dest)
     return
    else:
     dest = newPath
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -frp"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FF8XzP(self, BF(FFYpRN, self, cmd, VVvcJy=self.VV1IqV), txt, VVJRkN=True)
   else:
    FFa349(self, "Cannot %s to same directory !" % action.lower())
 def VVkRLp(self, path, fileName):
  path = FFddC4(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FF8XzP(self, BF(FF7Xva, self, BF(self.VVsz2K, path), title="Deleting ...", clearMsg=False), "%s\n\nDelete %s ?" % (path, pathType), title="Delete %s" % pathType)
 def VVsz2K(self, path):
  FFbwkF(path)
  FF1ojr(self)
  self.VV1IqV()
 def VVVjhf(self, path, isFile):
  dirName = FFnWu0(os.path.dirname(path))
  if isFile : objName, VVsHNL = "File"  , self.edited_newFile
  else  : objName, VVsHNL = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFsShb(self, BF(self.VVZTff, dirName, isFile, title), title=title, defaultText=VVsHNL, message="Enter %s Name:" % objName)
 def VVZTff(self, dirName, isFile, title, VVsHNL):
  if VVsHNL:
   if isFile : self.edited_newFile = VVsHNL
   else  : self.edited_newDir  = VVsHNL
   path = dirName + VVsHNL
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVeBpK)
    else  : cmd = "mkdir '%s' %s" % (path, VVeBpK)
    result = FFyJfo(cmd)
    if "Fail" in result:
     FFa349(self, result)
    self.VV1IqV()
   else:
    FFa349(self, "Name already exists !\n\n%s" % path, title)
 def VVri5m(self, path, selFile):
  c1, c2, c3 = VVTMjp, VVJ2KG, VVPpUd
  VVW1xb = []
  VVW1xb.append((c1 + "List Package Files"         , "VVqCZ4"     ))
  VVW1xb.append((c1 + "Package Information"         , "VV8wKg"     ))
  VVW1xb.append(VVswUs)
  VVW1xb.append((c2 + "Install Package"          , "VVLiA1_CheckVersion" ))
  VVW1xb.append((c2 + "Install Package (force reinstall)"     , "VVLiA1_ForceReinstall" ))
  VVW1xb.append((c2 + "Install Package (force overwrite)"     , "VVLiA1_ForceOverwrite" ))
  VVW1xb.append((c2 + "Install Package (force downgrade)"     , "VVLiA1_ForceDowngrade" ))
  VVW1xb.append((c2 + "Install Package (ignore failed dependencies)"  , "VVLiA1_IgnoreDepends" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append((c3 + "Remove Related Package"        , "VVGAun_ExistingPackage" ))
  VVW1xb.append((c3 + "Remove Related Package (force remove)"    , "VVGAun_ForceRemove"  ))
  VVW1xb.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VVGAun_IgnoreDepends" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Extract Files"           , "VVPY2h"     ))
  VVW1xb.append(("Unbuild Package"           , "VVv2Cr"     ))
  FFLFXy(self, BF(self.VVf6AT, path, selFile), VVW1xb=VVW1xb)
 def VVf6AT(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVqCZ4"      : self.VVqCZ4(path, selFile)
   elif item == "VV8wKg"      : self.VV8wKg(path)
   elif item == "VVLiA1_CheckVersion"  : self.VVLiA1(path, selFile, VVkKCu     )
   elif item == "VVLiA1_ForceReinstall" : self.VVLiA1(path, selFile, VVzgm4 )
   elif item == "VVLiA1_ForceOverwrite" : self.VVLiA1(path, selFile, VVDBBb )
   elif item == "VVLiA1_ForceDowngrade" : self.VVLiA1(path, selFile, VVd1HZ )
   elif item == "VVLiA1_IgnoreDepends" : self.VVLiA1(path, selFile, VVVG8q )
   elif item == "VVGAun_ExistingPackage" : self.VVGAun(path, selFile, VVdbf3     )
   elif item == "VVGAun_ForceRemove"  : self.VVGAun(path, selFile, VVYyAT  )
   elif item == "VVGAun_IgnoreDepends"  : self.VVGAun(path, selFile, VV0w22 )
   elif item == "VVPY2h"     : self.VVPY2h(path, selFile)
   elif item == "VVv2Cr"     : self.VVv2Cr(path, selFile)
   else           : self.close()
 def VVqCZ4(self, path, selFile):
  if FFeWq1("ar") : cmd = "allOK='1';"
  else    : cmd  = FFwwi6()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVI8D8, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVI8D8, VVI8D8)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFhS2c(self, cmd, VVvcJy=self.VV1IqV)
 def VVPY2h(self, path, selFile):
  lastPart = FFmKBR(path)
  dest  = FFSahc(path, True) + selFile[:-4]
  cmd  =  FFwwi6()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFQe93("mkdir '%s'" % dest) + ";"
  cmd +=    FFQe93("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFfLXZ(dest, VVlfrr))
  cmd += "fi;"
  FFsZIz(self, cmd, VVvcJy=self.VV1IqV)
 def VVv2Cr(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVEuWS = os.path.splitext(path)[0]
  else        : VVEuWS = path + "_"
  if path.endswith(".deb")   : VVKuhK = "DEBIAN"
  else        : VVKuhK = "CONTROL"
  cmd  = FFwwi6()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVEuWS, FFyH5d())
  cmd += "  mkdir '%s';"    % VVEuWS
  cmd += "  CONTPATH='%s/%s';"  % (VVEuWS, VVKuhK)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVEuWS
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVEuWS, VVEuWS)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVEuWS
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVEuWS, VVEuWS)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVEuWS
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVEuWS
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVEuWS, FFfLXZ(VVEuWS, VVlfrr))
  cmd += "fi;"
  FFsZIz(self, cmd, VVvcJy=self.VV1IqV)
 def VV8wKg(self, path):
  listCmd  = FFrkEH(VVcsXy, "")
  infoCmd  = FFkjia(VV1xDE , "")
  filesCmd = FFkjia(VVUWWs, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFuYac(VVzCWu)
   notInst = "Package not installed."
   cmd  = FF6CJ2("File Info", VVzCWu)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FF6CJ2("System Info", VVzCWu)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFfLXZ(notInst, VV9ZlA))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FF6CJ2("Related Files", VVzCWu)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFmzjA(self, cmd)
  else:
   FFPsN3(self)
 def VVLiA1(self, path, selFile, cmdOpt):
  cmd = FFkjia(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FF8XzP(self, BF(FFsZIz, self, cmd, VVvcJy=FFppy1), "Install Package ?\n\n%s" % selFile)
  else:
   FFPsN3(self)
 def VVGAun(self, path, selFile, cmdOpt):
  listCmd  = FFrkEH(VVcsXy, "")
  infoCmd  = FFkjia(VV1xDE, "")
  instRemCmd = FFkjia(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFfLXZ(errTxt, VV9ZlA))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFfLXZ(cannotTxt, VV9ZlA))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFfLXZ(tryTxt, VV9ZlA))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FF8XzP(self, BF(FFsZIz, self, cmd, VVvcJy=FFppy1), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFPsN3(self)
 def VVLevZ(self, path):
  hostName = FFyJfo("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVPK7C(self, path, isDir):
  txt1 = "Archive to "
  txt2 = "Archive (Preserve Path Structure) to "
  VVW1xb = []
  VVW1xb.append(("%s.tar"  % txt1 , "archDir_tar"  ))
  VVW1xb.append(("%s.tar.gz" % txt1 , "archDir_tar_gz" ))
  VVW1xb.append(("%s.tar.xz" % txt1 , "archDir_tar_xz" ))
  VVW1xb.append(("%s.tar.bz2" % txt1 , "archDir_tar_bz2" ))
  VVW1xb.append(("%s.zip"  % txt1 , "archDir_zip"  ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("%s.tar"  % txt2 , "archPath_tar" ))
  VVW1xb.append(("%s.tar.gz" % txt2 , "archPath_tar_gz" ))
  VVW1xb.append(("%s.tar.xz" % txt2 , "archPath_tar_xz" ))
  VVW1xb.append(("%s.tar.bz2" % txt2 , "archPath_tar_bz2"))
  VVW1xb.append(("%s.zip"  % txt2 , "archPath_zip" ))
  if isDir and not self.multiSelectState:
   VVW1xb.append(VVswUs)
   VVW1xb.append(('Convert to ".ipk" Package', "convertDirToIpk" ))
   VVW1xb.append(('Convert to ".deb" Package', "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFLFXy(self, BF(self.VV2upg, path, isDir, title), VVW1xb=VVW1xb, title=title, VVgchu=c1, VVn4Mh=c2)
 def VV2upg(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"  : self.VVIWzi(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz" : self.VVIWzi(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz" : self.VVIWzi(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2" : self.VVIWzi(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"  : self.VVIWzi(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"  : self.VVIWzi(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz" : self.VVIWzi(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz" : self.VVIWzi(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2" : self.VVIWzi(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"  : self.VVIWzi(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk" : self.VV5UbP(path, False)
   elif item == "convertDirToDeb" : self.VV5UbP(path, True)
 def VV5UbP(self, path, VV4kar):
  self.session.openWithCallback(self.VV1IqV, BF(CCMxVV, path=path, VV4kar=VV4kar))
 def VVIWzi(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FFSahc(path, True)
  lastPart = FFmKBR(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFsl4Z("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFsl4Z("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFsl4Z("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVI8D8
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFQe93("rm -f '%s'" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFfLXZ(failed, VV6yYu))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFfLXZ(srcTxt, VV5cg1))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFfLXZ("Output", VVlfrr))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFfLXZ(failed, VVAgOb))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFhS2c(self, cmd, VVvcJy=self.VV1IqV, title=title)
 def VV9oQp(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CCbI7Z.VVTgdV(FFSahc(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CCRtNz(self, self, title, BF(self.VVtQMN, pathLst))
 def VVtQMN(self, pathLst):
  return CCRtNz.VViQsh(pathLst)
 def VVpkaP(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VVuMWY, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FF8XzP(self, BF(FF7Xva, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FF7Xva(self, fnc, title=txt)
  else:
   FFa349(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VVuMWY(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, "w:gz") as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFyv2f(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VV1IqV()
  else:
   FFGWxS(tarPath)
   FFa349(self, "Error while converting.", title=title)
 def VVtPMZ(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVSvFx, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FF8XzP(self, BF(FF7Xva, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FF7Xva(self, fnc, title=txt)
  else:
   FFa349(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVSvFx(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFyv2f(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VV1IqV()
  else:
   FFGWxS(zipPath)
   FFa349(self, "Error while converting.", title=title)
 def VVbvtU(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FFnWu0(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  os.system(FFQe93("rm -f '%s' '%s'" % (m1v, mvi)))
  res = os.system(FFQe93("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)))
  if res == 0 and fileExists(m1v):
   res = os.system(FFQe93("mv -f '%s' '%s'" % (m1v, mvi)))
   self.VV1IqV()
   FF5nWa(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FFa349(self, "Cannot convert this file !", title=title)
 def VVRWL1(self, path):
  title = "Set as PIcon for current channel"
  pPath = CCMxom.VVVqXw()
  if pathExists(pPath):
   if CCXLqT.VVqbOL(self, title, False, cbFnc=BF(self.VVRWL1, path)):
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self)
    picon = "%s%s.png" % (pPath, refCode.strip(":").replace(":", "_").upper())
    VVW1xb = []
    for item in ((50,30),(96,64),(100,60),(220,132),(400,160),(400,240),(500,300)):
     VVW1xb.append(("%d x %d" % (item), item))
    infoBtnFnc = self.VVF9ZQ
    VVkjyo = ("Stretch", BF(self.VVymAq, title, path, picon))
    menuInstance = FFLFXy(self, BF(self.VVszLg, title, path, picon, False), VVW1xb=VVW1xb, width=700, title='PIcon Max. Size', infoBtnFnc=infoBtnFnc, VVkjyo=VVkjyo, barText="OK = Fit within size")
    menuInstance.VVUaDE(3)
  else:
   FFa349(self, "PIcons path not found:\n\n%s\n\n( You can change it in Settings )" % pPath, title=title)
 def VVymAq(self, title, path, picon, VVlAViObj, item):
  self.VVszLg(title, path, picon, True, item)
  VVlAViObj.cancel()
 def VVszLg(self, title, path, picon, stretch, sz=None):
  if sz:
   try:
    from PIL import Image
    im = Image.open(path)
    if stretch: im = im.resize(sz, Image.ANTIALIAS)
    else   : im.thumbnail(sz)
    im.save(picon)
    FFr9gS(self, fncMode=CCsydO.VVPCQS)
   except Exception as e:
    FFa349(self, "Image Processing error:\n\n%s" % e)
 def VVF9ZQ(self, menuInstance, txt, ref, ndx):
  FFsiZl(self, "_help_resize", "Picture File Resizing")
 @staticmethod
 def VVItJ2():
  lst = (("1"  , "DVB Stream"  , True)
   , ("4097", "servicemp3"  , True)
   , ("5001", "GST Player"  , os.path.exists("/usr/bin/gstplayer"))
   , ("5002", "Ext-3 EPlayer" , os.path.exists("/usr/bin/exteplayer3"))
   , ("8193", "eServiceUri" , os.path.exists("/usr/bin/apt-get")))
  defRt = CFG.iptvAddToBouquetRefType.getValue()
  VVW1xb = []
  for ndx, (rt, txt, ok) in enumerate(lst):
   txt = "%s\t... %s" % ((VVTMjp if rt == defRt else "") + txt, rt)
   if ok: VVW1xb.append((txt, rt))
   else : VVW1xb.append((txt, ))
   if ndx < 4 and ndx % 2: VVW1xb.append(VVswUs)
  return VVW1xb
 def VV2rUu(self, path):
  FFLFXy(self, BF(self.VVF3vR, path), VVW1xb=CCbI7Z.VVItJ2(), width=650, title="Select Player", VVgchu="#11220000", VVn4Mh="#11220000")
 def VVF3vR(self, path, rType=None):
  if rType:
   FF7Xva(self, BF(self.VV7vnp, self, path, rType), title="Playing Media ...")
 @staticmethod
 def VV7vnp(SELF, path, rType=""):
  try:
   if   rType     : prefix = rType
   elif path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCXzGX.VVmA7N(SELF.session, enableZapping= False, enableDownloadMenu=False, enableOpenInFMan=False)
  except:
   pass
 @staticmethod
 def VVzTch(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFnWu0(fDir), fName
  return "", "", ""
 @staticmethod
 def VVznyV(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVREmO(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVr8MR(size, mode=0):
  txt = CCbI7Z.VVhXuY(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVhXuY(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VVchO2(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VV8ERc(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FFa349(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VVxgYx():
  tDict = CCDiIK.VVGjn5()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVTgdV(path):
  lst = []
  for ext in CCbI7Z.VVxgYx():
   lst.extend(FFKZAp(path, "*.%s" % ext))
  return sorted(lst, key=FFKEcC(FF2f45))
 @staticmethod
 def VVEdXH(path):
  res = os.system("tar -tzf '%s' >/dev/null" % path)
  return res == 0
 @staticmethod
 def VVPH4O(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
 @staticmethod
 def VVPSgD(lst, fromFind=True):
  if len(lst) == 1 and lst[0] == VVRgbf:
   return VVRgbf
  elif fromFind:
   for line in lst:
    span = iSearch(r"find:\s*(.+):\s*Input\/output error", line, IGNORECASE)
    if span:
     return 'Filesystem Error in:\n\n%s' % span.group(1)
  return ""
class CCDiIK(MenuList):
 VVMazT   = 0
 VVBNSq   = 1
 VV5Byr   = 2
 VV9001   = 3
 VVpi1m   = 4
 VVOgNo   = 5
 VV9SIP   = 6
 VVCUvt   = 7
 VV4Yqy   = "<List of Storage Devices>"
 VVCZHz  = "<Parent Directory>"
 VVmKAE   = 0
 VVKcX2   = 1
 VV2XmM = 2
 VVrWQY  = 3
 VVKqnr   = 4
 VV1Tv8   = 5
 FILE_TYPE_LINK   = 6
 VVHnOG  = 7
 PROHIBITED_FILES  = ["/%s/" % x for x in ("DEBIAN","bin","boot","dev","etc","hdd","home","lib","media","mnt","network","proc","run","sbin","sys","tmp","usr","var")]
 def __init__(self, VVyCBb=False, directory="/", VVQ722=True, VVWuP8=True, VVCkTv=True, VVJLOl=None, VV0sgb=False, VVKpzC=False, VVDyKK=False, isTop=False, VVYRPF=None, VVExc6=1000, VVJmZ8=30, VVJ5AH=30):
  MenuList.__init__(self, list, VVyCBb, eListboxPythonMultiContent)
  self.VVQ722  = VVQ722
  self.VVWuP8    = VVWuP8
  self.VVCkTv  = VVCkTv
  self.VVJLOl  = VVJLOl
  self.VV0sgb   = VV0sgb
  self.VVKpzC   = VVKpzC or []
  self.VVDyKK   = VVDyKK or []
  self.isTop     = isTop
  self.additional_extensions = VVYRPF
  self.VVExc6    = VVExc6
  self.VVJmZ8    = VVJmZ8
  self.VVJ5AH    = VVJ5AH
  self.EXTENSIONS    = CCDiIK.VVGjn5()
  self.VVjSyF   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.multiSelect_color  = FFVPH4("#11ff4444")
  self.l.setFont(0, gFont(VVPvAG, self.VVJmZ8))
  self.l.setItemHeight(self.VVJ5AH)
  self.png_mem   = CCDiIK.VVAgne("mem")
  self.png_usb   = CCDiIK.VVAgne("usb")
  self.png_fil   = CCDiIK.VVAgne("fil")
  self.png_dir   = CCDiIK.VVAgne("dir")
  self.png_dirup   = CCDiIK.VVAgne("dirup")
  self.png_srv   = CCDiIK.VVAgne("srv")
  self.png_slwfil   = CCDiIK.VVAgne("slwfil")
  self.png_slbfil   = CCDiIK.VVAgne("slbfil")
  self.png_slwdir   = CCDiIK.VVAgne("slwdir")
  self.VVieEN()
  self.VVsove(directory)
 @staticmethod
 def VVAgne(category):
  return LoadPixmap("%s%s.png" % (VV9dcF, category), getDesktop(0))
 @staticmethod
 def VVGjn5():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","stream","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VV0mRE(self, name, absolute=None, isDir=False, typ=None, png=None):
  if absolute and isDir:
   path = absolute
   path = FFddC4(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFY7FT(" -> " , VVzCWu) + FFY7FT(os.readlink(path), VVlfrr)
  tableRow = [ (absolute, isDir, typ) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVJ5AH + 10, 0, self.VVExc6, self.VVJ5AH, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVDXCW: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVJ5AH-4, self.VVJ5AH-4, png, None, None, VVDXCW))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVJ5AH-4, self.VVJ5AH-4, png, None, None))
  return tableRow
 def VVVeDa(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVieEN(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VV3EHL(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVx3Wg(self, file):
  if os.path.realpath(file) == file:
   return self.VV3EHL(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VV3EHL(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VV3EHL(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVURdd(self):
  ndx = self.l.getCurrentSelectionIndex()
  row = self.list[ndx]
  bg = self.multiSelect_color if row[2][6] == None else None
  ndx = self.getSelectionIndex()
  if ndx < len(self.list) - 1:
   self.moveToIndex(self.getSelectionIndex() + 1)
  iconData = self.VVKysY(row, bg)
  if iconData:
   row[2] = iconData
   self.l.setList(self.list)
   return True
  else:
   return False
 def VVRezb(self, isSel):
  bg = self.multiSelect_color if isSel else None
  for ndx, row in enumerate(self.list):
   iconData = self.VVKysY(row, bg)
   if iconData:
    row[2] = iconData
  self.l.setList(self.list)
 def VVKysY(self, row, bg):
  if self.VVSnld(row):
   iconData = list(row[2])
   iconData[6] = bg
   iconData[7] = bg
   return tuple(iconData)
  else:
   return None
 def VVSnld(self, row):
  if not row[0][0] in self.mountpoints:
   if   row[0][2] in (self.VV1Tv8, self.FILE_TYPE_LINK): return True
   elif row[0][2] == self.VVKqnr:
    if   VVpn8D           : return True
    elif not row[0][0] in self.PROHIBITED_FILES    : return True
  return False
 def VVs41A(self):
  return self.VVSnld(self.list[self.l.getCurrentSelectionIndex()])
 def VVSsXY(self):
  tot = 0
  for row in self.list:
   if row[2][6]:
    tot += 1
  return tot
 def VVhsIU(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVsove(self, directory, selItem=None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VVCkTv:
    self.current_mountpoint = self.VVx3Wg(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VVCkTv:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VVDyKK and not self.VVhsIU(path, self.VVKpzC):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VV0mRE(name=p.description, absolute=path, isDir=True, typ=self.VVmKAE, png=png))
    path = "/"
    if path not in self.VVDyKK and not self.VVhsIU(path, self.VVKpzC):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VV0mRE(name="INTERNAL FLASH", absolute="/", isDir=True, typ=self.VVKcX2, png=self.png_mem))
  elif self.VV0sgb:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVjSyF = eServiceCenter.getInstance()
   list = VVjSyF.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVQ722 and not self.isTop:
   if directory == self.current_mountpoint and self.VVCkTv:
    self.list.append(self.VV0mRE(name=self.VV4Yqy, absolute=None, isDir=True, typ=self.VV2XmM, png=self.png_dirup))
   elif (directory != "/") and not (self.VVDyKK and self.VV3EHL(directory) in self.VVDyKK):
    self.list.append(self.VV0mRE(name=self.VVCZHz, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, typ=self.VVrWQY, png=self.png_dirup))
  if self.VVQ722:
   for x in directories:
    if not (self.VVDyKK and self.VV3EHL(x) in self.VVDyKK) and not self.VVhsIU(x, self.VVKpzC):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VV0mRE(name=name, absolute=x, isDir=True, typ=self.FILE_TYPE_LINK if os.path.islink(FFddC4(x)) else self.VVKqnr, png=png))
  if self.VVWuP8:
   for x in files:
    if self.VV0sgb:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFY7FT(" -> " , VVzCWu) + FFY7FT(target, VVlfrr)
       else:
        png = self.png_slbfil
        name += FFY7FT(" -> " , VVzCWu) + FFY7FT(target, VVAgOb)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVVeDa(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VV9dcF, category))
    if (self.VVJLOl is None) or iCompile(self.VVJLOl[0], flags=self.VVJLOl[1]).search(path):
     self.list.append(self.VV0mRE(name=name, absolute=x , isDir=False, typ=self.VV1Tv8, png=png))
  if self.VVCkTv and len(self.list) == 0:
   self.list.append(self.VV0mRE(name=FFY7FT("No USB connected", VVBh5X), absolute=None, isDir=False, typ=self.VVHnOG, png=self.png_usb))
  self.l.setList(self.list)
  self.VVDHdO()
  if selItem is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference): p = p.getPath()
    if p == selItem: self.moveToIndex(i)
    i += 1
 def VV2kM5(self):
  return self.current_directory
 def VVyaCa(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VVwTWT(self):
  return self.VVFU7n() and self.VV2kM5()
 def VVFU7n(self):
  return self.list[0][1][7] in (self.VV4Yqy, self.VVCZHz)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVsove(self.getSelection()[0], self.current_directory)
 def VVgn3P(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VV41MY)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VV41MY)
 def VV41MY(self, action, device):
  self.VVieEN()
  if self.current_directory is None:
   self.VVh50i()
 def VVh50i(self):
  tDict = {}
  for row in self.list:
   if row[2][6]:
    tDict[row[0][0]] = 1
  self.VVsove(self.current_directory, self.VVgn3P())
  isSel = 0
  if tDict:
   for row in self.list:
    if tDict.get(row[0][0], 0):
     row[2] = list(row[2])
     row[2][6] = row[2][7] = self.multiSelect_color
     row[2] = tuple(row[2])
     isSel = 1
   self.l.setList(self.list)
  return isSel
 def VVSSzO(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVMazT : nameAlpMode, nameAlpTxt = self.VVBNSq, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVMazT, sAZ
  if mode == self.VV5Byr : nameNumMode, nameNumTxt = self.VV9001, s90
  else       : nameNumMode, nameNumTxt = self.VV5Byr, s09
  if mode == self.VVpi1m : dateMode, dateTxt = self.VVOgNo, sON
  else       : dateMode, dateTxt = self.VVpi1m, sNO
  if mode == self.VV9SIP : typeMode, typeTxt = self.VVCUvt, sZA
  else       : typeMode, typeTxt = self.VV9SIP, sAZ
  if   mode in (self.VVMazT, self.VVBNSq): txt = "Name (%s)" % (sAZ if mode == self.VVMazT else sZA)
  elif mode in (self.VV5Byr, self.VV9001): txt = "Name (%s)" % (s09 if mode == self.VVMazT else s90)
  elif mode in (self.VVpi1m, self.VVOgNo): txt = "Date (%s)" % (sNO if mode == self.VVpi1m else sON)
  elif mode in (self.VV9SIP, self.VVCUvt): txt = "Type (%s)" % (sAZ if mode == self.VV9SIP else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VVDHdO(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FFxMsu(CFG.browserSortMode, mode)
   FFxMsu(CFG.browserSortMix, isMix)
  if self.list:
   if self.VVFU7n() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VVMazT, self.VVBNSq):
    rev = True if mode == self.VVBNSq else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VV5Byr, self.VV9001):
    rev = True if mode == self.VV9001 else False
    self.list = sorted(self.list[item0:], key=FFKEcC(BF(self.VVQHZg, isMix, rev)), reverse=rev)
   elif mode in (self.VVpi1m, self.VVOgNo):
    rev = True if mode == self.VVOgNo else False
    self.list = sorted(self.list[item0:], key=FFKEcC(BF(self.VVrwID, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VVCUvt else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VVQHZg(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FF2f45(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FFT3sR(dir2, dir1) or FF2f45(name1, name2)
 def VVrwID(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FFT3sR(stat2.st_ctime, stat1.st_ctime)
    else : return FFT3sR(dir2, dir1) or FFT3sR(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CCN1iw(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FFXh6Y(VVpl04, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VV6fdw   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVIXss(defFG, "#00FFFFFF")
  self.defBG   = self.VVIXss(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFwLhV(self, self.Title)
  self["keyRed"].show()
  FFxDER(self["keyGreen"] , "< > Transp.")
  FFxDER(self["keyYellow"], "Foreground")
  FFxDER(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVtyEh     ,
   "green"   : self.VVtyEh     ,
   "yellow"  : BF(self.VVGSd0, False)  ,
   "blue"   : BF(self.VVGSd0, True)  ,
   "up"   : self.VVEmui       ,
   "down"   : self.VV6joq      ,
   "left"   : self.VVWsG2      ,
   "right"   : self.VVYgav      ,
   "last"   : BF(self.VVrjaN, -5) ,
   "next"   : BF(self.VVrjaN, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVfcAc)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FF0e9t(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FF0e9t(self["keyRed"] , c)
  FF0e9t(self["keyGreen"] , c)
  self.VVluCi()
  self.VVLxHA()
  FFLsU4(self["myColorTst"], self.defFG)
  FF0e9t(self["myColorTst"], self.defBG)
 def VVIXss(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVLxHA(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VV2op5(0, 0)
     return
 def VVtyEh(self):
  self.close(self.defFG, self.defBG)
 def VVEmui(self): self.VV2op5(-1, 0)
 def VV6joq(self): self.VV2op5(1, 0)
 def VVWsG2(self): self.VV2op5(0, -1)
 def VVYgav(self): self.VV2op5(0, 1)
 def VV2op5(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVbawq()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VV5hvB()
 def VVluCi(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VV5hvB(self):
  color = self.VVbawq()
  if self.isBgMode: FF0e9t(self["myColorTst"], color)
  else   : FFLsU4(self["myColorTst"], color)
 def VVGSd0(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VVluCi()
   self.VVLxHA()
 def VVrjaN(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VV2op5(0, 0)
 def VVBjdn(self):
  return hex(self.transp)[2:].zfill(2)
 def VVbawq(self):
  return ("#%s%s" % (self.VVBjdn(), self.colors[self.curRow][self.curCol])).upper()
class CCdwmB(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFXh6Y(VV4Vk8, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FFwLhV(self, title="%s%s%s" % (self.Title, " " * 10, FFY7FT("Change values with Up , Down, < , 0 , >", VVBh5X)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVi1M6      ,
   "cancel" : self.VVOJpx      ,
   "info"  : self.VVkHem    ,
   "red"  : self.VVRbro  ,
   "green"  : self.VV961f   ,
   "yellow" : BF(self.VVi2hK, 0)  ,
   "blue"  : self.VVCoiy    ,
   "menu"  : self.VVC256      ,
   "left"  : self.VVWsG2      ,
   "right"  : self.VVYgav      ,
   "last"  : self.VVTmyi     ,
   "next"  : self.VVg10B     ,
   "0"   : self.VVueV1    ,
   "up"  : self.VVEmui       ,
   "down"  : self.VV6joq      ,
   "pageUp" : BF(self.VV5JQ3, True) ,
   "pageDown" : BF(self.VV5JQ3, False) ,
   "chanUp" : BF(self.VV5JQ3, True) ,
   "chanDown" : BF(self.VV5JQ3, False) ,
   "play"  : BF(self.VVQ8Xq, "pause")  ,
   "pause"  : BF(self.VVQ8Xq, "pause")  ,
   "playPause" : BF(self.VVQ8Xq, "pause")  ,
   "stop"  : BF(self.VVQ8Xq, "pause")  ,
   "audio"  : BF(self.VVQ8Xq, "audio")  ,
   "subtitle" : BF(self.VVQ8Xq, "subtitle") ,
   "rewind" : BF(self.VVQ8Xq, "rewind" ) ,
   "forward" : BF(self.VVQ8Xq, "forward" ) ,
   "rewindDm" : BF(self.VVQ8Xq, "rewindDm") ,
   "forwardDm" : BF(self.VVQ8Xq, "forwardDm")
  }, -1)
  self.VVrH92()
  self.onShown.append(self.VVfcAc)
  self.onClose.append(self.VV5p5F)
 def VVrH92(self):
  lst = []
  for fil in FFKZAp(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VVm9KW:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VVfcAc(self):
  self.onShown.remove(self.VVfcAc)
  FFvDt2(self)
  FF8TfI(self)
  for i in range(3):
   self["mySubt%d" % i].instance.setNoWrap(True)
   self["mySubt%d" % i].hide()
  self.VV7vip()
  self.VVi0FC()
  self.VV7hmh()
 def VV5p5F(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VVSkLA(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FF0e9t(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VVtB4o()
 def VV7vip(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FF0e9t(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VVi1M6(self):
  if self.settingShown:
   confItem = self.VVmjy6()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVW1xb = []
   if isinstance(lst[0], tuple):
    for item in lst: VVW1xb.append((item[1], item[0]))
   else:
    for item in lst: VVW1xb.append((item, item))
   menuInstance = FFLFXy(self, self.VV2G3f, VVW1xb=VVW1xb, width=700, title=title, VVgchu="#33221111", VVn4Mh="#33110011")
   menuInstance.VVUaDE(confItem.getIndex())
  else:
   self.close("subtExit")
 def VV2G3f(self, item=None):
  if item:
   self.VVmjy6()[self.CursorPos].setValue(item)
   self.VVtB4o()
   self.VVi0FC()
   self.VVzN8D(True)
 def VVOJpx(self):
  for confItem in self.VVmjy6():
   if confItem.isChanged():
    FF8XzP(self, self.VVjIkG, "Save Changes ?", callBack_No=self.VVx0Da, title=self.Title)
    break
  else:
   if self.settingShown: self.VV7vip()
   else    : self.close("subtExit")
 def VVC256(self):
  if self.settingShown: self.VV7HQA()
  else    : self.VVSkLA()
 def VVWsG2(self): self.VVUr16(-1)
 def VVYgav(self): self.VVUr16(1)
 def VVUr16(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VV8fnI()
   if pos == -1: ndx = self.VVkJdI(posVal)
   else  : ndx = self.VVwLsz(posVal)
   if   ndx < 0      : FF1ojr(self, "Not found" , 500)
   elif ndx == 0      : FF1ojr(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FF1ojr(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VV7zAG(frmSec)
    if allow:
     self.VVi2hK(delay, True)
     self.VVzN8D(force=True)
    else:
     FF1ojr(self, "Delay out of range", 800)
 def VV5JQ3(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VVQ8Xq(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVTmyi(self) : self.VVp5Lq(5)
 def VVg10B(self) : self.VVp5Lq(6)
 def VVueV1(self) : self.VVp5Lq(-1)
 def VVEmui(self):
  if self.settingShown: self.VVp5Lq(1)
  else    : self.VV5JQ3(True)
 def VV6joq(self):
  if self.settingShown: self.VVp5Lq(0)
  else    : self.VV5JQ3(False)
 def VVp5Lq(self, direction):
  if self.settingShown:
   confItem = self.VVmjy6()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VVtB4o()
   self.VVi0FC()
   self.VVzN8D(True)
 def VVmjy6(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VVx0Da(self):
  for confItem in self.VVmjy6(): confItem.cancel()
  self.VVtB4o()
  self.VVi0FC()
  self.VV7vip()
 def VVRbro(self):
  if self.settingShown:
   FF8XzP(self, self.VV4IGn, "Reset Subtitle Settings to default ?", title=self.Title)
 def VV4IGn(self):
  for confItem in self.VVmjy6(): confItem.setValue(confItem.default)
  self.VVjIkG()
  self.VVtB4o()
  self.VVi0FC()
 def VVi2hK(self, delay, force=False):
  if self.settingShown or force:
   FFxMsu(CFG.subtDelaySec, delay)
   self.VVUboX()
   self.VVtB4o()
   self.VVi0FC()
   if self.settingShown:
    FF1ojr(self, 'Reset to "0"', 800, isGrn=True)
 def VV961f(self):
  if self.settingShown:
   self.VVjIkG()
   self.VV7vip()
 def VVjIkG(self):
  for confItem in self.VVmjy6(): confItem.save()
  configfile.save()
  self.VVUboX()
  FF1ojr(self, "Saved", 1000, isGrn=True)
 def VVtB4o(self):
  cfgLst = self.VVmjy6()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VVi0FC(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   FFr0nN(path, fnt, isRepl=1)
  else:
   fnt = VVPvAG
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FFfFjr(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFLsU4(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FF0e9t(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    inst.setNoWrap(True)
    lineH = FFbSpu(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FFfFjr(CFG.subtVerticalPos.getValue(), 0, 100, 0, FFcmgn()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  FFOMWW(self, winW, winH)
 def VVkHem(self):
  sp = "    "
  txt  = "%s\n"   % FFY7FT("Subtitle File:", VVJ2KG)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FFY7FT("Subtitle Settings:", VVJ2KG)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VV8fnI()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FFCiZs(frmSec1)
   time2 = FFCiZs(toSec2)
   txt += "\n"
   txt += "%s\n"       % FFY7FT("Timing:", VVJ2KG)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FFCiZs(durVal)
   txt += sp + "Progress\t: %s\n" % FFCiZs(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FFY7FT("Subtitle end reached.", VV6yYu)
  FFyv2f(self, txt, title="Current Subtitle")
 def VV7hmh(self, path="", delay=0, enc=""):
  FF7Xva(self, BF(self.VVQftj, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VVQftj(self, path="", delay=0, enc=""):
  FF1ojr(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVD32q(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VVtB4o()
     self.VV6po9()
   else:
    path, delay, enc = CCdwmB.VVDYji(self)
    if path:
     self.VV7hmh(path=path, delay=delay, enc=enc)
    else:
     self.VV7HQA()
  except:
   pass
 def VV6po9(self):
  posVal, durVal = self.VV8fnI()
  if self.VVSOqM(posVal):
   return
  CCdwmB.VVUdg7(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVzN8D)
  except:
   self.timerUpdate.callback.append(self.VVzN8D)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVBSZT)
  except:
   self.timerEndText.callback.append(self.VVBSZT)
  FF1ojr(self, "Subtitle started", 700, isGrn=True)
 def VVSOqM(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CCdwmB.VV3z5E(self)
   FFGWxS(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VV7HQA(self):
  c1, c2, c3, c4, c5 = "", VVJ2KG, VVW6qu, VVPpUd, VV6yYu
  VVW1xb = []
  VVW1xb.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVW1xb.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVW1xb.append(VVswUs)
  VVW1xb.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVW1xb.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVW1xb.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVW1xb.append(VVswUs)
   VVW1xb.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVW1xb.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVW1xb.append(VVswUs)
   VVW1xb.append(("Help (Keys)"        , "help"  ))
  FFLFXy(self, self.VVMn3f, VVW1xb=VVW1xb, width=700, title='Find Subtitle ".srt" File', VVgchu="#33221111", VVn4Mh="#33110011")
 def VVMn3f(self, item=None):
  if item:
   if   item == "allSrt"   : self.VVHoAh(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VVHoAh(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    sDir = "/"
    for path in (CFG.lastFileManFindSrt.getValue(), CFG.MovieDownloadPath.getValue(), "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VVv5kX, BF(CCbI7Z, patternMode="srt", VVetf7=sDir))
   elif item.startswith("sugSrt") : self.VVHoAh(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FF7Xva(self, BF(CCAUx4.VVqaxk, self, self.lastSubtFile, self.VVlrtR, defEnc=self.lastSubtEnc), title="Loading Codecs ...", clearMsg=False)
    else             : FF1ojr(self, "SRT File error", 1000)
   elif item == "disab":
    FFGWxS(CCdwmB.VV3z5E(self))
    self.close("subtExit")
   elif item == "help"    : FFsiZl(self, "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VVlrtR(self, item=None):
  if item:
   FF7Xva(self, BF(self.VV7hmh, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VVv5kX(self, path):
  if path:
   FFxMsu(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VV7hmh(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VVHoAh(self, defSrt="", mode=0, coeff=0.25):
  FF7Xva(self, BF(self.VVPLVT, defSrt, mode=mode, coeff=coeff), title="Searching for srt files", clearMsg=False)
 def VVPLVT(self, defSrt="", mode=0, coeff=0.25):
  FF1ojr(self)
  if mode == 1:
   srtList = CCdwmB.VVhpaO(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FF94gP('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFiZoB(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VVu0b2(srtList, coeff)
     if err:
      if self.settingShown: FF1ojr(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VVuV68 = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FFnWu0(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVuV68.append((fName, Dir))
   VVVi12  = ("Select"    , self.VV2AGw     , [])
   VV6iCg = self.VVUsit
   VVd4CR = (""     , self.VVwysp       , [])
   VVH2MF = (""     , BF(self.VVdwK0, defSrt, False) , [])
   VVsTsL = ("Find Current File" , BF(self.VVdwK0, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FFEM8S(self, None, title=title, header=header, VV6fdw=VVuV68, VVHqY6=widths, VVJmZ8=28, VVVi12=VVVi12, VV6iCg=VV6iCg, VVd4CR=VVd4CR, VVH2MF=VVH2MF, VVsTsL=VVsTsL, lastFindConfigObj=CFG.lastFindSubtitle
     , VVgchu="#11002222", VVn4Mh="#33001111", VVMqKH="#33001111", VVKhj2="#11ffff00", VVntre="#11445544", VV3VhT="#22222222", VVwlSC="#11002233")
  elif self.settingShown : FF1ojr(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VVUsit(self, VVXOwS):
  VVXOwS.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VVwysp(self, VVXOwS, title, txt, colList):
  fName, Dir = colList
  FFyv2f(VVXOwS, "%s\n\n%s%s" % (FFY7FT("Path:", VVJ2KG), Dir, fName), title=title)
 def VVdwK0(self, path, VVik2e, VVXOwS, title, txt, colList):
  for ndx, row in enumerate(VVXOwS.VVWsuW()):
   if path == row[1].strip() + row[0].strip():
    VVXOwS.VV9fSx(ndx)
    break
  else:
   if VVik2e:
    FF1ojr(VVXOwS, "Not in list !", 1000)
 def VV2AGw(self, VVXOwS, title, txt, colList):
  VVXOwS.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VV7hmh(path=path)
 def VVu0b2(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCos4Q.VVuKUK(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName:
   if evName and CFG.epgLangTitle.getValue():
    CCos4Q.VVz1sV(evName, "en")[0] or evName
   lst, err = CCdwmB.VVBHuu(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVD32q(self, path, enc=None):
  if not fileExists(path):
   return [], "File not found"
  if (FFPYZx(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FFFfvw(path, encLst=enc if enc else None)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVZhzE(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VVDaoQ(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVUboX()
  return subtList, ""
 def VVDaoQ(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VVZhzE(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVUboX(self):
  path = CCdwmB.VV3z5E(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVzN8D(self, force=False):
  posVal, durVal = self.VV8fnI()
  if self.VVSOqM(posVal):
   return
  curIndex = self.VVRgUZ(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVBSZT()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFLsU4(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VV8fnI(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCXzGX.VVeLNP(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCos4Q.VVuKUK(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VVRgUZ(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VVkJdI(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VVwLsz(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VVBSZT(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFLsU4(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VVCoiy(self):
  FF7Xva(self, self.VVAJoo, title="Loading Lines ...", clearMsg=False)
 def VVAJoo(self):
  FF1ojr(self)
  VVuV68 = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VVuV68.append((cap, FFCiZs(frm), str(frm), firstLine))
  if VVuV68:
   title = "Select Current Subtitle Line"
   VVRzm2  = self.VVO3jJ
   VV6iCg = self.VVNdLP
   VVVi12  = ("Select"   , self.VVm6zI , [title])
   VVsTsL = ("Current Line" , self.VVEOIW , [True])
   VVQR2V = ("Reset Delay" , self.VVjzIg , [])
   VVmmwr = ("New Delay"  , self.VVWOXK   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VVI7B0  = (CENTER , CENTER, CENTER , LEFT    )
   VVXOwS = FFEM8S(self, None, title=title, header=header, VV6fdw=VVuV68, VVI7B0=VVI7B0, VVHqY6=widths, VVJmZ8=28, VVRzm2=VVRzm2, VV6iCg=VV6iCg, VVVi12=VVVi12, VVsTsL=VVsTsL, VVQR2V=VVQR2V, VVmmwr=VVmmwr
          , VVgchu="#33002222", VVn4Mh="#33001111", VVMqKH="#33110011", VVKhj2="#11ffff00", VVntre="#0a334455", VV3VhT="#22222222", VVwlSC="#33002233")
  else:
   FF1ojr(self, "Cannot read lines !", 2000)
 def VVO3jJ(self, VVXOwS):
  self.subtLinesTable = VVXOwS
  if CFG.subtDelaySec.getValue():
   VVXOwS["keyYellow"].show()
   VVXOwS["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVXOwS["keyYellow"].hide()
  VVXOwS["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FF0e9t(VVXOwS["keyBlue"], "#22222222")
  VVXOwS.VVG6Py(BF(self.VVuUi8, VVXOwS))
  self.VVEOIW(VVXOwS, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVQOcv)
  except:
   self.timerSubtLines.callback.append(self.VVQOcv)
  self.timerSubtLines.start(1000, False)
 def VVNdLP(self, VVXOwS):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVXOwS.cancel()
 def VVQOcv(self):
  if self.subtLinesTable:
   VVXOwS = self.subtLinesTable
   posVal, durVal = self.VV8fnI()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVRgUZ(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVXOwS.VVJsov(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVXOwS.VVxVqL(self.subtLinesTableNdx, row)
     row = VVXOwS.VVJsov(curIndex)
     row[0] = color + row[0]
     VVXOwS.VVxVqL(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VVm6zI(self, VVXOwS, Title):
  delay, color, allow = self.VVA0VJ(VVXOwS)
  if allow:
   self.VVNdLP(VVXOwS)
   self.VVi2hK(delay, True)
  else:
   FF1ojr(VVXOwS, "Delay out of range", 1500)
 def VVEOIW(self, VVXOwS, VVik2e, onlyColor=False):
  if VVXOwS:
   posVal, durVal = self.VV8fnI()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVRgUZ(posVal)
    if curIndex > -1:
     VVXOwS.VV9fSx(curIndex)
    else:
     ndx = self.VVkJdI(posVal)
     if ndx > -1:
      VVXOwS.VV9fSx(ndx)
 def VVjzIg(self, VVXOwS, title, txt, colList):
  if VVXOwS["keyYellow"].getVisible():
   self.VVi2hK(0, True)
   VVXOwS["keyYellow"].hide()
   self.VVEOIW(VVXOwS, False)
 def VVuUi8(self, VVXOwS):
  delay, color, allow = self.VVA0VJ(VVXOwS)
  VVXOwS["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VVA0VJ(self, VVXOwS):
  lineTime = float(VVXOwS.VVsaDG()[2].strip())
  return self.VV7zAG(lineTime)
 def VV7zAG(self, lineTime):
  posVal, durVal = self.VV8fnI()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VVTMjp
   else     : allow, color = False, VV6yYu
   delay = FFoooc(val, -600, 600)
  return delay, color, allow
 def VVWOXK(self, VVXOwS, title, txt, colList):
  pass
 @staticmethod
 def VVXyer(SELF):
  path, delay, enc = CCdwmB.VVDYji(SELF)
  return True if path else False
 @staticmethod
 def VVDYji(SELF):
  path, delay, enc = CCdwmB.VViLBK(SELF)
  if not path:
   path = CCdwmB.VVSIAA(SELF)
  return path, delay, enc
 @staticmethod
 def VViLBK(SELF):
  srtCfgPath = CCdwmB.VV3z5E(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FFFfvw(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VV3z5E(SELF):
  fPath, fDir, fName = CCbI7Z.VVzTch(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCos4Q.VVuKUK(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFSXdj(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VVSIAA(SELF):
  bestRatio = 0
  fPath, fDir, fName = CCbI7Z.VVzTch(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CCdwmB.VVhpaO(SELF)
    bLst, err = CCdwmB.VVBHuu(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVhpaO(SELF):
  fPath, fDir, fName = CCbI7Z.VVzTch(SELF)
  if pathExists(fDir):
   files = FFKZAp(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VVBHuu(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VVnwrW():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVUdg7(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CCdwmB.VVeZvR()
 @staticmethod
 def VVeZvR():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CCHGCV(ScrollLabel):
 def __init__(self, parentSELF, text="", VV9HcP=True):
  ScrollLabel.__init__(self, text)
  self.VV9HcP   = VV9HcP
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VV8BcX  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVJmZ8    = None
  self.parentW    = None
  self.parentH    = None
  self.firstTime    = True
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VVKAa7 ,
   "green"   : self.VV6kNI ,
   "yellow"  : self.VVGH5m ,
   "blue"   : self.VVNi8m ,
   "up"   : self.VVL78B   ,
   "down"   : self.VVSVHh  ,
   "left"   : self.VVL78B   ,
   "right"   : self.VVSVHh  ,
   "last"   : BF(self.VVekpe, 0) ,
   "0"    : BF(self.VVekpe, 1) ,
   "next"   : BF(self.VVekpe, 2) ,
   "pageUp"  : self.VV5GyJ   ,
   "chanUp"  : self.VV5GyJ   ,
   "pageDown"  : self.VVyAaL   ,
   "chanDown"  : self.VVyAaL
  }, -1)
 def VVYV4X(self, isResizable=True, VVttKB=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFLsU4(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FF0e9t(self.parentSELF["keyRedTop"], "#113A5365")
  FFvDt2(self.parentSELF, True)
  self.isResizable = isResizable
  if VVttKB:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVJmZ8  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FF0e9t(self, color)
 def VVWUAw(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  lineheight  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  lines   = int(self.long_text.size().height() / lineheight)
  margin   = int(lineheight / 6)
  self.pageHeight = int(lines * lineheight)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VV8BcX - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVO7xJ()
 def VVL78B(self):
  if self.VV8BcX > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def VVSVHh(self):
  if self.VV8BcX > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VV5GyJ(self):
  self.setPos(0)
 def VVyAaL(self):
  self.setPos(self.VV8BcX-self.pageHeight)
 def VV623O(self):
  return self.VV8BcX <= self.pageHeight or self.curPos == self.VV8BcX - self.pageHeight
 def getText(self):
  return self.message
 def VVO7xJ(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VV8BcX, 3))
   start = int((100 - vis) * self.curPos / (self.VV8BcX - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVpV1e=VVKznu):
  old_VV623O = self.VV623O()
  self.message = str(text)
  if self.pageHeight:
   self.long_text.setText(self.message)
   self.VV8BcX = max(self.long_text.calculateSize().height(), self.VVJmZ8 * len(self.message.splitlines()))
   if self.VV9HcP and self.VV8BcX > self.pageHeight:
    self.scrollbar.show()
    self.VVO7xJ()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VV8BcX))
   if   VVpV1e == VVXinG: self.setPos(0)
   elif VVpV1e == VVnJeb : self.VVyAaL()
   elif old_VV623O    : self.VVyAaL()
   if self.firstTime and len(self.message) > 0:
    self.firstTime = False
    self.setText(self.message, VVpV1e=VVpV1e)
 def appendText(self, text, VVpV1e=VVnJeb):
  self.setText(self.message + str(text), VVpV1e=VVpV1e)
 def VVGH5m(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVyXp1(size)
 def VVNi8m(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVyXp1(size)
 def VV6kNI(self):
  self.VVyXp1(self.VVJmZ8)
 def VVyXp1(self, VVJmZ8):
  self.long_text.setFont(gFont(self.fontFamily, VVJmZ8))
  self.setText(self.message, VVpV1e=VVKznu)
  self.VV8D9h(calledFromFontSizer=True)
 def VVekpe(self, align):
  self.long_text.setHAlign(align)
 def VVKAa7(self):
  VVW1xb = []
  VVW1xb.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Align Left" , "left" ))
  VVW1xb.append(("Align Center" , "center" ))
  VVW1xb.append(("Align Right" , "right" ))
  if self.outputFileToSave:
   VVW1xb.append(VVswUs)
   VVW1xb.append((FFY7FT("Save to File", VVJ2KG), "save"))
  VVW1xb.append(VVswUs)
  VVW1xb.append(("Keys (Shortcuts)", "help"))
  FFLFXy(self.parentSELF, self.VVEUuS, VVW1xb=VVW1xb, title="Text Option", width=500)
 def VVEUuS(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VVekpe(0)
   elif item == "center" : self.VVekpe(1)
   elif item == "right" : self.VVekpe(2)
   elif item == "save"  : self.VVIFq1()
   elif item == "help"  : FFsiZl(self.parentSELF, "_help_txt", "Text Viewer (Keys)")
 def VVIFq1(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FFnWu0(expPath), self.outputFileToSave, FFJCyp())
   with open(outF, "w") as f:
    f.write(FFyZAn(self.message))
   FF5nWa(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FFa349(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VV8D9h(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VV8BcX > 0 and self.pageHeight > 0:
   if self.VV8BcX < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VV8BcX
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
