import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVzByU   = "v5.0.1"
VVQO5U    = "23-04-2022"
EASY_MODE    = 0
VVuxXM   = 0
VV6vId   = 0
VVdG9z  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVcnky  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVjxPh    = "/media/usb/"
VVDsyD    = "/usr/share/enigma2/picon/"
VV3p6k = "/etc/enigma2/blacklist"
VVEkHL   = "/etc/enigma2/"
VVx9at  = "ajpanel_update_url"
VVrPCL   = "AJPan"
VVTlxf    = "AUTO FIND"
VVl9Ui    = ""
VVg54i    = "Regular"
VVo4vY      = "-" * 80
VVaOJ8    = ("-" * 100, )
VVnwy6    = ""
VVs1qJ   = " && echo 'Successful' || echo 'Failed!'"
VVOxUI    = []
VV0Frc  = "Cannot continue (No Enough Memory) !"
VVPjL0  = False
VVJtGD  = False
VVAFnE = False
VVyaPF     = 0
VVq42k    = 1
VVBM3N    = 2
VVcwsn   = 3
VV48pj    = 4
VVAYOg    = 5
VV8opi = 6
VV34Cv = 7
VVRGT2  = 8
VVf6he   = 9
VVyi6i   = 10
VVbXFe   = 11
VV4T9H  = 12
VVUJoS  = 13
VVxt4h    = 14
VVbLuF   = 15
VVtHnL   = 16
VVNO1G    = 17
WINDOW_SUBTITLE    = 18
VVTbqA  = 19
VVDGzB   = 0
VVL1cJ   = 1
VVcOJJ   = 2
def FFEjBE():
 fList = None
 try:
  from enigma import getFontFaces
  return set(getFontFaces())
 except:
  try:
   from skin import getFontFaces
   return set(getFontFaces())
  except:
   pass
 return [VVg54i]
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices=[ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.forceUtf8Encoding   = ConfigYesNo(default=True)
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsPath    = ConfigDirectory(default=VVTlxf, visible_width=51)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=51)
CFG.PIconsPath     = ConfigDirectory(default=VVDsyD, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVjxPh, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
tmp = [("srt", "From SRT File"), ("#FFFFFF", "White"), ("#C0C0C0", "Silver"), ("#808080", "Gray"), ("#000000", "Black"), ("#FF0000", "Red"), ("#800000", "Maroon"), ("#FFFF00", "Yellow"), ("#808000", "Olive"), ("#00FF00", "Lime"), ("#008000", "Green"), ("#00FFFF", "Aqua"), ("#008080", "Teal"), ("#0000FF", "Blue"), ("#000080", "Navy"), ("#FF00FF", "Fuchsia"), ("#800080", "Purple")]
CFG.subtDelay     = ConfigSelection(default="0.0", choices=[ (str(x/10.0),  str(x/10.0)) for x in range(-600, 600, 5) ])
CFG.subtTextFg     = ConfigSelection(default="srt", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVg54i, choices=[ (x,  x) for x in FFEjBE() ])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=80, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[ ("0", "Left"), ("1", "Center"), ("2", "Right") ])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=0, stepwidth=10, min=-140, max=140, wraparound=False)
del tmp
def FFmi5I():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVAZ6B  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VV1xx4 = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVAZ6B  : return 0
  elif VV1xx4 : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVoUIZ = FFmi5I()
VV1Lqa = VV5UCJ = VV13Hf = VVi1SQ = VVCfQO = VVOA2D = VVplBl = VVqWH2 = COLOR_CONS_BRIGHT_YELLOW = VVtzSE = VVZ9CV = VVZj00 = VVLtc8 = ""
def FFeOcA()  : return FFUQhw()
def FFREry(*args) : FFrYPt(True , True , *args)
def FFjenD(*args): FFrYPt(False, True , *args)
def FFtLTh(*args): FFrYPt(True, False, *args)
def FFrYPt(addSep=True, oneLine=True, *args):
 if VVuxXM:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if oneLine:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  else:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item:
      txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFrpVu(txt, isAppend=True, ignoreErr=False):
 if VVuxXM:
  tm = FFpait()
  err = ""
  if not ignoreErr:
   err = FFUQhw()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFREry(err)
  FFREry("Output Log File : %s" % fileName)
def FFUQhw():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFpait()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except Exception as e:
  return "Cannot Trace !"
def FF4j1f():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVOxUI = []
def FFZw75(win):
 global VVOxUI
 if not win in VVOxUI:
  VVOxUI.append(win)
def FFQ6xc(*args):
 global VVOxUI
 for win in VVOxUI:
  try:
   win.close()
  except:
   pass
 VVOxUI = []
def FF7Bsr():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVwuVG = FF7Bsr()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFM2Su()     : return PluginDescriptor(fnc=FFR3cq, where=[PluginDescriptor.WHERE_SESSIONSTART] , needsRestart=True   , description="AJPanel Startup")
def FFn4v0()      : return getDescriptor(FFg5ya   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFBYjx()       : return getDescriptor(FFZnJp  , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFBHpB()   : return getDescriptor(FF0zzF , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFFH8u(): return getDescriptor(FFKj5c , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player"  , descr="Signal Monitor / Player")
def FFcbJ2()  : return getDescriptor(FFT1mg  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV"     , descr="IPTV Menu")
def FFWliB()     : return getDescriptor(FFwW4f , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info."    , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFn4v0() , FFBYjx() , FFM2Su() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFBHpB())
  result.append(FFFH8u())
  result.append(FFcbJ2())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFWliB())
 return result
def FFR3cq(reason, **kwargs):
 if reason == 0:
  FFaVI4()
  if "session" in kwargs:
   session = kwargs["session"]
   FFARXZ(session)
   CCrCPE(session)
  CCy6sJ.VVANe3()
def FFZnJp(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFg5ya, PLUGIN_NAME, 45)]
 else:
  return []
def FFg5ya(session, **kwargs):
 session.open(Main_Menu)
def FF0zzF(session, **kwargs):
 session.open(CC82J5)
def FFKj5c(session, **kwargs):
 FFbtMj(session, isFromSession=True)
def FFT1mg(session, **kwargs):
 session.open(CCniMM)
def FFwW4f(session, **kwargs):
 session.open(CCip5O, fncMode=CCip5O.VVC9O2)
def FF6HBs():
 FFTDNF(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFBHpB(), FFFH8u(), FFcbJ2() ])
 FFTDNF(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFWliB() ])
def FFTDNF(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VV8afR = None
def FFaVI4():
 try:
  global VV8afR
  if VV8afR is None:
   VV8afR    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFsCw0
  ChannelContextMenu.FFVeEN = FFVeEN
 except:
  pass
def FFsCw0(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VV8afR(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFVeEN, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFVeEN, title1, csel, isFind=True))))
def FFVeEN(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFEChB(refCode)
 except:
  pass
 self.session.open(boundFunction(CC32MW, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFARXZ(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FF50It, session, "lok")
 hk.actions['longCancel'] = boundFunction(FF50It, session, "lesc")
 hk.actions['longRed']  = boundFunction(FF50It, session, "lred")
def FF50It(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFbtMj(session, isFromSession=True)
def FFFsOT(SELF, title="", addLabel=False, addScrollLabel=False, VVhOvi=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFzohF()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCb5vh(SELF)
 if VVhOvi:
  SELF["myMenu"] = MenuList(VVhOvi)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVIpBc        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFXMHc(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FFYCsa, SELF, "0") ,
  "1"    : boundFunction(FFYCsa, SELF, "1") ,
  "2"    : boundFunction(FFYCsa, SELF, "2") ,
  "3"    : boundFunction(FFYCsa, SELF, "3") ,
  "4"    : boundFunction(FFYCsa, SELF, "4") ,
  "5"    : boundFunction(FFYCsa, SELF, "5") ,
  "6"    : boundFunction(FFYCsa, SELF, "6") ,
  "7"    : boundFunction(FFYCsa, SELF, "7") ,
  "8"    : boundFunction(FFYCsa, SELF, "8") ,
  "9"    : boundFunction(FFYCsa, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FF2sBw, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFYCsa(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVLtc8:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVLtc8 + SELF.keyPressed + VV5UCJ)
    txt = VV5UCJ + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFbstz(SELF, txt)
def FF2sBw(SELF, tableObj, colNum):
 FFbstz(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     SELF.VVupmb(i)
     break
 except:
  pass
def FFL8cC(SELF, setMenuAction=True):
 if setMenuAction:
  global VVnwy6
  VVnwy6 = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFzohF():
 return ("  %s" % VVnwy6)
def FFydgK(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFwPAs(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFp86o(color):
 return parseColor(color).argb()
def FFxrbm(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFpqr2(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFbjpo(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FF23Tm(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVLtc8)
 else:
  return ""
def FFRcES(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVo4vY, word, VVo4vY, VVLtc8)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVo4vY, word, VVo4vY)
def FFFpMs(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVLtc8
def FFQbM5(color):
 if color: return "echo -e '%s' %s;" % (VVo4vY, FF23Tm(VVo4vY, VVqWH2))
 else : return "echo -e '%s';" % VVo4vY
def FF6kX4(title, color):
 title = "%s\n%s\n%s\n" % (VVo4vY, title, VVo4vY)
 return FFFpMs(title, color)
def FFEktE(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFvPiT(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFHmgI(callBackFunction):
 tCons = CCyIWM()
 tCons.ePopen("echo", boundFunction(FF0pUL, callBackFunction))
def FF0pUL(callBackFunction, result, retval):
 callBackFunction()
def FFmTns(SELF, fnc, title="Processing ...", clearMsg=True):
 FFbstz(SELF, title)
 tCons = CCyIWM()
 tCons.ePopen("echo", boundFunction(FFzIY7, SELF, fnc, clearMsg))
def FFzIY7(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFbstz(SELF)
def FFktqw(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VV0Frc
  else       : return ""
def FFGCWo(cmd):
 txt = FFktqw(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFSDWT(cmd):
 lines = FFGCWo(cmd)
 if lines: return lines[0]
 else : return ""
def FFWsAQ(SELF, cmd):
 lines = FFGCWo(cmd)
 VV2X4t = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VV2X4t.append((key, val))
  elif line:
   VV2X4t.append((line, ""))
 if VV2X4t:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFyzis(SELF, None, header=header, VV2PlJ=VV2X4t, VVDrmL=widths, VVCZ7I=28)
 else:
  FFZ9oT(SELF, cmd)
def FFZ9oT(    SELF, cmd, **kwargs): SELF.session.open(CCRA8D, VVlQdH=cmd, VVvvzl=True, VVLw9T=VVL1cJ, **kwargs)
def FF6wP8(  SELF, cmd, **kwargs): SELF.session.open(CCRA8D, VVlQdH=cmd, **kwargs)
def FFS0Ql(   SELF, cmd, **kwargs): SELF.session.open(CCRA8D, VVlQdH=cmd, VV23Fc=True, VVZfkK=True, VVLw9T=VVL1cJ, **kwargs)
def FFpX68(  SELF, cmd, **kwargs): SELF.session.open(CCRA8D, VVlQdH=cmd, VV23Fc=True, VVZfkK=True, VVLw9T=VVcOJJ, **kwargs)
def FFHbvq(  SELF, cmd, **kwargs): SELF.session.open(CCRA8D, VVlQdH=cmd, VVYg4L=True , **kwargs)
def FFdjeT( SELF, cmd, **kwargs): SELF.session.open(CCRA8D, VVlQdH=cmd, VV4qJS=True   , **kwargs)
def FFHHyb( SELF, cmd, **kwargs): SELF.session.open(CCRA8D, VVlQdH=cmd, VVjuGL=True  , **kwargs)
def FFiu56(cmd):
 return cmd + " > /dev/null 2>&1"
def FF5kRq():
 return " > /dev/null 2>&1"
def FFrgtg(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFBbZi(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFSRwQ():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFSDWT(cmd)
VVbsC9     = 0
VVPGrZ      = 1
VV4I1T   = 2
VVZCfy      = 3
VVQ3or      = 4
VVypMU     = 5
VVIqrC     = 6
VVwEDD = 7
VVzcHK = 8
VVVmdf = 9
VVCbLd  = 10
VVhJVe     = 11
VVmguF  = 12
VVHkLQ  = 13
def FFSU1Z(parmNum, grepTxt):
 if   parmNum == VVbsC9  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVPGrZ   : param = ["list"   , "apt list" ]
 elif parmNum == VV4I1T: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFSRwQ()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FF5ENR(parmNum, package):
 if   parmNum == VVZCfy      : param = ["info"      , "apt show"         ]
 elif parmNum == VVQ3or      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVypMU     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVIqrC     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVwEDD : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVzcHK : param = ["install --force-overwrite" , "dpkg -i --force-overwrite -y"    ]
 elif parmNum == VVVmdf : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVCbLd  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVhJVe     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVmguF  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVHkLQ  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFSRwQ()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFCv1g():
 result = FFSDWT("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FF5ENR(VVIqrC , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFiu56("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFiu56("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FF23Tm(failed1, VVqWH2))
   cmd += "  echo -e '%s' %s;"  % (failed2, FF23Tm(failed2, VVqWH2))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FF23Tm(failed3, VV13Hf))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFevla(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FF5ENR(VVIqrC , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFiu56("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FF23Tm(failed1, VVqWH2))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FF23Tm(failed2, VV13Hf))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFKIlG(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFiu56('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFiu56("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFJPcA(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCy6sJ.VVpClh()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFQoVo(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFJPcA(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFxImT(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFEZNr(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFJPcA(path, maxSize=maxSize, encLst=encLst)
  if lines: FFHVXB(SELF, lines, title=title, VVLw9T=VVL1cJ)
  else : FFFNOf(SELF, path, title=title)
 else:
  FFUQ3Z(SELF, path, title)
def FFftZ9(SELF, path, title):
 if fileExists(path):
  txt = FFJPcA(path)
  txt = txt.replace("#W#", VVLtc8)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VV5UCJ)
  txt = txt.replace("#C#", VVtzSE)
  txt = txt.replace("#P#", VVi1SQ)
  FFHVXB(SELF, txt, title=title)
 else:
  FFUQ3Z(SELF, path, title)
def FFAGME(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FF0MA9(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFG47Q(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFwI5c(parent)
 else    : return FFKGzo(parent)
def FFEZNr(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFwI5c(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFKGzo(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFzhEz():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVdG9z)
 paths.append(VVdG9z.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FF0MA9(ba)
 for p in list:
  p = ba + p + VVdG9z
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVrPCL, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVdG9z, VVrPCL , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVIZJG, VVoH8d = FFzhEz()
def FFoeH0():
 def VVVQrX(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 iPath = CFG.iptvHostsPath.getValue()
 if not iPath == VVTlxf and not pathExists(iPath):
  CFG.iptvHostsPath.setValue(VVTlxf)
  CFG.iptvHostsPath.save()
  oldIptvHostsPath = VVTlxf
 else:
  oldIptvHostsPath = ""
 oldMovieDownloadPath = VVVQrX(CFG.MovieDownloadPath, CCnmQ8.VVlaGn())
 VV6azX   = VVVQrX(CFG.backupPath, CCRZq2.VVSzXI())
 VVcWFJ   = VVVQrX(CFG.downloadedPackagesPath, t)
 VVJ2v8  = VVVQrX(CFG.exportedTablesPath, t)
 VVn7i4  = VVVQrX(CFG.exportedPIconsPath, t)
 VVjq2t   = VVVQrX(CFG.packageOutputPath, t)
 global VVjxPh
 VVjxPh = FFwI5c(CFG.backupPath.getValue())
 if VV6azX or VVjq2t or VVcWFJ or VVJ2v8 or VVn7i4 or oldIptvHostsPath or oldMovieDownloadPath:
  configfile.save()
 return VV6azX, VVjq2t, VVcWFJ, VVJ2v8, VVn7i4, oldIptvHostsPath, oldMovieDownloadPath
def FFUCAY(path):
 path = FFKGzo(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFgT7p(SELF, pathList, tarFileName, addTimeStamp=True):
 VV2PlJ = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VV2PlJ.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VV2PlJ.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VV2PlJ.append(path)
 if not VV2PlJ:
  FF2wyP(SELF, "Files not found!")
 elif not pathExists(VVjxPh):
  FF2wyP(SELF, "Path not found!\n\n%s" % VVjxPh)
 else:
  VVMnWt = FFwI5c(VVjxPh)
  tarFileName = "%s%s" % (VVMnWt, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFHXaa())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VV2PlJ:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVo4vY
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FF23Tm(tarFileName, VVplBl))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FF23Tm(failed, VVplBl))
  cmd += "fi;"
  cmd +=  sep
  FF6wP8(SELF, cmd)
def FFBLtF(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FF9Trc(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FF9Trc(SELF["keyInfo"], "info")
def FF9Trc(barObj, fName):
 path = "%s%s%s" % (VVoH8d, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FF5Tue(SELF, title, VVbFcr, showGrnMsg=""):
 SELF.session.open(boundFunction(CC0WxQ, title=title, VVbFcr=VVbFcr, showGrnMsg=showGrnMsg))
def FFnRFN(labelObj, VVbFcr):
 if VVbFcr and fileExists(VVbFcr):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VVHm6k(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VVHm6k)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VVbFcr)
   return True
  except:
   pass
 return False
def FFf0Ve(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFGrAn(satNum)
  return satName
def FFGrAn(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFYPEg(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFf0Ve(val)
  else  : sat = FFGrAn(val)
 return sat
def FFYd0o(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFf0Ve(num)
 except:
  pass
 return sat
def FFZ8tX(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFiApO(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFbHPv(info, iServiceInformation.sServiceref)
   prov = FFbHPv(info, iServiceInformation.sProvider)
   state = str(FFbHPv(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFupNy(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFONbJ(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFbHPv(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFTmWm(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFEChB(refCode):
 info = FFyn1o(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FF2DXN(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFtUoc(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFyn1o(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VV4lW6 = eServiceCenter.getInstance()
  if VV4lW6:
   info = VV4lW6.info(service)
 return info
def FFulYh(SELF, refCode, VVK8qL=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  FFCH4i(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVK8qL:
   FFbtMj(SELF, isFromSession)
 try:
  VVhiUf = InfoBar.instance
  if VVhiUf:
   VVdb8z = VVhiUf.servicelist
   if VVdb8z:
    servRef = eServiceReference(refCode)
    VVdb8z.saveChannel(servRef)
 except:
  pass
def FFCH4i(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCLv4R()
    if pr.VVrxHz(refCode, chName, decodedUrl, iptvRef):
     pr.VVLsnw(SELF, isFromSession)
def FFupNy(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFdSDy(url): return any(x in url for x in ("/movie/", "/series/", "mode=vod", "mode=series"))
def FFO3gx(url)  : return any(x in url for x in ("/movie/", "mode=vod"))
def FFfO63(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FFONbJ(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFjPwi(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFJeEN(userBfile):
 txt = ""
 bFile = VVEkHL + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVEkHL + userBfile):
  fTxt = FFJPcA(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFSDWT('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
def FFjPwi(url):
 if iUnquote : return iUnquote(url)
 else  : return url
def FFeJBn(url):
 if iQuote : return iQuote(url)
 else  : return url
def FFXUin(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFdMsE(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFqn0h(txt):
 try:
  return FFXUin(FFdMsE(txt)) == txt
 except:
  return False
def FFbtMj(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCrMvG, isFromExternal=isFromSession)
 else      : FFj5NQ(session, reopen=True, isFromExternal=isFromSession)
def FFj5NQ(session, reopen=False, isFromExternal=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFj5NQ, session, isFromExternal=isFromExternal), boundFunction(CCpjoh, isFromExternal=isFromExternal))
  except:
   try:
    FFtOs7(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFL0hm(refCode):
 tp = CCPwtQ()
 if tp.VVRifh(refCode) : return True
 else        : return False
def FFHJrf(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFgjOJ():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FFRVXA():
 VVhiUf = InfoBar.instance
 if VVhiUf:
  VVdb8z = VVhiUf.servicelist
  if VVdb8z:
   return VVdb8z.getBouquetList()
 return None
def FFIVg3():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFyTPg():
 path = FFIVg3()
 if path:
  txt = FFJPcA(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FFthWl():
 return FF0wye(InfoBar.instance.servicelist.getRoot())
def FF0wye(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VV4lW6 = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VV4lW6.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FFqZca():
 VV1wel = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VV6QHu = list(VV1wel)
 return VV6QHu, VV1wel
def FFdk6f():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFWwtt(session, VVwRlx):
 VVb23n, VVvSE5, VVOTo1, camCommand = FFcwnW()
 if VVvSE5:
  runLog = False
  if   VVwRlx == CCk7Ar.VV3uVY : runLog = True
  elif VVwRlx == CCk7Ar.VVguqV : runLog = True
  elif not VVOTo1          : FFtOs7(session, message="SoftCam not started yet!")
  elif fileExists(VVOTo1)        : runLog = True
  else             : FFtOs7(session, message="File not found !\n\n%s" % VVOTo1)
  if runLog:
   session.open(boundFunction(CCk7Ar, VVb23n=VVb23n, VVvSE5=VVvSE5, VVOTo1=VVOTo1, VVwRlx=VVwRlx))
 else:
  FFtOs7(session, message="No active OSCam/NCam found !", title="Live Log")
def FFcwnW():
 VVb23n = "/etc/tuxbox/config/"
 VVvSE5 = None
 VVOTo1  = None
 camCommand = FFSDWT("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVvSE5 = "oscam"
 elif "ncam"  in camCommand : VVvSE5 = "ncam"
 if VVvSE5:
  path = FFSDWT(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFwI5c(path)
  if pathExists(path):
   VVb23n = path
  tFile = VVb23n + VVvSE5 + ".conf"
  tFile = FFSDWT("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVOTo1 = tFile
 return VVb23n, VVvSE5, VVOTo1, camCommand
def FF0V0A(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FF8TPi():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFHXaa():
 return FF8TPi().replace(" ", "_").replace("-", "").replace(":", "")
def FFuGN6(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFpait():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFBgNy(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCniMM.VVawMx(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCniMM.VVwv6Z_forBouquet(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFiu56("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFpAYp(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFWpp1(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
VVnSSJ = 0
def FFxsPu():
 global VVnSSJ
 VVnSSJ = iTime()
def FF1yUG():
 FFREry(">>>>>> Elapsed\t: {:.6f} seconds".format(iTime() - VVnSSJ).rstrip("0").rstrip("."))
def FFnN3Y(SELF, message, title=""):
 SELF.session.open(boundFunction(CCtcZh, title=title, message=message, VVheTH=True))
def FFHVXB(SELF, message, title="", VVLw9T=VVL1cJ, **kwargs):
 SELF.session.open(boundFunction(CCtcZh, title=title, message=message, VVLw9T=VVLw9T, **kwargs))
def FF2wyP(SELF, message, title="")  : FFtOs7(SELF.session, message, title)
def FFUQ3Z(SELF, path, title="") : FFtOs7(SELF.session, "File not found !\n\n%s" % path, title)
def FFFNOf(SELF, path, title="") : FFtOs7(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFAopx(SELF, title="")  : FFtOs7(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFtOs7(session, message, title="") : session.open(boundFunction(CCV4IB, title=title, message=message))
def FFK2QC(SELF, VVPtly, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVPtly, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVPtly, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVPtly, boundFunction(CCM6NZ, title=title, message=message, VVa0Z4=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FF2wyP(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFStgm(SELF, callBack_Yes, VVxngl, callBack_No=None, title="", VVU3wZ=False, VVeJwQ=True):
 SELF.session.openWithCallback(boundFunction(FFnQ5D, callBack_Yes, callBack_No)
        , boundFunction(CCpUH0, title=title, VVxngl=VVxngl, VVeJwQ=VVeJwQ, VVU3wZ=VVU3wZ))
def FFnQ5D(callBack_Yes, callBack_No, FFStgmed):
 if FFStgmed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFbstz(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFpqr2(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FF0vNh(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFzWzb(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVMoU6 = eTimer()
def FF0vNh(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFUJTs, SELF))
 fnc = boundFunction(FFUJTs, SELF)
 try:
  t = VVMoU6.timeout.connect(fnc)
 except:
  VVMoU6.callback.append(fnc)
 VVMoU6.start(milliSeconds, 1)
def FFUJTs(SELF):
 VVMoU6.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFyzis(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCNc3Q, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCNc3Q, **kwargs))
  FFZw75(win)
  return win
 except:
  return None
def FFN6sa(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CC7mY3, **kwargs))
 FFZw75(win)
 return win
def FFhDEp(SELF, **kwargs):
 SELF.session.open(CCip5O, **kwargs)
def FFNepU(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFLbRz(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVg54i, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFwhmb(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFLbRz(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFbp9X():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFLIqC(VVCZ7I):
 screenSize  = FFbp9X()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVCZ7I)
 return bodyFontSize
def FFLtf8(VVCZ7I, extraSpace):
 font = gFont(VVg54i, VVCZ7I)
 VVDe7d = fontRenderClass.getInstance().getLineHeight(font) or (VVCZ7I * 1.25)
 return int(VVDe7d + VVDe7d * extraSpace)
def FF82u7(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFbp9X()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVg54i, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFLtf8(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVg54i, titleFontSize, alignLeftCenter)
 if winType == VVyaPF or winType == VVq42k:
  if winType == VVq42k : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVTbqA:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == WINDOW_SUBTITLE:
  lineH = int((height - 8) / 3.0)
  top = 2
  tmp += '<widget name="mySubtFr" position="0,0" size="%d,%d" zPosition="10" backgroundColor="#00FFFF00" />' % (width, height)
  for i in range(3):
   tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="11" foregroundColor="#ffffff" shadowColor="#555555" shadowOffset="-2,-2" backgroundColor="#ff000000" %s %s />' % (i, top + 2, width - 2, lineH - 2, bodyFontStr, alignCenter)
   top += lineH
 elif winType == VVxt4h:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FFnN3YL = b2Left2 + timeW + marginLeft
  FFnN3YW = b2Left3 - marginLeft - FFnN3YL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FFnN3YL  , b2Top, FFnN3YW , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
 elif winType == VVbLuF:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VV48pj:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVBM3N:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVcwsn:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVg54i, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVg54i, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVyi6i:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFnN3YH = int(bodyH * 0.5)
  inpTop = bodyTop + FFnN3YH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFnN3YH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVg54i, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVg54i, mapF, alignCenter)
 elif winType == VVbXFe:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VV4T9H:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVg54i, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVtHnL:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVg54i, fontH, alignCenter)
 elif winType == VVUJoS:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVg54i, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVg54i, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVg54i, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVNO1G:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 else:
  if   winType == VV34Cv : align = alignLeftCenter
  elif winType == VV8opi : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVf6he:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VVAYOg:
   moreParams = ""
  else:
   fontName = VVg54i
   if usefixedFont and winType == VV8opi:
    fnt = "Fixed"
    if fnt in FFEjBE():
     fontName = "Fixed"
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVCZ7I = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVg54i, VVCZ7I, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVPEgn = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVg54i, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVPEgn[i], VVg54i, barFont, alignCenter)
   left += btnW + gap
 if winType == VV8opi:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVPEgn = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVPEgn[i], VVg54i, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF82u7(VVyaPF, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.VVGK1e = ""
  self.themsList  = []
  VVhOvi = []
  if VV6vId:
   VVhOvi.append(("-- MY TEST --"    , "myTest"   ))
  VVhOvi.append(("  File Manager"     , "FileManager"  ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("  Services/Channels"    , "ChannelsTools" ))
  VVhOvi.append(("  IPTV"       , "IptvTools"  ))
  VVhOvi.append(("  PIcons"       , "PIconsTools"  ))
  VVhOvi.append(("  SoftCam"      , "SoftCam"   ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("  Plugins"      , "PluginsTools" ))
  VVhOvi.append(("  Terminal"      , "Terminal"  ))
  VVhOvi.append(("  Backup & Restore"    , "BackupRestore" ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("  Date/Time"      , "Date_Time"  ))
  VVhOvi.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVhOvi)
  FFFsOT(self, VVhOvi=VVhOvi)
  FFydgK(self["keyRed"] , "Exit")
  FFydgK(self["keyGreen"] , "Settings")
  FFydgK(self["keyYellow"], "Dev. Info.")
  FFydgK(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VV0bIS       ,
   "yellow"  : self.VV8Hfm       ,
   "blue"   : self.VVphko       ,
   "info"   : self.VVphko       ,
   "next"   : self.VVPIP9       ,
   "menu"   : self.VViilN     ,
   "text"   : self.VVffUr      ,
   "0"    : boundFunction(self.VV0ju8, 0) ,
   "1"    : boundFunction(self.VVBFoS, 1)   ,
   "2"    : boundFunction(self.VVBFoS, 2)   ,
   "3"    : boundFunction(self.VVBFoS, 3)   ,
   "4"    : boundFunction(self.VVBFoS, 4)   ,
   "5"    : boundFunction(self.VVBFoS, 5)   ,
   "6"    : boundFunction(self.VVBFoS, 6)   ,
   "7"    : boundFunction(self.VVBFoS, 7)   ,
   "8"    : boundFunction(self.VVBFoS, 8)   ,
   "9"    : boundFunction(self.VVBFoS, 9)
  })
  self.onShown.append(self.VVqrW9)
  self.onClose.append(self.onExit)
  global VVPjL0, VVJtGD, VVAFnE
  VVPjL0 = VVJtGD = VVAFnE = False
 def VVIpBc(self):
  item = FFL8cC(self)
  self.VVBFoS(item)
 def VVBFoS(self, item):
  if item is not None:
   if   item == "myTest"     : self.VV51VF()
   elif item in ("FileManager"  , 1) : self.session.open(CC82J5)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCz7Lj)
   elif item in ("IptvTools"  , 3) : self.session.open(CCniMM)
   elif item in ("PIconsTools"  , 4) : self.VVgVsw()
   elif item in ("SoftCam"   , 5) : self.session.open(CCG782)
   elif item in ("PluginsTools" , 6) : self.session.open(CC0yAR)
   elif item in ("Terminal"  , 7) : self.session.open(CCqPfT)
   elif item in ("BackupRestore" , 8) : self.session.open(CCKoF7)
   elif item in ("Date_Time"  , 9) : self.session.open(CCgRxy)
   elif item in ("CheckInternet" , 10) : self.session.open(CCeCZG)
   else         : self.close()
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FFEktE(self["myMenu"])
  FFwhmb(self)
  FFNepU(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVzByU)
  self["myTitle"].setText(title)
  VV6azX, VVjq2t, VVcWFJ, VVJ2v8, VVn7i4, oldIptvHostsPath, oldMovieDownloadPath = FFoeH0()
  self.VV4wmz()
  if VV6azX or VVjq2t or VVcWFJ or VVJ2v8 or VVn7i4 or oldIptvHostsPath or oldMovieDownloadPath:
   VVtlsz = lambda path, subj: "%s:\n%s\n\n" % (subj, FFFpMs(path, VV13Hf)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVtlsz(oldIptvHostsPath  , "IPTV Hosts Files Path"   )
   txt += VVtlsz(VV6azX   , "Backup/Restore Path"    )
   txt += VVtlsz(VVjq2t  , "Created Package Files (IPK/DEB)" )
   txt += VVtlsz(VVcWFJ  , "Download Packages (from feeds)" )
   txt += VVtlsz(VVJ2v8 , "Exported Tables"     )
   txt += VVtlsz(VVn7i4 , "Exported PIcons"     )
   txt += VVtlsz(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFHVXB(self, txt, title="Settings Paths")
  if (EASY_MODE or VVuxXM or VV6vId):
   FFpqr2(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFbstz(self, "Welcome", 300)
  FFHmgI(boundFunction(self.VVjjZG, title))
 def VVjjZG(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCRZq2.VVaEFH()
   if url:
    newWebVer = CCRZq2.VVB5SV(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFiu56("rm /tmp/ajpanel*"))
  global VVPjL0, VVJtGD, VVAFnE
  VVPjL0 = VVJtGD = VVAFnE = False
 def VV0ju8(self, digit):
  self.VVGK1e += str(digit)
  ln = len(self.VVGK1e)
  global VVPjL0, VVAFnE
  if ln == 4:
   if self.VVGK1e == "0" * ln:
    VVPjL0 = True
    FFpqr2(self["myTitle"], "#800080")
   else:
    self.VVGK1e = "x"
  elif self.VVGK1e == "0" * 8:
   VVAFnE = True
 def VVPIP9(self):
  self.VVGK1e += ">"
  if self.VVGK1e == "0" * 4 + ">" * 2:
   global VVJtGD
   VVJtGD = True
   FFpqr2(self["myTitle"], "#dd5588")
 def VVffUr(self):
  if self.VVGK1e == "0" * 4:
   ok = False
   fnt = "ae_AlMateen.ttf"
   fontFile = "/usr/share/fonts/%s" % fnt
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    try:
     addFont(fontFile, fontName, 100, True)
     ok = True
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      ok = True
     except:
      pass
   if ok: txt = 'Added Font: "%s"' % fnt
   else : txt = '"%s" Not Found' % fnt
   FFbstz(self, txt, 2000, isGrn=ok)
 def VVgVsw(self):
  found = False
  pPath = CCpHVD.VVRh8o()
  if pathExists(pPath):
   for fName, fType in CCpHVD.VVK9BJ(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCpHVD)
  else:
   VVhOvi = []
   VVhOvi.append(("PIcons Manager" , "CCpHVD" ))
   VVhOvi.append(VVaOJ8)
   VVhOvi.append(CCpHVD.VVNZ4l())
   VVhOvi.append(VVaOJ8)
   VVhOvi += CCpHVD.VVChtx()
   FFN6sa(self, self.VVzTwf, VVhOvi=VVhOvi)
 def VVzTwf(self, item=None):
  if item:
   if   item == "CCpHVD"   : self.session.open(CCpHVD)
   elif item == "VVVHpc"  : CCpHVD.VVVHpc(self)
   elif item == "VVCB4T"  : CCpHVD.VVCB4T(self)
   elif item == "findPiconBrokenSymLinks" : CCpHVD.VV2yfG(self, True)
   elif item == "FindAllBrokenSymLinks" : CCpHVD.VV2yfG(self, False)
 def VV0bIS(self):
  self.session.open(CCRZq2)
 def VV8Hfm(self):
  self.session.open(CCA2Fs)
 def VVphko(self):
  changeLogFile = VVoH8d + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FFQoVo(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFFpMs("\n%s\n%s\n%s" % (VVo4vY, line, VVo4vY), VVi1SQ, VVLtc8)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FFFpMs(line, VV5UCJ, VVLtc8)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFHVXB(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VVzByU), VVCZ7I=26)
 def VViilN(self):
  VVhOvi = []
  VVhOvi.append(("Title Colors"   , "title" ))
  VVhOvi.append(("Menu Area Colors"  , "body" ))
  VVhOvi.append(("Menu Pointer Colors" , "cursor" ))
  VVhOvi.append(("Bottom Bar Colors" , "bar"  ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Reset Colors"   , "reset" ))
  title = "Main Menu Colors"
  FFN6sa(self, boundFunction(self.VVdDvu, title), VVhOvi=VVhOvi, width=500, title=title)
 def VVdDvu(self, title, item=None):
  if item:
   if item == "reset":
    FFStgm(self, self.VVj86E, "Reset to default colors ?", title=title)
   else:
    tDict = self.VVIB0F()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VViXls, tDict, item), CC1ykL, defFG=fg, defBG=bg)
 def VVTD1q(self):
  return VVjxPh + "ajpanel_colors"
 def VVIB0F(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVTD1q()
  if fileExists(p):
   txt = FFJPcA(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VViXls(self, tDict, item, fg, bg):
  if fg:
   self.VVAbVP(item, fg)
   self.VVfsjL(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVWdAa(tDict)
 def VVWdAa(self, tDict):
   p = self.VVTD1q()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVAbVP(self, item, fg):
  if   item == "title" : FFxrbm(self["myTitle"], fg)
  elif item == "body"  :
   FFxrbm(self["myMenu"], fg)
   FFxrbm(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFpqr2(self["myBar"], fg)
   FFxrbm(self["keyRed"], fg)
   FFxrbm(self["keyGreen"], fg)
   FFxrbm(self["keyYellow"], fg)
   FFxrbm(self["keyBlue"], fg)
 def VVfsjL(self, item, bg):
  if   item == "title" : FFpqr2(self["myTitle"], bg)
  elif item == "body"  :
   FFpqr2(self["myMenu"], bg)
   FFpqr2(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFpqr2(self["myBar"], bg)
 def VVj86E(self):
  os.system(FFiu56("rm %s" % self.VVTD1q()))
  self.close()
 def VV4wmz(self):
  tDict = self.VVIB0F()
  self.VVQ4rS(tDict, "title")
  self.VVQ4rS(tDict, "body")
  self.VVQ4rS(tDict, "cursor")
  self.VVQ4rS(tDict, "bar")
 def VVQ4rS(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVAbVP(name, fg)
  if bg: self.VVfsjL(name, bg)
 def VV51VF(self):
  FFbtMj(self)
class CCy6sJ():
 @staticmethod
 def VVpClh():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVANe3(isApply=False):
  global VVnLJy, VV3fmU
  VVnLJy  = True
  VV3fmU = CCy6sJ.VV0BIf()
  CCy6sJ.VVNNnJ()
 @staticmethod
 def VVNNnJ():
  if VV3fmU:
   global VVnLJy
   if CFG.forceUtf8Encoding.getValue():
    if CCy6sJ.VVCsiz() : VVnLJy = True
    else        : VVnLJy = False
   else:
    CCy6sJ.VVSYIu()
    VVnLJy = False
 @staticmethod
 def VV0BIf(isApply=False):
  from sys import version_info
  if version_info[0] >= 3 and version_info[1] >= 10:
   path = "/etc/issue"
   if fileExists(path):
    path = "/etc/issue"
    if fileExists(path):
     txt = FFJPcA(path)
     span = iSearch(r"open.?vision", txt, IGNORECASE)
     if span:
      return True
  return False
 @staticmethod
 def VVCsiz():
  import locale
  enc = locale.getdefaultlocale()[1]
  span = iSearch(r"UTF.?8", enc, IGNORECASE)
  if not span:
   try:
    import locale
    return locale.setlocale(locale.LC_ALL, "en_GB.UTF-8")
   except:
    pass
  return None
 @staticmethod
 def VVSYIu():
  try:
   import locale
   return locale.setlocale(locale.LC_ALL, "")
  except:
   return None
 @staticmethod
 def VV1sbR(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFyzis(SELF, None, VV2PlJ=lst, VVCZ7I=30, VVZLrl=True)
 @staticmethod
 def VVKeHm(path, SELF=None):
  for enc in CCy6sJ.VVpClh():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FF2wyP(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVsT4r(SELF, path, cbFnc, defEnc="", pos=0):
  FFbstz(SELF)
  lst = CCy6sJ.VVTXBq(path)
  if lst:
   VVhOvi = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if defEnc == enc:
     txt = FFFpMs(txt, VVplBl)
    VVhOvi.append((txt, enc))
   win = FFN6sa(SELF, cbFnc, title="Select Encoding", VVhOvi=VVhOvi, width=900, height=500 if pos == 1 else 0)
   if pos == 1:
    win.instance.move(ePoint(40, 40))
  else:
   FFbstz(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVTXBq(path):
  encLst = []
  cPath = VVoH8d + "codecs"
  if fileExists(cPath):
   lines = FFQoVo(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCy6sJ.VVpClh())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    try:
     with ioOpen(path, "r", encoding=enc) as f:
      for line in f:
       pass
     lst.append((item[0], enc))
    except:
     pass
  return lst
class CCA2Fs(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF82u7(VVyaPF, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVhOvi = []
  VVhOvi.append(("Settings File"        , "SettingsFile"   ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Box Info"          , "VVYzBw"    ))
  VVhOvi.append(("Tuners Info"         , "VVXpc9"   ))
  VVhOvi.append(("Python Version"        , "VViPBp"   ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Screen Size"         , "ScreenSize"    ))
  VVhOvi.append(("Language/Locale"        , "Locale"     ))
  VVhOvi.append(("Processor"         , "Processor"    ))
  VVhOvi.append(("Operating System"        , "OperatingSystem"   ))
  VVhOvi.append(("Drivers"          , "drivers"     ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("System Users"         , "SystemUsers"    ))
  VVhOvi.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVhOvi.append(("Uptime"          , "Uptime"     ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Host Name"         , "HostName"    ))
  VVhOvi.append(("MAC Address"         , "MACAddress"    ))
  VVhOvi.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVhOvi.append(("Network Status"        , "NetworkStatus"   ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Disk Usage"         , "VV47Mo"    ))
  VVhOvi.append(("Mount Points"         , "MountPoints"    ))
  VVhOvi.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVhOvi.append(("USB Devices"         , "USB_Devices"    ))
  VVhOvi.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVhOvi.append(("Directory Size"        , "DirectorySize"   ))
  VVhOvi.append(("Memory"          , "Memory"     ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVhOvi.append(("Running Processes"       , "RunningProcesses"  ))
  VVhOvi.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFFsOT(self, VVhOvi=VVhOvi, title="Device Information")
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FFEktE(self["myMenu"])
  FFwhmb(self)
 def VVIpBc(self):
  global VVnwy6
  VVnwy6 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCCfaY)
   elif item == "VVYzBw"    : self.VVYzBw()
   elif item == "VVXpc9"   : self.VVXpc9()
   elif item == "VViPBp"   : self.VViPBp()
   elif item == "ScreenSize"    : FFHVXB(self, "Width\t: %s\nHeight\t: %s" % (FFbp9X()[0], FFbp9X()[1]))
   elif item == "Locale"     : CCy6sJ.VV1sbR(self)
   elif item == "Processor"    : self.VVWRR6()
   elif item == "OperatingSystem"   : FFZ9oT(self, "uname -a"        )
   elif item == "drivers"     : self.VVOIRL()
   elif item == "SystemUsers"    : FFZ9oT(self, "id"          )
   elif item == "LoggedInUsers"   : FFZ9oT(self, "who -a"         )
   elif item == "Uptime"     : FFZ9oT(self, "uptime"         )
   elif item == "HostName"     : FFZ9oT(self, "hostname"        )
   elif item == "MACAddress"    : self.VVo30B()
   elif item == "NetworkConfiguration"  : FFZ9oT(self, "ifconfig %s %s" % (FF23Tm("HWaddr", VVZj00), FF23Tm("addr:", VVqWH2)))
   elif item == "NetworkStatus"   : FFZ9oT(self, "netstat -tulpn"       )
   elif item == "VV47Mo"    : self.VV47Mo()
   elif item == "MountPoints"    : FFZ9oT(self, "mount %s" % (FF23Tm(" on ", VVqWH2)))
   elif item == "FileSystemTable"   : FFZ9oT(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFZ9oT(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFZ9oT(self, "blkid"         )
   elif item == "DirectorySize"   : FFZ9oT(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVEM4k="Reading size ...")
   elif item == "Memory"     : FFZ9oT(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVrbCz()
   elif item == "RunningProcesses"   : FFZ9oT(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFZ9oT(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVgoro()
   else         : self.close()
 def VVo30B(self):
  res = FFktqw("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFHVXB(self, txt)
  else:
   FFZ9oT(self, "ip link")
 def VVyj5Z(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFGCWo(cmd)
  return lines
 def VVqaFl(self, lines, headerRepl, widths, VVFSP3):
  VV2X4t = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VV2X4t.append(parts)
  if VV2X4t and len(header) == len(widths):
   VV2X4t.sort(key=lambda x: x[0].lower())
   FFyzis(self, None, header=header, VV2PlJ=VV2X4t, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=28, VVZLrl=True)
   return True
  else:
   return False
 def VV47Mo(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VVyj5Z(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVFSP3 = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VVqaFl(lines, headerRepl, widths, VVFSP3)
  if not allOK:
   lines = FFGCWo(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFKGzo(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVplBl:
     note = "\n%s" % FFFpMs("Green = Mounted Partitions", VVplBl)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVqWH2
     elif line.endswith(mountList) : color = VVplBl
     else       : color = VV5UCJ
     txt += FFFpMs(line, color) + "\n"
    FFHVXB(self, txt + note)
   else:
    FF2wyP(self, "Not data from system !")
 def VVrbCz(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVyj5Z(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVFSP3 = (LEFT , CENTER, LEFT )
  allOK = self.VVqaFl(lines, headerRepl, widths, VVFSP3)
  if not allOK:
   FFZ9oT(self, cmd)
 def VVOIRL(self):
  cmd = FFSU1Z(VV4I1T, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFZ9oT(self, cmd)
  else : FFAopx(self)
 def VVWRR6(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFZ9oT(self, cmd)
 def VVgoro(self):
  cmd = FFSU1Z(VVPGrZ, "| grep secondstage")
  if cmd : FFZ9oT(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFAopx(self)
 def VVYzBw(self):
  c = VVplBl
  VV2PlJ = []
  VV2PlJ.append((FFFpMs("Box Type"  , c), FFFpMs(self.VVmIpl("boxtype").upper(), c)))
  VV2PlJ.append((FFFpMs("Board Version", c), FFFpMs(self.VVmIpl("board_revision") , c)))
  VV2PlJ.append((FFFpMs("Chipset"  , c), FFFpMs(self.VVmIpl("chipset")  , c)))
  VV2PlJ.append((FFFpMs("S/N"   , c), FFFpMs(self.VVmIpl("sn")    , c)))
  VV2PlJ.append((FFFpMs("Version"  , c), FFFpMs(self.VVmIpl("version")  , c)))
  VVNFwO   = []
  VVxjAa = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVxjAa = SystemInfo[key]
     else:
      VVNFwO.append((FFFpMs(str(key), VVtzSE), FFFpMs(str(SystemInfo[key]), VVtzSE)))
  except:
   pass
  if VVxjAa:
   VVY8C4 = self.VVhEDE(VVxjAa)
   if VVY8C4:
    VVY8C4.sort(key=lambda x: x[0].lower())
    VV2PlJ += VVY8C4
  if VVNFwO:
   VVNFwO.sort(key=lambda x: x[0].lower())
   VV2PlJ += VVNFwO
  if VV2PlJ:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFyzis(self, None, header=header, VV2PlJ=VV2PlJ, VVDrmL=widths, VVCZ7I=28, VVZLrl=True)
  else:
   FFHVXB(self, "Could not read info!")
 def VVmIpl(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFQoVo(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVhEDE(self, mbDict):
  try:
   mbList = list(mbDict)
   VV2PlJ = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VV2PlJ.append((FFFpMs(subject, VVqWH2), FFFpMs(value, VVqWH2)))
  except:
   pass
  return VV2PlJ
 def VVXpc9(self):
  txt = self.VVEQ7i("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVEQ7i("/proc/bus/nim_sockets")
  if not txt: txt = self.VVBZ9g()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFHVXB(self, txt)
 def VVBZ9g(self):
  txt = ""
  VVtlsz = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVtlsz("Slot Name" , slot.getSlotName())
     txt += FFFpMs(slotName, VVqWH2)
     txt += VVtlsz("Description"  , slot.getFullDescription())
     txt += VVtlsz("Frontend ID"  , slot.frontend_id)
     txt += VVtlsz("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVEQ7i(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFQoVo(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFFpMs(line, VVqWH2)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VViPBp(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFHVXB(self, txt)
class CCCfaY(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF82u7(VVyaPF, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVhOvi = []
  VVhOvi.append(("Settings (All)"   , "Settings_All"   ))
  VVhOvi.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  if VVJtGD:
   VVhOvi.append(("Settings (FHDG-17)" , "Settings_FHDG_17"  ))
  VVhOvi.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVhOvi.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVhOvi.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVhOvi.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVhOvi.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFFsOT(self, VVhOvi=VVhOvi)
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FFEktE(self["myMenu"])
  FFwhmb(self)
 def VVIpBc(self):
  global VVnwy6
  VVnwy6 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFZ9oT(self, cmd                )
   elif item == "Settings_HotKeys"   : FFZ9oT(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFZ9oT(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFZ9oT(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFZ9oT(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFZ9oT(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFZ9oT(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFZ9oT(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCG782(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF82u7(VVyaPF, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVb23n, VVvSE5, VVOTo1, camCommand = FFcwnW()
  self.VVvSE5 = VVvSE5
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVhOvi = []
  VVhOvi.append(("OSCam Files"        , "OSCamFiles"  ))
  VVhOvi.append(("NCam Files"        , "NCamFiles"  ))
  VVhOvi.append(("CCcam Files"        , "CCcamFiles"  ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVhOvi.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVhOvi.append(VVaOJ8)
  if VVvSE5:
   if   "oscam" in VVvSE5 : camName = "OSCam"
   elif "ncam"  in VVvSE5 : camName = "NCam"
   VVhOvi.append((camName + " Info."      , "camInfo"   ))
   VVhOvi.append((camName + " Live Status"    , "camLiveStatus" ))
   VVhOvi.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVhOvi.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVhOvi.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFFsOT(self, VVhOvi=VVhOvi)
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FFEktE(self["myMenu"])
  FFwhmb(self)
 def VVIpBc(self):
  global VVnwy6
  VVnwy6 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCFjE0, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCFjE0, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCFjE0, "cccam"))
   elif item == "OSCamReaders"  : self.VVlnz5("os")
   elif item == "NSCamReaders"  : self.VVlnz5("n")
   elif item == "camInfo"   : FFWsAQ(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFWwtt(self.session, CCk7Ar.VV3uVY)
   elif item == "camLiveReaders" : FFWwtt(self.session, CCk7Ar.VVguqV)
   elif item == "camLiveLog"  : FFWwtt(self.session, CCk7Ar.VVduXH)
   else       : self.close()
 def VVlnz5(self, camPrefix):
  VV2X4t = self.VVCY8T(camPrefix)
  if VV2X4t:
   VV2X4t.sort(key=lambda x: int(x[0]))
   if self.VVvSE5 and self.VVvSE5.startswith(camPrefix):
    VVPtGh = ("Toggle State", self.VV99ly, [camPrefix], "Changing State ...")
   else:
    VVPtGh = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVFSP3  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFyzis(self, None, header=header, VV2PlJ=VV2X4t, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=26, VVPtGh=VVPtGh, VVwf0p=True)
 def VVCY8T(self, camPrefix):
  readersFile = self.VVb23n + camPrefix + "cam.server"
  VV2X4t = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFQoVo(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VV2X4t.append((str(len(VV2X4t) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VV2X4t:
    FF2wyP(self, "No readers found !")
  else:
   FFUQ3Z(self, readersFile)
  return VV2X4t
 def VV99ly(self, VVmxnp, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVb23n, camPrefix)
  readerState  = VVmxnp.VVYTBT(1)
  readerLabel  = VVmxnp.VVYTBT(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCG782.VVw1eX(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVmxnp.VVCAAJ()
    FF2wyP(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VV2X4t = self.VVCY8T(camPrefix)
   if VV2X4t:
    VVmxnp.VVkuQb(VV2X4t)
 @staticmethod
 def VVw1eX(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFQoVo(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FF2wyP(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FF2wyP(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFUQ3Z(SELF, confFile)
   return None
  if not iRequest:
   FF2wyP(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FF2wyP(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FF2wyP(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCFjE0(Screen):
 def __init__(self, VVZc9A, session, args=0):
  self.skin, self.skinParam = FF82u7(VVyaPF, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVb23n, VVvSE5, VVOTo1, camCommand = FFcwnW()
  if   VVZc9A == "ncam" : self.prefix = "n"
  elif VVZc9A == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVhOvi = []
  if self.prefix == "":
   VVhOvi.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVhOvi.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVhOvi.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVhOvi.append(("constant.cw"         , "x_constant_cw" ))
   VVhOvi.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVhOvi.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVhOvi.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVhOvi.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVhOvi.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVhOvi.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVhOvi.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVhOvi.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVhOvi.append(VVaOJ8)
   VVhOvi.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVhOvi.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVhOvi.append(VVaOJ8)
   VVhOvi.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVhOvi.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVhOvi.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFFsOT(self, VVhOvi=VVhOvi)
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FFEktE(self["myMenu"])
  FFwhmb(self)
 def VVIpBc(self):
  global VVnwy6
  VVnwy6 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFxImT(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFxImT(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFxImT(self, self.VVb23n + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFxImT(self, self.VVb23n + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVFvWJ("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVFvWJ("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVFvWJ("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVFvWJ("cam.provid"        )
   elif item == "x_cam_server"  : self.VVFvWJ("cam.server"        )
   elif item == "x_cam_services" : self.VVFvWJ("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVFvWJ("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVFvWJ("cam.user"        )
   elif item == "x_VVo4vY"   : pass
   elif item == "x_SoftCam_Key" : self.VV0X8j()
   elif item == "x_CCcam_cfg"  : FFxImT(self, self.VVb23n + "CCcam.cfg"    )
   elif item == "x_VVo4vY"   : pass
   elif item == "x_cam_log"  : FFxImT(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFxImT(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFxImT(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVFvWJ(self, fileName):
  FFxImT(self, self.VVb23n + self.prefix + fileName)
 def VV0X8j(self):
  path = self.VVb23n + "SoftCam.Key"
  if fileExists(path) : FFxImT(self, path)
  else    : FFxImT(self, path.replace(".Key", ".key"))
class CCk7Ar(Screen):
 VV3uVY  = 0
 VVguqV = 1
 VVduXH = 2
 def __init__(self, session, VVb23n="", VVvSE5="", VVOTo1="", VVwRlx=VV3uVY):
  self.skin, self.skinParam = FF82u7(VV8opi, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVOTo1   = VVOTo1
  self.VVwRlx  = VVwRlx
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVb23n + VVvSE5 + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVvSE5 : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVb23n, self.camPrefix)
  if self.VVwRlx == self.VV3uVY:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVwRlx == self.VVguqV:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFFsOT(self, self.Title, addScrollLabel=True)
  FFydgK(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVjlVj
  self.onShown.append(self.VVqrW9)
  self.onClose.append(self.onExit)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  self["myLabel"].VV3zxV(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFNepU(self)
  self.VVjlVj()
 def onExit(self):
  self.timer.stop()
 def VVOvvH(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV8ZLI)
  except:
   self.timer.callback.append(self.VV8ZLI)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFbstz(self, "Started", 1000)
 def VV5Tka(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VV8ZLI)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFbstz(self, "Stopped", 1000)
 def VVjlVj(self):
  if self.timerRunning:
   self.VV5Tka()
  else:
   self.VVOvvH()
   if self.VVwRlx == self.VV3uVY or self.VVwRlx == self.VVguqV:
    if self.VVwRlx == self.VV3uVY : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCG782.VVw1eX(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFHmgI(self.VVQ0TD)
    else:
     self.close()
   else:
    self.VV2MaG()
 def VV8ZLI(self):
  if self.timerRunning:
   if   self.VVwRlx == self.VV3uVY : self.VV6A0B()
   elif self.VVwRlx == self.VVguqV : self.VV6A0B()
   else            : self.VV2MaG()
 def VV2MaG(self):
  if fileExists(self.VVOTo1):
   fTime = FF0V0A(os.path.getmtime(self.VVOTo1))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VV1zCP(), VVLw9T=VVcOJJ)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVOTo1)
 def VVQ0TD(self):
  self.VV6A0B()
 def VV6A0B(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFFpMs("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVi1SQ))
   self.camWebIfErrorFound = True
   self.VV5Tka()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVwRlx == self.VV3uVY : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFFpMs("Error while parsing data elements !\n\nError = %s" % str(e), VV13Hf)
   self.camWebIfErrorFound = True
   self.VV5Tka()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVo0Ib(root)
  self["myLabel"].setText(txt, VVLw9T=VVcOJJ)
  self["myBar"].setText("Last Update : %s" % FF8TPi())
 def VVo0Ib(self, rootElement):
  def VVtlsz(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVwRlx == self.VV3uVY:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFFpMs(status, VVplBl)
    else          : status = FFFpMs(status, VV13Hf)
    txt += VVo4vY + "\n"
    txt += VVtlsz("Name"  , name)
    txt += VVtlsz("Description" , desc)
    txt += VVtlsz("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVtlsz("Protocol" , protocol)
    txt += VVtlsz("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFFpMs("Yes", VVplBl)
    else    : enabTxt = FFFpMs("No", VV13Hf)
    txt += VVo4vY + "\n"
    txt += VVtlsz("Label"  , label)
    txt += VVtlsz("Protocol" , protocol)
    txt += VVtlsz("Enabled" , enabTxt)
  return txt
 def VV1zCP(self):
  wordsDict = self.VVv4W3()
  color = [ VVqWH2, VVZj00, VVplBl, VV13Hf, VVtzSE, VVCfQO]
  lines = FFGCWo("tail -n %d %s" % (100, self.VVOTo1))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVi1SQ + line[:19] + VV5UCJ + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVLtc8 + line[ndx + 3:] + VV5UCJ
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVqWH2 + line[ndx + 8 : ndx1 + 4] + VV5UCJ + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VV5UCJ)
   elif line.startswith("----") or ">>" in line:
    line = FFFpMs(line, VVqWH2)
   txt += line + "\n"
  return txt
 def VVv4W3(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFQoVo(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCKoF7(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF82u7(VVyaPF, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVhOvi = []
  VVhOvi.append(("Backup Channels"    , "VVfN02"   ))
  VVhOvi.append(("Restore Channels"    , "Restore_Channels"  ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Backup SoftCAM Files"   , "VVFxiX" ))
  VVhOvi.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVhOvi.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVhOvi.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Backup Network Settings"  , "VVqZV4"   ))
  VVhOvi.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVJtGD:
   VVhOvi.append(VVaOJ8)
   VVhOvi.append((VVi1SQ + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VV86EG"   ))
   VVhOvi.append((VVplBl + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVQO5U) , "createMyIpk"   ))
   VVhOvi.append((VVplBl + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVQO5U) , "createMyDeb"   ))
   VVhOvi.append((VVtzSE + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVhOvi.append((VVtzSE + "Decode %s Crash Report"   % PLUGIN_NAME     , "VVEx3C" ))
  FFFsOT(self, VVhOvi=VVhOvi)
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FFEktE(self["myMenu"])
  FFwhmb(self)
 def VVIpBc(self):
  global VVnwy6
  VVnwy6 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVfN02"    : self.VVfN02()
   elif item == "Restore_Channels"    : self.VVrSLd("channels_backup*.tar.gz", self.VV86dS)
   elif item == "VVFxiX"   : self.VVFxiX()
   elif item == "Restore_SoftCAM_Files"  : self.VVrSLd("softcam_backup*.tar.gz", self.VVLRjz)
   elif item == "Backup_TunerDiSEqC"   : self.VV8uUw("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVrSLd("tuner_backup*.backup", boundFunction(self.VVWIai, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VV8uUw("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVrSLd("hotkey_*backup*.backup", boundFunction(self.VVWIai, "misc"))
   elif item == "VVqZV4"    : self.VVqZV4()
   elif item == "Restore_Network"    : self.VVrSLd("network_backup*.tar.gz", self.VV2LPk)
   elif item == "VV86EG"     : FFStgm(self, boundFunction(FFmTns, self, boundFunction(CCKoF7.VV86EG, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVer0M(False)
   elif item == "createMyDeb"     : self.VVer0M(True)
   elif item == "createMyTar"     : self.VVIs2t()
   elif item == "VVEx3C"   : self.VVEx3C()
 @staticmethod
 def VV86EG(SELF):
  OBF_Path = VVIZJG + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVIZJG, VVzByU, VVQO5U)
   if err : FF2wyP(SELF, err)
   else : FFHVXB(SELF, txt)
  else:
   FFUQ3Z(SELF, OBF_Path)
 def VVer0M(self, VVIK38):
  OBF_Path = VVIZJG + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FF2wyP(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVIZJG)
  os.system("mv -f %s %s" % (VVIZJG + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVIZJG + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVIZJG + "plugin.py"))
  self.session.openWithCallback(self.VVer0M1, boundFunction(CCIPZZ, path=VVIZJG, VVIK38=VVIK38))
 def VVer0M1(self):
  os.system("mv -f %s %s" % (VVIZJG + "OBF/main.py"  , VVIZJG))
  os.system("mv -f %s %s" % (VVIZJG + "OBF/plugin.py" , VVIZJG))
 def VVEx3C(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FF2wyP(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FF2wyP(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVhMBk("%s*.list" % path)
  if err:
   FFUQ3Z(self, path + "*.list")
   return
  srcF, err = self.VVhMBk("%s*main_final.py" % path)
  if err:
   FFUQ3Z(self, path + "*.final.py")
   return
  VV2PlJ = []
  for f in files:
   f = os.path.basename(f)
   VV2PlJ.append((f, f))
  FFN6sa(self, boundFunction(self.VVwiiR, path, codF, srcF), VVhOvi=VV2PlJ)
 def VVwiiR(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFUQ3Z(self, logF)
   else     : FFmTns(self, boundFunction(self.VV9TLF, logF, codF, srcF))
 def VV9TLF(self, logF, codF, srcF):
  lst  = []
  lines = FFQoVo(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FF2wyP(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VV9RlW(lst, logF, newLogF)
  totSrc  = self.VV9RlW(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFHVXB(self, txt)
 def VVhMBk(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VV9RlW(self, lst, f1, f2):
  txt = FFJPcA(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVIs2t(self):
  VV2PlJ = []
  VV2PlJ.append("%s%s" % (VVIZJG, "*.py"))
  VV2PlJ.append("%s%s" % (VVIZJG, "*.png"))
  VV2PlJ.append("%s%s" % (VVIZJG, "*.xml"))
  VV2PlJ.append("%s"  % (VVoH8d))
  FFgT7p(self, VV2PlJ, "%s_%s" % (PLUGIN_NAME, VVzByU), addTimeStamp=False)
 def VVfN02(self):
  path1 = VVEkHL
  path2 = "/etc/tuxbox/"
  VV2PlJ = []
  VV2PlJ.append("%s%s" % (path1, "*.tv"))
  VV2PlJ.append("%s%s" % (path1, "*.radio"))
  VV2PlJ.append("%s%s" % (path1, "*list"))
  VV2PlJ.append("%s%s" % (path1, "lamedb*"))
  VV2PlJ.append("%s%s" % (path2, "*.xml"))
  FFgT7p(self, VV2PlJ, "channels_backup", addTimeStamp=True)
 def VVFxiX(self):
  VV2PlJ = []
  VV2PlJ.append("/etc/tuxbox/config/")
  VV2PlJ.append("/usr/keys/")
  VV2PlJ.append("/usr/scam/")
  VV2PlJ.append("/etc/CCcam.cfg")
  FFgT7p(self, VV2PlJ, "softcam_backup", addTimeStamp=True)
 def VVqZV4(self):
  VV2PlJ = []
  VV2PlJ.append("/etc/hostname")
  VV2PlJ.append("/etc/default_gw")
  VV2PlJ.append("/etc/resolv.conf")
  VV2PlJ.append("/etc/wpa_supplicant*.conf")
  VV2PlJ.append("/etc/network/interfaces")
  VV2PlJ.append("/etc/enigma2/nameserversdns.conf")
  FFgT7p(self, VV2PlJ, "network_backup", addTimeStamp=True)
 def VV86dS(self, fileName=None):
  if fileName:
   FFStgm(self, boundFunction(self.VVFyqS, fileName), "Overwrite current channels ?")
 def VVFyqS(self, fileName):
  path = "%s%s" % (VVjxPh, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCz7Lj.VVOKga()
   lamedb5File, diabled5File = CCz7Lj.VV63lc()
   cmd = ""
   cmd += FFiu56("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFiu56("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFgjOJ()
   if res == 0 : FFnN3Y(self, "Channels Restored.")
   else  : FF2wyP(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFUQ3Z(self, path)
 def VVLRjz(self, fileName=None):
  if fileName:
   FFStgm(self, boundFunction(self.VVVwCr, fileName), "Overwrite SoftCAM files ?")
 def VVVwCr(self, fileName):
  fileName = "%s%s" % (VVjxPh, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVo4vY
   note = "You may need to restart your SoftCAM."
   FFpX68(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FF23Tm(note, VVqWH2), sep))
  else:
   FFUQ3Z(self, fileName)
 def VV2LPk(self, fileName=None):
  if fileName:
   FFStgm(self, boundFunction(self.VVAwTY, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVAwTY(self, fileName):
  fileName = "%s%s" % (VVjxPh, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFHbvq(self,  cmd)
  else:
   FFUQ3Z(self, fileName)
 def VVrSLd(self, pattern, callBackFunction, isTuner=False):
  title = FFzohF()
  if pathExists(VVjxPh):
   myFiles = iGlob("%s%s" % (VVjxPh, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VV2PlJ = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VV2PlJ.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVV70K = ("Sat. List", self.VVK9j6)
    else  : VVV70K = None
    VVyt0G = ("Delete File", self.VVB0HH)
    FFN6sa(self, callBackFunction, title=title, VVhOvi=VV2PlJ, VVV70K=VVV70K, VVyt0G=VVyt0G)
   else:
    FF2wyP(self, "No files found in:\n\n%s" % VVjxPh, title)
  else:
   FF2wyP(self, "Path not found:\n\n%s" % VVjxPh, title)
 def VVB0HH(self, VVfiljObj, path):
  FFStgm(self, boundFunction(self.VVtjYa, VVfiljObj, path), "Delete this file ?\n\n%s" % path)
 def VVtjYa(self, VVfiljObj, path):
  path = VVjxPh + path
  os.system(FFiu56("rm -f '%s'" % path))
  if fileExists(path) : FFbstz(VVfiljObj, "Not deleted", 1000)
  else    : VVfiljObj.VVtH0B()
 def VV8uUw(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCyIWM()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VVjjdq, filePrefix))
 def VVjjdq(self, filePrefix, result, retval):
  title = FFzohF()
  if pathExists(VVjxPh):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FF2wyP(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVjxPh, filePrefix, FFHXaa())
    try:
     VV2PlJ = str(result.strip()).split()
     if VV2PlJ:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VV2PlJ:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVo4vY, FFFpMs(fName, VVqWH2), VVo4vY)
       FFHVXB(self, txt, title=title, VVLw9T=VVcOJJ)
      else:
       FF2wyP(self, "File creation failed!", title)
     else:
      FF2wyP(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFiu56("rm %s" % fName))
     FF2wyP(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFiu56("rm %s" % fName))
     FF2wyP(self, "Error while writing file.")
  else:
   FF2wyP(self, "Path not found:\n\n%s" % VVjxPh, title)
 def VVWIai(self, mode, path=None):
  if path:
   path = "%s%s" % (VVjxPh, path)
   if fileExists(path):
    lines = FFQoVo(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFStgm(self, boundFunction(self.VVHkn6, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFFNOf(self, path, title=FFzohF())
   else:
    FFUQ3Z(self, path)
 def VVHkn6(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVlQdH = []
  VVlQdH.append("echo -e 'Reading current settings ...'")
  VVlQdH.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVlQdH.append("echo -e 'Preparing new settings ...'")
  VVlQdH.append(settingsLines)
  VVlQdH.append("echo -e 'Applying new settings ...'")
  VVlQdH.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFHHyb(self, VVlQdH)
 def VVK9j6(self, VVfiljObj, path):
  if not path:
   return
  path = VVjxPh + path
  if not fileExists(path):
   FFUQ3Z(self, path)
   return
  txt = FFJPcA(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VV2PlJ  = []
   for item in satList:
    VV2PlJ.append("%s\t%s" % (item[0], FFf0Ve(item[1])))
   FFHVXB(self, VV2PlJ, title="  Satellites List")
  else:
   FF2wyP(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CC0yAR(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF82u7(VVyaPF, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVhOvi = []
  VVhOvi.append(("Plugins Browser List"       , "VV7cmH"   ))
  VVhOvi.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVhOvi.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVhOvi.append(("Remove Packages (show all)"     , "VVpGsBsAll"   ))
  VVhOvi.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Update List of Available Packages"   , "VVZE2h"   ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Packaging Tool"        , "VVhqC5"    ))
  VVhOvi.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFFsOT(self, VVhOvi=VVhOvi)
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FFEktE(self["myMenu"])
  FFwhmb(self)
 def VVIpBc(self):
  global VVnwy6
  VVnwy6 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VV7cmH"   : self.VV7cmH()
   elif item == "pluginsMenus"     : self.VVJJuv(0)
   elif item == "pluginsStartup"    : self.VVJJuv(1)
   elif item == "pluginsDirList"    : self.VVgOIF()
   elif item == "downloadInstallPackages"  : FFmTns(self, boundFunction(self.VVIptE, 0, ""))
   elif item == "VVpGsBsAll"   : FFmTns(self, boundFunction(self.VVIptE, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFmTns(self, boundFunction(self.VVIptE, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVZE2h"   : self.VVZE2h()
   elif item == "VVhqC5"    : self.VVhqC5()
   elif item == "packagesFeeds"    : self.VVayXS()
   else          : self.close()
 def VVgOIF(self):
  extDirs  = FF0MA9(VVdG9z)
  sysDirs  = FF0MA9(VVcnky)
  VV2PlJ  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VV2PlJ.append((item, VVdG9z + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VV2PlJ.append((item, VVcnky + item))
  if VV2PlJ:
   VV2PlJ = sorted(VV2PlJ, key=lambda x: x[0].lower())
   VVCfae = ("Package Info.", self.VV44pS, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFyzis(self, None, header=header, VV2PlJ=VV2PlJ, VVDrmL=widths, VVCZ7I=28, VVCfae=VVCfae)
  else:
   FF2wyP(self, "Nothing found!")
 def VV44pS(self, VVmxnp, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVdG9z) : loc = "extensions"
  elif path.startswith(VVcnky) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVMdOf(package)
  else:
   FF2wyP(self, "No info!")
 def VVayXS(self):
  pkg = FFSRwQ()
  if pkg : FFZ9oT(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFAopx(self)
 def VV7cmH(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVtlsz(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVo4vY + "\n"
    txt += VVtlsz("Number"   , str(c))
    txt += VVtlsz("Name"   , FFFpMs(str(p.name), VVqWH2))
    txt += VVtlsz("Path"  , p.path  )
    txt += VVtlsz("Description" , p.description )
    txt += VVtlsz("Icon"  , p.iconstr  )
    txt += VVtlsz("Wakeup Fnc" , p.wakeupfnc )
    txt += VVtlsz("NeedsRestart", p.needsRestart)
    txt += VVtlsz("Internal" , p.internal )
    txt += VVtlsz("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFHVXB(self, txt)
 def VVJJuv(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VV2PlJ = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VV2PlJ.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VV2PlJ:
   VV2PlJ.sort(key=lambda x: x[0].lower())
   header  = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths  = (19  , 25 , 20  , 27   , 9  )
   FFyzis(self, None, title=title, header=header, VV2PlJ=VV2PlJ, VVDrmL=widths, VVCZ7I=26)
  else:
   FF2wyP(self, "Nothing Found", title=title)
 def VVZE2h(self):
  cmd = FFSU1Z(VVbsC9, "")
  if cmd : FFHbvq(self, cmd, checkNetAccess=True)
  else : FFAopx(self)
 def VVhqC5(self):
  pkg = FFSRwQ()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFnN3Y(self, txt)
 def VVIptE(self, mode, grep, VVmxnp=None, title=""):
  if   mode == 0: cmd = FFSU1Z(VVPGrZ    , grep)
  elif mode == 1: cmd = FFSU1Z(VV4I1T , grep)
  elif mode == 2: cmd = FFSU1Z(VV4I1T , grep)
  if not cmd:
   FFAopx(self)
   return
  VV2X4t = FFGCWo(cmd)
  if not VV2X4t:
   if VVmxnp: VVmxnp.VVCAAJ()
   FF2wyP(self, "No packages found!")
   return
  elif len(VV2X4t) == 1 and VV2X4t[0] == VV0Frc:
   FF2wyP(self, VV0Frc)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VV2PlJ  = []
  for item in VV2X4t:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VV2PlJ.append((name, package, version))
  if mode > 0:
   extensions = FFGCWo("ls %s -l | grep '^d' | awk '{print $9}'" % VVdG9z)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VV2PlJ:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VV2PlJ.append((name, VVdG9z + item, "-"))
   systemPlugins = FFGCWo("ls %s -l | grep '^d' | awk '{print $9}'" % VVcnky)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VV2PlJ:
      if item.lower() == row[0].lower():
       break
     else:
      VV2PlJ.append((item, VVcnky + item, "-"))
  if not VV2PlJ:
   FF2wyP(self, "No packages found!")
   return
  if VVmxnp:
   VV2PlJ.sort(key=lambda x: x[0].lower())
   VVmxnp.VVkuQb(VV2PlJ, title)
  else:
   widths = (20, 50, 30)
   VVPtGh = None
   VVMVHK = None
   if mode == 0:
    VVeO38 = ("Install" , self.VVHXim   , [])
    VVPtGh = ("Download" , self.VVBWwG   , [])
    VVMVHK = ("Filter"  , self.VVnqNo , [])
   elif mode == 1:
    VVeO38 = ("Uninstall", self.VVpGsB, [])
   elif mode == 2:
    VVeO38 = ("Uninstall", self.VVpGsB, [])
    widths= (18, 57, 25)
   VV2PlJ = sorted(VV2PlJ, key=lambda x: x[0].lower())
   VVCfae = ("Package Info.", self.VVuzFe, [])
   header   = ("Name" ,"Package" , "Version" )
   FFyzis(self, None, header=header, VV2PlJ=VV2PlJ, VVDrmL=widths, VVCZ7I=28, VVeO38=VVeO38, VVPtGh=VVPtGh, VVCfae=VVCfae, VVMVHK=VVMVHK, VVpjX8=self.lastSelectedRow
     , VVxH2w="#22110011", VV2Du9="#22191111", VVPEgn="#22191111", VVV3E9="#00003030", VVPt5m="#00333333")
 def VVuzFe(self, VVmxnp, title, txt, colList):
  package = colList[1]
  self.VVMdOf(package)
 def VVnqNo(self, VVmxnp, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVhOvi = []
  VVhOvi.append(("All Packages", "all"))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVhOvi.append(VVaOJ8)
  for word in words:
   VVhOvi.append((word, word))
  FFN6sa(self, boundFunction(self.VV6pJB, VVmxnp), VVhOvi=VVhOvi, title="Select Filter")
 def VV6pJB(self, VVmxnp, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFmTns(VVmxnp, boundFunction(self.VVIptE, 0, grep, VVmxnp, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVpGsB(self, VVmxnp, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVdG9z, VVcnky)):
   FFStgm(self, boundFunction(self.VVU1wu, VVmxnp, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVhOvi = []
   VVhOvi.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVhOvi.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVhOvi.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFN6sa(self, boundFunction(self.VVHqcI, VVmxnp, package), VVhOvi=VVhOvi)
 def VVU1wu(self, VVmxnp, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVs1qJ)
  FFHbvq(self, cmd, VV8KYv=boundFunction(self.VVul21, VVmxnp))
 def VVHqcI(self, VVmxnp, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVhJVe
   elif item == "remove_ForceRemove"  : cmdOpt = VVmguF
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVHkLQ
   FFStgm(self, boundFunction(self.VVAnUK, VVmxnp, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVAnUK(self, VVmxnp, package, cmdOpt):
  self.lastSelectedRow = VVmxnp.VVwa7w()
  cmd = FF5ENR(cmdOpt, package)
  if cmd : FFHbvq(self, cmd, VV8KYv=boundFunction(self.VVul21, VVmxnp))
  else : FFAopx(self)
 def VVul21(self, VVmxnp):
  VVmxnp.cancel()
  FFdk6f()
 def VVHXim(self, VVmxnp, title, txt, colList):
  package  = colList[1]
  VVhOvi = []
  VVhOvi.append(("Install Package"         , "install_CheckVersion" ))
  VVhOvi.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVhOvi.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VVhOvi.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVhOvi.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFN6sa(self, boundFunction(self.VVE8KV, package), VVhOvi=VVhOvi)
 def VVE8KV(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVIqrC
   elif item == "install_ForceReinstall" : cmdOpt = VVwEDD
   elif item == "install_ForceOverwrite" : cmdOpt = VVzcHK
   elif item == "install_ForceDowngrade" : cmdOpt = VVVmdf
   elif item == "install_IgnoreDepends" : cmdOpt = VVCbLd
   FFStgm(self, boundFunction(self.VVzCgQ, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVzCgQ(self, package, cmdOpt):
  cmd = FF5ENR(cmdOpt, package)
  if cmd : FFHbvq(self, cmd, VV8KYv=FFdk6f, checkNetAccess=True)
  else : FFAopx(self)
 def VVBWwG(self, VVmxnp, title, txt, colList):
  package  = colList[1]
  FFStgm(self, boundFunction(self.VVPWx1, package), "Download Package ?\n\n%s" % package)
 def VVPWx1(self, package):
  if FFKIlG():
   cmd = FF5ENR(VVypMU, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FF23Tm(success, VVplBl))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FF23Tm(fail, VV13Hf))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFHbvq(self, cmd, VVwrxl=[VV13Hf, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFAopx(self)
  else:
   FF2wyP(self, "No internet connection !")
 def VVMdOf(self, package):
  infoCmd  = FF5ENR(VVZCfy, package)
  filesCmd = FF5ENR(VVQ3or, package)
  listInstCmd = FFSU1Z(VV4I1T, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFQbM5(VVqWH2)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FF23Tm(notInst, VVi1SQ))
   cmd += "else "
   cmd +=   FFRcES("System Info", VVqWH2)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFRcES("Related Files", VVqWH2)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFS0Ql(self, cmd)
  else:
   FFAopx(self)
class CCz7Lj(Screen):
 VVv75Y  = 0
 VVgfQ7 = 1
 VVlxfl  = 2
 VVEKfR  = 3
 VVX37m = 4
 VVMyDj = 5
 VVj6fN = 6
 def __init__(self, session):
  self.skin, self.skinParam = FF82u7(VVyaPF, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVwQ9C = None
  self.lastfilterUsed  = None
  VVhOvi = self.VVnY3P()
  FFFsOT(self, VVhOvi=VVhOvi, title="Services/Channels")
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self["myMenu"].setList(self.VVnY3P())
  FFEktE(self["myMenu"])
  FFwhmb(self)
 def VVnY3P(self):
  VVhOvi = []
  VVhOvi.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VVhOvi.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Services (Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVhOvi.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVhOvi.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVhOvi.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVhOvi.append(("Services with PIcons for the System"  , "VVWbVW"     ))
  VVhOvi.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVhOvi.append(VVaOJ8)
  lamedbFile, disabledFile = CCz7Lj.VVOKga()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVhOvi.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVhOvi.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVhOvi.append(("Reset Parental Control Settings"   , "VVa5BN"    ))
  VVhOvi.append(("Delete Channels with no names"   , "VVK6Hs"    ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Reload Channels and Bouquets"    , "VVMcgq"      ))
  return VVhOvi
 def VVIpBc(self):
  global VVnwy6
  VVnwy6 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFbtMj(self)
   elif item == "currentServiceInfo"     : FFhDEp(self, fncMode=CCip5O.VVC9O2)
   elif item == "TranspondersStats"     : FFmTns(self, self.VVJo6i     )
   elif item == "lameDB_allChannels_with_refCode"  : FFmTns(self, self.VV2RIL )
   elif item == "lameDB_allChannels_with_tranaponder" : FFmTns(self, self.VVtwVo)
   elif item == "lameDB_allChannels_with_details"  : FFmTns(self, self.VVpvxV )
   elif item == "parentalControlChannels"    : FFmTns(self, self.VVVX1B   )
   elif item == "showHiddenChannels"     : FFmTns(self, self.VV94y0     )
   elif item == "VVWbVW"     : FFmTns(self, self.VV1msE     )
   elif item == "servicesWithMissingPIcons"   : FFmTns(self, self.VVkCv1   )
   elif item == "enableHiddenChannels"     : self.VVj4k1(True)
   elif item == "disableHiddenChannels"    : self.VVj4k1(False)
   elif item == "VVa5BN"    : FFStgm(self, self.VVa5BN, "Reset and Restart ?" )
   elif item == "VVK6Hs"    : FFmTns(self, self.VVK6Hs)
   elif item == "VVMcgq"      : FFmTns(self, boundFunction(CCz7Lj.VVMcgq, self))
   else            : self.close()
 @staticmethod
 def VVMcgq(SELF):
  FFgjOJ()
  FFnN3Y(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VV2RIL(self):
  self.VVwQ9C = None
  self.lastfilterUsed  = None
  self.filterObj   = CCROIp(self)
  VV2X4t = CCz7Lj.VVdmHx(self, self.VVv75Y)
  if VV2X4t:
   VV2X4t.sort(key=lambda x: x[0].lower())
   VVPZiO  = ("Zap"   , self.VVLEI7     , [])
   VVyW3N = (""    , self.VVMl79   , [])
   VVCfae = ("Options"  , self.VVt0V2 , [])
   VVPtGh = ("Current Service", self.VV6aR1 , [])
   VVMVHK = ("Filter"   , self.VVNaWu  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVFSP3  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFyzis(self, None, header=header, VV2PlJ=VV2X4t, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=26, VVPZiO=VVPZiO, VVyW3N=VVyW3N, VVPtGh=VVPtGh, VVCfae=VVCfae, VVMVHK=VVMVHK)
 def VVtwVo(self):
  self.VVwQ9C = None
  self.lastfilterUsed  = None
  self.filterObj   = CCROIp(self)
  VV2X4t = CCz7Lj.VVdmHx(self, self.VVgfQ7)
  if VV2X4t:
   VV2X4t.sort(key=lambda x: x[0].lower())
   VVPZiO  = ("Zap"   , self.VVLEI7      , [])
   VVyW3N = (""    , self.VVMl79    , [])
   VVPtGh = ("Current Service", self.VV6aR1  , [])
   VVCfae = ("Options"  , self.VVvQkK , [])
   VVMVHK = ("Filter"   , self.VVvYFd  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVFSP3  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFyzis(self, None, header=header, VV2PlJ=VV2X4t, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=26, VVPZiO=VVPZiO, VVyW3N=VVyW3N, VVPtGh=VVPtGh, VVCfae=VVCfae, VVMVHK=VVMVHK)
 def VVt0V2(self, VVmxnp, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel  = CClfxx(self, VVmxnp, 3)
  mSel.VV7E7z(servName, refCode, pcState, hidState)
 def VVvQkK(self, VVmxnp, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CClfxx(self, VVmxnp, 3)
  mSel.VVCjGG(servName, refCode)
 def VVe9mA(self, VVmxnp, refCode, isAddToBlackList):
  VVmxnp.VVAZt6("Processing ...")
  FFHmgI(boundFunction(self.VVzrSB, VVmxnp, [refCode], isAddToBlackList))
 def VVgNLp(self, VVmxnp, isAddToBlackList):
  refCodeList = VVmxnp.VVR0dW(3)
  if not refCodeList:
   FF2wyP(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVmxnp.VVAZt6("Processing ...")
  FFHmgI(boundFunction(self.VVzrSB, VVmxnp, refCodeList, isAddToBlackList))
 def VVzrSB(self, VVmxnp, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VV3p6k, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VV3p6k):
   lines = FFQoVo(VV3p6k)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VV3p6k, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVmxnp.VVbF0F
   if isMulti:
    self.VVidfc(VVmxnp, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVNVUt(VVmxnp, refCode)
    VVmxnp.VVCAAJ()
  else:
   VVmxnp.VV9577("No changes")
 def VVdQS0(self, VVmxnp, refCode, isHide):
  title = "Change Hidden State"
  if FFL0hm(refCode):
   VVmxnp.VVAZt6("Processing ...")
   ret = FFHJrf(refCode, isHide)
   if ret : FFmTns(self, boundFunction(self.VVNVUt, VVmxnp, refCode))
   else : FF2wyP(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FF2wyP(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVNVUt(self, VVmxnp, refCode):
  VV2X4t = CCz7Lj.VVdmHx(self, self.VVv75Y, VVR1sk=[3, [refCode], False])
  done = False
  if VV2X4t:
   data = VV2X4t[0]
   if data[3] == refCode:
    done = VVmxnp.VVC5ot(data)
  if not done:
   self.VVhsuL(VVmxnp, VVmxnp.VV2iNw(), self.VVv75Y)
  VVmxnp.VVCAAJ()
 def VVidfc(self, VVmxnp, totRefCodes):
  VV2X4t = CCz7Lj.VVdmHx(self, self.VVv75Y, VVR1sk=self.VVwQ9C)
  VVmxnp.VVkuQb(VV2X4t)
  VVmxnp.VVk734(False)
  VVmxnp.VV9577("%d Processed" % totRefCodes)
 def VVmjqL(self, VVmxnp, isHide):
  refCodeList = VVmxnp.VVR0dW(3)
  if not refCodeList:
   FF2wyP(self, "Nothing selected", title="Change Hidden State")
   return
  VVmxnp.VVAZt6("Processing ...")
  FFHmgI(boundFunction(self.VVlvsj, VVmxnp, refCodeList, isHide))
 def VVlvsj(self, VVmxnp, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFHJrf(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   db = eDVBDB.getInstance()
   if db:
    db.saveServicelist()
    db.reloadServicelist()
    db.reloadBouquets()
   self.VVidfc(VVmxnp, len(refCodeList))
  else:
   VVmxnp.VV9577("No changes")
 def VVNaWu(self, VVmxnp, title, txt, colList):
  self.filterObj.VVC4Sb(1, VVmxnp, 2, boundFunction(self.VVJHNb, VVmxnp))
 def VVJHNb(self, VVmxnp, item):
  self.VV7dF2(VVmxnp, item, 2, self.VVv75Y)
 def VVvYFd(self, VVmxnp, title, txt, colList):
  self.filterObj.VVC4Sb(2, VVmxnp, 4, boundFunction(self.VVgloi, VVmxnp))
 def VVgloi(self, VVmxnp, item):
  self.VV7dF2(VVmxnp, item, 4, self.VVgfQ7)
 def VVoHR6(self, VVmxnp, title, txt, colList):
  self.filterObj.VVC4Sb(0, VVmxnp, 4, boundFunction(self.VVjeQP, VVmxnp))
 def VVjeQP(self, VVmxnp, item):
  self.VV7dF2(VVmxnp, item, 4, self.VVlxfl)
 def VV7dF2(self, VVmxnp, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVmxnp.VVYTBT(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVwQ9C = None
  else:
   words, asPrefix = CCROIp.VVputs(words)
   self.VVwQ9C = [col, words, asPrefix]
  if words: FFmTns(self, boundFunction(self.VVhsuL, VVmxnp, title, mode), title="Reading Services ...")
  else : FFbstz(VVmxnp, "Incorrect filter", 2000)
 def VVhsuL(self, VVmxnp, title, mode):
  VV2X4t = CCz7Lj.VVdmHx(self, mode, VVR1sk=self.VVwQ9C, VVPg2W=False)
  if VV2X4t:
   VV2X4t.sort(key=lambda x: x[0].lower())
   VVmxnp.VVkuQb(VV2X4t, title)
  else:
   VVmxnp.VVCAAJ()
   FFbstz(VVmxnp, "Not found!", 1500)
 def VV5pnI(self, VV2PlJ, VVPZiO=None, VVyW3N=None, VVeO38=None, VVPtGh=None, VVCfae=None, VVMVHK=None):
  VVPtGh = ("Current Service", self.VV6aR1, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVFSP3 = (LEFT  , LEFT  , CENTER, LEFT    )
  FFyzis(self, None, header=header, VV2PlJ=VV2PlJ, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=26, VVPZiO=VVPZiO, VVyW3N=VVyW3N, VVeO38=VVeO38, VVPtGh=VVPtGh, VVCfae=VVCfae, VVMVHK=VVMVHK)
 def VV6aR1(self, VVmxnp, title, txt, colList):
  self.VVeiPG(VVmxnp)
 def VVg0Bg(self, VVmxnp, title, txt, colList):
  self.VVeiPG(VVmxnp, True)
 def VVeiPG(self, VVmxnp, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVmxnp.VVtnU7(colDict, VVJGrp=True)
   else:
    VVmxnp.VV1v28(3, refCode, True)
   return
  FF2wyP(self, "Colud not read current Reference Code !")
 def VVpvxV(self):
  self.VVwQ9C = None
  self.lastfilterUsed  = None
  self.filterObj   = CCROIp(self)
  VV2X4t = CCz7Lj.VVdmHx(self, self.VVlxfl)
  if VV2X4t:
   VV2X4t.sort(key=lambda x: x[0].lower())
   VVyW3N = (""    , self.VVD40k , []      )
   VVPtGh = ("Current Service", self.VVg0Bg  , []      )
   VVMVHK = ("Filter"   , self.VVoHR6   , [], "Loading Filters ..." )
   VVPZiO  = ("Zap"   , self.VVwtxm      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVFSP3  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFyzis(self, None, header=header, VV2PlJ=VV2X4t, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=26, VVPZiO=VVPZiO, VVyW3N=VVyW3N, VVPtGh=VVPtGh, VVMVHK=VVMVHK)
 def VVD40k(self, VVmxnp, title, txt, colList):
  refCode  = self.VV0yem(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFhDEp(self, fncMode=CCip5O.VVMicV, refCode=refCode, chName=chName, text=txt)
 def VVwtxm(self, VVmxnp, title, txt, colList):
  refCode = self.VV0yem(colList)
  FFulYh(self, refCode)
 def VVLEI7(self, VVmxnp, title, txt, colList):
  FFulYh(self, colList[3])
 def VV0yem(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVdmHx(SELF, mode, VVR1sk=None, VVPg2W=True, VVEx5a=True):
  lamedbFile, disabledFile = CCz7Lj.VVOKga()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVR1sk:
    filterCol = VVR1sk[0]
    filterWords = VVR1sk[1]
    asPrefix = VVR1sk[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCz7Lj.VVv75Y:
    blackList = None
    if fileExists(VV3p6k):
     blackList = FFQoVo(VV3p6k)
     if blackList:
      blackList = set(blackList)
   elif mode == CCz7Lj.VVgfQ7:
    tp = CCPwtQ()
   VV6QHu, VV1wel = FFqZca()
   tagFound  = False
   if mode in (CCz7Lj.VVMyDj, CCz7Lj.VVj6fN):
    VV2X4t = {}
   else:
    VV2X4t = []
   with ioOpen(lamedbFile, "r", encoding="utf-8") as f:
    lines = []
    for line in f:
     line = str(line).strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFGrAn(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CCz7Lj.VVlxfl:
        if sTypeInt in VV6QHu:
         STYPE = VV1wel[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VV2X4t.append(tRow)
         elif any(x in tmp for x in filterWords)    : VV2X4t.append(tRow)
        else:
         VV2X4t.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCz7Lj.VVMyDj:
         VV2X4t[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCz7Lj.VVj6fN:
         VV2X4t[chName] = refCode
        elif mode == CCz7Lj.VVv75Y:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VV2X4t.append(tRow)
          elif any(x in tmp for x in filterWords)    : VV2X4t.append(tRow)
         else:
          VV2X4t.append(tRow)
        elif mode == CCz7Lj.VVgfQ7:
         if sTypeInt in VV6QHu:
          STYPE = VV1wel[sTypeInt]
         freq, pol, fec, sr, syst = tp.VVd3OU(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VV2X4t.append(tRow)
          elif any(x in tmp for x in filterWords)    : VV2X4t.append(tRow)
         else:
          VV2X4t.append(tRow)
        elif mode == CCz7Lj.VVEKfR:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VV2X4t.append((chName, chProv, sat, refCode))
        elif mode == CCz7Lj.VVX37m:
         VV2X4t.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VV2X4t and VVPg2W:
    FF2wyP(SELF, "No services found!")
   return VV2X4t
  else:
   if VVEx5a:
    FFUQ3Z(SELF, lamedbFile)
   return None
 def VVVX1B(self):
  if fileExists(VV3p6k):
   lines = FFQoVo(VV3p6k)
   if lines:
    newRows  = []
    VV2X4t = CCz7Lj.VVdmHx(self, self.VVX37m)
    if VV2X4t:
     lines = set(lines)
     for item in VV2X4t:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VV2X4t = newRows
      VV2X4t.sort(key=lambda x: x[0].lower())
      VVyW3N = ("", self.VVMl79, [])
      VVPZiO = ("Zap", self.VVLEI7, [])
      self.VV5pnI(VV2PlJ=VV2X4t, VVPZiO=VVPZiO, VVyW3N=VVyW3N)
     else:
      FFHVXB(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VV2X4t)))
   else:
    FFnN3Y(self, "No active Parental Control services.", FFzohF())
  else:
   FFUQ3Z(self, VV3p6k)
 def VV94y0(self):
  VV2X4t = CCz7Lj.VVdmHx(self, self.VVEKfR)
  if VV2X4t:
   VV2X4t.sort(key=lambda x: x[0].lower())
   VVyW3N = ("" , self.VVMl79, [])
   VVPZiO  = ("Zap", self.VVLEI7, [])
   self.VV5pnI(VV2PlJ=VV2X4t, VVPZiO=VVPZiO, VVyW3N=VVyW3N)
  else:
   FFnN3Y(self, "No hidden services.", FFzohF())
 def VVJo6i(self):
  totT, totC, totA, totS, totS2, satList = self.VVvIM2()
  txt = FFFpMs("Total Transponders:\n\n", VVtzSE)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFFpMs("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVtzSE)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFZ8tX(item), satList.count(item))
  FFHVXB(self, txt)
 def VVvIM2(self):
  lamedbFile, disabledFile = CCz7Lj.VVOKga()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with ioOpen(lamedbFile, "r", encoding="utf-8") as f:
    lines = []
    for line in f:
     line = str(line).strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFUQ3Z(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VV1msE(self)   : self.VVWbVW(True)
 def VVkCv1(self) : self.VVWbVW(False)
 def VVWbVW(self, isWithPIcons):
  piconsPath = CCpHVD.VVRh8o()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCpHVD.VVK9BJ(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VV2X4t = CCz7Lj.VVdmHx(self, self.VVX37m)
    if VV2X4t:
     channels = []
     for (chName, chProv, sat, refCode) in VV2X4t:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFtUoc(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VV2X4t)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVtlsz(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVtlsz("PIcons Path"  , piconsPath)
     txt += VVtlsz("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVtlsz("Total services" , totalServices)
     txt += VVtlsz("With PIcons"  , totalWithPIcons)
     txt += VVtlsz("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFHVXB(self, txt)
     else:
      VVyW3N     = (""      , self.VVMl79 , [])
      if isWithPIcons : VVMVHK = ("Export Current PIcon", self.VVRRIM  , [])
      else   : VVMVHK = None
      VVCfae     = ("Statistics", FFHVXB, [txt])
      VVPZiO      = ("Zap", self.VVLEI7, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VV5pnI(VV2PlJ=channels, VVPZiO=VVPZiO, VVyW3N=VVyW3N, VVCfae=VVCfae, VVMVHK=VVMVHK)
   else:
    FF2wyP(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FF2wyP(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVMl79(self, VVmxnp, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFhDEp(self, fncMode=CCip5O.VVMicV, refCode=refCode, chName=chName, text=txt)
 def VVRRIM(self, VVmxnp, title, txt, colList):
  png, path = CCpHVD.VVCCT0(colList[3], colList[0])
  if path:
   CCpHVD.VVAi97(self, png, path)
 @staticmethod
 def VVOKga():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VV63lc():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVj4k1(self, isEnable):
  lamedbFile, disabledFile = CCz7Lj.VVOKga()
  if isEnable and not fileExists(disabledFile):
   FFnN3Y(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FF2wyP(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFStgm(self, boundFunction(self.VVqfZC, isEnable), "%s Hidden Channels ?" % word)
 def VVqfZC(self, isEnable):
  lamedbFile , disabledFile = CCz7Lj.VVOKga()
  lamedb5File, diabled5File = CCz7Lj.VV63lc()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FFgjOJ()
  if res == 0 : FFnN3Y(self, "Hidden List %s" % word)
  else  : FF2wyP(self, "Error while restoring:\n\n%s" % fileName)
 def VVa5BN(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFHHyb(self, cmd)
 def VVK6Hs(self):
  lamedbFile, disabledFile = CCz7Lj.VVOKga()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFiu56("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFQoVo(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFiu56("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FFgjOJ()
   FFHVXB(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFUQ3Z(self, lamedbFile)
class CCip5O(Screen):
 VVC9O2  = 0
 VV8IfL   = 1
 VVs114   = 2
 VVMicV    = 3
 VViRae    = 4
 VV5xcI   = 5
 VV2TW9   = 6
 VVDr3L    = 7
 VV3RIX   = 8
 VV0lxd   = 9
 VVpdMX   = 10
 VVznb5   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FF82u7(VV8opi, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVC9O2)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFFpMs("%s\n", VV1Lqa) % VVo4vY
  FFFsOT(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVK4V6 })
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  self["myLabel"].VV3zxV(textOutFile="chann_info")
  if   self.fncMode == self.VVC9O2 : fnc = self.VVEa5K_VVC9O2
  elif self.fncMode == self.VV8IfL  : fnc = self.VVEa5K_VVC9O2
  elif self.fncMode == self.VVs114  : fnc = self.VVEa5K_VVC9O2
  elif self.fncMode == self.VVMicV  : fnc = self.VVEa5K_VVMicV
  elif self.fncMode == self.VViRae  : fnc = self.VVEa5K_VViRae
  elif self.fncMode == self.VV5xcI  : fnc = self.VVEa5K_VV5xcI
  elif self.fncMode == self.VV2TW9  : fnc = self.VVEa5K_VV2TW9
  elif self.fncMode == self.VVDr3L  : fnc = self.VVEa5K_VVDr3L
  elif self.fncMode == self.VV3RIX  : fnc = self.VVEa5K_VV3RIX
  elif self.fncMode == self.VV0lxd : fnc = self.VVEa5K_VV0lxd
  elif self.fncMode == self.VVpdMX  : fnc = self.VVEa5K_VVpdMX
  elif self.fncMode == self.VVznb5 : fnc = self.VVEa5K_VVznb5
  self["myLabel"].setText("\n   Reading Info ...")
  FFHmgI(fnc)
 def VVownJ(self, err):
  self["myLabel"].setText(err)
  FFpqr2(self["myTitle"], "#22200000")
  FFpqr2(self["myBody"], "#22200000")
  self["myLabel"].FFpqr2Color("#22200000")
  self["myLabel"].VVgN9o()
 def VVEa5K_VVC9O2(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self)
  self.refCode = refCode
  self.VVW9Tr(chName)
 def VVEa5K_VVMicV(self):
  self.VVW9Tr(self.chName)
 def VVEa5K_VViRae(self):
  self.VVW9Tr(self.chName)
 def VVEa5K_VV5xcI(self):
  self.VVW9Tr(self.chName)
 def VVEa5K_VV2TW9(self):
  self.VVW9Tr("Picon Info")
 def VVEa5K_VVDr3L(self):
  self.VVW9Tr(self.chName)
 def VVEa5K_VV3RIX(self):
  self.VVW9Tr(self.chName)
 def VVEa5K_VV0lxd(self):
  self.VVW9Tr(self.chName)
 def VVEa5K_VVpdMX(self):
  self.chUrl = self.refCode + self.callingSELF.VVNafF(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVW9Tr(self.chName)
 def VVEa5K_VVznb5(self):
  self.VVW9Tr(self.chName)
 def VVW9Tr(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFiApO(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVyFpM(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFFpMs(self.VVIFl2(tUrl), VV5UCJ)
  if not self.epg:
   epg = self.VVUlQ3(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVmWFF(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCpHVD.VVCCT0(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVmWFF(path)
  self.VVsBep()
  self.VVbaR4()
  self["myLabel"].setText(self.text, VVLw9T=VVL1cJ)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVgN9o(minHeight=minH)
 def VVbaR4(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFupNy(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVI8Yh(FFjPwi(url))
  if epg:
   self.text += "\n" + FF6kX4("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVsBep()
 def VVsBep(self):
  if not self.piconShown and self.picUrl:
   path, err = FFBgNy(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVmWFF(path)
    if self.piconShown and self.refCode:
     self.VVFwrM(path, self.refCode)
 def VVFwrM(self, path, refCode):
  if path and fileExists(path) and os.system(FFiu56("which ffmpeg")) == 0:
   pPath = CCpHVD.VVRh8o()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
    cmd += FFiu56("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVmWFF(self, path):
  if path and fileExists(path):
   err, w, h = self.VVuW3O(path)
   if not err:
    if h > w:
     self.VVGoTG(self["myPicF"], w, h, True)
     self.VVGoTG(self["myPic"] , w, h, False)
   allOK = FFnRFN(self["myPic"], path)
   if allOK:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVGoTG(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVuW3O(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFSDWT(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVyFpM(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFFpMs(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVtlsz(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFFpMs(state, VVi1SQ)
   txt += "State\t: %s\n" % state
  w = FFbHPv(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFbHPv(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVraPM(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVtlsz(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVtlsz(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVtlsz(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVuc63()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVLk0L()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCip5O.VVYTKN(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFFpMs("IPTV", VVtzSE)
   txt += self.VVJcGn(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVyx8Z(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCPwtQ()
    tpTxt, namespace = tp.VVmJ9W(refCode)
    del tp
    if tpTxt:
     txt += FFFpMs("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFFpMs("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVtlsz(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVtlsz(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVtlsz(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVtlsz(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVtlsz(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVtlsz(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVtlsz(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVtlsz(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVtlsz(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVraPM(info):
  if info:
   aspect = FFbHPv(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVtlsz(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFbHPv(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVDirc(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVDirc(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVuc63(self):
  try:
   service = self.session.nav.getCurrentService()
   audio = service and service.audioTracks()
   return audio and audio.getNumberOfTracks() or 0
  except:
   pass
  return -1
 def VVLk0L(self):
  try:
   service   = self.session.nav.getCurrentService()
   subtitle  = service and service.subtitle()
   subtitlelist = subtitle and subtitle.getSubtitleList()
   return len(subtitlelist)
  except:
   pass
  return -1
 def VVyx8Z(self, refCode, iptvRef, chName):
  refCode = FFTmWm(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFJPcA(VVEkHL + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFJPcA(VVEkHL + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VV2PlJ = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVEkHL + item
   if fileExists(path):
    txt = FFJPcA(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VV2PlJ.append(bName)
  txt = self.Sep
  if VV2PlJ:
   if len(VV2PlJ) == 1:
    txt += "%s\t: %s\n" % (FFFpMs("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VV2PlJ[0])
   else:
    txt += FFFpMs("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VV2PlJ):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVUlQ3(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVvHPF(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVvHPF(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVvHPF(event, 0)
     except:
      pass
  return epg
 def VVvHPF(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName().strip()    or ""
   evTime = event.getBeginTime()      or ""
   evDur = event.getDuration()      or ""
   evShort = event.getShortDescription() .strip() or ""
   evDesc = event.getExtendedDescription().strip() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = self.VVu9Kq(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FFFpMs(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FFFpMs(evNameTransl, COLOR_CONS_BRIGHT_YELLOW))
    if evTime           : txt += "Start Time\t: %s\n" % FF0V0A(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FF0V0A(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFuGN6(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFuGN6(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFuGN6(evTime - now)
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFFpMs(evShort, VVZ9CV)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFFpMs(evDesc , VVZ9CV)
    if txt:
     txt = FFFpMs("\n%s\n%s Event:\n%s\n" % (VVo4vY, ("Current", "Next")[evNum], VVo4vY), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVJcGn(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFONbJ(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCOJpB()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV45BY(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFFpMs("URL:", VVtzSE) + "\n%s\n" % self.VVIFl2(decodedUrl)
  else:
   txt = "\n"
   txt += FFFpMs("Reference:", VVtzSE) + "\n%s\n" % refCode
  return txt
 def VVIFl2(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVJtGD:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VVI8Yh(self, decodedUrl):
  if not FFKIlG():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCniMM.VVawMx(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCniMM.VVZkWo(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVoKf2(tDict)
   elif uType == "movie" : epg, picUrl = self.VVFF9B(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVoKf2(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCniMM.VV0Pi7(item, "title"    , is_base64=True )
     lang    = CCniMM.VV0Pi7(item, "lang"         ).upper()
     description   = CCniMM.VV0Pi7(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCniMM.VV0Pi7(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCniMM.VV0Pi7(item, "start_timestamp"      )
     stop_timestamp  = CCniMM.VV0Pi7(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCniMM.VV0Pi7(item, "stop_timestamp"       )
     now_playing   = CCniMM.VV0Pi7(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVLtc8, ""
      else     : color, txt = VVi1SQ , "    (CURRENT EVENT)"
      epg += FFFpMs("_" * 32 + "\n", VV1Lqa)
      epg += FFFpMs("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFFpMs(description, VV5UCJ)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVqHHn(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VVFF9B(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCniMM.VV0Pi7(item, "movie_image" )
    genre  = CCniMM.VV0Pi7(item, "genre"   ) or "-"
    plot  = CCniMM.VV0Pi7(item, "plot"   ) or "-"
    cast  = CCniMM.VV0Pi7(item, "cast"   ) or "-"
    rating  = CCniMM.VV0Pi7(item, "rating"   ) or "-"
    director = CCniMM.VV0Pi7(item, "director"  ) or "-"
    releasedate = CCniMM.VV0Pi7(item, "releasedate" ) or "-"
    duration = CCniMM.VV0Pi7(item, "duration"  ) or "-"
    try:
     lang = CCniMM.VV0Pi7(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFFpMs(cast, VV5UCJ)
    epg += "Plot:\n%s"    % FFFpMs(self.VVu9Kq(plot), VV5UCJ)
   except:
    pass
  return epg, movie_image
 def VVu9Kq(self, evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = self.VVfGg9(evTxt, lang)
   return CCip5O.VV8eii(txt).strip() or evTxt
 @staticmethod
 def VV8eii(txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VVfGg9(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFeJBn(txt))
   txt, err = CCniMM.VVZkWo(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFjPwi(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVqHHn(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
 @staticmethod
 def VV1JmA(SELF):
  if not CCXLzC.VVl7b5(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(SELF)
  err = url =  fSize = resumable = ""
  if FFdSDy(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCOJpB.VV0ESN(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCOJpB.VVSS4mHeader(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FF2wyP(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CC82J5.VVnDM5(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFFpMs(" (M3U/M3U8 File)", VV5UCJ)
    else:
     fSize = "No info. from server. Try again later."
    hResume = resp.headers.get("Accept-Ranges" , "")
    if hResume:
     if not hResume == "none": resumable = "Yes"
     else     : resumable = "No"
   except requests.Timeout as e     : err = "Connection Timeout"
   except Exception as e       : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VValCD(subj, val):
   return "%s\n%s\n\n" % (FFFpMs("%s:" % subj, COLOR_CONS_BRIGHT_YELLOW), val)
  title = "File Size"
  txt  = VValCD(title , fSize or "?")
  txt += VValCD("Name" , chName)
  txt += VValCD("URL" , url)
  if resumable: txt += VValCD("Supports Download-Resume", resumable)
  if err  : txt += FFFpMs("Error:\n", VVi1SQ) + err
  FFHVXB(SELF, txt, title=title)
 @staticmethod
 def VVYTKN(SELF):
  fPath, fDir, fName = CC82J5.VVCYXm(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg", "mvi"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 def VVK4V6(self):
  if VVJtGD:
   def VVtlsz(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVtlsz(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCOJpB()
    valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV45BY(decodedUrl)
    n = ("valid", "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVtlsz(n[i], v[i])
   with open("/tmp/ajp_channel_details", "a") as f:
    f.write("%s\n%s\n" % (VVo4vY, txt))
   FFbstz(self, "Saved to:", 1000)
class CCOJpB():
 def __init__(self):
  self.VVHTHm  = ""
  self.VVNF0S   = ""
  self.VVPKBe  = ""
  self.portal_rand  = ""
  self.portal_moreAuth = False
  self.portal_moreAuthMsg = ""
  self.colored_user  = "#f#11ffffaa#User"
  self.colored_server  = "#f#11aaffff#Server"
 def VV6SCM(self, url, mac, VVJGrp=True):
  self.VVHTHm  = ""
  self.VVNF0S   = ""
  self.VVPKBe  = ""
  self.portal_rand  = ""
  self.portal_moreAuth = False
  self.portal_moreAuthMsg = ""
  host = self.VVHn5b(url)
  if not host:
   if VVJGrp:
    self.VVJGrpor("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVYKWq(mac)
  if not host:
   if VVJGrp:
    self.VVJGrpor("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVHTHm = host
  self.VVNF0S  = mac
  return True
 def VVHn5b(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVYKWq(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVh1Vn(self, VVJGrp=True):
  err = blkMsg = FFnN3YTxt = ""
  try:
   token, rand, err = self.VVXaEd()
   if token:
    self.VVPKBe = token
    self.portal_rand  = rand
    prof = self.VVUVIi()
    if prof:
     word = "m" + "sg"
     blkMsg = CCniMM.VV0Pi7(prof["js"], "block_%s" % word)
     FFnN3YTxt = CCniMM.VV0Pi7(prof["js"], word)
     if blkMsg or FFnN3YTxt:
      self.portal_moreAuth = True
      self.portal_moreAuthMsg = FFnN3YTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFnN3YTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFnN3YTxt: tErr += "\n%s" % FFnN3YTxt
  if VVJGrp:
   self.VVJGrpor(tErr)
  return "", "", tErr
 def VVXaEd(self):
  res, err = self.VVnzVv(self.VVBGuW())
  urlPath = "/stalker_portal"
  if "404" in err and urlPath in self.VVHTHm:
   self.VVHTHm = self.VVHTHm.replace(urlPath, "")
   res, err = self.VVnzVv(self.VVBGuW())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCniMM.VV0Pi7(tDict["js"], "token")
    rand  = CCniMM.VV0Pi7(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVUVIi(self):
  res, err = self.VVnzVv(self.VVUQYt())
  if not err:
   try:
    profJson = jLoads(res.text)
    return profJson
   except:
    pass
  return ""
 def VV1G96(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVHwml()
  if len(rows) < 10:
   rows = self.VVg5f4()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVHTHm ))
   rows.append(("MAC (from URL)" , self.VVNF0S ))
   rows.append(("Token"   , self.VVPKBe ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VVNF0S ))
   rows.append(("2", self.colored_server, "Host" , self.VVHTHm ))
   rows.append(("2", self.colored_server, "Token" , self.VVPKBe ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVHEM1(self, isPhp=True, VVJGrp=False):
  token, profile, tErr = self.VVh1Vn(VVJGrp)
  if not token:
   return "", tErr
  m3u_Url = ""
  url = self.VVjVFZ()
  res, err = self.VVnzVv(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCniMM.VV0Pi7(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFeJBn(span.group(2))
     pass1 = FFeJBn(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, err
 def VVHwml(self):
  m3u_Url, err = self.VVHEM1()
  rows = []
  if m3u_Url:
   res, err = self.VVnzVv(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FF0V0A(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FF0V0A(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVg5f4(self):
  token, profile, tErr = self.VVh1Vn()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFqn0h(val): val = FFdMsE(val.decode("UTF-8"))
     else     : val = self.VVNF0S
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FF0V0A(int(parts[1]))
      if parts[2] : ends = FF0V0A(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FF0V0A(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVNafF(self, mode, chCm, epNum, epId):
  crLinkUrl = self.VVhuwo(mode, chCm, epNum, epId)
  token, profile, tErr = self.VVh1Vn(VVJGrp=False)
  if not token:
   return ""
  res, err = self.VVnzVv(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCniMM.VV0Pi7(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  return chUrl
 def VVUL9A(self):
  return self.VVHTHm + "/server/load.php?"
 def VVBGuW(self):
  return self.VVUL9A() + "type=stb&action=handshake&token=&mac=%s" % self.VVNF0S
 def VVUQYt(self):
  if self.portal_moreAuth:
   import hashlib
   sn    = hashlib.md5(self.VVNF0S).hexdigest().upper()[:13]
   param  = ""
   param += "&sn=%s"   % sn
   param += "&device_id=%s" % hashlib.sha256(sn).hexdigest().upper()
   param += "&device_id2=%s" % hashlib.sha256(self.VVNF0S).hexdigest().upper()
   param += "&signature=%s" % hashlib.sha256(sn + self.VVNF0S).hexdigest().upper()
   param += '&auth_second_step=1'
   param += '&hw_version=2.17-IB-00&hw_version_2=62'
   param += '&metrics={"mac":"%s","sn":"%s","type":"STB","model":"MAG250","random":"%s"}' % (self.VVNF0S, sn, self.portal_rand)
  else:
   param = ""
  return self.VVUL9A() + "type=stb&action=get_profile" + param
 def VVhjBv(self, mode):
  url = self.VVUL9A() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVlkLr(self, catID):
  return self.VVUL9A() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVVCm3(self, mode, catID, page):
  url = self.VVUL9A() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "series" : url += "category=%s" % catID
  else    : url += "genre=%s&force_ch_link_check=" % catID
  return url
 def VVPMDS(self, mode, searchName, page):
  return self.VVUL9A() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VVD8B7(self, mode, catID):
  return self.VVUL9A() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVhuwo(self, mode, chCm, serCode, serId):
  url = self.VVUL9A() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVjVFZ(self):
  return self.VVUL9A() + "type=itv&action=create_link"
 def VVkUmT(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVfclL(catID, stID, chNum)
  query = self.VV7nGG(mode, FFXUin(host), FFXUin(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VV7nGG(self, mode, host, mac, serCode, serId, chCm):
  query = "mode=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VV45BY(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VV7nGG(mode, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFdMsE(host)
  mac   = FFdMsE(mac)
  valid = False
  if self.VVHn5b(playHost) and self.VVHn5b(host) and self.VVHn5b(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVnzVv(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCOJpB.VVSS4mHeader()
   if self.VVPKBe:
    headers["Authorization"] = "Bearer %s" % self.VVPKBe
   if useCookies : cookies = {"mac": self.VVNF0S, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok : return res, ""
   else  : err = "Err-%d : %s" % (res.status_code, res.reason or "Unknown")
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VViG3W(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCOJpB.VVSS4mHeader(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVSS4mHeader():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVIzzA(host, mac, tType, action, keysList=[]):
  myPortal = CCOJpB()
  ok = myPortal.VV6SCM(host, mac)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVh1Vn(VVJGrp=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s/server/load.php?type=%s&action=%s" % (host, tType, action)
  res, err = myPortal.VVnzVv(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVHnW6(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVHnW6(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVJGrpor(self, err, title="Portal Browser"):
  FF2wyP(self, str(err), title=title)
 def VV0qvg(self, mode):
  if   mode in ("itv"  , CCniMM.VVU9tS , CCniMM.VVl7uU)  : return "Live"
  elif mode in ("vod"  , CCniMM.VVUvrx , CCniMM.VVHG63)  : return "VOD"
  elif mode in ("series" , CCniMM.VVJhvm , CCniMM.VVGjad) : return "Series"
  else                          : return "IPTV"
 def VV5q8K(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VV0qvg(mode), searchName)
 def VVeRU3(self, catchup=False):
  VVhOvi = []
  VVhOvi.append(("Live"    , "live"  ))
  VVhOvi.append(("VOD"    , "vod"   ))
  VVhOvi.append(("Series"   , "series"  ))
  if catchup:
   VVhOvi.append(VVaOJ8)
   VVhOvi.append(("Catchup TV" , "catchup"  ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Account Info." , "accountInfo" ))
  return VVhOvi
 @staticmethod
 def VV1L14(decodedUrl):
  m3u_Url = ""
  p = CCOJpB()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV45BY(decodedUrl)
  if valid:
   ok = p.VV6SCM(host, mac, VVJGrp=False)
   if ok:
    m3u_Url, err = p.VVHEM1(isPhp=False, VVJGrp=False)
    span = iSearch(r".+ch\/(.+)_", decodedUrl, IGNORECASE)
    if span:
     m3u_Url += span.group(1)
  return m3u_Url
 @staticmethod
 def VV0ESN(decodedUrl):
  p = CCOJpB()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV45BY(decodedUrl)
  if valid:
   ok = p.VV6SCM(host, mac, VVJGrp=False)
   if ok:
    try:
     chUrl = p.VVNafF(mode, chCm, epNum, epId)
     return FFjPwi(chUrl)
    except Exception as e:
     pass
  return ""
class CCLv4R(CCOJpB):
 def __init__(self):
  CCOJpB.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVrxHz(self, refCode, chName, decodedUrl, iptvRef):
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = self.VV45BY(decodedUrl)
  if valid:
   if self.VV6SCM(host, mac, VVJGrp=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVLsnw(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVNafF(self.mode, self.chCm, self.epNum, self.epId)
  except:
   pass
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = self.refCode + chUrl.strip() + ":" + self.chName
  newIptvRef = self.VVKloe(chUrl)
  if newIptvRef:
   success = self.VVe2jr(self.iptvRef, newIptvRef)
   if passedSELF:
    FFulYh(passedSELF, newIptvRef, VVK8qL=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFulYh(self, newIptvRef, VVK8qL=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VVKloe(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVe2jr(self, oldCode, newCode):
  bPath = FFIVg3()
  if bPath:
   txt = FFJPcA(bPath)
   if oldCode in txt:
    txt = txt.replace(oldCode, newCode)
    with open(bPath, "w") as f:
     f.write(txt)
    FFgjOJ()
    return True
  return False
class CCrCPE(CCLv4R):
 def __init__(self, passedSession):
  CCLv4R.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.starttime  = iTime()
  self.timer1   = eTimer()
  self.isFromEOF  = False
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVJs3p, iPlayableService.evEOF: self.VVlPSL, iPlayableService.evEnd: self.VVKgjc})
  except:
   pass
 def VVJs3p(self):
  self.starttime = iTime()
 def VVlPSL(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.starttime) > 2:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self.passedSession, isFromSession=True)
    if iptvRef and not FFdSDy(decodedUrl):
     span = iSearch(r"(mode=itv.+end=)", decodedUrl, IGNORECASE)
     if span:
      self.isFromEOF = True
     CCmBoh(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
 def VVKgjc(self):
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVImZc)
  except:
   self.timer1.callback.append(self.VVImZc)
  self.timer1.start(100, True)
 def VVImZc(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self.passedSession, isFromSession=True)
  valid = False
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVrxHz(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCrMvG.VVI11X:
       self.isFromEOF = False
       self.VVLsnw(self.passedSession, isFromSession=True)
class CCsfdL():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.adultWords  = ("adult", "aduld", "sex", "porn", "xxx", "xxi", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.nameTagPatt = r"\s*[\[(|:].*[\])|:](.+)|\s*(?:[^a-z]+:)*(.+)"
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.missingUtf8 = VV3fmU and not VVnLJy
 def VVSQZW(self, name):
  if self.missingUtf8:
   name = str(name.encode('ascii', 'replace').decode('utf-8'))
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCniMM.VVYfjm(name):
   return CCniMM.VVypxI(name)
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    name = span.group(1) or span.group(2)
  return name.strip() or name
 def VVGCeA(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  span = iSearch(self.nameTagPatt, name)
  if span:
   name = span.group(1) or span.group(2)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVgYc1(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  else:
   return name.strip()
 def VVYMjr(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVp8GM(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCXLzC(CCOJpB):
 def __init__(self):
  CCOJpB.__init__(self)
 def VVFNzj(self):
  if CCXLzC.VVl7b5(self):
   FFmTns(self, self.VVLJqp, title="Searching ...")
 def VVZMBD(self, winSession, url, mac):
  if CCXLzC.VVl7b5(self):
   if self.VV6SCM(url, mac):
    FFmTns(winSession, self.VVt8LE, title="Checking Server ...")
   else:
    FF2wyP(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVLJqp(self):
  path = CCniMM.VVYViJ()
  lines = FFGCWo('find %s %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % (path, FFBbZi(1)))
  if lines:
   lines.sort()
   VVhOvi = []
   for line in lines:
    VVhOvi.append((line, line))
   OKBtnFnc  = self.VVePGv
   VVyt0G = ("Delete File", self.VVkYZs)
   FFN6sa(self, None, title="Select Portals File", VVhOvi=VVhOvi, width=1200, OKBtnFnc=OKBtnFnc, VVyt0G=VVyt0G)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FF2wyP(self, 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt)
 def VVkYZs(self, VVfiljObj, path):
  FFStgm(self, boundFunction(self.VVf3rw, VVfiljObj, path), "Delete this file ?\n\n%s" % path)
 def VVf3rw(self, VVfiljObj, path):
  os.system(FFiu56("rm -f '%s'" % path))
  if fileExists(path) : FFbstz(VVfiljObj, "Not deleted", 1000)
  else    : VVfiljObj.VVtH0B()
 def VVePGv(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = CCy6sJ.VVKeHm(path, self)
   if enc == -1:
    return
   self.session.open(CCvjpm, barTheme=CCvjpm.VVdivo
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VVdq9M, path, enc)
       , VVPtly = boundFunction(self.VVAYeT, menuInstance, path))
 def VVdq9M(self, path, enc, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  progBarObj.VVJZYU(totLines)
  progBarObj.VVQ53i = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVVcps(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVHn5b(url)
     mac  = self.VVYKWq(mac)
     if host and mac and progBarObj:
      progBarObj.VVQ53i.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVHn5b(url)
      mac  = self.VVYKWq(mac)
      if host and mac and not mac.startswith("AC") and progBarObj:
       progBarObj.VVQ53i.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVAYeT(self, menuInstance, path, VVWfVW, VVQ53i, threadCounter, threadTotal, threadErr):
  title = "Portals List File"
  if VVQ53i:
   VVeO38  = ("Home Menu", FFQ6xc, [])
   VVMVHK  = None #("Check & Filter" , boundFunction(self.filterPortalAuthorizedServers, path), [])
   VVCfae = ("Edit File" , boundFunction(self.VVYlKw, path) , [])
   VVPtGh = ("Open as M3U", self.VVEMp8     , [])
   VVPZiO  = ("Select"  , self.VVZMBD_fromMacFiles   , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVFSP3  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVmxnp = FFyzis(self, None, title=title, header=header, VV2PlJ=VVQ53i, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=26, VVPZiO=VVPZiO, VVeO38=VVeO38, VVPtGh=VVPtGh, VVCfae=VVCfae, VVMVHK=VVMVHK, VVxH2w="#0a001122", VV2Du9="#0a001122", VVPEgn="#0a001122", VVV3E9="#00004455", VVPt5m="#0a333333", VVbcXu="#11331100", VVwf0p=True, searchCol=1)
   if not VVWfVW:
    FFbstz(VVmxnp, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVWfVW:
    FF2wyP(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVEMp8(self, VVmxnp, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  FFmTns(VVmxnp, boundFunction(self.VVv1Se, VVmxnp, host, mac), title="Checking Server ...")
 def VVv1Se(self, VVmxnp, host, mac):
  p = CCOJpB()
  m3u_Url = ""
  ok = p.VV6SCM(host, mac, VVJGrp=False)
  err = ""
  if ok:
   m3u_Url, err = p.VVHEM1(VVJGrp=False)
  title = "Browsing M3U Server from Portal Data"
  if m3u_Url:
   self.VVU9VF(title, m3u_Url)
  else:
   FF2wyP(self, err or "No response from Server !", title=title)
 def VVZMBD_fromMacFiles(self, VVmxnp, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVZMBD(VVmxnp, url, mac)
 def VVYlKw(self, path, VVmxnp, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCtRew(self, path, VVPtly=boundFunction(self.VVqVCt, VVmxnp), curRowNum=rowNum)
  else    : FFUQ3Z(self, path)
 def VV93Oh(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFdMsE(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVt8LE(self):
  token, profile, tErr = self.VVh1Vn()
  if token:
   VVhOvi  = self.VVeRU3()
   OKBtnFnc = self.VVBUHS
   VVd2z3 = ("Home Menu", FFQ6xc)
   VVmwoc = ("Bookmark Server", boundFunction(CCniMM.VVzeec, self, True, self.VVHTHm + "\t" + self.VVNF0S))
   authMore = ".." if self.portal_moreAuth else ""
   FFN6sa(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVNF0S, authMore), VVhOvi=VVhOvi, OKBtnFnc=OKBtnFnc, VVd2z3=VVd2z3, VVmwoc=VVmwoc)
 def VVBUHS(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFmTns(menuInstance, boundFunction(self.VVmCAw, mode), title="Reading Categories ...")
   else : FFmTns(menuInstance, boundFunction(self.VVw4yJ, menuInstance, title), title="Reading Account ...")
 def VVw4yJ(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VV1G96(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVNF0S)
  VVeO38  = ("Home Menu" , FFQ6xc, [])
  if totCols == 2:
   VVMVHK = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
   VVMVHK = ("More Info.", boundFunction(self.VV4trT, menuInstance) , [])
  FFyzis(self, None, title=title, width=1200, header=header, VV2PlJ=rows, VVDrmL=widths, VVCZ7I=26, VVeO38=VVeO38, VVMVHK=VVMVHK, VVxH2w="#0a00292B", VV2Du9="#0a002126", VVPEgn="#0a002126", VVV3E9="#00000000", searchCol=searchCol)
 def VV4trT(self, menuInstance, VVmxnp, title, txt, colList):
  VVmxnp.cancel()
  FFmTns(menuInstance, boundFunction(self.VVw4yJ, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVmCAw(self, mode):
  token, profile, tErr = self.VVh1Vn()
  if not token:
   return
  res, err = self.VVnzVv(self.VVhjBv(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CCsfdL()
     chList = tDict["js"]
     for item in chList:
      Id   = CCniMM.VV0Pi7(item, "id"       )
      Title  = CCniMM.VV0Pi7(item, "title"      )
      censored = CCniMM.VV0Pi7(item, "censored"     )
      Title = processChanName.VVgYc1(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVPjL0:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VV0qvg(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVxH2w, VV2Du9, VVPEgn, VVV3E9 = self.VVMUVc(mode)
   mName = self.VV0qvg(mode)
   VVPZiO   = ("Show List"   , boundFunction(self.VVDvaU, mode) , [])
   VVeO38  = ("Home Menu"   , FFQ6xc         , [])
   if mode in ("vod", "series"):
    VVCfae = ("Find in %s" % mName , boundFunction(self.VV2lW6, mode), [])
   else:
    VVCfae = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FFyzis(self, None, title=title, width=1200, header=header, VV2PlJ=list, VVDrmL=widths, VVCZ7I=30, VVeO38=VVeO38, VVCfae=VVCfae, VVPZiO=VVPZiO, VVxH2w=VVxH2w, VV2Du9=VV2Du9, VVPEgn=VVPEgn, VVV3E9=VVV3E9)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.portal_moreAuthMsg:
     txt += "\n\n( %s )" % self.portal_moreAuthMsg
   else:
    txt = "Could not get Categories from server!"
   FF2wyP(self, txt, title=title)
 def VVLiVk(self, mode, VVmxnp, title, txt, colList):
  FFmTns(VVmxnp, boundFunction(self.VVfkqp, mode, VVmxnp, title, txt, colList), title="Downloading ...")
 def VVfkqp(self, mode, VVmxnp, title, txt, colList):
  token, profile, tErr = self.VVh1Vn()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVnzVv(self.VVlkLr(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCniMM.VV0Pi7(item, "id"    )
      actors   = CCniMM.VV0Pi7(item, "actors"   )
      added   = CCniMM.VV0Pi7(item, "added"   )
      age    = CCniMM.VV0Pi7(item, "age"   )
      category_id  = CCniMM.VV0Pi7(item, "category_id" )
      description  = CCniMM.VV0Pi7(item, "description" )
      director  = CCniMM.VV0Pi7(item, "director"  )
      genres_str  = CCniMM.VV0Pi7(item, "genres_str"  )
      name   = CCniMM.VV0Pi7(item, "name"   )
      path   = CCniMM.VV0Pi7(item, "path"   )
      screenshot_uri = CCniMM.VV0Pi7(item, "screenshot_uri" )
      series   = CCniMM.VV0Pi7(item, "series"   )
      cmd    = CCniMM.VV0Pi7(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VVPZiO  = ("Play"    , boundFunction(self.VVuNTt, mode)       , [])
   VVyW3N = (""     , boundFunction(self.VVge47, mode)     , [])
   VVeO38 = ("Home Menu"   , FFQ6xc               , [])
   VVPtGh = ("Download Options" , boundFunction(self.VVmNQH, mode, "sp", seriesName) , [])
   VVCfae = ("Options" , boundFunction(self.VVLgHV, 0, "pEp", mode, seriesName)  , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVFSP3  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFyzis(self, None, title=seriesName, width=1200, header=header, VV2PlJ=list, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=26, VVeO38=VVeO38, VVPtGh=VVPtGh, VVCfae=VVCfae, VVPZiO=VVPZiO, VVyW3N=VVyW3N, VVxH2w="#0a00292B", VV2Du9="#0a002126", VVPEgn="#0a002126", VVV3E9="#00000000")
  else:
   FF2wyP(self, "Could not get Episodes from server!", title=seriesName)
 def VV2lW6(self, mode, VVmxnp, title, txt, colList):
  VVhOvi = []
  VVhOvi.append(("Keyboard"  , "manualEntry"))
  VVhOvi.append(("From Filter" , "fromFilter"))
  FFN6sa(self, boundFunction(self.VV7ihU, VVmxnp, mode), title="Input Type", VVhOvi=VVhOvi, width=400)
 def VV7ihU(self, VVmxnp, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFK2QC(self, boundFunction(self.VVsp8i, VVmxnp, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCROIp(self)
    filterObj.VVxr86(boundFunction(self.VVsp8i, VVmxnp, mode))
 def VVsp8i(self, VVmxnp, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VV5q8K(mode, searchName)
   if len(searchName) < 3:
    FF2wyP(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CCsfdL()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVYMjr([searchName]):
     FF2wyP(self, processChanName.VVp8GM(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VVdYHY(mode, searchName, "", searchName)
 def VVDvaU(self, mode, VVmxnp, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVdYHY(mode, bName, catID, "")
 def VVdYHY(self, mode, bName, catID, searchName):
  self.session.open(CCvjpm, barTheme=CCvjpm.VVdivo
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVp4ay, mode, bName, catID, searchName)
      , VVPtly = boundFunction(self.VVOdZz, mode, bName, catID, searchName))
 def VVOdZz(self, mode, bName, catID, searchName, VVWfVW, VVQ53i, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VV5q8K(mode, searchName)
  else   : title = "%s : %s" % (self.VV0qvg(mode), bName)
  if VVQ53i:
   VVPtGh = None
   VVCfae = None
   if mode == "series":
    VVxH2w, VV2Du9, VVPEgn, VVV3E9 = self.VVMUVc("series2")
    VVPZiO  = ("Episodes", boundFunction(self.VVLiVk, mode) , [])
   else:
    VVxH2w, VV2Du9, VVPEgn, VVV3E9 = self.VVMUVc("")
    VVPZiO  = ("Play"    , boundFunction(self.VVuNTt, mode)           , [])
    VVPtGh = ("Download Options" , boundFunction(self.VVmNQH, mode, "vp" if mode == "vod" else "", "") , [])
    VVCfae = ("Options" , boundFunction(self.VVLgHV, 1, "pCh", mode, bName)  , [])
   VVyW3N = (""      , boundFunction(self.VVWMhe, mode)          , [])
   VVeO38 = ("Home Menu"    , FFQ6xc                   , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVFSP3  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT )
   VVmxnp = FFyzis(self, None, title=title, header=header, VV2PlJ=VVQ53i, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=26, VVeO38=VVeO38, VVPtGh=VVPtGh, VVCfae=VVCfae, VVPZiO=VVPZiO, VVyW3N=VVyW3N, VVxH2w=VVxH2w, VV2Du9=VV2Du9, VVPEgn=VVPEgn, VVV3E9=VVV3E9, VVwf0p=True, searchCol=1)
   if not VVWfVW:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVmxnp.VVJgLc(VVmxnp.VV2iNw() + tot)
    if threadErr: FFbstz(VVmxnp, "Error while reading !", 2000)
    else  : FFbstz(VVmxnp, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FF2wyP(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FF2wyP(self, "Could not get list from server !", title=title)
 def VVWMhe(self, mode, VVmxnp, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFhDEp(self, fncMode=CCip5O.VVznb5, portalHost=self.VVHTHm, portalMac=self.VVNF0S, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVPUTf(mode, VVmxnp, title, txt, colList)
 def VVge47(self, mode, VVmxnp, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFFpMs(colList[10], VV5UCJ)
  txt += "Description:\n%s" % FFFpMs(colList[11], VV5UCJ)
  self.VVPUTf(mode, VVmxnp, title, txt, colList)
 def VVPUTf(self, mode, VVmxnp, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVCLGa(mode, colList)
  refCode, chUrl = self.VVkUmT(self.VVHTHm, self.VVNF0S, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFhDEp(self, fncMode=CCip5O.VVpdMX, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVp4ay(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile, tErr = self.VVh1Vn()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VVQ53i, total_items, max_page_items, err = self.VVEiv6(mode, catID, 1, 1, searchName)
   if progBarObj.isCancelled:
    return
   if progBarObj.VVQ53i and total_items > -1 and max_page_items > -1:
    progBarObj.VVJZYU(total_items)
    progBarObj.VVVcps(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVEiv6(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VV4S9M()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VVQ53i += list
      progBarObj.VVVcps(len(list), True)
  except:
   pass
 def VVEiv6(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVPMDS(mode, searchName, page)
  else   : url = self.VVVCm3(mode, catID, page)
  res, err = self.VVnzVv(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVhyZF(CCniMM.VV0Pi7(item, "total_items" ))
     max_page_items = self.VVhyZF(CCniMM.VV0Pi7(item, "max_page_items" ))
     processChanName = CCsfdL()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCniMM.VV0Pi7(item, "id"    )
      name   = CCniMM.VV0Pi7(item, "name"   )
      tv_genre_id  = CCniMM.VV0Pi7(item, "tv_genre_id" )
      number   = CCniMM.VV0Pi7(item, "number"   ) or str(counter)
      logo   = CCniMM.VV0Pi7(item, "logo"   )
      screenshot_uri = CCniMM.VV0Pi7(item, "screenshot_uri" )
      cmd    = CCniMM.VV0Pi7(item, "cmd"   )
      cmd = cmd.replace("ffmpeg ", "")
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8"):
       span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      counter += 1
      name = processChanName.VVSQZW(name)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVVjFQ(self, mode, bName, VVmxnp, title, txt, colList):
  bNameFile = CCniMM.VVwv6Z_forBouquet(bName)
  num  = 0
  path = VVEkHL + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVEkHL + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   isMulti = VVmxnp.VVbF0F
   for ndx, row in enumerate(VVmxnp.VVlcwp()):
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVCLGa(mode, row)
    refCode, chUrl = self.VVkUmT(self.VVHTHm, self.VVNF0S, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    if not isMulti or VVmxnp.VVxu9W(ndx):
     f.write("#SERVICE %s\n"  % chUrl)
     f.write("#DESCRIPTION %s\n" % chName)
     totChange += 1
  FFJeEN(os.path.basename(path))
  self.VVBMaW(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVhyZF(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVuNTt(self, mode, VVmxnp, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVCLGa(mode, colList)
  refCode, chUrl = self.VVkUmT(self.VVHTHm, self.VVNF0S, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVYfjm(chName):
   FFbstz(VVmxnp, "This is a marker!", 300)
  else:
   FFmTns(VVmxnp, boundFunction(self.VV0I3N, mode, VVmxnp, chUrl), title="Playing ...")
 def VV0I3N(self, mode, VVmxnp, chUrl):
  FFulYh(self, chUrl, VVK8qL=False)
  self.session.open(CCrMvG, portalTableParam=(self, VVmxnp, mode))
 def VVH8UH(self, mode, VVmxnp, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVCLGa(mode, colList)
  refCode, chUrl = self.VVkUmT(self.VVHTHm, self.VVNF0S, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVCLGa(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVl7b5(SELF):
  try:
   import requests
   return True
  except:
   FFStgm(SELF, boundFunction(CCXLzC.VVzZXw, SELF), 'This requires the library "Requests".\n\nInstall it now ?')
   return False
 @staticmethod
 def VVzZXw(SELF):
  from sys import version_info
  cmdUpd = FFSU1Z(VVbsC9, "")
  if cmdUpd:
   cmdInst = FF5ENR(VVIqrC, "python-requests")
   if version_info[0] >= 3:
    cmdInst = cmdInst.replace("python-", "python3-")
   cmd = cmdUpd + " && " + cmdInst
   FFHbvq(SELF, cmd, checkNetAccess=True, title="Installing Requests Library")
  else:
   FFAopx(SELF)
class CCniMM(Screen, CCXLzC):
 VV3NBp    = 0
 VVQ0iW    = 1
 VVKJoE    = 2
 VVYkCI    = 3
 VVnLVc     = 4
 VVtWJw     = 5
 VV3qZv     = 6
 VVCovy     = 7
 VV0aDZ      = 8
 VVSdDo     = 9
 VVe35y     = 10
 VVmkCP     = 11
 VVtxYJ     = 12
 VVbiWo      = 13
 VVkru3      = 14
 VVACCK      = 15
 VVwhwR      = 16
 VVwWW2      = 17
 VVc5IF    = 0
 VVU9tS   = 1
 VVUvrx   = 2
 VVJhvm   = 3
 VV9RwF  = 4
 VV4d1i  = 5
 VVl7uU   = 6
 VVHG63   = 7
 VVGjad  = 8
 VVxgl2  = 9
 VVOdpp  = 10
 VV1T4F = 0
 VVRCe3 = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FF82u7(VVyaPF, 1000, 1000, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.m3uOrM3u8File  = m3uOrM3u8File
  self.m3uOrM3u8BName  = ""
  self.VVmxnp  = None
  self.tableTitle   = "IPTV Channels List"
  self.VVb4wgData  = {}
  self.lastFindIptvName = ""
  CCXLzC.__init__(self)
  VVhOvi= self.VV4auU()
  FFFsOT(self, title="IPTV", VVhOvi=VVhOvi)
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FFEktE(self["myMenu"])
  FFwhmb(self)
  FFZw75(self)
  if self.m3uOrM3u8File:
   self.VVuPj5(self.m3uOrM3u8File)
 def VV4auU(self):
  files = self.VVsRF1()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"        , "VVb4wg_fromPlayList" ))
  tList.append(("IPTV Server Browser (from Portal List)"        , "VVb4wg_fromMac"  ))
  tList.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)"    , "VVb4wg_fromM3u"  ))
  qUrl, iptvRef = self.VVV5hJ()
  if qUrl or "chCode" in iptvRef:
   tList.append(("IPTV Server Browser (from Current Channel)"      , "VVb4wg_fromCurrChan" ))
  VVhOvi = []
  if files:
   if self.VVmxnp:
    VVhOvi.append(("Add Current List to a New Bouquet"      , "VVFWGp"  ))
    VVhOvi.append(VVaOJ8)
    VVhOvi.append(("Change Current List References to Unique Codes"   , "VVMN7w"))
    VVhOvi.append(("Change Current List References to Identical Codes"  , "VVIzSX_rows" ))
    VVhOvi.append(VVaOJ8)
    VVhOvi.append(("Share Reference with Satellite/C/T Service (manual entry)", "VV59qj"   ))
    VVhOvi.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VVtWNH"   ))
   else:
    VVhOvi += tList
    VVhOvi.append(VVaOJ8)
    VVhOvi.append(("M3U/M3U8 Channels Browser"        , "VVzdRa"   ))
    VVhOvi.append(("Local IPTV Channels"          , "iptvTable_all"   ))
    if qUrl:
     VVhOvi.append(VVaOJ8)
     VVhOvi.append(("Update Current Bouquet EPG (from IPTV Server)"  , "refreshIptvEPG"   ))
    VVhOvi.append(VVaOJ8)
    VVhOvi.append(("Count Available IPTV Channels"       , "VVyj1C"    ))
    VVhOvi.append(("Check Reference Codes Format"        , "VVvdFB"   ))
    VVhOvi.append(("Check System Acceptable Reference Types"     , "VVPeh9"   ))
    VVhOvi.append(VVaOJ8)
    VVhOvi.append(("Share Reference with Sat./C/T (Only Matching Names)"  , "VVyCtU" ))
    VVhOvi.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVYZWe"  ))
    VVhOvi.append(("Change ALL References to Unique Codes"     , "VVuE6O" ))
    VVhOvi.append(("Change ALL References to Identical Codes"     , "VVIzSX_all" ))
  if not self.VVmxnp:
   if not files:
    VVhOvi += tList
   if not CCnmQ8.VVjZWd():
    VVhOvi.append(VVaOJ8)
    VVhOvi.append(("Download Manager"           , "dload_stat"    ))
  return VVhOvi
 def VVBFoS(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVFWGp"   : FFK2QC(self, self.VVFWGp, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVMN7w" : FFStgm(self, boundFunction(FFmTns, self.VVmxnp, self.VVMN7w ), "Change Current List References to Unique Codes ?")
   elif item == "VVIzSX_rows" : FFStgm(self, boundFunction(FFmTns, self.VVmxnp, self.VVIzSX   ), "Change Current List References to Identical Codes ?")
   elif item == "VV59qj"   : self.VV59qj(tTitle)
   elif item == "VVtWNH"   : self.VVtWNH(tTitle)
   elif item == "VVb4wg_fromPlayList" : FFmTns(self, self.VV5l3N, title=title)
   elif item == "VVb4wg_fromM3u"  : FFmTns(self, boundFunction(self.VV7SbR, 0), title=title)
   elif item == "VVb4wg_fromMac"  : self.VVFNzj()
   elif item == "VVb4wg_fromCurrChan" : self.VVZMBD_fromCurrChan()
   elif item == "VVzdRa"   : self.VVzdRa()
   elif item == "iptvTable_live"   : FFmTns(self, boundFunction(self.VV7LjS, self.VVCovy ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFmTns(self, boundFunction(self.VV7LjS, self.VV3NBp) , title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VVpvlE()
   elif item == "VVyj1C"    : FFmTns(self, self.VVyj1C)
   elif item == "VVvdFB"    : FFmTns(self, self.VVvdFB)
   elif item == "VVPeh9"   : FFmTns(self, self.VVPeh9)
   elif item == "VVyCtU"  : FFStgm(self, boundFunction(FFmTns, self, self.VVyCtU ), "Continue ?")
   elif item == "VVYZWe"  : self.VVYZWe()
   elif item == "VVuE6O" : FFStgm(self, boundFunction(FFmTns, self, self.VVuE6O ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVIzSX_all" : FFStgm(self, boundFunction(FFmTns, self, self.VVIzSX  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "dload_stat"    : CCnmQ8.VVW2Oa(self)
   elif item == "VVMcgq"   : FFmTns(self, boundFunction(CCz7Lj.VVMcgq, self))
 def VVzdRa(self):
  if CCXLzC.VVl7b5(self):
   FFmTns(self, boundFunction(self.VV7SbR, 1), title="Searching ...")
 def VVIpBc(self):
  global VVnwy6
  VVnwy6 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVBFoS(item)
 def VV7LjS(self, mode):
  VV2X4t = self.VVchoD(mode)
  if VV2X4t:
   VVPtGh = ("Current Service", self.VVnZeR  , [])
   VVCfae = ("Options"  , self.VVtcYl    , [])
   VVMVHK = ("Filter"   , self.VV40ch    , [])
   VVPZiO  = ("Play"   , boundFunction(self.VV63RB) , [])
   VVyW3N = (""    , self.VVFHOL     , [])
   VVYLq6 = (""    , self.VVPq0H      , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVFSP3  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFyzis(self, None, header=header, VV2PlJ=VV2X4t, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=26
     , VVPZiO=VVPZiO, VVPtGh=VVPtGh, VVCfae=VVCfae, VVMVHK=VVMVHK, VVyW3N=VVyW3N, VVYLq6=VVYLq6
     , VVxH2w="#0a00292B", VV2Du9="#0a002126", VVPEgn="#0a002126", VVV3E9="#00000000", VVwf0p=True, searchCol=1)
  else:
   if mode == self.VVCovy: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FF2wyP(self, err)
 def VVPq0H(self, VVmxnp, title, txt, colList):
  self.VVmxnp = VVmxnp
 def VVtcYl(self, VVmxnp, title, txt, colList):
  VVhOvi= self.VV4auU()
  FFN6sa(self, self.VVBFoS, title="IPTV Tools", VVhOvi=VVhOvi)
 def VV40ch(self, VVmxnp, title, txt, colList):
  VVhOvi = []
  VVhOvi.append(("All"         , "all"   ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Prefix of Selected Channel"   , "sameName" ))
  VVhOvi.append(("Suggest Words from Selected Channel" , "partName" ))
  VVhOvi.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Live TV"        , "live"  ))
  VVhOvi.append(("VOD"         , "vod"   ))
  VVhOvi.append(("Series"        , "series"  ))
  VVhOvi.append(("Uncategorised"      , "uncat"  ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Video"        , "video"  ))
  VVhOvi.append(("Audio"        , "audio"  ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("MKV"         , "MKV"   ))
  VVhOvi.append(("MP4"         , "MP4"   ))
  VVhOvi.append(("MP3"         , "MP3"   ))
  VVhOvi.append(("AVI"         , "AVI"   ))
  VVhOvi.append(("FLV"         , "FLV"   ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVdcC2()
  if bNames:
   bNames.sort()
   VVhOvi.append(VVaOJ8)
   for item in bNames:
    VVhOvi.append((item, "__b__" + item))
  filterObj = CCROIp(self)
  filterObj.VVkGhG(VVhOvi, VVhOvi, boundFunction(self.VVcQLs, VVmxnp))
 def VVcQLs(self, VVmxnp, item=None):
  prefix = VVmxnp.VVYTBT(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VV3NBp, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVQ0iW , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVKJoE , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVYkCI , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVCovy  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VV0aDZ   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVSdDo  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVe35y  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVmkCP  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVtxYJ  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVbiWo   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVkru3   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVACCK   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVwhwR   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVwWW2   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VV3qZv  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VVnLVc  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVtWJw  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVKJoE:
   VVhOvi = []
   chName = VVmxnp.VVYTBT(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVhOvi.append((item, item))
    if not VVhOvi and chName:
     VVhOvi.append((chName, chName))
    FFN6sa(self, boundFunction(self.VVg6AP_partOfName, title), title="Words from Current Selection", VVhOvi=VVhOvi)
   else:
    VVmxnp.VV9577("Invalid Channel Name")
  else:
   words, asPrefix = CCROIp.VVputs(words)
   if not words and mode in (self.VVnLVc, self.VVtWJw):
    FFbstz(self.VVmxnp, "Incorrect filter", 2000)
   else:
    FFmTns(self.VVmxnp, boundFunction(self.VVNzR1, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVg6AP_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFmTns(self.VVmxnp, boundFunction(self.VVNzR1, self.VVKJoE, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVypxI(txt):
  return "#f#11ffff00#" + txt
 def VVNzR1(self, mode, words, asPrefix, title):
  VV2X4t = self.VVchoD(mode=mode, words=words, asPrefix=asPrefix)
  if VV2X4t : self.VVmxnp.VVkuQb(VV2X4t, title)
  else  : self.VVmxnp.VV9577("Not found")
 def VVchoD(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VV2X4t = []
  files  = self.VVsRF1()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFJPcA(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVzAka = span.group(1)
    else : VVzAka = ""
    VVzAka_lCase = VVzAka.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVYfjm(chName): chNameMod = self.VVypxI(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVzAka, chType, refCode, url)
     ok = False
     tUrl = FFjPwi(url).lower()
     if mode == self.VV3NBp       : ok = True
     elif mode == self.VV3qZv       : ok = True
     elif mode == self.VVmkCP:
      if CCniMM.VVawMx(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVtxYJ:
      if CCniMM.VVawMx(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVCovy:
      if CCniMM.VVawMx(tUrl, compareType="live")  : ok = True
     elif mode == self.VV0aDZ:
      if CCniMM.VVawMx(tUrl, compareType="movie") : ok = True
     elif mode == self.VVSdDo:
      if CCniMM.VVawMx(tUrl, compareType="series") : ok = True
     elif mode == self.VVe35y:
      if CCniMM.VVawMx(tUrl, compareType="")   : ok = True
     elif mode == self.VVbiWo:
      if CCniMM.VVawMx(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVkru3:
      if CCniMM.VVawMx(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVACCK:
      if CCniMM.VVawMx(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVwhwR:
      if CCniMM.VVawMx(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVwWW2:
      if CCniMM.VVawMx(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVQ0iW:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVKJoE:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVYkCI:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VVnLVc:
      if words[0] == VVzAka_lCase:
       ok = True
     elif mode == self.VVtWJw:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VV2X4t.append(row)
      chNum += 1
  if VV2X4t and mode == self.VV3qZv:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VV2X4t)
   for item in VV2X4t:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VV2X4t = newRows
  return VV2X4t
 def VVFWGp(self, bName):
  if bName:
   FFmTns(self.VVmxnp, boundFunction(self.VVhbB7, bName), title="Adding Channels ...")
 def VVhbB7(self, bName):
  num = 0
  path = VVEkHL + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVEkHL + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVmxnp.VVlcwp():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFwPAs(row[1]))
    totChange += 1
  FFJeEN(os.path.basename(path))
  self.VVBMaW(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVYZWe(self):
  txt = "Stream Type "
  VVhOvi = []
  VVhOvi.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVhOvi.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVhOvi.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVhOvi.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVhOvi.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVhOvi.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFN6sa(self, self.VV8olj, title="Change Reference Types to:", VVhOvi=VVhOvi)
 def VV8olj(self, item=None):
  if item:
   if   item == "RT_1"  : self.VViXmo("1"   )
   elif item == "RT_4097" : self.VViXmo("4097")
   elif item == "RT_5001" : self.VViXmo("5001")
   elif item == "RT_5002" : self.VViXmo("5002")
   elif item == "RT_8192" : self.VViXmo("8192")
   elif item == "RT_8193" : self.VViXmo("8193")
 def VViXmo(self, rType):
  FFStgm(self, boundFunction(FFmTns, self, boundFunction(self.VVAd7c, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVAd7c(self, refType):
  totChange = 0
  files  = self.VVsRF1()
  if files:
   for path in files:
    txt = FFJPcA(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFJeEN(os.path.basename(path))
  self.VVBMaW(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVyj1C(self):
  totFiles = 0
  files  = self.VVsRF1()
  if files:
   totFiles = len(files)
  totChans = 0
  VV2X4t = self.VVchoD()
  if VV2X4t:
   totChans = len(VV2X4t)
  FFHVXB(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVvdFB(self):
  files  = self.VVsRF1()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFJPcA(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVplBl
   else    : color = VVi1SQ
   totInvalid = FFFpMs(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFFpMs("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFHVXB(self, txt, title="Check IPTV References")
 def VVPeh9(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVEkHL + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFJeEN(os.path.basename(path))
  FFgjOJ()
  acceptedList = []
  VVbzRG = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVbzRG:
   VVJptv = FF0wye(VVbzRG)
   if VVJptv:
    for service in VVJptv:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVEkHL + userBName
  bFile = VVEkHL + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFiu56("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFiu56("rm -f '%s'" % path)
  os.system(cmd)
  FFgjOJ()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVplBl
    else     : res, color = "No" , VVi1SQ
    txt += "    %s\t: %s\n" % (item, FFFpMs(res, color))
   FFHVXB(self, txt, title=title)
  else:
   txt = FF2wyP(self, "Could not complete the test on your system!", title=title)
 def VVyCtU(self):
  lameDbChans = CCz7Lj.VVdmHx(self, CCz7Lj.VVj6fN)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVsRF1():
    toSave = False
    txt = FFJPcA(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVBMaW(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FF2wyP(self, 'No channels in "lamedb" !')
 def VVuE6O(self):
  files  = self.VVsRF1()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFQoVo(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVsH3X(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVBMaW(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVMN7w(self):
  iptvRefList = []
  files  = self.VVsRF1()
  if files:
   for path in files:
    txt = FFJPcA(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVmxnp.VVrsXN(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVsH3X(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVsRF1()
  if files:
   for path in files:
    lines = FFQoVo(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVBMaW(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVsH3X(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVIzSX(self):
  list = None
  if self.VVmxnp:
   list = []
   for row in self.VVmxnp.VVlcwp():
    list.append(row[4] + row[5])
  files  = self.VVsRF1()
  totChange = 0
  if files:
   for path in files:
    lines = FFQoVo(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVBMaW(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVBMaW(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFgjOJ()
   if refreshTable and self.VVmxnp:
    VV2X4t = self.VVchoD()
    if VV2X4t and self.VVmxnp:
     self.VVmxnp.VVkuQb(VV2X4t, self.tableTitle)
     self.VVmxnp.VV9577(txt)
   FFHVXB(self, txt, title=title)
  else:
   FFnN3Y(self, "No changes.")
 def VVdcC2(self):
  files = self.VVsRF1()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with ioOpen(path, "r", encoding="utf-8") as f:
     span = iSearch(r"#NAME\s+(.*)", str(f.readline()), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VV12RE = FFRVXA()
    if VV12RE:
     for b in VV12RE:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVsRF1(self):
  return CCniMM.VVSdoT(self)
 @staticmethod
 def VVSdoT(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVEkHL + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFJPcA(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVFHOL(self, VVmxnp, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFjPwi(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFhDEp(self, fncMode=CCip5O.VVDr3L, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVDyXs(self, VVmxnp, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VV63RB(self, VVmxnp, title, txt, colList):
  chName, chUrl = self.VVDyXs(VVmxnp, colList)
  self.VVaiKj(VVmxnp, chName, chUrl, "localIptv")
 def VVLNrn(self, mode, VVmxnp, colList):
  chName, chUrl, picUrl, refCode = self.VVu0xi(mode, colList)
  return chName, chUrl
 def VVW5b0(self, mode, VVmxnp, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVu0xi(mode, colList)
  self.VVaiKj(VVmxnp, chName, chUrl, mode)
 def VVaiKj(self, VVmxnp, chName, chUrl, playerFlag):
  chName = FFwPAs(chName)
  if self.VVYfjm(chName):
   FFbstz(VVmxnp, "This is a marker!", 300)
  else:
   FFmTns(VVmxnp, boundFunction(self.VVl3bw, VVmxnp, chUrl, playerFlag), title="Playing ...")
 def VVl3bw(self, VVmxnp, chUrl, playerFlag):
  FFulYh(self, chUrl, VVK8qL=False)
  self.session.open(CCrMvG, portalTableParam=(self, VVmxnp, playerFlag))
 @staticmethod
 def VVYfjm(chName):
  mark = ("--", "__", "==", "##", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVnZeR(self, VVmxnp, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self)
  if refCode:
   bName = FFyTPg()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFTmWm(refCode, origUrl, chName) }
   VVmxnp.VVtnU7_partial(colDict, VVJGrp=True)
 def VV7SbR(self, m3uMode):
  path = CCniMM.VVYViJ()
  lines = FFGCWo("find %s %s -iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'" % (path, FFBbZi(1)))
  if lines:
   lines.sort()
   VVhOvi = []
   for line in lines:
    VVhOvi.append((line, line))
   if m3uMode == self.VV1T4F:
    title = "Browse Server from M3U URLs"
    VVmwoc = ("All to Playlist", self.VVPFku)
   else:
    title = "M3U/M3U8 Channels Browser"
    VVmwoc = None
   OKBtnFnc = boundFunction(self.VVQutU, m3uMode, title)
   VVV70K  = ("Show Full Path", self.VVBtMC)
   VVyt0G = ("Delete File", self.VVkYZs)
   FFN6sa(self, None, title=title, VVhOvi=VVhOvi, width=1200, OKBtnFnc=OKBtnFnc, VVV70K=VVV70K, VVyt0G=VVyt0G, VVmwoc=VVmwoc)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n\n%s" % path
   FF2wyP(self, 'No ".m3u" files found %s' % txt)
 def VVBtMC(self, VVfiljObj, url):
  FFHVXB(self, url, title="Full Path")
 def VVQutU(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == self.VV1T4F:
    FFmTns(menuInstance, boundFunction(self.VVPJup, title, path))
   else:
    FFmTns(menuInstance, boundFunction(self.VVuPj5, path))
 def VVuPj5(self, srcPath):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFJPcA(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  processChanName = CCsfdL()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VVYSaF(propLine, "group-title") or "-"
   if not group == "-" and processChanName.VVSQZW(group):
    groups.add(group)
  VV2X4t = []
  if len(groups) > 0:
   title = "Groups"
   for group in groups:
    VV2X4t.append((group, group))
   VV2X4t.append(("ALL", ""))
   VV2X4t.sort(key=lambda x: x[0].lower())
   VVnQuA = self.VVJgM9
   VVPZiO  = ("Select" , boundFunction(self.VVjmWf, srcPath), [])
   widths   = (100  , 0)
   VVFSP3  = (LEFT  , LEFT)
   FFyzis(self, None, title=title, width= 800, header=None, VV2PlJ=VV2X4t, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=30, VVPZiO=VVPZiO, VVnQuA=VVnQuA
     , VVxH2w="#11110022", VV2Du9="#11110022", VVPEgn="#11110022", VVV3E9="#00444400")
  else:
   txt = FFJPcA(srcPath)
   self.VVsO39(txt, filterGroup="")
 def VVjmWf(self, srcPath, VVmxnp, title, txt, colList):
  group = colList[1]
  txt = FFJPcA(srcPath)
  self.VVsO39(txt, filterGroup=group)
 def VVsO39(self, txt, filterGroup=""):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = "Group : %s" % (filterGroup or "ALL")
  if lst:
   self.session.open(CCvjpm, barTheme=CCvjpm.VVdivo
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VV0w8t, lst, filterGroup)
       , VVPtly = boundFunction(self.VVxB68, title, bName))
  else:
   self.VVw6Y1("No valid lines found !", title)
 def VV0w8t(self, lst, filterGroup, progBarObj):
  progBarObj.VVQ53i = []
  progBarObj.VVJZYU(len(lst))
  processChanName = CCsfdL()
  num = 0
  for cols in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVVcps(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VVYSaF(propLine, "tvg-logo")
   group = self.VVYSaF(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if group and not processChanName.VVSQZW(group) : skip = True
    if chName and not processChanName.VVSQZW(chName): skip = True
    if not skip and progBarObj:
     num += 1
     progBarObj.VVQ53i.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if progBarObj:
   progBarObj.VVnn7O_forcedUpdate("Loading %d Channels" % len(progBarObj.VVQ53i))
 def VVxB68(self, title, bName, VVWfVW, VVQ53i, threadCounter, threadTotal, threadErr):
  if VVQ53i:
   VVnQuA = self.VVJgM9
   VVPZiO  = ("Select"    , boundFunction(self.VVHRj1, title) , [])
   VVyW3N = (""     , self.VV7woP         , [])
   VVPtGh = ("Download PIcons" , self.VVkeiz        , [])
   VVCfae = ("Options" , boundFunction(self.VVLgHV, 1, "m3Ch", "", bName)  , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVFSP3  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFyzis(self, None, title=title, header=header, VV2PlJ=VVQ53i, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=28, VVPZiO=VVPZiO, VVnQuA=VVnQuA, VVyW3N=VVyW3N, VVPtGh=VVPtGh, VVCfae=VVCfae, VVwf0p=True, searchCol=1
     , VVxH2w="#0a00192B", VV2Du9="#0a00192B", VVPEgn="#0a00192B", VVV3E9="#00000000")
  else:
   self.VVw6Y1("No valid lines found !", title)
 def VVkeiz(self, VVmxnp, title, txt, colList):
  self.VV0yfn(VVmxnp, "m3u/m3u8")
 def VVzp6e(self, mode, bName, VVmxnp, title, txt, colList):
  bNameFile = CCniMM.VVwv6Z_forBouquet(bName)
  num  = 0
  path = VVEkHL + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVEkHL + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   catID = "33"
   rowNum = 0
   isMulti = VVmxnp.VVbF0F
   for ndx, row in enumerate(VVmxnp.VVlcwp()):
    chName = row[1].strip()
    url  = row[3].strip()
    chUrl = self.VVzuD0(rowNum, url, chName)
    rowNum += 1
    if not isMulti or VVmxnp.VVxu9W(ndx):
     f.write("#SERVICE %s\n"  % chUrl)
     f.write("#DESCRIPTION %s\n" % chName)
     totChange += 1
  FFJeEN(os.path.basename(path))
  self.VVBMaW(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVzuD0(self, rowNum, url, chName):
  refCode = self.VVIX0m(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFeJBn(url), chName)
  return chUrl
 def VVIX0m(self, rowNum, url, chName):
  span = iSearch(r"\/(\d{2,})", url, IGNORECASE)
  if span : stID = span.group(1)
  else : stID = "444"
  catID = "333"
  chNum = str(rowNum + 1)
  refCode = self.VVfclL(catID, stID, chNum)
  return refCode
 def VVYSaF(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVHRj1(self, Title, VVmxnp, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFmTns(VVmxnp, boundFunction(self.VVcXps, Title, VVmxnp, colList), title="Checking Server ...")
  else:
   self.VVzldW(VVmxnp, url, chName)
 def VVcXps(self, title, VVmxnp, colList):
  if not CCXLzC.VVl7b5(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCOJpB.VViG3W(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVhOvi = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCniMM.VVbwIj(url, fPath)
     VVhOvi.append((resol, fullUrl))
    if VVhOvi:
     if len(VVhOvi) > 1:
      FFN6sa(self, boundFunction(self.VV2cxo, VVmxnp, chName), VVhOvi=VVhOvi, title="Resolution", VV1r6m=True, VVJH0e=True)
     else:
      self.VVzldW(VVmxnp, VVhOvi[0][1], chName)
    else:
     self.VVJGrpor("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVsO39(txt, filterGroup="")
      return
    self.VVzldW(VVmxnp, url, chName)
   else:
    self.VVw6Y1("Cannot process this channel !", title)
  else:
   self.VVw6Y1(err, title)
 def VV2cxo(self, VVmxnp, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVzldW(VVmxnp, resolUrl, chName)
 def VVzldW(self, VVmxnp, url, chName):
  FFmTns(VVmxnp, boundFunction(self.VV48tN, VVmxnp, url, chName), title="Playing ...")
 def VV48tN(self, VVmxnp, url, chName):
  chUrl = self.VVzuD0(VVmxnp.VVwa7w(), url, chName)
  FFulYh(self, chUrl, VVK8qL=False)
  self.session.open(CCrMvG, portalTableParam=(self, VVmxnp, "m3u/m3u8"))
 def VVWKk8(self, VVmxnp, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVzuD0(VVmxnp.VVwa7w(), url, chName)
  return chName, chUrl
 def VV7woP(self, VVmxnp, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFhDEp(self, fncMode=CCip5O.VVDr3L, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVw6Y1(self, err, title):
  FF2wyP(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVJgM9(self, VVmxnp):
  if self.m3uOrM3u8File:
   self.close()
  VVmxnp.cancel()
 def VVPFku(self, VVfiljObj, item=None):
  FFmTns(VVfiljObj, boundFunction(self.VVJjzP, VVfiljObj, item))
 def VVJjzP(self, VVfiljObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVfiljObj.VVhOvi):
    path = item[1]
    if fileExists(path):
     enc = CCy6sJ.VVKeHm(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = self.VVeF1Z(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCniMM.VVYViJ(orExportPath=True)
    pListF = "%sPlaylist_%s.txt" % (path, FFHXaa())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVfiljObj.VVhOvi)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFHVXB(self, txt, title=title)
   else:
    FF2wyP(self, "Could not obtain URLs from this file list !", title=title)
 def VV5l3N(self):
  path = CCniMM.VVYViJ()
  lines = FFGCWo('find %s %s -iname "*playlist*" | grep -i ".txt"' % (path, FFBbZi(1)))
  if lines:
   lines.sort()
   VVhOvi = []
   for line in lines:
    VVhOvi.append((line, line))
   OKBtnFnc  = self.VVvScm
   VVyt0G = ("Delete File", self.VVkYZs)
   FFN6sa(self, None, title="Select Playlist File", VVhOvi=VVhOvi, width=1200, OKBtnFnc=OKBtnFnc, VVyt0G=VVyt0G)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FF2wyP(self, 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt)
 def VVvScm(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFmTns(menuInstance, boundFunction(self.VVV4Wr, menuInstance, path), title="Processing File ...")
 def VVV4Wr(self, fileMenuInstance, path):
  enc = CCy6sJ.VVKeHm(path, self)
  if enc == -1:
   return
  VV2X4t = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0]
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFwI5c(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCniMM.VVCipU(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VV2X4t:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(filter(None, [item[5], item[0]]))
     num += 1
     VV2X4t.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VV2X4t:
   title = "Playlist File"
   VVPZiO  = ("Start"    , boundFunction(self.VVCh6A, title)  , [])
   VVeO38 = ("Home Menu"   , FFQ6xc         , [])
   VVPtGh = ("Download M3U File" , self.VVWJOv     , [])
   VVCfae = ("Edit File"   , boundFunction(self.VVJvXd, path) , [])
   VVMVHK = ("Check & Filter"  , boundFunction(self.VVIFKU, fileMenuInstance, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVFSP3  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFyzis(self, None, title=title, header=header, VV2PlJ=VV2X4t, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=26, VVPZiO=VVPZiO, VVeO38=VVeO38, VVMVHK=VVMVHK, VVPtGh=VVPtGh, VVCfae=VVCfae, VVxH2w="#11001116", VV2Du9="#11001116", VVPEgn="#11001116", VVV3E9="#00003635", VVPt5m="#0a333333", VVbcXu="#11331100", VVwf0p=True)
  else:
   FF2wyP(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVWJOv(self, VVmxnp, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFStgm(self, boundFunction(FFmTns, VVmxnp, boundFunction(self.VVVXmN, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVVXmN(self, title, url):
  path, err = FFBgNy(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FF2wyP(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFJPcA(path)
   if '{"user_info":{"auth":0}}' in txt:
    os.system(FFiu56("rm -f '%s'" % path))
    FF2wyP(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    os.system(FFiu56("rm -f '%s'" % path))
    FF2wyP(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCniMM.VVYViJ(orExportPath=True) + fName
    os.system(FFiu56("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FFnN3Y(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FF2wyP(self, "Could not download the M3U file!", title=errTitle)
 def VVCh6A(self, Title, VVmxnp, title, txt, colList):
  url = colList[6]
  FFmTns(VVmxnp, boundFunction(self.VVU9VF, Title, url), title="Checking Server ...")
 def VVJvXd(self, path, VVmxnp, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCtRew(self, path, VVPtly=boundFunction(self.VVqVCt, VVmxnp), curRowNum=rowNum)
  else    : FFUQ3Z(self, path)
 def VVqVCt(self, VVmxnp, fileChanged):
  if fileChanged:
   VVmxnp.cancel()
 def VV59qj(self, title):
  curChName = self.VVmxnp.VVYTBT(1)
  FFK2QC(self, boundFunction(self.VVwL9J, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVwL9J(self, title, name):
  if name:
   lameDbChans = CCz7Lj.VVdmHx(self, CCz7Lj.VVX37m, VVPg2W=False, VVEx5a=False)
   list = []
   if lameDbChans:
    processChanName = CCsfdL()
    name = processChanName.VVGCeA(name)
    ratio = "1"
    for item in lameDbChans:
     if name in item[0].lower():
      list.append((item[0], FFYd0o(item[2]), item[3], ratio))
   if list : self.VVBZT1(list, title)
   else : FF2wyP(self, "Not found:\n\n%s" % name, title=title)
 def VVtWNH(self, title):
  curChName = self.VVmxnp.VVYTBT(1)
  self.session.open(CCvjpm, barTheme=CCvjpm.VVdivo
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVh7J0
      , VVPtly = boundFunction(self.VVzHtF, title, curChName))
 def VVh7J0(self, progBarObj):
  curChName = self.VVmxnp.VVYTBT(1)
  lameDbChans = CCz7Lj.VVdmHx(self, CCz7Lj.VVMyDj, VVPg2W=False, VVEx5a=False)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVQ53i = []
  progBarObj.VVJZYU(len(lameDbChans))
  processChanName = CCsfdL()
  curCh = processChanName.VVGCeA(curChName)
  for refCode in lameDbChans:
   chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
   ratio = CCpHVD.VVdW6A(chName.lower(), curCh)
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVVcps(1, True)
   if progBarObj and ratio > 50:
    progBarObj.VVQ53i.append((chName, FFYd0o(sat), refCode.replace("_", ":"), str(ratio)))
 def VVzHtF(self, title, curChName, VVWfVW, VVQ53i, threadCounter, threadTotal, threadErr):
  if VVQ53i: self.VVBZT1(VVQ53i, title)
  elif VVWfVW: FF2wyP(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVBZT1(self, VV2X4t, title):
  curChName = self.VVmxnp.VVYTBT(1)
  curRefCode = self.VVmxnp.VVYTBT(4)
  curUrl  = self.VVmxnp.VVYTBT(5)
  VV2X4t = sorted(VV2X4t, key=lambda x: (100-int(x[3]), x[0].lower()))
  VVPZiO  = ("Share Sat/C/T Ref.", boundFunction(self.VVsOGb, title, curChName, curRefCode, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFyzis(self, None, title=title, header=header, VV2PlJ=VV2X4t, VVDrmL=widths, VVCZ7I=26, VVPZiO=VVPZiO, VVxH2w="#0a00112B", VV2Du9="#0a001126", VVPEgn="#0a001126", VVV3E9="#00000000")
 def VVsOGb(self, newtitle, curChName, curRefCode, curUrl, VVmxnp, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFStgm(self.VVmxnp, boundFunction(FFmTns, self.VVmxnp, boundFunction(self.VVmMX0, VVmxnp, data)), ques, title=newtitle, VVU3wZ=True)
 def VVmMX0(self, VVmxnp, data):
  VVmxnp.cancel()
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVsRF1():
    txt = FFJPcA(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFgjOJ()
    newRow = []
    for i in range(6):
     newRow.append(self.VVmxnp.VVYTBT(i))
    newRow[4] = newRefCode
    done = self.VVmxnp.VVC5ot(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFHmgI(boundFunction(FFnN3Y , self, resTxt, title=title))
  elif resErr: FFHmgI(boundFunction(FF2wyP , self, resErr, title=title))
 def VVIFKU(self, fileMenuInstance, path, VVmxnp, title, txt, colList):
  self.session.open(CCvjpm, barTheme=CCvjpm.VVdivo
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VVmpmK, VVmxnp)
      , VVPtly = boundFunction(self.VVs9DG, fileMenuInstance, path, VVmxnp))
 def VVmpmK(self, VVmxnp, progBarObj):
  progBarObj.VVJZYU(VVmxnp.VV1Jo3())
  progBarObj.VVQ53i = []
  for row in VVmxnp.VVlcwp():
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVVcps(1, True)
   qUrl = self.VVpO9p(self.VVc5IF, row[6])
   txt, err = self.VVZkWo(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VV0Pi7(item, "auth") == "0":
       progBarObj.VVQ53i.append(qUrl)
    except:
     pass
 def VVs9DG(self, fileMenuInstance, path, VVmxnp, VVWfVW, VVQ53i, threadCounter, threadTotal, threadErr):
  if VVWfVW:
   list = VVQ53i
   title = "Authorized Servers"
   if list:
    totChk = VVmxnp.VV1Jo3()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFHXaa()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VV5l3N()
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFFpMs(str(totAuth), VVplBl)
     txt += "%s\n\n%s"    %  (FFFpMs("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFHVXB(self, txt, title=title)
     VVmxnp.close()
     fileMenuInstance.close()
    else:
     FFnN3Y(self, "All URLs are authorized.", title=title)
   else:
    FF2wyP(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVZkWo(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   cont = res.headers.get("Content-Type")
   if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
    return "", "Unexpected server data type ( %s )" % cont
   res = res.read().decode("UTF-8")
   if res:
    if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server !"
    else           : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVCipU(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVawMx(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVpO9p(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVCipU(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVc5IF   : return "%s"            % url
  elif mode == self.VVU9tS   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVUvrx   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVJhvm  : return "%s&action=get_series_categories"     % url
  elif mode == self.VV9RwF  : return "%s&action=get_live_categories"     % url
  elif mode == self.VV4d1i : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVl7uU   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVHG63    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVGjad  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVOdpp : return "%s&action=get_live_streams"      % url
  elif mode == self.VVxgl2  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VV0Pi7(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FF0V0A(int(val))
    elif is_base64 : val = FFdMsE(val)
    elif isToHHMMSS : val = FFuGN6(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVPJup(self, title, path):
  if fileExists(path):
   enc = CCy6sJ.VVKeHm(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = self.VVeF1Z(line)
     if qUrl:
      break
   if qUrl : self.VVU9VF(title, qUrl)
   else : FF2wyP(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FF2wyP(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVZMBD_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVV5hJ()
  if qUrl or "chCode" in iptvRef:
   p = CCOJpB()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV45BY(iptvRef)
   if valid:
    self.VVZMBD(self, host, mac)
    return
   elif qUrl:
    FFmTns(self, boundFunction(self.VVU9VF, title, qUrl), title="Checking Server ...")
    return
  FF2wyP(self, "Error in current channel URL !", title=title)
 def VVV5hJ(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self)
  qUrl = self.VVeF1Z(decodedUrl)
  return qUrl, iptvRef
 def VVeF1Z(self, url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVU9VF(self, title, url):
  self.VVb4wgData = {}
  qUrl = self.VVpO9p(self.VVc5IF, url)
  txt, err = self.VVZkWo(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVb4wgData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVb4wgData["username"    ] = self.VV0Pi7(item, "username"        )
    self.VVb4wgData["password"    ] = self.VV0Pi7(item, "password"        )
    self.VVb4wgData["message"    ] = self.VV0Pi7(item, "message"        )
    self.VVb4wgData["auth"     ] = self.VV0Pi7(item, "auth"         )
    self.VVb4wgData["status"    ] = self.VV0Pi7(item, "status"        )
    self.VVb4wgData["exp_date"    ] = self.VV0Pi7(item, "exp_date"    , isDate=True )
    self.VVb4wgData["is_trial"    ] = self.VV0Pi7(item, "is_trial"        )
    self.VVb4wgData["active_cons"   ] = self.VV0Pi7(item, "active_cons"       )
    self.VVb4wgData["created_at"   ] = self.VV0Pi7(item, "created_at"   , isDate=True )
    self.VVb4wgData["max_connections"  ] = self.VV0Pi7(item, "max_connections"      )
    self.VVb4wgData["allowed_output_formats"] = self.VV0Pi7(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVb4wgData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVb4wgData["url"    ] = self.VV0Pi7(item, "url"        )
    self.VVb4wgData["port"    ] = self.VV0Pi7(item, "port"        )
    self.VVb4wgData["https_port"  ] = self.VV0Pi7(item, "https_port"      )
    self.VVb4wgData["server_protocol" ] = self.VV0Pi7(item, "server_protocol"     )
    self.VVb4wgData["rtmp_port"   ] = self.VV0Pi7(item, "rtmp_port"       )
    self.VVb4wgData["timezone"   ] = self.VV0Pi7(item, "timezone"       )
    self.VVb4wgData["timestamp_now"  ] = self.VV0Pi7(item, "timestamp_now"  , isDate=True )
    self.VVb4wgData["time_now"   ] = self.VV0Pi7(item, "time_now"       )
    VVhOvi  = self.VVeRU3(True)
    OKBtnFnc = self.VVb4wgOptions
    VVd2z3 = ("Home Menu", FFQ6xc)
    VVmwoc = ("Bookmark Server", boundFunction(CCniMM.VVzeec, self, False, self.VVb4wgData["playListURL"]))
    FFN6sa(self, None, title="IPTV Server Resources", VVhOvi=VVhOvi, OKBtnFnc=OKBtnFnc, VVd2z3=VVd2z3, VVmwoc=VVmwoc)
   else:
    err = "Could not get data from server !"
  if err:
   FF2wyP(self, err, title=title)
  FFbstz(self)
 def VVb4wgOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFmTns(menuInstance, boundFunction(self.VVzkUs, self.VVU9tS  , title=title), title=wTxt)
   elif ref == "vod"   : FFmTns(menuInstance, boundFunction(self.VVzkUs, self.VVUvrx  , title=title), title=wTxt)
   elif ref == "series"  : FFmTns(menuInstance, boundFunction(self.VVzkUs, self.VVJhvm , title=title), title=wTxt)
   elif ref == "catchup"  : FFmTns(menuInstance, boundFunction(self.VVzkUs, self.VV9RwF , title=title), title=wTxt)
   elif ref == "accountInfo" : FFmTns(menuInstance, boundFunction(self.VVCMoR           , title=title), title=wTxt)
 def VVCMoR(self, title):
  rows = []
  for key, val in self.VVb4wgData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VVeO38 = ("Home Menu", FFQ6xc, [])
  header   = ("Num", "User/Server" , "Subject" , "Value" )
  widths   = (0 , 15   , 35  , 50  )
  FFyzis(self, None, title=title, width=1200, header=header, VV2PlJ=rows, VVDrmL=widths, VVCZ7I=26, VVeO38=VVeO38, VVxH2w="#0a00292B", VV2Du9="#0a002126", VVPEgn="#0a002126", VVV3E9="#00000000", searchCol=2)
 def VVFSEN(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CCsfdL()
    if mode in (self.VVl7uU, self.VVxgl2):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VV0Pi7(item, "num"         )
      name     = self.VV0Pi7(item, "name"        )
      stream_id    = self.VV0Pi7(item, "stream_id"       )
      stream_icon    = self.VV0Pi7(item, "stream_icon"       )
      epg_channel_id   = self.VV0Pi7(item, "epg_channel_id"      )
      added     = self.VV0Pi7(item, "added"    , isDate=True )
      is_adult    = self.VV0Pi7(item, "is_adult"       )
      category_id    = self.VV0Pi7(item, "category_id"       )
      tv_archive    = self.VV0Pi7(item, "tv_archive"       )
      name = processChanName.VVSQZW(name)
      if name:
       if mode == self.VVl7uU or mode == self.VVxgl2 and tv_archive == "1":
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVHG63:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VV0Pi7(item, "num"         )
      name    = self.VV0Pi7(item, "name"        )
      stream_id   = self.VV0Pi7(item, "stream_id"       )
      stream_icon   = self.VV0Pi7(item, "stream_icon"       )
      added    = self.VV0Pi7(item, "added"    , isDate=True )
      is_adult   = self.VV0Pi7(item, "is_adult"       )
      category_id   = self.VV0Pi7(item, "category_id"       )
      container_extension = self.VV0Pi7(item, "container_extension"     ) or "mp4"
      name = processChanName.VVSQZW(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVGjad:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VV0Pi7(item, "num"        )
      name    = self.VV0Pi7(item, "name"       )
      series_id   = self.VV0Pi7(item, "series_id"      )
      cover    = self.VV0Pi7(item, "cover"       )
      genre    = self.VV0Pi7(item, "genre"       )
      episode_run_time = self.VV0Pi7(item, "episode_run_time"    )
      category_id   = self.VV0Pi7(item, "category_id"      )
      container_extension = self.VV0Pi7(item, "container_extension"    ) or "mp4"
      name = processChanName.VVSQZW(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVzkUs(self, mode, title):
  cList, err = self.VVplM4(mode)
  if cList and mode == self.VV9RwF:
   cList = self.VVWsQN(cList)
  if err:
   FF2wyP(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVxH2w, VV2Du9, VVPEgn, VVV3E9 = self.VVMUVc(mode)
   mName = self.VV0qvg(mode)
   if   mode == self.VVU9tS  : fMode = self.VVl7uU
   elif mode == self.VVUvrx  : fMode = self.VVHG63
   elif mode == self.VVJhvm : fMode = self.VVGjad
   elif mode == self.VV9RwF : fMode = self.VVxgl2
   if mode == self.VV9RwF:
    VVCfae = None
   else:
    VVCfae = ("Find in %s" % mName , boundFunction(self.VVGScB, fMode) , [])
   VVPZiO   = ("Show List"   , boundFunction(self.VVYNuh, mode) , [])
   VVeO38  = ("Home Menu"   , FFQ6xc          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFyzis(self, None, title=title, width=1200, header=header, VV2PlJ=cList, VVDrmL=widths, VVCZ7I=30, VVeO38=VVeO38, VVCfae=VVCfae, VVPZiO=VVPZiO, VVxH2w=VVxH2w, VV2Du9=VV2Du9, VVPEgn=VVPEgn, VVV3E9=VVV3E9)
  else:
   FF2wyP(self, "No list from server !", title=title)
  FFbstz(self)
 def VVplM4(self, mode):
  qUrl  = self.VVpO9p(mode, self.VVb4wgData["playListURL"])
  txt, err = self.VVZkWo(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    processChanName = CCsfdL()
    for item in tDict:
     category_id  = self.VV0Pi7(item, "category_id"  )
     category_name = self.VV0Pi7(item, "category_name" )
     parent_id  = self.VV0Pi7(item, "parent_id"  )
     category_name = processChanName.VVgYc1(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVWsQN(self, catList):
  mode  = self.VVxgl2
  qUrl  = self.VVpO9p(mode, self.VVb4wgData["playListURL"])
  txt, err = self.VVZkWo(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVFSEN(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVYNuh(self, mode, VVmxnp, title, txt, colList):
  title = colList[1]
  FFmTns(VVmxnp, boundFunction(self.VV1rvl, mode, VVmxnp, title, txt, colList), title="Downloading ...")
 def VV1rvl(self, mode, VVmxnp, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VV0qvg(mode) + " : "+ bName
  if   mode == self.VVU9tS  : mode = self.VVl7uU
  elif mode == self.VVUvrx  : mode = self.VVHG63
  elif mode == self.VVJhvm : mode = self.VVGjad
  elif mode == self.VV9RwF : mode = self.VVxgl2
  qUrl  = self.VVpO9p(mode, self.VVb4wgData["playListURL"], catID)
  txt, err = self.VVZkWo(qUrl)
  list  = []
  if not err and mode in (self.VVl7uU, self.VVHG63, self.VVGjad, self.VVxgl2):
   list, err = self.VVFSEN(mode, txt)
  if err:
   FF2wyP(self, err, title=title)
  elif list:
   VVeO38  = ("Home Menu"   , FFQ6xc             , [])
   if mode in (self.VVl7uU, self.VVxgl2):
    VVxH2w, VV2Du9, VVPEgn, VVV3E9 = self.VVMUVc(mode)
    VVyW3N = (""     , boundFunction(self.VVBlMD, mode)     , [])
    VVPtGh = ("Download Options" , boundFunction(self.VVmNQH, mode, "", "")  , [])
    VVCfae = ("Options" , boundFunction(self.VVLgHV, 1, "lv", mode, bName)  , [])
    if mode == self.VVl7uU:
     VVPZiO = ("Play"    , boundFunction(self.VVW5b0, mode)     , [])
    elif mode == self.VVxgl2:
     VVPZiO  = ("Programs", boundFunction(self.VVyLbk_fromIptvTable, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVFSP3  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVHG63:
    VVxH2w, VV2Du9, VVPEgn, VVV3E9 = self.VVMUVc(mode)
    VVPZiO  = ("Play"    , boundFunction(self.VVW5b0, mode)    , [])
    VVyW3N = (""     , boundFunction(self.VVBlMD, mode)    , [])
    VVPtGh = ("Download Options" , boundFunction(self.VVmNQH, mode, "v", ""), [])
    VVCfae = ("Options" , boundFunction(self.VVLgHV, 1, "v", mode, bName)  , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVFSP3  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVGjad:
    VVxH2w, VV2Du9, VVPEgn, VVV3E9 = self.VVMUVc("series2")
    VVPZiO  = ("Show Seasons", boundFunction(self.VVAZ2F, mode) , [])
    VVyW3N = ("", boundFunction(self.VVBb2E, mode)  , [])
    VVPtGh = None
    VVCfae = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVFSP3  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFyzis(self, None, title=title, header=header, VV2PlJ=list, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=26, VVPZiO=VVPZiO, VVeO38=VVeO38, VVPtGh=VVPtGh, VVCfae=VVCfae, VVyW3N=VVyW3N, VVxH2w=VVxH2w, VV2Du9=VV2Du9, VVPEgn=VVPEgn, VVV3E9=VVV3E9, VVwf0p=True, searchCol=1)
  else:
   FF2wyP(self, "No Channels found !", title=title)
  FFbstz(self)
 def VVyLbk_fromIptvTable(self, mode, bName, VVmxnp, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVb4wgData["playListURL"]
  ok_fnc  = boundFunction(self.VVoIe1, hostUrl, chName, catId, streamId)
  FFmTns(VVmxnp, boundFunction(CCniMM.VVyLbk, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVoIe1(self, chUrl, chName, catId, streamId, VVmxnp, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCniMM.VVCipU(chUrl)
   chNum = "333"
   refCode = CCniMM.VVfclL(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFulYh(self, chUrl, VVK8qL=False)
   self.session.open(CCrMvG)
  else:
   FF2wyP(self, "Incorrect Timestamp", pTitle)
 def VVAZ2F(self, mode, VVmxnp, title, txt, colList):
  title = colList[1]
  FFmTns(VVmxnp, boundFunction(self.VV8RsF, mode, VVmxnp, title, txt, colList), title="Downloading ...")
 def VV8RsF(self, mode, VVmxnp, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVpO9p(self.VV4d1i, self.VVb4wgData["playListURL"], series_id)
  txt, err = self.VVZkWo(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VV0Pi7(tDict["info"], "name"   )
      category_id = self.VV0Pi7(tDict["info"], "category_id" )
      icon  = self.VV0Pi7(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VV0Pi7(EP, "id"     )
        episode_num   = self.VV0Pi7(EP, "episode_num"   )
        epTitle    = self.VV0Pi7(EP, "title"     )
        container_extension = self.VV0Pi7(EP, "container_extension" )
        seasonNum   = self.VV0Pi7(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FF2wyP(self, err, title=title)
  elif list:
   VVeO38 = ("Home Menu"   , FFQ6xc             , [])
   VVPtGh = ("Download Options" , boundFunction(self.VVmNQH, mode, "s", title) , [])
   VVCfae = ("Options" , boundFunction(self.VVLgHV, 0, "s", mode, title)  , [])
   VVyW3N = (""     , boundFunction(self.VVBlMD, mode)     , [])
   VVPZiO  = ("Play"    , boundFunction(self.VVW5b0, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVFSP3  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFyzis(self, None, title=title, header=header, VV2PlJ=list, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=26, VVeO38=VVeO38, VVPtGh=VVPtGh, VVPZiO=VVPZiO, VVyW3N=VVyW3N, VVCfae=VVCfae, VVxH2w="#0a00292B", VV2Du9="#0a002126", VVPEgn="#0a002126", VVV3E9="#00000000")
  else:
   FF2wyP(self, "No Channels found !", title=title)
  FFbstz(self)
 def VVGScB(self, mode, VVmxnp, title, txt, colList):
  VVhOvi = []
  VVhOvi.append(("Keyboard"  , "manualEntry"))
  VVhOvi.append(("From Filter" , "fromFilter"))
  FFN6sa(self, boundFunction(self.VV4eWo, VVmxnp, mode), title="Input Type", VVhOvi=VVhOvi, width=400)
 def VV4eWo(self, VVmxnp, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFK2QC(self, boundFunction(self.VVdN7c, VVmxnp, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCROIp(self)
    filterObj.VVxr86(boundFunction(self.VVdN7c, VVmxnp, mode))
 def VVdN7c(self, VVmxnp, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CCsfdL()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVYMjr(words):
     FF2wyP(self, processChanName.VVp8GM(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CCvjpm, barTheme=CCvjpm.VVdivo
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VVjR5d, VVmxnp, mode, title, words, toFind, asPrefix, processChanName)
         , VVPtly = boundFunction(self.VVjACt, mode, toFind, title))
   else:
    FF2wyP(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VVjR5d(self, VVmxnp, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVJZYU(VVmxnp.VV0fQZ())
  progBarObj.VVQ53i = []
  for row in VVmxnp.VVlcwp():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVVcps(1)
   progBarObj.VVnn7O_fromIptvFind(catName)
   qUrl  = self.VVpO9p(mode, self.VVb4wgData["playListURL"], catID)
   txt, err = self.VVZkWo(qUrl)
   if not err:
    tList, err = self.VVFSEN(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VVSQZW(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VVl7uU:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VVQ53i.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVHG63:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VVQ53i.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVGjad:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VVQ53i.append((num, name, catID, ID, genre, catName, ext, cover))
 def VVjACt(self, mode, toFind, title, VVWfVW, VVQ53i, threadCounter, threadTotal, threadErr):
  if VVQ53i:
   title = self.VV5q8K(mode, toFind)
   if mode == self.VVl7uU or mode == self.VVHG63:
    if mode == self.VVHG63 : typ = "v"
    else          : typ = ""
    bName   = CCniMM.VVwv6Z_forBouquet(toFind)
    VVPZiO  = ("Play"     , boundFunction(self.VVW5b0, mode)    , [])
    VVPtGh = ("Download Options" , boundFunction(self.VVmNQH, mode, typ, ""), [])
    VVCfae = ("Options" , boundFunction(self.VVLgHV, 1, "fnd", mode, bName)  , [])
   elif mode == self.VVGjad:
    VVPZiO  = ("Show Seasons"  , boundFunction(self.VVAZ2F, mode)    , [])
    VVCfae = None
    VVPtGh = None
   VVyW3N  = (""     , boundFunction(self.VVBlMD, mode)    , [])
   VVeO38  = ("Home Menu"   , FFQ6xc            , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVFSP3  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVmxnp = FFyzis(self, None, title=title, header=header, VV2PlJ=VVQ53i, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=26, VVPZiO=VVPZiO, VVeO38=VVeO38, VVPtGh=VVPtGh, VVCfae=VVCfae, VVyW3N=VVyW3N, VVxH2w="#0a00292B", VV2Du9="#0a002126", VVPEgn="#0a002126", VVV3E9="#00000000", VVwf0p=True, searchCol=1)
   if not VVWfVW:
    FFbstz(VVmxnp, "Stopped" , 1000)
  else:
   if VVWfVW:
    FF2wyP(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVu0xi(self, mode, colList):
  if mode in (self.VVl7uU, self.VVxgl2):
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVHG63:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFwPAs(chName)
  url = self.VVb4wgData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVCipU(url)
  refCode = self.VVfclL(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVBlMD(self, mode, VVmxnp, title, txt, colList):
  FFmTns(VVmxnp, boundFunction(self.VVHIBn, mode, VVmxnp, title, txt, colList))
 def VVHIBn(self, mode, VVmxnp, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVu0xi(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFhDEp(self, fncMode=CCip5O.VV3RIX, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVBb2E(self, mode, VVmxnp, title, txt, colList):
  FFmTns(VVmxnp, boundFunction(self.VVvvkW, mode, VVmxnp, title, txt, colList))
 def VVvvkW(self, mode, VVmxnp, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFhDEp(self, fncMode=CCip5O.VV0lxd, chName=name, text=txt, picUrl=Cover)
 def VVcrO3(self, mode, bName, VVmxnp, title, txt, colList):
  url = self.VVb4wgData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVCipU(url)
  bNameFile = CCniMM.VVwv6Z_forBouquet(bName)
  num  = 0
  path = VVEkHL + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVEkHL + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   isMulti = VVmxnp.VVbF0F
   for ndx, row in enumerate(VVmxnp.VVlcwp()):
    chName, chUrl, picUrl, refCode = self.VVu0xi(mode, row)
    if not isMulti or VVmxnp.VVxu9W(ndx):
     f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
     f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
     totChange += 1
  FFJeEN(os.path.basename(path))
  self.VVBMaW(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVmNQH(self, mode, typ, seriesName, VVmxnp, title, txt, colList):
  VVhOvi = []
  isMulti = VVmxnp.VVbF0F
  tot  = VVmxnp.VVXLPA()
  if isMulti:
   if tot < 1:
    FFbstz(VVmxnp, "Select rows first.", 1000)
    return
   else:
    s = "s" if tot > 1 else ""
    name = "%d Selected" % tot
  else:
   s = "s"
   name = "ALL"
  VVhOvi.append(("Download %s PIcon%s" % (name, s), "dnldPicons" ))
  if typ:
   VVhOvi.append(VVaOJ8)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVhOvi.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVhOvi.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVhOvi.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCnmQ8.VVjZWd():
    VVhOvi.append(VVaOJ8)
    VVhOvi.append(("Download Manager"      , "dload_stat" ))
  FFN6sa(self, boundFunction(self.VVBFoS_VVcRCM, VVmxnp, mode, typ, seriesName, colList), title="Download Options", VVhOvi=VVhOvi)
 def VVBFoS_VVcRCM(self, VVmxnp, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VV0yfn(VVmxnp, mode)
   elif item == "dnldSel"  : self.VVdEN6(VVmxnp, mode, typ, colList, True)
   elif item == "addSel"  : self.VVdEN6(VVmxnp, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVf2W9(VVmxnp, mode, typ, seriesName)
   elif item == "dload_stat" : CCnmQ8.VVW2Oa(self)
 def VVdEN6(self, VVmxnp, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVEqBU(mode, typ, colList)
  if startDnld:
   CCnmQ8.VVwVDv_url(self, decodedUrl)
  else:
   self.VVcRCM_FFStgm(VVmxnp, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVf2W9(self, VVmxnp, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVmxnp.VVlcwp():
   chName, decodedUrl = self.VVEqBU(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVcRCM_FFStgm(VVmxnp, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVcRCM_FFStgm(self, VVmxnp, title, chName, decodedUrl_list, startDnld):
  FFStgm(self, boundFunction(self.VV6v8X, VVmxnp, decodedUrl_list, startDnld), chName, title=title)
 def VV6v8X(self, VVmxnp, decodedUrl_list, startDnld):
  added, skipped = CCnmQ8.VVWaY9List(decodedUrl_list)
  FFbstz(VVmxnp, "Added", 1000)
 def VVEqBU(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVu0xi(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVCLGa(mode, colList)
   refCode, chUrl = self.VVkUmT(self.VVHTHm, self.VVNF0S, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFONbJ(chUrl)
  return chName, decodedUrl
 def VV0yfn(self, VVmxnp, mode):
  if os.system(FFiu56("which ffmpeg")) == 0:
   self.session.open(CCvjpm, barTheme=CCvjpm.VVjDUm
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VVHjpD, VVmxnp, mode)
       , VVPtly = self.VViOJ7)
  else:
   FFStgm(self, boundFunction(CCniMM.VVlvJk, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VViOJ7(self, VVWfVW, VVQ53i, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVQ53i["proces"], VVQ53i["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVQ53i["ok"], VVQ53i["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVQ53i["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVQ53i["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVQ53i["badURL"]
  txt += "Download Failure\t: %d\n"   % VVQ53i["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVQ53i["path"]
  if not VVWfVW  : color = "#11402000"
  elif VVQ53i["err"]: color = "#11201000"
  else     : color = None
  if VVQ53i["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVQ53i["err"], txt)
  title = "PIcons Download Result"
  if not VVWfVW:
   title += "  (cancelled)"
  FFHVXB(self, txt, title=title, VVPEgn=color)
 def VVHjpD(self, VVmxnp, mode, progBarObj):
  isMulti = VVmxnp.VVbF0F
  if isMulti : totRows = VVmxnp.VVXLPA()
  else  : totRows = VVmxnp.VV0fQZ()
  progBarObj.VVJZYU(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CCpHVD.VVRh8o()
  progBarObj.VVQ53i = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for rowNum, row in enumerate(VVmxnp.VVlcwp()):
    if progBarObj.isCancelled:
     break
    if not isMulti or VVmxnp.VVxu9W(rowNum):
     progBarObj.VVQ53i["proces"] += 1
     progBarObj.VVVcps(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVCLGa(mode, row)
      refCode = CCniMM.VVfclL(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVIX0m(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVu0xi(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       progBarObj.VVQ53i["attempt"] += 1
       path, err = FFBgNy(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        progBarObj.VVQ53i["ok"] += 1
        if FFEZNr(path) > 0:
         cmd = ""
         if not mode == CCniMM.VVl7uU:
          cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
         cmd += FFiu56("mv -f '%s' '%s'" % (path, pPath)) + ";"
         os.system(cmd)
        else:
         progBarObj.VVQ53i["size0"] += 1
         os.system(FFiu56("rm -f '%s'" % path))
       elif err:
        progBarObj.VVQ53i["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         progBarObj.VVQ53i["err"] = err.title()
         break
      else:
       progBarObj.VVQ53i["exist"] += 1
     else:
      progBarObj.VVQ53i["badURL"] += 1
  except:
   pass
 @staticmethod
 def VVlvJk(SELF):
  cmd = FF5ENR(VVIqrC, "ffmpeg")
  if cmd : FFHbvq(SELF, cmd, title="Installing FFmpeg")
  else : FFAopx(SELF)
 def VVpvlE(self):
  self.session.open(CCvjpm, barTheme=CCvjpm.VVjDUm
      , titlePrefix = ""
      , fncToRun  = self.VVRV4j
      , VVPtly = self.VVuiAG)
 def VVRV4j(self, progBarObj):
  bName = FFyTPg()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  progBarObj.VVQ53i = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = FFthWl()
  if not progBarObj or progBarObj.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   progBarObj.VVJZYU(totCh)
   for serv in services:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVVcps(1)
    progBarObj.VVnn7O_fromImportEPG(totEpgOK, uChName)
    fullRef  = serv[0]
    if FFupNy(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFONbJ(fullRef)
     span = iSearch(r"(mode=.+end=)", fullRef, IGNORECASE)
     if span:
      m3u_Url = CCOJpB.VV1L14(fullRef)
      uType, uHost, uUser, uPass, uId, uChName  = CCniMM.VVawMx(fullRef)
      uType, uHost, uUser, uPass, uId, uChName1 = CCniMM.VVawMx(m3u_Url)
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCniMM.VVawMx(m3u_Url)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCniMM.VVFZHp(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCip5O.VVqHHn(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
      else:
       pass
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if progBarObj:
     progBarObj.VVQ53i = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   progBarObj.VVQ53i = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VVuiAG(self, VVWfVW, VVQ53i, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVQ53i
  title = "IPTV EPG Import"
  if err:
   FF2wyP(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFFpMs(str(totNotIptv), VVi1SQ)
    if totServErr : txt += "Server Errors\t: %s\n" % FFFpMs(str(totServErr) + t1, VVi1SQ)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFFpMs(str(totInv), VVi1SQ)
   if not VVWfVW:
    title += "  (stopped)"
   FFHVXB(self, txt, title=title)
 @staticmethod
 def VVFZHp(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCniMM.VVCipU(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCniMM.VVZkWo(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCniMM.VV0Pi7(item, "description" , is_base64=True ).replace("\n", " .. ")
    has_archive   = CCniMM.VV0Pi7(item, "has_archive"      )
    lang    = CCniMM.VV0Pi7(item, "lang"        ).upper()
    now_playing   = CCniMM.VV0Pi7(item, "now_playing"      )
    start    = CCniMM.VV0Pi7(item, "start"        )
    start_timestamp  = CCniMM.VV0Pi7(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCniMM.VV0Pi7(item, "start_timestamp"     )
    stop_timestamp  = CCniMM.VV0Pi7(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCniMM.VV0Pi7(item, "stop_timestamp"      )
    tTitle    = CCniMM.VV0Pi7(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVfclL(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCniMM.VVbhg6(catID, MAX_4b)
  TSID = CCniMM.VVbhg6(chNum, MAX_4b)
  ONID = CCniMM.VVbhg6(chNum, MAX_4b)
  NS  = CCniMM.VVbhg6(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVbhg6(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVwv6Z_forBouquet(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVMUVc(mode):
  if   mode in ("itv"  , CCniMM.VVU9tS)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCniMM.VVUvrx)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCniMM.VVJhvm) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCniMM.VV9RwF) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCniMM.VVxgl2    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 @staticmethod
 def VVYViJ(orExportPath=False):
  path = CFG.iptvHostsPath.getValue()
  if not pathExists(path) or path == VVTlxf:
   if orExportPath : path = CFG.exportedTablesPath.getValue()
   else   : path ="/"
  return FFwI5c(path)
 @staticmethod
 def VVyLbk(SELF, hostUrl, chName, streamId, ok_fnc):
  title = "Catchup TV Programs"
  pList, err = CCniMM.VVFZHp(hostUrl, streamId, True)
  if err:
   FF2wyP(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVxH2w, VV2Du9, VVPEgn, VVV3E9 = CCniMM.VVMUVc("")
   VVeO38 = ("Home Menu" , FFQ6xc, [])
   VVPZiO  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVFSP3  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFyzis(SELF, None, title="Programs for : " + chName, header=header, VV2PlJ=pList, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=24, VVPZiO=VVPZiO, VVeO38=VVeO38, VVxH2w=VVxH2w, VV2Du9=VV2Du9, VVPEgn=VVPEgn, VVV3E9=VVV3E9)
  else:
   FF2wyP(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVbwIj(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 @staticmethod
 def VVzeec(SELF, isPortal, line, VVfiljObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCniMM.VVYViJ(orExportPath=True)
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FF2wyP(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFnN3Y(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FF2wyP(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVLgHV(self, nameCol, source, mode, bName, VVmxnp, title, txt, colList):
  isMulti = VVmxnp.VVbF0F
  mSel = CClfxx(self, VVmxnp, nameCol, addSep=False)
  title = ""
  if isMulti:
   tot = VVmxnp.VVXLPA()
   if tot > 0:
    s = "s" if tot > 1 else ""
    title = "Add %d Service%s to Bouquet" % (tot, s)
  else:
   title = "Add ALL to Bouquet"
  if title:
   mSel.VVhOvi.append(VVaOJ8)
   mSel.VVhOvi.append((title        , "addToBoquet"))
  FFN6sa(self, boundFunction(self.VVhwH6, mSel, source, mode, bName, VVmxnp, title, txt, colList), title="Options", VVhOvi=mSel.VVhOvi)
 def VVhwH6(self, mSelObj, source, mode, bName, VVmxnp, title, txt, colList, item):
  if item:
   if   item == "multSelEnab"     : mSelObj.VVmxnp.VVk734(True)
   elif item == "MultSelDisab"     : mSelObj.VVmxnp.VVk734(False)
   elif item == "selectAll"     : mSelObj.VVmxnp.VVktds()
   elif item == "unselectAll"     : mSelObj.VVmxnp.VV27HN()
   elif item == "addToBoquet"     :
    if   source == "pEp" : fnc = self.VVVjFQ
    elif source == "pCh" : fnc = self.VVVjFQ
    elif source == "m3Ch" : fnc = self.VVzp6e
    elif source == "lv"  : fnc = self.VVcrO3
    elif source == "v"  : fnc = self.VVcrO3
    elif source == "s"  : fnc = self.VVcrO3
    elif source == "fnd" : fnc = self.VVcrO3
    else     : return
    FFmTns(VVmxnp, boundFunction(fnc, mode, bName, VVmxnp, title, txt, colList), title="Adding Channels ...")
class CC32MW(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FF82u7(VVyaPF, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVm36u  = 0
  self.VVuRKZ = 1
  self.VVMJS7  = 2
  VVhOvi = []
  VVhOvi.append(("Find in All Service (from filter)" , "VVQvN4" ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Find in All (Manual Entry)"   , "VVWW2O"    ))
  VVhOvi.append(("Find in TV"       , "VVhWeu"    ))
  VVhOvi.append(("Find in Radio"      , "VVYxDH"   ))
  if self.VVc3ZL():
   VVhOvi.append(VVaOJ8)
   VVhOvi.append(("Hide Channel: %s" % self.servName , "VVEQej"   ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Zap History"       , "VVFa65"    ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("IPTV Tools"       , "iptv"      ))
  VVhOvi.append(("PIcons Tools"       , "PIconsTools"     ))
  VVhOvi.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FFFsOT(self, VVhOvi=VVhOvi, title=title)
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FFEktE(self["myMenu"])
  FFwhmb(self)
  if self.isFindMode:
   self.VVQe3j(self.VVdLJk())
 def VVIpBc(self):
  global VVnwy6
  VVnwy6 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVWW2O"    : self.VVWW2O()
   elif item == "VVQvN4" : self.VVQvN4()
   elif item == "VVhWeu"    : self.VVhWeu()
   elif item == "VVYxDH"   : self.VVYxDH()
   elif item == "VVEQej"   : self.VVEQej()
   elif item == "VVFa65"    : self.VVFa65()
   elif item == "iptv"       : self.session.open(CCniMM)
   elif item == "PIconsTools"     : self.session.open(CCpHVD)
   elif item == "ChannelsTools"    : self.session.open(CCz7Lj)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVhWeu(self) : self.VVQe3j(self.VVm36u)
 def VVYxDH(self) : self.VVQe3j(self.VVuRKZ)
 def VVWW2O(self) : self.VVQe3j(self.VVMJS7)
 def VVQe3j(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFK2QC(self, boundFunction(self.VVrCnP, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVQvN4(self):
  filterObj = CCROIp(self)
  filterObj.VVxr86(self.VVSnsw)
 def VVSnsw(self, item):
  self.VVrCnP(self.VVMJS7, item)
 def VVc3ZL(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFupNy(self.refCode)        : return False
  return True
 def VVrCnP(self, mode, VVL6ub):
  FFmTns(self, boundFunction(self.VVgiAH, mode, VVL6ub), title="Searching ...")
 def VVgiAH(self, mode, VVL6ub):
  if VVL6ub:
   self.findTxt = VVL6ub
   if   mode == self.VVm36u  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVuRKZ : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVL6ub)
   if len(title) > 55:
    title = title[:55] + ".."
   VV2X4t = self.VVnIHd(VVL6ub, servTypes)
   if self.isFindMode or mode == self.VVMJS7:
    VV2X4t += self.VVApro(VVL6ub)
   if VV2X4t:
    VV2X4t.sort(key=lambda x: x[0].lower())
    VVnQuA = self.VVOBxd
    VVPZiO  = ("Zap"   , self.VVQLml    , [])
    VVPtGh = ("Current Service", self.VVq4zX , [])
    VVCfae = ("Options"  , self.VV9JJq , [])
    VVyW3N = (""    , self.VVvCQJ , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVFSP3  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFyzis(self, None, title=title, header=header, VV2PlJ=VV2X4t, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=26, VVPZiO=VVPZiO, VVnQuA=VVnQuA, VVPtGh=VVPtGh, VVCfae=VVCfae, VVyW3N=VVyW3N)
   else:
    self.VVQe3j(self.VVdLJk())
    FFnN3Y(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVnIHd(self, VVL6ub, servTypes):
  VV4lW6  = eServiceCenter.getInstance()
  VVuoi5   = '%s ORDER BY name' % servTypes
  VVuopo   = eServiceReference(VVuoi5)
  VVE1Za = VV4lW6.list(VVuopo)
  if VVE1Za: VV2PlJ = VVE1Za.getContent("CN", False)
  else     : VV2PlJ = None
  VV2X4t = []
  if VV2PlJ:
   VV6QHu, VV1wel = FFqZca()
   tp   = CCPwtQ()
   words, asPrefix = CCROIp.VVputs(VVL6ub)
   colorYellow  = CCP10Q.VVETo6(VVqWH2)
   colorWhite  = CCP10Q.VVETo6(VVLtc8)
   for s in VV2PlJ:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFYPEg(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VV6QHu:
        STYPE = VV1wel[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVd3OU(refCode)
       if not "-S" in syst:
        sat = syst
       VV2X4t.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VV2X4t
 def VVApro(self, VVL6ub):
  VVL6ub = VVL6ub.lower()
  VV12RE = FFRVXA()
  VV2X4t = []
  colorYellow  = CCP10Q.VVETo6(VVqWH2)
  colorWhite  = CCP10Q.VVETo6(VVLtc8)
  if VV12RE:
   for b in VV12RE:
    VVzAka  = b[0]
    VVJhOl  = b[1].toString()
    VVbzRG = eServiceReference(VVJhOl)
    VVJptv = FF0wye(VVbzRG)
    for service in VVJptv:
     refCode  = service[0]
     if FFupNy(refCode):
      servName = service[1]
      if VVL6ub in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VVL6ub), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VV2X4t.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VV2X4t
 def VVdLJk(self):
  VVhiUf = InfoBar.instance
  if VVhiUf:
   VVdb8z = VVhiUf.servicelist
   if VVdb8z:
    return VVdb8z.mode == 1
  return self.VVMJS7
 def VVOBxd(self, VVmxnp):
  self.close()
  VVmxnp.cancel()
 def VVQLml(self, VVmxnp, title, txt, colList):
  FFulYh(VVmxnp, colList[2], VVK8qL=False, checkParentalControl=True)
 def VVq4zX(self, VVmxnp, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(VVmxnp)
  if refCode:
   VVmxnp.VV1v28(2, FFTmWm(refCode, iptvRef, chName), True)
 def VV9JJq(self, VVmxnp, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CClfxx(self, VVmxnp, 2)
  mSel.VVCjGG(servName, refCode)
 def VVvCQJ(self, VVmxnp, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFhDEp(self, fncMode=CCip5O.VViRae, refCode=refCode, chName=chName, text=txt)
 def VVEQej(self):
  FFStgm(self, self.VV6a1y, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VV6a1y(self):
  ret = FFHJrf(self.refCode, True)
  if ret:
   self.VVMoEB()
   self.close()
  else:
   FFbstz(self, "Cannot change state" , 1000)
 def VVMoEB(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVMSUi()
  except:
   self.VVNrB1()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFCH4i(self, serviceRef)
 def VVnnhd(self):
  VVhiUf = InfoBar.instance
  if VVhiUf:
   VVdb8z = VVhiUf.servicelist
   if VVdb8z:
    VVdb8z.setMode()
 def VVMSUi(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVhiUf = InfoBar.instance
   if VVhiUf:
    VVdb8z = VVhiUf.servicelist
    if VVdb8z:
     hList = VVdb8z.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVdb8z.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVdb8z.history  = newList
       VVdb8z.history_pos = pos
 def VVNrB1(self):
  VVhiUf = InfoBar.instance
  if VVhiUf:
   VVdb8z = VVhiUf.servicelist
   if VVdb8z:
    VVdb8z.history  = []
    VVdb8z.history_pos = 0
 def VVFa65(self):
  VVhiUf = InfoBar.instance
  VV2X4t = []
  if VVhiUf:
   VVdb8z = VVhiUf.servicelist
   if VVdb8z:
    VV6QHu, VV1wel = FFqZca()
    for chParams in VVdb8z.history:
     refCode = chParams[-1].toString()
     chName = FFEChB(refCode)
     isIptv = FFupNy(refCode)
     if isIptv: sat = "-"
     else  : sat = FFYPEg(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VV6QHu:
       STYPE = VV1wel[sTypeInt]
     VV2X4t.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VV2X4t:
   VVPZiO  = ("Zap"   , self.VVzXSe   , [])
   VVCfae = ("Clear History" , self.VVBpa7   , [])
   VVyW3N = (""    , self.VVEa5KFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVFSP3  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFyzis(self, None, title=title, header=header, VV2PlJ=VV2X4t, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=28, VVPZiO=VVPZiO, VVCfae=VVCfae, VVyW3N=VVyW3N)
  else:
   FFnN3Y(self, "Not found", title=title)
 def VVzXSe(self, VVmxnp, title, txt, colList):
  FFulYh(VVmxnp, colList[3], VVK8qL=False, checkParentalControl=True)
 def VVBpa7(self, VVmxnp, title, txt, colList):
  FFStgm(self, boundFunction(self.VVs7Hf, VVmxnp), "Clear Zap History ?")
 def VVs7Hf(self, VVmxnp):
  self.VVNrB1()
  VVmxnp.cancel()
 def VVEa5KFromZapHistory(self, VVmxnp, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFhDEp(self, fncMode=CCip5O.VV5xcI, refCode=refCode, chName=chName, text=txt)
class CCpHVD(Screen):
 VVmPSh   = 0
 VVC8FK  = 1
 VV3B0P  = 2
 VVtaeM  = 3
 VVVshU  = 4
 VVtBTw  = 5
 VVrEUQ  = 6
 VVqcz7  = 7
 VVfY7n = 8
 VVt0w0 = 9
 def __init__(self, session):
  self.skin, self.skinParam = FF82u7(VVUJoS, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFFsOT(self, self.Title)
  FFydgK(self["keyRed"] , "OK = Zap")
  FFydgK(self["keyGreen"] , "Current Service")
  FFydgK(self["keyYellow"], "Page Options")
  FFydgK(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCpHVD.VVRh8o()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VV2PlJ    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVoBDk        ,
   "green"   : self.VVpKek       ,
   "yellow"  : self.VVN5Sy        ,
   "blue"   : self.VVlUP1        ,
   "menu"   : self.VV3t0p        ,
   "info"   : self.VVEa5K         ,
   "up"   : self.VVZja3          ,
   "down"   : self.VVg9ls         ,
   "left"   : self.VVQoKD         ,
   "right"   : self.VVM1hH         ,
   "pageUp"  : boundFunction(self.VVrDfa, True) ,
   "chanUp"  : boundFunction(self.VVrDfa, True) ,
   "pageDown"  : boundFunction(self.VVrDfa, False) ,
   "chanDown"  : boundFunction(self.VVrDfa, False) ,
   "next"   : self.VVJ6Ec        ,
   "last"   : self.VVrH1O         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FFBLtF(self)
  FFNepU(self)
  FFpqr2(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFmTns(self, boundFunction(self.VVJxo6, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VV3t0p(self):
  if not self.isBusy:
   VVhOvi = []
   VVhOvi.append(("Statistics"           , "VVlOgt"    ))
   VVhOvi.append(VVaOJ8)
   VVhOvi.append(("Suggest PIcons for Current Channel"     , "VV5S59"   ))
   VVhOvi.append(("Set to Current Channel (copy file)"     , "VVE3Fq_file"  ))
   VVhOvi.append(("Set to Current Channel (as SymLink)"     , "VVE3Fq_link"  ))
   VVhOvi.append(VVaOJ8)
   VVhOvi.append(CCpHVD.VVNZ4l())
   VVhOvi.append(VVaOJ8)
   if self.filterTitle == "PIcons without Channels":
    c = VVi1SQ
    VVhOvi.append((FFFpMs("Move Unused PIcons to a Directory", c) , "VV4f7n"  ))
    VVhOvi.append((FFFpMs("DELETE Unused PIcons", c)    , "VVnPkK" ))
    VVhOvi.append(VVaOJ8)
   VVhOvi.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVPAXl"  ))
   VVhOvi.append(VVaOJ8)
   VVhOvi += CCpHVD.VVChtx()
   VVhOvi.append(VVaOJ8)
   VVhOvi.append(("RCU Keys Help"          , "VVOsyT"    ))
   FFN6sa(self, self.VVBFoS, title=self.Title, VVhOvi=VVhOvi)
 def VVBFoS(self, item=None):
  if item is not None:
   if   item == "VVlOgt"     : self.VVlOgt()
   elif item == "VV5S59"    : self.VV5S59()
   elif item == "VVE3Fq_file"   : self.VVE3Fq(0)
   elif item == "VVE3Fq_link"   : self.VVE3Fq(1)
   elif item == "VVO5JY_file"  : self.VVO5JY(0)
   elif item == "VVO5JY_link"  : self.VVO5JY(1)
   elif item == "VVwudX"   : self.VVwudX()
   elif item == "VVtZ6G"  : self.VVtZ6G()
   elif item == "VV4f7n"    : self.VV4f7n()
   elif item == "VVnPkK"   : self.VVnPkK()
   elif item == "VVPAXl"   : self.VVPAXl()
   elif item == "VVVHpc"   : CCpHVD.VVVHpc(self)
   elif item == "VVCB4T"   : CCpHVD.VVCB4T(self)
   elif item == "findPiconBrokenSymLinks"  : CCpHVD.VV2yfG(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCpHVD.VV2yfG(self, False)
   elif item == "VVOsyT"      : self.VVOsyT()
 def VVN5Sy(self):
  if not self.isBusy:
   VVhOvi = []
   VVhOvi.append(("Go to First PIcon"  , "VV8TaG"  ))
   VVhOvi.append(("Go to Last PIcon"   , "VVTHpH"  ))
   VVhOvi.append(VVaOJ8)
   VVhOvi.append(("Sort by Channel Name"     , "sortByChan" ))
   VVhOvi.append(("Sort by File Name"  , "sortByFile" ))
   VVhOvi.append(VVaOJ8)
   VVhOvi.append(("Find from File List .." , "VVl2JN" ))
   FFN6sa(self, self.VV3SRw, title=self.Title, VVhOvi=VVhOvi)
 def VV3SRw(self, item=None):
  if item is not None:
   if   item == "VV8TaG"   : self.VV8TaG()
   elif item == "VVTHpH"   : self.VVTHpH()
   elif item == "sortByChan"  : self.VVyd28(2)
   elif item == "sortByFile"  : self.VVyd28(0)
   elif item == "VVl2JN"  : self.VVl2JN()
 def VVOsyT(self):
  FFftZ9(self, VVoH8d + "_help_picons", "PIcons Manager (Keys Help)")
 def VVZja3(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVTHpH()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVYHPM()
 def VVg9ls(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV8TaG()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVYHPM()
 def VVQoKD(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVTHpH()
  else:
   self.curCol -= 1
   self.VVYHPM()
 def VVM1hH(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV8TaG()
  else:
   self.curCol += 1
   self.VVYHPM()
 def VVrH1O(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVYHPM(True)
 def VVJ6Ec(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVYHPM(True)
 def VV8TaG(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVYHPM(True)
 def VVTHpH(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVYHPM(True)
 def VVl2JN(self):
  VVhOvi = []
  for item in self.VV2PlJ:
   VVhOvi.append((item[0], item[0]))
  FFN6sa(self, self.VVHxuU, title='PIcons ".png" Files', VVhOvi=VVhOvi, VV1r6m=True)
 def VVHxuU(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVzfSW(ndx)
 def VVoBDk(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVCIBE()
   if refCode:
    FFulYh(self, refCode)
    self.VV6x8p()
    self.VVgnqd()
 def VVrDfa(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VV6x8p()
   self.VVgnqd()
  except:
   pass
 def VVpKek(self):
  if self["keyGreen"].getVisible():
   self.VVzfSW(self.curChanIndex)
 def VVzfSW(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVYHPM(True)
  else:
   FFbstz(self, "Not found", 1000)
 def VVyd28(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFmTns(self, boundFunction(self.VVJxo6, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVE3Fq(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVCIBE()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVhOvi = []
     VVhOvi.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVhOvi.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFN6sa(self, boundFunction(self.VVu6IX, mode, curChF, selPiconF), VVhOvi=VVhOvi, title="Current Channel PIcon (already exists)")
    else:
     self.VVu6IX(mode, curChF, selPiconF, "overwrite")
   else:
    FF2wyP(self, "Cannot change PIcon to itself !", title=title)
  else:
   FF2wyP(self, "Could not read current channel info. !", title=title)
 def VVu6IX(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFmTns(self, boundFunction(self.VVJxo6, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVO5JY(self, mode):
  pass
 def VVwudX(self):
  pass
 def VVtZ6G(self):
  pass
 def VV4f7n(self):
  defDir = FFwI5c(CCpHVD.VVRh8o() + "picons_backup")
  os.system(FFiu56("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(boundFunction(self.VVbV0H, defDir), boundFunction(CC82J5
         , mode=CC82J5.VVXr5v, VV3wnF=CCpHVD.VVRh8o()))
 def VVbV0H(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCpHVD.VVRh8o():
    FF2wyP(self, "Cannot move to same directory !", title=title)
   else:
    if not FFwI5c(path) == FFwI5c(defDir):
     self.VVSPdg(defDir)
    FFStgm(self, boundFunction(FFmTns, self, boundFunction(self.VVeaZA, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VV2PlJ), path), title=title)
  else:
   self.VVSPdg(defDir)
 def VVeaZA(self, title, defDir, toPath):
  try:
   from shutil import move as iMove
  except:
   self.VVSPdg(defDir)
   FF2wyP(self, 'Could not load "shutil" module !', title=title)
   return
  toPath = FFwI5c(toPath)
  pPath = CCpHVD.VVRh8o()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VV2PlJ:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VV2PlJ)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFHVXB(self, txt, title=title, VVPEgn="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVg6AP("all")
 def VVSPdg(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVnPkK(self):
  title = "Delete Unused PIcons"
  tot = len(self.VV2PlJ)
  s = "s" if tot > 1 else ""
  FFStgm(self, boundFunction(FFmTns, self, boundFunction(self.VVRlzX, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, s), title=title)
 def VVRlzX(self, title):
  pPath = CCpHVD.VVRh8o()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VV2PlJ:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VV2PlJ)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFFpMs(str(totErr), VVi1SQ)
  FFHVXB(self, txt, title=title)
 def VVPAXl(self):
  lines = FFGCWo("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFStgm(self, boundFunction(self.VVqh08, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVU3wZ=True)
  else:
   FFnN3Y(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVqh08(self, fList):
  os.system(FFiu56("find -L '%s' -type l -delete" % self.pPath))
  FFnN3Y(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVEa5K(self):
  FFmTns(self, self.VVuXea)
 def VVuXea(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVCIBE()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFFpMs("PIcon Directory:\n", VVtzSE)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FFUCAY(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFUCAY(path)
   txt += FFFpMs("PIcon File:\n", VVtzSE)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFGCWo(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFFpMs("Found %d SymLink%s to this file from:\n" % (tot, s), VVtzSE)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFEChB(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFFpMs(tChName, VVplBl)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFFpMs(line, VV5UCJ), tChName)
    txt += "\n"
   if chName:
    txt += FFFpMs("Channel:\n", VVtzSE)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFFpMs(chName, VVplBl)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFFpMs("Remarks:\n", VVtzSE)
    txt += "  %s\n" % FFFpMs("Unused", VVi1SQ)
  else:
   txt = "No info found"
  FFhDEp(self, fncMode=CCip5O.VV2TW9, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVCIBE(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VV2PlJ[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFYd0o(sat)
  return fName, refCode, chName, sat, inDB
 def VV6x8p(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VV2PlJ):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVgnqd(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVCIBE()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFFpMs("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVtzSE))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVCIBE()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFFpMs(self.curChanName, VVqWH2)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVlOgt(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VV2PlJ:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFSDWT("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFHVXB(self, txt, title=self.Title)
 def VVlUP1(self):
  if not self.isBusy:
   VVhOvi = []
   VVhOvi.append(("All"         , "all"   ))
   VVhOvi.append(VVaOJ8)
   VVhOvi.append(("Used by Channels"      , "used"  ))
   VVhOvi.append(("Unused PIcons"      , "unused"  ))
   VVhOvi.append(VVaOJ8)
   VVhOvi.append(("PIcons Files"       , "pFiles"  ))
   VVhOvi.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVhOvi.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVhOvi.append(VVaOJ8)
   VVhOvi.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVhOvi.append(VVaOJ8)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFGrAn(val)
      VVhOvi.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCROIp(self)
   filterObj.VVkGhG(VVhOvi, self.nsList, self.VVxW3A)
 def VVxW3A(self, item=None):
  if item is not None:
   self.VVg6AP(item)
 def VVg6AP(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVmPSh   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVC8FK   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VV3B0P  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVtaeM  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVVshU  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVtBTw  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVrEUQ   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVqcz7   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVfY7n , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVtBTw:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFGCWo("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFbstz(self, "Not found", 1000)
     return
   elif mode == self.VVt0w0:
    return
   else:
    words, asPrefix = CCROIp.VVputs(words)
   if not words and mode in (self.VVqcz7, self.VVfY7n):
    FFbstz(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFmTns(self, boundFunction(self.VVJxo6, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VV5S59(self):
  self.session.open(CCvjpm, barTheme=CCvjpm.VVdivo
      , titlePrefix = ""
      , fncToRun  = self.VV7Rse
      , VVPtly = self.VVUz3Q)
 def VV7Rse(self, progBarObj):
  lameDbChans = CCz7Lj.VVdmHx(self, CCz7Lj.VVMyDj, VVPg2W=False, VVEx5a=False)
  files = []
  words = []
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVQ53i = []
  progBarObj.VVJZYU(len(lameDbChans))
  if lameDbChans:
   processChanName = CCsfdL()
   curCh = processChanName.VVGCeA(self.curChanName)
   for refCode in lameDbChans:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVVcps(1, True)
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCpHVD.VVdW6A(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCpHVD.VV7BoM(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       progBarObj.VVQ53i.append(f.replace(".png", ""))
 def VVUz3Q(self, VVWfVW, VVQ53i, threadCounter, threadTotal, threadErr):
  if VVQ53i:
   self.timer = eTimer()
   fnc = boundFunction(FFmTns, self, boundFunction(self.VVJxo6, mode=self.VVt0w0, words=VVQ53i), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FFbstz(self, "Not found", 2000)
 def VVJxo6(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVKJsA(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCz7Lj.VVdmHx(self, CCz7Lj.VVMyDj, VVPg2W=False, VVEx5a=False)
  iptvRefList = self.VV9d2S()
  tList = []
  for fName, fType in CCpHVD.VVK9BJ(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVmPSh:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVC8FK  and chName         : isAdd = True
   elif mode == self.VV3B0P and not chName        : isAdd = True
   elif mode == self.VVtaeM  and fType == 0        : isAdd = True
   elif mode == self.VVVshU  and fType == 1        : isAdd = True
   elif mode == self.VVtBTw  and fName in words       : isAdd = True
   elif mode == self.VVt0w0 and fName in words       : isAdd = True
   elif mode == self.VVrEUQ  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVqcz7  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVfY7n:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VV2PlJ   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FFbstz(self)
  else:
   self.isBusy = False
   FFbstz(self, "Not found", 1000)
   return
  self.VV2PlJ.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VV6x8p()
  self.totalPIcons = len(self.VV2PlJ)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVYHPM(True)
 def VVKJsA(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCpHVD.VVK9BJ(self.pPath):
    if fName:
     return True
   if isFirstTime : FF2wyP(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFbstz(self, "Not found", 1000)
  else:
   FF2wyP(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VV9d2S(self):
  VV2X4t = {}
  files  = CCniMM.VVSdoT(self)
  if files:
   for path in files:
    txt = FFJPcA(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VV2X4t[refCode] = item[1]
  return VV2X4t
 def VVYHPM(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VV4R6I = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VV4R6I: self.curPage = VV4R6I
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVD6Tl()
  if self.curPage == VV4R6I:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVgnqd()
  filName, refCode, chName, sat, inDB = self.VVCIBE()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVD6Tl(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VV2PlJ[ndx]
   fName = self.VV2PlJ[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFFpMs(chName, VVplBl))
    else : lbl.setText("-")
   except:
    lbl.setText(FFFpMs(chName, VVZj00))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVdW6A(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVNZ4l():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVVHpc"   )
 @staticmethod
 def VVChtx():
  VVhOvi = []
  VVhOvi.append(("Find SymLinks (to PIcon Directory)"   , "VVCB4T"   ))
  VVhOvi.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVhOvi.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVhOvi
 @staticmethod
 def VVVHpc(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(SELF)
  png, path = CCpHVD.VVCCT0(refCode)
  if path : CCpHVD.VVAi97(SELF, png, path)
  else : FF2wyP(SELF, "No PIcon found for current channel in:\n\n%s" % CCpHVD.VVRh8o())
 @staticmethod
 def VVCB4T(SELF):
  if VVqWH2:
   sed1 = FF23Tm("->", VVqWH2)
   sed2 = FF23Tm("picon", VVi1SQ)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVZj00, VVLtc8)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFS0Ql(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFBbZi(), grep, sed1, sed2, sed3))
 @staticmethod
 def VV2yfG(SELF, isPIcon):
  sed1 = FF23Tm("->", VVZj00)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FF23Tm("picon", VVi1SQ)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFS0Ql(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFBbZi(), grep, sed1, sed2))
 @staticmethod
 def VVK9BJ(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVRh8o():
  path = CFG.PIconsPath.getValue()
  return FFwI5c(path)
 @staticmethod
 def VVCCT0(refCode, chName=None):
  if FFupNy(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFONbJ(refCode)
  allPath, fName, refCodeFile, pList = CCpHVD.VV7BoM(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVAi97(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FF23Tm("%s%s" % (dest, png), VVplBl))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FF23Tm(errTxt, VV13Hf))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFZ9oT(SELF, cmd)
 @staticmethod
 def VV7BoM(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCpHVD.VVRh8o()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFwPAs(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCXG6l():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVOto6  = None
  self.VVx7yl = ""
  self.VVyY8z  = noService
  self.VVMPEF = 0
  self.VV7jAb  = noService
  self.VVZeew = 0
  self.VV9XRO  = "-"
  self.VVoueT = 0
  self.VVoxFO  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVt1Cg(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVOto6 = frontEndStatus
     self.VVputY()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVputY(self):
  if self.VVOto6:
   val = self.VVOto6.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVx7yl = "%3.02f dB" % (val / 100.0)
   else         : self.VVx7yl = ""
   val = self.VVOto6.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVMPEF = int(val)
   self.VVyY8z  = "%d%%" % val
   val = self.VVOto6.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVZeew = int(val)
   self.VV7jAb  = "%d%%" % val
   val = self.VVOto6.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VV9XRO  = "%d" % val
   val = int(val * 100 / 500)
   self.VVoueT = min(500, val)
   val = self.VVOto6.get("tuner_locked", 0)
   if val == 1 : self.VVoxFO = "Locked"
   else  : self.VVoxFO = "Not locked"
 def VVvrMt(self)   : return self.VVx7yl
 def VVJaSy(self)   : return self.VVyY8z
 def VVXF9X(self)  : return self.VVMPEF
 def VVoeHp(self)   : return self.VV7jAb
 def VVTlOA(self)  : return self.VVZeew
 def VVnnQD(self)   : return self.VV9XRO
 def VVWXWE(self)  : return self.VVoueT
 def VVxDbc(self)   : return self.VVoxFO
 def VVufSN(self) : return self.serviceName
class CCPwtQ():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVVFvP(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FF2DXN(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VV8DrZ(self.ORPOS  , mod=1   )
      self.sat2  = self.VV8DrZ(self.ORPOS  , mod=2   )
      self.freq  = self.VV8DrZ(self.FREQ  , mod=3   )
      self.sr   = self.VV8DrZ(self.SR   , mod=4   )
      self.inv  = self.VV8DrZ(self.INV  , self.D_PIL_INV)
      self.pol  = self.VV8DrZ(self.POL  , self.D_POL )
      self.fec  = self.VV8DrZ(self.FEC  , self.D_FEC )
      self.syst  = self.VV8DrZ(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VV8DrZ("modulation" , self.D_MOD )
       self.rolof = self.VV8DrZ("rolloff"  , self.D_ROLOF )
       self.pil = self.VV8DrZ("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VV8DrZ("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VV8DrZ("pls_code"  )
       self.iStId = self.VV8DrZ("is_id"   )
       self.t2PlId = self.VV8DrZ("t2mi_plp_id" )
       self.t2PId = self.VV8DrZ("t2mi_pid"  )
 def VV8DrZ(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFGrAn(val)
  elif mod == 2   : return FFf0Ve(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVmJ9W(self, refCode):
  txt = ""
  self.VVVFvP(refCode)
  if self.data:
   def VVtlsz(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVtlsz("System"   , self.syst)
    txt += VVtlsz("Satellite"  , self.sat2)
    txt += VVtlsz("Frequency"  , self.freq)
    txt += VVtlsz("Inversion"  , self.inv)
    txt += VVtlsz("Symbol Rate"  , self.sr)
    txt += VVtlsz("Polarization" , self.pol)
    txt += VVtlsz("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVtlsz("Modulation" , self.mod)
     txt += VVtlsz("Roll-Off" , self.rolof)
     txt += VVtlsz("Pilot"  , self.pil)
     txt += VVtlsz("Input Stream", self.iStId)
     txt += VVtlsz("T2MI PLP ID" , self.t2PlId)
     txt += VVtlsz("T2MI PID" , self.t2PId)
     txt += VVtlsz("PLS Mode" , self.plsMod)
     txt += VVtlsz("PLS Code" , self.plsCod)
   else:
    txt += VVtlsz("System"   , self.txMedia)
    txt += VVtlsz("Frequency"  , self.freq)
  return txt, self.namespace
 def VVLUAJ(self, refCode):
  txt = "Transpoder : ?"
  self.VVVFvP(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VVtzSE + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVd3OU(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FF2DXN(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VV8DrZ(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VV8DrZ(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VV8DrZ(self.SYST, self.D_SYS_S)
     freq = self.VV8DrZ(self.FREQ , mod=3  )
     if isSat:
      pol = self.VV8DrZ(self.POL , self.D_POL)
      fec = self.VV8DrZ(self.FEC , self.D_FEC)
      sr = self.VV8DrZ(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVRifh(self, refCode):
  self.data = None
  self.VVVFvP(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCtRew():
 def __init__(self, VVpxEf, path, VVPtly=None, curRowNum=-1):
  self.VVpxEf  = VVpxEf
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVPtly  = VVPtly
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFiu56("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVMtS2(curRowNum)
  else:
   FF2wyP(self.VVpxEf, "Error while preparing edit!")
 def VVMtS2(self, curRowNum):
  VV2X4t = self.VVgMLA()
  VVeO38 = None #("Delete Line" , self.deleteLine  , [])
  VVPtGh = ("Save Changes" , self.VVSQid   , [])
  VVPZiO  = ("Edit Line"  , self.VVjYjU    , [])
  VVMVHK = ("Line Options" , self.VVbz8h   , [])
  VVYLq6 = (""    , self.VV4nim , [])
  VVnQuA = self.VVsRmc
  VV5fkN  = self.VV7JHz
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVFSP3  = (CENTER  , LEFT  )
  VVmxnp = FFyzis(self.VVpxEf, None, title=self.Title, header=header, VV2PlJ=VV2X4t, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=26, VVeO38=VVeO38, VVPtGh=VVPtGh, VVPZiO=VVPZiO, VVMVHK=VVMVHK, VVnQuA=VVnQuA, VV5fkN=VV5fkN, VVYLq6=VVYLq6, VVwf0p=True
    , VVxH2w   = "#11001111"
    , VV2Du9   = "#11001111"
    , VVPEgn   = "#11001111"
    , VVV3E9  = "#05333333"
    , VVPt5m  = "#00222222"
    , VVbcXu  = "#11331133"
    )
  VVmxnp.VVFbB6(curRowNum)
 def VVbz8h(self, VVmxnp, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVmxnp.VV1Jo3()
  VVhOvi = []
  VVhOvi.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVhOvi.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVDwSD"  ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVl9Ui:
   VVhOvi.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(  ("Delete Line"         , "deleteLine"   ))
  FFN6sa(self.VVpxEf, boundFunction(self.VVYRnF, VVmxnp, lineNum), VVhOvi=VVhOvi, title="Line Options")
 def VVYRnF(self, VVmxnp, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVivKs("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVmxnp)
   elif item == "VVDwSD"  : self.VVDwSD(VVmxnp, lineNum)
   elif item == "copyToClipboard"  : self.VV9Koc(VVmxnp, lineNum)
   elif item == "pasteFromClipboard" : self.VVmcHS(VVmxnp, lineNum)
   elif item == "deleteLine"   : self.VVivKs("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVmxnp)
 def VV7JHz(self, VVmxnp):
  VVmxnp.VVWWQw()
 def VV4nim(self, VVmxnp, title, txt, colList):
  if   self.insertMode == 1: VVmxnp.VVYNNA()
  elif self.insertMode == 2: VVmxnp.VV3sBl()
  self.insertMode = 0
 def VVDwSD(self, VVmxnp, lineNum):
  if lineNum == VVmxnp.VV1Jo3():
   self.insertMode = 1
   self.VVivKs("echo '' >> '%s'" % self.tmpFile, VVmxnp)
  else:
   self.insertMode = 2
   self.VVivKs("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVmxnp)
 def VV9Koc(self, VVmxnp, lineNum):
  global VVl9Ui
  VVl9Ui = FFSDWT("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVmxnp.VV9577("Copied to clipboard")
 def VVSQid(self, VVmxnp, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFiu56("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFiu56("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVmxnp.VV9577("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVmxnp.VVWWQw()
    else:
     FF2wyP(self.VVpxEf, "Cannot save file!")
   else:
    FF2wyP(self.VVpxEf, "Cannot create backup copy of original file!")
 def VVsRmc(self, VVmxnp):
  if self.fileChanged:
   FFStgm(self.VVpxEf, boundFunction(self.VVah1w, VVmxnp), "Cancel changes ?")
  else:
   finalOK = os.system(FFiu56("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVah1w(VVmxnp)
 def VVah1w(self, VVmxnp):
  VVmxnp.cancel()
  os.system(FFiu56("rm -f '%s'" % self.tmpFile))
  if self.VVPtly:
   self.VVPtly(self.fileSaved)
 def VVjYjU(self, VVmxnp, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVLtc8 + "ORIGINAL TEXT:\n" + VV5UCJ + lineTxt
  FFK2QC(self.VVpxEf, boundFunction(self.VVgCuu, lineNum, VVmxnp), title="File Line", defaultText=lineTxt, message=message)
 def VVgCuu(self, lineNum, VVmxnp, VVa0Z4):
  if not VVa0Z4 is None:
   if VVmxnp.VV1Jo3() <= 1:
    self.VVivKs("echo %s > '%s'" % (VVa0Z4, self.tmpFile), VVmxnp)
   else:
    self.VVbDfb(VVmxnp, lineNum, VVa0Z4)
 def VVmcHS(self, VVmxnp, lineNum):
  if lineNum == VVmxnp.VV1Jo3() and VVmxnp.VV1Jo3() == 1:
   self.VVivKs("echo %s >> '%s'" % (VVl9Ui, self.tmpFile), VVmxnp)
  else:
   self.VVbDfb(VVmxnp, lineNum, VVl9Ui)
 def VVbDfb(self, VVmxnp, lineNum, newTxt):
  VVmxnp.VVAZt6("Saving ...")
  lines = FFQoVo(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVmxnp.VV480f()
  VV2X4t = self.VVgMLA()
  VVmxnp.VVkuQb(VV2X4t)
 def VVivKs(self, cmd, VVmxnp):
  tCons = CCyIWM()
  tCons.ePopen(cmd, boundFunction(self.VVjfRm, VVmxnp))
  self.fileChanged = True
  VVmxnp.VV480f()
 def VVjfRm(self, VVmxnp, result, retval):
  VV2X4t = self.VVgMLA()
  VVmxnp.VVkuQb(VV2X4t)
 def VVgMLA(self):
  if fileExists(self.tmpFile):
   lines = FFQoVo(self.tmpFile)
   VV2X4t = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VV2X4t.append((str(ndx), line.strip()))
   if not VV2X4t:
    VV2X4t.append((str(1), ""))
   return VV2X4t
  else:
   FFUQ3Z(self.VVpxEf, self.tmpFile)
class CCROIp():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVhOvi   = []
  self.satList   = []
 def VVxr86(self, VVPtly):
  self.VVhOvi = []
  VVhOvi, VVCKNz = self.VVB4gO(False, True)
  if VVhOvi:
   self.VVhOvi += VVhOvi
   self.VVykJs(VVPtly, VVCKNz)
 def VVC4Sb(self, mode, VVmxnp, satCol, VVPtly):
  VVmxnp.VVAZt6("Loading Filters ...")
  self.VVhOvi = []
  self.VVhOvi.append(("All Services" , "all"))
  if mode == 1:
   self.VVhOvi.append(VVaOJ8)
   self.VVhOvi.append(("Parental Control", "parentalControl"))
   self.VVhOvi.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVhOvi.append(VVaOJ8)
   self.VVhOvi.append(("Selected Transponder"   , "selectedTP" ))
   self.VVhOvi.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVtVy7(VVmxnp, satCol)
  VVhOvi, VVCKNz = self.VVB4gO(True, False)
  if VVhOvi:
   VVhOvi.insert(0, VVaOJ8)
   self.VVhOvi += VVhOvi
  VVmxnp.VVCAAJ()
  self.VVykJs(VVPtly, VVCKNz)
 def VVkGhG(self, VVhOvi, sats, VVPtly):
  self.VVhOvi = VVhOvi
  VVhOvi, VVCKNz = self.VVB4gO(True, False)
  if VVhOvi:
   self.VVhOvi.append(VVaOJ8)
   self.VVhOvi += VVhOvi
  self.VVykJs(VVPtly, VVCKNz)
 def VVykJs(self, VVPtly, VVCKNz):
  VVyt0G = ("Edit Filter", boundFunction(self.VV8Ie4, VVCKNz))
  VVmwoc  = ("Filter Help", boundFunction(self.VVIEUl, VVCKNz))
  FFN6sa(self.callingSELF, boundFunction(self.VVkWq8, VVPtly), VVhOvi=self.VVhOvi, title="Select Filter", VVyt0G=VVyt0G, VVmwoc=VVmwoc)
 def VVkWq8(self, VVPtly, item):
  if item:
   VVPtly(item)
 def VV8Ie4(self, VVCKNz, VVfiljObj, sel):
  if fileExists(VVCKNz) : CCtRew(self.callingSELF, VVCKNz, VVPtly=None)
  else       : FFUQ3Z(self.callingSELF, VVCKNz)
  VVfiljObj.cancel()
 def VVIEUl(self, VVCKNz, VVfiljObj, sel):
  FFftZ9(self.callingSELF, VVoH8d + "_help_service_filter", "Service Filter")
 def VVtVy7(self, VVmxnp, satColNum):
  if not self.satList:
   satList = VVmxnp.VVrsXN(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFYd0o(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VVaOJ8)
  if self.VVhOvi:
   self.VVhOvi += self.satList
 def VVB4gO(self, addTag, VVJGrp):
  FFoeH0()
  fileName  = "ajpanel_services_filter"
  VVCKNz = VVjxPh + fileName
  VVhOvi  = []
  if not fileExists(VVCKNz):
   os.system(FFiu56("cp -f '%s' '%s'" % (VVoH8d + fileName, VVCKNz)))
  fileFound = False
  if fileExists(VVCKNz):
   fileFound = True
   lines = FFQoVo(VVCKNz)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVhOvi.append((line, "__w__" + line))
       else  : VVhOvi.append((line, line))
  if VVJGrp:
   if   not fileFound : FFUQ3Z(self.callingSELF , VVCKNz)
   elif not VVhOvi : FFFNOf(self.callingSELF , VVCKNz)
  return VVhOvi, VVCKNz
 @staticmethod
 def VVputs(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CClfxx():
 def __init__(self, callingSELF, VVmxnp, refCodeColNum, addSep=True):
  self.callingSELF = callingSELF
  self.VVmxnp = VVmxnp
  self.refCodeColNum = refCodeColNum
  self.VVhOvi = []
  iMulSel = self.VVmxnp.VVcqke()
  if iMulSel : self.VVhOvi.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVhOvi.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVmxnp.VVXLPA()
  self.VVhOvi.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVhOvi.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVhOvi.append(VVaOJ8)
 def VVq2aw(self, servName):
  tot = self.VVmxnp.VVXLPA()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVhOvi.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVl3rE_multi" ))
  else    : self.VVhOvi.append( ("Add to Bouquet : %s"      % servName , "VVl3rE_one" ))
 def VVCjGG(self, servName, refCode):
  self.VVq2aw(servName)
  self.VVk6OI(servName, refCode)
 def VV7E7z(self, servName, refCode, pcState, hidState):
  isMulti = self.VVmxnp.VVbF0F
  if isMulti:
   refCodeList = self.VVmxnp.VVR0dW(3)
   if refCodeList:
    self.VVhOvi.append(("Add Selection to Parental Control"    , "parentalControl_sel_add"  ))
    self.VVhOvi.append(("Remove Selection from Parental Control"   , "parentalControl_sel_remove" ))
    self.VVhOvi.append(VVaOJ8)
    self.VVhOvi.append(("Add Selection to Hidden Services"    , "hiddenServices_sel_add"  ))
    self.VVhOvi.append(("Remove Selection from Hidden Services"   , "hiddenServices_sel_remove" ))
   else:
    self.VVhOvi.pop(len(self.VVhOvi) - 1)
  else:
   if pcState == "No" : self.VVhOvi.append(("Add to Parental Control"  , "parentalControl_add"   ))
   else    : self.VVhOvi.append(("Remove from Parental Control" , "parentalControl_remove"  ))
   self.VVhOvi.append(VVaOJ8)
   if hidState == "No" : self.VVhOvi.append(("Add to Hidden Services"  , "hiddenServices_add"   ))
   else    : self.VVhOvi.append(("Remove from Hidden Services" , "hiddenServices_remove"  ))
  self.VVhOvi.append(VVaOJ8)
  self.VVq2aw(servName)
  self.VVk6OI(servName, refCode)
 def VVk6OI(self, servName, refCode):
  FFN6sa(self.callingSELF, boundFunction(self.VVFdT7, servName, refCode), title="Options", VVhOvi=self.VVhOvi)
 def VVFdT7(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"     : self.VVmxnp.VVk734(True)
   elif item == "MultSelDisab"     : self.VVmxnp.VVk734(False)
   elif item == "selectAll"     : self.VVmxnp.VVktds()
   elif item == "unselectAll"     : self.VVmxnp.VV27HN()
   elif item == "parentalControl_add"   : self.callingSELF.VVe9mA(self.VVmxnp, refCode, True)
   elif item == "parentalControl_remove"  : self.callingSELF.VVe9mA(self.VVmxnp, refCode, False)
   elif item == "hiddenServices_add"   : self.callingSELF.VVdQS0(self.VVmxnp, refCode, True)
   elif item == "hiddenServices_remove"  : self.callingSELF.VVdQS0(self.VVmxnp, refCode, False)
   elif item == "parentalControl_sel_add"  : self.callingSELF.VVgNLp(self.VVmxnp, True)
   elif item == "parentalControl_sel_remove" : self.callingSELF.VVgNLp(self.VVmxnp, False)
   elif item == "hiddenServices_sel_add"  : self.callingSELF.VVmjqL(self.VVmxnp, True)
   elif item == "hiddenServices_sel_remove" : self.callingSELF.VVmjqL(self.VVmxnp, False)
   elif item == "VVl3rE_multi"  : self.VVl3rE(refCode, True)
   elif item == "VVl3rE_one"  : self.VVl3rE(refCode, False)
 def VVcKQa(self, VVmxnp):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  mSel   = CClfxx(self, VVmxnp, 3)
  mSel.VVCjGG(servName, refCode)
 def VVl3rE(self, refCode, isMulti):
  bouquets = FFRVXA()
  if bouquets:
   VVhOvi = []
   for item in bouquets:
    VVhOvi.append((item[0], item[1].toString()))
   VVyt0G = ("Create New", boundFunction(self.VVMuYw, refCode, isMulti))
   FFN6sa(self.callingSELF, boundFunction(self.VVafUA, refCode, isMulti), VVhOvi=VVhOvi, title="Add to Bouquet", VVyt0G=VVyt0G, VV1r6m=True, VVJH0e=True)
  else:
   FFStgm(self.callingSELF, boundFunction(self.VVtN0M, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVafUA(self, refCode, isMulti, bName=None):
  if bName:
   FFmTns(self.VVmxnp, boundFunction(self.VVnkUV, refCode, isMulti, bName), title="Adding Channels ...")
 def VVnkUV(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVntCp(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVhiUf = InfoBar.instance
    if VVhiUf:
     VVdb8z = VVhiUf.servicelist
     if VVdb8z:
      mutableList = VVdb8z.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVmxnp.VVCAAJ()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFnN3Y(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FF2wyP(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVntCp(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVmxnp.VVR0dW(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VVMuYw(self, refCode, isMulti, VVfiljObj, path):
  self.VVtN0M(refCode, isMulti)
 def VVtN0M(self, refCode, isMulti):
  FFK2QC(self.callingSELF, boundFunction(self.VV2Pfk, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VV2Pfk(self, refCode, isMulti, name):
  if name:
   FFmTns(self.VVmxnp, boundFunction(self.VVlu58, refCode, isMulti, name), title="Adding Channels ...")
 def VVlu58(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVntCp(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVhiUf = InfoBar.instance
    if VVhiUf:
     VVdb8z = VVhiUf.servicelist
     if VVdb8z:
      try:
       VVdb8z.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVdb8z.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVmxnp.VVCAAJ()
   title = "Add to Bouquet"
   if allOK: FFnN3Y(self.callingSELF, "Added to : %s" % name, title=title)
   else : FF2wyP(self.callingSELF, "Nothing added!", title=title)
class CCgRxy(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF82u7(VVcwsn, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFFsOT(self)
  FFydgK(self["keyRed"]  , "Exit")
  FFydgK(self["keyGreen"]  , "Save")
  FFydgK(self["keyYellow"] , "Refresh")
  FFydgK(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVB6mz  ,
   "green"   : self.VV64ar ,
   "yellow"  : self.VV9Fl8  ,
   "blue"   : self.VVZR4z   ,
   "up"   : self.VVZja3    ,
   "down"   : self.VVg9ls   ,
   "left"   : self.VVQoKD   ,
   "right"   : self.VVM1hH   ,
   "cancel"  : self.VVB6mz
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VV9Fl8()
  self.VVwpu1()
  FFNepU(self)
 def VVB6mz(self) : self.close(True)
 def VVQMus(self) : self.close(False)
 def VVZR4z(self):
  self.session.openWithCallback(self.VVexNa, boundFunction(CCSV7X))
 def VVexNa(self, closeAll):
  if closeAll:
   self.close()
 def VVZja3(self):
  self.VV8tyk(1)
 def VVg9ls(self):
  self.VV8tyk(-1)
 def VVQoKD(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVwpu1()
 def VVM1hH(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVwpu1()
 def VV8tyk(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVWg1Y(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVWg1Y(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVWg1Y(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVzcQq(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVzcQq(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVwpu1(self):
  for obj in self.list:
   FFpqr2(obj, "#11404040")
  FFpqr2(self.list[self.index], "#11ff8000")
 def VV9Fl8(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VV64ar(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCyIWM()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VV210C)
 def VV210C(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFnN3Y(self, "Nothing returned from the system!")
  else:
   FFnN3Y(self, str(result))
class CCSV7X(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF82u7(VV34Cv, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFFsOT(self, addLabel=True)
  FFydgK(self["keyRed"]  , "Exit")
  FFydgK(self["keyGreen"]  , "Sync")
  FFydgK(self["keyYellow"] , "Refresh")
  FFydgK(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVB6mz   ,
   "green"   : self.VVzc5X  ,
   "yellow"  : self.VVLNTy ,
   "blue"   : self.VVJYvo  ,
   "cancel"  : self.VVB6mz
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVt885()
  self.onShow.append(self.start)
 def start(self):
  FFHmgI(self.refresh)
  FFNepU(self)
 def refresh(self):
  self.VV1O8t()
  self.VVD6LP(False)
 def VVB6mz(self)  : self.close(True)
 def VVJYvo(self) : self.close(False)
 def VVt885(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VV1O8t(self):
  self.VVhAo6()
  self.VV2pI4()
  self.VVux8i()
  self.VVfSMv()
 def VVLNTy(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVt885()
   self.VV1O8t()
   FFHmgI(self.refresh)
 def VVzc5X(self):
  if len(self["keyGreen"].getText()) > 0:
   FFStgm(self, self.VVPwft, "Synchronize with Internet Date/Time ?")
 def VVPwft(self):
  self.VV1O8t()
  FFHmgI(boundFunction(self.VVD6LP, True))
 def VVhAo6(self)  : self["keyRed"].show()
 def VVxkHx(self)  : self["keyGreen"].show()
 def VVfdfB(self) : self["keyYellow"].show()
 def VVozy0(self)  : self["keyBlue"].show()
 def VV2pI4(self)  : self["keyGreen"].hide()
 def VVux8i(self) : self["keyYellow"].hide()
 def VVfSMv(self)  : self["keyBlue"].hide()
 def VVD6LP(self, sync):
  localTime = FF8TPi()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVp7Ly(server)
   if epoch_time is not None:
    ntpTime = FF0V0A(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCyIWM()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VV210C, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVfdfB()
  self.VVozy0()
  if ok:
   self.VVxkHx()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VV210C(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVD6LP(False)
  except:
   pass
 def VVp7Ly(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFKIlG():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCeCZG(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF82u7(VVRGT2, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFFsOT(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FFHmgI(self.VVx8YX)
 def VVx8YX(self):
  if FFKIlG(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFpqr2(self["myBody"], color)
   FFpqr2(self["myLabel"], color)
  except:
   pass
class CCpjoh(Screen):
 def __init__(self, session, isFromExternal=False):
  size = CFG.signalSize.getValue()
  screenW = FFbp9X()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FF82u7(VV4T9H, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self.isFromExternal  = isFromExternal
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCkx0a(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCkx0a(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCkx0a(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCXG6l()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFFsOT(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVZja3          ,
   "down"  : self.VVg9ls         ,
   "left"  : self.VVQoKD         ,
   "right"  : self.VVM1hH         ,
   "info"  : self.VVk6I8        ,
   "epg"  : self.VVk6I8        ,
   "menu"  : self.VVOsyT         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "blue"  : self.VVRjHn       ,
   "last"  : boundFunction(self.VVpsux, -1)  ,
   "next"  : boundFunction(self.VVpsux, 1)  ,
   "pageUp" : boundFunction(self.VVGTMk, True) ,
   "chanUp" : boundFunction(self.VVGTMk, True) ,
   "pageDown" : boundFunction(self.VVGTMk, False) ,
   "chanDown" : boundFunction(self.VVGTMk, False) ,
   "0"   : boundFunction(self.VVpsux, 0)  ,
   "1"   : boundFunction(self.VVhMAL, pos=1) ,
   "2"   : boundFunction(self.VVhMAL, pos=2) ,
   "3"   : boundFunction(self.VVhMAL, pos=3) ,
   "4"   : boundFunction(self.VVhMAL, pos=4) ,
   "5"   : boundFunction(self.VVhMAL, pos=5) ,
   "6"   : boundFunction(self.VVhMAL, pos=6) ,
   "7"   : boundFunction(self.VVhMAL, pos=7) ,
   "8"   : boundFunction(self.VVhMAL, pos=8) ,
   "9"   : boundFunction(self.VVhMAL, pos=9) ,
  }, -1)
  self.onShown.append(self.VVqrW9)
  self.onClose.append(self.onExit)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  self.sliderSNR.VVQFQ1()
  self.sliderAGC.VVQFQ1()
  self.sliderBER.VVQFQ1(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVhMAL()
  self.VVSsd0Info()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVSsd0)
  except:
   self.timer.callback.append(self.VVSsd0)
  self.timer.start(500, False)
 def VVSsd0Info(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVt1Cg(service)
  serviceName = self.tunerInfo.VVufSN()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self)
  tp = CCPwtQ()
  txt = tp.VVLUAJ(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVSsd0(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVt1Cg(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVvrMt())
   self["mySNR"].setText(self.tunerInfo.VVJaSy())
   self["myAGC"].setText(self.tunerInfo.VVoeHp())
   self["myBER"].setText(self.tunerInfo.VVnnQD())
   self.sliderSNR.VVJyYb(self.tunerInfo.VVXF9X())
   self.sliderAGC.VVJyYb(self.tunerInfo.VVTlOA())
   self.sliderBER.VVJyYb(self.tunerInfo.VVWXWE())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVJyYb(0)
   self.sliderAGC.VVJyYb(0)
   self.sliderBER.VVJyYb(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self)
    if state and not state == "Tuned":
     FFbstz(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVk6I8(self):
  FFhDEp(self, fncMode=CCip5O.VV8IfL)
 def VVOsyT(self):
  FFftZ9(self, VVoH8d + "_help_signal", "Signal Monitor (Keys)")
 def VVRjHn(self):
  self.session.open(CCrMvG, isFromExternal=self.isFromExternal)
  self.close()
 def VVZja3(self)  : self.VVhMAL(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVg9ls(self) : self.VVhMAL(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVQoKD(self) : self.VVhMAL(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVM1hH(self) : self.VVhMAL(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVhMAL(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVpsux(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFpAYp(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVGTMk(self, isUp):
  FFbstz(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVSsd0Info()
  except:
   pass
class CCkx0a(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVQFQ1(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFpqr2(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVoH8d +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFpqr2(self.covObj, self.covColor)
   else:
    FFpqr2(self.covObj, "#00006688")
    self.isColormode = True
  self.VVJyYb(0)
 def VVJyYb(self, val):
  val  = FFpAYp(val, self.minN, self.maxN)
  width = int(FFWpp1(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFpAYp(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCvjpm(Screen):
 VVdivo    = 0
 VVjDUm = 1
 VVrcZv = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVPtly=None, barTheme=VVdivo):
  ratio = self.VVt3zT(barTheme)
  self.skin, self.skinParam = FF82u7(VVtHnL, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVPtly = VVPtly
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVQ53i = None
  self.timer   = eTimer()
  self.myThread  = None
  FFFsOT(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVqrW9)
  self.onClose.append(self.onExit)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  self.VV1wAL()
  self["myProgBarVal"].setText("0%")
  FFpqr2(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVYnEJ()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVYnEJ)
  except:
   self.timer.callback.append(self.VVYnEJ)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def VVJZYU(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVnn7O_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVQ53i), self.counter, self.maxValue, catName)
 def VVnn7O_fromImportEPG(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVnn7O_forcedUpdate(self, title):
  self.newTitle = title
  try:
   self.VVYnEJ()
  except:
   pass
 def VVVcps(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VVQ53i), self.counter, self.maxValue)
  except:
   pass
 def VVEsn7(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVzgmZ(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VV4S9M(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFbstz(self, "Cancelling ...")
  self.isCancelled = True
  self.VVWzSX(False)
 def VVWzSX(self, isDone):
  if self.VVPtly:
   self.VVPtly(isDone, self.VVQ53i, self.counter, self.maxValue, self.isError)
  self.close()
 def VVYnEJ(self):
  val = FFpAYp(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFWpp1(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VVWzSX(True)
 def VV1wAL(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVjDUm, self.VVrcZv):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVt3zT(self, barTheme):
  if   barTheme == self.VVjDUm : return 0.7
  if   barTheme == self.VVrcZv : return 0.5
  else             : return 1
class CCyIWM(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVPtly = {}
  self.commandRunning = False
  self.VVIK38  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVPtly, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVPtly[name] = VVPtly
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVIK38:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVq9hP, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVQx2O , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVq9hP, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVQx2O , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVQx2O(name, retval)
  return True
 def VVq9hP(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVQx2O(self, name, retval):
  if not self.VVIK38:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVPtly[name]:
   self.VVPtly[name](self.appResults[name], retval)
  del self.VVPtly[name]
 def VV27Uk(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCRA8D(Screen):
 def __init__(self, session, title="", VVlQdH=None, VVvvzl=False, VVZfkK=False, VV4qJS=False, VVjuGL=False, VV23Fc=False, VVYg4L=False, VVLw9T=VVDGzB, VV8KYv=None, VVQUJi=False, VVwrxl=None, VVEM4k="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FF82u7(VV8opi, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFFsOT(self, addScrollLabel=True)
  if not VVEM4k:
   VVEM4k = "Processing ..."
  self["myLabel"].setText("   %s" % VVEM4k)
  self.VVvvzl   = VVvvzl
  self.VVZfkK   = VVZfkK
  self.VV4qJS   = VV4qJS
  self.VVjuGL  = VVjuGL
  self.VV23Fc = VV23Fc
  self.VVYg4L = VVYg4L
  self.VVLw9T   = VVLw9T
  self.VV8KYv = VV8KYv
  self.VVQUJi  = VVQUJi
  self.VVwrxl  = VVwrxl
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCyIWM()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFzohF()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVlQdH, str):
   self.VVlQdH = [VVlQdH]
  else:
   self.VVlQdH = VVlQdH
  if self.VV4qJS or self.VVjuGL:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVo4vY, VVo4vY)
   self.VVlQdH.append("echo -e '\n%s\n' %s" % (restartNote, FF23Tm(restartNote, VVqWH2)))
   if self.VV4qJS:
    self.VVlQdH.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVlQdH.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VV23Fc:
   FFbstz(self, "Processing ...")
  self.onLayoutFinish.append(self.VVYLlq)
  self.onClose.append(self.VVcCLY)
 def VVYLlq(self):
  self["myLabel"].VV3zxV(textOutFile="console" if self.enableSaveRes else "")
  if self.VVvvzl:
   self["myLabel"].VVgN9o()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVTzvS()
  else:
   self.VVqWu8()
 def VVTzvS(self):
  if FFKIlG():
   self["myLabel"].setText("Processing ...")
   self.VVqWu8()
  else:
   self["myLabel"].setText(FFFpMs("\n   No connection to internet!", VVi1SQ))
 def VVqWu8(self):
  allOK = self.container.ePopen(self.VVlQdH[0], self.VVDxJO, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVDxJO("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVYg4L or self.VV4qJS or self.VVjuGL:
    self["myLabel"].setText(FF6kX4("STARTED", VVqWH2) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVwrxl:
   colorWhite = CCP10Q.VVETo6(VVLtc8)
   color  = CCP10Q.VVETo6(self.VVwrxl[0])
   words  = self.VVwrxl[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVLw9T=self.VVLw9T)
 def VVDxJO(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVlQdH):
   allOK = self.container.ePopen(self.VVlQdH[self.cmdNum], self.VVDxJO, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVDxJO("Cannot connect to Console!", -1)
  else:
   if self.VV23Fc and FFzWzb(self):
    FFbstz(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVYg4L:
    self["myLabel"].appendText("\n" + FF6kX4("FINISHED", VVqWH2), self.VVLw9T)
   if self.VVvvzl or self.VVZfkK:
    self["myLabel"].VVgN9o()
   if self.VV8KYv is not None:
    self.VV8KYv()
   if not retval and self.VVQUJi:
    self.VVcCLY()
 def VVcCLY(self):
  if self.container.VV27Uk():
   self.container.killAll()
class CCqPfT(Screen):
 def __init__(self, session, VVlQdH=None, VV23Fc=False):
  self.skin, self.skinParam = FF82u7(VV8opi, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVjxPh + "ajpanel_terminal.history"
  self.customCommandsFile = VVjxPh + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFSDWT("pwd") or "/home/root"
  self.container   = CCyIWM()
  FFFsOT(self, addScrollLabel=True)
  FFydgK(self["keyRed"] , "Exit = Stop Command")
  FFydgK(self["keyGreen"] , "OK = History")
  FFydgK(self["keyYellow"], "Menu = Custom Cmds")
  FFydgK(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVruxj ,
   "cancel" : self.VVZyys  ,
   "menu"  : self.VVyZjD ,
   "last"  : self.VVo1Jg  ,
   "next"  : self.VVo1Jg  ,
   "1"   : self.VVo1Jg  ,
   "2"   : self.VVo1Jg  ,
   "3"   : self.VVo1Jg  ,
   "4"   : self.VVo1Jg  ,
   "5"   : self.VVo1Jg  ,
   "6"   : self.VVo1Jg  ,
   "7"   : self.VVo1Jg  ,
   "8"   : self.VVo1Jg  ,
   "9"   : self.VVo1Jg  ,
   "0"   : self.VVo1Jg
  })
  self.onLayoutFinish.append(self.VVqrW9)
  self.onClose.append(self.VVTJM3)
 def VVqrW9(self):
  self["myLabel"].VV3zxV(isResizable=False, textOutFile="terminal")
  FFxrbm(self["keyRed"]  , "#00ff8000")
  FFpqr2(self["keyRed"]  , self.skinParam["titleColor"])
  FFpqr2(self["keyGreen"]  , self.skinParam["titleColor"])
  FFpqr2(self["keyYellow"] , self.skinParam["titleColor"])
  FFpqr2(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVpCIQ(FFSDWT("date"), 5)
  result = FFSDWT("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVDyLN()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVoH8d + "LinuxCommands.lst"
   newTemplate = VVoH8d + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFiu56("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFiu56("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVTJM3(self):
  if self.container.VV27Uk():
   self.container.killAll()
   self.VVpCIQ("Process killed\n", 4)
   self.VVDyLN()
 def VVZyys(self):
  if self.container.VV27Uk():
   self.VVTJM3()
  else:
   FFStgm(self, self.close, "Exit ?", VVeJwQ=False)
 def VVDyLN(self):
  self.VVpCIQ(self.prompt, 1)
  self["keyRed"].hide()
 def VVpCIQ(self, txt, mode):
  if   mode == 1 : color = VVqWH2
  elif mode == 2 : color = VVtzSE
  elif mode == 3 : color = VVLtc8
  elif mode == 4 : color = VVi1SQ
  elif mode == 5 : color = VV5UCJ
  elif mode == 6 : color = VV1Lqa
  else   : color = VVLtc8
  try:
   self["myLabel"].appendText(FFFpMs(txt, color))
  except:
   pass
 def VVcsPq(self, cmd):
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVpCIQ(cmd, 2)
   self.VVpCIQ("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVpCIQ(ch, 0)
   self.VVpCIQ("\nor\n", 4)
   self.VVpCIQ("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVDyLN()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFFpMs(parts[0].strip(), VVtzSE)
    right = FFFpMs("#" + parts[1].strip(), VV1Lqa)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVpCIQ(txt, 2)
   lastLine = self.VVQNSB()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVk9VS(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVDxJO, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FF2wyP(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVpCIQ(data, 3)
 def VVDxJO(self, data, retval):
  if not retval == 0:
   self.VVpCIQ("Exit Code : %d\n" % retval, 4)
  self.VVDyLN()
 def VVruxj(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVQNSB() == "":
   self.VVk9VS("cd /tmp")
   self.VVk9VS("ls")
  VV2X4t = []
  if fileExists(self.commandHistoryFile):
   lines  = FFQoVo(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VV2X4t.append((str(c), line, str(lNum)))
   self.VVwcVL(VV2X4t, title, self.commandHistoryFile, isHistory=True)
  else:
   FFUQ3Z(self, self.commandHistoryFile, title=title)
 def VVQNSB(self):
  lastLine = FFSDWT("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVk9VS(self, cmd):
  os.system("echo '%s' >> %s" % (str(cmd.encode("UTF-8")), str(self.commandHistoryFile)))
 def VVyZjD(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFQoVo(self.customCommandsFile)
   lastLineIsSep = False
   VV2X4t = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VV2X4t.append((str(c), line, str(lNum)))
   self.VVwcVL(VV2X4t, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFUQ3Z(self, self.customCommandsFile, title=title)
 def VVwcVL(self, VV2X4t, title, filePath=None, isHistory=False):
  if VV2X4t:
   VVV3E9 = "#05333333"
   if isHistory: VVxH2w = VV2Du9 = VVPEgn = "#11000020"
   else  : VVxH2w = VV2Du9 = VVPEgn = "#06002020"
   VVCfae = VVMVHK = None
   VVPZiO   = ("Send"   , self.VVAGuz        , [])
   VVPtGh  = ("Modify & Send" , self.VVW7Xk        , [])
   if isHistory:
    VVCfae = ("Clear History" , self.VVs6Wl        , [])
   elif filePath:
    VVMVHK = ("Edit File"  , boundFunction(self.VVQKZ6, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVFSP3     = (CENTER  , LEFT   , CENTER )
   FFyzis(self, None, title=title, header=header, VV2PlJ=VV2X4t, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=26, VVPZiO=VVPZiO, VVPtGh=VVPtGh, VVCfae=VVCfae, VVMVHK=VVMVHK, VVwf0p=True
     , VVxH2w   = VVxH2w
     , VV2Du9   = VV2Du9
     , VVPEgn   = VVPEgn
     , VV0a8a  = "#05ffff00"
     , VVV3E9  = VVV3E9
    )
  else:
   FFFNOf(self, filePath, title=title)
 def VVAGuz(self, VVmxnp, title, txt, colList):
  cmd = colList[1].strip()
  VVmxnp.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVpCIQ("\n%s\n" % cmd, 6)
   self.VVpCIQ(self.prompt, 1)
  else:
   self.VVcsPq(cmd)
 def VVW7Xk(self, VVmxnp, title, txt, colList):
  cmd = colList[1]
  self.VVvc1A(VVmxnp, cmd)
 def VVs6Wl(self, VVmxnp, title, txt, colList):
  FFStgm(self, boundFunction(self.VV3yX5, VVmxnp), "Reset History File ?", title="Command History")
 def VV3yX5(self, VVmxnp):
  os.system(FFiu56("echo '' > %s" % self.commandHistoryFile))
  VVmxnp.cancel()
 def VVQKZ6(self, filePath, VVmxnp, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCtRew(self, filePath, VVPtly=boundFunction(self.VVcwAl, VVmxnp), curRowNum=rowNum)
  else     : FFUQ3Z(self, filePath)
 def VVcwAl(self, VVmxnp, fileChanged):
  if fileChanged:
   VVmxnp.cancel()
   FFHmgI(self.VVyZjD)
 def VVo1Jg(self):
  self.VVvc1A(None, self.lastCommand)
 def VVvc1A(self, VVmxnp, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFK2QC(self, boundFunction(self.VVlCnq, VVmxnp), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVlCnq(self, VVmxnp, cmd):
  if cmd and len(cmd) > 0:
   self.VVcsPq(cmd)
   if VVmxnp:
    VVmxnp.cancel()
class CCM6NZ(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVa0Z4="", VV2wBF=False, VVRIJV=False, isTrimEnds=True):
  self.skin, self.skinParam = FF82u7(VVyi6i, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFFsOT(self, title, addLabel=True)
  FFydgK(self["keyRed"] , "Up/Down = Change")
  FFydgK(self["keyGreen"] , "Overwrite")
  FFydgK(self["keyYellow"], "Pick Key Map")
  FFydgK(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVRIJV   = VVRIJV
  self.VV2wBF  = VV2wBF
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVa0Z4, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVzunS      ,
   "green"    : self.VVEk21    ,
   "yellow"   : self.VVaMOG      ,
   "blue"    : self.VVWXRU     ,
   "menu"    : self.VVSXCk     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVpPF0, True) ,
   "down"    : boundFunction(self.VVpPF0, False) ,
   "left"    : self.VVPgKy       ,
   "right"    : self.VVGbov       ,
   "home"    : self.VVAXPp       ,
   "end"    : self.VVQpFh       ,
   "next"    : self.VV0NYt      ,
   "last"    : self.VVVeuN      ,
   "deleteForward"  : self.VV0NYt      ,
   "deleteBackward" : self.VVVeuN      ,
   "tab"    : self.VVZIIC       ,
   "toggleOverwrite" : self.VVEk21    ,
   "0"     : self.VVpgmD     ,
   "1"     : self.VVpgmD     ,
   "2"     : self.VVpgmD     ,
   "3"     : self.VVpgmD     ,
   "4"     : self.VVpgmD     ,
   "5"     : self.VVpgmD     ,
   "6"     : self.VVpgmD     ,
   "7"     : self.VVpgmD     ,
   "8"     : self.VVpgmD     ,
   "9"     : self.VVpgmD
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVW65B()
  self.onShown.append(self.VVqrW9)
  self.onClose.append(self.onExit)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FFBLtF(self)
  self["myLabel"].setText(self.message)
  self.VVRx5Q()
  if self.VV2wBF : self.VVEk21()
  else    : self.VV8ZiH()
  FFNepU(self)
  FFpqr2(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVCbFq)
  except:
   self.timer.callback.append(self.VVCbFq)
 def onExit(self):
  self.timer.stop()
 def VVzunS(self):
  self.VVqsIs()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVqsIs()
  self.close(None)
 def VVSXCk(self):
  VVhOvi = []
  VVhOvi.append(("Home"         , "home"    ))
  VVhOvi.append(("End"         , "end"     ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Clear All"       , "clearAll"   ))
  VVhOvi.append(("Clear To Home"      , "clearToHome"   ))
  VVhOvi.append(("Clear To End"       , "clearToEnd"   ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVl9Ui:
   VVhOvi.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("To Capital Letters"     , "toCapital"   ))
  VVhOvi.append(("To Small Letters"      , "toSmall"    ))
  FFN6sa(self, self.VVPfLO, title="Edit Options", VVhOvi=VVhOvi)
 def VVPfLO(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVAXPp()
   elif item == "end"     : self.VVQpFh()
   elif item == "clearAll"    : self.VVAipO()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVAXPp()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVl9Ui
    VVl9Ui = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVl9Ui)
    self.VVAXPp()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVCbFq(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVEk21(self):
  self["myInput"].toggleOverwrite()
  self.VV8ZiH()
 def VVaMOG(self):
  self.session.openWithCallback(self.VVpotn, boundFunction(CC1xRI, mode=self.charMode, VVRIJV=self.VVRIJV))
 def VVpotn(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVRx5Q()
 def VV8ZiH(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVW65B(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVqsIs(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVgizV(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVPgKy(self)     : self.VVvpbD(self["myInput"].left)
 def VVGbov(self)     : self.VVvpbD(self["myInput"].right)
 def VV0NYt(self)     : self.VVvpbD(self["myInput"].delete)
 def VVAXPp(self)     : self.VVvpbD(self["myInput"].home)
 def VVQpFh(self)     : self.VVvpbD(self["myInput"].end)
 def VVVeuN(self)    : self.VVvpbD(self["myInput"].deleteBackward)
 def VVZIIC(self)     : self.VVvpbD(self["myInput"].tab)
 def VVAipO(self)     : self["myInput"].setText("")
 def VVvpbD(self, fnc):
  fnc()
  self.VVCbFq()
 def VVpgmD(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVgizV(newChar, overwrite)
   self.VVYzGO(newChar, self["myInput"].mapping[number])
 def VVpPF0(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CC1xRI.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CC1xRI.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVgizV(newChar, True)
   for group in groups:
    if newChar in group:
     self.VVYzGO(newChar, group)
     break
 def VVYzGO(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVLtc8:
    group = VV5UCJ + group.replace(newChar, FFFpMs(newChar, VVLtc8, VV5UCJ))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVWXRU(self):
  if self.VVRIJV : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVRx5Q()
 def VVRx5Q(self):
  self["myInput"].mapping = CC1xRI.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CC1xRI.RCU_MAP_TITLES[self.charMode])
class CC1xRI(Screen):
 VViWOq  = 0
 VVQeJF  = 1
 VVUqhS  = 2
 VVozXp  = 3
 VVkYqA = 4
 VVCsJE = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols , arabic_nums1, arabic1)
       , ( symbols , arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A", u"\u0628")
       , (u"\u0647", u"\u062A")
       )
 def __init__(self, session, mode=VViWOq, VVRIJV=False):
  self.skin, self.skinParam = FF82u7(VVbXFe, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVRIJV  = VVRIJV
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFFsOT(self, title=self.Title)
  FFydgK(self["keyRed"] ,"OK = Select")
  FFydgK(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVJX9e     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVUyj7, -1) ,
   "next"  : boundFunction(self.VVUyj7, +1) ,
   "left"  : boundFunction(self.VVUyj7, -1) ,
   "right"  : boundFunction(self.VVUyj7, +1) ,
  }, -1)
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FFpqr2(self["keyRed"], "#11222222")
  FFpqr2(self["keyGreen"], "#11222222")
  self.VVNbkC()
 def VVNbkC(self):
  self.VVWv4i()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVWv4i(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVUyj7(self, direction):
  if self.VVRIJV : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVNbkC()
 def VVJX9e(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCtcZh(Screen):
 def __init__(self, session, title="", message="", VVLw9T=VVDGzB, VVheTH=False, VVPEgn=None, VVCZ7I=30, canSaveToFile=""):
  self.skin, self.skinParam = FF82u7(VV8opi, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVCZ7I)
  self.session   = session
  FFFsOT(self, title, addScrollLabel=True)
  self.VVLw9T   = VVLw9T
  self.VVheTH   = VVheTH
  self.VVPEgn   = VVPEgn
  self.canSaveToFile  = canSaveToFile
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  self["myLabel"].VV3zxV(VVheTH=self.VVheTH, textOutFile=self.canSaveToFile)
  self["myLabel"].setText(self.message, self.VVLw9T)
  if self.VVPEgn:
   FFpqr2(self["myBody"], self.VVPEgn)
   FFpqr2(self["myLabel"], self.VVPEgn)
   FFbjpo(self["myLabel"], self.VVPEgn)
  self["myLabel"].VVgN9o()
class CCV4IB(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FF82u7(VVf6he, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFFsOT(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FF9Trc(self["errPic"], "err")
class CCSH1D(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FF82u7(VVTbqA, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", 20)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FFFsOT(self, " ", addCloser=True)
class CCmBoh():
 def __init__(self, session, txt):
  self.win = session.instantiateDialog(CCSH1D, txt)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  self.session = session
  self.timer  = eTimer()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV5SQ3)
  except:
   self.timer.callback.append(self.VV5SQ3)
  self.timer.start(1500, True)
 def VV5SQ3(self):
  self.session.deleteDialog(self.win)
class CCnmQ8():
 VV1Fhe    = 0
 VViOli  = 1
 VVIVZX   = ""
 VVV0Nx    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVmxnp   = None
  self.timer     = eTimer()
  self.VV5Aat   = 0
  self.VV5ERU  = 1
  self.VVsXWC  = 2
  self.VVBeB7   = 3
  self.VVlb0p   = 4
  VV2X4t = self.VVNGfG()
  if VV2X4t:
   self.VVmxnp = self.VVMwUO(VV2X4t)
  if not VV2X4t and mode == self.VV1Fhe:
   self.VVJGrpor("Download list is empty !")
   self.cancel()
  if mode == self.VViOli:
   FFmTns(self.VVmxnp or self.SELF, boundFunction(self.VVDyZh, startDnld, decodedUrl), title="Checking Server ...")
  self.VV1zfc(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV1zfc)
  except:
   self.timer.callback.append(self.VV1zfc)
  self.timer.start(1000, False)
 def VVMwUO(self, VV2X4t):
  VV2X4t.sort(key=lambda x: int(x[0]))
  VVnQuA = self.VVdiMu
  VVPZiO  = ("Play"  , self.VVg7x2 , [])
  VVyW3N = (""   , self.VVJntR  , [])
  VVeO38 = ("Stop"  , self.VVregg  , [])
  VVPtGh = ("Resume"  , self.VVfAdZ , [])
  VVCfae = ("Options" , self.VV3t0p  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVFSP3  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFyzis(self.SELF, None, title=self.Title, header=header, VV2PlJ=VV2X4t, VVFSP3=VVFSP3, VVDrmL=widths, VVCZ7I=26, VVPZiO=VVPZiO, VVyW3N=VVyW3N, VVnQuA=VVnQuA, VVeO38=VVeO38, VVPtGh=VVPtGh, VVCfae=VVCfae, VV2Du9="#11110011", VVxH2w="#11220022", VVPEgn="#11110011", VV0a8a="#00ffff00", VVV3E9="#00223025", VVPt5m="#0a333333", VVbcXu="#0a400040", VVwf0p=True, searchCol=1)
 def VVNGfG(self):
  lines = CCnmQ8.VVBTwp()
  VV2X4t = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",")
     left  = parts[0].strip()
     decodedUrl = ",".join(parts[1:]).strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVUVzm(decodedUrl)
      if fName:
       if   FFO3gx(decodedUrl) : sType = "Movie"
       elif FFfO63(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVfOIc(decodedUrl, fName)
       if size > -1: sizeTxt = CC82J5.VVnDM5(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VV2X4t.append((str(len(VV2X4t) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VV2X4t
 def VV9BuO(self):
  VV2X4t = self.VVNGfG()
  if VV2X4t:
   if self.VVmxnp : self.VVmxnp.VVkuQb(VV2X4t, VVt885Msg=False)
   else     : self.VVmxnp = self.VVMwUO(VV2X4t)
  else:
   self.cancel()
 def VV1zfc(self, force=False):
  if self.VVmxnp:
   thrList = self.VVTz3S()
   VV2X4t = []
   changed = False
   for ndx, row in enumerate(self.VVmxnp.VVlcwp()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VV5Aat
    if m3u8Log:
     percent = self.VVlysQ(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVBeB7 , "%.2f %%" % percent
      else   : flag, progr = self.VVlb0p , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFEZNr(mPath)
     if curSize > -1:
      fSize = CC82J5.VVnDM5(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CC82J5.VVnDM5(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFEZNr(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVBeB7 , "%.2f %%" % percent
       else   : flag, progr = self.VVlb0p , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CC82J5.VVnDM5(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrList:
     flag = self.VVsXWC
     if m3u8Log :
      if not speed and not force : flag = self.VV5ERU
      elif curSize == -1   : self.VVLz7s(False)
    elif flag == self.VV5Aat  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VV5Aat  : color2 = "#f#00555555#"
    elif flag == self.VV5ERU : color2 = "#f#0000FFFF#"
    elif flag == self.VVsXWC : color2 = "#f#0000FFFF#"
    elif flag == self.VVBeB7  : color2 = "#f#00FF8000#"
    elif flag == self.VVlb0p  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVBHHs(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VV2X4t.append(row)
   if changed or force:
    self.VVmxnp.VVkuQb(VV2X4t, VVt885Msg=False)
 def VVBHHs(self, flag):
  tDict = self.VVhXzj()
  return tDict.get(flag, "?")
 def VVjBNz(self, state):
  for flag, txt in self.VVhXzj().items():
   if txt == state:
    return flag
  return -1
 def VVhXzj(self):
  return { self.VV5Aat: "Not started", self.VV5ERU: "Connecting", self.VVsXWC: "Downloading", self.VVBeB7: "Stopped", self.VVlb0p: "Completed" }
 def VVXTiZ(self, title):
  colList = self.VVmxnp.VVB9NM()
  path = colList[6]
  url  = colList[8]
  if self.VVtlci() : self.VVJGrpor("Cannot delete !\n\nFile is downloading.")
  else      : FFStgm(self.SELF, boundFunction(self.VV4u6V, path, url), "Delete ?\n\n%s" % path, title=title)
 def VV4u6V(self, path, url):
  m3u8Log = self.VVmxnp.VVB9NM()[12].strip()
  if m3u8Log : os.system(FFiu56("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFiu56("rm -r '%s'" % path))
  self.VVJruk()
  self.VV9BuO()
 def VVJruk(self):
  if self.VVtlci():
   FFbstz(self.VVmxnp, self.VVBHHs(self.VVsXWC), 500)
  else:
   colList  = self.VVmxnp.VVB9NM()
   state  = colList[4].strip()
   decodedUrl = colList[9].strip()
   if self.VVjBNz(state) in (self.VV5Aat, self.VVlb0p):
    lines = CCnmQ8.VVBTwp()
    newLines = []
    found = False
    for line in lines:
     if CCnmQ8.VVy1ec(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVStOA(newLines)
     self.VV9BuO()
     FFbstz(self.VVmxnp, "Removed.", 1000)
    else:
     FFbstz(self.VVmxnp, "Not found.", 1000)
   else:
    self.VVJGrpor("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVzRk6(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFStgm(self.SELF, boundFunction(self.VVhdGA, flag), ques, title=title)
 def VVhdGA(self, flag):
  list = []
  for ndx, row in enumerate(self.VVmxnp.VVlcwp()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVjBNz(state)
   if   flag == flagVal == self.VVlb0p: list.append(decodedUrl)
   elif flag == flagVal == self.VV5Aat : list.append(decodedUrl)
  lines = CCnmQ8.VVBTwp()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVStOA(newLines)
   self.VV9BuO()
   FFbstz(self.VVmxnp, "%d removed." % totRem, 1000)
  else:
   FFbstz(self.VVmxnp, "Not found.", 1000)
 def VVO1G4(self):
  colList  = self.VVmxnp.VVB9NM()
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFbstz(self.VVmxnp, "Poster exists", 1500)
  else    : FFmTns(self.VVmxnp, boundFunction(self.VVeusk, decodedUrl, path, png), title="Checking Server ...")
 def VVeusk(self, decodedUrl, path, png):
  err = self.VVaY9S(decodedUrl, path, png)
  if err:
   FF2wyP(self.SELF, err, title="Poster Download")
 def VVaY9S(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCOJpB.VV0ESN(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCniMM.VVawMx(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCniMM.VVZkWo(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCniMM.VV0Pi7(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if pUrl:
   ext = os.path.splitext(pUrl)[1] or ".png"
   tPath, err = FFBgNy(pUrl, "ajpanel_tmp%s", timeout=2, mustBeImage=True)
   if err:
    return "Cannot download poster !\n\n%s" % err
   else:
    png = "%s%s" % (os.path.splitext(path)[0], ext)
    os.system(FFiu56("mv -f '%s' '%s'" % (tPath, png)))
    FF5Tue(self.SELF, title=os.path.basename(png), VVbFcr=png, showGrnMsg="Downloaded")
  else:
   return "Cannot get Poster URL !\n\n%s" % err
  return ""
 def VVJntR(self, VVmxnp, title, txt, colList):
  def VValCD(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVtlsz(key, val) : return "\n%s:\n%s\n" % (FFFpMs(key, COLOR_CONS_BRIGHT_YELLOW), val.strip())
  heads  = self.VVmxnp.VVyjNu()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VValCD(heads[i]  , CC82J5.VVnDM5(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VValCD("Downloaded" , CC82J5.VVnDM5(int(curSize), mode=0))
   else:
    txt += VValCD(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVtlsz(heads[i], colList[i])
  FFHVXB(self.SELF, txt, title=title)
 def VVg7x2(self, VVmxnp, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CC82J5.VVsepf(self.SELF, path)
  else    : FFbstz(self.VVmxnp, "File not found", 1000)
 def VVdiMu(self, VVmxnp):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVmxnp:
   self.VVmxnp.cancel()
  del self
 def VV3t0p(self, VVmxnp, title, txt, colList):
  decodedUrl = colList[9].strip()
  if CFG.downloadAutoResume.getValue(): resumeTxt = "Disable"
  else        : resumeTxt = "Enable"
  VVhOvi = []
  VVhOvi.append(("Remove current row"      , "VVJruk"  ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(('Remove all "Completed"'     , "remFinished"    ))
  VVhOvi.append(('Remove all "Not started"'     , "remPending"    ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Delete the file (and remove from list)" , "VVXTiZ" ))
  if FFO3gx(decodedUrl):
   VVhOvi.append(VVaOJ8)
   VVhOvi.append(("Download Movie Poster (from server)" , "VVO1G4"   ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append((resumeTxt + " Auto Resume"     , "VVcGPa"  ))
  FFN6sa(self.SELF, self.VVxEKK, VVhOvi=VVhOvi, title=self.Title, VV1r6m=True, VVJH0e=True)
 def VVxEKK(self, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVJruk"  : self.VVJruk()
   elif ref == "remFinished"   : self.VVzRk6(self.VVlb0p, txt)
   elif ref == "remPending"   : self.VVzRk6(self.VV5Aat, txt)
   elif ref == "VVXTiZ" : self.VVXTiZ(txt)
   elif ref == "VVO1G4"  : self.VVO1G4()
   elif ref == "VVcGPa"  : self.VVcGPa()
 def VVDyZh(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCOJpB.VV0ESN(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVJGrpor("Could not get download link !\n\nTry again later.")
     return
  for line in CCnmQ8.VVBTwp():
   if CCnmQ8.VVy1ec(decodedUrl, line):
    self.VVyCLt(decodedUrl)
    FFHmgI(boundFunction(FFbstz, self.VVmxnp, "Already listed !", 2000))
    break
  else:
   params = self.VVML1L(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVJGrpor(params[0])
   elif len(params) == 2:
    self.VVu3B3(params[0], decodedUrl)
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CC82J5.VVnDM5(fSize)
    FFStgm(self.SELF, boundFunction(self.VV5vXu, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VV5vXu(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCnmQ8.VVd5GV(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VV9BuO()
  if self.VVmxnp:
   self.VVmxnp.VV3sBl()
  if startDnld:
   threadName = self.VVV0Nx + decodedUrl
   self.VVI9kd(threadName, url, decodedUrl, path, resp)
 def VVyCLt(self, decodedUrl):
  for ndx, row in enumerate(self.VVmxnp.VVlcwp()):
   decodedUrl2 = row[9].strip()
   if decodedUrl == decodedUrl2 and self.VVmxnp:
    self.VVmxnp.VVupmb(ndx)
    break
 def VVML1L(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVUVzm(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVfOIc(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCOJpB.VV0ESN(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCOJpB.VVSS4mHeader()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head["Content-Length"]
   cType = head["Content-Type"]
   if not "video" in cType:
    if resp.url.endswith(".m3u8"):
     return [resp, 1]
    else:
     return ["Cannot download this video !\n\nNot allowed by server."]
   if "Accept-Ranges" in head:
    resume = head["Accept-Ranges"]
    if not resume == "none":
     resumable = True
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  err = CCnmQ8.VVh9Go(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVu3B3(self, resp, decodedUrl):
  if not os.system(FFiu56("which ffmpeg")) == 0:
   FFStgm(self.SELF, boundFunction(CCniMM.VVlvJk, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVUVzm(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVqjRf(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFStgm(self.SELF, boundFunction(self.VV82o3, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VV82o3(rTxt, rUrl)
  else:
   self.VVJGrpor("Cannot process m3u8 file !")
 def VVqjRf(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVhOvi = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCniMM.VVbwIj(rUrl, fPath)
   VVhOvi.append((resol, fullUrl))
  if VVhOvi:
   FFN6sa(self.SELF, self.VV6QV5, VVhOvi=VVhOvi, title="Resolution", VV1r6m=True, VVJH0e=True)
  else:
   self.VVJGrpor("Cannot get Resolutions list from server !")
 def VV6QV5(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFStgm(self.SELF, boundFunction(FFHmgI, boundFunction(self.VVnU4B, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFHmgI(boundFunction(self.VVnU4B, resolUrl))
 def VVnU4B(self, resolUrl):
  txt, err = CCOJpB.VViG3W(resolUrl)
  if err : self.VVJGrpor(err)
  else : self.VV82o3(txt, resolUrl)
 def VVpGYR(self, logF, decodedUrl):
  found = False
  lines = CCnmQ8.VVBTwp()
  with open(CCnmQ8.VVd5GV(), "w") as f:
   for line in lines:
    if CCnmQ8.VVy1ec(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCnmQ8.VVd5GV(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VV9BuO()
 def VV82o3(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCniMM.VVbwIj(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVJGrpor("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVpGYR(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFiu56("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = self.VVV0Nx + decodedUrl
  myThread = iThread(name=threadName, target=boundFunction(os.system, cmd))
  myThread.start()
 def VVlysQ(self, dnldLog):
  if fileExists(dnldLog):
   dur = self.VVQiPy(dnldLog)
   if dur > -1:
    tim = self.VVpXnV(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 def VVQiPy(self, dnldLog):
  lines = FFGCWo("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVpXnV(self, dnldLog):
  lines = FFGCWo("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVfOIc(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFfO63(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFiu56("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVI9kd(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVmxnp.VVB9NM()[7].strip())
  myThread = iThread(name=threadName, target=boundFunction(self.VV7Xnc, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VV7Xnc(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if CCnmQ8.VVIVZX == path:
       break
     else:
      break
  except:
   return
  if CCnmQ8.VVIVZX:
   CCnmQ8.VVIVZX = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFEZNr(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVML1L(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VV7Xnc(url, decodedUrl, path, resp, totFileSize, True)
 def VVregg(self, VVmxnp, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVcOkw() : FFbstz(self.VVmxnp, self.VVBHHs(self.VVlb0p), 500)
  elif not self.VVtlci() : FFbstz(self.VVmxnp, self.VVBHHs(self.VVBeB7), 500)
  elif m3u8Log      : FFStgm(self.SELF, self.VVLz7s, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVTz3S():
    CCnmQ8.VVIVZX = colList[6]
    FFbstz(self.VVmxnp, "Stopping ...", 1000)
   else:
    FFbstz(self.VVmxnp, "Stopped", 500)
 def VVLz7s(self, withMsg=True):
  if withMsg:
   FFbstz(self.VVmxnp, "Stopping ...", 1000)
  os.system(FFiu56("killall -INT ffmpeg"))
 def VVcGPa(self):
  CFG.downloadAutoResume.setValue(not CFG.downloadAutoResume.getValue())
  CFG.downloadAutoResume.save()
  configfile.save()
 def VVfAdZ(self, *args):
  if   self.VVcOkw() : FFbstz(self.VVmxnp, self.VVBHHs(self.VVlb0p) , 500)
  elif self.VVtlci() : FFbstz(self.VVmxnp, self.VVBHHs(self.VVsXWC), 500)
  else:
   resume = False
   m3u8Log = self.VVmxnp.VVB9NM()[12].strip()
   if m3u8Log:
    if fileExists(m3u8Log) : FFStgm(self.SELF, boundFunction(self.VVTQ2K, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVM5CY():
    resume = True
   if resume: FFmTns(self.VVmxnp, boundFunction(self.VVX8Qh), title="Checking Server ...")
   else  : FFbstz(self.VVmxnp, "Cannot resume !", 500)
 def VVTQ2K(self, m3u8Log):
  os.system(FFiu56("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FFmTns(self.VVmxnp, boundFunction(self.VVX8Qh), title="Checking Server ...")
 def VVX8Qh(self):
  colList  = self.VVmxnp.VVB9NM()
  path  = colList[6].strip()
  size  = colList[7].strip()
  decodedUrl = colList[9].strip()
  if "j.php" in decodedUrl:
   url = CCOJpB.VV0ESN(decodedUrl)
   if url:
    decodedUrl = self.VVx2JS(decodedUrl, url)
   else:
    self.VVJGrpor("Could not get download link !\n\nTry again later.")
    return
  curSize = FFEZNr(path)
  params = self.VVML1L(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVJGrpor(params[0])
   return
  elif len(params) == 2:
   self.VVu3B3(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVx2JS(decodedUrl, url, fSize)
  threadName = self.VVV0Nx + decodedUrl
  if resumable: self.VVI9kd(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVJGrpor("Cannot resume from server !")
 def VVUVzm(self, decodedUrl):
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(http:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   x = decodedUrl.find("&mode")
   if x > -1: url = decodedUrl[:x]
   fName = ".mp4"
   x = decodedUrl.find("&end=")
   if x > -1: chName = decodedUrl[x+5:]
  if url and fName and chName:
   mix  = fName + chName
   fName =  mix.split(":")[0]
   chName = ":".join(mix.split(":")[1:])
   fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
   url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVJGrpor(self, txt):
  FF2wyP(self.SELF, txt, title=self.Title)
 def VVTz3S(self):
  thrList = []
  for thr in iEnumerate():
   if self.VVV0Nx in thr.name:
    thrList.append(thr.name.replace(self.VVV0Nx, ""))
  return thrList
 def VVtlci(self):
  decodedUrl = self.VVmxnp.VVB9NM()[9].strip()
  return decodedUrl in self.VVTz3S()
 def VVcOkw(self):
  colList = self.VVmxnp.VVB9NM()
  path = colList[6].strip()
  size = colList[7].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFEZNr(path)) == size
 def VVM5CY(self):
  colList = self.VVmxnp.VVB9NM()
  path = colList[6].strip()
  size = int(colList[7].strip())
  curSize = FFEZNr(path)
  if curSize > -1:
   size -= curSize
  err = CCnmQ8.VVh9Go(size)
  if err:
   FF2wyP(self.SELF, err, title=self.Title)
   return False
  return True
 def VVStOA(self, list):
  with open(CCnmQ8.VVd5GV(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVx2JS(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCnmQ8.VVBTwp()
  url = decodedUrl
  with open(CCnmQ8.VVd5GV(), "w") as f:
   for line in lines:
    if CCnmQ8.VVy1ec(decodedUrl, line):
     parts = line.split(",")
     oldUrl = ",".join(parts[1:]).strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VV9BuO()
  return url
 @staticmethod
 def VVBTwp():
  list = []
  if fileExists(CCnmQ8.VVd5GV()):
   for line in FFQoVo(CCnmQ8.VVd5GV()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVy1ec(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVh9Go(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CC82J5.VV1sQ2(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CC82J5.VVnDM5(size), CC82J5.VVnDM5(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVAfVK(SELF):
  tot = CCnmQ8.VV0mRZ()
  if tot:
   FF2wyP(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VV0mRZ():
  c = 0
  for thread in iEnumerate():
   if thread.name.startswith(CCnmQ8.VVV0Nx):
    c += 1
  return c
 @staticmethod
 def VVjZWd():
  return len(CCnmQ8.VVBTwp()) == 0
 @staticmethod
 def VVxWz6():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVlaGn():
  mPoints = CCnmQ8.VVxWz6()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFiu56("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVd5GV():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVW2Oa(SELF):
  CCnmQ8.VVQ7jF(SELF, CCnmQ8.VV1Fhe)
 @staticmethod
 def VVwVDv_cur(SELF):
  CCnmQ8.VVQ7jF(SELF, CCnmQ8.VViOli, startDnld=True)
 @staticmethod
 def VVwVDv_url(SELF, url):
  CCnmQ8.VVQ7jF(SELF, CCnmQ8.VViOli, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVWaY9Current(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(SELF)
  added, skipped = CCnmQ8.VVWaY9List([decodedUrl])
  FFbstz(SELF, "Added", 1000)
 @staticmethod
 def VVWaY9List(list):
  added = skipped = 0
  for line in CCnmQ8.VVBTwp():
   for ndx, url in enumerate(list):
    if url and CCnmQ8.VVy1ec(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCnmQ8.VVd5GV(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVQ7jF(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCXLzC.VVl7b5(SELF):
   return
  if mode == CCnmQ8.VV1Fhe and CCnmQ8.VVjZWd():
   FF2wyP(SELF, "Download list is empty !", title=title)
  else:
   inst = CCnmQ8(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
class CCrMvG(Screen, CCLv4R):
 VVI11X = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False, enableDownloadMenu=True):
  self.skin, self.skinParam = FF82u7(VVxt4h, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCLv4R.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  self.SubtWin    = None
  FFFsOT(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVk3zj())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVIpBc         ,
   "info"  : self.VVk6I8        ,
   "epg"  : self.VVk6I8        ,
   "menu"  : self.VVdTSm       ,
   "cancel" : self.cancel         ,
   "blue"  : self.VV1zlw        ,
   "green"  : self.VVjmUI    ,
   "yellow" : self.VVQHUH   ,
   "left"  : boundFunction(self.VVJ3rc, -1)   ,
   "right"  : boundFunction(self.VVJ3rc,  1)   ,
   "play"  : self.VVtuC5        ,
   "pause"  : self.VVtuC5        ,
   "playPause" : self.VVtuC5        ,
   "stop"  : self.VVtuC5        ,
   "rewind" : self.VVmka1        ,
   "forward" : self.VVzD1S        ,
   "rewindDm" : self.VVmka1        ,
   "forwardDm" : self.VVzD1S        ,
   "last"  : self.VVYrgd        ,
   "next"  : self.VVgJJH        ,
   "pageUp" : boundFunction(self.VViZfa, True) ,
   "pageDown" : boundFunction(self.VViZfa, False) ,
   "chanUp" : boundFunction(self.VViZfa, True) ,
   "chanDown" : boundFunction(self.VViZfa, False) ,
   "up"  : boundFunction(self.VViZfa, True) ,
   "down"  : boundFunction(self.VViZfa, False) ,
   "audio"  : boundFunction(self.VV4Gjx, True) ,
   "subtitle" : boundFunction(self.VV4Gjx, False) ,
   "0"   : boundFunction(self.VVYUPu , 10)  ,
   "1"   : boundFunction(self.VVYUPu , 1)  ,
   "2"   : boundFunction(self.VVYUPu , 2)  ,
   "3"   : boundFunction(self.VVYUPu , 3)  ,
   "4"   : boundFunction(self.VVYUPu , 4)  ,
   "5"   : boundFunction(self.VVYUPu , 5)  ,
   "6"   : boundFunction(self.VVYUPu , 6)  ,
   "7"   : boundFunction(self.VVYUPu , 7)  ,
   "8"   : boundFunction(self.VVYUPu , 8)  ,
   "9"   : boundFunction(self.VVYUPu , 9)
  }, -1)
  self.onShown.append(self.VVqrW9)
  self.onClose.append(self.onExit)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FFBLtF(self)
  if not CCrMvG.VVI11X:
   CCrMvG.VVI11X = self
  else:
   self.close()
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FF9Trc(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FF9Trc(self["myPlayRpt"], "rpt")
  self.VVHk4w()
  self.instance.move(ePoint(40, 40))
  self.VV1gJp(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVckcZ)
  except:
   self.timer.callback.append(self.VVckcZ)
  self.timer.start(250, False)
  self.VVckcZ("Checking ...")
  self.VVWquJ()
 def VVjmUI(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self)
  if "chCode" in iptvRef:
   if CCXLzC.VVl7b5(self):
    self.VVWquJ(True)
 def VVHk4w(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl:
   color = "#1120002a"
   self["myPlayGrn"].show()
  else:
   color = "#1100202a"
   self["myPlayGrn"].hide()
  FFpqr2(self["myTitle"], color)
 def VVdTSm(self):
  if self.SubtWin:
   self.SubtWin.VVxurx()
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self)
  VVhOvi = []
  if self.isFromExternal:
   VVhOvi.append(("IPTV Menu"     , "iptv"  ))
   VVhOvi.append(VVaOJ8)
  if FFupNy(iptvRef) and not "&end=" in decodedUrl and not FFdSDy(decodedUrl):
   uType, uHost, uUser, uPass, uId, uChName = CCniMM.VVawMx(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVhOvi.append(("Catchup Programs"   , "catchup"  ))
    VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Stop Current Service"    , "stop"  ))
  VVhOvi.append(("Restart Current Service"   , "restart"  ))
  VVhOvi.append(VVaOJ8)
  FFO3gxSeries = FFdSDy(decodedUrl)
  if FFO3gxSeries:
   VVhOvi.append(("File Size"     , "fileSize" ))
   VVhOvi.append(VVaOJ8)
  if self.enableDownloadMenu:
   addSep = False
   if FFupNy(iptvRef) and FFO3gxSeries:
    VVhOvi.append(("Start Download"   , "dload_cur" ))
    VVhOvi.append(("Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCnmQ8.VVjZWd():
    VVhOvi.append(("Download Manager"   , "dload_stat" ))
    addSep = True
   if addSep:
    VVhOvi.append(VVaOJ8)
  addSep = False
  fPath, fDir, fName = CC82J5.VVCYXm(self)
  if fPath:
   if not CC82J5.VVEIWM:
    VVhOvi.append((VVqWH2 + "Open path in File Manager" , "VVCOYY" ))
    addSep = True
   if fPath:
    VVhOvi.append((VVqWH2 + 'Add to "My Movies" Bouquet' , "VVfI3G" ))
    VVhOvi.append((VVqWH2 + "Start Subtitle"    , "VVDCIi"  ))
    addSep = True
   if addSep:
    VVhOvi.append(VVaOJ8)
   VVhOvi.append(("%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVRHKG" ))
   VVhOvi.append(VVaOJ8)
  if CFG.playerPos.getValue() : VVhOvi.append(("Move Bar to Bottom"  , "botm"  ))
  else      : VVhOvi.append(("Move Bar to Top"  , "top"   ))
  VVhOvi.append(("Help"             , "help"  ))
  FFN6sa(self, self.VVPSJN, VVhOvi=VVhOvi, width=550, title="Options")
 def VVPSJN(self, item=None):
  if item:
   if item == "iptv"     : self.VVhYYt()
   elif item == "catchup"    : self.VVQHUH()
   elif item == "stop"     : self.VV2r1h(0)
   elif item == "restart"    : self.VV2r1h(1)
   elif item == "fileSize"    : FFmTns(self, boundFunction(CCip5O.VV1JmA, self), title="Checking Server")
   elif item == "dload_cur"   : CCnmQ8.VVwVDv_cur(self)
   elif item == "addToDload"   : CCnmQ8.VVWaY9Current(self)
   elif item == "dload_stat"   : CCnmQ8.VVW2Oa(self)
   elif item == "VVCOYY" : self.VVCOYY()
   elif item == "VVfI3G" : FFmTns(self, self.VVfI3G)
   elif item == "VVDCIi"  : self.VVDCIi(CCdqgc.VVZURx)
   elif item == "VVRHKG"  : self.VVRHKG()
   elif item == "botm"     : self.VV1gJp(0)
   elif item == "top"     : self.VV1gJp(1)
   elif item == "help"     : FFftZ9(self, VVoH8d + "_help_player", "Player Controller (Keys)")
 def onExit(self):
  self.timer.stop()
  CCrMvG.VVI11X = None
  self.VVqWNd()
 def VVAcR8(self):
  if CCrMvG.VVI11X:
   self.session.open(CCrMvG, enableZapping= False, enableDownloadMenu=False)
  self.close()
 def VVCOYY(self):
  self.session.open(CC82J5, gotoMovie=True)
  self.VVAcR8()
 def VVhYYt(self):
  self.session.open(CCniMM)
  self.VVAcR8()
 def VV2r1h(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.close()
   elif typ == 1:
    self.VVckcZ("Restarting Service ...")
    FFHmgI(boundFunction(self.VVVp45, serv))
 def VVVp45(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self)
  if "&end=" in decodedUrl: boundFunction(self.VVWquJ, True)
  else     : self.session.nav.playService(serv)
 def VVfI3G(self):
  title = "Add Movie to Bouquet"
  bName = "My Movies"
  path  = VVEkHL + "userbouquet.my_local_movies.tv"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self)
  fPath, fDir, fName = CC82J5.VVCYXm(self)
  if not fPath or not chName:
   FF2wyP(self, "Cannot read Path or Channel Name", title=title)
   return
  isNew = False
  if not fileExists(path):
   isNew = True
   with open(path, "w") as f:
    f.write("#NAME %s\n" % bName)
  catID, stID, chNum = "1638", "6", "6"
  refCode = CCniMM.VVfclL(catID, stID, chNum)
  if not isNew:
   fTxt = FFJPcA(path)
   chUrl_noRef = "%s:%s" % (fPath, chName)
   if chUrl_noRef in fTxt:
    FF2wyP(self, "Already added to bouquet:\n\n%s" % bName, title=title)
    return
   for ns in range(1, 65535 - 1):
    catID, stID, chNum = "1638", str(ns), "6"
    refCode = CCniMM.VVfclL(catID, stID, chNum)
    if not refCode in fTxt:
     break
   else:
    FF2wyP(self, "Cannot create a unique Reference Code", title=title)
    return
  if refCode and fPath and chName:
   chUrl = "%s%s:%s" % (refCode, fPath, chName)
   with open(path, "a") as f:
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
   piconOk = self.VV3oJs(refCode)
   FFJeEN(os.path.basename(path))
   FFgjOJ()
   FFnN3Y(self, "Added to bouquet:\n\n%s" % bName, title=title + (" (with PIcon)" if piconOk else ""))
  else:
   FF2wyP(self, "Cannot create a unique Reference Code", title=title)
   return
 def VVRHKG(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCrMvG.VVq8Zu(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVckcZ(txt, highlight=ok)
 def VVDCIi(self, mode, useSubtFile=""):
  self.hide()
  self.SubtWin = self.session.instantiateDialog(CCdqgc, mode=mode, endCallback=self.VVw6WW)
  self.SubtWin.show()
  self.SubtWin.VV6PES(useSubtFile)
 def VVw6WW(self, err):
  if err:
   if err == "noResume": self.VVqWNd(False)
   else    : self.VVqWNd(True)
   if   err == "noResume" : return
   if   err == "noErr"  : return
   elif err == "noAutoSrt" : CCdqgc.VVjUzW(self, self.VVZIX2)
   else      : FFbstz(self, err, 2000)
 def VVZIX2(self, path):
  if path:
   self.VVDCIi(CCdqgc.VVZURx, useSubtFile=path)
 def VV3oJs(self, refCode):
  fPath, fDir, fName, picFile = CCip5O.VVYTKN(self)
  pPath = CCpHVD.VVRh8o()
  if fileExists(pPath) and pathExists(picFile):
   pFile = refCode.replace(":", "_").strip("_") + ".png"
   dest = os.path.join(pPath, pFile)
   os.system(FFiu56("cp -f '%s' '%s'" % (picFile, dest)))
   os.system(FFiu56("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (dest, dest)))
   return True
  return False
 def VV1gJp(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VVIpBc(self):
  if self.isManualSeek:
   self.VViqHT()
   self.VVYWWs(self.manualSeekPts)
  else:
   if self.shown:
    self.hide()
    self.VVDCIi(CCdqgc.VVJkHR)
   else:
    self.VVqWNd()
 def VVqWNd(self, showBar=True):
  if self.SubtWin:
   self.session.deleteDialog(self.SubtWin)
   self.SubtWin = None
  if showBar:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VViqHT()
  elif self.SubtWin : self.VVqWNd()
  else    : self.close()
 def VVk6I8(self):
  if self.SubtWin:
   self.SubtWin.VVwCeD("noErr")
  FFhDEp(self, fncMode=CCip5O.VVs114)
 def VVtuC5(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except Exception as e:
   pass
  self.VVckcZ("Toggling Play/Pause ...")
 def VViqHT(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVJ3rc(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCrMvG.VVq8Zu(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVo5lB()
   else:
    self.manualSeekSec += direc * self.VVo5lB()
    self.manualSeekSec = FFpAYp(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFWpp1(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFuGN6(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVYUPu(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVk3zj())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVckcZ("Changed Seek Time to : %d%s" % (val, self.VVEz7A()))
 def VVk3zj(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVEz7A())
 def VVEz7A(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVT1I0(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVo5lB(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVckcZ(self, stateTxt="", highlight=False):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFiApO(self, addInfoObj=True)
  fr = res = ""
  if info:
   w = FFbHPv(info, iServiceInformation.sVideoWidth) or -1
   h = FFbHPv(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFbHPv(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CCip5O.VVraPM(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCrMvG.VVq8Zu(self)
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FFpAYp(percVal, 0, 100)
    width = int(FFWpp1(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not posTxt: self["myPlayPos"].setText("")
  if not remTxt: self["myPlayRem"].setText("")
  if not durTxt:
   if   prov : txt = prov
   elif posTxt : txt = ">>>>"
   else  : txt = "...."
   self["myPlayVal"].setText(txt)
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText("")
   FFpqr2(self["myPlayBarBG"], "#1100202a")
   self["myPlayBarF"].hide()
  else:
   FFpqr2(self["myPlayBarBG"], "#11000000")
   self["myPlayBarF"].show()
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VVrdrZ() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   if highlight: FFxrbm(self["myPlayMsg"], "#0000ffff")
   else  : FFxrbm(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   self["myPlayMsg"].setText("-" if decodedUrl else FFYPEg(refCode, True))
   FFxrbm(self["myPlayMsg"], "#00ff8066")
  tot = CCnmQ8.VV0mRZ()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVFe6H()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VVYWWs(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVYrgd()
  state = self.VVowwp()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFxrbm(self["myPlayMsg"], "#0000ff00")
  else     : FFxrbm(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 @staticmethod
 def VVq8Zu(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFuGN6(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFuGN6(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFuGN6(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVFe6H(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VV1zlw(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VVrdrZ()
   if cList:
    VVhOvi = []
    for pts, what in cList:
     txt = FFuGN6(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVhOvi.append((txt, pts))
    FFN6sa(self, self.VV62ma, VVhOvi=VVhOvi, title="Cut List")
   else:
    self.VVckcZ("No Cut-List for this channel !")
 def VV62ma(self, item=None):
  if item:
   self.VVYWWs(item)
 def VVrdrZ(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVzD1S(self) : self.VVzKeH(1)
 def VVmka1(self) : self.VVzKeH(-1)
 def VVzKeH(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCrMvG.VVq8Zu(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVo5lB() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVT1I0())
    self.VVckcZ(txt)
  except:
   self.VVckcZ("Cannot jump")
 def VVYWWs(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVckcZ("Changing Time ...")
 def VVYrgd(self):
  self.VV2r1h(1)
  self.VVckcZ("Replaying ...")
  self.VViqHT()
 def VVgJJH(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCrMvG.VVq8Zu(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVckcZ("Jumping to end ...")
  except:
   pass
 def VVowwp(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VViZfa(self, isUp):
  if self.enableZapping:
   self.VVckcZ("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VViqHT()
   if self.portalTableParam:
    FFHmgI(boundFunction(self.VVm1Xn, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self)
    if "/timeshift/" in decodedUrl:
     self.VVckcZ("Cannot Zap Catcup TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVpSFM()
 def VVpSFM(self):
  self.lastPlayPos = 0
  self.VVHk4w()
  self.VVWquJ()
 def VVm1Xn(self, isUp):
  CCniMM_inatance, VVmxnp, mode = self.portalTableParam
  if isUp : VVmxnp.VVLCN1()
  else : VVmxnp.VV3M3a()
  colList = VVmxnp.VVB9NM()
  if mode == "localIptv":
   chName, chUrl = CCniMM_inatance.VVDyXs(VVmxnp, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCniMM_inatance.VVWKk8(VVmxnp, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCniMM_inatance.VVLNrn(mode, VVmxnp, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCniMM_inatance.VVH8UH(mode, VVmxnp, colList)
  else:
   self.VVckcZ("Cannot Zap")
   return
  FFulYh(self, chUrl, VVK8qL=False)
  self.VVpSFM()
 def VVWquJ(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCrMvG.VVq8Zu(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self)
   if not self.VVrxHz(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVckcZ("Refreshing Portal")
   FFHmgI(self.VVaLQY)
  except:
   pass
 def VVaLQY(self):
  self.restoreLastPlayPos = self.VVLsnw()
 def VVQHUH(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiApO(self)
  if not decodedUrl or FFdSDy(decodedUrl):
   self.VVckcZ("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCniMM.VVawMx(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVckcZ("Reading Program List ...")
   ok_fnc = boundFunction(self.VVcz7Z, refCode, chName, streamId, uHost, uUser, uPass)
   FFHmgI(boundFunction(CCniMM.VVyLbk, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVckcZ("Cannot process this channel")
 def VVcz7Z(self, refCode, chName, streamId, uHost, uUser, uPass, VVmxnp, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVmxnp.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVckcZ("Changing Program ...")
   FFHmgI(boundFunction(self.VVlL3B, chUrl))
  else:
   self.VVckcZ("Incorrect Timestamp !")
 def VVlL3B(self, chUrl):
   FFulYh(self, chUrl, VVK8qL=False)
   self.lastPlayPos = 0
   self.VVHk4w()
 def VV4Gjx(self, isAudio):
  try:
   VVhiUf = InfoBar.instance
   if VVhiUf:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVhiUf)
    else  : self.session.open(SubtitleSelection, VVhiUf)
  except:
   pass
class CCpUH0(Screen):
 def __init__(self, session, title="", VVxngl="Continue?", VVeJwQ=True, VVU3wZ=False):
  self.skin, self.skinParam = FF82u7(VV48pj, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVxngl = VVxngl
  self.VVU3wZ = VVU3wZ
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVeJwQ : VVhOvi = [no , yes]
  else   : VVhOvi = [yes, no ]
  FFFsOT(self, title, VVhOvi=VVhOvi, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVIpBc ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVxngl)
  if self.VVU3wZ:
   self["myLabel"].instance.setHAlign(0)
  self.VVbscX()
  FFEktE(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFvPiT(self["myMenu"])
  FFLbRz(self, self["myMenu"])
 def VVIpBc(self):
  item = FFL8cC(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVbscX(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CC7mY3(Screen):
 def __init__(self, session, title="", VVhOvi=None, width=1000, height=0, OKBtnFnc=None, VVd2z3=None, VVV70K=None, VVyt0G=None, VVmwoc=None, VV1r6m=False, VVJH0e=False):
  if height == 0: height = 850
  self.skin, self.skinParam = FF82u7(VVyaPF, width, height, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVhOvi   = VVhOvi
  self.OKBtnFnc   = OKBtnFnc
  self.VVd2z3   = VVd2z3
  self.VVV70K  = VVV70K
  self.VVyt0G  = VVyt0G
  self.VVmwoc   = VVmwoc
  self.VV1r6m  = VV1r6m
  self.VVJH0e  = VVJH0e
  FFFsOT(self, title, VVhOvi=VVhOvi)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVIpBc          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVEWx6         ,
   "green"  : self.VVQXRG         ,
   "yellow" : self.VVvYQO         ,
   "blue"  : self.VV8GOA         ,
   "pageUp" : self.VVLaWS       ,
   "chanUp" : self.VVLaWS       ,
   "pageDown" : self.VVE4wY        ,
   "chanDown" : self.VVE4wY
  }, -1)
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FFEktE(self["myMenu"])
  FFwhmb(self)
  self.VVjmWj(self["keyRed"]  , self.VVd2z3 )
  self.VVjmWj(self["keyGreen"] , self.VVV70K )
  self.VVjmWj(self["keyYellow"] , self.VVyt0G )
  self.VVjmWj(self["keyBlue"]  , self.VVmwoc )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFNepU(self)
 def VVjmWj(self, btnObj, btnFnc):
  if btnFnc:
   FFydgK(btnObj, btnFnc[0])
 def VVIpBc(self):
  item = FFL8cC(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VV1r6m: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVEWx6(self)  : self.VVvpbD(self.VVd2z3)
 def VVQXRG(self) : self.VVvpbD(self.VVV70K)
 def VVvYQO(self) : self.VVvpbD(self.VVyt0G)
 def VV8GOA(self) : self.VVvpbD(self.VVmwoc)
 def VVvpbD(self, btnFnc):
  if btnFnc:
   item = FFL8cC(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVJH0e:
    self.cancel()
 def VVtH0B(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVhOvi = self["myMenu"].list
  VVhOvi.pop(ndx)
  if len(VVhOvi) > 0: self["myMenu"].setList(VVhOvi)
  else    : self.close()
 def VVckx8(self, VVhOvi):
  if len(VVhOvi) > 0:
   newList = []
   for item in VVhOvi:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVc4h0(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVLaWS(self):
  self["myMenu"].moveToIndex(0)
 def VVE4wY(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCNc3Q(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VV2PlJ=None, VVFSP3=None, VVDrmL=None, VVCZ7I=26, VVwf0p=False, VVPZiO=None, VVyW3N=None, VVeO38=None, VVPtGh=None, VVCfae=None, VVMVHK=None, VV5fkN=None, VVYLq6=None, VVnQuA=None, VVpjX8=-1, VVZLrl=False, searchCol=0, VVxH2w=None, VV2Du9=None, VVfRwC="#00dddddd", VVPEgn="#11002233", VV0a8a="#00ff8833", VVV3E9="#11111111", VVPt5m="#0a555555", VVVt7V="#0affffff", VVbcXu="#11552200", VVFJSi="#0055ff55"):
  self.skin, self.skinParam = FF82u7(VVBM3N, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFFsOT(self, title)
  self.header     = header
  self.VV2PlJ     = VV2PlJ
  self.totalCols    = len(VV2PlJ[0])
  self.VVITdp   = 0
  self.lastSortModeIsReverese = False
  self.VVwf0p   = VVwf0p
  self.VVi5po   = 0.01
  self.VVJ7vM   = 0.02
  self.VVhYAM = 0.03
  self.VVqkpa  = 1
  self.VVDrmL = VVDrmL
  self.colWidthPixels   = []
  self.VVPZiO   = VVPZiO
  self.OKButtonObj   = None
  self.VVyW3N   = VVyW3N
  self.VVeO38   = VVeO38
  self.VVPtGh   = VVPtGh
  self.VVCfae  = VVCfae
  self.VVMVHK   = VVMVHK
  self.VV5fkN    = VV5fkN
  self.VVYLq6   = VVYLq6
  self.VVnQuA  = VVnQuA
  self.VVpjX8    = VVpjX8
  self.VVZLrl   = VVZLrl
  self.searchCol    = searchCol
  self.VVFSP3    = VVFSP3
  self.keyPressed    = -1
  self.VVCZ7I    = FFLIqC(VVCZ7I)
  self.VVDe7d    = FFLtf8(self.VVCZ7I, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVxH2w    = VVxH2w
  self.VV2Du9      = VV2Du9
  self.VVfRwC    = FFp86o(VVfRwC)
  self.VVPEgn    = FFp86o(VVPEgn)
  self.VV0a8a    = FFp86o(VV0a8a)
  self.VVV3E9    = FFp86o(VVV3E9)
  self.VVPt5m   = FFp86o(VVPt5m)
  self.VVVt7V    = FFp86o(VVVt7V)
  self.VVbcXu    = FFp86o(VVbcXu)
  self.VVFJSi   = FFp86o(VVFJSi)
  self.VVbF0F  = False
  self.selectedItems   = 0
  self.VVv4qC   = FFp86o("#01fefe01")
  self.VVcIK5   = FFp86o("#11400040")
  self.VVcasZ  = self.VVv4qC
  self.VVQT2r  = self.VVV3E9
  if self.VVZLrl:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV0Pgi  ,
   "red"   : self.VVZNly  ,
   "green"   : self.VVxXrG ,
   "yellow"  : self.VVqFxa ,
   "blue"   : self.VVtOsw  ,
   "menu"   : self.VVR2AZ ,
   "info"   : self.VVTxa3  ,
   "cancel"  : self.VVDlOA  ,
   "up"   : self.VV3M3a    ,
   "down"   : self.VVLCN1  ,
   "left"   : self.VVrH1O   ,
   "right"   : self.VVJ6Ec  ,
   "pageUp"  : self.VVFLtD  ,
   "chanUp"  : self.VVFLtD  ,
   "pageDown"  : self.VV3sBl  ,
   "chanDown"  : self.VV3sBl
  }, -1)
  FFXMHc(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FFBLtF(self)
  try:
   self.VV1AVj()
  except Exception as err:
   FF2wyP(self, str(err))
   self.close(None)
 def VV1AVj(self):
  FFNepU(self)
  if self.VVxH2w:
   FFpqr2(self["myTitle"], self.VVxH2w)
  if self.VV2Du9:
   FFpqr2(self["myBody"] , self.VV2Du9)
   FFpqr2(self["myTableH"] , self.VV2Du9)
   FFpqr2(self["myTable"] , self.VV2Du9)
   FFpqr2(self["myBar"]  , self.VV2Du9)
  self.VVjmWj(self.VVeO38  , self["keyRed"])
  self.VVjmWj(self.VVPtGh  , self["keyGreen"])
  self.VVjmWj(self.VVCfae , self["keyYellow"])
  self.VVjmWj(self.VVMVHK  , self["keyBlue"])
  if self.VVPZiO:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVPZiO[0])
    FFpqr2(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVDe7d)
  self["myTableH"].l.setFont(0, gFont(VVg54i, self.VVCZ7I))
  self["myTable"].l.setItemHeight(self.VVDe7d)
  self["myTable"].l.setFont(0, gFont(VVg54i, self.VVCZ7I))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVDe7d)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVDe7d))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVDe7d)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVDe7d
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVDe7d * len(self.VV2PlJ) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVDrmL:
   self.VVDrmL = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVDrmL)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVFSP3:
   self.VVFSP3 = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVFSP3
   self.VVFSP3 = []
   for item in tmpList:
    self.VVFSP3.append(item | RT_VALIGN_CENTER)
  self.VVeO6R()
  if self.VV5fkN:
   self.VV5fkN(self)
 def VVjmWj(self, btnFnc, btn):
  if btnFnc : FFydgK(btn, btnFnc[0])
  else  : FFydgK(btn, "")
 def VV6UCU(self, waitTxt):
  FFmTns(self, self.VVeO6R, title=waitTxt)
 def VVeO6R(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVD0MR(0, self.header, self.VVVt7V, self.VVbcXu, self.VVVt7V, self.VVbcXu, self.VVFJSi)])
   rows = []
   for c, row in enumerate(self.VV2PlJ):
    rows.append(self.VVD0MR(c, row, self.VVfRwC, self.VVPEgn, self.VV0a8a, self.VVV3E9, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVpjX8 > -1:
    self["myTable"].moveToIndex(self.VVpjX8 )
   self.VVCKuO()
   if self.VVZLrl:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVDe7d * len(self.VV2PlJ)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVYLq6:
    self.VVvpbD(self.VVYLq6, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FF2wyP(self, str(err))
    self.close()
   except:
    pass
 def VVD0MR(self, keyIndex, columns, VVfRwC, VVPEgn, VV0a8a, VVV3E9, VVFJSi):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVFJSi and ndx == self.VVITdp : textColor = VVFJSi
   else           : textColor = VVfRwC
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFp86o(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVPEgn = c
    entry = span.group(3)
   if self.VVFSP3[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVDe7d)
           , font   = 0
           , flags   = self.VVFSP3[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVPEgn
           , color_sel  = VV0a8a
           , backcolor_sel = VVV3E9
           , border_width = 1
           , border_color = self.VVPt5m
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVTxa3(self):
  rowData = self.VVeQc7()
  if rowData:
   title, txt, colList = rowData
   if self.VVyW3N:
    fnc  = self.VVyW3N[1]
    params = self.VVyW3N[2]
    fnc(self, title, txt, colList)
   else:
    FFHVXB(self, txt, title)
 def VV0Pgi(self):
  if   self.VVbF0F : self.VVk4T4(self.VVwa7w(), mode=2)
  elif self.VVPZiO  : self.VVvpbD(self.VVPZiO, None)
  else      : self.VVTxa3()
 def VVZNly(self) : self.VVvpbD(self.VVeO38 , self["keyRed"])
 def VVxXrG(self) : self.VVvpbD(self.VVPtGh , self["keyGreen"])
 def VVqFxa(self): self.VVvpbD(self.VVCfae , self["keyYellow"])
 def VVtOsw(self) : self.VVvpbD(self.VVMVHK , self["keyBlue"])
 def VVvpbD(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFbstz(self, buttonFnc[3])
    FFHmgI(boundFunction(self.VVedsa, buttonFnc))
   else:
    self.VVedsa(buttonFnc)
 def VVedsa(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVeQc7()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVk4T4(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VV2PlJ[ndx]
   isSelected = row[1][9] == self.VVv4qC
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVD0MR(ndx, item, self.VVfRwC, self.VVPEgn, self.VV0a8a, self.VVV3E9, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVD0MR(ndx, item, self.VVv4qC, self.VVcIK5, self.VVcasZ, self.VVQT2r, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVCKuO()
 def VVktds(self):
  FFmTns(self, self.VVhlJx, title="Selecting all ...")
 def VVhlJx(self):
  self.VVk734(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVv4qC
   if not isSelected:
    item = self.VV2PlJ[ndx]
    newRow = self.VVD0MR(ndx, item, self.VVv4qC, self.VVcIK5, self.VVcasZ, self.VVQT2r, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVCKuO()
  self.VVF9oW()
 def VV27HN(self):
  FFmTns(self, self.VV59p9, title="Unselecting all ...")
 def VV59p9(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVv4qC:
    item = self.VV2PlJ[ndx]
    newRow = self.VVD0MR(ndx, item, self.VVfRwC, self.VVPEgn, self.VV0a8a, self.VVV3E9, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVCKuO()
  self.VVF9oW()
 def VVF9oW(self):
  self.hide()
  self.show()
 def VVeQc7(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVDrmL[i] > 1 or self.VVDrmL[i] == self.VVi5po or self.VVDrmL[i] == self.VVhYAM:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VV2PlJ))
   return rowNum, txt, colList
  else:
   return None
 def VVDlOA(self):
  if self.VVnQuA : self.VVnQuA(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VV2iNw(self):
  return self["myTitle"].getText().strip()
 def VVyjNu(self):
  return self.header
 def VVJgLc(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVAZt6(self, txt):
  FFbstz(self, txt)
 def VV9577(self, txt):
  FFbstz(self, txt, 1000)
 def VVCAAJ(self):
  FFbstz(self)
 def VV1Jo3(self):
  return len(self.VV2PlJ)
 def VV480f(self): self["keyGreen"].show()
 def VVWWQw(self): self["keyGreen"].hide()
 def VVwa7w(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VV0fQZ(self):
  return len(self["myTable"].list)
 def VVk734(self, isOn):
  self.VVbF0F = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu"].hide()
   if self.VVMVHK: self["keyBlue"].hide()
   if self.VVPZiO and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVMVHK: self["keyBlue"].show()
   if self.VVPZiO and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVPZiO[0])
   self.VV27HN()
  FFpqr2(self["myTitle"], color)
  FFpqr2(self["myBar"]  , color)
 def VVcqke(self):
  return self.VVbF0F
 def VVXLPA(self):
  return self.selectedItems
 def VVFbB6(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VVCKuO()
 def VVYNNA(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVCKuO()
 def VV73a3(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VV2PlJ:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVBb01(self):
  txt  = "Total Rows\t: %d\n\n" % self.VV1Jo3()
  txt += FF6kX4("Total Unique Items", VVi1SQ)
  for i in range(self.totalCols):
   if self.VVDrmL[i - 1] > 1 or self.VVDrmL[i - 1] == self.VVi5po or self.VVDrmL[i - 1] == self.VVhYAM:
    name, tot = self.VV73a3(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFHVXB(self, txt)
 def VVYTBT(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVB9NM(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVkuQb(self, newList, newTitle="", VVt885Msg=True):
  if newList:
   self.VV2PlJ = newList
   if self.VVwf0p and self.VVITdp == 0:
    self.VV2PlJ = sorted(self.VV2PlJ, key=lambda x: int(x[self.VVITdp])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VV2PlJ = sorted(self.VV2PlJ, key=lambda x: x[self.VVITdp].lower(), reverse=self.lastSortModeIsReverese)
   if VVt885Msg : self.VV6UCU("Refreshing ...")
   else   : self.VVeO6R()
   if newTitle:
    self.VVJgLc(newTitle)
  else:
   FF2wyP(self, "Cannot refresh list")
   self.cancel()
 def VVC5ot(self, data):
  ndx = self.VVwa7w()
  newRow = self.VVD0MR(ndx, data, self.VVfRwC, self.VVPEgn, self.VV0a8a, self.VVV3E9, None)
  if newRow:
   self.VV2PlJ[ndx] = data
   self["myTable"].list[ndx] = newRow
   self.VVCKuO()
   return True
  else:
   return False
 def VV1v28(self, colNum, textToFind, VVJGrp=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVCKuO()
    break
  else:
   if VVJGrp:
    FFbstz(self, "Not found", 1000)
 def VVtnU7(self, colDict, VVJGrp=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVCKuO()
    return
  if VVJGrp:
   FFbstz(self, "Not found", 1000)
 def VVtnU7_partial(self, colDict, VVJGrp=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVCKuO()
    return
  if VVJGrp:
   FFbstz(self, "Not found", 1000)
 def VVrsXN(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVR0dW(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVv4qC:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVxu9W(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VVv4qC: return True
  else        : return False
 def VVlcwp(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVR2AZ(self):
  if not self["keyMenu"].getVisible() or self.VVZLrl:
   return
  VVhOvi = []
  VVhOvi.append(("Table Statistcis"             , "tableStat"  ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append((FFFpMs("Export Table to .html"     , VVi1SQ) , "VVGjm1" ))
  VVhOvi.append((FFFpMs("Export Table to .csv"     , VVi1SQ) , "VVKyeV" ))
  VVhOvi.append((FFFpMs("Export Table to .txt (Tab Separated)", VVi1SQ) , "VVjtEH" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVDrmL[i] > 1 or self.VVDrmL[i] == self.VVJ7vM:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVhOvi.append(VVaOJ8)
   if tot == 1 : VVhOvi.append(("Sort", sList[0][1]))
   else  : VVhOvi += sList
  FFN6sa(self, self.VVzbrY, VVhOvi=VVhOvi, title=self.VV2iNw())
 def VVzbrY(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVBb01()
   elif item == "VVGjm1": FFmTns(self, self.VVGjm1, title=title)
   elif item == "VVKyeV" : FFmTns(self, self.VVKyeV , title=title)
   elif item == "VVjtEH" : FFmTns(self, self.VVjtEH , title=title)
   else:
    isReversed = False
    if self.VVITdp == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVwf0p and item == 0:
     self.VV2PlJ = sorted(self.VV2PlJ, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VV2PlJ = sorted(self.VV2PlJ, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVITdp = item
    self.VV6UCU("Sorting ...")
 def VV3M3a(self):
  self["myTable"].up()
  self.VVCKuO()
 def VVLCN1(self):
  self["myTable"].down()
  self.VVCKuO()
 def VVrH1O(self):
  self["myTable"].pageUp()
  self.VVCKuO()
 def VVJ6Ec(self):
  self["myTable"].pageDown()
  self.VVCKuO()
 def VVFLtD(self):
  self["myTable"].moveToIndex(0)
  self.VVCKuO()
 def VV3sBl(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVCKuO()
 def VVupmb(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVCKuO()
 def VVjtEH(self):
  expFile = self.VVo3B6() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVDrJJ()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VV2PlJ:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVDrmL[ndx] > self.VVqkpa or self.VVDrmL[ndx] == self.VVhYAM:
      col = self.VVKhwI(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVGHuU(expFile)
 def VVKyeV(self):
  expFile = self.VVo3B6() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVDrJJ()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VV2PlJ:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVDrmL[ndx] > self.VVqkpa or self.VVDrmL[ndx] == self.VVhYAM:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVKhwI(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVGHuU(expFile)
 def VVGjm1(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VV2iNw(), PLUGIN_NAME, VVzByU)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VV2iNw()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVDrJJ()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVDrmL:
   colgroup += '   <colgroup>'
   for w in self.VVDrmL:
    if w > self.VVqkpa or w == self.VVhYAM:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVo3B6() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VV2PlJ:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVDrmL[ndx] > self.VVqkpa or self.VVDrmL[ndx] == self.VVhYAM:
      col = self.VVKhwI(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVGHuU(expFile)
 def VVDrJJ(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVDrmL[ndx] > self.VVqkpa or self.VVDrmL[ndx] == self.VVhYAM:
     newRow.append(col.strip())
  return newRow
 def VVKhwI(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFwPAs(col)
 def VVo3B6(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VV2iNw())
  fileName = fileName.replace("__", "_")
  path  = FFwI5c(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFHXaa()
  return expFile
 def VVGHuU(self, expFile):
  FFnN3Y(self, "File exported to:\n\n%s" % expFile, title=self.VV2iNw())
 def VVCKuO(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CC0WxQ(Screen):
 def __init__(self, session, title="", VVbFcr=None, showGrnMsg=""):
  self.skin, self.skinParam = FF82u7(VVAYOg, 1400, 800, 30, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FFFsOT(self, title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VVbFcr = VVbFcr
  self.showGrnMsg  = showGrnMsg
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  allOK = FFnRFN(self["myLabel"], self.VVbFcr)
  if allOK:
   if self.showGrnMsg:
    FFbstz(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FF2wyP(self, "Cannot view picture file:\n\n%s" % self.VVbFcr)
   self.close()
class CCRZq2(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FF82u7(VVq42k, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 26, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFFsOT(self, title=self.Title)
  FFydgK(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Signal & Player Cotroller Hotkey"       , CFG.hotkey_signal    ))
  if VVAFnE:
   lst.append(getConfigListEntry("EPG Translation Language"        , CFG.epgLanguage    ))
  if VV3fmU:
   lst.append(getConfigListEntry("Force UTF-8 Encoding (only OpenVision Python-3.10.2+)" , CFG.forceUtf8Encoding   ))
  lst.append(getConfigListEntry(VVo4vY *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type"         , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsPath    ))
  lst.append(getConfigListEntry("Movie/Series Download Path"         , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(VVo4vY *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(VVo4vY *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB)"        , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons"            , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVHAk5()
  self.onShown.append(self.VVqrW9)
  self.onClose.append(self.onExit)
 def VVHAk5(self):
  kList = {
    "ok"  : self.VVIpBc    ,
    "green"  : self.VV2swz   ,
    "menu"  : self.VViZvM  ,
    "cancel" : self.VVGXUD  ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"]  = boundFunction(self["config"].handleKey, kLeft)
   kList["right"]  = boundFunction(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = boundFunction(self["config"].VVX35L, 0)
     kList["chanDown"] = boundFunction(self["config"].VVX35L, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FFBLtF(self)
  FFEktE(self["config"])
  FFwhmb(self, self["config"])
  FFNepU(self)
  CFG.forceUtf8Encoding.addNotifier(self.VVsw8r, initial_call=False)
 def onExit(self):
  CFG.forceUtf8Encoding.removeNotifier(self.VVsw8r)
 def VVsw8r(self, configElement=None):
  CCy6sJ.VVNNnJ()
 def VVIpBc(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsPath   : self.VVaxtZ()
   elif item == CFG.MovieDownloadPath   : self.VVAnsF(item, self["config"].getCurrent()[0])
   elif item == CFG.PIconsPath    : self.VVm5xY(item)
   elif item == CFG.backupPath    : self.VVm5xY(item)
   elif item == CFG.packageOutputPath  : self.VVm5xY(item)
   elif item == CFG.downloadedPackagesPath : self.VVm5xY(item)
   elif item == CFG.exportedTablesPath  : self.VVm5xY(item)
   elif item == CFG.exportedPIconsPath  : self.VVm5xY(item)
 def VVAnsF(self, item, title):
  tot = CCnmQ8.VV0mRZ()
  if tot : FF2wyP(self, "Cannot change while downloading.", title=title)
  else : self.VVm5xY(item)
 def VVaxtZ(self):
  VVhOvi = []
  VVhOvi.append(("Auto Find" , "auto"))
  VVhOvi.append(("Custom Path" , "path"))
  FFN6sa(self, self.VVL5de, VVhOvi=VVhOvi, title="IPTV Hosts Files Path")
 def VVL5de(self, item=None):
  if item:
   if   item == "auto": CFG.iptvHostsPath.setValue(VVTlxf)
   elif item == "path": self.VVm5xY(CFG.iptvHostsPath)
 def VVm5xY(self, configObj):
  sDir = configObj.getValue()
  if sDir == VVTlxf:
   sDir = "/"
  self.session.openWithCallback(boundFunction(self.VVhNPc, configObj)
         , boundFunction(CC82J5, mode=CC82J5.VVXr5v, VV3wnF=sDir))
 def VVhNPc(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVGXUD(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFStgm(self, self.VV2swz, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VV2swz(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVXYHm()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VViZvM(self):
  VVhOvi = []
  VVhOvi.append(("Use Backup directory in all other paths"      , "VVycyK"   ))
  VVhOvi.append(("Reset all to default (including File Manager bookmarks)"  , "VVCwK4"   ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Backup %s Settings" % PLUGIN_NAME        , "VVsv7W"  ))
  VVhOvi.append(("Restore %s Settings" % PLUGIN_NAME       , "VVjtKf"  ))
  if fileExists(VVjxPh + VVx9at):
   VVhOvi.append(VVaOJ8)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVhOvi.append(('%s Checking for Update' % txt1       , txt2     ))
   VVhOvi.append(("Reinstall %s" % PLUGIN_NAME        , "VVeFP4"  ))
   VVhOvi.append(("Update %s" % PLUGIN_NAME        , "VVd9l0"   ))
  FFN6sa(self, self.VVvLst, VVhOvi=VVhOvi, title="Config. Options")
 def VVvLst(self, item=None):
  if item:
   if   item == "VVycyK"  : FFStgm(self, self.VVycyK , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVCwK4"  : FFStgm(self, self.VVCwK4, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCP10Q)
   elif item == "VVsv7W" : self.VVsv7W()
   elif item == "VVjtKf" : FFmTns(self, self.VVjtKf, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVAzTK(True)
   elif item == "disableChkUpdate" : self.VVAzTK(False)
   elif item == "VVeFP4" : FFmTns(self, self.VVeFP4 , "Checking Server ...")
   elif item == "VVd9l0"  : FFmTns(self, self.VVd9l0  , "Checking Server ...")
 def VVsv7W(self):
  path = "%sajpanel_settings_%s" % (VVjxPh, FFHXaa())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFnN3Y(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVjtKf(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFGCWo("find / %s -iname '%s*' | grep %s" % (FFBbZi(1), name, name))
  if lines:
   lines.sort()
   VVhOvi = []
   for line in lines:
    VVhOvi.append((line, line))
   FFN6sa(self, boundFunction(self.VVeCX9, title), title=title, VVhOvi=VVhOvi, width=1200)
  else:
   FF2wyP(self, "No settings files found !", title=title)
 def VVeCX9(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFQoVo(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVXYHm()
    FFoeH0()
   else:
    FFUQ3Z(SELF, path, title=title)
 def VVAzTK(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVycyK(self):
  newPath = FFwI5c(VVjxPh)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVXYHm()
 @staticmethod
 def VVSzXI():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVCwK4(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.EventsInfoMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.epgLanguage.setValue("off")
  CFG.forceUtf8Encoding.setValue(True)
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.autoResetFrozenIptvChan.setValue(True)
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.iptvHostsPath.setValue(VVTlxf)
  CFG.MovieDownloadPath.setValue(CCnmQ8.VVlaGn())
  CFG.PIconsPath.setValue(VVDsyD)
  CFG.backupPath.setValue(CCRZq2.VVSzXI())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVXYHm()
  self.close()
 def VVXYHm(self):
  configfile.save()
  global VVjxPh
  VVjxPh = CFG.backupPath.getValue()
  FF6HBs()
 def VVd9l0(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVP9PT(title)
  if webVer:
   FFStgm(self, boundFunction(FFmTns, self, boundFunction(self.VVSTIt, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVeFP4(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVP9PT(title, True)
  if webVer:
   FFStgm(self, boundFunction(FFmTns, self, boundFunction(self.VVSTIt, webVer, title, True)), "Install and Restart ?", title=title)
 def VVSTIt(self, webVer, title, isReinst=False):
  url = self.VVaEFH(self, title)
  if url:
   VVIK38 = FFSRwQ() == "dpkg"
   if VVIK38 == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVIK38 else "ipk")
   path, err = FFBgNy(url + fName, fName, timeout=2)
   if path:
    if isReinst : cmd = FF5ENR(VVwEDD, path)
    else  : cmd = FF5ENR(VVzcHK, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFHbvq(self, cmd)
    else:
     FFAopx(self, title=title)
   else:
    FF2wyP(self, err, title=title)
 def VVP9PT(self, title, anyVer=False):
  url = self.VVaEFH(self, title)
  if not url:
   return ""
  path, err = FFBgNy(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FF2wyP(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFJPcA(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FF2wyP(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVzByU.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFGCWo(cmd)
   if list and curVer == list[0]:
    return webVer
  FFnN3Y(self, FFFpMs("No update required.", VVplBl) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVaEFH(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVjxPh + VVx9at
  if fileExists(path):
   span = iSearch(r"(http.+)", FFJPcA(path), IGNORECASE)
   if span : url = FFwI5c(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FF2wyP(SELF, err, title)
  return url
 @staticmethod
 def VVB5SV(url):
  path, err = FFBgNy(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFJPcA(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVzByU.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFGCWo(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCP10Q(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FF82u7(VVbLuF, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVoUIZ
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFFsOT(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVJVqO("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVJVqO("\c00888888", i) + sp + "GREY\n"
   txt += self.VVJVqO("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVJVqO("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVJVqO("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVJVqO("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVJVqO("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVJVqO("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVJVqO("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVJVqO("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVJVqO("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVJVqO("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVIpBc ,
   "green"   : self.VVIpBc ,
   "left"   : self.VVQoKD ,
   "right"   : self.VVM1hH ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  self.VVHNU7()
 def VVIpBc(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFStgm(self, self.VVK6dc, "Change to : %s" % txt, title=self.Title)
 def VVK6dc(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVoUIZ
  VVoUIZ = self.cursorPos
  self.VV7Tyq()
  self.close()
 def VVQoKD(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVHNU7()
 def VVM1hH(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVHNU7()
 def VVHNU7(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVJVqO(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVETo6(color):
  if VVqWH2: return "\\" + color
  else    : return ""
 @staticmethod
 def VV7Tyq():
  global VV1Lqa, VV5UCJ, VV13Hf, VVi1SQ, VVCfQO, VVOA2D, VVplBl, VVqWH2, COLOR_CONS_BRIGHT_YELLOW, VVtzSE, VVZ9CV, VVZj00, VVLtc8
  VVLtc8   = CCP10Q.VVJVqO("\c00FFFFFF", VVoUIZ)
  VV5UCJ    = CCP10Q.VVJVqO("\c00888888", VVoUIZ)
  VV1Lqa  = CCP10Q.VVJVqO("\c005A5A5A", VVoUIZ)
  VVOA2D    = CCP10Q.VVJVqO("\c00FF0000", VVoUIZ)
  VV13Hf   = CCP10Q.VVJVqO("\c00FF5000", VVoUIZ)
  VVqWH2   = CCP10Q.VVJVqO("\c00FFFF00", VVoUIZ)
  COLOR_CONS_BRIGHT_YELLOW = CCP10Q.VVJVqO("\c00FFFFAA", VVoUIZ)
  VVplBl   = CCP10Q.VVJVqO("\c0000FF00", VVoUIZ)
  VVCfQO    = CCP10Q.VVJVqO("\c000066FF", VVoUIZ)
  VVtzSE    = CCP10Q.VVJVqO("\c0000FFFF", VVoUIZ)
  VVZ9CV  = CCP10Q.VVJVqO("\c00DSFFFF", VVoUIZ)  #
  VVZj00   = CCP10Q.VVJVqO("\c00FA55E7", VVoUIZ)
  VVi1SQ    = CCP10Q.VVJVqO("\c00FF8F5F", VVoUIZ)
CCP10Q.VV7Tyq()
class CCIPZZ(Screen):
 def __init__(self, session, path, VVIK38):
  self.skin, self.skinParam = FF82u7(VV34Cv, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVMbdt   = path
  self.VVQqYV   = ""
  self.VV5xyV   = ""
  self.VVIK38    = VVIK38
  self.VVFnrR    = ""
  self.VV60ES  = ""
  self.VVFmVa    = False
  self.VVwDAj  = False
  self.postInstAcion   = 0
  self.VVsSs7  = "enigma2-plugin-extensions"
  self.VVxsjl  = "enigma2-plugin-systemplugins"
  self.VV2eQg = "enigma2"
  self.VV7o5P  = 0
  self.VVwAZy  = 1
  self.VVxwyF  = 2
  if pathExists(self.Path + "DEBIAN") : self.VV32ei = "DEBIAN"
  else        : self.VV32ei = "CONTROL"
  self.controlPath = self.Path + self.VV32ei
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVIK38:
   self.packageExt  = ".deb"
   self.VVPEgn  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVPEgn  = "#11001020"
  FFFsOT(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFydgK(self["keyRed"] , "Create")
  FFydgK(self["keyGreen"] , "Post Install")
  FFydgK(self["keyYellow"], "Installation Path")
  FFydgK(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVcnAe  ,
   "green"   : self.VVCNqq ,
   "yellow"  : self.VVLX7G  ,
   "blue"   : self.VVlSiI  ,
   "cancel"  : self.VVB6mz
  }, -1)
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FFNepU(self)
  if self.VVPEgn:
   FFpqr2(self["myBody"], self.VVPEgn)
   FFpqr2(self["myLabel"], self.VVPEgn)
  self.VVtnLI(True)
  self.VVEa5K(True)
 def VVEa5K(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVsQzc()
  if isFirstTime:
   if   package.startswith(self.VVsSs7) : self.VVMbdt = VVdG9z + self.VVFnrR + "/"
   elif package.startswith(self.VVxsjl) : self.VVMbdt = VVcnky + self.VVFnrR + "/"
   else            : self.VVMbdt = self.Path
  if self.VVFmVa : myColor = VVi1SQ
  else    : myColor = VVLtc8
  txt  = ""
  txt += "Source Path\t: %s\n" % FFFpMs(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFFpMs(self.VVMbdt, VVqWH2)
  if self.VV5xyV : txt += "Package File\t: %s\n" % FFFpMs(self.VV5xyV, VV5UCJ)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFFpMs("Check Control File fields : %s" % errTxt, VV13Hf)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFFpMs("Restart GUI", VVi1SQ)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFFpMs("Reboot Device", VVi1SQ)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FFFpMs("Post Install", VVplBl), act)
  if not errTxt and VV13Hf in controlInfo:
   txt += "Warning\t: %s\n" % FFFpMs("Errors in control file may affect the result package.", VV13Hf)
  txt += "\nControl File\t: %s\n" % FFFpMs(self.controlFile, VV5UCJ)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVCNqq(self):
  VVhOvi = []
  VVhOvi.append(("No Action"    , "noAction"  ))
  VVhOvi.append(("Restart GUI"    , "VV4qJS"  ))
  VVhOvi.append(("Reboot Device"   , "rebootDev"  ))
  FFN6sa(self, self.VVQgS4, title="Package Installation Option (after completing installation)", VVhOvi=VVhOvi)
 def VVQgS4(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VV4qJS"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVtnLI(False)
   self.VVEa5K()
 def VVLX7G(self):
  rootPath = FFFpMs("/%s/" % self.VVFnrR, VV1Lqa)
  VVhOvi = []
  VVhOvi.append(("Current Path"        , "toCurrent"  ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Extension Path"       , "toExtensions" ))
  VVhOvi.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVhOvi.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFN6sa(self, self.VVsMBM, title="Installation Path", VVhOvi=VVhOvi)
 def VVsMBM(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVsZIs(FFG47Q(self.Path, True))
   elif item == "toExtensions"  : self.VVsZIs(VVdG9z)
   elif item == "toSystemPlugins" : self.VVsZIs(VVcnky)
   elif item == "toRootPath"  : self.VVsZIs("/")
   elif item == "toRoot"   : self.VVsZIs("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVarTG, boundFunction(CC82J5, mode=CC82J5.VVXr5v, VV3wnF=VVjxPh))
 def VVarTG(self, path):
  if len(path) > 0:
   self.VVsZIs(path)
 def VVsZIs(self, parent, withPackageName=True):
  if withPackageName : self.VVMbdt = parent + self.VVFnrR + "/"
  else    : self.VVMbdt = "/"
  mode = self.VVBFtw()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVTKoF(mode), self.controlFile))
  self.VVEa5K()
 def VVlSiI(self):
  if fileExists(self.controlFile):
   lines = FFQoVo(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFK2QC(self, self.VVoCly, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FF2wyP(self, "Version not found or incorrectly set !")
  else:
   FFUQ3Z(self, self.controlFile)
 def VVoCly(self, VVa0Z4):
  if VVa0Z4:
   version, color = self.VVi6iF(VVa0Z4, False)
   if color == VVtzSE:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVa0Z4, self.controlFile))
    self.VVEa5K()
   else:
    FF2wyP(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVB6mz(self):
  if self.newControlPath:
   if self.VVFmVa:
    self.VVABhw()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFFpMs(self.newControlPath, VV5UCJ)
    txt += FFFpMs("Do you want to keep these files ?", VVqWH2)
    FFStgm(self, self.close, txt, callBack_No=self.VVABhw, title="Create Package", VVU3wZ=True)
  else:
   self.close()
 def VVABhw(self):
  os.system(FFiu56("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVTKoF(self, mode):
  if   mode == self.VVwAZy : prefix = self.VVsSs7
  elif mode == self.VVxwyF : prefix = self.VVxsjl
  else        : prefix = self.VV2eQg
  return prefix + "-" + self.VV60ES
 def VVBFtw(self):
  if   self.VVMbdt.startswith(VVdG9z) : return self.VVwAZy
  elif self.VVMbdt.startswith(VVcnky) : return self.VVxwyF
  else            : return self.VV7o5P
 def VVtnLI(self, isFirstTime):
  self.VVFnrR   = os.path.basename(os.path.normpath(self.Path))
  self.VVFnrR   = "_".join(self.VVFnrR.split())
  self.VV60ES = self.VVFnrR.lower()
  self.VVFmVa = self.VV60ES == VVrPCL.lower()
  if self.VVFmVa and self.VV60ES.endswith("ajpan"):
   self.VV60ES += "el"
  if self.VVFmVa : self.VVQqYV = VVjxPh
  else    : self.VVQqYV = CFG.packageOutputPath.getValue()
  self.VVQqYV = FFwI5c(self.VVQqYV)
  if not pathExists(self.controlPath):
   os.system(FFiu56("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVFmVa : t = PLUGIN_NAME
  else    : t = self.VVFnrR
  self.VVBvTm(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVIZJG.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVFmVa : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVBvTm(self.postrmFile, txt)
  if self.VVFmVa:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVzByU)
   self.VVBvTm(self.preinstFile, txt)
  else:
   self.VVBvTm(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVFnrR)
  mode = self.VVBFtw()
  if isFirstTime and not mode == self.VV7o5P:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVo4vY
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVBvTm(self.postinstFile, txt, VV2wBF=True)
  os.system(FFiu56("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVFmVa : version, descripton, maintainer = VVzByU , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVFnrR , self.VVFnrR
   txt = ""
   txt += "Package: %s\n"  % self.VVTKoF(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVBvTm(self, path, lines, VV2wBF=False):
  if not fileExists(path) or VV2wBF:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVsQzc(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFQoVo(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFFpMs(line, VV13Hf)
     elif not line.startswith(" ")    : line = FFFpMs(line, VV13Hf)
     else          : line = FFFpMs(line, VVtzSE)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVtzSE
   else   : color = VV13Hf
   descr = FFFpMs(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VV13Hf
     elif line.startswith((" ", "\t")) : color = VV13Hf
     elif line.startswith("#")   : color = VV5UCJ
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVi6iF(val, True)
      elif key == "Version"  : version, color = self.VVi6iF(val, False)
      elif key == "Maintainer" : maint  , color = val, VVtzSE
      elif key == "Architecture" : arch  , color = val, VVtzSE
      else:
       color = VVtzSE
      if not key == "OE" and not key.istitle():
       color = VV13Hf
     else:
      color = VVi1SQ
     txt += FFFpMs(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VV5xyV = self.VVQqYV + packageName
   self.VVwDAj = True
   errTxt = ""
  else:
   self.VV5xyV  = ""
   self.VVwDAj = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVi6iF(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVtzSE
  else          : return val, VV13Hf
 def VVcnAe(self):
  if not self.VVwDAj:
   FF2wyP(self, "Please fix Control File errors first.")
   return
  if self.VVIK38: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFG47Q(self.VVMbdt, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVFnrR
  symlinkTo  = FFKGzo(self.Path)
  dataDir   = self.VVMbdt.rstrip("/")
  removePorjDir = FFiu56("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFiu56("rm -f '%s'" % self.VV5xyV) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFCv1g()
  if self.VVIK38:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFevla("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVFmVa:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVMbdt == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VV32ei)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VV5xyV, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VV5xyV
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VV5xyV, FF23Tm(result  , VVplBl))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVMbdt, FF23Tm(instPath, VVtzSE))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FF23Tm(failed, VV13Hf))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFHbvq(self, cmd)
class CC82J5(Screen):
 VVP8DH   = 0
 VVXr5v  = 1
 VVlyj7 = 20
 VVEIWM  = None
 def __init__(self, session, VV3wnF="/", mode=VVP8DH, VV6bxt="Select", VVCZ7I=30, gotoMovie=False):
  self.skin, self.skinParam = FF82u7(VVyaPF, 1400, 920, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFFsOT(self)
  FFydgK(self["keyRed"] , "Exit")
  FFydgK(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VV6bxt = VV6bxt
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  CC82J5.VVEIWM = self
  if   self.gotoMovie        : VVCQ4g, self.VV3wnF = True , CC82J5.VVCYXm(self)[1] or "/"
  elif self.mode == self.VVP8DH  : VVCQ4g, self.VV3wnF = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVXr5v : VVCQ4g, self.VV3wnF = False, VV3wnF
  else           : VVCQ4g, self.VV3wnF = True , VV3wnF
  self.VV3wnF = FFwI5c(self.VV3wnF)
  self["myMenu"] = CCEEgX(  directory   = "/"
         , VVCQ4g   = VVCQ4g
         , VVEXpL = True
         , VVmeUs   = self.skinParam["width"]
         , VVCZ7I   = self.skinParam["bodyFontSize"]
         , VVDe7d  = self.skinParam["bodyLineH"]
         , VVyKM6  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVIpBc      ,
   "red"    : self.VV6Zbe     ,
   "green"    : self.VVJBma    ,
   "yellow"   : self.VV1yUk   ,
   "blue"    : self.VVIoOF   ,
   "menu"    : self.VV0ncf    ,
   "info"    : self.VVmNDe    ,
   "cancel"   : self.VV4MJ0     ,
   "pageUp"   : self.VV4MJ0     ,
   "chanUp"   : self.VV4MJ0
  }, -1)
  FFXMHc(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVwpu1)
 def onExit(self):
  CC82J5.VVEIWM = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVwpu1)
  FFBLtF(self)
  FFEktE(self["myMenu"], bg="#06003333")
  FFNepU(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode == self.VVXr5v:
   FFydgK(self["keyGreen"], self.VV6bxt)
   color = "#22000022"
   FFpqr2(self["myBody"], color)
   FFpqr2(self["myMenu"], color)
   color = "#22220000"
   FFpqr2(self["myTitle"], color)
   FFpqr2(self["myBar"], color)
  self.VVwpu1()
  if self.VVNqsO(self.VV3wnF) > self.bigDirSize:
   FFbstz(self, "Changing directory...")
   FFHmgI(self.VVhXOZ)
  else:
   self.VVhXOZ()
 def VVhXOZ(self):
  self["myMenu"].VV3EGi(self.VV3wnF)
  if self.gotoMovie:
   self.VVK9Ji(chDir=False)
 def VVupmb(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVYccf(self):
  self["myMenu"].refresh()
  FFdk6f()
 def VVNqsO(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VVIpBc(self):
  if self["myMenu"].VVbnsL():
   path = self.VVHFiN(self.VVfilj())
   if self.VVNqsO(path) > self.bigDirSize:
    FFbstz(self, "Changing directory...")
    FFHmgI(self.VVRl0F)
   else:
    self.VVRl0F()
  else:
   self.VV4s8x()
 def VVRl0F(self):
  self["myMenu"].descent()
  self.VVwpu1()
 def VV4MJ0(self):
  if self["myMenu"].VVWDgL():
   self["myMenu"].moveToIndex(0)
   self.VVRl0F()
 def VV6Zbe(self):
  if not FFzWzb(self):
   self.close("")
 def VVJBma(self):
  if self.mode == self.VVXr5v:
   path = self.VVHFiN(self.VVfilj())
   self.close(path)
 def VVmNDe(self):
  FFmTns(self, self.VVdb2K, title="Calculating size ...")
 def VVdb2K(self):
  path = self.VVHFiN(self.VVfilj())
  param = self.VVXyf6(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFSDWT("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CC82J5.VVZGqg(path)
     freeSize = CC82J5.VV1sQ2(path)
     size = totSize - freeSize
     totSize  = CC82J5.VVnDM5(totSize)
     freeSize = CC82J5.VVnDM5(freeSize)
    else:
     size = FFSDWT("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CC82J5.VVnDM5(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFFpMs(pathTxt, VVi1SQ) + "\n"
   if slBroken : fileTime = self.VVlmTA(path)
   else  : fileTime = self.VV0i5U(path)
   def VValCD(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VValCD("Path"    , pathTxt)
   txt += VValCD("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VValCD("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VValCD("Total Size"   , "%s" % totSize)
    txt += VValCD("Used Size"   , "%s" % usedSize)
    txt += VValCD("Free Size"   , "%s" % freeSize)
   else:
    txt += VValCD("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VValCD("Owner"    , owner)
   txt += VValCD("Group"    , group)
   txt += VValCD("Perm. (User)"  , permUser)
   txt += VValCD("Perm. (Group)"  , permGroup)
   txt += VValCD("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VValCD("Perm. (Ext.)" , permExtra)
   txt += VValCD("iNode"    , iNode)
   txt += VValCD("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVo4vY, VVo4vY)
    txt += hLinkedFiles
   txt += self.VVSqAm(path)
  else:
   FF2wyP(self, "Cannot access information !")
  if len(txt) > 0:
   FFHVXB(self, txt)
 def VVXyf6(self, path):
  path = path.strip()
  path = FFKGzo(path)
  result = FFSDWT("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVZbQZ(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVZbQZ(perm, 1, 4)
   permGroup = VVZbQZ(perm, 4, 7)
   permOther = VVZbQZ(perm, 7, 10)
   permExtra = VVZbQZ(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFktqw("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVSqAm(self, path):
  txt  = ""
  res  = FFSDWT("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFFpMs("File Attributes:", VVZj00), txt)
  return txt
 def VV0i5U(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FF0V0A(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FF0V0A(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FF0V0A(os.path.getctime(path))
  return txt
 def VVlmTA(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFSDWT("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFSDWT("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFSDWT("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVHFiN(self, currentSel):
  currentDir  = self["myMenu"].VVWDgL()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVbnsL():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVfilj(self):
  return self["myMenu"].getSelection()[0]
 def VVwpu1(self):
  FFbstz(self)
  path = self.VVHFiN(self.VVfilj())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VV2PlJ = self.VVh9ij()
  if VV2PlJ and len(VV2PlJ) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VV2q15(path)
  if self.mode == self.VVP8DH and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
 def VV2q15(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVRfwV(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VV0ncf(self):
  if self.mode == self.VVP8DH:
   path  = self.VVHFiN(self.VVfilj())
   isDir  = os.path.isdir(path)
   VVhOvi = []
   VVhOvi.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVfHwC(path):
     sepShown = True
     VVhOvi.append(VVaOJ8)
     VVhOvi.append( (VVi1SQ + "Archiving / Packaging"      , "VVI0So"  ))
    if self.VVup81(path):
     if not sepShown:
      VVhOvi.append(VVaOJ8)
     VVhOvi.append( (VVi1SQ + "Read Backup information"     , "VV13TJ"  ))
     VVhOvi.append( (VVi1SQ + "Compress Octagon Image (to zip File)"  , "VVTcva" ))
   elif os.path.isfile(path):
    selFile = self.VVfilj()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar")) : VVhOvi.extend(self.VVaT8c(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVhOvi.extend(self.VVCyS7(True))
    elif selFile.endswith(".m3u")              : VVhOvi.extend(self.VVdIv8(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FFAGME(path):
     VVhOvi.append(VVaOJ8)
     VVhOvi.append((VVi1SQ + "View"     , "textView_def" ))
     VVhOvi.append((VVi1SQ + "View (Select Encoder)" , "textView_enc" ))
     VVhOvi.append((VVi1SQ + "Edit"     , "text_Edit"  ))
    if len(txt) > 0:
     VVhOvi.append(VVaOJ8)
     VVhOvi.append(   (VVi1SQ + txt      , "VV4s8x"  ))
   VVhOvi.append(VVaOJ8)
   VVhOvi.append(     ("Create SymLink"       , "VV9v1j" ))
   if not self.VVfHwC(path):
    VVhOvi.append(   ("Rename"          , "VVCof2" ))
    VVhOvi.append(   ("Copy"           , "copyFileOrDir" ))
    VVhOvi.append(   ("Move"           , "moveFileOrDir" ))
    VVhOvi.append(   ("DELETE"          , "VV15RN" ))
    if fileExists(path):
     VVhOvi.append(VVaOJ8)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVhOvi.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVhOvi.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVhOvi.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVhOvi.append(VVaOJ8)
   VVhOvi.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVhOvi.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CC82J5.VVCYXm(self)
   if fPath:
    VVhOvi.append(VVaOJ8)
    VVhOvi.append(   (VVqWH2 + "Go to current movie"  , "VVK9Ji"))
   VVhOvi.append(VVaOJ8)
   VVhOvi.append(    ("Set current directory as \"Startup Path\"" , "VVFxO9" ))
   FFN6sa(self, self.VVYbDy, title="Options", VVhOvi=VVhOvi)
 def VVYbDy(self, item=None):
  if self.mode == self.VVP8DH:
   if item is not None:
    path = self.VVHFiN(self.VVfilj())
    selFile = self.VVfilj()
    if   item == "properties"    : self.VVmNDe()
    elif item == "VVI0So"  : self.VVI0So(path)
    elif item == "VV13TJ"  : self.VV13TJ(path)
    elif item == "VVTcva" : self.VVTcva(path)
    elif item.startswith("extract_")  : self.VVTMXe(path, selFile, item)
    elif item.startswith("script_")   : self.VVTT4u(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVBFoSItem_m3u(path, selFile, item)
    elif item.startswith("textView_def") : FFxImT(self, path)
    elif item.startswith("textView_enc") : self.VV9UvM(path)
    elif item.startswith("text_Edit")  : CCtRew(self, path)
    elif item == "chmod644"     : self.VVEpPS(path, selFile, "644")
    elif item == "chmod755"     : self.VVEpPS(path, selFile, "755")
    elif item == "chmod777"     : self.VVEpPS(path, selFile, "777")
    elif item == "VV9v1j"   : self.VV9v1j(path, selFile)
    elif item == "VVCof2"   : self.VVCof2(path, selFile)
    elif item == "copyFileOrDir"   : self.VVfw8V(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVfw8V(path, selFile, True)
    elif item == "VV15RN"   : self.VV15RN(path, selFile)
    elif item == "createNewFile"   : self.VVi3AS(path, True)
    elif item == "createNewDir"    : self.VVi3AS(path, False)
    elif item == "VVK9Ji"   : self.VVK9Ji()
    elif item == "VVFxO9"   : self.VVFxO9(path)
    elif item == "VV4s8x"    : self.VV4s8x()
    else         : self.close()
 def VV4s8x(self):
  selFile = self.VVfilj()
  path  = self.VVHFiN(selFile)
  if os.path.isfile(path):
   VVlQdH = []
   category = self["myMenu"].VVwttk(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVqWMl(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FF5Tue(self, selFile, path)
   elif category == "txt"         : FFxImT(self, path)
   elif category in ("tar", "zip", "rar")     : self.VVEuVz(path, selFile)
   elif category == "scr"         : self.VVcimC(path, selFile)
   elif category == "m3u"         : self.VVZ9aJ(path, selFile)
   elif category in ("ipk", "deb")       : self.VVFHLU(path, selFile)
   elif category == "mus"         : self.VVsepf(self, path)
   elif category == "mov"         : self.VVsepf(self, path)
   elif not FFAGME(path)        : FFxImT(self, path)
 def VV1yUk(self):
  path = self.VVHFiN(self.VVfilj())
  action = self.VV2q15(path)
  if action == 1:
   self.VVo0oG(path)
   FFbstz(self, "Added", 500)
  elif action == -1:
   self.VVyGuL(path)
   FFbstz(self, "Removed", 500)
  self.VV2q15(path)
 def VVo0oG(self, path):
  VV2PlJ = self.VVh9ij()
  if not VV2PlJ:
   VV2PlJ = []
  if len(VV2PlJ) >= self.VVlyj7:
   FF2wyP(SELF, "Max bookmarks reached (max=%d)." % self.VVlyj7)
  elif not path in VV2PlJ:
   VV2PlJ = [path] + VV2PlJ
   self.VVBzS8(VV2PlJ)
 def VVIoOF(self):
  VV2PlJ = self.VVh9ij()
  if VV2PlJ:
   newList = []
   for line in VV2PlJ:
    newList.append((line, line))
   VVd2z3  = ("Delete"  , self.VVmT38 )
   VVyt0G = ("Move Up"   , self.VVFWfy )
   VVmwoc  = ("Move Down" , self.VVIQwZ )
   self.bookmarkMenu = FFN6sa(self, self.VVAyi2, title="Bookmarks", VVhOvi=newList, VVd2z3=VVd2z3, VVyt0G=VVyt0G, VVmwoc=VVmwoc)
 def VVmT38(self, VVfiljObj, path):
  if self.bookmarkMenu:
   VV2PlJ = self.VVyGuL(path)
   self.bookmarkMenu.VVckx8(VV2PlJ)
 def VVFWfy(self, VVfiljObj, path):
  if self.bookmarkMenu:
   VV2PlJ = self.bookmarkMenu.VVc4h0(True)
   if VV2PlJ:
    self.VVBzS8(VV2PlJ)
 def VVIQwZ(self, VVfiljObj, path):
  if self.bookmarkMenu:
   VV2PlJ = self.bookmarkMenu.VVc4h0(False)
   if VV2PlJ:
    self.VVBzS8(VV2PlJ)
 def VVAyi2(self, folder=None):
  if folder:
   folder = FFwI5c(folder)
   self["myMenu"].VV3EGi(folder)
   self["myMenu"].moveToIndex(0)
  self.VVwpu1()
 def VVh9ij(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVRfwV(self, path):
  VV2PlJ = self.VVh9ij()
  if VV2PlJ and path in VV2PlJ:
   return True
  else:
   return False
 def VVIPie(self):
  if VVh9ij():
   return True
  else:
   return False
 def VVBzS8(self, VV2PlJ):
  line = ",".join(VV2PlJ)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVyGuL(self, path):
  VV2PlJ = self.VVh9ij()
  if VV2PlJ:
   while path in VV2PlJ:
    VV2PlJ.remove(path)
   self.VVBzS8(VV2PlJ)
   return VV2PlJ
 def VVK9Ji(self, chDir=True):
  fPath, fDir, fName = CC82J5.VVCYXm(self)
  if fPath:
   if chDir:
    self["myMenu"].VV3EGi(fDir)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFbstz(self, "Not found", 1000)
 def VVFxO9(self, path):
  if not os.path.isdir(path):
   path = FFG47Q(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVqWMl(self, selFile, VVxngl, command):
  FFStgm(self, boundFunction(FFHbvq, self, command, VV8KYv=self.VVYccf), "%s\n\n%s" % (VVxngl, selFile))
 def VVaT8c(self, path, calledFromMenu):
  destPath = self.VVKrJo(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVhOvi = []
  if calledFromMenu:
   VVhOvi.append(VVaOJ8)
   color = VVi1SQ
  else:
   color = ""
  VVhOvi.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVhOvi.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVhOvi.append((color + "Extract Here"            , "extract_here"  ))
  if VVJtGD and path.endswith(".tar.gz"):
   VVhOvi.append(VVaOJ8)
   VVhOvi.append((color + 'Convert to ".ipk" Package' , "VVgPym"  ))
   VVhOvi.append((color + 'Convert to ".deb" Package' , "VVMqCN"  ))
  return VVhOvi
 def VVEuVz(self, path, selFile):
  FFN6sa(self, boundFunction(self.VVTMXe, path, selFile), title="Compressed File Options", VVhOvi=self.VVaT8c(path, False))
 def VVTMXe(self, path, selFile, item=None):
  if item is not None:
   parent  = FFG47Q(path, False)
   destPath = self.VVKrJo(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVo4vY
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFevla("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFevla("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVo4vY, VVo4vY)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFS0Ql(self, cmd)
   elif path.endswith(".zip"):
    self.VVaHv0(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif path.endswith(".rar"):
    self.VVnBzY(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFiu56("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVqWMl(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVqWMl(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFG47Q(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVqWMl(selFile, "Extract Here ?"      , cmd)
   elif item == "VVgPym" : self.VVgPym(path)
   elif item == "VVMqCN" : self.VVMqCN(path)
 def VVKrJo(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVaHv0(self, item, path, parent, destPath, VVxngl):
  FFStgm(self, boundFunction(self.VViPCs, item, path, parent, destPath), VVxngl)
 def VViPCs(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVo4vY
  cmd  = FFevla("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FF23Tm(destPath, VVplBl))
  cmd +=   sep
  cmd += "fi;"
  FFpX68(self, cmd, VV8KYv=self.VVYccf)
 def VVnBzY(self, item, path, parent, destPath, VVxngl):
  FFStgm(self, boundFunction(self.VVC3IT, item, path, parent, destPath), VVxngl)
 def VVC3IT(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFwI5c(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVo4vY
  cmd  = FFevla("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FF23Tm(destPath, VVplBl))
  cmd +=   sep
  cmd += "fi;"
  FFpX68(self, cmd, VV8KYv=self.VVYccf)
 def VVCyS7(self, addSep=False):
  VVhOvi = []
  if addSep:
   VVhOvi.append(VVaOJ8)
  VVhOvi.append((VVi1SQ + "View Script File"  , "script_View"  ))
  VVhOvi.append((VVi1SQ + "Execute Script File" , "script_Execute" ))
  VVhOvi.append((VVi1SQ + "Edit"     , "script_Edit" ))
  return VVhOvi
 def VVcimC(self, path, selFile):
  FFN6sa(self, boundFunction(self.VVTT4u, path, selFile), title="Script File Options", VVhOvi=self.VVCyS7())
 def VVTT4u(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFxImT(self, path)
   elif item == "script_Execute" : self.VVqWMl(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCtRew(self, path)
 def VVdIv8(self, addSep=False):
  VVhOvi = []
  if addSep:
   VVhOvi.append(VVaOJ8)
  VVhOvi.append((VVi1SQ + "Browse IPTV Channels"  , "m3u_Browse" ))
  VVhOvi.append((VVi1SQ + "Edit"      , "m3u_Edit" ))
  VVhOvi.append((VVi1SQ + "View"      , "m3u_View" ))
  return VVhOvi
 def VVZ9aJ(self, path, selFile):
  FFN6sa(self, boundFunction(self.VVBFoSItem_m3u, path, selFile), title="M3U/M3U8 File Options", VVhOvi=self.VVdIv8())
 def VVBFoSItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFmTns(self, boundFunction(self.session.open, CCniMM, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCtRew(self, path)
   elif item == "m3u_View"  : FFxImT(self, path)
 def VV9UvM(self, path):
  if fileExists(path) : FFmTns(self, boundFunction(CCy6sJ.VVsT4r, self, path, boundFunction(self.VVGhnX, path), defEnc=None), title="Loading Codecs ...", clearMsg=False)
  else    : FFUQ3Z(self, path)
 def VVGhnX(self, path, item=None):
  if item:
   FFxImT(self, path, encLst=item)
 def VVEpPS(self, path, selFile, newChmod):
  FFStgm(self, boundFunction(self.VVEGrF, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVEGrF(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVs1qJ)
  result = FFSDWT(cmd)
  if result == "Successful" : FFnN3Y(self, result)
  else      : FF2wyP(self, result)
 def VV9v1j(self, path, selFile):
  parent = FFG47Q(path, False)
  self.session.openWithCallback(self.VVS2VC, boundFunction(CC82J5, mode=CC82J5.VVXr5v, VV3wnF=parent, VV6bxt="Create Symlink here"))
 def VVS2VC(self, newPath):
  if len(newPath) > 0:
   target = self.VVHFiN(self.VVfilj())
   target = FFKGzo(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFwI5c(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FF2wyP(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFStgm(self, boundFunction(self.VVk4nG, target, link), "Create Soft Link ?\n\n%s" % txt, VVU3wZ=True)
 def VVk4nG(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVs1qJ)
  result = FFSDWT(cmd)
  if result == "Successful" : FFnN3Y(self, result)
  else      : FF2wyP(self, result)
 def VVCof2(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFK2QC(self, boundFunction(self.VVkBik, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVkBik(self, path, selFile, VVa0Z4):
  if VVa0Z4:
   parent = FFG47Q(path, True)
   if os.path.isdir(path):
    path = FFKGzo(path)
   newName = parent + VVa0Z4
   cmd = "mv '%s' '%s' %s" % (path, newName, VVs1qJ)
   if VVa0Z4:
    if selFile != VVa0Z4:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFStgm(self, boundFunction(self.VVdNHb, cmd), message, title="Rename file?")
    else:
     FF2wyP(self, "Cannot use same name!", title="Rename")
 def VVdNHb(self, cmd):
  result = FFSDWT(cmd)
  if "Fail" in result:
   FF2wyP(self, result)
  self.VVYccf()
 def VVfw8V(self, path, selFile, isMove):
  if isMove : VV6bxt = "Move to here"
  else  : VV6bxt = "Copy to here"
  parent = FFG47Q(path, False)
  self.session.openWithCallback(boundFunction(self.VVIItI, isMove, path, selFile)
         , boundFunction(CC82J5, mode=CC82J5.VVXr5v, VV3wnF=parent, VV6bxt=VV6bxt))
 def VVIItI(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFKGzo(path)
   newPath = FFwI5c(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFStgm(self, boundFunction(FFZ9oT, self, cmd, VV8KYv=self.VVYccf), txt, VVU3wZ=True)
   else:
    FF2wyP(self, "Cannot %s to same directory !" % action.lower())
 def VV15RN(self, path, fileName):
  path = FFKGzo(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFStgm(self, boundFunction(self.VVzSQB, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVzSQB(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VVYccf()
 def VVfHwC(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVPjL0 and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVi3AS(self, path, isFile):
  dirName = FFwI5c(os.path.dirname(path))
  if isFile : objName, VVa0Z4 = "File"  , self.edited_newFile
  else  : objName, VVa0Z4 = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFK2QC(self, boundFunction(self.VVIQXO, dirName, isFile, title), title=title, defaultText=VVa0Z4, message="Enter %s Name:" % objName)
 def VVIQXO(self, dirName, isFile, title, VVa0Z4):
  if VVa0Z4:
   if isFile : self.edited_newFile = VVa0Z4
   else  : self.edited_newDir  = VVa0Z4
   path = dirName + VVa0Z4
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVs1qJ)
    else  : cmd = "mkdir '%s' %s" % (path, VVs1qJ)
    result = FFSDWT(cmd)
    if "Fail" in result:
     FF2wyP(self, result)
    self.VVYccf()
   else:
    FF2wyP(self, "Name already exists !\n\n%s" % path, title)
 def VVFHLU(self, path, selFile):
  VVhOvi = []
  VVhOvi.append(("List Package Files"          , "VVbmdD"     ))
  VVhOvi.append(("Package Information"          , "VVHJTD"     ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Install Package"           , "VVSgP7_CheckVersion" ))
  VVhOvi.append(("Install Package (force reinstall)"      , "VVSgP7_ForceReinstall" ))
  VVhOvi.append(("Install Package (force overwrite)"      , "VVSgP7_ForceOverwrite" ))
  VVhOvi.append(("Install Package (force downgrade)"      , "VVSgP7_ForceDowngrade" ))
  VVhOvi.append(("Install Package (ignore failed dependencies)"    , "VVSgP7_IgnoreDepends" ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Remove Related Package"         , "VVzGBR_ExistingPackage" ))
  VVhOvi.append(("Remove Related Package (force remove)"     , "VVzGBR_ForceRemove"  ))
  VVhOvi.append(("Remove Related Package (ignore failed dependencies)"  , "VVzGBR_IgnoreDepends" ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Extract Files"           , "VVfz8y"     ))
  VVhOvi.append(("Unbuild Package"           , "VVpxIG"     ))
  FFN6sa(self, boundFunction(self.VV1OQw, path, selFile), VVhOvi=VVhOvi)
 def VV1OQw(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVbmdD"      : self.VVbmdD(path, selFile)
   elif item == "VVHJTD"      : self.VVHJTD(path)
   elif item == "VVSgP7_CheckVersion"  : self.VVSgP7(path, selFile, VVIqrC     )
   elif item == "VVSgP7_ForceReinstall" : self.VVSgP7(path, selFile, VVwEDD )
   elif item == "VVSgP7_ForceOverwrite" : self.VVSgP7(path, selFile, VVzcHK )
   elif item == "VVSgP7_ForceDowngrade" : self.VVSgP7(path, selFile, VVVmdf )
   elif item == "VVSgP7_IgnoreDepends" : self.VVSgP7(path, selFile, VVCbLd )
   elif item == "VVzGBR_ExistingPackage" : self.VVzGBR(path, selFile, VVhJVe     )
   elif item == "VVzGBR_ForceRemove"  : self.VVzGBR(path, selFile, VVmguF  )
   elif item == "VVzGBR_IgnoreDepends"  : self.VVzGBR(path, selFile, VVHkLQ )
   elif item == "VVfz8y"     : self.VVfz8y(path, selFile)
   elif item == "VVpxIG"     : self.VVpxIG(path, selFile)
   else           : self.close()
 def VVbmdD(self, path, selFile):
  if FFrgtg("ar") : cmd = "allOK='1';"
  else    : cmd  = FFCv1g()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVo4vY, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVo4vY, VVo4vY)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FF6wP8(self, cmd, VV8KYv=self.VVYccf)
 def VVfz8y(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFG47Q(path, True) + selFile[:-4]
  cmd  =  FFCv1g()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFiu56("mkdir '%s'" % dest) + ";"
  cmd +=    FFiu56("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FF23Tm(dest, VVplBl))
  cmd += "fi;"
  FFHbvq(self, cmd, VV8KYv=self.VVYccf)
 def VVpxIG(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVMnWt = os.path.splitext(path)[0]
  else        : VVMnWt = path + "_"
  if path.endswith(".deb")   : VV32ei = "DEBIAN"
  else        : VV32ei = "CONTROL"
  cmd  = FFCv1g()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVMnWt, FF5kRq())
  cmd += "  mkdir '%s';"    % VVMnWt
  cmd += "  CONTPATH='%s/%s';"  % (VVMnWt, VV32ei)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVMnWt
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVMnWt, VVMnWt)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVMnWt
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVMnWt, VVMnWt)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVMnWt
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVMnWt
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVMnWt, FF23Tm(VVMnWt, VVplBl))
  cmd += "fi;"
  FFHbvq(self, cmd, VV8KYv=self.VVYccf)
 def VVHJTD(self, path):
  listCmd  = FFSU1Z(VV4I1T, "")
  infoCmd  = FF5ENR(VVZCfy , "")
  filesCmd = FF5ENR(VVQ3or, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFQbM5(VVqWH2)
   notInst = "Package not installed."
   cmd  = FFRcES("File Info", VVqWH2)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFRcES("System Info", VVqWH2)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FF23Tm(notInst, VVi1SQ))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFRcES("Related Files", VVqWH2)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFS0Ql(self, cmd)
  else:
   FFAopx(self)
 def VVSgP7(self, path, selFile, cmdOpt):
  cmd = FF5ENR(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFStgm(self, boundFunction(FFHbvq, self, cmd, VV8KYv=FFdk6f), "Install Package ?\n\n%s" % selFile)
  else:
   FFAopx(self)
 def VVzGBR(self, path, selFile, cmdOpt):
  listCmd  = FFSU1Z(VV4I1T, "")
  infoCmd  = FF5ENR(VVZCfy, "")
  instRemCmd = FF5ENR(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FF23Tm(errTxt, VVi1SQ))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FF23Tm(cannotTxt, VVi1SQ))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FF23Tm(tryTxt, VVi1SQ))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFStgm(self, boundFunction(FFHbvq, self, cmd, VV8KYv=FFdk6f), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFAopx(self)
 def VVPMDg(self, path):
  hostName = FFSDWT("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVup81(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVPMDg(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVI0So(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVhOvi = []
  VVhOvi.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVhOvi.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVhOvi.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVhOvi.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVhOvi.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVhOvi.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVhOvi.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVhOvi.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVhOvi.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVhOvi.append(VVaOJ8)
  VVhOvi.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVhOvi.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FFN6sa(self, boundFunction(self.VVyn6W, path), VVhOvi=VVhOvi)
 def VVyn6W(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVvsR2(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVvsR2(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVvsR2(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVvsR2(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVvsR2(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVvsR2(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVvsR2(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVvsR2(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVvsR2(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVvsR2(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVHxCf(path, False)
   elif item == "convertDirToDeb"   : self.VVHxCf(path, True)
   else         : self.close()
 def VVHxCf(self, path, VVIK38):
  self.session.openWithCallback(self.VVYccf, boundFunction(CCIPZZ, path=path, VVIK38=VVIK38))
 def VVvsR2(self, path, fileExt, preserveDirStruct):
  parent  = FFG47Q(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFevla("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFevla("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFevla("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVo4vY
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFiu56("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FF23Tm(resultFile, VVplBl))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FF23Tm(failed, VV13Hf))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FF6wP8(self, cmd, VV8KYv=self.VVYccf)
 def VV13TJ(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFxImT(self, versionFile)
 def VVTcva(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVPMDg(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FF2wyP(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFQoVo(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFG47Q(path, False)
  VVMnWt = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FF23Tm(errCmd, VV13Hf))
  installCmd = FF5ENR(VVIqrC , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VVMnWt, VVMnWt)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VVMnWt
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VVMnWt
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VVMnWt, VVMnWt)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFHbvq(self, cmd, VV8KYv=self.VVYccf)
 def VVgPym(self, path):
  FF2wyP(self, "Under Construction.")
 def VVMqCN(self, path):
  FF2wyP(self, "Under Construction.")
 @staticmethod
 def VVsepf(SELF, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   SELF.session.open(CCrMvG, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVCYXm(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFwI5c(fDir), fName
  return "", "", ""
 @staticmethod
 def VVZGqg(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VV1sQ2(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVnDM5(size, mode=0):
  txt = CC82J5.VViGvI(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VViGvI(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
class CCEEgX(MenuList):
 def __init__(self, VVEXpL=False, directory="/", VVc4Ih=True, VVCQ4g=True, VV0ewO=True, VVc7qo=None, VVabAZ=False, VVPS54=False, VVWvmW=False, isTop=False, VVu1PF=None, VVmeUs=1000, VVCZ7I=30, VVDe7d=30, VVyKM6="#00000000"):
  MenuList.__init__(self, list, VVEXpL, eListboxPythonMultiContent)
  self.VVc4Ih  = VVc4Ih
  self.VVCQ4g    = VVCQ4g
  self.VV0ewO  = VV0ewO
  self.VVc7qo  = VVc7qo
  self.VVabAZ   = VVabAZ
  self.VVPS54   = VVPS54 or []
  self.VVWvmW   = VVWvmW or []
  self.isTop     = isTop
  self.additional_extensions = VVu1PF
  self.VVmeUs    = VVmeUs
  self.VVCZ7I    = VVCZ7I
  self.VVDe7d    = VVDe7d
  self.pngBGColor    = FFp86o(VVyKM6)
  self.EXTENSIONS    = self.VVYqLO()
  self.VV4lW6   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVg54i, self.VVCZ7I))
  self.l.setItemHeight(self.VVDe7d)
  self.png_mem   = self.VVm9kb("mem")
  self.png_usb   = self.VVm9kb("usb")
  self.png_fil   = self.VVm9kb("fil")
  self.png_dir   = self.VVm9kb("dir")
  self.png_dirup   = self.VVm9kb("dirup")
  self.png_srv   = self.VVm9kb("srv")
  self.png_slwfil   = self.VVm9kb("slwfil")
  self.png_slbfil   = self.VVm9kb("slbfil")
  self.png_slwdir   = self.VVm9kb("slwdir")
  self.VVX4Fu()
  self.VV3EGi(directory)
 def VVm9kb(self, category):
  return LoadPixmap("%s%s.png" % (VVoH8d, category), getDesktop(0))
 def VVYqLO(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "rar" : "rar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u" ,
   "m3u8" : "m3u"
  }
 def VVt0sx(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFKGzo(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFFpMs(" -> " , VVqWH2) + FFFpMs(os.readlink(path), VVplBl)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVDe7d + 10, 0, self.VVmeUs, self.VVDe7d, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVwuVG: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVDe7d-4, self.VVDe7d-4, png, self.pngBGColor, self.pngBGColor, VVwuVG))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVDe7d-4, self.VVDe7d-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVwttk(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVX4Fu(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VViCVY(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVxylO(self, file):
  if os.path.realpath(file) == file:
   return self.VViCVY(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VViCVY(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VViCVY(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVV23m(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VV4lW6.info(l[0][0]).getEvent(l[0][0])
 def VVRDAt(self):
  return self.list
 def VV6Qq0(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VV3EGi(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VV0ewO:
    self.current_mountpoint = self.VVxylO(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VV0ewO:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVWvmW and not self.VV6Qq0(path, self.VVPS54):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVt0sx(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVabAZ:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VV4lW6 = eServiceCenter.getInstance()
   list = VV4lW6.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVc4Ih and not self.isTop:
   if directory == self.current_mountpoint and self.VV0ewO:
    self.list.append(self.VVt0sx(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVWvmW and self.VViCVY(directory) in self.VVWvmW):
    self.list.append(self.VVt0sx(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVc4Ih:
   for x in directories:
    if not (self.VVWvmW and self.VViCVY(x) in self.VVWvmW) and not self.VV6Qq0(x, self.VVPS54):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVt0sx(name = name, absolute = x, isDir = True, png = png))
  if self.VVCQ4g:
   for x in files:
    if self.VVabAZ:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFFpMs(" -> " , VVqWH2) + FFFpMs(target, VVplBl)
       else:
        png = self.png_slbfil
        name += FFFpMs(" -> " , VVqWH2) + FFFpMs(target, VV13Hf)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVwttk(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVoH8d, category))
    if (self.VVc7qo is None) or iCompile(self.VVc7qo).search(path):
     self.list.append(self.VVt0sx(name = name, absolute = x , isDir = False, png = png))
  if self.VV0ewO and len(self.list) == 0:
   self.list.append(self.VVt0sx(name = FFFpMs("No USB connected", VV5UCJ), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVWDgL(self):
  return self.current_directory
 def VVbnsL(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VV3EGi(self.getSelection()[0], select = self.current_directory)
 def VV6sSA(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VV76mv(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVOi54)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVOi54)
 def refresh(self):
  self.VV3EGi(self.current_directory, self.VV6sSA())
 def VVOi54(self, action, device):
  self.VVX4Fu()
  if self.current_directory is None:
   self.refresh()
class CC1ykL(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FF82u7(VVNO1G, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VV2PlJ   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVOb4h(defFG, "#00FFFFFF")
  self.defBG   = self.VVOb4h(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFFsOT(self, self.Title)
  self["keyRed"].show()
  FFydgK(self["keyGreen"] , "< > Transp.")
  FFydgK(self["keyYellow"], "Foreground")
  FFydgK(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVus3j        ,
   "yellow"   : boundFunction(self.VVbIqI, False)  ,
   "blue"   : boundFunction(self.VVbIqI, True)  ,
   "up"   : self.VVZja3          ,
   "down"   : self.VVg9ls         ,
   "left"   : self.VVQoKD         ,
   "right"   : self.VVM1hH         ,
   "last"   : boundFunction(self.VV329n, -5) ,
   "next"   : boundFunction(self.VV329n, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFpqr2(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFpqr2(self["keyRed"] , c)
  FFpqr2(self["keyGreen"] , c)
  self.VVAeen()
  self.VVdxfW()
  FFxrbm(self["myColorTst"], self.defFG)
  FFpqr2(self["myColorTst"], self.defBG)
 def VVOb4h(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVdxfW(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVnVaX(0, 0)
     return
 def VVus3j(self):
  self.close(self.defFG, self.defBG)
 def VVZja3(self): self.VVnVaX(-1, 0)
 def VVg9ls(self): self.VVnVaX(1, 0)
 def VVQoKD(self): self.VVnVaX(0, -1)
 def VVM1hH(self): self.VVnVaX(0, 1)
 def VVnVaX(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVkPsa()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVQaXG()
 def VVAeen(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVQaXG(self):
  color = self.VVkPsa()
  if self.isBgMode: FFpqr2(self["myColorTst"], color)
  else   : FFxrbm(self["myColorTst"], color)
 def VVbIqI(self, isBg):
  self.isBgMode = isBg
  self.VVAeen()
  self.VVdxfW()
 def VV329n(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVnVaX(0, 0)
 def VVCiMq(self):
  return hex(self.transp)[2:].zfill(2)
 def VVkPsa(self):
  return ("#%s%s" % (self.VVCiMq(), self.colors[self.curRow][self.curCol])).upper()
class CCdqgc(Screen):
 VVZURx  = 0
 VVJkHR = 1
 def __init__(self, session, mode, endCallback):
  self.session  = session
  margin    = 50
  screenSize   = FFbp9X()
  w     = int(screenSize[0] - margin)
  h     = int(screenSize[1] / 2.0)
  self.skin, self.skinParam = FF82u7(WINDOW_SUBTITLE, w, h, 35, 20, 30, "#ff000000", "#ff000000", 60)
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.currentIndex  = -1
  self.subtitleMode  = mode
  self.defaultY   = 0
  self.endCallback  = endCallback
  FFFsOT(self)
  self["myTitle"].hide()
  self["mySubtFr"] = Label()
  self["mySubtFr"].hide()
  for i in range(3):
   self["mySubt%d" % i] = Label()
 def VV6PES(self, path=""):
  if path :
   self.VV0azq()
   FFmTns(self, boundFunction(self.VVvGv3, path), title="Checking file ...", clearMsg=False)
  else:
   self.VVvGv3()
 def VVvGv3(self, path=""):
  if path:
   subtList, err = self.VV6nW0(path)
   if err    : self.VVwCeD(err)
   elif not subtList : self.VVwCeD("Invalid srt file")
   else    :
    self.subtList = subtList
    self.VVhTxG()
  else:
   if self.VVfUuJ():
    self.VVhTxG()
   elif self.subtitleMode == CCdqgc.VVJkHR:
    self.VVwCeD("noResume")
   else:
    if self.VVr4OM(): self.VVhTxG()
    else         : self.VVwCeD("noAutoSrt")
 def VVhTxG(self):
  try:
   InfoBar.instance.enableSubtitle(None)
  except:
   try:
    InfoBar.instance.setSubtitlesEnable(False)
   except:
    pass
  FFbstz(self, "Subtitle started", 1000, isGrn=True)
  self.VV0azq()
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVJKWt)
  except:
   self.timerUpdate.callback.append(self.VVJKWt)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVcjE2)
  except:
   self.timerEndText.callback.append(self.VVcjE2)
  self.VVmtM0()
 def VVwCeD(self, res=""):
  self.timerUpdate.stop()
  self.timerEndText.stop()
  self.VV76a4()
  self.endCallback(res)
 def VVfUuJ(self):
  fPath, fDir, fName = CC82J5.VVCYXm(self)
  if fPath:
   path = fPath + ".ajp"
   if fileExists(path):
    lines = FFQoVo(path)
    srt = delay = enc = ""
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : srtPath = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay   = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc   = line.split("=")[1].strip()
    if srtPath and fileExists(srtPath):
     subtList, err = self.VV6nW0(srtPath, enc)
     if subtList:
      self.lastSubtEnc = enc
      self.subtList = subtList
      try:
       CFG.subtDelay.setValue("%.1f" % float(delay))
      except:
       pass
      return True
  return False
 def VVr4OM(self):
  bestSrt, bestRatio = CCdqgc.VVF6Cv(self)
  if bestSrt and bestRatio > 40:
   subtList, err = self.VV6nW0(bestSrt)
   if subtList:
    self.subtList = subtList
    return True
  return False
 def VVxurx(self):
  VVhOvi = []
  if self.lastSubtFile:
   VVhOvi.append(("Settings"      , "set"  ))
   VVhOvi.append(("Change Encoding"    , "enc"  ))
   VVhOvi.append(("Disable Current Subtitle"  , "disab" ))
   VVhOvi.append(VVaOJ8)
  VVhOvi.append(("Find all srt file"    , "findSrt" ))
  lst = CCdqgc.VVlnwI(self)
  if lst:
   VVhOvi.append(VVaOJ8)
   for item in lst:
    fName = os.path.basename(item)
    if self.lastSubtFile == item:
     fName = FFFpMs(fName, VVplBl)
    VVhOvi.append((fName, item))
  win = FFN6sa(self, self.VVSbp8, VVhOvi=VVhOvi, width=1200, title="Subtitle Options")
  win.instance.move(ePoint(40, 40))
 def VVSbp8(self, item=None):
  if item:
   if item == "set":
    self["mySubtFr"].show()
    for i in range(3):
     FFpqr2(self["mySubt%d" % i], "#55000000")
    self.session.openWithCallback(self.VVaQMn, CCImP4)
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile):
     FFmTns(self, boundFunction(CCy6sJ.VVsT4r, self, self.lastSubtFile, self.VVDGD6, defEnc=self.lastSubtEnc, pos=1), title="Loading Codecs ...", clearMsg=False)
    else:
     FFbstz(self, "SRT File error", 1000)
   elif item == "disab":
    fPath, fDir, fName = CC82J5.VVCYXm(self)
    os.system(FFiu56("rm -f '%s'" % fPath + ".ajp"))
    self.VVwCeD("noErr")
   elif item == "findSrt":
    CCdqgc.VVjUzW(self, self.VV1Cll, defSrt=self.lastSubtFile, pos=1)
   else:
    self.VV1Cll(item)
 def VVaQMn(self, res):
  self["mySubtFr"].hide()
  for i in range(3):
   FFpqr2(self["mySubt%d" % i], "#FF000000")
  if res:
   self.VVJ1d3()
   self.VV0azq()
 def VVmtM0(self):
  CFG.subtDelay.addNotifier(self.VV0azq, initial_call=False)
  CFG.subtTextFg.addNotifier(self.VV0azq, initial_call=False)
  CFG.subtTextFont.addNotifier(self.VV0azq, initial_call=False)
  CFG.subtTextSize.addNotifier(self.VV0azq, initial_call=False)
  CFG.subtTextAlign.addNotifier(self.VV0azq, initial_call=False)
  CFG.subtShadowColor.addNotifier(self.VV0azq, initial_call=False)
  CFG.subtShadowSize.addNotifier(self.VV0azq, initial_call=False)
  CFG.subtVerticalPos.addNotifier(self.VV0azq, initial_call=False)
 def VV76a4(self):
  CFG.subtDelay.removeNotifier(self.VV0azq)
  CFG.subtTextFg.removeNotifier(self.VV0azq)
  CFG.subtTextFont.removeNotifier(self.VV0azq)
  CFG.subtTextSize.removeNotifier(self.VV0azq)
  CFG.subtTextAlign.removeNotifier(self.VV0azq)
  CFG.subtShadowColor.removeNotifier(self.VV0azq)
  CFG.subtShadowSize.removeNotifier(self.VV0azq)
  CFG.subtVerticalPos.removeNotifier(self.VV0azq)
 def VV0azq(self, configElement=None):
  fnt = CFG.subtTextFont.getValue()
  if not fnt in FFEjBE():
   fnt = VVg54i
  lineH = 0
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFxrbm(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    inst.setHAlign(int(CFG.subtTextAlign.getValue()))
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    inst.setNoWrap(True)
    lineH = FFLtf8(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    inst.move(ePoint(int(inst.position().x()), int(lineH * i + 1)))
  except:
   pass
  try:
   height = lineH * 3 + 2
   if not self.defaultY:
    self.defaultY = int(getDesktop(0).size().height() - height - self.skinParam["marginTop"])
   if lineH:
    self.instance.resize(eSize(*(int(self.instance.size().width()), height)))
   y = int(self.defaultY + CFG.subtVerticalPos.getValue())
   y = min(y, getDesktop(0).size().height() - height - 5)
   self.instance.move(ePoint(int(self.instance.position().x()), int(y)))
   inst = self["myInfoFrame"].instance
   inst.move(ePoint(int(inst.position().x()), 2))
   inst = self["myInfoBody"].instance
   inst.move(ePoint(int(inst.position().x()), 4))
  except:
   pass
 def VV1Cll(self, path, enc=None):
  self.timerUpdate.stop()
  subtList, err = self.VV6nW0(path, enc)
  if err    : FFbstz(self, err, 2000)
  elif not subtList : FFbstz(self, "Invalid SRT file", 2000)
  else    :
   self.subtList  = subtList
   self.lastSubtInfo = ""
   self.lastSubtEnc = ""
   self.currentIndex = 0
   CFG.subtDelay.setValue("0.0")
   for i in range(3):
    FFxrbm(self["mySubt%d" % i], "#ffffff")
    self["mySubt%d" % i].setText("")
   FFbstz(self, "Subtitle started", 1000, isGrn=True)
  self.timerUpdate.start(500, False)
 def VVDGD6(self, item=None):
  if item:
   self.VV1Cll(self.lastSubtFile, item)
 @staticmethod
 def VVlnwI(SELF):
  fPath, fDir, fName = CC82J5.VVCYXm(SELF)
  if pathExists(fDir):
   files = iGlob("%s*.srt" % fDir)
   if files:
    return files
  return []
 @staticmethod
 def VVF6Cv(SELF):
  bestSrt = ""
  bestRatio = 0
  fPath, fDir, fName = CC82J5.VVCYXm(SELF)
  if fName:
   movName = os.path.splitext(fName)[0].lower()
   files = CCdqgc.VVlnwI(SELF)
   for path in files:
    fName = os.path.basename(path)
    fName = os.path.splitext(fName)[0]
    ratio = CCpHVD.VVdW6A(movName.lower(), fName.lower())
    if ratio > bestRatio:
     bestRatio = ratio
     bestSrt = path
  return bestSrt, bestRatio
 def VVByQ2(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VV6nW0(self, path, enc=None):
  if not fileExists(path):
   return [], "File not found"
  if (FFEZNr(path) > 1024 * 700):
   return [], "File too big"
  capNum = frmSec = toSec = bold = italic = under = 0
  color  = ""
  subtLines = []
  subtList = []
  capFound = False
  lines  = FFQoVo(path, encLst=enc if enc else None)
  for line in lines:
   line = line.strip()
   if line:
    if not capFound and line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVByQ2(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      subtLines.append((line.strip(), color, bold, italic, under))
   else:
    if (toSec - frmSec) > 0:
     subtList.append((capNum, frmSec, toSec, subtLines))
    capFound = False
    subtLines = []
    color = ""
    capNum = frmSec = toSec = bold = italic = under = 0
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVJ1d3()
  return subtList, ""
 def VVJ1d3(self):
  fPath, fDir, fName = CC82J5.VVCYXm(self)
  if fPath and pathExists(fDir):
   with open(fPath + ".ajp", "w") as f:
    f.write("srt=%s\n" % self.lastSubtFile)
    f.write("delay=%s\n" % CFG.subtDelay.getValue())
    if self.lastSubtEnc:
     f.write("enc=%s\n" % self.lastSubtEnc)
 def VVJKWt(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCrMvG.VVq8Zu(self)
  txtDur = 0
  lines = []
  self.VVyJz6(posVal)
  if self.currentIndex == -2:
   return
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[self.currentIndex]
   if not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    for i in range(3):
     FFxrbm(self["mySubt%d" % i], "#ffffff")
     self["mySubt%d" % i].setText("")
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
     txtDur = int(toSec * 1000 - frmSec * 1000)
     if txtDur > 0:
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        line = line.replace(u"\u202A", "")
        line = line.replace(u"\u202B", "")
        line = line.replace(u"\u202C", "")
        line = str(line)
        if newColor:
         FFxrbm(self["mySubt%d" % ndx], newColor)
        self["mySubt%d" % ndx].setText(line)
      self.timerEndText.start(txtDur, True)
 def VVyJz6(self, posVal):
  if posVal > 0:
   delay = float(CFG.subtDelay.getValue())
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     self.currentIndex = ndx
     return
  self.currentIndex = -2
 def VVcjE2(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
 @staticmethod
 def VVjUzW(SELF, cbFnc, defSrt="", pos=0):
  FFmTns(SELF, boundFunction(CCdqgc.VVRxR7, SELF, cbFnc, defSrt, pos), title="Searching for srt files", clearMsg=False)
 @staticmethod
 def VVRxR7(SELF, cbFnc, defSrt="", pos=0):
  FFbstz(SELF)
  lines = FFGCWo('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFBbZi(1)))
  if lines:
   lines.sort()
   VVhOvi = []
   for item in lines:
    VVhOvi.append(((VVplBl if defSrt == item else "") + item, item))
   VVV70K = ("Show Full Path", CCdqgc.VVBtMC)
   win = FFN6sa(SELF, boundFunction(CCdqgc.VVHOez, cbFnc), title="Subtitle Files", VVhOvi=VVhOvi, width=1200, height=500 if pos == 1 else 900, VVV70K=VVV70K)
   if pos == 1:
    win.instance.move(ePoint(40, 40))
  else:
   FFbstz(SELF, "No srt files found !", 2000)
 @staticmethod
 def VVBtMC(VVfiljObj, path):
  FFHVXB(VVfiljObj, path, title="Full Path")
 @staticmethod
 def VVHOez(cbFnc, item):
  if item:
   cbFnc(item)
 @staticmethod
 def VVOQGn():
  c = s = m = h = 0
  with open(VVjxPh + "AJPanel_test.srt", "w") as f:
   for i in range(1, 5401):
    s += 2
    if s >= 60:
     s = 0
     m += 1
     if m >= 60:
      m = 0
      h += 1
    if i < 6:
     txt  = '<font color="#ffff00">Created by AJPanel</font>\n'
     txt += '<font color="#00ffff">Testing Subtitle Files</font>\n'
     txt += '<font color="#00ff00">Line - %d</font>\n\n' % i
    else:
     txt = '<font color="#ffffbb">Subtitle Line - %d</font>\n\n' % i
    f.write("%d\n" % i)
    f.write("%02d:%02d:%02d,001 --> %02d:%02d:%02d,001\n" % (h, m, s, h, m, s+1))
    f.write(txt)
class CCImP4(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FF82u7(VVq42k, 600, 600, 40, 30, 10, "#11331010", "#11442020", 30, barHeight=40)
  self.session  = session
  self.Title   = "Subtitle Settings"
  FFFsOT(self, title=self.Title)
  FFydgK(self["keyRed"] , "Exit")
  FFydgK(self["keyGreen"] , "Save")
  FFydgK(self["keyYellow"], "Reset")
  self.confList = []
  self.confList.append(getConfigListEntry("Delay (current movie)" , CFG.subtDelay   ))
  self.confList.append(getConfigListEntry(VVo4vY *2     ,       ))
  self.confList.append(getConfigListEntry("Text Color"   , CFG.subtTextFg  ))
  self.confList.append(getConfigListEntry("Text Font"    , CFG.subtTextFont  ))
  self.confList.append(getConfigListEntry("Text Size"    , CFG.subtTextSize  ))
  self.confList.append(getConfigListEntry("Alignment"    , CFG.subtTextAlign  ))
  self.confList.append(getConfigListEntry("Shadow Color"   , CFG.subtShadowColor ))
  self.confList.append(getConfigListEntry("Shadow Size"   , CFG.subtShadowSize ))
  self.confList.append(getConfigListEntry(VVo4vY *2     ,       ))
  self.confList.append(getConfigListEntry("Vertical Pos"   , CFG.subtVerticalPos ))
  ConfigListScreen.__init__(self, self.confList, session)
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVGXUD  ,
   "green"   : self.VV2swz   ,
   "yellow"  : boundFunction(FFStgm, self, self.VVCwK4, "Reset Subtitle Settings to default ?", title="Subtitle Settings"),
   "cancel"  : self.VVGXUD
  }, -1)
  self.onShown.append(self.VVqrW9)
 def VVqrW9(self):
  self.onShown.remove(self.VVqrW9)
  FFEktE(self["config"])
  FFwhmb(self, self["config"])
  FFNepU(self)
  self.instance.move(ePoint(40, 40))
 def VVGXUD(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFStgm(self, self.VV2swz, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VV2swz(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  configfile.save()
  self.close(True)
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close(False)
 def VVCwK4(self):
  CFG.subtDelay.setValue("0.0")
  CFG.subtTextFg.setValue("srt")
  CFG.subtTextFont.setValue(VVg54i)
  CFG.subtTextSize.setValue(50)
  CFG.subtTextAlign.setValue("1")
  CFG.subtShadowColor.setValue("#000080")
  CFG.subtShadowSize.setValue(5)
  CFG.subtVerticalPos.setValue(0)
  self.VV2swz()
class CCb5vh(ScrollLabel):
 def __init__(self, parentSELF, text="", VVgzxl=True):
  ScrollLabel.__init__(self, text)
  self.VVgzxl=VVgzxl
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VV3f8i  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVCZ7I    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close     ,
   "cancel"  : parentSELF.close     ,
   "red"   : self.VVahNq     ,
   "green"   : self.VVrGd5    ,
   "yellow"  : self.VVTsJM    ,
   "blue"   : self.VVX9WK    ,
   "up"   : self.pageUp      ,
   "down"   : self.pageDown      ,
   "left"   : self.pageUp      ,
   "right"   : self.pageDown      ,
   "last"   : boundFunction(self.VV9hzO, 0) ,
   "next"   : boundFunction(self.VV9hzO, 2) ,
   "0"    : boundFunction(self.VV9hzO, 1) ,
   "pageUp"  : self.VV1O1S      ,
   "chanUp"  : self.VV1O1S      ,
   "pageDown"  : self.VV4R6I      ,
   "chanDown"  : self.VV4R6I
  }, -1)
 def VV3zxV(self, isResizable=True, VVheTH=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FFNepU(self.parentSELF, True)
  self.isResizable = isResizable
  if VVheTH:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVCZ7I  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFpqr2(self, color)
 def FFpqr2Color(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VV3f8i - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVuj1E()
 def pageUp(self):
  if self.VV3f8i > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VV3f8i > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VV1O1S(self):
  self.setPos(0)
 def VV4R6I(self):
  self.setPos(self.VV3f8i-self.pageHeight)
 def VVVDR9(self):
  return self.VV3f8i <= self.pageHeight or self.curPos == self.VV3f8i - self.pageHeight
 def VVuj1E(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VV3f8i, 3))
   start = int((100 - vis) * self.curPos / (self.VV3f8i - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVLw9T=VVDGzB):
  old_VVVDR9 = self.VVVDR9()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VV3f8i = self.long_text.calculateSize().height()
   if self.VVgzxl and self.VV3f8i > self.pageHeight:
    self.scrollbar.show()
    self.VVuj1E()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VV3f8i))
   if   VVLw9T == VVL1cJ: self.setPos(0)
   elif VVLw9T == VVcOJJ : self.VV4R6I()
   elif old_VVVDR9    : self.VV4R6I()
 def appendText(self, text, VVLw9T=VVcOJJ):
  self.setText(self.message + str(text), VVLw9T)
 def VVTsJM(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVa2OQ(size)
 def VVX9WK(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVa2OQ(size)
 def VVrGd5(self):
  self.VVa2OQ(self.VVCZ7I)
 def VVa2OQ(self, VVCZ7I):
  self.long_text.setFont(gFont(self.fontFamily, VVCZ7I))
  self.setText(self.message, VVLw9T=VVDGzB)
  self.VVgN9o(calledFromFontSizer=True)
 def VV9hzO(self, align):
  self.long_text.setHAlign(align)
 def VVahNq(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FFwI5c(expPath), self.textOutFile, FFHXaa())
    with open(outF, "w") as f:
     f.write(FFwPAs(self.message))
    FFnN3Y(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FF2wyP(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVgN9o(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VV3f8i > 0 and self.pageHeight > 0:
   if self.VV3f8i < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VV3f8i
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
