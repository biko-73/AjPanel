import os
from json      import loads as jLoads
from sys      import version_info
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import log
from time      import localtime, mktime, strftime
from time      import time as iTime
from datetime     import datetime
from base64      import b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigInteger
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVB14v   = "v2.4.1"
VVzZMh    = "05-08-2021"
VVNUSV  = "AJ File Manager"
VVLQC6   = "AJ Live Log (OSCam/NCam)"
EASY_MODE    = 0
VVrElc   = 0
VVbfsX   = 0
VVIuMA  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVAoPn  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VV84Zp    = "/media/usb/"
VV4Xzy    = "/usr/share/enigma2/picon/"
VVVuM0   = "/etc/enigma2/"
VVKIac  = "ajpanel_update_url"
VV0kWH   = "AJPan"
VVCerc    = ""
VVLeet    = "Regular"
VVuDI9      = "-" * 80;
VV8ygQ    = (VVuDI9, )
VVjhpS    = ""
VVE8qa  = 'ping -W1 -q 1.1.1.1 -c 1 | grep " 0% packet"'
VVL7Mj   = " && echo 'Successful' || echo 'Failed!'"
VVV691    = []
VVfyZW     = 0
VVwsZ5    = ""
VVaEgm  = False
VVUMBX  = False
VVFqLG     = 0
VVUtn1    = 1
VVwbJJ    = 2
VVi1ts   = 3
VVcYed    = 4
VVn0bF    = 5
VVB5d2 = 6
VVIgPt = 7
VVqMuZ  = 8
VVFR26   = 9
VV9aYx   = 10
VVqdOV   = 11
VVGyVT  = 12
VVr8W3 = 13
VVNYjB = 14
WINDOW_MIXED_COLORS   = 15
VVwV7u  = 15
VVRXKB   = 0
VVZLId   = 1
VVVWeh   = 2
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu   = ConfigYesNo(default=False)
CFG.showInExtensionMenu  = ConfigYesNo(default=True)
CFG.showInChannelListMenu = ConfigYesNo(default=True)
CFG.keyboard    = ConfigSelection(default="v", choices = [ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal   = ConfigSelection(default="lok", choices = [ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.PIconsPath    = ConfigDirectory(default=VV4Xzy, visible_width=51)
CFG.backupPath    = ConfigDirectory(default=VV84Zp, visible_width=51)
CFG.packageOutputPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath  = ConfigText(default="/")
CFG.browserBookmarks   = ConfigText(default="/tmp/,/")
CFG.signalPos    = ConfigInteger(default=5, limits=(1, 9))
CFG.signalSize    = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme  = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup = ConfigYesNo(default=False)
def FFhW4s():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVqQEu  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VV8JLf = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVqQEu  : return 0
  elif VV8JLf : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVZgG6 = FFhW4s()
VVqJ8u = VVrETx = VVK65K = VVxYDU = VVbTiz = VV688Y = VViUes = VVvAHa = COLOR_CONS_BRIGHT_YELLOW = VVvs8y = VVy7KO = VVMR5q = ""
def FFRsng(FFRsngText="", addSep=True):
 if VVrElc:
  txt = VVuDI9 + "\n" if addSep else ""
  txt += ">>>> %s >>  %s" % (PLUGIN_NAME, str(FFRsngText))
  os.system('echo -e "%s"' % txt)
def FFP7UC(txt, isAppend=True):
 if VVrElc:
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   f.write(str(txt) + "\n")
  FFRsng("Output Log File : %s" % fileName)
VVV691 = []
def FFXb1l(win):
 global VVV691
 if not win in VVV691:
  VVV691.append(win)
def FFPWQ6(*args):
 global VVV691
 for win in VVV691:
  try:
   win.close()
  except:
   pass
 VVV691 = []
def FFavWw():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VV2uK6 = FFavWw()
def getDescriptor(fnc, where, name=PLUGIN_NAME):
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=True, name=name, description=PLUGIN_DESCRIPTION, icon=str("icon.png"))
def FFpkBQ()     : return getDescriptor(FF2AM6   , [ PluginDescriptor.WHERE_PLUGINMENU  ] )
def FF1rMf()  : return getDescriptor(FF2AM6   , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] )
def FFjUNF()  : return getDescriptor(FFQKCU , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , VVNUSV)
def FFTCPF() : return getDescriptor(FFacTi , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , VVLQC6)
def FFnDTu()    : return getDescriptor(FF1AFX  , [ PluginDescriptor.WHERE_SESSIONSTART  ] )
def FF1Fg2()      : return getDescriptor(FFIo5I  , [ PluginDescriptor.WHERE_MENU    ] )
def Plugins(**kwargs):
 result = [ FFpkBQ() , FF1Fg2() , FFnDTu() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FF1rMf())
  result.append(FFjUNF())
  result.append(FFTCPF())
 return result
def FF1AFX(reason, **kwargs):
 if reason == 0:
  FFh47B()
  session = kwargs["session"]
  if session:
   FFsPgg(session)
def FFIo5I(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FF2AM6, PLUGIN_NAME, 45)]
 else:
  return []
def FF2AM6(session, **kwargs):
 session.open(Main_Menu)
def FFQKCU(session, **kwargs):
 session.open(CChsD2)
def FFacTi(session, **kwargs):
 FFLtSS(session, CCnz3S.VVZakG)
def FF7wnj():
 pluginList  = iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU)
 descrPanel  = FF1rMf()
 descrFileMan = FFjUNF()
 descrCamLog  = FFTCPF()
 try:
  if CFG.showInExtensionMenu.getValue():
   if not descrPanel    in pluginList : iPlugins.addPlugin(descrPanel)
   if not descrFileMan  in pluginList : iPlugins.addPlugin(descrFileMan)
   if not descrCamLog in pluginList : iPlugins.addPlugin(descrCamLog)
  else:
   if descrPanel   in pluginList  : iPlugins.removePlugin(descrPanel)
   if descrFileMan in pluginList  : iPlugins.removePlugin(descrFileMan)
   if descrCamLog  in pluginList  : iPlugins.removePlugin(descrCamLog)
 except:
  pass
VVAiHK = None
def FFh47B():
 try:
  global VVAiHK
  if VVAiHK is None:
   VVAiHK    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFjEPO
  ChannelContextMenu.FF0CXz = FF0CXz
 except:
  pass
def FFjEPO(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVAiHK(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FF0CXz, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FF0CXz, title1, csel, isFind=True))))
def FF0CXz(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFD086(refCode)
 except:
  pass
 self.session.open(boundFunction(CCH4jc, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFsPgg(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FFWcKt, session, "lok")
 hk.actions['longCancel'] = boundFunction(FFWcKt, session, "lesc")
 hk.actions['longRed']  = boundFunction(FFWcKt, session, "lred")
def FFWcKt(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFiTcK(session, isFromSession=True)
def FFBP5J(SELF, title="", addLabel=False, addScrollLabel=False, VVleKL=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFAA5z()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 if SELF.skinParam["topRightBtns"] > 0:
  SELF["keyMenu2F"]  = Label()
  SELF["keyMenu2"]  = Label("Menu")
  if SELF.skinParam["topRightBtns"] > 1:
   SELF["keyMenu1F"] = Label()
   SELF["keyMenu1"] = Label("Info")
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCJMTV(SELF)
 if VVleKL:
  SELF["myMenu"] = MenuList(VVleKL)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVjeN5        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close        ,
   "cancel"  : SELF.close        ,
   "red"   : SELF.close        ,
  }, -1)
def FFEpJJ(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FF9bX4, SELF, "0") ,
  "1"    : boundFunction(FF9bX4, SELF, "1") ,
  "2"    : boundFunction(FF9bX4, SELF, "2") ,
  "3"    : boundFunction(FF9bX4, SELF, "3") ,
  "4"    : boundFunction(FF9bX4, SELF, "4") ,
  "5"    : boundFunction(FF9bX4, SELF, "5") ,
  "6"    : boundFunction(FF9bX4, SELF, "6") ,
  "7"    : boundFunction(FF9bX4, SELF, "7") ,
  "8"    : boundFunction(FF9bX4, SELF, "8") ,
  "9"    : boundFunction(FF9bX4, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FFYvlF, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FF9bX4(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVMR5q:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVMR5q + SELF.keyPressed + VVrETx)
    txt = VVrETx + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFVyro(SELF, txt)
def FFYvlF(SELF, tableObj, colNum):
 FFVyro(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     tableObj.moveToIndex(i)
     SELF.VVvxHk()
     break
 except:
  pass
def FFZUdU(SELF, setMenuAction=True):
 if setMenuAction:
  global VVjhpS
  VVjhpS = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFAA5z():
 return ("  %s" % VVjhpS)
def FF0WGA(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFZTkY(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFxdwd(color):
 return parseColor(color).argb()
def FFqov2(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFkgcm(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFFmrv(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFbAJE(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVMR5q)
 else:
  return ""
def FFA6oY(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVuDI9, word, VVuDI9, VVMR5q)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVuDI9, word, VVuDI9)
def FFNMGt(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVMR5q
def FFHr04(color):
 if color: return "echo -e '%s' %s;" % (VVuDI9, FFbAJE(VVuDI9, VVvAHa))
 else : return "echo -e '%s';" % VVuDI9
def FFYFPf(title, color):
 title = "%s\n%s\n%s\n" % (VVuDI9, title, VVuDI9)
 return FFNMGt(title, color)
def FFqDc3(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFzVkT(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFYs6W(callBackFunction):
 tCons = CChFBB()
 tCons.ePopen("echo", boundFunction(FFGwwB, callBackFunction))
def FFGwwB(callBackFunction, result, retval):
 callBackFunction()
def FF2E2r(SELF, fnc, title="Processing ...", clearMsg=True):
 FFVyro(SELF, title)
 tCons = CChFBB()
 tCons.ePopen("echo", boundFunction(FFh4Ya, SELF, fnc, clearMsg))
def FFh4Ya(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFVyro(SELF)
def FFUdJQ(cmd):
 from subprocess import Popen, PIPE
 process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
 stdout, stderr = process.communicate()
 stdout = stdout.strip()
 stderr = stderr.strip()
 if stderr : return stderr
 else  : return stdout
def FFnzIb(cmd):
 txt = FFUdJQ(cmd)
 if txt:
  txt.strip()
  if "\n" in txt:
   txt = txt.splitlines()
   return list(map(str.strip, txt))
  else:
   return [txt]
 else:
  return []
def FFactG(cmd):
 lines = FFnzIb(cmd)
 if lines: return lines[0]
 else : return ""
def FFxJOT(SELF, cmd):
 lines = FFnzIb(cmd)
 VVLRbU = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVLRbU.append((key, val))
  elif line:
   VVLRbU.append((line, ""))
 if VVLRbU:
  VVb3Bo   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFI84f(SELF, None, VVb3Bo=VVb3Bo, VV0sV9=VVLRbU, VVNZlV=widths, VVZ1jJ=22)
 else:
  FF4lhA(SELF, cmd)
def FF4lhA(    SELF, cmd, **kwargs): SELF.session.open(CCWJyd, VV60Bm=cmd, VVBCwe=True, VVPBLI=VVZLId, **kwargs)
def FFLISI(  SELF, cmd, **kwargs): SELF.session.open(CCWJyd, VV60Bm=cmd, **kwargs)
def FFfQ52(   SELF, cmd, **kwargs): SELF.session.open(CCWJyd, VV60Bm=cmd, VVfVDP=True, VV6szA=True, VVPBLI=VVZLId, **kwargs)
def FFVfjo(  SELF, cmd, **kwargs): SELF.session.open(CCWJyd, VV60Bm=cmd, VVfVDP=True, VV6szA=True, VVPBLI=VVVWeh, **kwargs)
def FFhgGU(  SELF, cmd, **kwargs): SELF.session.open(CCWJyd, VV60Bm=cmd, VVnBg6=True , **kwargs)
def FFXjIu( SELF, cmd, **kwargs): SELF.session.open(CCWJyd, VV60Bm=cmd, VVvVxL=True   , **kwargs)
def FF1Buo( SELF, cmd, **kwargs): SELF.session.open(CCWJyd, VV60Bm=cmd, VVRELW=True  , **kwargs)
def FFZNvw(cmd):
 return cmd + " > /dev/null 2>&1"
def FFxdBe():
 return " > /dev/null 2>&1"
def FF6OVW(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFdplS(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "/bin"
    , "/boot"
    , "/dev"
    , "/hdd"
    , "/home"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/picon"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FF1cg4():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFactG(cmd)
VVcHIJ     = 0
VVtllz      = 1
VVjaB3   = 2
VV8zER      = 3
VVtU5k      = 4
VVhbLh     = 5
VVQ9eZ     = 6
VVfS86  = 7
VVMAst = 8
VVloSO  = 9
VVl3jj     = 10
VVR2nU  = 11
VVm34V  = 12
def FFNDYc(parmNum, grepTxt):
 if   parmNum == VVcHIJ  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVtllz   : param = ["list"   , "apt list" ]
 elif parmNum == VVjaB3: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FF1cg4()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFqpep(parmNum, package):
 if   parmNum == VV8zER      : param = ["info"      ,"apt show"          ]
 elif parmNum == VVtU5k      : param = ["files"      ,"dpkg -L"          ]
 elif parmNum == VVhbLh     : param = ["download"     ,"apt-get download"        ]
 elif parmNum == VVQ9eZ     : param = ["install"     ,"apt-get install -y"       ]
 elif parmNum == VVfS86  : param = ["install --force-reinstall" ,"apt-get install --reinstall -y"    ]
 elif parmNum == VVMAst : param = ["install --force-downgrade" ,"apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVloSO  : param = ["install --force-depends" ,"apt-get install --no-install-recommends -y" ]
 elif parmNum == VVl3jj     : param = ["remove"      ,"apt-get purge --auto-remove -y"    ]
 elif parmNum == VVR2nU  : param = ["remove --force-remove"  ,"dpkg --purge --force-all"      ]
 elif parmNum == VVm34V  : param = ["remove --force-depends"  ,"dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FF1cg4()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFaaKH():
 result = FFactG("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFqpep(VVQ9eZ , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFZNvw("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFZNvw("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFbAJE(failed1, VVvAHa))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFbAJE(failed2, VVvAHa))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFbAJE(failed3, VVK65K))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFJHzY(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFqpep(VVQ9eZ , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFZNvw("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFbAJE(failed1, VVvAHa))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFbAJE(failed2, VVK65K))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FF8zDj():
 response = os.system(VVE8qa)
 if response == 0: return True
 else   : return False
def FFMmfA(path, maxSize=-1):
 from io import open as ioOpen
 encodings = (None, "utf-8", "ISO8859-15", 'iso6937', "windows-1250", "windows-1252")
 txt = ""
 for enc in encodings:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFFfb9(path, keepends=False, maxSize=-1):
 lines = FFMmfA(path, maxSize)
 return lines.splitlines(keepends)
def FFNAd3(SELF, path):
 title = FFAA5z()
 if fileExists(path):
  fSize = os.path.getsize(path)
  maxSize = 60000
  if (fSize > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFFfb9(path, maxSize=maxSize)
  if lines: FF0y0a(SELF, lines, title=title, VVPBLI=VVZLId)
  else : FF96ug(SELF, path, title=title)
 else:
  FFiKqP(SELF, path, title)
def FF8PEY(SELF, path, title):
 if fileExists(path):
  txt = FFMmfA(path)
  txt = txt.replace("#W#", VVMR5q)
  txt = txt.replace("#Y#", VVvAHa)
  txt = txt.replace("#G#", VVrETx)
  txt = txt.replace("#C#", VVvs8y)
  txt = txt.replace("#P#", VVxYDU)
  txt = txt.replace("#Y#", VVvAHa)
  FF0y0a(SELF, txt, title=title)
 else:
  FFiKqP(SELF, path, title)
def FF7tIN(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FFTTCX(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFV3kK(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFjUmV(parent)
 else    : return FFvbpu(parent)
def FFjUmV(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFvbpu(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFE3Um():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVIuMA)
 paths.append(VVIuMA.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFTTCX(ba)
 for p in list:
  p = ba + p + VVIuMA
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VV0kWH, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVIuMA, VV0kWH , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVpP63, VVfX8s = FFE3Um()
def FFlQ92():
 def VVIFA0(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 VVqHZt  = VVIFA0(CFG.backupPath, CCN65h.VVjcLp())
 VVlcKE  = VVIFA0(CFG.downloadedPackagesPath, t)
 VVrOzn = VVIFA0(CFG.exportedTablesPath, t)
 VVYEJA = VVIFA0(CFG.exportedPIconsPath, t)
 VVkgYO  = VVIFA0(CFG.packageOutputPath, t)
 global VV84Zp
 VV84Zp = FFjUmV(CFG.backupPath.getValue())
 if VVqHZt or VVkgYO or VVlcKE or VVrOzn or VVYEJA:
  configfile.save()
 return VVqHZt, VVkgYO, VVlcKE, VVrOzn, VVYEJA
def FF2hmz(path):
 path = FFvbpu(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFnEDZ(SELF, pathList, tarFileName, addTimeStamp=True):
 VV0sV9 = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VV0sV9.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VV0sV9.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VV0sV9.append(path)
 if not VV0sV9:
  FFRwfz(SELF, "Files not found!")
 elif not pathExists(VV84Zp):
  FFRwfz(SELF, "Path not found!\n\n%s" % VV84Zp)
 else:
  VV4mAc = FFjUmV(VV84Zp)
  tarFileName = "%s%s" % (VV4mAc, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFGx0i())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VV0sV9:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVuDI9
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFbAJE(tarFileName, VViUes))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFbAJE(failed, VViUes))
  cmd += "fi;"
  cmd +=  sep
  FFLISI(SELF, cmd)
def FFsHQf(SELF, title, VVfzL0):
 SELF.session.open(boundFunction(CCHXcR, Title=title, VVfzL0=VVfzL0))
def FFoqMx(labelObj, VVfzL0):
 if VVfzL0 and fileExists(VVfzL0):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VVu2Y2(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VVu2Y2)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VVfzL0)
   return True
  except:
   pass
 return False
def FFzqHs(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFtBBn(satNum)
  return satName
def FFtBBn(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FF1HAl(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFzqHs(val)
  else  : sat = FFtBBn(val)
 return sat
def FFKoSI(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFzqHs(num)
 except:
  pass
 return sat
def FFMsdn(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFDq4f(SELF, isFromSession=None):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FF9JtJ(info, iServiceInformation.sServiceref)
   prov = FF9JtJ(info, iServiceInformation.sProvider)
   state = str(FF9JtJ(info, iServiceInformation.sDVBState))
   if   state == "0"     : state = "No Free Tuner"
   elif state == "1"     : state = "Tune Failed"
   elif state == "2"     : state = "No Data on Transponder (Timeout reading PAT)"
   elif state == "3"     : state = "Service Not Found (SID not found in PAT)"
   elif state == "4"     : state = "Service Invalid (Timeout reading PMT)"
   elif state in ("5", "6", "7", "8") : state = "Working"
   elif state == "9"     : state = "Service Unavailable (Check tuner config.)"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFKVJY(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFKp7T(refCode)
 return info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FF9JtJ(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FF7Hfa(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFD086(refCode):
 info = FFbObX(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFhPmX(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFsO3Q(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFbObX(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVk2NF = eServiceCenter.getInstance()
  if VVk2NF:
   info = VVk2NF.info(service)
 return info
def FFM38n(SELF, refCode, VVDz76=True, checkParentalControl=False):
 if not refCode.endswith(":"):
  refCode += ":"
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  SELF.session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
  if VVDz76:
   FFiTcK(SELF)
 try:
  VVctp2 = InfoBar.instance
  if VVctp2:
   VV4bcG = VVctp2.servicelist
   if VV4bcG:
    servRef = eServiceReference(refCode)
    VV4bcG.saveChannel(servRef)
 except:
  pass
def FFKVJY(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFKp7T(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFJx6y(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFuNTm(userBfile):
 txt = ""
 bFile = VVVuM0 + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVVuM0 + userBfile):
  fTxt = FFMmfA(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFactG('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
 return
def FFJx6y(url):
 try:
  from urllib import unquote
  return unquote(url)
 except:
  try:
   from urllib.parse import unquote
   return unquote(url)
  except:
   pass
 return url
def FFTTRw(url):
 try:
  from urllib import quote
  return quote(url)
 except:
  try:
   from urllib.parse import quote
   return quote(url)
  except:
   pass
 return url
def FFiTcK(SELF, isFromSession=None):
 info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFDq4f(SELF, isFromSession)
 if iptvRef:
  if isFromSession: SELF.open(boundFunction(CCgisO, showIptvNote=True))
  else   : SELF.session.open(CCgisO, showIptvNote=True)
 else:
  if isFromSession: session = SELF
  else   : session = SELF.session
  FF3Czf(session, True)
def FF3Czf(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FF3Czf, session), CCwOFg)
  except:
   try:
    FFKFDs(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFxbuy(refCode):
 tp = CCOm0d()
 if tp.VVVpOT(refCode) : return True
 else        : return False
def FFoQXt(refCode, isHide):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFb09f():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FFIgUg():
 VVctp2 = InfoBar.instance
 if VVctp2:
  VV4bcG = VVctp2.servicelist
  if VV4bcG:
   return VV4bcG.getBouquetList()
 return None
def FFLQGG(refCode, iptvRef, chName):
 refCode = FF7Hfa(refCode, iptvRef, chName)
 fList = []
 txt = FFMmfA(VVVuM0 + "bouquets.tv")
 list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
 if list: fList += list
 txt = FFMmfA(VVVuM0 + "bouquets.radio")
 list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
 if list: fList += list
 VV0sV9 = []
 tmpRefCode = refCode.upper()
 for item in fList:
  path = VVVuM0 + item
  if fileExists(path):
   txt = FFMmfA(path)
   if tmpRefCode in txt.upper():
    span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
    if span : bName = span.group(1)
    else : bName = "[ No Name ]"
    VV0sV9.append(bName)
 txt = VVuDI9 + "\n"
 if VV0sV9:
  if len(VV0sV9) == 1:
   txt += "Bouquet\t: %s\n" % VV0sV9[0]
  else:
   txt += "Bouquets:\n"
   for ndx, item in enumerate(VV0sV9):
    txt += "%d- %s\n" % (ndx + 1, item.strip())
 else:
  txt += "Bouquet\t: -\n"
 return txt
def FFJ5Wh(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVk2NF = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVk2NF.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FFpN9C():
 VVaijI = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVFjcY = list(VVaijI)
 return VVFjcY, VVaijI
def FFzH73():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFLtSS(session, VVkofC):
 VVP1TN, VVEmXY, VVHlnf, camCommand = FFtHtc()
 if VVEmXY:
  runLog = False
  if   VVkofC == CCnz3S.VVM83t : runLog = True
  elif VVkofC == CCnz3S.VV7CYc : runLog = True
  elif not VVHlnf          : FFKFDs(session, message="SoftCam not started yet!")
  elif fileExists(VVHlnf)        : runLog = True
  else             : FFKFDs(session, message="File not found !\n\n%s" % VVHlnf)
  if runLog:
   session.open(boundFunction(CCnz3S, VVP1TN=VVP1TN, VVEmXY=VVEmXY, VVHlnf=VVHlnf, VVkofC=VVkofC))
 else:
  FFKFDs(session, message="No active OSCam/NCam found !")
def FFtHtc():
 VVP1TN = "/etc/tuxbox/config/"
 VVEmXY = None
 VVHlnf  = None
 camCommand = FFactG("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVEmXY = "oscam"
 elif "ncam"  in camCommand : VVEmXY = "ncam"
 if VVEmXY:
  path = FFactG(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFjUmV(path)
  if pathExists(path):
   VVP1TN = path
  tFile = VVP1TN + VVEmXY + ".conf"
  tFile = FFactG("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVHlnf = tFile
 return VVP1TN, VVEmXY, VVHlnf, camCommand
def FFCgGR(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFftoO():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFGx0i():
 return FFftoO().replace(" ", "_").replace("-", "").replace(":", "")
def FFUqNW(SELF, camPrefix, configFile, urlPart, urlAction):
 if fileExists(configFile):
  lines = FFFfb9(configFile)
  user = "root"
  pwd  = port = ""
  if lines:
   webif = False
   for line in lines:
    line = line.strip().lower()
    if "[webif]" in line:
     webif = True
    if webif and "=" in line:
     if   line.startswith("httpuser") : user = line.split("=")[1].strip()
     elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
     elif line.startswith("httpport") : port = line.split("=")[1].strip()
  if not webif:
   FFRwfz(SELF, "Cannot connect to SoftCAM Web Interface !")
   return None
  elif not port:
   FFRwfz(SELF, "SoftCAM Web Port not found in file:\n\n%s" % configFile)
   return None
 else:
  FFiKqP(SELF, configFile)
  return None
 allOK = False
 try:
  from urllib2   import Request, urlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib2   import URLError
  allOK = True
 except:
  try:
   from urllib.request import Request, urlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
   from urllib.error import URLError
   allOK = True
  except:
   pass
 if not allOK:
  FFRwfz(SELF, "Module not found : urllib/urllib2 !")
  return None
 allOK = False
 try:
  from xml.etree import ElementTree
  allOK = True
 except:
  pass
 if not allOK:
  FFRwfz(SELF, "Module not found : xml.etree !")
  return None
 try:
  url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
  acceccManager  = HTTPPasswordMgrWithDefaultRealm()
  acceccManager.add_password(None, url, user, pwd)
  handlers   = HTTPDigestAuthHandler(acceccManager)
  opener    = build_opener(HTTPHandler, handlers)
  install_opener(opener)
  return Request(url), urlopen, URLError, ElementTree, url
 except Exception as e:
  FFRwfz(self, "Error while preparing URL Request !\n\n %s" % str(e))
 return None
def FFUNQn(url, fName, timeout=3):
 fName  = "/tmp/%s" % fName
 logF = fName + ".log"
 os.system(FFZNvw("rm -f '%s' '%s'" % (logF, fName)))
 cmd   = "wget -q -S -T %d "   % timeout
 cmd  += " '%s'"      % url.strip()
 cmd  += " --output-document '%s'" % fName
 cmd  += " --output-file '%s'"  % logF
 res = FFUdJQ(cmd)
 path = fName
 err  = ""
 if fileExists(logF):
  txt = FFMmfA(logF)
  if "200 OK" in txt:
   span = iSearch(r'filename=(.+)', txt, IGNORECASE)
   if span:
    fileName = span.group(1).replace('"', "")
    if fileName:
     fileName = fileName.replace(":", "_")
     path = "/tmp/" + fileName
     os.system(FFZNvw("mv -f '%s' '%s'" % (fName, path)))
  elif "404 Not Found" in txt:
   err = "Server Returned Error :\n\nHTTP/1.1 404 Not Found"
  else:
   err = txt.replace("wget:", "Error:")
 else:
  err = "Download failed !"
 if not path == fName: os.system(FFZNvw("rm -f '%s' '%s'" % (logF, fName)))
 else    : os.system(FFZNvw("rm -f '%s'"   % logF))
 if err : return ""  , err
 else : return path, ""
def FFDcvu(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFtnnY(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFmsDl():
 return int(FFUdJQ("cat /proc/meminfo | grep MemFree | awk '{print $2}'"))
def FFFCY2():
 global VVfyZW_TIME, VVwsZ5
 VVwsZ5  = int(FFmsDl())
 VVfyZW_TIME = iTime()
def FFv00Y():
 elapsed = iTime() - VVfyZW_TIME
 elapsed = "{:.6f}".format(elapsed).rstrip("0").rstrip(".")
 mem  = FFmsDl() - VVwsZ5
 FFRsng(">>>>>> Elapsed\t: {} seconds ... Memory\t: {} bytes".format(elapsed, mem))
def FFVXKI(SELF, message, title=""):
 SELF.session.open(boundFunction(CCJp4E, title=title, message=message, VVgTpR=True))
def FF0y0a(SELF, message, title="", VVPBLI=VVZLId, **kwargs):
 SELF.session.open(boundFunction(CCJp4E, title=title, message=message, VVPBLI=VVPBLI, **kwargs))
def FF86rP(SELF, message, **kwargs):
 FFK7pk(SELF.session, message, **kwargs)
def FFK7pk(session, message, **kwargs):
 session.open(boundFunction(CCY10s, message=message, **kwargs))
def FFRwfz(SELF, message, title="")  : FFKFDs(SELF.session, message, title)
def FFiKqP(SELF, path, title="") : FFKFDs(SELF.session, "File not found !\n\n%s" % path, title)
def FF96ug(SELF, path, title="") : FFKFDs(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFxXZG(SELF, title="")  : FFKFDs(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFKFDs(session, message, title="") : session.open(boundFunction(CCfJq1, title=title, message=message))
def FFX60J(SELF, VVVmsi, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVVmsi, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVVmsi, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVVmsi, boundFunction(CCQmWq, title=title, message=message, VVKchL=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFRwfz(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFQsdM(SELF, callBack_Yes, VVbMOP, callBack_No=None, title="", VVyjYQ=False):
 SELF.session.openWithCallback(boundFunction(FFzISR, callBack_Yes, callBack_No)
        , boundFunction(CCmnvi, title=title, VVbMOP=VVbMOP, VVSW5q=True, VVyjYQ=VVyjYQ))
def FFzISR(callBack_Yes, callBack_No, FFQsdMed):
 if FFQsdMed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFVyro(SELF, message="", milliSeconds=0):
 try:
  SELF["myInfoBody"].setText(str(message))
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFi2Wp(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FF1qsD(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
myTimer = eTimer()
def FFi2Wp(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFlu9C, SELF))
 try:
  myTimer_conn = myTimer.timeout.connect(boundFunction(FFlu9C, SELF))
 except:
  myTimer.callback.append(boundFunction(FFlu9C, SELF))
 myTimer.start(milliSeconds, 1)
def FFlu9C(SELF):
 myTimer.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFI84f(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCPQmb, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCPQmb, **kwargs))
  FFXb1l(win)
  return win
 except:
  return None
def FF7X20(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCrqbE, **kwargs))
 FFXb1l(win)
 return win
def FFoFoL(SELF, isTopBar=False):
 if isTopBar : names = [ "keyGreenTop", "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue" ]
 for name in names:
  try:
   obj = SELF[name]
   SELF[name].instance.setBorderColor(parseColor("#000000"))
   SELF[name].instance.setBorderWidth(3)
   SELF[name].instance.setNoWrap(True)
  except:
   pass
def FF9U6b(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVLeet, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFQH05(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FF9U6b(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFXDJG():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FF2m1A(VVZ1jJ):
 screenSize  = FFXDJG()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVZ1jJ)
 return bodyFontSize
def FFp4D5(VVZ1jJ, extraSpace):
 font = gFont(VVLeet, VVZ1jJ)
 VVLFpA = fontRenderClass.getInstance().getLineHeight(font) or (VVZ1jJ * 1.25)
 return int(VVLFpA + VVLFpA * extraSpace)
def FFMYS8(fontName):
 fList = None
 try:
  from enigma import getFontFaces
  fList = getFontFaces()
 except:
  try:
   from skin import getFontFaces
   fList = getFontFaces()
  except:
   pass
 if fList and fontName in fList : return fontName
 else       : return VVLeet
def FFPc34(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFXDJG()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * VVwV7u)
 bodyFontStr  = 'font="%s;%d"' % (VVLeet, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFp4D5(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVLeet, titleFontSize, alignLeftCenter)
 if winType == VVFqLG or winType == VVUtn1:
  if winType == VVUtn1 : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVNYjB:
  tmp += '<widget name="myQFrame" position="0,0" size="%d,%d" zPosition="4" backgroundColor="#00aaaa00" />' % (width, height)
  tmp += '<widget name="myQBody"  position="1,1" size="%d,%d" zPosition="5" backgroundColor="#0a550000" foregroundColor="#00aaaaaa" %s %s />' % (width-2, height-2, bodyFontStr, alignCenter)
 elif winType == WINDOW_MIXED_COLORS:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d"  position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVcYed:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVwbJJ:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVi1ts:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVLeet, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVLeet, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VV9aYx:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFVXKIH = int(bodyH * 0.5)
  inpTop = bodyTop + FFVXKIH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFVXKIH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVLeet, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVLeet, mapF, alignCenter)
 elif winType == VVqdOV:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVGyVT:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVLeet, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVr8W3:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVLeet, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVLeet, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVLeet, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 else:
  if   winType == VVIgPt : align = alignLeftCenter
  elif winType == VVB5d2 : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVFR26:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VVn0bF:
   moreParams = ""
  else:
   fontStr = bodyFontStr
   if usefixedFont and winType == VVB5d2:
    fontStr = 'font="%s;%d"' % (FFMYS8("Fixed"), bodyFontSize)
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" %s %s ' % (bodyColor, fontStr, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVZ1jJ = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVLeet, VVZ1jJ, alignCenter)
 if topRightBtns > 0:
  btnW = int(ratioW * 80)
  btnH = int(titleH * 0.7)
  btnTop = int(titleH * 0.15)
  btnLeft = width - (btnW + btnTop)
  btnFont = int(btnH * 0.6)
  tmp += '<widget name="keyMenu2F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
  tmp += '<widget name="keyMenu2"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VVLeet, btnFont, alignCenter)
  if topRightBtns > 1:
   btnLeft = btnLeft - btnW - 8
   tmp += '<widget name="keyMenu1F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="keyMenu1"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VVLeet, btnFont, alignCenter)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVV3xM = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVLeet, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVV3xM[i], VVLeet, barFont, alignCenter)
   left += btnW + gap
 if winType == VVB5d2:
  name = [ "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVV3xM = [ "#111f771f"  , "#11a08500" , "#1118188b"  ]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 3
  btnFont = int(btnH * 0.65)
  for i in range(3):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVV3xM[i], VVLeet, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFPc34(VVFqLG, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.hiddenMenuPass = ""
  self.themsList  = []
  VVleKL = []
  if VVbfsX:
   VVleKL.append(("-- MY TEST --"    , "myTest"   ))
  VVleKL.append(("File Manager"      , "FileManager"  ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Services/Channels"    , "ChannelsTools" ))
  VVleKL.append(("IPTV"        , "IptvTools"  ))
  VVleKL.append(("PIcons"       , "PIconsTools"  ))
  VVleKL.append(("SoftCam"       , "SoftCam"   ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Plugins"       , "PluginsTools" ))
  VVleKL.append(("Terminal"       , "Terminal"  ))
  VVleKL.append(("Backup & Restore"     , "BackupRestore" ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Date/Time"      , "Date_Time"  ))
  VVleKL.append(("Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVleKL)
  FFBP5J(self, VVleKL=VVleKL)
  FF0WGA(self["keyRed"] , "Exit")
  FF0WGA(self["keyGreen"] , "Settings")
  FF0WGA(self["keyYellow"], "Dev. Info.")
  FF0WGA(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VVDc3I       ,
   "yellow"  : self.VVG9Tz       ,
   "blue"   : self.VVfAs0       ,
   "info"   : self.VVfAs0       ,
   "next"   : self.VVkJiD       ,
   "0"    : boundFunction(self.VVUBl8, 0) ,
   "1"    : boundFunction(self.VVOILd, 1)   ,
   "2"    : boundFunction(self.VVOILd, 2)   ,
   "3"    : boundFunction(self.VVOILd, 3)   ,
   "4"    : boundFunction(self.VVOILd, 4)   ,
   "5"    : boundFunction(self.VVOILd, 5)   ,
   "6"    : boundFunction(self.VVOILd, 6)   ,
   "7"    : boundFunction(self.VVOILd, 7)   ,
   "8"    : boundFunction(self.VVOILd, 8)   ,
   "9"    : boundFunction(self.VVOILd, 9)
  })
  self.onShown.append(self.VVTwK9)
  self.onClose.append(self.onExit)
  global VVaEgm, VVUMBX
  VVaEgm = VVUMBX = False
 def VVjeN5(self):
  item = FFZUdU(self)
  self.VVOILd(item)
 def VVOILd(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVAniz()
   elif item in ("FileManager"  , 1) : self.session.open(CChsD2)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCXkK1)
   elif item in ("IptvTools"  , 3) : self.session.open(CCOhHC)
   elif item in ("PIconsTools"  , 4) : self.VVYh9w()
   elif item in ("SoftCam"   , 5) : self.session.open(CCmMQn)
   elif item in ("PluginsTools" , 6) : self.session.open(CCC2vw)
   elif item in ("Terminal"  , 7) : self.session.open(CCpkX1)
   elif item in ("BackupRestore" , 8) : self.session.open(CCRm1J)
   elif item in ("Date_Time"  , 9) : self.session.open(CCGBY3)
   elif item in ("CheckInternet" , 10) : self.session.open(CCnvip)
   else         : self.close()
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  FFqDc3(self["myMenu"])
  FFQH05(self)
  FFoFoL(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVB14v)
  self["myTitle"].setText(title)
  VVqHZt, VVkgYO, VVlcKE, VVrOzn, VVYEJA = FFlQ92()
  self.VV5Qv3()
  if VVqHZt or VVkgYO or VVlcKE or VVrOzn or VVYEJA:
   VVAf2N = lambda path, subj: "%s:\n%s\n\n" % (subj, FFNMGt(path, VVK65K)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVAf2N(VVqHZt   , "Backup/Restore Path"    )
   txt += VVAf2N(VVkgYO  , "Created Package Files (IPK/DEB)" )
   txt += VVAf2N(VVlcKE  , "Download Packages (from feeds)" )
   txt += VVAf2N(VVrOzn , "Exported Tables"     )
   txt += VVAf2N(VVYEJA , "Exported PIcons"     )
   txt += "\nYou can change paths from Settings.\n"
   FF0y0a(self, txt, title="Settings Paths")
  if (EASY_MODE or VVrElc or VVbfsX):
   FFkgcm(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFVyro(self, "Welcome", 300)
  FFYs6W(boundFunction(self.VVHsBu, title))
 def VVHsBu(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCN65h.VVjNtD()
   if url:
    newWebVer = CCN65h.VVhA2o(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFZNvw("rm /tmp/ajpanel*"))
 def VVUBl8(self, digit):
  self.hiddenMenuPass += str(digit)
  if len(self.hiddenMenuPass) == 4:
   if self.hiddenMenuPass == "0" * 4:
    global VVaEgm
    VVaEgm = True
    FFkgcm(self["myTitle"], "#800080")
   else:
    self.hiddenMenuPass = "x"
 def VVkJiD(self):
  self.hiddenMenuPass += ">"
  if self.hiddenMenuPass == ("0" * 4) + ">>":
   global VVUMBX
   VVUMBX = True
   FFkgcm(self["myTitle"], "#dd5588")
 def VVYh9w(self):
  found = False
  pPath = CCpLfD.VV6tkf()
  if pathExists(pPath):
   for fName, fType in CCpLfD.VVau0J(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCpLfD)
  else:
   VVleKL = []
   VVleKL.append(("PIcons Manager"          , "CCpLfD"    ))
   VVleKL.append(VV8ygQ)
   VVleKL.append(CCpLfD.VVu4tu())
   VVleKL.append(VV8ygQ)
   VVleKL += CCpLfD.VVN5Bm()
   FF7X20(self, self.VV2BbX, VVleKL=VVleKL)
 def VV2BbX(self, item=None):
  if item:
   if   item == "CCpLfD"   : self.session.open(CCpLfD)
   elif item == "VVie7F"  : CCpLfD.VVie7F(self)
   elif item == "VVxTy4"  : CCpLfD.VVxTy4(self)
   elif item == "findPiconBrokenSymLinks" : CCpLfD.VVbqLb(self, True)
   elif item == "FindAllBrokenSymLinks" : CCpLfD.VVbqLb(self, False)
 def VVDc3I(self):
  self.session.open(CCN65h)
 def VVG9Tz(self):
  self.session.open(CCNmPy)
 def VVfAs0(self):
  changeLogFile = VVfX8s + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FFFfb9(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFNMGt("\n%s\n%s\n%s" % (VVuDI9, line, VVuDI9), VVxYDU, VVMR5q)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FFNMGt(line, VVrETx, VVMR5q)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FF0y0a(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VVB14v), VVZ1jJ=26)
 def VV5Qv3(self):
  p = VV84Zp + "ajpanel_colors"
  if fileExists(p):
   txt = FFMmfA(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    try:
     if   txt == "main_title_fg" : FFqov2(self["myTitle"], c)
     elif txt == "main_title_bg" : FFkgcm(self["myTitle"], c)
     elif txt == "main_body_fg" : FFqov2(self["myMenu"], c)
     elif txt == "main_body_bg" :
      FFkgcm(self["myBody"], c)
      FFkgcm(self["myMenu"], c)
     elif txt == "main_cursor_fg" : self["myMenu"].instance.setForegroundColorSelected(parseColor(c))
     elif txt == "main_cursor_bg" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(c))
     elif txt == "main_bar_bg"  : FFkgcm(self["myBar"], c)
    except:
     pass
 def VVAniz(self):
  opt = 11
  if   opt ==  0 : FFVXKI(self, "This is My Message.", "Testing")
  elif opt == 11:
   pass
class CCNmPy(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFPc34(VVFqLG, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVleKL = []
  VVleKL.append(("Settings File"        , "SettingsFile"   ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Box Info"          , "VVqTVN"    ))
  VVleKL.append(("Tuners Info"         , "VVltZf"   ))
  VVleKL.append(("Python Version"        , "VV59Zm"   ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Screen Size"         , "ScreenSize"    ))
  VVleKL.append(("Locale"          , "Locale"     ))
  VVleKL.append(("Processor"         , "Processor"    ))
  VVleKL.append(("Operating System"        , "OperatingSystem"   ))
  VVleKL.append(("Drivers"          , "drivers"     ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("System Users"         , "SystemUsers"    ))
  VVleKL.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVleKL.append(("Uptime"          , "Uptime"     ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Host Name"         , "HostName"    ))
  VVleKL.append(("MAC Address"         , "MACAddress"    ))
  VVleKL.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVleKL.append(("Network Status"        , "NetworkStatus"   ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Disk Usage"         , "VVqXxA"    ))
  VVleKL.append(("Mount Points"         , "MountPoints"    ))
  VVleKL.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVleKL.append(("USB Devices"         , "USB_Devices"    ))
  VVleKL.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVleKL.append(("Directory Size"        , "DirectorySize"   ))
  VVleKL.append(("Memory"          , "Memory"     ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVleKL.append(("Running Processes"       , "RunningProcesses"  ))
  VVleKL.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFBP5J(self, VVleKL=VVleKL, title="Device Information")
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  FFqDc3(self["myMenu"])
  FFQH05(self)
 def VVjeN5(self):
  global VVjhpS
  VVjhpS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCpE0p)
   elif item == "VVqTVN"    : self.VVqTVN()
   elif item == "VVltZf"   : self.VVltZf()
   elif item == "VV59Zm"   : self.VV59Zm()
   elif item == "ScreenSize"    : FF0y0a(self, "Width\t: %s\nHeight\t: %s" % (FFXDJG()[0], FFXDJG()[1]))
   elif item == "Locale"     : self.VVY9Z2()
   elif item == "Processor"    : self.VVWHHi()
   elif item == "OperatingSystem"   : FF4lhA(self, "uname -a"        )
   elif item == "drivers"     : self.VVizyf()
   elif item == "SystemUsers"    : FF4lhA(self, "id"          )
   elif item == "LoggedInUsers"   : FF4lhA(self, "who -a"         )
   elif item == "Uptime"     : FF4lhA(self, "uptime"         )
   elif item == "HostName"     : FF4lhA(self, "hostname"        )
   elif item == "MACAddress"    : self.VVT9XC()
   elif item == "NetworkConfiguration"  : FF4lhA(self, "ifconfig %s %s" % (FFbAJE("HWaddr", VVy7KO), FFbAJE("addr:", VVvAHa)))
   elif item == "NetworkStatus"   : FF4lhA(self, "netstat -tulpn"       )
   elif item == "VVqXxA"    : self.VVqXxA()
   elif item == "MountPoints"    : FF4lhA(self, "mount %s" % (FFbAJE(" on ", VVvAHa)))
   elif item == "FileSystemTable"   : FF4lhA(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FF4lhA(self, "lsusb"         )
   elif item == "listBlockDevices"   : FF4lhA(self, "blkid"         )
   elif item == "DirectorySize"   : FF4lhA(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVxKsJ="Reading size ...")
   elif item == "Memory"     : FF4lhA(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVuEBi()
   elif item == "RunningProcesses"   : FF4lhA(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FF4lhA(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVBD14()
   else         : self.close()
 def VVT9XC(self):
  res = FFUdJQ("ip link")
  list = iFindall("[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FF0y0a(self, txt)
  else:
   FF4lhA(self, "ip link")
 def VVzLQc(self, cmd, VVb3BoRepl, length, use2Spaces):
  if VVb3BoRepl:
   cmd += " | sed 's/%s/%s/g'" % (VVb3BoRepl, VVb3BoRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFnzIb(cmd)
  return lines
 def VVH77f(self, lines, VVb3BoRepl, widths, VVAGqv):
  VVLRbU = []
  VVb3Bo  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and VVb3BoRepl:
    line = line.replace(VVb3BoRepl.replace(" ", "_"), VVb3BoRepl)
   parts = line.split("#")
   if ndx == 0 : VVb3Bo = parts
   else  : VVLRbU.append(parts)
  if VVLRbU and len(VVb3Bo) == len(widths):
   VVLRbU.sort(key=lambda x: x[0].lower())
   FFI84f(self, None, VVb3Bo=VVb3Bo, VV0sV9=VVLRbU, VVAGqv=VVAGqv, VVNZlV=widths, VVZ1jJ=22, VVRWle=True)
   return True
  else:
   return False
 def VVqXxA(self):
  cmd   = "df -h"
  VVb3BoRepl = "Mounted on"
  lines  = self.VVzLQc(cmd, VVb3BoRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVAGqv = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VVH77f(lines, VVb3BoRepl, widths, VVAGqv)
  if not allOK:
   lines = FFnzIb(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFvbpu(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VViUes:
     note = "\n%s" % FFNMGt("Green = Mounted Partitions", VViUes)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(VVb3BoRepl.replace(" ", "_"), VVb3BoRepl)
      color = VVvAHa
     elif line.endswith(mountList) : color = VViUes
     else       : color = VVrETx
     txt += FFNMGt(line, color) + "\n"
    FF0y0a(self, txt + note)
   else:
    FFRwfz(self, "Not data from system !")
 def VVuEBi(self):
  cmd   = "lsmod"
  VVb3BoRepl = "Used by"
  lines  = self.VVzLQc(cmd, VVb3BoRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVAGqv = (LEFT , CENTER, LEFT )
  allOK = self.VVH77f(lines, VVb3BoRepl, widths, VVAGqv)
  if not allOK:
   FF4lhA(self, cmd)
 def VVY9Z2(self):
  from locale import getdefaultlocale
  loc = getdefaultlocale()
  FF0y0a(self, "Language\t: %s\nEncoding\t: %s" % (loc[0], loc[1]))
 def VVizyf(self):
  cmd = FFNDYc(VVjaB3, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FF4lhA(self, cmd)
  else : FFxXZG(self)
 def VVWHHi(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FF4lhA(self, cmd)
 def VVBD14(self):
  cmd = FFNDYc(VVtllz, "| grep secondstage")
  if cmd : FF4lhA(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFxXZG(self)
 def VVqTVN(self):
  c = VViUes
  VV0sV9 = []
  VV0sV9.append((FFNMGt("Box Type"  , c), FFNMGt(self.VVQ8vS("boxtype").upper(), c)))
  VV0sV9.append((FFNMGt("Board Version", c), FFNMGt(self.VVQ8vS("board_revision") , c)))
  VV0sV9.append((FFNMGt("Chipset"  , c), FFNMGt(self.VVQ8vS("chipset")  , c)))
  VV0sV9.append((FFNMGt("S/N"   , c), FFNMGt(self.VVQ8vS("sn")    , c)))
  VV0sV9.append((FFNMGt("Version"  , c), FFNMGt(self.VVQ8vS("version")  , c)))
  VVFRnH   = []
  VVpbNb = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVpbNb = SystemInfo[key]
     else:
      VVFRnH.append((FFNMGt(str(key), VVvs8y), FFNMGt(str(SystemInfo[key]), VVvs8y)))
  except:
   pass
  if VVpbNb:
   VVaQAf = self.VV1S95(VVpbNb)
   if VVaQAf:
    VVaQAf.sort(key=lambda x: x[0].lower())
    VV0sV9 += VVaQAf
  if VVFRnH:
   VVFRnH.sort(key=lambda x: x[0].lower())
   VV0sV9 += VVFRnH
  if VV0sV9:
   VVb3Bo  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFI84f(self, None, VVb3Bo=VVb3Bo, VV0sV9=VV0sV9, VVNZlV=widths, VVZ1jJ=22, VVRWle=True)
  else:
   FF0y0a(self, "Could not read info!")
 def VVQ8vS(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFFfb9(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VV1S95(self, mbDict):
  try:
   mbList = list(mbDict)
   VV0sV9 = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VV0sV9.append((FFNMGt(subject, VVvAHa), FFNMGt(value, VVvAHa)))
  except:
   pass
  return VV0sV9
 def VVltZf(self):
  txt = self.VVnwIh("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVnwIh("/proc/bus/nim_sockets")
  if not txt: txt = self.VV1D1S()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FF0y0a(self, txt)
 def VV1D1S(self):
  txt = ""
  VVAf2N = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVAf2N("Slot Name" , slot.getSlotName())
     txt += FFNMGt(slotName, VVvAHa)
     txt += VVAf2N("Description"  , slot.getFullDescription())
     txt += VVAf2N("Frontend ID"  , slot.frontend_id)
     txt += VVAf2N("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVnwIh(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFFfb9(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFNMGt(line, VVvAHa)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VV59Zm(self):
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"   % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FF0y0a(self, txt)
class CCpE0p(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFPc34(VVFqLG, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVleKL = []
  VVleKL.append(("Settings (All)"   , "Settings_All"   ))
  VVleKL.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVleKL.append(("Settings (FHDG-17)"  , "Settings_FHDG_17"  ))
  VVleKL.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVleKL.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVleKL.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVleKL.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVleKL.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFBP5J(self, VVleKL=VVleKL)
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  FFqDc3(self["myMenu"])
  FFQH05(self)
 def VVjeN5(self):
  global VVjhpS
  VVjhpS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FF4lhA(self, cmd                )
   elif item == "Settings_HotKeys"   : FF4lhA(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FF4lhA(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FF4lhA(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FF4lhA(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FF4lhA(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FF4lhA(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FF4lhA(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCmMQn(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFPc34(VVFqLG, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVP1TN, VVEmXY, VVHlnf, camCommand = FFtHtc()
  self.VVEmXY = VVEmXY
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVleKL = []
  VVleKL.append(("OSCam Files"        , "OSCamFiles"  ))
  VVleKL.append(("NCam Files"        , "NCamFiles"  ))
  VVleKL.append(("CCcam Files"        , "CCcamFiles"  ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVleKL.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVleKL.append(VV8ygQ)
  if VVEmXY:
   if   "oscam" in VVEmXY : camName = "OSCam"
   elif "ncam"  in VVEmXY : camName = "NCam"
   VVleKL.append((camName + " Info."      , "camInfo"   ))
   VVleKL.append((camName + " Live Status"    , "camLiveStatus" ))
   VVleKL.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVleKL.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVleKL.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFBP5J(self, VVleKL=VVleKL)
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  FFqDc3(self["myMenu"])
  FFQH05(self)
 def VVjeN5(self):
  global VVjhpS
  VVjhpS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCyUzY, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCyUzY, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCyUzY, "cccam"))
   elif item == "OSCamReaders"  : self.VVcGOb("os")
   elif item == "NSCamReaders"  : self.VVcGOb("n")
   elif item == "camInfo"   : FFxJOT(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFLtSS(self.session, CCnz3S.VVM83t)
   elif item == "camLiveReaders" : FFLtSS(self.session, CCnz3S.VV7CYc)
   elif item == "camLiveLog"  : FFLtSS(self.session, CCnz3S.VVZakG)
   else       : self.close()
 def VVcGOb(self, camPrefix):
  VVLRbU = self.VV5gaY(camPrefix)
  if VVLRbU:
   VVLRbU.sort(key=lambda x: int(x[0]))
   if self.VVEmXY and self.VVEmXY.startswith(camPrefix):
    VVJVgU = ("Toggle State", self.VVn6sX, [camPrefix], "Changing State ...")
   else:
    VVJVgU = None
   VVb3Bo   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVAGqv  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFI84f(self, None, VVb3Bo=VVb3Bo, VV0sV9=VVLRbU, VVAGqv=VVAGqv, VVNZlV=widths, VVZ1jJ=22, VVJVgU=VVJVgU, VVgVDs=True)
 def VV5gaY(self, camPrefix):
  readersFile = self.VVP1TN + camPrefix + "cam.server"
  VVLRbU = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFFfb9(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = FFNMGt("ON", VViUes)
   offStr  = FFNMGt("OFF", VVrETx)
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVLRbU.append((str(len(VVLRbU) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVLRbU:
    FFRwfz(self, "No readers found !")
  else:
   FFiKqP(self, readersFile)
  return VVLRbU
 def VVn6sX(self, VVMzDi, camPrefix):
  configFile  = "%s%scam.conf" % (self.VVP1TN, camPrefix)
  readerState  = VVMzDi.VVOxOZ(1)
  readerLabel  = VVMzDi.VVOxOZ(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = FFUqNW(self, camPrefix, configFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, urlopen, URLError, elementTree, url = urlStuff
   try:
    page = urlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVMzDi.VVszJj()
    FFRwfz(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVLRbU = self.VV5gaY(camPrefix)
   if VVLRbU:
    VVMzDi.VVVImv(VVLRbU)
class CCyUzY(Screen):
 def __init__(self, VVaWEr, session, args=0):
  self.skin, self.skinParam = FFPc34(VVFqLG, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVP1TN, VVEmXY, VVHlnf, camCommand = FFtHtc()
  if   VVaWEr == "ncam" : self.prefix = "n"
  elif VVaWEr == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVleKL = []
  if self.prefix == "":
   VVleKL.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVleKL.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVleKL.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVleKL.append(("constant.cw"         , "x_constant_cw" ))
   VVleKL.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVleKL.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVleKL.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVleKL.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVleKL.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVleKL.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVleKL.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVleKL.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVleKL.append(VV8ygQ)
   VVleKL.append(("SoftCam.Key"         , "x_SoftCam_Key" ))
   VVleKL.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVleKL.append(VV8ygQ)
   VVleKL.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVleKL.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVleKL.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFBP5J(self, VVleKL=VVleKL)
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  FFqDc3(self["myMenu"])
  FFQH05(self)
 def VVjeN5(self):
  global VVjhpS
  VVjhpS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFNAd3(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFNAd3(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFNAd3(self, self.VVP1TN + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFNAd3(self, self.VVP1TN + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVFeEH("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVFeEH("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVFeEH("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVFeEH("cam.provid"        )
   elif item == "x_cam_server"  : self.VVFeEH("cam.server"        )
   elif item == "x_cam_services" : self.VVFeEH("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVFeEH("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVFeEH("cam.user"        )
   elif item == "x_VVuDI9"   : pass
   elif item == "x_SoftCam_Key" : FFNAd3(self, self.VVP1TN + "SoftCam.Key"   )
   elif item == "x_CCcam_cfg"  : FFNAd3(self, self.VVP1TN + "CCcam.cfg"    )
   elif item == "x_VVuDI9"   : pass
   elif item == "x_cam_log"  : FFNAd3(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFNAd3(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFNAd3(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVFeEH(self, fileName):
  FFNAd3(self, self.VVP1TN + self.prefix + fileName)
class CCnz3S(Screen):
 VVM83t  = 0
 VV7CYc = 1
 VVZakG = 2
 def __init__(self, session, VVP1TN="", VVEmXY="", VVHlnf="", VVkofC=VVM83t):
  self.skin, self.skinParam = FFPc34(VVB5d2, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVHlnf   = VVHlnf
  self.VVkofC  = VVkofC
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVP1TN + VVEmXY + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.urlopen   = None
  self.URLError   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVEmXY : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.configFile  = "%s%scam.conf" % (VVP1TN, self.camPrefix)
  if self.VVkofC == self.VVM83t:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVkofC == self.VV7CYc:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFBP5J(self, self.Title, addScrollLabel=True)
  FF0WGA(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVWH96
  self.onShown.append(self.VVTwK9)
  self.onClose.append(self.onExit)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  self["myLabel"].VV2Sqk(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFoFoL(self)
  self.VVWH96()
 def onExit(self):
  self.timer.stop()
 def VVsUyx(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVoJO5)
  except:
   self.timer.callback.append(self.VVoJO5)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFVyro(self, "Started", 1000)
 def VVwGB4(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVoJO5)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFVyro(self, "Stopped", 1000)
 def VVWH96(self):
  if self.timerRunning:
   self.VVwGB4()
  else:
   self.VVsUyx()
   if self.VVkofC == self.VVM83t or self.VVkofC == self.VV7CYc:
    if self.VVkofC == self.VVM83t : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = FFUqNW(self, self.camPrefix, self.configFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.urlopen, self.URLError, self.elementTree, url = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFYs6W(self.VVixs9)
    else:
     self.close()
   else:
    self.VVEFAs()
 def VVoJO5(self):
  if self.timerRunning:
   if   self.VVkofC == self.VVM83t : self.VVQ5HH()
   elif self.VVkofC == self.VV7CYc : self.VVQ5HH()
   else            : self.VVEFAs()
 def VVEFAs(self):
  if fileExists(self.VVHlnf):
   fTime = FFCgGR(os.path.getmtime(self.VVHlnf))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVFUsJ(), VVPBLI=VVVWeh)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVHlnf)
 def VVixs9(self):
  self.VVQ5HH()
 def VVQ5HH(self):
  err = ""
  try:
   page = self.urlopen(self.UrlRequest, timeout=1).read()
  except self.URLError as e:
   if hasattr(e, "code") : err = "Error Code : %s" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFNMGt("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVxYDU))
   self.camWebIfErrorFound = True
   self.VVwGB4()
   return
  page = page.decode('UTF-8')
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVkofC == self.VVM83t : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFNMGt("Error while parsing data elements !\n\nError = %s" % str(e), VVK65K)
   self.camWebIfErrorFound = True
   self.VVwGB4()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVnCxe(root)
  self["myLabel"].setText(txt, VVPBLI=VVVWeh)
  self["myBar"].setText("Last Update : %s" % FFftoO())
 def VVnCxe(self, rootElement):
  def VVAf2N(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVkofC == self.VVM83t:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFNMGt(status, VViUes)
    else          : status = FFNMGt(status, VVK65K)
    txt += VVuDI9 + "\n"
    txt += VVAf2N("Name"  , name)
    txt += VVAf2N("Description" , desc)
    txt += VVAf2N("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVAf2N("Protocol" , protocol)
    txt += VVAf2N("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFNMGt("Yes", VViUes)
    else    : enabTxt = FFNMGt("No", VVK65K)
    txt += VVuDI9 + "\n"
    txt += VVAf2N("Label"  , label)
    txt += VVAf2N("Protocol" , protocol)
    txt += VVAf2N("Enabled" , enabTxt)
  return txt
 def VVFUsJ(self):
  wordsDict = self.VV7t98()
  color = [ VVvAHa, VVy7KO, VViUes, VVK65K, VVvs8y, VVbTiz]
  lines = FFnzIb("tail -n %d %s" % (100, self.VVHlnf))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVxYDU + line[:19] + VVrETx + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVMR5q + line[ndx + 3:] + VVrETx
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVvAHa + line[ndx + 8 : ndx1 + 4] + VVrETx + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVrETx)
   elif line.startswith("----") or ">>" in line:
    line = FFNMGt(line, VVvAHa)
   txt += line + "\n"
  return txt
 def VV7t98(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFFfb9(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCRm1J(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFPc34(VVFqLG, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVleKL = []
  VVleKL.append(("Backup Channels"        , "VV9Tb2"   ))
  VVleKL.append(("Restore Channels"        , "Restore_Channels"  ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Backup SoftCAM Files"       , "VV7A7I" ))
  VVleKL.append(("Restore SoftCAM Files"      , "Restore_SoftCAM_Files" ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Backup Tuner Settings"      , "Backup_TunerDiSEqC"  ))
  VVleKL.append(("Restore Tuner Settings"      , "Restore_TunerDiSEqC"  ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Backup HotKeys & FHDG17 Settings"    , "Backup_Hotkey_FHDG17" ))
  VVleKL.append(("Restore HotKeys & FHDG17 Settings"   , "Restore_Hotkey_FHDG17" ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Backup Network Settings"      , "VVKwmR"   ))
  VVleKL.append(("Restore Network Settings"      , "Restore_Network"   ))
  if VVUMBX:
   VVleKL.append(VV8ygQ)
   VVleKL.append((VVxYDU + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME , "VVa3A7"   ))
   VVleKL.append((VViUes + "2- Create %s for IPK"   % PLUGIN_NAME , "createMyIpk"   ))
   VVleKL.append((VViUes + "3- Create %s for DEB"   % PLUGIN_NAME , "createMyDeb"   ))
   VVleKL.append((VVvs8y + "Create %s TAR (Absolute Path)" % PLUGIN_NAME , "createMyTar"   ))
   VVleKL.append((VVvs8y + "Decode %s Crash Report"   % PLUGIN_NAME , "VVREiC" ))
  FFBP5J(self, VVleKL=VVleKL)
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  FFqDc3(self["myMenu"])
  FFQH05(self)
 def VVjeN5(self):
  global VVjhpS
  VVjhpS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VV9Tb2"    : self.VV9Tb2()
   elif item == "Restore_Channels"    : self.VVl9E9("channels_backup*.tar.gz", self.VVp4go)
   elif item == "VV7A7I"   : self.VV7A7I()
   elif item == "Restore_SoftCAM_Files"  : self.VVl9E9("softcam_backup*.tar.gz", self.VVwKA9)
   elif item == "Backup_TunerDiSEqC"   : self.VVhNPr("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVl9E9("tuner_backup*.backup", boundFunction(self.VVPH8x, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVhNPr("hotkey_fhdg17_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVl9E9("hotkey_fhdg17_backup*.backup", boundFunction(self.VVPH8x, "misc"))
   elif item == "VVKwmR"    : self.VVKwmR()
   elif item == "Restore_Network"    : self.VVl9E9("network_backup*.tar.gz", self.VVa1r6)
   elif item == "VVa3A7"     : FFQsdM(self, boundFunction(FF2E2r, self, boundFunction(CCRm1J.VVa3A7, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVMeom(False)
   elif item == "createMyDeb"     : self.VVMeom(True)
   elif item == "createMyTar"     : self.VV8PAH()
   elif item == "VVREiC"   : self.VVREiC()
 @staticmethod
 def VVa3A7(SELF):
  OBF_Path = VVpP63 + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVpP63, VVB14v, VVzZMh)
   if err : FFRwfz(SELF, err)
   else : FF0y0a(SELF, txt)
  else:
   FFiKqP(SELF, OBF_Path)
 def VVMeom(self, VVdr4e):
  OBF_Path = VVpP63 + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFRwfz(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVpP63)
  os.system("mv -f %s %s" % (VVpP63 + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVpP63 + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVpP63 + "plugin.py"))
  self.session.openWithCallback(self.VVMeom1, boundFunction(CCNoYo, path=VVpP63, VVdr4e=VVdr4e))
 def VVMeom1(self):
  os.system("mv -f %s %s" % (VVpP63 + "OBF/main.py"  , VVpP63))
  os.system("mv -f %s %s" % (VVpP63 + "OBF/plugin.py" , VVpP63))
 def VVREiC(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFRwfz(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFRwfz(self, "No log files in:\n\n%s" % path)
   return
  VV0sV9 = []
  for f in files:
   f = os.path.basename(f)
   VV0sV9.append((f, f))
  FF7X20(self, boundFunction(self.VVyp7P, path), VVleKL=VV0sV9)
 def VVyp7P(self, path, item=None):
  if item:
   codF = ""
   cFiles = iGlob("%s*.list" % path)
   if cFiles:
    codF = cFiles[0]
    if fileExists(codF):
     logF = path + item
     if fileExists(logF):
      lst  = []
      lines = FFFfb9(codF)
      for line in lines:
       line = line.split(":")[1]
       parts = line.split("->")
       lst.append((parts[1].strip(), parts[0].strip()))
      if lst:
       logTxt = FFMmfA(logF)
       for item in lst:
        logTxt = logTxt.replace(item[0], item[1])
       resF = logF + ".decoded.log"
       with open(resF, "w") as f:
        f.write(logTxt)
       FFVXKI(self, "Output File:\n\n%s" % resF)
      else: FFRwfz(self, "No codes in : %s" % codF)
     else: FFiKqP(self, logF)
   else: FFiKqP(self, codF)
 def VV8PAH(self):
  VV0sV9 = []
  VV0sV9.append("%s%s" % (VVpP63, "*.py"))
  VV0sV9.append("%s%s" % (VVpP63, "*.png"))
  VV0sV9.append("%s%s" % (VVpP63, "*.xml"))
  VV0sV9.append("%s"  % (VVfX8s))
  FFnEDZ(self, VV0sV9, "%s_%s" % (PLUGIN_NAME, VVB14v), addTimeStamp=False)
 def VV9Tb2(self):
  path1 = VVVuM0
  path2 = "/etc/tuxbox/"
  VV0sV9 = []
  VV0sV9.append("%s%s" % (path1, "*.tv"))
  VV0sV9.append("%s%s" % (path1, "*.radio"))
  VV0sV9.append("%s%s" % (path1, "*list"))
  VV0sV9.append("%s%s" % (path1, "lamedb*"))
  VV0sV9.append("%s%s" % (path2, "*.xml"))
  FFnEDZ(self, VV0sV9, "channels_backup", addTimeStamp=True)
 def VV7A7I(self):
  VV0sV9 = []
  VV0sV9.append("/etc/tuxbox/config/")
  VV0sV9.append("/usr/keys/")
  VV0sV9.append("/usr/scam/")
  VV0sV9.append("/etc/CCcam.cfg")
  FFnEDZ(self, VV0sV9, "softcam_backup", addTimeStamp=True)
 def VVKwmR(self):
  VV0sV9 = []
  VV0sV9.append("/etc/hostname")
  VV0sV9.append("/etc/default_gw")
  VV0sV9.append("/etc/resolv.conf")
  VV0sV9.append("/etc/wpa_supplicant*.conf")
  VV0sV9.append("/etc/network/interfaces")
  VV0sV9.append("/etc/enigma2/nameserversdns.conf")
  FFnEDZ(self, VV0sV9, "network_backup", addTimeStamp=True)
 def VVp4go(self, fileName):
  if fileName:
   FFQsdM(self, boundFunction(self.VVlrfj, fileName), "Overwrite current channels ?")
 def VVlrfj(self, fileName):
  path = "%s%s" % (VV84Zp, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCXkK1.VVYsuD()
   lamedb5File, diabled5File = CCXkK1.VVOe0w()
   cmd = ""
   cmd += FFZNvw("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFZNvw("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFb09f()
   if res == 0 : FFVXKI(self, "Channels Restored.")
   else  : FFRwfz(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFiKqP(self, path)
 def VVwKA9(self, fileName):
  if fileName:
   FFQsdM(self, boundFunction(self.VVOPzC, fileName), "Overwrite SoftCAM files ?")
 def VVOPzC(self, fileName):
  fileName = "%s%s" % (VV84Zp, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVuDI9
   note = "You may need to restart your SoftCAM."
   FFVfjo(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFbAJE(note, VVvAHa), sep))
  else:
   FFiKqP(self, fileName)
 def VVa1r6(self, fileName):
  if fileName:
   FFQsdM(self, boundFunction(self.VVEGH6, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVEGH6(self, fileName):
  fileName = "%s%s" % (VV84Zp, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFhgGU(self,  cmd)
  else:
   FFiKqP(self, fileName)
 def VVl9E9(self, pattern, callBackFunction, isTuner=False):
  title = FFAA5z()
  if pathExists(VV84Zp):
   myFiles = iGlob("%s%s" % (VV84Zp, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VV0sV9 = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VV0sV9.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVrIGp = ("Sat. List", self.VVZDMW)
    else  : VVrIGp = None
    FF7X20(self, callBackFunction, title=title, VVleKL=VV0sV9, VVrIGp=VVrIGp)
   else:
    FFRwfz(self, "No files found in:\n\n%s" % VV84Zp, title)
  else:
   FFRwfz(self, "Path not found:\n\n%s" % VV84Zp, title)
 def VVhNPr(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CChFBB()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VVkrzq, filePrefix))
 def VVkrzq(self, filePrefix, result, retval):
  title = FFAA5z()
  if pathExists(VV84Zp):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFRwfz(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VV84Zp, filePrefix, FFGx0i())
    try:
     VV0sV9 = str(result.strip()).split()
     if VV0sV9:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VV0sV9:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVuDI9, FFNMGt(fName, VVvAHa), VVuDI9)
       FF0y0a(self, txt, title=title, VVPBLI=VVVWeh)
      else:
       FFRwfz(self, "File creation failed!", title)
     else:
      FFRwfz(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFZNvw("rm %s" % fName))
     FFRwfz(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFZNvw("rm %s" % fName))
     FFRwfz(self, "Error while writing file.")
  else:
   FFRwfz(self, "Path not found:\n\n%s" % VV84Zp, title)
 def VVPH8x(self, mode, path):
  if path:
   path = "%s%s" % (VV84Zp, path)
   if fileExists(path):
    lines = FFFfb9(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys/FHDG17"
     FFQsdM(self, boundFunction(self.VV28zC, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FF96ug(self, path, title=FFAA5z())
   else:
    FFiKqP(self, path)
 def VV28zC(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VV60Bm = []
  VV60Bm.append("echo -e 'Reading current settings ...'")
  VV60Bm.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VV60Bm.append("echo -e 'Preparing new settings ...'")
  VV60Bm.append(settingsLines)
  VV60Bm.append("echo -e 'Applying new settings ...'")
  VV60Bm.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FF1Buo(self, VV60Bm)
 def VVZDMW(self, VVxnlbObj, path):
  if not path:
   return
  path = VV84Zp + path
  if not fileExists(path):
   FFiKqP(self, path)
   return
  txt = FFMmfA(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VV0sV9  = []
   for item in satList:
    VV0sV9.append("%s\t%s" % (item[0], FFzqHs(item[1])))
   FF0y0a(self, VV0sV9, title="  Satellites List")
  else:
   FFRwfz(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCC2vw(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFPc34(VVFqLG, 850, 700, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVleKL = []
  VVleKL.append(("Plugins Browser List"       , "VVrUsi"   ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVleKL.append(("Installed Packages (all)"      , "installedPackagesAll"  ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Remove Packages (Plugin/SoftCAM/Skin)"  , "removePluginSkinSoftCAM"  ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Update List of Available Packages"   , "VVinkj"   ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Packaging Tool"        , "VVq10p"    ))
  VVleKL.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFBP5J(self, VVleKL=VVleKL)
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  FFqDc3(self["myMenu"])
  FFQH05(self)
 def VVjeN5(self):
  global VVjhpS
  VVjhpS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVrUsi"   : self.VVrUsi()
   elif item == "pluginsDirList"    : self.VVoHJ8()
   elif item == "installedPackagesAll"     : FF2E2r(self, boundFunction(self.VVk6dW, 0, ""))
   elif item == "removePluginSkinSoftCAM"  : FF2E2r(self, boundFunction(self.VVk6dW, 1, "| grep -e skin -e enigma2-"))
   elif item == "downloadInstallPackages"  : FF2E2r(self, boundFunction(self.VVk6dW, 2, ""))
   elif item == "VVinkj"   : self.VVinkj()
   elif item == "VVq10p"    : self.VVq10p()
   elif item == "packagesFeeds"    : self.VVTh4J()
   else          : self.close()
 def VVoHJ8(self):
  extDirs  = FFTTCX(VVIuMA)
  sysDirs  = FFTTCX(VVAoPn)
  VV0sV9  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VV0sV9.append((item, VVIuMA + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VV0sV9.append((item, VVAoPn + item))
  if VV0sV9:
   VV0sV9 = sorted(VV0sV9, key=lambda x: x[0].lower())
   VVbtTj = ("Package Info.", self.VV0yHk, [])
   VVb3Bo   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFI84f(self, None, VVb3Bo=VVb3Bo, VV0sV9=VV0sV9, VVNZlV=widths, VVZ1jJ=28, VVbtTj=VVbtTj)
  else:
   FFRwfz(self, "Nothing found!")
 def VV0yHk(self, VVMzDi, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVIuMA) : loc = "extensions"
  elif path.startswith(VVAoPn) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VV2Wpz(package)
  else:
   FFRwfz(self, "No info!")
 def VVTh4J(self):
  pkg = FF1cg4()
  if pkg : FF4lhA(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFxXZG(self)
 def VVrUsi(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVAf2N(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVuDI9 + "\n"
    txt += VVAf2N("Number"   , str(c))
    txt += VVAf2N("Name"   , FFNMGt(str(p.name), VVvAHa))
    txt += VVAf2N("Path"  , p.path  )
    txt += VVAf2N("Description" , p.description )
    txt += VVAf2N("Icon"  , p.iconstr  )
    txt += VVAf2N("Wakeup Fnc" , p.wakeupfnc   )
    txt += VVAf2N("NeedsRestart", p.needsRestart)
    txt += VVAf2N("Internal" , p.internal )
    txt += VVAf2N("Weight"  , p.weight      ) + "\n"
    c += 1
   except:
    pass
  FF0y0a(self, txt)
 def VVinkj(self):
  cmd = FFNDYc(VVcHIJ, "")
  if cmd : FFhgGU(self, cmd, checkNetAccess=True)
  else : FFxXZG(self)
 def VVq10p(self):
  pkg = FF1cg4()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFVXKI(self, txt)
 def VVk6dW(self, mode, grep, VVMzDi=None, title=""):
  if   mode == 0: cmd = FFNDYc(VVjaB3 , grep)
  elif mode == 1: cmd = FFNDYc(VVjaB3 , grep)
  elif mode == 2: cmd = FFNDYc(VVtllz    , grep)
  if not cmd:
   FFxXZG(self)
   return
  VVLRbU = FFnzIb(cmd)
  if not VVLRbU:
   if VVMzDi: VVMzDi.VVszJj()
   FFRwfz(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VV0sV9  = []
  for item in VVLRbU:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VV0sV9.append((name, package, version))
  if mode == 1:
   extensions = FFnzIb("ls %s -l | grep '^d' | awk '{print $9}'" % VVIuMA)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VV0sV9:
      if item.lower() == row[0].lower():
       break
     else:
      VV0sV9.append((item, VVIuMA + item, "-"))
   systemPlugins = FFnzIb("ls %s -l | grep '^d' | awk '{print $9}'" % VVAoPn)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VV0sV9:
      if item.lower() == row[0].lower():
       break
     else:
      VV0sV9.append((item, VVAoPn + item, "-"))
  if not VV0sV9:
   FFRwfz(self, "No packages found!")
   return
  if VVMzDi:
   VV0sV9.sort(key=lambda x: x[0].lower())
   VVMzDi.VVVImv(VV0sV9, title)
  else:
   widths = (20, 50, 30)
   if mode == 0:
    VVGrFS = None
    VVJVgU = None
    VVRqTs = None
   elif mode == 1:
    VVGrFS = ("Uninstall", self.VVyKiS, [])
    VVJVgU = None
    VVRqTs = None
    widths= (18, 57, 25)
   elif mode == 2:
    VVGrFS = ("Install" , self.VVJd5d   , [])
    VVJVgU = ("Download" , self.VVo4Cl   , [])
    VVRqTs = ("Filter"  , self.VVxMef , [])
   VV0sV9 = sorted(VV0sV9, key=lambda x: x[0].lower())
   VVbtTj = ("Package Info.", self.VV8fwR, [])
   VVb3Bo   = ("Name" ,"Package" , "Version" )
   FFI84f(self, None, VVb3Bo=VVb3Bo, VV0sV9=VV0sV9, VVNZlV=widths, VVZ1jJ=24, VVGrFS=VVGrFS, VVJVgU=VVJVgU, VVbtTj=VVbtTj, VVRqTs=VVRqTs, VVyBeo=self.lastSelectedRow
     , VVgxh0="#22110011", VVd0OK="#22191111", VVV3xM="#22191111", VVt3ai="#00003030", VVtlnJ="#00333333")
 def VV8fwR(self, VVMzDi, title, txt, colList):
  package  = colList[1]
  self.VV2Wpz(package)
 def VVxMef(self, VVMzDi, title, txt, colList):
  words = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVleKL = []
  VVleKL.append(("All Packages", "all"))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVleKL.append(VV8ygQ)
  for word in words:
   VVleKL.append((word, word))
  FF7X20(self, boundFunction(self.VVIg4z, VVMzDi), VVleKL=VVleKL, title="Select Filter")
 def VVIg4z(self, VVMzDi, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FF2E2r(VVMzDi, boundFunction(self.VVk6dW, 2, grep, VVMzDi, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVyKiS(self, VVMzDi, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVIuMA, VVAoPn)):
   FFQsdM(self, boundFunction(self.VVjCSQ, VVMzDi, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVleKL = []
   VVleKL.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVleKL.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVleKL.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FF7X20(self, boundFunction(self.VVQmpO, VVMzDi, package), VVleKL=VVleKL)
 def VVjCSQ(self, VVMzDi, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVL7Mj)
  FFhgGU(self, cmd, VVBoHg=boundFunction(self.VVsGwD, VVMzDi))
 def VVQmpO(self, VVMzDi, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVl3jj
   elif item == "remove_ForceRemove"  : cmdOpt = VVR2nU
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVm34V
   FFQsdM(self, boundFunction(self.VVLbow, VVMzDi, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVLbow(self, VVMzDi, package, cmdOpt):
  self.lastSelectedRow = VVMzDi.VVlfrz()
  cmd = FFqpep(cmdOpt, package)
  if cmd : FFhgGU(self, cmd, VVBoHg=boundFunction(self.VVsGwD, VVMzDi))
  else : FFxXZG(self)
 def VVsGwD(self, VVMzDi):
  VVMzDi.cancel()
  FFzH73()
 def VVJd5d(self, VVMzDi, title, txt, colList):
  package  = colList[1]
  VVleKL = []
  VVleKL.append(("Install Package"         , "install_CheckVersion" ))
  VVleKL.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVleKL.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVleKL.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FF7X20(self, boundFunction(self.VVi2CJ, package), VVleKL=VVleKL)
 def VVi2CJ(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVQ9eZ
   elif item == "install_ForceReinstall" : cmdOpt = VVfS86
   elif item == "install_ForceDowngrade" : cmdOpt = VVMAst
   elif item == "install_IgnoreDepends" : cmdOpt = VVloSO
   FFQsdM(self, boundFunction(self.VVQt11, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVQt11(self, package, cmdOpt):
  cmd = FFqpep(cmdOpt, package)
  if cmd : FFhgGU(self, cmd, VVBoHg=FFzH73, checkNetAccess=True)
  else : FFxXZG(self)
 def VVo4Cl(self, VVMzDi, title, txt, colList):
  package  = colList[1]
  FFQsdM(self, boundFunction(self.VVnBB0, package), "Download Package ?\n\n%s" % package)
 def VVnBB0(self, package):
  if FF8zDj():
   cmd = FFqpep(VVhbLh, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFbAJE(success, VViUes))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFbAJE(fail, VVK65K))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFhgGU(self, cmd, VVjiUW=[VVK65K, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFxXZG(self)
  else:
   FFRwfz(self, "No internet connection !")
 def VV2Wpz(self, package):
  infoCmd  = FFqpep(VV8zER, package)
  filesCmd = FFqpep(VVtU5k, package)
  listInstCmd = FFNDYc(VVjaB3, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFHr04(VVvAHa)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFbAJE(notInst, VVxYDU))
   cmd += "else "
   cmd +=   FFA6oY("System Info", VVvAHa)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFA6oY("Related Files", VVvAHa)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFfQ52(self, cmd)
  else:
   FFxXZG(self)
class CCXkK1(Screen):
 VVnQCL  = 0
 VVtvGt = 1
 VVt1BA  = 2
 VVsXId  = 3
 VVxXGO = 4
 VV98a1 = 5
 VV4ebV = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFPc34(VVFqLG, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVGhjd = None
  self.lastfilterUsed  = None
  VVleKL = self.VVtHsf()
  FFBP5J(self, VVleKL=VVleKL, title="Services/Channels")
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self["myMenu"].setList(self.VVtHsf())
  FFqDc3(self["myMenu"])
  FFQH05(self)
 def VVtHsf(self):
  VVleKL = []
  VVleKL.append(("Current Service (Signal Monitor)"   , "currentServiceSignal"    ))
  VVleKL.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Services (Reference)"      , "lameDB_allChannels_with_refCode"  ))
  VVleKL.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVleKL.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVleKL.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVleKL.append(("Services with PIcons for the System"  , "VVsCFs"     ))
  VVleKL.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVleKL.append(VV8ygQ)
  lamedbFile, disabledFile = CCXkK1.VVYsuD()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVleKL.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVleKL.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVleKL.append(("Reset Parental Control Settings"   , "VVmRHr"    ))
  VVleKL.append(("Delete Channels with no names"   , "VVH7KP"    ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Reload Channels and Bouquets"    , "VVUB1J"      ))
  return VVleKL
 def VVjeN5(self):
  global VVjhpS
  VVjhpS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFiTcK(self)
   elif item == "currentServiceInfo"     : self.session.open(CCgisO)
   elif item == "TranspondersStats"     : FF2E2r(self, self.VVEZTY     )
   elif item == "lameDB_allChannels_with_refCode"  : FF2E2r(self, self.VV5oZg )
   elif item == "lameDB_allChannels_with_tranaponder" : FF2E2r(self, self.VVuVMd)
   elif item == "lameDB_allChannels_with_details"  : FF2E2r(self, self.VVgju2 )
   elif item == "parentalControlChannels"    : FF2E2r(self, self.VVMEPY   )
   elif item == "showHiddenChannels"     : FF2E2r(self, self.VVrDYK     )
   elif item == "VVsCFs"     : FF2E2r(self, self.VVB1Ef     )
   elif item == "servicesWithMissingPIcons"   : FF2E2r(self, self.VVvRa8   )
   elif item == "enableHiddenChannels"     : self.VV3kzm(True)
   elif item == "disableHiddenChannels"    : self.VV3kzm(False)
   elif item == "VVmRHr"    : FFQsdM(self, self.VVmRHr, "Reset and Restart ?" )
   elif item == "VVH7KP"    : FF2E2r(self, self.VVH7KP)
   elif item == "VVUB1J"      : FF2E2r(self, boundFunction(CCXkK1.VVUB1J, self))
   else            : self.close()
 @staticmethod
 def VVUB1J(SELF):
  FFb09f()
  FFVXKI(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VV5oZg(self):
  self.VVGhjd = None
  self.lastfilterUsed  = None
  self.filterObj   = CCiBgE(self)
  VVLRbU = CCXkK1.VVXUi6(self, self.VVnQCL)
  if VVLRbU:
   VVLRbU.sort(key=lambda x: x[0].lower())
   VV7bTo  = ("Zap"   , self.VV3t42     , [])
   VVpzw6 = (""    , self.VVQVAE   , [])
   VVbtTj = ("Options"  , self.VV6sJQ , [])
   VVJVgU = ("Current Service", self.VV1Cge , [])
   VVRqTs = ("Filter"   , self.VVtOEJ  , [], "Loading Filters ...")
   VVb3Bo   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVAGqv  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFI84f(self, None, VVb3Bo=VVb3Bo, VV0sV9=VVLRbU, VVAGqv=VVAGqv, VVNZlV=widths, VVZ1jJ=22, VV7bTo=VV7bTo, VVpzw6=VVpzw6, VVJVgU=VVJVgU, VVbtTj=VVbtTj, VVRqTs=VVRqTs)
 def VVuVMd(self):
  self.VVGhjd = None
  self.lastfilterUsed  = None
  self.filterObj   = CCiBgE(self)
  VVLRbU = CCXkK1.VVXUi6(self, self.VVtvGt)
  if VVLRbU:
   VVLRbU.sort(key=lambda x: x[0].lower())
   VV7bTo  = ("Zap"   , self.VV3t42      , [])
   VVpzw6 = (""    , self.VVQVAE    , [])
   VVJVgU = ("Current Service", self.VV1Cge  , [])
   VVbtTj = ("Options"  , self.VViusA , [])
   VVRqTs = ("Filter"   , self.VVfTKu  , [], "Loading Filters ...")
   VVb3Bo   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVAGqv  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFI84f(self, None, VVb3Bo=VVb3Bo, VV0sV9=VVLRbU, VVAGqv=VVAGqv, VVNZlV=widths, VVZ1jJ=22, VV7bTo=VV7bTo, VVpzw6=VVpzw6, VVJVgU=VVJVgU, VVbtTj=VVbtTj, VVRqTs=VVRqTs)
 def VV6sJQ(self, VVMzDi, title, txt, colList):
  servName = colList[0]
  refCode  = colList[3]
  pcState  = colList[4]
  hidState = colList[5]
  mSel  = CC6EK5(self, VVMzDi, 3)
  mSel.VVMGt8(servName, refCode, pcState, hidState)
 def VViusA(self, VVMzDi, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CC6EK5(self, VVMzDi, 3)
  mSel.VVUXi9(servName, refCode)
 def VV3msU(self, VVMzDi, refCode, isAddToBlackList):
  self.VVGhjd = None
  self.lastfilterUsed  = None
  VVMzDi.VVPLYE("Changing state ...")
  path = "/etc/enigma2/blacklist"
  if not fileExists(path):
   os.system("echo '' > %s" % path)
  if fileExists(path):
   if not refCode.endswith(":"):
    refCode += ":"
   if isAddToBlackList :
    os.system("sed -i '/%s/d' %s" % (refCode, path))
    os.system("echo '%s' >> %s" % (refCode, path))
   else:
    os.system("sed -i '/%s/d' %s" % (refCode, path))
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   if refCode.endswith(":"):
    refCode = refCode[:-1]
   FF2E2r(self, boundFunction(self.VVz7As, VVMzDi, refCode))
  else:
   FFiKqP(self, path)
 def VVRhtC(self, VVMzDi, refCode, isHide):
  self.VVGhjd = None
  self.lastfilterUsed  = None
  VVMzDi.VVPLYE("Changing state ...")
  if FFxbuy(refCode):
   ret = FFoQXt(refCode, isHide)
   if ret : FF2E2r(self, boundFunction(self.VVz7As, VVMzDi, refCode))
   else : FFRwfz(self, "Cannot Hide/Unhide this channel.")
  else:
   FFRwfz(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)")
 def VVz7As(self, VVMzDi, refCode):
  VVLRbU = CCXkK1.VVXUi6(self, self.VVnQCL, VVZg4g=[3, [refCode], False])
  done = False
  if VVLRbU:
   data = VVLRbU[0]
   if data[3] == refCode:
    done = VVMzDi.VVJiWq(data)
  if not done:
   self.VVaDDq(VVMzDi, VVMzDi.VV12KJ(), self.VVnQCL)
  VVMzDi.VVszJj()
 def VVtOEJ(self, VVMzDi, title, txt, colList):
  self.filterObj.VVMr8s(1, VVMzDi, 2, boundFunction(self.VVBOZM, VVMzDi))
 def VVBOZM(self, VVMzDi, item):
  self.VVtoQY(VVMzDi, item, 2, self.VVnQCL)
 def VVfTKu(self, VVMzDi, title, txt, colList):
  self.filterObj.VVMr8s(2, VVMzDi, 4, boundFunction(self.VVWX7i, VVMzDi))
 def VVWX7i(self, VVMzDi, item):
  self.VVtoQY(VVMzDi, item, 4, self.VVtvGt)
 def VVPrlp(self, VVMzDi, title, txt, colList):
  self.filterObj.VVMr8s(0, VVMzDi, 4, boundFunction(self.VVHTfD, VVMzDi))
 def VVHTfD(self, VVMzDi, item):
  self.VVtoQY(VVMzDi, item, 4, self.VVt1BA)
 def VVtoQY(self, VVMzDi, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVMzDi.VVOxOZ(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVGhjd = None
  else:
   words, asPrefix = CCiBgE.VVSxZN(words)
   self.VVGhjd = [col, words, asPrefix]
  if not words:
   FFVyro(VVMzDi, "Incorrect filter", 2000)
  else:
   VVMzDi.VVPLYE("Reading Services ...")
   FF2E2r(self, boundFunction(self.VVaDDq, VVMzDi, title, mode))
 def VVaDDq(self, VVMzDi, title, mode):
  VVLRbU = CCXkK1.VVXUi6(self, mode, VVZg4g=self.VVGhjd, VVFeLp=False)
  if VVLRbU:
   VVLRbU.sort(key=lambda x: x[0].lower())
   VVMzDi.VVVImv(VVLRbU, title)
  else:
   VVMzDi.VVszJj()
   FFVyro(VVMzDi, "Not found!", 1500)
 def VVcE8k(self, VV0sV9, VV7bTo=None, VVpzw6=None, VVGrFS=None, VVJVgU=None, VVbtTj=None, VVRqTs=None):
  VVJVgU = ("Current Service", self.VV1Cge, [], )
  VVb3Bo  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVAGqv = (LEFT  , LEFT  , CENTER, LEFT    )
  FFI84f(self, None, VVb3Bo=VVb3Bo, VV0sV9=VV0sV9, VVAGqv=VVAGqv, VVNZlV=widths, VVZ1jJ=24, VV7bTo=VV7bTo, VVpzw6=VVpzw6, VVGrFS=VVGrFS, VVJVgU=VVJVgU, VVbtTj=VVbtTj, VVRqTs=VVRqTs)
 def VV1Cge(self, VVMzDi, title, txt, colList):
  self.VVLNgL(VVMzDi)
 def VV97DZ(self, VVMzDi, title, txt, colList):
  self.VVLNgL(VVMzDi, True)
 def VVLNgL(self, VVMzDi, isFromDetails=False):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFDq4f(self)
  if refCode:
   if isFromDetails:
    chName  = info.getName()
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVMzDi.VVzvPP(colDict, showErr=True)
   else:
    VVMzDi.VV6hTi(3, refCode, True)
   return
  FFRwfz(self, "Colud not read current Reference Code !")
 def VVgju2(self):
  self.VVGhjd = None
  self.lastfilterUsed  = None
  self.filterObj   = CCiBgE(self)
  VVLRbU = CCXkK1.VVXUi6(self, self.VVt1BA)
  if VVLRbU:
   VVLRbU.sort(key=lambda x: x[0].lower())
   VVpzw6 = (""    , self.VVb3rx , []      )
   VVJVgU = ("Current Service", self.VV97DZ  , []      )
   VVRqTs = ("Filter"   , self.VVPrlp   , [], "Loading Filters ..." )
   VV7bTo  = ("Zap"   , self.VVeEf4      , []      )
   VVb3Bo   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVAGqv  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFI84f(self, None, VVb3Bo=VVb3Bo, VV0sV9=VVLRbU, VVAGqv=VVAGqv, VVNZlV=widths, VVZ1jJ=24, VV7bTo=VV7bTo, VVpzw6=VVpzw6, VVJVgU=VVJVgU, VVRqTs=VVRqTs)
 def VVb3rx(self, VVMzDi, title, txt, colList):
  refCode  = self.VV1F5U(colList)
  chName  = colList[0]
  png, path = CCpLfD.VVs7r4(refCode, chName)
  txt   += "Reference\t: %s" % refCode
  FF0y0a(self, txt, title=title, VVfzL0=path)
 def VVeEf4(self, VVMzDi, title, txt, colList):
  refCode = self.VV1F5U(colList)
  FFM38n(self, refCode)
 def VV3t42(self, VVMzDi, title, txt, colList):
  FFM38n(self, colList[3])
 def VV1F5U(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVXUi6(SELF, mode, VVZg4g=None, VVFeLp=True, VV1KQM=True):
  lamedbFile, disabledFile = CCXkK1.VVYsuD()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVZg4g:
    filterCol = VVZg4g[0]
    filterWords = VVZg4g[1]
    asPrefix = VVZg4g[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCXkK1.VVnQCL:
    blackList = None
    path = "/etc/enigma2/blacklist"
    if fileExists(path):
     blackList = FFFfb9(path)
     if blackList:
      blackList = set(blackList)
   elif mode == CCXkK1.VVtvGt:
    tp = CCOm0d()
   VVFjcY, VVaijI = FFpN9C()
   tagFound  = False
   if mode in (CCXkK1.VV98a1, CCXkK1.VV4ebV):
    VVLRbU = {}
   else:
    VVLRbU = []
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     if not FF1qsD(SELF):
      return None
     line = line.strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
        sTypeInt = int(STYPE)
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFtBBn(val)
       servTypeHex = (hex(sTypeInt))[2:].upper()
       if mode == CCXkK1.VVt1BA:
        if sTypeInt in VVFjcY:
         STYPE = VVaijI[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVLRbU.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVLRbU.append(tRow)
        else:
         VVLRbU.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCXkK1.VV98a1:
         VVLRbU[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCXkK1.VV4ebV:
         VVLRbU[chName] = refCode
        elif mode == CCXkK1.VVnQCL:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVLRbU.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVLRbU.append(tRow)
         else:
          VVLRbU.append(tRow)
        elif mode == CCXkK1.VVtvGt:
         if sTypeInt in VVFjcY:
          STYPE = VVaijI[sTypeInt]
         freq, pol, fec, sr, syst = tp.VVe9c8(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVLRbU.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVLRbU.append(tRow)
         else:
          VVLRbU.append(tRow)
        elif mode == CCXkK1.VVsXId:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VVLRbU.append((chName, chProv, sat, refCode))
        elif mode == CCXkK1.VVxXGO:
         VVLRbU.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VVLRbU and VVFeLp:
    FFRwfz(SELF, "No services found!")
   return VVLRbU
  else:
   if VV1KQM:
    FFiKqP(SELF, lamedbFile)
   return None
 def VVMEPY(self):
  path = "/etc/enigma2/blacklist"
  if fileExists(path):
   lines = FFFfb9(path)
   if lines:
    newRows  = []
    VVLRbU = CCXkK1.VVXUi6(self, self.VVxXGO)
    if VVLRbU:
     lines = set(lines)
     for item in VVLRbU:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVLRbU = newRows
      VVLRbU.sort(key=lambda x: x[0].lower())
      VVpzw6 = ("", self.VVQVAE, [])
      VV7bTo = ("Zap", self.VV3t42, [])
      self.VVcE8k(VV0sV9=VVLRbU, VV7bTo=VV7bTo, VVpzw6=VVpzw6)
     else:
      FF0y0a(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVLRbU)))
   else:
    FFVXKI(self, "No hidden services.", FFAA5z())
  else:
   FFiKqP(self, path)
 def VVrDYK(self):
  VVLRbU = CCXkK1.VVXUi6(self, self.VVsXId)
  if VVLRbU:
   if VVLRbU:
    VVLRbU.sort(key=lambda x: x[0].lower())
    VVpzw6 = ("" , self.VVQVAE, [])
    VV7bTo  = ("Zap", self.VV3t42, [])
    self.VVcE8k(VV0sV9=VVLRbU, VV7bTo=VV7bTo, VVpzw6=VVpzw6)
   else:
    FF0y0a(self, "Lines\t: %d\nFound\t: %d\nLameDB\t: %d" % (len(lines), txt.count("\n"), len(VVLRbU)))
 def VVEZTY(self):
  totT, totC, totA, totS, totS2, satList = self.VVxwVO()
  txt = FFNMGt("Total Transponders:\n\n", VVvs8y)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFNMGt("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVvs8y)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFMsdn(item), satList.count(item))
  FF0y0a(self, txt)
 def VVxwVO(self):
  lamedbFile, disabledFile = CCXkK1.VVYsuD()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     if not FF1qsD(self):
      return 0, 0, 0, 0, 0, None
     line = line.strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFiKqP(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VVB1Ef(self):
  self.VVsCFs(True)
 def VVvRa8(self):
  self.VVsCFs(False)
 def VVsCFs(self, isWithPIcons):
  piconsPath = CCpLfD.VV6tkf()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCpLfD.VVau0J(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVLRbU = CCXkK1.VVXUi6(self, self.VVxXGO)
    if VVLRbU:
     channels = []
     for (chName, chProv, sat, refCode) in VVLRbU:
      if not FF1qsD(self):
       return
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFsO3Q(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVLRbU)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVAf2N(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVAf2N("PIcons Path"  , piconsPath)
     txt += VVAf2N("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVAf2N("Total services" , totalServices)
     txt += VVAf2N("With PIcons"  , totalWithPIcons)
     txt += VVAf2N("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FF0y0a(self, txt)
     else:
      VVpzw6     = (""      , self.VVQVAE , [])
      if isWithPIcons : VVRqTs = ("Export Current PIcon", self.VVYpUg  , [])
      else   : VVRqTs = None
      VVbtTj     = ("Statistics", FF0y0a, [txt])
      VV7bTo      = ("Zap", self.VV3t42, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVcE8k(VV0sV9=channels, VV7bTo=VV7bTo, VVpzw6=VVpzw6, VVbtTj=VVbtTj, VVRqTs=VVRqTs)
   else:
    FFRwfz(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFRwfz(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVQVAE(self, VVMzDi, title, txt, colList):
  png, path = CCpLfD.VVs7r4(colList[3], colList[0])
  FF0y0a(self, txt, title=title, VVfzL0=path)
 def VVYpUg(self, VVMzDi, title, txt, colList):
  png, path = CCpLfD.VVs7r4(colList[3], colList[0])
  if path:
   CCpLfD.VVmj4L(self, png, path)
 @staticmethod
 def VVYsuD():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVOe0w():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VV3kzm(self, isEnable):
  lamedbFile, disabledFile = CCXkK1.VVYsuD()
  if isEnable and not fileExists(disabledFile):
   FFVXKI(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FFRwfz(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFQsdM(self, boundFunction(self.VV2Oww, isEnable), "%s Hidden Channels ?" % word)
 def VV2Oww(self, isEnable):
  lamedbFile , disabledFile = CCXkK1.VVYsuD()
  lamedb5File, diabled5File = CCXkK1.VVOe0w()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FFb09f()
  if res == 0 : FFVXKI(self, "Hidden List %s" % word)
  else  : FFRwfz(self, "Error while restoring:\n\n%s" % fileName)
 def VVmRHr(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FF1Buo(self, cmd)
 def VVH7KP(self):
  lamedbFile, disabledFile = CCXkK1.VVYsuD()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFZNvw("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFFfb9(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFZNvw("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FFb09f()
   FF0y0a(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFiKqP(self, lamedbFile)
class CCgisO(Screen):
 def __init__(self, session, showIptvNote=False):
  self.skin, self.skinParam = FFPc34(VVB5d2, 1400, 800, 50, 30, 20, "#110B2830", "#050B242c", 30, addFramedPic=True)
  title = "Current Service"
  if showIptvNote:
   title += FFNMGt("   (No Signal Monitor for IPTV)", VVqJ8u)
  self.session   = session
  FFBP5J(self, title=title, addScrollLabel=True)
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  self["myLabel"].VV2Sqk()
  FF2E2r(self, self.VVfiof, title="Reading info. ...")
 def VVj4A7(self, err):
  self["myLabel"].setText(err)
  FFkgcm(self["myTitle"], "#22200000")
  FFkgcm(self["myBody"], "#22200000")
  self["myLabel"].FFkgcmColor("#22200000")
  self["myLabel"].VVqPCR()
 def VVfiof(self):
  sep = "%s\n" % VVuDI9
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFDq4f(self)
  if not info:
   self.VVj4A7("No data from system !")
   return
  chName = info.getName()
  txt = ""
  txt += "Service Name\t: %s\n" % FFNMGt(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVAf2N(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not "Working" in state:
    state = FFNMGt(state, VVxYDU)
   txt += "State\t: %s\n" % state
  w = FF9JtJ(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FF9JtJ(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = FF9JtJ(info      , iServiceInformation.sAspect)
  if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : aspect = "4:3"
  else           : aspect = "16:9"
  txt += "Video Format\t: %s\n" % aspect
  txt += self.VVAf2N(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVAf2N(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVAf2N(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  isIptv = len(iptvRef) > 0
  if iptvRef:
   txt += "Service Type\t: %s\n" % FFNMGt("IPTV", VVvs8y)
   txt += CCgisO.VVD7V2(iptvRef)
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  txt += "\n"
  txt += FFLQGG(refCode, iptvRef, chName)
  png, path = CCpLfD.VVs7r4(refCode, chName)
  picShown = False
  if png:
   if VVaEgm:
    txt += "\n"
    txt += sep
    txt += "PIcon:\n"
    txt += "%s\n" % path
   if path:
    allOK = FFoqMx(self["myPic"], path)
    if allOK:
     self["myPicF"].show()
     self["myPic"].show()
     picShown = True
  if isIptv:
   epg, err = self.VVSFGw(decodedUrl, not picShown)
   txt += FFNMGt("\n%sEPG:\n%s" % (sep, sep), COLOR_CONS_BRIGHT_YELLOW)
   if epg : txt += epg
   elif err: txt += FFNMGt(err, VVqJ8u)
  else:
   txt += "\n"
   txt += sep
   namespace = None
   if refCode:
    tp = CCOm0d()
    tpTxt, namespace = tp.VV1LYW(refCode)
    del tp
    if tpTxt:
     txt += FFNMGt("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += sep
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVAf2N(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVAf2N(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVAf2N(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVAf2N(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVAf2N(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVAf2N(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVAf2N(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVAf2N(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVAf2N(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
   txt += self.VVAf2N(info, "Description"    , iServiceInformation.sDescription  , 2  )
   txt += self.VVAf2N(info, "Time Create"    , iServiceInformation.sTimeCreate  , 2  )
   try:   txt += self.VVAf2N(info, "File Size"  , iServiceInformation.sFileSize   , 0  )
   except: pass
  self["myLabel"].setText(txt, VVPBLI=VVZLId)
  self["myLabel"].VVqPCR()
 def VVAf2N(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FF9JtJ(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVk8MX(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVk8MX(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVSFGw(self, decodedUrl, showPIcon):
  if not FF8zDj():
   return "", "No internet connection !"
  span  = iSearch(r"\s*(.+):(\d+)\/(live|movie|series)*\/*(.+)\/(.+)\/(\d+):*", decodedUrl, IGNORECASE)
  if span:
   uHost = span.group(1)
   uPort = span.group(2)
   uType = span.group(3) or "live"
   uUser = span.group(4)
   uPass = span.group(5)
   uId  = span.group(6)
  else:
   return "", "Cannot parse URL !"
  if   uType == "live" : qUrl = "%s:%s/player_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uHost, uPort, uUser, uPass, uId)
  elif uType == "movie" : qUrl = "%s:%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uPort, uUser, uPass, uId)
  elif uType == "series" : return "", "No EPG for Series"
  txt, err = CCOhHC.VV3qHB(qUrl)
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "Could not parse server data !"
  epg  = ""
  if tDict and not err:
   if uType == "live":
    epg, lang = self.VVdUPa(tDict)
    if epg:
     epg = "Language\t: %s\n\n%s" % (lang, epg)
   elif uType == "movie":
    epg, picUrl = self.VVlYLE(tDict)
    if showPIcon and picUrl:
     path, err = FFUNQn(picUrl, "ajpanel_tmp.png", timeout=1)
     allOK = FFoqMx(self["myPic"], path)
     if allOK:
      self["myPicF"].show()
      self["myPic"].show()
  if epg : return epg, ""
  else : return "" ,  "No EPG from server."
 def VVdUPa(self, tDict):
  epg = lang = ""
  sep = "_" * 32 + "\n"
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCOhHC.VVX8RL(item, "title"    , isBase64=True )
     lang    = CCOhHC.VVX8RL(item, "lang"        ).upper()
     description   = CCOhHC.VVX8RL(item, "description"  , isBase64=True )
     start_timestamp  = CCOhHC.VVX8RL(item, "start_timestamp" , isDate=True )
     stop_timestamp  = CCOhHC.VVX8RL(item, "stop_timestamp"  , isDate=True )
     stop_timestamp_unix = CCOhHC.VVX8RL(item, "stop_timestamp"      )
     now_playing   = CCOhHC.VVX8RL(item, "now_playing"      )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVMR5q, ""
      else     : color, txt = VVxYDU , "    (CURRENT EVENT)"
      epg +=  sep
      epg += FFNMGt("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      epg += "Description:\n%s\n" % FFNMGt(description, VVrETx)
      evNum += 1
   except:
    pass
  return epg, lang
 def VVlYLE(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item =tDict["info"]
    movie_image   = CCOhHC.VVX8RL(item, "movie_image" )
    genre    = CCOhHC.VVX8RL(item, "genre"   ) or "-"
    plot    = CCOhHC.VVX8RL(item, "plot"   ) or "-"
    cast    = CCOhHC.VVX8RL(item, "cast"   ) or "-"
    rating    = CCOhHC.VVX8RL(item, "rating"   ) or "-"
    director   = CCOhHC.VVX8RL(item, "director"  ) or "-"
    releasedate   = CCOhHC.VVX8RL(item, "releasedate" ) or "-"
    duration   = CCOhHC.VVX8RL(item, "duration"  ) or "-"
    epg += "Genre\t: %s\n"  % genre
    epg += "Released\t: %s\n" % releasedate
    epg += "Duration\t: %s\n" % duration
    epg += "Director\t: %s\n" % director
    epg += "Rating\t: %s\n\n" % rating
    epg += "Cast:\n%s\n\n"  % FFNMGt(cast, VVrETx)
    epg += "Plot:\n%s"   % FFNMGt(plot, VVrETx)
   except:
    pass
  return epg, movie_image
 @staticmethod
 def VVD7V2(refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFKp7T(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   txt += "\n"
   txt += FFNMGt("URL:", VVvs8y) + "\n%s\n" % decodedUrl
  else:
   txt = "\n"
   txt += FFNMGt("Reference:", VVvs8y) + "\n%s\n" % refCode
  return txt
class CCOhHC(Screen):
 VVjjcc = 0
 VVVgXf = 1
 VVmvv7 = 2
 VV1B4u = 3
 VVFziT  = 4
 VV1tEx  = 5
 VVWvSx  = 6
 VVGjxG  = 7
 VVVNK4   = 8
 VV3JFz  = 9
 VVi68O  = 10
 VVqgeH  = 11
 VVvXh9  = 12
 VVtwSo   = 13
 VVCK1p   = 14
 VVEFE8   = 15
 VVtxSK   = 16
 VVjWR8   = 17
 VVrFLz    = 0
 VVthLV   = 1
 VV0Mgs   = 2
 VVr4Nw   = 3
 VVDuqL  = 4
 VVR1nY   = 5
 VVNVcl   = 6
 VVl5fs  = 7
 VVZ2WC  = 8
 VVGh78   = 9
 VVhusr = 10
 VVGZNm   = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFPc34(VVFqLG, 1100, 1000, 50, 40, 30, "#0a00292B", "#0a00272B", 30)
  self.session  = session
  self.VVMzDi = None
  self.tableTitle  = "IPTV Channels List"
  self.VVWmFQData = {}
  VVleKL= self.VV32Kt()
  FFBP5J(self, VVleKL=VVleKL)
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  FFqDc3(self["myMenu"])
  FFQH05(self)
  FFXb1l(self)
 def VV32Kt(self):
  files = self.VVmRUy()
  VVleKL = []
  if files:
   if self.VVMzDi:
    VVleKL.append(("Add Current List to a New Bouquet"      , "VVnQVw"  ))
    VVleKL.append(VV8ygQ)
    VVleKL.append(("Change Current List References to Unique Codes"   , "VVQpiB"))
    VVleKL.append(("Change Current List References to Identical Codes"  , "VVU0TB_rows" ))
   else:
    VVleKL.append(("IPTV Server Browser (from Playlists)"      , "VVWmFQ_fromPlayList" ))
    VVleKL.append(("IPTV Server Browser (from M3U File)"      , "VVWmFQ_fromM3u"  ))
    VVleKL.append(VV8ygQ)
    VVleKL.append(("Local IPTV Channels (Live)"        , "iptvTable_live"   ))
    VVleKL.append(("Local IPTV Channels (All)"        , "iptvTable_all"   ))
    VVleKL.append(VV8ygQ)
    VVleKL.append(("Count Available IPTV Channels"       , "VVyS0M"    ))
    VVleKL.append(("Check Reference Codes Format"        , "VV5God"   ))
    VVleKL.append(("Check System Acceptable Reference Types"     , "VVGvo3"   ))
    VVleKL.append(VV8ygQ)
    VVleKL.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVoJ1I"  ))
    VVleKL.append(("Change ALL References to Matching Sat/C/T Channels"  , "VVIHYV" ))
    VVleKL.append(("Change ALL References to Unique Codes"     , "VVr27O" ))
    VVleKL.append(("Change ALL References to Identical Codes"     , "VVU0TB_all" ))
  if not self.VVMzDi:
   if not files:
    VVleKL.append(("IPTV Server Browser (from Playlists)"      , "VVWmFQ_fromPlayList" ))
    VVleKL.append(("IPTV Server Browser (from m3U)"       , "VVWmFQ_fromM3u"  ))
   VVleKL.append(VV8ygQ)
   VVleKL.append(("Analyse m3u File"            , "VVpTaf"   ))
   VVleKL.append(("Convert m3u File to Bouquet (from File Manager)"    , "VVVVdx" ))
   VVleKL.append(("Convert m3u File to Bouquet (from m3u File List)"    , "VVLM5R" ))
   VVleKL.append(('Convert m3u File to Bouquet (Download from "Play Lists")'  , "VVr0ki" ))
   VVleKL.append(VV8ygQ)
   VVleKL.append(("Reload Channels and Bouquets"         , "VVUB1J"   ))
  return VVleKL
 def VVOILd(self, item):
  if item is not None:
   if   item == "VVnQVw"   : FFX60J(self, self.VVnQVw, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVQpiB" : FFQsdM(self, boundFunction(FF2E2r, self.VVMzDi, self.VVQpiB ), "Change Current List References to Unique Codes ?")
   elif item == "VVU0TB_rows" : FFQsdM(self, boundFunction(FF2E2r, self.VVMzDi, self.VVU0TB   ), "Change Current List References to Identical Codes ?")
   elif item == "VVWmFQ_fromPlayList" : FF2E2r(self, boundFunction(self.VV7c40, True), title="Searching ...")
   elif item == "VVWmFQ_fromM3u"  : FF2E2r(self, boundFunction(self.VV5n3s, 0), title="Searching ...")
   elif item == "iptvTable_live"   : FF2E2r(self, boundFunction(self.VVMcXB, self.VVGjxG ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FF2E2r(self, boundFunction(self.VVMcXB, self.VVjjcc) , title="Loading Channels ...")
   elif item == "VVyS0M"    : FF2E2r(self, self.VVyS0M)
   elif item == "VV5God"    : FF2E2r(self, self.VV5God)
   elif item == "VVGvo3"   : FF2E2r(self, self.VVGvo3)
   elif item == "VVoJ1I"  : self.VVoJ1I()
   elif item == "VVIHYV"  : FFQsdM(self, boundFunction(FF2E2r, self, self.VVIHYV ), "Copy from existing Sat. Channel" )
   elif item == "VVr27O" : FFQsdM(self, boundFunction(FF2E2r, self, self.VVr27O ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVU0TB_all" : FFQsdM(self, boundFunction(FF2E2r, self, self.VVU0TB  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "VVpTaf"   : FF2E2r(self, boundFunction(self.VV5n3s, 1), title="Searching ...")
   elif item == "VVVVdx" : self.VVVVdx()
   elif item == "VVLM5R" : FF2E2r(self, boundFunction(self.VV5n3s, 2), title="Searching ...")
   elif item == "VVr0ki" : FF2E2r(self, boundFunction(self.VV7c40, False), title="Searching ...")
   elif item == "VVUB1J"   : FF2E2r(self, boundFunction(CCXkK1.VVUB1J, self))
 def VVjeN5(self):
  global VVjhpS
  VVjhpS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVOILd(item)
 def VVMcXB(self, mode):
  VVLRbU = self.VVkkw2(mode)
  if VVLRbU:
   VVJVgU = ("Current Service", self.VVL5QP , [])
   VVbtTj = ("Options"  , self.VVEyVI   , [])
   VVRqTs = ("Filter"   , self.VVEDTg    , [])
   VV7bTo  = ("Zap"   , self.VVoW4b   , [])
   VVpzw6 = (""    , self.VVDQ65    , [])
   VVCYQA = (""    , self.VVtuwC     , [])
   VVFNcA = (""    , self.VVLYsR    , [])
   VVb3Bo   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVAGqv  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFI84f(self, None, VVb3Bo=VVb3Bo, VV0sV9=VVLRbU, VVAGqv=VVAGqv, VVNZlV=widths, VVZ1jJ=22
     , VV7bTo=VV7bTo, VVJVgU=VVJVgU, VVbtTj=VVbtTj, VVRqTs=VVRqTs, VVpzw6=VVpzw6, VVCYQA=VVCYQA
     , VVgxh0="#0a00292B", VVd0OK="#0a002126", VVV3xM="#0a002126", VVt3ai="#00000000", VVgVDs=True, searchCol=1)
  else:
   if mode == self.VVGjxG: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFRwfz(self, err)
 def VVtuwC(self, VVMzDi, title, txt, colList):
  self.VVMzDi = VVMzDi
 def VVLYsR(self, VVMzDi):
  self.VVMzDi = None
 def VVEyVI(self, VVMzDi, title, txt, colList):
  VVleKL= self.VV32Kt()
  FF7X20(self, self.VVOILd, title="IPTV Tools", VVleKL=VVleKL)
 def VVEDTg(self, VVMzDi, title, txt, colList):
  VVleKL = []
  VVleKL.append(("All"         , "all"   ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Prefix of Selected Channel"   , "sameName" ))
  VVleKL.append(("Suggest Words from Selected Channel" , "partName" ))
  VVleKL.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Live TV"        , "live"  ))
  VVleKL.append(("VOD"         , "vod"   ))
  VVleKL.append(("Series"        , "series"  ))
  VVleKL.append(("Uncategorised"      , "uncat"  ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Video"        , "video"  ))
  VVleKL.append(("Audio"        , "audio"  ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("MKV"         , "MKV"   ))
  VVleKL.append(("MP4"         , "MP4"   ))
  VVleKL.append(("MP3"         , "MP3"   ))
  VVleKL.append(("AVI"         , "AVI"   ))
  VVleKL.append(("FLV"         , "FLV"   ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVlY0g()
  if bNames:
   bNames.sort()
   VVleKL.append(VV8ygQ)
   for item in bNames:
    VVleKL.append((item, "__b__" + item))
  filterObj = CCiBgE(self)
  filterObj.VVyrYE(VVleKL, VVleKL, boundFunction(self.VVqrkr, VVMzDi))
 def VVqrkr(self, VVMzDi, item=None):
  prefix = VVMzDi.VVOxOZ(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVjjcc, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVVgXf , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVmvv7 , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VV1B4u , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVGjxG  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVVNK4   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VV3JFz  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVi68O  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVqgeH  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVvXh9  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVtwSo   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVCK1p   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVEFE8   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVtxSK   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVjWR8   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVWvSx  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VVFziT  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VV1tEx  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVmvv7:
   VVleKL = []
   chName = VVMzDi.VVOxOZ(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVleKL.append((item, item))
    if not VVleKL and chName:
     VVleKL.append((chName, chName))
    FF7X20(self, boundFunction(self.VVbEaV_partOfName, title), title="Words from Current Selection", VVleKL=VVleKL)
   else:
    VVMzDi.VV8K08("Invalid Channel Name")
  else:
   words, asPrefix = CCiBgE.VVSxZN(words)
   if not words and mode in (self.VVFziT, self.VV1tEx):
    FFVyro(self.VVMzDi, "Incorrect filter", 2000)
   else:
    FF2E2r(self.VVMzDi, boundFunction(self.VVZoCc, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVbEaV_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FF2E2r(self.VVMzDi, boundFunction(self.VVZoCc, self.VVmvv7, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 def VVZoCc(self, mode, words, asPrefix, title):
  VVLRbU = self.VVkkw2(mode=mode, words=words, asPrefix=asPrefix)
  if VVLRbU : self.VVMzDi.VVVImv(VVLRbU, title)
  else  : self.VVMzDi.VV8K08("Not found")
 def VVkkw2(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pat = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pat = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VVLRbU = []
  files  = self.VVmRUy()
  if files:
   vid, aud, liv1, liv2, movie, series = self.VVQehj()
   vid_aud = vid + aud
   mix1 = liv1 + liv2 + ("/movie", "/series")
   series1 = r"(s\d\d.*e\d\d|e\d\d.*s\d\d)"
   urlPat = r"((.+)(?::[^:\/]+$)|.+)"
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFMmfA(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVHUXe = span.group(1)
    else : VVHUXe = ""
    VVHUXe_lCase = VVHUXe.lower()
    for match in iFinditer(pat, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VV2kiT(chName): chName = FFNMGt(chName, VVvAHa)
     row = (str(chNum), chName, VVHUXe, chType, refCode, url)
     ok = False
     span = iSearch(urlPat, url, IGNORECASE)
     if span:
      if span.group(2): tUrl = span.group(2)
      else   : tUrl = span.group(1)
     else:
      tUrl = url
     if tUrl.endswith(chName):
      tUrl = tUrl.replace(":" + chName, "")
     tUrl = tUrl.lower()
     if   mode == self.VVjjcc : ok = True
     elif mode == self.VVWvSx : ok = True
     elif mode == self.VVVgXf:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVmvv7:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VV1B4u:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VVGjxG:
      if not tUrl.endswith(vid_aud):
       if tUrl.endswith(liv1) or ".m3u" in tUrl or any(x in tUrl for x in liv2) or tUrl[-3].isdigit():
        ok = True
     elif mode == self.VVVNK4:
      if "/movie/" in tUrl or tUrl.endswith(vid_aud) and not "/series/" in tUrl:
       ok = True
     elif mode == self.VV3JFz:
      if "/series/" in tUrl or iSearch(series1, chName, IGNORECASE):
       ok = True
     elif mode == self.VVi68O:
      if not tUrl.endswith(vid_aud) and not tUrl.endswith(liv1) and not any(x in tUrl for x in mix1) and not tUrl[-3].isdigit():
       ok = True
     elif mode == self.VVqgeH:
      if tUrl.endswith(vid) :
       ok = True
     elif mode == self.VVvXh9:
      if tUrl.endswith(aud) :
       ok = True
     elif mode == self.VVtwSo:
      if tUrl.endswith(".mkv"):
       ok = True
     elif mode == self.VVCK1p:
      if tUrl.endswith(".mp4"):
       ok = True
     elif mode == self.VVEFE8:
      if tUrl.endswith(".mp3"):
       ok = True
     elif mode == self.VVtxSK:
      if tUrl.endswith(".avi"):
       ok = True
     elif mode == self.VVjWR8:
      if tUrl.endswith(".flv"):
       ok = True
     elif mode == self.VVFziT:
      if words[0] == VVHUXe_lCase:
       ok = True
     elif mode == self.VV1tEx:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VVLRbU.append(row)
      chNum += 1
  if VVLRbU and mode == self.VVWvSx:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VVLRbU)
   for item in VVLRbU:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VVLRbU = newRows
  return VVLRbU
 def VVnQVw(self, bName):
  if bName:
   FF2E2r(self.VVMzDi, boundFunction(self.VV7vrn, bName), title="Adding Channels ...")
 def VV7vrn(self, bName):
  num = 0
  path = VVVuM0 + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVVuM0 + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVMzDi.VVOs8r():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFZTkY(row[1]))
    totChange += 1
  FFuNTm(os.path.basename(path))
  self.VVFlxw(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVoJ1I(self):
  txt = "Stream Type "
  VVleKL = []
  VVleKL.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVleKL.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVleKL.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVleKL.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVleKL.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVleKL.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FF7X20(self, self.VV7Hb5, title="Change Reference Types to:", VVleKL=VVleKL)
 def VV7Hb5(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVqZ4c("1"   )
   elif item == "RT_4097" : self.VVqZ4c("4097")
   elif item == "RT_5001" : self.VVqZ4c("5001")
   elif item == "RT_5002" : self.VVqZ4c("5002")
   elif item == "RT_8192" : self.VVqZ4c("8192")
   elif item == "RT_8193" : self.VVqZ4c("8193")
 def VVqZ4c(self, rType):
  FFQsdM(self, boundFunction(FF2E2r, self, boundFunction(self.VVy2Ic, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVy2Ic(self, refType):
  totChange = 0
  files  = self.VVmRUy()
  if files:
   for path in files:
    txt = FFMmfA(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFuNTm(os.path.basename(path))
  self.VVFlxw(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVyS0M(self):
  totFiles = 0
  files  = self.VVmRUy()
  if files:
   totFiles = len(files)
  totChans = 0
  VVLRbU = self.VVkkw2()
  if VVLRbU:
   totChans = len(VVLRbU)
  FF0y0a(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VV5God(self):
  files  = self.VVmRUy()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFMmfA(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VViUes
   else    : color = VVxYDU
   totInvalid = FFNMGt(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFNMGt("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FF0y0a(self, txt, title="Check IPTV References")
 def VVGvo3(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVVuM0 + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFuNTm(os.path.basename(path))
  FFb09f()
  acceptedList = []
  VVoYtW = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVoYtW:
   VVAyix = FFJ5Wh(VVoYtW)
   if VVAyix:
    for service in VVAyix:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVVuM0 + userBName
  bFile = VVVuM0 + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFZNvw("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFZNvw("rm -f '%s'" % path)
  os.system(cmd)
  FFb09f()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VViUes
    else     : res, color = "No" , VVxYDU
    txt += "    %s\t: %s\n" % (item, FFNMGt(res, color))
   FF0y0a(self, txt, title=title)
  else:
   txt = FFRwfz(self, "Could not complete the test on your system!", title=title)
 def VVIHYV(self):
  lameDbChans = CCXkK1.VVXUi6(self, CCXkK1.VV4ebV)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVmRUy():
    toSave = False
    txt = FFMmfA(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVFlxw(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFRwfz(self, 'No channels in "lamedb" !')
 def VVr27O(self):
  files  = self.VVmRUy()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFFfb9(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVADli(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVFlxw(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVQpiB(self):
  iptvRefList = []
  files  = self.VVmRUy()
  if files:
   for path in files:
    txt = FFMmfA(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVMzDi.VV7rVB(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVADli(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVmRUy()
  if files:
   for path in files:
    lines = FFFfb9(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVFlxw(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVADli(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVU0TB(self):
  list = None
  if self.VVMzDi:
   list = []
   for row in self.VVMzDi.VVOs8r():
    list.append(row[4] + row[5])
  files  = self.VVmRUy()
  totChange = 0
  if files:
   for path in files:
    lines = FFFfb9(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVFlxw(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVFlxw(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFb09f()
   if refreshTable and self.VVMzDi:
    VVLRbU = self.VVkkw2()
    if VVLRbU and self.VVMzDi:
     self.VVMzDi.VVVImv(VVLRbU, self.tableTitle)
     self.VVMzDi.VV8K08(txt)
   FF0y0a(self, txt, title=title)
  else:
   FFVXKI(self, "No changes.")
 def VVlY0g(self):
  files = self.VVmRUy()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with open(path, "r") as f:
     span = iSearch(r"#NAME\s+(.*)", f.readline(), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VVDH8R = FFIgUg()
    if VVDH8R:
     for b in VVDH8R:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVmRUy(self):
  return CCOhHC.VV5GxP(self)
 @staticmethod
 def VV5GxP(SELF):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVVuM0 + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFMmfA(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
   return iptvFiles
  else:
   FFRwfz(SELF, "IPTV files not found in path\n\n%s" % VVVuM0)
   return None
 def VVDQ65(self, VVMzDi, title, txt, colList):
  span = iSearch(r'URL\s+:\s*(.+)', txt, IGNORECASE)
  if span:
   url = span.group(1)
   url = FFJx6y(url.strip())
   txt = txt.replace(span.group(0), "URL\t: %s" % url)
  chName = colList[1]
  refCode = colList[4]
  png, path = CCpLfD.VVs7r4(refCode.rstrip(":"), chName)
  txt = "Row Number\t: %d of %d\n\n%s" % (VVMzDi.VVlfrz() + 1, VVMzDi.VVddTB(), txt)
  FF0y0a(self, txt, VVfzL0=path, title=self.tableTitle)
 def VVoW4b(self, VVMzDi, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  self.VVnccF(VVMzDi, chName, chUrl)
 def VVboBj(self, mode, VVMzDi, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVC8t9(mode, colList)
  self.VVnccF(VVMzDi, chName, chUrl)
 def VVnccF(self, VVMzDi, chName, chUrl):
  chName = FFZTkY(chName)
  if not self.VV2kiT(chName):
   FFM38n(self, chUrl, VVDz76=False)
   if len(chName) > 70:
    chName = chName[:70] + " .."
   FF86rP(self, "%s\n%s" % (FFNMGt("Playing:", VVrETx), chName), timerSec=0, isTopLeft=True, fixSize=True)
  else:
   FFVyro(VVMzDi, "This is a marker!", 300)
 def VV2kiT(self, chName):
  mark = ("--", "__", "==", "##")
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVL5QP(self, VVMzDi, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFDq4f(self)
  if refCode:
   colDict = { 4:refCode, 5:FF7Hfa(refCode, origUrl, chName) }
   VVMzDi.VVzvPP_partial(colDict, showErr=True)
 def VVVVdx(self):
  self.session.open(CChsD2)
  self.close()
 def VV5n3s(self, m3uMode):
  lines = FFnzIb("find / %s -iname '*.m3u' | grep -i '.m3u'" % FFdplS(1))
  if lines:
   lines.sort()
   VVleKL = []
   for line in lines:
    VVleKL.append((line, line))
   if   m3uMode == 0 : title = "Browse Server from M3U URLs"
   elif m3uMode == 1 : title = "Analyse M3U File:"
   else    : title = "Convert M3U File to Bouquet"
   VVrIGp = ("Show Full Path", self.VVtqwG)
   OKBtnFnc = boundFunction(self.VVY3K9, m3uMode, title)
   FF7X20(self, None, title=title, VVleKL=VVleKL, VVrIGp=VVrIGp, OKBtnFnc=OKBtnFnc)
  else:
   FFRwfz(self, 'No "m3u" files found.')
 def VVtqwG(self, VVxnlbObj, url):
  FF0y0a(self, url, title="Full Path")
 def VVY3K9(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if   m3uMode == 0 : FF2E2r(menuInstance, boundFunction(self.VV4MQO, title, path))
   elif m3uMode == 1 : FF2E2r(menuInstance, boundFunction(self.VVpTaf, title, path))
   else    : self.VVLA5z(path)
 def VVpTaf(self, title, path):
  if fileExists(path):
   txt = FFMmfA(path)
   totChan   = 0
   totLive   = 0
   totVod   = 0
   totSeries  = 0
   totUncat  = 0
   totVideo  = 0
   totAudio  = 0
   vid, aud, liv1, liv2, movie, series = self.VVQehj()
   vid_aud   = vid + aud
   mix1   = liv1 + liv2 + ("/movie", "/series")
   series1   = r"(s\d\d.*e\d\d|e\d\d.*s\d\d)"
   for match in iFinditer(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?((.+)(:[^:\/]+$)|.+)", txt, IGNORECASE):
    totChan += 1
    chName  = match.group(1).strip()
    fullUrl  = match.group(2).strip()
    urlPart1 = match.group(3)
    if urlPart1 : tUrl = urlPart1
    else  : tUrl = fullUrl
    tUrl = tUrl.lower()
    if tUrl.endswith(chName):
     tUrl = tUrl.replace(":" + chName, "")
    tUrl = tUrl.lower()
    if not tUrl.endswith(vid_aud) and (tUrl.endswith(liv1) or ".m3u" in tUrl or any(x in tUrl for x in liv2) or tUrl[-3].isdigit()):
     totLive += 1
    elif "/movie/" in tUrl or tUrl.endswith(vid_aud) and not "/series/" in tUrl:
     totVod += 1
    elif "/series/" in tUrl or iSearch(series1, chName, IGNORECASE):
     totSeries += 1
    else:
     totUncat += 1
    if   tUrl.endswith(vid): totVideo += 1
    elif tUrl.endswith(aud): totAudio += 1
   txt = ""
   txt += FFNMGt("File:\n", VVvs8y)
   txt += "    %s\n"    % path
   txt += "\n"
   txt += FFNMGt("Channels:\n", VVvs8y)
   txt += "    Total\t: %d\n" % totChan
   txt += "\n"
   txt += FFNMGt("Category:\n", VVvs8y)
   txt += "    Live\t: %d\n" % totLive
   txt += "    VOD\t: %d\n" % totVod
   txt += "    Series\t: %d\n" % totSeries
   txt += "    Uncat.\t: %d\n" % totUncat
   txt += "\n"
   txt += FFNMGt("Content:\n", VVvs8y)
   txt += "    Video\t: %d\n" % totVideo
   txt += "    Audio\t: %d\n" % totAudio
   txt += "\n"
   FF0y0a(self, txt, title="M3U File Analysis")
  else:
   FFRwfz(SELF, "Cannot open file :\n\n%s" % path, title=title)
   return
 def VV7c40(self, isBrowseServer):
  lines = FFnzIb('find / %s -iname "*playlist*" | grep -i ".txt"' % FFdplS(1))
  if lines:
   lines.sort()
   VVleKL = []
   for line in lines:
    VVleKL.append((line, line))
   OKBtnFnc = boundFunction(self.VVtWjy, isBrowseServer)
   FF7X20(self, None, title="Select Playlist File", VVleKL=VVleKL, OKBtnFnc=OKBtnFnc)
  else:
   FFiKqP(self, "( playlist.txt  or  playlists.txt )")
 def VVtWjy(self, isBrowseServer, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   VVleKL = []
   lines = FFFfb9(path)
   for line in lines:
    line = line.strip()
    if line and "/" in line:
     VVleKL.append((line, line))
   if VVleKL:
    if isBrowseServer : title = "Select Server URL"
    else    : title = "Convert to Bouquet"
    OKBtnFnc  = boundFunction(self.VV2HJS, isBrowseServer, title)
    VV3DJ3  = ("Exit IPTV", FFPWQ6)
    VVrIGp  = ("Show URL", self.VVNwjM)
    FF7X20(self, None, title=title, VVleKL=VVleKL, OKBtnFnc=OKBtnFnc, VV3DJ3=VV3DJ3, VVrIGp=VVrIGp)
   else:
    FFRwfz(self, "No valid URLs in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVNwjM(self, VVxnlbObj, url):
  FF0y0a(self, url, title="URL")
 def VV2HJS(self, isBrowseServer, title, item=None):
  if item:
   menuInstance, txt, url, ndx = item
   if isBrowseServer:
    FF2E2r(menuInstance, boundFunction(self.VV1lsO, title, url), title="Checking Server ...")
   else:
    FFQsdM(self, boundFunction(FF2E2r, menuInstance, boundFunction(self.VVtbMc, url), title="Downloading ..."), "Download m3u file from this URL ?\n\n%s" % url, title=title)
 def VVtbMc(self, url):
  path, err = FFUNQn(url, "ajpanel_tmp.m3u", timeout=3)
  if err : FFRwfz(self, err, title="Download Problem")
  else : self.VVLA5z(path)
 def VVLA5z(self, path):
  files = CCOhHC.VV5GxP(self)
  if files:
   exitCurWin = False
  else:
   exitCurWin = True
  CCOhHC.VVHH8c(self, path, exitCurWin)
 @staticmethod
 def VVHH8c(SELF, path, exitCurWin):
  FFQsdM(SELF, boundFunction(FF2E2r, SELF, boundFunction(CCOhHC.VVuXjM, SELF, path, exitCurWin), title="Converting ...")
    , "Convert file to bouquet ?\n\n%s" % path, title="Convert m3u file")
 @staticmethod
 def VVuXjM(SELF, path, exitCurWin):
  SID = TSID = ONID = 0
  MAX = 65535
  title = "Convert m3u File to Bouquet"
  if not fileExists(path):
   FFRwfz(SELF, "Cannot open file :\n\n%s" % path, title=title)
   return
  bName  = os.path.basename(path)
  bName  = os.path.splitext(bName)[0]
  bName  = iSub(r"[^A-Za-z0-9]+", "_", bName, IGNORECASE)
  bName  = "IPTV_" + bName.strip("_")
  bFileName = "userbouquet.%s.tv" % bName
  if fileExists(VVVuM0 + bFileName):
   while True:
    SID += 1
    tmpBName = "%s_%d" % (bName, SID)
    bFileName = "userbouquet.%s.tv" % tmpBName
    if not fileExists(VVVuM0 + bFileName):
     bName = tmpBName
     break
  txt = FFMmfA(path)
  pattern = r"#EXTINF.+,(.+)\n(.+)"
  span = iSearch(r"#EXTINF.+,(.+)\n(.+)", txt, IGNORECASE)
  if span:
   with open(VVVuM0 + bFileName, "w") as f:
    totChan = 0
    f.write("#NAME %s\n" % bName.replace("IPTV_", "IPTV - ", 1))
    for match in iFinditer(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?(.+)", txt, IGNORECASE):
     TSID += 1
     if TSID > MAX:
      TSID = MAX
      ONID += 1
      if ONID > MAX:
       ONID = 0
     chName = match.group(1).strip()
     url  = FFTTRw(match.group(2).strip())
     refCode = "4097:0:1:%s:%s:%s:0:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:])
     line1 = "#SERVICE %s%s\n" % (refCode.upper(), url)
     line2 = "#DESCRIPTION %s\n" % chName
     f.write(line1 + line2)
     totChan += 1
   FFuNTm(bFileName)
   FFb09f()
   FFVXKI(SELF, 'New Bouquet = %s\n\nTotal Channels = %d' % (bName, totChan), title=title)
  else:
   FFRwfz(SELF, "No channels found in file (or invalid file format) !\n\n%s" % path, title=title)
  if exitCurWin:
   SELF.close()
 def VVQehj(self):
  vid  = (".avi", ".flv", ".h264", ".h265", ".m2ts", ".m4v", ".mjpeg", ".mk3d", ".mks", ".mkv", ".mov", ".mp4", ".mpg", ".mts", ".vob", ".webm", ".wmv", ".xvid")
  aud  = (".aac", ".ac3", ".m3u", ".m4a", ".m4b", ".m4p", ".mid", ".mka", ".mp2", ".mp3", ".mpc", ".ogg", ".wav", ".wma", ".wpl")
  liv1 = (".ts", ".m3u8")
  liv2 = ("/m3u8", "/live", "deviceUser", "deviceMac")
  movie = ("/movie")
  series = ("/series")
  return vid, aud, liv1, liv2, movie, series
 @staticmethod
 def VV3qHB(url, timeout=5):
  uOpen = None
  try:
   from urllib2 import urlopen  as uOpen
  except:
   try:
    from urllib.request import urlopen as uOpen
   except:
    pass
  txt  = ""
  err  = ""
  if uOpen:
   res = ""
   try:
    res = uOpen(url, timeout=timeout)
    res = res.read().decode('utf-8')
    if res:
     if "<!DOCTYPE html>" in res : err = "Incorrect data format from server !"
     else      : txt = res
   except Exception as e:
    err = str(e)
  else:
   err = "Error while importing URLLIB/URLLIB2 !"
  return txt, err
 def VVAWrg(self, url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     key, val = part.split("=")
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 def VVRiPe(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVAWrg(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVrFLz   : return "%s"            % url
  elif mode == self.VVthLV   : return "%s&action=get_live_categories"     % url
  elif mode == self.VV0Mgs   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVr4Nw  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVDuqL : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVR1nY   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVNVcl    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVl5fs  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVZ2WC  : return "%s&action=get_simple_data_table&stream_id=%s"  % (url, Id)
  elif mode == self.VVGh78  : return "%s&action=get_short_epg&stream_id=%s"    % (url, Id)
  elif mode == self.VVhusr : return "%s&action=get_short_epg&stream_id=%s&limit=%s" % (url, Id, limit)
  elif mode == self.VVGZNm   : return "%s&action=get_vod_info&vod_id=%s"     % (url, Id)
 @staticmethod
 def VVX8RL(item, key, isDate=False, isBase64=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFCgGR(int(val))
    elif isBase64 : val = b64decode(val).decode("utf-8")
   except:
    pass
   return val
  else:
   return ""
 def VV4MQO(self, title, path):
  if fileExists(path):
   qUrl = ""
   with open(path, "r") as f:
    for line in f:
     span  = iSearch(r"\s*(.+):(\d+)\/(live|movie|series)*\/*(.+)\/(.+)\/(\d+):*", line, IGNORECASE)
     if span:
      uHost = span.group(1)
      uPort = span.group(2)
      uUser = span.group(4)
      uPass = span.group(5)
      qUrl = "%s:%s/get.php?username=%s&password=%s&type=m3u" % (uHost, uPort, uUser, uPass)
      break
   if qUrl : self.VV1lsO(title, qUrl)
   else : FFRwfz(self, "No valid Server URL found in:\n\n%s" % path, title=title)
  else:
   FFRwfz(self, "Cannot open file :\n\n%s" % path, title=title)
 def VV1lsO(self, title, url):
  self.VVWmFQData = {}
  qUrl = self.VVRiPe(self.VVrFLz, url)
  txt, err = self.VV3qHB(qUrl)
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVWmFQData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVWmFQData["username"    ] = self.VVX8RL(item, "username"        )
    self.VVWmFQData["password"    ] = self.VVX8RL(item, "password"        )
    self.VVWmFQData["message"    ] = self.VVX8RL(item, "message"        )
    self.VVWmFQData["auth"     ] = self.VVX8RL(item, "auth"         )
    self.VVWmFQData["status"    ] = self.VVX8RL(item, "status"        )
    self.VVWmFQData["exp_date"    ] = self.VVX8RL(item, "exp_date"    , isDate=True )
    self.VVWmFQData["is_trial"    ] = self.VVX8RL(item, "is_trial"        )
    self.VVWmFQData["active_cons"   ] = self.VVX8RL(item, "active_cons"       )
    self.VVWmFQData["created_at"   ] = self.VVX8RL(item, "created_at"   , isDate=True )
    self.VVWmFQData["max_connections"  ] = self.VVX8RL(item, "max_connections"      )
    self.VVWmFQData["allowed_output_formats"] = self.VVX8RL(item, "allowed_output_formats"    )
    lst = []
    key = "allowed_output_formats"
    if key in item:
     for item in item[key]:
      lst.append(str(item))
     self.VVWmFQData[key] = lst
    item = tDict["server_info"]
    self.VVWmFQData["url"    ] = self.VVX8RL(item, "url"        )
    self.VVWmFQData["port"    ] = self.VVX8RL(item, "port"        )
    self.VVWmFQData["https_port"  ] = self.VVX8RL(item, "https_port"      )
    self.VVWmFQData["server_protocol" ] = self.VVX8RL(item, "server_protocol"     )
    self.VVWmFQData["rtmp_port"   ] = self.VVX8RL(item, "rtmp_port"       )
    self.VVWmFQData["timezone"   ] = self.VVX8RL(item, "timezone"       )
    self.VVWmFQData["timestamp_now"  ] = self.VVX8RL(item, "timestamp_now"  , isDate=True )
    self.VVWmFQData["time_now"   ] = self.VVX8RL(item, "time_now"       )
    VVleKL = []
    VVleKL.append(("Live"     , "serverLive"  ))
    VVleKL.append(("VOD"     , "serverVod"  ))
    VVleKL.append(("Series (Seasons)"  , "serverSeries" ))
    VVleKL.append(VV8ygQ)
    VVleKL.append(("User/Server Info." , "serverInfo"  ))
    OKBtnFnc = self.VVWmFQOptions
    VV3DJ3 = ("Exit IPTV", FFPWQ6)
    FF7X20(self, None, title="Categories", VVleKL=VVleKL, OKBtnFnc=OKBtnFnc, VV3DJ3=VV3DJ3)
   else:
    err = "Could not get data from server !"
  if err:
   FFRwfz(self, err, title=title)
  FFVyro(self)
 def VVWmFQOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "serverLive" : FF2E2r(menuInstance, boundFunction(self.VVoMmN, self.VVthLV , title=title), title=wTxt)
   elif ref == "serverVod"  : FF2E2r(menuInstance, boundFunction(self.VVoMmN, self.VV0Mgs , title=title), title=wTxt)
   elif ref == "serverSeries" : FF2E2r(menuInstance, boundFunction(self.VVoMmN, self.VVr4Nw, title=title), title=wTxt)
   elif ref == "serverInfo" : FF2E2r(menuInstance, boundFunction(self.VVLnQs          , title=title), title=wTxt)
 def VVLnQs(self, title):
  c1 = VVvAHa
  c2 = VVy7KO
  list = []
  list.append((FFNMGt("User" , c1), "Username"    , self.VVWmFQData["username"    ]))
  list.append((FFNMGt("User" , c1), "Password"    , self.VVWmFQData["password"    ]))
  list.append((FFNMGt("User" , c1), "Message"    , self.VVWmFQData["message"        ]))
  list.append((FFNMGt("User" , c1), "Auth"     , self.VVWmFQData["auth"     ]))
  list.append((FFNMGt("User" , c1), "Status"     , self.VVWmFQData["status"        ]))
  list.append((FFNMGt("User" , c1), "Expiry"     , self.VVWmFQData["exp_date"    ]))
  list.append((FFNMGt("User" , c1), "Is Trial"    , self.VVWmFQData["is_trial"    ]))
  list.append((FFNMGt("User" , c1), "Active Cons"   , self.VVWmFQData["active_cons"       ]))
  list.append((FFNMGt("User" , c1), "Created"    , self.VVWmFQData["created_at"    ]))
  list.append((FFNMGt("User" , c1), "Max Connections"  , self.VVWmFQData["max_connections"   ]))
  list.append((FFNMGt("User" , c1), "Allowed Output Formats" , " , ".join(self.VVWmFQData["allowed_output_formats"])))
  list.append((FFNMGt("Server" , c2), "URL"     , self.VVWmFQData["url"         ]))
  list.append((FFNMGt("Server" , c2), "Port"     , self.VVWmFQData["port"     ]))
  list.append((FFNMGt("Server" , c2), "HTTPS Port"    , self.VVWmFQData["https_port"       ]))
  list.append((FFNMGt("Server" , c2), "Server Protocol"  , self.VVWmFQData["server_protocol"      ]))
  list.append((FFNMGt("Server" , c2), "RTMP Port"    , self.VVWmFQData["rtmp_port"    ]))
  list.append((FFNMGt("Server" , c2), "Timezone"    , self.VVWmFQData["timezone"    ]))
  list.append((FFNMGt("Server" , c2), "Local Time"    , self.VVWmFQData["timestamp_now"   ]))
  list.append((FFNMGt("Server" , c2), "Server Time"   , self.VVWmFQData["time_now"    ]))
  VVb3Bo   = ("User/Server", "Subject" , "Value" )
  widths   = (15   , 45   , 40  )
  FFI84f(self, None, title=title, VVb3Bo=VVb3Bo, VV0sV9=list, VVNZlV=widths, VVZ1jJ=26, VVgxh0="#0a00292B", VVd0OK="#0a002126", VVV3xM="#0a002126", VVt3ai="#00000000")
  FFVyro(self)
 def VVdN8t(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    if mode == self.VVR1nY:
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVX8RL(item, "num"         )
      name     = self.VVX8RL(item, "name"        )
      stream_id    = self.VVX8RL(item, "stream_id"       )
      stream_icon    = self.VVX8RL(item, "stream_icon"       )
      epg_channel_id   = self.VVX8RL(item, "epg_channel_id"      )
      added     = self.VVX8RL(item, "added"    , isDate=True )
      is_adult    = self.VVX8RL(item, "is_adult"       )
      category_id    = self.VVX8RL(item, "category_id"       )
      if self.VV2kiT(name): name = FFNMGt(name, VVvAHa)
      list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVNVcl:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVX8RL(item, "num"         )
      name    = self.VVX8RL(item, "name"        )
      stream_id   = self.VVX8RL(item, "stream_id"       )
      stream_icon   = self.VVX8RL(item, "stream_icon"       )
      added    = self.VVX8RL(item, "added"    , isDate=True )
      is_adult   = self.VVX8RL(item, "is_adult"       )
      category_id   = self.VVX8RL(item, "category_id"       )
      container_extension = self.VVX8RL(item, "container_extension"     ) or "mp4"
      if self.VV2kiT(name): name = FFNMGt(name, VVvAHa)
      list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVl5fs:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVX8RL(item, "num"        )
      name    = self.VVX8RL(item, "name"       )
      series_id   = self.VVX8RL(item, "series_id"      )
      cover    = self.VVX8RL(item, "cover"       )
      genre    = self.VVX8RL(item, "genre"       )
      episode_run_time = self.VVX8RL(item, "episode_run_time"    )
      category_id   = self.VVX8RL(item, "category_id"      )
      container_extension = self.VVX8RL(item, "container_extension"    ) or "mp4"
      if self.VV2kiT(name): name = FFNMGt(name, VVvAHa)
      list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVoMmN(self, mode, title):
  qUrl = self.VVRiPe(mode, self.VVWmFQData["playListURL"])
  txt, err = self.VV3qHB(qUrl)
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     for item in tDict:
      category_id  = self.VVX8RL(item, "category_id"  )
      category_name = self.VVX8RL(item, "category_name" )
      parent_id  = self.VVX8RL(item, "parent_id"  )
      if category_name:
       list.append((category_name, category_id, parent_id))
   except:
    err = "Cannot parse received data !"
  else:
   FFRwfz(self, err, title=title)
  if err:
   FFRwfz(self, err, title=title)
  elif list:
   list.sort(key=lambda x: x[0].lower())
   if   mode == self.VVthLV  : okTitle = "Show Channels"
   elif mode == self.VV0Mgs  : okTitle = "Show Channels"
   elif mode == self.VVr4Nw : okTitle = "Show List"
   VV7bTo  = (okTitle, boundFunction(self.VVI7lr, mode) , [])
   VVGrFS = ("Exit IPTV"   , FFPWQ6       , [])
   VVb3Bo   = ("Category", "catID" , "ParentID" )
   widths   = (100   , 0  , 0    )
   FFI84f(self, None, title=title, VVb3Bo=VVb3Bo, VV0sV9=list, VVNZlV=widths, VVZ1jJ=30, VVGrFS=VVGrFS, VV7bTo=VV7bTo, VVgxh0="#0a00292B", VVd0OK="#0a002126", VVV3xM="#0a002126", VVt3ai="#00000000")
  else:
   FFRwfz(self, "No list from server !", title=title)
  FFVyro(self)
 def VVI7lr(self, mode, VVMzDi, title, txt, colList):
  title = colList[1]
  FF2E2r(VVMzDi, boundFunction(self.VVkXhQ, mode, VVMzDi, title, txt, colList), title="Downloading ...")
 def VVkXhQ(self, mode, VVMzDi, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title  = bName
  if   mode == self.VVthLV  : mode, title = self.VVR1nY  , "Live = %s" % title
  elif mode == self.VV0Mgs  : mode, title = self.VVNVcl  , "VOD = %s" % title
  elif mode == self.VVr4Nw : mode, title = self.VVl5fs , "Series = %s" % title
  qUrl  = self.VVRiPe(mode, self.VVWmFQData["playListURL"], catID)
  txt, err = self.VV3qHB(qUrl)
  list  = []
  if not err:
   if   mode == self.VVR1nY : list, err = self.VVdN8t(mode, txt)
   elif mode == self.VVNVcl  : list, err = self.VVdN8t(mode, txt)
   elif mode == self.VVl5fs : list, err = self.VVdN8t(mode, txt)
  if err:
   FFRwfz(self, err, title=title)
  elif list:
   VVGrFS  = ("Exit IPTV"   , FFPWQ6            , [])
   if mode == self.VVR1nY:
    VV7bTo  = ("Play"    , boundFunction(self.VVboBj, mode)    , [])
    VVpzw6 = (""     , boundFunction(self.VV55Ze, mode)    , [])
    VVJVgU = ("Download PIcons" , boundFunction(self.VVwqRo , mode)   , [])
    VVbtTj = ("Add ALL to Bouquet" , boundFunction(self.VVBGoY, mode, bName) , [])
    VVb3Bo   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 69  , 0   , 0   , 0  , 23  , 0   , 0   )
    VVAGqv  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVNVcl:
    VV7bTo  = ("Play"    , boundFunction(self.VVboBj, mode)    , [])
    VVpzw6 = (""     , boundFunction(self.VV55Ze, mode)    , [])
    VVJVgU = ("Download PIcons" , boundFunction(self.VVwqRo , mode)   , [])
    VVbtTj = ("Add ALL to Bouquet" , boundFunction(self.VVBGoY, mode, bName) , [])
    VVb3Bo   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 69  , 0   , 0   , 0  , 23  , 0   , 0  )
    VVAGqv  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVl5fs:
    VV7bTo  = ("Show Seasons", boundFunction(self.VVv18b, mode), [])
    VVpzw6 = ("", boundFunction(self.VVrm1b, mode), [])
    VVJVgU = None
    VVbtTj = None
    VVb3Bo   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 69  , 0   , 0   , 23  , 0  , 0  , 0   )
    VVAGqv  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFI84f(self, None, title=title, VVb3Bo=VVb3Bo, VV0sV9=list, VVAGqv=VVAGqv, VVNZlV=widths, VVZ1jJ=24, VV7bTo=VV7bTo, VVGrFS=VVGrFS, VVJVgU=VVJVgU, VVbtTj=VVbtTj, VVpzw6=VVpzw6, searchCol=1, VVgxh0="#0a00292B", VVd0OK="#0a002126", VVV3xM="#0a002126", VVt3ai="#00000000", VVgVDs=True)
  else:
   FFRwfz(self, "No Channels found !", title=title)
  FFVyro(self)
 def VVv18b(self, mode, VVMzDi, title, txt, colList):
  title = colList[1]
  FF2E2r(VVMzDi, boundFunction(self.VVMbLO, mode, VVMzDi, title, txt, colList), title="Downloading ...")
 def VVMbLO(self, mode, VVMzDi, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVRiPe(self.VVDuqL, self.VVWmFQData["playListURL"], series_id)
  txt, err = self.VV3qHB(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVX8RL(tDict["info"], "name"   )
      category_id = self.VVX8RL(tDict["info"], "category_id" )
      icon  = self.VVX8RL(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVX8RL(EP, "id"     )
        episode_num   = self.VVX8RL(EP, "episode_num"   )
        epTitle    = self.VVX8RL(EP, "title"     )
        container_extension = self.VVX8RL(EP, "container_extension" )
        seasonNum   = self.VVX8RL(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFRwfz(self, err, title=title)
  elif list:
   VVGrFS = ("Exit IPTV"   , FFPWQ6            , [])
   VVJVgU = ("Download PIcons" , boundFunction(self.VVwqRo , mode)   , [])
   VVbtTj = ("Add ALL to Bouquet" , boundFunction(self.VVBGoY, mode, title) , [])
   VVpzw6 = (""     , boundFunction(self.VV55Ze, mode)    , [])
   VV7bTo  = ("Play"    , boundFunction(self.VVboBj, mode)    , [])
   VVb3Bo   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVAGqv  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFI84f(self, None, title=title, VVb3Bo=VVb3Bo, VV0sV9=list, VVAGqv=VVAGqv, VVNZlV=widths, VVZ1jJ=24, VVGrFS=VVGrFS, VVJVgU=VVJVgU, VV7bTo=VV7bTo, VVpzw6=VVpzw6, VVbtTj=VVbtTj, VVgxh0="#0a00292B", VVd0OK="#0a002126", VVV3xM="#0a002126", VVt3ai="#00000000")
  else:
   FFRwfz(self, "No Channels found !", title=title)
  FFVyro(self)
 def VVC8t9(self, mode, colList):
  if mode == self.VVR1nY:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVNVcl:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFZTkY(chName)
  url = self.VVWmFQData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVAWrg(url)
  refCode = self.VVkaKA(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VV55Ze(self, mode, VVMzDi, title, txt, colList):
  FF2E2r(VVMzDi, boundFunction(self.VVDhbd, mode, VVMzDi, title, txt, colList))
 def VVDhbd(self, mode, VVMzDi, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVC8t9(mode, colList)
  path = ""
  if picUrl:
   path, err = FFUNQn(picUrl, "ajpanel_tmp.png", timeout=1)
  FF0y0a(self, txt, title=title, VVfzL0=path)
 def VVrm1b(self, mode, VVMzDi, title, txt, colList):
  FF2E2r(VVMzDi, boundFunction(self.VVoapZ, mode, VVMzDi, title, txt, colList))
 def VVoapZ(self, mode, VVMzDi, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  += "Duration\t: %s" % Dur
  if Cover: path, err = FFUNQn(Cover, "ajpanel_tmp.png", timeout=1)
  else : path = ""
  FF0y0a(self, txt, title=name, VVfzL0=path)
 def VVBGoY(self, mode, bName, VVMzDi, title, txt, colList):
  FF2E2r(VVMzDi, boundFunction(self.VVrO7m, mode, bName, VVMzDi, title, txt, colList), title="Adding Channels ...")
 def VVrO7m(self, mode, bName, VVMzDi, title, txt, colList):
  url = self.VVWmFQData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVAWrg(url)
  num = 0
  path = VVVuM0 + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVVuM0 + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVMzDi.VVOs8r():
    chName, chUrl, picUrl, refCode = self.VVC8t9(mode, row)
    f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
    f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
    totChange += 1
  FFuNTm(os.path.basename(path))
  self.VVFlxw(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVwqRo(self, mode, VVMzDi, title, txt, colList):
  totRows = VVMzDi.VVceP4()
  FFQsdM(self, boundFunction(FF2E2r, VVMzDi, boundFunction(self.VVrCrY, mode, VVMzDi), title="Downloading %d PIcons ..." % totRows), "Download PIcons for %d records ?\n\n( THIS CAN BE A LONG PROCESS )" % totRows, title="Download PIcons")
 def VVrCrY(self, mode, VVMzDi):
  pPath = CCpLfD.VV6tkf()
  if pathExists(pPath):
   c = 0
   for row in VVMzDi.VVOs8r():
    chName, chUrl, picUrl, refCode = self.VVC8t9(mode, row)
    if picUrl:
     picon = refCode.replace(":", "_").rstrip("_") + ".png"
     path, err = FFUNQn(picUrl, picon, timeout=1)
     if path:
      c += 1
      cmd = ""
      if not mode == self.VVR1nY:
       cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
      cmd += FFZNvw("mv -f '%s' '%s'" % (path, pPath)) + ";"
      os.system(cmd)
   FF0y0a(self, "Total PIcons = %d\n\nDownloaded to:\n%s" % (c, pPath), title="PIcons Download Result")
  else:
   FFRwfz(self, "PIcons path not found.\n\n%s" % pPath)
 def VVkaKA(self, catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = self.VVLjoG(catID, MAX_4b)
  TSID = self.VVLjoG(chNum, MAX_4b)
  ONID = self.VVLjoG(chNum, MAX_4b)
  NS  = self.VVLjoG(stID, MAX_8b)
  int(catID) if catID.isdigit() else ""
  return "4097:0:1:%s:%s:%s:%s:0:0:0:" % (SID, TSID, ONID, NS)
 def VVLjoG(self, numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
class CCH4jc(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFPc34(VVFqLG, 700, 700, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVAQdl  = 0
  self.VVp8s3 = 1
  self.VVxu2N  = 2
  VVleKL = []
  VVleKL.append(("Find All (from filter)"    , "VVAB8c" ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Find All"        , "VVdgI0"    ))
  VVleKL.append(("Find TV"        , "VViNDn"    ))
  VVleKL.append(("Find Radio"       , "VVle9T"   ))
  if self.VVCdtq():
   VVleKL.append(VV8ygQ)
   VVleKL.append(("Hide Channel: %s" % self.servName , "VVmIca"   ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Zap History"       , "VVwcLY"    ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("PIcons Tools"       , "PIconsTools"     ))
  VVleKL.append(("Channels Tools"      , "ChannelsTools"    ))
  FFBP5J(self, VVleKL=VVleKL, title=title)
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  FFqDc3(self["myMenu"])
  FFQH05(self)
  if self.isFindMode:
   self.VV5t9z(self.VVwYu0())
 def VVjeN5(self):
  global VVjhpS
  VVjhpS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVdgI0"    : self.VVdgI0()
   elif item == "VVAB8c" : self.VVAB8c()
   elif item == "VViNDn"    : self.VViNDn()
   elif item == "VVle9T"   : self.VVle9T()
   elif item == "VVmIca"   : self.VVmIca()
   elif item == "VVwcLY"    : self.VVwcLY()
   elif item == "PIconsTools"     : self.session.open(CCpLfD)
   elif item == "ChannelsTools"    : self.session.open(CCXkK1)
 def VViNDn(self) : self.VV5t9z(self.VVAQdl)
 def VVle9T(self) : self.VV5t9z(self.VVp8s3)
 def VVdgI0(self) : self.VV5t9z(self.VVxu2N)
 def VV5t9z(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFX60J(self, boundFunction(self.VVV9Jd, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVAB8c(self):
  filterObj = CCiBgE(self)
  filterObj.VV4Q7Z(self.VVo3eW)
 def VVo3eW(self, item):
  self.VVV9Jd(self.VVxu2N, item)
 def VVCdtq(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFKVJY(self.refCode)        : return False
  return True
 def VVV9Jd(self, mode, VVbHDF):
  FF2E2r(self, boundFunction(self.VVVRbd, mode, VVbHDF), title="Searching ...")
 def VVVRbd(self, mode, VVbHDF):
  if VVbHDF:
   self.findTxt = VVbHDF
   if   mode == self.VVAQdl  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVp8s3 : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVbHDF)
   if len(title) > 55:
    title = title[:55] + ".."
   VVLRbU = self.VVxnGw(VVbHDF, servTypes)
   if self.isFindMode or mode == self.VVxu2N:
    VVLRbU += self.VV8kQM(VVbHDF)
   if VVLRbU:
    VVLRbU.sort(key=lambda x: x[0].lower())
    VVFNcA = self.VVJyUV
    VV7bTo  = ("Zap"   , self.VVqVtp    , [])
    VVJVgU = ("Current Service", self.VVGBod , [])
    VVbtTj = ("Options"  , self.VVkBfX , [])
    VVpzw6 = (""    , self.VVbkC4 , [])
    VVb3Bo   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVAGqv  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFI84f(self, None, title=title, VVb3Bo=VVb3Bo, VV0sV9=VVLRbU, VVAGqv=VVAGqv, VVNZlV=widths, VVZ1jJ=25, VV7bTo=VV7bTo, VVFNcA=VVFNcA, VVJVgU=VVJVgU, VVbtTj=VVbtTj, VVpzw6=VVpzw6)
   else:
    self.VV5t9z(self.VVwYu0())
    FFVXKI(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVxnGw(self, VVbHDF, servTypes):
  VVk2NF  = eServiceCenter.getInstance()
  VV3QaD   = '%s ORDER BY name' % servTypes
  VVVHJH   = eServiceReference(VV3QaD)
  VVs9Ie = VVk2NF.list(VVVHJH)
  if VVs9Ie: VV0sV9 = VVs9Ie.getContent("CN", False)
  else     : VV0sV9 = None
  VVLRbU = []
  if VV0sV9:
   VVFjcY, VVaijI = FFpN9C()
   tp   = CCOm0d()
   words, asPrefix = CCiBgE.VVSxZN(VVbHDF)
   colorYellow  = CCgbRZ.VV9vw8(VVvAHa)
   colorWhite  = CCgbRZ.VV9vw8(VVMR5q)
   for s in VV0sV9:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FF1HAl(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVFjcY:
        STYPE = VVaijI[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVe9c8(refCode)
       if not "-S" in syst:
        sat = syst
       VVLRbU.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVLRbU
 def VV8kQM(self, VVbHDF):
  VVbHDF = VVbHDF.lower()
  VVDH8R = FFIgUg()
  VVLRbU = []
  colorYellow  = CCgbRZ.VV9vw8(VVvAHa)
  colorWhite  = CCgbRZ.VV9vw8(VVMR5q)
  if VVDH8R:
   for b in VVDH8R:
    VVHUXe  = b[0]
    VV5fPF  = b[1].toString()
    VVoYtW = eServiceReference(VV5fPF)
    VVAyix = FFJ5Wh(VVoYtW)
    for service in VVAyix:
     refCode  = service[0]
     if FFKVJY(refCode):
      servName = service[1]
      if VVbHDF in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VVbHDF), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VVLRbU.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVLRbU
 def VVwYu0(self):
  VVctp2 = InfoBar.instance
  if VVctp2:
   VV4bcG = VVctp2.servicelist
   if VV4bcG:
    return VV4bcG.mode == 1
  return self.VVxu2N
 def VVJyUV(self, VVMzDi):
  self.close()
  VVMzDi.cancel()
 def VVqVtp(self, VVMzDi, title, txt, colList):
  FFM38n(VVMzDi, colList[2], VVDz76=False, checkParentalControl=True)
 def VVGBod(self, VVMzDi, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFDq4f(VVMzDi)
  if refCode:
   VVMzDi.VV6hTi(2, FF7Hfa(refCode, iptvRef, chName), True)
 def VVkBfX(self, VVMzDi, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CC6EK5(self, VVMzDi, 2)
  mSel.VVUXi9(servName, refCode)
 def VVbkC4(self, VVMzDi, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  txt += FFLQGG(refCode, refCode, chName)
  if FFKVJY(refCode):
   txt += CCgisO.VVD7V2(refCode)
  else:
   tp = CCOm0d()
   tpTxt, namespace = tp.VV1LYW(refCode)
   del tp
   if tpTxt:
    txt += VVuDI9 + "\n"
    txt += tpTxt
  png, path = CCpLfD.VVs7r4(refCode, chName)
  FF0y0a(self, txt, title=title, VVfzL0=path)
 def VVmIca(self):
  FFQsdM(self, self.VVnyHI, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVnyHI(self):
  ret = FFoQXt(self.refCode, True)
  if ret:
   self.VVBNlj()
   self.close()
  else:
   FFVyro(self, "Cannot change state" , 1000)
 def VVBNlj(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VV1vyZ()
  except:
   self.VVKdNR()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      self.session.nav.playService(serviceRef)
 def VVoXHj(self):
  VVctp2 = InfoBar.instance
  if VVctp2:
   VV4bcG = VVctp2.servicelist
   if VV4bcG:
    VV4bcG.setMode()
 def VV1vyZ(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVctp2 = InfoBar.instance
   if VVctp2:
    VV4bcG = VVctp2.servicelist
    if VV4bcG:
     hList = VV4bcG.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VV4bcG.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VV4bcG.history  = newList
       VV4bcG.history_pos = pos
 def VVKdNR(self):
  VVctp2 = InfoBar.instance
  if VVctp2:
   VV4bcG = VVctp2.servicelist
   if VV4bcG:
    VV4bcG.history  = []
    VV4bcG.history_pos = 0
 def VVwcLY(self):
  VVctp2 = InfoBar.instance
  VVLRbU = []
  if VVctp2:
   VV4bcG = VVctp2.servicelist
   if VV4bcG:
    VVFjcY, VVaijI = FFpN9C()
    for chParams in VV4bcG.history:
     refCode = chParams[-1].toString()
     chName = FFD086(refCode)
     isIptv = FFKVJY(refCode)
     if isIptv: sat = "-"
     else  : sat = FF1HAl(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVFjcY:
       STYPE = VVaijI[sTypeInt]
     VVLRbU.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVLRbU:
   VV7bTo  = ("Zap"   , self.VVYuqL   , [])
   VVbtTj = ("Clear History" , self.VVukv2   , [])
   VVpzw6 = (""    , self.VVJGWnFromZapHistory , [] )
   VVb3Bo   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVAGqv  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFI84f(self, None, title=title, VVb3Bo=VVb3Bo, VV0sV9=VVLRbU, VVAGqv=VVAGqv, VVNZlV=widths, VVZ1jJ=23, VV7bTo=VV7bTo, VVbtTj=VVbtTj, VVpzw6=VVpzw6)
  else:
   FFVXKI(self, "Not found", title=title)
 def VVYuqL(self, VVMzDi, title, txt, colList):
  FFM38n(VVMzDi, colList[3], VVDz76=False, checkParentalControl=True)
 def VVukv2(self, VVMzDi, title, txt, colList):
  FFQsdM(self, boundFunction(self.VVyQHB, VVMzDi), "Clear Zap History ?")
 def VVyQHB(self, VVMzDi):
  self.VVKdNR()
  VVMzDi.cancel()
 def VVJGWnFromZapHistory(self, VVMzDi, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  png, path = CCpLfD.VVs7r4(refCode, chName)
  FF0y0a(self, txt, title=title, VVfzL0=path)
class CCpLfD(Screen):
 VVt1Ah   = 0
 VVYGHo  = 1
 VVCgWh  = 2
 VVlKwe  = 3
 VVwZdP  = 4
 VVRAmL  = 5
 VVHk3w  = 6
 VVPifv = 7
 VV2pTj = 8
 def __init__(self, session):
  self.skin, self.skinParam = FFPc34(VVr8W3, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFBP5J(self, self.Title)
  FF0WGA(self["keyRed"] , "OK = Zap")
  FF0WGA(self["keyGreen"] , "Current Service")
  FF0WGA(self["keyYellow"], "Page Options")
  FF0WGA(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCpLfD.VV6tkf()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VV0sV9    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVHnFW   ,
   "green"   : self.VV2vqh  ,
   "yellow"  : self.VVNUHJ   ,
   "blue"   : self.VVQ2wr   ,
   "menu"   : self.VVZXLl   ,
   "info"   : self.VVJGWn    ,
   "up"   : self.VVa6GU     ,
   "down"   : self.VVf2XF    ,
   "left"   : self.VV7oMZ    ,
   "right"   : self.VVT9YS    ,
   "pageUp"  : self.VV4ima    ,
   "chanUp"  : self.VV4ima    ,
   "pageDown"  : self.VVvp69   ,
   "chanDown"  : self.VVvp69   ,
   "next"   : self.VVKOpE    ,
   "last"   : self.VVBnYj    ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  FFoFoL(self)
  FFkgcm(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FF2E2r(self, boundFunction(self.VVEwIZ, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVZXLl(self):
  if not self.isBusy:
   VVleKL = []
   VVleKL.append(("Statistics"           , "VVz5Pm"    ))
   VVleKL.append(VV8ygQ)
   VVleKL.append(("Suggest PIcons for Current Channel"     , "VVwZtc"   ))
   VVleKL.append(("Set to Current Channel (copy file)"     , "VVqGRi_file"  ))
   VVleKL.append(("Set to Current Channel (as SymLink)"     , "VVqGRi_link"  ))
   VVleKL.append(VV8ygQ)
   VVleKL.append(CCpLfD.VVu4tu())
   VVleKL.append(VV8ygQ)
   VVleKL.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVHWzQ"  ))
   VVleKL.append(VV8ygQ)
   VVleKL += CCpLfD.VVN5Bm()
   FF7X20(self, self.VVOILd, title=self.Title, VVleKL=VVleKL)
 def VVOILd(self, item=None):
  if item is not None:
   if   item == "VVz5Pm"     : self.VVz5Pm()
   elif item == "VVwZtc"    : FF2E2r(self, self.VVwZtc, clearMsg=False)
   elif item == "VVqGRi_file"   : self.VVqGRi(0)
   elif item == "VVqGRi_link"   : self.VVqGRi(1)
   elif item == "VV8zjJ_file"  : self.VV8zjJ(0)
   elif item == "VV8zjJ_link"  : self.VV8zjJ(1)
   elif item == "VVYH4A"   : self.VVYH4A()
   elif item == "VVTXpg"  : self.VVTXpg()
   elif item == "VVAtpp"   : self.VVAtpp()
   elif item == "VVHWzQ"   : self.VVHWzQ()
   elif item == "VVie7F"   : CCpLfD.VVie7F(self)
   elif item == "VVxTy4"   : CCpLfD.VVxTy4(self)
   elif item == "findPiconBrokenSymLinks"  : CCpLfD.VVbqLb(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCpLfD.VVbqLb(self, False)
 def VVNUHJ(self):
  if not self.isBusy:
   VVleKL = []
   VVleKL.append(("Go to First PIcon   ( < )" , "VVBnYj"  ))
   VVleKL.append(("Go to Last PIcon   ( > )"  , "VVKOpE"  ))
   VVleKL.append(VV8ygQ)
   VVleKL.append(("Sort by Channel Name"      , "sortByChan" ))
   VVleKL.append(("Sort by File Name"   , "sortByFile" ))
   VVleKL.append(VV8ygQ)
   VVleKL.append(("Find from File List .."  , "VVgXsB" ))
   FF7X20(self, self.VVfyXr, title=self.Title, VVleKL=VVleKL)
 def VVfyXr(self, item=None):
  if item is not None:
   if   item == "VVBnYj"   : self.VVBnYj()
   elif item == "VVKOpE"   : self.VVKOpE()
   elif item == "sortByChan"  : self.VVuKo0(2)
   elif item == "sortByFile"  : self.VVuKo0(0)
   elif item == "VVgXsB"  : self.VVgXsB()
 def VVa6GU(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVKOpE()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VV45y7()
 def VVf2XF(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVBnYj()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VV45y7()
 def VV7oMZ(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVKOpE()
  else:
   self.curCol -= 1
   self.VV45y7()
 def VVT9YS(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVBnYj()
  else:
   self.curCol += 1
   self.VV45y7()
 def VV4ima(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VV45y7(True)
 def VVvp69(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VV45y7(True)
 def VVBnYj(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VV45y7(True)
 def VVKOpE(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VV45y7(True)
 def VVgXsB(self):
  VVleKL = []
  for item in self.VV0sV9:
   VVleKL.append((item[0], item[0]))
  FF7X20(self, self.VV9GGB, title='PIcons ".png" Files', VVleKL=VVleKL, VVqaht=True)
 def VV9GGB(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVG4OP(ndx)
 def VVHnFW(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VViz0e()
   if refCode:
    FFM38n(self, refCode)
    self.VV8rAZ()
    self.VVRyie()
 def VV2vqh(self):
  if self["keyGreen"].getVisible():
   self.VVG4OP(self.curChanIndex)
 def VVG4OP(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VV45y7(True)
  else:
   FFVyro(self, "Not found", 1000)
 def VVuKo0(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FF2E2r(self, boundFunction(self.VVEwIZ, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVqGRi(self, mode):
  title = "Change Current Channel PIcon"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFDq4f(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VViz0e()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVleKL = []
     VVleKL.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVleKL.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FF7X20(self, boundFunction(self.VVaJUR, mode, curChF, selPiconF), VVleKL=VVleKL, title="Current Channel PIcon (already exists)")
    else:
     self.VVaJUR(mode, curChF, selPiconF, "overwrite")
   else:
    FFRwfz(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFRwfz(self, "Could not read current channel info. !", title=title)
 def VVaJUR(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FF2E2r(self, boundFunction(self.VVEwIZ, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VV8zjJ(self, mode):
  pass
 def VVYH4A(self):
  pass
 def VVTXpg(self):
  pass
 def VVAtpp(self):
  pass
 def VVHWzQ(self):
  lines = FFnzIb("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFQsdM(self, boundFunction(self.VVGW2k, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVyjYQ=True)
  else:
   FFVXKI(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVGW2k(self, fList):
  os.system(FFZNvw("find -L '%s' -type l -delete" % self.pPath))
  FFVXKI(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVJGWn(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VViz0e()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFNMGt("PIcon Directory:\n", VVvs8y)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FF2hmz(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FF2hmz(path)
   txt += FFNMGt("PIcon File:\n", VVvs8y)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFnzIb(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFNMGt("Found %d SymLink%s to this file from:\n" % (tot, s), VVvs8y)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFD086(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFNMGt(tChName, VViUes)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFNMGt(line, VVrETx), tChName)
    txt += "\n"
   if chName:
    txt += FFNMGt("Channel:\n", VVvs8y)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFNMGt(chName, VViUes)
    if sat:
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFNMGt("Remarks:\n", VVvs8y)
    txt += "  %s\n" % FFNMGt("Unused", VVxYDU)
  else:
   txt = "No info found"
  FF0y0a(self, txt, VVfzL0=self.pPath + filName, title="PIcon Info.")
 def VViz0e(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VV0sV9[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFKoSI(sat)
  return fName, refCode, chName, sat, inDB
 def VV8rAZ(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFDq4f(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VV0sV9):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVRyie(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VViz0e()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFNMGt("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVvs8y))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VViz0e()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFNMGt(self.curChanName, VVvAHa)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVz5Pm(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VV0sV9:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFactG("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FF0y0a(self, txt, title=self.Title)
 def VVQ2wr(self):
  if not self.isBusy:
   VVleKL = []
   VVleKL.append(("All"         , "all"   ))
   VVleKL.append(VV8ygQ)
   VVleKL.append(("Used by Channels"      , "used"  ))
   VVleKL.append(("Unused PIcons"      , "unused"  ))
   VVleKL.append(VV8ygQ)
   VVleKL.append(("PIcons Files"       , "pFiles"   ))
   VVleKL.append(("SymLinks to PIcons"     , "pLinks"   ))
   VVleKL.append(("PIcons Files Targeted by SymLinks" , "pTargets"  ))
   if self.nsList:
    VVleKL.append(VV8ygQ)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFtBBn(val)
      VVleKL.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCiBgE(self)
   filterObj.VVLI8W(VVleKL, self.nsList, self.VVzvwT)
 def VVzvwT(self, item=None):
  if item is not None:
   self.VVbEaV(item)
 def VVbEaV(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVt1Ah   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVYGHo   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVCgWh  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVlKwe  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVwZdP  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVRAmL  , ""  , "Targets"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVHk3w   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVPifv , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVRAmL:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFnzIb("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFVyro(self, "Not found", 1000)
     return
   elif mode == self.VV2pTj:
    return
   else:
    words, asPrefix = CCiBgE.VVSxZN(words)
   if not words and mode in (self.VVHk3w, self.VVPifv):
    FFVyro(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FF2E2r(self, boundFunction(self.VVEwIZ, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...")
 def VVwZtc(self):
  FFVyro(self, "Loading Channels ...")
  lameDbChans = CCXkK1.VVXUi6(self, CCXkK1.VV98a1, VVFeLp=False, VV1KQM=False)
  files = []
  words = []
  if lameDbChans:
   curCh = self.curChanName.lower().replace(" hd", "").replace(" fm", "").replace("4k", "")
   for refCode in lameDbChans:
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = self.VV8M2o(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCpLfD.VVTCeT(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       words.append(f.replace(".png", ""))
  if words:
   FF2E2r(self, boundFunction(self.VVEwIZ, mode=self.VV2pTj, words=words), title="Filtering ...")
  else:
   FFVyro(self, "Not found", 1000)
 def VVEwIZ(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VV9Unn(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCXkK1.VVXUi6(self, CCXkK1.VV98a1, VVFeLp=False, VV1KQM=False)
  tList = []
  for fName, fType in CCpLfD.VVau0J(self.pPath):
   fName = fName[:-4]
   if fName.count("_") > 8 and lameDbChans:
    chName, sat, inDB = lameDbChans.get(fName, ("", "", 0))
    if inDB and not chName:
     chName = "?"
    namSp = fName.split("_")[6].zfill(8)[:4]
   else:
    namSp = ""
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVt1Ah              :
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVYGHo  and chName         : isAdd = True
   elif mode == self.VVCgWh and not chName        : isAdd = True
   elif mode == self.VVlKwe  and fType == 0        : isAdd = True
   elif mode == self.VVwZdP  and fType == 1        : isAdd = True
   elif mode == self.VVRAmL  and fName in words       : isAdd = True
   elif mode == self.VV2pTj and fName in words       : isAdd = True
   elif mode == self.VVHk3w  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVPifv:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VV0sV9   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
  else:
   self.isBusy = False
   FFVyro(self, "Not found", 1000)
   return
  self.VV0sV9.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VV8rAZ()
  self.totalPIcons = len(self.VV0sV9)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VV45y7(True)
 def VV9Unn(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCpLfD.VVau0J(self.pPath):
    if fName:
     return True
   if isFirstTime : FFRwfz(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFVyro(self, "Not found", 1000)
  else:
   FFRwfz(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VV45y7(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVFwTx = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVFwTx: self.curPage = VVFwTx
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVE6FY()
  if self.curPage == VVFwTx:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVRyie()
  filName, refCode, chName, sat, inDB = self.VViz0e()
  if inDB : self["keyRed"].show()
  else : self["keyRed"].hide()
 def VVE6FY(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VV0sV9[ndx]
   fName = self.VV0sV9[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFNMGt(chName, VViUes))
    else : lbl.setText("-")
   except:
    lbl.setText(FFNMGt(chName, VVy7KO))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VV8M2o(self, s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVu4tu():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVie7F"   )
 @staticmethod
 def VVN5Bm():
  VVleKL = []
  VVleKL.append(("Find SymLinks (to PIcon Directory)"   , "VVxTy4"   ))
  VVleKL.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVleKL.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVleKL
 @staticmethod
 def VVie7F(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFDq4f(SELF)
  png, path = CCpLfD.VVs7r4(refCode)
  if path : CCpLfD.VVmj4L(SELF, png, path)
  else : FFRwfz(SELF, "No PIcon found for current channel in:\n\n%s" % CCpLfD.VV6tkf())
 @staticmethod
 def VVxTy4(SELF):
  if VVvAHa:
   sed1 = FFbAJE("->", VVvAHa)
   sed2 = FFbAJE("picon", VVxYDU)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVy7KO, VVMR5q)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFfQ52(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFdplS(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVbqLb(SELF, isPIcon):
  sed1 = FFbAJE("->", VVy7KO)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFbAJE("picon", VVxYDU)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFfQ52(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFdplS(), grep, sed1, sed2))
 @staticmethod
 def VVau0J(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VV6tkf():
  path = CFG.PIconsPath.getValue()
  return FFjUmV(path)
 @staticmethod
 def VVs7r4(refCode, chName=None):
  if FFKVJY(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFKp7T(refCode)
  allPath, fName, refCodeFile, pList = CCpLfD.VVTCeT(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVmj4L(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFbAJE("%s%s" % (dest, png), VViUes))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFbAJE(errTxt, VVK65K))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FF4lhA(SELF, cmd)
 @staticmethod
 def VVTCeT(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCpLfD.VV6tkf()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFZTkY(chName)
    lst = iGlob(allPath + chName + ".png")
    if lst:
     pList += lst
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCFaAG():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVqgz3  = None
  self.VVwxxJ = ""
  self.VVWIYm  = noService
  self.VVYHT0 = 0
  self.VVkVA8  = noService
  self.VVtqGE = 0
  self.VVRSoJ  = "-"
  self.VVBmSl = 0
  self.VVur6F  = ""
  self.serviceName = ""
 def VVVqrk(self, service):
  if service:
   feinfo = service.frontendInfo()
   if feinfo:
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVqgz3 = frontEndStatus
     self.VV9CzC()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VV9CzC(self):
  if self.VVqgz3:
   val = self.VVqgz3.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVwxxJ = "%3.02f dB" % (val / 100.0)
   else         : self.VVwxxJ = ""
   val = self.VVqgz3.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVYHT0 = int(val)
   self.VVWIYm  = "%d%%" % val
   val = self.VVqgz3.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVtqGE = int(val)
   self.VVkVA8  = "%d%%" % val
   val = self.VVqgz3.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVRSoJ  = "%d" % val
   val = int(val * 100 / 500)
   self.VVBmSl = min(500, val)
   val = self.VVqgz3.get("tuner_locked", 0)
   if val == 1 : self.VVur6F = "Locked"
   else  : self.VVur6F = "Not locked"
 def VVEHSt(self)   : return self.VVwxxJ
 def VVoStR(self)   : return self.VVWIYm
 def VV74IK(self)  : return self.VVYHT0
 def VVRP54(self)   : return self.VVkVA8
 def VVcPpV(self)  : return self.VVtqGE
 def VVHBrk(self)   : return self.VVRSoJ
 def VVqO03(self)  : return self.VVBmSl
 def VVagnk(self)   : return self.VVur6F
 def VVggLh(self) : return self.serviceName
class CCOm0d():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVk8xO(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFhPmX(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVWX7l(self.ORPOS  , mod=1   )
      self.sat2  = self.VVWX7l(self.ORPOS  , mod=2   )
      self.freq  = self.VVWX7l(self.FREQ  , mod=3   )
      self.sr   = self.VVWX7l(self.SR   , mod=4   )
      self.inv  = self.VVWX7l(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVWX7l(self.POL  , self.D_POL )
      self.fec  = self.VVWX7l(self.FEC  , self.D_FEC )
      self.syst  = self.VVWX7l(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVWX7l("modulation" , self.D_MOD )
       self.rolof = self.VVWX7l("rolloff"  , self.D_ROLOF )
       self.pil = self.VVWX7l("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVWX7l("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVWX7l("pls_code"  )
       self.iStId = self.VVWX7l("is_id"   )
       self.t2PlId = self.VVWX7l("t2mi_plp_id" )
       self.t2PId = self.VVWX7l("t2mi_pid"  )
 def VVWX7l(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFtBBn(val)
  elif mod == 2   : return FFzqHs(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VV1LYW(self, refCode):
  txt = ""
  self.VVk8xO(refCode)
  if self.data:
   def VVAf2N(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVAf2N("System"   , self.syst)
    txt += VVAf2N("Satellite"  , self.sat2)
    txt += VVAf2N("Frequency"  , self.freq)
    txt += VVAf2N("Inversion"  , self.inv)
    txt += VVAf2N("Symbol Rate"  , self.sr)
    txt += VVAf2N("Polarization" , self.pol)
    txt += VVAf2N("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVAf2N("Modulation" , self.mod)
     txt += VVAf2N("Roll-Off" , self.rolof)
     txt += VVAf2N("Pilot"  , self.pil)
     txt += VVAf2N("Input Stream", self.iStId)
     txt += VVAf2N("T2MI PLP ID" , self.t2PlId)
     txt += VVAf2N("T2MI PID" , self.t2PId)
     txt += VVAf2N("PLS Mode" , self.plsMod)
     txt += VVAf2N("PLS Code" , self.plsCod)
   else:
    txt += VVAf2N("System"   , self.txMedia)
    txt += VVAf2N("Frequency"  , self.freq)
  return txt, self.namespace
 def VVL7Qm(self, refCode):
  txt = "Transpoder : ?"
  self.VVk8xO(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VVvs8y + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVe9c8(self, refCode):
  self.data = None
  servRef = eServiceReference(refCode)
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFhPmX(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVWX7l(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVWX7l(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVWX7l(self.SYST, self.D_SYS_S)
     freq = self.VVWX7l(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVWX7l(self.POL , self.D_POL)
      fec = self.VVWX7l(self.FEC , self.D_FEC)
      sr = self.VVWX7l(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVVpOT(self, refCode):
  self.data = None
  self.VVk8xO(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCMRwk():
 def __init__(self, VVUMQh, path, VVVmsi=None):
  self.VVUMQh  = VVUMQh
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVVmsi  = VVVmsi
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.insertMode   = 0
  response = os.system(FFZNvw("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVMNfr()
  else:
   FFRwfz(self.VVUMQh, "Error while preparing edit!")
 def VVMNfr(self):
  VVLRbU = self.VVBZd9()
  VVGrFS = None #("Delete Line" , self.deleteLine  , [])
  VVJVgU = ("Save Changes" , self.VVcEet   , [])
  VV7bTo  = ("Edit Line"  , self.VVEdye    , [])
  VVRqTs = ("Line Options" , self.VVBX0B   , [])
  VVCYQA = (""    , self.VVmo0Z , [])
  VVFNcA = self.VV04e3
  VVoWIj  = self.VVGqB9
  VVb3Bo   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVAGqv  = (CENTER  , LEFT  )
  FFI84f(self.VVUMQh, None, title=self.Title, VVb3Bo=VVb3Bo, VV0sV9=VVLRbU, VVAGqv=VVAGqv, VVNZlV=widths, VVZ1jJ=24, VVGrFS=VVGrFS, VVJVgU=VVJVgU, VV7bTo=VV7bTo, VVRqTs=VVRqTs, VVFNcA=VVFNcA, VVoWIj=VVoWIj, VVCYQA=VVCYQA, VVgVDs=True
    , VVgxh0   = "#11001111"
    , VVd0OK   = "#11001111"
    , VVV3xM   = "#11001111"
    , VVt3ai  = "#05333333"
    , VVtlnJ  = "#00222222"
    , VVeTWM  = "#11331133"
    )
 def VVBX0B(self, VVMzDi, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVMzDi.VVceP4()
  VVleKL = []
  VVleKL.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVleKL.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVjvaL"  ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVCerc:
   VVleKL.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(  ("Delete Line"         , "deleteLine"   ))
  FF7X20(self.VVUMQh, boundFunction(self.VVvB4j, VVMzDi, lineNum), VVleKL=VVleKL, title="Line Options")
 def VVvB4j(self, VVMzDi, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVZRND("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVMzDi)
   elif item == "VVjvaL"  : self.VVjvaL(VVMzDi, lineNum)
   elif item == "copyToClipboard"  : self.VVOOhq(VVMzDi, lineNum)
   elif item == "pasteFromClipboard" : self.VV7k17(VVMzDi, lineNum)
   elif item == "deleteLine"   : self.VVZRND("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVMzDi)
 def VVGqB9(self, VVMzDi):
  VVMzDi.VVGA7s()
 def VVmo0Z(self, VVMzDi, title, txt, colList):
  if   self.insertMode == 1: VVMzDi.VV9XCo()
  elif self.insertMode == 2: VVMzDi.VVtkTi()
  self.insertMode = 0
 def VVjvaL(self, VVMzDi, lineNum):
  if lineNum == VVMzDi.VVceP4():
   self.insertMode = 1
   self.VVZRND("echo '' >> '%s'" % self.tmpFile, VVMzDi)
  else:
   self.insertMode = 2
   self.VVZRND("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVMzDi)
 def VVOOhq(self, VVMzDi, lineNum):
  global VVCerc
  VVCerc = FFactG("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVMzDi.VV8K08("Copied to clipboard")
 def VVcEet(self, VVMzDi, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFZNvw("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFZNvw("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVMzDi.VV8K08("Saved")
     self.fileChanged = False
     VVMzDi.VVGA7s()
    else:
     FFRwfz(self.VVUMQh, "Cannot save file!")
   else:
    FFRwfz(self.VVUMQh, "Cannot create backup copy of original file!")
 def VV04e3(self, VVMzDi):
  if self.fileChanged:
   FFQsdM(self.VVUMQh, boundFunction(self.VVNrwK, VVMzDi), "Cancel changes ?")
  else:
   finalOK = os.system(FFZNvw("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVNrwK(VVMzDi)
 def VVNrwK(self, VVMzDi):
  VVMzDi.cancel()
  os.system(FFZNvw("rm -f '%s'" % self.tmpFile))
  if self.VVVmsi:
   self.VVVmsi()
 def VVEdye(self, VVMzDi, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVMR5q + "ORIGINAL TEXT:\n" + VVrETx + lineTxt
  FFX60J(self.VVUMQh, boundFunction(self.VVHlKC, lineNum, VVMzDi), title="File Line", defaultText=lineTxt, message=message)
 def VVHlKC(self, lineNum, VVMzDi, VVKchL):
  if not VVKchL is None:
   if VVMzDi.VVceP4() <= 1:
    self.VVZRND("echo %s > '%s'" % (VVKchL, self.tmpFile), VVMzDi)
   else:
    self.VVpnXi(VVMzDi, lineNum, VVKchL)
 def VV7k17(self, VVMzDi, lineNum):
  if lineNum == VVMzDi.VVceP4() and VVMzDi.VVceP4() == 1:
   self.VVZRND("echo %s >> '%s'" % (VVCerc, self.tmpFile), VVMzDi)
  else:
   self.VVpnXi(VVMzDi, lineNum, VVCerc)
 def VVpnXi(self, VVMzDi, lineNum, newTxt):
  VVMzDi.VVPLYE("Saving ...")
  lines = FFFfb9(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVMzDi.VVujvk()
  VVLRbU = self.VVBZd9()
  VVMzDi.VVVImv(VVLRbU)
 def VVZRND(self, cmd, VVMzDi):
  tCons = CChFBB()
  tCons.ePopen(cmd, boundFunction(self.VVLURv, VVMzDi))
  self.fileChanged = True
  VVMzDi.VVujvk()
 def VVLURv(self, VVMzDi, result, retval):
  VVLRbU = self.VVBZd9()
  VVMzDi.VVVImv(VVLRbU)
 def VVBZd9(self):
  if fileExists(self.tmpFile):
   lines = FFFfb9(self.tmpFile)
   VVLRbU = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVLRbU.append((str(ndx), line.strip()))
   if not VVLRbU:
    VVLRbU.append((str(1), ""))
   return VVLRbU
  else:
   FFiKqP(self.VVUMQh, self.tmpFile)
class CCiBgE():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVleKL   = []
  self.satList   = []
 def VV4Q7Z(self, VVVmsi):
  self.VVleKL = []
  VVleKL, VVlMBg = self.VVL4N9(False, True)
  if VVleKL:
   self.VVleKL += VVleKL
   self.VVEF47(VVVmsi, VVlMBg)
 def VVMr8s(self, mode, VVMzDi, satCol, VVVmsi):
  VVMzDi.VVPLYE("Loading Filters ...")
  self.VVleKL = []
  self.VVleKL.append(("All Services" , "all"))
  if mode == 1:
   self.VVleKL.append(VV8ygQ)
   self.VVleKL.append(("Parental Control", "parentalControl"))
   self.VVleKL.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVleKL.append(VV8ygQ)
   self.VVleKL.append(("Selected Transponder"   , "selectedTP" ))
   self.VVleKL.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVsd6L(VVMzDi, satCol)
  VVleKL, VVlMBg = self.VVL4N9(True, False)
  if VVleKL:
   VVleKL.insert(0, VV8ygQ)
   self.VVleKL += VVleKL
  VVMzDi.VVszJj()
  self.VVEF47(VVVmsi, VVlMBg)
 def VVLI8W(self, VVleKL, sats, VVVmsi):
  self.VVleKL = VVleKL
  VVleKL, VVlMBg = self.VVL4N9(True, False)
  if VVleKL:
   self.VVleKL.append(VV8ygQ)
   self.VVleKL += VVleKL
  self.VVEF47(VVVmsi, VVlMBg)
 def VVyrYE(self, VVleKL, sats, VVVmsi):
  self.VVleKL = VVleKL
  VVleKL, VVlMBg = self.VVL4N9(True, False)
  if VVleKL:
   self.VVleKL.append(VV8ygQ)
   self.VVleKL += VVleKL
  self.VVEF47(VVVmsi, VVlMBg)
 def VVEF47(self, VVVmsi, VVlMBg):
  VVrIGp = ("Edit Filter", boundFunction(self.VVHA7J, VVlMBg))
  VV4CPh  = ("Filter Help", boundFunction(self.VVuhff, VVlMBg))
  FF7X20(self.callingSELF, boundFunction(self.VV3ZWj, VVVmsi), VVleKL=self.VVleKL, title="Select Filter", VVrIGp=VVrIGp, VV4CPh=VV4CPh)
 def VV3ZWj(self, VVVmsi, item):
  if item:
   VVVmsi(item)
 def VVHA7J(self, VVlMBg, VVxnlbObj, sel):
  if fileExists(VVlMBg) : CCMRwk(self.callingSELF, VVlMBg, VVVmsi=None)
  else       : FFiKqP(self.callingSELF, VVlMBg)
  VVxnlbObj.cancel()
 def VVuhff(self, VVlMBg, VVxnlbObj, sel):
  FF8PEY(self.callingSELF, VVfX8s + "_help_service_filter", "Service Filter")
 def VVsd6L(self, VVMzDi, satColNum):
  if not self.satList:
   satList = VVMzDi.VV7rVB(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFKoSI(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VV8ygQ)
  if self.VVleKL:
   self.VVleKL += self.satList
 def VVL4N9(self, addTag, showErr):
  FFlQ92()
  fileName  = "ajpanel_services_filter"
  VVlMBg = VV84Zp + fileName
  VVleKL  = []
  if not fileExists(VVlMBg):
   os.system(FFZNvw("cp -f '%s' '%s'" % (VVfX8s + fileName, VVlMBg)))
  fileFound = False
  if fileExists(VVlMBg):
   fileFound = True
   lines = FFFfb9(VVlMBg)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVleKL.append((line, "__w__" + line))
       else  : VVleKL.append((line, line))
  if showErr:
   if   not fileFound : FFiKqP(self.callingSELF , VVlMBg)
   elif not VVleKL : FF96ug(self.callingSELF , VVlMBg)
  return VVleKL, VVlMBg
 @staticmethod
 def VVSxZN(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CC6EK5():
 def __init__(self, callingSELF, VVMzDi, refCodeColNum):
  self.callingSELF = callingSELF
  self.VVMzDi = VVMzDi
  self.refCodeColNum = refCodeColNum
  self.VVleKL = []
  iMulSel = self.VVMzDi.VVRYFP()
  if iMulSel : self.VVleKL.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVleKL.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVMzDi.VVdBoY()
  self.VVleKL.append(    ("Select all"    , "selectAll"  ))
  if tot > 0:
   self.VVleKL.append(   ("Unselect all"    , "unselectAll"  ))
  self.VVleKL.append(VV8ygQ)
 def VVUXi9(self, servName, refCode):
  tot = self.VVMzDi.VVdBoY()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVleKL.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVdie5_multi" ))
  else    : self.VVleKL.append( ("Add to Bouquet : %s"      % servName , "VVdie5_one" ))
  self.VVROrV(servName, refCode)
 def VVMGt8(self, servName, refCode, pcState, hidState):
  self.VVleKL = []
  if pcState == "No" : self.VVleKL.append(("Add to Parental Control"  , "parentalControl_add"  ))
  else    : self.VVleKL.append(("Remove from Parental Control" , "parentalControl_remove" ))
  if hidState == "No" : self.VVleKL.append(("Add to Hidden Services"  , "hiddenServices_add"  ))
  else    : self.VVleKL.append(("Remove from Hidden Services" , "hiddenServices_remove" ))
  self.VVROrV(servName, refCode)
 def VVROrV(self, servName, refCode):
  FF7X20(self.callingSELF, boundFunction(self.VVA0KU, servName, refCode), title="Options", VVleKL=self.VVleKL)
 def VVA0KU(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"    : self.VVMzDi.VVQFSa(True)
   elif item == "MultSelDisab"    : self.VVMzDi.VVQFSa(False)
   elif item == "selectAll"    : self.VVMzDi.VVflGu()
   elif item == "unselectAll"    : self.VVMzDi.VVMGxI()
   elif item == "parentalControl_add"  : self.callingSELF.VV3msU(self.VVMzDi, refCode, True)
   elif item == "parentalControl_remove" : self.callingSELF.VV3msU(self.VVMzDi, refCode, False)
   elif item == "hiddenServices_add"  : self.callingSELF.VVRhtC(self.VVMzDi, refCode, True)
   elif item == "hiddenServices_remove" : self.callingSELF.VVRhtC(self.VVMzDi, refCode, False)
   elif item == "VVdie5_multi" : self.VVdie5(refCode, True)
   elif item == "VVdie5_one" : self.VVdie5(refCode, False)
 def VVdie5(self, refCode, isMulti):
  bouquets = FFIgUg()
  if bouquets:
   VVleKL = []
   for item in bouquets:
    VVleKL.append((item[0], item[1].toString()))
   VVrIGp = ("Create New", boundFunction(self.VVKFbj, refCode, isMulti))
   FF7X20(self.callingSELF, boundFunction(self.VVJN4J, refCode, isMulti), VVleKL=VVleKL, title="Add to Bouquet", VVrIGp=VVrIGp, VVqaht=True, VVNTzo=True)
  else:
   FFQsdM(self.callingSELF, boundFunction(self.VVPKWs, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVJN4J(self, refCode, isMulti, bName=None):
  if bName:
   FF2E2r(self.VVMzDi, boundFunction(self.VVyeTd, refCode, isMulti, bName), title="Adding Channels ...")
 def VVyeTd(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVoRYC(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVctp2 = InfoBar.instance
    if VVctp2:
     VV4bcG = VVctp2.servicelist
     if VV4bcG:
      mutableList = VV4bcG.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVMzDi.VVszJj()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFVXKI(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FFRwfz(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVoRYC(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVMzDi.VVGbxv(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VVKFbj(self, refCode, isMulti, VVxnlbObj, path):
  self.VVPKWs(refCode, isMulti)
 def VVPKWs(self, refCode, isMulti):
  FFX60J(self.callingSELF, boundFunction(self.VVvb9w, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVvb9w(self, refCode, isMulti, name):
  if name:
   FF2E2r(self.VVMzDi, boundFunction(self.VVOZVF, refCode, isMulti, name), title="Adding Channels ...")
 def VVOZVF(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVoRYC(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVctp2 = InfoBar.instance
    if VVctp2:
     VV4bcG = VVctp2.servicelist
     if VV4bcG:
      try:
       VV4bcG.addBouquet(name, services)
       allOK = True
      except:
       try:
        VV4bcG.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVMzDi.VVszJj()
   title = "Add to Bouquet"
   if allOK: FFVXKI(self.callingSELF, "Added to : %s" % name, title=title)
   else : FFRwfz(self.callingSELF, "Nothing added!", title=title)
class CCGBY3(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFPc34(VVi1ts, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFBP5J(self)
  FF0WGA(self["keyRed"]  , "Exit")
  FF0WGA(self["keyGreen"]  , "Save")
  FF0WGA(self["keyYellow"] , "Refresh")
  FF0WGA(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVDpMH  ,
   "green"   : self.VVm51D ,
   "yellow"  : self.VV9Fyk  ,
   "blue"   : self.VVZFOS   ,
   "up"   : self.VVa6GU    ,
   "down"   : self.VVf2XF   ,
   "left"   : self.VV7oMZ   ,
   "right"   : self.VVT9YS   ,
   "cancel"  : self.VVDpMH
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VV9Fyk()
  self.VV1R5g()
  FFoFoL(self)
 def VVDpMH(self) : self.close(True)
 def VVKwNT(self) : self.close(False)
 def VVZFOS(self):
  self.session.openWithCallback(self.VVegyb, boundFunction(CC1JqO))
 def VVegyb(self, closeAll):
  if closeAll:
   self.close()
 def VVa6GU(self):
  self.VVfhDZ(1)
 def VVf2XF(self):
  self.VVfhDZ(-1)
 def VV7oMZ(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VV1R5g()
 def VVT9YS(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VV1R5g()
 def VVfhDZ(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVZoaR(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVZoaR(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVZoaR(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VV5aoA(year)):
   days += 1 #29 days in a leap year February
  return days
 def VV5aoA(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VV1R5g(self):
  for obj in self.list:
   FFkgcm(obj, "#11404040")
  FFkgcm(self.list[self.index], "#11ff8000")
 def VV9Fyk(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVm51D(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CChFBB()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVKtZu)
 def VVKtZu(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFVXKI(self, "Nothing returned from the system!")
  else:
   FFVXKI(self, str(result))
class CC1JqO(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFPc34(VVIgPt, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFBP5J(self, addLabel=True)
  FF0WGA(self["keyRed"]  , "Exit")
  FF0WGA(self["keyGreen"]  , "Sync")
  FF0WGA(self["keyYellow"] , "Refresh")
  FF0WGA(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVDpMH   ,
   "green"   : self.VVVuTd  ,
   "yellow"  : self.VVH730 ,
   "blue"   : self.VVfbLi  ,
   "cancel"  : self.VVDpMH
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VV3j0x()
  self.onShow.append(self.start)
 def start(self):
  FFYs6W(self.refresh)
  FFoFoL(self)
 def refresh(self):
  self.VVOb8G()
  self.VVjPZZ(False)
 def VVDpMH(self)  : self.close(True)
 def VVfbLi(self) : self.close(False)
 def VV3j0x(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVOb8G(self):
  self.VVzU69()
  self.VVSjS3()
  self.VVMkHD()
  self.VVzS6t()
 def VVH730(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VV3j0x()
   self.VVOb8G()
   FFYs6W(self.refresh)
 def VVVuTd(self):
  if len(self["keyGreen"].getText()) > 0:
   FFQsdM(self, self.VV6AUn, "Synchronize with Internet Date/Time ?")
 def VV6AUn(self):
  self.VVOb8G()
  FFYs6W(boundFunction(self.VVjPZZ, True))
 def VVzU69(self)  : self["keyRed"].show()
 def VV6kq7(self)  : self["keyGreen"].show()
 def VV7fH1(self) : self["keyYellow"].show()
 def VV0KoL(self)  : self["keyBlue"].show()
 def VVSjS3(self)  : self["keyGreen"].hide()
 def VVMkHD(self) : self["keyYellow"].hide()
 def VVzS6t(self)  : self["keyBlue"].hide()
 def VVjPZZ(self, sync):
  localTime = FFftoO()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVNlwj(server)
   if epoch_time is not None:
    ntpTime = FFCgGR(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CChFBB()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVKtZu, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VV7fH1()
  self.VV0KoL()
  if ok:
   self.VV6kq7()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVKtZu(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVjPZZ(False)
  except:
   pass
 def VVNlwj(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FF8zDj():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCnvip(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFPc34(VVqMuZ, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFBP5J(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking ... ")
  tCons = CChFBB()
  self.onShow.append(boundFunction(tCons.ePopen, VVE8qa, self.start))
 def start(self, result, retval):
  if " 0% packet loss" in result:
   txt     = "Internet Connection = Successful."
   color  = "#22002020"
  else:
   txt   = "Cannot connect (or server is down) !"
   color  = "#22500000"
  try:
   self["myLabel"].setText("  " + txt)
   FFkgcm(self["myBody"], color)
   FFkgcm(self["myLabel"], color)
  except:
   pass
class CCwOFg(Screen):
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFXDJG()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFPc34(VVGyVT, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CChDtQ(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CChDtQ(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CChDtQ(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"] = Label()
  self.timer   = eTimer()
  self.tunerInfo  = CCFaAG()
  self.top   = 0
  self.left   = 0
  self.curPosNum  = CFG.signalPos.getValue()
  self.curSize  = CFG.signalSize.getValue()
  FFBP5J(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVa6GU          ,
   "down"  : self.VVf2XF         ,
   "left"  : self.VV7oMZ         ,
   "right"  : self.VVT9YS         ,
   "info"  : self.VVu5z5        ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "last"  : boundFunction(self.VVUmX1, -1)  ,
   "next"  : boundFunction(self.VVUmX1, 1)  ,
   "0"   : boundFunction(self.VVUmX1, 0)  ,
   "1"   : boundFunction(self.VVafRm, pos=1) ,
   "2"   : boundFunction(self.VVafRm, pos=2) ,
   "3"   : boundFunction(self.VVafRm, pos=3) ,
   "4"   : boundFunction(self.VVafRm, pos=4) ,
   "5"   : boundFunction(self.VVafRm, pos=5) ,
   "6"   : boundFunction(self.VVafRm, pos=6) ,
   "7"   : boundFunction(self.VVafRm, pos=7) ,
   "8"   : boundFunction(self.VVafRm, pos=8) ,
   "9"   : boundFunction(self.VVafRm, pos=9) ,
  }, -1)
  self.onShown.append(self.VVTwK9)
  self.onClose.append(self.onExit)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  self.sliderSNR.VV4i0M()
  self.sliderAGC.VV4i0M()
  self.sliderBER.VV4i0M(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVafRm()
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFDq4f(self)
  tp  = CCOm0d()
  self["myTPInfo"].setText(tp.VVL7Qm(refCode))
  del tp
  if not "Working" in state:
   state = "No data on transponder (Timeout reading PAT)"
   FFVyro(self, state.replace(" (", "\n("), 2000)
  self.VV1NP6()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV1NP6)
  except:
   self.timer.callback.append(self.VV1NP6)
  self.timer.start(500, False)
 def VV1NP6(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVVqrk(service)
  self["mySNRdB"].setText(self.tunerInfo.VVEHSt())
  self["mySNR"].setText(self.tunerInfo.VVoStR())
  self["myAGC"].setText(self.tunerInfo.VVRP54())
  self["myBER"].setText(self.tunerInfo.VVHBrk())
  self.sliderSNR.VVa7S8(self.tunerInfo.VV74IK())
  self.sliderAGC.VVa7S8(self.tunerInfo.VVcPpV())
  self.sliderBER.VVa7S8(self.tunerInfo.VVqO03())
  serviceName = self.tunerInfo.VVggLh()
  if not serviceName    : serviceName = "Signal"
  if len(serviceName) > 25  : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
 def VVu5z5(self):
  self.session.open(CCgisO)
 def VVa6GU(self)  : self.VVafRm(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVf2XF(self) : self.VVafRm(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VV7oMZ(self) : self.VVafRm(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVT9YS(self) : self.VVafRm(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVafRm(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVUmX1(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFDcvu(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
class CChDtQ(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VV4i0M(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFkgcm(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVfX8s +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFkgcm(self.covObj, self.covColor)
   else:
    FFkgcm(self.covObj, "#00006688")
    self.isColormode = True
  self.VVa7S8(0)
 def VVa7S8(self, val):
  val  = FFDcvu(val, self.minN, self.maxN)
  width = int(FFtnnY(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFDcvu(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CChFBB(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVVmsi = {}
  self.commandRunning = False
  self.VVdr4e  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVVmsi, dataAvailFnc=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVVmsi[name] = VVVmsi
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVdr4e:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VV8uqE, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVV5j7 , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VV8uqE, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVV5j7 , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVV5j7(name, retval)
  return True
 def VV8uqE(self, name, data):
  data = data.decode('UTF-8')
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVV5j7(self, name, retval):
  if not self.VVdr4e:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVVmsi[name]:
   self.VVVmsi[name](self.appResults[name], retval)
  del self.VVVmsi[name]
 def VVrIRL(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCWJyd(Screen):
 def __init__(self, session, title="", VV60Bm=None, VVBCwe=False, VV6szA=False, VVvVxL=False, VVRELW=False, VVfVDP=False, VVnBg6=False, VVPBLI=VVRXKB, VVBoHg=None, VVdkvA=False, VVjiUW=None, VVxKsJ="", checkNetAccess=False):
  self.skin, self.skinParam = FFPc34(VVB5d2, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFBP5J(self, addScrollLabel=True)
  if not VVxKsJ:
   VVxKsJ = "Processing ..."
  self["myLabel"].setText("   %s" % VVxKsJ)
  self.VVBCwe   = VVBCwe
  self.VV6szA   = VV6szA
  self.VVvVxL   = VVvVxL
  self.VVRELW  = VVRELW
  self.VVfVDP = VVfVDP
  self.VVnBg6 = VVnBg6
  self.VVPBLI   = VVPBLI
  self.VVBoHg = VVBoHg
  self.VVdkvA  = VVdkvA
  self.VVjiUW  = VVjiUW
  self.checkNetAccess  = checkNetAccess
  self.cmdNum    = 0
  self.container   = CChFBB()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFAA5z()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VV60Bm, str):
   self.VV60Bm = [VV60Bm]
  else:
   self.VV60Bm = VV60Bm
  if self.VVvVxL or self.VVRELW:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVuDI9, VVuDI9)
   self.VV60Bm.append("echo -e '\n%s\n' %s" % (restartNote, FFbAJE(restartNote, VVvAHa)))
   if self.VVvVxL:
    self.VV60Bm.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VV60Bm.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVfVDP:
   FFVyro(self, "Processing ...")
  self.onLayoutFinish.append(self.VV2X0S)
  self.onClose.append(self.VVbVvh)
 def VV2X0S(self):
  self["myLabel"].VV2Sqk()
  if self.VVBCwe:
   self["myLabel"].VVqPCR()
  if self.checkNetAccess : self.VVttnh()
  else     : self.VVxBFj()
 def VVttnh(self):
  self["myLabel"].setText("  Checking Internet ...")
  tCons = CChFBB()
  tCons.ePopen(VVE8qa, self.VVkoI0)
 def VVkoI0(self, result, retval):
  self["myLabel"].setText("Processing ...")
  if retval == 0 : self.VVxBFj()
  else   : self["myLabel"].setText(FFNMGt("\n   No connection to internet!", VVxYDU))
 def VVxBFj(self):
  allOK = self.container.ePopen(self.VV60Bm[0], self.VVmqQi, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVmqQi("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVnBg6 or self.VVvVxL or self.VVRELW:
    self["myLabel"].setText(FFYFPf("STARTED", VVvAHa) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVjiUW:
   colorWhite = CCgbRZ.VV9vw8(VVMR5q)
   color  = CCgbRZ.VV9vw8(self.VVjiUW[0])
   words  = self.VVjiUW[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVPBLI=self.VVPBLI)
 def VVmqQi(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VV60Bm):
   allOK = self.container.ePopen(self.VV60Bm[self.cmdNum], self.VVmqQi, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVmqQi("Cannot connect to Console!", -1)
  else:
   if self.VVfVDP and FF1qsD(self):
    FFVyro(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVnBg6:
    self["myLabel"].appendText("\n" + FFYFPf("FINISHED", VVvAHa), self.VVPBLI)
   if self.VVBCwe or self.VV6szA:
    self["myLabel"].VVqPCR()
   if self.VVBoHg is not None:
    self.VVBoHg()
   if not retval and self.VVdkvA:
    self.VVbVvh()
 def VVbVvh(self):
  if self.container.VVrIRL():
   self.container.killAll()
class CCpkX1(Screen):
 def __init__(self, session, VV60Bm=None, VVfVDP=False):
  self.skin, self.skinParam = FFPc34(VVB5d2, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VV84Zp + "ajpanel_terminal.history"
  self.customCommandsFile = VV84Zp + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFactG("pwd") or "/home/root"
  self.container   = CChFBB()
  FFBP5J(self, addScrollLabel=True)
  FF0WGA(self["keyRed"] , "Stop Command")
  FF0WGA(self["keyGreen"] , "OK = History")
  FF0WGA(self["keyYellow"], "Menu = Custom Cmds")
  FF0WGA(self["keyBlue"] , "Keypad = New Cmd")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVA3QO ,
   "red"  : self.VVpvCR   ,
   "cancel" : self.VVpcoS   ,
   "menu"  : self.VV0MOh ,
   "last"  : self.VVxTUs  ,
   "next"  : self.VVxTUs  ,
   "1"   : self.VVxTUs  ,
   "2"   : self.VVxTUs  ,
   "3"   : self.VVxTUs  ,
   "4"   : self.VVxTUs  ,
   "5"   : self.VVxTUs  ,
   "6"   : self.VVxTUs  ,
   "7"   : self.VVxTUs  ,
   "8"   : self.VVxTUs  ,
   "9"   : self.VVxTUs  ,
   "0"   : self.VVxTUs
  })
  self.onLayoutFinish.append(self.VVTwK9)
  self.onClose.append(self.VVpvCR)
 def VVTwK9(self):
  self["myLabel"].VV2Sqk(isResizable=False)
  FFkgcm(self["keyGreen"]  , self.skinParam["titleColor"])
  FFkgcm(self["keyYellow"] , self.skinParam["titleColor"])
  FFkgcm(self["keyBlue"] , self.skinParam["titleColor"])
  self.VV4FRT(FFactG("date"), 5)
  result = FFactG("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVTOd6()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVfX8s + "LinuxCommands.lst"
   newTemplate = VVfX8s + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFZNvw("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFZNvw("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVpvCR(self):
  if self.container.VVrIRL():
   self.container.killAll()
   self.VV4FRT("Process killed\n", 4)
   self.VVTOd6()
 def VVpcoS(self):
  if self.container.VVrIRL():
   FFQsdM(self, self.close, "Terminate command and exit ?")
  else:
   self.close()
 def VVTOd6(self):
  self.VV4FRT(self.prompt, 1)
  self["keyRed"].hide()
 def VV4FRT(self, txt, mode):
  if   mode == 1 : color = VVvAHa
  elif mode == 2 : color = VVvs8y
  elif mode == 3 : color = VVMR5q
  elif mode == 4 : color = VVxYDU
  elif mode == 5 : color = VVrETx
  else   : color = VVMR5q
  try:
   self["myLabel"].appendText(FFNMGt(txt, color))
  except:
   pass
 def VVaR7g(self, cmd):
  self["keyRed"].show()
  cmd = cmd.strip()
  if "#" in cmd:
   parts = cmd.split("#")
   left  = FFNMGt(parts[0].strip(), VVvs8y)
   right = FFNMGt("#" + parts[1].strip(), VVqJ8u)
   txt = "%s    %s\n" % (left, right)
  else:
   txt = "%s\n" % cmd
  self.VV4FRT(txt, 2)
  lastLine = self.VVUF13()
  if not lastLine or not cmd == lastLine:
   self.lastCommand = cmd
   self.VVjN2q(cmd)
  cdList = iFindall(r'(cd\s+[\/?\w\.+\~]+|cd\s?)', cmd)
  if cdList:
   self.curDir = cdList[-1]
  finalCmd = FFZNvw(self.curDir) + ";" + cmd
  allOK = self.container.ePopen(finalCmd, self.VVmqQi, dataAvailFnc=self.dataAvail)
  if not allOK:
   FFRwfz(self, "Cannot connect to Console!")
  self.lastCommand = cmd
 def dataAvail(self, data):
  self.VV4FRT(data, 3)
 def VVmqQi(self, data, retval):
  if not retval == 0:
   self.VV4FRT("Exit Code : %d\n" % retval, 4)
  self.VVTOd6()
 def VVA3QO(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVUF13() == "":
   self.VVjN2q("cd /tmp")
   self.VVjN2q("ls")
  VVLRbU = []
  if fileExists(self.commandHistoryFile):
   lines  = FFFfb9(self.commandHistoryFile)
   c = 0
   for line in reversed(lines):
    line = line.strip()
    if line and not line.startswith("#"):
     c += 1
     VVLRbU.append((str(c), line))
   self.VV2cST(VVLRbU, title, self.commandHistoryFile, isHistory=True)
  else:
   FFiKqP(self, self.commandHistoryFile, title=title)
 def VVUF13(self):
  lastLine = FFactG("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVjN2q(self, cmd):
  os.system("echo '%s' >> %s" % (cmd, self.commandHistoryFile))
 def VV0MOh(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFFfb9(self.customCommandsFile)
   lastLineIsSep = False
   VVLRbU = []
   c = 0
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     c += 1
     VVLRbU.append((str(c), line))
   self.VV2cST(VVLRbU, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFiKqP(self, self.customCommandsFile, title=title)
 def VV2cST(self, VVLRbU, title, filePath=None, isHistory=False):
  if VVLRbU:
   VVt3ai = "#05333333"
   if isHistory: VVgxh0 = VVd0OK = VVV3xM = "#11000020"
   else  : VVgxh0 = VVd0OK = VVV3xM = "#06002020"
   VV7bTo     = ("Send"   , self.VVhjfm  , [])
   VVbtTj    = ("Modify & Send" , self.VVjTFr  , [])
   if filePath : VVRqTs = ("Edit File"  , self.VVvOEv , [filePath])
   else  : VVRqTs = None
   VVb3Bo      = ("No."  , "Commands")
   widths      = (7   , 93   )
   VVAGqv     = (CENTER  , LEFT   )
   FFI84f(self, None, title=title, VVb3Bo=VVb3Bo, VV0sV9=VVLRbU, VVAGqv=VVAGqv, VVNZlV=widths, VVZ1jJ=22, VV7bTo=VV7bTo, VVbtTj=VVbtTj, VVRqTs=VVRqTs
     , VVgxh0   = VVgxh0
     , VVd0OK   = VVd0OK
     , VVV3xM   = VVV3xM
     , VVt3ai  = VVt3ai
    )
  else:
   FF96ug(self, filePath, title=title)
 def VVhjfm(self, VVMzDi, title, txt, colList):
  cmd = colList[1]
  VVMzDi.cancel()
  self.VVaR7g(cmd)
 def VVjTFr(self, VVMzDi, title, txt, colList):
  cmd = colList[1]
  self.VV65Ub(VVMzDi, cmd)
 def VVvOEv(self, VVMzDi, filePath):
  if fileExists(filePath):
   CCMRwk(self, filePath, VVVmsi=boundFunction(self.VVCRia))
   VVMzDi.cancel()
  else:
   FFiKqP(self, filePath)
 def VVCRia(self):
  FFYs6W(self.VV0MOh)
 def VVxTUs(self):
  self.VV65Ub(None, self.lastCommand)
 def VV65Ub(self, VVMzDi, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFX60J(self, boundFunction(self.VV7o16, VVMzDi), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VV7o16(self, VVMzDi, cmd):
  if cmd and len(cmd) > 0:
   self.VVaR7g(cmd)
   if VVMzDi:
    VVMzDi.cancel()
class CCQmWq(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVKchL="", VVn4sN=False, VV6Kv5=False, isTrimEnds=True):
  self.skin, self.skinParam = FFPc34(VV9aYx, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFBP5J(self, title, addLabel=True)
  FF0WGA(self["keyRed"] , "Up/Down = Change")
  FF0WGA(self["keyGreen"] , "Overwrite")
  FF0WGA(self["keyYellow"], "Pick Key Map")
  FF0WGA(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VV6Kv5   = VV6Kv5
  self.VVn4sN  = VVn4sN
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVKchL, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard", "WizardActions", "InputBoxActions", "InputAsciiActions", "KeyboardInputActions"],
  {
   "ok"    : self.VVsfkt      ,
   "OK"    : self.VVsfkt      ,
   "green"    : self.VVapIh    ,
   "yellow"   : self.VVdtQb      ,
   "blue"    : self.VVqydW     ,
   "menu"    : self.VVBlL6     ,
   "back"    : self.cancel       ,
   "up"    : boundFunction(self.VVdDVc, True) ,
   "down"    : boundFunction(self.VVdDVc, False) ,
   "left"    : self.VVse9i       ,
   "right"    : self.VVW6aa       ,
   "home"    : self.VVnG1V       ,
   "end"    : self.VVtASK       ,
   "deleteForward"  : self.VVw7Wt      ,
   "deleteBackward" : self.VVTBcl      ,
   "tab"    : self.VVlFy0       ,
   "toggleOverwrite" : self.VVapIh    ,
   "0"     : self.VVX3FW     ,
   "1"     : self.VVX3FW     ,
   "2"     : self.VVX3FW     ,
   "3"     : self.VVX3FW     ,
   "4"     : self.VVX3FW     ,
   "5"     : self.VVX3FW     ,
   "6"     : self.VVX3FW     ,
   "7"     : self.VVX3FW     ,
   "8"     : self.VVX3FW     ,
   "9"     : self.VVX3FW
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVPHH6()
  self.onShown.append(self.VVTwK9)
  self.onClose.append(self.onExit)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  self["myLabel"].setText(self.message)
  self.VVbXYK()
  if self.VVn4sN : self.VVapIh()
  else    : self.VVYEsK()
  FFoFoL(self)
  FFkgcm(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVfkzs)
  except:
   self.timer.callback.append(self.VVfkzs)
 def onExit(self):
  self.timer.stop()
 def VVsfkt(self):
  self.VV84oI()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VV84oI()
  self.close(None)
 def VVBlL6(self):
  VVleKL = []
  VVleKL.append(("Home"         , "home"    ))
  VVleKL.append(("End"         , "end"     ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Clear All"       , "clearAll"   ))
  VVleKL.append(("Clear To Home"      , "clearToHome"   ))
  VVleKL.append(("Clear To End"       , "clearToEnd"   ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVCerc:
   VVleKL.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("To Capital Letters"     , "toCapital"   ))
  VVleKL.append(("To Small Letters"      , "toSmall"    ))
  FF7X20(self, self.VVDdyo, title="Edit Options", VVleKL=VVleKL)
 def VVDdyo(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVnG1V()
   elif item == "end"     : self.VVtASK()
   elif item == "clearAll"    : self.VVslGZ()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVnG1V()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVCerc
    VVCerc = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVCerc)
    self.VVnG1V()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVfkzs(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVapIh(self):
  self["myInput"].toggleOverwrite()
  self.VVYEsK()
 def VVdtQb(self):
  self.session.openWithCallback(self.VVB5qB, boundFunction(CCJK5r, mode=self.charMode, VV6Kv5=self.VV6Kv5))
 def VVB5qB(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVbXYK()
 def VVYEsK(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVPHH6(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VV84oI(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVSDt9(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVse9i(self)     : self.VVPhQr(self["myInput"].left)
 def VVW6aa(self)     : self.VVPhQr(self["myInput"].right)
 def VVw7Wt(self)     : self.VVPhQr(self["myInput"].delete)
 def VVnG1V(self)     : self.VVPhQr(self["myInput"].home)
 def VVtASK(self)     : self.VVPhQr(self["myInput"].end)
 def VVTBcl(self)    : self.VVPhQr(self["myInput"].deleteBackward)
 def VVlFy0(self)     : self.VVPhQr(self["myInput"].tab)
 def VVslGZ(self)     : self["myInput"].setText("")
 def VVPhQr(self, fnc):
  fnc()
  self.VVfkzs()
 def VVX3FW(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVSDt9(newChar, overwrite)
   self.VVl4Ll(newChar, self["myInput"].mapping[number])
 def VVdDVc(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCJK5r.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCJK5r.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVSDt9(newChar, True)
   for group in groups:
    if newChar in group:
     self.VVl4Ll(newChar, group)
     break
 def VVl4Ll(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVMR5q:
    group = VVrETx + group.replace(newChar, FFNMGt(newChar, VVMR5q, VVrETx))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVqydW(self):
  if self.VV6Kv5 : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVbXYK()
 def VVbXYK(self):
  self["myInput"].mapping = CCJK5r.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCJK5r.RCU_MAP_TITLES[self.charMode])
class CCJK5r(Screen):
 VVDd5a  = 0
 VV3S81  = 1
 VVLObW  = 2
 VVqksB  = 3
 VVpZa5 = 4
 VVJmVP = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols, arabic_nums1, arabic1)
       , ( symbols, arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A" , u"\u0628")
       , (u"\u0647" , u"\u062A")
       )
 def __init__(self, session, mode=VVDd5a, VV6Kv5=False):
  self.skin, self.skinParam = FFPc34(VVqdOV, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VV6Kv5  = VV6Kv5
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFBP5J(self, title=self.Title)
  FF0WGA(self["keyRed"] ,"OK = Select")
  FF0WGA(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVnCaZ     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVg8si, -1) ,
   "next"  : boundFunction(self.VVg8si, +1) ,
   "left"  : boundFunction(self.VVg8si, -1) ,
   "right"  : boundFunction(self.VVg8si, +1) ,
  }, -1)
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  FFkgcm(self["keyRed"], "#11222222")
  FFkgcm(self["keyGreen"], "#11222222")
  self.VVwyI3()
 def VVwyI3(self):
  self.VVNEsS()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVNEsS(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVg8si(self, direction):
  if self.VV6Kv5 : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVwyI3()
 def VVnCaZ(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCJp4E(Screen):
 def __init__(self, session, title="", message="", VVPBLI=VVRXKB, VVgTpR=False, VVfzL0=None, VVV3xM=None, VVZ1jJ=30):
  self.skin, self.skinParam = FFPc34(VVB5d2, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVZ1jJ, addFramedPic=True)
  self.session   = session
  FFBP5J(self, title, addScrollLabel=True)
  self.VVPBLI   = VVPBLI
  self.VVgTpR   = VVgTpR
  self.VVfzL0  = VVfzL0
  self.VVV3xM   = VVV3xM
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  if not self.VVfzL0:
   self["myPicF"].hide()
   self["myPic"].hide()
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  self["myLabel"].VV2Sqk(VVgTpR=self.VVgTpR)
  self["myLabel"].setText(self.message, self.VVPBLI)
  if self.VVV3xM:
   FFkgcm(self["myBody"], self.VVV3xM)
   FFkgcm(self["myLabel"], self.VVV3xM)
   FFFmrv(self["myLabel"], self.VVV3xM)
  if self.VVfzL0:
   allOK = FFoqMx(self["myPic"], self.VVfzL0)
   if not allOK:
    self["myPicF"].hide()
    self["myPic"].hide()
  self["myLabel"].VVqPCR()
class CCfJq1(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFPc34(VVFR26, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFBP5J(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  path = VVfX8s + "err.png"
  if fileExists(path):
   self["errPic"].instance.setScale(1)
   self["errPic"].instance.setPixmapFromFile(path)
class CCY10s(Screen):
 def __init__(self, session, message, timerSec=1000, isTopLeft=False, fixSize=False, VVHdFP="#00aaaaaa", VVV3xM="#22002020"):
  self.skin, self.skinParam = FFPc34(VVNYjB, 700, 100, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFBP5J(self, "", addLabel=True, addCloser=True)
  self["myQFrame"] = Label()
  self["myQBody" ] = Label(message)
  self.timer   = eTimer()
  self.timerSec  = timerSec
  self.isTopLeft  = isTopLeft
  self.VVHdFP  = VVHdFP
  self.VVV3xM  = VVV3xM
  self.fixSize  = fixSize
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  FFqov2(self["myQBody" ], self.VVHdFP)
  FFkgcm(self["myQBody" ], self.VVV3xM)
  if self.isTopLeft:
   self.instance.move(ePoint(50, 50))
  if self.fixSize:
   size = self["myQBody"].instance.calculateSize()
   h = int(size.height() + size.height() * 0.2)
   w = int(size.width() + h )
   self.instance.resize(eSize(*(w, h)))
   self["myQFrame"].instance.resize(eSize(*(w, h)))
   self["myQBody"].instance.resize(eSize(*(w - 2, h - 2)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVW8jY)
  except:
   self.timer.callback.append(self.VVW8jY)
  if self.timerSec > 0:
   self.timer.start(self.timerSec, False)
 def VVW8jY(self):
  self.timer.stop()
  self.close()
 def onExit(self):
  self.timer.stop()
class CCmnvi(Screen):
 def __init__(self, session, title="", VVbMOP="Continue?", VVSW5q=True, VVyjYQ=False):
  self.skin, self.skinParam = FFPc34(VVcYed, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVbMOP = VVbMOP
  self.VVyjYQ = VVyjYQ
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVSW5q : VVleKL = [no , yes]
  else   : VVleKL = [yes, no ]
  FFBP5J(self, title, VVleKL=VVleKL, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVjeN5 ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVbMOP)
  if self.VVyjYQ:
   self["myLabel"].instance.setHAlign(0)
  self.VVWhFS()
  FFqDc3(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFzVkT(self["myMenu"])
  FF9U6b(self, self["myMenu"])
 def VVjeN5(self):
  item = FFZUdU(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVWhFS(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCrqbE(Screen):
 def __init__(self, session, title="", VVleKL=None, OKBtnFnc=None, VV3DJ3=None, VVDmrx=None, VVrIGp=None, VV4CPh=None, VVqaht=False, VVNTzo=False):
  self.skin, self.skinParam = FFPc34(VVFqLG, 1000, 850, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVleKL   = VVleKL
  self.OKBtnFnc   = OKBtnFnc
  self.VV3DJ3   = VV3DJ3
  self.VVDmrx  = VVDmrx
  self.VVrIGp  = VVrIGp
  self.VV4CPh   = VV4CPh
  self.VVqaht  = VVqaht
  self.VVNTzo  = VVNTzo
  FFBP5J(self, title, VVleKL=VVleKL)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVjeN5          ,
   "cancel" : self.cancel          ,
   "red"  : self.VV8TBD         ,
   "green"  : self.VVapNP         ,
   "yellow" : self.VVg4Dt         ,
   "blue"  : self.VVDSbR         ,
   "pageUp" : self.VVQ1Vq       ,
   "chanUp" : self.VVQ1Vq       ,
   "pageDown" : self.VVdgVd        ,
   "chanDown" : self.VVdgVd
  }, -1)
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  FFqDc3(self["myMenu"])
  FFQH05(self)
  self.VVZ2tz(self["keyRed"]  , self.VV3DJ3 )
  self.VVZ2tz(self["keyGreen"] , self.VVDmrx )
  self.VVZ2tz(self["keyYellow"] , self.VVrIGp )
  self.VVZ2tz(self["keyBlue"]  , self.VV4CPh )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFoFoL(self)
 def VVZ2tz(self, btnObj, btnFnc):
  if btnFnc:
   FF0WGA(btnObj, btnFnc[0])
 def VVjeN5(self):
  item = FFZUdU(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVqaht: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VV8TBD(self)  : self.VVPhQr(self.VV3DJ3)
 def VVapNP(self) : self.VVPhQr(self.VVDmrx)
 def VVg4Dt(self) : self.VVPhQr(self.VVrIGp)
 def VVDSbR(self) : self.VVPhQr(self.VV4CPh)
 def VVPhQr(self, btnFnc):
  if btnFnc:
   item = FFZUdU(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVNTzo:
    self.cancel()
 def VVlY1S(self, VVleKL):
  if len(VVleKL) > 0:
   newList = []
   for item in VVleKL:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVXYnS(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVQ1Vq(self):
  self["myMenu"].moveToIndex(0)
 def VVdgVd(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCPQmb(Screen):
 def __init__(self, session, title="", VVb3Bo=None, VV0sV9=None, VVAGqv=None, VVNZlV=None, VVZ1jJ=24, VVgVDs=False, VV7bTo=None, VVpzw6=None, VVGrFS=None, VVJVgU=None, VVbtTj=None, VVRqTs=None, VVoWIj=None, VVCYQA=None, VVFNcA=None, VVyBeo=-1, VVRWle=False, searchCol=0, VVgxh0=None, VVd0OK=None, VVHdFP="#00dddddd", VVV3xM="#11002233", VVe4YZ="#00ff8833", VVt3ai="#11111111", VVtlnJ="#0a555555", VV1s0P="#0affffff", VVeTWM="#11552200", VVkdZd="#0055ff55"):
  self.skin, self.skinParam = FFPc34(VVwbJJ, 1400, 800, 50, 10, 5, "#22003344", "#22002233", 24, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFBP5J(self, title)
  self.VVb3Bo     = VVb3Bo
  self.VV0sV9     = VV0sV9
  self.totalCols    = len(VV0sV9[0])
  self.VVTazf   = 0
  self.lastSortModeIsReverese = False
  self.VVgVDs   = VVgVDs
  self.VVSpmM   = 0.01
  self.VVNPhB   = 0.02
  self.VV5LPl  = 1
  self.VVNZlV = VVNZlV
  self.colWidthPixels   = []
  self.VV7bTo   = VV7bTo
  self.OKButtonObj   = None
  self.VVpzw6   = VVpzw6
  self.VVGrFS   = VVGrFS
  self.VVJVgU   = VVJVgU
  self.VVbtTj  = VVbtTj
  self.VVRqTs   = VVRqTs
  self.VVoWIj    = VVoWIj
  self.VVCYQA   = VVCYQA
  self.VVFNcA  = VVFNcA
  self.VVyBeo    = VVyBeo
  self.VVRWle   = VVRWle
  self.searchCol    = searchCol
  self.VVAGqv    = VVAGqv
  self.keyPressed    = -1
  self.VVZ1jJ    = FF2m1A(VVZ1jJ)
  self.VVLFpA    = FFp4D5(self.VVZ1jJ, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVgxh0    = VVgxh0
  self.VVd0OK      = VVd0OK
  self.VVHdFP    = FFxdwd(VVHdFP)
  self.VVV3xM    = FFxdwd(VVV3xM)
  self.VVe4YZ    = FFxdwd(VVe4YZ)
  self.VVt3ai    = FFxdwd(VVt3ai)
  self.VVtlnJ   = FFxdwd(VVtlnJ)
  self.VV1s0P    = FFxdwd(VV1s0P)
  self.VVeTWM    = FFxdwd(VVeTWM)
  self.VVkdZd   = FFxdwd(VVkdZd)
  self.VVlZY4  = False
  self.selectedItems   = 0
  self.VV1Xq5   = FFxdwd("#01fefe01")
  self.VV4x2y   = FFxdwd("#11400040")
  self.VVOD9h  = self.VV1Xq5
  self.VV4sVs  = self.VVt3ai
  if self.VVRWle:
   self["keyMenu1F"].hide()
   self["keyMenu1"].hide()
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVMRA2  ,
   "red"   : self.VVsFUM  ,
   "green"   : self.VV37bM ,
   "yellow"  : self.VVDFdi ,
   "blue"   : self.VVp3Eo  ,
   "menu"   : self.VV2j1v ,
   "info"   : self.VV6IZb  ,
   "cancel"  : self.VVmIXX  ,
   "up"   : self.VVbOVR    ,
   "down"   : self.VVAM9f  ,
   "left"   : self.VV4ima   ,
   "right"   : self.VVvp69  ,
   "pageUp"  : self.VVkRlz  ,
   "chanUp"  : self.VVkRlz  ,
   "pageDown"  : self.VVtkTi  ,
   "chanDown"  : self.VVtkTi
  }, -1)
  FFEpJJ(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  try:
   self.VVcCsY()
  except Exception as err:
   FFRwfz(self, str(err))
   self.close(None)
 def VVcCsY(self):
  FFoFoL(self)
  if self.VVgxh0:
   FFkgcm(self["myTitle"], self.VVgxh0)
  if self.VVd0OK:
   FFkgcm(self["myBody"] , self.VVd0OK)
   FFkgcm(self["myTableH"] , self.VVd0OK)
   FFkgcm(self["myTable"] , self.VVd0OK)
   FFkgcm(self["myBar"]  , self.VVd0OK)
  self.VVZ2tz(self.VVGrFS  , self["keyRed"])
  self.VVZ2tz(self.VVJVgU  , self["keyGreen"])
  self.VVZ2tz(self.VVbtTj , self["keyYellow"])
  self.VVZ2tz(self.VVRqTs  , self["keyBlue"])
  if self.VV7bTo:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VV7bTo[0])
    FFkgcm(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVLFpA)
  self["myTableH"].l.setFont(0, gFont(VVLeet, self.VVZ1jJ))
  self["myTable"].l.setItemHeight(self.VVLFpA)
  self["myTable"].l.setFont(0, gFont(VVLeet, self.VVZ1jJ))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.VVb3Bo:
   self["myTableH"].instance.resize(eSize(*(w, self.VVLFpA)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVLFpA))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVLFpA)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVLFpA
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.VVb3Bo:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVLFpA * len(self.VV0sV9) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVNZlV:
   self.VVNZlV = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVNZlV)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVAGqv:
   self.VVAGqv = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVAGqv
   self.VVAGqv = []
   for item in tmpList:
    self.VVAGqv.append(item | RT_VALIGN_CENTER)
  self.VVVBZ4("Creating %d rows ..." % len(self.VV0sV9))
  if self.VVoWIj:
   self.VVoWIj(self)
 def VVZ2tz(self, btnFnc, btn):
  if btnFnc : FF0WGA(btn, btnFnc[0])
  else  : FF0WGA(btn, "")
 def VVVBZ4(self, waitTxt):
  FF2E2r(self, self.VV4vz8, title=waitTxt)
 def VV4vz8(self):
  try:
   if self.VVb3Bo:
    self["myTableH"].setList([self.VVovrK(0, self.VVb3Bo, self.VV1s0P, self.VVeTWM, self.VV1s0P, self.VVeTWM, self.VVkdZd)])
   rows = []
   for c, row in enumerate(self.VV0sV9):
    rows.append(self.VVovrK(c, row, self.VVHdFP, self.VVV3xM, self.VVe4YZ, self.VVt3ai, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVyBeo > -1:
    self["myTable"].moveToIndex(self.VVyBeo )
   self.VVvxHk()
   if self.VVRWle:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVLFpA * len(self.VV0sV9)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVCYQA:
    self.VVPhQr(self.VVCYQA, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFRwfz(self, str(err))
    self.close()
   except:
    pass
 def VVovrK(self, keyIndex, columns, VVHdFP, VVV3xM, VVe4YZ, VVt3ai, VVkdZd):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if self.VVAGqv[ndx] & LEFT:
    entry = " " + entry
   if VVkdZd and ndx == self.VVTazf : textColor = VVkdZd
   else           : textColor = VVHdFP
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVLFpA)
           , font   = 0
           , flags   = self.VVAGqv[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVV3xM
           , color_sel  = VVe4YZ
           , backcolor_sel = VVt3ai
           , border_width = 1
           , border_color = self.VVtlnJ
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VV6IZb(self):
  rowData = self.VVDQA0()
  if rowData:
   title, txt, colList = rowData
   if self.VVpzw6:
    fnc  = self.VVpzw6[1]
    params = self.VVpzw6[2]
    fnc(self, title, txt, colList)
   else:
    FF0y0a(self, txt, title)
 def VVMRA2(self):
  if   self.VVlZY4 : self.VV06Pb(self.VVlfrz(), mode=2)
  elif self.VV7bTo  : self.VVPhQr(self.VV7bTo, None)
  else      : self.VV6IZb()
 def VVsFUM(self) : self.VVPhQr(self.VVGrFS , self["keyRed"])
 def VV37bM(self) : self.VVPhQr(self.VVJVgU , self["keyGreen"])
 def VVDFdi(self): self.VVPhQr(self.VVbtTj , self["keyYellow"])
 def VVp3Eo(self) : self.VVPhQr(self.VVRqTs , self["keyBlue"])
 def VVPhQr(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFVyro(self, buttonFnc[3])
    FFYs6W(boundFunction(self.VV7oae, buttonFnc))
   else:
    self.VV7oae(buttonFnc)
 def VV7oae(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVDQA0()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VV06Pb(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VV0sV9[ndx]
   isSelected = row[1][9] == self.VV1Xq5
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVovrK(ndx, item, self.VVHdFP, self.VVV3xM, self.VVe4YZ, self.VVt3ai, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVovrK(ndx, item, self.VV1Xq5, self.VV4x2y, self.VVOD9h, self.VV4sVs, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVvxHk()
 def VVflGu(self):
  FF2E2r(self, self.VVkNf4, title="Selecting all ...")
 def VVkNf4(self):
  self.VVQFSa(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VV1Xq5
   if not isSelected:
    item = self.VV0sV9[ndx]
    newRow = self.VVovrK(ndx, item, self.VV1Xq5, self.VV4x2y, self.VVOD9h, self.VV4sVs, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVvxHk()
  self.VVySdO()
 def VVMGxI(self):
  FF2E2r(self, self.VVZ3jr, title="Unselecting all ...")
 def VVZ3jr(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VV1Xq5:
    item = self.VV0sV9[ndx]
    newRow = self.VVovrK(ndx, item, self.VVHdFP, self.VVV3xM, self.VVe4YZ, self.VVt3ai, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVvxHk()
  self.VVySdO()
 def VVDQA0(self):
  item = self["myTable"].getCurrent()
  if item:
   rowNum = item[0] + 1
   txt  = ""
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    if self.VVNZlV[i - 1] > 1 or self.VVNZlV[i - 1] == self.VVSpmM:
     if self.VVb3Bo : txt += "%s\t: %s\n" % (self.VVb3Bo[i - 1], colTxt)
     else   : txt += "Col-%d\t: %s\n" % (i, colTxt)
    colList.append(colTxt)
   return "Row Number : %d of %d\n\n" % (rowNum, len(self.VV0sV9)), txt, colList
  else:
   return None
 def VVmIXX(self):
  if self.VVFNcA : self.VVFNcA(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VV12KJ(self):
  return self["myTitle"].getText().strip()
 def VVQt8E(self, title):
  self["myTitle"].setText("  " + title)
 def VVPLYE(self, txt):
  FFVyro(self, txt)
 def VV8K08(self, txt):
  FFVyro(self, txt, 1000)
 def VVszJj(self):
  FFVyro(self)
 def VVceP4(self):
  return len(self.VV0sV9)
 def VVujvk(self): self["keyGreen"].show()
 def VVGA7s(self): self["keyGreen"].hide()
 def VVlfrz(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVddTB(self):
  return len(self["myTable"].list)
 def VVQFSa(self, isOn):
  self.VVlZY4 = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   if self.VVRqTs: self["keyBlue"].hide()
   if self.VV7bTo and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
   if self.VVRqTs: self["keyBlue"].show()
   if self.VV7bTo and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VV7bTo[0])
   self.VVMGxI()
  FFkgcm(self["myTitle"], color)
  FFkgcm(self["myBar"]  , color)
 def VVRYFP(self):
  return self.VVlZY4
 def VVdBoY(self):
  return self.selectedItems
 def VVySdO(self):
  self.hide()
  self.show()
 def VV9XCo(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVvxHk()
 def VVESqO(self, colNum):
  if colNum < self.totalCols:
   if self.VVb3Bo : subj = self.VVb3Bo[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VV0sV9:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVew73(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVceP4()
  txt += FFYFPf("Total Unique Items", VVxYDU)
  for i in range(self.totalCols):
   if self.VVNZlV[i - 1] > 1 or self.VVNZlV[i - 1] == self.VVSpmM:
    name, tot = self.VVESqO(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FF0y0a(self, txt)
 def VVOxOZ(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVVImv(self, newList, newTitle=""):
  if newList:
   self.VV0sV9 = newList
   if self.VVgVDs and self.VVTazf == 0:
    self.VV0sV9 = sorted(self.VV0sV9, key=lambda x: int(x[self.VVTazf])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VV0sV9 = sorted(self.VV0sV9, key=lambda x: x[self.VVTazf].lower(), reverse=self.lastSortModeIsReverese)
   self.VVVBZ4("Refreshing ...")
   if newTitle:
    self.VVQt8E(newTitle)
  else:
   FFRwfz(self, "Cannot refresh list")
   self.cancel()
 def VVJiWq(self, data):
  ndx = self.VVlfrz()
  newRow = self.VVovrK(ndx, data, self.VVHdFP, self.VVV3xM, self.VVe4YZ, self.VVt3ai, None)
  if newRow:
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVySdO()
   return True
  else:
   return False
 def VV6hTi(self, colNum, textToFind, showErr=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVvxHk()
    break
  else:
   if showErr:
    FFVyro(self, "Not found", 1000)
 def VVzvPP(self, colDict, showErr=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVvxHk()
    return
  if showErr:
   FFVyro(self, "Not found", 1000)
 def VVzvPP_partial(self, colDict, showErr=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(txt, self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVvxHk()
    return
  if showErr:
   FFVyro(self, "Not found", 1000)
 def VV7rVB(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVGbxv(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VV1Xq5:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVOs8r(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VV2j1v(self):
  if not self["keyMenu2F"].getVisible():
   return
  if not self.VVRWle:
   VVleKL = []
   VVleKL.append(("Table Statistcis"             , "tableStat"  ))
   VVleKL.append(VV8ygQ)
   VVleKL.append((FFNMGt("Export Table to .html"     , VVxYDU) , "VVeLKA" ))
   VVleKL.append((FFNMGt("Export Table to .csv"     , VVxYDU) , "VVtiS7" ))
   VVleKL.append((FFNMGt("Export Table to .txt (Tab Separated)", VVxYDU) , "VVcBvW" ))
   VVleKL.append(VV8ygQ)
   for i in range(self.totalCols):
    if self.VVb3Bo : name = self.VVb3Bo[i]
    else   : name = "Col-%d" % i
    if self.VVNZlV[i] > 1 or self.VVNZlV[i] == self.VVNPhB:
     VVleKL.append(("Sort by : %s" % name, i))
   if VVleKL:
    FF7X20(self, self.VVUXc4, VVleKL=VVleKL, title=self.VV12KJ())
 def VVUXc4(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVew73()
   elif item == "VVeLKA": FF2E2r(self, self.VVeLKA, title=title)
   elif item == "VVtiS7" : FF2E2r(self, self.VVtiS7 , title=title)
   elif item == "VVcBvW" : FF2E2r(self, self.VVcBvW , title=title)
   else:
    isReversed = False
    if self.VVTazf == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVgVDs and item == 0:
     self.VV0sV9 = sorted(self.VV0sV9, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VV0sV9 = sorted(self.VV0sV9, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVTazf = item
    self.VVVBZ4("Sorting ...")
 def VVbOVR(self):
  self["myTable"].up()
  self.VVvxHk()
 def VVAM9f(self):
  self["myTable"].down()
  self.VVvxHk()
 def VV4ima(self):
  self["myTable"].pageUp()
  self.VVvxHk()
 def VVvp69(self):
  self["myTable"].pageDown()
  self.VVvxHk()
 def VVkRlz(self):
  self["myTable"].moveToIndex(0)
  self.VVvxHk()
 def VVtkTi(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVvxHk()
 def VVcBvW(self):
  expFile = self.VV3dSZ() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVqtb0()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VV0sV9:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVNZlV[ndx] > self.VV5LPl:
      col = self.VVFCmR(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VV8Uy3(expFile)
 def VVtiS7(self):
  expFile = self.VV3dSZ() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVqtb0()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VV0sV9:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVNZlV[ndx] > self.VV5LPl:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVFCmR(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VV8Uy3(expFile)
 def VVeLKA(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VV12KJ(), PLUGIN_NAME, VVB14v)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VV12KJ()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVqtb0()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVNZlV:
   colgroup += '   <colgroup>'
   for w in self.VVNZlV:
    if w > self.VV5LPl:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VV3dSZ() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VV0sV9:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVNZlV[ndx] > self.VV5LPl:
      col = self.VVFCmR(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VV8Uy3(expFile)
 def VVqtb0(self):
  newRow = []
  if self.VVb3Bo:
   for ndx, col in enumerate(self.VVb3Bo):
    if self.VVNZlV[ndx] > self.VV5LPl:
     newRow.append(col.strip())
  return newRow
 def VVFCmR(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  return FFZTkY(col)
 def VV3dSZ(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VV12KJ())
  fileName = fileName.replace("__", "_")
  path  = FFjUmV(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFGx0i()
  return expFile
 def VV8Uy3(self, expFile):
  FFVXKI(self, "File exported to:\n\n%s" % expFile, title=self.VV12KJ())
 def VVvxHk(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCHXcR(Screen):
 def __init__(self, session, Title="", VVfzL0=None):
  self.skin, self.skinParam = FFPc34(VVn0bF, 1400, 800, 50, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FFBP5J(self, Title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VVfzL0 = VVfzL0
  if len(Title) == 0 : Title = FFAA5z()
  else    : Title = "File : %s" % VVfzL0
  self["myTitle"] = Label("  %s" % Title)
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  allOK = FFoqMx(self["myLabel"], self.VVfzL0)
  if not allOK:
   FFRwfz(self, "Could not view this picture file")
   self.close()
class CCN65h(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFPc34(VVUtn1, 1400, 850, 50, 40, 40, "#11201010", "#11101010", 32, barHeight=40, topRightBtns=1)
  self.session  = session
  FFBP5J(self)
  FF0WGA(self["keyGreen"], "Save")
  self.VV0sV9 = []
  self.VV0sV9.append(getConfigListEntry("Show in Main Menu"     , CFG.showInMainMenu   ))
  self.VV0sV9.append(getConfigListEntry("Show in Extensions Menu"    , CFG.showInExtensionMenu  ))
  self.VV0sV9.append(getConfigListEntry("Show in Channel List Context Menu" , CFG.showInChannelListMenu  ))
  self.VV0sV9.append(getConfigListEntry("Input Type"       , CFG.keyboard     ))
  self.VV0sV9.append(getConfigListEntry("Signal Monitor Hotkey"    , CFG.hotkey_signal    ))
  self.VV0sV9.append(getConfigListEntry(VVuDI9 *2        ,         ))
  self.VV0sV9.append(getConfigListEntry("PIcons Path"       , CFG.PIconsPath    ))
  self.VV0sV9.append(getConfigListEntry(VVuDI9 *2        ,         ))
  self.VV0sV9.append(getConfigListEntry("Backup/Restore Path"     , CFG.backupPath    ))
  self.VV0sV9.append(getConfigListEntry("Created Package Files (IPK/DEB)"  , CFG.packageOutputPath   ))
  self.VV0sV9.append(getConfigListEntry("Downloaded Packages (from feeds)" , CFG.downloadedPackagesPath ))
  self.VV0sV9.append(getConfigListEntry("Exported Tables"      , CFG.exportedTablesPath  ))
  self.VV0sV9.append(getConfigListEntry("Exported PIcons"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, self.VV0sV9, session)
  self["setupActions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard", "OkCancelActions", "ColorActions"],
  {
   "ok"   : self.VVjeN5   ,
   "OK"   : self.VVjeN5   ,
   "green"   : self.VV618t  ,
   "menu"   : self.VVDStg ,
   "cancel"  : self.VVBlDv
  }, -1)
  self.titleText = "  Settings"
  self["myTitle"].setText(self.titleText)
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  FFqDc3(self["config"])
  FFQH05(self,  self["config"])
  FFoFoL(self)
 def VVjeN5(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.PIconsPath    : self.VV2sYR(item)
   elif item == CFG.backupPath    : self.VV2sYR(item)
   elif item == CFG.packageOutputPath  : self.VV2sYR(item)
   elif item == CFG.downloadedPackagesPath : self.VV2sYR(item)
   elif item == CFG.exportedTablesPath  : self.VV2sYR(item)
   elif item == CFG.exportedPIconsPath  : self.VV2sYR(item)
 def VV2sYR(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(boundFunction(self.VVGbM9, configObj)
         , boundFunction(CChsD2, mode=CChsD2.BROWSER_MODE_DIR_PICKER, VVqgXp=sDir))
 def VVGbM9(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVBlDv(self):
  if CFG.showInMainMenu.isChanged()   or \
   CFG.showInExtensionMenu.isChanged()  or \
   CFG.showInChannelListMenu.isChanged() or \
   CFG.keyboard.isChanged()    or \
   CFG.hotkey_signal.isChanged()   or \
   CFG.PIconsPath.isChanged()    or \
   CFG.backupPath.isChanged()    or \
   CFG.packageOutputPath.isChanged()  or \
   CFG.downloadedPackagesPath.isChanged() or \
   CFG.exportedTablesPath.isChanged()  or \
   CFG.exportedPIconsPath.isChanged():
    FFQsdM(self, self.VV618t, "Save Changes ?", callBack_No=self.cancel)
  else:
   self.cancel()
 def VV618t(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVS76L()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVDStg(self):
  VVleKL = []
  VVleKL.append(("Use Backup directory in all other paths"      , "VV7Yzq"   ))
  VVleKL.append(("Reset all to default (including File Manager bookmarks)"  , "VVw3dt"   ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Change Text Color Scheme (for Transparent Text)"    , "changeColorScheme" ))
  if fileExists(VV84Zp + VVKIac):
   VVleKL.append(VV8ygQ)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVleKL.append(('%s Checking for Update' % txt1       , txt2     ))
   VVleKL.append(("Reinstall %s" % PLUGIN_NAME        , "VVynGw"  ))
   VVleKL.append(("Update %s" % PLUGIN_NAME        , "VVqhDW"   ))
  FF7X20(self, self.VVsV8j, VVleKL=VVleKL, title="Config. Options")
 def VVsV8j(self, item=None):
  if item:
   if   item == "VV7Yzq"  : FFQsdM(self, self.VV7Yzq , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVw3dt"  : FFQsdM(self, self.VVw3dt, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCgbRZ)
   elif item == "enableChkUpdate" : self.VVVIfG(True)
   elif item == "disableChkUpdate" : self.VVVIfG(False)
   elif item == "VVynGw" : FF2E2r(self, self.VVynGw , "Checking Server ...")
   elif item == "VVqhDW"  : FF2E2r(self, self.VVqhDW  , "Checking Server ...")
 def VVVIfG(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VV7Yzq(self):
  newPath = FFjUmV(VV84Zp)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVS76L()
 @staticmethod
 def VVjcLp():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVw3dt(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("v")
  CFG.PIconsPath.setValue(VV4Xzy)
  CFG.backupPath.setValue(CCN65h.VVjcLp())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  CFG.showInMainMenu.save()
  CFG.showInExtensionMenu.save()
  CFG.showInChannelListMenu.save()
  CFG.keyboard.save()
  CFG.hotkey_signal.save()
  CFG.PIconsPath.save()
  CFG.backupPath.save()
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  CFG.browserStartPath.save()
  CFG.browserBookmarks.save()
  self.VVS76L()
  self.close()
 def VVS76L(self):
  configfile.save()
  global VV84Zp
  VV84Zp = CFG.backupPath.getValue()
  FF7wnj()
 def VVqhDW(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVdY7q(title)
  if webVer:
   FFQsdM(self, boundFunction(FF2E2r, self, boundFunction(self.VVpvMQ, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVynGw(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVdY7q(title, True)
  if webVer:
   FFQsdM(self, boundFunction(FF2E2r, self, boundFunction(self.VVpvMQ, webVer, title)), "Install and Restart ?", title=title)
 def VVpvMQ(self, webVer, title):
  url = self.VVjNtD(self, title)
  if url:
   VVdr4e = FF1cg4() == "dpkg"
   if VVdr4e == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVdr4e else "ipk")
   path, err = FFUNQn(url + fName, fName, timeout=2)
   if path:
    cmd = FFqpep(VVfS86, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFhgGU(self, cmd)
    else:
     FFxXZG(self, title=title)
   else:
    FFRwfz(self, err, title=title)
 def VVdY7q(self, title, anyVer=False):
  url = self.VVjNtD(self, title)
  if not url:
   return ""
  path, err = FFUNQn(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFRwfz(self, 'Server "version" file not found !', title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFMmfA(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFRwfz(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVB14v.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFnzIb(cmd)
   if list and curVer == list[0]:
    return webVer
  FFVXKI(self, FFNMGt("No update required.", VViUes) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVjNtD(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VV84Zp + VVKIac
  if fileExists(path):
   span = iSearch(r"(http.+)", FFMmfA(path), IGNORECASE)
   if span : url = FFjUmV(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFRwfz(SELF, err, title)
  return url
 @staticmethod
 def VVhA2o(url):
  path, err = FFUNQn(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFMmfA(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVB14v.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFnzIb(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCgbRZ(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFPc34(WINDOW_MIXED_COLORS, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVZgG6
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFBP5J(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVv7iT("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVv7iT("\c00888888", i) + sp + "GREY\n"
   txt += self.VVv7iT("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVv7iT("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVv7iT("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVv7iT("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVv7iT("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVv7iT("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVv7iT("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVv7iT("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVv7iT("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVv7iT("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVjeN5 ,
   "green"   : self.VVjeN5 ,
   "left"   : self.VV7oMZ ,
   "right"   : self.VVT9YS ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  self.VV4x7n()
 def VVjeN5(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFQsdM(self, self.VV2V4a, "Change to : %s" % txt, title=self.Title)
 def VV2V4a(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVZgG6
  VVZgG6 = self.cursorPos
  self.VVZhRZ()
  self.close()
 def VV7oMZ(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VV4x7n()
 def VVT9YS(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VV4x7n()
 def VV4x7n(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVv7iT(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VV9vw8(color):
  if VVvAHa: return "\\" + color
  else    : return ""
 @staticmethod
 def VVZhRZ():
  global VVqJ8u, VVrETx, VVK65K, VVxYDU, VVbTiz, VV688Y, VViUes, VVvAHa, COLOR_CONS_BRIGHT_YELLOW, VVvs8y, VVy7KO, VVMR5q
  VVMR5q   = CCgbRZ.VVv7iT("\c00FFFFFF", VVZgG6)
  VVrETx    = CCgbRZ.VVv7iT("\c00888888", VVZgG6)
  VVqJ8u  = CCgbRZ.VVv7iT("\c005A5A5A", VVZgG6)
  VV688Y    = CCgbRZ.VVv7iT("\c00FF0000", VVZgG6)
  VVK65K   = CCgbRZ.VVv7iT("\c00FF5000", VVZgG6)
  VVvAHa   = CCgbRZ.VVv7iT("\c00FFFF00", VVZgG6)
  COLOR_CONS_BRIGHT_YELLOW = CCgbRZ.VVv7iT("\c00FFFFAA", VVZgG6)
  VViUes   = CCgbRZ.VVv7iT("\c0000FF00", VVZgG6)
  VVbTiz    = CCgbRZ.VVv7iT("\c000066FF", VVZgG6)
  VVvs8y    = CCgbRZ.VVv7iT("\c0000FFFF", VVZgG6)
  VVy7KO   = CCgbRZ.VVv7iT("\c00FA55E7", VVZgG6)
  VVxYDU    = CCgbRZ.VVv7iT("\c00FF8F5F", VVZgG6)
CCgbRZ.VVZhRZ()
class CCNoYo(Screen):
 def __init__(self, session, path, VVdr4e):
  self.skin, self.skinParam = FFPc34(VVIgPt, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVlROK   = path
  self.VVSPg3   = ""
  self.VV4FEI   = ""
  self.VVdr4e    = VVdr4e
  self.VVTtHQ    = ""
  self.VVqU7J  = ""
  self.VV11xd    = False
  self.VVF8dh  = False
  self.postInstAcion   = 0
  self.VV3fjU  = "enigma2-plugin-extensions"
  self.VVCSBD  = "enigma2-plugin-systemplugins"
  self.VVNJL2 = "enigma2"
  self.VVAvCe  = 0
  self.VVWOVQ  = 1
  self.VVeO4r  = 2
  if pathExists(self.Path + "DEBIAN") : self.VV7OBD = "DEBIAN"
  else        : self.VV7OBD = "CONTROL"
  self.controlPath = self.Path + self.VV7OBD
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVdr4e:
   self.packageExt  = ".deb"
   self.VVV3xM  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVV3xM  = "#11001020"
  FFBP5J(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FF0WGA(self["keyRed"] , "Create")
  FF0WGA(self["keyGreen"] , "Post Install")
  FF0WGA(self["keyYellow"], "Installation Path")
  FF0WGA(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVuYS0  ,
   "green"   : self.VVd5rD ,
   "yellow"  : self.VVv3P3  ,
   "blue"   : self.VVt91S  ,
   "cancel"  : self.VVDpMH
  }, -1)
  self.onShown.append(self.VVTwK9)
 def VVTwK9(self):
  self.onShown.remove(self.VVTwK9)
  FFoFoL(self)
  if self.VVV3xM:
   FFkgcm(self["myBody"], self.VVV3xM)
   FFkgcm(self["myLabel"], self.VVV3xM)
  self.VVbFEv(True)
  self.VVJGWn(True)
 def VVJGWn(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVMl4E()
  if isFirstTime:
   if   package.startswith(self.VV3fjU) : self.VVlROK = VVIuMA + self.VVTtHQ + "/"
   elif package.startswith(self.VVCSBD) : self.VVlROK = VVAoPn + self.VVTtHQ + "/"
   else            : self.VVlROK = self.Path
  if self.VV11xd : myColor = VVxYDU
  else    : myColor = VVMR5q
  txt  = ""
  txt += "Source Path\t: %s\n" % FFNMGt(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFNMGt(self.VVlROK, VVvAHa)
  if self.VV4FEI : txt += "Package File\t: %s\n" % FFNMGt(self.VV4FEI, VVrETx)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFNMGt("Check Control File fields : %s" % errTxt, VVK65K)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFNMGt("Restart GUI", VVxYDU)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFNMGt("Reboot Device", VVxYDU)
  else      : act = "No action."
  txt += "\nPost Install\t: %s\n" % act
  if not errTxt and VVK65K in controlInfo:
   txt += "Warning\t: %s\n" % FFNMGt("Errors in control file may affect the result package.", VVK65K)
  txt += "\nControl File\t: %s\n" % FFNMGt(self.controlFile, VVrETx)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVd5rD(self):
  VVleKL = []
  VVleKL.append(("No Action"    , "noAction"  ))
  VVleKL.append(("Restart GUI"    , "VVvVxL"  ))
  VVleKL.append(("Reboot Device"   , "rebootDev"  ))
  FF7X20(self, self.VV7G8B, title="Package Installation Option (after completing installation)", VVleKL=VVleKL)
 def VV7G8B(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVvVxL"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVbFEv(False)
   self.VVJGWn()
 def VVv3P3(self):
  VVleKL = []
  VVleKL.append(("Current Path"   , "toCurrent"  ))
  VVleKL.append(("Extension Path"  , "toExtensions" ))
  VVleKL.append(("System Plugins Path" , "toSystemPlugins" ))
  VVleKL.append(("Root Path"   , "toRoot"   ))
  VVleKL.append(("Other Path"   , "toOthers"  ))
  FF7X20(self, self.VV99KU, title="Installation Path", VVleKL=VVleKL)
 def VV99KU(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVfADl(FFV3kK(self.Path, True))
   elif item == "toExtensions"  : self.VVfADl(VVIuMA)
   elif item == "toSystemPlugins" : self.VVfADl(VVAoPn)
   elif item == "toRoot"   : self.VVfADl("/")
   elif item == "toOthers"   : self.session.openWithCallback(self.VVPlcU, boundFunction(CChsD2, mode=CChsD2.BROWSER_MODE_DIR_PICKER, VVqgXp=VV84Zp))
 def VVPlcU(self, path):
  if len(path) > 0:
   self.VVfADl(path)
 def VVfADl(self, parent):
  self.VVlROK = parent + self.VVTtHQ + "/"
  mode = self.VVj7Vx()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VV7nB5(mode), self.controlFile))
  self.VVJGWn()
 def VVt91S(self):
  if fileExists(self.controlFile):
   lines = FFFfb9(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFX60J(self, self.VVTIJx, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFRwfz(self, "Version not found or incorrectly set !")
  else:
   FFiKqP(self, self.controlFile)
 def VVTIJx(self, VVKchL):
  if VVKchL:
   version, color = self.VVYnMC(VVKchL, False)
   if color == VVvs8y:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVKchL, self.controlFile))
    self.VVJGWn()
   else:
    FFRwfz(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVDpMH(self):
  if self.newControlPath:
   if self.VV11xd:
    self.VVa1BS()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFNMGt(self.newControlPath, VVrETx)
    txt += FFNMGt("Do you want to keep these files ?", VVvAHa)
    FFQsdM(self, self.close, txt, callBack_No=self.VVa1BS, title="Create Package", VVyjYQ=True)
  else:
   self.close()
 def VVa1BS(self):
  os.system(FFZNvw("rm -r '%s'" % self.newControlPath))
  self.close()
 def VV7nB5(self, mode):
  if   mode == self.VVWOVQ : prefix = self.VV3fjU
  elif mode == self.VVeO4r : prefix = self.VVCSBD
  else        : prefix = self.VVNJL2
  return prefix + "-" + self.VVqU7J
 def VVj7Vx(self):
  if   self.VVlROK.startswith(VVIuMA) : return self.VVWOVQ
  elif self.VVlROK.startswith(VVAoPn) : return self.VVeO4r
  else            : return self.VVAvCe
 def VVbFEv(self, isFirstTime):
  self.VVTtHQ   = os.path.basename(os.path.normpath(self.Path))
  self.VVTtHQ   = "_".join(self.VVTtHQ.split())
  self.VVqU7J = self.VVTtHQ.lower()
  self.VV11xd = self.VVqU7J == VV0kWH.lower()
  if self.VV11xd and self.VVqU7J.endswith("ajpan"):
   self.VVqU7J += "el"
  if self.VV11xd : self.VVSPg3 = VV84Zp
  else    : self.VVSPg3 = CFG.packageOutputPath.getValue()
  self.VVSPg3 = FFjUmV(self.VVSPg3)
  if not pathExists(self.controlPath):
   os.system(FFZNvw("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VV11xd : t = PLUGIN_NAME
  else    : t = self.VVTtHQ
  self.VVoJ1o(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVpP63.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VV11xd : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVoJ1o(self.postrmFile, txt)
  if self.VV11xd:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVB14v)
   txt += rmCmd
   txt += rmCmd.replace(myPath, myPath + "el")
   self.VVoJ1o(self.preinstFile, txt)
  else:
   self.VVoJ1o(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVTtHQ)
  mode = self.VVj7Vx()
  if isFirstTime and not mode == self.VVAvCe:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVuDI9
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVoJ1o(self.postinstFile, txt, VVn4sN=True)
  os.system(FFZNvw("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VV11xd : version, descripton, maintainer = VVB14v , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVTtHQ , self.VVTtHQ
   txt = ""
   txt += "Package: %s\n"  % self.VV7nB5(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVoJ1o(self, path, lines, VVn4sN=False):
  if not fileExists(path) or VVn4sN:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVMl4E(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFFfb9(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFNMGt(line, VVK65K)
     elif not line.startswith(" ")    : line = FFNMGt(line, VVK65K)
     else          : line = FFNMGt(line, VVvs8y)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVvs8y
   else   : color = VVK65K
   descr = FFNMGt(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVK65K
     elif line.startswith((" ", "\t")) : color = VVK65K
     elif line.startswith("#")   : color = VVrETx
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVYnMC(val, True)
      elif key == "Version"  : version, color = self.VVYnMC(val, False)
      elif key == "Maintainer" : maint  , color = val, VVvs8y
      elif key == "Architecture" : arch  , color = val, VVvs8y
      else:
       color = VVvs8y
      if not key == "OE" and not key.istitle():
       color = VVK65K
     else:
      color = VVxYDU
     txt += FFNMGt(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VV4FEI = self.VVSPg3 + packageName
   self.VVF8dh = True
   errTxt = ""
  else:
   self.VV4FEI  = ""
   self.VVF8dh = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVYnMC(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVvs8y
  else          : return val, VVK65K
 def VVuYS0(self):
  if not self.VVF8dh:
   FFRwfz(self, "Please fix Control File errors first.")
   return
  if self.VVdr4e: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFV3kK(self.VVlROK, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVTtHQ
  symlinkTo  = FFvbpu(self.Path)
  dataDir   = self.VVlROK.rstrip("/")
  removePorjDir = FFZNvw("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFZNvw("rm -f '%s'" % self.VV4FEI) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFaaKH()
  if self.VVdr4e:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFJHzY("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VV11xd:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VV7OBD)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VV4FEI, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VV4FEI
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VV4FEI, FFbAJE(result  , VViUes))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVlROK, FFbAJE(instPath, VVvs8y))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFbAJE(failed, VVK65K))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFhgGU(self, cmd)
class CChsD2(Screen):
 BROWSER_MODE_NORMAL   = 0
 BROWSER_MODE_DIR_PICKER  = 1
 MAX_BOOKMARKS = 20
 def __init__(self, session, VVqgXp="/", mode=BROWSER_MODE_NORMAL, VVMUu8="Select", VVZ1jJ=30):
  self.skin, self.skinParam = FFPc34(VVFqLG, 1400, 820, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFBP5J(self)
  FF0WGA(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVMUu8 = VVMUu8
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  if   self.mode == self.BROWSER_MODE_NORMAL  : VVeXC2, self.VVqgXp = True , CFG.browserStartPath.getValue()
  elif self.mode == self.BROWSER_MODE_DIR_PICKER : VVeXC2, self.VVqgXp = False, VVqgXp
  else           : VVeXC2, self.VVqgXp = True , VVqgXp
  VVqgXp = FFjUmV(VVqgXp)
  self["myMenu"] = CCh6I0(  directory   = "/"
         , VVeXC2   = VVeXC2
         , VVslYo = True
         , VVGda7   = self.skinParam["width"]
         , VVZ1jJ   = self.skinParam["bodyFontSize"]
         , VVLFpA  = self.skinParam["bodyLineH"]
         , VVDGDB  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVjeN5      ,
   "cancel"   : self.cancel      ,
   "green"    : self.VVO6Va    ,
   "yellow"   : self.VV4Fox   ,
   "blue"    : self.VVPXkE   ,
   "menu"    : self.VV3iNZ    ,
   "info"    : self.VV6eBO    ,
   "pageUp"   : self.VVvV9X     ,
   "chanUp"   : self.VVvV9X
  }, -1)
  FFEpJJ(self, self["myMenu"])
  self.onShown.append(self.start)
  self["myMenu"].onSelectionChanged.append(self.VV1R5g)
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VV1R5g)
  FFqDc3(self["myMenu"], bg="#06003333")
  FFoFoL(self)
  self.maxTitleWidth = self["keyMenu1"].getPosition()[0] - 40
  if self.mode == self.BROWSER_MODE_DIR_PICKER:
   FF0WGA(self["keyGreen"], self.VVMUu8)
   color = "#22000022"
   FFkgcm(self["myBody"], color)
   FFkgcm(self["myMenu"], color)
   color = "#22220000"
   FFkgcm(self["myTitle"], color)
   FFkgcm(self["myBar"], color)
  self.VV1R5g()
  if self.VV71ra(self.VVqgXp) > self.bigDirSize:
   FFVyro(self, "Changing directory...")
   FFYs6W(self.VVgwOu)
  else:
   self.VVgwOu()
 def VVgwOu(self):
  self["myMenu"].VVLAOz(self.VVqgXp)
 def VVqJlL(self):
  self["myMenu"].refresh()
  FFzH73()
 def VV71ra(self, folder):
  totalItems = 0
  if pathExists(folder):
   totalItems = len(os.listdir(folder))
  return totalItems
 def VVjeN5(self):
  if self["myMenu"].VVA7Np():
   path = self.VVMnQP(self.VVxnlb())
   if self.VV71ra(path) > self.bigDirSize:
    FFVyro(self, "Changing directory...")
    FFYs6W(self.VVsbP9)
   else:
    self.VVsbP9()
  else:
   self.VVYVkp()
 def VVsbP9(self):
  self["myMenu"].descent()
  self["myMenu"].moveToIndex(0)
  self.VV1R5g()
 def VVvV9X(self):
  if self["myMenu"].VV0tfJ():
   self["myMenu"].moveToIndex(0)
   self.VVsbP9()
 def cancel(self):
  if not FF1qsD(self):
   self.close("")
 def VVO6Va(self):
  if self.mode == self.BROWSER_MODE_DIR_PICKER:
   path = self.VVMnQP(self.VVxnlb())
   self.close(path)
 def VV6eBO(self):
  FF2E2r(self, self.VVMmvD, title="Calculating size ...")
 def VVMmvD(self):
  path = self.VVMnQP(self.VVxnlb())
  param = self.VVr22U(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = ""
   if typeChar == "d":
    result = FFactG("myDir='%s'; totDirs=$(find $myDir -type d | wc -l); totFiles=$(find $myDir ! -type d | wc -l); echo $totDirs','$totFiles" % path)
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents  = "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
    size = FFactG("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    size = int(size)
   if size >= 1024 : size = "%s  ( %s bytes )" % (self.VVBcn9(size), format(size, ',d'))
   else   : size = "%s" % self.VVBcn9(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFNMGt(pathTxt, VVxYDU) + "\n"
   if slBroken : fileTime = self.VVgRyq(path)
   else  : fileTime = self.VVVr6U(path)
   def VVxdbW(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVxdbW("Path"    , pathTxt)
   txt += VVxdbW("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVxdbW("Target"   , slTarget)
   txt += VVxdbW("Size"    , "%s" % size)
   txt += contents
   txt += "\n"
   txt += VVxdbW("Owner"    , owner)
   txt += VVxdbW("Group"    , group)
   txt += VVxdbW("Perm. (User)"  , permUser)
   txt += VVxdbW("Perm. (Group)"  , permGroup)
   txt += VVxdbW("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVxdbW("Perm. (Ext.)" , permExtra)
   txt += VVxdbW("iNode"    , iNode)
   txt += VVxdbW("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVuDI9, VVuDI9)
    txt += hLinkedFiles
  else:
   FFRwfz(self, "Cannot access information !")
  if len(txt) > 0:
   FF0y0a(self, txt)
 def VVr22U(self, path):
  path = path.strip()
  path = FFvbpu(path)
  result = FFactG("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVYr6w(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVYr6w(perm, 1, 4)
   permGroup = VVYr6w(perm, 4, 7)
   permOther = VVYr6w(perm, 7, 10)
   permExtra = VVYr6w(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFUdJQ("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVVr6U(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFCgGR(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFCgGR(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFCgGR(os.path.getctime(path))
  return txt
 def VVgRyq(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFactG("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFactG("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFactG("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVBcn9(self, size):
  power = 1024.0
  n = 0
  power_labels = {0 : 'B', 1: 'kB', 2: 'MB', 3: 'GB', 4: 'TB'}
  while size > power:
   size /= power
   n += 1
  size = "%.1f" % size
  if size.endswith(".0"):
   size = size[:-2]
  return "%s %s" % (size, power_labels[n])
 def VVMnQP(self, currentSel):
  currentDir  = self["myMenu"].VV0tfJ()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVA7Np():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVxnlb(self):
  return self["myMenu"].getSelection()[0]
 def VV1R5g(self):
  FFVyro(self)
  path = self.VVMnQP(self.VVxnlb())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VV0sV9 = self.VViOqM()
  if VV0sV9 and len(VV0sV9) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VVwpvV(path)
  if self.mode == self.BROWSER_MODE_NORMAL and len(path) > 0:
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
  else:
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
 def VVwpvV(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VV89KX(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VV3iNZ(self):
  if self.mode == self.BROWSER_MODE_NORMAL:
   path  = self.VVMnQP(self.VVxnlb())
   isDir  = os.path.isdir(path)
   VVleKL = []
   VVleKL.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVUw5A(path):
     sepShown = True
     VVleKL.append(VV8ygQ)
     VVleKL.append( (VVxYDU + "Archiving / Packaging"      , "VVvGru"  ))
    if self.VVQOpf(path):
     if not sepShown:
      VVleKL.append(VV8ygQ)
     VVleKL.append( (VVxYDU + "Read Backup information"     , "VVp6u0"  ))
     VVleKL.append( (VVxYDU + "Compress Octagon Image (to zip File)"  , "VVPBgq" ))
   elif os.path.isfile(path):
    selFile = self.VVxnlb()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip"))   : VVleKL.extend(self.VVBvaa(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVleKL.extend(self.VVsl3X(True))
    elif selFile.endswith(".m3u")              : VVleKL.extend(self.VVizSk(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FF7tIN(path):
     VVleKL.append(VV8ygQ)
     VVleKL.append((VVxYDU + "View" , "text_View" ))
     VVleKL.append((VVxYDU + "Edit" , "text_Edit" ))
    if len(txt) > 0:
     VVleKL.append(VV8ygQ)
     VVleKL.append(   (VVxYDU + txt      , "VVYVkp"  ))
   VVleKL.append(VV8ygQ)
   VVleKL.append(     ("Create SymLink"       , "VVfwbV" ))
   if not self.VVUw5A(path):
    VVleKL.append(   ("Rename"          , "VVPNzG" ))
    VVleKL.append(   ("Copy"           , "copyFileOrDir" ))
    VVleKL.append(   ("Move"           , "moveFileOrDir" ))
    VVleKL.append(   ("DELETE"          , "VVwaSG" ))
    if fileExists(path):
     VVleKL.append(VV8ygQ)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVleKL.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVleKL.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVleKL.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVleKL.append(VV8ygQ)
   VVleKL.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVleKL.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   VVleKL.append(VV8ygQ)
   VVleKL.append(    ("Set current directory as \"Startup Path\"" , "VV0M3U" ))
   FF7X20(self, self.VVJOwv, title="Options", VVleKL=VVleKL)
 def VVJOwv(self, item=None):
  if self.mode == self.BROWSER_MODE_NORMAL:
   if item is not None:
    path = self.VVMnQP(self.VVxnlb())
    selFile = self.VVxnlb()
    if   item == "properties"    : self.VV6eBO()
    elif item == "VVvGru"  : self.VVvGru(path)
    elif item == "VVp6u0"  : self.VVp6u0(path)
    elif item == "VVPBgq" : self.VVPBgq(path)
    elif item.startswith("extract_")  : self.VVIEIc(path, selFile, item)
    elif item.startswith("script_")   : self.VVBbDz(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVOILdItem_m3u(path, selFile, item)
    elif item.startswith("text_View")  : FFNAd3(self, path)
    elif item.startswith("text_Edit")  : CCMRwk(self, path)
    elif item == "chmod644"     : self.VV3tx0(path, selFile, "644")
    elif item == "chmod755"     : self.VV3tx0(path, selFile, "755")
    elif item == "chmod777"     : self.VV3tx0(path, selFile, "777")
    elif item == "VVfwbV"   : self.VVfwbV(path, selFile)
    elif item == "VVPNzG"   : self.VVPNzG(path, selFile)
    elif item == "copyFileOrDir"   : self.VVsHPv(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVsHPv(path, selFile, True)
    elif item == "VVwaSG"   : self.VVwaSG(path, selFile)
    elif item == "createNewFile"   : self.VV4vtF(path, True)
    elif item == "createNewDir"    : self.VV4vtF(path, False)
    elif item == "VV0M3U"   : self.VV0M3U(path)
    elif item == "VVYVkp"    : self.VVYVkp()
    else         : self.close()
 def VVYVkp(self):
  selFile = self.VVxnlb()
  path  = self.VVMnQP(selFile)
  if os.path.isfile(path):
   VV60Bm = []
   category = self["myMenu"].VVAZTU(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVbXLi(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FFsHQf(self, selFile, path)
   elif category == "txt"         : FFNAd3(self, path)
   elif category in ("tar", "zip")       : self.VVRwcS(path, selFile)
   elif category == "scr"         : self.VV2tRG(path, selFile)
   elif category == "m3u"         : self.VVnE5x(path, selFile)
   elif category in ("ipk", "deb")       : self.VVGdIg(path, selFile)
   elif not FF7tIN(path)        : FFNAd3(self, path)
 def VV4Fox(self):
  path = self.VVMnQP(self.VVxnlb())
  action = self.VVwpvV(path)
  if action == 1:
   self.VVgA7r(path)
   FFVyro(self, "Added", 500)
  elif action == -1:
   self.VVVSgG(path)
   FFVyro(self, "Removed", 500)
  self.VVwpvV(path)
 def VVgA7r(self, path):
  VV0sV9 = self.VViOqM()
  if not VV0sV9:
   VV0sV9 = []
  if len(VV0sV9) >= self.MAX_BOOKMARKS:
   FFRwfz(SELF, "Max bookmarks reached (max=%d)." % self.MAX_BOOKMARKS)
  elif not path in VV0sV9:
   VV0sV9 = [path] + VV0sV9
   self.VVdEi9(VV0sV9)
 def VVPXkE(self):
  VV0sV9 = self.VViOqM()
  if VV0sV9:
   newList = []
   for line in VV0sV9:
    newList.append((line, line))
   VV3DJ3  = ("Delete"  , self.VVD3U3 )
   VVrIGp = ("Move Up"   , self.VVTo87 )
   VV4CPh  = ("Move Down" , self.VVvjtM )
   self.bookmarkMenu = FF7X20(self, self.VV4Fdz, title="Bookmarks", VVleKL=newList, VV3DJ3=VV3DJ3, VVrIGp=VVrIGp, VV4CPh=VV4CPh)
 def VVD3U3(self, VVxnlbObj, path):
  if self.bookmarkMenu:
   VV0sV9 = self.VVVSgG(path)
   self.bookmarkMenu.VVlY1S(VV0sV9)
 def VVTo87(self, VVxnlbObj, path):
  if self.bookmarkMenu:
   VV0sV9 = self.bookmarkMenu.VVXYnS(True)
   if VV0sV9:
    self.VVdEi9(VV0sV9)
 def VVvjtM(self, VVxnlbObj, path):
  if self.bookmarkMenu:
   VV0sV9 = self.bookmarkMenu.VVXYnS(False)
   if VV0sV9:
    self.VVdEi9(VV0sV9)
 def VV4Fdz(self, folder=None):
  if folder:
   if not folder.endswith("/"):
    folder += "/"
   self["myMenu"].VVLAOz(folder)
   self["myMenu"].moveToIndex(0)
  self.VV1R5g()
 def VViOqM(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VV89KX(self, path):
  VV0sV9 = self.VViOqM()
  if VV0sV9 and path in VV0sV9:
   return True
  else:
   return False
 def VVMY8E(self):
  if VViOqM():
   return True
  else:
   return False
 def VVdEi9(self, VV0sV9):
  line = ",".join(VV0sV9)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVVSgG(self, path):
  VV0sV9 = self.VViOqM()
  if VV0sV9:
   while path in VV0sV9:
    VV0sV9.remove(path)
   self.VVdEi9(VV0sV9)
   return VV0sV9
 def VV0M3U(self, path):
  if not os.path.isdir(path):
   path = FFV3kK(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVbXLi(self, selFile, VVbMOP, command):
  FFQsdM(self, boundFunction(FFhgGU, self, command, VVBoHg=self.VVqJlL), "%s\n\n%s" % (VVbMOP, selFile))
 def VVBvaa(self, path, calledFromMenu):
  destPath = self.VV7qHF(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVleKL = []
  if calledFromMenu:
   VVleKL.append(VV8ygQ)
   color = VVxYDU
  else:
   color = ""
  VVleKL.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVleKL.append(VV8ygQ)
  VVleKL.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVleKL.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVleKL.append((color + "Extract Here"            , "extract_here"  ))
  if VVUMBX and path.endswith(".tar.gz"):
   VVleKL.append(VV8ygQ)
   VVleKL.append((color + 'Convert to ".ipk" Package' , "VVYLOX"  ))
   VVleKL.append((color + 'Convert to ".deb" Package' , "VVt3Tw"  ))
  return VVleKL
 def VVRwcS(self, path, selFile):
  FF7X20(self, boundFunction(self.VVIEIc, path, selFile), title="Tar File Options", VVleKL=self.VVBvaa(path, False))
 def VVIEIc(self, path, selFile, item=None):
  if item is not None:
   parent  = FFV3kK(path, False)
   destPath = self.VV7qHF(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVuDI9
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += "echo '';"
     cmd += "unzip -l '%s';" % path
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVuDI9, VVuDI9)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFfQ52(self, cmd)
   elif path.endswith(".zip"):
    self.VVwBTy(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFZNvw("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVbXLi(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVbXLi(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFV3kK(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVbXLi(selFile, "Extract Here ?"      , cmd)
   elif item == "VVYLOX" : self.VVYLOX(path)
   elif item == "VVt3Tw" : self.VVt3Tw(path)
 def VV7qHF(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVwBTy(self, item, path, parent, destPath, VVbMOP):
  FFQsdM(self, boundFunction(self.VVoyfe, item, path, parent, destPath), VVbMOP)
 def VVoyfe(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVuDI9
  cmd  = FFJHzY("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFbAJE(destPath, VViUes))
  cmd +=   sep
  cmd += "fi;"
  FFVfjo(self, cmd, VVBoHg=self.VVqJlL)
 def VVsl3X(self, addSep=False):
  VVleKL = []
  if addSep:
   VVleKL.append(VV8ygQ)
  VVleKL.append((VVxYDU + "View Script File"  , "script_View"  ))
  VVleKL.append((VVxYDU + "Execute Script File" , "script_Execute" ))
  VVleKL.append((VVxYDU + "Edit"     , "script_Edit" ))
  return VVleKL
 def VV2tRG(self, path, selFile):
  FF7X20(self, boundFunction(self.VVBbDz, path, selFile), title="Script File Options", VVleKL=self.VVsl3X())
 def VVBbDz(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFNAd3(self, path)
   elif item == "script_Execute" : self.VVbXLi(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCMRwk(self, path)
 def VVizSk(self, addSep=False):
  VVleKL = []
  if addSep:
   VVleKL.append(VV8ygQ)
  VVleKL.append((VVxYDU + "View"      , "m3u_View" ))
  VVleKL.append((VVxYDU + "Edit"      , "m3u_Edit" ))
  VVleKL.append((VVxYDU + "Convert to IPTV Bouquet" , "m3u_Convert" ))
  return VVleKL
 def VVnE5x(self, path, selFile):
  FF7X20(self, boundFunction(self.VVOILdItem_m3u, path, selFile), title="M3U File Options", VVleKL=self.VVizSk())
 def VVOILdItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_View"  : FFNAd3(self, path)
   elif item == "m3u_Edit"  : CCMRwk(self, path)
   elif item == "m3u_Convert" : CCOhHC.VVHH8c(self, path, False)
 def VV3tx0(self, path, selFile, newChmod):
  FFQsdM(self, boundFunction(self.VVf06W, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVf06W(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVL7Mj)
  result = FFactG(cmd)
  if result == "Successful" : FFVXKI(self, result)
  else      : FFRwfz(self, result)
 def VVfwbV(self, path, selFile):
  parent = FFV3kK(path, False)
  self.session.openWithCallback(self.VVKOK2, boundFunction(CChsD2, mode=CChsD2.BROWSER_MODE_DIR_PICKER, VVqgXp=parent, VVMUu8="Create Symlink here"))
 def VVKOK2(self, newPath):
  if len(newPath) > 0:
   target = self.VVMnQP(self.VVxnlb())
   target = FFvbpu(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFjUmV(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFRwfz(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFQsdM(self, boundFunction(self.VVnJH3, target, link), "Create Soft Link ?\n\n%s" % txt, VVyjYQ=True)
 def VVnJH3(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVL7Mj)
  result = FFactG(cmd)
  if result == "Successful" : FFVXKI(self, result)
  else      : FFRwfz(self, result)
 def VVPNzG(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFX60J(self, boundFunction(self.VVa40T, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVa40T(self, path, selFile, VVKchL):
  if VVKchL:
   parent = FFV3kK(path, True)
   if os.path.isdir(path):
    path = FFvbpu(path)
   newName = parent + VVKchL
   cmd = "mv '%s' '%s' %s" % (path, newName, VVL7Mj)
   if VVKchL:
    if selFile != VVKchL:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFQsdM(self, boundFunction(self.VVvipN, cmd), message, title="Rename file?")
    else:
     FFRwfz(self, "Cannot use same name!", title="Rename")
 def VVvipN(self, cmd):
  result = FFactG(cmd)
  if "Fail" in result:
   FFRwfz(self, result)
  self.VVqJlL()
 def VVsHPv(self, path, selFile, isMove):
  if isMove : VVMUu8 = "Move to here"
  else  : VVMUu8 = "Copy to here"
  parent = FFV3kK(path, False)
  self.session.openWithCallback(boundFunction(self.VVZHJy, isMove, path, selFile)
         , boundFunction(CChsD2, mode=CChsD2.BROWSER_MODE_DIR_PICKER, VVqgXp=parent, VVMUu8=VVMUu8))
 def VVZHJy(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFvbpu(path)
   newPath = FFjUmV(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFQsdM(self, boundFunction(FF4lhA, self, cmd, VVBoHg=self.VVqJlL), txt, VVyjYQ=True)
   else:
    FFRwfz(self, "Cannot %s to same directory !" % action.lower())
 def VVwaSG(self, path, fileName):
  path = FFvbpu(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFQsdM(self, boundFunction(self.VVKVLK, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVKVLK(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("rm %s '%s'" % (opt, path))
  self.VVqJlL()
 def VVUw5A(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVaEgm and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VV4vtF(self, path, isFile):
  dirName = FFjUmV(os.path.dirname(path))
  if isFile : objName, VVKchL = "File"  , self.edited_newFile
  else  : objName, VVKchL = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFX60J(self, boundFunction(self.VVK903, dirName, isFile, title), title=title, defaultText=VVKchL, message="Enter %s Name:" % objName)
 def VVK903(self, dirName, isFile, title, VVKchL):
  if VVKchL:
   if isFile : self.edited_newFile = VVKchL
   else  : self.edited_newDir  = VVKchL
   path = dirName + VVKchL
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVL7Mj)
    else  : cmd = "mkdir '%s' %s" % (path, VVL7Mj)
    result = FFactG(cmd)
    if "Fail" in result:
     FFRwfz(self, result)
    self.VVqJlL()
   else:
    FFRwfz(self, "Name already exists !\n\n%s" % path, title)
 def VVGdIg(self, path, selFile):
  VVleKL = []
  VVleKL.append(("List Package Files"          , "VV0Vf8"     ))
  VVleKL.append(("Package Information"          , "VVYZVx"     ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Install Package"           , "VV7eLT_CheckVersion" ))
  VVleKL.append(("Install Package (force reinstall)"      , "VV7eLT_ForceReinstall" ))
  VVleKL.append(("Install Package (force downgrade)"      , "VV7eLT_ForceDowngrade" ))
  VVleKL.append(("Install Package (ignore failed dependencies)"    , "VV7eLT_IgnoreDepends" ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Remove Related Package"         , "VV7Urs_ExistingPackage" ))
  VVleKL.append(("Remove Related Package (force remove)"     , "VV7Urs_ForceRemove"  ))
  VVleKL.append(("Remove Related Package (ignore failed dependencies)"  , "VV7Urs_IgnoreDepends" ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("Extract Files"           , "VVEAnc"     ))
  VVleKL.append(("Unbuild Package"           , "VV2Gge"     ))
  FF7X20(self, boundFunction(self.VV9auc, path, selFile), VVleKL=VVleKL)
 def VV9auc(self, path, selFile, item=None):
  if item is not None:
   if   item == "VV0Vf8"      : self.VV0Vf8(path, selFile)
   elif item == "VVYZVx"      : self.VVYZVx(path)
   elif item == "VV7eLT_CheckVersion"  : self.VV7eLT(path, selFile, VVQ9eZ     )
   elif item == "VV7eLT_ForceReinstall" : self.VV7eLT(path, selFile, VVfS86 )
   elif item == "VV7eLT_ForceDowngrade" : self.VV7eLT(path, selFile, VVMAst )
   elif item == "VV7eLT_IgnoreDepends" : self.VV7eLT(path, selFile, VVloSO )
   elif item == "VV7Urs_ExistingPackage" : self.VV7Urs(path, selFile, VVl3jj     )
   elif item == "VV7Urs_ForceRemove"  : self.VV7Urs(path, selFile, VVR2nU  )
   elif item == "VV7Urs_IgnoreDepends"  : self.VV7Urs(path, selFile, VVm34V )
   elif item == "VVEAnc"     : self.VVEAnc(path, selFile)
   elif item == "VV2Gge"     : self.VV2Gge(path, selFile)
   else           : self.close()
 def VV0Vf8(self, path, selFile):
  if FF6OVW("ar") : cmd = "allOK='1';"
  else    : cmd  = FFaaKH()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVuDI9, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVuDI9, VVuDI9)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFLISI(self, cmd, VVBoHg=self.VVqJlL)
 def VVEAnc(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFV3kK(path, True) + selFile[:-4]
  cmd  =  FFaaKH()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFZNvw("mkdir '%s'" % dest) + ";"
  cmd +=    FFZNvw("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFbAJE(dest, VViUes))
  cmd += "fi;"
  FFhgGU(self, cmd, VVBoHg=self.VVqJlL)
 def VV2Gge(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VV4mAc = os.path.splitext(path)[0]
  else        : VV4mAc = path + "_"
  if path.endswith(".deb")   : VV7OBD = "DEBIAN"
  else        : VV7OBD = "CONTROL"
  cmd  = FFaaKH()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VV4mAc, FFxdBe())
  cmd += "  mkdir '%s';"    % VV4mAc
  cmd += "  CONTPATH='%s/%s';"  % (VV4mAc, VV7OBD)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VV4mAc
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VV4mAc, VV4mAc)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VV4mAc
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VV4mAc, VV4mAc)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VV4mAc
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VV4mAc
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VV4mAc, FFbAJE(VV4mAc, VViUes))
  cmd += "fi;"
  FFhgGU(self, cmd, VVBoHg=self.VVqJlL)
 def VVYZVx(self, path):
  listCmd  = FFNDYc(VVjaB3, "")
  infoCmd  = FFqpep(VV8zER , "")
  filesCmd = FFqpep(VVtU5k, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFHr04(VVvAHa)
   notInst = "Package not installed."
   cmd  = FFA6oY("File Info", VVvAHa)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFA6oY("System Info", VVvAHa)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFbAJE(notInst, VVxYDU))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFA6oY("Related Files", VVvAHa)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFfQ52(self, cmd)
  else:
   FFxXZG(self)
 def VV7eLT(self, path, selFile, cmdOpt):
  cmd = FFqpep(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFQsdM(self, boundFunction(FFhgGU, self, cmd, VVBoHg=FFzH73), "Install Package ?\n\n%s" % selFile)
  else:
   FFxXZG(self)
 def VV7Urs(self, path, selFile, cmdOpt):
  listCmd  = FFNDYc(VVjaB3, "")
  infoCmd  = FFqpep(VV8zER, "")
  instRemCmd = FFqpep(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFbAJE(errTxt, VVxYDU))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFbAJE(cannotTxt, VVxYDU))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFbAJE(tryTxt, VVxYDU))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFQsdM(self, boundFunction(FFhgGU, self, cmd, VVBoHg=FFzH73), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFxXZG(self)
 def VV4EGP(self, path):
  hostName = FFactG("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVQOpf(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VV4EGP(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVvGru(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVleKL = []
  VVleKL.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVleKL.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVleKL.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVleKL.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVleKL.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVleKL.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVleKL.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVleKL.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVleKL.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVleKL.append(VV8ygQ)
  VVleKL.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVleKL.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FF7X20(self, boundFunction(self.VVfR8U, path), VVleKL=VVleKL)
 def VVfR8U(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVU9IW(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVU9IW(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVU9IW(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVU9IW(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVU9IW(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVU9IW(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVU9IW(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVU9IW(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVU9IW(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVU9IW(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVdml6(path, False)
   elif item == "convertDirToDeb"   : self.VVdml6(path, True)
   else         : self.close()
 def VVdml6(self, path, VVdr4e):
  self.session.openWithCallback(self.VVqJlL, boundFunction(CCNoYo, path=path, VVdr4e=VVdr4e))
 def VVU9IW(self, path, fileExt, preserveDirStruct):
  parent  = FFV3kK(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFJHzY("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFJHzY("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFJHzY("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVuDI9
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFZNvw("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FFbAJE(resultFile, VViUes))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FFbAJE(failed, VVK65K))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFLISI(self, cmd, VVBoHg=self.VVqJlL)
 def VVp6u0(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFNAd3(self, versionFile)
 def VVPBgq(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VV4EGP(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFRwfz(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFFfb9(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFV3kK(path, False)
  VV4mAc = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FFbAJE(errCmd, VVK65K))
  installCmd = FFqpep(VVQ9eZ , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VV4mAc, VV4mAc)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VV4mAc
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VV4mAc
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VV4mAc, VV4mAc)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFhgGU(self, cmd, VVBoHg=self.VVqJlL)
 def VVYLOX(self, path):
  FFRwfz(self, "Under Construction.")
 def VVt3Tw(self, path):
  FFRwfz(self, "Under Construction.")
class CCh6I0(MenuList):
 def __init__(self, VVslYo=False, directory="/", VVFrN2=True, VVeXC2=True, VVxZoU=True, VV9OQB=None, VVsH3Y=False, VVGXs0=False, VVuPCM=False, isTop=False, VVy57I=None, VVGda7=1000, VVZ1jJ=30, VVLFpA=30, VVDGDB="#00000000"):
  MenuList.__init__(self, list, VVslYo, eListboxPythonMultiContent)
  self.VVFrN2  = VVFrN2
  self.VVeXC2    = VVeXC2
  self.VVxZoU  = VVxZoU
  self.VV9OQB  = VV9OQB
  self.VVsH3Y   = VVsH3Y
  self.VVGXs0   = VVGXs0 or []
  self.VVuPCM   = VVuPCM or []
  self.isTop     = isTop
  self.additional_extensions = VVy57I
  self.VVGda7    = VVGda7
  self.VVZ1jJ    = VVZ1jJ
  self.VVLFpA    = VVLFpA
  self.pngBGColor    = FFxdwd(VVDGDB)
  self.EXTENSIONS    = self.VVtefB()
  self.VVk2NF   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVLeet, self.VVZ1jJ))
  self.l.setItemHeight(self.VVLFpA)
  self.png_mem   = self.VVsZKy("mem")
  self.png_usb   = self.VVsZKy("usb")
  self.png_fil   = self.VVsZKy("fil")
  self.png_dir   = self.VVsZKy("dir")
  self.png_dirup   = self.VVsZKy("dirup")
  self.png_srv   = self.VVsZKy("srv")
  self.png_slwfil   = self.VVsZKy("slwfil")
  self.png_slbfil   = self.VVsZKy("slbfil")
  self.png_slwdir   = self.VVsZKy("slwdir")
  self.VVs1Bc()
  self.VVLAOz(directory)
 def VVsZKy(self, category):
  return LoadPixmap("%s%s.png" % (VVfX8s, category), getDesktop(0))
 def VVtefB(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u"
  }
 def VVh673(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFvbpu(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFNMGt(" -> " , VVvAHa) + FFNMGt(os.readlink(path), VViUes)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVLFpA + 10, 0, self.VVGda7, self.VVLFpA, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VV2uK6: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVLFpA-4, self.VVLFpA-4, png, self.pngBGColor, self.pngBGColor, VV2uK6))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVLFpA-4, self.VVLFpA-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVAZTU(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVs1Bc(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVTwnk(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVogoE(self, file):
  if os.path.realpath(file) == file:
   return self.VVTwnk(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVTwnk(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVTwnk(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVUuCs(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVk2NF.info(l[0][0]).getEvent(l[0][0])
 def VVcdgl(self):
  return self.list
 def VVo0ji(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVLAOz(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVxZoU:
    self.current_mountpoint = self.VVogoE(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVxZoU:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVuPCM and not self.VVo0ji(path, self.VVGXs0):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVh673(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVsH3Y:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVk2NF = eServiceCenter.getInstance()
   list = VVk2NF.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVFrN2 and not self.isTop:
   if directory == self.current_mountpoint and self.VVxZoU:
    self.list.append(self.VVh673(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVuPCM and self.VVTwnk(directory) in self.VVuPCM):
    self.list.append(self.VVh673(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVFrN2:
   for x in directories:
    if not (self.VVuPCM and self.VVTwnk(x) in self.VVuPCM) and not self.VVo0ji(x, self.VVGXs0):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVh673(name = name, absolute = x, isDir = True, png = png))
  if self.VVeXC2:
   for x in files:
    if self.VVsH3Y:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFNMGt(" -> " , VVvAHa) + FFNMGt(target, VViUes)
       else:
        png = self.png_slbfil
        name += FFNMGt(" -> " , VVvAHa) + FFNMGt(target, VVK65K)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVAZTU(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVfX8s, category))
    if (self.VV9OQB is None) or iCompile(self.VV9OQB).search(path):
     self.list.append(self.VVh673(name = name, absolute = x , isDir = False, png = png))
  if self.VVxZoU and len(self.list) == 0:
   self.list.append(self.VVh673(name = FFNMGt("No USB connected", VVrETx), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VV0tfJ(self):
  return self.current_directory
 def VVA7Np(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVLAOz(self.getSelection()[0], select = self.current_directory)
 def VVZRFh(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVij2e(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVOvXT)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVOvXT)
 def refresh(self):
  self.VVLAOz(self.current_directory, self.VVZRFh())
 def VVOvXT(self, action, device):
  self.VVs1Bc()
  if self.current_directory is None:
   self.refresh()
class CCJMTV(ScrollLabel):
 def __init__(self, parentSELF, text="", VVtLAo=True):
  ScrollLabel.__init__(self, text)
  self.VVtLAo=VVtLAo
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVnGHL  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.fontFamily    = None
  self.VVZ1jJ    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close   ,
   "cancel"  : parentSELF.close   ,
   "green"   : self.VVUYkQ  ,
   "yellow"  : self.VVrJvB  ,
   "blue"   : self.VV16yJ  ,
   "up"   : self.pageUp    ,
   "down"   : self.pageDown    ,
   "left"   : self.pageUp    ,
   "right"   : self.pageDown    ,
   "pageUp"  : self.VVJvpM    ,
   "chanUp"  : self.VVJvpM    ,
   "pageDown"  : self.VVFwTx    ,
   "chanDown"  : self.VVFwTx
  }, -1)
 def VV2Sqk(self, isResizable=True, VVgTpR=False):
  FFoFoL(self.parentSELF, True)
  self.isResizable = isResizable
  if VVgTpR:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVZ1jJ  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFkgcm(self, color)
 def FFkgcmColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVnGHL - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVoYAX()
 def pageUp(self):
  if self.VVnGHL > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVnGHL > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVJvpM(self):
  self.setPos(0)
 def VVFwTx(self):
  self.setPos(self.VVnGHL-self.pageHeight)
 def VVTYcy(self):
  return self.VVnGHL <= self.pageHeight or self.curPos == self.VVnGHL - self.pageHeight
 def VVoYAX(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVnGHL, 3))
   start = int((100 - vis) * self.curPos / (self.VVnGHL - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVPBLI=VVRXKB):
  old_VVTYcy = self.VVTYcy()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VVnGHL = self.long_text.calculateSize().height()
   if self.VVtLAo and self.VVnGHL > self.pageHeight:
    self.scrollbar.show()
    self.VVoYAX()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVnGHL))
   if   VVPBLI == VVZLId: self.setPos(0)
   elif VVPBLI == VVVWeh : self.VVFwTx()
   elif old_VVTYcy    : self.VVFwTx()
 def appendText(self, text, VVPBLI=VVVWeh):
  self.setText(self.message + str(text), VVPBLI)
 def VVrJvB(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VV44mZ(size)
 def VV16yJ(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VV44mZ(size)
 def VVUYkQ(self):
  self.VV44mZ(self.VVZ1jJ)
 def VV44mZ(self, VVZ1jJ):
  self.long_text.setFont(gFont(self.fontFamily, VVZ1jJ))
  self.setText(self.message, VVPBLI=VVRXKB)
  self.VVqPCR(True)
 def VVqPCR(self, calledFromFontSizer=False):
  if not calledFromFontSizer:
   totalCR = self.message.count("\n")
   if totalCR < 20:
    txt = ""
    if not self.message.startswith("\n"): txt = "\n" + self.message
    if not self.message.endswith("\n") : txt += "\n"
    if txt and not len(txt) == len(self.message):
     self.setText(txt)
   elif totalCR < 30:
    self.setText(self.message.strip())
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVnGHL
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
