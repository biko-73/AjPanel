import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from collections    import Counter as iCounter
from base64      import b64encode, b64decode
from sys      import version_info as pyVersion
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Tools.Directories   import SCOPE_CURRENT_SKIN
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile, copymode as iCopymode
except: iMove = iCopyfile = iCopymode = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVQHC8   = "v8.8.3"
VV4y0R    = "22-03-2023"
EASY_MODE    = 0
VVMawv   = 0
TEST_FUNCTION   = 0
VVxCog  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVtttO  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVZAJU    = "/media/usb/"
VVe3iS    = "/usr/share/enigma2/picon/"
VVmldL = "/etc/enigma2/blacklist"
VVKJQA   = "/etc/enigma2/"
VV2see   = "AJPan"
VVpo4j  = "AUTO FIND"
VVcfm2  = "Custom"
VVjWqK  = None
VVLYHK    = ""
VVhYTJ = "Regular"
VV2XlK = "Fixed"
VVA8nc  = "AJP_Main"
VVF0VX = "AJP_Terminal"
VVAMRn = "AJP_System"
VVlMYE  = VVhYTJ
VVsQSL    = ""
VVlkj1   = " && echo 'Successful' || echo 'Failed!'"
VVBCi5  = "Cannot continue (No Enough Memory) !"
VVDroB  = ["#119f1313","#11005500","#11a08000","#1118188b"]
VVQOuY    = ["KeyMap_RC", "KeyMap_KeyBoard"]
VVXZlu  = "utf8"
VVXGzj    = ("-" * 100, )
SEP      = "-" * 80
VVk4gu  = False
VVXYuQ  = False
VVMjBN     = 0
VVOLrS    = 1
VVRmkR    = 2
VVWjx3   = 3
VVPmmT    = 4
VVcmhN    = 5
VVNC84 = 6
VVOcaS = 7
VVLuHh  = 8
VVC9dH   = 9
VVlRaw  = 10
VVRjYc  = 11
VVLivS = 12
VVgjmm = 13
VVd75O = 14
VVt7dk  = 15
VVauyc    = 16
VVA7xL   = 17
VVcx2a   = 18
VV3hZy    = 19
VV06lC    = 20
VVoPgW  = 21
VVwhxs    = 22
VVCv9j   = 0
VVjF3K   = 1
VViudQ   = 2
def FF3hnL():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VVlMYE
  if VVA8nc in lst and CFG.fontPathMain.getValue(): VVlMYE = VVA8nc
  else               : VVlMYE = VVhYTJ
  return lst
 else:
  return [VVhYTJ]
def FFc6B4(path, alias, scale=100, isRepl=0):
 try:
  addFont(path, alias, scale, isRepl)
  return True
 except:
  try:
   addFont(path, alias, scale, isRepl, 0)
   return True
  except:
   pass
 return False
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[("v", "Virtual Keyboard"),("s", "System Default")])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[("d", "Directory Up"),("e", "Exit")])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[("off", "Disable"),("lok", "Long-OK"),("lesc", "Long-Exit"),("lred", "Long-Red")])
CFG.subtDefaultEnc    = ConfigDirectory(default=VVXZlu)
CFG.screenshotFType    = ConfigSelection(default="jpg", choices=[("off", "Disable"),("jpg", "JPG"),("png", "PNG"),("bmp", "BMP")])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[("1", "1 (DVB Stream)"),("4097", "4097 (servicemp3)"),("5001", "5001 (GST Player)"),("5002", "5002 (Ext-3 EPlayer)"),("8192", "8192 (HDMI input)"),("8193", "8193 (eServiceUri)")])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVpo4j, visible_width=45)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.portalConnTimeout   = ConfigSelectionNumber(default=2, stepwidth=1, min=1, max=5, wraparound=False)
CFG.PIconsPath     = ConfigDirectory(default=VVe3iS, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVZAJU, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastPkgProjDir    = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindMovie    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.lastFindRepl_fnd   = ConfigText(default="")
CFG.lastFindRepl_rpl   = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
CFG.transpColorMovies   = ConfigText(default="#11404040")
CFG.transpColorChannels   = ConfigText(default="#88004040")
CFG.epgLangTitle    = ConfigText(default="")
CFG.epgLangDescr    = ConfigText(default="")
CFG.lastFtpLocalPath   = ConfigText(default="")
CFG.lastNetworkDevice   = ConfigInteger(default=0)
CFG.terminalCmdFile    = ConfigText(default="LinuxCommands.lst")
tmp = [("srt","FROM SRT FILE"),("#00FFFF","Aqua"),("#000000","Black"),("#0000FF","Blue"),("#FF00FF","Fuchsia"),("#808080","Gray"),("#008000","Green"),("#00FF00","Lime"),("#800000","Maroon"),("#000080","Navy"),("#808000","Olive"),("#800080","Purple"),("#FF0000","Red"),("#C0C0C0","Silver"),("#008080","Teal"),("#FFFFFF","White"),("#FFFF00","Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVlMYE, choices=[(x,  x) for x in FF3hnL()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[("0", "Left"),("1", "Center"),("2", "Right")])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FF3cvB():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VV4hgX  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VV2hxe = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VV4hgX  : return 0
  elif VV2hxe : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVECMO = FF3cvB()
VVdZck = VVD4un = VVOr14 = VVtchu = VV8ETX = VV4mV2 = VVmV2z = VVqVbe = VViZMT = VV7z62 = VVXAXH = VVRuOi = VVoIYV = VVdVTX = VVbRZL = VV7V3G = ""
def FFHfO1()  : FFCKyS(FFCnD1())
def FFPsWo()  : FFCKyS(FFSZ6k())
def FF8tNi(tDict): FFCKyS(iDumps(tDict, indent=4, sort_keys=True))
def FFPFox(*args): FFHA3G(True, True, *args)
def FFCKyS(*args) : FFHA3G(True , False , *args)
def FFRtD6(*args): FFHA3G(False, False, *args)
def FFHA3G(addSep=True, isArray=True, *args):
 if VVMawv:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(str(key).ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FF06fk(fnc):
 def VVgzgc(*args, **kwargs):
  t1 = iTime()
  fnc(*args, **kwargs)
  FFCKyS(">>>>>> Elapsed : %s sec\nargs = %s\nkwargs = %s" % (("%.6f" % (iTime() - t1)).rstrip("0"), args, kwargs))
 return VVgzgc
def FF35nP(*args):
 if VVMawv:
  path = "/tmp/ajp_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FFRtD6("Added to : %s" % path)
def FFRUiQ(txt, isAppend=True, ignoreErr=False):
 if VVMawv:
  tm = FF6lgD()
  err = ""
  if not ignoreErr:
   err = FFSZ6k()
  fileName = "/tmp/ajp_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFCKyS(err)
  FFCKyS("Output Log File : %s" % fileName)
def FFSZ6k():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FF6lgD()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFCnD1():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VV3Q6P = 0
def FFvtp4():
 global VV3Q6P
 VV3Q6P = iTime()
def FFc6Sj(txt=""):
 FFCKyS(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VV3Q6P)).rstrip("0"), txt))
VVLlWZ = []
def FFTaOD(win):
 global VVLlWZ
 if not win in VVLlWZ:
  VVLlWZ.append(win)
def FFqjXt(*args):
 global VVLlWZ
 for win in VVLlWZ:
  try:
   win.close()
  except:
   pass
 VVLlWZ = []
def FFLJqp(vTxt):
 if vTxt in globals(): del globals()[vTxt]
def FFJwyJ():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VV75x1 = FFJwyJ()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFND1y()    : return PluginDescriptor(fnc=FF7WJL, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FFNq7E()      : return getDescriptor(FFpJrJ , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFA48r()     : return getDescriptor(FFzwuq  , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFeyQF()  : return getDescriptor(FFhSmI, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFjIN2() : return getDescriptor(FFdVAu , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FF3iB4()  : return getDescriptor(FFpagI , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FFcMzM()  : return getDescriptor(FFDJZN  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FFkJc0() : return getDescriptor(FFetBG , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Terminal"    , descr="Terminal")
def FFsyoi()      : return getDescriptor(FFm2QT, [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFA48r() , FFNq7E() , FFND1y() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFeyQF())
  result.append(FFjIN2())
  result.append(FF3iB4())
  result.append(FFcMzM())
  result.append(FFkJc0())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFsyoi())
 return result
def FF7WJL(reason, **kwargs):
 if reason == 0:
  CCyzbt.VVxCdL()
  if "session" in kwargs:
   session = kwargs["session"]
   FFm3O0(session)
   CCwa0B(session)
def FFpJrJ(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFzwuq, PLUGIN_NAME, 45)]
 else:
  return []
def FFzwuq(session, **kwargs):
 session.open(Main_Menu)
def FFhSmI(session, **kwargs): session.open(CCVnYx)
def FFdVAu(session, **kwargs) : session.open(CCoUhv)
def FFpagI(session, **kwargs) : CCuYKB.VVa42W(session)
def FFDJZN(session, **kwargs)  : FF89A3(session, reopen=True)
def FFetBG(session, **kwargs) : session.open(CCptmR)
def FFm2QT(session, **kwargs):
 session.open(CCqIel, fncMode=CCqIel.VVajvb)
def FF8Zct():
 FFM8Mt(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [FFeyQF(), FFjIN2(), FF3iB4(), FFcMzM(), FFkJc0()])
 FFM8Mt(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFsyoi() ])
def FFM8Mt(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
def FFm3O0(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions["longOK"] = BF(FFTHIl, session, "lok")
 hk.actions["longCancel"]= BF(FFTHIl, session, "lesc")
 hk.actions["longRed"] = BF(FFTHIl, session, "lred")
 for k in (CCSwPL.VVpmty, CCSwPL.VVAkjY, CCSwPL.VVeWNL):
  hk.actions[k] = BF(CCSwPL.VVNmX2, session, k)
def FFTHIl(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CC1y6w.VVTV70:
    CC1y6w.VVTV70.close()
   if not CCuYKB.VVy0QT:
    CCuYKB.VVa42W(session)
  except:
   pass
def FF0UO9(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FFRFZg(SELF, title="", addLabel=False, addScrollLabel=False, VVtMHe=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFmlRV()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF.VVu42K = eTimer()
 try: SELF.VVVlC7 = SELF.VVu42K.timeout.connect(BF(FF8r9g, SELF))
 except: SELF.VVu42K.callback.append(BF(FF8r9g, SELF))
 SELF.onClose.append(SELF.VVu42K.stop)
 FF8r9g(SELF)
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCv4Bs(SELF)
 if VVtMHe:
  SELF["myMenu"] = MenuList(VVtMHe)
  SELF["myActionMap"] = ActionMap(VVQOuY,
  {
   "ok" : SELF.VV2Iyl ,
   "cancel": SELF.close ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(VVQOuY,
  {
   "ok" : SELF.close,
   "cancel": SELF.close,
   "red" : SELF.close
  }, -1)
def FFfyBc(SELF, tableObj, colNum=0, isMenu=False):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FFkvcg, SELF, "0"),
  "1" : BF(FFkvcg, SELF, "1"),
  "2" : BF(FFkvcg, SELF, "2"),
  "3" : BF(FFkvcg, SELF, "3"),
  "4" : BF(FFkvcg, SELF, "4"),
  "5" : BF(FFkvcg, SELF, "5"),
  "6" : BF(FFkvcg, SELF, "6"),
  "7" : BF(FFkvcg, SELF, "7"),
  "8" : BF(FFkvcg, SELF, "8"),
  "9" : BF(FFkvcg, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFumMv, SELF, tableObj, colNum, isMenu))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFkvcg(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VV7V3G:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VV7V3G + SELF.keyPressed + VVD4un)
    txt = VVD4un + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFZD7H(SELF, txt)
def FFumMv(SELF, tableObj, colNum, isMenu):
 FFZD7H(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    if isMenu: item = tableObj.list[i][colNum].strip()
    else  : item = tableObj.list[i][colNum + 1][7].strip()
    item = FF3gfV(item).encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     if isMenu: SELF.VV27hm(i)
     else  : SELF.VVTklH(i)
     break
 except:
  pass
def FFmlRV():
 return ("  %s" % VVsQSL)
def FFKdfz(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FF3gfV(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFGsVi(color):
 return parseColor(color).argb()
def FF0TXZ(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFC3pI(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFFnhz(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFP1gK(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VV7V3G)
 else:
  return ""
def FFZOMf(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, SEP, word, SEP, VV7V3G)
 else : return "echo -e '%s\n--- %s\n%s';" % (SEP, word, SEP)
def FF8oA9(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VV7V3G
def FFTLIE(color):
 if color: return "echo -e '%s' %s;" % (SEP, FFP1gK(SEP, VVXAXH))
 else : return "echo -e '%s';" % SEP
def FFHM5m(title, color):
 title = "%s\n%s\n%s\n" % (SEP, title, SEP)
 return FF8oA9(title, color)
def FFWIRJ(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FF4Dy8(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFkvVR(fncCB):
 tCons = CC2xQD()
 tCons.ePopen(":", BF(FFGAqz, fncCB))
def FFGAqz(fncCB, result, retval):
 fncCB()
def FFbA1i(SELF, fnc, title="Processing ...", clearMsg=True):
 FFZD7H(SELF, title)
 tCons = CC2xQD()
 tCons.ePopen(":", BF(FFt9NT, SELF, fnc, clearMsg))
def FFt9NT(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFZD7H(SELF)
def FFjwNC(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVBCi5
  else       : return ""
def FFYEhL(cmd):
 txt = FFjwNC(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFvL4V(cmd):
 lines = FFYEhL(cmd)
 if lines: return lines[0]
 else : return ""
def FFjqfL(SELF, cmd):
 lines = FFYEhL(cmd)
 VVsLLE = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVsLLE.append((key, val))
  elif line:
   VVsLLE.append((line, ""))
 if VVsLLE:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFDpub(SELF, None, header=header, VVcuvv=VVsLLE, VVbG6j=widths, VVGNdU=28)
 else:
  FFYQXW(SELF, cmd)
def FFqSkC(cmd):
 return os.system(FFb0lc(cmd)) == 0
def FFmiBl(cmd):
 return os.system(FFccR6(cmd)) == 0
def FFb0lc(cmd)  : return cmd.rstrip("\t; ") + " > /dev/null 2>&1;"
def FFccR6(cmd) : return cmd.rstrip("\t; ") + " 2> /dev/null;"
def FFYQXW(    SELF, cmd, **kwargs): SELF.session.open(CCiDJP, VVpHRB=cmd, VVZ1xV=True, VVSDbk=VVjF3K, **kwargs)
def FF1ZjZ(  SELF, cmd, **kwargs): SELF.session.open(CCiDJP, VVpHRB=cmd, **kwargs)
def FF1lrl(   SELF, cmd, **kwargs): SELF.session.open(CCiDJP, VVpHRB=cmd, VVUp7w=True, VV2zzG=True, VVSDbk=VVjF3K, **kwargs)
def FFk2dP(  SELF, cmd, **kwargs): SELF.session.open(CCiDJP, VVpHRB=cmd, VVUp7w=True, VV2zzG=True, VVSDbk=VViudQ, **kwargs)
def FFyrLj(  SELF, cmd, **kwargs): SELF.session.open(CCiDJP, VVpHRB=cmd, VVaFca=True , **kwargs)
def FFuyXR(  session, cmd, **kwargs):      session.open(CCiDJP, VVpHRB=cmd, VVaFca=True , **kwargs)
def FF4DJd( SELF, cmd, **kwargs): SELF.session.open(CCiDJP, VVpHRB=cmd, VVAex6=True   , **kwargs)
def FFRrmn( SELF, cmd, **kwargs): SELF.session.open(CCiDJP, VVpHRB=cmd, VVmYZV=True  , **kwargs)
def FFLsle(cmd):
 return FFqSkC("which %s" % cmd)
def FFUNHV():
 cmd = "if [ -f /etc/apt/apt.conf ]; then echo dpkg; else if [ -f /etc/opkg/opkg.conf ]; then echo opkg; else if which dpkg; then echo dpkg; else if which opkg; then echo opkg; else if which ipkg; then echo ipkg; else echo ''; fi; fi; fi; fi; fi"
 return FFvL4V(cmd)
def FFXN5L(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
VVjmk7     = 0
VVCCMr      = 1
VVOApa   = 2
VVNr2C   = 3
VVh7PL      = 4
VVabTi      = 5
VVRTWG     = 6
VV2Yh7     = 7
VVqrBj     = 8
VVkYaB = 9
VVGJh6 = 10
VV6qvM = 11
VVqwiy  = 12
VVCAlU     = 13
VVqsIZ  = 14
VVwmI5  = 15
def FFRkrW(parmNum, grepTxt):
 if   parmNum == VVjmk7  : param = ["update"   , "dpkg update"    ]
 elif parmNum == VVCCMr   : param = ["list"   , "apt list"    ]
 elif parmNum == VVOApa: param = ["list-installed" , "dpkg -l"     ]
 elif parmNum == VVNr2C: param = ["list-upgradable", "apt list --upgradable"]
 else         : param = []
 if param:
  pkg = FFUNHV()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFbfXZ(parmNum, package):
 if   parmNum == VVh7PL      : param = ["info"      , "apt show"         ]
 elif parmNum == VVabTi      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVRTWG     : param = ["search"      , "dpkg -S"          ]
 elif parmNum == VV2Yh7     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVqrBj     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVkYaB : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVGJh6 : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VV6qvM : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVqwiy  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVCAlU     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVqsIZ  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVwmI5  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFUNHV()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFfDPF():
 result = FFvL4V("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e 'GNU \"ar\" command not found!';"
  installCmd = FFbfXZ(VVqrBj, "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFb0lc("%s enigma2-plugin-extensions-opkg-tools" % installCmd)
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFb0lc("%s binutils" % installCmd)
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFP1gK(failed1, VVXAXH))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFP1gK(failed2, VVXAXH))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFP1gK(failed3, VVOr14))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFv2CR(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFbfXZ(VVqrBj , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFb0lc("%s %s" % (installCmd, toolPkgName))
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFP1gK(failed1, VVXAXH))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFP1gK(failed2, VVOr14))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFFr8o(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CC2TkW.VVmhex()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FF72md(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFFr8o(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFxhJI(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFF0Rr(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFFr8o(path, maxSize=maxSize, encLst=encLst)
  if lines: FFoB4k(SELF, lines, title=title, VVSDbk=VVjF3K, width=1600, height=1000, titleFontSize=30)
  else : FFAyN7(SELF, path, title=title)
 else:
  FFbiIe(SELF, path, title)
def FFSnt9(SELF, fName, title):
 path = VV2V68 + fName
 if fileExists(path):
  txt = FFFr8o(path)
  txt = txt.replace("#W#", VV7V3G)
  txt = txt.replace("#Y#", VVRuOi)
  txt = txt.replace("#G#", VVD4un)
  txt = txt.replace("#C#", VVoIYV)
  txt = txt.replace("#P#", VV8ETX)
  FFoB4k(SELF, txt, title=title)
 else:
  FFbiIe(SELF, path, title)
def FFplXR(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFG1q8(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFDpEI(parent)
 else    : return FF55ZU(parent)
def FFd4tO(path):
 return os.path.basename(os.path.normpath(path))
def FFCZGy(path):
 try:
  os.mkdir(path)
  return "" if pathExists(path) else "Cannot create dir !"
 except Exception as e:
  return str(e)
def FFF0Rr(path):
 try:
  if os.path.islink(path)  : return os.lstat(path).st_size
  elif os.path.isfile(path): return os.path.getsize(path)
 except:
  pass
 return -1
def FFMkON(path):
 path = FF55ZU(path)
 if   os.path.islink(path) : return "SymLink"
 elif os.path.ismount(path) : return "Mount"
 elif os.path.isfile(path) : return "File"
 elif os.path.isdir(path) : return "Directory"
 else      : return ""
def FFOcJX(path):
 size = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   try:
    if os.path.islink(fp) : size += os.lstat(fp).st_size
    elif os.path.isfile(fp) : size += os.path.getsize(fp)
   except:
    pass
 return size
def FFv951(path):
 totDir = totFile = totLink = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   if os.path.islink(fp) : totLink += 1
   elif os.path.isfile(fp) : totFile += 1
   else     : totDir += 1
 return totDir, totFile, totLink
def FFOlRe(path):
 try: os.remove(path)
 except: pass
def FF2Usq(path):
 with open(path, "rb+") as f:
  try:
   f.seek(-1, 2)
   if ord(f.read(1)) not in (10, 13):
    f.write(b"\n")
  except:
   pass
def FFjhVR(path):
 return FFqSkC("chattr -AacDdijsStu '%s'; rm -fr '%s'" % (path, path))
def FFZkSn(path):
 return FFqSkC("cp -f '%s' '%s.bak'" % (path, path))
def FFDpEI(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FF55ZU(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFUIO4():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVxCog)
 paths.append(VVxCog.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFplXR(ba)
 for p in list:
  p = ba + p + VVxCog
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VV2see, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVxCog, VV2see , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVwuoS, VV2V68 = FFUIO4()
def FFQ71e():
 def VVwB10(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VVLfqp   = VVwB10(CFG.backupPath, CC1Kd0.VVTjpf())
 VVLR34   = VVwB10(CFG.downloadedPackagesPath, t)
 VV3c2M  = VVwB10(CFG.exportedTablesPath, t)
 VVgL8Y  = VVwB10(CFG.exportedPIconsPath, t)
 VV6MWe   = VVwB10(CFG.packageOutputPath, t)
 global VVZAJU
 VVZAJU = FFDpEI(CFG.backupPath.getValue())
 if VVLfqp or VV6MWe or VVLR34 or VV3c2M or VVgL8Y or oldMovieDownloadPath:
  configfile.save()
 return VVLfqp, VV6MWe, VVLR34, VV3c2M, VVgL8Y, oldMovieDownloadPath
def FFn4Y0(path):
 path = FF55ZU(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFnwui(SELF, pathList, tarFileName, addTimeStamp=True):
 VVcuvv = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVcuvv.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVcuvv.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVcuvv.append(path)
 if not VVcuvv:
  FFOyl1(SELF, "Files not found!")
 elif not pathExists(VVZAJU):
  FFOyl1(SELF, "Path not found!\n\n%s" % VVZAJU)
 else:
  VVCWFX = FFDpEI(VVZAJU)
  tarFileName = "%s%s" % (VVCWFX, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFZR2n())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVcuvv:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % SEP
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFP1gK(tarFileName, VViZMT))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFP1gK(failed, VViZMT))
  cmd += "fi;"
  cmd +=  sep
  FF1ZjZ(SELF, cmd)
def FFk6h6(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFl0wi(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFl0wi(SELF["keyInfo"], "info")
def FFl0wi(barObj, fName):
 path = "%s%s%s" % (VV2V68, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFxdmJ(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFNSbQ(satNum)
  return satName
def FFNSbQ(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFbQ09(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFxdmJ(val)
  else  : sat = FFNSbQ(val)
 return sat
def FFH6BB(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFxdmJ(num)
 except:
  pass
 return sat
def FFpYGP(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FF7TZz(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFkLkE(info, iServiceInformation.sServiceref)
   prov = FFkLkE(info, iServiceInformation.sProvider)
   state = str(FFkLkE(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFueFC(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFp63C(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFkLkE(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFhk4f(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFWkWw(refCode):
 info = FFfl2n(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFGH0N(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FFp7Qx(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFfl2n(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVcpye = eServiceCenter.getInstance()
  if VVcpye:
   info = VVcpye.info(service)
 return info
def FFoYZf(SELF, refCode, VVMFOV=True, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if "j.php" in refCode and "&end=:" in refCode:
  refCode1, decodedUrl, origUrl, iptvRef = FFp63C(refCode)
  chName = decodedUrl[decodedUrl.index("&end=:") + 6:]
  pr = CC1RWP()
  if pr.VVGpFS(refCode1, chName, decodedUrl, iptvRef):
   if pr.VVqHVf(SELF, isFromSession):
    return
   else:
    fromPortalReplay = True
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFZZBl(SELF, serviceRef, checkParentalControl, isFromSession, fromPortalReplay)
  if VVMFOV:
   FFQc3A(SELF, isFromSession)
 try:
  VVLbeP = InfoBar.instance
  if VVLbeP:
   VVIh3I = VVLbeP.servicelist
   if VVIh3I:
    servRef = eServiceReference(refCode)
    VVIh3I.saveChannel(servRef)
 except:
  pass
def FFZZBl(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPortalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CC1RWP()
    if pr.VVGpFS(refCode, chName, decodedUrl, iptvRef):
     pr.VVqHVf(SELF, isFromSession)
def FFueFC(refCode):
 return True if iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE) else False
def FF81BD(ref):
 if "chcm=" in ref.lower(): return False
 else      : return True if iSearch(r"https?([:]|%3a)\/\/(127.0.0.\d|0.0.0.0|192.168.\d.\d|localhost).+", ref, IGNORECASE) else False
def FF9Dqr(url): return FFf4jh(url) or FFGpT0(url)
def FFf4jh(url) : return not "mode=itv" in url and any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFGpT0(url): return any(x in url for x in ("/series/", "mode=series"))
def FFp63C(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFC8zI(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFC8zI(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFP1tK(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFx4C0(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFkr9k(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFRb1j(txt):
 try:
  return FFx4C0(FFkr9k(txt)) == txt
 except:
  return False
def FF0KZb(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FFDpEI(newPath), patt))
def FFQc3A(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: CCuYKB.VVa42W(session)
 else      : FF89A3(session, reopen=True)
def FF89A3(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FF89A3, session), CC1y6w)
  except:
   try:
    FFcZkm(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFj69C(refCode):
 tp = CCMbXb()
 if tp.VVrKAA(refCode) : return True
 else        : return False
def FFbQCc(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFjaui(True)
     return True
 return False
def FFjaui(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FFAy23()
def FFAy23():
 VVLbeP = InfoBar.instance
 if VVLbeP:
  VVIh3I = VVLbeP.servicelist
  if VVIh3I:
   VVIh3I.setMode()
def FF6kZn(root, mode=0):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVcpye = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    flags = service.flags
    if mode == 0 and service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    ref, info = service.toString(), VVcpye.info(service)
    name = info.getName(service)
    if   mode == 0: lst.append((ref, name))
    elif mode == 1: lst.append((ref, name, flags))
 except:
  pass
 return lst
def FFAND4():
 VVFf41 = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVJwMZ = list(VVFf41)
 return VVJwMZ, VVFf41
def FFAIFB():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FF7pXq(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FFt4wC(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFQs05():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFZR2n():
 return FFQs05().replace(" ", "_").replace("-", "").replace(":", "")
def FFBNnO(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FF6lgD():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FF4VyK(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCoUhv.VV1JTf(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCoUhv.VVFP7U(fName)
     phpFile = tmpDir + fName + ext
     FFqSkC("mv -f '%s' '%s'" % (outFile, phpFile))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFZrII(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FFsfSO(num):
 return "s" if num > 1 else ""
def FFOaVa(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFYZmF(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FF7buB(a, b):
 return (a > b) - (a < b)
def FFGVZA(a, b):
 def VV6rm4(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VV6rm4(a)
 b = VV6rm4(b)
 return (a > b) - (a < b)
def FFgRqj(mycmp):
 class CCUGlR(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CCUGlR
def FFDeF8(SELF, message, title="", VVCBqA=None):
 SELF.session.openWithCallback(VVCBqA, CCL9Lj, title=title, message=message, VVi6aX=True)
def FFoB4k(SELF, message, title="", VVSDbk=VVjF3K, VVCBqA=None, **kwargs):
 SELF.session.openWithCallback(VVCBqA, CCL9Lj, title=title, message=message, VVSDbk=VVSDbk, **kwargs)
def FFYzpl(SELF, txt):
 SELF.session.open(CCr9QV, txt)
def FFOyl1(SELF, message, title="")  : FFcZkm(SELF.session, message, title)
def FFbiIe(SELF, path, title="") : FFcZkm(SELF.session, "File not found !\n\n%s" % path, title)
def FFAyN7(SELF, path, title="") : FFcZkm(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFvp5w(SELF, title="")  : FFcZkm(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFcZkm(session, message, title="") : session.open(BF(CCCIsI, title=title, message=message))
def FFdnKb(SELF, VVCBqA, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVCBqA, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVCBqA, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFOyl1(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFgBNQ(SELF, callBack_Yes, VVStYd, callBack_No=None, title="", VVMgjE=False, VVJ9WI=True, isFromExternal=False):
 session = SELF if isFromExternal else SELF.session
 return session.openWithCallback(BF(FFpcvH, callBack_Yes, callBack_No)
         , BF(CCJSdN, title=title, VVStYd=VVStYd, VVJ9WI=VVJ9WI, VVMgjE=VVMgjE))
def FFpcvH(callBack_Yes, callBack_No, FFgBNQed):
 if FFgBNQed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFZD7H(SELF, txt="", timeout=0, isGrn=False):
 if len(txt) > 0:
  try:
   if isGrn: FFC3pI(SELF["myInfoBody"], "#00004040")
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   SELF["myInfoBody"].setText(str(txt))
   if timeout > 0: SELF.VVu42K.start(timeout, True)
  except: pass
 else: FF8r9g(SELF)
def FFZbFo(*kargs, **kwargs):
 FFkvVR(BF(FFZD7H, *kargs, **kwargs))
def FF8r9g(SELF):
 try:
  SELF.VVu42K.stop()
  SELF["myInfoFrame"].hide()
  SELF["myInfoBody"].hide()
 except:
  pass
def FFDiFh(SELF):
 try: return SELF["myInfoBody"].visible
 except: return False
def FFDpub(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCXQTE, **kwargs))
  else   : win = SELF.session.open(BF(CCXQTE, **kwargs))
  FFTaOD(win)
  return win
 except:
  return None
def FFECK9(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CChyFO, **kwargs))
 FFTaOD(win)
 return win
def FF5f5W(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FFQlwu(txt, ref, cond, color=""):
 return (color + txt, ref) if cond else (txt,)
def FF1wB7(SELF, **kwargs):
 SELF.session.open(CCqIel, **kwargs)
def FFFlxX(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   FFMf5R(SELF[name], "#000000", 3)
  except:
   pass
def FFMf5R(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FFSPFU(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVlMYE, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFJI0m(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFSPFU(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize = winInst.size()
 FF1bLc(SELF, winSize.width(), winSize.height())
def FF1bLc(SELF, w, h):
 fSize = SELF["myInfoFrame"].instance.size()
 bSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((w - fSize.width()) // 2, (h - fSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((w - bSize.width()) // 2, (h - bSize.height()) // 2))
def FFrRKK():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FF9qRO(VVGNdU):
 screenSize  = FFrRKK()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVGNdU)
 return bodyFontSize
def FFYpsV(VVGNdU, extraSpace):
 font = gFont(VVlMYE, VVGNdU)
 VVavwW = fontRenderClass.getInstance().getLineHeight(font) or (VVGNdU * 1.25)
 return int(VVavwW + VVavwW * extraSpace)
def FFPFsH(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, vSliderW=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True, menuLabel=0, morePar={}):
 screenSize = FFrRKK()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 extraPar  = None
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 vSliderW  = int(ratioW  * vSliderW)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVlMYE, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFYpsV(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0" size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb"  %s />' % (width, titleH, titleColor, VVlMYE, titleFontSize, alignLeftCenter)
 if winType == VVwhxs:
  pass
 elif winType in (VVMjBN, VVOLrS):
  if winType == VVOLrS : menuName = "config"
  else      : menuName = "myMenu"
  menuW = bodyW - int(bodyW * menuLabel / 100.0) - marginLeft if menuLabel else bodyW
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, menuW, bodyH, bodyColor, bodyLineH)
  if menuLabel:
   param = 'backgroundColor="%s" foregroundColor="#ffffff" %s' % (bodyColor, bodyFontStr)
   x, w, gap = menuW + marginLeft * 2, bodyW - menuW - marginLeft, int(marginLeft / 2.0)
   tmp += '<widget name="myLabelFrm" position="%d,%d" size="%d,%d" zPosition="3" %s />' % (x - gap, bodyTop, w + gap * 2, bodyH, param)
   tmp += '<widget name="myLabelTit" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + 10, w, titleH, alignCenter, param)
   tmp += '<widget name="myLabelTxt" position="%d,%d" size="%d,%d" zPosition="4" noWrap="1" %s %s />' % (x, bodyTop + titleH + gap , w, bodyH - titleH - gap * 2, alignLeftCenter, param)
 elif winType == VVoPgW:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignCenter)
 elif winType == VV06lC:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VVlMYE, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="6" noWrap="1" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VVauyc:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FFDeF8L = b2Left2 + timeW + marginLeft
  FFDeF8W = b2Left3 - marginLeft - FFDeF8L
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FFDeF8L , b2Top, FFDeF8W , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVA7xL:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVPmmT:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVRmkR:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVWjx3:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVlMYE, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVlMYE, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVlRaw:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVlMYE, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVcx2a:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVlMYE, fontH, alignCenter)
 elif winType in (VVRjYc, VVLivS, VVgjmm, VVd75O, VVt7dk):
  if   winType == VVRjYc  : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  elif winType == VVLivS : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  elif winType == VVgjmm : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorMovies.getValue()
  elif winType == VVd75O : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.80, 0.20, int(width * 0.80), int(width * 0.20), CFG.transpColorChannels.getValue()
  else          : totRows, totCols, picR, lblR, w1, w2, transpBG = 4, 5, 0.65, 0.35, int(width * 0.85), int(width * 0.15), ""
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + marginTop + 2
  boxW = int((width - vSliderW - marginLeft * 2)  / totCols)
  boxH = int((height - barHeight - boxT - marginTop * 2) / totRows)
  extraPar = marginLeft, boxT, boxW, boxH
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" noWrap="1" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVRjYc:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h, fg, bg[i]  , VVlMYE, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h, fg, bg[i+3], VVlMYE, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VVlMYE, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VVlMYE, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h, fg, bg, VVlMYE, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h, fg, bg, VVlMYE, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  if morePar.get("grid", 0):
   y = boxT + boxH
   for i in range(totRows - 1):
    tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
    y += boxH
   x = boxW
   h = height - barHeight - boxT
   for i in range(totCols - 1):
    tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
    x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s"/>' % (marginLeft, boxT + marginTop, boxW, boxH, morePar.get("cursC", "#00ffff00"))
  picBgTr = 'transparent="1"' if morePar.get("picBgTr", 0) else ""
  lblTr = 'transparent="1"' if morePar.get("lblTr", 0) else ""
  lblC = morePar.get("lblC", "#00003333")
  gapX = morePar.get("gapX", 3)
  gapY = morePar.get("gapY", 3)
  midGap = morePar.get("mGap", 0)
  areaW = boxW - gapX * 2
  areaH = boxH - gapY * 2 - midGap
  picT = boxT + gapY
  picH = int(areaH * picR)
  lblH = int(areaH * lblR)
  lblT = boxT + gapY + picH + midGap
  lblFont = int(lblH * 0.65)
  transpBG = 'backgroundColor="%s"'% transpBG if transpBG else ""
  for row in range(totRows):
   left = marginLeft + gapX
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (row, col, left, picT, areaW, picH, transpBG, picBgTr)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, left, picT, areaW, picH)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="%s" noWrap="1" %s font="%s;%d" %s />' % (row, col, left, lblT, areaW, lblH, lblC, lblTr, VVlMYE, lblFont, alignCenter)
    left += boxW
   picT += boxH
   lblT += boxH
 elif winType == VV3hZy:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVcmhN:
  tmp += '<widget name="myPic" position="0,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (bodyTop, bodyW+3, bodyH+3)
 else:
  if   winType == VVOcaS : align = alignLeftCenter
  elif winType == VVNC84 : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVC9dH:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVlMYE
  if usefixedFont and winType == VVNC84:
   fLst = FF3hnL()
   if   VVF0VX in fLst and CFG.fontPathTerm.getValue(): fontName = VVF0VX
   elif VV2XlK in fLst         : fontName = VV2XlK
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVGNdU = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVlMYE, VVGNdU, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVlMYE, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" noWrap="1" %s />' % (name[i], left, btnTop, btnW, btnH, VVDroB[i], VVlMYE, barFont, alignCenter)
   left += btnW + gap
 if vSliderW:
  par = 'position="0,0" size="20,20"'
  tmp += '<widget name="mySbFrm" zPosition="13" %s />' % par
  tmp += '<widget name="mySbBak" zPosition="14" %s />' % par
  tmp += '<widget name="mySbSld" zPosition="15" %s />' % par
 if winType == VVNC84:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVDroB[i], VVlMYE, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap, "extraPar":extraPar}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFPFsH(VVMjBN, 800, 1000, 40, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VVIbWb = ""
  self.themsList  = []
  self.Title   = "%s - %s" % (PLUGIN_NAME, VVQHC8)
  VVtMHe = []
  if TEST_FUNCTION:
   VVtMHe.append(("-- MY TEST --", "myTest" ))
  VVtMHe.append(("File Manager"  , "fMan" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("IPTV"    , "iptv" ))
  VVtMHe.append(("Movies Browser" , "movie" ))
  VVtMHe.append(("Services/Channels", "chan" ))
  VVtMHe.append(("Bouquet Editor" , "bouq" ))
  VVtMHe.append(("PIcons"   , "picon" ))
  VVtMHe.append(("EPG"    , "epg"  ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Terminal"   , "term" ))
  VVtMHe.append(("SoftCam"   , "soft" ))
  VVtMHe.append(("Plugins"   , "plug" ))
  VVtMHe.append(("Backup & Restore" , "bakup" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Date/Time"  , "date" ))
  VVtMHe.append(("Network"   , "net"  ))
  for ndx, item in enumerate(VVtMHe):
   item = list(item)
   item[0] = "  %s" % item[0]
   VVtMHe[ndx] = tuple(item)
  FFRFZg(self, title=self.Title, VVtMHe=VVtMHe)
  FFKdfz(self["keyRed"] , "Exit")
  FFKdfz(self["keyGreen"] , "Settings")
  FFKdfz(self["keyYellow"], "Dev. Info.")
  FFKdfz(self["keyBlue"] , "Color/Font")
  self["myActionMap"].actions.update({
   "red" : self.close       ,
   "green" : self.VVBqoT      ,
   "yellow": self.VVmCIN      ,
   "blue" : self.VVrnJ7     ,
   "info" : BF(FFbA1i, self, self.VV0cFQ) ,
   "text" : self.VVz7B6      ,
   "menu" : self.VVUCD2    ,
   "0"  : BF(self.VVguzH, 0)   ,
   "1"  : BF(self.VVvmYM, "fMan")   ,
   "2"  : BF(self.VVvmYM, "iptv")   ,
   "3"  : BF(self.VVvmYM, "movie")   ,
   "4"  : BF(self.VVvmYM, "chan")   ,
   "5"  : BF(self.VVvmYM, "bouq")   ,
   "6"  : BF(self.VVvmYM, "picon")   ,
   "7"  : BF(self.VVvmYM, "epg")   ,
   "8"  : BF(self.VVvmYM, "term")   ,
   "9"  : BF(self.VVvmYM, "soft")   ,
   "last" : BF(self.VVvmYM, "plug")   ,
   "next" : BF(self.VVvmYM, "bakup")
  })
  self.onShown.append(self.VVnLQg)
  self.onClose.append(self.onExit)
  global VVk4gu, VVXYuQ, VVTsbd
  VVk4gu = VVXYuQ = False
  VVTsbd = True
 def VV2Iyl(self):
  self.VVvmYM(self["myMenu"].l.getCurrentSelection()[1])
 def VVvmYM(self, item):
  if item is not None:
   for ndx, param in enumerate(self["myMenu"].list):
    if len(param) > 1 and param[1] == item:
     self["myMenu"].moveToIndex(ndx)
     break
   global VVsQSL
   VVsQSL = self["myMenu"].l.getCurrentSelection()[0].strip()
   if   item == "myTest" : self.VVu5ko()
   elif item == "fMan"  : self.session.open(CCVnYx)
   elif item == "iptv"  : self.session.open(CCoUhv)
   elif item == "movie" : FFbA1i(self, BF(CCYcxX.VVtnnH, self))
   elif item == "chan"  : self.session.open(CCwuBY)
   elif item == "bouq"  : self.session.open(CCQIeq)
   elif item == "picon" : self.VVtpFp()
   elif item == "epg"  : self.session.open(CCfTje)
   elif item == "term"  : self.session.open(CCptmR)
   elif item == "soft"  : self.session.open(CCAfrz)
   elif item == "plug"  : self.session.open(CCmJHl)
   elif item == "bakup" : self.session.open(CCYdfM)
   elif item == "date"  : self.session.open(CCCoKO)
   elif item == "net"  : self.session.open(CCVzEh)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFWIRJ(self["myMenu"])
  FFJI0m(self)
  FFFlxX(self)
  FFk6h6(self)
  VVLfqp, VV6MWe, VVLR34, VV3c2M, VVgL8Y, oldMovieDownloadPath = FFQ71e()
  if VVLfqp or VV6MWe or VVLR34 or VV3c2M or VVgL8Y or oldMovieDownloadPath:
   VVYgG4 = lambda path, subj: "%s:\n%s\n\n" % (subj, FF8oA9(path, VVtchu)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVYgG4(VVLfqp   , "Backup/Restore Path"    )
   txt += VVYgG4(VV6MWe  , "Created Package Files (IPK/DEB)" )
   txt += VVYgG4(VVLR34  , "Download Packages (from feeds)" )
   txt += VVYgG4(VV3c2M , "Exported Tables"     )
   txt += VVYgG4(VVgL8Y , "Exported PIcons"     )
   txt += VVYgG4(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFoB4k(self, txt, title="Settings Paths")
  self.VVOLR2()
  if (EASY_MODE or VVMawv or TEST_FUNCTION):
   FFC3pI(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFZD7H(self, "Welcome", 300)
  FFkvVR(self.VVlgIb)
 def VVlgIb(self):
  if CFG.checkForUpdateAtStartup.getValue():
   curVer, webVer, url, isHigher, err = CC1Kd0.VVhCzz()
   if webVer and isHigher:
    self["myTitle"].setText("  %s (v%s available)" % (self.Title, webVer))
 def onExit(self):
  FFqSkC("rm -f /tmp/ajp_*")
  global VVk4gu, VVXYuQ
  VVk4gu = VVXYuQ = False
  FFLJqp("VVTsbd")
 def VVguzH(self, digit):
  self.VVIbWb += str(digit)
  ln = len(self.VVIbWb)
  global VVk4gu
  if ln == 4:
   if self.VVIbWb == "0" * ln:
    VVk4gu = True
    FFC3pI(self["myTitle"], "#11805040")
   else:
    self.VVIbWb = "x"
 def VVz7B6(self):
  self.VVIbWb += "t"
  if self.VVIbWb == "0" * 4 + "t" * 2:
   global VVXYuQ
   VVXYuQ = True
   FFC3pI(self["myTitle"], "#dd5588")
 def VVtpFp(self):
  found = False
  pPath = CCuqLp.VVchM7()
  if pathExists(pPath):
   for fName, fType in CCuqLp.VV7eH6(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCuqLp)
  else:
   VVtMHe = []
   VVtMHe.append(("PIcons Tools" , "CCuqLp" ))
   VVtMHe.append(VVXGzj)
   VVtMHe.append(CCuqLp.VVcoCN())
   VVtMHe.append(VVXGzj)
   VVtMHe += CCuqLp.VVNRum()
   FFECK9(self, self.VVV1bm, VVtMHe=VVtMHe)
 def VVV1bm(self, item=None):
  if item:
   if   item == "CCuqLp"   : self.session.open(CCuqLp)
   elif item == "VVthyt"  : CCuqLp.VVthyt(self)
   elif item == "VVsFYR"  : CCuqLp.VVsFYR(self)
   elif item == "findPiconBrokenSymLinks" : CCuqLp.VVjAqm(self, True)
   elif item == "FindAllBrokenSymLinks" : CCuqLp.VVjAqm(self, False)
 def VV0cFQ(self):
  changeLogFile = VV2V68 + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FF72md(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FF8oA9("\n%s\n%s\n%s" % (SEP, line, SEP), VVXAXH, VV7V3G)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FF8oA9(line, VVD4un, VV7V3G)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFoB4k(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVQHC8, PLUGIN_DESCRIPTION), VVGNdU=28, width=1600, height=1000, VVSJJk="#11000011")
 def VVUCD2(self):
  VVtMHe = []
  VVtMHe.append(("%s Requirements" % PLUGIN_NAME, "libr"))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Keys Help"     , "hlp" ))
  FFECK9(self, self.VVmPGR, VVtMHe=VVtMHe, width=650, title="Options")
 def VVmPGR(self, item=None):
  if item:
   if   item == "libr" : FFbA1i(self, BF(self.VVmFTv))
   elif item == "hlp" : FFSnt9(self, "_help_main", "Main Page (Keys Help)")
 def VVBqoT(self) : self.session.open(CC1Kd0)
 def VVmCIN(self) : self.session.open(CCqRTV)
 def VVrnJ7(self):
  title = "Colors and Fonts"
  c1, c2, c3, c4 = VV7z62, VVtchu, VVRuOi, VV4mV2
  VVtMHe = []
  VVtMHe.append((c1 + "Change Title Colors"   , "title"  ))
  VVtMHe.append((c1 + "Change Menu Area Colors"  , "body"  ))
  VVtMHe.append((c1 + "Change Menu Pointer Colors" , "cursor"  ))
  VVtMHe.append((c1 + "Change Bottom Bar Colors" , "bar"   ))
  VVtMHe.append((c2 + "Reset Colors"    , "resetColor" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((c3 + "Change %s Font" % PLUGIN_NAME, "mainFont" ))
  VVtMHe.append((c3 + "Change Termianl Font"   , "termFont" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((c4 + "Change System Font"    , "sysFont"  ))
  FFECK9(self, BF(self.VV25ni, title), VVtMHe=VVtMHe, width=600, title=title)
 def VV25ni(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VV1cJh()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVSQfn, tDict, item), CCmyVJ, defFG=fg, defBG=bg)
   elif item == "resetColor" : FFgBNQ(self, self.VV6II9, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVqbt4(VVA8nc  )
   elif item == "termFont"  : self.VVqbt4(VVF0VX)
   elif item == "sysFont"  : self.VVqbt4(VVAMRn  )
 def VVmFTv(self):
  title = "%s requirements (for some features)" % PLUGIN_NAME
  VVsLLE, pkgs = self.VVuEf0()
  VV1kWx = ("Install", BF(self.VVfS9x, title, pkgs)  , [])
  VVRHhw  = ("Update Sys. Packages", self.VVoJhw , [])
  header  = ("Library", "State", "Usage" )
  widths  = (20   , 25  , 55  )
  VV0CnX = (LEFT  , CENTER , LEFT  )
  VVdesl = FFDpub(self, None, title=title, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=28, width=1350, VV1kWx=VV1kWx, VVRHhw=VVRHhw, VVlrsP="#00ffffaa", VVcmLr=1)
 def VVfS9x(self, Title, pkgs, VVdesl, title, txt, colList):
  if "Not" in colList[1]:
   cbFnc = BF(self.VVTzDO, VVdesl)
   item = colList[0]
   if   item == "requests" : CCvqvw.VV6Zw5(self, cbFnc=cbFnc)
   elif item == "Imaging" : CCSwPL.VVBSOI(self, Title, False, cbFnc=cbFnc)
   elif item == "ar"  : FFyrLj(self, FFfDPF(), VV4qLc=cbFnc)
   elif item in pkgs  : FFyrLj(self, FFv2CR(item, item, item.capitalize()), VV4qLc=cbFnc)
  else:
   FFZD7H(VVdesl, "Already installed.", 700, isGrn=True)
 def VVoJhw(self, VVdesl, title, txt, colList):
  CCmJHl.VV7iwP(self)
 def VVTzDO(self, VVdesl):
  VVsLLE, pkgs = self.VVuEf0()
  VVdesl.VVIDuW(VVsLLE[VVdesl.VVvapY()])
 def VVuEf0(self):
  tDict = {}
  path = VV2V68 + "_sup_lib"
  if fileExists(path):
   for line in FF72md(path):
    lib, eq, txt = line.partition("=")
    tDict[lib] = txt
  def VVYgG4(lib, ok):
   txt = tDict.get(lib, "")
   if ok: return (lib, FF8oA9("Installed", VViZMT), txt)
   else : return (lib, FF8oA9("Not installed", VVOr14), txt)
  pkgs = ("xz", "zip", "unrar", "bzip2", "ffmpeg")
  VVsLLE = []
  VVsLLE.append(VVYgG4("requests", CCvqvw.VV6Zw5(self, install=False)))
  VVsLLE.append(VVYgG4("Imaging" , CCSwPL.VVBSOI(self, "", False, install=False)))
  VVsLLE.append(VVYgG4("ar"   , FFqSkC("if [[ \"$(ar -V 2> /dev/null | grep 'GNU ar')\" ]]; then exit 0; else exit 1; fi")))
  for item in pkgs: VVsLLE.append(VVYgG4(item, FFLsle(item)))
  VVsLLE.sort(key=lambda x: x[0].lower())
  return VVsLLE, pkgs
 def VVzZ30(self):
  return VVZAJU + "ajpanel_colors"
 def VV1cJh(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVzZ30()
  if fileExists(p):
   txt = FFFr8o(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVSQfn(self, tDict, item, fg, bg):
  if fg:
   self.VV47M6(item, fg)
   self.VVXxX3(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVuODp(tDict)
 def VVuODp(self, tDict):
   p = self.VVzZ30()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VV47M6(self, item, fg):
  if   item == "title" : FF0TXZ(self["myTitle"], fg)
  elif item == "body"  :
   FF0TXZ(self["myMenu"], fg)
   FF0TXZ(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   for item in ("myBar", "keyRed", "keyGreen", "keyYellow", "keyBlue"): FF0TXZ(self[item], fg)
 def VVXxX3(self, item, bg):
  if   item == "title" : FFC3pI(self["myTitle"], bg)
  elif item == "body"  :
   FFC3pI(self["myMenu"], bg)
   FFC3pI(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFC3pI(self["myBar"], bg)
 def VV6II9(self):
  FFqSkC("rm '%s'" % self.VVzZ30())
  self.close()
 def VVOLR2(self):
  tDict = self.VV1cJh()
  for item in ("title", "body", "cursor", "bar"):
   self.VVQqv6(tDict, item)
 def VVQqv6(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VV47M6(name, fg)
  if bg: self.VVXxX3(name, bg)
 def VVqbt4(self, which):
  if   which == VVA8nc  : rest, defFnt, title = False, CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif which == VVF0VX : rest, defFnt, title = False, CFG.fontPathTerm.getValue(), "Terminal "
  elif which == VVAMRn  : rest, defFnt, title = True , CFG.fontPathSys.getValue() , "System"
  CCJdTe.VV8jpx(self, "Change %s Font" % title, defFnt, rest, BF(self.VVBEfo, which))
 def VVBEfo(self, which, path=None):
  if path:
   path = "" if path == "DEFAULT" else path
   if   which == VVA8nc  : FF0UO9(CFG.fontPathMain, path)
   elif which == VVF0VX: FF0UO9(CFG.fontPathTerm, path)
   elif which == VVAMRn  : FF0UO9(CFG.fontPathSys , path)
   err = Main_Menu.VVPl3Y(which)
   if err          : FFOyl1(self, err, title=title)
   elif which == VVA8nc   : self.close()
   elif which == VVF0VX  : FFZD7H(self, "Terminal font applied", 1500, isGrn=True)
   elif which == VVAMRn and path: FFZD7H(self, "System font applied", 1500, isGrn=True)
   elif which == VVAMRn   : FFgBNQ(self, BF(Main_Menu.VVAex6, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VVAex6(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVPl3Y(name):
  if   name == VVA8nc : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VVF0VX: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VVAMRn : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FF3hnL()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VVAMRn:
   nameLst = []
   for nm in FF3hnL():
    if not nm in (VVA8nc, VVF0VX):
     nameLst.append(nm)
  else:
   nameLst = [name]
  totDone = 0
  for fntName in nameLst:
   if FFc6B4(path, fntName, isRepl=repl):
    totDone += 1
  if totDone > 0: FF3hnL()
  else    : return "Could not add font"
 def VVu5ko(self):
  self.session.open(CCQIeq)
class CCVzEh(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFPFsH(VVMjBN, 800, 950, 40, 50, 30, "#22300030", "#0a202020", 33)
  self.session  = session
  self.netEntryFile = "%s%s" % (VVZAJU, "ajpanel_network")
  c1, c2 = VVRuOi, VV7z62
  VVtMHe = []
  VVtMHe.append((c1 + "Network Devices"     , "dev" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Network Scanner (ping)"    , "ping"))
  VVtMHe.append(("Port Scanner (scan for famous ports)" , "port"))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((c2 + "Check Internet Connection"  , "intr"))
  FFRFZg(self, title="Network Tools", VVtMHe=VVtMHe)
  FFRFZg(self, VVtMHe=VVtMHe)
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFWIRJ(self["myMenu"])
  FFJI0m(self)
 def VV2Iyl(self):
  global VVsQSL
  VVsQSL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if   item == "dev" : FFbA1i(self, self.VVlyiC, title="Reading Devices ...")
  elif item == "ping" : FFbA1i(self, self.VVDckO, title="Scanning ...")
  elif item == "port" : CCFewM.VV223H(self, self.VVqzVe, title="Select host to scan")
  elif item == "intr" : self.session.open(CCXjzw)
 def VVlyiC(self, canCencel=False):
  title = "Network Devices"
  VVsLLE = self.VVZnnN()
  if VVsLLE:
   bg = "#0a223333"
   VVsLLE.sort(key=lambda x: x[0].lower())
   VVJi29 = BF(self.VVMP2P, canCencel)
   VVMWQK  = ("Start FTP"   , self.VVrLGL    , [])
   VVM9Pm = ("Entry Options"  , self.VV2e52  , [])
   VVRHhw = ("Scan for Devices" , self.VVlo7d , [])
   header  = ("Num" , "IP-Address", "Username", "Password", "Default Path", "Remarks" )
   widths  = (7  , 25   , 19  , 19  , 0.01   , 30  )
   VV0CnX = (CENTER , LEFT   , LEFT  , LEFT  , LEFT   , LEFT  )
   VVdesl = FFDpub(self, None, title=title, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, width=1500, height=900, VVbG6j=widths, VVGNdU=28, VVMWQK=VVMWQK, VVJi29=VVJi29, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw
       , VVaRsg=bg, VVWgai=bg, VVSJJk=bg, VVlrsP="#11ffff00", VVYCZ6="#11220000", VVTjte="#00333333", VVIyj7="#11400040")
   ndx = CFG.lastNetworkDevice.getValue()
   if isinstance(ndx, int):
    VVdesl.VVTklH(ndx)
  else:
   FFgBNQ(self, BF(FFbA1i, self, BF(self.VVsskm, canCencel=canCencel), title="Scanning ..."), "No devices found !\n\nScan network ?", callBack_No=BF(self.VVMP2P, canCencel), title=title)
 def VV2e52(self, VVdesl, title, txt, colList):
  VVtMHe = []
  VVtMHe.append(("Change Username"   , "user"))
  VVtMHe.append(("Change Password"   , "pass"))
  VVtMHe.append(("Change Remarks"   , "rem"))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Remove Selected Server" , "del"))
  FFECK9(self, BF(self.VVDBg7, VVdesl), VVtMHe=VVtMHe, title="Entry Options")
 def VVDBg7(self, VVdesl, item=None):
  if item:
   if   item == "user" : self.VVDxHa("u", VVdesl)
   elif item == "pass" : self.VVDxHa("p", VVdesl)
   elif item == "rem" : self.VVDxHa("r", VVdesl)
   elif item == "del" : FFgBNQ(self, BF(FFbA1i, self, BF(self.VVwpWM, VVdesl), title="Deleting ..."), "Continue ?", title="Delete Entry")
 def VVMP2P(self, canCencel, VVdesl=None):
  if VVdesl: VVdesl.cancel()
  if canCencel : self.close()
 def VVrLGL(self, VVdesl, title, txt, colList):
  num, ip, u, p, path, rem = colList
  entry = (ip, u, p, path, rem)
  FF0UO9(CFG.lastNetworkDevice, VVdesl.VVvapY())
  self.session.openWithCallback(BF(self.VVqGFP, entry, VVdesl), CC6WLu, entry)
 def VVqGFP(self, entry, VVdesl, newPath=None):
  if newPath:
   ip, u, p, path, rem = entry
   if path != newPath:
    self.VVYZC2("d", newPath, ip, u, p, path, rem)
    self.VVLjnr(VVdesl)
 def VVlo7d(self, VVdesl, title, txt, colList):
  FFbA1i(VVdesl, BF(self.VVsskm, mainTableInst=VVdesl), title="Scanning Network ...")
 def VVsskm(self, canCencel=False, mainTableInst=None):
  title = "Network Devices"
  ftpLst, err = CCFewM.VVQ8Xy(CCFewM.VViLyO)
  if err:
   FFOyl1(self, err, title=title)
   return
  telLst, err = CCFewM.VVQ8Xy(CCFewM.VV4ypy)
  if err:
   FFOyl1(self, err, title=title)
   return
  tLst = list(set(ftpLst + telLst))
  lst = []
  for item in tLst:
   typ = []
   if item in ftpLst: typ.append("FTP")
   if item in telLst: typ.append("Telnet")
   lst.append((item[0], item[1], " / ".join(typ)))
  ftpLst = telLst = tLst = None
  if lst:
   def VVUpQQ(p1, p2): return FFGVZA(p1[0], p2[0])
   lst.sort(key=FFgRqj(VVUpQQ))
   bg = "#0a202020"
   VVJi29 = BF(self.VVMP2P, canCencel)
   VVMWQK  = ("Add to Devices" , BF(self.VV4gUh, mainTableInst, canCencel), [])
   header  = ("IP-Address" , "MAC-Address" , "Open Ports" )
   widths  = (40   , 34   , 26   )
   VV0CnX = (LEFT   , CENTER  , CENTER  )
   FFDpub(self, None, title=title, header=header, VVcuvv=lst, VV0CnX=VV0CnX, VVbG6j=widths, width=1200, VVGNdU=30, VVMWQK=VVMWQK, VVJi29=VVJi29, VVcmLr=2
     , VVaRsg=bg, VVWgai=bg, VVSJJk=bg, VVYCZ6="#0a225555", VVIyj7="#11403040")
  else:
   FFOyl1(self, "No devices found !", title=title)
 def VVDckO(self):
  title = 'Hosts that responded to "ping"'
  lst, err = CCFewM.VVQ8Xy(-1)
  if err:
   FFOyl1(self, err, title=title)
  elif lst:
   def VVUpQQ(p1, p2): return FFGVZA(p1[0], p2[0])
   lst.sort(key=FFgRqj(VVUpQQ))
   bg = "#0a202020"
   header  = ("IP-Address" , "MAC-Address" )
   widths  = (50   , 50   )
   VV0CnX = (LEFT   , LEFT   )
   FFDpub(self, None, title=title, header=header, VVcuvv=lst, VV0CnX=VV0CnX, VVbG6j=widths, width=1000, height=700, VVGNdU=30
     , VVaRsg=bg, VVWgai=bg, VVSJJk=bg, VVYCZ6="#0a225555", VVIyj7="#11403040")
  else:
   FFOyl1(self, "Network scanning failed !", title=title)
 def VVqzVe(self, ip=None):
  if ip:
   FFbA1i(self, BF(self.VVa424, ip), title="Scanning %s" % ip)
 def VVa424(self, ip):
  dct = {20: "FTP Data Transfer", 21: "FTP Control", 22: "SSH", 23: "Telnet", 25: "SMTP (eMail)", 80: "HTTP", 443: "HTTPS"}
  txt  = "IP:\n   %s\n\n" % ip
  txt += "Ping Result:\n   %s\n\n" % ("OK" if CCFewM.VVqkc1(ip) else "Failed")
  txt += "Available Ports:\n"
  ports = ""
  for port, subj in dct.items():
   ok = CCFewM.VVfHxR(ip, port, timeout=0.5)
   if ok:
    ports += "   %d : %s\n" % (port, subj)
  FFoB4k(self, txt + (ports or "   None"), title="Scanned ports : %s" % str(list(dct)).strip("[]"))
 def VVZnnN(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFFr8o(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVUpQQ(p1, p2): return FFGVZA(p1[0], p2[0])
  tLst.sort(key=FFgRqj(VVUpQQ))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VV4gUh(self, mainTableInst, canCencel, VVdesl, title, txt, colList):
  ip, mac, typ = VVdesl.VVLabl(VVdesl.VVvapY())
  if "Own" in ip:
   FFZD7H(VVdesl, "Cannot add your device", 1500)
  else:
   gw = "Gateway"
   if gw in ip : ip, u, p, path, rem = ip.split()[0].strip(), "admin", "123456", "/", gw
   else  : ip, u, p, path, rem = ip, "root", "dreambox", "/", "No-name"
   for entry in self.VVZnnN():
    num1, ip1, u1, p1, path1, rem1 = entry
    if (ip, u, p, path, rem) == (ip1, u1, p1, path1, rem1):
     break
   else:
    if fileExists(self.netEntryFile):
     FF2Usq(self.netEntryFile)
    with open(self.netEntryFile, "a") as f:
     f.write(self.VVBY5D(ip, u, p, path, rem))
   if mainTableInst: self.VVLjnr(mainTableInst, [ip, u, p, path, rem])
   else   : self.VVlyiC(canCencel)
   VVdesl.cancel()
 def VVBY5D(self, ip, u, p, path, rem):
  return "host=%s,user=%s,pass=%s,path=%s,rem=%s\n" % (ip, u, p, path, rem)
 def VVwpWM(self, VVdesl):
  num, ip, u, p, path, rem = VVdesl.VVLabl(VVdesl.VVvapY())
  lst = self.VVZnnN()
  tot = 0
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if not (ip1, u1, p1, path1, rem1) == (ip, u, p, path, rem):
     f.write(self.VVBY5D(ip1, u1, p1, path1, rem1))
     tot += 1
  if tot:
   self.VVLjnr(VVdesl)
  else:
   VVdesl.cancel()
 def VVDxHa(self, col, VVdesl):
  num, ip, u, p, path, rem = VVdesl.VVLabl(VVdesl.VVvapY())
  if   col == "u": orig, subj = u  , "User"
  elif col == "p": orig, subj = p  , "Password"
  elif col == "r": orig, subj = rem, "Remarks"
  FFdnKb(self, BF(self.VVoxn3, col, orig, VVdesl, num, ip, u, p, path, rem), defaultText=orig, title="Change %s" % subj, message="Enter %s:" % subj)
 def VVoxn3(self, col, orig, VVdesl, num, ip, u, p, path, rem, newTxt):
  if not newTxt == None:
   newTxt = newTxt.strip()
   if orig == newTxt:
    FFZD7H(VVdesl, "No change", 1500)
   elif not newTxt and col == "u":
    FFZD7H(VVdesl, "No user !", 2000)
   else:
    self.VVYZC2(col, newTxt, ip, u, p, path, rem)
    self.VVLjnr(VVdesl)
 def VVYZC2(self, col, newTxt, ip, u, p, path, rem):
  lst = self.VVZnnN()
  oldItem = (ip, u, p, path, rem)
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if (ip1, u1, p1, path1, rem1) == oldItem:
     if   col == "u": u1  = newTxt
     elif col == "p": p1  = newTxt
     elif col == "d": path1 = newTxt
     elif col == "r": rem1 = newTxt
    f.write(self.VVBY5D(ip1, u1, p1, path1, rem1))
 def VVLjnr(self, VVdesl, newEntry=None):
  VVsLLE = self.VVZnnN()
  if VVsLLE : VVdesl.VV87pY(VVsLLE, tableRefreshCB=BF(self.VVXTx1, newEntry))
  else  : VVdesl.cancel()
 def VVXTx1(self, newEntry, VVdesl, title, txt, colList):
  if newEntry:
   for ndx, row in enumerate(VVdesl.VVTW2g()):
    if row[1:] == newEntry:
     VVdesl.VVTklH(ndx)
 def VVMP2P(self, canCencel, VVdesl=None):
  if VVdesl: VVdesl.cancel()
  if canCencel : self.close()
class CCFewM():
 VViLyO = 21
 VV4ypy = 23
 def __init__(self):
  self.VVrMkE()
 def VVrMkE(self):
  self.ftp  = None
  self.ftpIp  = ""
  self.ftpUser = ""
  self.ftpPass = ""
  self.ftpSys  = ""
 def VVQuAX(self, ip, User, Pass, timeout=5):
  myIp = CCFewM.VVK38g()
  if ip != myIp:
   if CCFewM.VVfHxR(ip, CCFewM.VViLyO):
    self.VVrMkE()
    err = ""
    try:
     from ftplib import FTP
     self.ftp  = FTP(ip, user=User, passwd=Pass, timeout=timeout)
     self.ftp.set_pasv(False)
     self.ftpIp  = ip
     self.ftpUser = User
     self.ftpPass = Pass
    except Exception as e:
     err = str(e)
   else:
    err = "Connection timed out !\n\n%s" % ip
  else:
   err = "Cannot FTP to your Device-IP:\n\n%s" % ip
  return err
 def VVN0uT(self):
  try: return self.ftp.sendcmd("SYST")
  except: return ""
 def VVFc79(self):
  try: return self.ftp.sendcmd("NOOP")
  except: return ""
 def VVFMeK(self, timeout=3):
  t1 = iTime()
  while True:
   state = self.VVFc79()
   if not state or state == "200 OK" or iTime() - t1 >= timeout:
    break
 def VVRQst(self):
  try: return self.ftp.sendcmd("STAT")
  except: return ""
 def VV0SFe(self, Dir, isLong=False):
  files, err = [], ""
  if self.ftp and self.VVsUB1(Dir):
   try:
    if isLong: self.ftp.dir(files.append)
    else  : self.ftp.nlst()
   except Exception as e:
    err = str(e)
  else:
   err = "No FTP Connection !"
  return files, err
 def VVXQpM(self):
  try: return self.ftp.pwd()
  except: return ""
 def VV6aS6(self, path):
  try:
   size = self.ftp.sendcmd("SIZE %s" % path)
   return "f"
  except:
   curDir = self.VVXQpM()
   if self.VVsUB1(path) : typ = "d"
   else      : typ = "b"
   self.VVsUB1(curDir)
   return typ
 def VVrilt(self, path):
  try: return self.ftp.size(path)
  except: return -1
 def VVsUB1(self, path):
  try:
   self.ftp.cwd(path)
   return True
  except:
   return False
 def VVu8HS(self, path):
  try:
   self.ftp.mkd(path)
   return True
  except:
   return False
 def VVzuHN(self, path, flag):
  try:
   if flag == "d" : self.ftp.rmd(path)
   else   : self.ftp.delete(path)
   return True
  except:
   return False
 def VVR4CE(self, fromN, toN):
  try:
   self.ftp.rename(fromN, toN)
   return True
  except:
   return False
 def VVBTBh(self, remFile, locFile="", maxSz=10000000):
  sz = self.VVrilt(remFile)
  if   sz == -1 : return "", sz, "Cannot read file size."
  elif sz > maxSz : return "", sz, "File too big."
  else   : err= ""
  locFile = locFile or "/tmp/%s" % os.path.basename(remFile)
  try:
   self.ftp.retrbinary("RETR %s" % remFile, open(locFile, "wb").write)
   if fileExists(locFile) : return locFile, sz, ""
   else     : return "", sz, "Download Failed."
  except Exception as e:
   FFOlRe(locFile)
   return "", sz, str(e)
 def VVhJiR(self):
  if self.ftp:
   try: self.ftp.quit()
   except: pass
  self.VVrMkE()
 @staticmethod
 def VVXxba():
  from uuid import getnode
  return ':'.join(iFindall('..', '%012x' % getnode())).upper()
 @staticmethod
 def VVK38g():
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_DGRAM
  try:
   setdefaulttimeout(1)
   s = socket(AF_INET, SOCK_DGRAM)
   s.connect(("1.1.1.1", 80))
   ip = s.getsockname()[0]
   s.close()
   return ip
  except:
   return ""
 @staticmethod
 def VVeZ57():
  myIp = CCFewM.VVK38g()
  if myIp.count(".") == 3:
   parts = myIp.split('.')
   return ".".join(parts[:3]) + "."
  return ""
 @staticmethod
 def VVRpaF():
  span = iSearch(r"((?:\d+.){3}\.\d+)", FFvL4V("ip route | grep default"), IGNORECASE)
  return span.group(1) if span else ""
 @staticmethod
 def VVWtRf(port=-1):
  lst = []
  def VVpFzx(ip):
   if port > -1: ok = CCFewM.VVfHxR(ip, port)
   else  : ok = CCFewM.VVqkc1(ip)
   if ok:
    lst.append(ip)
  try:
   baseIp = CCFewM.VVeZ57()
   thLst  = []
   for num in range(1, 255):
    ip = "%s%d" % (baseIp, num)
    th = iThread(name="ajp_scanIp%d" % num, target=BF(VVpFzx, ip))
    th.start()
    thLst.append(th)
   for th in thLst: th.join()
   return lst, ""
  except Exception as e:
   err = str(e)
   return [], err + '\n\nMax Threads = %d\nCheck your system "Max User Processes" with "ulimit -u"' % len(thLst) if "can't start new thread" in err else ""
 @staticmethod
 def VVQ8Xy(port):
  myIp = CCFewM.VVK38g()
  myGw = CCFewM.VVRpaF()
  tDict = { myIp: CCFewM.VVXxba() }
  devLst, err = CCFewM.VVWtRf(port)
  if err:
   return [], err
  else:
   for ip in devLst:
    span = iSearch(r"((?:\d+.){3}\.\d+).+\s+((?:[a-f\d]{2}:){5}[a-f\d]{2})", FFjwNC("arp -n %s" % ip), IGNORECASE)
    if span    : tDict[ip] = span.group(2).upper()
    elif not ip == myIp : tDict[ip] = ""
   lst = []
   for key, val in tDict.items():
    if   key == myIp: txt = " %s Own" % VVRuOi
    elif key == myGw: txt = " %s Gateway" % VVRuOi
    else   : txt = ""
    lst.append((key + txt, val))
   return lst, ""
 @staticmethod
 def VVqkc1(ip):
  return FFqSkC("ping -W1 -q -c1 %s" % ip)
 @staticmethod
 def VVfHxR(host, port, timeout=1.0):
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
  setdefaulttimeout(timeout)
  try:
   socket(AF_INET, SOCK_STREAM).connect((host, port))
   return True
  except:
   return False
 @staticmethod
 def VVmB13(ip="1.1.1.1", timeout=1):
  if CCFewM.VVfHxR(ip, 53, timeout):
   return True
  if CCFewM.VVqkc1(ip):
   return True
  return FFqSkC("wget -q -T %d -t 1 --spider %s" % (timeout, ip))
 @staticmethod
 def VV223H(SELF, okFnc, title):
  baseIp = CCFewM.VVeZ57()
  lst = []
  for num in range(1, 255):
   item = "%s%d" % (baseIp, num)
   lst.append((item, item))
  FFECK9(SELF, okFnc, VVtMHe=lst, width=600, title=title, VVaRsg="#222222", VVWgai="#222222")
class CC6WLu(Screen, CCFewM):
 def __init__(self, session, entry):
  self.skin, self.skinParam = FFPFsH(VVMjBN, 1400, 920, 40, 50, 30, "#11333344", "#08303030", 30, barHeight=40, topRightBtns=2)
  self.session  = session
  self.ftpEntry  = entry
  self.VVGNdU  = self.skinParam["bodyFontSize"]
  self.VVavwW  = self.skinParam["bodyLineH"]
  self.VVeSt7  = self.skinParam["width"]
  self.curDir   = "/"
  self.list   = []
  self.png_fil  = CCXPWq.VV919t("fil")
  self.png_dir  = CCXPWq.VV919t("dir")
  self.png_dirup  = CCXPWq.VV919t("dirup")
  self.png_slwfil  = CCXPWq.VV919t("slwfil")
  self.png_slbfil  = CCXPWq.VV919t("slbfil")
  self.png_slwdir  = CCXPWq.VV919t("slwdir")
  self.serverOrigData = None
  self.Title   = "FTP (%s)" % entry[0]
  CCFewM.__init__(self)
  VVtMHe = [("Item-%d" % x,) for x in range(50)]
  FFRFZg(self, title=self.Title, VVtMHe=VVtMHe)
  FFKdfz(self["keyRed"] , "Exit")
  self["myMenu"] = MenuList(VVtMHe, True, eListboxPythonMultiContent)
  self["myMenu"].l.setFont(0, gFont(VVlMYE, self.VVGNdU))
  self["myMenu"].l.setItemHeight(self.VVavwW)
  self["myActionMap"] = ActionMap(VVQOuY,
  {
   "red" : BF(self.VV2ouQ, True) ,
   "ok" : self.VV2Iyl    ,
   "cancel": self.VV2ouQ    ,
   "menu" : self.VV3KEZ   ,
   "info" : self.VVCwJj  ,
   "pageUp": self.VVa8hD    ,
   "chanUp": self.VVa8hD
  })
  self.onShown.append(self.VVnLQg)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVEnVS)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFWIRJ(self["myMenu"])
  FFJI0m(self)
  FFFlxX(self)
  FFk6h6(self)
  FFC3pI(self["keyBlue"], "#11333333")
  FFbA1i(self, self.VVR1W1, title="Connecting ...")
 def VVR1W1(self):
  ip, u, p, path, rem = self.ftpEntry
  err = self.VVQuAX(ip, u, p)
  if err:
   FFOyl1(self, err, title=self.Title)
   FFKdfz(self["keyBlue"] , "")
   self.close()
  elif self.ftp:
   FFKdfz(self["keyBlue"], self.ftpIp)
   if not self.VVsUB1(path):
    path = "/"
   self.VVylVS(path)
   self.serverOrigData = (ip, u, p, path, rem)
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.VVFc79():
   self.VVhJiR()
 def VV2Iyl(self):
  if self.VVcCcN():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    if   flag == "d" or targetState == "d" : self.VVylVS(os.path.join(self.curDir, name))
    elif flag == "x"      : self.VVa8hD()
    else         : self.VVdDeJ(os.path.join(self.curDir, name))
 def VV2ouQ(self, force=False):
  if force or CFG.FileManagerExit.getValue() == "e": self.close(self.curDir)
  else            : self.VVa8hD()
 def VVcCcN(self):
  if self.VVFc79():
   return True
  else:
   FFOyl1(self, "FTP Server is now diconnected !", title=self.Title)
   return False
 def VVdDeJ(self, path):
  cat = self.VVoEHk(path)
  if cat in ("pic"):
   FFbA1i(self, BF(self.VVcN4g, path))
  elif cat in ("mov", "mus"):
   if CCoUhv.VVoESL("5002"):
    url = "ftp%%3a//%s%%3a%s@%s%s" % (self.ftpUser, self.ftpPass, self.ftpIp, path)
    rType = "5002"
   else:
    rType = CFG.iptvAddToBouquetRefType.getValue()
    url = "http%%3a//%s/file?file=%s" % (self.ftpIp, path)
   FFbA1i(self, BF(CCVnYx.VVWQNk, self, url, rType=rType), title="Playing Media ...")
 def VVcN4g(self, path):
  locFile, size, err = self.VVBTBh(path)
  if err: FFOyl1(self, err, title="View Picture File")
  else  : CCXzC3.VVHZ7h(self, locFile, fakePath="ftp:/%s" % path, cbFnc=BF(FFOlRe))
 def VVEnVS(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel: title = "  %s  " % os.path.join(self.curDir, "" if sel[0][0] == CCXPWq.VV4zAm else sel[0][0])
  else  : title=  VVOr14 + "  No Files Found !"
  self["myTitle"].setText(title)
 def VVa8hD(self):
  if self.VVcCcN():
   lastPart = FFd4tO(self.curDir)
   parentDir = os.path.abspath(os.path.join(self.curDir, os.pardir))
   self.VVylVS(parentDir, lastPart, "d")
 def VVylVS(self, Dir, moveTo="", moveToType=""):
  FFbA1i(self, BF(self.VVgZGc, Dir, moveTo, moveToType))
 def VVgZGc(self, Dir, moveTo, moveToType):
  files, err = self.VV0SFe(Dir, isLong=True)
  self.curDir = self.VVXQpM() or "/"
  self.VVcJzY(files)
  if moveTo:
   for ndx, item in enumerate(self.list):
    name, target, targetState, flag, sortSeq = item[0]
    if moveTo == name:
     if not moveToType or moveToType == flag:
      self["myMenu"].moveToIndex(ndx)
      break
  else:
   self["myMenu"].moveToIndex(0)
 def VVcJzY(self, files):
  self.list = []
  if self.curDir != "/":
   self.list.append(self.VVl5nv(CCXPWq.VV4zAm, CCXPWq.VV4zAm, "", "", "x"))
  for item in files:
   linkTo = ""
   isDir = isFile = isLink = False
   item = item.strip()
   if   item.startswith("l")     : flag = "l"
   elif item.startswith("d") or "<DIR>" in item: flag = "d"
   else          : flag = "f"
   gaps = 3 if item[:1].isdigit() else 8
   name = item.split(None, gaps)[gaps]
   linkSep = " -> "
   origName = name
   target = targetState = ""
   if linkSep in name:
    flag = "l"
    name, _, target = name.partition(linkSep)
    if not target.startswith("/"):
     target = "/" + target
    targetState = self.VV6aS6(target)
    color = VVOr14 if targetState == "b" else VViZMT
    origName = name + VVXAXH + linkSep + color + " "+ target
   self.list.append(self.VVl5nv(origName, name, target, targetState, flag))
  self.list.sort(key=lambda x: (x[0][4], x[0][0]))
  self["myMenu"].l.setList(self.list)
 def VVl5nv(self, origName, name, target, targetState, flag):
  if flag == "f":
   png = self.png_fil
   ext = os.path.splitext(name)[1]
   if ext:
    cat = self.VVoEHk(name)
    if cat: png = LoadPixmap("%s%s.png" % (VV2V68, cat))
  elif flag == "d": png = self.png_dir
  elif flag == "l":
   if   targetState == "f" : png = self.png_slwfil
   elif targetState == "d" : png = self.png_slwdir
   elif targetState == "b" : png = self.png_slbfil
   else      : png = self.png_slwfil
  elif flag == "x": png = self.png_dirup
  else   : png = self.png_fil
  if   origName == CCXPWq.VV4zAm: sortSeq = 0
  elif flag == "d" or targetState == "d"  : sortSeq = 1
  else          : sortSeq = 2
  tableRow = [ (name, target, targetState, flag, sortSeq) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVavwW + 10, 0, self.VVeSt7, self.VVavwW, 0, LEFT | RT_VALIGN_CENTER, origName))
  tableRow.append(CCXQTE.VVGIbI(0, 2, self.VVavwW-4, self.VVavwW-4, png))
  return tableRow
 def VVoEHk(self, path):
  ext = os.path.splitext(path)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in CCXPWq.VVbz66().items():
    if ext in lst:
     return cat
  return ""
 def VV3KEZ(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel : name, target, targetState, flag, sortSeq = sel[0]
  else : name = target = targetState = flag = ""
  isTop  = name == CCXPWq.VV4zAm
  isDir  = flag == "d" or targetState == "d"
  isFile = flag == "f" or targetState == "f"
  def VVQyFE(titl, ref, chk, color=""):
   if chk: return VVtMHe.append((color + titl, ref))
   else  : return VVtMHe.append((titl, ))
  VVtMHe = []
  VVQyFE("Properties", "VVCwJj", not isTop)
  c = VVRuOi
  VVtMHe.append(VVXGzj)
  VVQyFE("Download Selected File ..."    , "FF4VyKFromServer", isFile, c)
  VVQyFE("Upload a Local File to Remote Server ...", "VVIL6p" , True  , c)
  VVtMHe.append(VVXGzj)
  VVQyFE("Create new directory", "VVIW37", True)
  VVQyFE("Rename", "VVjXTL", not isTop)
  VVQyFE("DELETE", "VVq3l6", not isTop, VV8ETX)
  VVtMHe.append(VVXGzj)
  VVQyFE("FTP Server Information", "VVrRLy", True)
  VVtMHe.append(VVXGzj)
  VVQyFE("Refresh File List", "refresh", True)
  FFECK9(self, self.VV1t0r, VVtMHe=VVtMHe, title="Options")
 def VV1t0r(self, item=None):
  if item:
   if   item == "VVCwJj"     : self.VVCwJj()
   elif item == "FF4VyKFromServer"   : self.FF4VyKFromServer()
   elif item == "VVIL6p"   : self.VVIL6p()
   elif item == "VVIW37"   : self.VVIW37()
   elif item == "VVjXTL"   : self.VVjXTL()
   elif item == "VVq3l6"   : self.VVq3l6()
   elif item == "VVrRLy"    : self.VVrRLy()
   elif item == "refresh"and self.VVcCcN() : self.VVylVS(self.curDir)
 def VVCwJj(self):
  if self.VVcCcN():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    path = os.path.join(self.curDir, name)
    txt = "%s:\n%s\n\n" % (FF8oA9("Path", VVRuOi), path)
    typ = {"d": "Directory", "f": "File", "l": "SymLink", "x": ""}.get(flag, "")
    if typ: txt += "Type\t: %s%s\n" % (typ, " (Broken)" if targetState == "b" else "")
    if target: txt += "Target\t: %s\n" % target
    sz = self.VVrilt(path)
    if sz > -1: txt += "Size\t: %s" % CCVnYx.VVI3LQ(sz)
   else:
    txt = "Nothing selected"
   FFoB4k(self, txt, title="Properties")
 def VVrRLy(self):
  if self.VVcCcN():
   Sys  = self.VVN0uT() or " -"
   txt = "%s\n  %s\n\n" % (FF8oA9("System:", VVRuOi), Sys[4:] if Sys.startswith("215 ") else Sys)
   Stat = self.VVRQst() or " -"
   txt += "%s\n" % (FF8oA9("Status:", VVRuOi))
   for line in Stat.splitlines():
    txt += "  %s\n" % (line[4:] if line.startswith("211-") or line.startswith("211 ") else line)
   FFoB4k(self, txt, title="FTP Server Information")
 def VVIW37(self, name=""):
  if self.VVcCcN():
   title = "Add New Directory"
   FFdnKb(self, BF(self.VVAFuc, title), defaultText=name, title=title, message="Enter Directory name")
 def VVAFuc(self, title, name):
  if name and name.strip():
   if self.VVu8HS(name) : self.VVylVS(self.curDir, name, "d")
   else     : FFOyl1(self, "Failed to create : %s" % name, title)
 def VVjXTL(self):
  if self.VVcCcN():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Rename"
    name, target, targetState, flag, sortSeq = sel[0]
    FFdnKb(self, BF(self.VVMEed, title, name, flag), defaultText=name, title=title, message="Enter new name")
 def VVMEed(self, title, name, flag, newName):
  if newName and newName.strip():
   if self.VVR4CE(name, newName.strip()) : self.VVylVS(self.curDir, newName, flag)
   else          : FFOyl1(self, "Failed to rename to : %s" % newName, title)
 def VVq3l6(self):
  if self.VVcCcN():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    FFgBNQ(self, BF(FFbA1i, self, BF(self.VVd1dN, name, flag), title="Deleting ..."), "Delete ?\n\n%s" % name, title="Delete")
 def VVd1dN(self, name, flag):
  if self.VVzuHN(name, flag) : self.VVylVS(self.curDir)
  else         : FFOyl1(self, "Failed to delete:\n\n%s" % name, "Delete")
 def FF4VyKFromServer(self):
  if self.VVcCcN():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Download File"
    name, target, targetState, flag, sortSeq = sel[0]
    remFile = os.path.join(self.curDir, name)
    size = self.VVrilt(remFile)
    if size == -1:
     FFOyl1(self, "Cannot get file size for:\n\n%s" % remFile, title=title)
    else:
     Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVZAJU
     self.session.openWithCallback(BF(self.VVg4X7, title, remFile, name, size), BF(CCVnYx, mode=CCVnYx.VVW7oj, VVyIuw="Download here", VVSMX5=Dir, width=1200, height=840, pickTitleBG="#11002222", pickBodyBG="#11003333", cursorBG="#11005566"))
 def VVg4X7(self, title, remFile, name, size, locPath):
  if locPath:
   FF0UO9(CFG.lastFtpLocalPath, locPath)
   locFile = os.path.join(locPath, name)
   self.session.open(CCjWUz, barTheme=CCjWUz.VVh7HE, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Downloading ..."
       , fncToRun  = BF(self.VVOxgg, remFile, size, locFile)
       , VVCBqA = BF(self.VVgETR, remFile, size, locFile))
 def VVOxgg(self, remFile, size, locFile, VVNVFL):
  VVNVFL.VV0amK(size)
  VVNVFL.VVpwcW = ""
  with open(locFile, "wb") as locFileObj:
   try:
    def VVzjP7(data):
     if not VVNVFL or VVNVFL.isCancelled:
      return
     locFileObj.write(data)
     VVNVFL.VViyfK(len(data))
    self.ftp.retrbinary("RETR %s" % remFile, VVzjP7)
   except Exception as e:
    VVNVFL.VVpwcW = str(e)
 def VVgETR(self, remFile, size, locFile, VVdCuP, VVpwcW, threadCounter, threadTotal, threadErr):
  title = "File Download"
  delF = False
  if VVpwcW:
   FFOyl1(self, "%s\n\nftp:/%s" % (VVpwcW, remFile), title="Download Error")
   delF = True
  elif not VVdCuP:
   FFOyl1(self, "Download cancelled for:\n\nftp:/%s" % remFile, title=title)
   delF = True
  else:
   if size == FFF0Rr(locFile):
    txt = "Successfully downloaded to:\n\n%s" % locFile
    FFDeF8(self, txt, title=title)
   else:
    FFOyl1(self, "Incorrect downloaded file size for:\n\nftp:/%s" % remFile, title=title)
    delF = True
  if delF:
   FFOlRe(locFile)
 def VVIL6p(self):
  if self.VVcCcN():
   Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVZAJU
   self.session.openWithCallback(self.VVbbbf, BF(CCVnYx, VVyIuw="Upload selected file", VVSMX5=Dir, patternMode="all", width=1200, height=850, pickTitleBG="#11001122", pickBodyBG="#11330033", cursorBG="#11662200"))
 def VVbbbf(self, locFile):
  if locFile:
   title = "Upload File to Remote Server"
   FF0UO9(CFG.lastFtpLocalPath, os.path.dirname(locFile))
   size = FFF0Rr(locFile)
   if size == -1:
    FFOyl1(self, "Cannot get file size for:\n\n%s" % locFile, title=title)
   else:
    remFile = os.path.join(self.curDir, os.path.basename(locFile))
    self.session.open(CCjWUz, barTheme=CCjWUz.VVh7HE, titleBg="#22220022", bodyBg="#22220022"
        , titlePrefix = "Uploading ..."
        , fncToRun  = BF(self.VV4GNt, locFile, size, remFile)
        , VVCBqA = BF(self.VVS8Bt, locFile, size, remFile))
 def VV4GNt(self, locFile, size, remFile, VVNVFL):
  VVNVFL.VV0amK(size)
  VVNVFL.VVpwcW = ""
  with open(locFile, "rb") as locFileObj:
   try:
    def VV6Ubw(data):
     if not VVNVFL or VVNVFL.isCancelled:
      VVNVFL.VVpwcW = "Upload cancelled"
      locFileObj.close()
      return
     VVNVFL.VViyfK(len(data))
    self.ftp.storbinary("STOR %s" % remFile, locFileObj, callback=VV6Ubw)
   except Exception as e:
    VVNVFL.VVpwcW = VVNVFL.VVpwcW or str(e)
 def VVS8Bt(self, locFile, size, remFile, VVdCuP, VVpwcW, threadCounter, threadTotal, threadErr):
  title = "File Upload"
  err = ""
  if VVdCuP:
   if size == FFF0Rr(locFile) : FFDeF8(self, "Successfully uploaded to:\n\n%s" % remFile, title=title)
   else       : err = "Incorrect uploaded file size for:\n\nftp:/%s" % remFile
  elif VVpwcW : err = "%s\n\n%s" % (VVpwcW, locFile)
  else    : err = "Incomplete file transfer:\n\n%s" % locFile
  if err:
   FFOyl1(self, err, title=title)
   self.VVFMeK()
   self.VVzuHN(remFile, "")
  self.VVylVS(self.curDir)
class CCSwPL():
 VVpmty  = "all"
 VVAkjY = "vid"
 VVeWNL  = "osd"
 @staticmethod
 def VVNmX2(session, k):
  if not CFG.screenshotFType.getValue() == "off":
   title = "%s Screenshot" % PLUGIN_NAME
   if FFLsle("grab"):
    winShown = session.current_dialog.shown
    if k == CCSwPL.VVAkjY and winShown: session.current_dialog.hide()
    FFkvVR(BF(CCSwPL.VVaJCF, title, session, k, winShown))
   else:
    FFcZkm(session, "No Grab command !", title=title)
 @staticmethod
 def VVaJCF(title, session, k, winShown):
  fTitle = skinName = ""
  x = y = w = h = 0
  if k == CCSwPL.VVeWNL:
   if not winShown:
    FFcZkm(session, "No Window to capture !", title=title)
    return
   if not CCSwPL.VVBSOI(session, title, True):
    return
   valid, origTitle, clnTitle, skinName, x, y, w, h = CCSwPL.VVDwLd(session)
   fTitle = "%s_(%s)" % (clnTitle, skinName)
   if not valid:
    FFcZkm(session, "Cannot get Window Dimensions !", title=title)
    return
  if not fTitle:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(session, isFromSession=True)
   chName = iSub(r"[^A-Za-z0-9]" ,"-" , chName.strip())
   fTitle = chName or refCode.replace(":", "_")
  ext = CFG.screenshotFType.getValue()
  if   ext == "jpg": typ = "-j 100"
  elif ext == "png": typ = "-p"
  else    : typ = ""
  path = "%sscreenshot_%s_%s.%s" % (FFDpEI(CFG.exportedPIconsPath.getValue()), fTitle, FFZR2n(), ext)
  ok = FFmiBl("grab -q -s %s > '%s'" % (typ, path))
  if k == CCSwPL.VVAkjY and winShown:
   session.current_dialog.show()
  elif k == CCSwPL.VVeWNL:
   ok = CCSwPL.VVCWfk(path, x, y, w, h)
   if not ok:
    FFOlRe(path)
    FFcZkm(session, "Error while cropping image file !", title=title)
    return
  if ok and fileExists(path) : session.open(BF(CCXzC3, title=path, VVlNrK=path))
  else      : FFcZkm(session, "Error while capturing screen !", title=title)
 @staticmethod
 def VVBSOI(SELF, title, isFromExternal, install=True, cbFnc=None):
  try:
   from PIL import Image
   return True
  except:
   if install:
    FFgBNQ(SELF, BF(CCSwPL.VV9zNl, SELF, isFromExternal, cbFnc=cbFnc), "Imaging Library is required.\n\nInstall ?", title=title, isFromExternal=isFromExternal)
   return False
 @staticmethod
 def VV9zNl(SELF, isFromExternal, cbFnc=None):
  if pyVersion[0] >= 3: name = "python3-pillow"
  else    : name = "python-imaging"
  if isFromExternal: fnc = BF(FFuyXR, VV4qLc=cbFnc)
  else    : fnc = BF(FFyrLj , VV4qLc=cbFnc)
  fnc(SELF, FFbfXZ(VVqrBj, name), checkNetAccess=True, title="Installing Imaging Library")
 @staticmethod
 def VVDwLd(session, repl="-"):
  valid = False
  origTitle = clnTitle = skinName = ""
  x = y = w = h = 0
  obj = session.current_dialog
  if obj:
   inst = obj.instance
   skinName = obj.skinName
   if inst:
    origTitle = inst.getTitle()
    pos, size = inst.position(), inst.size()
    x, y, w, h = pos.x(), pos.y(), size.width(), size.height()
    valid = w != 0 and h !=0
    clnTitle = iSub(r"[^A-Za-z0-9]", repl , origTitle.strip())
  return valid, origTitle, clnTitle, skinName, x, y, w, h
 @staticmethod
 def VVCWfk(path, x, y, w, h, scaleToScreen=True):
  try:
   from PIL import Image
   im = Image.open(path)
   x1 = w + x
   y1 = h + y
   if scaleToScreen:
    scrW, scrH = FFrRKK()
    w, h = im.size
    if w != scrW or h != scrH:
     x  = FFYZmF(x , 0, scrW, 0, w)
     y  = FFYZmF(y , 0, scrH, 0, h)
     x1 = FFYZmF(x1, 0, scrW, 0, w)
     y1 = FFYZmF(y1, 0, scrH, 0, h)
   im = im.crop((x, y, x1, y1))
   im.save(path)
   return True
  except:
   return False
 @staticmethod
 def VVLIgA(path):
  size = FFF0Rr(path)
  sizeTxt = CCVnYx.VVI3LQ(size) if size > -1 else ""
  try:
   from PIL import Image
   im = Image.open(path)
   form = im.format
   mode = im.mode
   resTxt = "%d x %d" % im.size
  except:
   resTxt = form = mode = ""
  return size, sizeTxt, resTxt, form, mode
class CCJdTe(Screen):
 def __init__(self, session, title, fontsList, defFnt, withRestart):
  self.skin, self.skinParam = FFPFsH(VVMjBN, 1400, 1000, 40, 40, 30, "#0a001100", "#10110000", 30, barHeight=220)
  self.session  = session
  self.fontsList  = fontsList
  self.defFnt   = defFnt
  txt = FF8oA9(" (Requires GUI Restart)", VV4mV2) if withRestart else ""
  VVtMHe = []
  for path in self.fontsList:
   VVtMHe.append((os.path.splitext(os.path.basename(path))[0], path))
  VVtMHe.sort(key=lambda x: x[0].lower())
  VVtMHe.insert(0, VVXGzj)
  VVtMHe.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if self.defFnt:
   for ndx, item in enumerate(VVtMHe):
    if len(item) == 2 and item[1] == self.defFnt:
     VVtMHe[ndx] = (VViZMT + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVtMHe[curIndex] = (VViZMT + VVtMHe[curIndex][0], VVtMHe[curIndex][1])
  FFRFZg(self, VVtMHe=VVtMHe, title=title)
  self["myActionMap"].actions.update({"cancel": self.cancel})
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFWIRJ(self["myMenu"])
  FFJI0m(self)
  self["myBar"].setText(self.VVWr5C())
  self["myBar"].instance.setHAlign(1)
  self["myMenu"].onSelectionChanged.append(self.VV1qLN)
  self.VV1qLN()
 def VV2Iyl(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VV1qLN(self):
  path = self["myMenu"].l.getCurrentSelection()[1]
  if fileExists(path):
   fnt = "AJP_Sample"
   FFc6B4(path, fnt, isRepl=1)
  else:
   fnt = VVhYTJ
  self["myMenu"].instance.setFont(gFont(fnt, self.skinParam["bodyFontSize"]))
  self["myMenu"].instance.invalidate()
  self["myBar"].instance.setFont(gFont(fnt, int(self.skinParam["bodyFontSize"] * 1.3)))
  self["myBar"].instance.invalidate()
 def VVWr5C(self):
  txt = ""
  for i in range(65, 91): txt += chr(i)
  txt += "\n"
  for i in range(97, 123): txt += chr(i)
  txt += "  "
  for i in range(48, 58): txt += chr(i)
  txt += "\n"
  txt += u"\u0623\u0628\u062c\u062f \u0647\u0648\u0632 \u062d\u0637\u064a \u0643\u0644\u0645\u0646 \u0633\u0639\u0641\u0635 \u0642\u0631\u0634\u062a \u062b\u062e\u0630 \u0636\u0638\u063a  \u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
  return str(txt)
 @staticmethod
 def VV8jpx(SELF, title, defFnt, rest, VVCBqA):
  fntPath = resolveFilename(SCOPE_FONTS)
  fontsList = FF0KZb(fntPath, "*.[tToO][tT][fF]")
  if fontsList: SELF.session.openWithCallback(VVCBqA, CCJdTe, title, fontsList, defFnt, rest)
  else  : FFOyl1(self, "No fonts found in:\n\n%s" % fntPath, title=title)
class CCye7V(Screen):
 def __init__(self, session, path, VVtMHe, title):
  self.skin, self.skinParam = FFPFsH(VVMjBN, 1700, 1000, 40, 40, 30, "#11001122", "#11002233", 30, menuLabel=50)
  self.session = session
  self.path  = path
  FFRFZg(self, VVtMHe=VVtMHe, title=title)
  self["myLabelFrm"] = Label()
  self["myLabelTit"] = Label("Result Sample")
  self["myLabelTxt"] = Label()
  self["myActionMap"] = ActionMap(VVQOuY,
  {
   "ok"  : self.VV2Iyl   ,
   "cancel" : self.cancel   ,
   "pageUp" : self.VVMwbu,
   "chanUp" : self.VVMwbu,
   "pageDown" : self.VVoVse ,
   "chanDown" : self.VVoVse ,
  }, -1)
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFWIRJ(self["myMenu"])
  FFJI0m(self)
  FFC3pI(self["myLabelFrm"], "#11110000")
  FFC3pI(self["myLabelTit"], "#11663322")
  FFC3pI(self["myLabelTxt"], "#11110000")
  self["myMenu"].onSelectionChanged.append(self.VV8RNL)
  self.VV8RNL()
 def VV8RNL(self):
  if fileExists(self.path): txt = FFFr8o(self.path, maxSize=1000, encLst=[self["myMenu"].l.getCurrentSelection()[1]])
  else     : txt = "Review error !"
  self["myLabelTxt"].setText(txt.strip())
 def VV2Iyl(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVMwbu(self) : self["myMenu"].moveToIndex(0)
 def VVoVse(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CC2TkW():
 @staticmethod
 def VVmhex():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVdHN0(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFDpub(SELF, None, VVcuvv=lst, VVGNdU=30, VVcmLr=1)
 @staticmethod
 def VV73sc(path, SELF=None):
  for enc in CC2TkW.VVmhex():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFOyl1(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVAZoa(path, enc):
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     pass
   return True
  except:
   return False
 @staticmethod
 def VVLm7q(SELF, path, cbFnc, curEnc=VVXZlu, title="Select Encoding"):
  lst = CC2TkW.VVZIq5(SELF, path, "")
  if lst:
   SELF.session.openWithCallback(cbFnc, CCye7V, path, lst, title)
 @staticmethod
 def VVIR9M(SELF, cbFnc, curEnc=VVXZlu, title="Select Encoding"):
  lst = CC2TkW.VVZIq5(SELF, "", "")
  if lst:
   FFECK9(SELF, cbFnc, title=title, VVtMHe=lst, width=1000, height=1000, VVaRsg="#22220000", VVWgai="#22220000", VVIZXB=True)
 @staticmethod
 def VVZIq5(SELF, path, curEnc):
  lst = CC2TkW.VVrFi3(path)
  if lst:
   VVtMHe = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if   enc == curEnc   : c = VViZMT
    elif enc == VVXZlu: c = VVXAXH
    else      : c = ""
    VVtMHe.append((c + txt, enc))
   return VVtMHe
  else:
   FFZbFo(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVrFi3(path=""):
  encLst = []
  cPath = VV2V68 + "_sup_codecs"
  if fileExists(cPath):
   lines = FF72md(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CC2TkW.VVmhex())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if path:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CCqRTV(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFPFsH(VVMjBN, 900, 950, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVtMHe = []
  VVtMHe.append(("Settings File"   , "SettingsFile"  ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Box Info"     , "VVmHzX"   ))
  VVtMHe.append(("Tuners Info"    , "VVe9S6"  ))
  VVtMHe.append(("Python Version"   , "VVexP4"  ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Screen Size"    , "ScreenSize"   ))
  VVtMHe.append(("Language/Locale"   , "Locale"    ))
  VVtMHe.append(("Processor"    , "Processor"   ))
  VVtMHe.append(("Operating System"   , "OperatingSystem"  ))
  VVtMHe.append(("Drivers"     , "drivers"    ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("System Users"    , "SystemUsers"   ))
  VVtMHe.append(("Logged-in Users"   , "LoggedInUsers"  ))
  VVtMHe.append(("Uptime"     , "Uptime"    ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Host Name"    , "HostName"   ))
  VVtMHe.append(("MAC Address"    , "MACAddress"   ))
  VVtMHe.append(("Network Configuration" , "NetworkConfiguration"))
  VVtMHe.append(("Network Status"   , "NetworkStatus"  ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Disk Usage"    , "VVv7CX"   ))
  VVtMHe.append(("Mount Points"    , "MountPoints"   ))
  VVtMHe.append(("File System Table (FSTAB)", "FileSystemTable"  ))
  VVtMHe.append(("USB Devices"    , "USB_Devices"   ))
  VVtMHe.append(("List Block-Devices"  , "listBlockDevices" ))
  VVtMHe.append(("Directory Size"   , "DirectorySize"  ))
  VVtMHe.append(("Memory"     , "Memory"    ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Loaded Kernel Modules" , "LoadedKernelModules" ))
  VVtMHe.append(("Running Processes"  , "RunningProcesses" ))
  VVtMHe.append(("Processes with open files", "ProcessesOpenFiles" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"))
  FFRFZg(self, VVtMHe=VVtMHe, title="Device Information")
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFWIRJ(self["myMenu"])
  FFJI0m(self)
 def VV2Iyl(self):
  global VVsQSL
  VVsQSL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"   : self.session.open(CCftWZ)
   elif item == "VVmHzX"   : self.VVmHzX()
   elif item == "VVe9S6"  : self.VVe9S6()
   elif item == "VVexP4"  : self.VVexP4()
   elif item == "ScreenSize"   : FFoB4k(self, "Width\t: %s\nHeight\t: %s" % (FFrRKK()[0], FFrRKK()[1]))
   elif item == "Locale"    : CC2TkW.VVdHN0(self)
   elif item == "Processor"   : self.VVwtKr()
   elif item == "OperatingSystem"  : FFYQXW(self, "uname -a")
   elif item == "drivers"    : self.VVGQhh()
   elif item == "SystemUsers"   : FFYQXW(self, "id")
   elif item == "LoggedInUsers"  : FFYQXW(self, "who -a", consFont=True)
   elif item == "Uptime"    : FFYQXW(self, "uptime")
   elif item == "HostName"    : FFYQXW(self, "hostname")
   elif item == "MACAddress"   : self.VV72wz()
   elif item == "NetworkConfiguration" : FFYQXW(self, "ifconfig %s %s" % (FFP1gK("HWaddr", VVbRZL), FFP1gK("addr:", VVXAXH)))
   elif item == "NetworkStatus"  : FFYQXW(self, "netstat -tulpn", VVGNdU=24, consFont=True)
   elif item == "VVv7CX"   : self.VVv7CX()
   elif item == "MountPoints"   : FFYQXW(self, "mount %s" % (FFP1gK(" on ", VVXAXH)))
   elif item == "FileSystemTable"  : FFYQXW(self, "cat /etc/fstab", VVGNdU=24, consFont=True)
   elif item == "USB_Devices"   : FFYQXW(self, "lsusb")
   elif item == "listBlockDevices"  : FFYQXW(self, "blkid")
   elif item == "DirectorySize"  : FFYQXW(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVWiG3="Reading size ...")
   elif item == "Memory"    : FFYQXW(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules" : self.VVIKFu()
   elif item == "RunningProcesses"  : FFYQXW(self, "ps", consFont=True)
   elif item == "ProcessesOpenFiles" : FFYQXW(self, "lsof", consFont=True)
   elif item == "DreamBoxBootloader"  : self.VVkr7A()
   else        : self.close()
 def VV72wz(self):
  res = FFjwNC("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFoB4k(self, txt)
  else:
   FFYQXW(self, "ip link")
 def VV5GNr(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFYEhL(cmd)
  return lines
 def VVubIp(self, lines, headerRepl, widths, VV0CnX):
  VVsLLE = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVsLLE.append(parts)
  if VVsLLE and len(header) == len(widths):
   VVsLLE.sort(key=lambda x: x[0].lower())
   FFDpub(self, None, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=28, VVcmLr=1)
   return True
  else:
   return False
 def VVv7CX(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFjwNC(cmd)
  if not "invalid option" in txt:
   lines  = self.VV5GNr(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VV0CnX = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVubIp(lines, headerRepl, widths, VV0CnX)
  else:
   cmd = "df -h"
   lines  = self.VV5GNr(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VV0CnX = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVubIp(lines, headerRepl, widths, VV0CnX)
  if not allOK:
   lines = FFYEhL(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FF55ZU(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VViZMT:
     note = "\n%s" % FF8oA9("Green = Mounted Partitions", VViZMT)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVXAXH
     elif line.endswith(mountList) : color = VViZMT
     else       : color = VVD4un
     txt += FF8oA9(line, color) + "\n"
    FFoB4k(self, txt + note)
   else:
    FFOyl1(self, "Not data from system !")
 def VVIKFu(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VV5GNr(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VV0CnX = (LEFT , CENTER, LEFT )
  allOK = self.VVubIp(lines, headerRepl, widths, VV0CnX)
  if not allOK:
   FFYQXW(self, cmd)
 def VVGQhh(self):
  cmd = FFRkrW(VVOApa, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFYQXW(self, cmd)
  else : FFvp5w(self)
 def VVwtKr(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFYQXW(self, cmd)
 def VVkr7A(self):
  cmd = FFRkrW(VVCCMr, "| grep secondstage")
  if cmd : FFYQXW(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFvp5w(self)
 def VVmHzX(self):
  c = VViZMT
  VVcuvv = []
  VVcuvv.append((FF8oA9("Box Type"  , c), FF8oA9(self.VVQzlZ("boxtype").upper(), c)))
  VVcuvv.append((FF8oA9("Board Version", c), FF8oA9(self.VVQzlZ("board_revision") , c)))
  VVcuvv.append((FF8oA9("Chipset"  , c), FF8oA9(self.VVQzlZ("chipset")  , c)))
  VVcuvv.append((FF8oA9("S/N"   , c), FF8oA9(self.VVQzlZ("sn")    , c)))
  VVcuvv.append((FF8oA9("Version"  , c), FF8oA9(self.VVQzlZ("version")  , c)))
  VVp0Xy   = []
  VVHHw1 = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVHHw1 = SystemInfo[key]
     else:
      VVp0Xy.append((FF8oA9(str(key), VVoIYV), FF8oA9(str(SystemInfo[key]), VVoIYV)))
  except:
   pass
  if VVHHw1:
   VVXdWI = self.VVJ7GI(VVHHw1)
   if VVXdWI:
    VVXdWI.sort(key=lambda x: x[0].lower())
    VVcuvv += VVXdWI
  if VVp0Xy:
   VVp0Xy.sort(key=lambda x: x[0].lower())
   VVcuvv += VVp0Xy
  if VVcuvv:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFDpub(self, None, header=header, VVcuvv=VVcuvv, VVbG6j=widths, VVGNdU=28, VVcmLr=1)
  else:
   FFoB4k(self, "Could not read info!")
 def VVQzlZ(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FF72md(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVJ7GI(self, mbDict):
  try:
   mbList = list(mbDict)
   VVcuvv = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVcuvv.append((FF8oA9(subject, VVXAXH), FF8oA9(value, VVXAXH)))
  except:
   pass
  return VVcuvv
 def VVe9S6(self):
  txt = self.VVNWBU("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVNWBU("/proc/bus/nim_sockets")
  if not txt: txt = self.VVBOyk()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFoB4k(self, txt)
 def VVBOyk(self):
  txt = ""
  VVYgG4 = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVYgG4("Slot Name" , slot.getSlotName())
     txt += FF8oA9(slotName, VVXAXH)
     txt += VVYgG4("Description"  , slot.getFullDescription())
     txt += VVYgG4("Frontend ID"  , slot.frontend_id)
     txt += VVYgG4("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVNWBU(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FF72md(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FF8oA9(line, VVXAXH)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVexP4(self):
  major   = pyVersion[0]
  minor   = pyVersion[1]
  micro   = pyVersion[2]
  releaselevel = pyVersion[3]
  serial   = pyVersion[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFoB4k(self, txt)
 @staticmethod
 def VVW12e():
  def VVYgG4(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VVYgG4(v,0), "/etc/issue.net": VVYgG4(v,1), "/etc/image-version": VVYgG4(v,2)}
  for p1, d in v.items():
   img = CCqRTV.VVekRm(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VVYgG4(v,0), p + "Plugins/": VVYgG4(v,1), VVtttO: VVYgG4(v,2), VVxCog: VVYgG4(v,3)}
  for p1, d in v.items():
   img = CCqRTV.VVAacq(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VVekRm(path, d):
  if fileExists(path):
   txt = FFFr8o(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VVAacq(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CCftWZ(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFPFsH(VVMjBN, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVtMHe = []
  VVtMHe.append(("Settings (All)"   , "Settings_All"   ))
  VVtMHe.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVtMHe.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVtMHe.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVtMHe.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVtMHe.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVtMHe.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VVXYuQ:
   VVtMHe.append(VVXGzj)
   VVtMHe.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVtMHe.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FFRFZg(self, VVtMHe=VVtMHe)
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFWIRJ(self["myMenu"])
  FFJI0m(self)
 def VV2Iyl(self):
  global VVsQSL
  VVsQSL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %ssettings" % VVKJQA
   grep = " | grep "
   if   item == "Settings_All"   : FFYQXW(self, cmd)
   elif item == "Settings_HotKeys"  : FFYQXW(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'")
   elif item == "Settings_ajp"   : FFYQXW(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME)
   elif item == "Settings_FHDG_17"  : FFYQXW(self, cmd + grep + "'config.plugins.setupGlass17.'")
   elif item == "Settings_Tuner_DiSEqC": FFYQXW(self, cmd + grep + "'config.Nims.'")
   elif item == "Settings_Plugins"  : FFYQXW(self, cmd + grep + "'.plugins.\|config.TS'")
   elif item == "Settings_Usage"  : FFYQXW(self, cmd + grep + "'.usage.'")
   elif item == "Settings_TimeZone" : FFYQXW(self, cmd + grep + "'.timezone.'")
   elif item == "Settings_Skin"  : FFYQXW(self, cmd + grep + "'.skin.'")
   else        : self.close()
class CCAfrz(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFPFsH(VVMjBN, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVFUlr, VV7mz0, VVQSQp, camCommand = CCAfrz.VVaeiJ()
  self.VV7mz0 = VV7mz0
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VV7mz0:
   c = VV7z62 if VVQSQp else VVdVTX
   if   "oscam" in VV7mz0 : camName, oC = "OSCam", c
   elif "ncam"  in VV7mz0 : camName, nC = "NCam" , c
  VVtMHe = []
  VVtMHe.append(("OSCam Files" , "OSCamFiles" ))
  VVtMHe.append(("NCam Files" , "NCamFiles" ))
  VVtMHe.append(("CCcam Files" , "CCcamFiles" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((VVRuOi + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VVCMqU" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVtMHe.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVtMHe.append(VVXGzj)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  VVtMHe.append(FFQlwu(txt, "camInfo", VV7mz0, c))
  VVtMHe.append(VVXGzj)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VV7mz0:
   for item in camLst: VVtMHe.append(item)
  else:
   for item in camLst: VVtMHe.append((item[0], ))
  FFRFZg(self, VVtMHe=VVtMHe)
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFWIRJ(self["myMenu"])
  FFJI0m(self)
 def VV2Iyl(self):
  global VVsQSL
  VVsQSL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CCOc5e, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CCOc5e, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CCOc5e, "cccam"))
   elif item == "VVCMqU" : self.VVCMqU()
   elif item == "OSCamReaders"  : self.VVKP0h("os")
   elif item == "NSCamReaders"  : self.VVKP0h("n")
   elif item == "camInfo"   : FFjqfL(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CCAfrz.VVqm6b(self.session, CCvQPx.VVaxJJ)
   elif item == "camLiveReaders" : CCAfrz.VVqm6b(self.session, CCvQPx.VVkY7y)
   elif item == "camLiveLog"  : CCAfrz.VVqm6b(self.session, CCvQPx.VVa3tb)
   else       : self.close()
 def VVCMqU(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VVZAJU, FFZR2n())
  if fileExists(path):
   lines = FF72md("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VVYgG4 = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VVYgG4("label"    , "CCcam-Line-%d" % ndx))
      f.write(VVYgG4("description"  , "CCcam-Line-%d" % ndx))
      f.write(VVYgG4("protocol"   , "cccam"))
      f.write(VVYgG4("device"    , "%s,%s" % (host, port)))
      f.write(VVYgG4("user"    , User))
      f.write(VVYgG4("password"   , Pass))
      f.write(VVYgG4("fallback"   , "1"))
      f.write(VVYgG4("group"    , "64"))
      f.write(VVYgG4("cccversion"   , "2.3.2"))
      f.write(VVYgG4("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FFDeF8(self, "Output = %d Reader%s in:\n\n%s" % (tot, FFsfSO(tot), outFile))
   else:
    FFZD7H(self, "No valid CCcam lines", 1500)
  else:
   FFZD7H(self, "%s not found" % path, 1500)
 def VVKP0h(self, camPrefix):
  VVsLLE = self.VVmBxz(camPrefix)
  if VVsLLE:
   VVsLLE.sort(key=lambda x: int(x[0]))
   if self.VV7mz0 and self.VV7mz0.startswith(camPrefix):
    VV1kWx = ("Toggle State", self.VV3hrJ, [camPrefix], "Changing State ...")
   else:
    VV1kWx = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VV0CnX  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFDpub(self, None, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=26, VV1kWx=VV1kWx, VVEMdg=True)
 def VVmBxz(self, camPrefix):
  readersFile = self.VVFUlr + camPrefix + "cam.server"
  VVsLLE = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FF72md(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVsLLE.append((str(len(VVsLLE) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVsLLE:
    FFOyl1(self, "No readers found !")
  else:
   FFbiIe(self, readersFile)
  return VVsLLE
 def VV3hrJ(self, VVdesl, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVFUlr, camPrefix)
  readerState  = VVdesl.VVxBD7(1)
  readerLabel  = VVdesl.VVxBD7(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCAfrz.VV7W4a(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVdesl.VVaW1B()
    FFOyl1(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVsLLE = self.VVmBxz(camPrefix)
   if VVsLLE:
    VVdesl.VV87pY(VVsLLE)
  else:
   VVdesl.VVaW1B()
 @staticmethod
 def VV7W4a(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FF72md(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFOyl1(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFOyl1(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFbiIe(SELF, confFile)
   return None
  if not iRequest:
   FFOyl1(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CCAfrz.VV6Dqd(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FFOyl1(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VV6Dqd(SELF):
  if iElem:
   return True
  else:
   FFOyl1(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVqm6b(session, VVRof7):
  VVFUlr, VV7mz0, VVQSQp, camCommand = CCAfrz.VVaeiJ()
  if VV7mz0:
   runLog = False
   if   VVRof7 == CCvQPx.VVaxJJ : runLog = True
   elif VVRof7 == CCvQPx.VVkY7y : runLog = True
   elif not VVQSQp          : FFcZkm(session, message="SoftCam not started yet!")
   elif fileExists(VVQSQp)        : runLog = True
   else             : FFcZkm(session, message="File not found !\n\n%s" % VVQSQp)
   if runLog:
    session.open(BF(CCvQPx, VVFUlr=VVFUlr, VV7mz0=VV7mz0, VVQSQp=VVQSQp, VVRof7=VVRof7))
  else:
   FFcZkm(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VVaeiJ():
  VVFUlr = "/etc/tuxbox/config/"
  VV7mz0 = None
  VVQSQp  = None
  camCommand = FFvL4V("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VV7mz0 = "oscam"
   elif camCmd.startswith("ncam") : VV7mz0 = "ncam"
  if VV7mz0:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FFFr8o(path), IGNORECASE)
     if span:
      VVFUlr = FFDpEI(span.group(1))
      break
   else:
    path = FFvL4V(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FFDpEI(path)
    if pathExists(path):
     VVFUlr = path
   tFile = FFDpEI(VVFUlr) + VV7mz0 + ".conf"
   tFile = FFvL4V("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VVQSQp = tFile
  return VVFUlr, VV7mz0, VVQSQp, camCommand
class CCOc5e(Screen):
 def __init__(self, VVY05o, session, args=0):
  self.skin, self.skinParam = FFPFsH(VVMjBN, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVFUlr, VV7mz0, VVQSQp, camCommand = CCAfrz.VVaeiJ()
  if   VVY05o == "ncam" : self.prefix = "n"
  elif VVY05o == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVtMHe = []
  if self.prefix == "":
   VVtMHe.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVtMHe.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVtMHe.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVtMHe.append(("constant.cw"         , "x_constant_cw" ))
   VVtMHe.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVtMHe.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVtMHe.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVtMHe.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVtMHe.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVtMHe.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVtMHe.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVtMHe.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVtMHe.append(VVXGzj)
   VVtMHe.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVtMHe.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVtMHe.append(VVXGzj)
   VVtMHe.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVtMHe.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVtMHe.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFRFZg(self, VVtMHe=VVtMHe)
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFWIRJ(self["myMenu"])
  FFJI0m(self)
 def VV2Iyl(self):
  global VVsQSL
  VVsQSL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFxhJI(self, "/var/etc/CCcam.cfg")
   elif item == "c_ecm_info"  : FFxhJI(self, "/tmp/ecm.info")
   elif item == "x_AutoRoll_Key" : FFxhJI(self, self.VVFUlr + "AutoRoll.Key")
   elif item == "x_constant_cw" : FFxhJI(self, self.VVFUlr + "constant.cw")
   elif item == "x_cam_ccache"  : self.VV7ezr("cam.ccache")
   elif item == "x_cam_conf"  : self.VV7ezr("cam.conf")
   elif item == "x_cam_dvbapi"  : self.VV7ezr("cam.dvbapi")
   elif item == "x_cam_provid"  : self.VV7ezr("cam.provid")
   elif item == "x_cam_server"  : self.VV7ezr("cam.server")
   elif item == "x_cam_services" : self.VV7ezr("cam.services")
   elif item == "x_cam_srvid2"  : self.VV7ezr("cam.srvid2")
   elif item == "x_cam_user"  : self.VV7ezr("cam.user")
   elif item == "x_SEP"   : pass
   elif item == "x_SoftCam_Key" : self.VVeGEC()
   elif item == "x_CCcam_cfg"  : FFxhJI(self, self.VVFUlr + "CCcam.cfg")
   elif item == "x_SEP"   : pass
   elif item == "x_cam_log"  : FFxhJI(self, pathTmp + self.prefix + "cam.log")
   elif item == "x_cam_log_prev" : FFxhJI(self, pathTmp + self.prefix + "cam.log-prev")
   elif item == "x_cam_pid"  : FFxhJI(self, pathTmp + self.prefix + "cam.pid")
   else       : self.close()
 def VV7ezr(self, fileName):
  FFxhJI(self, self.VVFUlr + self.prefix + fileName)
 def VVeGEC(self):
  path = self.VVFUlr + "SoftCam.Key"
  if fileExists(path) : FFxhJI(self, path)
  else    : FFxhJI(self, path.replace(".Key", ".key"))
class CCvQPx(Screen):
 VVaxJJ  = 0
 VVkY7y = 1
 VVa3tb = 2
 def __init__(self, session, VVFUlr="", VV7mz0="", VVQSQp="", VVRof7=VVaxJJ):
  self.skin, self.skinParam = FFPFsH(VVNC84, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVQSQp   = VVQSQp
  self.VVRof7  = VVRof7
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVFUlr + VV7mz0 + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VV7mz0 : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVFUlr, self.camPrefix)
  if self.VVRof7 == self.VVaxJJ:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVRof7 == self.VVkY7y:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFRFZg(self, self.Title, addScrollLabel=True)
  FFKdfz(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVJAPl
  self.onShown.append(self.VVnLQg)
  self.onClose.append(self.onExit)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  self["myLabel"].VV4U7z(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFFlxX(self)
  self.VVJAPl()
 def onExit(self):
  self.timer.stop()
 def VVnt2W(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVruGP)
  except:
   self.timer.callback.append(self.VVruGP)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFZD7H(self, "Started", 1000)
 def VVkfgr(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVruGP)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFZD7H(self, "Stopped", 1000)
 def VVJAPl(self):
  if self.timerRunning:
   self.VVkfgr()
  else:
   self.VVnt2W()
   if self.VVRof7 == self.VVaxJJ or self.VVRof7 == self.VVkY7y:
    if self.VVRof7 == self.VVaxJJ : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCAfrz.VV7W4a(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFkvVR(self.VV5dTq)
    else:
     self.close()
   else:
    self.VVlsJr()
 def VVruGP(self):
  if self.timerRunning:
   if   self.VVRof7 == self.VVaxJJ : self.VVPYdK()
   elif self.VVRof7 == self.VVkY7y : self.VVPYdK()
   else            : self.VVlsJr()
 def VVlsJr(self):
  if fileExists(self.VVQSQp):
   fTime = FFt4wC(os.path.getmtime(self.VVQSQp))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVQQyJ(), VVSDbk=VViudQ)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVQSQp)
 def VV5dTq(self):
  self.VVPYdK()
 def VVPYdK(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FF8oA9("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VV8ETX))
   self.camWebIfErrorFound = True
   self.VVkfgr()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVRof7 == self.VVaxJJ : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FF8oA9("Error while parsing data elements !\n\nError = %s" % str(e), VVOr14)
   self.camWebIfErrorFound = True
   self.VVkfgr()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVDSeO(root)
  self["myLabel"].setText(txt, VVSDbk=VViudQ)
  self["myBar"].setText("Last Update : %s" % FFQs05())
 def VVDSeO(self, rootElement):
  def VVYgG4(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVRof7 == self.VVaxJJ:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FF8oA9(status, VViZMT)
    else          : status = FF8oA9(status, VVOr14)
    txt += SEP + "\n"
    txt += VVYgG4("Name"  , name)
    txt += VVYgG4("Description" , desc)
    txt += VVYgG4("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVYgG4("Protocol" , protocol)
    txt += VVYgG4("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FF8oA9("Yes", VViZMT)
    else    : enabTxt = FF8oA9("No", VVOr14)
    txt += SEP + "\n"
    txt += VVYgG4("Label"  , label)
    txt += VVYgG4("Protocol" , protocol)
    txt += VVYgG4("Enabled" , enabTxt)
  return txt
 def VVQQyJ(self):
  lines = FFYEhL("tail -n %d %s" % (100, self.VVQSQp))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VV4mV2 + line[:19] + VVD4un + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VVmV2z + "WebIf" + VVD4un)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VVoIYV + h1 + h2 + VVD4un + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VViZMT + span.group(2) + VVRuOi + span.group(3) + VVD4un + span.group(4)
    line = self.VVzCAg(line, VVRuOi, ("(webif)", ))
    line = self.VVzCAg(line, VVRuOi, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VVzCAg(line, VViZMT, ("OSCam", "NCam", "log switched"))
    line = self.VVzCAg(line, VVtchu, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVXAXH + line[ndx + 3:] + VVD4un
   elif line.startswith("----") or ">>" in line:
    line = FF8oA9(line, VV7V3G)
   txt += line + "\n"
  return txt
 def VVzCAg(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVD4un + t3
  return line
class CCYdfM(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFPFsH(VVMjBN, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVtMHe = []
  VVtMHe.append(("Backup Channels"    , "VVdSE3"   ))
  VVtMHe.append(("Restore Channels"    , "Restore_Channels"  ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Backup SoftCAM Files"   , "VVj48E" ))
  VVtMHe.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVtMHe.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVtMHe.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Backup Network Settings"  , "VVVkZ1"   ))
  VVtMHe.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVXYuQ:
   VVtMHe.append(VVXGzj)
   VVtMHe.append((VV8ETX + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME    , "VV87wB"   ))
   VVtMHe.append((VViZMT + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VV4y0R), "createMyIpk"   ))
   VVtMHe.append((VViZMT + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VV4y0R), "createMyDeb"   ))
   VVtMHe.append((VVoIYV + "Create %s TAR (Absolute Path)" % PLUGIN_NAME    , "createMyTar"   ))
   VVtMHe.append((VVoIYV + "Decode %s Crash Report"   % PLUGIN_NAME    , "VVFsFm" ))
   VVtMHe.append((VVoIYV + "Show Windows Stats"           , "VVY1fL" ))
  FFRFZg(self, VVtMHe=VVtMHe)
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFWIRJ(self["myMenu"])
  FFJI0m(self)
 def VV2Iyl(self):
  global VVsQSL
  VVsQSL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVdSE3"    : self.VVdSE3()
   elif item == "Restore_Channels"    : self.VVtj0v("channels_backup*.tar.gz", self.VVvrVd, isChan=True)
   elif item == "VVj48E"   : self.VVj48E()
   elif item == "Restore_SoftCAM_Files"  : self.VVtj0v("softcam_backup*.tar.gz", self.VVbymj)
   elif item == "Backup_TunerDiSEqC"   : self.VV6dpK("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVtj0v("tuner_backup*.backup", BF(self.VVX6cO, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VV6dpK("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVtj0v("hotkey_*backup*.backup", BF(self.VVX6cO, "misc"))
   elif item == "VVVkZ1"    : self.VVVkZ1()
   elif item == "Restore_Network"    : self.VVtj0v("network_backup*.tar.gz", self.VVv0SE)
   elif item == "VV87wB"     : FFgBNQ(self, BF(FFbA1i, self, BF(CCYdfM.VV87wB, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVVNPG(False)
   elif item == "createMyDeb"     : self.VVVNPG(True)
   elif item == "createMyTar"     : self.VVzAcm()
   elif item == "VVFsFm"   : self.VVFsFm()
   elif item == "VVY1fL"    : CCYdfM.VVY1fL(self)
 @staticmethod
 def VVUlNf(SELF):
  OBF_Path = VVwuoS + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try: from .OBF import obf
   except: import obf
   reload(obf)
   return obf
  else:
   FFbiIe(SELF, OBF_Path)
   return None
 @staticmethod
 def VVY1fL(SELF):
  obf = CCYdfM.VVUlNf(SELF)
  if obf:
   txt, title = obf.windowsStats()
   FFoB4k(SELF, txt, title=title, outputFileToSave="WinStat")
 @staticmethod
 def VV87wB(SELF):
  obf = CCYdfM.VVUlNf(SELF)
  if obf:
   txt, err = obf.fixCode(VVwuoS, VVQHC8, VV4y0R)
   if err : FFOyl1(SELF, err)
   else : FFoB4k(SELF, txt)
 def VVVNPG(self, VVlAOK):
  OBF_Path = VVwuoS + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFOyl1(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  FFqSkC("rm -f %s__pycache__/" % VVwuoS)
  FFqSkC("mv -f '%smain.py' '%s'" % (VVwuoS, OBF_Path))
  FFqSkC("mv -f '%splugin.py' '%s'" % (VVwuoS, OBF_Path))
  FFqSkC("cp -f %s*main_final.py %splugin.py" % (OBF_Path, VVwuoS))
  self.session.openWithCallback(self.VVvqkO, BF(CC3sVu, path=VVwuoS, VVlAOK=VVlAOK))
 def VVvqkO(self):
  FFqSkC("mv -f %s %s" % (VVwuoS + "OBF/main.py" , VVwuoS))
  FFqSkC("mv -f %s %s" % (VVwuoS + "OBF/plugin.py", VVwuoS))
 def VVFsFm(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFOyl1(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFOyl1(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVDY04("%s*.list" % path)
  if err:
   FFbiIe(self, path + "*.list")
   return
  srcF, err = self.VVDY04("%s*main_final.py" % path)
  if err:
   FFbiIe(self, path + "*.final.py")
   return
  VVcuvv = []
  for f in files:
   f = os.path.basename(f)
   VVcuvv.append((f, f))
  FFECK9(self, BF(self.VVvdEc, path, codF, srcF), VVtMHe=VVcuvv)
 def VVvdEc(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFbiIe(self, logF)
   else     : FFbA1i(self, BF(self.VVkEYj, logF, codF, srcF))
 def VVkEYj(self, logF, codF, srcF):
  lst  = []
  lines = FF72md(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFOyl1(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVRPWb(lst, logF, newLogF)
  totSrc  = self.VVRPWb(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFoB4k(self, txt)
 def VVDY04(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVRPWb(self, lst, f1, f2):
  txt = FFFr8o(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVzAcm(self):
  VVcuvv = []
  VVcuvv.append("%s%s" % (VVwuoS, "*.py"))
  VVcuvv.append("%s%s" % (VVwuoS, "*.png"))
  VVcuvv.append("%s%s" % (VVwuoS, "*.xml"))
  VVcuvv.append("%s"  % (VV2V68))
  FFnwui(self, VVcuvv, "%s_%s" % (PLUGIN_NAME, VVQHC8), addTimeStamp=False)
 def VVdSE3(self):
  path1 = VVKJQA
  path2 = "/etc/tuxbox/"
  VVcuvv = []
  VVcuvv.append("%s%s" % (path1, "*.tv"))
  VVcuvv.append("%s%s" % (path1, "*.radio"))
  VVcuvv.append("%s%s" % (path1, "*list"))
  VVcuvv.append("%s%s" % (path1, "lamedb*"))
  VVcuvv.append("%s%s" % (path2, "*.xml"))
  FFnwui(self, VVcuvv, self.VV3csM("channels_backup"), addTimeStamp=True)
 def VVj48E(self):
  VVcuvv = []
  VVcuvv.append("/etc/tuxbox/config/")
  VVcuvv.append("/usr/keys/")
  VVcuvv.append("/usr/scam/")
  VVcuvv.append("/etc/CCcam.cfg")
  FFnwui(self, VVcuvv, self.VV3csM("softcam_backup"), addTimeStamp=True)
 def VVVkZ1(self):
  VVcuvv = []
  VVcuvv.append("/etc/hostname")
  VVcuvv.append("/etc/default_gw")
  VVcuvv.append("/etc/resolv.conf")
  VVcuvv.append("/etc/wpa_supplicant*.conf")
  VVcuvv.append("/etc/network/interfaces")
  VVcuvv.append("%snameserversdns.conf" % VVKJQA)
  FFnwui(self, VVcuvv, self.VV3csM("network_backup"), addTimeStamp=True)
 def VV3csM(self, fName):
  img = CCqRTV.VVW12e()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VVvrVd(self, fileName=None):
  if fileName:
   FFgBNQ(self, BF(FFbA1i, self, BF(self.VVaicY, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VVaicY(self, fileName):
  path = "%s%s" % (VVZAJU, fileName)
  if fileExists(path):
   if CCVnYx.VVed9k(path):
    VV7eR1 , VVfT9H = CCwuBY.VVxOqT()
    VVJVV4, VVUBU4 = CCwuBY.VVkOHy()
    cmd  = FFb0lc("cd %s" % VVKJQA)
    cmd += FFb0lc("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VVfT9H, VVUBU4))
    cmd += "tar -xzf '%s' -C /" % path
    ok = FFqSkC(cmd)
    FFjaui()
    if ok: FFDeF8(self, "Channels Restored.")
    else : FFOyl1(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FFOyl1(self, "Invalid tar file:\n\n%s" % path)
  else:
   FFbiIe(self, path)
 def VVbymj(self, fileName=None):
  if fileName:
   FFgBNQ(self, BF(self.VVno6d, fileName), "Overwrite SoftCAM files ?")
 def VVno6d(self, fileName):
  fileName = "%s%s" % (VVZAJU, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % SEP
   note = "You may need to restart your SoftCAM."
   FFk2dP(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFP1gK(note, VVXAXH), sep))
  else:
   FFbiIe(self, fileName)
 def VVv0SE(self, fileName=None):
  if fileName:
   FFgBNQ(self, BF(self.VVAH3A, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVAH3A(self, fileName):
  fileName = "%s%s" % (VVZAJU, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFyrLj(self,  cmd)
  else:
   FFbiIe(self, fileName)
 def VVtj0v(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FFmlRV()
  if pathExists(VVZAJU):
   myFiles = FF0KZb(VVZAJU, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVcuvv = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVcuvv.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VVI3Sz = ("Sat. List", self.VVKaRW)
    elif isChan and iTar: VVI3Sz = ("Bouquets Importer", CCHaaH.VVg6eg)
    else    : VVI3Sz = None
    FFECK9(self, callBackFunction, title=title, width=1200, VVtMHe=VVcuvv, VVI3Sz=VVI3Sz, VVNhLF=VVZAJU)
   else:
    FFOyl1(self, "No files found in:\n\n%s" % VVZAJU, title)
  else:
   FFOyl1(self, "Path not found:\n\n%s" % VVZAJU, title)
 def VV6dpK(self, filePrefix, wordsFilter):
  settingFile = "%ssettings" % VVKJQA
  tCons = CC2xQD()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), BF(self.VVx35P, filePrefix))
 def VVx35P(self, filePrefix, result, retval):
  title = FFmlRV()
  if pathExists(VVZAJU):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFOyl1(self, "Cannot read settings file", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVZAJU, filePrefix, self.VV3csM(""), FFZR2n())
    try:
     VVcuvv = str(result.strip()).split()
     if VVcuvv:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVcuvv:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (SEP, FF8oA9(fName, VVXAXH), SEP)
       FFoB4k(self, txt, title=title, VVSDbk=VViudQ)
      else:
       FFOyl1(self, "File creation failed!", title)
     else:
      FFOyl1(self, "Parameters not found in settings file.", title)
    except IOError as e:
     FFqSkC("rm %s" % fName)
     FFOyl1(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     FFqSkC("rm %s" % fName)
     FFOyl1(self, "Error while writing file.")
  else:
   FFOyl1(self, "Path not found:\n\n%s" % VVZAJU, title)
 def VVX6cO(self, mode, path=None):
  if path:
   path = "%s%s" % (VVZAJU, path)
   if fileExists(path):
    lines = FF72md(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFgBNQ(self, BF(self.VVbmiy, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFAyN7(self, path, title=FFmlRV())
   else:
    FFbiIe(self, path)
 def VVbmiy(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  finalList = []
  for line in newList:
   if line.strip() and not line in finalList:
    finalList.append(line)
  VVpHRB = []
  sFile = "/etc/enigma2/settings"
  tFile = "/tmp/ajp_tmp"
  VVpHRB.append("echo -e 'Reading current settings ...'")
  VVpHRB.append("cat %s | grep -v '%s' > %s" % (sFile, grepFilter, tFile))
  settingsLines = "echo -e '"
  for line in finalList:
   settingsLines += line
  settingsLines = settingsLines.strip()
  settingsLines += "' >> %s" % tFile
  VVpHRB.append("echo -e 'Preparing new settings ...'")
  VVpHRB.append(settingsLines)
  VVpHRB.append("echo -e 'Applying new settings ...'")
  VVpHRB.append("mv -f %s %s" % (tFile, sFile))
  FFRrmn(self, VVpHRB)
 def VVKaRW(self, selectionObj, path):
  if not path:
   return
  path = VVZAJU + path
  if not fileExists(path):
   FFbiIe(self, path)
   return
  txt = FFFr8o(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   txt = ""
   for item in satList:
    txt += "%s\t%s\n" % (item[0], FFxdmJ(item[1]))
   FFoB4k(self, txt, title="Satellites List")
  else:
   FFOyl1(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCHaaH():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VVg6eg(SELF, fName):
  bi = CCHaaH(SELF)
  bi.instance = bi
  bi.VV2Czo(SELF, fName)
 @staticmethod
 def VVNOhr(SELF):
  bi = CCHaaH(SELF)
  bi.instance = bi
  bi.VVIJO8()
 def VV2Czo(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VVZAJU + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FFbA1i(waitObg, self.VV6ra6, title="Reading bouquets ...")
  else      : self.VV3ox0(self.filePath)
 def VVoafo(self, txt) : FFOyl1(self.SELF, txt, title=self.Title)
 def VVl1IZ(self, txt)  : FFZD7H(self, txt, 1500)
 def VV3ox0(self, path) : FFbiIe(self.SELF, path, title=self.Title)
 def VVIJO8(self):
  if pathExists(VVZAJU):
   lst = FF0KZb(VVZAJU, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VV5a75())
   if len(lst) > 0:
    VVtMHe = []
    for item in lst:
     item = os.path.basename(item)
     txt = FF8oA9(item, VVRuOi) if item.endswith(".zip") else item
     VVtMHe.append((txt, item))
    VVtMHe.sort(key=lambda x: x[1].lower())
    VVyXO1 = self.VV23hL
    FFECK9(self.SELF, self.VVvtCl, minRows=3, title=self.Title, width=1200, VVtMHe=VVtMHe, VVyXO1=VVyXO1, VVNhLF=VVZAJU, VVaRsg="#22111111", VVWgai="#22111111")
   else:
    self.VVoafo("No valid backup files found in:\n\n%s" % VVZAJU)
  else:
   self.VVoafo("Backup Directory not found:\n\n%s" % VVZAJU)
 def VV23hL(self, item=None):
  if item:
   VVkbkP, txt, fName, ndx = item
   self.VV2Czo(VVkbkP, fName)
 def VVvtCl(self, item=None):
  if not item and self.instance:
   del self.instance
 def VV5a75(self):
  files = FF0KZb(VVZAJU, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VV6ra6(self):
  lines, err = CCHaaH.VVJH1K(self.filePath, "bouquets.tv")
  if err:
   self.VVoafo(err)
   return
  bTvSortLst  = self.VV4aqw(lines)
  lines, err = CCHaaH.VVJH1K(self.filePath, "bouquets.radio")
  if err:
   self.VVoafo(err)
   return
  bRadSortLst = self.VV4aqw(lines)
  VVsLLE = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VVCn0i(f, mode, len(VVsLLE), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VVsLLE.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VVCn0i(f, mode, len(VVsLLE), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VVCn0i(f, mode, len(VVsLLE), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VVsLLE.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VVCn0i(f, mode, len(VVsLLE), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VVsLLE:
   VVsLLE.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VVsLLE): VVsLLE[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VVsLLE):
     if key == os.path.basename(row[9]):
      VVsLLE = VVsLLE[:ndx+1] + lst + VVsLLE[ndx+1:]
      break
   for ndx, item in enumerate(VVsLLE): VVsLLE[ndx][0] = str(ndx + 1)
   VVSJJk = "#11000600"
   VVMWQK  = ("Show Services" , self.VVJfhj  , [], "Reading ..." )
   VVZArZ = (""    , self.VVikfI, [])
   VVM9Pm = ("Options"  , self.VVhIRL, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "S.Relay" , "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 36   , 7  , 7   , 7  , 7  , 7   , 7   , 7   , 8   ,  0.01 )
   VV0CnX  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER , CENTER ,  LEFT )
   FFDpub(self.SELF, None, title=self.Title, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=24, VVMWQK=VVMWQK, VVZArZ=VVZArZ, VVM9Pm=VVM9Pm, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVaRsg=VVSJJk, VVWgai=VVSJJk, VVSJJk=VVSJJk, VVYCZ6="#00004455", VVTjte="#0a282828")
  else:
   self.VVoafo("No valid bouquets in:\n\n%s" % self.filePath)
 def VV4aqw(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VVikfI(self, VVdesl, title, txt, colList):
  FFoB4k(self.SELF, FF3gfV(txt), title=title)
 def VVhIRL(self, VVdesl, title, txt, colList):
  mSel = CCB2u5(self.SELF, VVdesl)
  if VVdesl.VVcTnU:
   totSel = VVdesl.VVLHWg()
   if totSel: VVtMHe = [("Import %s Bouquet%s" % (FF8oA9(str(totSel), VViZMT), FFsfSO(totSel)), "imp")]
   else  : VVtMHe = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FF8oA9(bName, VViZMT)
   VVtMHe = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FFbA1i, VVdesl, BF(CCHaaH.VVwpiQ, self.SELF, VVdesl, self.filePath))}
  mSel.VVcQQV(VVtMHe, cbFncDict)
 def VVJfhj(self, VVdesl, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CCHaaH.VVJH1K(self.filePath, "lamedb")
   if err:
    self.VVoafo(err)
    return
   dbServLst = CCwuBY.VVvZpb(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName = VVdesl.VV1blE()
   lines, err = CCHaaH.VVJH1K(self.filePath, os.path.basename(fName))
   if err:
    self.VVoafo(err)
    return
   VVsLLE = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VVsLLE.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VVsLLE.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VVsLLE.append((span.group(1).strip() or "-", "Stream Relay" if FF81BD(line) else "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VVsLLE.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VVsLLE.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CCwuBY.VVp10c(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VVsLLE.append((name.strip() or "-", FFbQ09(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VVsLLE):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CCHaaH.VVJH1K(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VVsLLE[ndx] = (bName, descr)
   if VVsLLE:
    VVSJJk = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VV0CnX = (LEFT  , CENTER)
    FFDpub(self.SELF, None, title="Services in : %s" % bName, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=28, VVaRsg=VVSJJk, VVWgai=VVSJJk, VVSJJk=VVSJJk, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FFZD7H(VVdesl, err, 1500)
  else : VVdesl.VVaW1B()
 def VVCn0i(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totSRelay = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VVoafo("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif FF81BD(line)             : totSRelay += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VVc2G6(var):
   return str(var) if var else VVdZck + str(var)
  totItem = VVXAXH + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VV8ETX   , str(totBnb)
  elif isSubB : bColor, totBnb  = VVRuOi, "Sub-B."
  else  : bColor, totBnb = ""      , VVc2G6(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VVc2G6(totDVB), VVc2G6(totIptv), VVc2G6(totSRelay), VVc2G6(totLoc), VVc2G6(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VVwpiQ(SELF, VVdesl, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVKJQA + "bouquets.tv"
  radBouquetFile = VVKJQA + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FFbiIe(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FFbiIe(SELF, radBouquetFile, title=title)
   return
  isMulti = VVdesl.VVcTnU
  if isMulti : rows = VVdesl.VVbgN8()
  else  : rows = [VVdesl.VV1blE()]
  for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FFOyl1(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FF3gfV(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FF3gfV(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVKJQA + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVKJQA + newFile
    CCHaaH.VVMubW(archPath, fName, VVKJQA, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   FF2Usq(tvBouquetFile)
   FF2Usq(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CCHaaH.VVnMAc(SELF, archPath, bList)
   FFjaui()
  txt  = FF8oA9("Added:\n", VVRuOi)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FF8oA9("Imported to lamedab:\n", VVRuOi)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FF8oA9("Missing from archived lamedb:\n", VV8ETX)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FFoB4k(SELF, txt, title=title, width=1000)
 @staticmethod
 def VVnMAc(SELF, archPath, bList):
  VV7eR1, err = CCwuBY.VVJmSV(SELF, VVGHpD=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CCwuBY.VVwCXh(VV7eR1, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FF72md(VVKJQA + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CCwuBY.VVp10c(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CCwuBY.VVB9hs(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CCHaaH.VVYmTy(archPath, dbName)
   CCHaaH.VVMubW(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CCwuBY.VVwCXh(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CCwuBY.VVwCXh(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CCwuBY.VVwCXh(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CCwuBY.VVwCXh(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FFOlRe(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VV7eR1 + ".tmp"
   lines   = FF72md(VV7eR1)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   FFqSkC("mv -f '%s' '%s'" % (tmpDbFile, VV7eR1))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VVc25b(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VVYmTy(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VVMubW(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VVJH1K(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CCGIk4():
 def __init__(self):
  self.projTitle   = "Package Creator"
  self.projPrefix   = "ajpanel_package_"
  self.projMainPath  = CFG.packageOutputPath.getValue()
  self.projName   = ""
  self.projPath   = ""
  self.projFile   = ""
  self.projMenu   = None
  self.projTable   = None
  self.projFile_control = ""
  self.projFile_preRm  = ""
  self.projFile_postRm = ""
  self.projFile_preInst = ""
  self.projFile_postInst = ""
  self.projLastDepends = ""
  self.VVHQJI()
 def VVHQJI(self):
  self.projPkg   = ""
  self.projVer   = ""
  self.projArch   = ""
  self.projFilesSize  = 0
  self.projTotalDirs  = 0
  self.projTotalFiles  = 0
  self.projAct_postInst = 0
  self.projAct_postRm  = 0
 def VVGmAc(self):
  FFbA1i(self, self.VV1L6d)
 def VV1L6d(self):
  if pathExists(self.projMainPath):
   lst = FFplXR(self.projMainPath)
   VVtMHe = []
   if lst:
    for path in lst:
     if path.startswith(self.projPrefix):
      prName = os.path.basename(path)
      VVtMHe.append((prName, prName))
   if VVtMHe:
    VVtMHe.sort(key=lambda x: x[1].lower())
    VVyXO1 = self.VVwnPR
    VVI3Sz = ("Add new project", self.VVTLrW)
    VVIL24= ("Delete Project" , self.VVrVKE)
    self.projMenu = FFECK9(self, None, VVtMHe=VVtMHe, width=1100, VVyXO1=VVyXO1, VVI3Sz=VVI3Sz, VVIL24=VVIL24, minRows=5, VVaRsg="#22111133", VVWgai="#22111133")
   else:
    FFgBNQ(self, self.VV9MOq, "No projects found !\n\n Create new project ?", title=self.projTitle)
  else:
   self.VV0tSK("Main Packages Directory not found:\n\n%s" % self.projMainPath)
 def VV9MOq(self)    : FFbA1i(self, BF(self.VV4Ajk))
 def VVTLrW(self, VVkbkP, item) : FFbA1i(self.projMenu, BF(self.VV4Ajk))
 def VV4Ajk(self):
  c = 0
  while True:
   c += 1
   name = "project_%d" % (c)
   if not pathExists("%s%s%s" % (self.projMainPath, self.projPrefix, name)):
    break
  self.VVWcDF(name)
 def VVWcDF(self, name, cbFnc=None):
  FFdnKb(self, cbFnc or self.VV3xaA, defaultText=name, title="New Project Name", message="Enter project name")
 def VV3xaA(self, name):
  if name and name.strip():
   path = "%s%s%s" % (self.projMainPath, self.projPrefix, name)
   if pathExists(path):
    FFgBNQ(self, BF(self.VVWcDF, name), "Project directory already exists !\n\n Change name ?", title=self.projTitle)
   else:
    err = FFCZGy(path)
    if err:
     self.VV0tSK("Cannot create project directory !\n\n %s" % err)
    else:
     item = os.path.basename(path)
     if self.projMenu: self.projMenu.VVSwKG((item, item), isSort=True)
     else   : self.VVGmAc()
 def VVrVKE(self, VVkbkP, path):
  if path:
   path = self.projMainPath + path
   if pathExists(path):
    totDir, totFile, totLink = FFv951(path)
    FFgBNQ(self, BF(self.VV5kZ2, path), "Project directory contains %d items.\n\n%s\n\nDelete ?" %(totDir + totFile + totLink, path), title=self.projTitle)
 def VV5kZ2(self, path):
  if FFqSkC("rm -rf '%s'" % path):
   self.projMenu.VVzjcG()
 def VVwnPR(self, item=None):
  if item:
   VVkbkP, txt, Dir, ndx = item
   self.VVHQJI()
   self.projName = os.path.basename(Dir)[len(self.projPrefix):]
   self.projPath = "%s%s/" % (self.projMainPath, Dir)
   self.projFile = "%s%s.cfg"  % (self.projPath, self.projName)
   self.projFile_control = self.projPath + "control"
   self.projFile_preRm  = self.projPath + "prerm"
   self.projFile_postRm = self.projPath + "postrm"
   self.projFile_preInst = self.projPath + "preinst"
   self.projFile_postInst = self.projPath + "postinst"
   tmplF = "%sajpanel_pkg" % VV2V68
   if not fileExists(self.projFile_control) and fileExists(tmplF):
    pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
    with open(self.projFile_control, "w") as f:
     for line in FF72md(tmplF, keepends=True):
      f.write(line.replace("xx1", pkg).replace("xx2", self.projName))
   if not fileExists(self.projFile):
    with open(self.projFile, "w") as f:
     sep = "#" * 80
     f.write("%s\n" % sep)
     f.write("%s Project\t: %s\n" % ("#", self.projName))
     f.write("%s Started\t: %s\n" % ("#", FFQs05()))
     f.write("%s\n" % sep)
   if fileExists(self.projFile): self.VVaI3w()
   else      : self.VV0tSK("Cannot create project file:\n\n%s" % self.projFile)
 def VVaI3w(self, VVkbkP=None, jmpDict=None):
  FFbA1i(VVkbkP or self.projTable or self, BF(self.VV9tQW, jmpDict))
 def VV9tQW(self, jmpDict):
  self.VVHQJI()
  pkgRows, ctrlRows, actnRows, fileRows, unknRows = [], [], [], [], []
  if fileExists(self.projFile_control):
   for lineNdx, line in enumerate(FF72md(self.projFile_control)):
    line = line.strip()
    if ":" in line:
     subj, val, rem = self.VVbIPy(line)
     pkgRows.append((str(lineNdx), "Control", subj, val, "", rem, ""))
  if not pkgRows:
   self.VV0tSK('Invalid "control" file:\n\n%s' % self.projFile_control)
   return
  for path in (self.projFile_preInst, self.projFile_postInst, self.projFile_preRm, self.projFile_postRm):
   size = val = ""
   if fileExists(path):
    val = path
    sz = FFF0Rr(path)
    if sz > -1: size = CCVnYx.VVI3LQ(sz, mode=4)
    else   : size = FF8oA9("Size error", VV8ETX)
   ctrlRows.append(("", "Script", os.path.basename(path), val, size, "", ""))
  for lineNdx, line in enumerate(FF72md(self.projFile)):
   lineNdx = str(lineNdx)
   line = line.strip()
   if line and not line.startswith("#"):
    validF = size = rem = ""
    if line.startswith("/"):
     path, fName, typ, size, rem, validF = self.VV7YOh(line, fileRows)
     fileRows.append((lineNdx, "Resource", typ or "Unknown", path, size, rem, validF))
    else:
     Title, val = self.VVPNGJ(line)
     if Title: actnRows.append((lineNdx, "Action", Title, val, size, rem, validF))
     else : unknRows.append((lineNdx, "?", "-", line, size, FF8oA9("Unknown value", VV8ETX), validF))
  for ndx, row in enumerate(actnRows):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   rem = ""
   if   fileExists(self.projFile_postInst) and Title == "postinst" : rem = "Ignored (if custom postinst)"
   elif fileExists(self.projFile_postRm  ) and Title == "postrm" : rem = "Ignored (if custom postrm)"
   if rem:
    actnRows[ndx] = (lineNdx, Section, Title, Value, Size, FF8oA9(rem, VV8ETX), ValidF)
  actnRows.sort(key=lambda x: x[2].lower())
  fileRows.sort(key=lambda x: (x[2].lower(), x[3].lower()))
  unknRows.sort(key=lambda x: x[3].lower())
  VVsLLE = pkgRows
  VVsLLE.extend(actnRows)
  VVsLLE.extend(ctrlRows)
  VVsLLE.extend(fileRows)
  VVsLLE.extend(unknRows)
  cDict = {"Control":"", "Action":"0c302636", "Script":"0a28281a", "Resource":"1100385a", "?":"11550000"}
  for ndx, row in enumerate(VVsLLE):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   color = cDict.get(Section, "")
   if color:
    if ValidF: Remarks = "%s%s" % (FF8oA9("Valid", VViZMT), " ... " + Remarks if Remarks else "")
    VVsLLE[ndx] = (lineNdx, "#b#%s#" % color + Section, Title, Value, Size, "#b#0a0b0b1b#" + Remarks, ValidF)
  if self.projTable:
   self.projTable.VV87pY(VVsLLE, tableRefreshCB=BF(self.VVLWm8, jmpDict) if jmpDict else None, isSort=False)
  else:
   bg = "#15000000"
   title = "%s : %s" % (self.projTitle, self.projName)
   VVZArZ = (""     , self.VVzQDs   , [])
   menuButtonFnc = (""     , self.VVqjos   , [])
   VVIzUv = ("Create Package"  , self.VV7o7Q , [])
   VVM9Pm = ("Post Install Action", self.VVsubI, [])
   VVRHhw = ("Edit File"   , self.VVQoct  , [])
   header  = ("lineNdx", "Section" , "Title" , "Value / Path", "Size", "Remarks" , "ValidF")
   widths  = (0  , 9   , 11  , 48   , 10 , 22  , 0   )
   VV0CnX = (CENTER , CENTER , LEFT  , LEFT   , CENTER, LEFT  , CENTER )
   self.projTable = FFDpub(self, None, title=title, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, width=1850, height=1040, VVGNdU=26, VVZArZ=VVZArZ, menuButtonFnc=menuButtonFnc, VVIzUv=VVIzUv, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw, searchCol=2
         , VVaRsg=bg, VVWgai=bg, VVSJJk=bg, VVYCZ6="#00664411", VVTjte="#00444444", VVIyj7="#08442211")
   self.projTable.VVLS8Z(self.VVudmX, True)
 def VVLWm8(self, jmpDict, VVdesl, title, txt, colList):
  self.projTable.VVQMdW(jmpDict)
 def VVudmX(self):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = self.projTable.VV1blE()
  if Section == "Control":
   txt = '"control" File'
  elif Section == "Script" :
   txt = "Script File"
   if Value.startswith("/") and fileExists(Value):
    txt = "Script File"
   else:
    self.projTable["keyBlue"].hide()
    return
  else:
   txt = "Project File"
  self.projTable["keyBlue"].show()
  self.projTable["keyBlue"].setText("Edit %s" % txt)
 def VVbIPy(self, line):
  def VVpFzx(patt, val, Len):
   if len(val) < Len   : return FF8oA9("Length error" , VV8ETX)
   elif not iMatch(patt, val) : return FF8oA9("Invalid format" , VV8ETX)
   else      : return ""
  subj, _, val = line.partition(":")
  val, rem = val.strip(), ""
  if   not self.projPkg  and subj == "Package"  : self.projPkg, rem = val, VVpFzx(r"^[a-z]+[a-z0-9+-_.]+$", val, 2)
  elif not self.projVer  and subj == "Version"  : self.projVer, rem = val, VVpFzx(r"^[a-zA-Z0-9_+-.~]*$" , val, 1)
  elif not self.projArch and subj == "Architecture": self.projArch = val
  return subj, val, rem
 def VV7YOh(self, path, fileRows):
  rem = note = validF = targetType = ""
  size = "-"
  isCtrl = False
  fName = os.path.basename(path)
  typ = FFMkON(path)
  path = FF55ZU(path)
  c = VV8ETX
  if   typ == "Mount" : rem = FF8oA9("Not allowed", c)
  elif not typ  : rem = FF8oA9("Not found", c)
  else:
   for item in fileRows:
    if item[3].strip() == path:
     rem = FF8oA9("Duplicate", c)
     break
   else:
    sz = -1
    skipSz = False
    if typ == "Directory":
     sz = FFOcJX(path)
    elif typ == "SymLink":
     targetPath = os.path.realpath(path)
     targetType = FFMkON(targetPath)
     if  targetType == "Mount"  : skipSz, rem = True, FF8oA9("Not allowed", c)
     elif targetType == "Directory" : sz = FFOcJX(targetPath)
     elif targetType == "File"  : sz = FFF0Rr(targetPath)
     else       : sz, rem = FFF0Rr(path), FF8oA9("Invalid", c)
     note = "%s%s%s" % (note, " ... " if note else "", "Linked to : %s" % targetPath)
    elif typ == "File":
     sz = FFF0Rr(path)
    if not skipSz:
     if sz > -1:
      validF = "" if rem else "1"
      if validF:
       if "Directory" in (typ, targetType) : self.projTotalDirs  += 1
       if "File" in (typ, targetType)  : self.projTotalFiles += 1
       self.projFilesSize += sz
      size = CCVnYx.VVI3LQ(sz, mode=4)
     else:
      size = FF8oA9("Size error", c)
    rem = "%s%s%s" % (rem, " ... " if rem else "", note)
  return path, fName, typ, size, rem, validF
 def VVPNGJ(self, line):
  Title = val = ""
  actDict = {"restart":1, "reboot":2 }
  span = iSearch(r"postinst\s*=\s*(.+)", line, IGNORECASE)
  if span:
   act = span.group(1).lower()
   self.projAct_postInst = actDict.get(act, 0)
   Title, val = "postinst", "%s after the package is installed" % act.capitalize()
  else:
   span = iSearch(r"postrm\s*=\s*(.+)", line, IGNORECASE)
   if span:
    act = span.group(1).lower()
    self.projAct_postRm = actDict.get(act, 0)
    Title, val = "postrm", "%s after the package is removed" % act.capitalize()
  return Title, val
 def VVQoct(self, VVdesl, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  if   Section == "Control": path, lineNdx = self.projFile_control, int(lineNdx)
  elif Section == "Script" : path, lineNdx = Value, 0
  else      : path, lineNdx = self.projFile, int(lineNdx)
  if fileExists(path) : CCiazU(self, path, VVCBqA=self.VVAMuI, curRowNum=lineNdx)
  else    : FFbiIe(self, path)
 def VVAMuI(self, fileChanged):
  if fileChanged:
   self.VVaI3w()
 def VV0tSK(self, txt):
  FFOyl1(self, txt, title=self.projTitle)
 def VVzQDs(self, VVdesl, title, txt, colList):
  tab = lambda x, y: "%s\t: %s\n" % (x, y)
  c = VVRuOi
  s  = FFHM5m("Current Row", c)
  s += title + "\n"
  s += txt + "\n"
  s += FFHM5m("Project", c)
  s += tab("File Name", self.projFile)
  s += tab("Valid Dirs", self.projTotalDirs)
  s += tab("Valid Files", self.projTotalFiles)
  s += tab("Total Size", CCVnYx.VVI3LQ(self.projFilesSize))
  FFoB4k(self, s, title="Project Info", width=1600)
 def VVqjos(self, VVdesl, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  c1, c2, c3 = VV7z62, VVdVTX, VVRuOi
  VVtMHe = []
  VVtMHe.append((c1 + "Add Resource File"  , "addFile" ))
  VVtMHe.append((c1 + "Add Resource Directory" , "addDir" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Change Package Name"   , "pkgNam" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((c2 + "Add Dependency"   , "addDep" ))
  VVtMHe.append((c2 + "Remove Dependency"  , "delDep" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Import Control File (control/preinst/prerm/postinst/postrm)", "ctrlFMan"))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((c3 + 'Import Control Data from an Installed Package' , "ctrlImprt" ))
  VVtMHe.append(FFQlwu('Undo Last "control" File Changes'   , "ctrlUndo" , fileExists(self.projFile_control + ".bak"), c3))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(FFQlwu("Delete Current Row (from Project File)" , "delRow"  , Section not in ("Control", "Script")   , VV8ETX))
  FFECK9(self, self.VVYdzw, VVtMHe=VVtMHe, width=1050, title="Options", VVaRsg="#11001122", VVWgai="#11001122")
 def VVYdzw(self, item=None):
  if item:
   if   item == "addFile" : self.VVzsS7(False)
   elif item == "addDir" : self.VVzsS7(True)
   elif item == "pkgNam" : self.VVWxXe()
   elif item == "addDep" : FFbA1i(self.projTable, self.VVu4Qw)
   elif item == "delDep" : self.VVDThv()
   elif item == "ctrlFMan" : self.VVezey()
   elif item == "ctrlImprt": FFbA1i(self.projTable, self.VVm1of)
   elif item == "ctrlUndo" : self.VV5MSg()
   elif item == "delRow" : self.VVXmnn()
 def VVzsS7(self, isDir):
  Dir = FFG1q8(CFG.lastPkgProjDir.getValue(), False)
  if isDir: self.session.openWithCallback(self.VVVB6C, BF(CCVnYx, mode=CCVnYx.VVW7oj, VVSMX5=Dir))
  else : self.session.openWithCallback(self.VVVB6C, BF(CCVnYx, patternMode="all", VVSMX5=Dir))
 def VVVB6C(self, path):
  if path:
   FF0UO9(CFG.lastPkgProjDir, path)
   self.VVqJSh(path, 2)
 def VVezey(self):
  Dir = FFG1q8(CFG.lastPkgProjDir.getValue(), False)
  self.session.openWithCallback(self.VVFkgu, BF(CCVnYx, patternMode="pkgCtrl", VVSMX5=Dir))
 def VVFkgu(self, path):
  if path:
   FF0UO9(CFG.lastPkgProjDir, path)
   fName = os.path.basename(path)
   if FFqSkC("cp -f '%s' '%s'" % (path, self.projPath + fName)):
    self.VVaI3w()
    self.projTable.VVQMdW({1:"Script", 2:fName})
 def VVm1of(self):
  cmd = FFRkrW(VVOApa, "")
  if not cmd:
   FFvp5w(self)
   return
  lst = FFYEhL(cmd)
  if lst:
   err = CCVnYx.VVDb8p(lst, fromFind=False)
   if err:
    self.VV0tSK(err)
    return
   lst.sort()
   VVsLLE = []
   for item in lst:
    span = iSearch(r"(.+) - (.+)", item)
    if span:
     VVsLLE.append(("", span.group(1), span.group(2)))
   if VVsLLE:
    VV1kWx = ("Import 'control' data", self.VVrtjg, [])
    VVM9Pm = ("Package Info.", self.VV47BN     , [])
    header = ("dum", "Package" , "Version" )
    widths = (0 , 70  , 30  )
    FFDpub(self, None, header=header, VVcuvv=VVsLLE, VVbG6j=widths, VVGNdU=30, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, VVJScE=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
      , VVaRsg="#22110011", VVWgai="#22191111", VVSJJk="#22191111", VVYCZ6="#00003030", VVTjte="#00333333")
   else:
    self.VV0tSK("Cannot process installed packages !")
  else:
   self.VV0tSK("Cannot read installed packages !")
 def VV5MSg(self):
  if FFqSkC("mv -f '%s' '%s'" % (self.projFile_control + ".bak", self.projFile_control)):
   self.VVaI3w(jmpDict={1:"Control", 2:"Package"})
  else:
   self.VV0tSK("Process Failed !")
 def VVrtjg(self, VVdesl, title, txt, colList):
  FFbA1i(VVdesl, BF(self.VVoMMC, VVdesl, colList[1]))
 def VVoMMC(self, VVdesl, pkg):
  lines = []
  for line in FFYEhL(FFbfXZ(VVh7PL, pkg)):
   span = iSearch(r"^([A-Z].+):\s*.+", line)
   if span and span.group(1) in ("Package", "Version", "Depends", "Section", "Architecture", "Maintainer", "Source", "Description"):
    lines.append(line)
  if lines: FFgBNQ(self, BF(self.VVSKu6, VVdesl, lines), "Replace current fields ?", title="Import Control Fields")
  else : self.VV0tSK("Cannot import from this package:\n\n%s" % pkg)
 def VVSKu6(self, VVdesl, lines):
  VVdesl.cancel()
  FFZkSn(self.projFile_control)
  with open(self.projFile_control, "w") as f:
   for line in lines:
    f.write(line.strip()+ "\n")
  self.VVaI3w(jmpDict={1:"Control", 2:"Package"})
 def VVXmnn(self):
  lineNum = int(self.projTable.VV1blE()[0]) + 1
  FFqSkC("sed -i.bak -e '%dd' '%s'" % (lineNum, self.projFile))
  self.VVaI3w()
 def VVqJSh(self, line, jmp):
  if fileExists(self.projFile):
   FFZkSn(self.projFile)
   FF2Usq(self.projFile)
   with open(self.projFile, "a") as f:
    f.write("%s\n" % line)
   if   jmp == 1: jmpDict = {1:"Action" , 2:line.split("=")[0]}
   elif jmp == 2: jmpDict = {1:"Resource" , 3:line.strip().rstrip("/")}
   else   : jmpDict = None
   self.VVaI3w(jmpDict=jmpDict)
  else:
   FFbiIe(self, self.projFile, title=self.projTitle)
 def VVsubI(self, VVdesl, title, txt, colList):
  VVtMHe = []
  VVtMHe.append(FFQlwu("No-Action after installation" , "instNon", self.projAct_postInst != 0))
  VVtMHe.append(FFQlwu("Restart after installation" , "instRes", self.projAct_postInst != 1))
  VVtMHe.append(FFQlwu("Reboot after installation"  , "instReb", self.projAct_postInst != 2))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(FFQlwu("No-Action after removal" , "rmNon", self.projAct_postRm != 0))
  VVtMHe.append(FFQlwu("Restart after removal" , "rmRes", self.projAct_postRm != 1))
  VVtMHe.append(FFQlwu("Reboot after removal"  , "rmReb", self.projAct_postRm != 2))
  FFECK9(self, self.VVe1iw, VVtMHe=VVtMHe, title="Action (after the package is installed/removed)")
 def VVe1iw(self, item=None):
  if item:
   if   item == "instNon" : self.VV5nFU("postinst", 0)
   elif item == "instRes" : self.VV5nFU("postinst", 1)
   elif item == "instReb" : self.VV5nFU("postinst", 2)
   elif item == "rmNon" : self.VV5nFU("postrm", 0)
   elif item == "rmRes" : self.VV5nFU("postrm", 1)
   elif item == "rmReb" : self.VV5nFU("postrm", 2)
 def VV5nFU(self, subj, val):
  if fileExists(self.projFile):
   lines = FF72md(self.projFile)
   FFZkSn(self.projFile)
  else:
   lines = []
  inFile = False
  with open(self.projFile, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if not iMatch(r"%s\s*=.+" % subj, line, IGNORECASE) : f.write(line + "\n")
    else            : inFile = True
  if val > 0: self.VVqJSh("%s=%s" % (subj, {1:"restart", 2:"reboot"}.get(val, "")), 1)
  elif inFile: self.VVaI3w()
 def VVWxXe(self):
  pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
  VVtMHe = []
  VVtMHe.append((pkg, pkg))
  VVtMHe.append(VVXGzj)
  for s in ("extensions", "systemplugins", "", "skins", "picons", "softcams", "", "drivers", "security", "settings"):
   if s:
    name = "enigma2-plugin-%s-%s" % (s, pkg)
    c = VVRuOi if name == self.projPkg else ""
    VVtMHe.append((c + name, name))
   else:
    VVtMHe.append(VVXGzj)
  FFECK9(self, self.VVrVc5, VVtMHe=VVtMHe, title="Package Name")
 def VVrVc5(self, item=None):
  if item:
   self.VVDDfe("Package", item)
 def VVu4Qw(self):
  lst = set()
  for s in ("d", "o", "i"):
   path = "/var/lib/%spkg/status" % s
   if fileExists(path):
    with open(path, "r") as f:
     for line in f:
      if line.startswith(("Package:", "Depends:", "Recommends:", "Suggests:", "Conflicts:", "Replaces:", "Breaks:", "Provides:")):
       line = line.split(":", 1)[1]
       for dep in line.split(","):
        lst.add(dep.strip())
  if lst:
   VVtMHe = []
   for item in lst: VVtMHe.append((item, item))
   VVtMHe.sort(key=lambda x: x[0].lower())
   VVkbkP = FFECK9(self, self.VVlYR8, VVtMHe=VVtMHe, width=1100, title="Add Dependency")
   if self.projLastDepends:
    VVkbkP.VV6A4S(self.projLastDepends)
  else:
   self.VV0tSK("Cannot read dependencies list !")
 def VVlYR8(self, item=None):
  if item:
   lst = []
   self.projLastDepends = item
   if fileExists(self.projFile_control):
    for line in FF72md(self.projFile_control):
     if line.startswith("Depends:"):
      lst = list(map(str.strip, line[8:].split(",")))
      break
   if not item in lst:
    lst.append(item)
    self.VVDDfe("Depends", ", ".join(lst))
   else:
    FFZD7H(self.projTable, "Already added", 1500)
    self.projTable.VVQMdW({1:"Control", 2:"Depends"})
 def VVDThv(self):
  lst = []
  for row in self.projTable.VVTW2g():
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Title == "Depends":
    lst = list(map(str.strip, Value.split(",")))
    break
  if lst:
   VVtMHe = []
   for item in lst: VVtMHe.append((item, item))
   FFECK9(self, BF(self.VVEiNC, lst), VVtMHe=VVtMHe, title="Remove Dependency")
  else:
   self.VV0tSK("No dependencies to remove !")
 def VVEiNC(self, lst, item=None):
  if item:
   for ndx, dep in enumerate(lst):
    if dep == item:
     del lst[ndx]
     break
   if lst:
    self.VVDDfe("Depends", ", ".join(lst))
   else:
    FFqSkC("sed -i '/Depends:*/d' '%s'" % self.projFile_control)
    self.VVaI3w()
 def VVDDfe(self, subj, val):
  lines = FF72md(self.projFile_control) if fileExists(self.projFile_control) else []
  inFile = False
  with open(self.projFile_control, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if iMatch(r"%s\s*:\s*.+" % subj, line):
     line = "%s: %s" % (subj, val)
     inFile = True
    f.write(line + "\n")
   if not inFile:
    f.write("%s: %s\n" % (subj, val))
  self.VVaI3w(jmpDict={1:"Control", 2:subj})
 def VV7o7Q(self, VVdesl, title, txt, colList):
  VVtMHe = []
  VVtMHe.append(("Create .ipk"  , "ipk"))
  VVtMHe.append(("Create .deb"  , "deb"))
  VVtMHe.append(("Create .tar.gz" , "tar"))
  FFECK9(self, self.VVRBNW, VVtMHe=VVtMHe, width=500, title=self.projTitle)
 def VVRBNW(self, item=None):
  if item:
   FFbA1i(self.projTable, BF(self.VVLbxQ, item))
 def VVLbxQ(self, item):
  if self.projTotalDirs + self.projTotalFiles == 0:
   self.VV0tSK("No Dirs/Files found !\n\nYou need to add at least 1 directory or 1 file to the project !")
   return
  if   item in ("ipk", "tar") : VVlAOK, tarParam, tarExt = False, "-czhf", ".tar.gz"
  elif item == "deb"   : VVlAOK, tarParam, tarExt = True , "-cJhf", ".tar.xz"
  if   not self.projPkg : err = "Package"
  elif not self.projVer : err = "Version"
  elif not self.projArch : err = "Architecture"
  else     : err = ""
  if err:
   VV0tSK(self, 'Parameter "%s" not found !' % err)
   return
  if item == "tar": pName, arch, ext = self.projName, "", "tar.gz"
  else   : pName, arch, ext = self.projPkg , self.projArch, item
  pkgFile = "%s%s_%s_%s.%s" % (CFG.packageOutputPath.getValue(), pName, self.projVer, arch, ext)
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  dataTmpPath  = projDir + "DATA/"
  dataFile  = projDir + "data" + tarExt
  removePorjDir = FFb0lc("rm -rf '%s'" % projDir)
  ctrlDir   = "%sCONTROL" % projDir
  controlTarF  = projDir + "control" + tarExt
  controlFile  = "%s/control" % ctrlDir
  debianFile  = projDir + "debian-binary"
  result = "Package:"
  failed= "Process Failed."
  resCmd  = " if [ -f '%s' ]; then "  % pkgFile
  resCmd += "  echo -e '\n%s\n%s' %s;" % (result, pkgFile, FFP1gK(result  , VViZMT))
  resCmd += " else"
  resCmd += "  echo -e '\n%s' %s;"  % (failed, FFP1gK(failed, VVOr14))
  resCmd += " fi;"
  cmd  = ""
  cmd += FFb0lc("rm -f '%s'" % pkgFile)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % dataTmpPath
  linkLst = []
  ctrlLst = []
  for ndx, row in enumerate(self.projTable.VVTW2g()):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Section == "Control":
    ctrlLst.append("%s: %s" % (Title, Value))
   elif ValidF:
    Dir = os.path.dirname(Value)
    cmd += "mkdir -p '%s%s';"  % (dataTmpPath, Dir)
    cmd += "ln -sf '%s' '%s%s';" % (Value, dataTmpPath, Value)
  if item == "tar":
   cmd += "echo 'Processing Data Files ...';"
   cmd += "tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, pkgFile)
   cmd += resCmd
   cmd += removePorjDir
   FFyrLj(self, cmd)
   return
  cmd += "mkdir -p '%s';"  % ctrlDir
  cmd += " echo '2.0' > %s;" % debianFile
  if not FFqSkC(cmd) or not pathExists(ctrlDir):
   VV0tSK(self, "Preparation Failed")
   return
  else:
   with open(controlFile, "w") as f:
    for item in ctrlLst:
     f.write("%s\n" % item)
  fName = ("prerm"     ,"preinst"      ,"postrm"     , "postinst"     )
  srcF  = (self.projFile_preRm  , self.projFile_preInst   , self.projFile_postRm  , self.projFile_postInst  )
  line  = ("Removing package : xx ...", "Installing Package : xx ..." , "Package removed (xx)." , "Installation completed (xx)" )
  act   = (0       , 0        , self.projAct_postRm  , self.projAct_postInst   )
  def VVpFzx(act):
   if   act == 1: return "echo 'RESTARTING GUI ...'\nif which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
   elif act == 2: return "echo 'REBOOTING DEVICE ...'\nsleep 3; reboot\n"
   else   : return "echo 'echo 'You may need to Restart GUI.'\n"
  for fName, srcF, line, act in zip(fName, srcF, line, act):
   dstF = os.path.join(ctrlDir, fName)
   if fileExists(srcF):
    FFqSkC("cp -f '%s' '%s'" % (srcF, dstF))
   else:
    with open(dstF, "w") as f:
     f.write("#!/bin/bash\n")
     f.write("echo '%s'\n" % line.replace("xx", self.projPkg))
     f.write(VVpFzx(act) if srcF in (self.projFile_postInst, self.projFile_postRm) else "")
     f.write("exit 0\n")
   FF2Usq(dstF)
   FFqSkC("chmod 755 '%s'" % dstF)
  cmd  = ""
  cmd += FFfDPF()
  if VVlAOK:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFv2CR("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  cmd += "cd '%s';" % dataTmpPath
  cmd += " echo 'Processing Control Files ...';"
  cmd += " cd '%s';"   % ctrlDir
  cmd += " tar %s '%s' ./*;" % (tarParam, controlTarF)
  cmd += " echo 'Processing Data Files ...';"
  cmd += " tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, dataFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlTarF, "control.tar")
  cmd += checkCmd % (dataFile   , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (pkgFile, debianFile, controlTarF, dataFile)
  cmd += " fi;"
  cmd +=  resCmd
  cmd += "fi;"
  cmd += removePorjDir
  FFyrLj(self, cmd)
class CCmJHl(Screen, CCGIk4):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFPFsH(VVMjBN, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  CCGIk4.__init__(self)
  c1, c2, c3, c4 = VV7z62, VVdVTX, VV4mV2, VVRuOi
  VVtMHe = []
  VVtMHe.append((c1 + "Plugins Browser"        , "pluginsBrowser"   ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((c2 + "Download/Install Packages (from image feeds)", "downloadInstallPackages" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((c3 + "Remove Packages (show all)"     , "VVTkJ7sAll"  ))
  VVtMHe.append((c3 + "Remove Packages (Plugins/SoftCams/Skins)" , "removePluginSkinSoftCAM" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((c2 + "Update Packages List from Feed"    , "VV7iwP"  ))
  VVtMHe.append((c2 + "Upgradable Packages"       , "VVnVwT" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((c4 + "Package Creator (ipk/deb/tar.gz)"   , "packageCreator"   ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Packaging Tool"         , "VVGh4f"   ))
  VVtMHe.append(("Active Feeds"          , "VV1ul5"   ))
  FFRFZg(self, VVtMHe=VVtMHe)
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFWIRJ(self["myMenu"])
  FFJI0m(self)
 def VV2Iyl(self):
  global VVsQSL
  VVsQSL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "pluginsBrowser"    : CCHdWN.VVi3xt(self)
   elif item == "downloadInstallPackages"  : FFbA1i(self, BF(self.VV5SrT, 0, ""))
   elif item == "VVTkJ7sAll"   : FFbA1i(self, BF(self.VV5SrT, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFbA1i(self, BF(self.VV5SrT, 2, "| grep -e skin -e enigma2-"))
   elif item == "VV7iwP"   : CCmJHl.VV7iwP(self)
   elif item == "VVnVwT"  : FFbA1i(self, self.VVnVwT)
   elif item == "packageCreator"    : self.VVGmAc()
   elif item == "VVGh4f"    : self.VVGh4f()
   elif item == "VV1ul5"    : FFbA1i(self, self.VV1ul5)
   else          : self.close()
 def VV1ul5(self):
  files = []
  for s in ("d", "o", "i"):
   files.extend(iGlob("/var/lib/%spkg/lists/*" % s))
  VVsLLE = []
  if files:
   for path in files:
    tot = 0
    with open(path, "r") as f:
     for line in f:
      if line.startswith("Package:"): tot += 1
    VVsLLE.append((os.path.basename(path), str(tot)))
  if VVsLLE:
   VVsLLE.sort(key=lambda x: x[0].lower())
   header  = ("Feed","Packages")
   widths  = (82  , 18  )
   VV0CnX = (LEFT  , CENTER )
   FFDpub(self, None, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, width=1000, VVGNdU=26, VVcmLr=2)
  else:
   self.VV0tSK("Cannot read packages list !")
 def VVnVwT(self, VVdesl=None):
  lst = FFYEhL(FFRkrW(VVNr2C, ""))
  VVsLLE = []
  if lst:
   lst.sort(key=lambda x: x.lower())
   for line in lst:
    pkg = curV = newVer = ""
    span = iSearch(r"(.+) - (.+) - (.+)", line)
    if span:
     pkg, curV, newVer = span.group(1), span.group(2), span.group(3)
    else:
     span = iSearch(r"(.+) (.+) (.+) \[upgradable from: (.+)\]", line)
     if span:
      pkg, newVer, arch, curV = span.group(1), span.group(2), span.group(3), span.group(4)
    if all((pkg, curV, newVer)):
     VVsLLE.append((str(len(VVsLLE) + 1), pkg, curV, newVer))
   if VVsLLE:
    if VVdesl:
     VVdesl.VV87pY(VVsLLE, VVZoVsMsg=True)
    else:
     bg = "#00221111"
     VV1kWx = ("Upgrade", self.VVxGbE   , [])
     VVM9Pm = ("Package Info.", self.VV47BN , [])
     header  = ("Num" ,"Package" ,"Version" , "New Version" )
     widths  = (6  , 42  , 26  , 26   )
     VV0CnX = (CENTER , LEFT  , LEFT  , LEFT   )
     FFDpub(self, None, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, width=1700, VVGNdU=26, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, VVEMdg=True, VVG01F=0, searchCol=1, lastFindConfigObj=CFG.lastFindPackages, VVaRsg=bg, VVWgai=bg, VVSJJk=bg, VVlrsP="#00ffff55", VVYCZ6="#00003040")
  if not VVsLLE:
   FFZbFo(self, "Nothing to upgrade", 1500)
   if VVdesl: VVdesl.cancel()
 def VVxGbE(self, VVdesl, title, txt, colList):
  pkg = colList[1]
  cmd = FFbfXZ(VVqrBj, pkg)
  if cmd : FFyrLj(self, cmd, title="Installing : %s" % pkg, VV4qLc=BF(self.VVnVwT, VVdesl))
  else : FFvp5w(SELF)
 def VVGh4f(self):
  pkg = FFUNHV()
  aptT = "apt - Advanced Package Tool" if FFLsle("apt") else ""
  txt = {"ipkg": "Itsy", "opkg": "Open", "dpkg": "Debian"}.get(pkg, "")
  txt = "%s - %s Package Management System" % (pkg, txt) if txt else ""
  txt += "%s%s" % ("\n\nand\n\n" if txt and aptT else "", aptT)
  FFDeF8(self, txt or "No packaging tools found!")
 def VV5SrT(self, mode, grep, VVdesl=None, title=""):
  if   mode == 0: cmd = FFRkrW(VVCCMr    , grep)
  elif mode == 1: cmd = FFRkrW(VVOApa , grep)
  elif mode == 2: cmd = FFRkrW(VVOApa , grep)
  if not cmd:
   FFvp5w(self)
   return
  VVsLLE = FFYEhL(cmd)
  if VVsLLE:
   err = CCVnYx.VVDb8p(VVsLLE, fromFind=False)
   if err:
    FFOyl1(self, err)
    return
  else:
   if VVdesl: VVdesl.VVaW1B()
   FFOyl1(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVcuvv  = []
  for item in VVsLLE:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVcuvv.append((name, package, version))
  if mode > 0:
   extensions = FFYEhL("ls %s -l | grep '^d' | awk '{print $9}'" % VVxCog)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVcuvv:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == VV2see: name += "el"
      VVcuvv.append((name, VVxCog + item, "-"))
   systemPlugins = FFYEhL("ls %s -l | grep '^d' | awk '{print $9}'" % VVtttO)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVcuvv:
      if item.lower() == row[0].lower():
       break
     else:
      VVcuvv.append((item, VVtttO + item, "-"))
  if not VVcuvv:
   FFOyl1(self, "No packages found!")
   return
  if VVdesl:
   VVcuvv.sort(key=lambda x: x[0].lower())
   VVdesl.VV87pY(VVcuvv, title)
  else:
   widths = (20, 50, 30)
   VV1kWx = None
   VVRHhw = None
   if mode == 0:
    VVIzUv = ("Install" , self.VVcqik   , [])
    VV1kWx = ("Download" , self.VVImQI   , [])
    VVRHhw = ("Filter"  , self.VVKygv , [])
   elif mode == 1:
    VVIzUv = ("Uninstall", self.VVTkJ7, [])
   elif mode == 2:
    VVIzUv = ("Uninstall", self.VVTkJ7, [])
    widths= (18, 57, 25)
   VVcuvv.sort(key=lambda x: x[0].lower())
   VVM9Pm = ("Package Info.", self.VV47BN, [])
   header   = ("Name" ,"Package" , "Version" )
   FFDpub(self, None, header=header, VVcuvv=VVcuvv, VVbG6j=widths, VVGNdU=28, VVIzUv=VVIzUv, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw, VVJScE=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVaRsg="#22110011", VVWgai="#22191111", VVSJJk="#22191111", VVYCZ6="#00003030", VVTjte="#00333333")
 def VV47BN(self, VVdesl, title, txt, colList):
  FFbA1i(VVdesl, BF(self.VVhgU3, VVdesl, colList[1]))
 def VVhgU3(self, VVdesl, pkg):
  if pathExists(pkg):
   pkg, err = CCmJHl.VVl9hd(pkg)
   if err:
    FFZbFo(VVdesl, err, 1000)
    return
  CCmJHl.VVYBTJ(self, pkg)
 def VVKygv(self, VVdesl, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVtMHe = []
  VVtMHe.append(("All Packages", "all"))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVtMHe.append(VVXGzj)
  for word in words:
   VVtMHe.append((word, word))
  FFECK9(self, BF(self.VVeE52, VVdesl), VVtMHe=VVtMHe, title="Select Filter")
 def VVeE52(self, VVdesl, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFbA1i(VVdesl, BF(self.VV5SrT, 0, grep, VVdesl, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVTkJ7(self, VVdesl, title, txt, colList):
  FFbA1i(VVdesl, BF(self.VVmAvp, VVdesl, colList[1]))
 def VVmAvp(self, VVdesl, package):
  if pathExists(package):
   pkg, err = CCmJHl.VVl9hd(package)
   if pkg:
    package = pkg
  if package.startswith((VVxCog, VVtttO)):
   FFgBNQ(self, BF(self.VVPaos, VVdesl, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVtMHe = []
   VVtMHe.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVtMHe.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVtMHe.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFECK9(self, BF(self.VV59mM, VVdesl, package), VVtMHe=VVtMHe)
 def VVPaos(self, VVdesl, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -rf '%s' &>/dev/null %s" % (package, VVlkj1)
  FFyrLj(self, cmd, VV4qLc=BF(self.VVhRNa, VVdesl))
 def VV59mM(self, VVdesl, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVCAlU
   elif item == "remove_ForceRemove"  : cmdOpt = VVqsIZ
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVwmI5
   FFgBNQ(self, BF(self.VV9R8n, VVdesl, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VV9R8n(self, VVdesl, package, cmdOpt):
  self.lastSelectedRow = VVdesl.VVvapY()
  cmd = FFbfXZ(cmdOpt, package)
  if cmd : FFyrLj(self, cmd, VV4qLc=BF(self.VVhRNa, VVdesl))
  else : FFvp5w(self)
 def VVhRNa(self, VVdesl):
  VVdesl.cancel()
  FFAIFB()
 def VVcqik(self, VVdesl, title, txt, colList):
  package  = colList[1]
  VVtMHe = []
  VVtMHe.append(("Install Package"        , "install_CheckVersion" ))
  VVtMHe.append(("Install Package (force reinstall)"   , "install_ForceReinstall" ))
  VVtMHe.append(("Install Package (force overwrite)"   , "install_ForceOverwrite" ))
  VVtMHe.append(("Install Package (force downgrade)"   , "install_ForceDowngrade" ))
  VVtMHe.append(("Install Package (ignore failed dependencies)" , "install_IgnoreDepends" ))
  FFECK9(self, BF(self.VVfCpH, package), VVtMHe=VVtMHe)
 def VVfCpH(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVqrBj
   elif item == "install_ForceReinstall" : cmdOpt = VVkYaB
   elif item == "install_ForceOverwrite" : cmdOpt = VVGJh6
   elif item == "install_ForceDowngrade" : cmdOpt = VV6qvM
   elif item == "install_IgnoreDepends" : cmdOpt = VVqwiy
   FFgBNQ(self, BF(self.VVCWtA, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVCWtA(self, package, cmdOpt):
  cmd = FFbfXZ(cmdOpt, package)
  if cmd : FFyrLj(self, cmd, VV4qLc=FFAIFB, checkNetAccess=True)
  else : FFvp5w(self)
 def VVImQI(self, VVdesl, title, txt, colList):
  package  = colList[1]
  FFgBNQ(self, BF(self.VVgPO6, package), "Download Package ?\n\n%s" % package)
 def VVgPO6(self, package):
  if CCFewM.VVmB13():
   cmd = FFbfXZ(VV2Yh7, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFP1gK(success, VViZMT))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFP1gK(fail, VVOr14))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFyrLj(self, cmd, VVYGxa=[VVOr14, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFvp5w(self)
  else:
   FFOyl1(self, "No internet connection !")
 @staticmethod
 def VV7iwP(SELF):
  cmd = FFRkrW(VVjmk7, "")
  if cmd : FFyrLj(SELF, cmd, checkNetAccess=True)
  else : FFvp5w(SELF)
 @staticmethod
 def VVl9hd(path):
  pkg = err = ""
  if pathExists(path):
   for line in FFYEhL(FFbfXZ(VVRTWG, "*%s*" % path)):
    span = iSearch(r"(.+) - .+", line)
    if span:
     pkg = span.group(1)
     break
    else:
     span = iSearch(r"(.+):+", line)
     if span:
      pkg = span.group(1)
      break
   if not pkg:
    err = "No package info !"
  else:
   err = "Path not found !"
  return pkg, err
 @staticmethod
 def VVYBTJ(SELF, package, title=""):
  title = title or package
  infoCmd  = FFbfXZ(VVh7PL, package)
  filesCmd = FFbfXZ(VVabTi, package)
  listInstCmd = FFRkrW(VVOApa, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFTLIE(VVXAXH)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFP1gK(notInst, VV8ETX))
   cmd += "else "
   cmd +=   FFZOMf("System Info", VVXAXH)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFZOMf("Related Files", VVXAXH)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FF1lrl(SELF, cmd, title=title)
  else:
   FFvp5w(SELF, title=title)
class CC8zCm():
 def VV3AUZ(self, isRef, onlyEpg=False):
  self.shareIsRef   = isRef
  self.onlyEpg   = onlyEpg
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VVdcyS()
 def VVdcyS(self):
  files = FF0KZb(VVZAJU, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVtMHe = []
   for fil in files:
    VVtMHe.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVaRsg, VVWgai = "#22221133", "#22221133"
   else    : VVaRsg, VVWgai = "#22003344", "#22002233"
   VVI3Sz  = ("Add new File", self.VVQta8)
   FFECK9(self, self.VV4o31, VVtMHe=VVtMHe, width=1100, VVI3Sz=VVI3Sz, VVNhLF="", minRows=4, VVaRsg=VVaRsg, VVWgai=VVWgai)
  else:
   FFgBNQ(self, self.VVtAnC, "No files found.\n\nCreate a new file ?")
 def VVtAnC(self):
  path = self.VVRF8G()
  if fileExists(path) : self.VVdcyS()
  else    : FFZD7H(self, "Cannot create file", 1500)
 def VVQta8(self, VVkbkP, path):
  path = self.VVRF8G()
  VVkbkP.VVSwKG((os.path.basename(path), path), isSort=True)
 def VVRF8G(self):
  path = "%s%s%s.xml" % (VVZAJU, self.shareFilePrefix, FFZR2n())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VV4o31(self, path=None):
  if path:
   FFbA1i(self, BF(self.VVYHCg, path))
 def VVYHCg(self, path):
  if not fileExists(path):
   FFbiIe(self, path)
   return
  elif not CCVnYx.VV8SZ3(self, path, FFmlRV()):
   return
  else:
   self.shareFilePath = path
  if not CCAfrz.VV6Dqd(self):
   return
  tree = CCwuBY.VVYfv4(self, self.shareFilePath)
  if not tree:
   return
  refLst = CCotiQ.VVKKit()
  def VVYgG4(refCode):
   if   FFj69C(refCode): return FF8oA9("DVB", VV7z62)
   elif refCode in refLst     : return FF8oA9("IPTV", VV7z62)
   else         : return ""
  VVsLLE= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VVvOTY(ch)
   if ok:
    srcTxt = VVYgG4(srcRef)
    dstTxt = VVYgG4(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VVsLLE:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VVsLLE.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VVsLLE:
   if self.shareIsRef : VVaRsg, VVWgai, optTxt = "#1a221133", "#1a221133", "Share Reference"
   else    : VVaRsg, VVWgai, optTxt = "#1a003344", "#1a002233", "Copy EPG" if self.onlyEpg else "Copy EPG/PIcons"
   VVBYRP = (""    , BF(self.VVNPYz, dupl), [])
   VVZArZ = (""    , self.VVUqC7    , [])
   VVIzUv = ("Delete Entry" , self.VV4wcl   , [])
   VV1kWx = ("Add Entry"  , self.VVuKUA   , [])
   VVM9Pm = (optTxt   , self.VVvzJv  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VV0CnX = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVdesl = FFDpub(self, None, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=24, VVBYRP=VVBYRP, VVZArZ=VVZArZ, VVIzUv=VVIzUv, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, VVEMdg=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVaRsg=VVaRsg, VVWgai=VVWgai, VVSJJk=VVWgai, VVYCZ6="#0a000000")
  else:
   FFOyl1(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VVNPYz(self, dupl, VVdesl, title, txt, colList):
  if dupl:
   VVdesl.VVz4xL("Skipped %d duplicate%s" % (dupl, FFsfSO(dupl)), 2000)
 def VVUqC7(self, VVdesl, title, txt, colList):
  def VVYgG4(key, val): return "%s\t: %s\n" % (key, val or FF8oA9("?", VVtchu))
  Keys = VVdesl.VVoZ97()
  Vals = VVdesl.VV1blE()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VVYgG4(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VViZMT, VVtchu
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FFoB4k(self, txt + txt1, title=title)
 def VVvOTY(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VV4wcl(self, VVdesl, title, txt, colList):
  if VVdesl.VVvapY() == 0 and VVdesl.VVH1h9() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FFgBNQ(self, BF(self.VVHrYd, isLast, VVdesl), ques)
 def VVHrYd(self, isLast, VVdesl):
  if isLast:
   FFOlRe(self.shareFilePath)
   VVdesl.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVdesl.VV1blE()
   if self.VVlG1T(srcName, srcRef, dstName, dstRef):
    VVdesl.VVKchm()
    VVdesl.VVj9Yv()
    FFZD7H(VVdesl, "Deleted", 500, isGrn=True)
   else:
    FFZD7H(VVdesl, "Cannot delete from file", 2000)
 def VVuKUA(self, VVdesl, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VV4z8k(VVdesl, isDvb=True)
  else    : self.VVvx7P(VVdesl, "Source Channel", "#22003344", "#22002233")
 def VVvx7P(self, mainTableInst, title, VVaRsg, VVWgai):
  FFECK9(self, BF(self.VV6jDh, mainTableInst, title), VVtMHe=[("DVB", "DVB"), ("IPTV / Stream Relay", "IPTV")], title=title + " Type", width=800, VVaRsg=VVaRsg, VVWgai=VVWgai)
 def VV6jDh(self, mainTableInst, title, item=None):
  if item:
   FFbA1i(mainTableInst, BF(self.VVt0Dr, mainTableInst, title, item), clearMsg=False)
 def VVt0Dr(self, mainTableInst, title, item):
  FFZD7H(mainTableInst)
  if item == "DVB": self.VV4z8k(mainTableInst, isDvb=True)
  else   : self.VV4z8k(mainTableInst, isDvb=False)
 def VVaQsV(self, mainTableInst, chType, VVdesl, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVdesl.VVvapY()
  if   chType == "DVB" : FF0UO9(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FF0UO9(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VVTW2g()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FFOyl1(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VVsrhC(srcName, srcRef, dstName, dstRef):
      mainTableInst.VVavnG((str(mainTableInst.VVH1h9() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FFZD7H(mainTableInst, "Added", 500, isGrn=True)
     else:
      FFZD7H(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FFZD7H(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VV4z8k(mainTableInst, isDvb=False)
   else    : FFkvVR(BF(self.VVvx7P, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVdesl.cancel()
 def VVnsSm(self, item, VVdesl, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVdesl.VVTklH(ndx)
 def VV4z8k(self, VVdesl, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VVaQsV, VVdesl, typ)
  doneFnc = BF(self.VVnsSm, typ)
  if isDvb: CC8zCm.VVBSQw(VVdesl , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CC8zCm.VVuGnU(VVdesl, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VVBSQw(SELF, title, okFnc, doneFnc=None):
  FFbA1i(SELF, BF(CC8zCm.VVcxk4, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VVcxk4(SELF, title, okFnc, doneFnc=None):
  VVsLLE, err = CCwuBY.VVtR0o(SELF, CCwuBY.VVPzpc)
  if VVsLLE:
   color = "#0a000022"
   VVsLLE.sort(key=lambda x: x[0].lower())
   VVMWQK = ("Select" , okFnc, [])
   VVBYRP= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VV0CnX = (LEFT  , LEFT  , CENTER, LEFT    )
   FFDpub(SELF, None, title=title, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=26, VVaRsg=color, VVWgai=color, VVSJJk=color, VVMWQK=VVMWQK, VVBYRP=VVBYRP, lastFindConfigObj=CFG.lastFindServices)
  else:
   FFOyl1(SELF, "No DVB Services !")
 @staticmethod
 def VVuGnU(SELF, title, okFnc, doneFnc=None):
  FFbA1i(SELF, BF(CC8zCm.VVqwn5, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VVqwn5(SELF, title, okFnc, doneFnc=None):
  VVsLLE = CC8zCm.VVPWEa()
  if VVsLLE:
   color = "#0a112211"
   VVsLLE.sort(key=lambda x: x[0].lower())
   VVMWQK = ("Select" , okFnc, [])
   VVBYRP= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FFDpub(SELF, None, title=title, header=header, VVcuvv=VVsLLE, VVbG6j=widths, VVGNdU=26, VVaRsg=color, VVWgai=color, VVSJJk=color, VVMWQK=VVMWQK, VVBYRP=VVBYRP, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFOyl1(SELF, "No IPTV Services !")
 @staticmethod
 def VVPWEa():
  VVsLLE = []
  files  = CCoUhv.VVDteM()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFFr8o(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVFLv8 = span.group(1)
    else : VVFLv8 = ""
    VVFLv8_lCase = VVFLv8.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VVsLLE.append((chName, VVFLv8, url, refCode))
  return VVsLLE
 def VVsrhC(self, srcName, srcRef, dstName, dstRef):
  tree = CCwuBY.VVYfv4(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VVvwyS(tree, root)
  return True
 def VVlG1T(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CCwuBY.VVYfv4(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VVvOTY(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VVvwyS(tree, root)
  return found
 def VVvwyS(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CCwuBY.VV28FB(xmlTxt)
  parser = CCwuBY.CC279D()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VVvzJv(self, VVdesl, title, txt, colList):
  if self.onlyEpg:
   self.VVyIHN(VVdesl, "epg")
  else:
   if self.shareIsRef:
    FFgBNQ(self, BF(FFbA1i, VVdesl, BF(self.VVOkOz, VVdesl)), "Copy all References from Source to Destination ?")
   else:
    VVtMHe = []
    VVtMHe.append(("Copy EPG\t (All List)" , "epg"  ))
    VVtMHe.append(("Copy Picons\t (All List)" , "picon" ))
    FFECK9(self, BF(self.VVyIHN, VVdesl), VVtMHe=VVtMHe, width=1000)
 def VVyIHN(self, VVdesl, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VVP4fv  , "EPG"
   elif item == "picon": fnc, txt = self.VVKk4w , "PIcons"
   title = "Copy %s" % txt
   tot   = VVdesl.VVH1h9()
   FFgBNQ(self, BF(FFbA1i, VVdesl, BF(fnc, VVdesl, title)), "Overwrite %s for %d Service%s ?" % (FF8oA9(txt, VVXAXH), tot, FFsfSO(tot)), title=title)
 def VVOkOz(self, VVdesl):
  files = CCoUhv.VVDteM()
  totChange = 0
  if files:
   for path in files:
    txt = FFFr8o(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVdesl.VVTW2g():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFjaui()
  tot = VVdesl.VVH1h9()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FFoB4k(self, txt)
 def VVKk4w(self, VVdesl, title):
  if not iCopyfile:
   FFOyl1(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CCuqLp.VVchM7()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVdesl.VVTW2g():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVdesl.VVH1h9()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FFoB4k(self, txt, title=title)
 def VVP4fv(self, VVdesl, title):
  txt, err = CCfTje.VVn81t(VVdesl, title)
  if err : FFOyl1(self, err, title=title)
  else : FFoB4k(self, txt, title=title)
 class CC279D(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VVYfv4(SELF, path, withComments=True, title=""):
  try:
   if withComments : parser = iElem.XMLParser(target=CCwuBY.CC279D())
   else   : parser = None
   return iElem.parse(path, parser=parser)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FF8oA9("XML Parse Error in:", VVtchu), path)
   txt += "%s\n%s\n\n" % (FF8oA9("Error:", VVtchu), str(e))
   FFoB4k(SELF, txt, VVSJJk="#11220000", title=title)
   return None
 @staticmethod
 def VV28FB(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
class CCfTje(Screen, CC8zCm):
 VVlwk0  = "BDTSE"
 VVrkg7   = "save"
 VV31Rj   = "load"
 VV9bap  = "flushEPG"
 def __init__(self, session):
  self.skin, self.skinParam = FFPFsH(VVMjBN, 950, 800, 50, 40, 30, "#22110011", "#22110022", 30)
  self.session  = session
  valid, path, sz, szTxt = CCfTje.VVGiSU()
  qUrl, iptvRef = CCoUhv.VVToal(self)
  VVtMHe = []
  VVtMHe.append((VV7z62 + "Cache File Info." , "inf"))
  VVtMHe.append(VVXGzj)
  fTxt = " (%s)" % os.path.basename(path) if valid else ""
  VVtMHe.append(FFQlwu("Save EPG to File%s" % fTxt , self.VVrkg7, valid))
  VVtMHe.append(FFQlwu("Load EPG from File%s" % fTxt , self.VV31Rj, valid))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((VV8ETX + "Delete EPG (from RAM only)", self.VV9bap))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(FFQlwu("Update Current Bouquet EPG (from IPTV Server)", "refreshIptvEPG", qUrl or "chCode" in iptvRef))
  VVtMHe.append(("Copy EPG between Channels (from xml file)", "copyEpg" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Translate Current Channel EPG %s(Experimental)" % VV8ETX, "VVu7iN"))
  FFRFZg(self, VVtMHe=VVtMHe)
  self.onShown.append(self.VVnLQg)
 def VV2Iyl(self):
  global VVsQSL
  VVsQSL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "inf"    : self.VVbprd()
   elif item in (self.VVrkg7, self.VV31Rj, self.VV9bap):
    reset = item == self.VV31Rj
    FFgBNQ(self, BF(FFbA1i, self, BF(self.VVM7Qp, item, reset)), VVStYd="Continue ?")
   elif item == "refreshIptvEPG"  : CCoUhv.VVAZLx(self)
   elif item == "VVu7iN" : self.VVu7iN()
   elif item == "copyEpg"    : self.VV3AUZ(False, onlyEpg=True)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFWIRJ(self["myMenu"])
  FFJI0m(self)
 def VVM7Qp(self, act, reset=False):
  ok = CCfTje.VVNqwA(act)
  if ok:
   if reset:
    CCfTje.VV0bF3(self)
   FFDeF8(self, "Done")
  else:
   FFDeF8(self, "Failed!")
 def VVbprd(self):
  title = "EPG Cache File"
  valid, path, sz, szTxt = CCfTje.VVGiSU()
  if path:
   if valid: txt = "File Path\t: %s\n\nFile Size\t: %s\n" % (path, szTxt or "?")
   else : txt = "System Settings: %s\n\n%s" % (path, FF8oA9("File not found (check System EPG settings).", VV8ETX))
   FFoB4k(self, txt, title=title)
  else:
   FFOyl1(self, "Cannot read Path Settings !", title=title)
 @staticmethod
 def VVOi2Q():
  return [("", "Disable"),("af","Afrikaans"),("sq","Albanian"),("am","Amharic"),("ar","Arabic"),("hy","Armenian"),("as","Assamese"),("ay","Aymara"),("az","Azerbaijani"),("bm","Bambara"),("eu","Basque"),("be","Belarusian"),("bn","Bengali"),("bho","Bhojpuri"),("bs","Bosnian"),("bg","Bulgarian"),("ca","Catalan"),("ceb","Cebuano"),("ny","Chichewa"),("zh-CN","Chinese (Simplified)"),("zh-TW","Chinese (Traditional)"),("co","Corsican"),("hr","Croatian"),("cs","Czech"),("da","Danish"),("dv","Dhivehi"),("doi","Dogri"),("nl","Dutch"),("en","English"),("eo","Esperanto"),("et","Estonian"),("ee","Ewe"),("tl","Filipino"),("fi","Finnish"),("fr","French"),("fy","Frisian"),("gl","Galician"),("ka","Georgian"),("de","German"),("el","Greek"),("gn","Guarani"),("gu","Gujarati"),("ht","Haitian Creole"),("ha","Hausa"),("haw","Hawaiian"),("iw","Hebrew"),("hi","Hindi"),("hmn","Hmong"),("hu","Hungarian"),("is","Icelandic"),("ig","Igbo"),("ilo","Ilocano"),("id","Indonesian"),("ga","Irish"),("it","Italian"),("ja","Japanese"),("jw","Javanese"),("kn","Kannada"),("kk","Kazakh"),("km","Khmer"),("rw","Kinyarwanda"),("gom","Konkani"),("ko","Korean"),("kri","Krio"),("ku","Kurdish (Kurmanji)"),("ckb","Kurdish (Sorani)"),("ky","Kyrgyz"),("lo","Lao"),("la","Latin"),("lv","Latvian"),("ln","Lingala"),("lt","Lithuanian"),("lg","Luganda"),("lb","Luxembourgish"),("mk","Macedonian"),("mai","Maithili"),("mg","Malagasy"),("ms","Malay"),("ml","Malayalam"),("mt","Maltese"),("mi","Maori"),("mr","Marathi"),("mni-Mtei","Meiteilon (Manipuri)"),("lus","Mizo"),("mn","Mongolian"),("my","Myanmar (Burmese)"),("ne","Nepali"),("no","Norwegian"),("or","Odia (Oriya)"),("om","Oromo"),("ps","Pashto"),("fa","Persian"),("pl","Polish"),("pt","Portuguese"),("pa","Punjabi"),("qu","Quechua"),("ro","Romanian"),("ru","Russian"),("sm","Samoan"),("sa","Sanskrit"),("gd","Scots Gaelic"),("nso","Sepedi"),("sr","Serbian"),("st","Sesotho"),("sn","Shona"),("sd","Sindhi"),("si","Sinhala"),("sk","Slovak"),("sl","Slovenian"),("so","Somali"),("es","Spanish"),("su","Sundanese"),("sw","Swahili"),("sv","Swedish"),("tg","Tajik"),("ta","Tamil"),("tt","Tatar"),("te","Telugu"),("th","Thai"),("ti","Tigrinya"),("ts","Tsonga"),("tr","Turkish"),("tk","Turkmen"),("ak","Twi"),("uk","Ukrainian"),("ur","Urdu"),("ug","Uyghur"),("uz","Uzbek"),("vi","Vietnamese"),("cy","Welsh"),("xh","Xhosa"),("yi","Yiddish"),("yo","Yoruba"),("zu","Zulu")]
 def VVu7iN(self):
  title = "Translate Current Channel EPG"
  bg = "#11101010"
  VVMWQK  = (""  , BF(self.VVFYpQ, title, True) , [])
  VV1kWx = ("Start" , BF(self.VVFYpQ, title, False), [])
  VVRHhw = ("Change Language", self.VVQ1IR      , [])
  widths  = (70 , 30)
  VV0CnX = (LEFT , CENTER)
  FFDpub(self, None, title=title, VVcuvv=self.VVJJlg(), VV0CnX=VV0CnX, VVbG6j=widths, width=1200, vMargin=20, VVGNdU=30, VVMWQK=VVMWQK, VV1kWx=VV1kWx, VVRHhw=VVRHhw, VVcmLr=2
    , VVaRsg="#11201010", VVWgai=bg, VVSJJk=bg, VVYCZ6="#00004455", VVTjte=bg)
 def VVJJlg(self):
  Def, ch = "DISABLED", dict(CCfTje.VVOi2Q())
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  VVcuvv = [("Event Name Language", ch.get(tVal, Def)), ("Description Language", ch.get(dVal, Def))]
  return VVcuvv
 def VVQ1IR(self, VVdesl, title, txt, colList):
  ndx = VVdesl.VVvapY()
  title = colList[0]
  confItem = CFG.epgLangTitle if ndx == 0 else CFG.epgLangDescr
  CC1Kd0.VVPHBN(self, confItem, title, lst=CCfTje.VVOi2Q(), cbFnc=BF(self.VVDlrd, VVdesl), isSave=True)
 def VVDlrd(self, VVdesl):
  for ndx, row in enumerate(self.VVJJlg()):
   VVdesl.VVFoW1(ndx, row)
 def VVFYpQ(self, Title, isAsk, VVdesl, title, txt, colList):
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  if not (tVal or dVal):
   FFZD7H(VVdesl, "Change Language", 700)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
   refCode, evList, err = CCfTje.VVZHor(refCode)
   fnc = BF(self.VV9gBe, Title, refCode, evList, VVdesl)
   if   err : FFOyl1(self, err, title=Title)
   elif isAsk : FFgBNQ(self, fnc, "Start ?", title=Title)
   else  : fnc()
 def VV9gBe(self, title, refCode, evList, VVdesl):
  self.session.open(CCjWUz, barTheme=CCjWUz.VVh7HE, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVFxSO, evList)
      , VVCBqA = BF(self.VVyznn, title, refCode))
  VVdesl.cancel()
 def VVFxSO(self, evList, VVNVFL):
  totEv = len(evList)
  newLst = []
  totErrName = totErrShort = totErrLong = totSkip = 0
  VVNVFL.VV0amK(totEv)
  VVNVFL.VVpwcW = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
  lang = CFG.epgLangDescr.getValue()
  for ev in evList:
   trName, trShort, trLong, errName, errShort, errLong = CCfTje.VVFUhP(*ev[2:5])
   totErrName  += errName
   totErrShort += errShort
   totErrLong  += errLong
   if not VVNVFL or VVNVFL.isCancelled:
    return
   VVNVFL.VViyfK(1)
   VVNVFL.VVmLrY(len(newLst), ev[2] if len(ev[2]) < 22 else ev[2][:22] + " ...")
   name1, short1, long1 = ev[2:5]
   if (name1, short1, long1) != (trName, trShort, trLong):
    item = list(ev)
    item[2], item[3], item[4] = trName, trShort, trLong
    item.append(1)
    newLst.append(tuple(item))
   else:
    totSkip += 1
   VVNVFL.VVpwcW = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
 def VVyznn(self, title, refCode, VVdCuP, VVpwcW, threadCounter, threadTotal, threadErr):
  newLst, totEv, totErrName, totErrShort, totErrLong, totSkip = VVpwcW
  if newLst: totEv, totOK = CCfTje.VVNFjl(refCode, newLst)
  else  : totOK = 0
  if totOK:
   CCfTje.VVYgeK()
   CCfTje.VV0bF3(self)
  txt  = "Events\t: %d\n"  % totEv
  txt += "Processed\t: %d\n" % len(newLst)
  txt += "Changed\t: %d\n" % totOK
  if totSkip : txt += "Skipped\t: %d \t... Same language\n" % totSkip
  if any((totErrName, totErrShort, totErrLong)):
   txt += "\nErrors:\n"
   if totErrName : txt += "  Event Name\t: %d\n" % totErrName
   if totErrShort: txt += "  Description\t: %d\n" % totErrShort
   if totErrLong : txt += "  Description\t: %d\n" % totErrLong
  FFoB4k(self, txt, title=title)
 @staticmethod
 def VVFUhP(eName, eShort, eLong):
  eName, eShort, eLong = eName.strip(), eShort.strip(), eLong.strip()
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  lang, lst, resLst, errLst = (tVal, dVal, dVal), (eName, eShort, eLong), ["", "", ""], [0, 0, 0]
  def VVYgG4(ndx):
   if lst[ndx] and lang[ndx]:
    txt, err = CCfTje.VV9Aun(lst[ndx], lang[ndx])
    resLst[ndx], errLst[ndx] = txt, 1 if err else 0
  thLst = []
  for ndx in range(3):
   th = iThread(name="ajp_%d" % ndx, target=BF(VVYgG4, ndx))
   th.start()
   thLst.append(th)
  for th in thLst: th.join()
  trName, trShort, trLong = resLst[0] or eName, resLst[1] or eShort, resLst[2] or eLong
  errName, errShort, errLong = errLst
  return trName, trShort, trLong, errName, errShort, errLong
 @staticmethod
 def VV9Aun(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "%s%s&q=%s" % ("=lt&otua=ls&?m/moc.elgoog.etalsnart//:sptth"[::-1], toLang, FFP1tK(txt))
   txt, err = CCoUhv.VVnY0U(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFC8zI(txt)
    ndx  = txt.find('<div class="result-container">')
    if ndx > -1:
     txt = txt[ndx + 30:]
     ndx  = txt.find("</div>")
     if ndx > -1:
      return str(CCfTje.VVSUts(txt[:ndx])).strip(), ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVGiSU():
  path = szTxt = ""
  valid = sz = 0
  try: path = config.misc.epgcache_filename.getValue()
  except: pass
  if fileExists(path):
   valid = 1
   sz = FFF0Rr(path)
   szTxt = CCVnYx.VVI3LQ(sz) if sz > -1 else ""
  return valid, path, sz, szTxt
 @staticmethod
 def VVSx7J():
  try:
   from enigma import eEPGCache
   return eEPGCache, eEPGCache.getInstance()
  except:
   return None, None
 @staticmethod
 def VVYgeK(): CCfTje.VVNqwA(CCfTje.VVrkg7)
 @staticmethod
 def VVNqwA(act):
  ec, inst = CCfTje.VVSx7J()
  if inst and hasattr(ec, act):
   try:
    exec("inst.%s()" % act)
    return True
   except:
    pass
  return False
 @staticmethod
 def VV0bF3(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   SELF.session.nav.stopService()
   SELF.session.nav.playService(serv)
 @staticmethod
 def VVZHor(refCode):
  ec, inst = CCfTje.VVSx7J()
  if inst:
   try:
    evList = inst.lookupEvent([CCfTje.VVlwk0, (refCode, 0, -1, 20160)])
    if evList: return refCode, evList, ""
    else  : return refCode, [], "System returned empty EPG list"
   except:
    return refCode, [], "EPG Read-Error !"
  else:
   return refCode, [], "Cannot read EPG Cache !"
 @staticmethod
 def VVNFjl(refCode, events, longDescDays=0):
  ec, inst = CCfTje.VVSx7J()
  totEv, totOK, fnc = 0, 0, None
  if inst:
   if   hasattr(ec, "importEvents"): fnc = inst.importEvents
   elif hasattr(ec, "importEvent") : fnc = inst.importEvent
  if fnc:
   for data in events:
    totEv += 1
    try:
     if longDescDays and data[0] > iTime() + 86400 * longDescDays:
      data = data[:4] + ("",) + data[5:]
     fnc(refCode, (data,))
     totOK += 1
    except:
     pass
  return totEv, totOK
 @staticmethod
 def VVtNm6(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   ec, inst = CCfTje.VVSx7J()
   if ec:
    event = inst.lookupEventTime(serv, -1, 0)
    if event:
     return CCfTje.VVeU7D(event)
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CCqIel.CCfTje(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVeU7D(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCfTje.VV7H8r(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVRH2U(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   ec, inst = CCfTje.VVSx7J()
   try:
    if inst:
     for evNum in range(2):
      event = inst.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CCfTje.VVeU7D(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FFt4wC(evTime)
       evEndTxt  = FFt4wC(evEnd)
       evDurTxt  = FFBNnO(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FFBNnO(evPos)
        evRem = evEnd - now
        evRemTxt = FFBNnO(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FFBNnO(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VV7H8r(event):
  genre = PR = ""
  try:
   genre  = CCfTje.VV1fCb(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCfTje.VVz1cn(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVz1cn(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VV1fCb(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCfTje.VVroJs()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVroJs():
  path = VV2V68 + "_sup_genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFFr8o(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFFr8o(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVn81t(VVdesl, title):
  ec, inst = CCfTje.VVSx7J()
  if not inst:
   return "", "Cannot access EPG Cache !"
  totFound = totEvents = totSuccess = totInvalid = totEvErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVdesl.VVTW2g():
   if remark == "0":
    try:
     evList = inst.lookupEvent([CCfTje.VVlwk0, (srcRef, 0, -1, 20160)])
    except:
     totEvErr += 1
     evList = []
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CCfTje.VVNFjl(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CCfTje.VVYgeK()
  txt  = "Services\t: %d\n"  % VVdesl.VVH1h9()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  if totEvErr:
   txt += "EPG Errors\t: %d" % totEvErr
  return txt, ""
 @staticmethod
 def VVU9Cp(info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += CCfTje.VVG0bq(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += CCfTje.VVG0bq(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += CCfTje.VVG0bq(event, 0)
     except:
      pass
  return epg
 @staticmethod
 def VVG0bq(event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCfTje.VVeU7D(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    trName, trShort, trLong, errName, errShort, errLong = CCfTje.VVFUhP(evName, evShort, evDesc)
    evShort, evDesc = trShort, trLong
    evNameTransl = trName if evName and trName and evName != trName else ""
    if evName          : txt += "Name\t: %s\n"   % FF8oA9(evName, VVRuOi)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (CFG.epgLangDescr.getValue().upper(), FF8oA9(evNameTransl, VVRuOi))
    if evTime           : txt += "Start Time\t: %s\n" % FFt4wC(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFt4wC(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFBNnO(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFBNnO(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFBNnO(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FF8oA9(evShort, VVdVTX)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FF8oA9(evDesc , VVdVTX)
    if txt:
     txt = FF8oA9("\n%s\n%s Event:\n%s\n" % (SEP, ("Current", "Next")[evNum], SEP), VVRuOi) + txt
  return txt
 @staticmethod
 def VVSUts(txt):
  try:
   from HTMLParser import HTMLParser
   return HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
class CCwuBY(Screen, CC8zCm):
 VV4sct  = 0
 VVAkxJ = 1
 VVWn5F  = 2
 VVRCRk  = 3
 VVFNFY = 4
 VVTsIE = 5
 VVBOJI = 6
 VVPzpc   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FFPFsH(VVMjBN, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVzihc = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVtMHe = self.VVvGqt()
  FFRFZg(self, VVtMHe=VVtMHe, title="Services/Channels")
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self["myMenu"].setList(self.VVvGqt())
  FFWIRJ(self["myMenu"])
  FFJI0m(self)
 def VVvGqt(self):
  VVtMHe = []
  c = VV7z62
  VVtMHe.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVtMHe.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVtMHe.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVtMHe.append(VVXGzj)
  c = VVRuOi
  VVtMHe.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVtMHe.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVtMHe.append((VVtchu + "More tables ..."     , "VVvRN8"    ))
  c = VVdVTX
  VVtMHe.append(VVXGzj)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVtMHe.append((c + txt          , "VVNOhr"  ))
  else : VVtMHe.append((txt           ,          ))
  VVtMHe.append((c + 'Export Services to "channels.xml"'    , "VVWwir"      ))
  VVtMHe.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VV4mV2
  VVtMHe.append(VVXGzj)
  VVtMHe.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVtMHe.append((c + "Invalid Services Cleaner"       , "VVgew5"    ))
  c = VV4mV2
  VVtMHe.append(VVXGzj)
  VVtMHe.append((c + "Delete Channels with no names"     , "VVXtot"    ))
  VVtMHe.append((c + "Delete Empty Bouquets"       , "VVbGDA"     ))
  VVtMHe.append(VVXGzj)
  VV7eR1, VVfT9H = CCwuBY.VVxOqT()
  if fileExists(VV7eR1):
   enab = fileExists(VVfT9H)
   if enab: VVtMHe.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVtMHe.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVtMHe.append(("Reset Parental Control Settings"      , "VVKUMP"    ))
  VVtMHe.append(("Reload Channels and Bouquets"       , "VV0wZE"      ))
  return VVtMHe
 def VV2Iyl(self):
  global VVsQSL
  VVsQSL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCuYKB.VVa42W(self.session)
   elif item == "openSignal"       : FF89A3(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FF1wB7(self, fncMode=CCqIel.VVajvb)
   elif item == "lameDB_allChannels_with_refCode"  : FFbA1i(self, self.VVv1Y1)
   elif item == "lameDB_allChannels_with_tranaponder" : FFbA1i(self, self.VVFBSs)
   elif item == "VVvRN8"     : self.VVvRN8()
   elif item == "VVNOhr"  : CCHaaH.VVNOhr(self)
   elif item == "VVWwir"      : self.VVWwir()
   elif item == "copyEpgPicons"      : self.VV3AUZ(False)
   elif item == "SatellitesCleaner"     : FFbA1i(self, self.FFbA1i_SatellitesCleaner)
   elif item == "VVgew5"    : FFbA1i(self, BF(self.VVgew5))
   elif item == "VVXtot"    : FFbA1i(self, self.VVXtot)
   elif item == "VVbGDA"     : self.VVbGDA(self)
   elif item == "enableHiddenChannels"     : self.VVYC9D(True)
   elif item == "disableHiddenChannels"    : self.VVYC9D(False)
   elif item == "VVKUMP"    : FFgBNQ(self, self.VVKUMP, "Reset and Restart ?")
   elif item == "VV0wZE"      : FFbA1i(self, BF(CCwuBY.VV0wZE, self))
 def VVvRN8(self):
  VVtMHe = []
  VVtMHe.append(("Services (IDs)"       , "lameDB_allChannels_with_details" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Services (Parental-Control List)"   , "parentalControlChannels"   ))
  VVtMHe.append(("Services (Hidden List)"     , "showHiddenChannels"    ))
  VVtMHe.append(("Services with PIcons for the System"  , "VVWMFJ"    ))
  VVtMHe.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"  ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Transponders (Statistics)"    , "TranspondersStats"    ))
  VVtMHe.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"    ))
  FFECK9(self, self.VVGBFi, VVtMHe=VVtMHe, title="Service Information", VVIZXB=True)
 def VVGBFi(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FFbA1i(self, BF(self.VVyDQu, title))
   elif ref == "parentalControlChannels"   : FFbA1i(self, BF(self.VVu48X, title))
   elif ref == "showHiddenChannels"    : FFbA1i(self, BF(self.VVfmBY, title))
   elif ref == "VVWMFJ"    : FFbA1i(self, BF(self.VVFsFn, title))
   elif ref == "servicesWithMissingPIcons"   : FFbA1i(self, BF(self.VVwsM5, title))
   elif ref == "TranspondersStats"     : FFbA1i(self, BF(self.VV7ayI, title))
   elif ref == "SatellitesXmlStats"    : FFbA1i(self, BF(self.VVrJ8J, title))
 def VVWwir(self):
  VVtMHe = []
  VVtMHe.append(("All DVB-S/C/T Services", "all"))
  VVtMHe.extend(CCotiQ.VVq4e6())
  FFECK9(self, self.VVMHlU, VVtMHe=VVtMHe, title="", VVIZXB=True)
 def VVMHlU(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCwuBY.VVPwKw("1:7:")
   else   : lst = FF6kZn(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFbQ09(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FF81BD(r)  : sat = "Stream Relay"
       elif FFueFC(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FFDpEI(CFG.exportedTablesPath.getValue()), FFZR2n())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FFDeF8(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFZD7H(self, "No Services found !", 1500)
 @staticmethod
 def VV0wZE(SELF):
  FFjaui()
  FFDeF8(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVv1Y1(self):
  self.VVzihc = None
  self.lastfilterUsed  = None
  self.filterObj   = CC6kzI(self)
  VVsLLE, err = CCwuBY.VVtR0o(self, self.VV4sct)
  if VVsLLE:
   VVsLLE.sort(key=lambda x: x[0].lower())
   VVMWQK  = ("Zap"   , self.VVYQCK     , [])
   VVZArZ = (""    , self.VVE0vv   , [])
   VVM9Pm = ("Options"  , self.VVZhG5 , [])
   VV1kWx = ("Current Service", self.VVPQp6 , [])
   VVRHhw = ("Filter"   , self.VVpWDm  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VV0CnX  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFDpub(self, None, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=26, VVMWQK=VVMWQK, VVZArZ=VVZArZ, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw, lastFindConfigObj=CFG.lastFindServices)
 def VVFBSs(self):
  self.VVzihc = None
  self.lastfilterUsed  = None
  self.filterObj   = CC6kzI(self)
  VVsLLE, err = CCwuBY.VVtR0o(self, self.VVAkxJ)
  if VVsLLE:
   VVsLLE.sort(key=lambda x: x[0].lower())
   VVMWQK  = ("Zap"   , self.VVYQCK      , [])
   VVZArZ = (""    , self.VVE0vv    , [])
   VV1kWx = ("Current Service", self.VVPQp6  , [])
   VVM9Pm = ("Options"  , self.VVISFD , [])
   VVRHhw = ("Filter"   , self.VVQfn0  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VV0CnX  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFDpub(self, None, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=26, VVMWQK=VVMWQK, VVZArZ=VVZArZ, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw, lastFindConfigObj=CFG.lastFindServices)
 def VVZhG5(self, VVdesl, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CCB2u5(self, VVdesl)
  VVtMHe = []
  isMulti = VVdesl.VVcTnU
  if isMulti:
   refCodeList = VVdesl.VVLRcj(3)
   if refCodeList:
    VVtMHe.append(("Add Selection to Parental Control"  , "parentalControl_sel_add"  ))
    VVtMHe.append(("Remove Selection from Parental Control" , "parentalControl_sel_remove" ))
    VVtMHe.append(VVXGzj)
    VVtMHe.append(("Add Selection to Hidden Services"   , "hiddenServices_sel_add"  ))
    VVtMHe.append(("Remove Selection from Hidden Services" , "hiddenServices_sel_remove" ))
    VVtMHe.append(VVXGzj)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVtMHe.append((txt1, "parentalControl_add" ))
    VVtMHe.append((txt2,        ))
   else:
    VVtMHe.append((txt1,       ))
    VVtMHe.append((txt2, "parentalControl_remove" ))
   VVtMHe.append(VVXGzj)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVtMHe.append((txt1, "hiddenServices_add"  ))
    VVtMHe.append((txt2,       ))
   else:
    VVtMHe.append((txt1,        ))
    VVtMHe.append((txt2, "hiddenServices_remove" ))
   VVtMHe.append(VVXGzj)
  cbFncDict = { "parentalControl_add"   : BF(self.VVu48f, VVdesl, refCode, True)
     , "parentalControl_remove"  : BF(self.VVu48f, VVdesl, refCode, False)
     , "hiddenServices_add"   : BF(self.VVmslW, VVdesl, refCode, True)
     , "hiddenServices_remove"  : BF(self.VVmslW, VVdesl, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVSaBJ, VVdesl, True)
     , "parentalControl_sel_remove" : BF(self.VVSaBJ, VVdesl, False)
     , "hiddenServices_sel_add"  : BF(self.VVrlov, VVdesl, True)
     , "hiddenServices_sel_remove" : BF(self.VVrlov, VVdesl, False)
     }
  VVtMHe1, cbFncDict1 = CCwuBY.VVGFHF(self, VVdesl, servName, 3)
  VVtMHe.extend(VVtMHe1)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VVcQQV(VVtMHe, cbFncDict)
 def VVISFD(self, VVdesl, title, txt, colList):
  servName = colList[0]
  mSel = CCB2u5(self, VVdesl)
  VVtMHe, cbFncDict = CCwuBY.VVGFHF(self, VVdesl, servName, 3)
  mSel.VVcQQV(VVtMHe, cbFncDict)
 @staticmethod
 def VVGFHF(SELF, VVdesl, servName, refCodeCol):
  tot = VVdesl.VVLHWg()
  if tot > 0:
   sTxt = FF8oA9("%d Service%s" % (tot, FFsfSO(tot)), VVRuOi)
   VVtMHe = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FF3gfV(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FF8oA9(servName, VVRuOi)
   VVtMHe = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CCwuBY.VVaILG, SELF, VVdesl, refCodeCol, True)
     , "addToBouquet_one" : BF(CCwuBY.VVaILG, SELF, VVdesl, refCodeCol, False)
     }
  return VVtMHe, cbFncDict
 @staticmethod
 def VVaILG(SELF, VVdesl, refCodeCol, isMulti):
  picker = CCotiQ(SELF, VVdesl, "Add to Bouquet", BF(CCwuBY.VVht1S, VVdesl, refCodeCol, isMulti))
 @staticmethod
 def VVht1S(VVdesl, refCodeCol, isMulti):
  if isMulti : refCodeList = VVdesl.VVLRcj(refCodeCol)
  else  : refCodeList = [VVdesl.VV1blE()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VVu48f(self, VVdesl, refCode, isAddToBlackList):
  VVdesl.VVYtu4("Processing ...")
  FFkvVR(BF(self.VVw4UF, VVdesl, [refCode], isAddToBlackList))
 def VVSaBJ(self, VVdesl, isAddToBlackList):
  refCodeList = VVdesl.VVLRcj(3)
  if not refCodeList:
   FFOyl1(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVdesl.VVYtu4("Processing ...")
  FFkvVR(BF(self.VVw4UF, VVdesl, refCodeList, isAddToBlackList))
 def VVw4UF(self, VVdesl, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVmldL, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVmldL):
   lines = FF72md(VVmldL)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVmldL, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVdesl.VVcTnU
   if isMulti:
    self.VV0Mg3(VVdesl, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVIyAJ(VVdesl, refCode)
    VVdesl.VVaW1B()
  else:
   VVdesl.VVz4xL("No changes")
 def VVmslW(self, VVdesl, refCode, isHide):
  title = "Change Hidden State"
  if FFj69C(refCode):
   VVdesl.VVYtu4("Processing ...")
   ret = FFbQCc(refCode, isHide)
   if ret : FFbA1i(self, BF(self.VVIyAJ, VVdesl, refCode))
   else : FFOyl1(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFOyl1(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVIyAJ(self, VVdesl, refCode):
  VVsLLE, err = CCwuBY.VVtR0o(self, self.VV4sct, VVmmpe=[3, [refCode], False])
  done = False
  if VVsLLE:
   data = VVsLLE[0]
   if data[3] == refCode:
    done = VVdesl.VVIDuW(data)
  if not done:
   self.VV2BZx(VVdesl, VVdesl.VVtVut(), self.VV4sct)
  VVdesl.VVaW1B()
 def VV0Mg3(self, VVdesl, totRefCodes):
  VVsLLE, err = CCwuBY.VVtR0o(self, self.VV4sct, VVmmpe=self.VVzihc)
  VVdesl.VV87pY(VVsLLE)
  VVdesl.VVrFVf(False)
  VVdesl.VVz4xL("%d Processed" % totRefCodes)
 def VVrlov(self, VVdesl, isHide):
  refCodeList = VVdesl.VVLRcj(3)
  if not refCodeList:
   FFOyl1(self, "Nothing selected", title="Change Hidden State")
   return
  VVdesl.VVYtu4("Processing ...")
  FFkvVR(BF(self.VVUBPn, VVdesl, refCodeList, isHide))
 def VVUBPn(self, VVdesl, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFbQCc(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFjaui(True)
   self.VV0Mg3(VVdesl, len(refCodeList))
  else:
   VVdesl.VVz4xL("No changes")
 def VVpWDm(self, VVdesl, title, txt, colList):
  inFilterFnc = BF(self.VVvIaa, VVdesl) if self.VVzihc else None
  self.filterObj.VVRAJD(1, VVdesl, 2, BF(self.VVEJvg, VVdesl), inFilterFnc=inFilterFnc)
 def VVEJvg(self, VVdesl, item):
  self.VVsuW5(VVdesl, False, item, 2, self.VV4sct)
 def VVvIaa(self, VVdesl, VVkbkP, item):
  self.VVsuW5(VVdesl, True, item, 2, self.VV4sct)
 def VVQfn0(self, VVdesl, title, txt, colList):
  inFilterFnc = BF(self.VVLSYi, VVdesl) if self.VVzihc else None
  self.filterObj.VVRAJD(2, VVdesl, 4, BF(self.VVo1E8, VVdesl), inFilterFnc=inFilterFnc)
 def VVo1E8(self, VVdesl, item):
  self.VVsuW5(VVdesl, False, item, 4, self.VVAkxJ)
 def VVLSYi(self, VVdesl, VVkbkP, item):
  self.VVsuW5(VVdesl, True, item, 4, self.VVAkxJ)
 def VVOfN9(self, VVdesl, title, txt, colList):
  inFilterFnc = BF(self.VVWhma, VVdesl) if self.VVzihc else None
  self.filterObj.VVRAJD(0, VVdesl, 4, BF(self.VVVavq, VVdesl), inFilterFnc=inFilterFnc)
 def VVVavq(self, VVdesl, item):
  self.VVsuW5(VVdesl, False, item, 4, self.VVWn5F)
 def VVWhma(self, VVdesl, VVkbkP, item):
  self.VVsuW5(VVdesl, True, item, 4, self.VVWn5F)
 def VVsuW5(self, VVdesl, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVdesl.VVxBD7(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVzihc = None
  else:
   words, asPrefix = CC6kzI.VVV2i7(words)
   self.VVzihc = [col, words, asPrefix]
  if words: FFbA1i(VVdesl, BF(self.VV2BZx, VVdesl, title, mode), clearMsg=False)
  else : FFZD7H(VVdesl, "Incorrect filter", 2000)
 def VV2BZx(self, VVdesl, title, mode):
  VVsLLE, err = CCwuBY.VVtR0o(self, mode, VVmmpe=self.VVzihc, VVOnBM=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVdesl.VVTW2g():
    try:
     ndx = VVsLLE.index(tuple(list(map(str.strip, row))))
     lst.append(VVsLLE[ndx])
    except:
     pass
   VVsLLE = lst
  if VVsLLE:
   VVsLLE.sort(key=lambda x: x[0].lower())
   VVdesl.VV87pY(VVsLLE, title, VVZoVsMsg=True)
  else:
   FFZD7H(VVdesl, "Not found!", 1500)
 def VV2EKM(self, title, VVcuvv, VVMWQK=None, VVZArZ=None, VVIzUv=None, VV1kWx=None, VVM9Pm=None, VVRHhw=None):
  VV1kWx = ("Current Service", self.VVPQp6, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VV0CnX = (LEFT  , LEFT  , CENTER, LEFT    )
  FFDpub(self, None, title=title, header=header, VVcuvv=VVcuvv, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=26, VVMWQK=VVMWQK, VVZArZ=VVZArZ, VVIzUv=VVIzUv, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw, lastFindConfigObj=CFG.lastFindServices)
 def VVPQp6(self, VVdesl, title, txt, colList):
  self.VVCAnm(VVdesl)
 def VVSJOh(self, VVdesl, title, txt, colList):
  self.VVCAnm(VVdesl, True)
 def VVCAnm(self, VVdesl, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVdesl.VVQMdW(colDict, VVl1IZ=True)
   else:
    VVdesl.VVaQuz(3, refCode, True)
   return
  FFOyl1(self, "Cannot read current Reference Code !")
 def VVyDQu(self, title):
  self.VVzihc = None
  self.lastfilterUsed  = None
  self.filterObj   = CC6kzI(self)
  VVsLLE, err = CCwuBY.VVtR0o(self, self.VVWn5F)
  if VVsLLE:
   VVsLLE.sort(key=lambda x: x[0].lower())
   VVZArZ = (""    , self.VVopbF , []      )
   VV1kWx = ("Current Service", self.VVSJOh  , []      )
   VVRHhw = ("Filter"   , self.VVOfN9   , [], "Loading Filters ..." )
   VVMWQK  = ("Zap"   , self.VVmAj3      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VV0CnX  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFDpub(self, None, title=title, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=26, VVMWQK=VVMWQK, VVZArZ=VVZArZ, VV1kWx=VV1kWx, VVRHhw=VVRHhw, lastFindConfigObj=CFG.lastFindServices)
 def VVopbF(self, VVdesl, title, txt, colList):
  refCode  = self.VV6ZvT(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FF1wB7(self, fncMode=CCqIel.VVYIji, refCode=refCode, chName=chName, text=txt)
 def VVmAj3(self, VVdesl, title, txt, colList):
  refCode = self.VV6ZvT(colList)
  FFoYZf(self, refCode)
 def VVYQCK(self, VVdesl, title, txt, colList):
  FFoYZf(self, colList[3])
 def VV6ZvT(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVwCXh(VV7eR1, mode=0):
  lines = FF72md(VV7eR1, encLst=["UTF-8"])
  return CCwuBY.VVvZpb(lines, mode)
 @staticmethod
 def VVvZpb(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VVtR0o(SELF, mode, VVmmpe=None, VVOnBM=True, VVGHpD=True):
  VV7eR1, err = CCwuBY.VVJmSV(SELF, VVGHpD)
  if err:
   return None, err
  asPrefix = False
  if VVmmpe:
   filterCol = VVmmpe[0]
   filterWords = VVmmpe[1]
   asPrefix = VVmmpe[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCwuBY.VV4sct:
   blackList = None
   if fileExists(VVmldL):
    blackList = FF72md(VVmldL)
    if blackList:
     blackList = set(blackList)
  elif mode == CCwuBY.VVAkxJ:
   tp = CCMbXb()
  VVJwMZ, VVFf41 = FFAND4()
  if mode in (CCwuBY.VVTsIE, CCwuBY.VVBOJI):
   VVsLLE = {}
  else:
   VVsLLE = []
  tagFound = False
  with ioOpen(VV7eR1, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FFNSbQ(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCwuBY.VVWn5F:
       if sTypeInt in VVJwMZ:
        STYPE = VVFf41[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVsLLE.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVsLLE.append(tRow)
       else:
        VVsLLE.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCwuBY.VVPzpc:
        VVsLLE.append((chName, chProv, sat, refCode))
       elif mode == CCwuBY.VVTsIE:
        VVsLLE[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCwuBY.VVBOJI:
        VVsLLE[chName] = refCode
       elif mode == CCwuBY.VV4sct:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVsLLE.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVsLLE.append(tRow)
        else:
         VVsLLE.append(tRow)
       elif mode == CCwuBY.VVAkxJ:
        if sTypeInt in VVJwMZ:
         STYPE = VVFf41[sTypeInt]
        freq, pol, fec, sr, syst = tp.VV1FtS(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVsLLE.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVsLLE.append(tRow)
        else:
         VVsLLE.append(tRow)
       elif mode == CCwuBY.VVRCRk:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVsLLE.append((chName, chProv, sat, refCode))
       elif mode == CCwuBY.VVFNFY:
        VVsLLE.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVsLLE and VVOnBM:
   FFOyl1(SELF, "No services found!")
  return VVsLLE, ""
 def VVu48X(self, title):
  if fileExists(VVmldL):
   lines = FF72md(VVmldL)
   if lines:
    newRows = []
    VVsLLE, err = CCwuBY.VVtR0o(self, self.VVFNFY)
    if VVsLLE:
     lines = set(lines)
     for item in VVsLLE:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVsLLE = newRows
      VVsLLE.sort(key=lambda x: x[0].lower())
      VVZArZ = ("", self.VVE0vv, [])
      VVMWQK = ("Zap", self.VVYQCK, [])
      self.VV2EKM(title, VVsLLE, VVMWQK=VVMWQK, VVZArZ=VVZArZ)
     else:
      FFoB4k(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVsLLE)))
   else:
    FFDeF8(self, "No active Parental Control services.", FFmlRV())
  else:
   FFbiIe(self, VVmldL)
 def VVfmBY(self, title):
  VVsLLE, err = CCwuBY.VVtR0o(self, self.VVRCRk)
  if VVsLLE:
   VVsLLE.sort(key=lambda x: x[0].lower())
   VVZArZ = ("" , self.VVE0vv, [])
   VVMWQK  = ("Zap", self.VVYQCK, [])
   self.VV2EKM(title, VVsLLE, VVMWQK=VVMWQK, VVZArZ=VVZArZ)
  elif err:
   pass
  else:
   FFDeF8(self, "No hidden services.", FFmlRV())
 def VVgew5(self):
  title = "Services unused in Tuner Configuration"
  VV7eR1, err = CCwuBY.VVJmSV(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CCwuBY.VVNZgY()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VVxCgg(str(item[0]))
    nsLst.add(ns)
  sysLst = CCwuBY.VVPwKw("1:7:")
  tpLst  = CCwuBY.VVwCXh(VV7eR1, mode=1)
  VVsLLE = []
  for refCode, chName in sysLst:
   servID = CCwuBY.VVp10c(refCode)
   tpID = CCwuBY.VVB9hs(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VVsLLE.append((chName, FFbQ09(refCode, False), refCode, servID))
  if VVsLLE:
   VVsLLE.sort(key=lambda x: x[0].lower())
   VVM9Pm = ("Options"   , BF(self.VVo8uL, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VV0CnX  = (LEFT  , CENTER , LEFT   , CENTER   )
   FFDpub(self, None, title=title, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=26, VVM9Pm=VVM9Pm, VVaRsg="#0a001122", VVWgai="#0a001122", VVSJJk="#0a001122", VVYCZ6="#00004455", VVTjte="#0a333333", VVIyj7="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FFDeF8(self, "No invalid service found !", title=title)
 def VVo8uL(self, Title, VVdesl, title, txt, colList):
  mSel = CCB2u5(self, VVdesl)
  isMulti = VVdesl.VVcTnU
  if isMulti : txt = "Remove %s Services" % FF8oA9(str(VVdesl.VVLHWg()), VVtchu)
  else  : txt = "Remove : %s" % FF8oA9(VVdesl.VV1blE()[0], VVtchu)
  VVtMHe = [(txt, "del")]
  cbFncDict = {"del": BF(FFbA1i, VVdesl, BF(self.VVokqj, VVdesl, Title))}
  mSel.VVcQQV(VVtMHe, cbFncDict)
 def VVokqj(self, VVdesl, title):
  VV7eR1, err = CCwuBY.VVJmSV(self, title=title)
  if err:
   return
  isMulti = VVdesl.VVcTnU
  skipLst = []
  if isMulti : skipLst = VVdesl.VVLRcj(3)
  else  : skipLst = [VVdesl.VV1blE()[3]]
  tpLst = CCwuBY.VVwCXh(VV7eR1, mode=0)
  servLst = CCwuBY.VVwCXh(VV7eR1, mode=10)
  tmpDbFile = VV7eR1 + ".tmp"
  lines   = FF72md(VV7eR1)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  FFqSkC("mv -f '%s' '%s'" % (tmpDbFile, VV7eR1))
  VVsLLE = []
  for row in VVdesl.VVTW2g():
   if not row[3] in skipLst:
    VVsLLE.append(row)
  FFjaui()
  FFoB4k(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VVsLLE:
   VVdesl.VV87pY(VVsLLE, title)
   VVdesl.VVrFVf(False)
  else:
   VVdesl.cancel()
 def VV7ayI(self, title):
  VV7eR1, err = CCwuBY.VVJmSV(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VVAC3A(VV7eR1)
  txt = FF8oA9("Total Transponders:\n\n", VVoIYV)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FF8oA9("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVoIYV)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFpYGP(item), satList.count(item))
  FFoB4k(self, txt, title)
 def VVAC3A(self, VV7eR1):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VV7eR1, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVrJ8J(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FFbiIe(self, path, title=title)
   return
  elif not CCVnYx.VV8SZ3(self, path, title):
   return
  if not CCAfrz.VV6Dqd(self):
   return
  tree = CCwuBY.VVYfv4(self, path, title=title)
  if not tree:
   return
  VVsLLE = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FFNSbQ(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVsLLE.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVsLLE:
   VVsLLE.sort(key=lambda x: int(x[1]))
   VV1kWx = ("Current Satellite", BF(self.VVE6sa, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VV0CnX  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FFDpub(self, None, title=title, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=25, VVG01F=1, VV1kWx=VV1kWx, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFOyl1(self, "No data found !", title=title)
 def VVE6sa(self, satCol, VVdesl, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
  sat = FFbQ09(refCode, False)
  for ndx, row in enumerate(VVdesl.VVTW2g()):
   if sat == row[satCol].strip():
    VVdesl.VVTklH(ndx)
    break
  else:
   FFZD7H(VVdesl, "No listed !", 1500)
 def FFbA1i_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FFOyl1(self, "No Satellites found !")
   return
  usedSats = CCwuBY.VVNZgY()
  VVsLLE = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VVsLLE.append((sat[1], posTxt, FFNSbQ(sat[0]), tuners, str(posVal)))
  if VVsLLE:
   VVSJJk = "#11222222"
   VVsLLE.sort(key=lambda x: int(x[1]))
   VV1kWx = ("Current Satellite" , BF(self.VVE6sa, 2) , [])
   VVM9Pm = ("Options"   , self.VV0fWr  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VV0CnX  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FFDpub(self, None, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=28, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, VVaRsg=VVSJJk, VVWgai=VVSJJk, VVSJJk=VVSJJk, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFOyl1(self, "No data found !")
 def VV0fWr(self, VVdesl, title, txt, colList):
  mSel = CCB2u5(self, VVdesl)
  isMulti = VVdesl.VVcTnU
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FF8oA9(str(VVdesl.VVLHWg()), VVtchu)
  else  : txt = "Remove ALL Services on : %s" % FF8oA9(VVdesl.VV1blE()[0], VVtchu)
  VVtMHe = []
  VVtMHe.append((txt, "deleteSat"))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Delete Empty Bouquets", "VVbGDA"))
  cbFncDict = { "deleteSat"   : BF(FFbA1i, VVdesl, BF(self.VV3vQr, VVdesl))
     , "VVbGDA" : BF(self.VVbGDA, VVdesl)
     }
  mSel.VVcQQV(VVtMHe, cbFncDict)
 def VV3vQr(self, VVdesl):
  posLst = []
  isMulti = VVdesl.VVcTnU
  posLst = []
  if isMulti : posLst = VVdesl.VVLRcj(4)
  else  : posLst = [VVdesl.VV1blE()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VVxCgg(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VVWlOT(nsLst)
  FFjaui(True)
  FFoB4k(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VVbGDA(self, winObj):
  title = "Delete Empty Bouquets"
  FFgBNQ(self, BF(FFbA1i, winObj, BF(self.VV2jdv, title)), "Delete bouquets with no services ?", title=title)
 def VV2jdv(self, title):
  bList = CCotiQ.VVuL2Z()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CCotiQ.VVaqE5(bRef)
    bPath = VVKJQA + bFile
    FFOlRe(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVKJQA + fil
     if fileExists(path):
      lines = FF72md(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFjaui(True)
  if bNames: txt = "%s\n\n%s" % (FF8oA9("Deleted Bouquets:", VVRuOi), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FFoB4k(self, txt, title=title)
 def VVxCgg(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VVWlOT(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVKJQA)
  for srcF in files:
   if fileExists(srcF):
    lines = FF72md(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFGH0N(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VVFsFn(self, title)   : self.VVWMFJ(title, True)
 def VVwsM5(self, title) : self.VVWMFJ(title, False)
 def VVWMFJ(self, title, isWithPIcons):
  piconsPath = CCuqLp.VVchM7()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCuqLp.VV7eH6(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVsLLE, err = CCwuBY.VVtR0o(self, self.VVFNFY)
    if VVsLLE:
     channels = []
     for (chName, chProv, sat, refCode) in VVsLLE:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFp7Qx(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVsLLE)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVYgG4(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVYgG4("PIcons Path"  , piconsPath)
     txt += VVYgG4("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVYgG4("Total services" , totalServices)
     txt += VVYgG4("With PIcons"  , totalWithPIcons)
     txt += VVYgG4("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFoB4k(self, txt)
     else:
      VVZArZ     = (""      , self.VVE0vv , [])
      if isWithPIcons : VVRHhw = ("Export Current PIcon", self.VV6dE0  , [])
      else   : VVRHhw = None
      VVM9Pm     = ("Statistics", FFoB4k, [txt])
      VVMWQK      = ("Zap", self.VVYQCK, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VV2EKM(title, channels, VVMWQK=VVMWQK, VVZArZ=VVZArZ, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw)
   else:
    FFOyl1(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFOyl1(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVE0vv(self, VVdesl, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FF1wB7(self, fncMode=CCqIel.VVYIji, refCode=refCode, chName=chName, text=txt)
 def VV6dE0(self, VVdesl, title, txt, colList):
  png, path = CCuqLp.VV1THp(colList[3], colList[0])
  if path:
   CCuqLp.VVLRoF(self, png, path)
 @staticmethod
 def VVxOqT():
  VV7eR1  = "%slamedb" % VVKJQA
  VVfT9H = "%slamedb.disabled" % VVKJQA
  return VV7eR1, VVfT9H
 @staticmethod
 def VVkOHy():
  VVJVV4  = "%slamedb5" % VVKJQA
  VVUBU4 = "%slamedb5.disabled" % VVKJQA
  return VVJVV4, VVUBU4
 def VVYC9D(self, isEnable):
  VV7eR1, VVfT9H = CCwuBY.VVxOqT()
  if isEnable and not fileExists(VVfT9H):
   FFDeF8(self, "Aready enabled.")
  elif not isEnable and not fileExists(VV7eR1):
   FFOyl1(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFgBNQ(self, BF(self.VVEl5o, isEnable), "%s Hidden Channels ?" % word)
 def VVEl5o(self, isEnable):
  VV7eR1 , VVfT9H = CCwuBY.VVxOqT()
  VVJVV4, VVUBU4 = CCwuBY.VVkOHy()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVfT9H, VVfT9H, VV7eR1)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVUBU4, VVUBU4, VVJVV4)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VV7eR1  , VV7eR1 , VVfT9H)
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVJVV4 , VVJVV4, VVUBU4)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVfT9H, VV7eR1 )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVUBU4, VVJVV4)
  ok = FFqSkC(cmd)
  FFjaui()
  if ok: FFDeF8(self, "Hidden List %s" % word)
  else : FFOyl1(self, "Error while restoring:\n\n%s" % fileName)
 def VVKUMP(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %ssettings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVKJQA
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %ssettings" % VVKJQA
  FFRrmn(self, cmd)
 def VVXtot(self):
  VV7eR1, err = CCwuBY.VVJmSV(self)
  if err:
   return
  tmpFile = "/tmp/ajp_lamedb"
  FFOlRe(tmpFile)
  totChan = totRemoved = 0
  lines = FF72md(VV7eR1, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FFgBNQ(self, BF(FFbA1i, self, BF(self.VV1Qq3, tmpFile, VV7eR1, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FFsfSO(totRemoved), totChan, FFsfSO(totChan))
      , callBack_No=BF(self.VVdaEm, tmpFile))
  else:
   FFoB4k(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VV1Qq3(self, tmpFile, VV7eR1, totRemoved, totChan):
  FFqSkC("mv -f '%s' '%s'" % (tmpFile, VV7eR1))
  FFjaui()
  FFoB4k(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VVdaEm(self, tmpFile):
  FFOlRe(tmpFile)
 @staticmethod
 def VVJmSV(SELF, VVGHpD=True, title=""):
  VV7eR1, VVfT9H = CCwuBY.VVxOqT()
  if   not fileExists(VV7eR1)       : err = "File not found !\n\n%s" % VV7eR1
  elif not CCVnYx.VV8SZ3(SELF, VV7eR1) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VVGHpD:
   FFOyl1(SELF, err, title=title)
  return VV7eR1, err
 @staticmethod
 def VVB9hs(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VVp10c(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VVPwKw(servTypes):
  VVcpye  = eServiceCenter.getInstance()
  VVl1m1   = '%s ORDER BY name' % servTypes
  VVA1Hy   = eServiceReference(VVl1m1)
  VVBPQB = VVcpye.list(VVA1Hy)
  if VVBPQB: return VVBPQB.getContent("CN", False)
  else     : return []
 @staticmethod
 def VVNZgY():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CCqIel(Screen):
 VVajvb  = 0
 VViWfB   = 1
 VVsTiW   = 2
 VVYIji    = 3
 VVk0Au    = 4
 VVA0Zm   = 5
 VVmJLK   = 6
 VV3tb6    = 7
 VVTkls   = 8
 VV4prm   = 9
 VVs6XG   = 10
 VVUU9o   = 11
 EPG_MODE_BOUQUET_EDITOR   = 12
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFPFsH(VVNC84, 1400, 1000, 50, 30, 10, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVajvb)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.portalEpgUrl = kwargs.get("portalEpgUrl", "")
  self.piconShown  = False
  self.Sep   = FF8oA9("%s\n", VVdZck) % SEP
  self.picViewer  = None
  FFRFZg(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VV28kf })
  self["myPicF"] = Label()
  self["myPicB"] = Label()
  self["myPic"] = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVnLQg)
  self.onClose.append(self.onExit)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  self["myLabel"].VV4U7z(outputFileToSave="chann_info")
  if   self.fncMode == self.VVajvb : fnc = self.VVYKwh
  elif self.fncMode == self.VViWfB  : fnc = self.VVYKwh
  elif self.fncMode == self.VVsTiW  : fnc = self.VVYKwh
  elif self.fncMode == self.VVYIji  : fnc = self.VVKWsd
  elif self.fncMode == self.VVk0Au  : fnc = self.VVq4fJ
  elif self.fncMode == self.VVA0Zm  : fnc = self.VV34Be
  elif self.fncMode == self.VVmJLK  : fnc = self.VValMF
  elif self.fncMode == self.VV3tb6  : fnc = self.VV7kyl
  elif self.fncMode == self.VVTkls  : fnc = self.VVHmKQ
  elif self.fncMode == self.VV4prm : fnc = self.VVtTOO
  elif self.fncMode == self.VVs6XG  : fnc = self.VVy9t7
  elif self.fncMode == self.VVUU9o : fnc = self.VVC5Bb
  elif self.fncMode == self.EPG_MODE_BOUQUET_EDITOR : fnc = self.VVDMZX
  self["myLabel"].setText("\n   Reading Info ...")
  self["myLabel"].VVo5pW()
  FFkvVR(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVIcNY()
 def VVTmBj(self, err):
  self["myLabel"].setText(err)
  FFC3pI(self["myTitle"], "#22200000")
  FFC3pI(self["myBody"], "#22200000")
  self["myLabel"].VV5vuE("#22200000")
  self["myLabel"].VVo5pW()
 def VVYKwh(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
  self.refCode = refCode
  self.VV3h8F(chName)
 def VVKWsd(self):
  self.VV3h8F(self.chName)
 def VVq4fJ(self):
  self.VV3h8F(self.chName)
 def VV34Be(self):
  self.VV3h8F(self.chName)
 def VValMF(self):
  self.VV3h8F("Picon Info")
 def VV7kyl(self):
  self.VV3h8F(self.chName)
 def VVHmKQ(self):
  self.VV3h8F(self.chName)
 def VVtTOO(self):
  self.VV3h8F(self.chName)
 def VVy9t7(self):
  if self.chCm.startswith("Zz1") : self.chUrl = FFkr9k(self.chCm[3:])
  else       : self.chUrl = self.refCode + self.callingSELF.VViT3K(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VV3h8F(self.chName)
 def VVC5Bb(self):
  self.VV3h8F(self.chName)
 def VVDMZX(self):
  self.VVG9Pi(self.picPath)
  self.VV2UgW()
 def VV3h8F(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FF7TZz(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVJktg(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.portalEpgUrl or self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    self.text = self.text.rstrip() + "\n\nURL:\n%s\n" % FF8oA9(self.VVrEAP(tUrl), VVD4un)
  if not self.epg:
   epg = CCfTje.VVU9Cp(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVG9Pi(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCuqLp.VV1THp(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVG9Pi(path)
  self.VV6yzq()
  self.VVqCkn(decodedUrl)
  self.VV2UgW()
 def VV2UgW(self):
  self["myLabel"].setText(self.text or "   No active service", VVSDbk=VVjF3K)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVo5pW(minHeight=minH)
 def VVqCkn(self, decodedUrl):
  url = max([self.refCode, self.chUrl, self.iptvRef, self.portalEpgUrl], key=len)
  if not FFueFC(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVJeQa(FFC8zI(url))
  if not epg:
   if self.portalEpgUrl: epg, err = CCOGg2.VVpR2C(self.portalEpgUrl, refCode=self.refCode)
   else    : epg, err = CCOGg2.VVpR2C(decodedUrl, refCode=self.refCode)
  if epg:
   self.text += "\n" + FFHM5m("EPG:", VVRuOi) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VV6yzq()
 def VV6yzq(self):
  if not self.piconShown and self.picUrl:
   path, err = FF4VyK(self.picUrl, "ajp_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVG9Pi(path)
    if self.piconShown and self.refCode:
     self.VVDek6(path, self.refCode)
 def VVDek6(self, path, refCode):
  if path and fileExists(path) and FFLsle("ffmpeg"):
   pPath = CCuqLp.VVchM7()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CCqIel.VVIyOc(path)
    cmd += FFb0lc("mv -f '%s' '%s%s'" % (path, pPath, picon))
    FFqSkC(cmd)
 def VVG9Pi(self, path):
  if path and fileExists(path):
   err, w, h = self.VVXQSn(path)
   if not err:
    if h > w:
     self.VV9gL7(self["myPicF"], w, h, True)
     self.VV9gL7(self["myPicB"], w, h, False)
     self.VV9gL7(self["myPic"] , w, h, False)
   self.picViewer = CCskRx.VV27Hb(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VV9gL7(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVXQSn(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFvL4V(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVJktg(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FF8oA9(chName, VVRuOi)
  txt += self.VVYgG4(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FF8oA9(state, VV8ETX)
   txt += "State\t: %s\n" % state
  w = FFkLkE(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFkLkE(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVWsHu(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVYgG4(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVYgG4(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVYgG4(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVTgEK()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVMwV7()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCqIel.VVNQJi(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FF8oA9("Stream-Relay" if FF81BD(decodedUrl) else "IPTV", VVoIYV)
   txt += self.VV2OTa(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVlofD(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCMbXb()
    tpTxt, namespace = tp.VVCBEO(refCode)
    if tpTxt:
     txt += FF8oA9("Tuner:\n", VVRuOi)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FF8oA9("Codes:\n", VVRuOi)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVYgG4(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVYgG4(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVYgG4(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVYgG4(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVYgG4(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVYgG4(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVYgG4(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVYgG4(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVYgG4(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVWsHu(info):
  if info:
   aspect = FFkLkE(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVYgG4(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFkLkE(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVuuSJ(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVuuSJ(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVTgEK(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VVMwV7(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVlofD(self, refCode, iptvRef, chName):
  refCode = FFhk4f(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFFr8o(VVKJQA + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFFr8o(VVKJQA + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VVcuvv = []
  tmpRefCode = FFC8zI(refCode)
  for item in fList:
   path = VVKJQA + item
   if fileExists(path):
    txt = FFFr8o(path)
    if tmpRefCode in FFC8zI(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVcuvv.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VVcuvv:
   if len(VVcuvv) == 1:
    txt += "%s\t: %s%s\n" % (FF8oA9("Bouquet", VVRuOi), VVcuvv[0][0], " (%s)" % VVcuvv[0][1] if VVk4gu else "")
   else:
    txt += FF8oA9("Bouquets:\n", VVRuOi)
    for ndx, item in enumerate(VVcuvv):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVk4gu else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VV2OTa(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFp63C(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCOGg2()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VV4sir(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FF8oA9("URL:", VVoIYV) + "\n%s\n" % self.VVrEAP(decodedUrl)
  else:
   txt = "\n"
   txt += FF8oA9("Reference:", VVoIYV) + "\n%s\n" % refCode
  return txt
 def VVrEAP(self, url):
  if not FF81BD(url):
   span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
   if span:
    url = span.group(1)
   if not VVXYuQ:
    url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return FFC8zI(url)
 def VVJeQa(self, decodedUrl):
  if not CCFewM.VVmB13():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCoUhv.VV1JTf(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCoUhv.VVnY0U(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVhadr(tDict)
   elif uType == "movie" : epg, picUrl = CCqIel.VVxFTl(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVhadr(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCoUhv.VVGIa1(item, "title"    , is_base64=True )
     lang    = CCoUhv.VVGIa1(item, "lang"         ).upper()
     description   = CCoUhv.VVGIa1(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCoUhv.VVGIa1(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCoUhv.VVGIa1(item, "start_timestamp"      )
     stop_timestamp  = CCoUhv.VVGIa1(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCoUhv.VVGIa1(item, "stop_timestamp"       )
     now_playing   = CCoUhv.VVGIa1(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VV7V3G, ""
      else     : color, txt = VV8ETX , "    (CURRENT EVENT)"
      epg += FF8oA9("_" * 32 + "\n", VVdZck)
      epg += FF8oA9("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FF8oA9(description, VVD4un)
      else   : epg += "Description\t: - \n"
      evNum += 1
      try:
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       totEv, totOK = CCfTje.VVNFjl(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)], longDescDays=7)
      except:
       pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VVxFTl(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCoUhv.VVGIa1(item, "movie_image" )
    genre  = CCoUhv.VVGIa1(item, "genre"   ) or "-"
    plot  = CCoUhv.VVGIa1(item, "plot"   ) or "-"
    country  = CCoUhv.VVGIa1(item, "country"  ) or "-"
    actors  = CCoUhv.VVGIa1(item, "actors"   ) or "-"
    cast  = CCoUhv.VVGIa1(item, "cast"   ) or "-"
    rating  = CCoUhv.VVGIa1(item, "rating"   ) or "-"
    director = CCoUhv.VVGIa1(item, "director"  ) or "-"
    releasedate = CCoUhv.VVGIa1(item, "releasedate" ) or "-"
    duration = CCoUhv.VVGIa1(item, "duration"  ) or "-"
    try:
     lang = CCoUhv.VVGIa1(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Country\t: %s\n"  % country
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FF8oA9(cast if cast != "-" else actors, VVD4un)
    epg += "Plot:\n%s"    % FF8oA9(plot, VVD4un)
   except:
    pass
  return epg, movie_image
 def VV28kf(self):
  if VVXYuQ:
   def VVYgG4(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVYgG4(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCOGg2()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VV4sir(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVYgG4(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (SEP, txt))
   FFZD7H(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVJvyk(SELF):
  if not CCvqvw.VV6Zw5(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(SELF)
  err = url =  fSize = resumable = ""
  if FF9Dqr(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCOGg2.VVY8JV(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCOGg2.VVhc7i(), timeout=4, stream=True, verify=False)
    if not resp.ok:
     FFOyl1(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCVnYx.VVI3LQ(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FF8oA9(" (M3U/M3U8 File)", VVD4un)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCEvBr.VVKihe(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVc2G6(subj, val):
   return "%s\n%s\n\n" % (FF8oA9("%s:" % subj, VVRuOi), val)
  title = "File Size"
  txt  = VVc2G6(title , fSize or "?")
  txt += VVc2G6("Name" , chName)
  txt += VVc2G6("URL" , url)
  if resumable: txt += VVc2G6("Supports Download-Resume", resumable)
  if err  : txt += FF8oA9("Error:\n", VV8ETX) + err
  FFoB4k(SELF, txt, title=title)
 @staticmethod
 def VVNQJi(SELF):
  fPath, fDir, fName = CCVnYx.VVASTW(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVIyOc(path):
  return FFb0lc("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (path, path))
 @staticmethod
 def VVYHPN(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CCuqLp.VVchM7() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VVWQS7(serv):
  isLocal = isIptv = isFtp = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if "file?file" in refCode or ":ftp%3a//" in refCode:
    isFtp = True
    typeTxt = "FTP"
   elif FFueFC(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFGH0N(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCOGg2():
 def __init__(self):
  self.VVRzLJ()
  self.VV8IsJ    = ""
  self.VVvwVA   = "#f#11ffffaa#User"
  self.VVEtEf   = "#f#11aaffff#Server"
 def VVRzLJ(self):
  self.VViEDk   = ""
  self.VVdwIL    = ""
  self.VVCRAJ   = ""
  self.VV1RXl = ""
  self.VVYl1D  = ""
  self.VV2Qzd = 0
 def VVChcY(self, url, mac, ph1="", VVl1IZ=True):
  self.VVRzLJ()
  self.VV8IsJ = {"s": "/server/load.php", "p": "/portal.php", "q": "/portal1.php"}.get(ph1, "")
  host = self.VVlZe0(url)
  if not host:
   if VVl1IZ:
    self.VVoafo("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVb85D(mac)
  if not host:
   if VVl1IZ:
    self.VVoafo("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VViEDk = host
  self.VVdwIL  = mac
  return True
 def VVifYH(self):
  return {"/server/load.php":"s", "/portal.php":"p", "/portal1.php":"q"}.get(self.VV8IsJ, "")
 def VVlZe0(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVb85D(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVaukM(self):
  res, err = self.VV4xKP(self.VVsYOc())
  if "404" in err or res and res.status_code == 200 and not res.text.strip():
   if self.VViEDk.endswith("/c"):
    self.VViEDk = self.VViEDk[:-2]
    res, err = self.VV4xKP(self.VVsYOc())
   elif self.VViEDk.endswith("/stalker_portal"):
    self.VViEDk = self.VViEDk[:-15]
    res, err = self.VV4xKP(self.VVsYOc())
   else:
    self.VViEDk += "/c"
    res, err = self.VV4xKP(self.VVsYOc())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCoUhv.VVGIa1(tDict["js"], "token")
    rand  = CCoUhv.VVGIa1(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVGIta(self, VVl1IZ=True):
  if not self.VV8IsJ:
   self.VVjc47()
  err = blkMsg = FFDeF8Txt = ""
  try:
   token, rand, err = self.VVaukM()
   if token:
    self.VVCRAJ = token
    self.VV1RXl = rand
    if rand:
     self.VV2Qzd = 2
    prof, retTxt = self.VVxn62(True)
    if prof:
     self.VVYl1D = retTxt
     if any(x in retTxt for x in ("device_id mismatch", "old firmware")):
      self.VV2Qzd = 3
      prof, retTxt = self.VVxn62(False)
      if retTxt:
       self.VVYl1D = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFDeF8Txt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFDeF8Txt: tErr += "\n%s" % FFDeF8Txt
  if VVl1IZ:
   self.VVoafo(tErr)
  return "", "", tErr
 def VVjc47(self):
  try:
   import requests
   url = self.VVsZJ1()
   jsFile = "xpcom.common.js"
   res = requests.get("%s/stalker_portal/c/%s" % (url, jsFile), headers=CCOGg2.VVhc7i(), stream=True, timeout=2)
   if not res.ok or not "javascript" in res.headers.get("content-type"):
    res = requests.get("%s/c/%s" % (url, jsFile), headers=CCOGg2.VVhc7i(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    patt = ""
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r"\s*var\s+pattern\s*=\s*\/(.+)\/\s*;", line, IGNORECASE)
      if span:
       patt = span.group(1)
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       if "portal_path" in line:
        if patt.endswith("*\/(.)*") : url += "/c"
        else      : url += "/stalker_portal"
       self.VViEDk = url
       self.VV8IsJ = span.group(1)
       return
  except:
   pass
  self.VV8IsJ = "/server/load.php"
 def VVsZJ1(self):
  url = self.VViEDk.rstrip("/")
  if url.endswith("/c")    : url = url[:-2]
  if url.endswith("/stalker_portal") : url = url[:-15]
  if url.endswith("/c")    : url = url[:-2]
  return url
 def VVkKbF(self, url, isJsFile=False):
  import requests
  jsFile = "xpcom.common.js" if isJsFile else "version.js"
  res, err = self.VV4xKP("%s/stalker_portal/c/%s" % (url, jsFile))
  if not res or not "javascript" in res.headers.get("content-type"):
   res, err = self.VV4xKP("%s/c/%s" % (url, jsFile))
  if res and "javascript" in res.headers.get("content-type"):
   if isJsFile:
    return str(res.content), ""
   else:
    span = iSearch(r"var\s+ver\s*=\s*'(.+)'", res.text, IGNORECASE)
    if span:
     return span.group(1), ""
  return "", err
 def VVxn62(self, capMac):
  res, err = self.VV4xKP(self.VVQ1wG(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCoUhv.VVGIa1(tDict["js"], "block_%s" % word)
    FFDeF8Txt = CCoUhv.VVGIa1(tDict["js"], word)
    return tDict, FFDeF8Txt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVQ1wG(self, capMac):
  param = ""
  if self.VVYl1D or self.VV1RXl:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVdwIL.upper() if capMac else self.VVdwIL.lower(), self.VV1RXl))
  return self.VV7nq4() + "type=stb&action=get_profile" + param
 exec(FFkr9k("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gPSAiJmF1dGhfc2Vjb25kX3N0ZXA9MSZod192ZXJzaW9uPTIuMTctSUItMDAmaHdfdmVyc2lvbl8yPTYyJnNuPSVzJmRldmljZV9pZD0lcyZkZXZpY2VfaWQyPSVzJnNpZ25hdHVyZT0lcyIgJSAoSWRbMF0sIElkWzFdLCBJZFsxXSwgSWRbMl0pDQogcmV0dXJuIHBhcmFtICsgJyZ2ZXI9UGxheWVyIEVuZ2luZSB2ZXJzaW9uOiAweDU4YyZtZXRyaWNzPXsibWFjIjoiJXMiLCJzbiI6IiVzIiwidHlwZSI6IlNUQiIsIm1vZGVsIjoiTUFHMjUwIiwicmFuZG9tIjoiJXMifScgJSAoSWRbM10sIElkWzBdLCBJZFs0XSkNCmRlZiBnZXRNb3JlQXV0aF9JRHMoc2VsZiwgbSwgcik6DQogaW1wb3J0IGhhc2hsaWINCiBtYWNVdGY4ID0gbS5lbmNvZGUoJ3V0Zi04JykNCiBzID0gaGFzaGxpYi5tZDUobWFjVXRmOCkuaGV4ZGlnZXN0KCkudXBwZXIoKVs6MTNdDQogcmV0dXJuIHMsIGhhc2hsaWIuc2hhMjU2KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKCksIGhhc2hsaWIuc2hhMjU2KChzICsgbSkuZW5jb2RlKCd1dGYtOCcpKS5oZXhkaWdlc3QoKS51cHBlcigpLCBtLCBy"))
 def VVCwgh(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVETzr()
  if len(rows) < 10:
   rows = self.VVegHt()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VViEDk ))
   rows.append(("MAC (from URL)" , self.VVdwIL ))
   rows.append(("Token"   , self.VVCRAJ ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VVvwVA  , "MAC" , self.VVdwIL ))
   rows.append(("2", self.VVEtEf, "Host" , self.VViEDk ))
   rows.append(("2", self.VVEtEf, "Token" , self.VVCRAJ ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVQm0f(self, isPhp=True, VVl1IZ=False):
  token, profile, tErr = self.VVGIta(VVl1IZ)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VVM7Ah()
  res, err = self.VV4xKP(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCoUhv.VVGIa1(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFP1tK(span.group(2))
     pass1 = FFP1tK(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VVETzr(self):
  m3u_Url, host, user1, pass1, err = self.VVQm0f()
  rows = []
  if m3u_Url:
   res, err = self.VV4xKP(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFt4wC(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VVvwVA, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFt4wC(int(val))
      else      : val = str(val)
      rows.append(("2", self.VVEtEf, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVegHt(self):
  token, profile, tErr = self.VVGIta()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFRb1j(val): val = FFkr9k(val.decode("UTF-8"))
     else     : val = self.VVdwIL
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFt4wC(int(parts[1]))
      if parts[2] : ends = FFt4wC(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFt4wC(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VViT3K(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVGIta(VVl1IZ=False)
  if not token:
   return ""
  crLinkUrl = self.VVZvD1(mode, chCm, epNum, epId)
  res, err = self.VV4xKP(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCoUhv.VVGIa1(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VV7nq4(self):
  return self.VViEDk + self.VV8IsJ + "?"
 def VVsYOc(self):
  return self.VV7nq4() + "type=stb&action=handshake&token=&mac=%s" % self.VVdwIL
 def VV2gX4(self, mode):
  url = self.VV7nq4() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVjN4D(self, catID):
  return self.VV7nq4() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVi6E1(self, mode, catID, page):
  url = self.VV7nq4() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVPGAI(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VV7nq4() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVMnHL(self, stID):
  return self.VV7nq4() + "type=itv&action=get_short_epg&ch_id=%s" % stID
 def VVZvD1(self, mode, chCm, serCode, serId):
  url = self.VV7nq4() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=0&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVM7Ah(self):
  return self.VV7nq4() + "type=itv&action=create_link"
 def VVaCQl(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVGbMl(catID, stID, chNum)
  query = self.VVukf5(mode, self.VVifYH(), FFx4C0(host), FFx4C0(mac), serCode, serId, chCm, catID, stID)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVukf5(self, mode, ph1, host, mac, serCode, serId, chCm, catID, stID):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&cId=%s&sId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, catID, stID, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VV4sir(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  catID = tDict.get("cId" , [""])[0].strip()
  stID = tDict.get("sId" , [""])[0].strip()
  query = self.VVukf5(mode, ph1, host, mac, epNum, epId, FFP1tK(chCm), catID, stID)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFkr9k(host)
  mac   = FFkr9k(mac)
  valid = False
  if self.VVlZe0(playHost) and self.VVlZe0(host) and self.VVlZe0(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query
 def VV4xKP(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCOGg2.VVhc7i()
   if self.VVCRAJ:
    headers["Authorization"] = "Bearer %s" % self.VVCRAJ
   if useCookies : cookies = {"mac": self.VVdwIL, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=CFG.portalConnTimeout.getValue(), cookies=cookies)
   if res.ok:
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVJ9oy(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCOGg2.VVhc7i(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVhc7i():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 def VVoafo(self, err, title="Portal Browser"):
  FFOyl1(self, str(err), title=title)
 def VVVGwi(self, mode):
  if   mode in ("itv"  , CCoUhv.VVVCMd , CCoUhv.VVGeyj)  : return "Live"
  elif mode in ("vod"  , CCoUhv.VV0Qng , CCoUhv.VVD73g)  : return "VOD"
  elif mode in ("series" , CCoUhv.VV5kkI , CCoUhv.VVIYmB) : return "Series"
  else                          : return "IPTV"
 def VVdEhw(self, mode, searchName):
  return 'Find in %s : %s' % (self.VVVGwi(mode), FF8oA9(searchName, VVD4un))
 def VVMcpt(self, catchup=False):
  VVtMHe = []
  VVtMHe.append(("Live"    , "live"  ))
  VVtMHe.append(("VOD"    , "vod"   ))
  VVtMHe.append(("Series"   , "series"  ))
  if catchup:
   VVtMHe.append(VVXGzj)
   VVtMHe.append(("Catch-up TV" , "catchup"  ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Account Info." , "accountInfo" ))
  return VVtMHe
 @staticmethod
 def VV6Ffa(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCOGg2()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VV4sir(decodedUrl)
  if valid:
   ok = p.VVChcY(host, mac, ph1, VVl1IZ=False)
   if ok:
    m3u_Url, host1, user1, pass1, err = p.VVQm0f(isPhp=False, VVl1IZ=False)
    streamId = CCOGg2.VV92ar(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err
 @staticmethod
 def VV92ar(decodedUrl):
  p = CCOGg2()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VV4sir(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FFkr9k(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVY8JV(decodedUrl):
  p = CCOGg2()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VV4sir(decodedUrl)
  if valid:
   if CCOGg2.VVEA6M(chCm):
    return FFC8zI(chCm)
   else:
    ok = p.VVChcY(host, mac, ph1, VVl1IZ=False)
    if ok:
     try:
      chUrl = p.VViT3K(mode, chCm, epNum, epId)
      return FFC8zI(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VVEA6M(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
 @staticmethod
 def VVpR2C(decodedUrl, retLst=False, refCode=""):
  epg = err = ""
  if "mode=itv" in decodedUrl:
   p = CCOGg2()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VV4sir(decodedUrl)
   if valid:
    if not stID:
     stID = CCOGg2.VV92ar(decodedUrl)
    if stID:
     if p.VVChcY(host, mac, ph1, VVl1IZ=False):
      token, profile, tErr = p.VVGIta(VVl1IZ=False)
      if token:
       res, err = p.VV4xKP(p.VVMnHL(stID))
       if res:
        epg, err = CCOGg2.VVbbRg(res.text, retLst)
        if not retLst and epg and refCode:
         pList, err = CCOGg2.VVbbRg(res.text, retLst=True)
         if pList:
          totEv, totOK = CCfTje.VVNFjl(refCode, pList)
  return epg, err
 @staticmethod
 def VVbbRg(txt, retLst=False):
  epg, lst = "", []
  try:
   tDict = jLoads(txt)
   evNum = 1
   for item in tDict["js"]:
    actor    = CCoUhv.VVGIa1(item, "actor"       )
    category   = CCoUhv.VVGIa1(item, "category"      )
    descr    = CCoUhv.VVGIa1(item, "descr"   , is_base64=True).replace("\n", " .. ")
    director   = CCoUhv.VVGIa1(item, "director"      )
    name    = CCoUhv.VVGIa1(item, "name"   , is_base64=True)
    start_timestamp  = CCoUhv.VVGIa1(item, "start_timestamp", isDate=True )
    start_timestamp_unix= CCoUhv.VVGIa1(item, "start_timestamp"    )
    stop_timestamp  = CCoUhv.VVGIa1(item, "stop_timestamp" , isDate=True )
    stop_timestamp_unix = CCoUhv.VVGIa1(item, "stop_timestamp"     )
    if retLst:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ""
       lst.append((start, dur, name, shortDesc, descr, 1))
     except:
      pass
    else:
     skip, curEv = False, ""
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
      if float(start_timestamp_unix) < iTime() and float(stop_timestamp_unix) > iTime():
       curEv = FF8oA9("    (CURRENT EVENT)", VV7z62)
     except:
      pass
     if not skip:
      epg += FF8oA9("_" * 32 + "\n", VVdZck)
      epg += "Event\t: %d%s\n" % (evNum, curEv)
      epg += "Title\t: %s\n"  % FF8oA9(name, VVRuOi)
      epg += "Start\t: %s\n"  % start_timestamp
      epg += "End\t: %s\n"  % stop_timestamp
      epg += "Description:\n%s\n" % FF8oA9(descr , VVD4un) if descr else "Description\t: - \n"
      epg += "Genre:\n%s\n"  % FF8oA9(category, VVD4un) if category else ""
      epg += "Actors:\n%s\n"  % FF8oA9(actor , VVD4un) if actor else ""
      epg += "Director:\n%s\n" % FF8oA9(director, VVD4un) if director else ""
      evNum += 1
  except:
   return "", "Cannot parse received data !"
  if retLst: return lst, ""
  else  : return epg, ""
class CC1RWP(CCOGg2):
 def __init__(self):
  CCOGg2.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVGpFS(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VV4sir(decodedUrl)
  if valid:
   if self.VVChcY(host, mac, ph1, VVl1IZ=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVqHVf(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  if self.chCm.startswith("Zz1"):
   self.chCm = FFkr9k(self.chCm[3:])
  else:
   try:
    chUrl = self.VViT3K(self.mode, self.chCm, self.epNum, self.epId)
   except:
    return False
  isDirect = False
  if CCOGg2.VVEA6M(self.chCm):
   chUrl = FFC8zI(self.chCm)
   chUrl = FFP1tK(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl.startswith("http"):
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VV8VWR(chUrl)
  bPath = CCotiQ.VVON60()
  if newIptvRef:
   if passedSELF:
    FFoYZf(passedSELF, newIptvRef, VVMFOV=False, fromPortalReplay=True, isFromSession=isFromSession)
   else:
    FFoYZf(self, newIptvRef, VVMFOV=False, fromPortalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VVGYnX(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VV8VWR(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVGYnX(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("ph1", "cId", "sId")
   for par in params:
    newPar = iSub(r"&%s=.*?&" % par, "&", newPar)
   lines = FF72md(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for par in params:
       filePar = iSub(r"&%s=.*?&" % par, "&", filePar)
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFjaui()
class CCwa0B(CC1RWP):
 def __init__(self, passedSession):
  CC1RWP.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVPl3Y(VVA8nc  )
  Main_Menu.VVPl3Y(VVF0VX)
  Main_Menu.VVPl3Y(VVAMRn  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVpwOe, iPlayableService.evEOF: self.VVHnAb, iPlayableService.evEnd: self.VVWmzm})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVmgwE)
  except:
   self.timer2.callback.append(self.VVmgwE)
  self.timer2.start(3000, False)
  self.VVmgwE()
 def VVmgwE(self):
  if not CFG.downloadMonitor.getValue():
   self.VVI78J()
   return
  lst = CCEvBr.VVucv1()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FFF0Rr(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCEvBr.VVMYPh(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin : self.dnldWin = CC817S.VVVwYM(self.passedSession, txt, 30)
   else    : CC817S.VVLCo1(self.dnldWin, txt)
  elif self.dnldWin:
   self.VVI78J()
 def VVI78J(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVpwOe(self):
  self.startTime = iTime()
 def VVHnAb(self):
  global VVGHbd
  VVGHbd = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self.passedSession, isFromSession=True)
    if iptvRef and not "file?file" in iptvRef and not ":ftp%3a//" in iptvRef and not FF9Dqr(decodedUrl):
     self.isFromEOF = True
     CC817S(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVWmzm(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVOptC)
  except:
   self.timer1.callback.append(self.VVOptC)
  self.timer1.start(100, True)
 def VVOptC(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVGpFS(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCuYKB.VVy0QT:
       self.isFromEOF = False
       self.VVqHVf(self.passedSession, isFromSession=True)
class CCBpAz():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Za-z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-Za-z0-9\/\-._:|\]\[]+[\])|:](.+)"
          r"|^[A-Za-z]{,3}[^\x00-\x7F]{,3}\ (.+)")
  self.prefixRemoveList = self.VVxPo1(self.removeTag, "ajpanel_iptv_prefix", False, ())
  self.adultWords = self.VVxPo1(self.hideAdult, "ajpanel_iptv_blacklist", True, ("adult","aduld","sex","porn","xxx","xxi","erotic","x-rated","xrated","skin flick","dirty movie","dirty film","blue movie","blue film","18+","+18","r18 movie","r18 film","r-18 movie","r-18 film","r-17 movie","r-17 film"))
 def VVxPo1(self, cond, fName, isLower, tSet):
  tSet = set(tSet)
  if cond:
   for path in (VV2V68, VVZAJU):
    path += fName
    if fileExists(path):
     for line in FF72md(path):
      line = line.strip()
      if len(line) >= 3:
       tSet.add(line.lower() if isLower else line)
  return tuple(sorted(tSet, key=lambda x: x.lower()))
 def VVz6O6(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCoUhv.VVUkm4(name):
   return CCoUhv.VVEbIh(name)
  return self.VV0oHO(name)
 def VV0oHO(self, name):
  newName = ""
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2) or span.group(3)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     newName = tName
   for t in self.prefixRemoveList:
    if name.startswith(t):
     newName = name[len(t):]
     break
  return newName.strip() or name
 def VV65U4(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VV0oHO(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVkMnb(self, name):
  if self.hideAdult:
   tName = name.lower()
   if any(x in tName for x in self.adultWords):
    return ""
  return name.strip()
 def VVajLT(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVQyXQ(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCvqvw(CCOGg2):
 def __init__(self):
  self.curPortalCatId = ""
  CCOGg2.__init__(self)
 def VViP15(self):
  if CCvqvw.VV6Zw5(self):
   FFbA1i(self, BF(self.VVBfOn, 2), title="Searching ...")
 def VVkEnX(self, winSession, url, mac):
  self.curUrl = url
  if CCvqvw.VV6Zw5(self):
   if self.VVChcY(url, mac):
    FFbA1i(winSession, self.VVaHO9, title="Checking Server ...")
   else:
    FFOyl1(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVsfDf(self, item=None):
  if item:
   VVkbkP, txt, path, ndx = item
   enc = CC2TkW.VV73sc(path, self)
   if enc == -1:
    return
   self.session.open(CCjWUz, barTheme=CCjWUz.VVJmH5
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VV94fY, path, enc)
       , VVCBqA = BF(self.VVttn1, VVkbkP, path))
 def VV94fY(self, path, enc, VVNVFL):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVNVFL.VV0amK(totLines)
  VVNVFL.VVpwcW = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVNVFL or VVNVFL.isCancelled:
     return
    VVNVFL.VViyfK(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVlZe0(url)
     mac  = self.VVb85D(mac)
     if host and mac and VVNVFL:
      VVNVFL.VVpwcW.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVlZe0(url)
      mac  = self.VVb85D(mac)
      if host and mac and not mac.startswith("AC") and VVNVFL:
       VVNVFL.VVpwcW.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVttn1(self, VVkbkP, path, VVdCuP, VVpwcW, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVpwcW:
   VVIzUv  = ("Home Menu"  , FFqjXt            , [])
   VVM9Pm = ("Edit File"  , BF(self.VVEZpK, path)       , [])
   VV1kWx = ("M3U Options" , self.VVwSag         , [])
   VVRHhw = ("Check & Filter" , BF(self.VVfsae, VVkbkP, path), [])
   VVMWQK  = ("Select"   , self.VV29v3      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VV0CnX  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVdesl = FFDpub(self, None, title=title, header=header, VVcuvv=VVpwcW, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=26, VVMWQK=VVMWQK, VVIzUv=VVIzUv, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw, VVaRsg="#0a001122", VVWgai="#0a001122", VVSJJk="#0a001122", VVYCZ6="#00004455", VVTjte="#0a333333", VVIyj7="#11331100", VVEMdg=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VVdCuP:
    FFZD7H(VVdesl, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVdCuP:
    FFOyl1(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVwSag(self, VVdesl, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVtMHe = []
  VVtMHe.append(("Browse as M3U"  , "browse"))
  VVtMHe.append(("Download M3U File" , "downld"))
  FFECK9(self, BF(self.VVOKJr, VVdesl, host, mac), title=title, VVtMHe=VVtMHe, width=600, VVIZXB=True)
 def VVOKJr(self, VVdesl, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FFbA1i(VVdesl, BF(self.VVvZXV, VVdesl, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FFgBNQ(self, BF(FFbA1i, VVdesl, BF(self.VVvZXV, VVdesl, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVvZXV(self, VVdesl, title, host, mac, item):
  p = CCOGg2()
  m3u_Url = ""
  ok = p.VVChcY(host, mac, VVl1IZ=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VVQm0f(VVl1IZ=False)
  if m3u_Url:
   if   item == "browse": self.VVsxAp(title, m3u_Url)
   elif item == "downld": self.VVkULX(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FFOyl1(self, err or "No response from Server !", title=title)
 def VV29v3(self, VVdesl, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVkEnX(VVdesl, url, mac)
 def VVEZpK(self, path, VVdesl, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCiazU(self, path, VVCBqA=BF(self.VVDhpV, VVdesl), curRowNum=rowNum)
  else    : FFbiIe(self, path)
 def VVfsae(self, VVkbkP, path, VVdesl, title, txt, colList):
  self.session.open(CCjWUz, barTheme=CCjWUz.VVh7HE
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VVfSb7, VVdesl)
      , VVCBqA = BF(self.VVEXjV, VVkbkP, VVdesl, path))
 def VVfSb7(self, VVdesl, VVNVFL):
  VVNVFL.VVpwcW = []
  VVNVFL.VV0amK(VVdesl.VVH1h9())
  for row in VVdesl.VVTW2g():
   if not VVNVFL or VVNVFL.isCancelled:
    return
   VVNVFL.VViyfK(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVChcY(host, mac, VVl1IZ=False):
    token, profile, tErr = self.VVGIta(VVl1IZ=False)
    if token and VVNVFL and not VVNVFL.isCancelled:
     res, err = self.VV4xKP(self.VV2gX4("itv"))
     if res and VVNVFL and not VVNVFL.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVNVFL.VViyfK(0, showFound=True)
       VVNVFL.VVpwcW.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVNVFL:
    return
 def VVEXjV(self, VVkbkP, VVdesl, path, VVdCuP, VVpwcW, threadCounter, threadTotal, threadErr):
  if VVpwcW:
   VVdesl.close()
   VVkbkP.close()
   newPath = "%s_OK_%s.txt" % (path, FFZR2n())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVpwcW:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FF8oA9(str(threadCounter), VV8ETX)
    skipped = FF8oA9(str(threadTotal - threadCounter), VV8ETX)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVpwcW)
   txt += "%s\n\n%s"    %  (FF8oA9("Result File:", VVRuOi), newPath)
   FFoB4k(self, txt, title="Accessible Portals")
  elif VVdCuP:
   FFOyl1(self, "No portal access found !", title="Accessible Portals")
 def VVRWyd(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFkr9k(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVaHO9(self):
  token, profile, tErr = self.VVGIta()
  if token:
   dots = "." * self.VV2Qzd
   dots += {"s":"", "p":"+", "q":"++", }.get(self.VVifYH(), "")
   dots += "*" if not self.VViEDk == self.curUrl else ""
   VVtMHe  = self.VVMcpt()
   VVyXO1 = self.VVl4V5
   VVBLNR = self.VV5I9w
   VVEJLl = ("Home Menu", FFqjXt)
   VVIL24= ("Add to Menu", BF(CCoUhv.VVnAMb, self, True, self.VViEDk + "\t" + self.VVdwIL))
   VVrBns = ("Bookmark Server", BF(CCoUhv.VVxMqR, self, True, self.VViEDk + "\t" + self.VVdwIL))
   VVkbkP = FFECK9(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVdwIL, dots), VVtMHe=VVtMHe, VVyXO1=VVyXO1, VVBLNR=VVBLNR, VVEJLl=VVEJLl, VVIL24=VVIL24, VVrBns=VVrBns)
   self.VVxnkp(VVkbkP)
 def VVl4V5(self, item=None):
  if item:
   VVkbkP, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFbA1i(VVkbkP, BF(self.VVwms4, mode), title="Reading Categories ...")
   else : FFbA1i(VVkbkP, BF(self.VVfJgv, VVkbkP, title), title="Reading Account ...")
 def VVfJgv(self, VVkbkP, title, forceMoreInfo=False):
  rows, totCols = self.VVCwgh(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVdwIL)
  VVIzUv  = ("Home Menu" , FFqjXt           , [])
  VV1kWx  = None
  if VVXYuQ:
   VV1kWx = ("Get JS"  , BF(self.VVKDUR, self.VVsZJ1()) , [])
  if totCols == 2:
   VVRHhw = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVRHhw = ("More Info.", BF(self.VVxYjo, VVkbkP)    , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFDpub(self, None, title=title, width=1200, header=header, VVcuvv=rows, VVbG6j=widths, VVGNdU=26, VVIzUv=VVIzUv, VV1kWx=VV1kWx, VVRHhw=VVRHhw, VVaRsg="#0a00292B", VVWgai="#0a002126", VVSJJk="#0a002126", VVYCZ6="#00000000", searchCol=searchCol)
 def VVKDUR(self, url, VVdesl, title, txt, colList):
  FFbA1i(VVdesl, BF(self.VVFw8H, url), title="Getting JS ...")
 def VVFw8H(self, url):
  txt  = "// Host\t: %s\t%s\n" % (url, self.VVdwIL)
  ver, err = self.VVkKbF(url)
  txt += "// Version\t: %s\n\n" % (ver or err)
  js , err = self.VVkKbF(url, isJsFile=True)
  if err: txt += "Error : %s" % err
  else  : txt += js
  FFoB4k(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VVxYjo(self, VVkbkP, VVdesl, title, txt, colList):
  VVdesl.cancel()
  FFbA1i(VVkbkP, BF(self.VVfJgv, VVkbkP, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVwms4(self, mode):
  token, profile, tErr = self.VVGIta()
  if not token:
   return
  res, err = self.VV4xKP(self.VV2gX4(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]
     for item in chList:
      Id   = CCoUhv.VVGIa1(item, "id"       )
      Title  = CCoUhv.VVGIa1(item, "title"      )
      censored = CCoUhv.VVGIa1(item, "censored"     )
      Title = self.VVkMnb(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVk4gu:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVVGwi(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVaRsg, VVWgai, VVSJJk, VVYCZ6 = self.VVJktB(mode)
   mName = self.VVVGwi(mode)
   VVBYRP  = (""     , BF(self.VVY2Vi, mode), [])
   VVMWQK   = ("Show List"   , BF(self.VVuQlz, mode)   , [])
   VVIzUv  = ("Home Menu"   , FFqjXt        , [])
   if mode in ("vod", "series"):
    VVM9Pm = ("Find in %s" % mName , BF(self.VV78oj, mode, False), [])
    VVRHhw = ("Find in Selected" , BF(self.VV78oj, mode, True) , [])
   else:
    VVM9Pm = None
    VVRHhw = None
   header   = None
   widths   = (100   , 0  )
   FFDpub(self, None, title=title, width=1200, header=header, VVcuvv=list, VVbG6j=widths, VVGNdU=30, VVIzUv=VVIzUv, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw, VVBYRP=VVBYRP, VVMWQK=VVMWQK, VVaRsg=VVaRsg, VVWgai=VVWgai, VVSJJk=VVSJJk, VVYCZ6=VVYCZ6, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VVYl1D:
     txt += "\n\n( %s )" % self.VVYl1D
   else:
    txt = "Could not get Categories from server!"
   FFOyl1(self, txt, title=title)
 def VVFNOd(self, mode, VVdesl, title, txt, colList):
  FFbA1i(VVdesl, BF(self.VV0z4Z, mode, VVdesl, title, txt, colList), title="Downloading ...")
 def VV0z4Z(self, mode, VVdesl, title, txt, colList):
  token, profile, tErr = self.VVGIta()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VV4xKP(self.VVjN4D(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]['data']
     for item in chList:
      Id    = CCoUhv.VVGIa1(item, "id"    )
      actors   = CCoUhv.VVGIa1(item, "actors"   )
      added   = CCoUhv.VVGIa1(item, "added"   )
      age    = CCoUhv.VVGIa1(item, "age"   )
      category_id  = CCoUhv.VVGIa1(item, "category_id" )
      description  = CCoUhv.VVGIa1(item, "description" )
      director  = CCoUhv.VVGIa1(item, "director"  )
      genres_str  = CCoUhv.VVGIa1(item, "genres_str"  )
      name   = CCoUhv.VVGIa1(item, "name"   )
      path   = CCoUhv.VVGIa1(item, "path"   )
      screenshot_uri = CCoUhv.VVGIa1(item, "screenshot_uri" )
      series   = CCoUhv.VVGIa1(item, "series"   )
      cmd    = CCoUhv.VVGIa1(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VVBYRP = (""     , BF(self.VVM0an, mode, True)  , [])
   VVMWQK  = ("Play"    , BF(self.VVLvTi, mode)       , [])
   VVZArZ = (""     , BF(self.VVMkOb, mode)     , [])
   VVIzUv = ("Home Menu"   , FFqjXt            , [])
   VV1kWx = ("Download Options" , BF(self.VVbubI, mode, "sp", seriesName) , [])
   VVM9Pm = ("Options"   , BF(self.VVQ9xp, "pEp", mode, seriesName) , [])
   VVRHhw = ("Posters Mode"  , BF(self.VV3yl3, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VV0CnX  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFDpub(self, None, title=seriesName, width=1200, header=header, VVcuvv=list, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=26, VVBYRP=VVBYRP, VVMWQK=VVMWQK, VVZArZ=VVZArZ, VVIzUv=VVIzUv, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw, lastFindConfigObj=CFG.lastFindIptv, VVaRsg="#0a00292B", VVWgai="#0a002126", VVSJJk="#0a002126", VVYCZ6="#00000000")
  else:
   FFOyl1(self, "Could not get Episodes from server!", title=seriesName)
 def VV78oj(self, mode, searchInCat, VVdesl, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVtMHe = []
  VVtMHe.append(("Keyboard"  , "manualEntry"))
  VVtMHe.append(("From Filter" , "fromFilter"))
  FFECK9(self, BF(self.VV4XgS, VVdesl, mode, searchCatId), title="Input Type", VVtMHe=VVtMHe, width=400)
 def VV4XgS(self, VVdesl, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFdnKb(self, BF(self.VVeTqE, VVdesl, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CC6kzI(self)
    filterObj.VVZBdt(BF(self.VVeTqE, VVdesl, mode, searchCatId))
 def VVeTqE(self, VVdesl, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FF0UO9(CFG.lastFindIptv, searchName)
   title = self.VVdEhw(mode, searchName)
   if "," in searchName : FFOyl1(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FFOyl1(self, "Enter at least 3 characters.", title=title)
   else     :
    if CFG.hideIptvServerAdultWords.getValue() and self.VVajLT([searchName]):
     FFOyl1(self, self.VVQyXQ(), title=title)
    else:
     self.VVru6D(mode, searchName, "", searchName, searchCatId)
 def VVuQlz(self, mode, VVdesl, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.curPortalCatId = catID
  self.VVru6D(mode, bName, catID, "", "")
 def VVru6D(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CCjWUz, barTheme=CCjWUz.VVJmH5
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVB3KX, mode, bName, catID, searchName, searchCatId)
      , VVCBqA = BF(self.VVUmkT, mode, bName, catID, searchName, searchCatId))
 def VVUmkT(self, mode, bName, catID, searchName, searchCatId, VVdCuP, VVpwcW, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVdEhw(mode, searchName)
  else   : title = "%s : %s" % (self.VVVGwi(mode), bName)
  if VVpwcW:
   VV1kWx = None
   VVM9Pm = None
   if mode == "series":
    VVaRsg, VVWgai, VVSJJk, VVYCZ6 = self.VVJktB("series2")
    VVMWQK  = ("Episodes"   , BF(self.VVFNOd, mode)           , [])
   else:
    VVaRsg, VVWgai, VVSJJk, VVYCZ6 = self.VVJktB("")
    VVMWQK  = ("Play"    , BF(self.VVLvTi, mode)           , [])
    VV1kWx = ("Download Options" , BF(self.VVbubI, mode, "vp" if mode == "vod" else "", "") , [])
    VVM9Pm = ("Options"   , BF(self.VVQ9xp, "pCh", mode, bName)      , [])
   VVBYRP = (""      , BF(self.VVM0an, mode, False)      , [])
   VVZArZ = (""      , BF(self.VVCnZx, mode)         , [])
   VVIzUv = ("Home Menu"    , FFqjXt                , [])
   VVRHhw = ("Posters Mode"   , BF(self.VV3yl3, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Cat./Genre" , "Logo", "play", "actors" , "descr" , "director")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25   , 6  , 0  , 0   , 0   , 0   )
   VV0CnX  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT   , CENTER, LEFT , LEFT  , LEFT  , LEFT  )
   VVdesl = FFDpub(self, None, title=title, header=header, VVcuvv=VVpwcW, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=26, VVIzUv=VVIzUv, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw, lastFindConfigObj=CFG.lastFindIptv, VVMWQK=VVMWQK, VVBYRP=VVBYRP, VVZArZ=VVZArZ, VVaRsg=VVaRsg, VVWgai=VVWgai, VVSJJk=VVSJJk, VVYCZ6=VVYCZ6, VVEMdg=True, searchCol=1)
   if not VVdCuP:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVdesl.VVOiVj(VVdesl.VVtVut() + tot)
    if threadErr: FFZD7H(VVdesl, "Error while reading !", 2000)
    else  : FFZD7H(VVdesl, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFOyl1(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFOyl1(self, "Could not get list from server !", title=title)
 def VVCnZx(self, mode, VVdesl, title, txt, colList):
  ttl = lambda x, y: "%s:\n%s\n\n" % (FF8oA9(x, VVRuOi), str(y)) if y.strip() and not "N/A" in y else ""
  tab = lambda x, y: "%s\t: %s\n" % (x, y) if y.strip() and not "N/A" in y else ""
  Num, Name, catID, genreID, Icon, cmd, Cat_Genre, Logo, play, actors, descr, director = colList
  txt  = tab("Number"  , Num)
  txt += tab("Name"  , Name)
  txt += tab("Cat./Genre" , Cat_Genre)
  txt += tab("Director" , director)
  txt += "\n"
  txt += ttl("Actors"  , actors)
  txt += ttl("Description", descr)
  play = play.strip()
  if play and not play.startswith("[No "):
   txt += ttl("Cur. Playing", play)
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FF1wB7(self, fncMode=CCqIel.VVUU9o, portalHost=self.VViEDk, portalMac=self.VVdwIL, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVgfes(mode, VVdesl, title, txt, colList)
 def VVMkOb(self, mode, VVdesl, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FF8oA9(colList[10], VVD4un)
  txt += "Description:\n%s" % FF8oA9(colList[11], VVD4un)
  self.VVgfes(mode, VVdesl, title, txt, colList)
 def VVgfes(self, mode, VVdesl, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVE4tz(mode, colList)
  refCode, chUrl = self.VVaCQl(self.VViEDk, self.VVdwIL, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FF1wB7(self, fncMode=CCqIel.VVs6XG, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId, portalEpgUrl=chUrl)
 def VVB3KX(self, mode, bName, catID, searchName, searchCatId, VVNVFL):
  try:
   token, profile, tErr = self.VVGIta()
   if not token:
    return
   if VVNVFL.isCancelled:
    return
   VVNVFL.VVpwcW, total_items, max_page_items, err = self.VVjd6o(mode, catID, 1, 1, searchName, searchCatId)
   if VVNVFL.isCancelled:
    return
   if VVNVFL.VVpwcW and total_items > -1 and max_page_items > -1:
    VVNVFL.VV0amK(total_items)
    VVNVFL.VViyfK(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVNVFL.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVjd6o(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVNVFL.VV3FZH()
     if VVNVFL.isCancelled:
      return
     if list:
      VVNVFL.VVpwcW += list
      VVNVFL.VViyfK(len(list), True)
  except:
   pass
 def VVjd6o(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVPGAI(mode, searchName, searchCatId, page)
  else   : url = self.VVi6E1(mode, catID, page)
  res, err = self.VV4xKP(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVs8TG(CCoUhv.VVGIa1(item, "total_items" ))
     max_page_items = self.VVs8TG(CCoUhv.VVGIa1(item, "max_page_items" ))
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCoUhv.VVGIa1(item, "id"    )
      name   = CCoUhv.VVGIa1(item, "name"   )
      o_name   = CCoUhv.VVGIa1(item, "o_name"   )
      category_id  = CCoUhv.VVGIa1(item, "category_id" )
      tv_genre_id  = CCoUhv.VVGIa1(item, "tv_genre_id" )
      number   = CCoUhv.VVGIa1(item, "number"   ) or str(counter)
      logo   = CCoUhv.VVGIa1(item, "logo"   )
      screenshot_uri = CCoUhv.VVGIa1(item, "screenshot_uri" )
      pic    = CCoUhv.VVGIa1(item, "pic"   )
      cmd    = CCoUhv.VVGIa1(item, "cmd"   )
      censored  = CCoUhv.VVGIa1(item, "censored"  )
      genres_str  = CCoUhv.VVGIa1(item, "genres_str"  )
      curPlay   = CCoUhv.VVGIa1(item, "cur_playing" )
      actors   = CCoUhv.VVGIa1(item, "actors"   )
      descr   = CCoUhv.VVGIa1(item, "description" )
      director  = CCoUhv.VVGIa1(item, "director"  )
      catID   = category_id or tv_genre_id
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       if "token=" in cmd and "d=Mag" in cmd:
        cmd = "Zz1" + FFx4C0(cmd)
       else:
        span = iSearch(r"stream=(.+)&", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
        else:
         span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
         if span:
          cmd = "%s%s_" % (cmdStr, span.group(1))
      if   logo.startswith("http")   : picon = logo
      elif pic.startswith("http")    : picon = pic
      elif screenshot_uri.startswith("http") : picon = screenshot_uri
      else         : picon = logo or screenshot_uri or pic
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VViEDk + picon).replace(sp * 2, sp)
      isIcon = "Yes" if picon.startswith("http") else ""
      counter += 1
      name = self.VVz6O6(name, censored)
      if name:
       list.append((number, name, Id, catID, picon, cmd, genres_str, isIcon, curPlay, actors, descr, director))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVs8TG(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVLvTi(self, mode, VVdesl, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVE4tz(mode, colList)
  refCode, chUrl = self.VVaCQl(self.VViEDk, self.VVdwIL, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVUkm4(chName):
   FFZD7H(VVdesl, "This is a marker!", 300)
  else:
   FFbA1i(VVdesl, BF(self.VVH1XD, mode, VVdesl, chUrl), title="Playing ...")
 def VVH1XD(self, mode, VVdesl, chUrl):
  FFoYZf(self, chUrl, VVMFOV=False)
  CCuYKB.VVa42W(self.session, iptvTableParams=(self, VVdesl, mode))
 def VVicXd(self, mode, VVdesl, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVE4tz(mode, colList)
  refCode, chUrl = self.VVaCQl(self.VViEDk, self.VVdwIL, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVE4tz(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "_")
  else:
   chNum = colList[0]
   chName = colList[1]
   stID = colList[2]
   catID = colList[3]
   picUrl = colList[4]
   chCm = colList[5]
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VV6Zw5(SELF, install=True, cbFnc=None):
  try:
   import requests
   return True
  except:
   if install:
    title = 'Install "Requests"'
    VVtMHe = []
    VVtMHe.append((title        , "inst" ))
    VVtMHe.append(("Update Packages then %s" % title , "updInst" ))
    FFECK9(SELF, BF(CCvqvw.VVLqfL, SELF, cbFnc=cbFnc), title='This requires Python "Requests" library', VVtMHe=VVtMHe)
   return False
 @staticmethod
 def VVLqfL(SELF, item=None, cbFnc=None):
  if item:
   cmdUpd = FFRkrW(VVjmk7, "")
   if cmdUpd:
    cmdInst = FFbfXZ(VVqrBj, "python-requests")
    if pyVersion[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFyrLj(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library', VV4qLc=cbFnc)
   else:
    FFvp5w(SELF)
 def VVkcLy(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VV4sir(decodedUrl)
  return mode, host, catID, stID, epNum.replace("%3a", ":"), epId.replace("%3a", ":")
 def VVxnkp(self, VVkbkP):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVkcLy()
  if all((curMode, curHost, curCat)) and curHost == self.VViEDk:
   VVkbkP.VV27hm({"itv": 0, "vod": 1, "series": 2}.get(curMode, 0))
 def VVY2Vi(self, mode, VVdesl, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVkcLy()
  if all((curMode, curHost, curCat)) and curMode == mode and curHost == self.VViEDk:
   VVdesl.VVQMdW({1:curCat})
 def VVM0an(self, mode, isEp, VVdesl, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVkcLy()
  if all((curMode, curHost, curCat)) and curCat == self.curPortalCatId and curMode == mode and curHost == self.VViEDk:
   if mode in ("itv", "vod"):
    VVdesl.VVQMdW({2:curStID})
   else: #series
    if isEp:
     VVdesl.VVQMdW({2:curEpNum, 4:curEpId})
    elif mode == "series":
     ser1 = curEpId.split(":")[0]
     ser2 = "%s:%s" % (ser1, ser1)
     ok = VVdesl.VVQMdW({2:ser2})
     if not ok: VVdesl.VVQMdW({2:ser1})
class CCoUhv(Screen, CCvqvw, CCBpAz, CC8zCm):
 VVD1Oc    = 0
 VVUxtW    = 1
 VVTK3V    = 2
 VVRk1a    = 3
 VVOFfP     = 4
 VVy14D     = 5
 VV2r82     = 6
 VVFLIc     = 7
 VVemTZ     = 8
 VVW7YW     = 9
 VVhz13      = 10
 VV2AbK     = 11
 VVSwNU     = 12
 VVMqLl     = 13
 VVSaL8     = 14
 VVcx7H      = 15
 VVzk9y      = 16
 VVxgk2      = 17
 VVIedT      = 18
 VVeLFj      = 19
 VVwXOG    = 0
 VVVCMd   = 1
 VV0Qng   = 2
 VV5kkI   = 3
 VVSMo0  = 4
 VVkTlW  = 5
 VVGeyj   = 6
 VVD73g   = 7
 VVIYmB  = 8
 VVIWj9  = 9
 VVmA98  = 10
 VVCJ2r = 0
 VVyjyT = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFPFsH(VVMjBN, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28, topRightBtns=1)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVdesl    = None
  self.tableTitle     = "IPTV Channels List"
  self.VV5nPVData    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CCoUhv.VVDteM(atLeastOne=True)
  self.isFirstTime    = True
  self.curUrl      = ""
  CCvqvw.__init__(self)
  CCBpAz.__init__(self)
  VVtMHe = self.VVvGqt()
  FFRFZg(self, title="IPTV", VVtMHe=VVtMHe)
  self["myActionMap"].actions.update({
   "menu" : self.VVsYEt
  })
  self.onShown.append(self.VVnLQg)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVdKu7)
  global VVVVVT
  VVVVVT = True
 def VVnLQg(self):
  self["myMenu"].setList(self.VVvGqt())
  FFJI0m(self)
  FFk6h6(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FFWIRJ(self["myMenu"])
   FFTaOD(self)
   if self.m3uOrM3u8File:
    self.VViIxe(self.m3uOrM3u8File)
   else:
    self.VVxN08()
 def VVxN08(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
  if "chCode" in decodedUrl:
   for ndx, item in enumerate(self["myMenu"].list):
    if item[0] == "IPTV Server Browser (from Current Channel)" and len(item) > 1:
     self["myMenu"].moveToIndex(ndx)
     break
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  FFLJqp("VVVVVT")
 def VVdKu7(self):
  if self["myMenu"].getCurrent()[1] in ("VVxTeH", "VVVNFuPortal") : self["keyMenu"].show()
  else                      : self["keyMenu"].hide()
 def VVsYEt(self):
  if self["myMenu"].getVisible():
   title, item = self["myMenu"].getCurrent()
   if   item == "VVVNFuPortal" : confItem = CFG.favServerPortal
   elif item == "VVxTeH" : confItem = CFG.favServerPlaylist
   else         : return
   FFgBNQ(self, BF(self.VV1eML, confItem), 'Remove from menu ?', title=title)
 def VV1eML(self, confItem):
  FF0UO9(confItem, "")
  self.VVnLQg()
 def VVvGqt(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VV4mV2
  VVtMHe = []
  if isFav1: VVtMHe.append((c +  "Favourite Playlist Server"   , "VVxTeH" ))
  if isFav2: VVtMHe.append((c +  "Favourite Portal Server"    , "VVVNFuPortal" ))
  VVtMHe.append(("IPTV Server Browser (from Playlists)"     , "VV5nPV_fromPlayList" ))
  VVtMHe.append(("IPTV Server Browser (from Portal List)"    , "VV5nPV_fromMac"  ))
  VVtMHe.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VV5nPV_fromM3u"  ))
  qUrl, iptvRef = CCoUhv.VVToal(self)
  fromCurCond = qUrl or "chCode" in iptvRef
  VVtMHe.append(FFQlwu("IPTV Server Browser (from Current Channel)", "VV5nPV_fromCurrChan", fromCurCond))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("M3U/M3U8 File Browser"        , "VVTZbV"   ))
  if self.iptvFileAvailable:
   VVtMHe.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(FFQlwu("Update Current Bouquet EPG (from IPTV Server)" , "refreshIptvEPG"  , fromCurCond))
  VVtMHe.append(FFQlwu("Update Current Bouquet PIcons (from IPTV Server)" , "refreshIptvPicons", fromCurCond))
  if self.iptvFileAvailable:
   VVtMHe.append(VVXGzj)
   c1, c2 = VVdVTX, VVRuOi
   t1 = FF8oA9("auto-match names", VV4mV2)
   t2 = FF8oA9("from xml file"  , VV4mV2)
   VVtMHe.append((c1 + "Count Available IPTV Channels"    , "VVH44T"    ))
   VVtMHe.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVtMHe.append(VVXGzj)
   VVtMHe.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVtMHe.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VV8hOV" ))
   VVtMHe.append((VVtchu + "More Reference Tools ..."  , "VV6YVI"   ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Reload Channels and Bouquets"       , "VV0wZE"   ))
  VVtMHe.append(VVXGzj)
  if not CCEvBr.VVk9dH():
   VVtMHe.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVtMHe.append(("Download Manager ... No downloads"    ,       ))
  return VVtMHe
 def VVvmYM(self, item):
  self.curUrl = ""
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVXGxI"   : self.VVXGxI()
   elif item == "VVAB2o" : FFgBNQ(self, self.VVAB2o, "Change Current List References to Unique Codes ?")
   elif item == "VVLW53_rows" : FFgBNQ(self, BF(FFbA1i, self.VVdesl, self.VVLW53), "Change Current List References to Identical Codes ?")
   elif item == "VVchKB"   : self.VVchKB(tTitle)
   elif item == "VVDSmz"   : self.VVDSmz(tTitle)
   elif item == "VVxTeH" : self.VVVNFu(False)
   elif item == "VVVNFuPortal" : self.VVVNFu(True)
   elif item == "VV5nPV_fromPlayList" : FFbA1i(self, BF(self.VVBfOn, 1), title=title)
   elif item == "VV5nPV_fromM3u"  : FFbA1i(self, BF(self.VVR8m8, CCoUhv.VVCJ2r), title=title)
   elif item == "VV5nPV_fromMac"  : self.VViP15()
   elif item == "VV5nPV_fromCurrChan" : self.VVginf()
   elif item == "VVTZbV"   : self.VVTZbV()
   elif item == "iptvTable_all"   : FFbA1i(self, BF(self.VVLKh1, self.VVD1Oc), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : CCoUhv.VVAZLx(self)
   elif item == "refreshIptvPicons"  : self.VVJxLR()
   elif item == "VVH44T"    : FFbA1i(self, self.VVH44T)
   elif item == "copyEpgPicons"   : self.VV3AUZ(False)
   elif item == "renumIptvRef_fromFile" : self.VV3AUZ(True)
   elif item == "VV8hOV" : FFgBNQ(self, BF(FFbA1i, self, self.VV8hOV), VVStYd="Continue ?")
   elif item == "VV6YVI"    : self.VV6YVI()
   elif item == "VV0wZE"   : FFbA1i(self, BF(CCwuBY.VV0wZE, self))
   elif item == "dload_stat"    : CCEvBr.VVQOcZ(self)
 def VVTZbV(self):
  if CCvqvw.VV6Zw5(self):
   FFbA1i(self, BF(self.VVR8m8, CCoUhv.VVyjyT), title="Searching ...")
 def VV2Iyl(self):
  global VVsQSL
  VVsQSL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVvmYM(item)
 def VVLKh1(self, mode):
  VVsLLE = self.VVdbgy(mode)
  if VVsLLE:
   VV1kWx = ("Current Service", self.VVNjxQ , [])
   VVM9Pm = ("Options"  , self.VV7OEe   , [])
   VVRHhw = ("Filter"   , self.VVBRav   , [])
   VVMWQK  = ("Play"   , BF(self.VVgPgk)  , [])
   VVZArZ = (""    , self.VVRZKi    , [])
   VVBYRP = (""    , self.VVa7NV     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VV0CnX  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FFDpub(self, None, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=26
     , VVMWQK=VVMWQK, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw, VVZArZ=VVZArZ, VVBYRP=VVBYRP
     , VVaRsg="#0a00292B", VVWgai="#0a002126", VVSJJk="#0a002126", VVYCZ6="#00000000", VVEMdg=True, searchCol=1)
  else:
   if mode == self.VVW7YW: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFOyl1(self, err)
 def VVa7NV(self, VVdesl, title, txt, colList):
  self.VVdesl = VVdesl
 def VV7OEe(self, VVdesl, title, txt, colList):
  VVtMHe = []
  VVtMHe.append(("Add Current List to a New Bouquet"    , "VVXGxI"  ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Change Current List References to Unique Codes" , "VVAB2o"))
  VVtMHe.append(("Change Current List References to Identical Codes", "VVLW53_rows" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Share Reference with DVB Service (manual entry)" , "VVchKB"   ))
  VVtMHe.append(("Share Reference with DVB Service (auto-find)"  , "VVDSmz"   ))
  FFECK9(self, self.VVvmYM, title="IPTV Tools", VVtMHe=VVtMHe)
 def VVBRav(self, VVdesl, title, txt, colList):
  FFbA1i(VVdesl, BF(self.VVLMg9, VVdesl))
 def VVLMg9(self, VVdesl):
  VVtMHe = []
  VVtMHe.append(("All"         , "all"   ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Prefix of Selected Channel"   , "sameName" ))
  VVtMHe.append(("Suggest Words from Selected Channel" , "partName" ))
  VVtMHe.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVtMHe.append(("Duplicate References"     , "depRef"  ))
  VVtMHe.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVtMHe.append(("Stream Relay"       , "SRelay"  ))
  VVtMHe.append(FF5f5W("Category"))
  VVtMHe.append(("Live TV"        , "live"  ))
  VVtMHe.append(("VOD"         , "vod"   ))
  VVtMHe.append(("Series"        , "series"  ))
  VVtMHe.append(("Uncategorised"      , "uncat"  ))
  VVtMHe.append(FF5f5W("Media"))
  VVtMHe.append(("Video"        , "video"  ))
  VVtMHe.append(("Audio"        , "audio"  ))
  VVtMHe.append(FF5f5W("File Type"))
  VVtMHe.append(("MKV"         , "MKV"   ))
  VVtMHe.append(("MP4"         , "MP4"   ))
  VVtMHe.append(("MP3"         , "MP3"   ))
  VVtMHe.append(("AVI"         , "AVI"   ))
  VVtMHe.append(("FLV"         , "FLV"   ))
  VVtMHe.extend(CCotiQ.VVq4e6(prefix="__b__", onlyIptv=True))
  inFilterFnc = BF(self.VVmcW2, VVdesl) if VVdesl.VVtVut().startswith("IPTV Filter ") else None
  filterObj = CC6kzI(self)
  filterObj.VVmQ3J(VVtMHe, VVtMHe, BF(self.VVyy1b, VVdesl, False), inFilterFnc=inFilterFnc)
 def VVmcW2(self, VVdesl, VVkbkP, item):
  self.VVyy1b(VVdesl, True, item)
 def VVyy1b(self, VVdesl, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVdesl.VVxBD7(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVD1Oc , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVUxtW , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVTK3V , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVRk1a , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VV2r82  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VVFLIc  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "SRelay"   : mode, words, title = self.VVemTZ  , ""  , f + "= Stream Relay"
   elif item == "live"    : mode, words, title = self.VVW7YW  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVhz13   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VV2AbK  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVSwNU  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVMqLl  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVSaL8  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVcx7H   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVzk9y   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVxgk2   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVIedT   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVeLFj   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVOFfP  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVy14D  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVTK3V:
   VVtMHe = []
   chName = VVdesl.VVxBD7(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVtMHe.append((item, item))
    if not VVtMHe and chName:
     VVtMHe.append((chName, chName))
    FFECK9(self, BF(self.VVOWm5, title), title="Words from Current Selection", VVtMHe=VVtMHe)
   else:
    VVdesl.VVz4xL("Invalid Channel Name")
  else:
   words, asPrefix = CC6kzI.VVV2i7(words)
   if not words and mode in (self.VVOFfP, self.VVy14D):
    FFZD7H(self.VVdesl, "Incorrect filter", 2000)
   else:
    FFbA1i(self.VVdesl, BF(self.VVkwux, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VVOWm5(self, title, word=None):
  if word:
   words = [word.lower()]
   FFbA1i(self.VVdesl, BF(self.VVkwux, self.VVTK3V, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVEbIh(txt):
  return "#f#11ffff00#" + txt
 def VVkwux(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVsLLE = self.VVUb82(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVsLLE = self.VVdbgy(mode=mode, words=words, asPrefix=asPrefix)
  if VVsLLE : self.VVdesl.VV87pY(VVsLLE, title)
  else  : self.VVdesl.VVz4xL("Not found")
 def VVUb82(self, mode=0, words=None, asPrefix=False):
  VVsLLE = []
  for row in self.VVdesl.VVTW2g():
   row = list(map(str.strip, row))
   chNum, chName, VVFLv8, chType, refCode, url = row
   if self.VVEK12(mode, refCode, FFC8zI(url).lower(), chName, words, VVFLv8.lower(), asPrefix):
    VVsLLE.append(row)
  VVsLLE = self.VVayXi(mode, VVsLLE)
  return VVsLLE
 def VVdbgy(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VVsLLE = []
  files = CCoUhv.VVDteM()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFFr8o(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVFLv8 = span.group(1)
    else : VVFLv8 = ""
    VVFLv8_lCase = VVFLv8.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVUkm4(chName): chNameMod = self.VVEbIh(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVFLv8, chType + (" SRel" if FF81BD(url) else ""), refCode, url)
     if self.VVEK12(mode, refCode, FFC8zI(url).lower(), chName, words, VVFLv8_lCase, asPrefix):
      VVsLLE.append(row)
      chNum += 1
  VVsLLE = self.VVayXi(mode, VVsLLE)
  return VVsLLE
 def VVayXi(self, mode, VVsLLE):
  newRows = []
  if VVsLLE and mode == self.VV2r82:
   counted  = iCounter(elem[4] for elem in VVsLLE)
   for item in VVsLLE:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVsLLE
 def VVEK12(self, mode, refCode, tUrl, chName, words, VVFLv8_lCase, asPrefix):
  if   mode == self.VVD1Oc : return True
  elif mode == self.VV2r82 : return True
  elif mode == self.VVFLIc  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VVemTZ : return FF81BD(tUrl)
  elif mode == self.VVMqLl  : return CCoUhv.VV1JTf(tUrl, getAudVid=True) == "vid"
  elif mode == self.VVSaL8  : return CCoUhv.VV1JTf(tUrl, getAudVid=True) == "aud"
  elif mode == self.VVW7YW  : return CCoUhv.VV1JTf(tUrl, compareType="live")
  elif mode == self.VVhz13  : return CCoUhv.VV1JTf(tUrl, compareType="movie")
  elif mode == self.VV2AbK : return CCoUhv.VV1JTf(tUrl, compareType="series")
  elif mode == self.VVSwNU  : return CCoUhv.VV1JTf(tUrl, compareType="")
  elif mode == self.VVcx7H  : return CCoUhv.VV1JTf(tUrl, compareExt="mkv")
  elif mode == self.VVzk9y  : return CCoUhv.VV1JTf(tUrl, compareExt="mp4")
  elif mode == self.VVxgk2  : return CCoUhv.VV1JTf(tUrl, compareExt="mp3")
  elif mode == self.VVIedT  : return CCoUhv.VV1JTf(tUrl, compareExt="avi")
  elif mode == self.VVeLFj  : return CCoUhv.VV1JTf(tUrl, compareExt="flv")
  elif mode == self.VVUxtW: return chName.lower().startswith(words[0])
  elif mode == self.VVTK3V: return words[0] in chName.lower()
  elif mode == self.VVRk1a: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVOFfP : return words[0] == VVFLv8_lCase
  elif mode == self.VVy14D :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVXGxI(self):
  picker = CCotiQ(self, self.VVdesl, "Add to Bouquet", self.VV8t2F)
 def VV8t2F(self):
  chUrlLst = []
  for row in self.VVdesl.VVTW2g():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VV6YVI(self):
  t1 = FF8oA9("Bouquet" , VVRuOi)
  t2 = FF8oA9("ALL"  , VVtchu)
  t3 = FF8oA9("Unique"  , VVdVTX)
  t4 = FF8oA9("Identical" , VV4mV2)
  VVtMHe = []
  VVtMHe.append((VV7z62 + "Check System Acceptable Reference Types", "VVJLyf"))
  VVtMHe.append(FFQlwu("Check Reference Codes Format", "VViZ0s", self.iptvFileAvailable, VV7z62))
  VVtMHe.append(VVXGzj)
  txt = "Change %s Ref. Types to (1/4097/5001/5002/8192/8193) .."
  VVtMHe.append((txt % t1, "VVb10J" ))
  VVtMHe.append((txt % t2, "VVlmn4_all"  ))
  VVtMHe.append(VVXGzj)
  txt = "Change %s References to %s Codes .."
  VVtMHe.append((txt % (t1, t3), "VVJ5Lb" ))
  VVtMHe.append((txt % (t2, t3), "VVZlnw"  ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Change %s References to %s Codes" % (t2, t4) , "VVLW53_all"))
  VVyXO1 = self.VVAzSI
  FFECK9(self, None, width=1150, title="IPTV Reference Tools", VVtMHe=VVtMHe, VVyXO1=VVyXO1, VVaRsg="#22002233", VVWgai="#22001122")
 def VVAzSI(self, item=None):
  if item:
   ques = "Continue ?"
   VVkbkP, txt, item, ndx = item
   if   item == "VVJLyf"    : FFbA1i(VVkbkP, self.VVJLyf)
   elif item == "VViZ0s"     : FFbA1i(VVkbkP, self.VViZ0s)
   elif item == "VVb10J" : self.VViZHb(VVkbkP, self.VVpJgy)
   elif item == "VVlmn4_all"  : self.VVpJgy(VVkbkP, None, None)
   elif item == "VVJ5Lb" : self.VVJ5Lb(VVkbkP, txt)
   elif item == "VVZlnw"  : FFgBNQ(self, BF(self.VVZlnw , VVkbkP, txt), title=txt, VVStYd=ques)
   elif item == "VVLW53_all"  : FFgBNQ(self, BF(FFbA1i, VVkbkP, self.VVLW53), title=txt, VVStYd=ques)
 def VVpJgy(self, VVkbkP, bName, bPath):
  VVtMHe = []
  for rt in CCoUhv.VVO4pN():
   VVtMHe.append(("%s\t ... %s" % (rt, CCoUhv.VVnTMx(rt)), rt))
  FFECK9(self, BF(self.VVD4Bu, VVkbkP, bName, bPath), VVtMHe=VVtMHe, width=800, title="Change Reference Types to:")
 def VVD4Bu(self, VVkbkP, bName, bPath, rType=None):
  if rType:
   self.VVt6Qx(VVkbkP, bName, bPath, rType)
 def VViZHb(self, VVkbkP, fnc):
  VVtMHe = CCotiQ.VVq4e6()
  if VVtMHe:
   FFECK9(self, BF(self.VVS0Vl, VVkbkP, fnc), VVtMHe=VVtMHe, title="IPTV Bouquets", VVIZXB=True)
  else:
   FFZD7H(VVkbkP, "No bouquets Found !", 1500)
 def VVS0Vl(self, VVkbkP, fnc, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVKJQA + span.group(1)
    if fileExists(bPath): fnc(VVkbkP, bName, bPath)
    else    : FFZD7H(VVkbkP, "Bouquet file not found!", 2000)
   else:
    FFZD7H(VVkbkP, "Cannot process bouquet !", 2000)
 def VVt6Qx(self, VVkbkP, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FF8oA9(bName, VVXAXH)
  else : title = "Change for %s" % FF8oA9("All IPTV Services", VVXAXH)
  FFgBNQ(self, BF(FFbA1i, VVkbkP, BF(self.VVTsFJ, VVkbkP, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FF8oA9(rType, VVXAXH), title=title)
 def VVTsFJ(self, VVkbkP, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = CCoUhv.VVDteM()
  if files:
   newRType = rType + ":"
   piconPath = CCuqLp.VVchM7()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CCVnYx.VV8SZ3(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FFOyl1(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           FFqSkC("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png"))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    FFqSkC(cmd)
  self.VVIeTz(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VVH44T(self):
  totFiles = 0
  files  = CCoUhv.VVDteM()
  if files:
   totFiles = len(files)
  totChans = 0
  VVsLLE = self.VVdbgy()
  if VVsLLE:
   totChans = len(VVsLLE)
  FFoB4k(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VViZ0s(self):
  files = CCoUhv.VVDteM()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFFr8o(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VViZMT
   else    : color = VV8ETX
   totInvalid = FF8oA9(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FF8oA9("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFoB4k(self, txt, title="Check IPTV References")
 def VVJLyf(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = CCoUhv.VVO4pN()
  chUrlLst = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CCotiQ.VVvpYd(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VV73fw = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VV73fw:
   VVXNdR = FF6kZn(VV73fw)
   if VVXNdR:
    for service in VVXNdR:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVKJQA + userBName
  bFile = VVKJQA + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFb0lc("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += FFb0lc("rm -f '%s'" % path)
  FFqSkC(cmd)
  FFjaui()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VViZMT
    else     : res, color = "No" , VV8ETX
    pl = CCoUhv.VVnTMx(item)
    txt += "    %s\t: %s%s\n" % (item, FF8oA9(res, color), FF8oA9("\t... %s" % pl, VVD4un) if pl else "")
   FFoB4k(self, txt, title=title)
  else:
   txt = FFOyl1(self, "Could not complete the test on your system!", title=title)
 def VV8hOV(self):
  VVXA47, err = CCwuBY.VVtR0o(self, CCwuBY.VVBOJI)
  if VVXA47:
   totChannels = 0
   totChange = 0
   for path in CCoUhv.VVDteM():
    toSave = False
    txt = FFFr8o(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVXA47.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVIeTz(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFOyl1(self, 'No channels in "lamedb" !')
 def VVZlnw(self, VVkbkP, title):
  bFiles = CCoUhv.VVDteM()
  if bFiles: self.VVKWtr(bFiles, title)
  else  : FFZD7H(VVkbkP, "No bouquets files !", 1500)
 def VVJ5Lb(self, VVkbkP, title):
  self.VViZHb(VVkbkP, BF(self.VV38My, title))
 def VV38My(self, title, VVkbkP, bName, bPath):
  self.VVKWtr([bPath], title)
 def VVKWtr(self, bFiles, title):
  self.session.open(CCjWUz, barTheme=CCjWUz.VVh7HE
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVlQxL, bFiles)
      , VVCBqA = BF(self.VVlBCx, title))
 def VVlQxL(self, bFiles, VVNVFL):
  VVNVFL.VVpwcW = ""
  VVNVFL.VVXtf8("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FF72md(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVNVFL or VVNVFL.isCancelled:
   return
  elif not totLines:
   VVNVFL.VVpwcW = "No IPTV Services !"
   return
  else:
   VVNVFL.VV0amK(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVNVFL or VVNVFL.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FF72md(path)
    for ndx, line in enumerate(lines):
     if not VVNVFL or VVNVFL.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVNVFL:
       VVNVFL.VVXtf8("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVNVFL:
       VVNVFL.VViyfK(1)
      refCode, startId, startNS = CCotiQ.VVevo1(rType, CCotiQ.VVm8is, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVNVFL:
        VVNVFL.VVpwcW = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VVlBCx(self, title, VVdCuP, VVpwcW, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VVpwcW:
   txt += "\n\n%s\n%s" % (FF8oA9("Ended with Error:", VV8ETX), VVpwcW)
  self.VVIeTz(True, title, txt)
 def VVAB2o(self):
  bFiles = CCoUhv.VVDteM()
  if not bFiles:
   FFZD7H(self.VVdesl, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVdesl.VVTW2g():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FFZD7H(self.VVdesl, "Cannot read list", 1500)
   return
  self.session.open(CCjWUz, barTheme=CCjWUz.VVh7HE
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVcejl, bFiles, tableRefList)
      , VVCBqA = BF(self.VVlBCx, "Change Current List References to Unique Codes"))
 def VVcejl(self, bFiles, tableRefList, VVNVFL):
  VVNVFL.VVpwcW = ""
  VVNVFL.VVXtf8("Reading System References ...")
  refLst = CCotiQ.VVt3gB(CCotiQ.VVm8is, stripRType=True)
  if not VVNVFL or VVNVFL.isCancelled:
   return
  VVNVFL.VV0amK(len(tableRefList))
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVNVFL or VVNVFL.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFFr8o(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVNVFL or VVNVFL.isCancelled:
     return
    VVNVFL.VVXtf8("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVNVFL or VVNVFL.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVNVFL.VViyfK(1)
      refCode, startId, startNS = CCotiQ.VVevo1(rType, CCotiQ.VVm8is, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVNVFL:
        VVNVFL.VVpwcW = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VVLW53(self):
  list = None
  if self.VVdesl:
   list = []
   for row in self.VVdesl.VVTW2g():
    list.append(row[4] + row[5])
  files = CCoUhv.VVDteM()
  totChange = 0
  if files:
   for path in files:
    lines = FF72md(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VVIeTz(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVIeTz(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFjaui()
   if refreshTable and self.VVdesl:
    VVsLLE = self.VVdbgy()
    if VVsLLE and self.VVdesl:
     self.VVdesl.VV87pY(VVsLLE, self.tableTitle)
     self.VVdesl.VVz4xL(txt)
   FFoB4k(self, txt, title=title)
  else:
   FFDeF8(self, "No changes.")
 @staticmethod
 def VVDteM(atLeastOne=False, onlyFileName=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVKJQA + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFFr8o(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(os.path.basename(path) if onlyFileName else path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVRZKi(self, VVdesl, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFC8zI(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FF1wB7(self, fncMode=CCqIel.VV3tb6, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VViZFW(self, VVdesl, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVgPgk(self, VVdesl, title, txt, colList):
  chName, chUrl = self.VViZFW(VVdesl, colList)
  self.VV5hfV(VVdesl, chName, chUrl, "localIptv")
 def VVAOBG(self, mode, VVdesl, colList):
  chName, chUrl, picUrl, refCode = self.VVQqBJ(mode, colList)
  return chName, chUrl
 def VVq3mF(self, mode, VVdesl, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVQqBJ(mode, colList)
  self.VV5hfV(VVdesl, chName, chUrl, mode)
 def VV5hfV(self, VVdesl, chName, chUrl, playerFlag):
  chName = FF3gfV(chName)
  if self.VVUkm4(chName):
   FFZD7H(VVdesl, "This is a marker!", 300)
  else:
   FFbA1i(VVdesl, BF(self.VVol69, VVdesl, chUrl, playerFlag), title="Playing ...")
 def VVol69(self, VVdesl, chUrl, playerFlag):
  FFoYZf(self, chUrl, VVMFOV=False)
  CCuYKB.VVa42W(self.session, iptvTableParams=(self, VVdesl, playerFlag))
 @staticmethod
 def VVUkm4(chName):
  mark = ("--", "__", "==", "##",  "**", str(u"\u2605" * 2))
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVNjxQ(self, VVdesl, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
  if refCode:
   url1 = FFC8zI(origUrl.strip())
   for ndx, row in enumerate(VVdesl.VVTW2g()):
    if refCode in row[4]:
     tableRow = FFC8zI(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVdesl.VVTklH(ndx)
      break
   else:
    FFZD7H(VVdesl, "No found", 1000)
 def VVR8m8(self, m3uMode):
  lines = self.VVZwKG(3)
  if lines:
   lines.sort()
   VVtMHe = []
   for line in lines:
    VVtMHe.append((line, line))
   if m3uMode == CCoUhv.VVCJ2r:
    title = "Browse Server from M3U URLs"
    VVrBns = ("All to Playlist", self.VVh2gy)
   else:
    title = "M3U/M3U8 File Browser"
    VVrBns = None
   VVyXO1 = BF(self.VVdkFW, m3uMode, title)
   VVBLNR = self.VVNCDh
   FFECK9(self, None, title=title, VVtMHe=VVtMHe, width=1200, VVyXO1=VVyXO1, VVBLNR=VVBLNR, VVNhLF="", VVrBns=VVrBns, VVaRsg="#11221122", VVWgai="#11221122")
 def VVdkFW(self, m3uMode, title, item=None):
  if item:
   VVkbkP, txt, path, ndx = item
   if m3uMode == CCoUhv.VVCJ2r:
    FFbA1i(VVkbkP, BF(self.VVYlUU, title, path))
   else:
    FFbA1i(VVkbkP, BF(self.VViIxe, path))
 def VViIxe(self, path, m3uFilterParam=None, VVdesl=None):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(path))[0]
  txt = FFFr8o(path)
  span = iSearch(r"#EXTINF:.+\n(.+)\n.+", txt, IGNORECASE)
  if span:
   self.curUrl = span.group(1)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  groups = []
  mode, words, asPrefix, fTitle = m3uFilterParam or (0, (), False, "")
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVvjMm(propLine, "group-title") or "-"
   if not group == "-" and self.VVkMnb(group):
    if not chName or self.VVz6O6(chName):
     if self.VVEK12(mode, "", url.lower(), chName, words, "", asPrefix):
      groups.append(group)
  VVsLLE = []
  if groups:
   totAll = 0
   for name, tot in iCounter(groups).items():
    VVsLLE.append((name, str(tot), name))
    totAll += tot
   VVsLLE.sort(key=lambda x: x[0].lower())
   VVsLLE.insert(0, ("ALL", str(totAll), ""))
  if VVsLLE:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   if VVdesl:
    VVdesl.VV87pY(VVsLLE, newTitle=title, VVZoVsMsg=True)
   else:
    VVJi29 = self.VVW6KB
    VVMWQK  = ("Select" , BF(self.VV2b7i, path, m3uFilterParam)  , [])
    VVRHhw = ("Filter" , BF(self.VV2qwh, path, m3uFilterParam), [])
    header   = ("Group" , "Total" , "grp" )
    widths   = (85  , 15  , 0  )
    VV0CnX  = (LEFT  , CENTER , LEFT )
    FFDpub(self, None, title=title, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, width= 1400, height= 1000, VVGNdU=28, VVMWQK=VVMWQK, VVRHhw=VVRHhw, VVJi29=VVJi29, lastFindConfigObj=CFG.lastFindIptv
      , VVaRsg="#11110022", VVWgai="#11110022", VVSJJk="#11110022", VVYCZ6="#00444400")
  elif VVdesl:
   FFZbFo(VVdesl, "Not found !", 1500)
  else:
   self.VV1KKy(FFFr8o(path), "", m3uFilterParam)
 def VV2b7i(self, path, m3uFilterParam, VVdesl, title, txt, colList):
  self.VV1KKy(FFFr8o(path), colList[2], m3uFilterParam)
 def VV2qwh(self, path, m3uFilterParam, VVdesl, title, txt, colList):
  VVtMHe = []
  VVtMHe.append(("All"      , "all"  ))
  VVtMHe.append(FF5f5W("Category"))
  VVtMHe.append(("Live TV"     , "live" ))
  VVtMHe.append(("VOD"      , "vod"  ))
  VVtMHe.append(("Series"     , "series" ))
  VVtMHe.append(("Uncategorised"   , "uncat" ))
  VVtMHe.append(FF5f5W("Media"))
  VVtMHe.append(("Video"     , "video" ))
  VVtMHe.append(("Audio"     , "audio" ))
  VVtMHe.append(FF5f5W("File Type"))
  VVtMHe.append(("MKV"      , "MKV"  ))
  VVtMHe.append(("MP4"      , "MP4"  ))
  VVtMHe.append(("MP3"      , "MP3"  ))
  VVtMHe.append(("AVI"      , "AVI"  ))
  VVtMHe.append(("FLV"      , "FLV"  ))
  filterObj = CC6kzI(self, VVaRsg="#11332244", VVWgai="#11222244")
  filterObj.VVmQ3J(VVtMHe, [], BF(self.VVmpXy, VVdesl, path), inFilterFnc=None)
 def VVmpXy(self, VVdesl, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VVD1Oc , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VVW7YW  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VVhz13  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VV2AbK  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VVSwNU  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VVMqLl  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VVSaL8  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VVcx7H  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VVzk9y  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VVxgk2  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVIedT  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VVeLFj  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVy14D  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CC6kzI.VVV2i7(words)
   if not mode == self.VVD1Oc:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FF8oA9(fTitle, VVD4un)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FFbA1i(VVdesl, BF(self.VViIxe, path, m3uFilterParam, VVdesl), title="Filtering ...")
 def VV1KKy(self, txt, filterGroup="", m3uFilterParam=None):
  lst   = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CCjWUz, barTheme=CCjWUz.VVJmH5
       , titlePrefix = "Reading File Lines", endTitle="Loading channels ..."
       , fncToRun  = BF(self.VVXhbI, lst, filterGroup, m3uFilterParam)
       , VVCBqA = BF(self.VVAUif, title, bName))
  else:
   self.VVZUeJ("No valid lines found !", title)
 def VVXhbI(self, lst, filterGroup, m3uFilterParam, VVNVFL):
  VVNVFL.VVpwcW = []
  VVNVFL.VV0amK(len(lst))
  num = 0
  for cols in lst:
   if not VVNVFL or VVNVFL.isCancelled:
    return
   VVNVFL.VViyfK(1, True)
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVvjMm(propLine, "group-title") or "-"
   picon = self.VVvjMm(propLine, "tvg-logo")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not self.VVkMnb(group) : skip = True
    elif chName and not self.VVz6O6(chName)   : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VVEK12(mode, "", FFC8zI(url).lower(), chName, words, "", asPrefix)
    if not skip and VVNVFL:
     num += 1
     VVNVFL.VVpwcW.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
 def VVAUif(self, title, bName, VVdCuP, VVpwcW, threadCounter, threadTotal, threadErr):
  if VVpwcW:
   VVJi29 = self.VVW6KB
   VVMWQK  = ("Select"   , BF(self.VVS501, title)   , [])
   VVZArZ = (""    , self.VVrWlm        , [])
   VV1kWx = ("Download PIcons", self.VVVFsH       , [])
   VVM9Pm = ("Options"  , BF(self.VVQ9xp, "m3Ch", "", bName) , [])
   VVRHhw = ("Posters Mode" , BF(self.VV3yl3, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VV0CnX  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFDpub(self, None, title=title, header=header, VVcuvv=VVpwcW, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=28, VVMWQK=VVMWQK, VVJi29=VVJi29, VVZArZ=VVZArZ, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw, lastFindConfigObj=CFG.lastFindIptv, VVEMdg=True, searchCol=1
     , VVaRsg="#0a00192B", VVWgai="#0a00192B", VVSJJk="#0a00192B", VVYCZ6="#00000000")
  else:
   self.VVZUeJ("Not found !", title)
 def VVVFsH(self, VVdesl, title, txt, colList):
  self.VVGiPX(VVdesl, "m3u/m3u8")
 def VVtwnG(self, rowNum, url, chName):
  refCode = self.VVaLSR(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFP1tK(url), chName)
  return chUrl
 def VVaLSR(self, rowNum, url, chName):
  fName = os.path.basename(url)
  catID = "333"
  stID  =  "444"
  if fName:
   num = os.path.splitext(fName)[0]
   if num.isdigit() and int(num) < 0xeeee0000:
    stID = num
  chNum = str(rowNum + 1)
  refCode = self.VVGbMl(catID, stID, chNum)
  return refCode
 def VVvjMm(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVS501(self, Title, VVdesl, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFbA1i(VVdesl, BF(self.VVh81F, Title, VVdesl, colList), title="Checking Server ...")
  else:
   self.VVrKN4(VVdesl, url, chName)
 def VVh81F(self, title, VVdesl, colList):
  if not CCvqvw.VV6Zw5(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCOGg2.VVJ9oy(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVtMHe = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCoUhv.VVYQAD(url, fPath)
     VVtMHe.append((resol, fullUrl))
    if VVtMHe:
     if len(VVtMHe) > 1:
      FFECK9(self, BF(self.VVj7AL, VVdesl, chName), VVtMHe=VVtMHe, title="Resolution", VVIZXB=True, VVy2u1=True)
     else:
      self.VVrKN4(VVdesl, VVtMHe[0][1], chName)
    else:
     span = iSearch(r"(http.+)", txt, IGNORECASE)
     if span:
      self.VVrKN4(VVdesl, span.group(1), chName)
     else:
      span = iSearch(r"#EXT-X-STREAM-INF.*\n(.+)", txt, IGNORECASE)
      if span:
       fullUrl = CCoUhv.VVYQAD(url, span.group(1))
       self.VVrKN4(VVdesl, fullUrl, chName)
      else:
       self.VVoafo("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VV1KKy(txt, filterGroup="")
      return
    self.VVrKN4(VVdesl, url, chName)
   else:
    self.VVZUeJ("Cannot process this channel !", title)
  else:
   self.VVZUeJ(err, title)
 def VVj7AL(self, VVdesl, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVrKN4(VVdesl, resolUrl, chName)
 def VVrKN4(self, VVdesl, url, chName):
  FFbA1i(VVdesl, BF(self.VVZX2l, VVdesl, url, chName), title="Playing ...")
 def VVZX2l(self, VVdesl, url, chName):
  chUrl = self.VVtwnG(VVdesl.VVvapY(), url, chName)
  FFoYZf(self, chUrl, VVMFOV=False)
  CCuYKB.VVa42W(self.session, iptvTableParams=(self, VVdesl, "m3u/m3u8"))
 def VVUU0W(self, VVdesl, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVtwnG(VVdesl.VVvapY(), url, chName)
  return chName, chUrl
 def VVrWlm(self, VVdesl, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FF1wB7(self, fncMode=CCqIel.VV3tb6, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVZUeJ(self, err, title):
  FFOyl1(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVW6KB(self, VVdesl):
  if self.m3uOrM3u8File:
   self.close()
  VVdesl.cancel()
 def VVh2gy(self, selectionObj, item=None):
  FFbA1i(selectionObj, BF(self.VVsY0h, selectionObj, item))
 def VVsY0h(self, selectionObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(selectionObj.VVtMHe):
    path = item[1]
    if fileExists(path):
     enc = CC2TkW.VV73sc(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = CCoUhv.VVz2SY(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCoUhv.VVfXlV()
    pListF = "%sPlaylist_%s.txt" % (path, FFZR2n())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(selectionObj.VVtMHe)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFoB4k(self, txt, title=title)
   else:
    FFOyl1(self, "Could not obtain URLs from this file list !", title=title)
 def VVBfOn(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VVLf8o
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VVsfDf
  lines = self.VVZwKG(mode)
  if lines:
   lines.sort()
   VVtMHe = []
   for line in lines:
    VVtMHe.append((FF8oA9(line, VVRuOi) if "Bookmarks" in line else line, line))
   VVBLNR = self.VVNCDh
   FFECK9(self, None, title=title, VVtMHe=VVtMHe, width=1200, VVyXO1=okFnc, VVBLNR=VVBLNR, VVNhLF="")
 def VVNCDh(self, VVkbkP, txt, ref, ndx):
  txt = ref
  sz = FFF0Rr(ref)
  if sz > 0:
   txt += "\n\nSize: %s" % CCVnYx.VVI3LQ(sz)
  FFoB4k(self, txt, title="File Path")
 def VVLf8o(self, item=None):
  if item:
   VVkbkP, txt, path, ndx = item
   FFbA1i(VVkbkP, BF(self.VVkyKA, VVkbkP, path), title="Processing File ...")
 def VVkyKA(self, VVsRAp, path):
  enc = CC2TkW.VV73sc(path, self)
  if enc == -1:
   return
  VVsLLE = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFDpEI(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCoUhv.VVkgSK(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVsLLE:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVsLLE.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVsLLE:
   title = "Playlist File : %s" % os.path.basename(path)
   VVMWQK  = ("Start"    , BF(self.VVbBtW, "Playlist File")      , [])
   VVIzUv = ("Home Menu"   , FFqjXt             , [])
   VV1kWx = ("Download M3U File" , self.VV96JI         , [])
   VVM9Pm = ("Edit File"   , BF(self.VVEer1, path)        , [])
   VVRHhw = ("Check & Filter"  , BF(self.VVc7mO, VVsRAp, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VV0CnX  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFDpub(self, None, title=title, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=26, VVMWQK=VVMWQK, VVIzUv=VVIzUv, VVRHhw=VVRHhw, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, VVaRsg="#11001116", VVWgai="#11001116", VVSJJk="#11001116", VVYCZ6="#00003635", VVTjte="#0a333333", VVIyj7="#11331100", VVEMdg=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FFOyl1(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VV96JI(self, VVdesl, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFgBNQ(self, BF(FFbA1i, VVdesl, BF(self.VVkULX, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVkULX(self, title, url):
  path, err = FF4VyK(url, "ajp_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFOyl1(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFFr8o(path)
   if '{"user_info":{"auth":0}}' in txt:
    FFOlRe(path)
    FFOyl1(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FFOlRe(path)
    FFOyl1(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCoUhv.VVfXlV() + fName
    FFqSkC("mv -f '%s' '%s'" % (path, newPath))
    if fileExists(newPath):
     path = newPath
    FFDeF8(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFOyl1(self, "Could not download the M3U file!", title=errTitle)
 def VVbBtW(self, Title, VVdesl, title, txt, colList):
  url = colList[6]
  FFbA1i(VVdesl, BF(self.VVsxAp, Title, url), title="Checking Server ...")
 def VVEer1(self, path, VVdesl, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCiazU(self, path, VVCBqA=BF(self.VVDhpV, VVdesl), curRowNum=rowNum)
  else    : FFbiIe(self, path)
 def VVDhpV(self, VVdesl, fileChanged):
  if fileChanged:
   VVdesl.cancel()
 def VVchKB(self, title):
  curChName = self.VVdesl.VVxBD7(1)
  FFdnKb(self, BF(self.VV0xNS, title), defaultText=curChName, title=title, message="Enter Name:")
 def VV0xNS(self, title, name):
  if name:
   VVXA47, err = CCwuBY.VVtR0o(self, CCwuBY.VVFNFY, VVOnBM=False, VVGHpD=False)
   list = []
   if VVXA47:
    name = self.VV65U4(name)
    ratio = "1"
    for item in VVXA47:
     if name in item[0].lower():
      list.append((item[0], FFH6BB(item[2]), item[3], ratio))
   if list : self.VV0bpi(list, title)
   else : FFOyl1(self, "Not found:\n\n%s" % name, title=title)
 def VVDSmz(self, title):
  curChName = self.VVdesl.VVxBD7(1)
  self.session.open(CCjWUz, barTheme=CCjWUz.VVJmH5
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVQyuk
      , VVCBqA = BF(self.VV14fP, title, curChName))
 def VVQyuk(self, VVNVFL):
  curChName = self.VVdesl.VVxBD7(1)
  VVXA47, err = CCwuBY.VVtR0o(self, CCwuBY.VVTsIE, VVOnBM=False, VVGHpD=False)
  if not VVXA47 or not VVNVFL or VVNVFL.isCancelled:
   return
  VVNVFL.VVpwcW = []
  VVNVFL.VV0amK(len(VVXA47))
  curCh = self.VV65U4(curChName)
  for refCode in VVXA47:
   chName, sat, inDB = VVXA47.get(refCode, ("", "", 0))
   ratio = CCuqLp.VVudZF(chName.lower(), curCh)
   if not VVNVFL or VVNVFL.isCancelled:
    return
   VVNVFL.VViyfK(1, True)
   if VVNVFL and ratio > 50:
    VVNVFL.VVpwcW.append((chName, FFH6BB(sat), refCode.replace("_", ":"), str(ratio)))
 def VV14fP(self, title, curChName, VVdCuP, VVpwcW, threadCounter, threadTotal, threadErr):
  if VVpwcW: self.VV0bpi(VVpwcW, title)
  elif VVdCuP: FFOyl1(self, "No similar names found for:\n\n%s" % curChName, title)
 def VV0bpi(self, VVsLLE, title):
  curChName = self.VVdesl.VVxBD7(1)
  VVucyc = self.VVdesl.VVxBD7(4)
  curUrl  = self.VVdesl.VVxBD7(5)
  VVsLLE.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVMWQK  = ("Share Sat/C/T Ref.", BF(self.VVSiad, title, curChName, VVucyc, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFDpub(self, None, title=title, header=header, VVcuvv=VVsLLE, VVbG6j=widths, VVGNdU=26, VVMWQK=VVMWQK, VVaRsg="#0a00112B", VVWgai="#0a001126", VVSJJk="#0a001126", VVYCZ6="#00000000")
 def VVSiad(self, newtitle, curChName, VVucyc, curUrl, VVdesl, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVucyc, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFgBNQ(self.VVdesl, BF(FFbA1i, self.VVdesl, BF(self.VVb6Ho, VVdesl, data)), ques, title=newtitle, VVMgjE=True)
 def VVb6Ho(self, VVdesl, data):
  VVdesl.cancel()
  title, curChName, VVucyc, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVucyc = VVucyc.strip()
  newRefCode = newRefCode.strip()
  if not VVucyc.endswith(":") : VVucyc += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVucyc, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVucyc + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in CCoUhv.VVDteM():
    txt = FFFr8o(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFjaui()
    newRow = []
    for i in range(6):
     newRow.append(self.VVdesl.VVxBD7(i))
    newRow[4] = newRefCode
    done = self.VVdesl.VVIDuW(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFkvVR(BF(FFDeF8 , self, resTxt, title=title))
  elif resErr: FFkvVR(BF(FFOyl1, self, resErr, title=title))
 def VVc7mO(self, VVsRAp, path, VVdesl, title, txt, colList):
  self.session.open(CCjWUz, barTheme=CCjWUz.VVh7HE
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVOSoP, VVdesl)
      , VVCBqA = BF(self.VVi17Z, VVsRAp, path, VVdesl))
 def VVOSoP(self, VVdesl, VVNVFL):
  VVNVFL.VV0amK(VVdesl.VVMs9k())
  VVNVFL.VVpwcW = []
  for row in VVdesl.VVTW2g():
   if not VVNVFL or VVNVFL.isCancelled:
    return
   VVNVFL.VViyfK(1, True)
   qUrl = self.VVnWzT(self.VVwXOG, row[6])
   txt, err = self.VVnY0U(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVGIa1(item, "auth") == "0":
       VVNVFL.VVpwcW.append(qUrl)
    except:
     pass
 def VVi17Z(self, VVsRAp, path, VVdesl, VVdCuP, VVpwcW, threadCounter, threadTotal, threadErr):
  if VVdCuP:
   list = VVpwcW
   title = "Authorized Servers"
   if list:
    totChk = VVdesl.VVMs9k()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFZR2n()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVBfOn(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FF8oA9(str(totAuth), VViZMT)
     txt += "%s\n\n%s"    %  (FF8oA9("Result File:", VVRuOi), newPath)
     FFoB4k(self, txt, title=title)
     VVdesl.close()
     VVsRAp.close()
    else:
     FFDeF8(self, "All URLs are authorized.", title=title)
   else:
    FFOyl1(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVnY0U(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVkgSK(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VV1JTf(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CCXPWq.VVbz66()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VVD9QL(decodedUrl):
  return CCoUhv.VV1JTf(decodedUrl, justRetDotExt=True)
 def VVnWzT(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVkgSK(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVwXOG   : return "%s"            % url
  elif mode == self.VVVCMd   : return "%s&action=get_live_categories"     % url
  elif mode == self.VV0Qng   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VV5kkI  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVSMo0  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVkTlW : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVGeyj   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVD73g    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVIYmB  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVmA98 : return "%s&action=get_live_streams"      % url
  elif mode == self.VVIWj9  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVGIa1(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFt4wC(int(val))
    elif is_base64 : val = FFkr9k(val)
    elif isToHHMMSS : val = FFBNnO(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVYlUU(self, title, path):
  if fileExists(path):
   enc = CC2TkW.VV73sc(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = CCoUhv.VVz2SY(line)
     if qUrl:
      break
   if qUrl : self.VVsxAp(title, qUrl)
   else : FFOyl1(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFOyl1(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVginf(self):
  title = "Current Channel Server"
  qUrl, iptvRef = CCoUhv.VVToal(self)
  if qUrl or "chCode" in iptvRef:
   p = CCOGg2()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VV4sir(iptvRef)
   if valid:
    self.VVkEnX(self, host, mac)
    return
   elif qUrl:
    FFbA1i(self, BF(self.VVsxAp, title, qUrl), title="Checking Server ...")
    return
  FFOyl1(self, "Error in current channel URL !", title=title)
 @staticmethod
 def VVToal(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(SELF)
  qUrl = CCoUhv.VVz2SY(decodedUrl)
  return qUrl, iptvRef
 @staticmethod
 def VVz2SY(url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVsxAp(self, title, url):
  self.curUrl = url
  self.VV5nPVData = {}
  qUrl = self.VVnWzT(self.VVwXOG, url)
  txt, err = self.VVnY0U(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VV5nPVData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VV5nPVData["username"    ] = self.VVGIa1(item, "username"        )
    self.VV5nPVData["password"    ] = self.VVGIa1(item, "password"        )
    self.VV5nPVData["message"    ] = self.VVGIa1(item, "message"        )
    self.VV5nPVData["auth"     ] = self.VVGIa1(item, "auth"         )
    self.VV5nPVData["status"    ] = self.VVGIa1(item, "status"        )
    self.VV5nPVData["exp_date"    ] = self.VVGIa1(item, "exp_date"    , isDate=True )
    self.VV5nPVData["is_trial"    ] = self.VVGIa1(item, "is_trial"        )
    self.VV5nPVData["active_cons"   ] = self.VVGIa1(item, "active_cons"       )
    self.VV5nPVData["created_at"   ] = self.VVGIa1(item, "created_at"   , isDate=True )
    self.VV5nPVData["max_connections"  ] = self.VVGIa1(item, "max_connections"      )
    self.VV5nPVData["allowed_output_formats"] = self.VVGIa1(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VV5nPVData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VV5nPVData["url"    ] = self.VVGIa1(item, "url"        )
    self.VV5nPVData["port"    ] = self.VVGIa1(item, "port"        )
    self.VV5nPVData["https_port"  ] = self.VVGIa1(item, "https_port"      )
    self.VV5nPVData["server_protocol" ] = self.VVGIa1(item, "server_protocol"     )
    self.VV5nPVData["rtmp_port"   ] = self.VVGIa1(item, "rtmp_port"       )
    self.VV5nPVData["timezone"   ] = self.VVGIa1(item, "timezone"       )
    self.VV5nPVData["timestamp_now"  ] = self.VVGIa1(item, "timestamp_now"  , isDate=True )
    self.VV5nPVData["time_now"   ] = self.VVGIa1(item, "time_now"       )
    VVtMHe  = self.VVMcpt(True)
    VVyXO1 = self.VVajuO
    VVBLNR = self.VV5I9w
    VVEJLl = ("Home Menu", FFqjXt)
    VVIL24= ("Add to Menu", BF(CCoUhv.VVnAMb, self, False, self.VV5nPVData["playListURL"]))
    VVrBns = ("Bookmark Server", BF(CCoUhv.VVxMqR, self, False, self.VV5nPVData["playListURL"]))
    FFECK9(self, None, title="IPTV Server Resources", VVtMHe=VVtMHe, VVyXO1=VVyXO1, VVBLNR=VVBLNR, VVEJLl=VVEJLl, VVIL24=VVIL24, VVrBns=VVrBns)
   else:
    err = "Could not get data from server !"
  if err:
   FFOyl1(self, err, title=title)
  FFZD7H(self)
 def VVajuO(self, item=None):
  if item:
   VVkbkP, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFbA1i(VVkbkP, BF(self.VVfcVp, self.VVVCMd  , title=title), title=wTxt)
   elif ref == "vod"   : FFbA1i(VVkbkP, BF(self.VVfcVp, self.VV0Qng  , title=title), title=wTxt)
   elif ref == "series"  : FFbA1i(VVkbkP, BF(self.VVfcVp, self.VV5kkI , title=title), title=wTxt)
   elif ref == "catchup"  : FFbA1i(VVkbkP, BF(self.VVfcVp, self.VVSMo0 , title=title), title=wTxt)
   elif ref == "accountInfo" : FFbA1i(VVkbkP, BF(self.VVAuYT           , title=title), title=wTxt)
 def VV5I9w(self, VVkbkP, txt, ref, ndx):
  FFbA1i(VVkbkP, self.VV6hQ6)
 def VV6hQ6(self):
  txt = self.curUrl
  if VVXYuQ:
   ver, err = self.VVkKbF(self.VVsZJ1())
   txt += "\n\n"
   txt += "Original\t: %s\n" % self.curUrl
   txt += "Modified\t: %s\n" % self.VViEDk
   txt += "PHP\t: %s\n"  % self.VV8IsJ
   txt += "Extra\t: %s\n"  % {2:"Big", 3:"Sml"}.get(self.VV2Qzd, "-")
   txt += "Version\t: %s"  % (ver or err)
  FFoB4k(self, txt, title="Current Server URL")
 def VVAuYT(self, title):
  rows = []
  for key, val in self.VV5nPVData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VVEtEf
   else:
    num, part = "1", self.VVvwVA
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVIzUv  = ("Home Menu", FFqjXt, [])
  VV1kWx  = None
  if VVXYuQ:
   VV1kWx = ("Get JS" , BF(self.VVKDUR, "/".join(self.VV5nPVData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFDpub(self, None, title=title, width=1200, header=header, VVcuvv=rows, VVbG6j=widths, VVGNdU=26, VVIzUv=VVIzUv, VV1kWx=VV1kWx, VVaRsg="#0a00292B", VVWgai="#0a002126", VVSJJk="#0a002126", VVYCZ6="#00000000", searchCol=2)
 def VV1ATy(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    if mode in (self.VVGeyj, self.VVIWj9):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVGIa1(item, "num"         )
      name     = self.VVGIa1(item, "name"        )
      stream_id    = self.VVGIa1(item, "stream_id"       )
      stream_icon    = self.VVGIa1(item, "stream_icon"       )
      epg_channel_id   = self.VVGIa1(item, "epg_channel_id"      )
      added     = self.VVGIa1(item, "added"    , isDate=True )
      is_adult    = self.VVGIa1(item, "is_adult"       )
      category_id    = self.VVGIa1(item, "category_id"       )
      tv_archive    = self.VVGIa1(item, "tv_archive"       )
      direct_source   = self.VVGIa1(item, "direct_source"      )
      tv_archive_duration  = self.VVGIa1(item, "tv_archive_duration"     )
      name = self.VVz6O6(name, is_adult)
      if name:
       if mode == self.VVGeyj or mode == self.VVIWj9 and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VVD73g:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVGIa1(item, "num"         )
      name    = self.VVGIa1(item, "name"        )
      stream_id   = self.VVGIa1(item, "stream_id"       )
      stream_icon   = self.VVGIa1(item, "stream_icon"       )
      added    = self.VVGIa1(item, "added"    , isDate=True )
      is_adult   = self.VVGIa1(item, "is_adult"       )
      category_id   = self.VVGIa1(item, "category_id"       )
      container_extension = self.VVGIa1(item, "container_extension"     ) or "mp4"
      name = self.VVz6O6(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VVIYmB:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVGIa1(item, "num"        )
      name    = self.VVGIa1(item, "name"       )
      series_id   = self.VVGIa1(item, "series_id"      )
      cover    = self.VVGIa1(item, "cover"       )
      genre    = self.VVGIa1(item, "genre"       )
      episode_run_time = self.VVGIa1(item, "episode_run_time"    )
      category_id   = self.VVGIa1(item, "category_id"      )
      container_extension = self.VVGIa1(item, "container_extension"    ) or "mp4"
      name = self.VVz6O6(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVfcVp(self, mode, title):
  cList, err = self.VVwUhE(mode)
  if cList and mode == self.VVSMo0:
   cList = self.VVBv55(cList)
  if err:
   FFOyl1(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVaRsg, VVWgai, VVSJJk, VVYCZ6 = self.VVJktB(mode)
   mName = self.VVVGwi(mode)
   if   mode == self.VVVCMd  : fMode = self.VVGeyj
   elif mode == self.VV0Qng  : fMode = self.VVD73g
   elif mode == self.VV5kkI : fMode = self.VVIYmB
   elif mode == self.VVSMo0 : fMode = self.VVIWj9
   if mode == self.VVSMo0:
    VVM9Pm = None
    VVRHhw = None
   else:
    VVM9Pm = ("Find in %s" % mName , BF(self.VVaJV7, fMode, True) , [])
    VVRHhw = ("Find in Selected" , BF(self.VVaJV7, fMode, False) , [])
   VVMWQK   = ("Show List"   , BF(self.VVgMZb, mode)  , [])
   VVIzUv  = ("Home Menu"   , FFqjXt         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFDpub(self, None, title=title, width=1200, header=header, VVcuvv=cList, VVbG6j=widths, VVGNdU=30, VVIzUv=VVIzUv, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw, VVMWQK=VVMWQK, VVaRsg=VVaRsg, VVWgai=VVWgai, VVSJJk=VVSJJk, VVYCZ6=VVYCZ6, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFOyl1(self, "No list from server !", title=title)
  FFZD7H(self)
 def VVwUhE(self, mode):
  qUrl  = self.VVnWzT(mode, self.VV5nPVData["playListURL"])
  txt, err = self.VVnY0U(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    for item in tDict:
     category_id  = self.VVGIa1(item, "category_id"  )
     category_name = self.VVGIa1(item, "category_name" )
     parent_id  = self.VVGIa1(item, "parent_id"  )
     category_name = self.VVkMnb(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVBv55(self, catList):
  mode  = self.VVIWj9
  qUrl  = self.VVnWzT(mode, self.VV5nPVData["playListURL"])
  txt, err = self.VVnY0U(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VV1ATy(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVgMZb(self, mode, VVdesl, title, txt, colList):
  title = colList[1]
  FFbA1i(VVdesl, BF(self.VVCO2y, mode, VVdesl, title, txt, colList), title="Downloading ...")
 def VVCO2y(self, mode, VVdesl, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVVGwi(mode) + " : "+ bName
  if   mode == self.VVVCMd  : mode = self.VVGeyj
  elif mode == self.VV0Qng  : mode = self.VVD73g
  elif mode == self.VV5kkI : mode = self.VVIYmB
  elif mode == self.VVSMo0 : mode = self.VVIWj9
  qUrl  = self.VVnWzT(mode, self.VV5nPVData["playListURL"], catID)
  txt, err = self.VVnY0U(qUrl)
  list  = []
  if not err and mode in (self.VVGeyj, self.VVD73g, self.VVIYmB, self.VVIWj9):
   list, err = self.VV1ATy(mode, txt)
  if err:
   FFOyl1(self, err, title=title)
  elif list:
   VVIzUv  = ("Home Menu"   , FFqjXt            , [])
   if mode in (self.VVGeyj, self.VVIWj9):
    VVaRsg, VVWgai, VVSJJk, VVYCZ6 = self.VVJktB(mode)
    VVZArZ = (""     , BF(self.VVpR4r, mode)      , [])
    VV1kWx = ("Download Options" , BF(self.VVbubI, mode, "", "")   , [])
    VVM9Pm = ("Options"   , BF(self.VVQ9xp, "lv", mode, bName)   , [])
    VVRHhw = ("Posters Mode"  , BF(self.VV3yl3, mode, False)     , [])
    if mode == self.VVGeyj:
     VVMWQK = ("Play"    , BF(self.VVq3mF, mode)       , [])
    else:
     VVMWQK = ("Programs"   , BF(self.VVZ7H7, mode, bName) , [])
   elif mode == self.VVD73g:
    VVaRsg, VVWgai, VVSJJk, VVYCZ6 = self.VVJktB(mode)
    VVMWQK  = ("Play"    , BF(self.VVq3mF, mode)       , [])
    VVZArZ = (""     , BF(self.VVpR4r, mode)      , [])
    VV1kWx = ("Download Options" , BF(self.VVbubI, mode, "v", "")   , [])
    VVM9Pm = ("Options"   , BF(self.VVQ9xp, "v", mode, bName)   , [])
    VVRHhw = ("Posters Mode"  , BF(self.VV3yl3, mode, False)     , [])
   elif mode == self.VVIYmB:
    VVaRsg, VVWgai, VVSJJk, VVYCZ6 = self.VVJktB("series2")
    VVMWQK  = ("Show Seasons"  , BF(self.VVkPbt, mode)       , [])
    VVZArZ = (""     , BF(self.VVjvIR, mode)     , [])
    VV1kWx = None
    VVM9Pm = None
    VVRHhw = ("Posters Mode"  , BF(self.VV3yl3, mode, True)      , [])
   header, widths, VV0CnX = self.VVRYqJ(mode)
   FFDpub(self, None, title=title, header=header, VVcuvv=list, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=26, VVMWQK=VVMWQK, VVIzUv=VVIzUv, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw, lastFindConfigObj=CFG.lastFindIptv, VVZArZ=VVZArZ, VVaRsg=VVaRsg, VVWgai=VVWgai, VVSJJk=VVSJJk, VVYCZ6=VVYCZ6, VVEMdg=True, searchCol=1)
  else:
   FFOyl1(self, "No Channels found !", title=title)
  FFZD7H(self)
 def VVRYqJ(self, mode):
  if mode in (self.VVGeyj, self.VVIWj9):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VV0CnX  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VVD73g:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VV0CnX  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VVIYmB:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VV0CnX  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VV0CnX
 def VVZ7H7(self, mode, bName, VVdesl, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VV5nPVData["playListURL"]
  ok_fnc  = BF(self.VVRgVm, hostUrl, chName, catId, streamId)
  FFbA1i(VVdesl, BF(CCoUhv.VVrPkx, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVRgVm(self, chUrl, chName, catId, streamId, VVdesl, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCoUhv.VVkgSK(chUrl)
   chNum = "333"
   refCode = CCoUhv.VVGbMl(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFoYZf(self, chUrl, VVMFOV=False)
   CCuYKB.VVa42W(self.session)
  else:
   FFOyl1(self, "Incorrect Timestamp", pTitle)
 def VVkPbt(self, mode, VVdesl, title, txt, colList):
  title = colList[1]
  FFbA1i(VVdesl, BF(self.VVOTZw, mode, VVdesl, title, txt, colList), title="Downloading ...")
 def VVOTZw(self, mode, VVdesl, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVnWzT(self.VVkTlW, self.VV5nPVData["playListURL"], series_id)
  txt, err = self.VVnY0U(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVGIa1(tDict["info"], "name"   )
      category_id = self.VVGIa1(tDict["info"], "category_id" )
      icon  = self.VVGIa1(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVGIa1(EP, "id"     )
        episode_num   = self.VVGIa1(EP, "episode_num"   )
        epTitle    = self.VVGIa1(EP, "title"     )
        container_extension = self.VVGIa1(EP, "container_extension" )
        seasonNum   = self.VVGIa1(EP, "season"    )
        epTitle = self.VVz6O6(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFOyl1(self, err, title=title)
  elif list:
   VVIzUv = ("Home Menu"   , FFqjXt          , [])
   VV1kWx = ("Download Options" , BF(self.VVbubI, mode, "s", title), [])
   VVM9Pm = ("Options"   , BF(self.VVQ9xp, "s", mode, title) , [])
   VVRHhw = ("Posters Mode"  , BF(self.VV3yl3, mode, False)   , [])
   VVZArZ = (""     , BF(self.VVpR4r, mode)    , [])
   VVMWQK  = ("Play"    , BF(self.VVq3mF, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VV0CnX  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFDpub(self, None, title=title, header=header, VVcuvv=list, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=26, VVIzUv=VVIzUv, VV1kWx=VV1kWx, VVMWQK=VVMWQK, VVZArZ=VVZArZ, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw, lastFindConfigObj=CFG.lastFindIptv, VVaRsg="#0a00292B", VVWgai="#0a002126", VVSJJk="#0a002126", VVYCZ6="#00000000")
  else:
   FFOyl1(self, "No Channels found !", title=title)
  FFZD7H(self)
 def VVaJV7(self, mode, isAll, VVdesl, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVtMHe = []
  VVtMHe.append(("Keyboard"  , "manualEntry"))
  VVtMHe.append(("From Filter" , "fromFilter"))
  FFECK9(self, BF(self.VVtSAW, VVdesl, mode, onlyCatID), title="Input Type", VVtMHe=VVtMHe, width=400)
 def VVtSAW(self, VVdesl, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFdnKb(self, BF(self.VVI0iN, VVdesl, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CC6kzI(self)
    filterObj.VVZBdt(BF(self.VVI0iN, VVdesl, mode, onlyCatID))
 def VVI0iN(self, VVdesl, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FF0UO9(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CC6kzI.VVV2i7(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FFOyl1(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FFOyl1(self, "All words must be at least 3 characters !", title=title)
        return
     if CFG.hideIptvServerAdultWords.getValue() and self.VVajLT(words):
      FFOyl1(self, self.VVQyXQ(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CCjWUz, barTheme=CCjWUz.VVJmH5
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVTXCi, VVdesl, mode, onlyCatID, title, words, toFind, asPrefix)
          , VVCBqA = BF(self.VVHJJ6, mode, toFind, title))
   if not words:
    FFZD7H(VVdesl, "Nothing to find !", 1500)
 def VVTXCi(self, VVdesl, mode, onlyCatID, title, words, toFind, asPrefix, VVNVFL):
  VVNVFL.VV0amK(VVdesl.VVH1h9() if onlyCatID is None else 1)
  VVNVFL.VVpwcW = []
  for row in VVdesl.VVTW2g():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVNVFL or VVNVFL.isCancelled:
    return
   VVNVFL.VViyfK(1)
   VVNVFL.VV51IW(catName)
   qUrl  = self.VVnWzT(mode, self.VV5nPVData["playListURL"], catID)
   txt, err = self.VVnY0U(qUrl)
   if not err:
    tList, err = self.VV1ATy(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = self.VVz6O6(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if not VVNVFL or VVNVFL.isCancelled:
        return
       VVNVFL.VVpwcW.append(item)
       VVNVFL.VV51IW(catName)
 def VVHJJ6(self, mode, toFind, title, VVdCuP, VVpwcW, threadCounter, threadTotal, threadErr):
  if VVpwcW:
   title = self.VVdEhw(mode, toFind)
   if mode == self.VVGeyj or mode == self.VVD73g:
    if mode == self.VVD73g : typ = "v"
    else          : typ = ""
    bName   = CCoUhv.VVFP7U(toFind)
    VVMWQK  = ("Play"     , BF(self.VVq3mF, mode)     , [])
    VV1kWx = ("Download Options" , BF(self.VVbubI, mode, typ, "") , [])
    VVM9Pm = ("Options"   , BF(self.VVQ9xp, "fnd", mode, bName), [])
    VVRHhw = ("Posters Mode"  , BF(self.VV3yl3, mode, False)   , [])
    VVZArZ = (""     , BF(self.VVpR4r, mode)    , [])
   elif mode == self.VVIYmB:
    VVMWQK  = ("Show Seasons"  , BF(self.VVkPbt, mode)     , [])
    VVM9Pm = None
    VV1kWx = None
    VVRHhw = ("Posters Mode"  , BF(self.VV3yl3, mode, True)    , [])
    VVZArZ = (""     , BF(self.VVjvIR, mode)   , [])
   VVIzUv  = ("Home Menu"   , FFqjXt          , [])
   header, widths, VV0CnX = self.VVRYqJ(mode)
   VVdesl = FFDpub(self, None, title=title, header=header, VVcuvv=VVpwcW, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=26, VVMWQK=VVMWQK, VVIzUv=VVIzUv, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw, VVZArZ=VVZArZ, VVaRsg="#0a00292B", VVWgai="#0a002126", VVSJJk="#0a002126", VVYCZ6="#00000000", VVEMdg=True, searchCol=1)
   if not VVdCuP:
    FFZD7H(VVdesl, "Stopped" , 1000)
  else:
   if VVdCuP:
    FFOyl1(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVQqBJ(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VVGeyj, self.VVIWj9):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VVD73g:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FF3gfV(chName)
  url = self.VV5nPVData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVkgSK(url)
  refCode = self.VVGbMl(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVpR4r(self, mode, VVdesl, title, txt, colList):
  FFbA1i(VVdesl, BF(self.VVSRcD, mode, VVdesl, title, txt, colList))
 def VVSRcD(self, mode, VVdesl, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVQqBJ(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FF1wB7(self, fncMode=CCqIel.VVTkls, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVjvIR(self, mode, VVdesl, title, txt, colList):
  FFbA1i(VVdesl, BF(self.VVz1eW, mode, VVdesl, title, txt, colList))
 def VVz1eW(self, mode, VVdesl, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FF1wB7(self, fncMode=CCqIel.VV4prm, chName=name, text=txt, picUrl=Cover)
 def VV3yl3(self, mode, isSerNames, VVdesl, title, txt, colList):
  if   mode in ("itv"  , CCoUhv.VVGeyj, CCoUhv.VVIWj9): category = "live"
  elif mode in ("vod"  , CCoUhv.VVD73g )          : category = "vod"
  elif mode in ("series" , CCoUhv.VVIYmB)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VVGeyj : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVIWj9 : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVD73g  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVIYmB : picCol, descCol, descTxt = 5, 0, "Season"
  FFbA1i(VVdesl, BF(self.session.open, CCeLLo, VVdesl, category, nameCol, picCol, descCol, descTxt))
 def VVbubI(self, mode, typ, seriesName, VVdesl, title, txt, colList):
  VVtMHe = []
  isMulti = VVdesl.VVcTnU
  tot  = VVdesl.VVLHWg()
  if isMulti:
   if tot < 1:
    FFZD7H(VVdesl, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVtMHe.append(("Download %s PIcon%s" % (name, FFsfSO(tot)), "dnldPicons" ))
  if typ:
   VVtMHe.append(VVXGzj)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVtMHe.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVtMHe.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVtMHe.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCEvBr.VVk9dH():
    VVtMHe.append(VVXGzj)
    VVtMHe.append(("Download Manager"      , "dload_stat" ))
  FFECK9(self, BF(self.VVjrWd, VVdesl, mode, typ, seriesName, colList), title="Download Options", VVtMHe=VVtMHe)
 def VVjrWd(self, VVdesl, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVGiPX(VVdesl, mode)
   elif item == "dnldSel"  : self.VVExVF(VVdesl, mode, typ, colList, True)
   elif item == "addSel"  : self.VVExVF(VVdesl, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVilHE(VVdesl, mode, typ, seriesName)
   elif item == "dload_stat" : CCEvBr.VVQOcZ(self, VVdesl)
 def VVExVF(self, VVdesl, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVL2BS(mode, typ, colList)
  if startDnld:
   CCEvBr.VV0Osn(self, decodedUrl)
  else:
   self.VVmkqN(VVdesl, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVilHE(self, VVdesl, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVdesl.VVTW2g():
   chName, decodedUrl = self.VVL2BS(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVmkqN(VVdesl, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVmkqN(self, VVdesl, title, chName, decodedUrl_list, startDnld):
  FFgBNQ(self, BF(self.VVTkSh, VVdesl, decodedUrl_list, startDnld), chName, title=title)
 def VVTkSh(self, VVdesl, decodedUrl_list, startDnld):
  added, skipped = CCEvBr.VVoUGn(decodedUrl_list)
  FFZD7H(VVdesl, "Added", 1000)
 def VVL2BS(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVQqBJ(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVE4tz(mode, colList)
   refCode, chUrl = self.VVaCQl(self.VViEDk, self.VVdwIL, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFp63C(chUrl)
  return chName, decodedUrl
 def VVGiPX(self, VVdesl, mode):
  if FFLsle("ffmpeg"):
   self.session.open(CCjWUz, barTheme=CCjWUz.VVh7HE
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VVGI1R, VVdesl, mode)
       , VVCBqA = self.VV8hzP)
  else:
   FFgBNQ(self, BF(CCoUhv.VVMeQ3, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VV8hzP(self, VVdCuP, VVpwcW, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVpwcW["proces"], VVpwcW["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVpwcW["ok"], VVpwcW["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVpwcW["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVpwcW["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVpwcW["badURL"]
  txt += "Download Failure\t: %d\n"   % VVpwcW["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVpwcW["path"]
  if not VVdCuP  : color = "#11402000"
  elif VVpwcW["err"]: color = "#11201000"
  else     : color = "#22001122"
  if VVpwcW["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVpwcW["err"], txt)
  title = "PIcons Download Result"
  if not VVdCuP:
   title += "  (cancelled)"
  FFoB4k(self, txt, title=title, VVSJJk=color)
 def VVGI1R(self, VVdesl, mode, VVNVFL):
  isMulti = VVdesl.VVcTnU
  if isMulti : totRows = VVdesl.VVLHWg()
  else  : totRows = VVdesl.VVH1h9()
  VVNVFL.VV0amK(totRows)
  VVNVFL.VVp98U(0)
  counter     = VVNVFL.counter
  maxValue    = VVNVFL.maxValue
  pPath     = CCuqLp.VVchM7()
  VVNVFL.VVpwcW = {   "total" : totRows
         , "proces" : 0
         , "attempt" : 0
         , "fail" : 0
         , "ok"  : 0
         , "size0" : 0
         , "exist" : 0
         , "badURL" : 0
         , "path" : pPath
         , "err"  : "" }
  try:
   for rowNum, row in enumerate(VVdesl.VVTW2g()):
    if VVNVFL.isCancelled:
     break
    if not isMulti or VVdesl.VV44Kf(rowNum):
     VVNVFL.VVpwcW["proces"] += 1
     VVNVFL.VViyfK(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVE4tz(mode, row)
      refCode = CCoUhv.VVGbMl(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVaLSR(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVQqBJ(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVNVFL.VVpwcW["attempt"] += 1
       path, err = FF4VyK(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVNVFL:
         VVNVFL.VVpwcW["ok"] += 1
         VVNVFL.VVp98U(VVNVFL.VVpwcW["ok"])
        if FFF0Rr(path) > 0:
         cmd = CCqIel.VVIyOc(path)
         cmd += FFb0lc("mv -f '%s' '%s'" % (path, pPath))
         FFqSkC(cmd)
        else:
         if VVNVFL:
          VVNVFL.VVpwcW["size0"] += 1
         FFOlRe(path)
       elif err:
        if VVNVFL:
         VVNVFL.VVpwcW["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVNVFL:
          VVNVFL.VVpwcW["err"] = err.title()
         break
      else:
       if VVNVFL:
        VVNVFL.VVpwcW["exist"] += 1
     else:
      if VVNVFL:
       VVNVFL.VVpwcW["badURL"] += 1
  except:
   pass
 def VVJxLR(self):
  title = "Download PIcons for Current Bouquet"
  if FFLsle("ffmpeg"):
   self.session.open(CCjWUz, barTheme=CCjWUz.VVh7HE
       , titlePrefix = ""
       , fncToRun  = self.VVTAj6
       , VVCBqA = BF(self.VVIwQJ, title))
  else:
   FFgBNQ(self, BF(CCoUhv.VVMeQ3, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VVTAj6(self, VVNVFL):
  bName = CCotiQ.VVFiWm()
  pPath = CCuqLp.VVchM7()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVNVFL.VVpwcW = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CCotiQ.VV6s7T()
  if not VVNVFL or VVNVFL.isCancelled:
   return
  if not services or len(services) == 0:
   VVNVFL.VVpwcW = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVNVFL.VV0amK(totCh)
  VVNVFL.VVp98U(0)
  for serv in services:
   if not VVNVFL or VVNVFL.isCancelled:
    return
   VVNVFL.VVpwcW = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVNVFL.VViyfK(1)
   VVNVFL.VVp98U(totPic)
   fullRef  = serv[0]
   if FFueFC(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFp63C(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err = CCOGg2.VV6Ffa(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CCoUhv.VV1JTf(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInvServ += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCoUhv.VVnY0U(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CCqIel.VVxFTl(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FF4VyK(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVNVFL:
     VVNVFL.VVp98U(totPic)
    if FFF0Rr(path) > 0:
     cmd = CCqIel.VVIyOc(path)
     cmd += FFb0lc("mv -f '%s' '%s'" % (path, pPath))
     FFqSkC(cmd)
     totPicOK += 1
    else:
     totSize0
     FFOlRe(path)
  if VVNVFL:
   VVNVFL.VVpwcW = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVIwQJ(self, title, VVdCuP, VVpwcW, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VVpwcW
  if err:
   FFOyl1(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FF8oA9(str(totExist)  , VV8ETX)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FF8oA9(str(totNotIptv)  , VV8ETX)
    if totServErr : txt += "Server Errors\t: %s\n" % FF8oA9(str(totServErr) + t1, VV8ETX)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FF8oA9(str(totParseErr) , VV8ETX)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FF8oA9(str(totInvServ)  , VV8ETX)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FF8oA9(str(totInvPicUrl) , VV8ETX)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FF8oA9(str(totSize0)  , VV8ETX)
   if not VVdCuP:
    title += "  (stopped)"
   FFoB4k(self, txt, title=title)
 @staticmethod
 def VVMeQ3(SELF):
  cmd = FFbfXZ(VVqrBj, "ffmpeg")
  if cmd : FFyrLj(SELF, cmd, title="Installing FFmpeg")
  else : FFvp5w(SELF)
 @staticmethod
 def VVAZLx(SELF):
  SELF.session.open(CCjWUz, barTheme=CCjWUz.VVh7HE
      , titlePrefix = ""
      , fncToRun  = CCoUhv.VVUoRn
      , VVCBqA = BF(CCoUhv.VVDkLd, SELF))
 @staticmethod
 def VVUoRn(VVNVFL):
  bName = CCotiQ.VVFiWm()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVNVFL.VVpwcW = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CCotiQ.VV6s7T()
  if not VVNVFL or VVNVFL.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVNVFL.VV0amK(totCh)
   for serv in services:
    if not VVNVFL or VVNVFL.isCancelled:
     return
    VVNVFL.VViyfK(1)
    fullRef = serv[0]
    if FFueFC(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFp63C(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     pList, err = [], ""
     if span:
      pList, err = CCOGg2.VVpR2C(decodedUrl, retLst=True)
     else:
      uType, uHost, uUser, uPass, uId, uChName = CCoUhv.VV1JTf(decodedUrl)
      if all([uHost, uUser, uPass, uId]):
       url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
       pList, err = CCoUhv.VVFFdU(url, uId)
      else:
       totInv += 1
     if err:
      totServErr += 1
      if "Unauth" in err:
       totUnauth += 1
     if VVNVFL:
      VVNVFL.VVmvzP(totEpgOK, uChName)
     if pList:
      totEv, totOK = CCfTje.VVNFjl(refCode, pList)
      totEpg += totEv
      totEpgOK += totOK
    else:
     totNotIptv += 1
    if VVNVFL:
     VVNVFL.VVpwcW = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVNVFL.VVpwcW = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 @staticmethod
 def VVDkLd(SELF, VVdCuP, VVpwcW, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVpwcW
  title = "IPTV EPG Import"
  if err:
   FFOyl1(SELF, err, title=title)
  else:
   if VVdCuP and totEpgOK > 0:
    CCfTje.VVYgeK()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FF8oA9(str(totNotIptv), VV8ETX)
    if totServErr : txt += "Server Errors\t: %s\n" % FF8oA9(str(totServErr) + t1, VV8ETX)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FF8oA9(str(totInv), VV8ETX)
   if not VVdCuP:
    title += "  (stopped)"
   FFoB4k(SELF, txt, title=title)
 @staticmethod
 def VVFFdU(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCoUhv.VVkgSK(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCoUhv.VVnY0U(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCoUhv.VVGIa1(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CCoUhv.VVGIa1(item, "lang"        ).upper()
    now_playing   = CCoUhv.VVGIa1(item, "now_playing"      )
    start    = CCoUhv.VVGIa1(item, "start"        )
    start_timestamp  = CCoUhv.VVGIa1(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCoUhv.VVGIa1(item, "start_timestamp"     )
    stop_timestamp  = CCoUhv.VVGIa1(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCoUhv.VVGIa1(item, "stop_timestamp"      )
    tTitle    = CCoUhv.VVGIa1(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVGbMl(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCoUhv.VVhok1(catID, MAX_4b)
  TSID = CCoUhv.VVhok1(chNum, MAX_4b)
  ONID = CCoUhv.VVhok1(chNum, MAX_4b)
  NS  = CCoUhv.VVhok1(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVhok1(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVFP7U(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVJktB(mode):
  if   mode in ("itv"  , CCoUhv.VVVCMd)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCoUhv.VV0Qng)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCoUhv.VV5kkI) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCoUhv.VVSMo0) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCoUhv.VVIWj9    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVZwKG(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVpo4j:
   excl = FFXN5L(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FFOyl1(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FFYEhL('find %s %s %s' % (path, excl, par))
  if files:
   err = CCVnYx.VVDb8p(files)
   if err : FFOyl1(self, err + FF8oA9('\n\n( Change "IPTV Hosts Files Path" to "Custom" and try again )', VVRuOi))
   else : return files
  else:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FFOyl1(self, err)
  return []
 @staticmethod
 def VVfXlV():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FFDpEI(path)
  return "/"
 @staticmethod
 def VVrPkx(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CCoUhv.VVFFdU(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FFOyl1(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVaRsg, VVWgai, VVSJJk, VVYCZ6 = CCoUhv.VVJktB("")
   VVIzUv = ("Home Menu" , FFqjXt, [])
   VVMWQK  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VV0CnX  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFDpub(SELF, None, title="Programs for : " + chName, header=header, VVcuvv=pList, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=24, VVMWQK=VVMWQK, VVIzUv=VVIzUv, VVaRsg=VVaRsg, VVWgai=VVWgai, VVSJJk=VVSJJk, VVYCZ6=VVYCZ6)
  else:
   FFOyl1(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVYQAD(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VVnAMb(self, isPortal, line, selectionObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FFgBNQ(self, BF(self.VV2oXc, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FF0UO9(confItem, line)
   FFDeF8(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VV2oXc(self, title, confItem):
  FF0UO9(confItem, "")
  FFDeF8(self, "Removed from IPTV Menu.", title=title)
 def VVVNFu(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VVkEnX(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FFbA1i(self, BF(self.VVsxAp, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FFOyl1(self, "Incorrect server data !")
 @staticmethod
 def VVxMqR(SELF, isPortal, line, selectionObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCoUhv.VVfXlV()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFOyl1(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFDeF8(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFOyl1(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVQ9xp(self, source, mode, curBName, VVdesl, title, txt, colList):
  isMulti = VVdesl.VVcTnU
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVdesl.VVLHWg()
   totTxt = "%d Service%s" % (tot, FFsfSO(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FF8oA9(totTxt, VVRuOi)
  curBName2 = ""
  if self.curUrl:
   name = iUrlparse(self.curUrl).netloc
   if name:
    curBName2 = "%s (%s)" % (curBName, name.split(":")[0])
  title = "Add to Bouquet"
  mSel = CCB2u5(self, VVdesl, addSep=False)
  thTxt = "Adding Services ..."
  VVtMHe, cbFncDict = [], None
  VVtMHe.append(VVXGzj)
  if itemsOK:
   VVtMHe.append(("Add %s to New Bouquet : %s"    % (totTxt, FF8oA9(curBName , VViZMT)), "addToCur1"))
   if curBName2: VVtMHe.append(("Add %s to New Bouquet : %s" % (totTxt, FF8oA9(curBName2, VVoIYV)) , "addToCur2"))
   VVtMHe.append(("Add %s to Existing Bouquet ..."   % (totTxt)            , "addToNew" ))
   cbFncDict = { "addToCur1": BF(FFbA1i, mSel.VVdesl, BF(self.VVYrm1,source, mode, curBName , VVdesl, title), title=thTxt)
      , "addToCur2": BF(FFbA1i, mSel.VVdesl, BF(self.VVYrm1,source, mode, curBName2, VVdesl, title), title=thTxt)
      , "addToNew" : BF(self.VVodSz, source, mode, curBName, VVdesl, title)
      }
  else:
   VVtMHe.append(("Add to Bouquet (nothing selected)", ))
  mSel.VVcQQV(VVtMHe, cbFncDict, width=1400)
 def VVYrm1(self, source, mode, curBName, VVdesl, Title):
  chUrlLst = self.VVAtOy(source, mode, VVdesl)
  CCotiQ.VVvpYd(self, Title, curBName, "", chUrlLst)
 def VVodSz(self, source, mode, curBName, VVdesl, Title):
  picker = CCotiQ(self, VVdesl, Title, BF(self.VVAtOy, source, mode, VVdesl), defBName=curBName)
 def VVAtOy(self, source, mode, VVdesl):
  totChange = 0
  isMulti = VVdesl.VVcTnU
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVdesl.VVTW2g()):
   if not isMulti or VVdesl.VV44Kf(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVE4tz(mode, row)
     refCode, chUrl = self.VVaCQl(self.VViEDk, self.VVdwIL, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VVtwnG(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VVQqBJ(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
 @staticmethod
 def VVfqoZ():
  return {"1": "DVB Stream", "4097": "servicemp3", "5001": "GST Player", "5002": "Ext-3 EPlayer", "8192": "HDMI input", "8193": "eServiceUri"}
 @staticmethod
 def VVO4pN():
  return sorted(tuple(CCoUhv.VVfqoZ()))
 @staticmethod
 def VVnTMx(rt):
  return CCoUhv.VVfqoZ().get(str(rt), "")
 @staticmethod
 def VVD90E(refCode):
  span = iSearch(r"(?:([A-Fa-f0-9]+):){1}(?:[A-Fa-f0-9]+:){8}", refCode)
  return CCoUhv.VVnTMx(span.group(1)) if span else ""
 @staticmethod
 def VVoESL(rt):
  if   rt == "1"  : return True
  elif rt == "4097": return True
  elif rt == "5001": return fileExists("/usr/bin/gstplayer") or fileExists("/usr/bin/gstplayer_gst-1.0")
  elif rt == "5002": return fileExists("/usr/bin/exteplayer3")
  elif rt == "8192": return False
  elif rt == "8193": return os.path.exists("/usr/bin/apt-get")
  else    : return False
 @staticmethod
 def VV7ivb():
  defRt = CFG.iptvAddToBouquetRefType.getValue()
  VVtMHe = []
  for ndx, rt in enumerate(CCoUhv.VVO4pN()):
   VVtMHe.append(FFQlwu("%s\t... %s" % (CCoUhv.VVnTMx(rt), rt), rt, CCoUhv.VVoESL(rt), VV7z62 if rt == defRt else ""))
   if ndx < 4 and ndx % 2: VVtMHe.append(VVXGzj)
  return VVtMHe
class CCmHSc(object):
 def __init__(self, SELF):
  SELF["mySbFrm"] = Label()
  SELF["mySbBak"] = Label()
  SELF["mySbSld"] = Label()
  self.frm, self.bak, self.sld = SELF["mySbFrm"], SELF["mySbBak"], SELF["mySbSld"]
  self.frmI = self.bakI = self.sldI = None
  self.sldX = self.sldY = self.sldW = self.sldH = 0
  for obj in (self.frm, self.bak, self.sld): obj.hide()
 def VVyIua(self, x, y, w, h, bW=1, frmColor="#11aaaaaa", bakColor="#11003344", sldColor="#11ff8000"):
  x, y, w, h = int(x), int(y), int(w), int(h)
  FFC3pI(self.frm, frmColor)
  FFC3pI(self.bak, bakColor)
  FFC3pI(self.sld, sldColor)
  self.frmI, self.bakI, self.sldI = self.frm.instance, self.bak.instance, self.sld.instance
  self.frmI.move(ePoint(x, y))
  self.frmI.resize(eSize(w, h))
  self.bakI.move(ePoint(x + bW, y + bW))
  self.bakI.resize(eSize(w - bW * 2, h - bW * 2))
  self.sldX = x + bW
  self.sldY = y + bW
  self.sldW = w - bW * 2
  self.sldH = h - bW * 2
  self.sldI.move(ePoint(self.sldX, self.sldY))
  self.sldI.resize(eSize(self.sldW, self.sldH))
 def VVbt3B(self, val, maxN):
  if maxN < 2:
   for obj in (self.frm, self.bak, self.sld): obj.hide()
  else:
   for obj in (self.frm, self.bak, self.sld): obj.show()
   visH = max(self.sldH / maxN, self.sldH * 0.05)
   self.sldI.resize(eSize(self.sldW, int(visH)))
   y = FFYZmF(val, 1, maxN, 0, self.sldH - visH)
   self.sldI.move(ePoint(self.sldX, int(self.sldY + y)))
class CCIquq(CCmHSc):
 def __init__(self, rows, cols, colorCfg):
  self.TOTAL_ROWS   = rows
  self.TOTAL_COLS   = cols
  self.PAGE_ITEMS   = self.TOTAL_ROWS * self.TOTAL_COLS
  self.colorCfg   = colorCfg
  self.totalItems   = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.isBusy    = False
  CCmHSc.__init__(self, self)
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  self.VVCoFp()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(VVQOuY,
  {
   "up" : self.VV7yT6   ,
   "down" : self.VVjcLF  ,
   "left" : self.VViWA8  ,
   "right" : self.VVpaBZ  ,
   "next" : self.VVlu2y ,
   "last" : self.VVTqsq
  }, -1)
 def VVOoGg(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
  gap = int(self.skinParam["marginLeft"] / 1)
  topBox = self["myPosterPic%d%d" % (0, 0)].instance
  botBox = self["myPosterPic%d%d" % (self.TOTAL_ROWS - 1, self.TOTAL_COLS - 1)].instance
  w = 20
  y = topBox.position().y() - int(self.skinParam["marginTop"] / 2) + 2
  h = self.skinParam["height"] - self.skinParam["barHeight"] - y - 2
  x = self.skinParam["width"] - w - 2
  self.VVyIua(x, y, w, h)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    try:
     inst = (self["myPosterLbl%d%d" % (row, col)]).instance
     inst.setBorderColor(parseColor("#000000"))
     inst.setBorderWidth(2)
    except:
     pass
  self.VVtI3D()
  self["myPiconPtr"].hide()
 def VVaMX8(self):
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > self.totalItems: f1 = self.totalItems
  if f2 > self.totalItems: f2 = self.totalItems
  return f1, f2
 def VV7yT6(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVKt3O()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVaG1c()
 def VVjcLF(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV7hNq()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVaG1c()
 def VViWA8(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVKt3O()
  else:
   self.curCol -= 1
   self.VVaG1c()
 def VVpaBZ(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV7hNq()
  else:
   self.curCol += 1
   self.VVaG1c()
 def VVTqsq(self):
  oldPage = self.curPage
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVaG1c(oldPage != self.curPage)
 def VVlu2y(self):
  oldPage = self.curPage
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVaG1c(oldPage != self.curPage)
 def VV7hNq(self):
  force = self.curPage != 0
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVaG1c(force)
 def VVKt3O(self):
  force = self.curPage != self.totalPages - 1
  self.curPage = self.totalPages - 1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVaG1c(force)
 def VVaG1c(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VV2EDV = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VV2EDV: self.curPage = VV2EDV
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  self.VVEU69()
  self["myPiconPtr"].hide()
  self.VVbt3B(self.curPage + 1, self.totalPages)
  FFkvVR(BF(self.VVFOqd, force or not oldPage == self.curPage, VV2EDV))
 def VVFOqd(self, force, VV2EDV):
  try:
   if force:
    self.VVQQTH()
   if self.curPage == VV2EDV:
    if self.curRow > self.lastRow:
     self.curRow = self.lastRow
    if self.curRow == self.lastRow and self.curCol > self.lastCol:
     self.curCol = self.lastCol
   self.curIndex = self.curPage * self.PAGE_ITEMS + self.curRow * self.TOTAL_COLS + self.curCol
   self.VVEU69()
   boxX, boxY, boxW, boxH = self.skinParam["extraPar"]
   self["myPiconPtr"].instance.move(ePoint(int(boxX + boxW * self.curCol), int(boxY + boxH * self.curRow)))
  except:
   pass
  self["myPiconPtr"].show()
 def VVUBc5(self, ndx):
  if ndx > -1 and ndx < self.totalItems:
   oldPage   = self.curPage
   self.curPage = int(ndx / self.PAGE_ITEMS)
   firstInPage  = self.curPage * self.PAGE_ITEMS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVaG1c(False if oldPage == self.curPage else True)
  else:
   FFZD7H(self, "Not found", 1000)
 def VVVNAn(self):
  self.VVUBc5(self.totalItems - 1 if self.curIndex == 0 else 0)
 def VVCoFp(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)].hide()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
 def VVCdm8(self):
  if self.colorCfg:
   fg = bg = self.colorCfg.getValue()
   self.session.openWithCallback(self.VVrjrj, CCmyVJ, defFG=fg, defBG=bg, onlyBG=True)
 def VVrjrj(self, fg, bg):
  if self.colorCfg and bg:
   FF0UO9(self.colorCfg, bg)
   self.VVtI3D()
 def VVtI3D(self):
  if self.colorCfg:
   for row in range(self.TOTAL_ROWS):
    for col in range(self.TOTAL_COLS):
     FFC3pI(self["myPosterRep%d%d" % (row, col)], self.colorCfg.getValue())
 def VVKGTb(self, lbl, txt, color=""):
  CCIquq.VVEEH6(lbl, txt, color)
 @staticmethod
 def VVEEH6(lbl, txt, color=""):
  lbl.show()
  lbl.setText(txt)
  txtW = lbl.instance.calculateSize().width()
  lblW = lbl.instance.size().width() - 15
  if txtW > lblW:
   for i in range(len(txt), 5, -1):
    txt = txt[:-1]
    lbl.setText("%s.." % txt)
    txtW = lbl.instance.calculateSize().width()
    if txtW < lblW:
     break
  if color:
   lbl.setText("%s%s" % (color, txt))
 @staticmethod
 def VVkpor(pic, path):
  pic.show()
  if fileExists(path):
   try:
    png = LoadPixmap(path)
    pic.instance.setScale(1)
    pic.instance.setPixmap(png)
    return png
   except:
    pass
  return None
class CCeLLo(Screen, CCIquq):
 def __init__(self, session, VVdesl, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FFPFsH(VVLivS, 1870, 1030, 50, 3, 3, "#33000000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "Server Browser"
  self.VVdesl  = VVdesl
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.VVcuvv    = []
  self.totPosterUrls  = 0
  self.totalItems   = 0
  FFRFZg(self, self.Title)
  CCIquq.__init__(self, 2, 6, CFG.transpColorPosters)
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VVZAJU, subPath)
  if not pathExists(self.pPath):
   FFqSkC("mkdir -p '%s'" % self.pPath)
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myAction"].actions.update(
  {
   "ok" : self.VV2Iyl    ,
   "cancel": self.close    ,
   "menu" : self.VVv57u ,
   "info" : self.VVPpbE  ,
   "0"  : self.VVVNAn
  })
  self.onShown.append(self.VVnLQg)
  self.onClose.append(self.onExit)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFk6h6(self)
  FFFlxX(self)
  self.VVOoGg()
  self.VVu7L7()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVv57u(self):
  chName, subj, desc, fName, picUrl = self.VVcuvv[self.curIndex]
  VVtMHe = []
  VVtMHe.append(FFQlwu("Show Selected Picture"        , "VVhmNM"  , fName))
  VVtMHe.append(FFQlwu("Copy Selected Picture to Export-Directory"   , "VVqb3d" , fName))
  VVtMHe.append(FFQlwu("Set Selected Picture as a Poster for a Local Media" , "VV1c9Y", fName))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Cache details"       , "VVsRNg"  ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Change Poster/Picon Transparency Color" , "VVCdm8" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Help (Keys)"        , "help"     ))
  FFECK9(self, self.VV9tfO, title=self.Title, VVtMHe=VVtMHe)
 def VV9tfO(self, item=None):
  if item is not None:
   if   item == "VVhmNM"   : self.VVhmNM()
   elif item == "VVqb3d"   : self.VVqb3d()
   elif item == "VV1c9Y"  : self.VV1c9Y()
   elif item == "VVsRNg"  : FFbA1i(self, self.VVsRNg, title="Calculating ...")
   elif item == "VVCdm8": self.VVCdm8()
   elif item == "help"     : FFSnt9(self, "_help_servBr", "Server Browser (Keys)")
 def VV2Iyl(self):
  self.VVdesl.VVTklH(self.curIndex)
  self.VVdesl.VVNHwA()
 def VVPpbE(self):
  self.VVdesl.VVTklH(self.curIndex)
  self.VVdesl.VV7MZh()
 def VVu7L7(self):
  for colList in self.VVdesl.VVTW2g():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = os.path.basename(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VVcuvv.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalItems = len(self.VVcuvv)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  ndx = self.VVdesl.VVvapY()
  self.curPage = int(ndx / self.PAGE_ITEMS)
  ndx     -= self.curPage * self.PAGE_ITEMS
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VVaG1c(True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVwZ4g)
  except:
   self.timer.callback.append(self.VVwZ4g)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VV32Hj)
  self.myThread.start()
 def VV32Hj(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VVcuvv):
    if not self.stopThread:
     if picUrl and not fName:
      fName = os.path.basename(picUrl)
      path, err = FF4VyK(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       FFqSkC("mv -f '%s' '%s'" % (path, self.pPath + fName))
       self.VVcuvv[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VVwZ4g(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VVOr14 + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalItems
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVcuvv[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VVcuvv[ndx] = (chName, subj, desc, fName, "")
     CCIquq.VVkpor(self["myPosterPic%d%d" % (row, col)], path)
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVQQTH(self):
  self.VVCoFp()
  f1, f2 = self.VVaMX8()
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVcuvv[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVKGTb(lbl, chName)
   path = ""
   if fName    : path = self.pPath + fName
   if not fileExists(path) : path = VV2V68 + "iptv.png"
   CCIquq.VVkpor(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVEU69(self):
  chName, subj, desc, fName, picUrl = self.VVcuvv[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVhmNM(self):
  chName, subj, desc, fName, picUrl = self.VVcuvv[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CCXzC3.VVHZ7h(self, self.pPath + fName)
  else          : FFZD7H(self, "File not found", 1500)
 def VVqb3d(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VVcuvv[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   if FFqSkC("cp -f '%s' '%s'" % (self.pPath + fName, dstF)):
    FFDeF8(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FFOyl1(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FFOyl1(self, "No Poster/PIcon found", title=title)
 def VV1c9Y(self):
  self.session.openWithCallback(self.VV4oWH, BF(CCVnYx, patternMode="movies", VVSMX5=CFG.MovieDownloadPath.getValue()))
 def VV4oWH(self, path):
  if path:
   title = "Set Selected Picture as a Poster for a Local Media"
   chName, subj, desc, fName, picUrl = self.VVcuvv[self.curIndex]
   if fName:
    srcF = self.pPath + fName
    dstF = "%s%s" % (os.path.splitext(path)[0], os.path.splitext(srcF)[1])
    if FFqSkC("cp -f '%s' '%s'" % (srcF, dstF)):
     FFDeF8(self, "File copied to:\n\n%s" % dstF, title=title)
    else:
     FFOyl1(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstF), title=title)
    CCYcxX.VVtuZE(dstF)
   else:
    FFOyl1(self, "No Poster/PIcon found", title=title)
 def VVsRNg(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VVZAJU, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FFvL4V("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CCVnYx.VVI3LQ(size)
   txt += "%s\n    %s\n\n" % (FF8oA9(path, VVRuOi), size)
  mainPath = "%sPosters" % VVZAJU
  totFiles = FFvL4V("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FFsfSO(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FF8oA9("Total space used by Posters/PIcons%s:" % totFTxt, VVXAXH), CCVnYx.VVI3LQ(totSize))
  mountPath = CCVnYx.VV4cQu(mainPath)
  if pathExists(mountPath):
   totSize  = CCVnYx.VV0ibt(mountPath)
   freeSize = CCVnYx.VVP9pE(mountPath)
   usedSize = CCVnYx.VVI3LQ(totSize - freeSize)
   totSize  = CCVnYx.VVI3LQ(totSize)
   freeSize = CCVnYx.VVI3LQ(freeSize)
   txt += "%s\n" % SEP
   txt += FF8oA9("Media Space:\n", VV4mV2)
   txt += "    Media Path\t: %s\n" % FF8oA9(mountPath, VVdVTX)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FFoB4k(self, txt, title="Cache Used Size", height=1000)
class CCYcxX(Screen, CCIquq):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFPFsH(VVgjmm, 1870, 1030, 50, 3, 3, "#33440000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = title
  self.VVcuvv    = lst
  FFRFZg(self, self.Title)
  CCIquq.__init__(self, 2, 6, CFG.transpColorMovies)
  self["myAction"].actions.update(
  {
   "ok" : self.VV2Iyl    ,
   "cancel": self.close    ,
   "menu" : self.VV5brN ,
   "info" : self.VVVLRT  ,
   "0"  : self.VVVNAn
  })
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFk6h6(self)
  FFFlxX(self)
  self.VVOoGg()
  self.totalItems = len(self.VVcuvv)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVaG1c(True)
 def VVQQTH(self):
  self.VVCoFp()
  f1, f2 = self.VVaMX8()
  mPath = CFG.MovieDownloadPath.getValue()
  row = col = 0
  for ndx in range(f1, f2):
   path, movie, poster = self.VVcuvv[ndx]
   path = os.path.join(mPath, path)
   path = os.path.join(path, movie)
   if poster: poster = os.path.join(os.path.dirname(path), poster)
   else  : poster = VV2V68 + "noPos.png"
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVKGTb(lbl, os.path.splitext(os.path.basename(path))[0])
   CCIquq.VVkpor(pic, poster)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVDMup(self):
  path, movie, poster = self.VVcuvv[self.curIndex]
  path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
  path = os.path.join(path, movie)
  if poster:
   poster = os.path.join(os.path.dirname(path), poster)
  return path, poster
 def VVEU69(self):
  path, poster = self.VVDMup()
  self["myPiconInf0"].setText("  " + os.path.splitext(os.path.basename(path))[0] + "  ")
  self["myPiconInf1"].setText("   " + os.path.dirname(path) + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VV5brN(self):
  path, poster = self.VVDMup()
  VVtMHe = []
  VVtMHe.append(("Go to movie ...", "VVD5Dx"))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(FFQlwu("Show Poster"      , "VVhmNM" , poster))
  VVtMHe.append(FFQlwu("Copy Poster to Export-Directory" , "VVqb3d", poster))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Change Poster/Picon Transparency Color"  , "VVCdm8" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Change Poster (from current movie path) ..." , "VVOq9q1"  ))
  VVtMHe.append(("Change Poster (locate manually) ..."   , "VVOq9q2"  ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Help (Keys)"         , "help"     ))
  FFECK9(self, self.VVIvTd, title=self.Title, VVtMHe=VVtMHe)
 def VVIvTd(self, item=None):
  if item is not None:
   if   item == "VVD5Dx"    : self.VVD5Dx()
   elif item == "VVqb3d"    : self.VVqb3d()
   elif item == "VVhmNM"    : self.VVhmNM()
   elif item == "VVCdm8" : self.VVCdm8()
   elif item == "VVOq9q1"  : self.VVOq9q()
   elif item == "VVOq9q2"  : self.VVOq9q(True)
   elif item == "help"      : FFSnt9(self, "_help_movBr", "Movies Browser (Keys)")
 def VVD5Dx(self):
  VVsLLE = []
  for ndx, item in enumerate(self.VVcuvv):
   path, movie, poster = item
   path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
   VVsLLE.append((os.path.splitext(movie)[0], path, str(ndx)))
  VVsLLE.sort(key=lambda x: x[0].lower())
  VVMWQK = ("Select" , self.VVmJc0, [])
  header  = ("Name" , "Path", "NDX.")
  widths  = (60  , 40 , 0  )
  FFDpub(self, None, title="Select Movie", width=1800, height=1000, header=header, VVcuvv=VVsLLE, VVbG6j=widths, VVGNdU=26, VVMWQK=VVMWQK, lastFindConfigObj=CFG.lastFindMovie)
 def VVmJc0(self, VVdesl, title, txt, colList):
  self.VVUBc5(int(colList[2].strip()))
  VVdesl.cancel()
 def VV2Iyl(self):
  path, poster = self.VVDMup()
  FFbA1i(self, BF(CCVnYx.VVWQNk, self, path), title="Playing Media ...")
 def VVVLRT(self):
  path, poster = self.VVDMup()
  txt = "%s:\n%s\n\n" % (FF8oA9("Path", VVRuOi), path)
  size = FFF0Rr(path)
  if size > -1:
   txt += "%s:\n%s\n\n" % (FF8oA9("File Size", VVRuOi), CCVnYx.VVI3LQ(size))
  if poster:
   txt += "%s:\n%s" % (FF8oA9("Poster", VVRuOi), poster)
  FFoB4k(self, txt, title="Media File Information")
 def VVhmNM(self):
  path, poster = self.VVDMup()
  if fileExists(poster): CCXzC3.VVHZ7h(self, poster)
  else     : FFZD7H(self, "No Poster", 1500)
 def VVqb3d(self):
  title = "Copy Poster"
  path, poster = self.VVDMup()
  if poster:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = os.path.join(dstPath, os.path.basename(poster))
   if FFqSkC("cp -f '%s' '%s'" % (poster, dstF)):
    FFDeF8(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FFOyl1(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (poster, dstPath), title=title)
  else:
   FFZD7H(self, "No Poster", 1500)
 def VVOq9q(self, isManual=False):
  path, poster = self.VVDMup()
  sDir = FFDpEI(os.path.dirname(path))
  if isManual:
   self.session.openWithCallback(BF(self.VVBraD, sDir, path), BF(CCVnYx, patternMode="poster", VVSMX5=sDir))
  else:
   VVtMHe = []
   for item in [f for f in os.listdir(sDir) if iSearch(r"^.*\.(jpg|png)", f, IGNORECASE)]:
    VVtMHe.append((os.path.basename(item), sDir + item))
   if VVtMHe:
    VVtMHe.sort(key=lambda x: x[0].lower())
    VVBLNR = self.VVptu0
    FFECK9(self, BF(self.VVBraD, sDir, path), VVtMHe=VVtMHe, title="Posters", VVBLNR=VVBLNR, VVNhLF=sDir)
   else:
    FFZD7H(self, "No jpg/png in current dir", 1500)
 def VVptu0(self, VVkbkP, txt, ref, ndx):
  CCXzC3.VVHZ7h(self, VVlNrK=ref)
 def VVBraD(self, sDir, path, pPath=None):
  if pPath:
   newPath = sDir + os.path.splitext(os.path.basename(path))[0] + os.path.splitext(pPath)[1].lower()
   if FFqSkC("cp -f '%s' '%s'" % (pPath, newPath)) or pPath == newPath:
    self.VVcuvv[self.curIndex] = (self.VVcuvv[self.curIndex][0], self.VVcuvv[self.curIndex][1], os.path.basename(newPath))
    FFbA1i(self, self.VVQQTH)
    CCYcxX.VVtuZE(newPath)
   else:
    FFZD7H(self, "Cannot copy file", 1000)
 @staticmethod
 def VVtuZE(path):
  if path.endswith(".png"):
   fileNoExt = path[:-4]
   jpgF = fileNoExt + ".jpg"
   if fileExists(jpgF):
    c = 1
    newF = "%s_%d.jpg" % (fileNoExt, c)
    while fileExists(newF):
     c += 1
     newF = "%s_%d.jpg" % (fileNoExt, c)
    FFqSkC("mv -f '%s' '%s'" % (jpgF, newF))
 @staticmethod
 def VVtnnH(SELF):
  eLst = CCXPWq.VVbz66()["mov"]
  mPath = CFG.MovieDownloadPath.getValue()
  lst = []
  for (Dir, dirs, files) in os.walk(mPath):
   for f in files:
    if os.path.splitext(f)[1].lstrip(".").lower() in eLst:
     path = os.path.join(Dir, f)
     poster = ""
     for ext in ("jpg", "png"):
      pic = "%s.%s" % (os.path.splitext(path)[0], ext)
      if fileExists(pic):
       poster = os.path.basename(pic)
       break
     lst.append((os.path.dirname(path).replace(mPath, ""), os.path.basename(path), poster))
  title = "Movies Browser"
  lst.sort(key=lambda x: x[1].lower())
  if lst: SELF.session.open(CCYcxX, title, lst)
  else  : FFOyl1(SELF, "No movies found in:\n\n%s\n\nYou can change the path from settings." % mPath, title=title)
class CCATv4(Screen, CCIquq):
 def __init__(self, session, bName, lst):
  self.skin, self.skinParam = FFPFsH(VVd75O, 1840, 1040, 50, 3, 3, "#22003344", "#22001122", 45, barHeight=40, topRightBtns=1, vSliderW=20)
  self.session   = session
  self.Title    = bName
  self.VVcuvv    = lst
  self.pPath    = CCuqLp.VVchM7()
  self.totalItems   = 0
  self.isFirstTime  = True
  FFRFZg(self, self.Title)
  FFKdfz(self["keyRed"] , "OK = Zap (Review)")
  FFKdfz(self["keyGreen"] , "Zap & Exit")
  FFKdfz(self["keyYellow"], "Find Current Service")
  CCIquq.__init__(self, 5, 7, CFG.transpColorChannels)
  self["myAction"].actions.update(
  {
   "ok"  : BF(self.VVlFdt, False),
   "cancel" : self.VV2ouQ      ,
   "menu"  : self.VVujM8   ,
   "red"  : self.VV2ouQ      ,
   "green"  : BF(self.VVlFdt, True) ,
   "yellow" : BF(self.VVL7mk, True)  ,
   "0"   : self.VVVNAn
  })
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  if self.isFirstTime:
   force = True
   self.isFirstTime = False
   FFk6h6(self)
   FFFlxX(self)
   FFC3pI(self["keyRed"], "#0a333333")
   self.VVOoGg()
  else:
   pName, srvLst = CCATv4.VVDZhc()
   if srvLst and not srvLst == self.VVcuvv:
    force = True
    self.Title = pName
    self["myTitle"].setText("  %s  " % self.Title)
    self.VVcuvv = srvLst
   else:
    force = False
  self.totalItems = len(self.VVcuvv)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVaG1c(force)
  self.VVL7mk()
 def VVujM8(self):
  VVtMHe = []
  VVtMHe.append(("Find Name (sorted list)" , "findSrt"  ))
  VVtMHe.append(("Find Name (as listed)" , "findNoSrt"))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Change Background Color" , "VVCdm8"))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Help (Keys)", "help"))
  FFECK9(self, self.VVz9SK, title="Options", VVtMHe=VVtMHe)
 def VVz9SK(self, item=None):
  if item:
   if   item == "findSrt"    : self.VVZBIB(True)
   elif item == "findNoSrt"   : self.VVZBIB(False)
   elif item == "VVCdm8": self.VVCdm8()
   elif item == "help"     : FFSnt9(self, "_help_srvcBr", "Services Browser (Keys)")
 def VVZBIB(self, isSort):
  VVtMHe = []
  for ndx, item in enumerate(self.VVcuvv):
   VVtMHe.append((item[1], ndx))
  if isSort:
   VVtMHe.sort(key=lambda x: x[0].lower())
  FFECK9(self, self.VVPQrP, title="Find Name", VVtMHe=VVtMHe, width=1300)
 def VVPQrP(self, ndx=None):
  if ndx is not None:
   self.VVUBc5(ndx)
 def VV2ouQ(self):
  if self.shown: self.close()
  else   : self.show()
 def VVlFdt(self, isExit):
  FFbA1i(self, BF(self.VV2phe, isExit), title="Starting ...")
 def VV2phe(self, isExit):
  try:
   if self.shown:
    FFoYZf(self, self.VVcuvv[self.curIndex][0], VVMFOV=False)
    if isExit: self.close()
    else  : CCuYKB.VVa42W(self.session)
   else:
    self.show()
  except:
   pass
 def VVL7mk(self, VVl1IZ=False):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  err = ""
  if serv:
   curRef = serv.toString()
   for ndx, item in enumerate(self.VVcuvv):
    if curRef == item[0]:
     self.VVUBc5(ndx)
     return ndx
   else:
    err = "Not found"
  else:
   err = "No active service"
  if VVl1IZ and err:
   FFZD7H(self, err, 500)
  return -1
 def VVQQTH(self):
  self.VVCoFp()
  f1, f2 = self.VVaMX8()
  row = col = 0
  noPos = VV2V68 + "noPos.png"
  for ndx in range(f1, f2):
   ref, name = self.VVcuvv[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVKGTb(lbl, name)
   path = CCuqLp.VVVT8Z(self.pPath, ref, name) or noPos
   CCIquq.VVkpor(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVEU69(self):
  ref, name = self.VVcuvv[self.curIndex]
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % ref)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVrsqu():
  refCode = refName = rootRef = rootName = ""
  inBouquet = False
  VVLbeP = InfoBar.instance
  if VVLbeP:
   csel = VVLbeP.servicelist
   if csel:
    currSel  = csel.getCurrentSelection()
    rootRef  = csel.getRoot().toString()
    refCode  = currSel.toString()
    rootName = FFWkWw(rootRef)
    refName  = FFWkWw(refCode)
    inBouquet = csel.inBouquet()
  return refCode, refName, rootRef, rootName, inBouquet
 @staticmethod
 def VVDZhc(refCode="", refName="", rootRef="", rootName="", inBouquet=False):
  refCode, rootRef = refCode.strip(), rootRef.strip()
  if not refCode and not rootRef:
   refCode, refName, rootRef, rootName, inBouquet = CCATv4.VVrsqu()
   refCode, rootRef = refCode.strip(), rootRef.strip()
  pName, srvLst = "", []
  if refCode and rootRef:
   if   refCode.startswith("1:7:") : ref, name = refCode, refName
   elif rootRef.startswith("1:7:") : ref, name = rootRef, rootName
   else       : return "", []
   srvLst = FF6kZn(eServiceReference(ref))
   pName = name or "No-Name"
   if not inBouquet: srvLst.sort(key=lambda x: x[1].lower())
  else:
   srvLst = CCotiQ.VV6s7T()
   pName  = CCotiQ.VVFiWm() or "ALL (Group)"
  return pName, srvLst
 @staticmethod
 def VVNtzG(SELF):
  pName, srvLst = CCATv4.VVDZhc()
  if srvLst: SELF.session.open(CCATv4, pName, srvLst)
  else  : FFOyl1(SELF, "No services found:\n\n%s" % pName, title="Channels Browser")
class CCHdWN(Screen, CCIquq):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFPFsH(VVt7dk, 1600, 1000, 50, 20, 20, "#2200202a", "#2200101a", 45, barHeight=40, topRightBtns=2, vSliderW=20, morePar={"gapX":30, "gapY":30, "mGap":5, "lblC":"#2200101a", "lblTr":1, "picBgTr":1, "cursC":"#00336070"})
  self.session   = session
  self.Title    = title
  self.VVcuvv    = CCHdWN.VVL5tK(lst)
  self.totalItems   = 0
  self.useOrigSize  = False
  FFRFZg(self, self.Title)
  FFKdfz(self["keyRed"] , "OK = Start Plugin")
  FFKdfz(self["keyYellow"], "Package Info.")
  FFKdfz(self["keyBlue"] , "Plugins Group")
  CCIquq.__init__(self, 4, 5, "")
  self["myAction"].actions.update(
  {
   "ok"  : self.VV16dV   ,
   "cancel" : self.VV2ouQ    ,
   "menu"  : self.VVhXJv ,
   "info"  : self.VVXTLh  ,
   "red"  : self.VV2ouQ    ,
   "yellow" : BF(FFbA1i, self, self.VVzxBR),
   "blue"  : self.VViVCo  ,
   "0"   : self.VVVNAn
  })
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFk6h6(self)
  FFFlxX(self)
  FFC3pI(self["keyRed"], "#0a333333")
  self.VVOoGg()
  self.totalItems = len(self.VVcuvv)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVaG1c(True)
 def VV2ouQ(self):
  self.close()
 def VV16dV(self):
  name, desc = self.VVRp4S(self.curIndex)
  if name == PLUGIN_NAME:
   FFZD7H(self, "Already running.", 500)
  else:
   try:
    p = self.VVcuvv[self.curIndex]
    p(session=self.session)
   except:
    FFOyl1(self, "Cannot start from here !", title="Error in : %s" % name)
 def VVXTLh(self):
  def VVYgG4(key, val):
   return key + "\t: " + str(val) + "\n"
  p = self.VVcuvv[self.curIndex]
  txt = ""
  try:
   txt += VVYgG4("Path"  , p.path  )
   txt += VVYgG4("Description" , p.description )
   txt += VVYgG4("Icon"  , p.iconstr  )
   txt += VVYgG4("Wakeup Fnc" , p.wakeupfnc )
   txt += VVYgG4("NeedsRestart", p.needsRestart)
   txt += VVYgG4("Internal" , p.internal )
   txt += VVYgG4("Weight"  , p.weight  )
  except:
   pass
  name, desc = self.VVRp4S(self.curIndex)
  if txt : FFoB4k(self, txt, title=name)
  else : FFOyl1(self, "Could not read plugin info.", title=name)
 def VVzxBR(self):
  p = self.VVcuvv[self.curIndex]
  name, desc = self.VVRp4S(self.curIndex)
  path = p.path
  pkg, err = CCmJHl.VVl9hd(path)
  if pkg : CCmJHl.VVYBTJ(self, pkg, name)
  else : FFZbFo(self, err, 1000)
 def VVhXJv(self):
  path = self.VVcuvv[self.curIndex].path
  VVtMHe = []
  txt = "Open Plugin Path in File Manager"
  VVtMHe.append(FFQlwu("Open Plugin Path in File Manager", "inFileMan", pathExists(path)))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Use Original Icon Size", "setOrigSize"))
  FFECK9(self, self.VVfGiD, title="Plugins Group", VVtMHe=VVtMHe)
 def VVfGiD(self, item=None):
  if item:
   if item == "inFileMan":
    self.session.open(CCVnYx, mode=CCVnYx.VVHgbC, VVSMX5=self.VVcuvv[self.curIndex].path)
   elif item == "setOrigSize":
    self.useOrigSize = True
    self.VVaG1c(True)
 def VViVCo(self):
  FFECK9(self, self.VVdD1i, title="Plugins Group", VVtMHe=CCHdWN.VVGzst(True, True), width=700, VVIZXB=True)
 def VVdD1i(self, item=None):
  if item:
   title, where, ndx = item
   self["myTitle"].setText("  %s (%s)" % (self.Title, title))
   lst = CCHdWN.VV72qi(where)
   if lst:
    self.VVcuvv = CCHdWN.VVL5tK(lst)
    self.curPage = self.curCol = self.curRow = self.curIndex = 0
    self.totalItems = len(self.VVcuvv)
    self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
    self.VVaG1c(True)
   else:
    FFOyl1(self, "Not found !", title=self.Title)
 def VVQQTH(self):
  self.VVCoFp()
  f1, f2 = self.VVaMX8()
  row = col = 0
  for ndx in range(f1, f2):
   name, desc = self.VVRp4S(ndx)
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVKGTb(lbl, name)
   iconOk = False
   pngSz = None
   if self.VVcuvv[ndx].icon:
    try:
     pngSz = self.VVcuvv[ndx].icon.size()
     pic.instance.setScale(1)
     pic.instance.setPixmap(self.VVcuvv[ndx].icon)
     pic.show()
     iconOk = True
    except:
     pass
   if not iconOk:
    icons = []
    path = self.VVcuvv[ndx].path
    if pathExists(path):
     for f in ("iconfhd.png", "iconhd.png", "icon.png"):
      icons.append(os.path.join(path, f))
    icons.append(resolveFilename(SCOPE_CURRENT_SKIN, "icons/plugin.png"))
    icons.append(VV2V68 + "plugin.png")
    for path in icons:
     pixMap = CCIquq.VVkpor(pic, path)
     if pixMap:
      pngSz = pixMap.size()
      break
   if self.useOrigSize and pngSz:
    try:
     boxSz = pic.instance.size()
     picPos = pic.instance.position()
     pngW, pngH = pngSz.width(), pngSz.height()
     boxW, boxH = boxSz.width(), boxSz.height()
     if boxW > pngW and boxH > pngH:
      pic.instance.resize(pngSz)
      pic.instance.move(ePoint(picPos.x() + (boxW - pngW) // 2, picPos.y() + (boxH - pngH) // 2))
    except:
     pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVRp4S(self, ndx):
  name = str(self.VVcuvv[ndx].name).strip()
  desc = str(self.VVcuvv[ndx].description).strip().replace("\n", " >> ")
  if not name or name == "Plugin":
   name = desc or FFd4tO(self.VVcuvv[ndx].path)
  return name, desc
 def VVEU69(self):
  name, desc = self.VVRp4S(self.curIndex)
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % desc)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVGzst(isMenu=False, addTot=False):
  lst =[("Plugin Menu"   , PluginDescriptor.WHERE_PLUGINMENU    )
   , ("Audio Menu"    , PluginDescriptor.WHERE_AUDIOMENU    )
   , ("Auto-Start Menu"  , PluginDescriptor.WHERE_AUTOSTART    )
   , ("Channel Context Menu" , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU )
   , ("Event Info"    , PluginDescriptor.WHERE_EVENTINFO    )
   , ("Extensions Menu"  , PluginDescriptor.WHERE_EXTENSIONSMENU   )
   , ("File Scan"    , PluginDescriptor.WHERE_FILESCAN    )
   , ("Main Menu"    , PluginDescriptor.WHERE_MAINMENU    )
   , ("Menu"     , PluginDescriptor.WHERE_MENU     )
   , ("Movie List"    , PluginDescriptor.WHERE_MOVIELIST    )
   , ("Network Configuration" , PluginDescriptor.WHERE_NETWORKCONFIG_READ  )
   , ("Network Setup"   , PluginDescriptor.WHERE_NETWORKSETUP   )
   , ("Session Start"   , PluginDescriptor.WHERE_SESSIONSTART   )
   , ("Software Manager"  , PluginDescriptor.WHERE_SOFTWAREMANAGER  )
   , ("Teletext"    , PluginDescriptor.WHERE_TELETEXT    )
   , ("Wizard"     , PluginDescriptor.WHERE_WIZARD     )]
  if addTot:
   for ndx, item in enumerate(lst):
    tot = len(CCHdWN.VV72qi(item[1]))
    lst[ndx] = ("%s   %s(%d)" % (lst[ndx][0], VVD4un, tot), lst[ndx][1])
  if isMenu: lst.insert(1, VVXGzj)
  else  : lst.sort(key=lambda x: x[0].lower())
  return lst
 @staticmethod
 def VV72qi(where):
  try: return iPlugins.getPlugins(where)
  except: return []
 @staticmethod
 def VVL5tK(lst):
  tmp = []
  for item in lst:
   name = str(item.name).strip()
   if not name or name == "Plugin":
    name = str(item.description).strip() or FFd4tO(item.path)
   tmp.append((name, item))
  tmp.sort(key=lambda x: x[0].lower())
  lst = []
  for nm, obj in tmp:
   lst.append(obj)
  return lst
 @staticmethod
 def VVi3xt(SELF):
  title = "Plugins Browser"
  lst = CCHdWN.VV72qi(PluginDescriptor.WHERE_PLUGINMENU)
  if lst : SELF.session.open(CCHdWN, title, lst)
  else : FFOyl1(SELF, "No plugins found !", title=title)
class CCyzbt(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", isFind=False):
  self.skin, self.skinParam = FFPFsH(VVMjBN, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.isFindMode     = isFind
  self.VVzoBE  = 0
  self.VV5qtE = 1
  self.VVF71c  = 2
  VVtMHe = []
  VVtMHe.append(("Find in All Service (from filter)" , "VVOmmC" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Find in All (Manual Entry)"   , "VVHjic"    ))
  VVtMHe.append(("Find in TV"       , "VV7N6K"    ))
  VVtMHe.append(("Find in Radio"      , "VV9Ylx"   ))
  if self.VVRR1Y():
   VVtMHe.append(VVXGzj)
   VVtMHe.append(("Hide Channel: %s" % self.servName , "VVJS8r"   ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Zap History"       , "VV25du"    ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("IPTV Tools"       , "iptv"      ))
  VVtMHe.append(("PIcons Tools"       , "PIconsTools"     ))
  VVtMHe.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  VVtMHe.append(("EPG Tools"       , "epgTools"     ))
  FFRFZg(self, VVtMHe=VVtMHe, title=title)
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFWIRJ(self["myMenu"])
  FFJI0m(self)
  if self.isFindMode:
   self.VVJ00d(self.VVbIkC())
 def VV2Iyl(self):
  global VVsQSL
  VVsQSL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVHjic"    : self.VVHjic()
   elif item == "VVOmmC" : self.VVOmmC()
   elif item == "VV7N6K"    : self.VV7N6K()
   elif item == "VV9Ylx"   : self.VV9Ylx()
   elif item == "VVJS8r"   : self.VVJS8r()
   elif item == "VV25du"    : self.VV25du()
   elif item == "iptv"       : self.session.open(CCoUhv)
   elif item == "PIconsTools"     : self.session.open(CCuqLp)
   elif item == "ChannelsTools"    : self.session.open(CCwuBY)
   elif item == "epgTools"      : self.session.open(CCfTje)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VV7N6K(self) : self.VVJ00d(self.VVzoBE)
 def VV9Ylx(self) : self.VVJ00d(self.VV5qtE)
 def VVHjic(self) : self.VVJ00d(self.VVF71c)
 def VVJ00d(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFdnKb(self, BF(self.VVEAx8, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VVOmmC(self):
  filterObj = CC6kzI(self)
  filterObj.VVZBdt(self.VV22wO)
 def VV22wO(self, item):
  self.VVEAx8(self.VVF71c, item)
 def VVRR1Y(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFueFC(self.refCode)        : return False
  return True
 def VVEAx8(self, mode, VV5ieK):
  FFbA1i(self, BF(self.VVyZ5G, mode, VV5ieK), title="Searching ...")
 def VVyZ5G(self, mode, VV5ieK):
  if VV5ieK:
   VV5ieK = VV5ieK.strip()
  if VV5ieK:
   self.findTxt = VV5ieK
   CFG.lastFindContextFind.setValue(VV5ieK)
   if   mode == self.VVzoBE  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VV5qtE : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VV5ieK)
   if len(title) > 55:
    title = title[:55] + ".."
   VVsLLE = self.VVRWqW(VV5ieK, servTypes)
   if self.isFindMode or mode == self.VVF71c:
    VVsLLE += self.VVgI2G(VV5ieK)
   if VVsLLE:
    VVsLLE.sort(key=lambda x: x[0].lower())
    VVJi29 = self.VViLjT
    VVMWQK  = ("Zap"   , self.VVsSTm    , [])
    VV1kWx = ("Current Service", self.VVZbGf , [])
    VVM9Pm = ("Options"  , self.VVZ06z , [])
    VVZArZ = (""    , self.VV2Ziu , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VV0CnX  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFDpub(self, None, title=title, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=26, VVMWQK=VVMWQK, VVJi29=VVJi29, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, VVZArZ=VVZArZ, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVJ00d(self.VVbIkC())
    FFDeF8(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVRWqW(self, VV5ieK, servTypes):
  VVcuvv = CCwuBY.VVPwKw(servTypes)
  VVsLLE = []
  if VVcuvv:
   VVJwMZ, VVFf41 = FFAND4()
   tp = CCMbXb()
   words, asPrefix = CC6kzI.VVV2i7(VV5ieK)
   colorYellow  = CCtoHe.VVsjz9(VVXAXH)
   colorWhite  = CCtoHe.VVsjz9(VV7V3G)
   for s in VVcuvv:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFbQ09(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVJwMZ:
        STYPE = VVFf41[sTypeInt]
       freq, pol, fec, sr, syst = tp.VV1FtS(refCode)
       if not "-S" in syst:
        sat = syst
       VVsLLE.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVsLLE
 def VVgI2G(self, VV5ieK):
  VV5ieK = VV5ieK.lower()
  VVsLLE = []
  colorYellow  = CCtoHe.VVsjz9(VVXAXH)
  colorWhite  = CCtoHe.VVsjz9(VV7V3G)
  for b in CCotiQ.VV1U2X():
   VVFLv8  = b[0]
   VVqCDa  = b[1].toString()
   VV73fw = eServiceReference(VVqCDa)
   VVXNdR = FF6kZn(VV73fw)
   for service in VVXNdR:
    refCode  = service[0]
    if FFueFC(refCode):
     servName = service[1]
     if VV5ieK in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VV5ieK), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVsLLE.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVsLLE
 def VVbIkC(self):
  mode = CCQIeq.VVIWfk(default=-1)
  return self.VVF71c if mode == -1 else mode
 def VViLjT(self, VVdesl):
  self.close()
  VVdesl.cancel()
 def VVsSTm(self, VVdesl, title, txt, colList):
  FFoYZf(VVdesl, colList[2], VVMFOV=False, checkParentalControl=True)
 def VVZbGf(self, VVdesl, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(VVdesl)
  if refCode:
   VVdesl.VVaQuz(2, FFhk4f(refCode, iptvRef, chName), True)
 def VVZ06z(self, VVdesl, title, txt, colList):
  servName = colList[0]
  mSel = CCB2u5(self, VVdesl)
  VVtMHe, cbFncDict = CCwuBY.VVGFHF(self, VVdesl, servName, 2)
  mSel.VVcQQV(VVtMHe, cbFncDict)
 def VV2Ziu(self, VVdesl, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FF1wB7(self, fncMode=CCqIel.VVk0Au, refCode=refCode, chName=chName, text=txt)
 def VVJS8r(self):
  FFgBNQ(self, self.VVzH93, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVzH93(self):
  ret = FFbQCc(self.refCode, True)
  if ret:
   self.VVrbih()
   self.close()
  else:
   FFZD7H(self, "Cannot change state" , 1000)
 def VVrbih(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVXmfv()
  except:
   self.VVGQti()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFZZBl(self, serviceRef)
 def VVXmfv(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVLbeP = InfoBar.instance
   if VVLbeP:
    VVIh3I = VVLbeP.servicelist
    if VVIh3I:
     hList = VVIh3I.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVIh3I.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVIh3I.history  = newList
       VVIh3I.history_pos = pos
 def VVGQti(self):
  VVLbeP = InfoBar.instance
  if VVLbeP:
   VVIh3I = VVLbeP.servicelist
   if VVIh3I:
    VVIh3I.history  = []
    VVIh3I.history_pos = 0
 def VV25du(self):
  VVLbeP = InfoBar.instance
  VVsLLE = []
  if VVLbeP:
   VVIh3I = VVLbeP.servicelist
   if VVIh3I:
    VVJwMZ, VVFf41 = FFAND4()
    for serv in VVIh3I.history:
     refCode = serv[-1].toString()
     chName = FFWkWw(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FFueFC(refCode)
     isSRel = FF81BD(refCode)
     sat = "-" if isIptv and not isSRel or isLocal else FFbQ09(refCode, True)
     if isIptv : STYPE = "Stream Relay" if isSRel else "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVJwMZ:
       STYPE = VVFf41[sTypeInt]
     VVsLLE.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVsLLE:
   VVMWQK  = ("Zap"   , self.VVVGjW   , [])
   VVM9Pm = ("Clear History" , self.VVAIvN   , [])
   VVZArZ = (""    , self.VVUr98 , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VV0CnX  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFDpub(self, None, title=title, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=28, VVMWQK=VVMWQK, VVM9Pm=VVM9Pm, VVZArZ=VVZArZ)
  else:
   FFDeF8(self, "History is empty.", title=title)
 def VVVGjW(self, VVdesl, title, txt, colList):
  FFoYZf(VVdesl, colList[3], VVMFOV=False, checkParentalControl=True)
 def VVAIvN(self, VVdesl, title, txt, colList):
  FFgBNQ(self, BF(self.VVgEdQ, VVdesl), "Clear Zap History ?")
 def VVgEdQ(self, VVdesl):
  self.VVGQti()
  VVdesl.cancel()
 def VVUr98(self, VVdesl, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FF1wB7(self, fncMode=CCqIel.VVA0Zm, refCode=refCode, chName=chName, text=txt)
 @staticmethod
 def VVxCdL():
  try:
   global VVjWqK
   if VVjWqK is None:
    VVjWqK    = ChannelContextMenu.__init__
   ChannelContextMenu.__init__   = CCyzbt.VVNXOi
   ChannelContextMenu.VVwdWc = CCyzbt.VVwdWc
  except:
   pass
 @staticmethod
 def VVNXOi(SELF, session, csel):
  from Components.ChoiceList import ChoiceEntryComponent
  VVjWqK(SELF, session, csel)
  if CFG.showInChannelListMenu.getValue():
   for ndx, title in enumerate(("Channels Browser", "Find", "Bouquet Editor", "Channels Tools")):
    title = "%s - %s" % (PLUGIN_NAME, title)
    SELF["menu"].list.insert(ndx, ChoiceEntryComponent(key=" ", text=(title , BF(SELF.VVwdWc, csel, ndx, title))))
 @staticmethod
 def VVwdWc(SELF, csel, mode, title):
  try:
   currSel  = csel.getCurrentSelection()
   refCode  = currSel.toString()
   refName  = FFWkWw(refCode)
  except:
   refCode = refName = ""
  if   mode == 0: CCATv4.VVNtzG(SELF)
  elif mode == 2: SELF.session.open(CCQIeq)
  else    : SELF.session.open(CCyzbt, title=title, csel=csel, refCode=refCode, servName=refName, isFind=True if mode == 1 else False)
  SELF.close()
class CCQIeq(Screen):
 def __init__(self, session, refCode="", servName=""):
  self.skin, self.skinParam = FFPFsH(VVwhxs, 10, 10, 30, 0, 0, "#ff000000", "#ff000000", 30)
  self.session = session
  self.Title  = "Bouquet Editor"
  self.pPath  = CCuqLp.VVchM7()
  self.bTables = []
  FFRFZg(self)
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  self.VVVoVc()
 def VVUKSz(self, tbl, bName, bRef):
  self.bTables.append(tbl)
  tbl.bouqName = bName
  tbl.bouqRef  = bRef
 def VVVoVc(self):
  rootStr = CCQIeq.VVAXur()
  rows = self.VVHsnO(rootStr)
  if rows :
   self.VVTFAL(self, "Main Bouquets List", rootStr, rows)
   refCode, refName, rootRef, rootName, inBouquet = CCATv4.VVrsqu()
   if not self.bTables[-1].VVQMdW({3:refCode}):
    self.bTables[-1].VVQMdW({3:rootRef})
  else:
   FFOyl1(self, "No bouquets Found !", title=self.Title)
   self.close()
 def VVVxcG(self):
  self.bTables[-1].cancel()
  if len(self.bTables) > 0: del self.bTables[-1]
  if not len(self.bTables): self.close()
 def VVHsnO(self, bRef=None):
  blkLst = CCQIeq.VV4BXG()
  rows = []
  for ndx, row in enumerate(FF6kZn(eServiceReference(bRef), mode=1), start=1):
   ref, name, flags = row
   fTxt, fColor = CCQIeq.VVg2Gx(flags)
   lck = "1" if CCQIeq.VVvipS(ref, blkLst) > -1 else ""
   rows.append((str(ndx), "", fColor + name, ref, fTxt, str(flags), lck))
  return rows
 def VVTFAL(self, selfObj, bName, bRef, rows):
  totTbl = len(self.bTables)
  title = {0:"Main Bouquets List", 1:"%s %s" % (FF8oA9("Fav: ", VVD4un), bName), 2:"%s %s" % (FF8oA9("Sub: ", VVD4un), bName)}.get(totTbl, bName)
  bg  = {0:"#11002233", 1:"#0a112222"}.get(totTbl, "#0a131111")
  VVJi29 = self.VVvcGw
  VVZArZ = (""    , self.VVd06Z  , [])
  VVMWQK  = ("Enter Bouquet" , self.VVvTGt , [])
  VVIzUv = ("Delete"   , self.VV5LLz , [])
  VVM9Pm = ("Options"  , self.VVMu1L , [])
  VVRHhw = ("Move Here"  , self.VVnuyP , [])
  picParams  = (1, self.VVN9gF, None)
  widths  = (12   , 7   , 81 , 0  , 0   , 0   , 0   )
  VV0CnX = (CENTER  , CENTER , LEFT , LEFT , LEFT  , CENTER , CENTER )
  tbl = FFDpub(self, None, title=title, VVcuvv=rows, VV0CnX=VV0CnX, width=1500, height=1000, VVbG6j=widths, VVGNdU=28, addSort=False, VVZArZ=VVZArZ, VVMWQK=VVMWQK, VVJi29=VVJi29, VVIzUv=VVIzUv, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw, VVEMdg=True, searchCol=1, picParams=picParams, lastFindConfigObj=CFG.lastFindServices
     , VVaRsg=bg, VVWgai=bg, VVSJJk=bg, VVYCZ6="#0a442200", borderWidth=0, VVIyj7="#11330000")
  tbl.VVLS8Z(BF(self.VVE7VD, tbl), True)
  self.VVUKSz(tbl, bName, bRef)
 def VV8oXD(self, VVdesl, mutableList, tot, jumpDict=None):
  if tot:
   if mutableList:
    mutableList.flushChanges()
   FFjaui()
   rows = self.VVHsnO(VVdesl.bouqRef)
   if rows:
    VVdesl.VVrFVf(False)
    VVdesl.VV87pY(rows, VVZoVsMsg=True, isSort=False, tableRefreshCB=BF(self.VVuyCy, jumpDict))
   else:
    self.VVVxcG()
    totTbl = len(self.bTables)
    FFZD7H(self.bTables[-1] if totTbl > 0 else self, "Empty List !", 1500)
  else:
   FFZbFo(VVdesl, "No change !", 1500)
 def VVuyCy(self, jumpDict, VVdesl, title, txt, colList):
  if jumpDict:
   VVdesl.VVQMdW(jumpDict)
 def VVE7VD(self, VVdesl):
  VVdesl["keyRed"].hide()
  VVdesl["keyBlue"].hide()
  if VVdesl.VVcTnU:
   if VVdesl.VVLHWg() > 0:
    VVdesl["keyRed"].show()
    VVdesl["keyBlue"].show()
  else:
   VVdesl["keyRed"].show()
 def VVd06Z(self, VVdesl, title, txt, colList):
  c1, c2, c3 = VVXAXH, VVoIYV, VV8ETX
  ttl = lambda x, y, color=c1: "%s:\n%s\n\n" % (FF8oA9(x, color), y) if y else ""
  num, picon, name, ref, rem, flags, lck = colList
  path = CCQIeq.VVQ4aW(ref, mode=1)
  txt  = ttl("Name"    , name)
  txt += ttl("Bouquet File"  , path if path.startswith("/") else "")
  txt += ttl("Parent Bouquet"  , VVdesl.bouqName, c2)
  txt += ttl("Parent Bouquet File", CCQIeq.VVQ4aW(VVdesl.bouqRef, mode=1), c2)
  txt += ttl("Ref."    , ref, c3) if VVXYuQ else ""
  txt += ttl("Remarks"   , rem, c3) if VVXYuQ else ""
  path = CCuqLp.VVVT8Z(self.pPath, ref, name)
  FF1wB7(self, fncMode=CCqIel.EPG_MODE_BOUQUET_EDITOR, text=txt, picPath=path)
 def VVvTGt(self, VVdesl, title, txt, colList):
  FFbA1i(VVdesl, BF(self.VVAvbu, VVdesl, colList) )
 def VVAvbu(self, VVdesl, colList):
  maxLev = 2
  num, picon, name, ref, rem, flags, lck = colList
  if "FROM BOUQUET " in ref:
   if len(self.bTables) <= maxLev:
    rows = self.VVHsnO(ref)
    if rows : self.VVTFAL(VVdesl, name, ref, rows)
    else : FFZbFo(VVdesl, "Empty list !", 1500)
   else:
    FFOyl1(self, "Maximum Level of Recursive Bouquets (%d) !" % maxLev, title=self.Title)
  elif CCQIeq.VVOhxA(ref) == 0:
   FFoYZf(self, ref, VVMFOV=False)
   FFYzpl(self, "Cancel to go back to table")
  else:
   FFZD7H(VVdesl, "No action", 300)
 def VVvcGw(self, VVdesl):
  if VVdesl.VVcTnU:
   VVdesl.VVrFVf(False)
   self.VVE7VD(VVdesl)
  else:
   self.VVVxcG()
 def VVMu1L(self, VVdesl, title, txt, colList):
  VVtMHe = []
  iMulSel = VVdesl.VVs9jW()
  sortItem = ("Sort", )
  if iMulSel:
   tot = VVdesl.VVLHWg()
   if tot > 1: sortItem = ("Sort", "sort")
   isSel = tot > 0
   bTxt = "Bouquet%s" % FFsfSO(tot)
  else:
   isSel = True
   bTxt = "Bouquet"
  inMain = len(self.bTables) == 1
  VVtMHe.append(FFQlwu("Rename"   , "renm" , not iMulSel))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(FFQlwu("Add Marker"  , "mrkr" , not iMulSel))
  VVtMHe.append(FFQlwu("Add Empty Bouquet", "addBouq" , not iMulSel and inMain))
  if inMain:
   VVtMHe.append(VVXGzj)
   VVtMHe.append(FFQlwu("Hide %s" % bTxt , "hidOn" , isSel))
   VVtMHe.append(FFQlwu("Unhide %s" % bTxt , "hidOff" , isSel))
   VVtMHe.append(VVXGzj)
   VVtMHe.append(FFQlwu("Protect %s" % bTxt , "lckOn" , isSel))
   VVtMHe.append(FFQlwu("Unprotect %s" % bTxt , "lckOff" , isSel))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(sortItem)
  VVtMHe.append(FFQlwu("Copy to Bouquet" , "toBouq" , isSel))
  cbFncDict = { "renm" : BF(self.VVQcO5  , VVdesl)
     , "mrkr" : BF(self.VVRvXH , VVdesl)
     , "addBouq" : BF(self.VVnlqN, VVdesl)
     , "hidOn" : BF(self.VVloVb  , VVdesl, True)
     , "hidOff" : BF(self.VVloVb  , VVdesl, False)
     , "lckOn" : BF(self.VVsUOw  , VVdesl, True)
     , "lckOff" : BF(self.VVsUOw  , VVdesl, False)
     , "sort" : BF(self.VVtxE2  , VVdesl)
     , "toBouq" : BF(self.VVAANb , VVdesl) }
  fnc = BF(self.VVE7VD, VVdesl)
  mSel = CCB2u5(self, VVdesl)
  mSel.VVcQQV(VVtMHe, cbFncDict, okFnc=fnc, onMultiSelFnc=fnc)
 def VV5LLz(self, VVdesl, title, txt, colList):
  txt, totSel = "", 0
  if VVdesl.VVs9jW():
   totSel = VVdesl.VVLHWg()
   if totSel:
    txt = "Delete %s item%s" % (FF8oA9(str(totSel), VVXAXH), FFsfSO(totSel))
  else:
   num, picon, name, ref, rem, flags, lck = colList
   txt = "Delete : %s" % FF8oA9(name, VVXAXH)
  if txt:
   FFgBNQ(self, BF(self.VVKmZF, VVdesl), "%s\n\nContinue ?" % txt, title=self.Title)
 def VVKmZF(self, VVdesl):
  FFbA1i(VVdesl, BF(self.VV9fEu, VVdesl))
 def VV9fEu(self, VVdesl):
  lst, mutableList, csel, bServ = self.VVGKFx(VVdesl)
  if mutableList is not None:
   tot = 0
   for ref in lst:
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.removeService(serv):
     tot += 1
     bFile = CCotiQ.VVaqE5(ref)
     if "userSubBouquet" in bFile:
      bFile = VVKJQA + bFile
      FFqSkC("rm -f '%s' '%s.del'" % (bFile, bFile))
   self.VV8oXD(VVdesl, mutableList, tot)
 def VVnuyP(self, VVdesl, title, txt, colList):
  FFbA1i(VVdesl, BF(self.VV4UOp, VVdesl))
 def VV4UOp(self, VVdesl):
  lst, mutableList, csel, bServ = self.VVGKFx(VVdesl)
  if mutableList is not None:
   curNdx = VVdesl.VVvapY()
   if curNdx <= VVdesl.VVP9ZS(): lst = reversed(lst)
   else             : curNdx -= 1
   tot = 0
   for ref in lst:
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.moveService(serv, curNdx):
     tot += 1
   self.VV8oXD(VVdesl, mutableList, tot)
 def VVtxE2(self, VVdesl):
  FFbA1i(VVdesl, BF(self.VVVxpd, VVdesl))
 def VVVxpd(self, VVdesl):
  lst, mutableList, csel, bServ = self.VVGKFx(VVdesl)
  if mutableList is not None:
   nmlst = VVdesl.VVLRcj(2)
   lst = list(zip(nmlst, lst))
   lst.sort(key=lambda x: x[0].lower())
   curNdx = VVdesl.VVP9ZS()
   tot = 0
   for name, ref in reversed(lst):
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.moveService(serv, curNdx):
     tot += 1
   self.VV8oXD(VVdesl, mutableList, tot)
 def VVQcO5(self, VVdesl, item=None):
  name = VVdesl.VV1blE()[2]
  FFdnKb(self, BF(self.VVZFTB, VVdesl), defaultText=name, title="Rename", message="Enter new name")
 def VVZFTB(self, VVdesl, name):
  lst, mutableList, csel, bServ = self.VVGKFx(VVdesl)
  if name and csel and mutableList:
   name = name.strip()
   if name:
    ref = VVdesl.VV1blE()[3]
    if "FROM BOUQUET " in ref:
     CCotiQ.VVQGdj(ref, name)
    else:
     serv = eServiceReference(ref)
     if serv.valid():
      serv.setName(name)
      mutableList.removeService(serv)
      mutableList.addService(serv)
      mutableList.moveService(serv, VVdesl.VVvapY())
    self.VV8oXD(VVdesl, mutableList, 1)
 def VVRvXH(self, VVdesl):
  name = "%s Marker %s" % ("=" * 7, "=" * 7)
  FFbA1i(VVdesl, BF(self.VVTLiL, VVdesl, name))
 def VVTLiL(self, VVdesl, name):
  lst, mutableList, csel, bServ = self.VVGKFx(VVdesl)
  if mutableList is not None:
   curServ = eServiceReference(VVdesl.VV1blE()[3])
   cnt = tot = 0
   while mutableList:
    serv = eServiceReference("1:64:%d:0:0:0:0:0:0:0::%s" % (cnt, name))
    if curServ and curServ.valid():
     if not mutableList.addService(serv, curServ):
      csel.servicelist.addService(serv, True)
      tot += 1
      break
    elif not mutableList.addService(serv):
     csel.servicelist.addService(serv, True)
     tot += 1
     break
    cnt += 1
   self.VV8oXD(VVdesl, mutableList, tot)
 def VVnlqN(self, VVdesl):
  names = VVdesl.VVdWFX(2)
  name = "Bouquet-1"
  num = 0
  while name in names:
   num += 1
   name = "Bouquet-%s" % num
  FFdnKb(self, BF(self.VVWkbV, VVdesl), defaultText=name, title="New Bouquet", message="Enter Bouquet name")
 def VVWkbV(self, VVdesl, name=None):
  if name and name.strip():
   FFbA1i(VVdesl, BF(self.VVXe4d, VVdesl, name.strip()))
 def VVXe4d(self, VVdesl, bName):
  CCotiQ.VVESJ4(bName)
  self.VV8oXD(VVdesl, None, 1, jumpDict={2:bName})
 def VVAANb(self, VVdesl):
  bRows = CCotiQ.VVkd0a()
  if VVdesl.VVcTnU : lst = VVdesl.VVLRcj(3)
  else        : lst = [VVdesl.VV1blE()[3]]
  VVtMHe = []
  for name, ref in bRows:
   if not ref in lst:
    VVtMHe.append((name, ref))
  if VVtMHe : FFECK9(self,  BF(self.VV8cAs, VVdesl), VVtMHe=VVtMHe, width=1100, height=900, VVaRsg="#22220000", VVWgai="#22110000", title="Destination Bouquet", VVIZXB=True)
  else  : FFZD7H(VVdesl, "No bouquets left !", 1000)
 def VV8cAs(self, VVdesl, item=None):
  if item:
   bName, bRef, ndx = item
   FFbA1i(VVdesl, BF(self.VVqEmg, VVdesl, bName, bRef))
 def VVqEmg(self, VVdesl, bName, bRef):
  if VVdesl.VVcTnU : lst = VVdesl.VVLRcj(3)
  else        : lst = [VVdesl.VV1blE()[3]]
  dstFile = CCotiQ.VVaqE5(bRef)
  tot = 0
  for ref in lst:
   ok = CCotiQ.VVpP52(ref, dstFile)
   if ok:
    tot += 1
  self.VV8oXD(VVdesl, None, tot)
  ttl = lambda x, y: "%s:\n%s\n\n" % (FF8oA9(x, VVRuOi), y)
  txt  = ttl("Source Bouquet"  , VVdesl.bouqName)
  txt += ttl("Destination Bouquet", bName)
  txt += ttl("Copied Services" , tot)
  FFoB4k(VVdesl, txt, title="Copy Services")
 def VVloVb(self, VVdesl, isHide):
  FFbA1i(VVdesl, BF(self.VVqRwM, VVdesl, isHide))
 def VVqRwM(self, VVdesl, isHide):
  lst, mutableList, csel, bServ = self.VVGKFx(VVdesl)
  mode = CCQIeq.VVIWfk()
  path = VVKJQA + "bouquets.%s" % ("tv" if mode==0 else "radio")
  if fileExists(path):
   tot = 0
   lines = list(map(str.strip, FF72md(path)))
   for ref in lst:
    if "FROM BOUQUET " in ref:
     ref = "#SERVICE " + ref
     nrm = ref.replace("1:519:", "1:7:")
     hid = ref.replace("1:7:"  , "1:519:")
     if isHide: r1, r2 = nrm, hid
     else  : r1, r2 = hid, nrm
     if r1 in lines:
      ndx = lines.index(r1)
      lines[ndx] = r2
      tot += 1
   if tot:
    with open(path, "w") as f:
     for line in lines:
      f.write("%s\n" % line)
    self.VV8oXD(VVdesl, None, tot)
 def VVsUOw(self, VVdesl, isLck):
  FFbA1i(VVdesl, BF(self.VVMdcL, VVdesl, isLck))
 def VVMdcL(self, VVdesl, isLck):
  lst, mutableList, csel, bServ = self.VVGKFx(VVdesl)
  blkLst = CCQIeq.VV4BXG()
  tot = 0
  for ref in lst:
   if "FROM BOUQUET " in ref:
    ndx = CCQIeq.VVvipS(ref, blkLst)
    if isLck:
     if ndx == -1:
      ref = ref.replace("1:519:", "1:0:").replace("1:7:", "1:0:")
      blkLst.append(ref)
      tot += 1
    else:
     if ndx > -1:
      blkLst[ndx] = ""
      tot += 1
  if tot:
   with open(VVmldL, "w") as f:
    for line in blkLst:
     if line.strip():
      f.write("%s\n" % line)
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   self.VV8oXD(VVdesl, None, tot)
 def VVGKFx(self, VVdesl, bServ=None):
  if VVdesl.VVcTnU : lst = VVdesl.VVLRcj(3)
  else        : lst = [VVdesl.VV1blE()[3]]
  mutableList = csel = None
  VVLbeP = InfoBar.instance
  if VVLbeP:
   csel = VVLbeP.servicelist
   if csel:
    if not bServ:
     bServ = eServiceReference(VVdesl.bouqRef)
    if bServ.valid():
     mutableList = csel.getMutableList(bServ)
  return lst,  mutableList, csel, bServ
 def VVN9gF(self, colList):
  num, picon, name, ref, rem, flags, lck = colList
  png = lambda x: "%s%s.png" % (VV2V68, x)
  if   rem == "Marker"   : return png("mrk1")
  elif rem == "Numbered Marker" : return png("mrk2")
  elif rem == "Group"    : return png("grp")
  elif "FROM BOUQUET " in ref:
   if   lck == "1" and rem == "Invisible" : return png("dirLckInvis")
   elif lck == "1"       : return png("dirLck")
   elif rem == "Invisible"     : return png("dirInvis")
   else         : return png("dir1")
  else:
   return CCuqLp.VVVT8Z(self.pPath, ref, name)
 @staticmethod
 def VVg2Gx(flag):
  t = c = ""
  try:
   if   flag & eServiceReference.isInvisible  : t, c = "Invisible"  , "#f#00ff7722#"
   elif flag & eServiceReference.isNumberedMarker : t, c = "Numbered Marker" , "#f#00ffffaa#"
   elif flag & eServiceReference.isGroup   : t, c = "Group"   , "#f#00bbffbb#"
   elif flag & eServiceReference.isMarker   : t, c = "Marker"   , "#f#00ffffaa#"
   elif flag & eServiceReference.isDirectory  : t, c = "Directory"  , ""
  except:
   pass
  return t, c
 @staticmethod
 def VVQ4aW(ref, mode=0):
  path = ""
  serv = eServiceReference(ref)
  if serv.valid():
   path = serv.getPath()
   if path and not VVXYuQ:
    path = iSub(r"[&?]mode=.+end=", r"", path, flags=IGNORECASE)
   if mode == 1:
    span = iSearch(r'FROM\s+BOUQUET\s+"(.+)"\s+ORDER\s+BY\s+bouquet', path, IGNORECASE)
    if span:
     path = VVKJQA + span.group(1)
  return path
 @staticmethod
 def VVOhxA(ref):
  path = ""
  serv = eServiceReference(ref)
  if serv.valid():
   return serv.flags
  return -1
 @staticmethod
 def VVIWfk(default=0):
  VVLbeP = InfoBar.instance
  if VVLbeP:
   csel = VVLbeP.servicelist
   if csel:
    return csel.mode
  return default
 @staticmethod
 def VVAXur():
  VVLbeP = InfoBar.instance
  if VVLbeP:
   csel = VVLbeP.servicelist
   if csel:
    return csel.bouquet_rootstr
  return ""
 @staticmethod
 def VV4BXG():
  return FF72md(VVmldL) if fileExists(VVmldL) else []
 @staticmethod
 def VVvipS(ref, lst=None):
  if not lst:
   lst = CCQIeq.VV4BXG()
  if "FROM BOUQUET " in ref:
   ref1 = ref.replace("1:7:", "1:0:")
   ref2 = ref.replace("1:519:", "1:0:")
   if   ref1 in lst: return lst.index(ref1)
   elif ref2 in lst: return lst.index(ref2)
  return -1
class CCuqLp(Screen, CCIquq, CCBpAz):
 VVIcuP   = 0
 VVrxti  = 1
 VV8R9P  = 2
 VVUfqe  = 3
 VVsY25  = 4
 VVhZbn  = 5
 VVDYD4  = 6
 VVsTyC  = 7
 VVGYQb = 8
 VV2z4L = 9
 VV4GnZ = 10
 VVOkRv = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFPFsH(VVRjYc, 1400, 840, 30, 0, 0, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "PIcons Tools"
  self.pPath    = CCuqLp.VVchM7()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVcuvv    = []
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  FFRFZg(self, self.Title)
  FFKdfz(self["keyRed"] , "OK = Zap")
  FFKdfz(self["keyGreen"] , "Current Service")
  FFKdfz(self["keyYellow"], "Page Options")
  FFKdfz(self["keyBlue"] , "Filter")
  CCIquq.__init__(self, 5, 7, CFG.transpColorPicons)
  CCBpAz.__init__(self)
  self["myAction"].actions.update(
  {
   "ok"  : self.VVsRqJ     ,
   "green"  : self.VVGXlZ    ,
   "yellow" : self.VV8OcL     ,
   "blue"  : self.VVIV1s     ,
   "menu"  : self.VVrZeY     ,
   "info"  : self.VVLPOT    ,
   "pageUp" : BF(self.VVRK2q, True) ,
   "chanUp" : BF(self.VVRK2q, True) ,
   "pageDown" : BF(self.VVRK2q, False) ,
   "chanDown" : BF(self.VVRK2q, False) ,
   "0"   : self.VVVNAn  ,
   "cancel" : self.close
  })
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFk6h6(self)
  FFFlxX(self)
  FFC3pI(self["keyRed"], "#0a333333")
  self.VVOoGg()
  FFbA1i(self, BF(self.VVJ7js, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVrZeY(self):
  if not self.isBusy:
   VVtMHe = []
   VVtMHe.append(("Statistics"           , "VV0zFX"    ))
   VVtMHe.append(VVXGzj)
   VVtMHe.append(("Suggest PIcons for Current Channel"     , "VVG22b"   ))
   VVtMHe.append(("Set to Current Channel (copy file)"     , "VVXhwi_file"  ))
   VVtMHe.append(("Set to Current Channel (as SymLink)"     , "VVXhwi_link"  ))
   VVtMHe.append(VVXGzj)
   VVtMHe.append(("Export Current File Names List"      , "VVKLwE" ))
   VVtMHe.append(CCuqLp.VVcoCN())
   VVtMHe.append(VVXGzj)
   c, cond = VVtchu, self.filterTitle == "PIcons without Channels"
   VVtMHe.append(FFQlwu("Move Unused PIcons to a Directory", "VVWxI3" , cond, c))
   VVtMHe.append(FFQlwu("DELETE Unused PIcons"    , "VVLGLK" , cond, c))
   VVtMHe.append(VVXGzj)
   VVtMHe.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VV9Kde"  ))
   VVtMHe.append(VVXGzj)
   VVtMHe += CCuqLp.VVNRum()
   VVtMHe.append(VVXGzj)
   VVtMHe.append(("Change Poster/Picon Transparency Color"    , "VVCdm8" ))
   VVtMHe.append(("Keys Help"           , "VVU5Zj"    ))
   FFECK9(self, self.VVvmYM, width=1100, height=1050, title=self.Title, VVtMHe=VVtMHe)
 def VVvmYM(self, item=None):
  if item is not None:
   if   item == "VV0zFX"    : self.VV0zFX()
   elif item == "VVG22b"   : self.VVG22b()
   elif item == "VVXhwi_file"  : self.VVXhwi(0)
   elif item == "VVXhwi_link"  : self.VVXhwi(1)
   elif item == "VVKLwE"  : self.VVKLwE()
   elif item == "VVthyt"  : CCuqLp.VVthyt(self)
   elif item == "VVWxI3"   : self.VVWxI3()
   elif item == "VVLGLK"  : self.VVLGLK()
   elif item == "VV9Kde"  : self.VV9Kde()
   elif item == "VVsFYR"  : CCuqLp.VVsFYR(self)
   elif item == "findPiconBrokenSymLinks" : CCuqLp.VVjAqm(self, True)
   elif item == "FindAllBrokenSymLinks" : CCuqLp.VVjAqm(self, False)
   elif item == "VVCdm8" : self.VVCdm8()
   elif item == "VVU5Zj"     : FFSnt9(self, "_help_picons", "PIcons Tools (Keys Help)")
 def VV8OcL(self):
  if not self.isBusy:
   VVtMHe = []
   VVtMHe.append(("Go to First PIcon"  , "VV7hNq"  ))
   VVtMHe.append(("Go to Last PIcon"   , "VVKt3O"  ))
   VVtMHe.append(VVXGzj)
   VVtMHe.append(("Sort by Channel Name"     , "sortByChan" ))
   VVtMHe.append(("Sort by File Name"  , "sortByFile" ))
   VVtMHe.append(VVXGzj)
   VVtMHe.append(("Find from File List .." , "VVPeYk" ))
   FFECK9(self, self.VVWlQz, title=self.Title, VVtMHe=VVtMHe)
 def VVWlQz(self, item=None):
  if item is not None:
   if   item == "VV7hNq"   : self.VV7hNq()
   elif item == "VVKt3O"   : self.VVKt3O()
   elif item == "sortByChan"  : self.VV8x59(2)
   elif item == "sortByFile"  : self.VV8x59(0)
   elif item == "VVPeYk"  : self.VVPeYk()
 def VVPeYk(self):
  VVtMHe = []
  for item in self.VVcuvv:
   VVtMHe.append((item[0], item[0]))
  FFECK9(self, self.VVnGav, title='PIcons ".png" Files', VVtMHe=VVtMHe, VVIZXB=True)
 def VVnGav(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVUBc5(ndx)
 def VVsRqJ(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVzTIv()
   if refCode:
    FFoYZf(self, refCode)
    self.VVzmON()
    self.VVEU69()
 def VVRK2q(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVzmON()
   self.VVEU69()
  except:
   pass
 def VVGXlZ(self):
  if self["keyGreen"].getVisible():
   self.VVUBc5(self.curChanIndex)
 def VV8x59(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFbA1i(self, BF(self.VVJ7js, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVXhwi(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVzTIv()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVtMHe = []
     VVtMHe.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVtMHe.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFECK9(self, BF(self.VVIRKB, mode, curChF, selPiconF), VVtMHe=VVtMHe, title="Current Channel PIcon (already exists)")
    else:
     self.VVIRKB(mode, curChF, selPiconF, "overwrite")
   else:
    FFOyl1(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFOyl1(self, "Could not read current channel info. !", title=title)
 def VVIRKB(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   FFqSkC(cmd)
   FFbA1i(self, BF(self.VVJ7js, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVWxI3(self):
  defDir = FFDpEI(CCuqLp.VVchM7() + "picons_backup")
  FFqSkC("mkdir '%s'" % defDir)
  self.session.openWithCallback(BF(self.VVc1BW, defDir), BF(CCVnYx
         , mode=CCVnYx.VVW7oj, VVSMX5=CCuqLp.VVchM7()))
 def VVc1BW(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCuqLp.VVchM7():
    FFOyl1(self, "Cannot move to same directory !", title=title)
   else:
    if not FFDpEI(path) == FFDpEI(defDir):
     self.VV4DHF(defDir)
    FFgBNQ(self, BF(FFbA1i, self, BF(self.VVhmiP, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVcuvv), path), title=title)
  else:
   self.VV4DHF(defDir)
 def VVhmiP(self, title, defDir, toPath):
  if not iMove:
   self.VV4DHF(defDir)
   FFOyl1(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FFDpEI(toPath)
  pPath = CCuqLp.VVchM7()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVcuvv:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVcuvv)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFoB4k(self, txt, title=title, VVSJJk="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVG1Hf("all")
 def VV4DHF(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVLGLK(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVcuvv)
  FFgBNQ(self, BF(FFbA1i, self, BF(self.VV12oP, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FFsfSO(tot)), title=title)
 def VV12oP(self, title):
  pPath = CCuqLp.VVchM7()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVcuvv:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVcuvv)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FF8oA9(str(totErr), VV8ETX)
  FFoB4k(self, txt, title=title)
 def VV9Kde(self):
  lines = FFYEhL("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FFgBNQ(self, BF(self.VVsGUT, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FFsfSO(tot)), VVMgjE=True)
  else:
   FFDeF8(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVsGUT(self, fList):
  FFqSkC("find -L '%s' -type l -delete" % self.pPath)
  FFDeF8(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVLPOT(self):
  FFbA1i(self, self.VVHaqg)
 def VVHaqg(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVzTIv()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FF8oA9("PIcon Directory:\n", VVoIYV)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FFn4Y0(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFn4Y0(path)
   txt += FF8oA9("PIcon File:\n", VVoIYV)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FF8oA9("Found %d SymLink%s to this file from:\n" % (tot, FFsfSO(tot)), VVoIYV)
     for fPath in slLst:
      txt += "  %s\n" % FF8oA9(fPath, VVD4un)
     txt += "\n"
   if chName:
    txt += FF8oA9("Channel:\n", VVoIYV)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FF8oA9(chName, VViZMT)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FF8oA9("Remarks:\n", VVoIYV)
    txt += "  %s\n" % FF8oA9("Unused", VV8ETX)
  else:
   txt = "No info found"
  FF1wB7(self, fncMode=CCqIel.VVmJLK, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVzTIv(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalItems:
   fName, fType, chName, sat, inDB = self.VVcuvv[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFH6BB(sat)
  return fName, refCode, chName, sat, inDB
 def VVzmON(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVcuvv):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVEU69(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVzTIv()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalItems)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FF8oA9("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVoIYV))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVzTIv()[1]))
  if self.curChanIptvRef : typ = "Stream Relay" if FF81BD(self.curChanIptvRef) else "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FF8oA9(self.curChanName, VVXAXH)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
  filName, refCode, chName, sat, inDB = self.VVzTIv()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VV0zFX(self):
  VVJwMZ, VVFf41 = FFAND4()
  sTypeNameDict = {}
  for key, val in VVFf41.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VVcuvv:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VVFf41: sTypeDict[VVFf41[stNum]] = sTypeDict.get(VVFf41[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FFvL4V("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVsLLE = []
  c = "#b#11003333#"
  VVsLLE.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalItems, totUsedFiles + totUsedLinks)))
  VVsLLE.append((c + "Files" , "%d\tUsed = %s" % (self.totalItems - totSymLinks, totUsedFiles)))
  VVsLLE.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVsLLE.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVsLLE.append((c + "Not In Database (lamedb)" , str(self.totalItems - totInDB)))
  VVsLLE.append((c + "Satellites"    , str(len(self.nsList))))
  VVsLLE.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVsLLE.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVsLLE.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVsLLE.extend(sTypeRows)
  FFDpub(self, None, title=self.Title, VVcuvv=VVsLLE, VVGNdU=28, VVYCZ6="#00003333", VVTjte="#00222222")
 def VVKLwE(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FFDpEI(CFG.exportedTablesPath.getValue()), txt, FFZR2n())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VVcuvv:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FFDeF8(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVIV1s(self):
  if not self.isBusy:
   VVtMHe = []
   VVtMHe.append(("All"        , "all"  ))
   VVtMHe.append(VVXGzj)
   VVtMHe.append(("Used by Channels"     , "used" ))
   VVtMHe.append(("Unused PIcons"     , "unused" ))
   VVtMHe.append(("IPTV PIcons"      , "iptv" ))
   VVtMHe.append(VVXGzj)
   VVtMHe.append(("PIcons Files"      , "pFiles" ))
   VVtMHe.append(("SymLinks to PIcons"    , "pLinks" ))
   VVtMHe.append(("PIcons Files Targeted by SymLinks", "pTargets"))
   VVtMHe.append(("By Files Date ..."    , "pDate" ))
   VVtMHe.append(("By Service Type ..."    , "servType"))
   if self.nsList:
    VVtMHe.append(FF5f5W("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFNSbQ(val)
      VVtMHe.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CC6kzI(self)
   filterObj.VVmQ3J(VVtMHe, self.nsList, self.VVohRn)
 def VVohRn(self, item=None):
  if item is not None:
   self.VVG1Hf(item)
 def VVG1Hf(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVIcuP   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVrxti   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VV8R9P  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVDYD4   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVUfqe  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVsY25  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVhZbn  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VV4GnZ , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VVOkRv , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVsTyC   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVGYQb , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVhZbn:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFYEhL("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFd4tO(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFZD7H(self, "Not found", 1000)
     return
   elif mode == self.VV4GnZ:
    self.VVOhbB(mode)
    return
   elif mode == self.VVOkRv:
    self.VVUffK(mode)
    return
   elif mode == self.VV2z4L:
    return
   else:
    words, asPrefix = CC6kzI.VVV2i7(words)
   if not words and mode in (self.VVsTyC, self.VVGYQb):
    FFZD7H(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFbA1i(self, BF(self.VVJ7js, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVOhbB(self, mode):
  VVtMHe = []
  VVtMHe.append(("Today"   , "today" ))
  VVtMHe.append(("Since Yesterday" , "yest" ))
  VVtMHe.append(("Since 7 days"  , "week" ))
  FFECK9(self, BF(self.VVuhqI, mode), VVtMHe=VVtMHe, title="Filter by Added/Modified Date")
 def VVuhqI(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FF7pXq(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FF7pXq(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FF7pXq(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FFbA1i(self, BF(self.VVJ7js, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVUffK(self, mode):
  VVJwMZ, VVFf41 = FFAND4()
  lst = set()
  for key, val in VVFf41.items():
   lst.add(val)
  VVtMHe = []
  for item in lst:
   VVtMHe.append((item, item))
  VVtMHe.sort(key=lambda x: x[0])
  FFECK9(self, BF(self.VVTB9c, mode), VVtMHe=VVtMHe, title="Filter by Service Type")
 def VVTB9c(self, mode, item=None):
  if item:
   VVJwMZ, VVFf41 = FFAND4()
   sTypeList = []
   for key, val in VVFf41.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FFbA1i(self, BF(self.VVJ7js, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVG22b(self):
  self.session.open(CCjWUz, barTheme=CCjWUz.VVJmH5
      , titlePrefix = ""
      , fncToRun  = self.VVUfHJ
      , VVCBqA = self.VV052K)
 def VVUfHJ(self, VVNVFL):
  VVXA47, err = CCwuBY.VVtR0o(self, CCwuBY.VVTsIE, VVOnBM=False, VVGHpD=False)
  files = []
  words = []
  if not VVNVFL or VVNVFL.isCancelled:
   return
  VVNVFL.VVpwcW = []
  VVNVFL.VV0amK(len(VVXA47))
  if VVXA47:
   curCh = self.VV65U4(self.curChanName)
   for refCode in VVXA47:
    if not VVNVFL or VVNVFL.isCancelled:
     return
    VVNVFL.VViyfK(1, True)
    chName, sat, inDB = VVXA47.get(refCode, ("", "", 0))
    ratio = CCuqLp.VVudZF(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCuqLp.VV64RK(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFd4tO(f)
       fil = f.replace(".png", "")
       if not fil in VVNVFL.VVpwcW:
        VVNVFL.VVpwcW.append(fil)
 def VV052K(self, VVdCuP, VVpwcW, threadCounter, threadTotal, threadErr):
  if VVpwcW : FFbA1i(self, BF(self.VVJ7js, mode=self.VV2z4L, words=VVpwcW), title="Loading ...")
  else   : FFZD7H(self, "Not found", 2000)
 def VVJ7js(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VVAi6D(isFirstTime):
   return
  self.isBusy = True
  VVGHpD = True if isFirstTime else False
  VVXA47, err = CCwuBY.VVtR0o(self, CCwuBY.VVTsIE, VVOnBM=False, VVGHpD=VVGHpD)
  if err:
   self.close()
  iptvRefList = self.VVqYW7()
  tList = []
  for fName, fType in CCuqLp.VV7eH6(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVXA47:
    if fName in VVXA47:
     chName, sat, inDB = VVXA47.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVIcuP:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVrxti  and chName         : isAdd = True
   elif mode == self.VV8R9P and not chName        : isAdd = True
   elif mode == self.VVUfqe  and fType == 0        : isAdd = True
   elif mode == self.VVsY25  and fType == 1        : isAdd = True
   elif mode == self.VVhZbn  and fName in words       : isAdd = True
   elif mode == self.VV2z4L and fName in words       : isAdd = True
   elif mode == self.VVDYD4  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVsTyC  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVGYQb:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VV4GnZ:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VVOkRv:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVcuvv   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FFZD7H(self)
  else:
   self.isBusy = False
   FFZD7H(self, "Not found", 1000)
   return
  self.VVcuvv.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVzmON()
  self.totalItems = len(self.VVcuvv)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self.isBusy = False
  self.VVaG1c(True)
 def VVAi6D(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCuqLp.VV7eH6(self.pPath):
    if fName:
     return True
   if isFirstTime : FFOyl1(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFZD7H(self, "Not found", 1000)
  else:
   FFOyl1(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVqYW7(self):
  VVsLLE = {}
  files  = CCoUhv.VVDteM()
  if files:
   for path in files:
    txt = FFFr8o(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVsLLE[refCode] = item[1]
  return VVsLLE
 def VVQQTH(self):
  self.VVCoFp()
  f1, f2 = self.VVaMX8()
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVcuvv[ndx]
   fName = self.VVcuvv[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   if CCIquq.VVkpor(pic, path) : color = VViZMT if inDB else ""
   elif not chName           : color = ""
   else             : color = VVbRZL
   self.VVKGTb(lbl, chName or "-", color)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVudZF(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVcoCN():
  return ("Copy Current Channel PIcon (to PIcons Export Path)", "VVthyt")
 @staticmethod
 def VVNRum():
  VVtMHe = []
  VVtMHe.append(("Find SymLinks (to PIcon Directory)"   , "VVsFYR"  ))
  VVtMHe.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks" ))
  VVtMHe.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks" ))
  return VVtMHe
 @staticmethod
 def VVthyt(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(SELF)
  png, path = CCuqLp.VV1THp(refCode)
  if path : CCuqLp.VVLRoF(SELF, png, path)
  else : FFOyl1(SELF, "No PIcon found for current channel in:\n\n%s" % CCuqLp.VVchM7())
 @staticmethod
 def VVsFYR(SELF):
  if VVXAXH:
   sed1 = FFP1gK("->", VVXAXH)
   sed2 = FFP1gK("picon", VV8ETX)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVbRZL, VV7V3G)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FF1lrl(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFXN5L(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVjAqm(SELF, isPIcon):
  sed1 = FFP1gK("->", VVbRZL)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFP1gK("picon", VV8ETX)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FF1lrl(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFXN5L(), grep, sed1, sed2))
 @staticmethod
 def VVLRoF(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFP1gK("%s%s" % (dest, png), VViZMT))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFP1gK(errTxt, VVOr14))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFYQXW(SELF, cmd)
 @staticmethod
 def VV7eH6(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVchM7():
  path = CFG.PIconsPath.getValue()
  return FFDpEI(path)
 @staticmethod
 def VV1THp(refCode, chName=None):
  if FFueFC(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFp63C(refCode)
  allPath, fName, refCodeFile, pList = CCuqLp.VV64RK(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return "", ""
 @staticmethod
 def VVVT8Z(pPath, refCode, chName):
  span = iSearch(r"^((?:[A-Fa-f0-9]+:){10})", refCode.strip())
  if span:
   exts = ("png", "jpg")
   refCode = span.group(1).rstrip(":").replace(":", "_")
   tPath = "%s%s." % (pPath, refCode)
   for ext in exts:
    path = tPath + ext
    if fileExists(path):
     return path
   refParts = refCode.split("_", 1)
   for rType in CCoUhv.VVO4pN():
    if not rType == refParts[0]:
     for ext in exts:
      path = "%s%s_%s.%s" %  (pPath, rType, refParts[1], ext)
      if fileExists(path):
       return path
   chName = FF3gfV(chName)
   chName1 = chName.replace(" ", "")
   for name in (chName, chName.lower(), chName.upper(), chName1.lower(), chName1.upper()):
    for ext in exts:
     path = "%s%s.%s" % (pPath, name, ext)
     if fileExists(path):
      return path
  return ""
 @staticmethod
 def VV64RK(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   fName = fName.rstrip(":")
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCuqLp.VVchM7()
   pList = []
   lst = FF0KZb(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FF3gfV(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFd4tO(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCCDSZ():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVtNvf  = None
  self.VVD3ai = ""
  self.VVaFpv  = noService
  self.VVJkxN = 0
  self.VV3Ngy  = noService
  self.VVAQ3J = 0
  self.VVp0zS  = "-"
  self.VVLazN = 0
  self.VV3rJf  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVPbWD(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVtNvf = frontEndStatus
     self.VVF5Ic()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVF5Ic(self):
  if self.VVtNvf:
   val = self.VVtNvf.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVD3ai = "%3.02f dB" % (val / 100.0)
   else         : self.VVD3ai = ""
   val = self.VVtNvf.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVJkxN = int(val)
   self.VVaFpv  = "%d%%" % val
   val = self.VVtNvf.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVAQ3J = int(val)
   self.VV3Ngy  = "%d%%" % val
   val = self.VVtNvf.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVp0zS  = "%d" % val
   val = int(val * 100 / 500)
   self.VVLazN = min(500, val)
   val = self.VVtNvf.get("tuner_locked", 0)
   if val == 1 : self.VV3rJf = "Locked"
   else  : self.VV3rJf = "Not locked"
 def VViHbF(self)   : return self.VVD3ai
 def VVjS80(self)   : return self.VVaFpv
 def VVLNrQ(self)  : return self.VVJkxN
 def VVec9U(self)   : return self.VV3Ngy
 def VVN3cP(self)  : return self.VVAQ3J
 def VVLAwp(self)   : return self.VVp0zS
 def VV12M4(self)  : return self.VVLazN
 def VVyaL8(self)   : return self.VV3rJf
 def VVPSN9(self) : return self.serviceName
class CCMbXb():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVyuTR(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFGH0N(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVJHHd(self.ORPOS  , mod=1   )
      self.sat2  = self.VVJHHd(self.ORPOS  , mod=2   )
      self.freq  = self.VVJHHd(self.FREQ  , mod=3   )
      self.sr   = self.VVJHHd(self.SR   , mod=4   )
      self.inv  = self.VVJHHd(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVJHHd(self.POL  , self.D_POL )
      self.fec  = self.VVJHHd(self.FEC  , self.D_FEC )
      self.syst  = self.VVJHHd(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVJHHd("modulation" , self.D_MOD )
       self.rolof = self.VVJHHd("rolloff"  , self.D_ROLOF )
       self.pil = self.VVJHHd("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVJHHd("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVJHHd("pls_code"  )
       self.iStId = self.VVJHHd("is_id"   )
       self.t2PlId = self.VVJHHd("t2mi_plp_id" )
       self.t2PId = self.VVJHHd("t2mi_pid"  )
 def VVJHHd(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFNSbQ(val)
  elif mod == 2   : return FFxdmJ(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VVCBEO(self, refCode):
  txt = ""
  self.VVyuTR(refCode)
  if self.data:
   def VVYgG4(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVYgG4("System"   , self.syst)
    txt += VVYgG4("Satellite"  , self.sat2)
    txt += VVYgG4("Frequency"  , self.freq)
    txt += VVYgG4("Inversion"  , self.inv)
    txt += VVYgG4("Symbol Rate"  , self.sr)
    txt += VVYgG4("Polarization" , self.pol)
    txt += VVYgG4("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVYgG4("Modulation" , self.mod)
     txt += VVYgG4("Roll-Off" , self.rolof)
     txt += VVYgG4("Pilot"  , self.pil)
     txt += VVYgG4("Input Stream", self.iStId)
     txt += VVYgG4("T2MI PLP ID" , self.t2PlId)
     txt += VVYgG4("T2MI PID" , self.t2PId)
     txt += VVYgG4("PLS Mode" , self.plsMod)
     txt += VVYgG4("PLS Code" , self.plsCod)
   else:
    txt += VVYgG4("System"   , self.txMedia)
    txt += VVYgG4("Frequency"  , self.freq)
  return txt, self.namespace
 def VVe2ir(self, refCode):
  txt = "Transpoder : ?"
  self.VVyuTR(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VV1FtS(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFGH0N(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVJHHd(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVJHHd(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVJHHd(self.SYST, self.D_SYS_S)
     freq = self.VVJHHd(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVJHHd(self.POL , self.D_POL)
      fec = self.VVJHHd(self.FEC , self.D_FEC)
      sr = self.VVJHHd(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVrKAA(self, refCode):
  self.data = None
  self.VVyuTR(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCiazU():
 def __init__(self, VVJpFH, path, VVCBqA=None, curRowNum=-1):
  self.VVJpFH  = VVJpFH
  self.origFile   = path
  self.Title    = "File Editor: " + FFd4tO(path)
  self.VVCBqA  = VVCBqA
  self.tmpFile   = "/tmp/ajp_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  self.editorTable  = None
  if FFqSkC("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)):
   FFbA1i(self.VVJpFH, BF(self.VVrykL, curRowNum), title="Loading file ...")
  else:
   FFOyl1(self.VVJpFH, "Error while preparing edit!")
 def VVrykL(self, curRowNum):
  VVsLLE = self.VVKANC()
  VV1kWx = ("Save Changes" , self.VVl4UD   , [])
  VVMWQK  = ("Edit Line"  , self.VVsYe9    , [])
  VVM9Pm = ("Options"  , self.VVMc0n  , [])
  VVRHhw = ("Line Options" , self.VVkIpe   , [])
  VVBYRP = (""    , self.VV06S5 , [])
  VVJi29 = self.VVFexB
  VVXhOf  = self.VVkaj7
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VV0CnX  = (CENTER  , LEFT  )
  bg    = "#11001111"
  self.editorTable = FFDpub(self.VVJpFH, None, title=self.Title, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, width=1600, height=1000, VVGNdU=26, isEditor=True, VV1kWx=VV1kWx, VVMWQK=VVMWQK, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw, VVJi29=VVJi29, VVXhOf=VVXhOf, VVBYRP=VVBYRP, VVEMdg=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
        , VVaRsg=bg, VVWgai=bg, VVSJJk=bg, VVYCZ6="#05333333", VVTjte="#00303030", VVIyj7="#11331133")
  self.editorTable.VVTklH(curRowNum)
 def VVkaj7(self, VVdesl):
  VVdesl.VVNvGq()
 def VVMc0n(self, VVdesl, title, txt, colList):
  VVtMHe = []
  VVtMHe.append(("Go to Line Num" , "toLine"))
  VVtMHe.append(("Find & Replace" , "repl"))
  FFECK9(self.VVJpFH, self.VVt46J, VVtMHe=VVtMHe, width=500, title="Options", VVIZXB=True)
 def VVt46J(self, item=None):
  if item:
   title, ref, ndx = item
   if   ref == "toLine" : self.VVyxWB()
   elif ref == "repl"  : self.VVhFBe(title)
 def VVhFBe(self, title):
  fnd = CFG.lastFindRepl_fnd.getValue()
  rpl = CFG.lastFindRepl_rpl.getValue()
  lst = [(" Find", fnd, str(len(fnd))), (" Replace with", rpl, str(len(rpl)))]
  bg = "#11101010"
  VVMWQK  = ("Change" , BF(self.VVqfg6, title, lst) , [])
  VV1kWx = ("Start" , BF(self.VVjwrR, title)  , [])
  header  = (" Subject", " Text" , "Len.")
  widths  = (20   , 70  , 10 )
  VV0CnX = (LEFT   , LEFT  , CENTER)
  FFDpub(self.VVJpFH, None, title=title, VVcuvv=lst, header=header, VV0CnX=VV0CnX, VVbG6j=widths, width=1200, VVGNdU=30, isEditor=True, VVMWQK=VVMWQK, VV1kWx=VV1kWx, VVcmLr=2
    , VVaRsg=bg, VVWgai=bg, VVSJJk=bg, VVYCZ6="#06224455", VVTjte="#0a303030")
 def VVqfg6(self, Title, lst, VVdesl, title, txt, colList):
  title = VVdesl.VVxBD7(0)
  ndx = VVdesl.VVvapY()
  txt = CFG.lastFindRepl_fnd.getValue() if ndx == 0 else CFG.lastFindRepl_rpl.getValue()
  FFdnKb(self.VVJpFH, BF(self.VVQodX, VVdesl, ndx), title=title, defaultText=txt, message="New entry")
 def VVQodX(self, VVdesl, ndx, newTxt=None):
  if newTxt:
   if ndx == 0 : FF0UO9(CFG.lastFindRepl_fnd, newTxt)
   else  : FF0UO9(CFG.lastFindRepl_rpl, newTxt)
   VVdesl.VVonwB({1:newTxt, 2:len(newTxt)})
 def VVjwrR(self, Title, VVdesl, title, txt, colList):
  fnd = CFG.lastFindRepl_fnd.getValue()
  rpl = CFG.lastFindRepl_rpl.getValue()
  if len(fnd) > 0:
   txt = FFFr8o(self.tmpFile)
   tot = txt.count(fnd)
   if tot > 0:
    FFgBNQ(self.VVJpFH, BF(FFbA1i, VVdesl, BF(self.VVOJWl, VVdesl, fnd, rpl), title="Replacing ..."), "Replace %d occurrences ?" % tot, title=Title)
   else:
    FFZD7H(VVdesl, "Not found in file !", 1000)
    VVdesl.VVTklH(0)
  else:
   FFZD7H(VVdesl, "Nothing to find", 1000)
 def VVOJWl(self, VVdesl, fnd, rpl):
  txt = FFFr8o(self.tmpFile)
  txt = txt.replace(fnd, rpl)
  with open(self.tmpFile, "w") as f:
   f.write(txt)
  VVdesl.cancel()
  self.fileChanged = True
  self.editorTable.VVQUuA()
  VVsLLE = self.VVKANC()
  self.editorTable.VV87pY(VVsLLE)
 def VVyxWB(self):
  totRows = self.editorTable.VVH1h9()
  lineNum = self.editorTable.VVvapY() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FFdnKb(self.VVJpFH, BF(self.VVqGnN, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VVqGnN(self, lineNum, totRows, VVfJks):
  if VVfJks:
   VVfJks = VVfJks.strip()
   if VVfJks.isdigit():
    num = FFOaVa(int(VVfJks) - 1, 0, totRows)
    self.editorTable.VVTklH(num)
    self.lastLineNum = num + 1
   else:
    FFZD7H(self.editorTable, "Incorrect number", 1500)
 def VVkIpe(self, VVdesl, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVdesl.VVMs9k()
  VVtMHe = []
  VVtMHe.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVtMHe.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVKSJn"  ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVLYHK:
   VVtMHe.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(  ("Delete Line"         , "deleteLine"   ))
  FFECK9(self.VVJpFH, BF(self.VVUmfb, lineNum), VVtMHe=VVtMHe, title="Line Options")
 def VVUmfb(self, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVapst("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile))
   elif item == "VVKSJn"  : self.VVKSJn(lineNum)
   elif item == "copyToClipboard"  : self.VVbhnG(lineNum)
   elif item == "pasteFromClipboard" : self.VVjh34(lineNum)
   elif item == "deleteLine"   : self.VVapst("sed -i '%dd' '%s'" % (lineNum, self.tmpFile))
 def VV06S5(self, VVdesl, title, txt, colList):
  if   self.insertMode == 1: VVdesl.VVkzmH()
  elif self.insertMode == 2: VVdesl.VVenHM()
  self.insertMode = 0
 def VVKSJn(self, lineNum):
  if lineNum == self.editorTable.VVMs9k():
   self.insertMode = 1
   self.VVapst("echo '' >> '%s'" % self.tmpFile)
  else:
   self.insertMode = 2
   self.VVapst("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile))
 def VVbhnG(self, lineNum):
  global VVLYHK
  VVLYHK = FFvL4V("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  self.editorTable.VVz4xL("Copied to clipboard")
 def VVl4UD(self, VVdesl, title, txt, colList):
  if self.fileChanged:
   if FFZkSn(self.origFile):
    if FFqSkC("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)):
     VVdesl.VVz4xL("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVdesl.VVNvGq()
    else:
     FFOyl1(self.VVJpFH, "Cannot save file!")
   else:
    FFOyl1(self.VVJpFH, "Cannot create backup copy of original file!")
 def VVFexB(self, VVdesl):
  if self.fileChanged:
   FFgBNQ(self.VVJpFH, BF(self.VVISo1, VVdesl), "Cancel changes ?")
  else:
   FFqSkC("cp -f '%s' '%s'" % (self.tmpFile, self.origFile))
   self.VVISo1(VVdesl)
 def VVISo1(self, VVdesl):
  VVdesl.cancel()
  FFOlRe(self.tmpFile)
  if self.VVCBqA:
   self.VVCBqA(self.fileSaved)
 def VVsYe9(self, VVdesl, title, txt, colList):
  lineNum = int(VVdesl.VVxBD7(0))
  lineTxt = VVdesl.VVxBD7(1, isStrip=False)
  message = VV7V3G + "ORIGINAL TEXT:\n" + VVD4un + lineTxt
  FFdnKb(self.VVJpFH, BF(self.VVbKMA, lineNum), title="File Line", defaultText=lineTxt, message=message)
 def VVbKMA(self, lineNum, VVfJks):
  if not VVfJks is None:
   if self.editorTable.VVMs9k() <= 1:
    self.VVapst("echo %s > '%s'" % (VVfJks, self.tmpFile))
   else:
    self.VVE9Oo(lineNum, VVfJks)
 def VVjh34(self, lineNum):
  if lineNum == self.editorTable.VVMs9k() and self.editorTable.VVMs9k() == 1:
   self.VVapst("echo %s >> '%s'" % (VVLYHK, self.tmpFile))
  else:
   self.VVE9Oo(lineNum, VVLYHK)
 def VVE9Oo(self, lineNum, newTxt):
  self.editorTable.VVYtu4("Saving ...")
  lines = FF72md(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  self.editorTable.VVQUuA()
  VVsLLE = self.VVKANC()
  self.editorTable.VV87pY(VVsLLE)
 def VVapst(self, cmd):
  tCons = CC2xQD()
  tCons.ePopen(cmd, self.VVOCPH)
  self.fileChanged = True
  self.editorTable.VVQUuA()
 def VVOCPH(self, result, retval):
  VVsLLE = self.VVKANC()
  self.editorTable.VV87pY(VVsLLE)
 def VVKANC(self):
  if fileExists(self.tmpFile):
   lines = FF72md(self.tmpFile)
   VVsLLE = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVsLLE.append((str(ndx), line))
   if not VVsLLE:
    VVsLLE.append((str(1), ""))
   return VVsLLE
  else:
   FFbiIe(self.VVJpFH, self.tmpFile)
class CC6kzI():
 def __init__(self, callingSELF, VVaRsg="#22003344", VVWgai="#22002233"):
  self.callingSELF = callingSELF
  self.VVtMHe  = []
  self.satList  = []
  self.VVaRsg  = VVaRsg
  self.VVWgai   = VVWgai
 def VVZBdt(self, VVCBqA):
  self.VVtMHe = []
  VVtMHe, VVxFc7 = CC6kzI.VVMhrM(self.callingSELF, False, True)
  if VVtMHe:
   self.VVtMHe += VVtMHe
   self.VVOWve(VVCBqA, VVxFc7)
 def VVRAJD(self, mode, VVdesl, satCol, VVCBqA, inFilterFnc=None):
  VVdesl.VVYtu4("Loading Filters ...")
  self.VVtMHe = []
  self.VVtMHe.append(("All Services" , "all"))
  if mode == 1:
   self.VVtMHe.append(VVXGzj)
   self.VVtMHe.append(("Parental Control", "parentalControl" ))
   self.VVtMHe.append(("Hidden Services" , "hiddenServices" ))
  elif mode == 2:
   self.VVtMHe.append(VVXGzj)
   self.VVtMHe.append(("Selected Transponder"   , "selectedTP" ))
   self.VVtMHe.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVdmRc(VVdesl, satCol)
  VVtMHe, VVxFc7 = CC6kzI.VVMhrM(self.callingSELF, True, False)
  if VVtMHe:
   VVtMHe.insert(0, FF5f5W("Custom Words"))
   self.VVtMHe += VVtMHe
  VVdesl.VVaW1B()
  self.VVOWve(VVCBqA, VVxFc7, inFilterFnc)
 def VVmQ3J(self, VVtMHe, sats, VVCBqA, inFilterFnc=None):
  self.VVtMHe = VVtMHe
  VVtMHe, VVxFc7 = CC6kzI.VVMhrM(self.callingSELF, True, False)
  if VVtMHe:
   self.VVtMHe.append(FF5f5W("Custom Words"))
   self.VVtMHe += VVtMHe
  self.VVOWve(VVCBqA, VVxFc7, inFilterFnc)
 def VVOWve(self, VVCBqA, VVxFc7, inFilterFnc=None):
  VVI3Sz  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VVIL24 = ("Edit Filter"  , BF(self.VVm5cT, VVxFc7))
  VVrBns  = ("Filter Help"  , BF(self.VVfB9h, VVxFc7))
  FFECK9(self.callingSELF, BF(self.VVzdXg, VVCBqA), VVtMHe=self.VVtMHe, title="Select Filter", VVI3Sz=VVI3Sz, VVIL24=VVIL24, VVrBns=VVrBns, VVy2u1=True, VVaRsg=self.VVaRsg, VVWgai=self.VVWgai)
 def VVzdXg(self, VVCBqA, item):
  if item:
   VVCBqA(item)
 def VVm5cT(self, VVxFc7, selectionObj, sel):
  if fileExists(VVxFc7) : CCiazU(self.callingSELF, VVxFc7, VVCBqA=None)
  else       : FFbiIe(self.callingSELF, VVxFc7)
  selectionObj.cancel()
 def VVfB9h(self, VVxFc7, selectionObj, sel):
  FFSnt9(self.callingSELF, "_help_service_filter", "Service Filter")
 def VVdmRc(self, VVdesl, satColNum):
  if not self.satList:
   satList = VVdesl.VVdWFX(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFH6BB(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FF5f5W("Satellites"))
  if self.VVtMHe:
   self.VVtMHe += self.satList
 @staticmethod
 def VVMhrM(SELF, addTag, VVl1IZ):
  FFQ71e()
  fileName  = "ajpanel_services_filter"
  VVxFc7 = VVZAJU + fileName
  VVtMHe  = []
  if not fileExists(VVxFc7):
   FFqSkC("cp -f '%s' '%s'" % (VV2V68 + fileName, VVxFc7))
  fileFound = False
  if fileExists(VVxFc7):
   fileFound = True
   lines = FF72md(VVxFc7)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVtMHe.append((line, "__w__" + line))
       else  : VVtMHe.append((line, line))
  if VVl1IZ:
   if   not fileFound : FFbiIe(SELF, VVxFc7)
   elif not VVtMHe : FFAyN7(SELF, VVxFc7)
  return VVtMHe, VVxFc7
 @staticmethod
 def VVV2i7(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CCB2u5():
 def __init__(self, callingSELF, VVdesl, addSep=True):
  self.callingSELF = callingSELF
  self.VVdesl = VVdesl
  self.VVtMHe = []
  iMulSel = self.VVdesl.VVs9jW()
  if iMulSel : self.VVtMHe.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVtMHe.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVdesl.VVLHWg()
  self.VVtMHe.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVtMHe.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVtMHe.append(VVXGzj)
 def VVcQQV(self, extraMenu, cbFncDict, width=1000, okFnc=None, onMultiSelFnc=None):
  self.VVdesl.onMultiSelFnc = onMultiSelFnc
  if extraMenu:
   self.VVtMHe.extend(extraMenu)
  FFECK9(self.callingSELF, BF(self.VVv7IK, cbFncDict, okFnc), width=width, title="Options", VVtMHe=self.VVtMHe)
 def VVv7IK(self, cbFncDict, okFnc, item=None):
  if item:
   if   item == "multSelEnab" : self.VVdesl.VVrFVf(True)
   elif item == "MultSelDisab" : self.VVdesl.VVrFVf(False)
   elif item == "selectAll" : self.VVdesl.VVHCUx()
   elif item == "unselectAll" : self.VVdesl.VVXLvB()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
   if okFnc:
    okFnc()
class CCCoKO(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFPFsH(VVWjx3, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFRFZg(self)
  FFKdfz(self["keyRed"]  , "Exit")
  FFKdfz(self["keyGreen"]  , "Save")
  FFKdfz(self["keyYellow"] , "Refresh")
  FFKdfz(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(VVQOuY,
  {
   "red" : self.VV5TbA  ,
   "green" : self.VVzGk6 ,
   "yellow": self.VVvNvL  ,
   "blue" : self.VVsSz2   ,
   "up" : self.VV7yT6    ,
   "down" : self.VVjcLF   ,
   "left" : self.VViWA8   ,
   "right" : self.VVpaBZ   ,
   "cancel": self.VV5TbA
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VVnLQg)
  self.onClose.append(self.onExit)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  self.VVvNvL()
  self.VV0sXm()
  FFFlxX(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVWj3v)
  except:
   self.timer.callback.append(self.VVWj3v)
  self.timer.start(1000, False)
  self.VVWj3v()
 def onExit(self):
  self.timer.stop()
 def VV5TbA(self) : self.close(True)
 def VVnn9S(self) : self.close(False)
 def VVsSz2(self):
  self.session.openWithCallback(self.VVg1qb, BF(CCHGMt))
 def VVg1qb(self, closeAll):
  if closeAll:
   self.close()
 def VVWj3v(self):
  self["curTime"].setText(str(FFt4wC(iTime())))
 def VV7yT6(self):
  self.VVKnW2(1)
 def VVjcLF(self):
  self.VVKnW2(-1)
 def VViWA8(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VV0sXm()
 def VVpaBZ(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VV0sXm()
 def VVKnW2(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVsQ7T(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVsQ7T(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVsQ7T(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVTQ5Q(year)):
   days += 1
  return days
 def VVTQ5Q(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VV0sXm(self):
  for obj in self.list:
   FFC3pI(obj, "#11404040")
  FFC3pI(self.list[self.index], "#11ff8000")
 def VVvNvL(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVzGk6(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CC2xQD()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VV4Ip2)
 def VV4Ip2(self, result, retval):
  result = str(result.strip())
  if len(result) == 0 : FFDeF8(self, "Nothing returned from the system!")
  else    : FFDeF8(self, str(result))
class CCHGMt(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFPFsH(VVOcaS, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFRFZg(self, addLabel=True)
  FFKdfz(self["keyRed"]  , "Exit")
  FFKdfz(self["keyGreen"]  , "Sync")
  FFKdfz(self["keyYellow"] , "Refresh")
  FFKdfz(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(VVQOuY,
  {
   "red" : self.VV5TbA   ,
   "green" : self.VVR0Fh  ,
   "yellow": self.VV6Z1c ,
   "blue" : self.VVw0qb  ,
   "cancel": self.VV5TbA
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVZoVs()
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  FFFlxX(self)
  FFkvVR(self.VVd7T6)
 def VVd7T6(self):
  self.VV5l1k()
  self.VVZrbY(False)
 def VV5TbA(self)  : self.close(True)
 def VVw0qb(self) : self.close(False)
 def VVZoVs(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VV5l1k(self):
  self.VVEIHa()
  self.VVVLOs()
  self.VVNNIs()
  self.VVNPr2()
 def VV6Z1c(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVZoVs()
   self.VV5l1k()
   FFkvVR(self.VVd7T6)
 def VVR0Fh(self):
  if len(self["keyGreen"].getText()) > 0:
   FFgBNQ(self, self.VVbuwf, "Synchronize with Internet Date/Time ?")
 def VVbuwf(self):
  self.VV5l1k()
  FFkvVR(BF(self.VVZrbY, True))
 def VVEIHa(self)  : self["keyRed"].show()
 def VVmpT4(self)  : self["keyGreen"].show()
 def VVkox7(self) : self["keyYellow"].show()
 def VVXUzR(self)  : self["keyBlue"].show()
 def VVVLOs(self)  : self["keyGreen"].hide()
 def VVNNIs(self) : self["keyYellow"].hide()
 def VVNPr2(self)  : self["keyBlue"].hide()
 def VVZrbY(self, sync):
  localTime = FFQs05()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVtNbf(server)
   if epoch_time is not None:
    ntpTime = FFt4wC(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CC2xQD()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VV4Ip2, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVkox7()
  self.VVXUzR()
  if ok:
   self.VVmpT4()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VV4Ip2(self, syncAgain, result, retval):
  result = str(result.strip())
  if   len(result) == 0  : result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20: result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVZrbY(False)
  except:
   pass
 def VVtNbf(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if CCFewM.VVmB13():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCXjzw(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFPFsH(VVLuHh, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FFRFZg(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFkvVR(self.VVTa6R)
 def VVTa6R(self):
  if CCFewM.VVmB13() : color, txt = "#22002020", "Internet Connection = Successful."
  else     : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFC3pI(self["myBody"], color)
   FFC3pI(self["myLabel"], color)
  except:
   pass
class CC1y6w(Screen):
 VVTV70 = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFrRKK()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFPFsH(VVlRaw, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CC7NtP(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CC7NtP(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CC7NtP(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCCDSZ()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFRFZg(self, title="Signal")
  self["myActionMap"] = ActionMap(VVQOuY,
  {
   "ok"  : self.close      ,
   "up"  : self.VV7yT6       ,
   "down"  : self.VVjcLF      ,
   "left"  : self.VViWA8      ,
   "right"  : self.VVpaBZ      ,
   "info"  : self.VVPgrz     ,
   "epg"  : self.VVPgrz     ,
   "menu"  : self.VVU5Zj      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VVRK3J, -1)  ,
   "next"  : BF(self.VVRK3J, 1)  ,
   "pageUp" : BF(self.VVE0ot, True) ,
   "chanUp" : BF(self.VVE0ot, True) ,
   "pageDown" : BF(self.VVE0ot, False) ,
   "chanDown" : BF(self.VVE0ot, False) ,
   "0"   : BF(self.VVRK3J, 0)  ,
   "1"   : BF(self.VVtOrA, pos=1) ,
   "2"   : BF(self.VVtOrA, pos=2) ,
   "3"   : BF(self.VVtOrA, pos=3) ,
   "4"   : BF(self.VVtOrA, pos=4) ,
   "5"   : BF(self.VVtOrA, pos=5) ,
   "6"   : BF(self.VVtOrA, pos=6) ,
   "7"   : BF(self.VVtOrA, pos=7) ,
   "8"   : BF(self.VVtOrA, pos=8) ,
   "9"   : BF(self.VVtOrA, pos=9) ,
  }, -1)
  self.onShown.append(self.VVnLQg)
  self.onClose.append(self.onExit)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  if not CC1y6w.VVTV70:
   CC1y6w.VVTV70 = self
  self.sliderSNR.VVpjuz()
  self.sliderAGC.VVpjuz()
  self.sliderBER.VVpjuz(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVtOrA()
  self.VVGpn0()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VViAXy)
  except:
   self.timer.callback.append(self.VViAXy)
  self.timer.start(500, False)
 def VVGpn0(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVPbWD(service)
  serviceName = self.tunerInfo.VVPSN9()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
  tp = CCMbXb()
  tpTxt, satTxt = tp.VVe2ir(refCode)
  if tpTxt == "?" :
   tpTxt = FF8oA9("NO SIGNAL", VVtchu)
  self["myTPInfo"].setText(tpTxt + "  " + FF8oA9(satTxt, VVRuOi))
 def VViAXy(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVPbWD(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VViHbF())
   self["mySNR"].setText(self.tunerInfo.VVjS80())
   self["myAGC"].setText(self.tunerInfo.VVec9U())
   self["myBER"].setText(self.tunerInfo.VVLAwp())
   self.sliderSNR.VVx3o6(self.tunerInfo.VVLNrQ())
   self.sliderAGC.VVx3o6(self.tunerInfo.VVN3cP())
   self.sliderBER.VVx3o6(self.tunerInfo.VV12M4())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVx3o6(0)
   self.sliderAGC.VVx3o6(0)
   self.sliderBER.VVx3o6(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
    if state and not state == "Tuned":
     FFZD7H(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVPgrz(self):
  FF1wB7(self, fncMode=CCqIel.VViWfB)
 def VVU5Zj(self):
  FFSnt9(self, "_help_signal", "Signal Monitor (Keys)")
 def VV7yT6(self)  : self.VVtOrA(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVjcLF(self) : self.VVtOrA(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VViWA8(self) : self.VVtOrA(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVpaBZ(self) : self.VVtOrA(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVtOrA(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FF0UO9(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVRK3J(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFOaVa(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FF0UO9(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CC1y6w.VVTV70 = None
 def VVE0ot(self, isUp):
  FFZD7H(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVGpn0()
  except:
   pass
class CC7NtP(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVpjuz(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFC3pI(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VV2V68 +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFC3pI(self.covObj, self.covColor)
   else:
    FFC3pI(self.covObj, "#00006688")
    self.isColormode = True
  self.VVx3o6(0)
 def VVx3o6(self, val):
  val  = FFOaVa(val, self.minN, self.maxN)
  width = int(FFYZmF(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFOaVa(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCjWUz(Screen):
 VVJmH5    = 0
 VVh7HE = 1
 VVp7fs = 2
 def __init__(self, session, titlePrefix="Processing ...", endTitle="Finishing ...", fncToRun=None, VVCBqA=None, barTheme=VVJmH5, titleBg="#0a042328", bodyBg="#0a042328"):
  ratio = self.VVU7iw(barTheme)
  self.skin, self.skinParam = FFPFsH(VVcx2a, 900, 200, 30, 40, 30, titleBg, bodyBg, 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.endTitle  = endTitle
  self.fncToRun  = fncToRun
  self.VVCBqA = VVCBqA
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVpwcW = None
  self.timer   = eTimer()
  self.myThread  = None
  FFRFZg(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(VVQOuY, { "cancel" : self.cancel }, -1)
  self.onShown.append(self.VVnLQg)
  self.onClose.append(self.onExit)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  self.VV7Nrm()
  self["myProgBarVal"].setText("0%")
  FFC3pI(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVmLUQ()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVmLUQ)
  except:
   self.timer.callback.append(self.VVmLUQ)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VV0amK(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VV51IW(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVpwcW), self.counter, self.maxValue, catName)
 def VVmvzP(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVp98U(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VVmLrY(self, tot, evName):
  self.newTitle = "Translated: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, evName)
 def VVEJLg(self, action, tot, name):
  self.newTitle = "%s: %d   ... %d/%d >> %s" % (action, tot, self.counter, self.maxValue, name)
 def VVzN3b(self, tot, name):
  self.newTitle = "Added: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, name)
 def VVXtf8(self, txt):
  self.newTitle = txt
 def VViyfK(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VVpwcW), self.counter, self.maxValue)
  except:
   pass
 def VVta6S(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVoP8T(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VV3FZH(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFZD7H(self, "Cancelling ...")
  self.isCancelled = True
  self.VV5uIH(False)
 def VV5uIH(self, isDone):
  FFkvVR(BF(self.VVfZWc, isDone))
 def VVfZWc(self, isDone):
  if self.VVCBqA:
   self.VVCBqA(isDone, self.VVpwcW, self.counter, self.maxValue, self.isError)
  self.close()
 def VVmLUQ(self):
  val = FFOaVa(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFYZmF(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self["myTitle"].setText("  %s  " % self.endTitle)
    self.VV5uIH(True)
 def VV7Nrm(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVh7HE, self.VVp7fs):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVU7iw(self, barTheme):
  if   barTheme == self.VVh7HE : return 0.7
  if   barTheme == self.VVp7fs : return 0.5
  else             : return 1
class CC2xQD(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVCBqA = {}
  self.commandRunning = False
  self.VVlAOK  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVCBqA, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVCBqA[name] = VVCBqA
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVlAOK:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVTj5K, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVz2rX , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVTj5K, name))
    self.appContainers[name].appClosed.append(BF(self.VVz2rX , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVz2rX(name, retval)
  return True
 def VVTj5K(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FF8oA9("[UN-DECODED STRING]", VVtchu))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVz2rX(self, name, retval):
  if not self.VVlAOK:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVCBqA[name]:
   self.VVCBqA[name](self.appResults[name], retval)
  del self.VVCBqA[name]
 def VV5K8g(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCiDJP(Screen):
 def __init__(self, session, title="", VVpHRB=None, VVZ1xV=False, VV2zzG=False, VVAex6=False, VVmYZV=False, VVUp7w=False, VVaFca=False, VVSDbk=VVCv9j, VV4qLc=None, VVaVe1=False, VVYGxa=None, VVWiG3="", checkNetAccess=False, VVGNdU=30, consFont=False, enableSaveRes=True):
  self.skin, self.skinParam = FFPFsH(VVNC84, 1600, 1000, 50, 40, 20, "#22003040", "#22001122", VVGNdU, usefixedFont=consFont)
  self.session   = session
  self.VVWiG3 = VVWiG3
  FFRFZg(self, addScrollLabel=True)
  self.VVZ1xV   = VVZ1xV
  self.VV2zzG   = VV2zzG
  self.VVAex6   = VVAex6
  self.VVmYZV  = VVmYZV
  self.VVUp7w = VVUp7w
  self.VVaFca = VVaFca
  self.VVSDbk   = VVSDbk
  self.VV4qLc = VV4qLc
  self.VVaVe1  = VVaVe1
  self.VVYGxa  = VVYGxa
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CC2xQD()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFmlRV()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVpHRB, str):
   self.VVpHRB = [VVpHRB]
  else:
   self.VVpHRB = VVpHRB
  if self.VVAex6 or self.VVmYZV:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (SEP, SEP)
   self.VVpHRB.append("echo -e '\n%s\n' %s" % (restartNote, FFP1gK(restartNote, VVXAXH)))
   if self.VVAex6:
    self.VVpHRB.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVpHRB.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVUp7w:
   FFZD7H(self, "Processing ...")
  self.onLayoutFinish.append(self.VVZoty)
  self.onClose.append(self.VVOhbx)
 def VVZoty(self):
  self["myLabel"].VV4U7z(outputFileToSave="console" if self.enableSaveRes else "")
  self["myLabel"].setText("   %s" % (self.VVWiG3 or "Processing ..."))
  if self.VVZ1xV:
   self["myLabel"].VVo5pW()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVStli()
  else:
   self.VVDVDo()
 def VVStli(self):
  if CCFewM.VVmB13():
   self["myLabel"].setText("Processing ...")
   self.VVDVDo()
  else:
   self["myLabel"].setText(FF8oA9("\n   No connection to internet!", VV8ETX))
 def VVDVDo(self):
  allOK = self.container.ePopen(self.VVpHRB[0], self.VVcp4b, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVcp4b("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVaFca or self.VVAex6 or self.VVmYZV:
    self["myLabel"].setText(FFHM5m("STARTED", VVXAXH) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVYGxa:
   colorWhite = CCtoHe.VVsjz9(VV7V3G)
   color  = CCtoHe.VVsjz9(self.VVYGxa[0])
   words  = self.VVYGxa[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVSDbk=self.VVSDbk)
 def VVcp4b(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVpHRB):
   allOK = self.container.ePopen(self.VVpHRB[self.cmdNum], self.VVcp4b, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVcp4b("Cannot connect to Console!", -1)
  else:
   if self.VVUp7w and FFDiFh(self):
    FFZD7H(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVaFca:
    self["myLabel"].appendText("\n" + FFHM5m("FINISHED", VVXAXH), self.VVSDbk)
   if self.VVZ1xV or self.VV2zzG:
    self["myLabel"].VVo5pW()
   if self.VV4qLc is not None:
    self.VV4qLc()
   if not retval and self.VVaVe1:
    self.VVOhbx()
 def VVOhbx(self):
  if self.container.VV5K8g():
   self.container.killAll()
class CCptmR(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFPFsH(VVNC84, 1650, 950, 40, 20, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVZAJU + "ajpanel_terminal.history"
  self.customCommandsFile = ""
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFvL4V("pwd") or "/home/root"
  self.container   = CC2xQD()
  self.commandsList  = []
  self.exitBtnText  = "Exit = Interrupt"
  FFRFZg(self, title="Terminal", addScrollLabel=True)
  FFKdfz(self["keyRed"] , self.exitBtnText)
  FFKdfz(self["keyGreen"] , "OK = History")
  FFKdfz(self["keyYellow"], "Menu = Custom Cmds")
  FFKdfz(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok" : self.VVkPN0 ,
   "cancel": self.VVS4l2  ,
   "menu" : self.VVll2M ,
   "last" : self.VVCGV8  ,
   "next" : self.VVCGV8  ,
   "1"  : self.VVCGV8  ,
   "2"  : self.VVCGV8  ,
   "3"  : self.VVCGV8  ,
   "4"  : self.VVCGV8  ,
   "5"  : self.VVCGV8  ,
   "6"  : self.VVCGV8  ,
   "7"  : self.VVCGV8  ,
   "8"  : self.VVCGV8  ,
   "9"  : self.VVCGV8  ,
   "0"  : self.VVCGV8
  })
  self.onLayoutFinish.append(self.VVnLQg)
  self.onClose.append(self.VVV59e)
 def VVnLQg(self):
  self["myLabel"].VV4U7z(isResizable=False, outputFileToSave="terminal")
  FF0TXZ(self["keyRed"]  , "#00ff8000")
  FFC3pI(self["keyRed"]  , self.skinParam["titleColor"])
  FFC3pI(self["keyGreen"]  , self.skinParam["titleColor"])
  FFC3pI(self["keyYellow"] , self.skinParam["titleColor"])
  FFC3pI(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVsXLm(FFvL4V("date"), 5)
  result = FFvL4V("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVQarA()
  self.VVn0y8()
 def VVn0y8(self):
  userFile = CFG.terminalCmdFile.getValue()
  alterFile = VVZAJU + "LinuxCommands.lst"
  templPath = VV2V68 + "ajpanel_cmd_list"
  if   fileExists(userFile) : self.customCommandsFile = userFile
  elif fileExists(alterFile): self.customCommandsFile = alterFile
  else:
   if not FFqSkC("cp -f '%s' '%s'" % (templPath, alterFile)):
    FFmiBl("echo -e 'pwd\ncd\ncd /tmp\nls\nls -ls' > '%s'" % alterFile)
   self.customCommandsFile = alterFile
 def VVV59e(self):
  if self.container.VV5K8g():
   self.container.killAll()
   self.VVsXLm("Process killed\n", 4)
   self.VVQarA()
 def VVS4l2(self):
  if self.container.VV5K8g():
   self.VVV59e()
  else:
   FFgBNQ(self, self.close, "Exit ?", VVJ9WI=False)
 def VVQarA(self):
  self.VVsXLm(self.prompt, 1)
  self["keyRed"].hide()
 def VVsXLm(self, txt, mode):
  if   mode == 1 : color = VVXAXH
  elif mode == 2 : color = VVoIYV
  elif mode == 3 : color = VV7V3G
  elif mode == 4 : color = VV8ETX
  elif mode == 5 : color = VVD4un
  elif mode == 6 : color = VVdZck
  else   : color = VV7V3G
  try:
   self["myLabel"].appendText(FF8oA9(txt, color))
  except:
   pass
 def VVkPN0(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VV9JQp() == "":
   self.VVdyvJ("cd /tmp")
   self.VVdyvJ("ls")
  VVsLLE = []
  if fileExists(self.commandHistoryFile):
   lines  = FF72md(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVsLLE.append((str(c), line, str(lNum)))
   self.VVLurz(VVsLLE, title, self.commandHistoryFile, isHistory=True)
  else:
   FFbiIe(self, self.commandHistoryFile, title=title)
 def VV9JQp(self):
  lastLine = FFvL4V("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVdyvJ(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVll2M(self, VVdesl=None):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines = FF72md(self.customCommandsFile)
   VVsLLE = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVsLLE.append((str(c), line, str(lNum)))
   if VVdesl:
    VVdesl.VV87pY(VVsLLE)
    VVdesl.VVTklH(CFG.lastTerminalCustCmdLineNum.getValue())
   else:
    self.VVLurz(VVsLLE, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFbiIe(self, self.customCommandsFile, title=title)
 def VVLurz(self, VVsLLE, title, filePath=None, isHistory=False):
  if VVsLLE:
   VVYCZ6 = "#05333333"
   if isHistory: VVaRsg = VVWgai = VVSJJk = "#11000020"
   else  : VVaRsg = VVWgai = VVSJJk = "#06002020"
   VVMWQK   = ("Send"   , BF(self.VVbe97, isHistory)  , [])
   VV1kWx  = ("Modify & Send" , self.VVTi7D     , [])
   if isHistory:
    VVM9Pm = ("Clear History" , self.VV1xr5     , [])
    VVRHhw = None
    VVZArZ = None
   elif filePath:
    VVM9Pm = ("Options"  , self.VVOdY0      , [])
    VVRHhw = ("Edit File"  , BF(self.VVLvBZ, filePath) , [])
    VVZArZ = (""    , self.VVYZYs     , [])
   header  = ("No." , "Commands", "LineNum" )
   widths  = (7  , 93   , 0    )
   VV0CnX = (CENTER , LEFT   , CENTER )
   VVdesl = FFDpub(self, None, title=title, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=26, VVMWQK=VVMWQK, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw, VVZArZ=VVZArZ, lastFindConfigObj=CFG.lastFindTerminal, VVEMdg=True, searchCol=1
         , VVaRsg=VVaRsg, VVWgai=VVWgai, VVSJJk=VVSJJk, VVYCZ6=VVYCZ6)
   if not isHistory:
    VVdesl.VVTklH(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FFgBNQ(self, BF(self.VVYs1y, None, "Change Custom Commands File"), "File is empty:\n\n%s\n\nSelect another file ?" % self.customCommandsFile, title=title)
 def VVYZYs(self, VVdesl, title, txt, colList):
  txt  = "%s\n%s\n\n" % (FF8oA9("Command:", VVRuOi), colList[1])
  txt += "%s\n%s\n\n" % (FF8oA9("Line %s in File:" % colList[2], VVRuOi), self.customCommandsFile)
  FFoB4k(self, txt, title=title)
 def VVOdY0(self, VVdesl, title, txt, colList):
  mSel = CCB2u5(self, VVdesl)
  VVtMHe = []
  txt1 = "Change Custom Commands File"
  if VVdesl.VVcTnU:
   VVtMHe.append((txt1, ))
   VVtMHe.append(VVXGzj)
   totSel = VVdesl.VVLHWg()
   totTxt = str(totSel)
   txt2 = "Send %s Command%s" % (FF8oA9(totTxt, VVXAXH) if totSel else totTxt, FFsfSO(totSel))
   VVtMHe.append((txt2, "send") if totSel else (txt2,))
  else:
   VVtMHe.append((txt1, "newFile"))
   VVtMHe.append(VVXGzj)
   txt2 = "Send current line"
   VVtMHe.append((txt2, "send"))
  cbFncDict = { "newFile" : BF(self.VVYs1y, VVdesl, txt1)
     , "send" : BF(self.VVbe97, False, VVdesl, title, txt2, colList) }
  mSel.VVcQQV(VVtMHe, cbFncDict, okFnc=BF(self.VVSjDu, VVdesl))
 def VVYs1y(self, VVdesl, title):
  VVtMHe = []
  for fName in os.listdir(VVZAJU):
   path = os.path.join(VVZAJU, fName)
   if fName.lower().startswith(("ajpanel_cmd", "linuxcommands")) and os.path.isfile(path):
    VVtMHe.append((fName, path))
  VVtMHe.sort(key=lambda x: x[0].lower())
  if VVtMHe : FFECK9(self, BF(self.VVU4e8, VVdesl, title), VVtMHe=VVtMHe, title=title, minRows=3, VVaRsg="#11220000", VVWgai="#11220000")
  else  : FFOyl1(self, "No valid files found in:\n\n%s" % VVZAJU, title=title)
 def VVU4e8(self, VVdesl, title, path=None):
  if path:
   if CCVnYx.VVq7OD(path):
    FFOyl1(self, "Incorrect file format:\n\n%s" % path, title=title)
   else:
    lines = FF72md(path)
    for line in lines:
     if line.strip():
      oldF = self.customCommandsFile
      self.customCommandsFile = path
      FF0UO9(CFG.terminalCmdFile, path)
      if not oldF == self.customCommandsFile:
       FF0UO9(CFG.lastTerminalCustCmdLineNum, 0)
      self.VVll2M(VVdesl)
      break
    else:
     FFOyl1(self, "File is empty:\n\n%s" % path, title=title)
 def VVSjDu(self, VVdesl):
  if VVdesl.VVcTnU : VVdesl.VVNvGq()
  else        : VVdesl.VVQUuA()
 def VVbe97(self, isHistory, VVdesl, title, txt, colList):
  if VVdesl.VVcTnU:
   lst = VVdesl.VVLRcj(1)
   curNdx = VVdesl.VVP9ZS()
  else:
   lst = [colList[1]]
   curNdx = VVdesl.VVvapY()
  if not isHistory:
   FF0UO9(CFG.lastTerminalCustCmdLineNum, curNdx)
  self.commandsList = lst
  VVdesl.cancel()
  FFkvVR(self.VVKZiV)
 def VVKZiV(self):
  if self.commandsList:
   cmd = self.commandsList[0]
   self.commandsList.pop(0)
   if not iMatch("^[a-zA-Z0-9_]", cmd):
    self.VVsXLm("\n%s\n" % cmd, 6)
    self.VVsXLm(self.prompt, 1)
    self.VVKZiV()
   else:
    self.VVUKnM(cmd)
 def VVUKnM(self, cmd):
  tot = len(self.commandsList)
  self["keyRed"].setText("%s%s" % (self.exitBtnText, " (%s)" % tot if tot > 0 else ""))
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVsXLm(cmd, 2)
   self.VVsXLm("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVsXLm(ch, 0)
   self.VVsXLm("\nor\n", 4)
   self.VVsXLm("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVQarA()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FF8oA9(parts[0].strip(), VVoIYV)
    right = FF8oA9("#" + parts[1].strip(), VVdZck)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVsXLm(txt, 2)
   lastLine = self.VV9JQp()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVdyvJ(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVcp4b, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFOyl1(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVsXLm(data, 3)
 def VVcp4b(self, data, retval):
  if not retval == 0:
   self.VVsXLm("Exit Code : %d\n" % retval, 4)
  self.VVQarA()
  if self.commandsList:
   self.VVKZiV()
 def VVTi7D(self, VVdesl, title, txt, colList):
  if VVdesl.VVyYwz():
   cmd = colList[1]
   self.VVQsAL(VVdesl, cmd)
 def VV1xr5(self, VVdesl, title, txt, colList):
  FFgBNQ(self, BF(self.VVntYa, VVdesl), "Reset History File ?", title="Command History")
 def VVntYa(self, VVdesl):
  FFmiBl("> '%s'" % self.commandHistoryFile)
  VVdesl.cancel()
 def VVLvBZ(self, filePath, VVdesl, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCiazU(self, filePath, VVCBqA=BF(self.VVwZ9O, VVdesl), curRowNum=rowNum)
  else     : FFbiIe(self, filePath)
 def VVwZ9O(self, VVdesl, fileChanged):
  if fileChanged:
   VVdesl.cancel()
   FFkvVR(self.VVll2M)
 def VVCGV8(self):
  self.VVQsAL(None, self.lastCommand)
 def VVQsAL(self, VVdesl, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFdnKb(self, BF(self.VVuEN4, VVdesl), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVuEN4(self, VVdesl, cmd):
  if cmd and len(cmd) > 0:
   self.VVUKnM(cmd)
   if VVdesl:
    VVdesl.cancel()
class CCL9Lj(Screen):
 def __init__(self, session, title="", message="", VVSDbk=VVCv9j, width=1400, height=900, VVi6aX=False, titleBg="#22002020", VVSJJk="#22001122", VVGNdU=30, titleFontSize=50, outputFileToSave=""):
  self.skin, self.skinParam = FFPFsH(VVNC84, width, height, titleFontSize, 30, 20, titleBg, VVSJJk, VVGNdU)
  self.session   = session
  FFRFZg(self, title, addScrollLabel=True)
  self.VVSDbk   = VVSDbk
  self.VVi6aX   = VVi6aX
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  self["myLabel"].VV4U7z(VVi6aX=self.VVi6aX, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VVSDbk)
  self["myLabel"].VVo5pW()
class CCr9QV(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FFPFsH(VVoPgW, 1800, 60, 30, 30, 20, "#55000000", "#ff000000", 30)
  self.session  = session
  self.txt   = txt
  self["myWinTitle"] = Label()
  FFRFZg(self, " ", addCloser=True)
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  CC817S.VVLCo1(self, self.txt)
  self.instance.move(ePoint((getDesktop(0).size().width() - self.instance.size().width()) // 2, 20))
class CCCIsI(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFPFsH(VVC9dH, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFRFZg(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFl0wi(self["errPic"], "err")
class CCQGt9(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFPFsH(VVoPgW, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label()
  FFRFZg(self, " ", addCloser=True)
class CC817S():
 def __init__(self, session, txt, timeout=1500, fonSize=24):
  self.session = session
  self.win  = CC817S.VVVwYM(session, txt, fonSize)
  self.timer  = eTimer()
  try: self.timer_conn = self.timer.timeout.connect(self.VVIDHk)
  except: self.timer.callback.append(self.VVIDHk)
  self.timer.start(timeout, True)
 def VVIDHk(self):
  self.session.deleteDialog(self.win)
 @staticmethod
 def VVVwYM(session, txt, fonSize, shadW=2, shadColor="#440000", x=30, y=20):
  win = session.instantiateDialog(CCQGt9, txt.strip(), fonSize)
  win.instance.move(ePoint(x, y))
  win.show()
  FFMf5R(win["myWinTitle"], shadColor, shadW)
  CC817S.VVLCo1(win, txt)
  return win
 @staticmethod
 def VVLCo1(win, txt):
  win["myWinTitle"].setText(txt.strip())
  inst = win["myWinTitle"].instance
  w = inst.calculateSize().width() + 30
  h = int(inst.size().height())
  inst.resize(eSize(*(w, h)))
  win.instance.resize(eSize(*(w, h)))
class CCEvBr():
 VVHIEb    = 0
 VVnAN4  = 1
 VVRuqp   = ""
 VVcM1N    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVdesl   = None
  self.timer     = eTimer()
  self.VVCxxx   = 0
  self.VV1L96  = 1
  self.VVxhbz  = 2
  self.VVO0ZJ   = 3
  self.VVCLUR   = 4
  VVsLLE = self.VVoWct()
  if VVsLLE:
   self.VVdesl = self.VVXD8w(VVsLLE)
  if not VVsLLE and mode == self.VVHIEb:
   self.VVoafo("Download list is empty !")
   self.cancel()
  if mode == self.VVnAN4:
   FFbA1i(self.VVdesl or self.SELF, BF(self.VVZeHp, startDnld, decodedUrl), title="Checking Server ...")
  self.VV47T8(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV47T8)
  except:
   self.timer.callback.append(self.VV47T8)
  self.timer.start(1000, False)
 def VVXD8w(self, VVsLLE):
  VVsLLE.sort(key=lambda x: int(x[0]))
  VVJi29 = self.VVGJo1
  VVMWQK  = ("Play"  , self.VVtKUv , [])
  VVZArZ = (""   , self.VVH4YK  , [])
  VVIzUv = ("Stop"  , self.VVHh2t  , [])
  VV1kWx = ("Resume"  , self.VVuFgE , [])
  VVM9Pm = ("Options" , self.VVrZeY  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VV0CnX  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFDpub(self.SELF, None, title=self.Title, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=26, VVMWQK=VVMWQK, VVZArZ=VVZArZ, VVJi29=VVJi29, VVIzUv=VVIzUv, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, lastFindConfigObj=CFG.lastFindIptv, VVaRsg="#11220022", VVWgai="#11110011", VVSJJk="#11110011", VVYCZ6="#00223025", VVTjte="#0a333333", VVIyj7="#0a400040", VVEMdg=True, searchCol=1)
 def VVoWct(self):
  lines = CCEvBr.VVUrGU()
  VVsLLE = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VV4vsl(decodedUrl)
      if fName:
       if   FFf4jh(decodedUrl) : sType = "Movie"
       elif FFGpT0(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVYKxy(decodedUrl, fName)
       if size > -1: sizeTxt = CCVnYx.VVI3LQ(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVsLLE.append((str(len(VVsLLE) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVsLLE
 def VV3oAz(self):
  VVsLLE = self.VVoWct()
  if VVsLLE:
   if self.VVdesl : self.VVdesl.VV87pY(VVsLLE, VVZoVsMsg=False)
   else     : self.VVdesl = self.VVXD8w(VVsLLE)
  else:
   self.cancel()
 def VV47T8(self, force=False):
  if self.VVdesl:
   thrListUrls = self.VVvqbV()
   VVsLLE = []
   changed = False
   for ndx, row in enumerate(self.VVdesl.VVTW2g()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVCxxx
    if m3u8Log:
     percent = CCEvBr.VVMYPh(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVO0ZJ , "%.2f %%" % percent
      else   : flag, progr = self.VVCLUR , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFF0Rr(mPath)
     if curSize > -1:
      fSize = CCVnYx.VVI3LQ(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCVnYx.VVI3LQ(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFF0Rr(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVO0ZJ , "%.2f %%" % percent
       else   : flag, progr = self.VVCLUR , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCVnYx.VVI3LQ(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VVxhbz
     if m3u8Log :
      if not speed and not force : flag = self.VV1L96
      elif curSize == -1   : self.VVU8aK(False)
    elif flag == self.VVCxxx  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVCxxx  : color2 = "#f#00555555#"
    elif flag == self.VV1L96 : color2 = "#f#0000FFFF#"
    elif flag == self.VVxhbz : color2 = "#f#0000FFFF#"
    elif flag == self.VVO0ZJ  : color2 = "#f#00FF8000#"
    elif flag == self.VVCLUR  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVU3eY(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVsLLE.append(row)
   if changed or force:
    self.VVdesl.VV87pY(VVsLLE, VVZoVsMsg=False)
 def VVU3eY(self, flag):
  tDict = self.VVtzxU()
  return tDict.get(flag, "?")
 def VVRQHA(self, state):
  for flag, txt in self.VVtzxU().items():
   if txt == state:
    return flag
  return -1
 def VVtzxU(self):
  return { self.VVCxxx: "Not started", self.VV1L96: "Connecting", self.VVxhbz: "Downloading", self.VVO0ZJ: "Stopped", self.VVCLUR: "Completed" }
 def VVj7Sg(self, title):
  colList = self.VVdesl.VV1blE()
  path = colList[6]
  url  = colList[8]
  if self.VVFOGS() : self.VVoafo("Cannot delete !\n\nFile is downloading.")
  else      : FFgBNQ(self.SELF, BF(self.VV4tJd, path, url), "Delete ?\n\n%s" % path, title=title)
 def VV4tJd(self, path, url):
  m3u8Log = self.VVdesl.VV1blE()[12]
  if m3u8Log : FFqSkC("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  else  : FFqSkC("rm -rf '%s'" % path)
  self.VVVQeb(False)
  self.VV3oAz()
 def VVVQeb(self, VVl1IZ=True):
  if self.VVFOGS():
   FFZD7H(self.VVdesl, self.VVU3eY(self.VVxhbz), 500)
  else:
   colList  = self.VVdesl.VV1blE()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VVRQHA(state) in (self.VVCxxx, self.VVCLUR, self.VVO0ZJ):
    lines = CCEvBr.VVUrGU()
    newLines = []
    found = False
    for line in lines:
     if CCEvBr.VVdmk9(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VV6tOT(newLines)
     self.VV3oAz()
     FFZD7H(self.VVdesl, "Removed.", 1000)
    else:
     FFZD7H(self.VVdesl, "Not found.", 1000)
   elif VVl1IZ:
    self.VVoafo("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVWfPC(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFgBNQ(self.SELF, BF(self.VV8hgv, flag), ques, title=title)
 def VV8hgv(self, flag):
  list = []
  for ndx, row in enumerate(self.VVdesl.VVTW2g()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVRQHA(state)
   if   flag == flagVal == self.VVCLUR: list.append(decodedUrl)
   elif flag == flagVal == self.VVCxxx : list.append(decodedUrl)
  lines = CCEvBr.VVUrGU()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VV6tOT(newLines)
   self.VV3oAz()
   FFZD7H(self.VVdesl, "%d removed." % totRem, 1000)
  else:
   FFZD7H(self.VVdesl, "Not found.", 1000)
 def VVQCxb(self):
  colList  = self.VVdesl.VV1blE()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFZD7H(self.VVdesl, "Poster exists", 1500)
  else    : FFbA1i(self.VVdesl, BF(self.VVhjSq, decodedUrl, path, png), title="Checking Server ...")
 def VVhjSq(self, decodedUrl, path, png):
  err = self.VV2oBg(decodedUrl, path, png)
  if err:
   FFOyl1(self.SELF, err, title="Poster Download")
 def VV2oBg(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCOGg2.VVY8JV(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCoUhv.VV1JTf(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCoUhv.VVnY0U(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCoUhv.VVGIa1(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FF4VyK(pUrl, "ajp_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   FFqSkC("mv -f '%s' '%s'" % (tPath, png))
   CCXzC3.VVHZ7h(self.SELF, VVlNrK=png, showGrnMsg="Downloaded")
   return ""
 def VVH4YK(self, VVdesl, title, txt, colList):
  def VVc2G6(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVYgG4(key, val) : return "\n%s:\n%s\n" % (FF8oA9(key, VVRuOi), val.strip())
  heads  = self.VVdesl.VVoZ97()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVc2G6(heads[i]  , CCVnYx.VVI3LQ(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVc2G6("Downloaded" , CCVnYx.VVI3LQ(int(curSize), mode=0))
   else:
    txt += VVc2G6(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVYgG4(heads[i], colList[i])
  FFoB4k(self.SELF, txt, title=title)
 def VVtKUv(self, VVdesl, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCVnYx.VVWQNk(self.SELF, path)
  else    : FFZD7H(self.VVdesl, "File not found", 1000)
 def VVGJo1(self, VVdesl):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVdesl:
   self.VVdesl.cancel()
  del self
 def VVrZeY(self, VVdesl, title, txt, colList):
  c1, c2, c3 = VV4mV2, VV8ETX, VVRuOi
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVtMHe = []
  VVtMHe.append((c1 + "Remove current row"       , "VVVQeb" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVtMHe.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((c2 + "Delete the file (and remove from list)"  , "VVj7Sg"))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((resumeTxt + " Auto Resume"       , "VVpa46" ))
  VVtMHe.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVtMHe.append(VVXGzj)
  cond = FFf4jh(decodedUrl)
  VVtMHe.append(FFQlwu("Download Movie Poster %s" % ("(from server)" if cond else "... Movies only"), "VVQCxb", cond, c3))
  VVtMHe.append(FFQlwu("Open in File Manager", "inFileMan,%s" % path, fileExists(path), c3))
  FFECK9(self.SELF, BF(self.VVEsUA, VVdesl), VVtMHe=VVtMHe, title=self.Title, VVIZXB=True, width=800, VVy2u1=True, VVaRsg="#1a001122", VVWgai="#1a001122")
 def VVEsUA(self, VVdesl, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVVQeb"  : self.VVVQeb()
   elif ref == "remFinished"   : self.VVWfPC(self.VVCLUR, txt)
   elif ref == "remPending"   : self.VVWfPC(self.VVCxxx, txt)
   elif ref == "VVj7Sg" : self.VVj7Sg(txt)
   elif ref == "VVQCxb"  : self.VVQCxb()
   elif ref == "VVpa46"  : FF0UO9(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FF0UO9(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CCVnYx, mode=CCVnYx.VVcJJB, jumpToFile=path)
    else    : FFZD7H(VVdesl, "Path not found !", 1500)
 def VVZeHp(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCOGg2.VVY8JV(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVoafo("Could not get download link !\n\nTry again later.")
     return
  for line in CCEvBr.VVUrGU():
   if CCEvBr.VVdmk9(decodedUrl, line):
    if self.VVdesl:
     self.VVDzGl(decodedUrl)
     FFkvVR(BF(FFZD7H, self.VVdesl, "Already listed !", 2000))
    break
  else:
   params = self.VVkWyf(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVoafo(params[0])
   elif len(params) == 2:
    FFgBNQ(self.SELF, BF(self.VVR0D8, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCVnYx.VVI3LQ(fSize)
    FFgBNQ(self.SELF, BF(self.VVLm9g, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVLm9g(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCEvBr.VVEGoI(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VV3oAz()
  if self.VVdesl:
   self.VVdesl.VVenHM()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCEvBr.VVcM1N, path, decodedUrl)
   self.VVu2Fq(threadName, url, decodedUrl, path, resp)
 def VVDzGl(self, decodedUrl):
  if self.VVdesl:
   for ndx, row in enumerate(self.VVdesl.VVTW2g()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVdesl:
     self.VVdesl.VVTklH(ndx)
     break
 def VVkWyf(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VV4vsl(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVYKxy(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCOGg2.VVY8JV(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCOGg2.VVhc7i()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCEvBr.VVKihe(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCEvBr.VVdtZz(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVR0D8(self, resp, decodedUrl):
  if not FFLsle("ffmpeg"):
   FFgBNQ(self.SELF, BF(CCoUhv.VVMeQ3, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VV4vsl(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVDQGm(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFgBNQ(self.SELF, BF(self.VV9XIm, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VV9XIm(rTxt, rUrl)
  else:
   self.VVoafo("Cannot process m3u8 file !")
 def VVDQGm(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVtMHe = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCoUhv.VVYQAD(rUrl, fPath)
   VVtMHe.append((resol, fullUrl))
  if VVtMHe:
   FFECK9(self.SELF, self.VV5u17, VVtMHe=VVtMHe, title="Resolution", VVIZXB=True, VVy2u1=True)
  else:
   self.VVoafo("Cannot get Resolutions list from server !")
 def VV5u17(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFgBNQ(self.SELF, BF(FFkvVR, BF(self.VV8Ud8, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFkvVR(BF(self.VV8Ud8, resolUrl))
 def VV8Ud8(self, resolUrl):
  txt, err = CCOGg2.VVJ9oy(resolUrl)
  if err : self.VVoafo(err)
  else : self.VV9XIm(txt, resolUrl)
 def VVrA75(self, logF, decodedUrl):
  found = False
  lines = CCEvBr.VVUrGU()
  with open(CCEvBr.VVEGoI(), "w") as f:
   for line in lines:
    if CCEvBr.VVdmk9(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCEvBr.VVEGoI(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VV3oAz()
  if self.VVdesl:
   self.VVdesl.VVenHM()
 def VV9XIm(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  fName = fName.replace("(", "_").replace(")", "_")
  dest = dest.replace("(", "_").replace(")", "_")
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCoUhv.VVYQAD(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVoafo("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVrA75(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFb0lc("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCEvBr.VVcM1N, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVMYPh(dnldLog):
  if fileExists(dnldLog):
   dur = CCEvBr.VVXh6T(dnldLog)
   if dur > -1:
    tim = CCEvBr.VVoZAX(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVXh6T(dnldLog):
  lines = FFYEhL("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVoZAX(dnldLog):
  lines = FFYEhL("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVYKxy(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFGpT0(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    FFqSkC("mkdir '%s'" % path1)
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVu2Fq(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVdesl.VV1blE()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VVJcx4, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVJcx4(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVRuqp == path:
       break
     else:
      break
  except:
   return
  if CCEvBr.VVRuqp:
   CCEvBr.VVRuqp = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFF0Rr(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVkWyf(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVJcx4(url, decodedUrl, path, resp, totFileSize, True)
 def VVHh2t(self, VVdesl, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VV4DUD() : FFZD7H(self.VVdesl, self.VVU3eY(self.VVCLUR), 500)
  elif not self.VVFOGS() : FFZD7H(self.VVdesl, self.VVU3eY(self.VVO0ZJ), 500)
  elif m3u8Log      : FFgBNQ(self.SELF, self.VVU8aK, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVvqbV():
    CCEvBr.VVRuqp = colList[6]
    FFZD7H(self.VVdesl, "Stopping ...", 1000)
   else:
    FFZD7H(self.VVdesl, "Stopped", 500)
 def VVU8aK(self, withMsg=True):
  if withMsg:
   FFZD7H(self.VVdesl, "Stopping ...", 1000)
  FFqSkC("killall -INT ffmpeg")
 def VVuFgE(self, *args):
  if   self.VV4DUD() : FFZD7H(self.VVdesl, self.VVU3eY(self.VVCLUR) , 500)
  elif self.VVFOGS() : FFZD7H(self.VVdesl, self.VVU3eY(self.VVxhbz), 500)
  else:
   resume = False
   m3u8Log = self.VVdesl.VV1blE()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FFgBNQ(self.SELF, BF(self.VVw5Re, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVVrWP():
    resume = True
   if resume: FFbA1i(self.VVdesl, BF(self.VVOX4R), title="Checking Server ...")
   else  : FFZD7H(self.VVdesl, "Cannot resume !", 500)
 def VVw5Re(self, m3u8Log):
  FFqSkC("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  FFbA1i(self.VVdesl, BF(self.VVOX4R), title="Checking Server ...")
 def VVOX4R(self):
  colList  = self.VVdesl.VV1blE()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCOGg2.VVY8JV(decodedUrl)
   if url:
    decodedUrl = self.VV3jKT(decodedUrl, url)
   else:
    self.VVoafo("Could not get download link !\n\nTry again later.")
    return
  curSize = FFF0Rr(path)
  params = self.VVkWyf(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVoafo(params[0])
   return
  elif len(params) == 2:
   self.VVR0D8(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VV3jKT(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCEvBr.VVcM1N, path, decodedUrl)
  if resumable: self.VVu2Fq(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVoafo("Cannot resume from server !")
 def VV4vsl(self, decodedUrl):
  fileExt = CCoUhv.VVD9QL(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FF9Dqr(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVoafo(self, txt):
  FFOyl1(self.SELF, txt, title=self.Title)
 def VVvqbV(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCEvBr.VVcM1N, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VVFOGS(self):
  decodedUrl = self.VVdesl.VV1blE()[9]
  return decodedUrl in self.VVvqbV()
 def VV4DUD(self):
  colList = self.VVdesl.VV1blE()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFF0Rr(path)) == size
 def VVVrWP(self):
  colList = self.VVdesl.VV1blE()
  path = colList[6]
  size = int(colList[7])
  curSize = FFF0Rr(path)
  if curSize > -1:
   size -= curSize
  err = CCEvBr.VVdtZz(size)
  if err:
   FFOyl1(self.SELF, err, title=self.Title)
   return False
  return True
 def VV6tOT(self, list):
  with open(CCEvBr.VVEGoI(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VV3jKT(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCEvBr.VVUrGU()
  url = decodedUrl
  with open(CCEvBr.VVEGoI(), "w") as f:
   for line in lines:
    if CCEvBr.VVdmk9(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VV3oAz()
  return url
 @staticmethod
 def VVUrGU():
  list = []
  if fileExists(CCEvBr.VVEGoI()):
   for line in FF72md(CCEvBr.VVEGoI()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVdmk9(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVdtZz(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCVnYx.VVP9pE(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCVnYx.VVI3LQ(size), CCVnYx.VVI3LQ(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVIpcs(SELF):
  tot = CCEvBr.VVi9NB()
  if tot:
   FFOyl1(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVi9NB():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCEvBr.VVcM1N):
    c += 1
  return c
 @staticmethod
 def VVucv1():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCEvBr.VVcM1N, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VVk9dH():
  return len(CCEvBr.VVUrGU()) == 0
 @staticmethod
 def VV53k6():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVSYyb():
  mPoints = CCEvBr.VV53k6()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    FFqSkC("mkdir '%s'" % path)
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVEGoI():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVQOcZ(SELF, waitMsgObj=None):
  FFbA1i(waitMsgObj or SELF, BF(CCEvBr.VVJWvP, SELF, CCEvBr.VVHIEb))
 @staticmethod
 def VVu9Mb(SELF):
  CCEvBr.VVJWvP(SELF, CCEvBr.VVnAN4, startDnld=True)
 @staticmethod
 def VV0Osn(SELF, url):
  CCEvBr.VVJWvP(SELF, CCEvBr.VVnAN4, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVRiiI(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(SELF)
  added, skipped = CCEvBr.VVoUGn([decodedUrl])
  FFZD7H(SELF, "Added", 1000)
 @staticmethod
 def VVoUGn(list):
  added = skipped = 0
  for line in CCEvBr.VVUrGU():
   for ndx, url in enumerate(list):
    if url and CCEvBr.VVdmk9(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCEvBr.VVEGoI(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVJWvP(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCvqvw.VV6Zw5(SELF):
   return
  if mode == CCEvBr.VVHIEb and CCEvBr.VVk9dH():
   FFOyl1(SELF, "Download list is empty !", title=title)
  else:
   inst = CCEvBr(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVKihe(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCuYKB(Screen, CC1RWP):
 VVy0QT = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, enableDownloadMenu=True):
  self.skin, self.skinParam = FFPFsH(VVauyc, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CC1RWP.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.iptvTableParams  = iptvTableParams
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FFRFZg(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VV0VPe())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(VVQOuY,
  {
   "ok"  : self.VV2Iyl       ,
   "info"  : self.VVPgrz      ,
   "epg"  : self.VVPgrz      ,
   "menu"  : self.VV1B9J     ,
   "cancel" : self.cancel       ,
   "red"  : self.VVMqmf   ,
   "green"  : self.VVbGN1  ,
   "blue"  : self.VVguh1      ,
   "yellow" : self.VVtQtt ,
   "left"  : BF(self.VVX04J, -1)    ,
   "right"  : BF(self.VVX04J,  1)    ,
   "play"  : self.VV5Y7n      ,
   "pause"  : self.VV5Y7n      ,
   "playPause" : self.VV5Y7n      ,
   "stop"  : self.VV5Y7n      ,
   "rewind" : self.VV09YE      ,
   "forward" : self.VVhpaY      ,
   "rewindDm" : self.VV09YE      ,
   "forwardDm" : self.VVhpaY      ,
   "last"  : self.VVsv9y      ,
   "next"  : self.VVdWWv      ,
   "pageUp" : BF(self.VVi1Tc, True)  ,
   "pageDown" : BF(self.VVi1Tc, False)  ,
   "chanUp" : BF(self.VVi1Tc, True)  ,
   "chanDown" : BF(self.VVi1Tc, False)  ,
   "up"  : BF(self.VVi1Tc, True)  ,
   "down"  : BF(self.VVi1Tc, False)  ,
   "audio"  : BF(self.VVbj4S, True)  ,
   "subtitle" : BF(self.VVbj4S, False)  ,
   "text"  : self.VVXrI9  ,
   "0"   : BF(self.VVsCVc , 10)   ,
   "1"   : BF(self.VVsCVc , 1)   ,
   "2"   : BF(self.VVsCVc , 2)   ,
   "3"   : BF(self.VVsCVc , 3)   ,
   "4"   : BF(self.VVsCVc , 4)   ,
   "5"   : BF(self.VVsCVc , 5)   ,
   "6"   : BF(self.VVsCVc , 6)   ,
   "7"   : BF(self.VVsCVc , 7)   ,
   "8"   : BF(self.VVsCVc , 8)   ,
   "9"   : BF(self.VVsCVc , 9)
  }, -1)
  self.onShown.append(self.VVnLQg)
  self.onClose.append(self.onExit)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFk6h6(self)
  if not CCuYKB.VVy0QT:
   CCuYKB.VVy0QT = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFl0wi(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFl0wi(self["myPlayRpt"], "rpt")
  self.VVPKcd()
  self.instance.move(ePoint(40, 40))
  self.VVGu2V(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVjbCx)
  except:
   self.timer.callback.append(self.VVjbCx)
  self.timer.start(250, False)
  self.VVjbCx("Checking ...")
  if not bool(self.iptvTableParams):
   self.VVOt6X()
 def VVbGN1(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
  self.lastSubtitle = CCA1uQ.VVVysP()
  if "chCode" in iptvRef:
   if CCvqvw.VV6Zw5(self):
    self.VVOt6X(True)
  else:
   self.VVjbCx("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVPKcd(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVI8fP()
  chName = FF3gfV(chName)
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VVtchu + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FFC3pI(self["myTitle"], tColor)
  FFC3pI(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FFC3pI(self["myPlay%s" % item], tColor)
  picFile = CCqIel.VVYHPN(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CCqIel.VVNQJi(self)
  cl = CCskRx.VV27Hb(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VVjbCx(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCEvBr.VVi9NB()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVI8fP()
  if evName:
   evName = "    %s    " % FF8oA9(evName, VVD4un)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVjGy8():
   FF0TXZ(self["myPlayBlu"], "#00FFFFFF")
   FFC3pI(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FF0TXZ(self["myPlayBlu"], "#00FFFF88")
   FFC3pI(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  if not self.isManualSeek:
   player = CCoUhv.VVD90E(refCode)
   if player:
    self["myPlaySkp"].show()
    self["myPlaySkp"].setText(VVdZck + player)
   else:
    self["myPlaySkp"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FFC3pI(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FFOaVa(percVal, 0, 100)
   width = int(FFYZmF(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FFC3pI(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FF0TXZ(self["myPlayMsg"], "#0000ffff")
   else  : FF0TXZ(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FF0TXZ(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FF0TXZ(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVjviE()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VV6Sy3(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CCA1uQ.VVu6dy(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVsv9y()
  state = self.VVcy6f()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FF0TXZ(self["myPlayMsg"], "#0000ff00")
  else     : FF0TXZ(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVI8fP(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FF7TZz(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCuYKB.VVOZSB(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCqIel.VVWQS7(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  elif isFtp        : tColor = "#11222222"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CCMbXb()
   tpTxt, satTxt = tp.VVe2ir(refCode)
   self.satInfo_TP = tpTxt + "  " + FF8oA9(satTxt, VVdVTX)
  evName = evNameNext = ""
  evLst = CCfTje.VVRH2U(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFkLkE(info, iServiceInformation.sVideoWidth) or -1
   h = FFkLkE(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFkLkE(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CCqIel.VVWsHu(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VVOZSB(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFBNnO(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFBNnO(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFBNnO(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VV1B9J(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVI8fP()
  FFf4jhSeries = FF9Dqr(decodedUrl)
  VVtMHe = []
  if not "VVTsbd" in globals() and not "VVVVVT" in globals():
   VVtMHe.append((VVdVTX + "IPTV Menu", "iptv"))
   VVtMHe.append(VVXGzj)
  if isIptv and not "&end=" in decodedUrl and not FFf4jhSeries:
   uType, uHost, uUser, uPass, uId, uChName = CCoUhv.VV1JTf(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVtMHe.append((VVdVTX + "Catchup Programs", "catchup" ))
    VVtMHe.append(VVXGzj)
  if refCode:
   c = VVtchu
   VVtMHe.append((c + "Stop Current Service"  , "stop"  ))
   VVtMHe.append((c + "Restart Current Service" , "restart"  ))
   VVtMHe.append(FFQlwu("Replay with ..." , "replayWith", not isDvb, c))
   VVtMHe.append(VVXGzj)
  if FFf4jhSeries:
   VVtMHe.append((VVdVTX + "File Size (on server)", "fileSize" ))
   VVtMHe.append(VVXGzj)
  if self.enableDownloadMenu:
   c = VVdVTX
   addSep = False
   if isIptv and FFf4jhSeries:
    VVtMHe.append((c + "Start Download"  , "dload_cur" ))
    VVtMHe.append((c + "Add to Download List" , "addToDload" ))
    addSep = True
   if not CCEvBr.VVk9dH():
    VVtMHe.append((VVdVTX + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVtMHe.append(VVXGzj)
  fPath, fDir, fName = CCVnYx.VVASTW(self)
  if fPath:
   c = VV7z62
   if not "VV9pVc" in globals():
    VVtMHe.append((c + "Open path in File Manager", "VVY4li"))
   VVtMHe.append((c + "Add to Bouquet"             , "VVI9ol" ))
   VVtMHe.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVRPKP"  ))
   VVtMHe.append(VVXGzj)
  elif isFtp:
   VVtMHe.append((VVRuOi + "Add FTP Media to Bouquet"     , "VVX2A7"))
  if isDvb:
   VVtMHe.append((VVdVTX + "Signal Monitor", "sigMon"))
  if posTxt and durTxt:
   VVtMHe.append((VVRuOi + "Start Subtitle", "VVLKKq"))
   VVtMHe.append(VVXGzj)
  if CFG.playerPos.getValue() : VVtMHe.append(("Move Bar to Bottom" , "botm"))
  else      : VVtMHe.append(("Move Bar to Top" , "top" ))
  VVtMHe.append(("Help", "help"))
  FFECK9(self, self.VVKKW4, VVtMHe=VVtMHe, width=600, title="Options")
 def VVKKW4(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VVtQtt()
   elif item == "stop"     : self.VVVq3A(0)
   elif item == "restart"    : self.VVVq3A(1)
   elif item == "replayWith"   : self.VVz5fG()
   elif item == "fileSize"    : FFbA1i(self, BF(CCqIel.VVJvyk, self), title="Checking Server")
   elif item == "dload_cur"   : CCEvBr.VVu9Mb(self)
   elif item == "addToDload"   : CCEvBr.VVRiiI(self)
   elif item == "dload_stat"   : CCEvBr.VVQOcZ(self)
   elif item == "VVY4li" : self.close("close_openInFileMan")
   elif item == "VVI9ol" : self.VVI9ol()
   elif item == "VVX2A7" : self.VVX2A7()
   elif item == "VVLKKq"  : self.VVzQp8()
   elif item == "VVRPKP"  : self.VVRPKP()
   elif item == "botm"     : self.VVGu2V(0)
   elif item == "top"     : self.VVGu2V(1)
   elif item == "sigMon"    : self.VVMqmf()
   elif item == "help"     : FFSnt9(self, "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCuYKB.VVy0QT = None
 def VVVq3A(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VVPKcd()
   elif typ == 1:
    self.VVjbCx("Restarting Service ...")
    FFkvVR(BF(self.VVKNro, serv))
 def VVKNro(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
  if "&end=" in decodedUrl: BF(self.VVOt6X, True)
  else     : self.session.nav.playService(serv)
 def VVz5fG(self):
  FFECK9(self, self.VVhYby, VVtMHe=CCoUhv.VV7ivb(), width=650, title="Select Player", VVaRsg="#11220000", VVWgai="#11220000")
 def VVhYby(self, rType=None):
  if rType:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv : FFZZBl(self, eServiceReference(rType + ":" + serv.toString().split(":", 1)[1]))
   else : self.VVjbCx("No active service !")
 def VVI9ol(self):
  fPath, fDir, fName = CCVnYx.VVASTW(self)
  if fPath: picker = CCotiQ(self, self, "Add Current Movie to a Bouquet", BF(self.VVdHL8, [fPath]))
  else : FFZD7H(self, "Path not found !", 1500)
 def VVdHL8(self, pathLst):
  return CCotiQ.VVIsQk(pathLst)
 def VVX2A7(self):
  picker = CCotiQ(self, self, "Add FTP Media to Bouquet", self.VVDdlj)
 def VVDdlj(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
  return CCotiQ.VVIsQk([origUrl], rType=refCode.split(":", 1)[0])
 def VVRPKP(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCuYKB.VVOZSB(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVjbCx(txt, highlight=ok)
 def VVGu2V(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FF0UO9(CFG.playerPos, pos)
 def VVMqmf(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCqIel.VVWQS7(serv)
   if isDvb: self.close("close_sig")
   else : self.VVjbCx("No Signal for Current Service")
 def VVzQp8(self):
  self.session.openWithCallback(self.VVo8CN, BF(CCA1uQ))
 def VVXrI9(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVI8fP()
   if posTxt and durTxt: self.VVzQp8()
   else    : self.VVjbCx("No duration Info. !")
 def VVo8CN(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VVi1Tc(True)
  elif reason == "subtZapDn" : self.VVi1Tc(False)
  elif reason == "pause"  : self.VV5Y7n()
  elif reason == "audio"  : self.VVbj4S(True)
  elif reason == "subtitle" : self.VVbj4S(False)
  elif reason == "rewind"     : self.VV09YE()
  elif reason == "forward" : self.VVhpaY()
  elif reason == "rewindDm" : self.VV09YE()
  elif reason == "forwardDm" : self.VVhpaY()
  else      : txt = reason
  if txt:
   FFZD7H(self, txt, 2000)
 def VV2Iyl(self):
  if self.isManualSeek:
   self.VVR8tI()
   self.VV6Sy3(self.manualSeekPts)
  elif self.shown:
   if CCA1uQ.VVIpWT(self): self.VVzQp8()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVR8tI()
  else    : self.close()
 def VVPgrz(self):
  FF1wB7(self, fncMode=CCqIel.VVsTiW)
 def VV5Y7n(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VVjbCx("Toggling Play/Pause ...")
 def VVR8tI(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVX04J(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCuYKB.VVOZSB(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVxU1e()
   else:
    self.manualSeekSec += direc * self.VVxU1e()
    self.manualSeekSec = FFOaVa(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFYZmF(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFBNnO(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVsCVc(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VV0VPe())
   FF0UO9(CFG.playerJumpMin, self.jumpMinutes)
  self.VVjbCx("Changed Seek Time to : %d%s" % (val, self.VVaBtX()))
 def VV0VPe(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVaBtX())
 def VVaBtX(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VV4ZWG(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVxU1e(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVjviE(self):
  if "VVGHbd" in globals():
   global VVGHbd
   if VVGHbd:
    VVGHbd = VVGHbd[1:-1]
    if len(VVGHbd) == 3: VVGHbd = ""
    else     : return VVGHbd
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVguh1(self):
  cList = self.VVjGy8()
  if cList:
   VVtMHe = []
   for pts, what in cList:
    txt = FFBNnO(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVtMHe.append((txt, pts))
   FFECK9(self, self.VVAL7x, VVtMHe=VVtMHe, title="Cut List")
  else:
   self.VVjbCx("No Cut-List for this channel !")
 def VVAL7x(self, item=None):
  if item:
   self.VV6Sy3(item)
 def VVjGy8(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVhpaY(self) : self.VVlyDc(1)
 def VV09YE(self) : self.VVlyDc(-1)
 def VVlyDc(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCuYKB.VVOZSB(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVxU1e() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VV4ZWG())
    self.VVjbCx(txt)
  except:
   self.VVjbCx("Cannot jump")
 def VV6Sy3(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVjbCx("Changing Time ...")
 def VVsv9y(self):
  self.VVVq3A(1)
  self.VVjbCx("Replaying ...")
  self.VVR8tI()
 def VVdWWv(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCuYKB.VVOZSB(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVjbCx("Jumping to end ...")
  except:
   pass
 def VVcy6f(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVi1Tc(self, isUp):
  if self.enableZapping:
   self.VVjbCx("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVR8tI()
   if self.iptvTableParams:
    FFkvVR(BF(self.VVBVqn, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
    if "/timeshift/" in decodedUrl:
     self.VVjbCx("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VV76xN()
  else:
   self.VVjbCx("Zap Disabled !")
 def VV76xN(self):
  self.lastPlayPos = 0
  self.VVPKcd()
  self.VVOt6X()
 def VVBVqn(self, isUp):
  CCoUhv_inatance, VVdesl, mode = self.iptvTableParams
  if isUp : VVdesl.VVkvwu()
  else : VVdesl.VVVUEU()
  colList = VVdesl.VV1blE()
  if mode == "localIptv":
   chName, chUrl = CCoUhv_inatance.VViZFW(VVdesl, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCoUhv_inatance.VVUU0W(VVdesl, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCoUhv_inatance.VVAOBG(mode, VVdesl, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCoUhv_inatance.VVicXd(mode, VVdesl, colList)
  else:
   self.VVjbCx("Cannot Zap")
   return
  FFoYZf(self, chUrl, VVMFOV=False)
  self.VV76xN()
 def VVOt6X(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCuYKB.VVOZSB(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
   if not self.VVGpFS(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVjbCx("Refreshing Portal")
   FFkvVR(self.VV0EjE)
  except:
   pass
 def VV0EjE(self):
  self.restoreLastPlayPos = self.VVqHVf()
 def VVtQtt(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
  if not decodedUrl or FF9Dqr(decodedUrl):
   self.VVjbCx("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCoUhv.VV1JTf(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVjbCx("Reading Program List ...")
   ok_fnc = BF(self.VV1D8j, refCode, chName, streamId, uHost, uUser, uPass)
   FFkvVR(BF(CCoUhv.VVrPkx, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVjbCx("Cannot process this channel")
 def VV1D8j(self, refCode, chName, streamId, uHost, uUser, uPass, VVdesl, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVdesl.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVjbCx("Changing Program ...")
   FFkvVR(BF(self.VVsFgw, chUrl))
  else:
   self.VVjbCx("Incorrect Timestamp !")
 def VVsFgw(self, chUrl):
  FFoYZf(self, chUrl, VVMFOV=False)
  self.lastPlayPos = 0
  self.VVPKcd()
 def VVbj4S(self, isAudio):
  try:
   VVLbeP = InfoBar.instance
   if VVLbeP:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVLbeP)
    else  : self.session.open(SubtitleSelection, VVLbeP)
  except:
   pass
 @staticmethod
 def VVkkmW(session, mode=None):
  if   mode == "close_sig"   : FF89A3(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CCoUhv)
  elif mode == "close_openInFileMan" : session.open(CCVnYx, gotoMovie=True)
 @staticmethod
 def VVa42W(session, **kwargs):
  session.openWithCallback(BF(CCuYKB.VVkkmW, session), CCuYKB, **kwargs)
class CCJSdN(Screen):
 def __init__(self, session, title="", VVStYd="Continue?", VVJ9WI=True, VVMgjE=False):
  self.skin, self.skinParam = FFPFsH(VVPmmT, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVStYd = VVStYd
  self.VVMgjE = VVMgjE
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVJ9WI : VVtMHe = [no , yes]
  else   : VVtMHe = [yes, no ]
  FFRFZg(self, title, VVtMHe=VVtMHe, addLabel=True)
  self["myActionMap"] = ActionMap(VVQOuY,
  {
   "ok" : self.VV2Iyl ,
   "cancel": self.cancel ,
   "red" : self.cancel ,
  }, -1)
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVStYd)
  if self.VVMgjE:
   self["myLabel"].instance.setHAlign(0)
  self.VV21R5()
  FFWIRJ(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FF4Dy8(self["myMenu"])
  FFSPFU(self, self["myMenu"])
 def VV2Iyl(self):
  item = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VV21R5(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  diff  = textSize.height() - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CChyFO(Screen):
 def __init__(self, session, title="", VVtMHe=None, width=1000, height=850, VVGNdU=30, barText="", minRows=1, VVyXO1=None, VVBLNR=None, VVEJLl=None, VVI3Sz=None, VVIL24=None, VVrBns=None, VVIZXB=False, VVy2u1=False, VVNhLF=None, VVSdJg=True, VVaRsg="#22003344", VVWgai="#22002233"):
  self.skin, self.skinParam = FFPFsH(VVMjBN, width, height, 50, 40, 30, VVaRsg, VVWgai, VVGNdU, barHeight=40, topRightBtns=3 if VVBLNR else 0)
  self.session   = session
  self.VVtMHe   = VVtMHe
  self.barText   = barText
  self.minRows   = minRows
  self.VVyXO1   = VVyXO1
  self.VVBLNR   = VVBLNR
  self.VVEJLl   = VVEJLl
  self.VVI3Sz  = VVI3Sz
  self.VVIL24  = ("Delete File", BF(self.VVhV94, VVNhLF)) if not VVNhLF is None else VVIL24
  self.VVrBns   = VVrBns
  self.VVIZXB  = VVIZXB
  self.VVy2u1  = VVy2u1
  self.Title    = title
  FFRFZg(self, title, VVtMHe=VVtMHe)
  self["myActionMap"] = ActionMap(VVQOuY,
  {
   "ok"  : self.VV2Iyl    ,
   "cancel" : self.cancel    ,
   "info"  : self.VVyj7V   ,
   "red"  : self.VVwOGY   ,
   "green"  : self.VVZr1s   ,
   "yellow" : self.VVjsUu   ,
   "blue"  : self.VV5EBi   ,
   "pageUp" : self.VVMwbu ,
   "chanUp" : self.VVMwbu ,
   "pageDown" : self.VVoVse  ,
   "chanDown" : self.VVoVse  ,
   "0"   : BF(self.VVduQZ, 0) ,
   "1"   : BF(self.VVduQZ, 1) ,
   "2"   : BF(self.VVduQZ, 2) ,
   "3"   : BF(self.VVduQZ, 3) ,
   "4"   : BF(self.VVduQZ, 4) ,
   "5"   : BF(self.VVduQZ, 5) ,
   "6"   : BF(self.VVduQZ, 6) ,
   "7"   : BF(self.VVduQZ, 7) ,
   "8"   : BF(self.VVduQZ, 8) ,
   "9"   : BF(self.VVduQZ, 9)
  }, -1)
  if VVSdJg:
   FFfyBc(self, self["myMenu"], isMenu=True)
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFWIRJ(self["myMenu"])
  FFJI0m(self, minRows=self.minRows)
  FFk6h6(self)
  self.VVxfyr(self["keyRed"]  , self.VVEJLl )
  self.VVxfyr(self["keyGreen"] , self.VVI3Sz )
  self.VVxfyr(self["keyYellow"] , self.VVIL24 )
  self.VVxfyr(self["keyBlue"]  , self.VVrBns )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFFlxX(self)
 def VVxfyr(self, btnObj, btnFnc):
  if btnFnc:
   FFKdfz(btnObj, btnFnc[0])
 def VVxRWr(self, fnc=None):
  self.VVI3Sz = fnc
  if fnc : self.VVxfyr(self["keyGreen"], self.VVI3Sz)
  else : self["keyGreen"].hide()
 def VVduQZ(self, digit):
  digit = str(digit)
  VVtMHe = self["myMenu"].list
  for ndx, item in enumerate(VVtMHe):
   if len(item) == 2:
    span = iSearch(r"^\[(\d)\]\s.+", FF3gfV(item[0]), IGNORECASE)
    if span and span.group(1) == digit:
     self.VV27hm(ndx)
     self.VV2Iyl()
     break
 def VV2Iyl(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if item is not None:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   if self.VVyXO1:
    self.VVyXO1((self, txt, ref, ndx))
   else:
    if self.VVIZXB: self.close((txt, ref, ndx))
    else     : self.close(item)
 def VVyj7V(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if self.VVBLNR and item:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   self.VVBLNR(self, txt, ref, ndx)
 def cancel(self):
  self.close(None)
 def VVwOGY(self)  : self.VVKdC9(self.VVEJLl)
 def VVZr1s(self) : self.VVKdC9(self.VVI3Sz)
 def VVjsUu(self) : self.VVKdC9(self.VVIL24)
 def VV5EBi(self) : self.VVKdC9(self.VVrBns)
 def VVKdC9(self, btnFnc):
  if btnFnc:
   item = self["myMenu"].l.getCurrentSelection()[1]
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVy2u1:
    self.cancel()
 def VVzjcG(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVtMHe = self["myMenu"].list
  VVtMHe.pop(ndx)
  if len(VVtMHe) > 0: self["myMenu"].setList(VVtMHe)
  else    : self.close()
 def VVhV94(self, basePath, menuObj, fName):
  FFgBNQ(self, BF(self.VVY0lI, basePath + fName), "Delete this file ?\n\n%s" % fName, title=self.Title)
 def VVY0lI(self, path):
  FFOlRe(path)
  if fileExists(path) : FFZD7H(self, "Not deleted", 1000)
  else    : self.VVzjcG()
 def VVW5TS(self, VVtMHe):
  if len(VVtMHe) > 0:
   newList = []
   for item in VVtMHe:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FFJI0m(self, minRows=self.minRows)
  else:
   self.close("")
 def VVSwKG(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FFJI0m(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVDEoO(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VV27hm(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VVUaEY(self, refTxt):
  for ndx, item in enumerate(self["myMenu"].list):
   if refTxt == item[1]:
    self.VV27hm(ndx)
    break
 def VV6A4S(self, txt):
  for ndx, item in enumerate(self["myMenu"].list):
   if txt == item[0]:
    self.VV27hm(ndx)
    break
 def VVMwbu(self) : self["myMenu"].moveToIndex(0)
 def VVoVse(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCXQTE(Screen):
 def __init__(self, session, title="", width=1600, height=900, vMargin=5, header=None, VVcuvv=None, VV0CnX=None, VVbG6j=None, VVGNdU=26, isEditor=False, addSort=True, VVEMdg=False, VVG01F=0, picParams=None, VVMWQK=None, VVZArZ=None, menuButtonFnc=None, VVIzUv=None, VV1kWx=None, VVM9Pm=None, VVRHhw=None, VVXhOf=None, VVBYRP=None, VVJi29=None, VVJScE=-1, VVcmLr=0, searchCol=0, lastFindConfigObj=None, VVaRsg="#22003344", VVWgai="#22002233", VVHyoi="#00dddddd", VVSJJk="#11002233", VVlrsP=None, VVYCZ6="#11111111", borderWidth=1, VVTjte="#0a555555", VV2uE2="#0affffff", VVIyj7="#11552200", VV4avx="#0055ff55", VV4avxRev="#0000bbff"):
  self.skin, self.skinParam = FFPFsH(VVRmkR, width, height, 50, 10, vMargin, VVaRsg, VVWgai, 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFRFZg(self, title)
  self.Title     = title
  self.header     = header
  self.VVcuvv     = VVcuvv
  self.totalCols    = len(VVcuvv[0])
  self.VVG01F   = VVG01F
  self.picParams    = picParams
  self.lastSortModeIsReverese = False
  self.VVEMdg   = VVEMdg
  self.VV2yen   = 0.01
  self.VV79op   = 0.02
  self.VVNZut = 0.03
  self.VVexkV  = 1
  self.VVbG6j = VVbG6j
  self.colWidthPixels   = []
  self.VVMWQK   = VVMWQK
  self.OKButtonObj   = None
  self.VVZArZ   = VVZArZ
  self.VVIzUv   = VVIzUv
  self.VV1kWx   = VV1kWx
  self.VVM9Pm  = VVM9Pm
  self.VVRHhw   = VVRHhw
  self.VVXhOf    = VVXhOf
  self.VVBYRP   = VVBYRP
  self.tableRefreshCB   = None
  self.VVJi29  = VVJi29
  self.menuButtonFnc   = menuButtonFnc
  self.VVJScE    = VVJScE
  self.VVcmLr   = VVcmLr
  self.searchCol    = searchCol
  self.VV0CnX    = VV0CnX
  self.keyPressed    = -1
  self.VVGNdU    = FF9qRO(VVGNdU)
  self.isEditor    = isEditor
  self.addSort    = addSort
  self.VVavwW    = FFYpsV(self.VVGNdU, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVaRsg    = VVaRsg
  self.VVWgai      = VVWgai
  self.VVHyoi    = FFGsVi(VVHyoi)
  self.VVSJJk    = FFGsVi(VVSJJk)
  self.VVlrsP    = VVlrsP
  self.VVYCZ6    = FFGsVi(VVYCZ6)
  self.borderWidth   = borderWidth
  self.VVTjte   = FFGsVi(VVTjte)
  self.VV2uE2    = FFGsVi(VV2uE2)
  self.VVIyj7    = FFGsVi(VVIyj7)
  self.VV4avx   = FFGsVi(VV4avx)
  self.VV4avxRev  = FFGsVi(VV4avxRev)
  self.VVcTnU  = False
  self.selectedItems   = 0
  self.VVPeRf   = FFGsVi("#06542132")
  self.onMultiSelFnc   = None
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VVcmLr:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   if self.VVcmLr == 1: self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(VVQOuY,
  {
   "ok"  : self.VVNHwA  ,
   "red"  : self.VVvmjX  ,
   "green"  : self.VVNMOC ,
   "yellow" : self.VVBBXB ,
   "blue"  : self.VVJ8JY  ,
   "menu"  : self.VVhMgp ,
   "info"  : self.VV7MZh  ,
   "cancel" : self.VVbiSg  ,
   "up"  : self.VVVUEU    ,
   "down"  : self.VVkvwu  ,
   "left"  : self.VVTqsq   ,
   "right"  : self.VVlu2y  ,
   "next"  : self.VVl98G  ,
   "last"  : self.VV0VY8  ,
   "home"  : self.VVQ6jD  ,
   "pageUp" : self.VVQ6jD  ,
   "chanUp" : self.VVQ6jD  ,
   "end"  : self.VVenHM  ,
   "pageDown" : self.VVenHM  ,
   "chanDown" : self.VVenHM
  }, -1)
  FFfyBc(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFk6h6(self)
  try:
   self.VV7jMI()
  except Exception as e:
   FFOyl1(self, str(e), title=self.Title)
   self.close(None)
 def VV7jMI(self):
  FFFlxX(self)
  self.VVxfyr(self.VVIzUv , self["keyRed"])
  self.VVxfyr(self.VV1kWx , self["keyGreen"])
  self.VVxfyr(self.VVM9Pm, self["keyYellow"])
  self.VVxfyr(self.VVRHhw , self["keyBlue"])
  if self.VVMWQK:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj and self.VVMWQK[0]:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVMWQK[0])
    FFC3pI(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVavwW)
  self["myTableH"].l.setFont(0, gFont(VVlMYE, self.VVGNdU))
  self["myTable"].l.setItemHeight(self.VVavwW)
  self["myTable"].l.setFont(0, gFont(VVlMYE, self.VVGNdU))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w = self["myTable"].instance.size().width()
  h = self["myTable"].instance.size().height()
  pos = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVavwW)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVavwW))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVavwW)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVavwW
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVavwW * len(self.VVcuvv) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVbG6j:
   self.VVbG6j = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVbG6j)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VV0CnX:
   self.VV0CnX = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VV0CnX
   self.VV0CnX = []
   for item in tmpList:
    self.VV0CnX.append(item | RT_VALIGN_CENTER)
  self.VVCf21()
  if self.VVXhOf:
   self.VVXhOf(self)
 def VVxfyr(self, btnFnc, btn):
  if btnFnc : FFKdfz(btn, btnFnc[0])
  else  : FFKdfz(btn, "")
 def VV83b8(self, waitTxt):
  FFbA1i(self, self.VVCf21, title=waitTxt)
 def VVCf21(self, onlyHeader=False):
  try:
   if self.header:
    sortedFg = self.VV4avxRev if self.lastSortModeIsReverese else self.VV4avx
    self["myTableH"].setList([self.VVlaK8(0, self.header, self.VV2uE2, self.VVIyj7, None, self.VVIyj7, sortedFg)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VVcuvv):
    self["myTable"].list.append(self.VVlaK8(c, row, self.VVHyoi, self.VVSJJk, self.VVlrsP, self.VVYCZ6, None))
   self.VVcuvv = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVJScE > -1:
    self["myTable"].moveToIndex(self.VVJScE )
   self.VV9JI3()
   if self.VVcmLr:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVavwW * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
     FF1bLc(self, width, newH)
   if self.VVBYRP:
    self.VVKdC9(self.VVBYRP, None)
   if self.tableRefreshCB:
    self.VVKdC9(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FFOyl1(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VVlaK8(self, keyIndex, columns, VVHyoi, VVSJJk, VVlrsP, VVYCZ6, VV4avx):
  row = [keyIndex]
  if VVlrsP:
   VVlrsP = FFGsVi(VVlrsP)
  posX = 0
  for ndx, entry in enumerate(columns):
   if VV4avx and ndx == self.VVG01F : textColor = VV4avx
   else           : textColor = VVHyoi
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFGsVi(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVSJJk = c
    entry = span.group(3)
   if not self.isEditor and self.VV0CnX[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVavwW)
           , font   = 0
           , flags   = self.VV0CnX[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVSJJk
           , color_sel  = VVlrsP or textColor
           , backcolor_sel = VVYCZ6
           , border_width = self.borderWidth
           , border_color = self.VVTjte
           ))
   posX += self.colWidthPixels[ndx]
  if not VV4avx and self.picParams:
   picPosCol, picFnc, pathCol = self.picParams
   if   picFnc : png = picFnc(columns)
   elif pathCol: png = columns[pathCol].strip()
   else  : png = ""
   if png.startswith("/"):
    try:
     pngX = sum(self.colWidthPixels[:picPosCol])
     row.append(CCXQTE.VVGIbI(pngX+2, picPosCol+2, self.colWidthPixels[picPosCol]-4, self.VVavwW-4, LoadPixmap(png)))
    except:
     pass
  return row
 def VV7MZh(self):
  rowData = self.VVxHfZ()
  if rowData:
   title, txt, colList = rowData
   if self.VVZArZ:
    fnc  = self.VVZArZ[1]
    params = self.VVZArZ[2]
    fnc(self, title, txt, colList)
   else:
    FFoB4k(self, txt, title)
 def VVNHwA(self):
  if   self.VVcTnU : self.VVGOCg(self.VVvapY(), mode=2)
  elif self.VVMWQK  : self.VVKdC9(self.VVMWQK, None)
  else      : self.VV7MZh()
 def VVvmjX(self) : self.VVKdC9(self.VVIzUv , self["keyRed"])
 def VVNMOC(self) : self.VVKdC9(self.VV1kWx , self["keyGreen"])
 def VVBBXB(self): self.VVKdC9(self.VVM9Pm , self["keyYellow"])
 def VVJ8JY(self) : self.VVKdC9(self.VVRHhw , self["keyBlue"])
 def VVKdC9(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFZD7H(self, buttonFnc[3])
    FFkvVR(BF(self.VV3RB2, buttonFnc))
   else:
    self.VV3RB2(buttonFnc)
 def VV3RB2(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVxHfZ()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVGOCg(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][10] == self.VVPeRf
   if mode == 0 or (mode == 2 and isSelected):
    bg = self.VVSJJk
    if isSelected:
     self.selectedItems -= 1
   else:
    bg = self.VVPeRf
    if not isSelected:
     self.selectedItems += 1
   for col in range(1, len(row)):
    cols = list(row[col])
    if cols[0] == 0:
     cols[10] = bg
    row[col] = tuple(cols)
   self["myTable"].l.invalidate()
   if self.VVvapY() < len(self["myTable"].list) - 1 : self.VVkvwu()
   else              : self.VV9JI3()
   if self.onMultiSelFnc:
    self.onMultiSelFnc()
 def VVHCUx(self)  : FFbA1i(self, BF(self.VV8H1W, True ), title="Selecting all ..."  )
 def VVXLvB(self) : FFbA1i(self, BF(self.VV8H1W, False), title="Unselecting all ...")
 def VV8H1W(self, isSel=True):
  if isSel:
   bg = self.VVPeRf
   self.selectedItems = len(self["myTable"].list)
   self.VVrFVf(True)
  else:
   bg = self.VVSJJk
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][10] == self.VVPeRf
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     cols = list(self["myTable"].list[ndx][col])
     if cols[0] == 0:
      cols[10] = bg
     self["myTable"].list[ndx][col] = tuple(cols)
  self["myTable"].l.invalidate()
 def VVxHfZ(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVbG6j[i] > 1 or self.VVbG6j[i] == self.VV2yen or self.VVbG6j[i] == self.VVNZut:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VVbiSg(self):
  self["myTable"].onSelectionChanged = []
  if self.VVJi29 : self.VVJi29(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VVtVut(self):
  return self["myTitle"].getText().strip()
 def VVoZ97(self):
  return self.header
 def VVOiVj(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVEAoi(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FF0TXZ(self["myBar"], color)
 def VVYtu4(self, txt):
  FFZD7H(self, txt)
 def VVz4xL(self, txt, Time=1000):
  FFZD7H(self, txt, Time)
 def VVQUuA(self): self["keyGreen"].show()
 def VVNvGq(self): self["keyGreen"].hide()
 def VVyYwz(self): return self["keyGreen"].visible
 def VVaW1B(self):
  FFZD7H(self)
 def VVLS8Z(self, fnc, callFnc=False):
  self["myTable"].onSelectionChanged.append(fnc)
  if callFnc:
   fnc()
 def VVMs9k(self):
  return len(self["myTable"].list)
 def VVvapY(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVH1h9(self):
  return len(self["myTable"].list)
 def VVrFVf(self, isOn):
  self.VVcTnU = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VVRHhw: self["keyBlue"].hide()
   if self.VVMWQK and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.VVaRsg
   self["keyMenu"].show()
   if self.VVRHhw: self["keyBlue"].show()
   if self.VVMWQK and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVMWQK[0])
   self.VVXLvB()
  FFC3pI(self["myTitle"], color)
  FFC3pI(self["myBar"]  , color)
 def VVs9jW(self):
  return self.VVcTnU
 def VVLHWg(self):
  return self.selectedItems
 def VVkzmH(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VV9JI3()
 def VVICFC(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVDfBW(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVMs9k()
  txt += FFHM5m("Total Unique Items", VV8ETX)
  for i in range(self.totalCols):
   if self.VVbG6j[i - 1] > 1 or self.VVbG6j[i - 1] == self.VV2yen or self.VVbG6j[i - 1] == self.VVNZut:
    name, tot = self.VVICFC(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFoB4k(self, txt)
 def VVxBD7(self, colNum, isStrip=True):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip() if isStrip else item[colNum + 1][7]
  else : return None
 def VV1blE(self):
  return self.VVLabl(self["myTable"].l.getCurrentSelectionIndex())
 def VVLabl(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VV87pY(self, newList, newTitle="", VVZoVsMsg=True, tableRefreshCB=None, isSort=True):
  if newTitle:
   self.VVOiVj(newTitle)
  if newList:
   self.VVcuvv = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VVEMdg and self.VVG01F == 0:
    isNum = True
   else:
    for cols in self.VVcuvv:
     if not FFZrII(cols[self.VVG01F]): break
    else:
     isNum = True
   if isSort:
    if isNum: self.VVcuvv.sort(key=lambda x: int(x[self.VVG01F])  , reverse=self.lastSortModeIsReverese)
    else : self.VVcuvv.sort(key=lambda x: x[self.VVG01F].lower() , reverse=self.lastSortModeIsReverese)
   if VVZoVsMsg : self.VV83b8("Refreshing ...")
   else   : self.VVCf21()
  else:
   FFOyl1(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VVavnG(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VVlaK8(self.VVH1h9(), row, self.VVHyoi, self.VVSJJk, self.VVlrsP, self.VVYCZ6, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VVenHM()
 def VVKchm(self):
  self["myTable"].list.pop(self.VVvapY())
  self["myTable"].l.setList(self["myTable"].list)
 def VVIDuW(self, data):
  ndx = self.VVvapY()
  newRow = self.VVlaK8(ndx, data, self.VVHyoi, self.VVSJJk, self.VVlrsP, self.VVYCZ6, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VV9JI3()
   return True
  else:
   return False
 def VVonwB(self, tDict):
  ndx = self.VVvapY()
  for colNum, val in tDict.items():
   txt = str(val)
   if not self.isEditor and self.VV0CnX[ndx] & LEFT:
    txt = " %s " % txt.strip()
   col = list(self["myTable"].list[ndx][colNum + 1])
   col[7] = txt
   self["myTable"].list[ndx][colNum + 1] = tuple(col)
  self.VVwL9c()
 def VVFoW1(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VVlaK8(ndx, data, self.VVHyoi, self.VVSJJk, self.VVlrsP, self.VVYCZ6, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VVwL9c()
 def VVwL9c(self):
  self["myTable"].l.setList(self["myTable"].list)
  self.VV9JI3()
 def VVj9Yv(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VVaQuz(self, colNum, textToFind, VVl1IZ=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VV9JI3()
    break
  else:
   if VVl1IZ:
    FFZD7H(self, "Not found", 1000)
 def VVQMdW(self, colDict, VVl1IZ=False):
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VV9JI3()
    return
  if VVl1IZ:
   FFZD7H(self, "Not found", 1000)
  return False
 def VVdWFX(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVc7X2(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FFZrII(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VVLRcj(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][10] == self.VVPeRf:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVP9ZS(self):
  if self.selectedItems:
   for ndx, row in enumerate(self["myTable"].list):
    if row[1][10] == self.VVPeRf:
     return ndx
  return -1
 def VVbgN8(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][10] == self.VVPeRf:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VV44Kf(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][10] == self.VVPeRf : return True
  else        : return False
 def VVTW2g(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVhMgp(self):
  if self.menuButtonFnc:
   self.VV3RB2(self.menuButtonFnc)
   return
  if not self["keyMenu"].getVisible() or self.VVcmLr:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVvapY()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVtMHe1, VVxFc7 = CC6kzI.VVMhrM(self, False, False)
  VVtMHe = []
  VVtMHe.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVtMHe.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVtMHe.append(("Find ...\t\t%s" % (FF8oA9(txt, VVoIYV) if txt else ""), "findNew"   ))
  VVtMHe.append(itemOf(bool(VVtMHe1)    , "Find (from Filter) ..."   , "filter"   ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Table Statistcis"             , "tableStat"  ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((FF8oA9("Export Table to .html"     , VV8ETX) , "VVnT5Z" ))
  VVtMHe.append((FF8oA9("Export Table to .csv"     , VV8ETX) , "VVMlM3" ))
  VVtMHe.append((FF8oA9("Export Table to .txt (Tab Separated)", VV8ETX) , "VVfH8N" ))
  if self.addSort:
   sList = []
   tot  = 0
   for i in range(self.totalCols):
    if self.VVbG6j[i] > 1 or self.VVbG6j[i] == self.VV79op:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     sList.append(("Sort by : %s" % name, i))
   if tot:
    VVtMHe.append(VVXGzj)
    if tot == 1 : VVtMHe.append(("Sort", sList[0][1]))
    else  : VVtMHe += sList
  VVrBns = ("Keys Help", self.FFDpubHelp)
  FFECK9(self, self.VV3Hkm, VVtMHe=VVtMHe, title=self.VVtVut(), VVrBns=VVrBns)
 def VV3Hkm(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VVvn4g()
   elif item == "findPrev"  : self.VVvn4g(isPrev=True)
   elif item == "findNew"  : self.VVrmZl()
   elif item == "filter"  : self.VV86Fw()
   elif item == "tableStat" : self.VVDfBW()
   elif item == "VVnT5Z": FFbA1i(self, self.VVnT5Z, title=title)
   elif item == "VVMlM3" : FFbA1i(self, self.VVMlM3 , title=title)
   elif item == "VVfH8N" : FFbA1i(self, self.VVfH8N , title=title)
   else:
    if self.VVG01F == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVG01F, self.lastSortModeIsReverese = item, False
    if self.VVEMdg and self.VVG01F == 0 or self.VVc7X2(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVCf21(onlyHeader=True)
 def FFDpubHelp(self, VVkbkP, path):
  FFSnt9(self, "_help_table", "Table (Keys Help)")
 def VVVUEU(self):
  self["myTable"].up()
  self.VV9JI3()
 def VVkvwu(self):
  self["myTable"].down()
  self.VV9JI3()
 def VVTqsq(self):
  self["myTable"].pageUp()
  self.VV9JI3()
 def VVlu2y(self):
  self["myTable"].pageDown()
  self.VV9JI3()
 def VVQ6jD(self):
  self["myTable"].moveToIndex(0)
  self.VV9JI3()
 def VVenHM(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VV9JI3()
 def VVTklH(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VV9JI3()
 def VVl98G(self):
  if self.lastFindConfigObj.getValue():
   if self.VVvapY() == len(self["myTable"].list) - 1 : FFZD7H(self, "End reached", 1000)
   else              : self.VVvn4g()
  else:
   FFZD7H(self, 'Set "Find" in Menu', 1500)
 def VV0VY8(self):
  if self.lastFindConfigObj.getValue():
   if self.VVvapY() == 0 : FFZD7H(self, "Top reached", 1000)
   else       : self.VVvn4g(isPrev=True)
  else:
   FFZD7H(self, 'Set "Find" in Menu', 1500)
 def VVyIcP(self, txt):
  FF0UO9(self.lastFindConfigObj, txt)
 def VVrmZl(self):
  FFdnKb(self, self.VVIA9t, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VVIA9t(self, VVfJks):
  if not VVfJks is None:
   txt = VVfJks.strip()
   self.VVyIcP(txt)
   if VVfJks: self.VVvn4g(reset=True)
   else  : FFZD7H(self, "Nothing to find !", 1500)
 def VV86Fw(self):
  VVtMHe, VVxFc7 = CC6kzI.VVMhrM(self, False, False)
  VVIL24 = ("Edit Filter", BF(self.VVtaPa, VVxFc7))
  if VVtMHe : FFECK9(self, self.VV5Tdk, VVtMHe=VVtMHe, VVIL24=VVIL24, title="Find from Filter")
  else  : FFZD7H(self, "Filter Error !", 1500)
 def VV5Tdk(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VVyIcP(txt)
    self.VVvn4g(reset=True)
   else:
    FFZD7H(self, "No entry !", 1500)
 def VVtaPa(self, VVxFc7, selectionObj, sel):
  if fileExists(VVxFc7) : CCiazU(self, VVxFc7, VVCBqA=None)
  else       : FFbiIe(self, VVxFc7)
  selectionObj.cancel()
 def VVvn4g(self, reset=False, isPrev=False):
  curRow = self.VVvapY()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CC6kzI.VVV2i7(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VVTklH(i)
      break
    elif any(x in line for x in tupl):
     self.VVTklH(i)
     break
   else:
    FFZD7H(self, "Not found", 1000)
  else:
   FFZD7H(self, "Check your query", 1500)
 def VVfH8N(self):
  expFile = self.VVlHhp() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVMbww()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VVLabl(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVbG6j[ndx] > self.VVexkV or self.VVbG6j[ndx] == self.VVNZut:
      col = self.VVj5LH(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VVan6m(expFile)
 def VVMlM3(self):
  expFile = self.VVlHhp() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVMbww()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VVLabl(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVbG6j[ndx] > self.VVexkV or self.VVbG6j[ndx] == self.VVNZut:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VVj5LH(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVan6m(expFile)
 def VVnT5Z(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVtVut(), PLUGIN_NAME, VVQHC8)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVtVut()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVMbww()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVbG6j:
   colgroup += '   <colgroup>'
   for w in self.VVbG6j:
    if w > self.VVexkV or w == self.VVNZut:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVlHhp() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VVLabl(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVbG6j[ndx] > self.VVexkV or self.VVbG6j[ndx] == self.VVNZut:
      col = self.VVj5LH(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVan6m(expFile)
 def VVMbww(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVbG6j[ndx] > self.VVexkV or self.VVbG6j[ndx] == self.VVNZut:
     newRow.append(col.strip())
  return newRow
 def VVj5LH(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FF3gfV(col)
 def VVlHhp(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVtVut())
  fileName = fileName.replace("__", "_")
  path  = FFDpEI(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFZR2n()
  return expFile
 def VVan6m(self, expFile):
  FFDeF8(self, "File exported to:\n\n%s" % expFile, title=self.VVtVut())
 def VV9JI3(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   totCols = len(row)
   if row[totCols - 1][0] == 0 : lastCol = totCols - 1
   else      : lastCol = totCols - 2
   x, y, w, h = row[lastCol][1:5]
   self["myTable"].l.setSelectionClip(eRect(0, 0, int(x + w), int(h)), True)
 @staticmethod
 def VVGIbI(x, y, w, h, png, bg=None, bgSel=None):
  typ = eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST
  if VV75x1: return (typ, x, y, w, h, png, bg, bgSel, VV75x1 | CENTER)
  else   : return (typ, x, y, w, h, png, bg, bgSel)
class CCskRx():
 def __init__(self, pixmapObj, picPath, VVSJJk=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VVSJJk  = VVSJJk or "#2200002a"
 def VVrpWO(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVFwk8)
    except:
     self.picLoad.PictureData.get().append(self.VVFwk8)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VVSJJk])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVFwk8(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVIcNY(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VV27Hb(pixmapObj, path, VVSJJk=None):
  cl = CCskRx(pixmapObj, path, VVSJJk)
  ok = cl.VVrpWO()
  if ok: return cl
  else : return None
class CCXzC3(Screen):
 def __init__(self, session, VVlNrK, title="", showGrnMsg="", fileList=None, curIndex=0, fakePath=None, cbFnc=None):
  scrW, scrH = FFrRKK()
  w = 1700
  h = int(min(w * scrH / scrW + 51, 1040))
  self.skin, self.skinParam = FFPFsH(VVcmhN, w, h, 30, 0, 0, "#22000060", "#2200002a", 30, topRightBtns=3)
  self.session  = session
  self.Title   = title
  self["myPic"]  = Pixmap()
  self.VVlNrK = VVlNrK
  self.showGrnMsg  = showGrnMsg
  self.fileList  = fileList
  self.curIndex  = curIndex
  self.fakePath  = fakePath
  self.cbFnc   = cbFnc
  self.picViewer  = None
  FFRFZg(self)
  self["myActionMap"] = ActionMap(VVQOuY,
  {
   "ok" : self.close    ,
   "red" : self.close    ,
   "cancel": self.close    ,
   "info" : self.VVsssC  ,
   "up" : BF(self.VV2plg, -1),
   "down" : BF(self.VV2plg,  1),
   "left" : BF(self.VV2plg, -1),
   "right" : BF(self.VV2plg,  1)
  }, -1)
  self.onShown.append(self.VVnLQg)
  self.onClose.append(self.onExit)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFk6h6(self)
  self.VVEnVS()
  self.picViewer = CCskRx.VV27Hb(self["myPic"], self.VVlNrK)
  if self.picViewer:
   if self.showGrnMsg:
    FFZD7H(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFOyl1(self, "Cannot view picture file:\n\n%s" % self.VVlNrK)
   self.close()
 def onExit(self):
  if self.picViewer: self.picViewer.VVIcNY()
  if self.cbFnc  : self.cbFnc(self.VVlNrK)
 def VV2plg(self, direc):
  if self.fileList:
   oldNdx = self.curIndex
   self.curIndex += direc
   if direc == -1 and self.curIndex < 0      : self.curIndex = len(self.fileList) - 1
   if direc ==  1 and self.curIndex > len(self.fileList) - 1 : self.curIndex = 0
   if not oldNdx == self.curIndex:
    fName = self.fileList[self.curIndex]
    self.VVlNrK = FFDpEI(os.path.dirname(self.VVlNrK)) + fName
    self.picViewer.picPath = self.VVlNrK
    self.picViewer.VVrpWO()
    self.VVEnVS()
 def VVsssC(self):
  txt = "%s:\n  %s" % (FF8oA9("Path", VVRuOi), self.fakePath or self.VVlNrK)
  size, sizeTxt, resTxt, form, mode = CCSwPL.VVLIgA(self.VVlNrK)
  if any((size, sizeTxt, resTxt, form, mode)):
   txt += "\n\n%s:\n" % FF8oA9("Properties", VVRuOi)
   if sizeTxt: txt += "  File Size\t: %s\n" % sizeTxt
   if resTxt : txt += "  Dimensions\t: %s\n" % resTxt
   if form   : txt += "  Format\t: %s\n"  % form
   if mode   : txt += "  Mode\t: %s\n"   % mode
  FFoB4k(self, txt, title="File Information")
 def VVEnVS(self):
  if self.fileList: title = "%d/%d : %s" % (self.curIndex + 1, len(self.fileList), self.fileList[self.curIndex])
  elif self.Title : title = self.Title
  else   : title = os.path.basename(self.VVlNrK)
  self["myTitle"].setText("  %s  " % title)
 @staticmethod
 def VVHZ7h(SELF, VVlNrK, **kwargs):
  SELF.session.open(CCXzC3, VVlNrK, **kwargs)
class CCOh4t(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FFPFsH(VVwhxs, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FFRFZg(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VVnLQg)
  self.onClose.append(self.onExit)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  if not FFqSkC("showiframe %s" % self.mviFile):
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VVNvhD(SELF, mviFile):
  SELF.session.openWithCallback(BF(CCOh4t.VVNLAN, SELF), CCOh4t, mviFile)
 @staticmethod
 def VVNLAN(SELF, reason=None):
  if reason == -1: FFOyl1(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CC1Kd0(Screen, ConfigListScreen):
 VVkVSu = "ajpanel_update_url"
 def __init__(self, session):
  self.skin, self.skinParam = FFPFsH(VVOLrS, 1400, 1050, 50, 15, 15, "#11201010", "#11101010", 27, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFRFZg(self, title=self.Title)
  FFKdfz(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Exit-Button Action (in File Manager and FTP)"    , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Player Bar Hotkey"           , CFG.hotkey_signal    ))
  lst.append(getConfigListEntry("Screenshot"             , CFG.screenshotFType   ))
  lst.append(getConfigListEntry("Subtitle Files Encoding Priority"       , CFG.subtDefaultEnc   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type (defines the player)"   , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("Portal Servers Connection Timeout (seconds)"     , CFG.portalConnTimeout   ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Local Movies and IPTV Download Path"       , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB/etc.) + Package Projects"  , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons/Screenshots/Pictures"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVBkbO()
  self.onShown.append(self.VVnLQg)
 def VVBkbO(self):
  kList = {
    "ok" : self.VV2Iyl   ,
    "green" : self.VVyaMh ,
    "menu" : self.VVzQrh ,
    "cancel": self.VVnraB ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VVQz0a, 0)
     kList["chanDown"] = BF(self["config"].VVQz0a, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(VVQOuY, kList, -1)
  else:
   self["actions"] = ActionMap(VVQOuY, kList, -1)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFk6h6(self)
  FFWIRJ(self["config"])
  FFJI0m(self, self["config"])
  FFFlxX(self)
  self["config"].onSelectionChanged.append(self.VVIuoI)
  self.VVIuoI()
  FFC3pI(self["keyRed"], "#11000000")
  self["keyRed"].show()
 def VVIuoI(self):
  cfg = self["config"].getCurrent()[1]
  if   isinstance(cfg, ConfigDirectory): txt = "Change Path"
  else         : txt = "Show Choices"
  self["keyRed"].setText("OK = %s" % txt)
 def VV2Iyl(self):
  title, item = self["config"].getCurrent()
  if item:
   if   item == CFG.iptvHostsMode   : self.VVtSz1()
   elif item == CFG.MovieDownloadPath   : self.VV2mrv(item, self["config"].getCurrent()[0])
   elif item == CFG.subtDefaultEnc   : self.VV7PAv()
   elif isinstance(item, ConfigDirectory) : self.VVRsy3(item)
   else         : CC1Kd0.VVPHBN(self, item, title)
 @staticmethod
 def VVPHBN(SELF, confItem, title, lst=None, cbFnc=None, isSave=False):
  if not lst:
   if   isinstance(confItem, ConfigYesNo)  : lst = [(True, "ON"), (False, "OFF")]
   elif isinstance(confItem, ConfigSelectionNumber):
    lst = confItem.choices.choices
    if not isinstance(lst[0], tuple)  : lst = [(x, x) for x in lst]
   elif isinstance(confItem, ConfigSelection) : lst = confItem.choices.choices
   else          : return
  curNdx = defNdx = -1
  VVtMHe = []
  for ndx, item in enumerate(lst):
   if len(item) == 1:
    val, txt = ("dum",SEP)
   else:
    val, txt = item
    if   val == confItem.value : curNdx, txt = ndx, VVoIYV + txt
    elif val == confItem.default: defNdx, txt = ndx, VVXAXH + txt
   VVtMHe.append((txt, val))
  if defNdx == -1: defNdx = curNdx
  VVrBns  = ("Current", BF(CC1Kd0.VVH12A, curNdx))
  VVIL24 = ("Default", BF(CC1Kd0.VVH12A, defNdx))
  VVkbkP = FFECK9(SELF, BF(CC1Kd0.VVuk5p, confItem, cbFnc, isSave), VVtMHe=VVtMHe, width=1200, VVIL24=VVIL24, VVrBns=VVrBns, title=title, VVaRsg="#33221111", VVWgai="#33110011")
  VVkbkP.VV27hm(curNdx)
 @staticmethod
 def VVuk5p(confItem, cbFnc, isSave, item=None):
  if not item is None:
   confItem.setValue(item)
   if isSave: FF0UO9(confItem, item)
   if cbFnc: cbFnc()
 @staticmethod
 def VVH12A(ndx, selectionObj, item):
  selectionObj.VV27hm(ndx)
 @staticmethod
 def VV7ScU(confItem, lst):
  for ndx, item in enumerate(lst):
   if item[0] == confItem.value:
    return ndx
  return -1
 def VV2mrv(self, item, title):
  tot = CCEvBr.VVi9NB()
  if tot : FFOyl1(self, "Cannot change while downloading.", title=title)
  else : self.VVRsy3(item)
 def VV7PAv(self):
  curEnc = CFG.subtDefaultEnc.getValue()
  lst = CC2TkW.VVZIq5(self, "", curEnc)
  if lst:
   VVIL24 = ("Default", self.VVhMLL)
   VVrBns  = ("Current", self.VVISuB)
   VVkbkP = FFECK9(self, self.VVueLy, title="Select Priority Encoding", VVtMHe=lst, width=1000, height=1000, VVrBns=VVrBns, VVIL24=VVIL24, VVaRsg="#22220000", VVWgai="#22220000", VVIZXB=True)
   VVkbkP.VVUaEY(curEnc)
 def VVueLy(self, item=None):
  if item:
   txt, enc, ndx = item
   CFG.subtDefaultEnc.setValue(enc)
 def VVhMLL(self, VVkbkP, item): VVkbkP.VVUaEY(VVXZlu)
 def VVISuB(self, VVkbkP, item): VVkbkP.VVUaEY(CFG.subtDefaultEnc.getValue())
 def VVtSz1(self):
  VVtMHe = []
  VVtMHe.append(("Auto Find" , "auto"))
  VVtMHe.append(("Custom Path" , "cust"))
  FFECK9(self, self.VVG73C, VVtMHe=VVtMHe, title="IPTV Hosts Files Path")
 def VVG73C(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVpo4j)
   elif item == "cust":
    VVsLLE = self.VVOr2Q()
    if VVsLLE : self.VVt7q4(VVsLLE)
    else  : self.session.openWithCallback(self.VVOnjR, BF(CCVnYx, mode=CCVnYx.VVW7oj, VVSMX5="/"))
 def VVt7q4(self, VVsLLE):
  VVJi29 = self.VVJ8kW
  VVIzUv = ("Remove"  , self.VVKAfl , [])
  VVM9Pm = ("Add "  , self.VVhPWr, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VV0CnX  = (LEFT   , LEFT  )
  FFDpub(self, None, title="IPTV Hosts Search Paths", header=header, VVcuvv=VVsLLE, width=1200, height=700, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=26, VVJi29=VVJi29, VVIzUv=VVIzUv, VVM9Pm=VVM9Pm
    , VVaRsg="#22220000", VVWgai="#22110000", VVSJJk="#22110011", VVYCZ6="#11223025", VVTjte="#0a333333", VVIyj7="#11400040")
 def VVJ8kW(self, VVdesl):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VVcfm2)
  VVdesl.cancel()
 def VVOnjR(self, path):
  if path:
   FF0UO9(CFG.iptvHostsDirs, FFDpEI(path.strip()))
   VVsLLE = self.VVOr2Q()
   if VVsLLE : self.VVt7q4(VVsLLE)
   else  : FFZD7H(self, "Cannot add dir", 1500)
 def VVxZO1(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVpo4j:
   return []
  return lst
 def VVOr2Q(self):
  lst = self.VVxZO1()
  if lst:
   VVsLLE = []
   for Dir in lst:
    VVsLLE.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVsLLE.sort(key=lambda x: x[0].lower())
   return VVsLLE
  else:
   return []
 def VVhPWr(self, VVdesl, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VVklu7, VVdesl)
         , BF(CCVnYx, mode=CCVnYx.VVW7oj, VVSMX5=sDir))
 def VVklu7(self, VVdesl, path):
  if path:
   path = FFDpEI(path.strip())
   if self.VV0olQ(VVdesl, path):
    FFZD7H(VVdesl, "Already added", 1500)
   else:
    lst = self.VVxZO1()
    lst.append(path)
    FF0UO9(CFG.iptvHostsDirs, ",".join(lst))
    VVsLLE = self.VVOr2Q()
    VVdesl.VV87pY(VVsLLE, tableRefreshCB=BF(self.VVvTtx, path))
 def VVvTtx(self, path, VVdesl, title, txt, colList):
  self.VV0olQ(VVdesl, path)
 def VV0olQ(self, VVdesl, path):
  for ndx, row in enumerate(VVdesl.VVTW2g()):
   if row[0].strip() == path.strip():
    VVdesl.VVTklH(ndx)
    return True
  return False
 def VVKAfl(self, VVdesl, title, txt, colList):
  path = colList[0]
  FFgBNQ(self, BF(self.VV3F1W, VVdesl), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VV3F1W(self, VVdesl):
  row = VVdesl.VV1blE()
  path, rem = row[0], row[1]
  VVsLLE = []
  lst = []
  for ndx, row in enumerate(VVdesl.VVTW2g()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVsLLE.append((tPath, tRem))
  if len(VVsLLE) > 0:
   FF0UO9(CFG.iptvHostsDirs, ",".join(lst))
   VVdesl.VV87pY(VVsLLE)
   FFZD7H(VVdesl, "Deleted", 1500)
  else:
   FF0UO9(CFG.iptvHostsMode, VVpo4j)
   FF0UO9(CFG.iptvHostsDirs, "")
   VVdesl.cancel()
   FFkvVR(BF(FFZD7H, self, "Changed to Auto-Find", 1500))
 def VVRsy3(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VVRNXC, configObj)
         , BF(CCVnYx, mode=CCVnYx.VVW7oj, VVSMX5=sDir))
 def VVRNXC(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVnraB(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFgBNQ(self, self.VVyaMh, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVyaMh(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VV3qB1()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVzQrh(self):
  VVtMHe = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VVtMHe.append((txt    , "VV2Rz9"   ))
  else        : VVtMHe.append((txt    ,       ))
  VVtMHe.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Reset %s Settings" % PLUGIN_NAME      , "VVExb6"   ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Backup %s Settings" % PLUGIN_NAME      , "VVCB9n"  ))
  VVtMHe.append(("Restore %s Settings" % PLUGIN_NAME     , "VV6BDH"  ))
  if fileExists(VVZAJU + CC1Kd0.VVkVSu):
   VVtMHe.append(VVXGzj)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VVtMHe.append(('%s Checking for Update' % txt1     , txt2     ))
   VVtMHe.append(("Reinstall %s" % PLUGIN_NAME      , "VVVknQ"  ))
   VVtMHe.append(("Update %s" % PLUGIN_NAME      , "VVkp59"   ))
  FFECK9(self, self.VVNMEV, VVtMHe=VVtMHe, title="Config. Options")
 def VVNMEV(self, item=None):
  if item:
   if   item == "VV2Rz9"  : FFgBNQ(self, self.VV2Rz9 , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CCtoHe)
   elif item == "VVExb6"  : FFgBNQ(self, BF(self.VVExb6, True), "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VVCB9n" : self.VVCB9n()
   elif item == "VV6BDH" : FFbA1i(self, self.VV6BDH, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FF0UO9(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FF0UO9(CFG.checkForUpdateAtStartup, False)
   elif item == "VVVknQ" : FFbA1i(self, BF(self.VVR5Nu, True ), "Checking Server ...")
   elif item == "VVkp59"  : FFbA1i(self, BF(self.VVR5Nu, False), "Checking Server ...")
 def VVCB9n(self):
  path = "%sajpanel_settings_%s" % (VVZAJU, FFZR2n())
  FFmiBl("grep .%s. %ssettings > %s" % (PLUGIN_NAME, VVKJQA, path))
  FFDeF8(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VV6BDH(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name  = "ajpanel_settings_"
  files = FFYEhL("find / %s -iname '%s*' | grep %s" % (FFXN5L(1), name, name))
  if files:
   err = CCVnYx.VVDb8p(files)
   if err:
    FFgBNQ(self, BF(self.VVqXMW, title), "No valid settings files found !\n\nLocate Manually ?", title=title)
   else:
    files = sorted(files, key=lambda t: -os.stat(t).st_mtime)
    VVtMHe = []
    for line in files:
     VVtMHe.append((line, line))
    FFECK9(self, BF(self.VVGL7Y, title), title=title, VVtMHe=VVtMHe, width=1200, VVNhLF="")
  else:
   FFOyl1(self, "No settings files found !", title=title)
 def VVqXMW(self, title, path=None):
  sDir = "/"
  for path in (VVZAJU, "/media/usb/", "/media/hdd/", "/media/"):
   if pathExists(path):
    sDir = path
    break
  self.session.openWithCallback(BF(self.VVGL7Y, title), BF(CCVnYx, patternMode="ajpSet", VVSMX5=sDir))
 def VVGL7Y(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FF72md(path)
    self.VVExb6()
    for line in lines:
     name, _, val = line.partition("=")
     try:
      confItem = eval(name)
      if confItem is not None:
       if   isinstance(confItem, ConfigInteger)  : val = int(val)
       elif isinstance(confItem, ConfigSelectionNumber): val = int(val)
       elif isinstance(confItem, ConfigYesNo)   : val = { "true": True, "false": False }.get(val.lower())
       if not val is None:
        confItem.setValue(val)
        confItem.save()
     except:
      pass
    self.VV3qB1()
    FFQ71e()
    FFZD7H(self, "Apllied", 1500, isGrn=True)
   else:
    FFbiIe(self, path, title=title)
 def VV2Rz9(self):
  newPath = FFDpEI(VVZAJU)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VV3qB1()
 @staticmethod
 def VVTjpf():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVExb6(self, exit=False):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VV3qB1()
  if exit:
   self.close()
 def VV3qB1(self):
  configfile.save()
  global VVZAJU
  VVZAJU = CFG.backupPath.getValue()
  FF8Zct()
 def VVR5Nu(self, force):
  pre = "Reinstall" if force else "Update"
  title = "%s %s (from server)" % (pre, PLUGIN_NAME)
  curVer, webVer, url, isHigher, err = CC1Kd0.VVhCzz()
  if   err    : FFOyl1(self, err, title)
  elif isHigher or force : FFgBNQ(self, BF(FFbA1i, self, BF(self.VVVFlk, webVer, url, title, force)), "%s v%s and Restart ?" % ("Reinstall" if force else "Upgrade to", webVer), title=title)
  else     : FFDeF8(self, FF8oA9("No update required.", VViZMT) + "\n\nCurrent Version = v%s\n\nWeb Version = v%s" % (curVer, webVer), title)
 def VVVFlk(self, webVer, url, title, force):
  fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if FFUNHV() == "dpkg" else "ipk")
  path, err = FF4VyK(url + fName, fName, timeout=2)
  if path:
   if force: cmd = FFbfXZ(VVkYaB, path)
   else : cmd = FFbfXZ(VVGJh6, path)
   if cmd:
    cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -rf '%s'" % (cmd, path)
    FFyrLj(self, cmd, title=title)
   else:
    FFvp5w(self, title=title)
  else:
   FFOyl1(self, err, title=title)
 @staticmethod
 def VVhCzz():
  span = iSearch(r"v*(\d.\d.\d)", VVQHC8, IGNORECASE)
  if span : curVer = span.group(1)
  else : return "", "", "", False, "Incorrect local version format !"
  path = VVZAJU + CC1Kd0.VVkVSu
  if fileExists(path):
   span = iSearch(r"(http.+)", FFFr8o(path), IGNORECASE)
   if span : url = FFDpEI(span.group(1))
   else : return curVer, "", "", False, err
  else:
   return curVer, "", "", False, "Update File not found:\n\n%s" % path
  path, err = FF4VyK(url + "version", "ajp_tmp.ver", timeout=2)
  if err:
   return curVer, "", url, False, err
  if fileExists(path):
   txt  = FFFr8o(path).strip().replace(" ", "")
   FFOlRe(path)
   span = iSearch(r"v*(\d.\d.\d)", txt.partition("=")[2], IGNORECASE)
   if span:
    webVer = span.group(1)
    webTup = tuple(map(int, (webVer.split("."))))
    curTup = tuple(map(int, (curVer.split("."))))
    return curVer, webVer, url, webTup > curTup, ""
   else:
    return curVer, "", url, False, "Incorrect version format (from server) !"
  else:
   return curVer, "", url, False, "Cannot download Version File !"
class CCtoHe(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFPFsH(VVA7xL, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVECMO
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFRFZg(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VV3rH9("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VV3rH9("\c00888888", i) + sp + "GREY\n"
   txt += self.VV3rH9("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VV3rH9("\c00FF0000", i) + sp + "RED\n"
   txt += self.VV3rH9("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VV3rH9("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VV3rH9("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VV3rH9("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VV3rH9("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VV3rH9("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VV3rH9("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VV3rH9("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(VVQOuY,
  {
   "ok" : self.VV2Iyl ,
   "green" : self.VV2Iyl ,
   "left" : self.VViWA8 ,
   "right" : self.VVpaBZ ,
   "cancel": self.close
  }, -1)
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  self.VV54xX()
 def VV2Iyl(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFgBNQ(self, self.VV7hBW, "Change to : %s" % txt, title=self.Title)
 def VV7hBW(self):
  FF0UO9(CFG.mixedColorScheme, self.cursorPos)
  global VVECMO
  VVECMO = self.cursorPos
  self.VVEYGi()
  self.close()
 def VViWA8(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VV54xX()
 def VVpaBZ(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VV54xX()
 def VV54xX(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VV3rH9(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVsjz9(color):
  if VVXAXH: return "\\" + color
  else    : return ""
 @staticmethod
 def VVEYGi():
  global VVdZck, VVD4un, VVOr14, VVtchu, VV8ETX, VV4mV2, VVmV2z, VVqVbe, VViZMT, VV7z62, VVXAXH, VVRuOi, VVoIYV, VVdVTX, VVbRZL, VV7V3G
  VV7V3G   = CCtoHe.VV3rH9("\c00FFFFFF", VVECMO)
  VVD4un    = CCtoHe.VV3rH9("\c00888888", VVECMO)
  VVdZck  = CCtoHe.VV3rH9("\c005A5A5A", VVECMO)
  VVqVbe    = CCtoHe.VV3rH9("\c00FF0000", VVECMO)
  VVOr14   = CCtoHe.VV3rH9("\c00FF5000", VVECMO)
  VVtchu   = CCtoHe.VV3rH9("\c00FFBB66", VVECMO)
  VVXAXH   = CCtoHe.VV3rH9("\c00FFFF00", VVECMO)
  VVRuOi = CCtoHe.VV3rH9("\c00FFFFAA", VVECMO)
  VViZMT   = CCtoHe.VV3rH9("\c0000FF00", VVECMO)
  VV7z62  = CCtoHe.VV3rH9("\c00AAFFAA", VVECMO)
  VVmV2z    = CCtoHe.VV3rH9("\c000066FF", VVECMO)
  VVoIYV    = CCtoHe.VV3rH9("\c0000FFFF", VVECMO)
  VVdVTX  = CCtoHe.VV3rH9("\c00AAFFFF", VVECMO)  #
  VVbRZL   = CCtoHe.VV3rH9("\c00FA55E7", VVECMO)
  VV8ETX    = CCtoHe.VV3rH9("\c00FF8F5F", VVECMO)
  VV4mV2  = CCtoHe.VV3rH9("\c00FFC0C0", VVECMO)
CCtoHe.VVEYGi()
class CC3sVu(Screen):
 def __init__(self, session, path, VVlAOK):
  self.skin, self.skinParam = FFPFsH(VVOcaS, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVC2kj   = path
  self.VVy3hB   = ""
  self.VVUcNo   = ""
  self.VVlAOK    = VVlAOK
  self.VVoNVC    = ""
  self.VVyolP  = ""
  self.VV87ZR    = False
  self.VVnP0Y  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VVesti  = "enigma2-plugin-extensions-"
  self.VVk0wD  = "enigma2-plugin-systemplugins-"
  self.VVkKQ6 = "enigma2-"
  self.VVt9ie  = 0
  self.VV4ZzM  = 1
  self.VVxdUf  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVyI94 = "DEBIAN"
  else        : self.VVyI94 = "CONTROL"
  self.controlPath = self.Path + self.VVyI94
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVlAOK:
   self.packageExt  = ".deb"
   self.VVSJJk  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVSJJk  = "#11001020"
  FFRFZg(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFKdfz(self["keyRed"] , "Create")
  FFKdfz(self["keyGreen"] , "Post Install")
  FFKdfz(self["keyYellow"], "Installation Path")
  FFKdfz(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(VVQOuY,
  {
   "red"   : self.VVRWY4  ,
   "green"   : self.VVUwkg ,
   "yellow"  : self.VVK4iV  ,
   "blue"   : self.VVRhR8  ,
   "cancel"  : self.VV5TbA
  }, -1)
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFFlxX(self)
  if self.VVSJJk:
   FFC3pI(self["myBody"], self.VVSJJk)
   FFC3pI(self["myLabel"], self.VVSJJk)
  self.VVaQ4k(True)
  self.VVBl82(True)
 def VVBl82(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVjWnE()
  if isFirstTime:
   if   package.startswith(self.VVesti) : self.VVC2kj = VVxCog + self.VVoNVC + "/"
   elif package.startswith(self.VVk0wD) : self.VVC2kj = VVtttO + self.VVoNVC + "/"
   else            : self.VVC2kj = self.Path
  if self.VV87ZR : myColor = VV8ETX
  else    : myColor = VV7V3G
  txt  = ""
  txt += "Source Path\t: %s\n" % FF8oA9(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FF8oA9(self.VVC2kj, VVXAXH)
  if self.VVUcNo : txt += "Package File\t: %s\n" % FF8oA9(self.VVUcNo, VVD4un)
  elif errTxt   : txt += "Warning\t: %s\n"  % FF8oA9("Check Control File fields : %s" % errTxt, VVOr14)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FF8oA9("Restart GUI", VV8ETX)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FF8oA9("Reboot Device", VV8ETX)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FF8oA9("Post Install", VViZMT), act)
  if not errTxt and VVOr14 in controlInfo:
   txt += "Warning\t: %s\n" % FF8oA9("Errors in control file may affect the result package.", VVOr14)
  txt += "\nControl File\t: %s\n" % FF8oA9(self.controlFile, VVD4un)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVUwkg(self):
  if self["keyGreen"].getVisible():
   VVtMHe = []
   VVtMHe.append(("No Action"    , "noAction"  ))
   VVtMHe.append(("Restart GUI"    , "VVAex6"  ))
   VVtMHe.append(("Reboot Device"   , "rebootDev"  ))
   FFECK9(self, self.VVScJd, title="Package Installation Option (after completing installation)", VVtMHe=VVtMHe)
 def VVScJd(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVAex6"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVaQ4k(False)
   self.VVBl82()
 def VVK4iV(self):
  rootPath = FF8oA9("/%s/" % self.VVoNVC, VVRuOi)
  VVtMHe = []
  VVtMHe.append(("Current Path"        , "toCurrent"  ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Extension Path"       , "toExtensions" ))
  VVtMHe.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVtMHe.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFECK9(self, self.VVH7MW, title="Installation Path", VVtMHe=VVtMHe)
 def VVH7MW(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VV9Mef(FFG1q8(self.Path, True))
   elif item == "toExtensions"  : self.VV9Mef(VVxCog)
   elif item == "toSystemPlugins" : self.VV9Mef(VVtttO)
   elif item == "toRootPath"  : self.VV9Mef("/")
   elif item == "toRoot"   : self.VV9Mef("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VV7DGR, BF(CCVnYx, mode=CCVnYx.VVW7oj, VVSMX5=VVZAJU))
 def VV7DGR(self, path):
  if len(path) > 0:
   self.VV9Mef(path)
 def VV9Mef(self, parent, withPackageName=True):
  if withPackageName : self.VVC2kj = parent + self.VVoNVC + "/"
  else    : self.VVC2kj = "/"
  mode = self.VVjL6D()
  FFqSkC("sed -i '/Package/c\Package: %s' %s" % (self.VVt8zZ(mode), self.controlFile))
  self.VVBl82()
 def VVRhR8(self):
  if fileExists(self.controlFile):
   lines = FF72md(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFdnKb(self, self.VVgDLZ, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFOyl1(self, "Version not found or incorrectly set !")
  else:
   FFbiIe(self, self.controlFile)
 def VVgDLZ(self, VVfJks):
  if VVfJks:
   version, color = self.VVXOV5(VVfJks, False)
   if color == VVoIYV:
    FFqSkC("sed -i '/Version:/c\Version: %s' %s" % (VVfJks, self.controlFile))
    self.VVBl82()
   else:
    FFOyl1(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VV5TbA(self):
  if self.newControlPath:
   if self.VV87ZR:
    self.VVZ1Gw()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FF8oA9(self.newControlPath, VVD4un)
    txt += FF8oA9("Do you want to keep these files ?", VVXAXH)
    FFgBNQ(self, self.close, txt, callBack_No=self.VVZ1Gw, title="Create Package", VVMgjE=True)
  else:
   self.close()
 def VVZ1Gw(self):
  FFqSkC("rm -rf '%s'" % self.newControlPath)
  self.close()
 def VVt8zZ(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VVyolP
  if package.startswith(self.VVkKQ6):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VVkKQ6, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VV4ZzM : prefix = self.VVesti
  elif mode == self.VVxdUf : prefix = self.VVk0wD
  return (prefix + name).lower()
 def VVjL6D(self):
  if   self.VVC2kj.startswith(VVxCog) : return self.VV4ZzM
  elif self.VVC2kj.startswith(VVtttO) : return self.VVxdUf
  else            : return self.VVt9ie
 def VVaQ4k(self, isFirstTime):
  self.VVoNVC   = FFd4tO(self.Path)
  self.VVoNVC   = "_".join(self.VVoNVC.split())
  self.VVyolP = self.VVoNVC.lower()
  self.VV87ZR = self.VVyolP == VV2see.lower()
  if self.VV87ZR and self.VVyolP.endswith(VV2see.lower()):
   self.VVyolP += "el"
  if self.VV87ZR : self.VVy3hB = VVZAJU
  else    : self.VVy3hB = CFG.packageOutputPath.getValue()
  self.VVy3hB = FFDpEI(self.VVy3hB)
  if not pathExists(self.controlPath):
   FFqSkC("mkdir '%s'" % self.controlPath)
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VVjL6D()
  if fileExists(self.controlFile):
   lines = FF72md(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VV87ZR : version, descripton, maintainer = VVQHC8 , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVoNVC , self.VVoNVC
   txt = ""
   txt += "Package: %s\n"  % self.VVt8zZ(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VV87ZR : t = PLUGIN_NAME
  else    : t = self.VVoNVC
  self.VVJP8H(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VVJP8H(self.postrmFile, "echo 'Package removed.'\n")
  if self.VV87ZR : self.VVJP8H(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVQHC8))
  else    : self.VVJP8H(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVoNVC)
  if isFirstTime and not mode == self.VVt9ie:
   self.postInstAcion = 1
  txt = self.VVWfQS(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFFr8o(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VVWfQS(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  FFqSkC("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile))
 def VVJP8H(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VVWfQS(self, action):
  sep  = "echo '%s'\n" % SEP
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VVjWnE(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FF72md(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FF8oA9(line, VVOr14)
     elif not line.startswith(" ")    : line = FF8oA9(line, VVOr14)
     else          : line = FF8oA9(line, VVoIYV)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVoIYV
   else   : color = VVOr14
   descr = FF8oA9(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVOr14
     elif line.startswith((" ", "\t")) : color = VVOr14
     elif line.startswith("#")   : color = VVD4un
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVXOV5(val, True)
      elif key == "Version"  : version, color = self.VVXOV5(val, False)
      elif key == "Maintainer" : maint  , color = val, VVoIYV
      elif key == "Architecture" : arch  , color = val, VVoIYV
      else:
       color = VVoIYV
      if not key == "OE" and not key.istitle():
       color = VVOr14
     else:
      color = VV8ETX
     txt += FF8oA9(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVUcNo = self.VVy3hB + packageName
   self.VVnP0Y = True
   errTxt = ""
  else:
   self.VVUcNo  = ""
   self.VVnP0Y = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVXOV5(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVoIYV
  else          : return val, VVOr14
 def VVRWY4(self):
  if not self.VVnP0Y:
   FFOyl1(self, "Please fix Control File errors first.")
   return
  if self.VVlAOK: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFG1q8(self.VVC2kj, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVoNVC
  symlinkTo  = FF55ZU(self.Path)
  dataDir   = self.VVC2kj.rstrip("/")
  removePorjDir = FFb0lc("rm -rf '%s'"  % projDir)
  cmd  = ""
  cmd += FFb0lc("rm -f '%s'" % self.VVUcNo)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFfDPF()
  if self.VVlAOK:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFv2CR("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VV87ZR:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVC2kj == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVyI94)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVUcNo, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVUcNo
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVUcNo, FFP1gK(result  , VViZMT))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVC2kj, FFP1gK(instPath, VVoIYV))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFP1gK(failed, VVOr14))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFyrLj(self, cmd)
class CCotiQ():
 VVOHuQ  = "666"
 VVm8is   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.VVkbkP   = None
  self.VVryRl()
 def VVryRl(self):
  VVtMHe = CCotiQ.VVq4e6()
  if VVtMHe:
   VVIL24 = ("Create New", self.VVKaQ3)
   self.VVkbkP = FFECK9(self.SELF, self.VVZ4do, VVtMHe=VVtMHe, title=self.Title, VVIL24=VVIL24, VVIZXB=True, VVaRsg="#22222233", VVWgai="#22222233")
  else:
   self.VVKaQ3()
 def VVZ4do(self, item):
  if item:
   bName, bRef, ndx = item
   self.VVpsdu(bName, bRef)
  else:
   CCotiQ.VVgklg(self)
 def VVKaQ3(self, selectionObj=None, item=None):
  FFdnKb(self.SELF, BF(self.VVf50x), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVf50x(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.VVkbkP:
     self.VVkbkP.cancel()
    self.VVpsdu(bName, "")
   else:
    FFZD7H(self.VVkbkP, "Incorrect Bouquet Name !", 2000)
    CCotiQ.VVgklg(self)
 def VVpsdu(self, bName, bRef):
  FFbA1i(self.waitMsgSELF, BF(self.VVUH2r, bName, bRef), title="Adding Services ...")
 def VVUH2r(self, bName, bRef):
  CCotiQ.VVvpYd(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VVgklg(classObj):
  del classObj
 @staticmethod
 def VVvpYd(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FFOyl1(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVKJQA + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FFbiIe(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CCotiQ.VVaqE5(bRef)
   bPath = VVKJQA + bFile
  else:
   fName = CCoUhv.VVFP7U(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVKJQA + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVKJQA + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  FF2Usq(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   FF2Usq(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CCuqLp.VVchM7()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       FFqSkC("cp -f '%s' '%s'" % (poster, picon))
       FFqSkC(CCqIel.VVIyOc(picon))
       break
  FFjaui()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FFoB4k(SELF, txt, title=title)
 @staticmethod
 def VVESJ4(bName):
  mode = CCQIeq.VVIWfk(default=-1)
  modeTxt = "tv" if mode == 0 else "radio"
  fName = CCoUhv.VVFP7U(bName)
  bFile = "userbouquet.%s.%s" % (fName, modeTxt)
  num   = 0
  while fileExists(VVKJQA + bFile):
   num += 1
   bFile = "userbouquet.%s_%d.%s" % (fName, num, modeTxt)
  with open(VVKJQA + bFile, "w") as f:
   f.write("#NAME %s\n" % bName)
  mainBFile = "%sbouquets.%s" % (VVKJQA, modeTxt)
  if fileExists(mainBFile):
   FF2Usq(mainBFile)
   with open(mainBFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
 @staticmethod
 def VVQGdj(ref, bName):
  bFile = CCotiQ.VVaqE5(ref)
  ok = False
  if bFile:
   bFile = VVKJQA + bFile
   if fileExists(bFile):
    lines = FF72md(bFile, keepends=True)
    with open(bFile, "w") as f:
     for line in lines:
      if line.startswith("#NAME "):
       f.write("#NAME %s\n" % bName)
       ok = True
      else:
       f.write(line)
  return ok
 @staticmethod
 def VVq4e6(mode=2, showTitle=True, prefix="", onlyIptv=False):
  VVtMHe = []
  if mode in (0, 2): VVtMHe.extend(CCotiQ.VVOSAg(0, showTitle, prefix, onlyIptv))
  if mode in (1, 2): VVtMHe.extend(CCotiQ.VVOSAg(1, showTitle, prefix, onlyIptv))
  return VVtMHe
 @staticmethod
 def VVOSAg(mode, showTitle, prefix, onlyIptv):
  VVtMHe = []
  lst = CCotiQ.VVx5Ko(mode)
  if onlyIptv:
   lst = CCotiQ.VVqiWV(lst)
  if lst:
   if showTitle:
    VVtMHe.append(FF5f5W("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVtMHe.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVtMHe.append((item[0], item[1].toString()))
  return VVtMHe
 @staticmethod
 def VVqiWV(lst):
  fLst = CCoUhv.VVDteM(onlyFileName=True)
  newLst = []
  if fLst:
   for item in lst:
    span = iSearch(r".+(userbouquet\..+\.(tv|radio))", item[1].toString())
    if span and span.group(1) in fLst:
     newLst.append(item)
  return newLst
 @staticmethod
 def VV1U2X():
  lst = CCotiQ.VVx5Ko(0)
  lst.extend(CCotiQ.VVx5Ko(1))
  return lst
 @staticmethod
 def VVx5Ko(mode=0):
  bList = []
  VVLbeP = InfoBar.instance
  VVIh3I = VVLbeP and VVLbeP.servicelist
  if VVIh3I:
   curMode = VVIh3I.mode
   CCotiQ.VVQAYe(VVIh3I, mode)
   bList.extend(VVIh3I.getBouquetList() or [])
   CCotiQ.VVQAYe(VVIh3I, curMode)
  return bList
 @staticmethod
 def VVQAYe(VVIh3I, mode):
  if not mode == VVIh3I.mode:
   if   mode == 0: VVIh3I.setModeTv()
   elif mode == 1: VVIh3I.setModeRadio()
 @staticmethod
 def VVkd0a(isAll=True, onlyMain=False):
  bLst = []
  inst = InfoBar.instance
  if inst:
   csel = inst.servicelist
   if csel:
    root = csel.bouquet_root
    VVcpye = eServiceCenter.getInstance()
    if onlyMain:
     info = VVcpye.info(root)
     if info:
      bLst.append((info.getName(root), root.toString()))
    else:
     list = VVcpye and VVcpye.list(root)
     if list:
      while True:
       s = list.getNext()
       if not s.valid():
        break
       if isAll or (s.flags & eServiceReference.isDirectory and not s.flags & eServiceReference.isInvisible):
        info = VVcpye.info(s)
        if info:
         bLst.append((info.getName(s), s.toString()))
  return bLst
 @staticmethod
 def VVaqE5(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : return ""
 @staticmethod
 def VVpP52(ref, dstFile):
  dstFile = VVKJQA + dstFile
  if fileExists(dstFile):
   FF2Usq(dstFile)
   bLine = ""
   srcFile = CCotiQ.VVaqE5(ref)
   if srcFile:
    span = iSearch(r"\.(.+)\.(tv|radio)", srcFile, IGNORECASE)
    if span:
     fName, fType = span.group(1), span.group(2)
     newName = "userSubBouquet.%s.%s" % (fName, fType)
     num = 0
     while fileExists(VVKJQA + newName):
      num += 1
      newName = "userSubBouquet.%s_%d.%s" % (fName, num, fType)
     subFile = VVKJQA + newName
     FFqSkC("cp -f '%s%s' '%s'" % (VVKJQA, srcFile, subFile))
     if fileExists(subFile):
      bLine = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % newName
   else:
    bLine = ref
   if bLine:
    if fileExists(dstFile):
     with open(dstFile, "a") as f:
      f.write("#SERVICE %s\n" % bLine)
     return True
  return False
 @staticmethod
 def VVON60():
  try:
   fName = CCotiQ.VVaqE5(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVKJQA, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VVFiWm():
  path = CCotiQ.VVON60()
  if path:
   txt = FFFr8o(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VV6s7T():
  return FF6kZn(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VVuL2Z():
  lst = []
  for b in CCotiQ.VV1U2X():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVKJQA + CCotiQ.VVaqE5(bRef)
   if fileExists(path):
    lines = FF72md(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VVcdFW(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VVt3gB(SID="", stripRType=False):
  if SID : patt = CCotiQ.VVcdFW(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CCotiQ.VV1U2X():
   for service in FF6kZn(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VVKKit():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CCotiQ.VV1U2X():
   for service in FF6kZn(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VVevo1(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VVIsQk(pathLst, rType=""):
  refLst = CCotiQ.VVt3gB(CCotiQ.VVOHuQ, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = rType or CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CCotiQ.VVevo1(rType, CCotiQ.VVOHuQ, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CCVnYx(Screen):
 VVcJJB   = 0
 VVHgbC  = 1
 VVW7oj  = 2
 VVfg2B = 3
 VVb7kj    = 20
 VVT2Ln   = 0
 VV8PGh   = 1
 VVbHXa   = 2
 def __init__(self, session, VVSMX5="/", mode=VVcJJB, VVyIuw="Select", width=1400, height=920, VVGNdU=30, VVaRsg="#22001111", VVWgai="#22000000", pickTitleBG="#11001144", pickBodyBG="#11002255", cursorBG="#06003333", gotoMovie=False, jumpToFile="", patternMode=""):
  self.skin, self.skinParam = FFPFsH(VVMjBN, width, height, 30, 40, 20, VVaRsg, VVWgai, VVGNdU, barHeight=40, topRightBtns=2)
  self.session   = session
  self.VVaRsg   = VVaRsg
  self.VVWgai    = VVWgai
  self.pickTitleBG  = pickTitleBG
  self.pickBodyBG   = pickBodyBG
  FFRFZg(self)
  FFKdfz(self["keyRed"] , "Exit")
  FFKdfz(self["keyYellow"], "More Options")
  FFKdfz(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVyIuw = VVyIuw
  self.jumpToFile   = jumpToFile
  self.patternMode  = patternMode
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = cursorBG
  self.multiSelectState = False
  VVAncz = None
  if patternMode:
   self.mode = self.VVfg2B
   if   patternMode == "srt"  : VVAncz = ("^.*\.srt$"    , IGNORECASE)
   elif patternMode == "ajpSet" : VVAncz = ("^.*\/ajpanel_settings_" , 0    )
   elif patternMode == "poster" : VVAncz = ("^.*\.(jpg|png)$"    , IGNORECASE)
   elif patternMode == "pkgCtrl": VVAncz = ("^.*\/(control|preinst|prerm|postinst|postrm)$", 0)
   elif patternMode == "movies" : VVAncz = ("^.*\.(%s)$" % "|".join(CCXPWq.VVbz66()["mov"]), IGNORECASE)
   else       : VVAncz = None
  if self.mode in (self.VVW7oj, self.VVfg2B):
   FFKdfz(self["keyRed"], "Cancel")
  if   self.jumpToFile       : VVoNaJ, self.VVSMX5 = True , FFG1q8(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VVoNaJ, self.VVSMX5 = True , CCVnYx.VVASTW(self)[1] or "/"
  elif self.mode == self.VVcJJB  : VVoNaJ, self.VVSMX5 = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVW7oj : VVoNaJ, self.VVSMX5 = False, VVSMX5
  elif self.mode == self.VVfg2B : VVoNaJ, self.VVSMX5 = True , VVSMX5
  else           : VVoNaJ, self.VVSMX5 = True , VVSMX5
  self.VVSMX5 = FFDpEI(self.VVSMX5)
  self["myMenu"] = CCXPWq(  directory   = None
         , VVAncz = VVAncz
         , VVoNaJ   = VVoNaJ
         , VVpIzu = True
         , VVQJbs = True
         , VVeSt7   = self.skinParam["width"]
         , VVGNdU   = self.skinParam["bodyFontSize"]
         , VVavwW  = self.skinParam["bodyLineH"] )
  self["myActionMap"] = ActionMap(VVQOuY,
  {
   "ok" : self.VV2Iyl    ,
   "red" : self.VVX2dX   ,
   "green" : self.VV5R24,
   "yellow": self.VVZ7F2  ,
   "blue" : self.VVhkKk ,
   "menu" : self.VVCLPP  ,
   "info" : self.VVeWi8  ,
   "cancel": self.VVBxXQ    ,
   "pageUp": self.VVsrZo   ,
   "chanUp": self.VVsrZo
  }, -1)
  FFfyBc(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VV0sXm)
  global VV9pVc
  VV9pVc = True
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.mode == self.VVcJJB:
   FFLJqp("VV9pVc")
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VV0sXm)
  FFk6h6(self)
  FFWIRJ(self["myMenu"], bg=self.cursorBG)
  FFFlxX(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVW7oj, self.VVfg2B):
   FFKdfz(self["keyGreen"], self.VVyIuw)
   self.VVjATv(self.VV8PGh)
  self.VV0sXm()
  w  = self["myMenu"].instance.size().width()
  h  = self["myMenu"].instance.size().height()
  pos  = self["myMenu"].getPosition()
  part = self["myMenu"].instance.size().height() % self.skinParam["bodyLineH"]
  half = int(part / 2)
  self["myMenu"].instance.resize(eSize(*(w, h - part)))
  self["myMenu"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.VV9Fn2(self.VVSMX5) > self.bigDirSize: FFbA1i(self, self.VVDCeb, title="Changing directory...")
  else              : self.VVDCeb()
 def VVDCeb(self):
  if self.jumpToFile : self.VV07E0(self.jumpToFile)
  elif self.gotoMovie : self.VV9oA3(chDir=False)
  else    : self["myMenu"].VVzXBY(self.VVSMX5)
 def VVTklH(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVXcc0(self):
  FFbA1i(self, self.VVgg0L, title="Refreshing list ...")
 def VVgg0L(self):
  isSel = self["myMenu"].VVlT28()
  if not isSel:
   self.VVf1RL(False)
  FFAIFB()
 def VVmaFH(self, saved):
  if saved: self.VVXcc0()
 def VV9Fn2(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VV2Iyl(self):
  if self.multiSelectState:
   ok = self["myMenu"].VV9gNH()
   if ok : self["keyBlue"].setText(self.VVuKrc())
   else : FFZD7H(self, "Cannot select item", 500)
  elif self["myMenu"].VVsX2Y(): self.VVsVGE()
  else       : self.VVLcF7()
 def VVsrZo(self):
  if self.multiSelectState:
   FFZD7H(self, "Disable Multi-Select first", 1000)
  else:
   self["myMenu"].moveToIndex(0)
   if self["myMenu"].VVYdJB():
    self.VVsVGE()
 def VVsVGE(self, isDirUp=False):
  if self["myMenu"].VVsX2Y():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VVppQG(self.VVZo19())
   if self.VV9Fn2(path) > self.bigDirSize : FFbA1i(self, self.VV2294, title="Changing directory...")
   else           : self.VV2294()
 def VV2294(self):
  self["myMenu"].descent()
  self.VV0sXm()
 def VVBxXQ(self):
  if   self.multiSelectState     : self.VVf1RL(False, True)
  elif CFG.FileManagerExit.getValue() == "e" : self.VVX2dX()
  else          : self.VVsrZo()
 def VVX2dX(self):
  if not FFDiFh(self):
   self.close("")
 def VV5R24(self):
  path = self.VVppQG(self.VVZo19())
  if self.mode == self.VVW7oj:
   self.close(path)
  elif self.mode == self.VVfg2B:
   if os.path.isfile(path) : self.close(path)
   else     : FFZD7H(self, "Cannot access this file", 1000)
 def VVeWi8(self):
  FFbA1i(self, self.VVMnUv, title="Calculating size ...")
 def VVMnUv(self):
  path = self.VVppQG(self.VVZo19())
  param = self.VVU5Xm(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFvL4V("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCVnYx.VV0ibt(path)
     freeSize = CCVnYx.VVP9pE(path)
     size = totSize - freeSize
     totSize  = CCVnYx.VVI3LQ(totSize)
     freeSize = CCVnYx.VVI3LQ(freeSize)
    else:
     size = FFOcJX(path)
   usedSize = CCVnYx.VVI3LQ(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FF8oA9(pathTxt, VV8ETX) + "\n"
   if slBroken : fileTime = self.VVc60X(path)
   else  : fileTime = self.VV27ra(path)
   def VVc2G6(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVc2G6("Path"    , pathTxt)
   txt += VVc2G6("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVc2G6("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVc2G6("Total Size"   , "%s" % totSize)
    txt += VVc2G6("Used Size"   , "%s" % usedSize)
    txt += VVc2G6("Free Size"   , "%s" % freeSize)
   else:
    txt += VVc2G6("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVc2G6("Owner"    , owner)
   txt += VVc2G6("Group"    , group)
   txt += VVc2G6("Perm. (User)"  , permUser)
   txt += VVc2G6("Perm. (Group)"  , permGroup)
   txt += VVc2G6("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVc2G6("Perm. (Ext.)" , permExtra)
   txt += VVc2G6("iNode"    , iNode)
   txt += VVc2G6("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (SEP, SEP)
    txt += hLinkedFiles
   txt += self.VV0lGk(path)
  else:
   FFOyl1(self, "Cannot access information !")
  if len(txt) > 0:
   FFoB4k(self, txt)
 def VVU5Xm(self, path):
  path = path.strip()
  path = FF55ZU(path)
  result = FFvL4V("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VV1Csf(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VV1Csf(perm, 1, 4)
   permGroup = VV1Csf(perm, 4, 7)
   permOther = VV1Csf(perm, 7, 10)
   permExtra = VV1Csf(perm, 10, 100)
   typeChar = perm[0:1]
   typeStr = {"-":"File", "b":"Block Device File", "c":"Character Device File", "d":"Directory", "e":"External Link", "l":"Symbolic Link", "n":"Network File", "p":"Named Pipe", "s":"Local Socket File"}.get(typeChar, "Unknown")
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFjwNC("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VV0lGk(self, path):
  txt  = ""
  res  = FFvL4V("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = {"a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file"}
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FF8oA9("File Attributes:", VVbRZL), txt)
  return txt
 def VV27ra(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFt4wC(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFt4wC(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFt4wC(os.path.getctime(path))
  return txt
 def VVc60X(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFvL4V("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFvL4V("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFvL4V("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVppQG(self, currentSel):
  currentDir  = self["myMenu"].VVjLjx()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVsX2Y():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVZo19(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VV0sXm(self):
  path = self.VVppQG(self.VVZo19())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VVQ1u3()
  if self.mode == self.VVcJJB:
   if len(path) > 0: self["keyMenu"].show()
   else   : self["keyMenu"].hide()
  if self.mode == self.VVfg2B:
   path = self.VVppQG(self.VVZo19())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VVCLPP(self):
  color1 = VV4mV2
  color2 = VVRuOi
  color3 = VVdVTX
  totSel = 0
  menuW = 1000
  title = "Options"
  VVtMHe= []
  if self.multiSelectState:
   menuW = 850
   totSel = self["myMenu"].VV6kXD()
   if totSel > 0:
    if iTar:
     txt1 = "Archive to .tar.gz"
     txt2 = " (Preserve Path Structure)"
     title = "Options  (%d item%s)" % (totSel, FFsfSO(totSel))
     VVtMHe.append((color1 + txt1     , "VVa4um1" ))
     VVtMHe.append((color1 + txt1 + txt2   , "VVa4um2" ))
     VVtMHe.append(VVXGzj)
    VVtMHe.append(("[6] Copy"       , "copyBulk" ))
    VVtMHe.append(("[7] Move"       , "moveBulk" ))
    VVtMHe.append(("[8] %sDELETE" % VV8ETX , "VVx0S1" ))
   else:
    FFZD7H(self, "Nothing selected", 700)
    return
  elif self.mode in (self.VVW7oj, self.VVfg2B):
   VVtMHe.append(("Properties"           , "properties" ))
   VVtMHe.append(VVXGzj)
   VVtMHe.append((color3 + "Create New Directory (in current directory)" , "createNewDir"))
  else:
   menuW = 1000
   path  = self.VVppQG(self.VVZo19())
   isEditable = self["myMenu"].VVeWQG()
   VVtMHe.append(("Properties", "properties"))
   if os.path.isdir(path):
    if isEditable:
     VVtMHe.append(VVXGzj)
     VVtMHe.append((color1 + "Archiving / Packaging", "VVS70b_dir"))
   elif os.path.isfile(path):
    selFile = self.VVZo19()
    isArch = selFile.endswith((".tar", ".gz", ".tar.bz2", "tar.xz", ".zip", ".rar"))
    if not isArch:
     VVtMHe.append((color1 + "Archive ...", "VVS70b_file"))
    isText = False
    txt = ""
    if   isArch            : VVtMHe.extend(self.VVyueN(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith((".m3u", ".m3u8"))    : VVtMHe.extend(self.VVCusr(True))
    elif selFile.endswith(".sh"):
     VVtMHe.extend(self.VVlXF5(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CCVnYx.VVq7OD(path):
     VVtMHe.append(VVXGzj)
     VVtMHe.append((color2 + "View"     , "textView_def"))
     VVtMHe.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVtMHe.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VV3Hec(path) == "pic":
     VVtMHe.append(VVXGzj)
     VVtMHe.append((color2 + "Set as PIcon for current channel" , "VVgeOn" ))
     if FFLsle("ffmpeg") and selFile.lower().endswith((".jpg", ".png")):
      VVtMHe.append(VVXGzj)
      VVtMHe.append((color2 + "Convert to MVI (1280 x 720 )" , "VVWYx5Hd"   ))
      VVtMHe.append((color2 + "Convert to MVI (1920 x 1080)" , "VVWYx5Fhd"   ))
    elif selFile.endswith(CCVnYx.VVAviw()):
     if selFile.endswith(".mvi"):
      if FFLsle("showiframe"):
       VVtMHe.append(VVXGzj)
       VVtMHe.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVtMHe.append(VVXGzj)
      VVtMHe.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVtMHe.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
      VVtMHe.append((color2 + "Play with ..."       , "playWith"    ))
    if isText:
     VVtMHe.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVtMHe.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVtMHe.append((color1 + "Convert Line-Breaks to Unix Format..." , "VVtfbo" ))
    if len(txt) > 0:
     VVtMHe.append(VVXGzj)
     VVtMHe.append((color1 + txt, "VVLcF7"))
   VVtMHe.append(VVXGzj)
   VVtMHe.append(("[4] Create SymLink", "VVyaLq"))
   if isEditable:
    VVtMHe.append(("[5] Rename"      , "VVSBGs" ))
    VVtMHe.append(("[6] Copy"       , "copyFileOrDir" ))
    VVtMHe.append(("[7] Move"       , "moveFileOrDir" ))
    VVtMHe.append(("[8] %sDELETE" % VV8ETX , "VVc2eV" ))
    if fileExists(path):
     VVtMHe.append(VVXGzj)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVtMHe.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVtMHe.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVtMHe.append((chmodTxt + "777)", "chmod777"))
   VVtMHe.append(VVXGzj)
   VVtMHe.append((color3 + "Create New File (in current directory)"  , "createNewFile" ))
   VVtMHe.append((color3 + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCVnYx.VVASTW(self)
   if fPath:
    VVtMHe.append(VVXGzj)
    VVtMHe.append((color2 + "Go to Current Movie Dir", "VV9oA3"))
  FFECK9(self, self.VV8oQF, width=menuW, height=1050, title=title, VVtMHe=VVtMHe, VVSdJg=False, VVaRsg="#00101020", VVWgai="#00101A2A")
 def VV8oQF(self, item=None):
  if item is not None:
   path = self.VVppQG(self.VVZo19())
   selFile = self.VVZo19()
   if   item == "VVa4um1"    : self.VVa4um(False)
   if   item == "VVa4um2"    : self.VVa4um(True)
   elif item == "copyBulk"     : self.VVr8rq(False)
   elif item == "moveBulk"     : self.VVr8rq(True)
   elif item == "VVx0S1"    : self.VVx0S1()
   elif item == "properties"    : self.VVeWi8()
   elif item == "VVS70b_dir" : self.VVS70b(path, True)
   elif item == "VVS70b_file" : self.VVS70b(path, False)
   elif item == "VVNwye"  : self.VVNwye(path)
   elif item == "VV3avY"  : self.VV3avY(path)
   elif item.startswith("extract_")  : self.VV1Unv(path, selFile, item)
   elif item.startswith("script_")   : self.VVOBvJ(path, selFile, item)
   elif item.startswith("m3u_")   : self.VVueFX(path, selFile, item)
   elif item.startswith("textView_def") : FFxhJI(self, path)
   elif item.startswith("textView_enc") : self.VVr3bi(path)
   elif item.startswith("text_Edit")  : CCiazU(self, path, VVCBqA=self.VVmaFH)
   elif item.startswith("textSave_encUtf8"): self.VVMAJ1(path, "Save as UTF-8"   , True)
   elif item.startswith("textSave_encOthr"): self.VVMAJ1(path, "Save as Other Encoding", False)
   elif item.startswith("VVtfbo") : self.VVtfbo(path)
   elif item == "viewAsBootlogo"   : self.VVq9NS(path, True)
   elif item == "addMovieToBouquet"  : self.VVNUvD(path, False)
   elif item == "addAllMoviesToBouquet" : self.VVNUvD(path, True)
   elif item == "playWith"     : self.VVqvXT(path)
   elif item == "VVgeOn" : self.VVgeOn(path)
   elif item == "VVWYx5Hd"   : FFbA1i(self, BF(self.VVWYx5, path, False))
   elif item == "VVWYx5Fhd"   : FFbA1i(self, BF(self.VVWYx5, path, True))
   elif item == "VVyaLq"   : self.VVyaLq(path, selFile)
   elif item == "VVSBGs"   : self.VVSBGs(path, selFile)
   elif item == "copyFileOrDir"   : self.VVmCjy(path, False)
   elif item == "moveFileOrDir"   : self.VVmCjy(path, True)
   elif item == "VVc2eV"   : self.VVc2eV(path, selFile)
   elif item == "chmod644"     : self.VVhPK4(path, selFile, "644")
   elif item == "chmod755"     : self.VVhPK4(path, selFile, "755")
   elif item == "chmod777"     : self.VVhPK4(path, selFile, "777")
   elif item == "createNewFile"   : self.VVjmqU(path, True)
   elif item == "createNewDir"    : self.VVjmqU(path, False)
   elif item == "VV9oA3"   : self.VV9oA3()
   elif item == "VVLcF7"    : self.VVLcF7()
 def VVLcF7(self):
  if self.mode == self.VVfg2B and not self.patternMode == "poster":
   return
  selFile = self.VVZo19()
  path  = self.VVppQG(selFile)
  if os.path.isfile(path):
   cat = self["myMenu"].VV3Hec(path)
   if   cat == "pic"       : self.VVV09F(path)
   elif cat == "txt"       : FFxhJI(self, path)
   elif cat in ("tar", "zip", "rar")   : self.VVXkQ1(path, selFile)
   elif cat == "scr"       : self.VVxuH9(path, selFile)
   elif cat == "m3u"       : self.VVHYUo(path, selFile)
   elif cat in ("ipk", "deb")     : self.VVSx6D(path, selFile)
   elif cat in ("mov", "mus")     : self.VVq9NS(path)
   elif not CCVnYx.VVq7OD(path) : FFxhJI(self, path)
 def VVV09F(self, path):
  curIndex = 0
  curFile = os.path.basename(path)
  lst = []
  for item in self["myMenu"].list:
   if not item[0][1]:
    category = self["myMenu"].VV3Hec(item[1][7])
    if category == "pic":
     if curFile == item[1][7]:
      curIndex = len(lst)
     lst.append(item[1][7])
  CCXzC3.VVHZ7h(self, path, fileList=lst, curIndex=curIndex, cbFnc=self.VVOSxV)
 def VVOSxV(self, path):
  self.VV07E0(path)
 def VVq9NS(self, path, asLogo=False):
  if asLogo : CCOh4t.VVNvhD(self, path)
  else  : FFbA1i(self, BF(self.VVWQNk, self, path), title="Playing Media ...")
 def VVhkKk(self):
  if self["keyBlue"].getVisible():
   VVcuvv = self.VVyfgS()
   if VVcuvv:
    path = self.VVppQG(self.VVZo19())
    enableGreenBtn = False if path in self.VVyfgS() else True
    newList = []
    for line in VVcuvv:
     newList.append((line, line))
    VVEJLl  = ("Delete"    , self.VVdSoP    )
    VVI3Sz  = ("Add Current Dir"   , BF(self.VVSQLW, path) ) if enableGreenBtn else None
    VVIL24 = ("Move Up"     , self.VVfhXd    )
    VVrBns  = ("Move Down"   , self.VV0Fyd    )
    self.bookmarkMenu = FFECK9(self, self.VVjnx9, width=1200, title="Bookmarks", VVtMHe=newList, minRows=10 ,VVEJLl=VVEJLl, VVI3Sz=VVI3Sz, VVIL24=VVIL24, VVrBns=VVrBns, VVaRsg="#00000022", VVWgai="#00000022")
 def VVdSoP(self, VVkbkP=None, path=None):
  VVcuvv = self.VVyfgS()
  if VVcuvv:
   while path in VVcuvv:
    VVcuvv.remove(path)
   self.VVezEj(VVcuvv)
  if self.bookmarkMenu:
   self.bookmarkMenu.VVW5TS(VVcuvv)
   self.bookmarkMenu.VVxRWr(("Add Current Dir", BF(self.VVSQLW, path)))
  else:
   FFZD7H(self, "Removed", 800)
  self.VVQ1u3()
 def VVSQLW(self, path, VVkbkP=None, item=None):
  VVcuvv = self.VVyfgS()
  if len(VVcuvv) >= self.VVb7kj:
   FFOyl1(SELF, "Max bookmarks reached (max=%d)." % self.VVb7kj)
  elif not path in VVcuvv:
   if not os.path.isdir(path):
    path = FFG1q8(path, True)
   newList = [path] + VVcuvv
   self.VVezEj(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VVW5TS(newList)
    self.bookmarkMenu.VVxRWr()
   else:
    FFZD7H(self, "Added", 800)
  self.VVQ1u3()
 def VVfhXd(self, selectionObj, path):
  if self.bookmarkMenu:
   VVcuvv = self.bookmarkMenu.VVDEoO(True)
   if VVcuvv:
    self.VVezEj(VVcuvv)
 def VV0Fyd(self, selectionObj, path):
  if self.bookmarkMenu:
   VVcuvv = self.bookmarkMenu.VVDEoO(False)
   if VVcuvv:
    self.VVezEj(VVcuvv)
 def VVjnx9(self, folder=None):
  if folder:
   folder = FFDpEI(folder)
   self["myMenu"].VVzXBY(folder)
   self["myMenu"].moveToIndex(0)
  self.VV0sXm()
 def VVyfgS(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VVHNAc(self):
  return True if VVyfgS() else False
 def VVezEj(self, VVcuvv):
  line = ",".join(VVcuvv)
  FF0UO9(CFG.browserBookmarks, line)
 def VV07E0(self, path):
  if fileExists(path):
   fDir  = FFDpEI(os.path.dirname(path))
   if fDir:
    self["myMenu"].VVzXBY(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFZD7H(self, "Not found", 1000)
 def VV9oA3(self, chDir=True):
  fPath, fDir, fName = CCVnYx.VVASTW(self)
  self.VV07E0(fPath)
 def VVZ7F2(self):
  path = self.VVppQG(self.VVZo19())
  isAdd = False if path in self.VVyfgS() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  c1, c2 , c3 = VVoIYV, VV7z62, VVRuOi
  VVtMHe = []
  VVtMHe.append(("Find Files ..." , "find"))
  VVtMHe.append(("Sort ..."   , "sort"))
  VVtMHe.append(VVXGzj)
  if isAdd: VVtMHe.append((c1 + "Add %s Dir to Bookmarks"  % dirTxt, "addBM"))
  else : VVtMHe.append((c1 + "Remove %s Dir from Bookmarks" % dirTxt, "remBM"))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(    (c2 + 'Set %s Dir as "Startup Dir"' % dirTxt, "start"))
  if self.mode == self.VVcJJB:
   VVtMHe.append(VVXGzj)
   if self.multiSelectState: VVtMHe.append( (c3 + "Disable Multi-Select ", "multiOff"))
   else     : VVtMHe.append( (c3 + "Enable Multi-Select"  , "multiOn" ))
   VVtMHe.append(       (c3 + "Select all"    , "selAll"  ))
  FFECK9(self, BF(self.VVsHNx, path), width=750, title="More Options", VVtMHe=VVtMHe, VVaRsg="#00221111", VVWgai="#00221111")
 def VVsHNx(self, path, item):
  if item:
   if   item == "find"  : self.VV1UQb(path)
   elif item == "sort"  : self.VVzey2()
   elif item == "addBM" : self.VVSQLW(path)
   elif item == "remBM" : self.VVdSoP(None, path)
   elif item == "start" : self.VVJzEj(path)
   elif item == "multiOn" : self.VVf1RL(True)
   elif item == "multiOff" : self.VVf1RL(False)
   elif item == "selAll" : self.VVf1RL(True, True)
 def VVf1RL(self, isOn, isAll=False):
  self.multiSelectState = isOn
  if isAll or not isOn:
   FFbA1i(self, BF(self["myMenu"].VVCYtP, isOn), title="Selecting ..." if isOn else "Unselecting ...")
  self.VVjATv(self.VVbHXa if isOn else self.VVT2Ln)
 def VVjATv(self, mode=0):
  if   mode == self.VV8PGh : titBg, bodBg = self.pickTitleBG, self.pickBodyBG
  elif mode == self.VVbHXa: titBg, bodBg = "#01883366", "#11002233"
  else        : titBg, bodBg = self.VVaRsg, self.VVWgai
  FFC3pI(self["myTitle"], titBg)
  FFC3pI(self["myBar"], titBg)
  FFC3pI(self["myBody"], bodBg)
  FFC3pI(self["myMenu"], bodBg)
  if self.multiSelectState: bg, txt = "#01883366", self.VVuKrc()
  else     : bg, txt = VVDroB[3], "Bookmarks"
  FFKdfz(self["keyBlue"], txt)
  FFC3pI(self["keyBlue"], bg)
  self.VVQ1u3()
 def VVuKrc(self):
  return "Selected Items = %d" % self["myMenu"].VV6kXD()
 def VVQ1u3(self):
  if self.VVyfgS() or self.multiSelectState: self["keyBlue"].show()
  else            : self["keyBlue"].hide()
 def VV1UQb(self, path):
  VVtMHe = []
  VVtMHe.append(("Find in Current Directory"    , "findCur"  ))
  VVtMHe.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVtMHe.append(("Find in all Storage Systems"    , "findAll"  ))
  FFECK9(self, BF(self.VV5K4b, path), width=700, title="Find File/Pattern", VVtMHe=VVtMHe, VVIZXB=True, VVy2u1=True, VVaRsg="#00221111", VVWgai="#00221111")
 def VV5K4b(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VVcoQB(0, path, title)
   elif item == "findCurR" : self.VVcoQB(1, path, title)
   elif item == "findAll" : self.VVcoQB(2, path, title)
 def VVcoQB(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FFdnKb(self, BF(self.VVoB4L, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VVoB4L(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FF0UO9(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FFZD7H(self, "No entery", 1500)
   elif badLst  : FFZD7H(self, "Too many file !", 1500)
   else   : FFbA1i(self, BF(self.VV8bDx, mode, path, title, filePatt), title="Searching ...")
 def VV8bDx(self, mode, path, title, filePatt):
  lst = FFYEhL(FFccR6("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   err = CCVnYx.VVDb8p(lst)
   if err:
    FFOyl1(self, err)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VVZArZ = (""     , self.VV2W4j , [])
    VV1kWx = ("Go to File Location", self.VVf85r  , [])
    FFDpub(self, None, title="%s : %s" % (title, filePatt), header=header, VVcuvv=lst, VVbG6j=widths, VVGNdU=26, VVZArZ=VVZArZ, VV1kWx=VV1kWx)
  else:
   FFZbFo(self, "Not found !", 2000)
 def VVf85r(self, VVdesl, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVdesl.cancel()
   self.VV07E0(path)
  else:
   FFZD7H(VVdesl, "Path not found !", 1000)
 def VV2W4j(self, VVdesl, title, txt, colList):
  txt = "%s\n%s\n\n" % (FF8oA9("File:"  , VVRuOi), colList[0])
  txt += "%s\n%s"  % (FF8oA9("Directory:", VVRuOi), FFDpEI(colList[1]))
  FFoB4k(VVdesl, txt, title=title)
 def VVzey2(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVh2JT()
  VVtMHe = []
  VVtMHe.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVtMHe.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVtMHe.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVtMHe.append(("Type\t%s" % typeTxt, "typeAlp"))
  VVrBns = ("Mix", BF(self.VV1cmp, True))
  FFECK9(self, BF(self.VVaRGx, False), barText=txt, width=650, title="Sort Options", VVtMHe=VVtMHe, VVrBns=VVrBns, VVy2u1=True, VVaRsg="#00221111", VVWgai="#00221111")
 def VV1cmp(self, isMix, VVkbkP, item):
  self.VVaRGx(True, item)
 def VVaRGx(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVh2JT()
   title = "Sorting ... "
   if   item == "nameAlp": FFbA1i(self, BF(self["myMenu"].VV92XA, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FFbA1i(self, BF(self["myMenu"].VV92XA, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FFbA1i(self, BF(self["myMenu"].VV92XA, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FFbA1i(self, BF(self["myMenu"].VV92XA, typeMode , isMix, False), title=title)
 def VVJzEj(self, path):
  if not os.path.isdir(path):
   path = FFG1q8(path, True)
  FF0UO9(CFG.browserStartPath, path)
  FFZD7H(self, "Done", 500)
 def VVLyMO(self, selFile, VVStYd, command):
  FFgBNQ(self, BF(FFyrLj, self, command, consFont=True, VV4qLc=self.VVXcc0), "%s\n\n%s" % (VVStYd, selFile))
 def VVyueN(self, path, calledFromMenu):
  destPath = self.VVOQXv(path)
  lastPart = FFd4tO(destPath)
  color = VVRuOi if calledFromMenu else ""
  VVtMHe = []
  if path.endswith(".gz") and not path.endswith(".tar.gz"):
   VVtMHe.append((color + "Extract Content"           , "extract_gz" ))
  else:
   if calledFromMenu: VVtMHe.append(VVXGzj)
   VVtMHe.append((color + "List Archived Files"          , "extract_listFiles" ))
   VVtMHe.append(VVXGzj)
   VVtMHe.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
   VVtMHe.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
   VVtMHe.append((color + "Extract Here"            , "extract_here"  ))
   if iTar and iZip:
    if path.endswith(".zip"):
     if not calledFromMenu: VVtMHe.append(VVXGzj)
     VVtMHe.append((color + "Convert .zip to .tar.gz"       , "VVNwye" ))
    elif path.endswith(".tar.gz"):
     if not calledFromMenu: VVtMHe.append(VVXGzj)
     VVtMHe.append((color + "Convert .tar.gz to .zip"       , "VV3avY" ))
  return VVtMHe
 def VVXkQ1(self, path, selFile):
  FFECK9(self, BF(self.VV1Unv, path, selFile), title="Compressed File Options", VVtMHe=self.VVyueN(path, False))
 def VV1Unv(self, path, selFile, item=None):
  if item is not None:
   parent  = FFG1q8(path, False)
   destPath = self.VVOQXv(path)
   lastPart = FFd4tO(destPath)
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % SEP
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFv2CR("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFv2CR("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n\n';" % path
     cmd += "totFiles=$(tar -tf '%s' | wc -l);" % path
     cmd += "if (( $totFiles > 300 )); then moreInf='  ... Will list the first 300 only ...'; else moreInf=''; fi;"
     cmd += "echo -e '\n%s\n--- Contents (Total='$totFiles')'$moreInf'\n%s';" % (SEP, SEP)
     cmd += "tar -tf '%s' | head -n300;" % path
     cmd += "if (( $totFiles > 300 )); then echo '\n... Only the first 300 are listed ...'; fi;"
    cmd += "echo '';"
    cmd += linux_sep
    FF1lrl(self, cmd)
   elif path.endswith(".zip"):
    if item == "VVNwye" : self.VVNwye(path)
    else       : self.VV7GMC(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "VV3avY" and path.endswith(".tar.gz"):
    self.VV3avY(path)
   elif item == "extract_gz":
    title = 'Extract ".gz" file'
    res = FFvL4V("RES=$(gzip -dk '%s') && echo ok || echo $RES" % path)
    if res == "ok":
     FFDeF8(self, "Result:\n\n%s" % path[:-3], title=title)
     self.VVXcc0()
    else:
     FFOyl1(self, "Error:\n\n%s" % res, title=title)
   elif path.endswith(".rar"):
    self.VVqUB7(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFb0lc("mkdir '%s'"   % lastPart)
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVLyMO(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVLyMO(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FFG1q8(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVLyMO(selFile, "Extract Here ?"      , cmd)
 def VVOQXv(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VV7GMC(self, item, path, parent, destPath, VVStYd):
  FFgBNQ(self, BF(self.VVhApC, item, path, parent, destPath), VVStYd)
 def VVhApC(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFv2CR("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFP1gK(destPath, VViZMT))
  cmd +=   sep
  cmd += "fi;"
  FFk2dP(self, cmd, VV4qLc=self.VVXcc0)
 def VVqUB7(self, item, path, parent, destPath, VVStYd):
  FFgBNQ(self, BF(self.VVDUz9, item, path, parent, destPath), VVStYd)
 def VVDUz9(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFDpEI(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFv2CR("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFP1gK(destPath, VViZMT))
  cmd +=   sep
  cmd += "fi;"
  FFk2dP(self, cmd, VV4qLc=self.VVXcc0)
 def VVlXF5(self, addSep=False):
  VVtMHe = []
  if addSep:
   VVtMHe.append(VVXGzj)
  VVtMHe.append((VVRuOi + "View Script File"  , "script_View"  ))
  VVtMHe.append((VVRuOi + "Execute Script File" , "script_Execute" ))
  VVtMHe.append((VVRuOi + "Edit"     , "script_Edit"  ))
  return VVtMHe
 def VVxuH9(self, path, selFile):
  FFECK9(self, BF(self.VVOBvJ, path, selFile), title="Script File Options", VVtMHe=self.VVlXF5())
 def VVOBvJ(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFxhJI(self, path)
   elif item == "script_Execute" : self.VVLyMO(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCiazU(self, path, VVCBqA=self.VVmaFH)
 def VVCusr(self, addSep=False):
  VVtMHe = []
  if addSep:
   VVtMHe.append(VVXGzj)
  VVtMHe.append((VVRuOi + "Browse IPTV Channels" , "m3u_Browse" ))
  VVtMHe.append((VVRuOi + "Edit"     , "m3u_Edit" ))
  VVtMHe.append((VVRuOi + "View"     , "m3u_View" ))
  return VVtMHe
 def VVHYUo(self, path, selFile):
  FFECK9(self, BF(self.VVueFX, path, selFile), title="M3U/M3U8 File Options", VVtMHe=self.VVCusr())
 def VVueFX(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFbA1i(self, BF(self.session.open, CCoUhv, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCiazU(self, path, VVCBqA=self.VVmaFH)
   elif item == "m3u_View"  : FFxhJI(self, path)
 def VVr3bi(self, path):
  if fileExists(path) : FFbA1i(self, BF(CC2TkW.VVLm7q, self, path, BF(self.VVVSSf, path)), title="Loading Codecs ...")
  else    : FFbiIe(self, path)
 def VVVSSf(self, path, item=None):
  if item:
   FFxhJI(self, path, encLst=item)
 def VVMAJ1(self, path, title, asUtf8):
  if fileExists(path) : FFbA1i(self, BF(CC2TkW.VVLm7q, self, path, BF(self.VVhzUb, path, title, asUtf8), title="Original Encoding"), title="Loading Codecs ...")
  else    : FFbiIe(self, path)
 def VVhzUb(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8: self.VVVpfi(path, title, fromEnc, "UTF-8")
   else  : CC2TkW.VVIR9M(self, BF(self.VVVpfi, path, title, fromEnc), title="Convert to Encoding")
 def VVVpfi(self, path, title, fromEnc, item):
  if item:
   txt, toEnc, ndx = item
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FF8oA9("Successful\n\n", VViZMT)
      txt += FF8oA9("From Encoding (%s):\n" % fromEnc, VVXAXH)
      txt += "%s\n\n" % path
      txt += FF8oA9("To Encoding (%s):\n" % toEnc, VVXAXH)
      txt += "%s\n\n" % outFile
      FFoB4k(self, txt, title=title)
    except:
     FFOyl1(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FFZD7H(self, "Cannot open file", 2000)
   self.VVXcc0()
 def VVtfbo(self, path):
  title = "File Line-Break Conversion"
  FFgBNQ(self, BF(self.VVcg1D, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVcg1D(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FF8oA9("File converted:", VViZMT), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FFDeF8(self, txt, title=title)
  else:
   FFbiIe(self, path, title=title)
 def VVhPK4(self, path, selFile, newChmod):
  FFgBNQ(self, BF(self.VVCAyC, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVCAyC(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVlkj1)
  result = FFvL4V(cmd)
  if result == "Successful" : FFDeF8(self, result)
  else      : FFOyl1(self, result)
 def VVyaLq(self, path, selFile):
  parent = FFG1q8(path, False)
  self.session.openWithCallback(self.VVeS6E, BF(CCVnYx, mode=CCVnYx.VVW7oj, VVSMX5=parent, VVyIuw="Create Symlink here"))
 def VVeS6E(self, newPath):
  if len(newPath) > 0:
   target = self.VVppQG(self.VVZo19())
   target = FF55ZU(target)
   linkName = FFd4tO(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFDpEI(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFOyl1(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFgBNQ(self, BF(self.VV4E3I, target, link), "Create Soft Link ?\n\n%s" % txt, VVMgjE=True)
 def VV4E3I(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVlkj1)
  result = FFvL4V(cmd)
  if result == "Successful" : FFDeF8(self, result)
  else      : FFOyl1(self, result)
 def VVSBGs(self, path, selFile):
  lastPart = FFd4tO(path)
  FFdnKb(self, BF(self.VVP6t3, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVP6t3(self, path, selFile, VVfJks):
  if VVfJks:
   parent = FFG1q8(path, True)
   if os.path.isdir(path):
    path = FF55ZU(path)
   newName = parent + VVfJks
   cmd = "mv '%s' '%s' %s" % (path, newName, VVlkj1)
   if VVfJks:
    if selFile != VVfJks:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFgBNQ(self, BF(self.VVyudI, cmd), message, title="Rename file?")
    else:
     FFOyl1(self, "Cannot use same name!", title="Rename")
 def VVyudI(self, cmd):
  result = FFvL4V(cmd)
  if "Fail" in result:
   FFOyl1(self, result)
  self.VVXcc0()
 def VVa4um(self, preserve):
  title="Archive to .tar.gz"
  self.session.open(CCjWUz, barTheme=CCjWUz.VVh7HE, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVbNKu, title, preserve)
      , VVCBqA = BF(self.VVIs9S, title))
 def VVbNKu(self, title, preserve, VVNVFL):
  totSel = self["myMenu"].VV6kXD()
  totOk = totFail = 0
  VVNVFL.VV0amK(totSel)
  VVNVFL.VVpwcW = ["", totSel, totOk, totFail, ""]
  VVNVFL.VVXtf8("Prepareing targz file")
  curDir = self["myMenu"].VVjLjx()
  lastPart = FFd4tO(curDir) or "archive"
  outF = os.path.join(curDir, lastPart + ".tar.gz")
  c = 0
  while fileExists(outF):
   c += 1
   outF = os.path.join(curDir, lastPart + "_%d.tar.gz" % c)
  totOk = totFail = 0
  path = ""
  try:
   with iTar.open(outF, mode="w:gz") as tarF:
    for row in self["myMenu"].list:
     if not VVNVFL or VVNVFL.isCancelled:
      return
     if row[2][6]:
      VVNVFL.VViyfK(1)
      name  = FF55ZU(row[0][0])
      lastPath = FFd4tO(name)
      path  = os.path.join(curDir, name)
      tarF.add(path, arcname=None if preserve else lastPath)
      totOk += 1
      if VVNVFL:
       VVNVFL.VVpwcW = [outF, totSel, totOk, totFail, path]
       VVNVFL.VVzN3b(totOk, lastPath)
  except:
   totFail += 1
   if VVNVFL:
    VVNVFL.VVpwcW = [outF, totSel, totOk, totFail, path]
 def VVIs9S(self, title, VVdCuP, VVpwcW, threadCounter, threadTotal, threadErr):
  outF, totSel, totOk, totFail, path = VVpwcW
  txt  = "%s:\n%s\n\n"   % (FF8oA9("Output File", VViZMT), outF)
  txt += "Total\t: %d\n"  % totSel
  txt += "Archived\t: %d\n" % totOk
  if totFail   : txt += FF8oA9("Failed\t: %d\n" % totFail, VV8ETX)
  if not VVdCuP: txt += "%s\n%s" % (FF8oA9("\nCancelled while copying:", VV8ETX), path)
  FFoB4k(self, txt, title=title)
  self.VVXcc0()
 def VVr8rq(self, isMove):
  self.session.openWithCallback(BF(self.VViBj7, isMove), BF(CCVnYx, mode=CCVnYx.VVW7oj, VVSMX5=self["myMenu"].VVjLjx(), VVyIuw="Move to here" if isMove else "Paste here"))
 def VViBj7(self, isMove, newPath):
  if newPath:
   if isMove : title, action = "Move Items", "Moved"
   else  : title, action = "Copy Items", "Copied"
   self.session.open(CCjWUz, barTheme=CCjWUz.VVh7HE, titleBg="#22003344", bodyBg="#22001122"
       , titlePrefix = title
       , fncToRun  = BF(self.VVpmuQ, title, action, isMove, newPath)
       , VVCBqA = BF(self.VVaXya, title, action, isMove, newPath))
 def VVpmuQ(self, title, action, isMove, newPath, VVNVFL):
  curDir = self["myMenu"].VVjLjx()
  totOk = totFail = 0
  totSel = self["myMenu"].VV6kXD()
  if isMove: cmd = "mv -f"
  else  : cmd = "cp -frp"
  VVNVFL.VV0amK(totSel)
  VVNVFL.VVpwcW = [totSel, totOk, totFail, ""]
  for row in self["myMenu"].list:
   if not VVNVFL or VVNVFL.isCancelled:
    return
   if row[2][6]:
    VVNVFL.VViyfK(1)
    VVNVFL.VVEJLg(action, totOk, FFd4tO(row[0][0]))
    path = os.path.join(curDir, row[0][0])
    lastPart = FFd4tO(path)
    if os.path.isdir(path): path = FF55ZU(path)
    dest = os.path.join(newPath, lastPart)
    if FFqSkC("%s '%s' '%s'" % (cmd, path, dest)) : totOk += 1
    else            : totFail += 1
    if VVNVFL:
     VVNVFL.VVpwcW = [totSel, totOk, totFail, path]
     VVNVFL.VVEJLg(action, totOk, FFd4tO(row[0][0]))
 def VVaXya(self, title, action, isMove, newPath, VVdCuP, VVpwcW, threadCounter, threadTotal, threadErr):
  totSel, totOk, totFail, path = VVpwcW
  txt  = "Total\t: %d\n" % totSel
  txt += "%s\t: %d\n"  % (action, totOk)
  if totFail   : txt += FF8oA9("Failed\t: %d\n" % totFail, VV8ETX)
  if not VVdCuP: txt += "%s\n%s" % (FF8oA9("\nCancelled while copying:", VV8ETX), path)
  FFoB4k(self, txt, title=title)
  self.VVXcc0()
 def VVx0S1(self):
  tot = self["myMenu"].VV6kXD()
  FFgBNQ(self, BF(FFbA1i, self, self.VVmQnE, title="Deleting ...", clearMsg=False), "Delete %d item%s ?" % (tot, FFsfSO(tot)), title="Delete Selection")
 def VVmQnE(self):
  path = self["myMenu"].VVjLjx()
  for row in self["myMenu"].list:
   if row[2][6]:
    FFjhVR(os.path.join(path, row[0][0]))
  FFZD7H(self)
  self.VVXcc0()
 def VVmCjy(self, path, isMove):
  self.session.openWithCallback(BF(self.VVoVP7, isMove, path), BF(CCVnYx, mode=CCVnYx.VVW7oj, VVSMX5=FFG1q8(path, False), VVyIuw="Move to here" if isMove else "Paste here"))
 def VVoVP7(self, isMove, src, dst):
  if not dst:
   return
  action = "Move" if isMove else "Copy"
  src = FF55ZU(src)
  if os.path.isfile(src) or os.path.islink(src): isFile, srcSubj = True , "File"
  else           : isFile, srcSubj = False, "Directory"
  title = "%s %s" % (action, srcSubj)
  src = FF55ZU(src)
  dst = os.path.join(dst, FFd4tO(src))
  if src == dst:
   FFOyl1(self, "From:\n%s\n\n To:\n%s" % (src, dst), title=("Cannot %s %s to itself" % (action, srcSubj)).capitalize())
   return
  prams = title, isFile, isMove, srcSubj, src, dst
  if fileExists(dst) or pathExists(dst): FFgBNQ(self, BF(self.VV39Yz, prams), "Overwrite Destination %s ?\n\n%s" % (srcSubj, dst), title=title)
  elif not isFile       : FFgBNQ(self, BF(self.VV39Yz, prams), "Overwrite Destination Files", title=title)
  else         : self.VV39Yz(prams)
 def VV39Yz(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isMove and CCVnYx.VV4cQu(src) == CCVnYx.VV4cQu(dst):
   FFbA1i(self, BF(self.VVACFB, prams), title="Moving %s ..." % srcSubj)
  else:
   FFbA1i(self, BF(self.VVwGjq, prams), title="Calculating Size ...")
 def VVACFB(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  res = FFvL4V("RES=$(mv -f '%s' '%s') && echo ok || echo $RES" % (src, dst))
  if res == "ok":
   self.VVXcc0()
  else:
   FFOyl1(self, "Error : %s\n\n%s" % (res, src), title=title)
 def VVwGjq(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isFile: size = FFF0Rr(src)
  else  : size = FFOcJX(src)
  if size > -1:
   self.session.open(CCjWUz, barTheme=CCjWUz.VVh7HE, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Moving %s ..." % srcSubj if isMove else "Copying %s ..." % srcSubj
       , fncToRun  = BF(self.VVwZUI, prams, size)
       , VVCBqA = BF(self.VVjJYS, prams))
  else:
   FFOyl1(self, "Cannot get size for:\n\n%s" % src, title=title)
 def VVwZUI(self, prams, size, VVNVFL):
  title, isFile, isMove, srcSubj, src, dst = prams
  VVNVFL.VV0amK(size)
  VVNVFL.VVpwcW = ("", "", False)
  def VVpFzx(srcFile, dstFile):
   if os.path.islink(srcFile):
    if fileExists(dstFile):
     FFOlRe(dstFile)
    os.symlink(os.readlink(srcFile), dstFile)
   elif os.path.isfile(srcFile):
    with open(srcFile, "rb") as srcF:
     with open(dstFile, "wb") as dstF:
      while True:
       if not VVNVFL or VVNVFL.isCancelled:
        VVNVFL.VVpwcW = (srcFile, "", True)
        FFOlRe(dstFile)
        return False
       try:
        data = srcF.read(1024)
        if not data:
         break
        dstF.write(data)
        VVNVFL.VViyfK(len(data))
       except Exception as e:
        VVNVFL.VVpwcW = (srcFile, str(e), False)
        FFOlRe(dstFile)
        return False
   if iCopymode: iCopymode(srcFile, dstFile)
   if isMove: FFOlRe(srcFile)
   return True
  if isFile:
   tot = 1
   VVpFzx(src, dst)
  else:
   VVNVFL.VVXtf8("Calculating Dirs/Files ...")
   totDir, totFile, totLink = FFv951(src)
   if not VVNVFL or VVNVFL.isCancelled:
    VVNVFL.VVpwcW = ("", "", True)
    return
   tot = totFile + totLink
   fCount = 0
   for Dir, dirs, files in os.walk(src):
    files = os.listdir(Dir)
    dstDir = os.path.join(dst, Dir[len(src):].lstrip("/"))
    if not pathExists(dstDir):
     try:
      os.makedirs(dstDir)
     except Exception as e:
      VVNVFL.VVpwcW = (os.path.join(Dir, f), str(e), False)
    for f in files:
     srcFile = os.path.join(Dir, f)
     dstFile = os.path.join(dst, srcFile[len(src):].lstrip("/"))
     if os.path.islink(srcFile) or os.path.isfile(srcFile):
      fCount += 1
      VVNVFL.VVXtf8("File: %d/%d >> %s" % (fCount, tot, f))
      if not VVpFzx(srcFile, dstFile):
       return
    if isMove and not os.listdir(Dir):
     FFqSkC("rm -fr '%s'" % Dir)
   if isMove:
    FFqSkC("rm -fr '%s'" % src)
 def VVjJYS(self, prams, VVdCuP, VVpwcW, threadCounter, threadTotal, threadErr):
  title, isFile, isMove, srcSubj, src, dst = prams
  lastFile, err, isCancelled = VVpwcW
  if err:
   FFOyl1(self, "%s\n\n%s" % (err, lastFile), title=title + " ... Error")
  elif isCancelled:
   if isFile: FFZD7H(self, "Canelled", 1000)
   else  : FFOyl1(self, "Cancelled at file:\n\n%s" % lastFile if lastFile else "Process Stopped.", title=title + " ... Cancelled")
  else:
   FFZD7H(self, "Done", 1500, isGrn=True)
  if VVdCuP and isMove:
   self.VVXcc0()
 def VVc2eV(self, path, fileName):
  path = FF55ZU(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFgBNQ(self, BF(FFbA1i, self, BF(self.VVzQIN, path), title="Deleting ...", clearMsg=False), "%s\n\nDelete %s ?" % (path, pathType), title="Delete %s" % pathType)
 def VVzQIN(self, path):
  FFjhVR(path)
  FFZD7H(self)
  self.VVXcc0()
 def VVjmqU(self, path, isFile):
  dirName = FFDpEI(os.path.dirname(path))
  if isFile : objName, VVfJks = "File"  , self.edited_newFile
  else  : objName, VVfJks = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFdnKb(self, BF(self.VVrLvw, dirName, isFile, title), title=title, defaultText=VVfJks, message="Enter %s Name:" % objName)
 def VVrLvw(self, dirName, isFile, title, VVfJks):
  if VVfJks:
   if isFile : self.edited_newFile = VVfJks
   else  : self.edited_newDir  = VVfJks
   path = dirName + VVfJks
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVlkj1)
    else  : cmd = "mkdir '%s' %s" % (path, VVlkj1)
    result = FFvL4V(cmd)
    if "Fail" in result:
     FFOyl1(self, result)
    self.VVXcc0()
   else:
    FFOyl1(self, "Name already exists !\n\n%s" % path, title)
 def VVSx6D(self, path, selFile):
  c1, c2, c3 = VV7z62, VVRuOi, VV4mV2
  VVtMHe = []
  VVtMHe.append((c1 + "List Package Files"         , "VVdx1I"     ))
  VVtMHe.append((c1 + "Package Information"         , "VVbgHW"     ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((c2 + "Install Package"          , "VVKD45_CheckVersion" ))
  VVtMHe.append((c2 + "Install Package (force reinstall)"     , "VVKD45_ForceReinstall" ))
  VVtMHe.append((c2 + "Install Package (force overwrite)"     , "VVKD45_ForceOverwrite" ))
  VVtMHe.append((c2 + "Install Package (force downgrade)"     , "VVKD45_ForceDowngrade" ))
  VVtMHe.append((c2 + "Install Package (ignore failed dependencies)"  , "VVKD45_IgnoreDepends" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((c3 + "Remove Related Package"        , "VV03xS_ExistingPackage" ))
  VVtMHe.append((c3 + "Remove Related Package (force remove)"    , "VV03xS_ForceRemove"  ))
  VVtMHe.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VV03xS_IgnoreDepends" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Extract Files"           , "VVBbwi"     ))
  VVtMHe.append(("Unbuild Package"           , "VV0CMW"     ))
  FFECK9(self, BF(self.VVLsPm, path, selFile), VVtMHe=VVtMHe)
 def VVLsPm(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVdx1I"      : self.VVdx1I(path, selFile)
   elif item == "VVbgHW"      : self.VVbgHW(path)
   elif item == "VVKD45_CheckVersion"  : self.VVKD45(path, selFile, VVqrBj     )
   elif item == "VVKD45_ForceReinstall" : self.VVKD45(path, selFile, VVkYaB )
   elif item == "VVKD45_ForceOverwrite" : self.VVKD45(path, selFile, VVGJh6 )
   elif item == "VVKD45_ForceDowngrade" : self.VVKD45(path, selFile, VV6qvM )
   elif item == "VVKD45_IgnoreDepends" : self.VVKD45(path, selFile, VVqwiy )
   elif item == "VV03xS_ExistingPackage" : self.VV03xS(path, selFile, VVCAlU     )
   elif item == "VV03xS_ForceRemove"  : self.VV03xS(path, selFile, VVqsIZ  )
   elif item == "VV03xS_IgnoreDepends"  : self.VV03xS(path, selFile, VVwmI5 )
   elif item == "VVBbwi"     : self.VVBbwi(path, selFile)
   elif item == "VV0CMW"     : self.VV0CMW(path, selFile)
 def VVdx1I(self, path, selFile):
  if FFLsle("ar") : cmd = "allOK='1';"
  else    : cmd  = FFfDPF()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (SEP, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (SEP, SEP)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FF1ZjZ(self, cmd, VV4qLc=self.VVXcc0)
 def VVBbwi(self, path, selFile):
  lastPart = FFd4tO(path)
  dest  = FFG1q8(path, True) + selFile[:-4]
  cmd  =  FFfDPF()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFb0lc("mkdir '%s'" % dest)
  cmd +=    FFb0lc("cd '%s'" % dest)
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFP1gK(dest, VViZMT))
  cmd += "fi;"
  FFyrLj(self, cmd, VV4qLc=self.VVXcc0)
 def VV0CMW(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVCWFX = os.path.splitext(path)[0]
  else        : VVCWFX = path + "_"
  if path.endswith(".deb")   : VVyI94 = "DEBIAN"
  else        : VVyI94 = "CONTROL"
  cmd  = FFfDPF()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -rf '%s' > /dev/null 2>&1;" % VVCWFX
  cmd += "  mkdir '%s';"      % VVCWFX
  cmd += "  CONTPATH='%s/%s';"    % (VVCWFX, VVyI94)
  cmd += '  mkdir "$CONTPATH";'
  cmd += "  cd '%s';"       % VVCWFX
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"      % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVCWFX, VVCWFX)
  cmd += "  FILE='%s/control.tar.gz'; [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVCWFX
  cmd += "  FILE='%s/data.tar.xz';    [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVCWFX, VVCWFX)
  cmd += "  FILE='%s/control.tar.xz'; [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVCWFX
  cmd += "  FILE='%s/debian-binary';  [ -f \"$FILE\" ]                                        && rm -f \"$FILE\";" %  VVCWFX
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e '\nOutput Directory:\n%s' %s;" % (VVCWFX, FFP1gK(VVCWFX, VViZMT))
  cmd += "fi;"
  FFyrLj(self, cmd, VV4qLc=self.VVXcc0)
 def VVbgHW(self, path):
  listCmd  = FFRkrW(VVOApa, "")
  infoCmd  = FFbfXZ(VVh7PL , "")
  filesCmd = FFbfXZ(VVabTi, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFTLIE(VVXAXH)
   notInst = "Package not installed."
   cmd  = FFZOMf("File Info", VVXAXH)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFZOMf("System Info", VVXAXH)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFP1gK(notInst, VV8ETX))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFZOMf("Related Files", VVXAXH)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FF1lrl(self, cmd)
  else:
   FFvp5w(self)
 def VVKD45(self, path, selFile, cmdOpt):
  cmd = FFbfXZ(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFgBNQ(self, BF(FFyrLj, self, cmd, VV4qLc=FFAIFB), "Install Package ?\n\n%s" % selFile)
  else:
   FFvp5w(self)
 def VV03xS(self, path, selFile, cmdOpt):
  listCmd  = FFRkrW(VVOApa, "")
  infoCmd  = FFbfXZ(VVh7PL, "")
  instRemCmd = FFbfXZ(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFP1gK(errTxt, VV8ETX))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFP1gK(cannotTxt, VV8ETX))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFP1gK(tryTxt, VV8ETX))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFgBNQ(self, BF(FFyrLj, self, cmd, VV4qLc=FFAIFB), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFvp5w(self)
 def VVAHa7(self, path):
  hostName = FFvL4V("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVS70b(self, path, isDir):
  txt1 = "Archive to "
  txt2 = "Archive (Preserve Path Structure) to "
  VVtMHe = []
  VVtMHe.append(("%s.tar"  % txt1 , "archDir_tar"  ))
  VVtMHe.append(("%s.tar.gz" % txt1 , "archDir_tar_gz" ))
  VVtMHe.append(("%s.tar.xz" % txt1 , "archDir_tar_xz" ))
  VVtMHe.append(("%s.tar.bz2" % txt1 , "archDir_tar_bz2" ))
  VVtMHe.append(("%s.zip"  % txt1 , "archDir_zip"  ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("%s.tar"  % txt2 , "archPath_tar" ))
  VVtMHe.append(("%s.tar.gz" % txt2 , "archPath_tar_gz" ))
  VVtMHe.append(("%s.tar.xz" % txt2 , "archPath_tar_xz" ))
  VVtMHe.append(("%s.tar.bz2" % txt2 , "archPath_tar_bz2"))
  VVtMHe.append(("%s.zip"  % txt2 , "archPath_zip" ))
  if isDir and not self.multiSelectState:
   VVtMHe.append(VVXGzj)
   VVtMHe.append(('Convert to ".ipk" Package', "convertDirToIpk" ))
   VVtMHe.append(('Convert to ".deb" Package', "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFECK9(self, BF(self.VVORFw, path, isDir, title), VVtMHe=VVtMHe, title=title, VVaRsg=c1, VVWgai=c2)
 def VVORFw(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"  : self.VVoGun(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz" : self.VVoGun(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz" : self.VVoGun(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2" : self.VVoGun(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"  : self.VVoGun(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"  : self.VVoGun(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz" : self.VVoGun(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz" : self.VVoGun(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2" : self.VVoGun(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"  : self.VVoGun(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk" : self.VVkUne(path, False)
   elif item == "convertDirToDeb" : self.VVkUne(path, True)
 def VVkUne(self, path, VVlAOK):
  self.session.openWithCallback(self.VVXcc0, BF(CC3sVu, path=path, VVlAOK=VVlAOK))
 def VVoGun(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FFG1q8(path, True)
  lastPart = FFd4tO(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFv2CR("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFv2CR("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFv2CR("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % SEP
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFb0lc("rm -f '%s'" % archFile)
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFP1gK(failed, VVtchu))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFP1gK(srcTxt, VVoIYV))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFP1gK("Output", VViZMT))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFP1gK(failed, VVOr14))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FF1ZjZ(self, cmd, VV4qLc=self.VVXcc0, title=title)
 def VVNUvD(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CCVnYx.VVAIFC(FFG1q8(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CCotiQ(self, self, title, BF(self.VVdHL8, pathLst))
 def VVdHL8(self, pathLst):
  return CCotiQ.VVIsQk(pathLst)
 def VVNwye(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VVrBRj, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFgBNQ(self, BF(FFbA1i, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFbA1i(self, fnc, title=txt)
  else:
   FFOyl1(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VVrBRj(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, "w:gz") as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFoB4k(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VVXcc0()
  else:
   FFOlRe(tarPath)
   FFOyl1(self, "Error while converting.", title=title)
 def VV3avY(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVH1Bi, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFgBNQ(self, BF(FFbA1i, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFbA1i(self, fnc, title=txt)
  else:
   FFOyl1(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVH1Bi(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFoB4k(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VVXcc0()
  else:
   FFOlRe(zipPath)
   FFOyl1(self, "Error while converting.", title=title)
 def VVWYx5(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FFDpEI(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  FFqSkC("rm -f '%s' '%s'" % (m1v, mvi))
  if FFqSkC("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)) and fileExists(m1v):
   FFqSkC("mv -f '%s' '%s'" % (m1v, mvi))
   self.VVXcc0()
   FFDeF8(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FFOyl1(self, "Cannot convert this file !", title=title)
 def VVgeOn(self, path):
  title = "Set as PIcon for current channel"
  pPath = CCuqLp.VVchM7()
  if pathExists(pPath):
   if CCSwPL.VVBSOI(self, title, False, cbFnc=BF(self.VVgeOn, path)):
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
    picon = "%s%s.png" % (pPath, refCode.strip(":").replace(":", "_").upper())
    VVtMHe = []
    for item in ((50,30),(96,64),(100,60),(220,132),(400,160),(400,240),(500,300)):
     VVtMHe.append(("%d x %d" % (item), item))
    VVBLNR = self.VViLDv
    VVrBns = ("Stretch", BF(self.VVigbu, title, path, picon))
    VVkbkP = FFECK9(self, BF(self.VVuJ1c, title, path, picon, False), VVtMHe=VVtMHe, width=700, title='PIcon Max. Size', VVBLNR=VVBLNR, VVrBns=VVrBns, barText="OK = Fit within size")
    VVkbkP.VV27hm(3)
  else:
   FFOyl1(self, "PIcons path not found:\n\n%s\n\n( You can change it in Settings )" % pPath, title=title)
 def VVigbu(self, title, path, picon, selectionObj, item):
  self.VVuJ1c(title, path, picon, True, item)
  selectionObj.cancel()
 def VVuJ1c(self, title, path, picon, stretch, sz=None):
  if sz:
   try:
    from PIL import Image
    im = Image.open(path)
    if stretch: im = im.resize(sz, Image.ANTIALIAS)
    else   : im.thumbnail(sz)
    im.save(picon)
    FF1wB7(self, fncMode=CCqIel.VVajvb)
   except Exception as e:
    FFOyl1(self, "Image Processing error:\n\n%s" % e)
 def VViLDv(self, VVkbkP, txt, ref, ndx):
  FFSnt9(self, "_help_resize", "Picture File Resizing")
 def VVqvXT(self, path):
  FFECK9(self, BF(self.VVVGYP, path), VVtMHe=CCoUhv.VV7ivb(), width=650, title="Select Player", VVaRsg="#11220000", VVWgai="#11220000")
 def VVVGYP(self, path, rType=None):
  if rType:
   FFbA1i(self, BF(self.VVWQNk, self, path, rType), title="Playing Media ...")
 @staticmethod
 def VVWQNk(SELF, path, rType=""):
  try:
   if   rType     : prefix = rType
   elif path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCuYKB.VVa42W(SELF.session, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVASTW(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFDpEI(fDir), fName
  return "", "", ""
 @staticmethod
 def VV0ibt(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVP9pE(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVI3LQ(size, mode=0):
  txt = CCVnYx.VVC5XL(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVC5XL(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VVq7OD(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VV8SZ3(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FFOyl1(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VVAviw():
  tDict = CCXPWq.VVbz66()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVAIFC(path):
  lst = []
  for ext in CCVnYx.VVAviw():
   lst.extend(FF0KZb(path, "*.%s" % ext))
  return sorted(lst, key=FFgRqj(FFGVZA))
 @staticmethod
 def VVed9k(path):
  return FFqSkC("tar -tzf '%s'" % path)
 @staticmethod
 def VV4cQu(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
 @staticmethod
 def VVDb8p(lst, fromFind=True):
  if len(lst) == 1 and lst[0] == VVBCi5:
   return VVBCi5
  elif fromFind:
   for line in lst:
    span = iSearch(r"find:\s*(.+):\s*Input\/output error", line, IGNORECASE)
    if span:
     return 'Filesystem Error in:\n\n%s' % span.group(1)
  return ""
class CCXPWq(MenuList):
 VVpklU   = 0
 VV1rfK   = 1
 VVvE1i   = 2
 VViEN5   = 3
 VVtoAU   = 4
 VVUEie   = 5
 VVvs2v   = 6
 VVLY9b   = 7
 VVKE9J   = "<List of Storage Devices>"
 VV4zAm  = "<Parent Directory>"
 VVMhuu   = 0
 VVq0bV   = 1
 VVw2T9 = 2
 VVsuai  = 3
 VVyi5L   = 4
 VVd7Gw   = 5
 FILE_TYPE_LINK   = 6
 VVqw0o  = 7
 PROHIBITED_FILES  = ["/%s/" % x for x in ("DEBIAN","bin","boot","dev","etc","hdd","home","lib","media","mnt","network","proc","run","sbin","sys","tmp","usr","var")]
 def __init__(self, VVQJbs=False, directory="/", VVMWCQ=True, VVoNaJ=True, VVpIzu=True, VVAncz=None, VVo4Nf=False, VVAcKl=False, VVIQZP=False, isTop=False, VV0VHg=None, VVeSt7=1000, VVGNdU=30, VVavwW=30):
  MenuList.__init__(self, list, VVQJbs, eListboxPythonMultiContent)
  self.VVMWCQ  = VVMWCQ
  self.VVoNaJ    = VVoNaJ
  self.VVpIzu  = VVpIzu
  self.VVAncz  = VVAncz
  self.VVo4Nf   = VVo4Nf
  self.VVAcKl   = VVAcKl or []
  self.VVIQZP   = VVIQZP or []
  self.isTop     = isTop
  self.additional_extensions = VV0VHg
  self.VVeSt7    = VVeSt7
  self.VVGNdU    = VVGNdU
  self.VVavwW    = VVavwW
  self.EXTENSIONS    = CCXPWq.VVbz66()
  self.VVcpye   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.multiSelect_color  = FFGsVi("#11ff4444")
  self.l.setFont(0, gFont(VVlMYE, self.VVGNdU))
  self.l.setItemHeight(self.VVavwW)
  self.png_mem   = CCXPWq.VV919t("mem")
  self.png_usb   = CCXPWq.VV919t("usb")
  self.png_fil   = CCXPWq.VV919t("fil")
  self.png_dir   = CCXPWq.VV919t("dir")
  self.png_dirup   = CCXPWq.VV919t("dirup")
  self.png_srv   = CCXPWq.VV919t("srv")
  self.png_slwfil   = CCXPWq.VV919t("slwfil")
  self.png_slbfil   = CCXPWq.VV919t("slbfil")
  self.png_slwdir   = CCXPWq.VV919t("slwdir")
  self.VVWywx()
  self.VVzXBY(directory)
 @staticmethod
 def VV919t(category):
  return LoadPixmap("%s%s.png" % (VV2V68, category), getDesktop(0))
 @staticmethod
 def VVbz66():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","stream","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVHGO9(self, name, absolute=None, isDir=False, typ=None, png=None):
  if absolute and isDir:
   path = absolute
   path = FF55ZU(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FF8oA9(" -> " , VVXAXH) + FF8oA9(os.readlink(path), VViZMT)
  tableRow = [ (absolute, isDir, typ) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVavwW + 10, 0, self.VVeSt7, self.VVavwW, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   tableRow.append(CCXQTE.VVGIbI(0, 2, self.VVavwW-4, self.VVavwW-4, png))
  return tableRow
 def VV3Hec(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVWywx(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VVYGgD(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VV0hWU(self, file):
  if os.path.realpath(file) == file:
   return self.VVYGgD(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVYGgD(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVYGgD(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VV9gNH(self):
  ndx = self.l.getCurrentSelectionIndex()
  row = self.list[ndx]
  bg = self.multiSelect_color if row[2][6] == None else None
  ndx = self.getSelectionIndex()
  if ndx < len(self.list) - 1:
   self.moveToIndex(self.getSelectionIndex() + 1)
  iconData = self.VVpfIu(row, bg)
  if iconData:
   row[2] = iconData
   self.l.setList(self.list)
   return True
  else:
   return False
 def VVCYtP(self, isSel):
  bg = self.multiSelect_color if isSel else None
  for ndx, row in enumerate(self.list):
   iconData = self.VVpfIu(row, bg)
   if iconData:
    row[2] = iconData
  self.l.setList(self.list)
 def VVpfIu(self, row, bg):
  if self.VVe3Qh(row):
   iconData = list(row[2])
   iconData[6] = bg
   iconData[7] = bg
   return tuple(iconData)
  else:
   return None
 def VVe3Qh(self, row):
  if not row[0][0] in self.mountpoints:
   if   row[0][2] in (self.VVd7Gw, self.FILE_TYPE_LINK): return True
   elif row[0][2] == self.VVyi5L:
    if   VVk4gu           : return True
    elif not row[0][0] in self.PROHIBITED_FILES    : return True
  return False
 def VVeWQG(self):
  return self.VVe3Qh(self.list[self.l.getCurrentSelectionIndex()])
 def VV6kXD(self):
  tot = 0
  for row in self.list:
   if row[2][6]:
    tot += 1
  return tot
 def VV7EFA(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVzXBY(self, directory, selItem=None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VVpIzu:
    self.current_mountpoint = self.VV0hWU(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VVpIzu:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VVIQZP and not self.VV7EFA(path, self.VVAcKl):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VVHGO9(name=p.description, absolute=path, isDir=True, typ=self.VVMhuu, png=png))
    path = "/"
    if path not in self.VVIQZP and not self.VV7EFA(path, self.VVAcKl):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VVHGO9(name="INTERNAL FLASH", absolute="/", isDir=True, typ=self.VVq0bV, png=self.png_mem))
  elif self.VVo4Nf:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVcpye = eServiceCenter.getInstance()
   list = VVcpye.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVMWCQ and not self.isTop:
   if directory == self.current_mountpoint and self.VVpIzu:
    self.list.append(self.VVHGO9(name=self.VVKE9J, absolute=None, isDir=True, typ=self.VVw2T9, png=self.png_dirup))
   elif (directory != "/") and not (self.VVIQZP and self.VVYGgD(directory) in self.VVIQZP):
    self.list.append(self.VVHGO9(name=self.VV4zAm, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, typ=self.VVsuai, png=self.png_dirup))
  if self.VVMWCQ:
   for x in directories:
    if not (self.VVIQZP and self.VVYGgD(x) in self.VVIQZP) and not self.VV7EFA(x, self.VVAcKl):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVHGO9(name=name, absolute=x, isDir=True, typ=self.FILE_TYPE_LINK if os.path.islink(FF55ZU(x)) else self.VVyi5L, png=png))
  if self.VVoNaJ:
   for x in files:
    if self.VVo4Nf:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(target):
        png = self.png_slwfil
        name += FF8oA9(" -> " , VVXAXH) + FF8oA9(target, VViZMT)
       else:
        png = self.png_slbfil
        name += FF8oA9(" -> " , VVXAXH) + FF8oA9(target, VVOr14)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VV3Hec(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VV2V68, category))
    if (self.VVAncz is None) or iCompile(self.VVAncz[0], flags=self.VVAncz[1]).search(path):
     self.list.append(self.VVHGO9(name=name, absolute=x , isDir=False, typ=self.VVd7Gw, png=png))
  if self.VVpIzu and len(self.list) == 0:
   self.list.append(self.VVHGO9(name=FF8oA9("No USB connected", VVD4un), absolute=None, isDir=False, typ=self.VVqw0o, png=self.png_usb))
  self.l.setList(self.list)
  self.VV92XA()
  if selItem is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference): p = p.getPath()
    if p == selItem: self.moveToIndex(i)
    i += 1
 def VVjLjx(self):
  return self.current_directory
 def VVsX2Y(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VVYdJB(self):
  return self.VVUxIY() and self.VVjLjx()
 def VVUxIY(self):
  return self.list[0][1][7] in (self.VVKE9J, self.VV4zAm)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVzXBY(self.getSelection()[0], self.current_directory)
 def VVGKNW(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVAOkw)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVAOkw)
 def VVAOkw(self, action, device):
  self.VVWywx()
  if self.current_directory is None:
   self.VVlT28()
 def VVlT28(self):
  tDict = {}
  for row in self.list:
   if row[2][6]:
    tDict[row[0][0]] = 1
  self.VVzXBY(self.current_directory, self.VVGKNW())
  isSel = 0
  if tDict:
   for row in self.list:
    if tDict.get(row[0][0], 0):
     row[2] = list(row[2])
     row[2][6] = row[2][7] = self.multiSelect_color
     row[2] = tuple(row[2])
     isSel = 1
   self.l.setList(self.list)
  return isSel
 def VVh2JT(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVpklU : nameAlpMode, nameAlpTxt = self.VV1rfK, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVpklU, sAZ
  if mode == self.VVvE1i : nameNumMode, nameNumTxt = self.VViEN5, s90
  else       : nameNumMode, nameNumTxt = self.VVvE1i, s09
  if mode == self.VVtoAU : dateMode, dateTxt = self.VVUEie, sON
  else       : dateMode, dateTxt = self.VVtoAU, sNO
  if mode == self.VVvs2v : typeMode, typeTxt = self.VVLY9b, sZA
  else       : typeMode, typeTxt = self.VVvs2v, sAZ
  if   mode in (self.VVpklU, self.VV1rfK): txt = "Name (%s)" % (sAZ if mode == self.VVpklU else sZA)
  elif mode in (self.VVvE1i, self.VViEN5): txt = "Name (%s)" % (s09 if mode == self.VVpklU else s90)
  elif mode in (self.VVtoAU, self.VVUEie): txt = "Date (%s)" % (sNO if mode == self.VVtoAU else sON)
  elif mode in (self.VVvs2v, self.VVLY9b): txt = "Type (%s)" % (sAZ if mode == self.VVvs2v else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VV92XA(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FF0UO9(CFG.browserSortMode, mode)
   FF0UO9(CFG.browserSortMix, isMix)
  if self.list:
   if self.VVUxIY() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VVpklU, self.VV1rfK):
    rev = True if mode == self.VV1rfK else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VVvE1i, self.VViEN5):
    rev = True if mode == self.VViEN5 else False
    self.list = sorted(self.list[item0:], key=FFgRqj(BF(self.VVOpM2, isMix, rev)), reverse=rev)
   elif mode in (self.VVtoAU, self.VVUEie):
    rev = True if mode == self.VVUEie else False
    self.list = sorted(self.list[item0:], key=FFgRqj(BF(self.VVnwUR, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VVLY9b else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VVOpM2(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FFGVZA(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FF7buB(dir2, dir1) or FFGVZA(name1, name2)
 def VVnwUR(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FF7buB(stat2.st_ctime, stat1.st_ctime)
    else : return FF7buB(dir2, dir1) or FF7buB(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CCmyVJ(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FFPFsH(VV3hZy, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVcuvv   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVFWyw(defFG, "#00FFFFFF")
  self.defBG   = self.VVFWyw(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFRFZg(self, self.Title)
  self["keyRed"].show()
  FFKdfz(self["keyGreen"] , "< > Transp.")
  FFKdfz(self["keyYellow"], "Foreground")
  FFKdfz(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(VVQOuY,
  {
   "ok"   : self.VV08Jq     ,
   "green"   : self.VV08Jq     ,
   "yellow"  : BF(self.VVquzO, False)  ,
   "blue"   : BF(self.VVquzO, True)  ,
   "up"   : self.VV7yT6       ,
   "down"   : self.VVjcLF      ,
   "left"   : self.VViWA8      ,
   "right"   : self.VVpaBZ      ,
   "last"   : BF(self.VVOZsG, -5) ,
   "next"   : BF(self.VVOZsG, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVnLQg)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFC3pI(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFC3pI(self["keyRed"] , c)
  FFC3pI(self["keyGreen"] , c)
  self.VVLDQQ()
  self.VVaejs()
  FF0TXZ(self["myColorTst"], self.defFG)
  FFC3pI(self["myColorTst"], self.defBG)
 def VVFWyw(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVaejs(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVnwrS(0, 0)
     return
 def VV08Jq(self):
  self.close(self.defFG, self.defBG)
 def VV7yT6(self): self.VVnwrS(-1, 0)
 def VVjcLF(self): self.VVnwrS(1, 0)
 def VViWA8(self): self.VVnwrS(0, -1)
 def VVpaBZ(self): self.VVnwrS(0, 1)
 def VVnwrS(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVlfp9()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVz2yz()
 def VVLDQQ(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVz2yz(self):
  color = self.VVlfp9()
  if self.isBgMode: FFC3pI(self["myColorTst"], color)
  else   : FF0TXZ(self["myColorTst"], color)
 def VVquzO(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VVLDQQ()
   self.VVaejs()
 def VVOZsG(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVnwrS(0, 0)
 def VVJ6Ko(self):
  return hex(self.transp)[2:].zfill(2)
 def VVlfp9(self):
  return ("#%s%s" % (self.VVJ6Ko(), self.colors[self.curRow][self.curCol])).upper()
class CCA1uQ(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFPFsH(VV06lC, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FFRFZg(self, title="%s%s%s" % (self.Title, " " * 10, FF8oA9("Change values with Up , Down, < , 0 , >", VVD4un)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(VVQOuY,
  {
   "ok"  : self.VV2Iyl      ,
   "cancel" : self.VV2ouQ      ,
   "info"  : self.VV52CI    ,
   "red"  : self.VVAT6X  ,
   "green"  : self.VVz23w   ,
   "yellow" : BF(self.VVI9fr, 0)  ,
   "blue"  : self.VVlGut    ,
   "menu"  : self.VVR4os      ,
   "left"  : self.VViWA8      ,
   "right"  : self.VVpaBZ      ,
   "last"  : self.VVSUiy     ,
   "next"  : self.VVWfH3     ,
   "0"   : self.VVbXRa    ,
   "up"  : self.VV7yT6       ,
   "down"  : self.VVjcLF      ,
   "pageUp" : BF(self.VV04vT, True) ,
   "pageDown" : BF(self.VV04vT, False) ,
   "chanUp" : BF(self.VV04vT, True) ,
   "chanDown" : BF(self.VV04vT, False) ,
   "play"  : BF(self.VVprFd, "pause")  ,
   "pause"  : BF(self.VVprFd, "pause")  ,
   "playPause" : BF(self.VVprFd, "pause")  ,
   "stop"  : BF(self.VVprFd, "pause")  ,
   "audio"  : BF(self.VVprFd, "audio")  ,
   "subtitle" : BF(self.VVprFd, "subtitle") ,
   "rewind" : BF(self.VVprFd, "rewind" ) ,
   "forward" : BF(self.VVprFd, "forward" ) ,
   "rewindDm" : BF(self.VVprFd, "rewindDm") ,
   "forwardDm" : BF(self.VVprFd, "forwardDm")
  }, -1)
  self.VVvdhm()
  self.onShown.append(self.VVnLQg)
  self.onClose.append(self.VVeHzi)
 def VVvdhm(self):
  lst = []
  for fil in FF0KZb(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VVhYTJ:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VVnLQg(self):
  self.onShown.remove(self.VVnLQg)
  FFFlxX(self)
  FFk6h6(self)
  for i in range(3):
   self["mySubt%d" % i].hide()
  self.VVlFBl()
  self.VVtQy4()
  self.VVLKKq()
 def VVeHzi(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VVMLyj(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FFC3pI(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VVVZmy()
 def VVlFBl(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FFC3pI(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VV2Iyl(self):
  if self.settingShown:
   confItem = self.VVFMPj()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVtMHe = []
   if isinstance(lst[0], tuple): VVtMHe = [(x[1], x[0]) for x in lst]
   else      : VVtMHe = [(x, x) for x in lst]
   VVkbkP = FFECK9(self, self.VVNmbt, VVtMHe=VVtMHe, width=700, title=title, VVaRsg="#33221111", VVWgai="#33110011")
   VVkbkP.VV6A4S(confItem.getText())
  else:
   self.close("subtExit")
 def VVNmbt(self, item=None):
  if item:
   self.VVFMPj()[self.CursorPos].setValue(item)
   self.VVVZmy()
   self.VVtQy4()
   self.VVXhLw(True)
 def VV2ouQ(self):
  for confItem in self.VVFMPj():
   if confItem.isChanged():
    FFgBNQ(self, BF(self.VVkcKF, cbFnc=self.VVrR2w), "Save Changes ?", callBack_No=self.VVsDjl, title=self.Title)
    break
  else:
   self.VVrR2w()
 def VVrR2w(self):
   if self.settingShown: self.VVlFBl()
   else    : self.close("subtExit")
 def VVR4os(self):
  if self.settingShown: self.VVfdh2()
  else    : self.VVMLyj()
 def VViWA8(self): self.VVrpLo(-1)
 def VVpaBZ(self): self.VVrpLo(1)
 def VVrpLo(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VVsnT8()
   if pos == -1: ndx = self.VVDY21(posVal)
   else  : ndx = self.VV0BSs(posVal)
   if   ndx < 0      : FFZD7H(self, "Not found" , 500)
   elif ndx == 0      : FFZD7H(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FFZD7H(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VVC0Ha(frmSec)
    if allow:
     self.VVI9fr(delay, True)
     self.VVXhLw(force=True)
     CC817S(self.session, "Changed Delay to %d sec" % delay, timeout=500, fonSize=35)
    else:
     FFZD7H(self, "Delay out of range", 800)
 def VV04vT(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VVprFd(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVSUiy(self) : self.VVXwip(5)
 def VVWfH3(self) : self.VVXwip(6)
 def VVbXRa(self) : self.VVXwip(-1)
 def VV7yT6(self):
  if self.settingShown: self.VVXwip(1)
  else    : self.VV04vT(True)
 def VVjcLF(self):
  if self.settingShown: self.VVXwip(0)
  else    : self.VV04vT(False)
 def VVXwip(self, direction):
  if self.settingShown:
   confItem = self.VVFMPj()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VVVZmy()
   self.VVtQy4()
   self.VVXhLw(True)
 def VVFMPj(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VVsDjl(self):
  for confItem in self.VVFMPj(): confItem.cancel()
  self.VVVZmy()
  self.VVtQy4()
  self.VVlFBl()
 def VVAT6X(self):
  if self.settingShown:
   FFgBNQ(self, self.VVVZOH, "Reset Subtitle Settings to default ?", title=self.Title)
 def VVVZOH(self):
  for confItem in self.VVFMPj(): confItem.setValue(confItem.default)
  self.VVkcKF()
  self.VVVZmy()
  self.VVtQy4()
 def VVI9fr(self, delay, force=False):
  if self.settingShown or force:
   FF0UO9(CFG.subtDelaySec, delay)
   self.VV6Hgq()
   self.VVVZmy()
   self.VVtQy4()
   if self.settingShown:
    FFZD7H(self, 'Reset to "0"', 800, isGrn=True)
 def VVz23w(self):
  if self.settingShown:
   self.VVkcKF()
   self.VVlFBl()
 def VVkcKF(self, cbFnc=None):
  for confItem in self.VVFMPj(): confItem.save()
  configfile.save()
  self.VV6Hgq()
  FFZD7H(self, "Saved", 1000, isGrn=True)
  if cbFnc:
   cbFnc()
 def VVVZmy(self):
  cfgLst = self.VVFMPj()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VVtQy4(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   FFc6B4(path, fnt, isRepl=1)
  else:
   fnt = VVlMYE
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FFYZmF(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FF0TXZ(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FFC3pI(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    lineH = FFYpsV(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FFYZmF(CFG.subtVerticalPos.getValue(), 0, 100, 0, FFrRKK()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  FF1bLc(self, winW, winH)
 def VV52CI(self):
  sp = "    "
  txt  = "%s\n"   % FF8oA9("Subtitle File:", VVRuOi)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FF8oA9("Subtitle Settings:", VVRuOi)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VVsnT8()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FFBNnO(frmSec1)
   time2 = FFBNnO(toSec2)
   txt += "\n"
   txt += "%s\n"       % FF8oA9("Timing:", VVRuOi)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FFBNnO(durVal)
   txt += sp + "Progress\t: %s\n" % FFBNnO(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FF8oA9("Subtitle end reached.", VVtchu)
  FFoB4k(self, txt, title="Current Subtitle")
 def VVLKKq(self, path="", delay=0, enc=""):
  FFbA1i(self, BF(self.VVySR3, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VVySR3(self, path="", delay=0, enc=""):
  FFZD7H(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVAadm(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VVVZmy()
     self.VVORmT()
   else:
    path, delay, enc = CCA1uQ.VVfL4W(self)
    if path:
     self.VVLKKq(path=path, delay=delay, enc=enc)
    else:
     self.VVfdh2()
  except:
   pass
 def VVORmT(self):
  posVal, durVal = self.VVsnT8()
  if self.VV8viB(posVal):
   return
  CCA1uQ.VVu6dy(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVXhLw)
  except:
   self.timerUpdate.callback.append(self.VVXhLw)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVQGno)
  except:
   self.timerEndText.callback.append(self.VVQGno)
  FFZD7H(self, "Subtitle started", 700, isGrn=True)
 def VV8viB(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CCA1uQ.VVhRqg(self)
   FFOlRe(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VVfdh2(self):
  c1, c2, c3, c4, c5 = "", VVRuOi, VVdVTX, VV4mV2, VVtchu
  VVtMHe = []
  VVtMHe.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVtMHe.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVtMHe.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVtMHe.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVtMHe.append(VVXGzj)
   VVtMHe.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVtMHe.append(VVXGzj)
   VVtMHe.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVtMHe.append(VVXGzj)
   VVtMHe.append(("Help (Keys)"        , "help"  ))
  FFECK9(self, self.VVzGmG, VVtMHe=VVtMHe, width=700, title='Find Subtitle ".srt" File', VVaRsg="#33221111", VVWgai="#33110011")
 def VVzGmG(self, item=None):
  if item:
   if   item == "allSrt"   : self.VV8NX7(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VV8NX7(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    sDir = "/"
    for path in (CFG.lastFileManFindSrt.getValue(), CFG.MovieDownloadPath.getValue(), "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VVLIvZ, BF(CCVnYx, patternMode="srt", VVSMX5=sDir))
   elif item.startswith("sugSrt") : self.VV8NX7(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FFbA1i(self, BF(CC2TkW.VVLm7q, self, self.lastSubtFile, self.VVFM7w, self.lastSubtEnc or CFG.subtDefaultEnc.getValue()), title="Loading Codecs ...")
    else             : FFZD7H(self, "SRT File error", 1000)
   elif item == "disab":
    FFOlRe(CCA1uQ.VVhRqg(self))
    self.close("subtExit")
   elif item == "help"    : FFSnt9(self, "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VVFM7w(self, item=None):
  if item:
   FFbA1i(self, BF(self.VVLKKq, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VVLIvZ(self, path):
  if path:
   FF0UO9(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VVLKKq(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VV8NX7(self, defSrt="", mode=0, coeff=0.25):
  FFbA1i(self, BF(self.VV8Hq0, defSrt, mode=mode, coeff=coeff), title="Searching for srt files")
 def VV8Hq0(self, defSrt="", mode=0, coeff=0.25):
  if mode == 1:
   srtList = CCA1uQ.VVjUDT(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FFYEhL('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFXN5L(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VVQQvh(srtList, coeff)
     if err:
      if self.settingShown: FFZbFo(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VVsLLE = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FFDpEI(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVsLLE.append((fName, Dir))
   VVMWQK  = ("Select"    , self.VVb5Mp     , [])
   VVJi29 = self.VVpU6u
   VVZArZ = (""     , self.VV8glo       , [])
   VVBYRP = (""     , BF(self.VVqrDQ, defSrt, False) , [])
   VV1kWx = ("Find Current File" , BF(self.VVqrDQ, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FFDpub(self, None, title=title, header=header, VVcuvv=VVsLLE, VVbG6j=widths, VVGNdU=28, VVMWQK=VVMWQK, VVJi29=VVJi29, VVZArZ=VVZArZ, VVBYRP=VVBYRP, VV1kWx=VV1kWx, lastFindConfigObj=CFG.lastFindSubtitle
     , VVaRsg="#11002222", VVWgai="#33001111", VVSJJk="#33001111", VVlrsP="#11ffff00", VVYCZ6="#11445544", VVTjte="#22222222", VVIyj7="#11002233")
  elif self.settingShown : FFZbFo(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VVpU6u(self, VVdesl):
  VVdesl.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VV8glo(self, VVdesl, title, txt, colList):
  fName, Dir = colList
  FFoB4k(VVdesl, "%s\n\n%s%s" % (FF8oA9("Path:", VVRuOi), Dir, fName), title=title)
 def VVqrDQ(self, path, VVl1IZ, VVdesl, title, txt, colList):
  for ndx, row in enumerate(VVdesl.VVTW2g()):
   if path == row[1].strip() + row[0].strip():
    VVdesl.VVTklH(ndx)
    break
  else:
   if VVl1IZ:
    FFZD7H(VVdesl, "Not in list !", 1000)
 def VVb5Mp(self, VVdesl, title, txt, colList):
  VVdesl.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VVLKKq(path=path)
 def VVQQvh(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCfTje.VVtNm6(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName:
   if evName and CFG.epgLangTitle.getValue():
    CCfTje.VV9Aun(evName, "en")[0] or evName
   lst, err = CCA1uQ.VVJowE(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVAadm(self, path, enc=None):
  if enc and CC2TkW.VVAZoa(path, enc)      : enc = enc
  elif CC2TkW.VVAZoa(path, CFG.subtDefaultEnc.getValue()): enc = CFG.subtDefaultEnc.getValue()
  else                   : enc = None
  if not fileExists(path):
   return [], "File not found"
  if (FFF0Rr(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FF72md(path, encLst=enc)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVq58E(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VVU5FP(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VV6Hgq()
  return subtList, ""
 def VVU5FP(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VVq58E(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VV6Hgq(self):
  path = CCA1uQ.VVhRqg(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVXhLw(self, force=False):
  posVal, durVal = self.VVsnT8()
  if self.VV8viB(posVal):
   return
  curIndex = self.VVFvJ6(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVQGno()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FF0TXZ(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VVsnT8(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCuYKB.VVOZSB(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCfTje.VVtNm6(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VVFvJ6(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VVDY21(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VV0BSs(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VVQGno(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FF0TXZ(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VVlGut(self):
  FFbA1i(self, self.VVodri, title="Loading Lines ...")
 def VVodri(self):
  VVsLLE = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VVsLLE.append((cap, FFBNnO(frm), str(frm), firstLine))
  if VVsLLE:
   title = "Select Current Subtitle Line"
   VVXhOf  = self.VVsCLc
   VVJi29 = self.VVc9bD
   VVMWQK  = ("Select"   , self.VVGgSp , [title])
   VV1kWx = ("Current Line" , self.VVmlEA , [True])
   VVM9Pm = ("Reset Delay" , self.VVg2f9 , [])
   VVRHhw = ("New Delay"  , self.VVE5no   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VV0CnX  = (CENTER , CENTER, CENTER , LEFT    )
   VVdesl = FFDpub(self, None, title=title, header=header, VVcuvv=VVsLLE, VV0CnX=VV0CnX, VVbG6j=widths, VVGNdU=28, VVXhOf=VVXhOf, VVJi29=VVJi29, VVMWQK=VVMWQK, VV1kWx=VV1kWx, VVM9Pm=VVM9Pm, VVRHhw=VVRHhw
          , VVaRsg="#33002222", VVWgai="#33001111", VVSJJk="#33110011", VVlrsP="#11ffff00", VVYCZ6="#0a334455", VVTjte="#22222222", VVIyj7="#33002233")
  else:
   FFZbFo(self, "Cannot read lines !", 2000)
 def VVsCLc(self, VVdesl):
  self.subtLinesTable = VVdesl
  if CFG.subtDelaySec.getValue():
   VVdesl["keyYellow"].show()
   VVdesl["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVdesl["keyYellow"].hide()
  VVdesl["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FFC3pI(VVdesl["keyBlue"], "#22222222")
  VVdesl.VVLS8Z(BF(self.VVFhDC, VVdesl))
  self.VVmlEA(VVdesl, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVXkrj)
  except:
   self.timerSubtLines.callback.append(self.VVXkrj)
  self.timerSubtLines.start(1000, False)
 def VVc9bD(self, VVdesl):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVdesl.cancel()
 def VVXkrj(self):
  if self.subtLinesTable:
   VVdesl = self.subtLinesTable
   posVal, durVal = self.VVsnT8()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVFvJ6(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVdesl.VVLabl(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVdesl.VVFoW1(self.subtLinesTableNdx, row)
     row = VVdesl.VVLabl(curIndex)
     row[0] = color + row[0]
     VVdesl.VVFoW1(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VVGgSp(self, VVdesl, Title):
  delay, color, allow = self.VV9zmL(VVdesl)
  if allow:
   self.VVc9bD(VVdesl)
   self.VVI9fr(delay, True)
  else:
   FFZD7H(VVdesl, "Delay out of range", 1500)
 def VVmlEA(self, VVdesl, VVl1IZ, onlyColor=False):
  if VVdesl:
   posVal, durVal = self.VVsnT8()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVFvJ6(posVal)
    if curIndex > -1:
     VVdesl.VVTklH(curIndex)
    else:
     ndx = self.VVDY21(posVal)
     if ndx > -1:
      VVdesl.VVTklH(ndx)
 def VVg2f9(self, VVdesl, title, txt, colList):
  if VVdesl["keyYellow"].getVisible():
   self.VVI9fr(0, True)
   VVdesl["keyYellow"].hide()
   self.VVmlEA(VVdesl, False)
 def VVFhDC(self, VVdesl):
  delay, color, allow = self.VV9zmL(VVdesl)
  VVdesl["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VV9zmL(self, VVdesl):
  lineTime = float(VVdesl.VV1blE()[2].strip())
  return self.VVC0Ha(lineTime)
 def VVC0Ha(self, lineTime):
  posVal, durVal = self.VVsnT8()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VV7z62
   else     : allow, color = False, VVtchu
   delay = FFOaVa(val, -600, 600)
  return delay, color, allow
 def VVE5no(self, VVdesl, title, txt, colList):
  pass
 @staticmethod
 def VVIpWT(SELF):
  path, delay, enc = CCA1uQ.VVfL4W(SELF)
  return True if path else False
 @staticmethod
 def VVfL4W(SELF):
  path, delay, enc = CCA1uQ.VVDcqV(SELF)
  if not path:
   path = CCA1uQ.VV1Cxn(SELF)
  return path, delay, enc
 @staticmethod
 def VVDcqV(SELF):
  srtCfgPath = CCA1uQ.VVhRqg(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FF72md(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VVhRqg(SELF):
  fPath, fDir, fName = CCVnYx.VVASTW(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCfTje.VVtNm6(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF7TZz(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VV1Cxn(SELF):
  bestRatio = 0
  fPath, fDir, fName = CCVnYx.VVASTW(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CCA1uQ.VVjUDT(SELF)
    bLst, err = CCA1uQ.VVJowE(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVjUDT(SELF):
  fPath, fDir, fName = CCVnYx.VVASTW(SELF)
  if pathExists(fDir):
   files = FF0KZb(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VVJowE(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VVVysP():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVu6dy(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CCA1uQ.VVuGde()
 @staticmethod
 def VVuGde():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CCv4Bs(ScrollLabel):
 def __init__(self, parentSELF, text="", VVoHkG=True):
  ScrollLabel.__init__(self, text)
  self.VVoHkG   = VVoHkG
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VVRDn4  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.pageLines    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.fontFamily    = None
  self.VVGNdU    = None
  self.parentW    = None
  self.parentH    = None
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(VVQOuY,
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VVCwj3 ,
   "green"   : self.VVZNjr ,
   "yellow"  : self.VVU5Ee ,
   "blue"   : self.VVviBd ,
   "up"   : self.VVTqsq   ,
   "down"   : self.VVlu2y  ,
   "left"   : self.VVTqsq   ,
   "right"   : self.VVlu2y  ,
   "last"   : BF(self.VVNsr2, 0) ,
   "0"    : BF(self.VVNsr2, 1) ,
   "next"   : BF(self.VVNsr2, 2) ,
   "pageUp"  : self.VVVHem   ,
   "chanUp"  : self.VVVHem   ,
   "pageDown"  : self.VV2EDV   ,
   "chanDown"  : self.VV2EDV
  }, -1)
 def VV4U7z(self, isResizable=True, VVi6aX=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FF0TXZ(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FFC3pI(self.parentSELF["keyRedTop"], "#113A5365")
  FFFlxX(self.parentSELF, True)
  self.isResizable = isResizable
  if VVi6aX:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVGNdU  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFC3pI(self, color)
 def VV5vuE(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  VVavwW  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  self.pageLines = int(self.long_text.size().height() / VVavwW)
  margin   = int(VVavwW / 6)
  self.pageHeight = int(self.pageLines * VVavwW)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVRDn4 - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVI7da()
 def VVTqsq(self):
  if self.VVRDn4 > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def VVlu2y(self):
  if self.VVRDn4 > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVVHem(self):
  self.setPos(0)
 def VV2EDV(self):
  self.setPos(self.VVRDn4-self.pageHeight)
 def VVhMGs(self):
  return self.VVRDn4 <= self.pageHeight or self.curPos == self.VVRDn4 - self.pageHeight
 def getText(self):
  return self.message
 def VVI7da(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVRDn4, 3))
   start = int((100 - vis) * self.curPos / (self.VVRDn4 - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVSDbk=VVCv9j):
  old_VVhMGs = self.VVhMGs()
  self.message = str(text)
  if self.pageHeight:
   if len(self.message.splitlines()) < self.pageLines - 2:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.message = self.message.rstrip() + "\n"
   self.long_text.setText(self.message)
   self.VVRDn4 = self.long_text.calculateSize().height()
   if self.VVoHkG and self.VVRDn4 > self.pageHeight:
    self.scrollbar.show()
    self.VVI7da()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
    pageWidth  = self.instance.size().width() - w
    self.long_text.resize(eSize(pageWidth, self.VVRDn4))
    self.VVRDn4 = self.long_text.calculateSize().height()
    self.long_text.resize(eSize(pageWidth, self.VVRDn4))
   else:
    self.scrollbar.hide()
   if   VVSDbk == VVjF3K: self.setPos(0)
   elif VVSDbk == VViudQ : self.VV2EDV()
   elif old_VVhMGs    : self.VV2EDV()
 def appendText(self, text, VVSDbk=VViudQ):
  self.setText(self.message + str(text), VVSDbk=VVSDbk)
 def VVU5Ee(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VV9FMQ(size)
 def VVviBd(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VV9FMQ(size)
 def VVZNjr(self):
  self.VV9FMQ(self.VVGNdU)
 def VV9FMQ(self, VVGNdU):
  self.long_text.setFont(gFont(self.fontFamily, VVGNdU))
  self.setText(self.message, VVSDbk=VVCv9j)
  self.VVo5pW()
 def VVNsr2(self, align):
  self.long_text.setHAlign(align)
 def VVCwj3(self):
  VVtMHe = []
  VVtMHe.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Align Left" , "left" ))
  VVtMHe.append(("Align Center" , "center" ))
  VVtMHe.append(("Align Right" , "right" ))
  if self.outputFileToSave:
   VVtMHe.append(VVXGzj)
   VVtMHe.append((FF8oA9("Save to File", VVRuOi), "save"))
  VVtMHe.append(VVXGzj)
  VVtMHe.append(("Keys (Shortcuts)", "help"))
  FFECK9(self.parentSELF, self.VVvQx5, VVtMHe=VVtMHe, title="Text Option", width=500)
 def VVvQx5(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VVNsr2(0)
   elif item == "center" : self.VVNsr2(1)
   elif item == "right" : self.VVNsr2(2)
   elif item == "save"  : self.VVR4Td()
   elif item == "help"  : FFSnt9(self.parentSELF, "_help_txt", "Text Viewer (Keys)")
 def VVR4Td(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FFDpEI(expPath), self.outputFileToSave, FFZR2n())
   with open(outF, "w") as f:
    f.write(FF3gfV(self.message))
   FFDeF8(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FFOyl1(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVo5pW(self, minHeight=0):
  if self.isResizable:
   VVavwW = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont()))
   textH = min(self.pageHeight, VVavwW * (len(self.message.splitlines()) + 1))
   if textH < self.pageHeight and self.VVRDn4 < self.pageHeight:
    textH = max(textH, self.VVRDn4)
   self.resize(eSize(*(self.instance.size().width(), textH + 6)))
   diff = self.pageHeight - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   if minHeight > 0:
    newH = max(newH, minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, min(self.parentH, newH))))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
