import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigInteger, ConfigSubList
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVIPCs   = "v4.0.0"
VVSo0J    = "02-02-2022"
EASY_MODE    = 0
VVRFnz   = 0
VV2r4v   = 0
VVTqTJ  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VV38TZ  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVBgPY    = "/media/usb/"
VVRqVx    = "/usr/share/enigma2/picon/"
VVyYRZ   = "/etc/enigma2/"
VV8o8r  = "ajpanel_update_url"
VV92IV   = "AJPan"
VV5FAb    = "AUTO FIND"
VVCYgA    = ""
VVXu7B    = "Regular"
VVkthi      = "-" * 80
VVxSb7    = ("-" * 100, )
VVsMrL    = ""
VV0PME   = " && echo 'Successful' || echo 'Failed!'"
VV77Of    = []
VVzlaf  = "Cannot continue (No Enough Memory) !"
FILE_ENCODINGS   = (None, "utf-8", "ISO8859-15", "ISO8859-7", "ISO8859-5", "ISO6937", "windows-1250", "windows-1252", "unicode_escape")
VVcuSx  = False
VVLoj5  = False
VVAEGR = False
VVd6Yn     = 0
VVr5yh    = 1
VVRJjU    = 2
VVLcyG   = 3
VVWdqz    = 4
VVbXcF    = 5
VVAxwO = 6
VVARMy = 7
VVjmzI  = 8
VVzWll   = 9
VVzxpQ   = 10
VVaOxX   = 11
VVHWzd  = 12
VVZeZP  = 13
VVIl27    = 14
VV52Mj   = 15
VVooHc   = 16
VVAwpk    = 17
VVbZPn  = 18
VVFDUg  = 15
VV64Ja   = 0
VV9wvN   = 1
VVpBFp   = 2
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices = [ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices = [ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices = [ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices = [ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=False)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsPath    = ConfigDirectory(default=VV5FAb, visible_width=51)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=51)
CFG.PIconsPath     = ConfigDirectory(default=VVRqVx, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVBgPY, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
def FFH9uI():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVfwLT  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVsOT6 = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVfwLT  : return 0
  elif VVsOT6 : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVKAZP = FFH9uI()
VVtSyw = VVIbxt = VVo2ZM = VVbvoH = VVMjkH = VVQrXh = VVoiSL = VVllxZ = COLOR_CONS_BRIGHT_YELLOW = VVq6Xr = VVvFue = VV0P8J = VVbEpi = ""
def FFBmPI()  : return FFssuQ()
def FFNf4a(*args) : FFbIU7(True , *args)
def FFYICr(*args): FFbIU7(False, *args)
def FFbIU7(addSep=True, *args):
 if VVRFnz:
  txt  = (">>>> %s\n" % VVkthi) if addSep else ""
  txt += ">>>> %s" % " , ".join(map(str, args))
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FF5y4E(txt, isAppend=True, ignoreErr=False):
 if VVRFnz:
  tm = FFMFzk()
  err = ""
  if not ignoreErr:
   err = FFssuQ()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFNf4a(err)
  FFNf4a("Output Log File : %s" % fileName)
def FFssuQ():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFMFzk()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except Exception as e:
  return "Cannot Trace !"
VV77Of = []
def FFE5Iz(win):
 global VV77Of
 if not win in VV77Of:
  VV77Of.append(win)
def FFysPJ(*args):
 global VV77Of
 for win in VV77Of:
  try:
   win.close()
  except:
   pass
 VV77Of = []
def FFfKwP():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VViIbq = FFfKwP()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FF3Ibo()     : return PluginDescriptor(fnc=FFPKqP, where=[PluginDescriptor.WHERE_SESSIONSTART] , needsRestart=True   , description="AJPanel Startup")
def FFiFaj()      : return getDescriptor(FF2LHz   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFkK9U()       : return getDescriptor(FFSUip  , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFWM5Y()   : return getDescriptor(FFLcaB , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FF4wOg(): return getDescriptor(FFRDWj , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player"  , descr="Signal Monitor / Player")
def FFPuUl()  : return getDescriptor(FFzdel  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV"     , descr="IPTV Menu")
def FFV6AA()     : return getDescriptor(FFVyCK , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info."    , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFiFaj() , FFkK9U() , FF3Ibo() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFWM5Y())
  result.append(FF4wOg())
  result.append(FFPuUl())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFV6AA())
 return result
def FFPKqP(reason, **kwargs):
 if reason == 0:
  FFQRRO()
  if "session" in kwargs:
   session = kwargs["session"]
   FFWpC2(session)
   CCD2tz(session)
def FFSUip(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FF2LHz, PLUGIN_NAME, 45)]
 else:
  return []
def FF2LHz(session, **kwargs):
 session.open(Main_Menu)
def FFLcaB(session, **kwargs):
 session.open(CCw1Kh)
def FFRDWj(session, **kwargs):
 FFTC4m(session, isFromSession=True)
def FFzdel(session, **kwargs):
 session.open(CCxu1n)
def FFVyCK(session, **kwargs):
 session.open(CCditA, fncMode=CCditA.VVP8oV)
def FFNXhB():
 FFjvRY(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFWM5Y(), FF4wOg(), FFPuUl() ])
 FFjvRY(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFV6AA() ])
def FFjvRY(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VVGo8j = None
def FFQRRO():
 try:
  global VVGo8j
  if VVGo8j is None:
   VVGo8j    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFzURj
  ChannelContextMenu.FFL21j = FFL21j
 except:
  pass
def FFzURj(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVGo8j(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFL21j, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFL21j, title1, csel, isFind=True))))
def FFL21j(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFdST5(refCode)
 except:
  pass
 self.session.open(boundFunction(CCfNh8, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFWpC2(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FFYXPs, session, "lok")
 hk.actions['longCancel'] = boundFunction(FFYXPs, session, "lesc")
 hk.actions['longRed']  = boundFunction(FFYXPs, session, "lred")
def FFYXPs(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFTC4m(session, isFromSession=True)
def FFEVgi(SELF, title="", addLabel=False, addScrollLabel=False, VVH93c=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFjCXZ()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCXDUQ(SELF)
 if VVH93c:
  SELF["myMenu"] = MenuList(VVH93c)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVrVKJ        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FF9Mg2(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FF7SeZ, SELF, "0") ,
  "1"    : boundFunction(FF7SeZ, SELF, "1") ,
  "2"    : boundFunction(FF7SeZ, SELF, "2") ,
  "3"    : boundFunction(FF7SeZ, SELF, "3") ,
  "4"    : boundFunction(FF7SeZ, SELF, "4") ,
  "5"    : boundFunction(FF7SeZ, SELF, "5") ,
  "6"    : boundFunction(FF7SeZ, SELF, "6") ,
  "7"    : boundFunction(FF7SeZ, SELF, "7") ,
  "8"    : boundFunction(FF7SeZ, SELF, "8") ,
  "9"    : boundFunction(FF7SeZ, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FFxZ8X, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FF7SeZ(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVbEpi:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVbEpi + SELF.keyPressed + VVIbxt)
    txt = VVIbxt + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FF70nx(SELF, txt)
def FFxZ8X(SELF, tableObj, colNum):
 FF70nx(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     SELF.VV4mn9(i)
     break
 except:
  pass
def FF5QLc(SELF, setMenuAction=True):
 if setMenuAction:
  global VVsMrL
  VVsMrL = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFjCXZ():
 return ("  %s" % VVsMrL)
def FFUxNa(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFuz5p(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFzKP2(color):
 return parseColor(color).argb()
def FFQGsp(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFAt0z(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFQOQY(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFa6r1(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVbEpi)
 else:
  return ""
def FF0v1F(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVkthi, word, VVkthi, VVbEpi)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVkthi, word, VVkthi)
def FFQRKC(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVbEpi
def FFfq9Z(color):
 if color: return "echo -e '%s' %s;" % (VVkthi, FFa6r1(VVkthi, VVllxZ))
 else : return "echo -e '%s';" % VVkthi
def FFwzVc(title, color):
 title = "%s\n%s\n%s\n" % (VVkthi, title, VVkthi)
 return FFQRKC(title, color)
def FFj85G(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFl807(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFpblr(callBackFunction):
 tCons = CC9sFI()
 tCons.ePopen("echo", boundFunction(FFDbq2, callBackFunction))
def FFDbq2(callBackFunction, result, retval):
 callBackFunction()
def FFTYCg(SELF, fnc, title="Processing ...", clearMsg=True):
 FF70nx(SELF, title)
 tCons = CC9sFI()
 tCons.ePopen("echo", boundFunction(FFkKxv, SELF, fnc, clearMsg))
def FFkKxv(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FF70nx(SELF)
def FFgni4(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVzlaf
  else       : return ""
def FF8QLc(cmd):
 txt = FFgni4(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFCdzs(cmd):
 lines = FF8QLc(cmd)
 if lines: return lines[0]
 else : return ""
def FFZzCQ(SELF, cmd):
 lines = FF8QLc(cmd)
 VVYnAG = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVYnAG.append((key, val))
  elif line:
   VVYnAG.append((line, ""))
 if VVYnAG:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFeiXT(SELF, None, header=header, VVOhES=VVYnAG, VVOmXx=widths, VVhAiY=28)
 else:
  FF4bPN(SELF, cmd)
def FF4bPN(    SELF, cmd, **kwargs): SELF.session.open(CCyVhv, VVYCFx=cmd, VVMIXO=True, VVTcLD=VV9wvN, **kwargs)
def FFasfN(  SELF, cmd, **kwargs): SELF.session.open(CCyVhv, VVYCFx=cmd, **kwargs)
def FFYoKS(   SELF, cmd, **kwargs): SELF.session.open(CCyVhv, VVYCFx=cmd, VVp8kb=True, VVCSaZ=True, VVTcLD=VV9wvN, **kwargs)
def FF68Dg(  SELF, cmd, **kwargs): SELF.session.open(CCyVhv, VVYCFx=cmd, VVp8kb=True, VVCSaZ=True, VVTcLD=VVpBFp, **kwargs)
def FFtPYL(  SELF, cmd, **kwargs): SELF.session.open(CCyVhv, VVYCFx=cmd, VVH1oe=True , **kwargs)
def FF5l0J( SELF, cmd, **kwargs): SELF.session.open(CCyVhv, VVYCFx=cmd, VVkHo4=True   , **kwargs)
def FFpter( SELF, cmd, **kwargs): SELF.session.open(CCyVhv, VVYCFx=cmd, VVFNXU=True  , **kwargs)
def FFmogf(cmd):
 return cmd + " > /dev/null 2>&1"
def FFSt8V():
 return " > /dev/null 2>&1"
def FFeAYH(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFJQpq(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFWFvN():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFCdzs(cmd)
VVmkLF     = 0
VVawNP      = 1
VVhRz7   = 2
VVxXfv      = 3
VV2shS      = 4
VVyGLm     = 5
VVzZPa     = 6
VVGnsR  = 7
VVs217 = 8
VV1pls  = 9
VVuYpF     = 10
VVJmSo  = 11
VV4AUp  = 12
def FFfvin(parmNum, grepTxt):
 if   parmNum == VVmkLF  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVawNP   : param = ["list"   , "apt list" ]
 elif parmNum == VVhRz7: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFWFvN()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFrD2J(parmNum, package):
 if   parmNum == VVxXfv      : param = ["info"      , "apt show"         ]
 elif parmNum == VV2shS      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVyGLm     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVzZPa     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVGnsR  : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVs217 : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VV1pls  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVuYpF     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVJmSo  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VV4AUp  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFWFvN()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFHrkw():
 result = FFCdzs("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFrD2J(VVzZPa , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFmogf("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFmogf("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFa6r1(failed1, VVllxZ))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFa6r1(failed2, VVllxZ))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFa6r1(failed3, VVo2ZM))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFG2Ge(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFrD2J(VVzZPa , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFmogf("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFa6r1(failed1, VVllxZ))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFa6r1(failed2, VVo2ZM))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFbBOf(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFmogf('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFmogf("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FF1gqL(path, maxSize=-1):
 txt = ""
 for enc in FILE_ENCODINGS:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFxHei(path, keepends=False, maxSize=-1):
 lines = FF1gqL(path, maxSize)
 return lines.splitlines(keepends)
def FFdAGY(SELF, path):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFoME1(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFxHei(path, maxSize=maxSize)
  if lines: FFNGa4(SELF, lines, title=title, VVTcLD=VV9wvN)
  else : FFk2jj(SELF, path, title=title)
 else:
  FFZZL8(SELF, path, title)
def FFoJme(SELF, path, title):
 if fileExists(path):
  txt = FF1gqL(path)
  txt = txt.replace("#W#", VVbEpi)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVIbxt)
  txt = txt.replace("#C#", VVq6Xr)
  txt = txt.replace("#P#", VVbvoH)
  FFNGa4(SELF, txt, title=title)
 else:
  FFZZL8(SELF, path, title)
def FFViFM(path, SELF=None):
 txt = ""
 for enc in FILE_ENCODINGS:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     pass
   return enc
  except:
   pass
 if SELF:
  FFy0Rl(SELF, "Cannot detect file encoding for:\n\n%s" % path)
 return -1
def FFwvx4(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FFCtHZ(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FF1zN0(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFIm0p(parent)
 else    : return FFEMdz(parent)
def FFoME1(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFIm0p(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFEMdz(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFqyIo():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVTqTJ)
 paths.append(VVTqTJ.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFCtHZ(ba)
 for p in list:
  p = ba + p + VVTqTJ
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VV92IV, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVTqTJ, VV92IV , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVEdhy, VVHIBy = FFqyIo()
def FFGAvG():
 def VVkWds(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 iPath = CFG.iptvHostsPath.getValue()
 if not iPath == VV5FAb and not pathExists(iPath):
  CFG.iptvHostsPath.setValue(VV5FAb)
  CFG.iptvHostsPath.save()
  oldIptvHostsPath = VV5FAb
 else:
  oldIptvHostsPath = ""
 oldMovieDownloadPath = VVkWds(CFG.MovieDownloadPath, CCgcno.VVFeSR())
 VVFD7Z   = VVkWds(CFG.backupPath, CCPaCW.VVZTQR())
 VVQJDW   = VVkWds(CFG.downloadedPackagesPath, t)
 VVsZFE  = VVkWds(CFG.exportedTablesPath, t)
 VVIohq  = VVkWds(CFG.exportedPIconsPath, t)
 VVitqI   = VVkWds(CFG.packageOutputPath, t)
 global VVBgPY
 VVBgPY = FFIm0p(CFG.backupPath.getValue())
 if VVFD7Z or VVitqI or VVQJDW or VVsZFE or VVIohq or oldIptvHostsPath or oldMovieDownloadPath:
  configfile.save()
 return VVFD7Z, VVitqI, VVQJDW, VVsZFE, VVIohq, oldIptvHostsPath, oldMovieDownloadPath
def FF6jLD(path):
 path = FFEMdz(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FF8xS3(SELF, pathList, tarFileName, addTimeStamp=True):
 VVOhES = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVOhES.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVOhES.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVOhES.append(path)
 if not VVOhES:
  FFy0Rl(SELF, "Files not found!")
 elif not pathExists(VVBgPY):
  FFy0Rl(SELF, "Path not found!\n\n%s" % VVBgPY)
 else:
  VVWm9U = FFIm0p(VVBgPY)
  tarFileName = "%s%s" % (VVWm9U, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFVgvw())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVOhES:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVkthi
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFa6r1(tarFileName, VVoiSL))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFa6r1(failed, VVoiSL))
  cmd += "fi;"
  cmd +=  sep
  FFasfN(SELF, cmd)
def FFUVmx(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFmJlY(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFmJlY(SELF["keyInfo"], "info")
def FFmJlY(barObj, fName):
 path = "%s%s%s" % (VVHIBy, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFzr12(SELF, title, VVigoX):
 SELF.session.open(boundFunction(CCXZqm, Title=title, VVigoX=VVigoX))
def FFrbJa(labelObj, VVigoX):
 if VVigoX and fileExists(VVigoX):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VVXazc(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VVXazc)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VVigoX)
   return True
  except:
   pass
 return False
def FFB3KB(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFp4Mi(satNum)
  return satName
def FFp4Mi(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFpaqk(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFB3KB(val)
  else  : sat = FFp4Mi(val)
 return sat
def FFovAP(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFB3KB(num)
 except:
  pass
 return sat
def FFSSz7(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFF0On(SELF, isFromSession=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFYzNX(info, iServiceInformation.sServiceref)
   prov = FFYzNX(info, iServiceInformation.sProvider)
   state = str(FFYzNX(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FF9NA0(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFxIgr(refCode)
 return info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFYzNX(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FF3zgs(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFdST5(refCode):
 info = FFTALr(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFzGKJ(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FF3Lm8(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFTALr(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVwjcZ = eServiceCenter.getInstance()
  if VVwjcZ:
   info = VVwjcZ.info(service)
 return info
def FFqfoC(SELF, refCode, VVIPM3=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  FFpY3C(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVIPM3:
   FFTC4m(SELF, isFromSession)
 try:
  VV6K6N = InfoBar.instance
  if VV6K6N:
   VVomKR = VV6K6N.servicelist
   if VVomKR:
    servRef = eServiceReference(refCode)
    VVomKR.saveChannel(servRef)
 except:
  pass
def FFpY3C(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCqMtN()
    if pr.VVuf5p(refCode, chName, decodedUrl, iptvRef):
     pr.VV7P1a(SELF, isFromSession)
def FF9NA0(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFxIgr(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFwDWV(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FF6MIz(userBfile):
 txt = ""
 bFile = VVyYRZ + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVyYRZ + userBfile):
  fTxt = FF1gqL(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFCdzs('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
 return
def FFwDWV(url):
 if iUnquote : return iUnquote(url)
 else  : return url
def FFOEqY(url):
 if iQuote : return iQuote(url)
 else  : return url
def FFxHES(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFHtVc(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFg1k2(txt):
 try:
  return FFxHES(FFHtVc(txt)) == txt
 except:
  return False
def FFTC4m(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(SELF, isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCqamV, isFromExternal=isFromSession)
 else      : FF1laI(session, reopen=True, isFromExternal=isFromSession)
def FF1laI(session, reopen=False, isFromExternal=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FF1laI, session, isFromExternal=isFromExternal), boundFunction(CCmJYl, isFromExternal=isFromExternal))
  except:
   try:
    FFoRrm(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFkJo0(refCode):
 tp = CCD09M()
 if tp.VVvjlJ(refCode) : return True
 else        : return False
def FFNElJ(refCode, isHide):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFMFw4():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FFq54s():
 VV6K6N = InfoBar.instance
 if VV6K6N:
  VVomKR = VV6K6N.servicelist
  if VVomKR:
   return VVomKR.getBouquetList()
 return None
def FFFxFr():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFvULn():
 path = FFFxFr()
 if path:
  txt = FF1gqL(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FFyRQh():
 return FFSDRx(InfoBar.instance.servicelist.getRoot())
def FFSDRx(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVwjcZ = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVwjcZ.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FFdJvq():
 VVvNfE = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VV926r = list(VVvNfE)
 return VV926r, VVvNfE
def FFi4Qv():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFR1m4(session, VVMZlH):
 VV3vuS, VVKnfn, VVDiot, camCommand = FFjEc6()
 if VVKnfn:
  runLog = False
  if   VVMZlH == CCNGTK.VVdPZ8 : runLog = True
  elif VVMZlH == CCNGTK.VVsACF : runLog = True
  elif not VVDiot          : FFoRrm(session, message="SoftCam not started yet!")
  elif fileExists(VVDiot)        : runLog = True
  else             : FFoRrm(session, message="File not found !\n\n%s" % VVDiot)
  if runLog:
   session.open(boundFunction(CCNGTK, VV3vuS=VV3vuS, VVKnfn=VVKnfn, VVDiot=VVDiot, VVMZlH=VVMZlH))
 else:
  FFoRrm(session, message="No active OSCam/NCam found !", title="Live Log")
def FFjEc6():
 VV3vuS = "/etc/tuxbox/config/"
 VVKnfn = None
 VVDiot  = None
 camCommand = FFCdzs("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVKnfn = "oscam"
 elif "ncam"  in camCommand : VVKnfn = "ncam"
 if VVKnfn:
  path = FFCdzs(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFIm0p(path)
  if pathExists(path):
   VV3vuS = path
  tFile = VV3vuS + VVKnfn + ".conf"
  tFile = FFCdzs("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVDiot = tFile
 return VV3vuS, VVKnfn, VVDiot, camCommand
def FFI3l2(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFgdpv():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFVgvw():
 return FFgdpv().replace(" ", "_").replace("-", "").replace(":", "")
def FFEQDX(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFMFzk():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FF9cSe(url, outFile, timeout=3):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCxu1n.VVoNlW(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCxu1n.VViIz6_forBouquet(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFmogf("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFjbSc(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FF2Zt3(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
VVcj8R = 0
def FFiD22():
 global VVcj8R
 VVcj8R = iTime()
def FFisEX():
 FFNf4a(">>>>>> Elapsed\t: {:.6f} seconds".format(iTime() - VVcj8R).rstrip("0").rstrip("."))
def FFM9af(SELF, message, title=""):
 SELF.session.open(boundFunction(CCzUcj, title=title, message=message, VVFdco=True))
def FFNGa4(SELF, message, title="", VVTcLD=VV9wvN, **kwargs):
 SELF.session.open(boundFunction(CCzUcj, title=title, message=message, VVTcLD=VVTcLD, **kwargs))
def FFy0Rl(SELF, message, title="")  : FFoRrm(SELF.session, message, title)
def FFZZL8(SELF, path, title="") : FFoRrm(SELF.session, "File not found !\n\n%s" % path, title)
def FFk2jj(SELF, path, title="") : FFoRrm(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFkPbc(SELF, title="")  : FFoRrm(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFoRrm(session, message, title="") : session.open(boundFunction(CCziej, title=title, message=message))
def FFpA7M(SELF, VVzQlc, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVzQlc, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVzQlc, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVzQlc, boundFunction(CC76eZ, title=title, message=message, VVNEJF=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFy0Rl(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FF3096(SELF, callBack_Yes, VVWYUn, callBack_No=None, title="", VVZH0D=False, VVKUzC=True):
 SELF.session.openWithCallback(boundFunction(FFTSOd, callBack_Yes, callBack_No)
        , boundFunction(CCR9wL, title=title, VVWYUn=VVWYUn, VVKUzC=VVKUzC, VVZH0D=VVZH0D))
def FFTSOd(callBack_Yes, callBack_No, FF3096ed):
 if FF3096ed : callBack_Yes()
 elif callBack_No: callBack_No()
def FF70nx(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFAt0z(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFydOe(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFvNec(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVx2mV = eTimer()
def FFydOe(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFCka9, SELF))
 fnc = boundFunction(FFCka9, SELF)
 try:
  t = VVx2mV.timeout.connect(fnc)
 except:
  VVx2mV.callback.append(fnc)
 VVx2mV.start(milliSeconds, 1)
def FFCka9(SELF):
 VVx2mV.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFeiXT(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCnr9g, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCnr9g, **kwargs))
  FFE5Iz(win)
  return win
 except:
  return None
def FFSEnE(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCMlqI, **kwargs))
 FFE5Iz(win)
 return win
def FFtcRZ(SELF, **kwargs):
 SELF.session.open(CCditA, **kwargs)
def FFcxMz(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFqmQB(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVXu7B, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFsbO6(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFqmQB(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFI2oD():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFTViU(VVhAiY):
 screenSize  = FFI2oD()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVhAiY)
 return bodyFontSize
def FFh7wR(VVhAiY, extraSpace):
 font = gFont(VVXu7B, VVhAiY)
 VVAdb2 = fontRenderClass.getInstance().getLineHeight(font) or (VVhAiY * 1.25)
 return int(VVAdb2 + VVAdb2 * extraSpace)
def FFArtN(fontName):
 fList = None
 try:
  from enigma import getFontFaces
  fList = getFontFaces()
 except:
  try:
   from skin import getFontFaces
   fList = getFontFaces()
  except:
   pass
 if fList and fontName in fList : return fontName
 else       : return VVXu7B
def FFvMLn(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFI2oD()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * VVFDUg)
 bodyFontStr  = 'font="%s;%d"' % (VVXu7B, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFh7wR(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVXu7B, titleFontSize, alignLeftCenter)
 if winType == VVd6Yn or winType == VVr5yh:
  if winType == VVr5yh : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVbZPn:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == VVIl27:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FFM9afL = b2Left2 + timeW + marginLeft
  FFM9afW = b2Left3 - marginLeft - FFM9afL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FFM9afL  , b2Top, FFM9afW , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="1000" alphatest="blend" />' % (0, top, sz, sz)
 elif winType == VV52Mj:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVWdqz:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVRJjU:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVLcyG:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVXu7B, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVXu7B, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVzxpQ:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFM9afH = int(bodyH * 0.5)
  inpTop = bodyTop + FFM9afH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFM9afH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVXu7B, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVXu7B, mapF, alignCenter)
 elif winType == VVaOxX:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVHWzd:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVXu7B, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVooHc:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVXu7B, fontH, alignCenter)
 elif winType == VVZeZP:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVXu7B, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVXu7B, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVXu7B, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVAwpk:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 else:
  if   winType == VVARMy : align = alignLeftCenter
  elif winType == VVAxwO : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVzWll:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VVbXcF:
   moreParams = ""
  else:
   fontStr = bodyFontStr
   if usefixedFont and winType == VVAxwO:
    fontStr = 'font="%s;%d"' % (FFArtN("Fixed"), bodyFontSize)
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" %s %s ' % (bodyColor, fontStr, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVhAiY = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVXu7B, VVhAiY, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVMBDz = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVXu7B, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVMBDz[i], VVXu7B, barFont, alignCenter)
   left += btnW + gap
 if winType == VVAxwO:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVMBDz = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVMBDz[i], VVXu7B, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFvMLn(VVd6Yn, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.hiddenMenuPass = ""
  self.themsList  = []
  VVH93c = []
  if VV2r4v:
   VVH93c.append(("-- MY TEST --"    , "myTest"   ))
  VVH93c.append(("  File Manager"     , "FileManager"  ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("  Services/Channels"    , "ChannelsTools" ))
  VVH93c.append(("  IPTV"       , "IptvTools"  ))
  VVH93c.append(("  PIcons"       , "PIconsTools"  ))
  VVH93c.append(("  SoftCam"      , "SoftCam"   ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("  Plugins"      , "PluginsTools" ))
  VVH93c.append(("  Terminal"      , "Terminal"  ))
  VVH93c.append(("  Backup & Restore"    , "BackupRestore" ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("  Date/Time"      , "Date_Time"  ))
  VVH93c.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVH93c)
  FFEVgi(self, VVH93c=VVH93c)
  FFUxNa(self["keyRed"] , "Exit")
  FFUxNa(self["keyGreen"] , "Settings")
  FFUxNa(self["keyYellow"], "Dev. Info.")
  FFUxNa(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VVdayu       ,
   "yellow"  : self.VVWdYO       ,
   "blue"   : self.VVptCO       ,
   "info"   : self.VVptCO       ,
   "last"   : self.VVFcq2      ,
   "next"   : self.VVOwJG       ,
   "menu"   : self.VVhm6a     ,
   "0"    : boundFunction(self.VVbdOd, 0) ,
   "1"    : boundFunction(self.VVBwCV, 1)   ,
   "2"    : boundFunction(self.VVBwCV, 2)   ,
   "3"    : boundFunction(self.VVBwCV, 3)   ,
   "4"    : boundFunction(self.VVBwCV, 4)   ,
   "5"    : boundFunction(self.VVBwCV, 5)   ,
   "6"    : boundFunction(self.VVBwCV, 6)   ,
   "7"    : boundFunction(self.VVBwCV, 7)   ,
   "8"    : boundFunction(self.VVBwCV, 8)   ,
   "9"    : boundFunction(self.VVBwCV, 9)
  })
  self.onShown.append(self.VVYVvL)
  self.onClose.append(self.onExit)
  global VVcuSx, VVLoj5, VVAEGR
  VVcuSx = VVLoj5 = VVAEGR = False
 def VVrVKJ(self):
  item = FF5QLc(self)
  self.VVBwCV(item)
 def VVBwCV(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVdect()
   elif item in ("FileManager"  , 1) : self.session.open(CCw1Kh)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCoJ8d)
   elif item in ("IptvTools"  , 3) : self.session.open(CCxu1n)
   elif item in ("PIconsTools"  , 4) : self.VVOtDc()
   elif item in ("SoftCam"   , 5) : self.session.open(CChsN8)
   elif item in ("PluginsTools" , 6) : self.session.open(CCBva9)
   elif item in ("Terminal"  , 7) : self.session.open(CCZ8hP)
   elif item in ("BackupRestore" , 8) : self.session.open(CCoLRv)
   elif item in ("Date_Time"  , 9) : self.session.open(CCi74Y)
   elif item in ("CheckInternet" , 10) : self.session.open(CCf48Y)
   else         : self.close()
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  FFj85G(self["myMenu"])
  FFsbO6(self)
  FFcxMz(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVIPCs)
  self["myTitle"].setText(title)
  VVFD7Z, VVitqI, VVQJDW, VVsZFE, VVIohq, oldIptvHostsPath, oldMovieDownloadPath = FFGAvG()
  self.VVLEhy()
  if VVFD7Z or VVitqI or VVQJDW or VVsZFE or VVIohq or oldIptvHostsPath or oldMovieDownloadPath:
   VVQGQz = lambda path, subj: "%s:\n%s\n\n" % (subj, FFQRKC(path, VVo2ZM)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVQGQz(oldIptvHostsPath  , "IPTV Hosts Files Path"   )
   txt += VVQGQz(VVFD7Z   , "Backup/Restore Path"    )
   txt += VVQGQz(VVitqI  , "Created Package Files (IPK/DEB)" )
   txt += VVQGQz(VVQJDW  , "Download Packages (from feeds)" )
   txt += VVQGQz(VVsZFE , "Exported Tables"     )
   txt += VVQGQz(VVIohq , "Exported PIcons"     )
   txt += VVQGQz(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFNGa4(self, txt, title="Settings Paths")
  if (EASY_MODE or VVRFnz or VV2r4v):
   FFAt0z(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FF70nx(self, "Welcome", 300)
  FFpblr(boundFunction(self.VVMcLy, title))
 def VVMcLy(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCPaCW.VVpmQj()
   if url:
    newWebVer = CCPaCW.VV7BvF(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFmogf("rm /tmp/ajpanel*"))
  global VVcuSx, VVLoj5, VVAEGR
  VVcuSx = VVLoj5 = VVAEGR = False
 def VVbdOd(self, digit):
  self.hiddenMenuPass += str(digit)
  ln = len(self.hiddenMenuPass)
  global VVcuSx, VVAEGR
  if ln == 4:
   if self.hiddenMenuPass == "0" * ln:
    VVcuSx = True
    FFAt0z(self["myTitle"], "#800080")
   else:
    self.hiddenMenuPass = "x"
  elif self.hiddenMenuPass == "0" * ln:
   VVAEGR = True
 def VVOwJG(self):
  self.hiddenMenuPass += ">"
  if self.hiddenMenuPass == "0" * 4 + ">" * 2:
   global VVLoj5
   VVLoj5 = True
   FFAt0z(self["myTitle"], "#dd5588")
 def VVFcq2(self):
  self.hiddenMenuPass += "<"
  if self.hiddenMenuPass == "0" * 4 + "<" * 2:
   ok = False
   fnt = "ae_AlMateen.ttf"
   fontFile = "/usr/share/fonts/%s" % fnt
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    try:
     addFont(fontFile, fontName, 100, True)
     ok = True
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      ok = True
     except:
      pass
   if ok: txt = 'Added Font: "%s"' % fnt
   else : txt = '"%s" Not Found' % fnt
   FF70nx(self, txt, 2000, isGrn=ok)
 def VVOtDc(self):
  found = False
  pPath = CCc2Xe.VVDAEE()
  if pathExists(pPath):
   for fName, fType in CCc2Xe.VVvfy6(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCc2Xe)
  else:
   VVH93c = []
   VVH93c.append(("PIcons Manager" , "CCc2Xe" ))
   VVH93c.append(VVxSb7)
   VVH93c.append(CCc2Xe.VVWiYg())
   VVH93c.append(VVxSb7)
   VVH93c += CCc2Xe.VVx2U7()
   FFSEnE(self, self.VVfid1, VVH93c=VVH93c)
 def VVfid1(self, item=None):
  if item:
   if   item == "CCc2Xe"   : self.session.open(CCc2Xe)
   elif item == "VVYdVI"  : CCc2Xe.VVYdVI(self)
   elif item == "VVxj3t"  : CCc2Xe.VVxj3t(self)
   elif item == "findPiconBrokenSymLinks" : CCc2Xe.VV7va1(self, True)
   elif item == "FindAllBrokenSymLinks" : CCc2Xe.VV7va1(self, False)
 def VVdayu(self):
  self.session.open(CCPaCW)
 def VVWdYO(self):
  self.session.open(CCIPsF)
 def VVptCO(self):
  changeLogFile = VVHIBy + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FFxHei(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFQRKC("\n%s\n%s\n%s" % (VVkthi, line, VVkthi), VVbvoH, VVbEpi)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FFQRKC(line, VVIbxt, VVbEpi)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFNGa4(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VVIPCs), VVhAiY=26)
 def VVhm6a(self):
  VVH93c = []
  VVH93c.append(("Title Colors"   , "title" ))
  VVH93c.append(("Menu Area Colors"  , "body" ))
  VVH93c.append(("Menu Pointer Colors" , "cursor" ))
  VVH93c.append(("Bottom Bar Colors" , "bar"  ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Reset Colors"   , "reset" ))
  title = "Main Menu Colors"
  FFSEnE(self, boundFunction(self.VVTfTl, title), VVH93c=VVH93c, width=500, title=title)
 def VVTfTl(self, title, item=None):
  if item:
   if item == "reset":
    FF3096(self, self.VVCoND, "Reset to default colors ?", title=title)
   else:
    tDict = self.VV09vW()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VVT9vW, tDict, item), CCnw9u, defFG=fg, defBG=bg)
 def VVHVbl(self):
  return VVBgPY + "ajpanel_colors"
 def VV09vW(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVHVbl()
  if fileExists(p):
   txt = FF1gqL(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVT9vW(self, tDict, item, fg, bg):
  if fg:
   self.VVSTaW(item, fg)
   self.VVkbWw(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVLmlH(tDict)
 def VVLmlH(self, tDict):
   p = self.VVHVbl()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVSTaW(self, item, fg):
  if   item == "title" : FFQGsp(self["myTitle"], fg)
  elif item == "body"  :
   FFQGsp(self["myMenu"], fg)
   FFQGsp(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFAt0z(self["myBar"], fg)
   FFQGsp(self["keyRed"], fg)
   FFQGsp(self["keyGreen"], fg)
   FFQGsp(self["keyYellow"], fg)
   FFQGsp(self["keyBlue"], fg)
 def VVkbWw(self, item, bg):
  if   item == "title" : FFAt0z(self["myTitle"], bg)
  elif item == "body"  :
   FFAt0z(self["myMenu"], bg)
   FFAt0z(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFAt0z(self["myBar"], bg)
 def VVCoND(self):
  os.system(FFmogf("rm %s" % self.VVHVbl()))
  self.close()
 def VVLEhy(self):
  tDict = self.VV09vW()
  self.VVTbOl(tDict, "title")
  self.VVTbOl(tDict, "body")
  self.VVTbOl(tDict, "cursor")
  self.VVTbOl(tDict, "bar")
 def VVTbOl(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVSTaW(name, fg)
  if bg: self.VVkbWw(name, bg)
 def VVdect(self):
  self.session.open(CCqamV)
class CCIPsF(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFvMLn(VVd6Yn, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVH93c = []
  VVH93c.append(("Settings File"        , "SettingsFile"   ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Box Info"          , "VVTcgY"    ))
  VVH93c.append(("Tuners Info"         , "VVrEg9"   ))
  VVH93c.append(("Python Version"        , "VVozJT"   ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Screen Size"         , "ScreenSize"    ))
  VVH93c.append(("Locale"          , "Locale"     ))
  VVH93c.append(("Processor"         , "Processor"    ))
  VVH93c.append(("Operating System"        , "OperatingSystem"   ))
  VVH93c.append(("Drivers"          , "drivers"     ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("System Users"         , "SystemUsers"    ))
  VVH93c.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVH93c.append(("Uptime"          , "Uptime"     ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Host Name"         , "HostName"    ))
  VVH93c.append(("MAC Address"         , "MACAddress"    ))
  VVH93c.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVH93c.append(("Network Status"        , "NetworkStatus"   ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Disk Usage"         , "VVwMfK"    ))
  VVH93c.append(("Mount Points"         , "MountPoints"    ))
  VVH93c.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVH93c.append(("USB Devices"         , "USB_Devices"    ))
  VVH93c.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVH93c.append(("Directory Size"        , "DirectorySize"   ))
  VVH93c.append(("Memory"          , "Memory"     ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVH93c.append(("Running Processes"       , "RunningProcesses"  ))
  VVH93c.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFEVgi(self, VVH93c=VVH93c, title="Device Information")
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  FFj85G(self["myMenu"])
  FFsbO6(self)
 def VVrVKJ(self):
  global VVsMrL
  VVsMrL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCEDl0)
   elif item == "VVTcgY"    : self.VVTcgY()
   elif item == "VVrEg9"   : self.VVrEg9()
   elif item == "VVozJT"   : self.VVozJT()
   elif item == "ScreenSize"    : FFNGa4(self, "Width\t: %s\nHeight\t: %s" % (FFI2oD()[0], FFI2oD()[1]))
   elif item == "Locale"     : self.VVUrEr()
   elif item == "Processor"    : self.VVy6IF()
   elif item == "OperatingSystem"   : FF4bPN(self, "uname -a"        )
   elif item == "drivers"     : self.VVUcIq()
   elif item == "SystemUsers"    : FF4bPN(self, "id"          )
   elif item == "LoggedInUsers"   : FF4bPN(self, "who -a"         )
   elif item == "Uptime"     : FF4bPN(self, "uptime"         )
   elif item == "HostName"     : FF4bPN(self, "hostname"        )
   elif item == "MACAddress"    : self.VVAtqh()
   elif item == "NetworkConfiguration"  : FF4bPN(self, "ifconfig %s %s" % (FFa6r1("HWaddr", VV0P8J), FFa6r1("addr:", VVllxZ)))
   elif item == "NetworkStatus"   : FF4bPN(self, "netstat -tulpn"       )
   elif item == "VVwMfK"    : self.VVwMfK()
   elif item == "MountPoints"    : FF4bPN(self, "mount %s" % (FFa6r1(" on ", VVllxZ)))
   elif item == "FileSystemTable"   : FF4bPN(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FF4bPN(self, "lsusb"         )
   elif item == "listBlockDevices"   : FF4bPN(self, "blkid"         )
   elif item == "DirectorySize"   : FF4bPN(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VV2vCv="Reading size ...")
   elif item == "Memory"     : FF4bPN(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVemqu()
   elif item == "RunningProcesses"   : FF4bPN(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FF4bPN(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVV6nB()
   else         : self.close()
 def VVAtqh(self):
  res = FFgni4("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFNGa4(self, txt)
  else:
   FF4bPN(self, "ip link")
 def VVrI4d(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FF8QLc(cmd)
  return lines
 def VV4GZV(self, lines, headerRepl, widths, VVwcLv):
  VVYnAG = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVYnAG.append(parts)
  if VVYnAG and len(header) == len(widths):
   VVYnAG.sort(key=lambda x: x[0].lower())
   FFeiXT(self, None, header=header, VVOhES=VVYnAG, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=28, VV5c0a=True)
   return True
  else:
   return False
 def VVwMfK(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VVrI4d(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVwcLv = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VV4GZV(lines, headerRepl, widths, VVwcLv)
  if not allOK:
   lines = FF8QLc(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFEMdz(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVoiSL:
     note = "\n%s" % FFQRKC("Green = Mounted Partitions", VVoiSL)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVllxZ
     elif line.endswith(mountList) : color = VVoiSL
     else       : color = VVIbxt
     txt += FFQRKC(line, color) + "\n"
    FFNGa4(self, txt + note)
   else:
    FFy0Rl(self, "Not data from system !")
 def VVemqu(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVrI4d(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVwcLv = (LEFT , CENTER, LEFT )
  allOK = self.VV4GZV(lines, headerRepl, widths, VVwcLv)
  if not allOK:
   FF4bPN(self, cmd)
 def VVUrEr(self):
  from locale import getdefaultlocale
  loc = getdefaultlocale()
  FFNGa4(self, "Language\t: %s\nEncoding\t: %s" % (loc[0], loc[1]))
 def VVUcIq(self):
  cmd = FFfvin(VVhRz7, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FF4bPN(self, cmd)
  else : FFkPbc(self)
 def VVy6IF(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FF4bPN(self, cmd)
 def VVV6nB(self):
  cmd = FFfvin(VVawNP, "| grep secondstage")
  if cmd : FF4bPN(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFkPbc(self)
 def VVTcgY(self):
  c = VVoiSL
  VVOhES = []
  VVOhES.append((FFQRKC("Box Type"  , c), FFQRKC(self.VV3muw("boxtype").upper(), c)))
  VVOhES.append((FFQRKC("Board Version", c), FFQRKC(self.VV3muw("board_revision") , c)))
  VVOhES.append((FFQRKC("Chipset"  , c), FFQRKC(self.VV3muw("chipset")  , c)))
  VVOhES.append((FFQRKC("S/N"   , c), FFQRKC(self.VV3muw("sn")    , c)))
  VVOhES.append((FFQRKC("Version"  , c), FFQRKC(self.VV3muw("version")  , c)))
  VV7kcu   = []
  VViLWV = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VViLWV = SystemInfo[key]
     else:
      VV7kcu.append((FFQRKC(str(key), VVq6Xr), FFQRKC(str(SystemInfo[key]), VVq6Xr)))
  except:
   pass
  if VViLWV:
   VV3J8e = self.VV6FT0(VViLWV)
   if VV3J8e:
    VV3J8e.sort(key=lambda x: x[0].lower())
    VVOhES += VV3J8e
  if VV7kcu:
   VV7kcu.sort(key=lambda x: x[0].lower())
   VVOhES += VV7kcu
  if VVOhES:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFeiXT(self, None, header=header, VVOhES=VVOhES, VVOmXx=widths, VVhAiY=28, VV5c0a=True)
  else:
   FFNGa4(self, "Could not read info!")
 def VV3muw(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFxHei(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VV6FT0(self, mbDict):
  try:
   mbList = list(mbDict)
   VVOhES = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVOhES.append((FFQRKC(subject, VVllxZ), FFQRKC(value, VVllxZ)))
  except:
   pass
  return VVOhES
 def VVrEg9(self):
  txt = self.VVw90g("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVw90g("/proc/bus/nim_sockets")
  if not txt: txt = self.VVjuRj()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFNGa4(self, txt)
 def VVjuRj(self):
  txt = ""
  VVQGQz = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVQGQz("Slot Name" , slot.getSlotName())
     txt += FFQRKC(slotName, VVllxZ)
     txt += VVQGQz("Description"  , slot.getFullDescription())
     txt += VVQGQz("Frontend ID"  , slot.frontend_id)
     txt += VVQGQz("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVw90g(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFxHei(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFQRKC(line, VVllxZ)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVozJT(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFNGa4(self, txt)
class CCEDl0(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFvMLn(VVd6Yn, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVH93c = []
  VVH93c.append(("Settings (All)"   , "Settings_All"   ))
  VVH93c.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  if VVLoj5:
   VVH93c.append(("Settings (FHDG-17)" , "Settings_FHDG_17"  ))
  VVH93c.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVH93c.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVH93c.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVH93c.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVH93c.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFEVgi(self, VVH93c=VVH93c)
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  FFj85G(self["myMenu"])
  FFsbO6(self)
 def VVrVKJ(self):
  global VVsMrL
  VVsMrL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FF4bPN(self, cmd                )
   elif item == "Settings_HotKeys"   : FF4bPN(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FF4bPN(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FF4bPN(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FF4bPN(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FF4bPN(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FF4bPN(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FF4bPN(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CChsN8(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFvMLn(VVd6Yn, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VV3vuS, VVKnfn, VVDiot, camCommand = FFjEc6()
  self.VVKnfn = VVKnfn
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVH93c = []
  VVH93c.append(("OSCam Files"        , "OSCamFiles"  ))
  VVH93c.append(("NCam Files"        , "NCamFiles"  ))
  VVH93c.append(("CCcam Files"        , "CCcamFiles"  ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVH93c.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVH93c.append(VVxSb7)
  if VVKnfn:
   if   "oscam" in VVKnfn : camName = "OSCam"
   elif "ncam"  in VVKnfn : camName = "NCam"
   VVH93c.append((camName + " Info."      , "camInfo"   ))
   VVH93c.append((camName + " Live Status"    , "camLiveStatus" ))
   VVH93c.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVH93c.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVH93c.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFEVgi(self, VVH93c=VVH93c)
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  FFj85G(self["myMenu"])
  FFsbO6(self)
 def VVrVKJ(self):
  global VVsMrL
  VVsMrL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCWr0f, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCWr0f, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCWr0f, "cccam"))
   elif item == "OSCamReaders"  : self.VVAME5("os")
   elif item == "NSCamReaders"  : self.VVAME5("n")
   elif item == "camInfo"   : FFZzCQ(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFR1m4(self.session, CCNGTK.VVdPZ8)
   elif item == "camLiveReaders" : FFR1m4(self.session, CCNGTK.VVsACF)
   elif item == "camLiveLog"  : FFR1m4(self.session, CCNGTK.VVw77g)
   else       : self.close()
 def VVAME5(self, camPrefix):
  VVYnAG = self.VVT6dJ(camPrefix)
  if VVYnAG:
   VVYnAG.sort(key=lambda x: int(x[0]))
   if self.VVKnfn and self.VVKnfn.startswith(camPrefix):
    VVvRGr = ("Toggle State", self.VVouVE, [camPrefix], "Changing State ...")
   else:
    VVvRGr = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVwcLv  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFeiXT(self, None, header=header, VVOhES=VVYnAG, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=26, VVvRGr=VVvRGr, VVAanx=True)
 def VVT6dJ(self, camPrefix):
  readersFile = self.VV3vuS + camPrefix + "cam.server"
  VVYnAG = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFxHei(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVYnAG.append((str(len(VVYnAG) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVYnAG:
    FFy0Rl(self, "No readers found !")
  else:
   FFZZL8(self, readersFile)
  return VVYnAG
 def VVouVE(self, VVrPW4, camPrefix):
  confFile  = "%s%scam.conf" % (self.VV3vuS, camPrefix)
  readerState  = VVrPW4.VVvKjl(1)
  readerLabel  = VVrPW4.VVvKjl(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CChsN8.VVe3Xo(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVrPW4.VVztP3()
    FFy0Rl(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVYnAG = self.VVT6dJ(camPrefix)
   if VVYnAG:
    VVrPW4.VVH1wF(VVYnAG)
 @staticmethod
 def VVe3Xo(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFxHei(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFy0Rl(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFy0Rl(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFZZL8(SELF, confFile)
   return None
  if not iRequest:
   FFy0Rl(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FFy0Rl(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FFy0Rl(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCWr0f(Screen):
 def __init__(self, VVUkT4, session, args=0):
  self.skin, self.skinParam = FFvMLn(VVd6Yn, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VV3vuS, VVKnfn, VVDiot, camCommand = FFjEc6()
  if   VVUkT4 == "ncam" : self.prefix = "n"
  elif VVUkT4 == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVH93c = []
  if self.prefix == "":
   VVH93c.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVH93c.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVH93c.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVH93c.append(("constant.cw"         , "x_constant_cw" ))
   VVH93c.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVH93c.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVH93c.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVH93c.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVH93c.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVH93c.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVH93c.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVH93c.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVH93c.append(VVxSb7)
   VVH93c.append(("SoftCam.Key"         , "x_SoftCam_Key" ))
   VVH93c.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVH93c.append(VVxSb7)
   VVH93c.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVH93c.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVH93c.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFEVgi(self, VVH93c=VVH93c)
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  FFj85G(self["myMenu"])
  FFsbO6(self)
 def VVrVKJ(self):
  global VVsMrL
  VVsMrL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFdAGY(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFdAGY(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFdAGY(self, self.VV3vuS + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFdAGY(self, self.VV3vuS + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VV1j6p("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VV1j6p("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VV1j6p("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VV1j6p("cam.provid"        )
   elif item == "x_cam_server"  : self.VV1j6p("cam.server"        )
   elif item == "x_cam_services" : self.VV1j6p("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VV1j6p("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VV1j6p("cam.user"        )
   elif item == "x_VVkthi"   : pass
   elif item == "x_SoftCam_Key" : FFdAGY(self, self.VV3vuS + "SoftCam.Key"   )
   elif item == "x_CCcam_cfg"  : FFdAGY(self, self.VV3vuS + "CCcam.cfg"    )
   elif item == "x_VVkthi"   : pass
   elif item == "x_cam_log"  : FFdAGY(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFdAGY(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFdAGY(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VV1j6p(self, fileName):
  FFdAGY(self, self.VV3vuS + self.prefix + fileName)
class CCNGTK(Screen):
 VVdPZ8  = 0
 VVsACF = 1
 VVw77g = 2
 def __init__(self, session, VV3vuS="", VVKnfn="", VVDiot="", VVMZlH=VVdPZ8):
  self.skin, self.skinParam = FFvMLn(VVAxwO, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVDiot   = VVDiot
  self.VVMZlH  = VVMZlH
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VV3vuS + VVKnfn + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVKnfn : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VV3vuS, self.camPrefix)
  if self.VVMZlH == self.VVdPZ8:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVMZlH == self.VVsACF:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFEVgi(self, self.Title, addScrollLabel=True)
  FFUxNa(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVyJ5v
  self.onShown.append(self.VVYVvL)
  self.onClose.append(self.onExit)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  self["myLabel"].VVaX06(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFcxMz(self)
  self.VVyJ5v()
 def onExit(self):
  self.timer.stop()
 def VVnokV(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVXtV7)
  except:
   self.timer.callback.append(self.VVXtV7)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FF70nx(self, "Started", 1000)
 def VVdKtK(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVXtV7)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FF70nx(self, "Stopped", 1000)
 def VVyJ5v(self):
  if self.timerRunning:
   self.VVdKtK()
  else:
   self.VVnokV()
   if self.VVMZlH == self.VVdPZ8 or self.VVMZlH == self.VVsACF:
    if self.VVMZlH == self.VVdPZ8 : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CChsN8.VVe3Xo(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFpblr(self.VVY6ob)
    else:
     self.close()
   else:
    self.VVWsxo()
 def VVXtV7(self):
  if self.timerRunning:
   if   self.VVMZlH == self.VVdPZ8 : self.VVT5xN()
   elif self.VVMZlH == self.VVsACF : self.VVT5xN()
   else            : self.VVWsxo()
 def VVWsxo(self):
  if fileExists(self.VVDiot):
   fTime = FFI3l2(os.path.getmtime(self.VVDiot))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VV2WSl(), VVTcLD=VVpBFp)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVDiot)
 def VVY6ob(self):
  self.VVT5xN()
 def VVT5xN(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFQRKC("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVbvoH))
   self.camWebIfErrorFound = True
   self.VVdKtK()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVMZlH == self.VVdPZ8 : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFQRKC("Error while parsing data elements !\n\nError = %s" % str(e), VVo2ZM)
   self.camWebIfErrorFound = True
   self.VVdKtK()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VV8CNu(root)
  self["myLabel"].setText(txt, VVTcLD=VVpBFp)
  self["myBar"].setText("Last Update : %s" % FFgdpv())
 def VV8CNu(self, rootElement):
  def VVQGQz(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVMZlH == self.VVdPZ8:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFQRKC(status, VVoiSL)
    else          : status = FFQRKC(status, VVo2ZM)
    txt += VVkthi + "\n"
    txt += VVQGQz("Name"  , name)
    txt += VVQGQz("Description" , desc)
    txt += VVQGQz("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVQGQz("Protocol" , protocol)
    txt += VVQGQz("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFQRKC("Yes", VVoiSL)
    else    : enabTxt = FFQRKC("No", VVo2ZM)
    txt += VVkthi + "\n"
    txt += VVQGQz("Label"  , label)
    txt += VVQGQz("Protocol" , protocol)
    txt += VVQGQz("Enabled" , enabTxt)
  return txt
 def VV2WSl(self):
  wordsDict = self.VVoWku()
  color = [ VVllxZ, VV0P8J, VVoiSL, VVo2ZM, VVq6Xr, VVMjkH]
  lines = FF8QLc("tail -n %d %s" % (100, self.VVDiot))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVbvoH + line[:19] + VVIbxt + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVbEpi + line[ndx + 3:] + VVIbxt
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVllxZ + line[ndx + 8 : ndx1 + 4] + VVIbxt + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVIbxt)
   elif line.startswith("----") or ">>" in line:
    line = FFQRKC(line, VVllxZ)
   txt += line + "\n"
  return txt
 def VVoWku(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFxHei(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCoLRv(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFvMLn(VVd6Yn, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVH93c = []
  VVH93c.append(("Backup Channels"    , "VVgjFD"   ))
  VVH93c.append(("Restore Channels"    , "Restore_Channels"  ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Backup SoftCAM Files"   , "VVtDGv" ))
  VVH93c.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVH93c.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVH93c.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Backup Network Settings"  , "VV8Y7f"   ))
  VVH93c.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVLoj5:
   VVH93c.append(VVxSb7)
   VVH93c.append((VVbvoH + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VVqz3P"   ))
   VVH93c.append((VVoiSL + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVSo0J) , "createMyIpk"   ))
   VVH93c.append((VVoiSL + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVSo0J) , "createMyDeb"   ))
   VVH93c.append((VVq6Xr + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVH93c.append((VVq6Xr + "Decode %s Crash Report"   % PLUGIN_NAME     , "VVtpAs" ))
  FFEVgi(self, VVH93c=VVH93c)
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  FFj85G(self["myMenu"])
  FFsbO6(self)
 def VVrVKJ(self):
  global VVsMrL
  VVsMrL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVgjFD"    : self.VVgjFD()
   elif item == "Restore_Channels"    : self.VVPi9d("channels_backup*.tar.gz", self.VVdqWt)
   elif item == "VVtDGv"   : self.VVtDGv()
   elif item == "Restore_SoftCAM_Files"  : self.VVPi9d("softcam_backup*.tar.gz", self.VVM3Nw)
   elif item == "Backup_TunerDiSEqC"   : self.VVvasd("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVPi9d("tuner_backup*.backup", boundFunction(self.VVTvN7, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVvasd("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVPi9d("hotkey_*backup*.backup", boundFunction(self.VVTvN7, "misc"))
   elif item == "VV8Y7f"    : self.VV8Y7f()
   elif item == "Restore_Network"    : self.VVPi9d("network_backup*.tar.gz", self.VV4sV1)
   elif item == "VVqz3P"     : FF3096(self, boundFunction(FFTYCg, self, boundFunction(CCoLRv.VVqz3P, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVTC5T(False)
   elif item == "createMyDeb"     : self.VVTC5T(True)
   elif item == "createMyTar"     : self.VVDyk5()
   elif item == "VVtpAs"   : self.VVtpAs()
 @staticmethod
 def VVqz3P(SELF):
  OBF_Path = VVEdhy + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVEdhy, VVIPCs, VVSo0J)
   if err : FFy0Rl(SELF, err)
   else : FFNGa4(SELF, txt)
  else:
   FFZZL8(SELF, OBF_Path)
 def VVTC5T(self, VVa20Y):
  OBF_Path = VVEdhy + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFy0Rl(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVEdhy)
  os.system("mv -f %s %s" % (VVEdhy + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVEdhy + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVEdhy + "plugin.py"))
  self.session.openWithCallback(self.VVTC5T1, boundFunction(CCXdvo, path=VVEdhy, VVa20Y=VVa20Y))
 def VVTC5T1(self):
  os.system("mv -f %s %s" % (VVEdhy + "OBF/main.py"  , VVEdhy))
  os.system("mv -f %s %s" % (VVEdhy + "OBF/plugin.py" , VVEdhy))
 def VVtpAs(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFy0Rl(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFy0Rl(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVuFGU("%s*.list" % path)
  if err:
   FFZZL8(self, path + "*.list")
   return
  srcF, err = self.VVuFGU("%s*main_final.py" % path)
  if err:
   FFZZL8(self, path + "*.final.py")
   return
  VVOhES = []
  for f in files:
   f = os.path.basename(f)
   VVOhES.append((f, f))
  FFSEnE(self, boundFunction(self.VVkafV, path, codF, srcF), VVH93c=VVOhES)
 def VVkafV(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFZZL8(self, logF)
   else     : FFTYCg(self, boundFunction(self.VVbGCI, logF, codF, srcF))
 def VVbGCI(self, logF, codF, srcF):
  lst  = []
  lines = FFxHei(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFy0Rl(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVPp6I(lst, logF, newLogF)
  totSrc  = self.VVPp6I(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFNGa4(self, txt)
 def VVuFGU(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVPp6I(self, lst, f1, f2):
  txt = FF1gqL(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVDyk5(self):
  VVOhES = []
  VVOhES.append("%s%s" % (VVEdhy, "*.py"))
  VVOhES.append("%s%s" % (VVEdhy, "*.png"))
  VVOhES.append("%s%s" % (VVEdhy, "*.xml"))
  VVOhES.append("%s"  % (VVHIBy))
  FF8xS3(self, VVOhES, "%s_%s" % (PLUGIN_NAME, VVIPCs), addTimeStamp=False)
 def VVgjFD(self):
  path1 = VVyYRZ
  path2 = "/etc/tuxbox/"
  VVOhES = []
  VVOhES.append("%s%s" % (path1, "*.tv"))
  VVOhES.append("%s%s" % (path1, "*.radio"))
  VVOhES.append("%s%s" % (path1, "*list"))
  VVOhES.append("%s%s" % (path1, "lamedb*"))
  VVOhES.append("%s%s" % (path2, "*.xml"))
  FF8xS3(self, VVOhES, "channels_backup", addTimeStamp=True)
 def VVtDGv(self):
  VVOhES = []
  VVOhES.append("/etc/tuxbox/config/")
  VVOhES.append("/usr/keys/")
  VVOhES.append("/usr/scam/")
  VVOhES.append("/etc/CCcam.cfg")
  FF8xS3(self, VVOhES, "softcam_backup", addTimeStamp=True)
 def VV8Y7f(self):
  VVOhES = []
  VVOhES.append("/etc/hostname")
  VVOhES.append("/etc/default_gw")
  VVOhES.append("/etc/resolv.conf")
  VVOhES.append("/etc/wpa_supplicant*.conf")
  VVOhES.append("/etc/network/interfaces")
  VVOhES.append("/etc/enigma2/nameserversdns.conf")
  FF8xS3(self, VVOhES, "network_backup", addTimeStamp=True)
 def VVdqWt(self, fileName):
  if fileName:
   FF3096(self, boundFunction(self.VV1922, fileName), "Overwrite current channels ?")
 def VV1922(self, fileName):
  path = "%s%s" % (VVBgPY, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCoJ8d.VVxE7t()
   lamedb5File, diabled5File = CCoJ8d.VVo7ek()
   cmd = ""
   cmd += FFmogf("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFmogf("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFMFw4()
   if res == 0 : FFM9af(self, "Channels Restored.")
   else  : FFy0Rl(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFZZL8(self, path)
 def VVM3Nw(self, fileName):
  if fileName:
   FF3096(self, boundFunction(self.VVQuoJ, fileName), "Overwrite SoftCAM files ?")
 def VVQuoJ(self, fileName):
  fileName = "%s%s" % (VVBgPY, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVkthi
   note = "You may need to restart your SoftCAM."
   FF68Dg(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFa6r1(note, VVllxZ), sep))
  else:
   FFZZL8(self, fileName)
 def VV4sV1(self, fileName):
  if fileName:
   FF3096(self, boundFunction(self.VVhu5v, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVhu5v(self, fileName):
  fileName = "%s%s" % (VVBgPY, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFtPYL(self,  cmd)
  else:
   FFZZL8(self, fileName)
 def VVPi9d(self, pattern, callBackFunction, isTuner=False):
  title = FFjCXZ()
  if pathExists(VVBgPY):
   myFiles = iGlob("%s%s" % (VVBgPY, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVOhES = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVOhES.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVDeB1 = ("Sat. List", self.VVvrFp)
    else  : VVDeB1 = None
    VVSptY = ("Delete File", boundFunction(self.VV8AsY, boundFunction(self.VVPi9d, pattern, callBackFunction, isTuner)))
    FFSEnE(self, callBackFunction, title=title, VVH93c=VVOhES, VVDeB1=VVDeB1, VVSptY=VVSptY)
   else:
    FFy0Rl(self, "No files found in:\n\n%s" % VVBgPY, title)
  else:
   FFy0Rl(self, "Path not found:\n\n%s" % VVBgPY, title)
 def VV8AsY(self, cbFnc, VVzEsrObj, path):
  FF3096(self, boundFunction(self.VVRdLc, cbFnc, VVzEsrObj, path), "Delete this file ?\n\n%s" % path)
 def VVRdLc(self, cbFnc, VVzEsrObj, path):
  os.system(FFmogf("rm -f '%s%s'" % (VVBgPY, path)))
  cbFnc()
  VVzEsrObj.cancel()
 def VVvasd(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CC9sFI()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VVLmVI, filePrefix))
 def VVLmVI(self, filePrefix, result, retval):
  title = FFjCXZ()
  if pathExists(VVBgPY):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFy0Rl(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVBgPY, filePrefix, FFVgvw())
    try:
     VVOhES = str(result.strip()).split()
     if VVOhES:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVOhES:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVkthi, FFQRKC(fName, VVllxZ), VVkthi)
       FFNGa4(self, txt, title=title, VVTcLD=VVpBFp)
      else:
       FFy0Rl(self, "File creation failed!", title)
     else:
      FFy0Rl(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFmogf("rm %s" % fName))
     FFy0Rl(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFmogf("rm %s" % fName))
     FFy0Rl(self, "Error while writing file.")
  else:
   FFy0Rl(self, "Path not found:\n\n%s" % VVBgPY, title)
 def VVTvN7(self, mode, path):
  if path:
   path = "%s%s" % (VVBgPY, path)
   if fileExists(path):
    lines = FFxHei(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FF3096(self, boundFunction(self.VVj0rT, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFk2jj(self, path, title=FFjCXZ())
   else:
    FFZZL8(self, path)
 def VVj0rT(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVYCFx = []
  VVYCFx.append("echo -e 'Reading current settings ...'")
  VVYCFx.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVYCFx.append("echo -e 'Preparing new settings ...'")
  VVYCFx.append(settingsLines)
  VVYCFx.append("echo -e 'Applying new settings ...'")
  VVYCFx.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFpter(self, VVYCFx)
 def VVvrFp(self, VVzEsrObj, path):
  if not path:
   return
  path = VVBgPY + path
  if not fileExists(path):
   FFZZL8(self, path)
   return
  txt = FF1gqL(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVOhES  = []
   for item in satList:
    VVOhES.append("%s\t%s" % (item[0], FFB3KB(item[1])))
   FFNGa4(self, VVOhES, title="  Satellites List")
  else:
   FFy0Rl(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCBva9(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFvMLn(VVd6Yn, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVH93c = []
  VVH93c.append(("Plugins Browser List"       , "VVK10V"   ))
  VVH93c.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVH93c.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVH93c.append(("Remove Packages (show all)"     , "VV2qjnsAll"   ))
  VVH93c.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Update List of Available Packages"   , "VVXg75"   ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Packaging Tool"        , "VVZZ8z"    ))
  VVH93c.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFEVgi(self, VVH93c=VVH93c)
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  FFj85G(self["myMenu"])
  FFsbO6(self)
 def VVrVKJ(self):
  global VVsMrL
  VVsMrL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVK10V"   : self.VVK10V()
   elif item == "pluginsMenus"     : self.VVcwr5(0)
   elif item == "pluginsStartup"    : self.VVcwr5(1)
   elif item == "pluginsDirList"    : self.VVWn4e()
   elif item == "downloadInstallPackages"  : FFTYCg(self, boundFunction(self.VVmZmO, 0, ""))
   elif item == "VV2qjnsAll"   : FFTYCg(self, boundFunction(self.VVmZmO, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFTYCg(self, boundFunction(self.VVmZmO, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVXg75"   : self.VVXg75()
   elif item == "VVZZ8z"    : self.VVZZ8z()
   elif item == "packagesFeeds"    : self.VVSlP3()
   else          : self.close()
 def VVWn4e(self):
  extDirs  = FFCtHZ(VVTqTJ)
  sysDirs  = FFCtHZ(VV38TZ)
  VVOhES  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVOhES.append((item, VVTqTJ + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVOhES.append((item, VV38TZ + item))
  if VVOhES:
   VVOhES = sorted(VVOhES, key=lambda x: x[0].lower())
   VV5m6F = ("Package Info.", self.VVqlE4, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFeiXT(self, None, header=header, VVOhES=VVOhES, VVOmXx=widths, VVhAiY=28, VV5m6F=VV5m6F)
  else:
   FFy0Rl(self, "Nothing found!")
 def VVqlE4(self, VVrPW4, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVTqTJ) : loc = "extensions"
  elif path.startswith(VV38TZ) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVMQul(package)
  else:
   FFy0Rl(self, "No info!")
 def VVSlP3(self):
  pkg = FFWFvN()
  if pkg : FF4bPN(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFkPbc(self)
 def VVK10V(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVQGQz(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVkthi + "\n"
    txt += VVQGQz("Number"   , str(c))
    txt += VVQGQz("Name"   , FFQRKC(str(p.name), VVllxZ))
    txt += VVQGQz("Path"  , p.path  )
    txt += VVQGQz("Description" , p.description )
    txt += VVQGQz("Icon"  , p.iconstr  )
    txt += VVQGQz("Wakeup Fnc" , p.wakeupfnc )
    txt += VVQGQz("NeedsRestart", p.needsRestart)
    txt += VVQGQz("Internal" , p.internal )
    txt += VVQGQz("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFNGa4(self, txt)
 def VVcwr5(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVOhES = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVOhES.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVOhES:
   VVOhES.sort(key=lambda x: x[0].lower())
   header  = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths  = (19  , 25 , 20  , 27   , 9  )
   FFeiXT(self, None, title=title, header=header, VVOhES=VVOhES, VVOmXx=widths, VVhAiY=26)
  else:
   FFy0Rl(self, "Nothing Found", title=title)
 def VVXg75(self):
  cmd = FFfvin(VVmkLF, "")
  if cmd : FFtPYL(self, cmd, checkNetAccess=True)
  else : FFkPbc(self)
 def VVZZ8z(self):
  pkg = FFWFvN()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFM9af(self, txt)
 def VVmZmO(self, mode, grep, VVrPW4=None, title=""):
  if   mode == 0: cmd = FFfvin(VVawNP    , grep)
  elif mode == 1: cmd = FFfvin(VVhRz7 , grep)
  elif mode == 2: cmd = FFfvin(VVhRz7 , grep)
  if not cmd:
   FFkPbc(self)
   return
  VVYnAG = FF8QLc(cmd)
  if not VVYnAG:
   if VVrPW4: VVrPW4.VVztP3()
   FFy0Rl(self, "No packages found!")
   return
  elif len(VVYnAG) == 1 and VVYnAG[0] == VVzlaf:
   FFy0Rl(self, VVzlaf)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVOhES  = []
  for item in VVYnAG:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVOhES.append((name, package, version))
  if mode > 0:
   extensions = FF8QLc("ls %s -l | grep '^d' | awk '{print $9}'" % VVTqTJ)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVOhES:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVOhES.append((name, VVTqTJ + item, "-"))
   systemPlugins = FF8QLc("ls %s -l | grep '^d' | awk '{print $9}'" % VV38TZ)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVOhES:
      if item.lower() == row[0].lower():
       break
     else:
      VVOhES.append((item, VV38TZ + item, "-"))
  if not VVOhES:
   FFy0Rl(self, "No packages found!")
   return
  if VVrPW4:
   VVOhES.sort(key=lambda x: x[0].lower())
   VVrPW4.VVH1wF(VVOhES, title)
  else:
   widths = (20, 50, 30)
   VVvRGr = None
   VVx5V8 = None
   if mode == 0:
    VVv9Eb = ("Install" , self.VVIwvI   , [])
    VVvRGr = ("Download" , self.VVPYJD   , [])
    VVx5V8 = ("Filter"  , self.VV2Awb , [])
   elif mode == 1:
    VVv9Eb = ("Uninstall", self.VV2qjn, [])
   elif mode == 2:
    VVv9Eb = ("Uninstall", self.VV2qjn, [])
    widths= (18, 57, 25)
   VVOhES = sorted(VVOhES, key=lambda x: x[0].lower())
   VV5m6F = ("Package Info.", self.VVUKNS, [])
   header   = ("Name" ,"Package" , "Version" )
   FFeiXT(self, None, header=header, VVOhES=VVOhES, VVOmXx=widths, VVhAiY=28, VVv9Eb=VVv9Eb, VVvRGr=VVvRGr, VV5m6F=VV5m6F, VVx5V8=VVx5V8, VVdn6v=self.lastSelectedRow
     , VVOFb6="#22110011", VVYfYq="#22191111", VVMBDz="#22191111", VVuLsk="#00003030", VVCiIJ="#00333333")
 def VVUKNS(self, VVrPW4, title, txt, colList):
  package = colList[1]
  self.VVMQul(package)
 def VV2Awb(self, VVrPW4, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVH93c = []
  VVH93c.append(("All Packages", "all"))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVH93c.append(VVxSb7)
  for word in words:
   VVH93c.append((word, word))
  FFSEnE(self, boundFunction(self.VVVGnF, VVrPW4), VVH93c=VVH93c, title="Select Filter")
 def VVVGnF(self, VVrPW4, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFTYCg(VVrPW4, boundFunction(self.VVmZmO, 0, grep, VVrPW4, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VV2qjn(self, VVrPW4, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVTqTJ, VV38TZ)):
   FF3096(self, boundFunction(self.VV3FoJ, VVrPW4, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVH93c = []
   VVH93c.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVH93c.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVH93c.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFSEnE(self, boundFunction(self.VVrI33, VVrPW4, package), VVH93c=VVH93c)
 def VV3FoJ(self, VVrPW4, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VV0PME)
  FFtPYL(self, cmd, VVD4UQ=boundFunction(self.VV7Wkf, VVrPW4))
 def VVrI33(self, VVrPW4, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVuYpF
   elif item == "remove_ForceRemove"  : cmdOpt = VVJmSo
   elif item == "remove_IgnoreDepends"  : cmdOpt = VV4AUp
   FF3096(self, boundFunction(self.VVIUvK, VVrPW4, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVIUvK(self, VVrPW4, package, cmdOpt):
  self.lastSelectedRow = VVrPW4.VV61YO()
  cmd = FFrD2J(cmdOpt, package)
  if cmd : FFtPYL(self, cmd, VVD4UQ=boundFunction(self.VV7Wkf, VVrPW4))
  else : FFkPbc(self)
 def VV7Wkf(self, VVrPW4):
  VVrPW4.cancel()
  FFi4Qv()
 def VVIwvI(self, VVrPW4, title, txt, colList):
  package  = colList[1]
  VVH93c = []
  VVH93c.append(("Install Package"         , "install_CheckVersion" ))
  VVH93c.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVH93c.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVH93c.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFSEnE(self, boundFunction(self.VVCeqZ, package), VVH93c=VVH93c)
 def VVCeqZ(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVzZPa
   elif item == "install_ForceReinstall" : cmdOpt = VVGnsR
   elif item == "install_ForceDowngrade" : cmdOpt = VVs217
   elif item == "install_IgnoreDepends" : cmdOpt = VV1pls
   FF3096(self, boundFunction(self.VVcHBd, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVcHBd(self, package, cmdOpt):
  cmd = FFrD2J(cmdOpt, package)
  if cmd : FFtPYL(self, cmd, VVD4UQ=FFi4Qv, checkNetAccess=True)
  else : FFkPbc(self)
 def VVPYJD(self, VVrPW4, title, txt, colList):
  package  = colList[1]
  FF3096(self, boundFunction(self.VVhALn, package), "Download Package ?\n\n%s" % package)
 def VVhALn(self, package):
  if FFbBOf():
   cmd = FFrD2J(VVyGLm, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFa6r1(success, VVoiSL))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFa6r1(fail, VVo2ZM))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFtPYL(self, cmd, VV5I5h=[VVo2ZM, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFkPbc(self)
  else:
   FFy0Rl(self, "No internet connection !")
 def VVMQul(self, package):
  infoCmd  = FFrD2J(VVxXfv, package)
  filesCmd = FFrD2J(VV2shS, package)
  listInstCmd = FFfvin(VVhRz7, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFfq9Z(VVllxZ)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFa6r1(notInst, VVbvoH))
   cmd += "else "
   cmd +=   FF0v1F("System Info", VVllxZ)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FF0v1F("Related Files", VVllxZ)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFYoKS(self, cmd)
  else:
   FFkPbc(self)
class CCoJ8d(Screen):
 VVxfre  = 0
 VV9Ced = 1
 VV2cp5  = 2
 VVCbgH  = 3
 VVzoNp = 4
 VVYINn = 5
 VVy85K = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFvMLn(VVd6Yn, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVbwJM = None
  self.lastfilterUsed  = None
  VVH93c = self.VVFCMo()
  FFEVgi(self, VVH93c=VVH93c, title="Services/Channels")
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self["myMenu"].setList(self.VVFCMo())
  FFj85G(self["myMenu"])
  FFsbO6(self)
 def VVFCMo(self):
  VVH93c = []
  VVH93c.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VVH93c.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Services (Reference)"      , "lameDB_allChannels_with_refCode"  ))
  VVH93c.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVH93c.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVH93c.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVH93c.append(("Services with PIcons for the System"  , "VVKrho"     ))
  VVH93c.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVH93c.append(VVxSb7)
  lamedbFile, disabledFile = CCoJ8d.VVxE7t()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVH93c.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVH93c.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVH93c.append(("Reset Parental Control Settings"   , "VVj1SN"    ))
  VVH93c.append(("Delete Channels with no names"   , "VV8k6i"    ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Reload Channels and Bouquets"    , "VVyAqd"      ))
  return VVH93c
 def VVrVKJ(self):
  global VVsMrL
  VVsMrL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFTC4m(self)
   elif item == "currentServiceInfo"     : FFtcRZ(self, fncMode=CCditA.VVP8oV)
   elif item == "TranspondersStats"     : FFTYCg(self, self.VVcBzj     )
   elif item == "lameDB_allChannels_with_refCode"  : FFTYCg(self, self.VV3xSD )
   elif item == "lameDB_allChannels_with_tranaponder" : FFTYCg(self, self.VV1tMl)
   elif item == "lameDB_allChannels_with_details"  : FFTYCg(self, self.VVbP4N )
   elif item == "parentalControlChannels"    : FFTYCg(self, self.VVfiiB   )
   elif item == "showHiddenChannels"     : FFTYCg(self, self.VVxG3L     )
   elif item == "VVKrho"     : FFTYCg(self, self.VVWquL     )
   elif item == "servicesWithMissingPIcons"   : FFTYCg(self, self.VVj9GJ   )
   elif item == "enableHiddenChannels"     : self.VV0PTC(True)
   elif item == "disableHiddenChannels"    : self.VV0PTC(False)
   elif item == "VVj1SN"    : FF3096(self, self.VVj1SN, "Reset and Restart ?" )
   elif item == "VV8k6i"    : FFTYCg(self, self.VV8k6i)
   elif item == "VVyAqd"      : FFTYCg(self, boundFunction(CCoJ8d.VVyAqd, self))
   else            : self.close()
 @staticmethod
 def VVyAqd(SELF):
  FFMFw4()
  FFM9af(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VV3xSD(self):
  self.VVbwJM = None
  self.lastfilterUsed  = None
  self.filterObj   = CCxiMQ(self)
  VVYnAG = CCoJ8d.VVEJIr(self, self.VVxfre)
  if VVYnAG:
   VVYnAG.sort(key=lambda x: x[0].lower())
   VVJAKf  = ("Zap"   , self.VVjKVB     , [])
   VVnOFk = (""    , self.VVFloZ   , [])
   VV5m6F = ("Options"  , self.VVHQvV , [])
   VVvRGr = ("Current Service", self.VVtHvH , [])
   VVx5V8 = ("Filter"   , self.VVGHBB  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVwcLv  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFeiXT(self, None, header=header, VVOhES=VVYnAG, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=26, VVJAKf=VVJAKf, VVnOFk=VVnOFk, VVvRGr=VVvRGr, VV5m6F=VV5m6F, VVx5V8=VVx5V8)
 def VV1tMl(self):
  self.VVbwJM = None
  self.lastfilterUsed  = None
  self.filterObj   = CCxiMQ(self)
  VVYnAG = CCoJ8d.VVEJIr(self, self.VV9Ced)
  if VVYnAG:
   VVYnAG.sort(key=lambda x: x[0].lower())
   VVJAKf  = ("Zap"   , self.VVjKVB      , [])
   VVnOFk = (""    , self.VVFloZ    , [])
   VVvRGr = ("Current Service", self.VVtHvH  , [])
   VV5m6F = ("Options"  , self.VVOeK8 , [])
   VVx5V8 = ("Filter"   , self.VV17Bw  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVwcLv  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFeiXT(self, None, header=header, VVOhES=VVYnAG, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=26, VVJAKf=VVJAKf, VVnOFk=VVnOFk, VVvRGr=VVvRGr, VV5m6F=VV5m6F, VVx5V8=VVx5V8)
 def VVHQvV(self, VVrPW4, title, txt, colList):
  servName = colList[0]
  refCode  = colList[3]
  pcState  = colList[4]
  hidState = colList[5]
  mSel  = CCgMGZ(self, VVrPW4, 3)
  mSel.VVyR3I(servName, refCode, pcState, hidState)
 def VVOeK8(self, VVrPW4, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CCgMGZ(self, VVrPW4, 3)
  mSel.VVQRMb(servName, refCode)
 def VVlJlv(self, VVrPW4, refCode, isAddToBlackList):
  self.VVbwJM = None
  self.lastfilterUsed  = None
  VVrPW4.VVSUEO("Changing state ...")
  path = "/etc/enigma2/blacklist"
  if not fileExists(path):
   os.system("echo '' > %s" % path)
  if fileExists(path):
   if not refCode.endswith(":"):
    refCode += ":"
   if isAddToBlackList :
    os.system("sed -i '/%s/d' %s" % (refCode, path))
    os.system("echo '%s' >> %s" % (refCode, path))
   else:
    os.system("sed -i '/%s/d' %s" % (refCode, path))
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   if refCode.endswith(":"):
    refCode = refCode[:-1]
   FFTYCg(self, boundFunction(self.VV0oDN, VVrPW4, refCode))
  else:
   FFZZL8(self, path)
 def VVQVjy(self, VVrPW4, refCode, isHide):
  self.VVbwJM = None
  self.lastfilterUsed  = None
  VVrPW4.VVSUEO("Changing state ...")
  if FFkJo0(refCode):
   ret = FFNElJ(refCode, isHide)
   if ret : FFTYCg(self, boundFunction(self.VV0oDN, VVrPW4, refCode))
   else : FFy0Rl(self, "Cannot Hide/Unhide this channel.")
  else:
   FFy0Rl(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)")
 def VV0oDN(self, VVrPW4, refCode):
  VVYnAG = CCoJ8d.VVEJIr(self, self.VVxfre, VVxKgK=[3, [refCode], False])
  done = False
  if VVYnAG:
   data = VVYnAG[0]
   if data[3] == refCode:
    done = VVrPW4.VVKR3H(data)
  if not done:
   self.VVuUOx(VVrPW4, VVrPW4.VVWfT2(), self.VVxfre)
  VVrPW4.VVztP3()
 def VVGHBB(self, VVrPW4, title, txt, colList):
  self.filterObj.VVvyHH(1, VVrPW4, 2, boundFunction(self.VV16ig, VVrPW4))
 def VV16ig(self, VVrPW4, item):
  self.VVrZWh(VVrPW4, item, 2, self.VVxfre)
 def VV17Bw(self, VVrPW4, title, txt, colList):
  self.filterObj.VVvyHH(2, VVrPW4, 4, boundFunction(self.VVqkQ1, VVrPW4))
 def VVqkQ1(self, VVrPW4, item):
  self.VVrZWh(VVrPW4, item, 4, self.VV9Ced)
 def VVBxrB(self, VVrPW4, title, txt, colList):
  self.filterObj.VVvyHH(0, VVrPW4, 4, boundFunction(self.VV6Hez, VVrPW4))
 def VV6Hez(self, VVrPW4, item):
  self.VVrZWh(VVrPW4, item, 4, self.VV2cp5)
 def VVrZWh(self, VVrPW4, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVrPW4.VVvKjl(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVbwJM = None
  else:
   words, asPrefix = CCxiMQ.VVCW7j(words)
   self.VVbwJM = [col, words, asPrefix]
  if words: FFTYCg(self, boundFunction(self.VVuUOx, VVrPW4, title, mode), title="Reading Services ...")
  else : FF70nx(VVrPW4, "Incorrect filter", 2000)
 def VVuUOx(self, VVrPW4, title, mode):
  VVYnAG = CCoJ8d.VVEJIr(self, mode, VVxKgK=self.VVbwJM, VVU9Vj=False)
  if VVYnAG:
   VVYnAG.sort(key=lambda x: x[0].lower())
   VVrPW4.VVH1wF(VVYnAG, title)
  else:
   VVrPW4.VVztP3()
   FF70nx(VVrPW4, "Not found!", 1500)
 def VVkxYb(self, VVOhES, VVJAKf=None, VVnOFk=None, VVv9Eb=None, VVvRGr=None, VV5m6F=None, VVx5V8=None):
  VVvRGr = ("Current Service", self.VVtHvH, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVwcLv = (LEFT  , LEFT  , CENTER, LEFT    )
  FFeiXT(self, None, header=header, VVOhES=VVOhES, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=26, VVJAKf=VVJAKf, VVnOFk=VVnOFk, VVv9Eb=VVv9Eb, VVvRGr=VVvRGr, VV5m6F=VV5m6F, VVx5V8=VVx5V8)
 def VVtHvH(self, VVrPW4, title, txt, colList):
  self.VVPjsV(VVrPW4)
 def VVPhk5(self, VVrPW4, title, txt, colList):
  self.VVPjsV(VVrPW4, True)
 def VVPjsV(self, VVrPW4, isFromDetails=False):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(self)
  if refCode:
   if isFromDetails:
    chName  = info.getName()
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVrPW4.VV5KJx(colDict, VVkUjI=True)
   else:
    VVrPW4.VVG4Jh(3, refCode, True)
   return
  FFy0Rl(self, "Colud not read current Reference Code !")
 def VVbP4N(self):
  self.VVbwJM = None
  self.lastfilterUsed  = None
  self.filterObj   = CCxiMQ(self)
  VVYnAG = CCoJ8d.VVEJIr(self, self.VV2cp5)
  if VVYnAG:
   VVYnAG.sort(key=lambda x: x[0].lower())
   VVnOFk = (""    , self.VVnM7L , []      )
   VVvRGr = ("Current Service", self.VVPhk5  , []      )
   VVx5V8 = ("Filter"   , self.VVBxrB   , [], "Loading Filters ..." )
   VVJAKf  = ("Zap"   , self.VVE8iX      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVwcLv  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFeiXT(self, None, header=header, VVOhES=VVYnAG, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=26, VVJAKf=VVJAKf, VVnOFk=VVnOFk, VVvRGr=VVvRGr, VVx5V8=VVx5V8)
 def VVnM7L(self, VVrPW4, title, txt, colList):
  refCode  = self.VV4Urx(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFtcRZ(self, fncMode=CCditA.VV1OPq, refCode=refCode, chName=chName, text=txt)
 def VVE8iX(self, VVrPW4, title, txt, colList):
  refCode = self.VV4Urx(colList)
  FFqfoC(self, refCode)
 def VVjKVB(self, VVrPW4, title, txt, colList):
  FFqfoC(self, colList[3])
 def VV4Urx(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVEJIr(SELF, mode, VVxKgK=None, VVU9Vj=True, VVDPmC=True):
  lamedbFile, disabledFile = CCoJ8d.VVxE7t()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVxKgK:
    filterCol = VVxKgK[0]
    filterWords = VVxKgK[1]
    asPrefix = VVxKgK[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCoJ8d.VVxfre:
    blackList = None
    path = "/etc/enigma2/blacklist"
    if fileExists(path):
     blackList = FFxHei(path)
     if blackList:
      blackList = set(blackList)
   elif mode == CCoJ8d.VV9Ced:
    tp = CCD09M()
   VV926r, VVvNfE = FFdJvq()
   tagFound  = False
   if mode in (CCoJ8d.VVYINn, CCoJ8d.VVy85K):
    VVYnAG = {}
   else:
    VVYnAG = []
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFp4Mi(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CCoJ8d.VV2cp5:
        if sTypeInt in VV926r:
         STYPE = VVvNfE[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVYnAG.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVYnAG.append(tRow)
        else:
         VVYnAG.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCoJ8d.VVYINn:
         VVYnAG[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCoJ8d.VVy85K:
         VVYnAG[chName] = refCode
        elif mode == CCoJ8d.VVxfre:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVYnAG.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVYnAG.append(tRow)
         else:
          VVYnAG.append(tRow)
        elif mode == CCoJ8d.VV9Ced:
         if sTypeInt in VV926r:
          STYPE = VVvNfE[sTypeInt]
         freq, pol, fec, sr, syst = tp.VVRCxv(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVYnAG.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVYnAG.append(tRow)
         else:
          VVYnAG.append(tRow)
        elif mode == CCoJ8d.VVCbgH:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VVYnAG.append((chName, chProv, sat, refCode))
        elif mode == CCoJ8d.VVzoNp:
         VVYnAG.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VVYnAG and VVU9Vj:
    FFy0Rl(SELF, "No services found!")
   return VVYnAG
  else:
   if VVDPmC:
    FFZZL8(SELF, lamedbFile)
   return None
 def VVfiiB(self):
  path = "/etc/enigma2/blacklist"
  if fileExists(path):
   lines = FFxHei(path)
   if lines:
    newRows  = []
    VVYnAG = CCoJ8d.VVEJIr(self, self.VVzoNp)
    if VVYnAG:
     lines = set(lines)
     for item in VVYnAG:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVYnAG = newRows
      VVYnAG.sort(key=lambda x: x[0].lower())
      VVnOFk = ("", self.VVFloZ, [])
      VVJAKf = ("Zap", self.VVjKVB, [])
      self.VVkxYb(VVOhES=VVYnAG, VVJAKf=VVJAKf, VVnOFk=VVnOFk)
     else:
      FFNGa4(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVYnAG)))
   else:
    FFM9af(self, "No active Parental Control services.", FFjCXZ())
  else:
   FFZZL8(self, path)
 def VVxG3L(self):
  VVYnAG = CCoJ8d.VVEJIr(self, self.VVCbgH)
  if VVYnAG:
   VVYnAG.sort(key=lambda x: x[0].lower())
   VVnOFk = ("" , self.VVFloZ, [])
   VVJAKf  = ("Zap", self.VVjKVB, [])
   self.VVkxYb(VVOhES=VVYnAG, VVJAKf=VVJAKf, VVnOFk=VVnOFk)
  else:
   FFM9af(self, "No hidden services.", FFjCXZ())
 def VVcBzj(self):
  totT, totC, totA, totS, totS2, satList = self.VV1zGB()
  txt = FFQRKC("Total Transponders:\n\n", VVq6Xr)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFQRKC("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVq6Xr)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFSSz7(item), satList.count(item))
  FFNGa4(self, txt)
 def VV1zGB(self):
  lamedbFile, disabledFile = CCoJ8d.VVxE7t()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFZZL8(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VVWquL(self)   : self.VVKrho(True)
 def VVj9GJ(self) : self.VVKrho(False)
 def VVKrho(self, isWithPIcons):
  piconsPath = CCc2Xe.VVDAEE()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCc2Xe.VVvfy6(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVYnAG = CCoJ8d.VVEJIr(self, self.VVzoNp)
    if VVYnAG:
     channels = []
     for (chName, chProv, sat, refCode) in VVYnAG:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FF3Lm8(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVYnAG)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVQGQz(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVQGQz("PIcons Path"  , piconsPath)
     txt += VVQGQz("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVQGQz("Total services" , totalServices)
     txt += VVQGQz("With PIcons"  , totalWithPIcons)
     txt += VVQGQz("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFNGa4(self, txt)
     else:
      VVnOFk     = (""      , self.VVFloZ , [])
      if isWithPIcons : VVx5V8 = ("Export Current PIcon", self.VVCHAC  , [])
      else   : VVx5V8 = None
      VV5m6F     = ("Statistics", FFNGa4, [txt])
      VVJAKf      = ("Zap", self.VVjKVB, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVkxYb(VVOhES=channels, VVJAKf=VVJAKf, VVnOFk=VVnOFk, VV5m6F=VV5m6F, VVx5V8=VVx5V8)
   else:
    FFy0Rl(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFy0Rl(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVFloZ(self, VVrPW4, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFtcRZ(self, fncMode=CCditA.VV1OPq, refCode=refCode, chName=chName, text=txt)
 def VVCHAC(self, VVrPW4, title, txt, colList):
  png, path = CCc2Xe.VV4353(colList[3], colList[0])
  if path:
   CCc2Xe.VVJyjp(self, png, path)
 @staticmethod
 def VVxE7t():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVo7ek():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VV0PTC(self, isEnable):
  lamedbFile, disabledFile = CCoJ8d.VVxE7t()
  if isEnable and not fileExists(disabledFile):
   FFM9af(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FFy0Rl(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FF3096(self, boundFunction(self.VV65yB, isEnable), "%s Hidden Channels ?" % word)
 def VV65yB(self, isEnable):
  lamedbFile , disabledFile = CCoJ8d.VVxE7t()
  lamedb5File, diabled5File = CCoJ8d.VVo7ek()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FFMFw4()
  if res == 0 : FFM9af(self, "Hidden List %s" % word)
  else  : FFy0Rl(self, "Error while restoring:\n\n%s" % fileName)
 def VVj1SN(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFpter(self, cmd)
 def VV8k6i(self):
  lamedbFile, disabledFile = CCoJ8d.VVxE7t()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFmogf("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFxHei(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFmogf("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FFMFw4()
   FFNGa4(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFZZL8(self, lamedbFile)
class CCditA(Screen):
 VVP8oV  = 0
 VVbEj0   = 1
 VVgdNI   = 2
 VV1OPq    = 3
 VVU6Z9    = 4
 VVGsdV   = 5
 VVSPbK   = 6
 VVq5t7    = 7
 VV8dzp   = 8
 VVjDWD   = 9
 VVHvd8   = 10
 VV5Ume   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFvMLn(VVAxwO, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVP8oV)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFQRKC("%s\n", VVtSyw) % VVkthi
  FFEVgi(self, title="Channel Info", addScrollLabel=True)
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  self["myLabel"].VVaX06(textOutFile="chann_info")
  if   self.fncMode == self.VVP8oV : fnc = self.VVDBi9_VVP8oV
  elif self.fncMode == self.VVbEj0  : fnc = self.VVDBi9_VVP8oV
  elif self.fncMode == self.VVgdNI  : fnc = self.VVDBi9_VVP8oV
  elif self.fncMode == self.VV1OPq  : fnc = self.VVDBi9_VV1OPq
  elif self.fncMode == self.VVU6Z9  : fnc = self.VVDBi9_VVU6Z9
  elif self.fncMode == self.VVGsdV  : fnc = self.VVDBi9_VVGsdV
  elif self.fncMode == self.VVSPbK  : fnc = self.VVDBi9_VVSPbK
  elif self.fncMode == self.VVq5t7  : fnc = self.VVDBi9_VVq5t7
  elif self.fncMode == self.VV8dzp  : fnc = self.VVDBi9_VV8dzp
  elif self.fncMode == self.VVjDWD : fnc = self.VVDBi9_VVjDWD
  elif self.fncMode == self.VVHvd8  : fnc = self.VVDBi9_VVHvd8
  elif self.fncMode == self.VV5Ume : fnc = self.VVDBi9_VV5Ume
  self["myLabel"].setText("\n   Reading Info ...")
  FFpblr(fnc)
 def VV5sZu(self, err):
  self["myLabel"].setText(err)
  FFAt0z(self["myTitle"], "#22200000")
  FFAt0z(self["myBody"], "#22200000")
  self["myLabel"].FFAt0zColor("#22200000")
  self["myLabel"].VV55as()
 def VVDBi9_VVP8oV(self):
  try:
   dum = self.session
  except:
   return
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(self)
  self.refCode = refCode
  self.VVslkO(chName)
 def VVDBi9_VV1OPq(self):
  self.VVslkO(self.chName)
 def VVDBi9_VVU6Z9(self):
  self.VVslkO(self.chName)
 def VVDBi9_VVGsdV(self):
  self.VVslkO(self.chName)
 def VVDBi9_VVSPbK(self):
  self.VVslkO("Picon Info")
 def VVDBi9_VVq5t7(self):
  self.VVslkO(self.chName)
 def VVDBi9_VV8dzp(self):
  self.VVslkO(self.chName)
 def VVDBi9_VVjDWD(self):
  self.VVslkO(self.chName)
 def VVDBi9_VVHvd8(self):
  self.chUrl = self.refCode + self.callingSELF.VV6MCN(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVslkO(self.chName)
 def VVDBi9_VV5Ume(self):
  self.VVslkO(self.chName)
 def VVslkO(self, title):
  self.VVXoXd(title)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(self)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVZ2cV(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFQRKC(self.VVph1O(tUrl), VVIbxt)
  if not self.epg:
   epg = self.VVKST0(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVJIQn(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCc2Xe.VV4353(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVJIQn(path)
  self.VVq1LO()
  self.VV9jBx()
  self["myLabel"].setText(self.text, VVTcLD=VV9wvN)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VV55as(minHeight=minH)
 def VV9jBx(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FF9NA0(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVkhVb(FFwDWV(url))
  if epg:
   self.text += "\n" + FFwzVc("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVq1LO()
 def VVq1LO(self):
  if not self.piconShown and self.picUrl:
   path, err = FF9cSe(self.picUrl, "ajpanel_tmp.png", timeout=2)
   if path:
    self.piconShown = self.VVJIQn(path)
    if self.piconShown and self.refCode:
     self.VVsY1V(path, self.refCode)
 def VVsY1V(self, path, refCode):
  if path and fileExists(path) and os.system(FFmogf("which ffmpeg")) == 0:
   pPath = CCc2Xe.VVDAEE()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
    cmd += FFmogf("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVJIQn(self, path):
  if path and fileExists(path):
   err, w, h = self.VV6f6w(path)
   if not err:
    if h > w:
     self.VVPSrb(self["myPicF"], w, h, True)
     self.VVPSrb(self["myPic"] , w, h, False)
   allOK = FFrbJa(self["myPic"], path)
   if allOK:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVPSrb(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VV6f6w(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFCdzs(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVXoXd(self, chName):
  if chName:
   self["myTitle"].setText("  " + chName + "  ")
 def VVZ2cV(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFQRKC(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVQGQz(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFQRKC(state, VVbvoH)
   txt += "State\t: %s\n" % state
  w = FFYzNX(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFYzNX(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVPlHO(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVQGQz(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVQGQz(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVQGQz(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVOfZ9()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVq8rn()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  isIptv = len(iptvRef) > 0
  if iptvRef:
   txt += "Service Type\t: %s\n" % FFQRKC("IPTV", VVq6Xr)
   txt += self.VVT10J(iptvRef)
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not refCode:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    path = serv.getPath()
    if path:
     txt += "Path\t: %s\n" % path
  txt += "\n"
  txt += self.VVTZfN(refCode, iptvRef, chName)
  if not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCD09M()
    tpTxt, namespace = tp.VVwoQB(refCode)
    del tp
    if tpTxt:
     txt += FFQRKC("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFQRKC("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVQGQz(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVQGQz(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVQGQz(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVQGQz(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVQGQz(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVQGQz(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVQGQz(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVQGQz(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVQGQz(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVPlHO(info):
  if info:
   aspect = FFYzNX(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVQGQz(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFYzNX(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVfcQg(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVfcQg(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVOfZ9(self):
  try:
   service = self.session.nav.getCurrentService()
   audio = service and service.audioTracks()
   return audio and audio.getNumberOfTracks() or 0
  except:
   pass
  return -1
 def VVq8rn(self):
  try:
   service   = self.session.nav.getCurrentService()
   subtitle  = service and service.subtitle()
   subtitlelist = subtitle and subtitle.getSubtitleList()
   return len(subtitlelist)
  except:
   pass
  return -1
 def VVTZfN(self, refCode, iptvRef, chName):
  refCode = FF3zgs(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FF1gqL(VVyYRZ + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FF1gqL(VVyYRZ + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VVOhES = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVyYRZ + item
   if fileExists(path):
    txt = FF1gqL(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVOhES.append(bName)
  txt = self.Sep
  if VVOhES:
   if len(VVOhES) == 1:
    txt += "%s\t: %s\n" % (FFQRKC("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VVOhES[0])
   else:
    txt += FFQRKC("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VVOhES):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVKST0(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVGrue(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVGrue(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVGrue(event, 0)
     except:
      pass
  return epg
 def VVGrue(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName().strip()    or ""
   evTime = event.getBeginTime()      or ""
   evDur = event.getDuration()      or ""
   evShort = event.getShortDescription() .strip() or ""
   evDesc = event.getExtendedDescription().strip() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = self.VVKCiP(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FFQRKC(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FFQRKC(evNameTransl, COLOR_CONS_BRIGHT_YELLOW))
    if evTime           : txt += "Start Time\t: %s\n" % FFI3l2(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFI3l2(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFEQDX(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFEQDX(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFEQDX(evTime - now)
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFQRKC(evShort, VVvFue)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFQRKC(evDesc , VVvFue)
    if txt:
     txt = FFQRKC("\n%s\n%s Event:\n%s\n" % (VVkthi, ("Current", "Next")[evNum], VVkthi), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVT10J(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFxIgr(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCiL8N()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVryCy(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFQRKC("URL:", VVq6Xr) + "\n%s\n" % self.VVph1O(decodedUrl)
  else:
   txt = "\n"
   txt += FFQRKC("Reference:", VVq6Xr) + "\n%s\n" % refCode
  return txt
 def VVph1O(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVLoj5:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VVkhVb(self, decodedUrl):
  if not FFbBOf():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCxu1n.VVoNlW(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (not a subscription ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCxu1n.VVwnBY(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVApMz(tDict)
   elif uType == "movie" : epg, picUrl = self.VVx8hV(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVApMz(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCxu1n.VViqrz(item, "title"    , is_base64=True )
     lang    = CCxu1n.VViqrz(item, "lang"         ).upper()
     description   = CCxu1n.VViqrz(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCxu1n.VViqrz(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCxu1n.VViqrz(item, "start_timestamp"      )
     stop_timestamp  = CCxu1n.VViqrz(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCxu1n.VViqrz(item, "stop_timestamp"       )
     now_playing   = CCxu1n.VViqrz(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVbEpi, ""
      else     : color, txt = VVbvoH , "    (CURRENT EVENT)"
      epg += FFQRKC("_" * 32 + "\n", VVtSyw)
      epg += FFQRKC("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFQRKC(description, VVIbxt)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVsZqV(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VVx8hV(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCxu1n.VViqrz(item, "movie_image" )
    genre  = CCxu1n.VViqrz(item, "genre"   ) or "-"
    plot  = CCxu1n.VViqrz(item, "plot"   ) or "-"
    cast  = CCxu1n.VViqrz(item, "cast"   ) or "-"
    rating  = CCxu1n.VViqrz(item, "rating"   ) or "-"
    director = CCxu1n.VViqrz(item, "director"  ) or "-"
    releasedate = CCxu1n.VViqrz(item, "releasedate" ) or "-"
    duration = CCxu1n.VViqrz(item, "duration"  ) or "-"
    try:
     lang = CCxu1n.VViqrz(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFQRKC(cast, VVIbxt)
    epg += "Plot:\n%s"    % FFQRKC(self.VVKCiP(plot), VVIbxt)
   except:
    pass
  return epg, movie_image
 def VVKCiP(self, evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = self.VVtN9e(evTxt, lang)
   return CCditA.VVn5m3(txt).strip() or evTxt
 @staticmethod
 def VVn5m3(txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VVtN9e(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFOEqY(txt))
   txt, err = CCxu1n.VVwnBY(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFwDWV(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVsZqV(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
 @staticmethod
 def VVAJtV(SELF):
  fSize = "Not received from server"
  if CCQctb.VVvc3e(SELF):
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(SELF)
   err = url =  fSize = resumable = ""
   if any(x in decodedUrl for x in ("/movie/", "/series/")):
    url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
    url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
    if url.endswith(":" + chName):
     url = url[:-(len(chName) + 1)]
    span = iSearch(r"(http:\/\/.+\/(?:movie|series).+\/.+\/.+)", url, IGNORECASE)
    if span:
     url = span.group(1)
     if "chCode" in decodedUrl:
      url = CCiL8N.VV5pNt(decodedUrl)
     try:
      import requests
      resp = requests.get(url, headers=CCiL8N.VVvqEYHeader(), timeout=3, stream=True, verify=False)
      if not resp.ok:
       return ["Err-%d : %s" % (resp.status_code, resp.reason)]
      hSize = resp.headers.get("Content-Length", "")
      if hSize and hSize.isdigit(): fSize = CCw1Kh.VV78Il(int(hSize))
      else      : fSize = "No info. from server. Try again later."
      hResume = resp.headers.get("Accept-Ranges" , "")
      if hResume:
       if not hResume == "none": resumable = "Yes"
       else     : resumable = "No"
     except requests.Timeout as e     : err = "Connection Timeout"
     except Exception as e       : err = "Connection Error"
   else:
    err = "Not a Movie/Series !"
   def VVvSHN(subj, val):
    return "%s\n%s\n\n" % (FFQRKC("%s:" % subj, COLOR_CONS_BRIGHT_YELLOW), val)
   title = "File Size"
   txt  = VVvSHN(title , fSize)
   txt += VVvSHN("Name" , chName)
   txt += VVvSHN("URL" , url)
   if resumable: txt += VVvSHN("Supports Download-Resume", resumable)
   if err  : txt += FFQRKC("Error:\n", VVbvoH) + err
   FFNGa4(SELF, txt, title="File Size")
class CCiL8N():
 def __init__(self):
  self.VVBE6t  = ""
  self.VV5c3V   = ""
  self.VVsT8y  = ""
  self.colored_user  = "#f#11ffffaa#User"
  self.colored_server  = "#f#11aaffff#Server"
 def VV5XpA(self, url, mac, VVkUjI=True):
  self.VVBE6t = ""
  self.VV5c3V  = ""
  self.VVsT8y = ""
  host = self.VVvLof(url)
  if not host:
   if VVkUjI:
    self.VVkUjIor("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVnn2W(mac)
  if not host:
   if VVkUjI:
    self.VVkUjIor("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVBE6t = host
  self.VV5c3V  = mac
  self.VVsT8y = ""
  return True
 def VVgIgm(self):
  res, err = self.VV0OpW(self.VVBE6t, useCookies=False)
  if err:
   self.VVkUjIor(err, "Connect to Portal")
   return False
  if (res.status_code == 301):
   title = "Redirection"
   newUrl = res.headers['location']
   res, err = self.VV0OpW(newUrl, res.cookies)
   if err:
    self.VVkUjIor(err, "URL Redirection")
    return False
   else:
    host = self.VVvLof(newUrl)
    if not host:
     self.VVkUjIor("Incorrect Redirection-URL Format !\n\n%s" % newUrl)
     return False
    self.VVBE6t = host
  token, profile = self.VV3qfN()
  if not token:
   return False
  return True
 def VVvLof(self, url):
  ndx = url.lower().find("mac=")
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  if url.lower().endswith("/stalker_portal"): url = url[:-15]
  return url
 def VVnn2W(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VV3qfN(self, VVkUjI=True):
  try:
   token = self.VVfQJu()
   if token:
    self.VVsT8y = token
   else:
    if VVkUjI:
     self.VVkUjIor("Could not get Token from server !")
    return "", ""
   return token, self.VVKXOx()
  except:
   return "", ""
 def VVfQJu(self):
  token  = ""
  res, err = self.VV0OpW(self.VV8aVh())
  if not err:
   try:
    tDict = jLoads(res.text)
    token = CCxu1n.VViqrz(tDict["js"], "token")
   except:
    pass
  return token.strip()
 def VVKXOx(self):
  res, err = self.VV0OpW(self.VVJnc5())
  if not err:
   try:
    profJson = jLoads(res.text)
    return profJson
   except:
    pass
  return ""
 def VV6QQJ(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVE1Uh()
  if len(rows) < 10:
   rows = self.VVqWFz()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVBE6t ))
   rows.append(("MAC (from URL)" , self.VV5c3V ))
   rows.append(("Token"   , self.VVsT8y ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VV5c3V ))
   rows.append(("2", self.colored_server, "Host" , self.VVBE6t ))
   rows.append(("2", self.colored_server, "Token" , self.VVsT8y ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVc03X(self, isPhp=True):
  token, profile = self.VV3qfN()
  if not token:
   return ""
  m3u_Url = ""
  url = self.VVK1OJ()
  res, err = self.VV0OpW(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCxu1n.VViqrz(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFOEqY(span.group(2))
     pass1 = FFOEqY(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url
 def VVE1Uh(self):
  m3u_Url = self.VVc03X()
  rows = []
  if m3u_Url:
   res, err = self.VV0OpW(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFI3l2(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFI3l2(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVqWFz(self):
  token, profile = self.VV3qfN()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFg1k2(val): val = FFHtVc(val.decode("UTF-8"))
     else     : val = self.VV5c3V
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFI3l2(int(parts[1]))
      if parts[2] : ends = FFI3l2(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFI3l2(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VV6MCN(self, mode, chCm, epNum, epId):
  crLinkUrl = self.VViAAl(mode, chCm, epNum, epId)
  token, profile = self.VV3qfN(VVkUjI=False)
  if not token:
   return ""
  res, err = self.VV0OpW(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCxu1n.VViqrz(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  return chUrl
 def VVhdDs(self):
  return self.VVBE6t + "/server/load.php?"
 def VV8aVh(self):
  return self.VVhdDs() + "type=stb&action=handshake&token=&mac=%s" % self.VV5c3V
 def VVJnc5(self):
  return self.VVhdDs() + "type=stb&action=get_profile"
 def VVYpec(self, mode):
  url = self.VVhdDs() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVowJz(self, catID):
  return self.VVhdDs() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVlmGa(self, mode, catID, page):
  url = self.VVhdDs() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "series" : url += "category=%s" % catID
  else    : url += "genre=%s&force_ch_link_check=" % catID
  return url
 def VV3haR(self, mode, searchName, page):
  return self.VVhdDs() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VV73cu(self, mode, catID):
  return self.VVhdDs() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VViAAl(self, mode, chCm, serCode, serId):
  url = self.VVhdDs() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVK1OJ(self):
  return self.VVhdDs() + "type=itv&action=create_link"
 def VV3Msv(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVxJ3z(catID, stID, chNum)
  query = self.VVRDO9(mode, FFxHES(host), FFxHES(mac), serCode, serId, chCm)
  chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVRDO9(self, mode, host, mac, serCode, serId, chCm):
  query = "mode=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVryCy(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVRDO9(mode, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFHtVc(host)
  mac   = FFHtVc(mac)
  valid = False
  if self.VVvLof(playHost) and self.VVvLof(host) and self.VVvLof(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, playHost, mode, host, mac, epNum, epId, chCm, query
 def VV0OpW(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCiL8N.VVvqEYHeader()
   if self.VVsT8y:
    headers["Authorization"] = "Bearer %s" % self.VVsT8y
   if useCookies : cookies = {"mac": self.VV5c3V, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=False, timeout=2, cookies=cookies)
   res.raise_for_status()
   return res, ""
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.exceptions.HTTPError as e  : err = "HTTP Error"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err + "\n\n" + url
 @staticmethod
 def VVvqEYHeader():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVUyYQ(host, mac, tType, action, keysList=[]):
  myPortal = CCiL8N()
  ok = myPortal.VV5XpA(host, mac)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile = myPortal.VV3qfN()
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s/server/load.php?type=%s&action=%s" % (host, tType, action)
  res, err = myPortal.VV0OpW(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVPwdQ(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVPwdQ(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVkUjIor(self, err, title="Portal Browser"):
  FFy0Rl(self, str(err), title=title)
 def VV0RME(self, mode):
  if   mode in ("itv"  , CCxu1n.VVLP44 , CCxu1n.VVuRg1)  : return "Live"
  elif mode in ("vod"  , CCxu1n.VVcTWm , CCxu1n.VVmYjG)  : return "VOD"
  elif mode in ("series" , CCxu1n.VVixUj , CCxu1n.VVdXHA) : return "Series"
  else                          : return "IPTV"
 def VVCNUz(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VV0RME(mode), searchName)
 def VVUPKI(self, catchup=False):
  VVH93c = []
  VVH93c.append(("Live"    , "live"  ))
  VVH93c.append(("VOD"    , "vod"   ))
  VVH93c.append(("Series"   , "series"  ))
  if catchup:
   VVH93c.append(VVxSb7)
   VVH93c.append(("Catchup TV" , "catchup"  ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Account Info." , "accountInfo" ))
  return VVH93c
 @staticmethod
 def VVt1C3(decodedUrl):
  m3u_Url = ""
  p = CCiL8N()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVryCy(decodedUrl)
  if valid:
   ok = p.VV5XpA(host, mac, VVkUjI=False)
   if ok:
    m3u_Url = p.VVc03X(isPhp=False)
    span = iSearch(r".+ch\/(.+)_", decodedUrl, IGNORECASE)
    if span:
     m3u_Url += span.group(1)
  return m3u_Url
 @staticmethod
 def VV5pNt(decodedUrl):
  p = CCiL8N()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVryCy(decodedUrl)
  if valid:
   ok = p.VV5XpA(host, mac, VVkUjI=False)
   if ok:
    try:
     chUrl = p.VV6MCN(mode, chCm, epNum, epId)
     return FFwDWV(chUrl)
    except Exception as e:
     pass
  return ""
class CCqMtN(CCiL8N):
 def __init__(self):
  CCiL8N.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVuf5p(self, refCode, chName, decodedUrl, iptvRef):
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVryCy(decodedUrl)
  if valid:
   if self.VV5XpA(host, mac, VVkUjI=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VV7P1a(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VV6MCN(self.mode, self.chCm, self.epNum, self.epId)
  except:
   pass
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = self.refCode + chUrl.strip() + ":" + self.chName
  newIptvRef = ""
  ndx = chUrl.find("play_token=")
  if ndx > -1:
   ndx = chUrl.find(":", ndx)
   if ndx > -1:
    left  = chUrl[:ndx]
    right  = chUrl[ndx:]
    newIptvRef = left + "&" + self.query + right
  if newIptvRef:
   success = self.VVRLxA(self.iptvRef, newIptvRef)
   if passedSELF:
    FFqfoC(passedSELF, newIptvRef, VVIPM3=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFqfoC(self, newIptvRef, VVIPM3=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VVRLxA(self, oldCode, newCode):
  bPath = FFFxFr()
  if bPath:
   txt = FF1gqL(bPath)
   if oldCode in txt:
    txt = txt.replace(oldCode, newCode)
    with open(bPath, "w") as f:
     f.write(txt)
    FFMFw4()
    return True
  return False
class CCD2tz(CCqMtN):
 def __init__(self, passedSession):
  CCqMtN.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.starttime  = iTime()
  self.timer1   = eTimer()
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVGaB3, iPlayableService.evEOF: self.VVa4g6, iPlayableService.evEnd: self.VVk5zX})
  except:
   pass
 def VVGaB3(self):
  self.starttime = iTime()
 def VVa4g6(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.starttime) > 2:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(self.passedSession, isFromSession=True)
    if iptvRef and not any(x in decodedUrl for x in ("/movie/", "/series/")):
     CCEVRA(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
 def VVk5zX(self):
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VV3L7N)
  except:
   self.timer1.callback.append(self.VV3L7N)
  self.timer1.start(100, True)
 def VV3L7N(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(self.passedSession, isFromSession=True)
  valid = False
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if not ref == self.lastRef:
     valid = self.VVuf5p(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if not CCqamV.VV0ERI:
       self.VV7P1a(self.passedSession, isFromSession=True)
class CCydi9():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.adultWords  = ("adult", "sex", "porn", "xxx", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.nameTagPatt = r"(?:\s*[(|:]\s*)?[A-Z]{2}\s*.?\s*[)|:]\s*(?:.+[|:]\s*)*(.+)"
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
 def VVPaiT(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCxu1n.VV8Bxt(name):
   return CCxu1n.VV25h8(name)
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name, IGNORECASE)
   if span:
    name = span.group(1)
  return name.strip() or name
 def VVTrFW(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  span = iSearch(self.nameTagPatt, name, IGNORECASE)
  if span:
   name = span.group(1)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VV2hXR(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  else:
   return name.strip()
 def VV3Ckg(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVwmN5(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCQctb(CCiL8N):
 def __init__(self):
  CCiL8N.__init__(self)
 def VVd7SC(self):
  if CCQctb.VVvc3e(self):
   FFTYCg(self, self.VViIEg, title="Searching ...")
 def VVaXny(self, winSession, url, mac):
  if CCQctb.VVvc3e(self):
   if self.VV5XpA(url, mac):
    FFTYCg(winSession, self.VVePYl, title="Checking Server ...")
   else:
    FFy0Rl(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VViIEg(self):
  path = CCxu1n.VVTICz()
  lines = FF8QLc('find %s %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % (path, FFJQpq(1)))
  if lines:
   lines.sort()
   VVH93c = []
   for line in lines:
    VVH93c.append((line, line))
   OKBtnFnc = self.VVYl64
   VVSptY = ("Delete File", boundFunction(self.VVFQYq, boundFunction(FFTYCg, self, self.VViIEg, title="Searching ...")))
   FFSEnE(self, None, title="Select Portals File", VVH93c=VVH93c, width=1200, OKBtnFnc=OKBtnFnc, VVSptY=VVSptY)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFy0Rl(self, 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt)
 def VVFQYq(self, cbFnc, VVzEsrObj, path):
  FF3096(self, boundFunction(self.VVhhNb, cbFnc, VVzEsrObj, path), "Delete this file ?\n\n%s" % path)
 def VVhhNb(self, cbFnc, VVzEsrObj, path):
  os.system(FFmogf("rm -f '%s'" % path))
  VVzEsrObj.cancel()
  cbFnc()
 def VVYl64(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = FFViFM(path, self)
   if enc == -1:
    return
   self.session.open(CCYzQV, barTheme=CCYzQV.VVaMkV
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VVdLQd, path, enc)
       , VVzQlc = boundFunction(self.VVcYGX, menuInstance, path))
 def VVdLQd(self, path, enc, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  progBarObj.VVvDFG(totLines)
  progBarObj.VVvkm4 = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVtXQw(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip() or "-"
     host = self.VVvLof(url)
     mac  = self.VVnn2W(mac)
     if host and mac and progBarObj:
      progBarObj.VVvkm4.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip() or "-"
      host = self.VVvLof(url)
      mac  = self.VVnn2W(mac)
      if host and mac and not mac.startswith("AC") and progBarObj:
       progBarObj.VVvkm4.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVcYGX(self, menuInstance, path, VVTmBA, VVvkm4, threadCounter, threadTotal, threadErr):
  title = "Portals List File"
  if VVvkm4:
   VVv9Eb  = ("Home Menu", FFysPJ, [])
   VVx5V8  = None #("Check & Filter" , boundFunction(self.filterPortalAuthorizedServers, path), [])
   VV5m6F = ("Edit File" , boundFunction(self.VVhZuk, path) , [])
   VVvRGr = ("Open as M3U", self.VVTlf8     , [])
   VVJAKf  = ("Select"  , self.VVaXny_fromMacFiles   , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVwcLv  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVrPW4 = FFeiXT(self, None, title=title, header=header, VVOhES=VVvkm4, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=26, VVJAKf=VVJAKf, VVv9Eb=VVv9Eb, VVvRGr=VVvRGr, VV5m6F=VV5m6F, VVx5V8=VVx5V8, VVOFb6="#0a001122", VVYfYq="#0a001122", VVMBDz="#0a001122", VVuLsk="#00004455", VVCiIJ="#0a333333", VViPgN="#11331100", VVAanx=True, searchCol=1)
   if not VVTmBA:
    FF70nx(VVrPW4, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVTmBA:
    FFy0Rl(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVTlf8(self, VVrPW4, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  FFTYCg(VVrPW4, boundFunction(self.VVo1hg, VVrPW4, host, mac), title="Checking Server ...")
 def VVo1hg(self, VVrPW4, host, mac):
  p = CCiL8N()
  m3u_Url = ""
  ok = p.VV5XpA(host, mac, VVkUjI=False)
  if ok:
   m3u_Url = p.VVc03X()
  title = "Browsing M3U Server from Portal Data"
  if m3u_Url:
   self.VVVWTX(title, m3u_Url)
  else:
   FFy0Rl(self, "No response from Server !", title=title)
 def VVaXny_fromMacFiles(self, VVrPW4, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVaXny(VVrPW4, url, mac)
 def VVhZuk(self, path, VVrPW4, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CC6xEh(self, path, VVzQlc=boundFunction(self.VVXepT, VVrPW4), curRowNum=rowNum)
  else    : FFZZL8(self, path)
 def VV2VSW(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFHtVc(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVePYl(self):
  if self.VVgIgm():
   VVH93c  = self.VVUPKI()
   OKBtnFnc = self.VVrWoB
   VVURxH = ("Home Menu", FFysPJ)
   FFSEnE(self, None, title="Portal Resources (MAC=%s)" % self.VV5c3V, VVH93c=VVH93c, OKBtnFnc=OKBtnFnc, VVURxH=VVURxH)
 def VVrWoB(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFTYCg(menuInstance, boundFunction(self.VVJQt4, mode), title="Reading Categories ...")
   else : FFTYCg(menuInstance, boundFunction(self.VVnff0, menuInstance, title), title="Reading Account ...")
 def VVnff0(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VV6QQJ(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VV5c3V)
  VVv9Eb  = ("Home Menu" , FFysPJ, [])
  if totCols == 2:
   VVx5V8 = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
   VVx5V8 = ("More Info.", boundFunction(self.VVHi9Q, menuInstance) , [])
  FFeiXT(self, None, title=title, width=1200, header=header, VVOhES=rows, VVOmXx=widths, VVhAiY=26, VVv9Eb=VVv9Eb, VVx5V8=VVx5V8, VVOFb6="#0a00292B", VVYfYq="#0a002126", VVMBDz="#0a002126", VVuLsk="#00000000", searchCol=searchCol)
 def VVHi9Q(self, menuInstance, VVrPW4, title, txt, colList):
  VVrPW4.cancel()
  FFTYCg(menuInstance, boundFunction(self.VVnff0, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVJQt4(self, mode):
  token, profile = self.VV3qfN()
  if not token:
   return
  res, err = self.VV0OpW(self.VVYpec(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CCydi9()
     chList = tDict["js"]
     for item in chList:
      Id   = CCxu1n.VViqrz(item, "id"       )
      Title  = CCxu1n.VViqrz(item, "title"      )
      censored = CCxu1n.VViqrz(item, "censored"     )
      Title = processChanName.VV2hXR(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVcuSx:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VV0RME(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVOFb6, VVYfYq, VVMBDz, VVuLsk = self.VVvSzQ(mode)
   mName = self.VV0RME(mode)
   VVJAKf   = ("Show List"   , boundFunction(self.VV8hqR, mode) , [])
   VVv9Eb  = ("Home Menu"   , FFysPJ         , [])
   if mode in ("vod", "series"):
    VV5m6F = ("Find in %s" % mName , boundFunction(self.VVeETc, mode), [])
   else:
    VV5m6F = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FFeiXT(self, None, title=title, width=1200, header=header, VVOhES=list, VVOmXx=widths, VVhAiY=30, VVv9Eb=VVv9Eb, VV5m6F=VV5m6F, VVJAKf=VVJAKf, VVOFb6=VVOFb6, VVYfYq=VVYfYq, VVMBDz=VVMBDz, VVuLsk=VVuLsk)
  else:
   FFy0Rl(self, "Could not get Categories from server!", title=title)
 def VVj10X(self, mode, VVrPW4, title, txt, colList):
  FFTYCg(VVrPW4, boundFunction(self.VVOzSb, mode, VVrPW4, title, txt, colList), title="Downloading ...")
 def VVOzSb(self, mode, VVrPW4, title, txt, colList):
  token, profile = self.VV3qfN()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VV0OpW(self.VVowJz(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCxu1n.VViqrz(item, "id"    )
      actors   = CCxu1n.VViqrz(item, "actors"   )
      added   = CCxu1n.VViqrz(item, "added"   )
      age    = CCxu1n.VViqrz(item, "age"   )
      category_id  = CCxu1n.VViqrz(item, "category_id" )
      description  = CCxu1n.VViqrz(item, "description" )
      director  = CCxu1n.VViqrz(item, "director"  )
      genres_str  = CCxu1n.VViqrz(item, "genres_str"  )
      name   = CCxu1n.VViqrz(item, "name"   )
      path   = CCxu1n.VViqrz(item, "path"   )
      screenshot_uri = CCxu1n.VViqrz(item, "screenshot_uri" )
      series   = CCxu1n.VViqrz(item, "series"   )
      cmd    = CCxu1n.VViqrz(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VVJAKf  = ("Play"    , boundFunction(self.VVVv9c, mode, False)     , [])
   VVnOFk = (""     , boundFunction(self.VVEcwe, mode)     , [])
   VVv9Eb = ("Home Menu"   , FFysPJ               , [])
   VVvRGr = ("Download Options" , boundFunction(self.VVmuWM, mode, "sp", seriesName) , [])
   VV5m6F = ("Add ALL to Bouquet" , boundFunction(self.VVGva9, mode, seriesName)  , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVwcLv  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFeiXT(self, None, title=seriesName, width=1200, header=header, VVOhES=list, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=26, VVv9Eb=VVv9Eb, VVvRGr=VVvRGr, VV5m6F=VV5m6F, VVJAKf=VVJAKf, VVnOFk=VVnOFk, VVOFb6="#0a00292B", VVYfYq="#0a002126", VVMBDz="#0a002126", VVuLsk="#00000000")
  else:
   FFy0Rl(self, "Could not get Episodes from server!", title=seriesName)
 def VVeETc(self, mode, VVrPW4, title, txt, colList):
  VVH93c = []
  VVH93c.append(("Keyboard"  , "manualEntry"))
  VVH93c.append(("From Filter" , "fromFilter"))
  FFSEnE(self, boundFunction(self.VVoyJV, VVrPW4, mode), title="Input Type", VVH93c=VVH93c, width=400)
 def VVoyJV(self, VVrPW4, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFpA7M(self, boundFunction(self.VV6eJa, VVrPW4, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCxiMQ(self)
    filterObj.VVfT2H(boundFunction(self.VV6eJa, VVrPW4, mode))
 def VV6eJa(self, VVrPW4, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VVCNUz(mode, searchName)
   if len(searchName) < 3:
    FFy0Rl(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CCydi9()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VV3Ckg([searchName]):
     FFy0Rl(self, processChanName.VVwmN5(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VVCuTj(mode, searchName, "", searchName)
 def VV8hqR(self, mode, VVrPW4, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVCuTj(mode, bName, catID, "")
 def VVCuTj(self, mode, bName, catID, searchName):
  self.session.open(CCYzQV, barTheme=CCYzQV.VVaMkV
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVDnAg, mode, bName, catID, searchName)
      , VVzQlc = boundFunction(self.VV4kVK, mode, bName, catID, searchName))
 def VV4kVK(self, mode, bName, catID, searchName, VVTmBA, VVvkm4, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVCNUz(mode, searchName)
  else   : title = "%s : %s" % (self.VV0RME(mode), bName)
  if VVvkm4:
   VVvRGr = None
   VV5m6F = None
   if mode == "series":
    VVOFb6, VVYfYq, VVMBDz, VVuLsk = self.VVvSzQ("series2")
    VVJAKf  = ("Episodes", boundFunction(self.VVj10X, mode) , [])
   else:
    VVOFb6, VVYfYq, VVMBDz, VVuLsk = self.VVvSzQ("")
    VVJAKf  = ("Play"    , boundFunction(self.VVVv9c, mode, False)         , [])
    VV5m6F = ("Add ALL to Bouquet" , boundFunction(self.VVGva9, mode, bName)       , [])
    VVvRGr = ("Download Options" , boundFunction(self.VVmuWM, mode, "vp" if mode == "vod" else "", "") , [])
   VVnOFk = (""      , boundFunction(self.VVeFVb, mode)          , [])
   VVv9Eb = ("Home Menu"    , FFysPJ                   , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVwcLv  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , CENTER)
   VVrPW4 = FFeiXT(self, None, title=title, header=header, VVOhES=VVvkm4, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=26, VVv9Eb=VVv9Eb, VVvRGr=VVvRGr, VV5m6F=VV5m6F, VVJAKf=VVJAKf, VVnOFk=VVnOFk, VVOFb6=VVOFb6, VVYfYq=VVYfYq, VVMBDz=VVMBDz, VVuLsk=VVuLsk, VVAanx=True, searchCol=1)
   if not VVTmBA:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVrPW4.VVBxdF(VVrPW4.VVWfT2() + tot)
    if threadErr: FF70nx(VVrPW4, "Error while reading !", 2000)
    else  : FF70nx(VVrPW4, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFy0Rl(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFy0Rl(self, "Could not get list from server !", title=title)
 def VVeFVb(self, mode, VVrPW4, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFtcRZ(self, fncMode=CCditA.VV5Ume, portalHost=self.VVBE6t, portalMac=self.VV5c3V, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVK1ho(mode, VVrPW4, title, txt, colList)
 def VVEcwe(self, mode, VVrPW4, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFQRKC(colList[10], VVIbxt)
  txt += "Description:\n%s" % FFQRKC(colList[11], VVIbxt)
  self.VVK1ho(mode, VVrPW4, title, txt, colList)
 def VVK1ho(self, mode, VVrPW4, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVpnFu(mode, colList)
  refCode, chUrl = self.VV3Msv(self.VVBE6t, self.VV5c3V, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFtcRZ(self, fncMode=CCditA.VVHvd8, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVDnAg(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile = self.VV3qfN()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VVvkm4, total_items, max_page_items, err = self.VVuIqh(mode, catID, 1, 1, searchName)
   if progBarObj.isCancelled:
    return
   if progBarObj.VVvkm4 and total_items > -1 and max_page_items > -1:
    progBarObj.VVvDFG(total_items)
    progBarObj.VVtXQw(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVuIqh(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VVuUXd()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VVvkm4 += list
      progBarObj.VVtXQw(len(list), True)
  except:
   pass
 def VVuIqh(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VV3haR(mode, searchName, page)
  else   : url = self.VVlmGa(mode, catID, page)
  res, err = self.VV0OpW(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VV0WFG(CCxu1n.VViqrz(item, "total_items" ))
     max_page_items = self.VV0WFG(CCxu1n.VViqrz(item, "max_page_items" ))
     processChanName = CCydi9()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCxu1n.VViqrz(item, "id"    )
      name   = CCxu1n.VViqrz(item, "name"   )
      tv_genre_id  = CCxu1n.VViqrz(item, "tv_genre_id" )
      number   = CCxu1n.VViqrz(item, "number"   ) or str(counter)
      logo   = CCxu1n.VViqrz(item, "logo"   )
      screenshot_uri = CCxu1n.VViqrz(item, "screenshot_uri" )
      cmd    = CCxu1n.VViqrz(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      if mode == "itv" and not cmdStr in cmd:
       span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
      picon   = logo or screenshot_uri
      counter += 1
      name = processChanName.VVPaiT(name)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVGva9(self, mode, bName, VVrPW4, title, txt, colList):
  FFTYCg(VVrPW4, boundFunction(self.VVMMnj, mode, bName, VVrPW4, title, txt, colList), title="Adding Channels ...")
 def VVMMnj(self, mode, bName, VVrPW4, title, txt, colList):
  bNameFile = CCxu1n.VViIz6_forBouquet(bName)
  num  = 0
  path = VVyYRZ + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVyYRZ + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVrPW4.VVPNQS():
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVpnFu(mode, row)
    refCode, chUrl = self.VV3Msv(self.VVBE6t, self.VV5c3V, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
    totChange += 1
  FF6MIz(os.path.basename(path))
  self.VVRArg(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VV0WFG(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVVv9c(self, mode, fromPlayer, VVrPW4, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVpnFu(mode, colList)
  refCode, chUrl = self.VV3Msv(self.VVBE6t, self.VV5c3V, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if fromPlayer:
   self.VV3pBD(mode, VVrPW4, chUrl)
  elif self.VV8Bxt(chName):
   FF70nx(VVrPW4, "This is a marker!", 300)
  else:
   FFTYCg(VVrPW4, boundFunction(self.VV3pBD, mode, VVrPW4, chUrl), title="Playing ...")
 def VV3pBD(self, mode, VVrPW4, chUrl):
  FFqfoC(self, chUrl, VVIPM3=False)
  self.session.open(CCqamV, portalTableParam=(self, VVrPW4, mode))
 def VVpnFu(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVvc3e(SELF):
  try:
   import requests
   return True
  except:
   FF3096(SELF, boundFunction(CCQctb.VVV9LM, SELF), 'This requires the library "Requests".\n\nInstall it now ?')
   return False
 @staticmethod
 def VVV9LM(SELF):
  from sys import version_info
  cmdUpd = FFfvin(VVmkLF, "")
  if cmdUpd:
   cmdInst = FFrD2J(VVzZPa, "python-requests")
   if version_info[0] >= 3:
    cmdInst = cmdInst.replace("python-", "python3-")
   cmd = cmdUpd + " && " + cmdInst
   FFtPYL(SELF, cmd, checkNetAccess=True, title="Installing Requests Library")
  else:
   FFkPbc(SELF)
class CCxu1n(Screen, CCQctb):
 VVPg0o = 0
 VVGanL = 1
 VVfxmC = 2
 VVHPzQ = 3
 VViuR5  = 4
 VVE5wS  = 5
 VVY9en  = 6
 VVcwyR  = 7
 VVkkhw   = 8
 VVjO2e  = 9
 VVo3lS  = 10
 VVNPZ2  = 11
 VVltuv  = 12
 VVJlgi   = 13
 VVLTDp   = 14
 VVxnta   = 15
 VVYi8r   = 16
 VVgF6o   = 17
 VVGbfW    = 0
 VVLP44   = 1
 VVcTWm   = 2
 VVixUj   = 3
 VVJ435  = 4
 VVLODV  = 5
 VVuRg1   = 6
 VVmYjG   = 7
 VVdXHA  = 8
 VVWR8J  = 9
 VVOdU3  = 10
 def __init__(self, session):
  self.skin, self.skinParam = FFvMLn(VVd6Yn, 1000, 1050, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.VVrPW4  = None
  self.tableTitle   = "IPTV Channels List"
  self.VV5ueLData  = {}
  self.lastFindIptvName = ""
  CCQctb.__init__(self)
  VVH93c= self.VVSBBV()
  FFEVgi(self, title="IPTV", VVH93c=VVH93c)
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  FFj85G(self["myMenu"])
  FFsbO6(self)
  FFE5Iz(self)
 def VVSBBV(self):
  files = self.VVyzGD()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"    , "VV5ueL_fromPlayList" ))
  tList.append(("IPTV Server Browser (from Portal File)"    , "VV5ueL_fromMac"  ))
  tList.append(("IPTV Server Browser (from M3U File)"     , "VV5ueL_fromM3u"  ))
  qUrl, iptvRef = self.VVRPTF()
  if qUrl:
   tList.append(("IPTV Server Browser (from Current Channel)"  , "VV5ueL_fromCurrChan" ))
  VVH93c = []
  if files:
   if self.VVrPW4:
    VVH93c.append(("Add Current List to a New Bouquet"      , "VVBBtm"  ))
    VVH93c.append(VVxSb7)
    VVH93c.append(("Change Current List References to Unique Codes"   , "VV1cgb"))
    VVH93c.append(("Change Current List References to Identical Codes"  , "VVE5mh_rows" ))
    VVH93c.append(VVxSb7)
    VVH93c.append(("Share Reference with Satellite/C/T Service (manual entry)", "VVYDfk"   ))
    VVH93c.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VVmtxs"   ))
   else:
    VVH93c += tList
    VVH93c.append(VVxSb7)
    VVH93c.append(("Local IPTV Channels"          , "iptvTable_all"   ))
    if qUrl:
     VVH93c.append(VVxSb7)
     VVH93c.append(("Update Current Bouquet EPG (from IPTV Server)"  , "refreshIptvEPG"   ))
    VVH93c.append(VVxSb7)
    VVH93c.append(("Count Available IPTV Channels"       , "VVeL2Y"    ))
    VVH93c.append(("Check Reference Codes Format"        , "VVuhU6"   ))
    VVH93c.append(("Check System Acceptable Reference Types"     , "VVU0Gp"   ))
    VVH93c.append(VVxSb7)
    VVH93c.append(("Share Reference with Sat./C/T (Only Matching Names)"  , "VVsrEe" ))
    VVH93c.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVWslp"  ))
    VVH93c.append(("Change ALL References to Unique Codes"     , "VVQ1TC" ))
    VVH93c.append(("Change ALL References to Identical Codes"     , "VVE5mh_all" ))
  if not self.VVrPW4:
   if not files:
    VVH93c += tList
   VVH93c.append(VVxSb7)
   VVH93c.append(("M3U Files Tools ..."           , "VVyxTE"   ))
   if not CCgcno.VVn4WS():
    VVH93c.append(VVxSb7)
    VVH93c.append(("Download Manager"           , "dload_stat"    ))
  return VVH93c
 def VVBwCV(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   if   item == "VVBBtm"   : FFpA7M(self, self.VVBBtm, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VV1cgb" : FF3096(self, boundFunction(FFTYCg, self.VVrPW4, self.VV1cgb ), "Change Current List References to Unique Codes ?")
   elif item == "VVE5mh_rows" : FF3096(self, boundFunction(FFTYCg, self.VVrPW4, self.VVE5mh   ), "Change Current List References to Identical Codes ?")
   elif item == "VVYDfk"   : self.VVYDfk(tTitle)
   elif item == "VVmtxs"   : self.VVmtxs(tTitle)
   elif item == "VV5ueL_fromPlayList" : FFTYCg(self, boundFunction(self.VVGGof, True), title="Searching ...")
   elif item == "VV5ueL_fromM3u"  : FFTYCg(self, boundFunction(self.VVmJQZ, 0), title="Searching ...")
   elif item == "VV5ueL_fromMac"  : self.VVd7SC()
   elif item == "VV5ueL_fromCurrChan" : self.VVaXny_fromCurrChan()
   elif item == "iptvTable_live"   : FFTYCg(self, boundFunction(self.VVRbNw, self.VVcwyR ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFTYCg(self, boundFunction(self.VVRbNw, self.VVPg0o) , title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VVw4t1()
   elif item == "VVeL2Y"    : FFTYCg(self, self.VVeL2Y)
   elif item == "VVuhU6"    : FFTYCg(self, self.VVuhU6)
   elif item == "VVU0Gp"   : FFTYCg(self, self.VVU0Gp)
   elif item == "VVsrEe"  : FF3096(self, boundFunction(FFTYCg, self, self.VVsrEe ), "Continue ?")
   elif item == "VVWslp"  : self.VVWslp()
   elif item == "VVQ1TC" : FF3096(self, boundFunction(FFTYCg, self, self.VVQ1TC ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVE5mh_all" : FF3096(self, boundFunction(FFTYCg, self, self.VVE5mh  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "VVyxTE"   : self.VVyxTE()
   elif item == "dload_stat"    : CCgcno.VVqtop(self)
   elif item == "VVyAqd"   : FFTYCg(self, boundFunction(CCoJ8d.VVyAqd, self))
 def VVyxTE(self):
  VVH93c = []
  VVH93c.append(("Analyse m3u File"            , "VVlrUa"   ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Convert m3u File to Bouquet (from File Manager)"    , "VVEsGZ" ))
  VVH93c.append(("Convert m3u File to Bouquet (from m3u File List)"    , "VV8CoB" ))
  VVH93c.append(('Convert m3u File to Bouquet (Download from "Play Lists")'  , "VVe9iB" ))
  FFSEnE(self, self.VVsN4N, title="M3U Files Tools", VVH93c=VVH93c)
 def VVsN4N(self, item):
  if item is not None:
   t = "Searching ..."
   if   item == "VVlrUa"   : FFTYCg(self, boundFunction(self.VVmJQZ, 1), title="Searching ...")
   elif item == "VVEsGZ" : self.VVEsGZ()
   elif item == "VV8CoB" : FFTYCg(self, boundFunction(self.VVmJQZ, 2), title=t)
   elif item == "VVe9iB" : FFTYCg(self, boundFunction(self.VVGGof, False), title=t)
 def VVrVKJ(self):
  global VVsMrL
  VVsMrL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVBwCV(item)
 def VVRbNw(self, mode):
  VVYnAG = self.VVMcPq(mode)
  if VVYnAG:
   VVvRGr = ("Current Service", self.VV5kyg    , [])
   VV5m6F = ("Options"  , self.VVFtHb      , [])
   VVx5V8 = ("Filter"   , self.VVhkem       , [])
   VVJAKf  = ("Play"   , boundFunction(self.VVwmLV, False) , [])
   VVnOFk = (""    , self.VV4Q5h       , [])
   VVS0Uh = (""    , self.VVp5N9        , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVwcLv  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFeiXT(self, None, header=header, VVOhES=VVYnAG, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=26
     , VVJAKf=VVJAKf, VVvRGr=VVvRGr, VV5m6F=VV5m6F, VVx5V8=VVx5V8, VVnOFk=VVnOFk, VVS0Uh=VVS0Uh
     , VVOFb6="#0a00292B", VVYfYq="#0a002126", VVMBDz="#0a002126", VVuLsk="#00000000", VVAanx=True, searchCol=1)
  else:
   if mode == self.VVcwyR: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFy0Rl(self, err)
 def VVp5N9(self, VVrPW4, title, txt, colList):
  self.VVrPW4 = VVrPW4
 def VVFtHb(self, VVrPW4, title, txt, colList):
  VVH93c= self.VVSBBV()
  FFSEnE(self, self.VVBwCV, title="IPTV Tools", VVH93c=VVH93c)
 def VVhkem(self, VVrPW4, title, txt, colList):
  VVH93c = []
  VVH93c.append(("All"         , "all"   ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Prefix of Selected Channel"   , "sameName" ))
  VVH93c.append(("Suggest Words from Selected Channel" , "partName" ))
  VVH93c.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Live TV"        , "live"  ))
  VVH93c.append(("VOD"         , "vod"   ))
  VVH93c.append(("Series"        , "series"  ))
  VVH93c.append(("Uncategorised"      , "uncat"  ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Video"        , "video"  ))
  VVH93c.append(("Audio"        , "audio"  ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("MKV"         , "MKV"   ))
  VVH93c.append(("MP4"         , "MP4"   ))
  VVH93c.append(("MP3"         , "MP3"   ))
  VVH93c.append(("AVI"         , "AVI"   ))
  VVH93c.append(("FLV"         , "FLV"   ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VV9vrb()
  if bNames:
   bNames.sort()
   VVH93c.append(VVxSb7)
   for item in bNames:
    VVH93c.append((item, "__b__" + item))
  filterObj = CCxiMQ(self)
  filterObj.VVZv4q(VVH93c, VVH93c, boundFunction(self.VVKzLd, VVrPW4))
 def VVKzLd(self, VVrPW4, item=None):
  prefix = VVrPW4.VVvKjl(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVPg0o, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVGanL , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVfxmC , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVHPzQ , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVcwyR  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVkkhw   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVjO2e  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVo3lS  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVNPZ2  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVltuv  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVJlgi   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVLTDp   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVxnta   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVYi8r   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVgF6o   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVY9en  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VViuR5  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVE5wS  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVfxmC:
   VVH93c = []
   chName = VVrPW4.VVvKjl(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVH93c.append((item, item))
    if not VVH93c and chName:
     VVH93c.append((chName, chName))
    FFSEnE(self, boundFunction(self.VVP1g9_partOfName, title), title="Words from Current Selection", VVH93c=VVH93c)
   else:
    VVrPW4.VVjBbc("Invalid Channel Name")
  else:
   words, asPrefix = CCxiMQ.VVCW7j(words)
   if not words and mode in (self.VViuR5, self.VVE5wS):
    FF70nx(self.VVrPW4, "Incorrect filter", 2000)
   else:
    FFTYCg(self.VVrPW4, boundFunction(self.VVykQ0, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVP1g9_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFTYCg(self.VVrPW4, boundFunction(self.VVykQ0, self.VVfxmC, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VV25h8(txt):
  return "#f#11ffff00#" + txt
 def VVykQ0(self, mode, words, asPrefix, title):
  VVYnAG = self.VVMcPq(mode=mode, words=words, asPrefix=asPrefix)
  if VVYnAG : self.VVrPW4.VVH1wF(VVYnAG, title)
  else  : self.VVrPW4.VVjBbc("Not found")
 def VVMcPq(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VVYnAG = []
  files  = self.VVyzGD()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FF1gqL(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVs172 = span.group(1)
    else : VVs172 = ""
    VVs172_lCase = VVs172.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VV8Bxt(chName): chNameMod = self.VV25h8(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVs172, chType, refCode, url)
     ok = False
     tUrl = FFwDWV(url).lower()
     if mode == self.VVPg0o       : ok = True
     elif mode == self.VVY9en       : ok = True
     elif mode == self.VVNPZ2:
      if CCxu1n.VVoNlW(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVltuv:
      if CCxu1n.VVoNlW(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVcwyR:
      if CCxu1n.VVoNlW(tUrl, compareType="live")  : ok = True
     elif mode == self.VVkkhw:
      if CCxu1n.VVoNlW(tUrl, compareType="movie") : ok = True
     elif mode == self.VVjO2e:
      if CCxu1n.VVoNlW(tUrl, compareType="series") : ok = True
     elif mode == self.VVo3lS:
      if CCxu1n.VVoNlW(tUrl, compareType="")   : ok = True
     elif mode == self.VVJlgi:
      if CCxu1n.VVoNlW(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVLTDp:
      if CCxu1n.VVoNlW(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVxnta:
      if CCxu1n.VVoNlW(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVYi8r:
      if CCxu1n.VVoNlW(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVgF6o:
      if CCxu1n.VVoNlW(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVGanL:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVfxmC:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVHPzQ:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VViuR5:
      if words[0] == VVs172_lCase:
       ok = True
     elif mode == self.VVE5wS:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VVYnAG.append(row)
      chNum += 1
  if VVYnAG and mode == self.VVY9en:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VVYnAG)
   for item in VVYnAG:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VVYnAG = newRows
  return VVYnAG
 def VVBBtm(self, bName):
  if bName:
   FFTYCg(self.VVrPW4, boundFunction(self.VVkJtM, bName), title="Adding Channels ...")
 def VVkJtM(self, bName):
  num = 0
  path = VVyYRZ + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVyYRZ + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVrPW4.VVPNQS():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFuz5p(row[1]))
    totChange += 1
  FF6MIz(os.path.basename(path))
  self.VVRArg(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVWslp(self):
  txt = "Stream Type "
  VVH93c = []
  VVH93c.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVH93c.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVH93c.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVH93c.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVH93c.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVH93c.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFSEnE(self, self.VVmfzZ, title="Change Reference Types to:", VVH93c=VVH93c)
 def VVmfzZ(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVZeaL("1"   )
   elif item == "RT_4097" : self.VVZeaL("4097")
   elif item == "RT_5001" : self.VVZeaL("5001")
   elif item == "RT_5002" : self.VVZeaL("5002")
   elif item == "RT_8192" : self.VVZeaL("8192")
   elif item == "RT_8193" : self.VVZeaL("8193")
 def VVZeaL(self, rType):
  FF3096(self, boundFunction(FFTYCg, self, boundFunction(self.VVMnYn, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVMnYn(self, refType):
  totChange = 0
  files  = self.VVyzGD()
  if files:
   for path in files:
    txt = FF1gqL(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FF6MIz(os.path.basename(path))
  self.VVRArg(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVeL2Y(self):
  totFiles = 0
  files  = self.VVyzGD()
  if files:
   totFiles = len(files)
  totChans = 0
  VVYnAG = self.VVMcPq()
  if VVYnAG:
   totChans = len(VVYnAG)
  FFNGa4(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVuhU6(self):
  files  = self.VVyzGD()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FF1gqL(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVoiSL
   else    : color = VVbvoH
   totInvalid = FFQRKC(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFQRKC("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFNGa4(self, txt, title="Check IPTV References")
 def VVU0Gp(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVyYRZ + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FF6MIz(os.path.basename(path))
  FFMFw4()
  acceptedList = []
  VV6yNw = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VV6yNw:
   VVFiXm = FFSDRx(VV6yNw)
   if VVFiXm:
    for service in VVFiXm:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVyYRZ + userBName
  bFile = VVyYRZ + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFmogf("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFmogf("rm -f '%s'" % path)
  os.system(cmd)
  FFMFw4()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVoiSL
    else     : res, color = "No" , VVbvoH
    txt += "    %s\t: %s\n" % (item, FFQRKC(res, color))
   FFNGa4(self, txt, title=title)
  else:
   txt = FFy0Rl(self, "Could not complete the test on your system!", title=title)
 def VVsrEe(self):
  lameDbChans = CCoJ8d.VVEJIr(self, CCoJ8d.VVy85K)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVyzGD():
    toSave = False
    txt = FF1gqL(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVRArg(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFy0Rl(self, 'No channels in "lamedb" !')
 def VVQ1TC(self):
  files  = self.VVyzGD()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFxHei(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVuJqn(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVRArg(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VV1cgb(self):
  iptvRefList = []
  files  = self.VVyzGD()
  if files:
   for path in files:
    txt = FF1gqL(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVrPW4.VVePxH(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVuJqn(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVyzGD()
  if files:
   for path in files:
    lines = FFxHei(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVRArg(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVuJqn(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVE5mh(self):
  list = None
  if self.VVrPW4:
   list = []
   for row in self.VVrPW4.VVPNQS():
    list.append(row[4] + row[5])
  files  = self.VVyzGD()
  totChange = 0
  if files:
   for path in files:
    lines = FFxHei(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVRArg(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVRArg(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFMFw4()
   if refreshTable and self.VVrPW4:
    VVYnAG = self.VVMcPq()
    if VVYnAG and self.VVrPW4:
     self.VVrPW4.VVH1wF(VVYnAG, self.tableTitle)
     self.VVrPW4.VVjBbc(txt)
   FFNGa4(self, txt, title=title)
  else:
   FFM9af(self, "No changes.")
 def VV9vrb(self):
  files = self.VVyzGD()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with open(path, "r") as f:
     span = iSearch(r"#NAME\s+(.*)", f.readline(), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VVtyRo = FFq54s()
    if VVtyRo:
     for b in VVtyRo:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVyzGD(self):
  return CCxu1n.VVoYPl(self)
 @staticmethod
 def VVoYPl(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVyYRZ + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FF1gqL(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VV4Q5h(self, VVrPW4, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFwDWV(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFtcRZ(self, fncMode=CCditA.VVq5t7, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVwmLV(self, fromPlayer, VVrPW4, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  self.VV8CMo(fromPlayer, VVrPW4, chName, chUrl, "localIptv")
 def VV5bA9(self, mode, fromPlayer, VVrPW4, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVxBlL(mode, colList)
  self.VV8CMo(fromPlayer, VVrPW4, chName, chUrl, mode)
 def VV8CMo(self, fromPlayer, VVrPW4, chName, chUrl, playerFlag):
  chName = FFuz5p(chName)
  if fromPlayer:
   self.VVxDKZ(VVrPW4, chUrl, playerFlag)
  elif self.VV8Bxt(chName):
   FF70nx(VVrPW4, "This is a marker!", 300)
  else:
   FFTYCg(VVrPW4, boundFunction(self.VVxDKZ, VVrPW4, chUrl, playerFlag), title="Playing ...")
 def VVxDKZ(self, VVrPW4, chUrl, playerFlag):
  FFqfoC(self, chUrl, VVIPM3=False)
  self.session.open(CCqamV, portalTableParam=(self, VVrPW4, playerFlag))
 @staticmethod
 def VV8Bxt(chName):
  mark = ("--", "__", "==", "##", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VV5kyg(self, VVrPW4, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(self)
  if refCode:
   bName = FFvULn()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FF3zgs(refCode, origUrl, chName) }
   VVrPW4.VV5KJx_partial(colDict, VVkUjI=True)
 def VVEsGZ(self):
  self.session.open(CCw1Kh)
  self.close()
 def VVmJQZ(self, m3uMode):
  path = CCxu1n.VVTICz()
  lines = FF8QLc("find %s %s -iname '*.m3u' | grep -i '.m3u'" % (path, FFJQpq(1)))
  if lines:
   lines.sort()
   VVH93c = []
   for line in lines:
    VVH93c.append((line, line))
   if   m3uMode == 0 : title = "Browse Server from M3U URLs"
   elif m3uMode == 1 : title = "Analyse M3U File"
   else    : title = "Convert M3U File to Bouquet"
   if m3uMode in [0, 2]: VVM3vl = ("All to Playlist", self.VVBjNb)
   else    : VVM3vl = None
   OKBtnFnc = boundFunction(self.VVf5WI, m3uMode, title)
   VVDeB1 = ("Show Full Path", self.VVotez)
   VVSptY = ("Delete File", boundFunction(self.VVFQYq, boundFunction(FFTYCg, self, boundFunction(self.VVmJQZ, m3uMode), title="Searching ...")))
   FFSEnE(self, None, title=title, VVH93c=VVH93c, OKBtnFnc=OKBtnFnc, VVDeB1=VVDeB1, VVSptY=VVSptY, VVM3vl=VVM3vl)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n\n%s" % path
   FFy0Rl(self, 'No ".m3u" files found %s' % txt)
 def VVotez(self, VVzEsrObj, url):
  FFNGa4(self, url, title="Full Path")
 def VVf5WI(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if   m3uMode == 0 : FFTYCg(menuInstance, boundFunction(self.VVKSyV, title, path))
   elif m3uMode == 1 : self.VVlrUa(title, path)
   else    : self.VVQaUc(menuInstance, path)
 def VVBjNb(self, VVzEsrObj, item=None):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVzEsrObj.VVH93c):
    path = item[1]
    if fileExists(path):
     enc = FFViFM(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = self.VVOabS(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCxu1n.VVTICz()
    if path == "/":
     path = CFG.exportedTablesPath.getValue()
    pListF = "%sPlaylist_%s.txt" % (FFIm0p(path), FFVgvw())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVzEsrObj.VVH93c)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFNGa4(self, txt, title=title)
   else:
    FFy0Rl(self, "Could not obtain URLs from this file list !", title=title)
 def VVlrUa(self, title, path):
  if fileExists(path):
   self.session.open(CCYzQV, barTheme=CCYzQV.VVaMkV
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VVY9Ur, path)
       , VVzQlc = boundFunction(self.VVno3i, title, path))
  else:
   FFy0Rl(SELF, "Cannot open file :\n\n%s" % path, title=title)
 def VVno3i(self, title, path, VVTmBA, VVvkm4, threadCounter, threadTotal, threadErr):
  if VVTmBA:
   FFNGa4(self, VVvkm4, title=title)
 def VVY9Ur(self, path, progBarObj):
  totChan   = 0
  totLive   = 0
  totVod   = 0
  totSeries  = 0
  totUncat  = 0
  totVideo  = 0
  totAudio  = 0
  txt = FF1gqL(path)
  lst = iFindall(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?((.+)(:[^:\/]+$)|.+)", txt, IGNORECASE)
  txt = ""
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVvkm4 = ""
  progBarObj.VVvDFG(len(lst))
  for item in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVtXQw(1, True)
   totChan += 1
   chName  = item[0].strip()
   fullUrl  = item[1].strip()
   urlPart1 = item[2]
   if urlPart1 : tUrl = urlPart1
   else  : tUrl = fullUrl
   tUrl = FFwDWV(tUrl).lower()
   chType, host, username, password, streamId, chName = CCxu1n.VVoNlW(tUrl)
   if   chType == "live" : totLive += 1
   elif chType == "movie" : totVod += 1
   elif chType == "series" : totSeries += 1
   else     : totUncat += 1
   aud_vid = CCxu1n.VVoNlW(tUrl, getAudVid=True)
   if   aud_vid == "vid" : totVideo += 1
   elif aud_vid == "aud" : totAudio += 1
  txt = ""
  txt += FFQRKC("File:\n", VVq6Xr)
  txt += "    %s\n"   % path
  txt += "\n"
  txt += FFQRKC("Channels:\n", VVq6Xr)
  if lst:
   txt += "    Total\t: %d\n" % totChan
   txt += "\n"
   txt += FFQRKC("Category:\n", VVq6Xr)
   txt += "    Live\t: %d\n" % totLive
   txt += "    VOD\t: %d\n" % totVod
   txt += "    Series\t: %d\n" % totSeries
   txt += "    Uncat.\t: %d\n" % totUncat
   txt += "\n"
   txt += FFQRKC("Content:\n", VVq6Xr)
   txt += "    Video\t: %d\n" % totVideo
   txt += "    Audio\t: %d\n" % totAudio
   txt += "\n"
  else:
   txt += "    No channels  (or invalid file file format)"
  if progBarObj:
   progBarObj.VVvkm4 = txt
 def VVGGof(self, isBrowseServer):
  path = CCxu1n.VVTICz()
  lines = FF8QLc('find %s %s -iname "*playlist*" | grep -i ".txt"' % (path, FFJQpq(1)))
  if lines:
   lines.sort()
   VVH93c = []
   for line in lines:
    VVH93c.append((line, line))
   OKBtnFnc = boundFunction(self.VV3izM, isBrowseServer)
   VVSptY = ("Delete File", boundFunction(self.VVFQYq, boundFunction(FFTYCg, self, boundFunction(self.VVGGof, isBrowseServer), title="Searching ...")))
   FFSEnE(self, None, title="Select Playlist File", VVH93c=VVH93c, width=1200, OKBtnFnc=OKBtnFnc, VVSptY=VVSptY)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFy0Rl(self, 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt)
 def VV3izM(self, isBrowseServer, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFTYCg(menuInstance, boundFunction(self.VVqbGU, menuInstance, path, isBrowseServer), title="Processing File ...")
 def VVqbGU(self, fileMenuInstance, path, isBrowseServer):
  enc = FFViFM(path, self)
  if enc == -1:
   return
  VVYnAG = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFIm0p(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCxu1n.VVszTs(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVYnAG:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(filter(None, [item[5], item[0]]))
     num += 1
     VVYnAG.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVYnAG:
   if isBrowseServer : title = "Playlist File"
   else    : title = "Convert to Bouquet"
   VVJAKf  = ("Start"   , boundFunction(self.VVbUUd, isBrowseServer, title) , [])
   VVv9Eb = ("Home Menu"  , FFysPJ            , [])
   VV5m6F = ("Edit File"  , boundFunction(self.VVz8Kp, path)    , [])
   VVx5V8 = ("Check & Filter" , boundFunction(self.VVJDiQ, fileMenuInstance, path, isBrowseServer), [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVwcLv  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFeiXT(self, None, title=title, header=header, VVOhES=VVYnAG, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=26, VVJAKf=VVJAKf, VVv9Eb=VVv9Eb, VVx5V8=VVx5V8, VV5m6F=VV5m6F, VVOFb6="#11001116", VVYfYq="#11001116", VVMBDz="#11001116", VVuLsk="#00003635", VVCiIJ="#0a333333", VViPgN="#11331100", VVAanx=True)
  else:
   FFy0Rl(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVz8Kp(self, path, VVrPW4, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CC6xEh(self, path, VVzQlc=boundFunction(self.VVXepT, VVrPW4), curRowNum=rowNum)
  else    : FFZZL8(self, path)
 def VVXepT(self, VVrPW4, fileChanged):
  if fileChanged:
   VVrPW4.cancel()
 def VVbUUd(self, isBrowseServer, Title, VVrPW4, title, txt, colList):
  url = colList[6]
  if isBrowseServer:
   FFTYCg(VVrPW4, boundFunction(self.VVVWTX, Title, url), title="Checking Server ...")
  else:
   t = "&type=m3u"
   if not url.endswith(t):
    url += t
   url = url.replace("player_api.php", "get.php" )
   FF3096(self, boundFunction(FFTYCg, VVrPW4, boundFunction(self.VVLQW8, VVrPW4, url), title="Downloading ..."), "Download m3u file from this URL ?\n\n%s" % url, title=Title)
 def VVLQW8(self, VVrPW4, url):
  path, err = FF9cSe(url, "ajpanel_tmp.m3u", timeout=3)
  title = "Download Problem"
  if err:
   FFy0Rl(self, err, title=title)
  else:
   if fileExists(path):
    txt = FF1gqL(path)
    if '{"user_info":{"auth":0}}' in txt:
     FFy0Rl(self, "Unauthorized", title=title)
     os.system(FFmogf("rm -f '%s'" % path))
     return
   self.VVQaUc(VVrPW4, path)
 def VVYDfk(self, title):
  curChName = self.VVrPW4.VVvKjl(1)
  FFpA7M(self, boundFunction(self.VVax4W, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVax4W(self, title, name):
  if name:
   lameDbChans = CCoJ8d.VVEJIr(self, CCoJ8d.VVzoNp, VVU9Vj=False, VVDPmC=False)
   list = []
   if lameDbChans:
    processChanName = CCydi9()
    name = processChanName.VVTrFW(name)
    ratio = "1"
    for item in lameDbChans:
     if name in item[0].lower():
      list.append((item[0], FFovAP(item[2]), item[3], ratio))
   if list : self.VVZGZ5(list, title)
   else : FFy0Rl(self, "Not found:\n\n%s" % name, title=title)
 def VVmtxs(self, title):
  curChName = self.VVrPW4.VVvKjl(1)
  self.session.open(CCYzQV, barTheme=CCYzQV.VVaMkV
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVOlOo
      , VVzQlc = boundFunction(self.VVDpYJ, title, curChName))
 def VVOlOo(self, progBarObj):
  curChName = self.VVrPW4.VVvKjl(1)
  lameDbChans = CCoJ8d.VVEJIr(self, CCoJ8d.VVYINn, VVU9Vj=False, VVDPmC=False)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVvkm4 = []
  progBarObj.VVvDFG(len(lameDbChans))
  processChanName = CCydi9()
  curCh = processChanName.VVTrFW(curChName)
  for refCode in lameDbChans:
   chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
   ratio = CCc2Xe.VVBQIn(chName.lower(), curCh)
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVtXQw(1, True)
   if progBarObj and ratio > 50:
    progBarObj.VVvkm4.append((chName, FFovAP(sat), refCode.replace("_", ":"), str(ratio)))
 def VVDpYJ(self, title, curChName, VVTmBA, VVvkm4, threadCounter, threadTotal, threadErr):
  if VVvkm4: self.VVZGZ5(VVvkm4, title)
  elif VVTmBA: FFy0Rl(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVZGZ5(self, VVYnAG, title):
  curChName = self.VVrPW4.VVvKjl(1)
  curRefCode = self.VVrPW4.VVvKjl(4)
  curUrl  = self.VVrPW4.VVvKjl(5)
  VVYnAG = sorted(VVYnAG, key=lambda x: (100-int(x[3]), x[0].lower()))
  VVJAKf  = ("Share Sat/C/T Ref.", boundFunction(self.VVrKmg, title, curChName, curRefCode, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFeiXT(self, None, title=title, header=header, VVOhES=VVYnAG, VVOmXx=widths, VVhAiY=26, VVJAKf=VVJAKf, VVOFb6="#0a00112B", VVYfYq="#0a001126", VVMBDz="#0a001126", VVuLsk="#00000000")
 def VVrKmg(self, newtitle, curChName, curRefCode, curUrl, VVrPW4, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FF3096(self.VVrPW4, boundFunction(FFTYCg, self.VVrPW4, boundFunction(self.VVmAnH, VVrPW4, data)), ques, title=newtitle, VVZH0D=True)
 def VVmAnH(self, VVrPW4, data):
  VVrPW4.cancel()
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVyzGD():
    txt = FF1gqL(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFMFw4()
    newRow = []
    for i in range(6):
     newRow.append(self.VVrPW4.VVvKjl(i))
    newRow[4] = newRefCode
    done = self.VVrPW4.VVKR3H(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFpblr(boundFunction(FFM9af , self, resTxt, title=title))
  elif resErr: FFpblr(boundFunction(FFy0Rl , self, resErr, title=title))
 def VVJDiQ(self, fileMenuInstance, path, isBrowseServer, VVrPW4, title, txt, colList):
  self.session.open(CCYzQV, barTheme=CCYzQV.VVaMkV
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VVOD95, VVrPW4)
      , VVzQlc = boundFunction(self.VVo1Bt, fileMenuInstance, path, isBrowseServer, VVrPW4))
 def VVOD95(self, VVrPW4, progBarObj):
  progBarObj.VVvDFG(VVrPW4.VVFWie())
  progBarObj.VVvkm4 = []
  for row in VVrPW4.VVPNQS():
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVtXQw(1, True)
   qUrl = self.VV4x5F(self.VVGbfW, row[6])
   txt, err = self.VVwnBY(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VViqrz(item, "auth") == "0":
       progBarObj.VVvkm4.append(qUrl)
    except:
     pass
 def VVo1Bt(self, fileMenuInstance, path, isBrowseServer, VVrPW4, VVTmBA, VVvkm4, threadCounter, threadTotal, threadErr):
  if VVTmBA:
   list = VVvkm4
   title = "Authorized Servers"
   if list:
    totChk = VVrPW4.VVFWie()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFVgvw()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVGGof(isBrowseServer)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFQRKC(str(totAuth), VVoiSL)
     txt += "%s\n\n%s"    %  (FFQRKC("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFNGa4(self, txt, title=title)
     VVrPW4.close()
     fileMenuInstance.close()
    else:
     FFM9af(self, "All URLs are authorized.", title=title)
   else:
    FFy0Rl(self, "No authorized URL found !", title=title)
 def VVQaUc(self, parentInstant, path):
  files = CCxu1n.VVoYPl(self, atLeastOne=True)
  if files: exitCurWin = False
  else : exitCurWin = True
  CCxu1n.VVR0Wv(parentInstant, path, exitCurWin)
 @staticmethod
 def VVR0Wv(SELF, path, exitCurWin):
  FF3096(SELF, boundFunction(FFTYCg, SELF, boundFunction(CCxu1n.VVs2qg, SELF, path, exitCurWin), title="Converting ...")
    , "Convert file to bouquet ?\n\n%s" % path, title="Convert m3u file")
 @staticmethod
 def VVs2qg(SELF, path, exitCurWin):
  SID = TSID = ONID = 0
  MAX = 65535
  title = "Convert m3u File to Bouquet"
  if not fileExists(path):
   FFy0Rl(SELF, "Cannot open file :\n\n%s" % path, title=title)
   return
  bName  = os.path.basename(path)
  bName  = os.path.splitext(bName)[0]
  bName   = CCxu1n.VViIz6_forBouquet(bName)
  bName  = "IPTV_" + bName
  bFileName = "userbouquet.%s.tv" % bName
  if fileExists(VVyYRZ + bFileName):
   while True:
    SID += 1
    tmpBName = "%s_%d" % (bName, SID)
    bFileName = "userbouquet.%s.tv" % tmpBName
    if not fileExists(VVyYRZ + bFileName):
     bName = tmpBName
     break
  txt = FF1gqL(path)
  pattern = r"#EXTINF.+,(.+)\n(.+)"
  span = iSearch(r"#EXTINF.+,(.+)\n(.+)", txt, IGNORECASE)
  if span:
   with open(VVyYRZ + bFileName, "w") as f:
    totChan = 0
    f.write("#NAME %s\n" % bName.replace("IPTV_", "IPTV - ", 1))
    for match in iFinditer(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?(.+)", txt, IGNORECASE):
     TSID += 1
     if TSID > MAX:
      TSID = MAX
      ONID += 1
      if ONID > MAX:
       ONID = 0
     chName = match.group(1).strip()
     url  = FFOEqY(match.group(2).strip())
     rType = CFG.iptvAddToBouquetRefType.getValue()
     refCode = "%s:0:1:%s:%s:%s:0:0:0:0:" % (rType, hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:])
     line1 = "#SERVICE %s%s\n" % (refCode.upper(), url)
     line2 = "#DESCRIPTION %s\n" % chName
     f.write(line1 + line2)
     totChan += 1
   FF6MIz(bFileName)
   FFMFw4()
   FFM9af(SELF, 'New Bouquet = %s\n\nTotal Channels = %d' % (bName, totChan), title=title)
  else:
   FFy0Rl(SELF, "No channels found in file (or invalid file format) !\n\n%s" % path, title=title)
  if exitCurWin:
   SELF.close()
 @staticmethod
 def VVwnBY(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   res = res.read().decode("UTF-8")
   if res:
    if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server !"
    else           : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVszTs(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVoNlW(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VV4x5F(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVszTs(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVGbfW   : return "%s"            % url
  elif mode == self.VVLP44   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVcTWm   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVixUj  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVJ435  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVLODV : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVuRg1   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVmYjG    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVdXHA  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVOdU3 : return "%s&action=get_live_streams"      % url
  elif mode == self.VVWR8J  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VViqrz(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFI3l2(int(val))
    elif is_base64 : val = FFHtVc(val)
    elif isToHHMMSS : val = FFEQDX(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVKSyV(self, title, path):
  if fileExists(path):
   enc = FFViFM(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = self.VVOabS(line)
     if qUrl:
      break
   if qUrl : self.VVVWTX(title, qUrl)
   else : FFy0Rl(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFy0Rl(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVaXny_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVRPTF()
  if qUrl:
   host, mac, isPortalUrl = self.VV2VSW(iptvRef)
   if isPortalUrl:
    if host and mac : self.VVaXny(self, host, mac)
    else   : FFy0Rl(self, "Error in current channel URL/MAC !", title=title)
   else:
    FFTYCg(self, boundFunction(self.VVVWTX, title, qUrl), title="Checking Server ...")
  else:
   FFy0Rl(self, "Error in current channel URL !", title=title)
 def VVRPTF(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(self)
  qUrl = self.VVOabS(decodedUrl)
  return qUrl, iptvRef
 def VVOabS(self, url):
  if url.startswith("#"):
   return ""
  url = url.lstrip(" /").rstrip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) >= 2 : return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else    : return ""
 def VVVWTX(self, title, url):
  self.VV5ueLData = {}
  qUrl = self.VV4x5F(self.VVGbfW, url)
  txt, err = self.VVwnBY(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VV5ueLData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VV5ueLData["username"    ] = self.VViqrz(item, "username"        )
    self.VV5ueLData["password"    ] = self.VViqrz(item, "password"        )
    self.VV5ueLData["message"    ] = self.VViqrz(item, "message"        )
    self.VV5ueLData["auth"     ] = self.VViqrz(item, "auth"         )
    self.VV5ueLData["status"    ] = self.VViqrz(item, "status"        )
    self.VV5ueLData["exp_date"    ] = self.VViqrz(item, "exp_date"    , isDate=True )
    self.VV5ueLData["is_trial"    ] = self.VViqrz(item, "is_trial"        )
    self.VV5ueLData["active_cons"   ] = self.VViqrz(item, "active_cons"       )
    self.VV5ueLData["created_at"   ] = self.VViqrz(item, "created_at"   , isDate=True )
    self.VV5ueLData["max_connections"  ] = self.VViqrz(item, "max_connections"      )
    self.VV5ueLData["allowed_output_formats"] = self.VViqrz(item, "allowed_output_formats"    )
    lst = []
    key = "allowed_output_formats"
    if key in item:
     for item in item[key]:
      lst.append(str(item))
     self.VV5ueLData[key] = lst
    item = tDict["server_info"]
    self.VV5ueLData["url"    ] = self.VViqrz(item, "url"        )
    self.VV5ueLData["port"    ] = self.VViqrz(item, "port"        )
    self.VV5ueLData["https_port"  ] = self.VViqrz(item, "https_port"      )
    self.VV5ueLData["server_protocol" ] = self.VViqrz(item, "server_protocol"     )
    self.VV5ueLData["rtmp_port"   ] = self.VViqrz(item, "rtmp_port"       )
    self.VV5ueLData["timezone"   ] = self.VViqrz(item, "timezone"       )
    self.VV5ueLData["timestamp_now"  ] = self.VViqrz(item, "timestamp_now"  , isDate=True )
    self.VV5ueLData["time_now"   ] = self.VViqrz(item, "time_now"       )
    VVH93c  = self.VVUPKI(True)
    OKBtnFnc = self.VV5ueLOptions
    VVURxH = ("Home Menu", FFysPJ)
    FFSEnE(self, None, title="IPTV Server Resources", VVH93c=VVH93c, OKBtnFnc=OKBtnFnc, VVURxH=VVURxH)
   else:
    err = "Could not get data from server !"
  if err:
   FFy0Rl(self, err, title=title)
  FF70nx(self)
 def VV5ueLOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFTYCg(menuInstance, boundFunction(self.VVHkxg, self.VVLP44  , title=title), title=wTxt)
   elif ref == "vod"   : FFTYCg(menuInstance, boundFunction(self.VVHkxg, self.VVcTWm  , title=title), title=wTxt)
   elif ref == "series"  : FFTYCg(menuInstance, boundFunction(self.VVHkxg, self.VVixUj , title=title), title=wTxt)
   elif ref == "catchup"  : FFTYCg(menuInstance, boundFunction(self.VVHkxg, self.VVJ435 , title=title), title=wTxt)
   elif ref == "accountInfo" : FFTYCg(menuInstance, boundFunction(self.VVwuD0           , title=title), title=wTxt)
 def VVwuD0(self, title):
  rows = []
  for key, val in self.VV5ueLData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VVv9Eb = ("Home Menu", FFysPJ, [])
  header   = ("Num", "User/Server" , "Subject" , "Value" )
  widths   = (0 , 15   , 35  , 50  )
  FFeiXT(self, None, title=title, width=1200, header=header, VVOhES=rows, VVOmXx=widths, VVhAiY=26, VVv9Eb=VVv9Eb, VVOFb6="#0a00292B", VVYfYq="#0a002126", VVMBDz="#0a002126", VVuLsk="#00000000", searchCol=2)
 def VV4Yqn(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CCydi9()
    if mode in (self.VVuRg1, self.VVWR8J):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VViqrz(item, "num"         )
      name     = self.VViqrz(item, "name"        )
      stream_id    = self.VViqrz(item, "stream_id"       )
      stream_icon    = self.VViqrz(item, "stream_icon"       )
      epg_channel_id   = self.VViqrz(item, "epg_channel_id"      )
      added     = self.VViqrz(item, "added"    , isDate=True )
      is_adult    = self.VViqrz(item, "is_adult"       )
      category_id    = self.VViqrz(item, "category_id"       )
      tv_archive    = self.VViqrz(item, "tv_archive"       )
      name = processChanName.VVPaiT(name)
      if name:
       if mode == self.VVuRg1 or mode == self.VVWR8J and tv_archive == "1":
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVmYjG:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VViqrz(item, "num"         )
      name    = self.VViqrz(item, "name"        )
      stream_id   = self.VViqrz(item, "stream_id"       )
      stream_icon   = self.VViqrz(item, "stream_icon"       )
      added    = self.VViqrz(item, "added"    , isDate=True )
      is_adult   = self.VViqrz(item, "is_adult"       )
      category_id   = self.VViqrz(item, "category_id"       )
      container_extension = self.VViqrz(item, "container_extension"     ) or "mp4"
      name = processChanName.VVPaiT(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVdXHA:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VViqrz(item, "num"        )
      name    = self.VViqrz(item, "name"       )
      series_id   = self.VViqrz(item, "series_id"      )
      cover    = self.VViqrz(item, "cover"       )
      genre    = self.VViqrz(item, "genre"       )
      episode_run_time = self.VViqrz(item, "episode_run_time"    )
      category_id   = self.VViqrz(item, "category_id"      )
      container_extension = self.VViqrz(item, "container_extension"    ) or "mp4"
      name = processChanName.VVPaiT(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVHkxg(self, mode, title):
  cList, err = self.VVEqPz(mode)
  if cList and mode == self.VVJ435:
   cList = self.VVC7nz(cList)
  if err:
   FFy0Rl(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVOFb6, VVYfYq, VVMBDz, VVuLsk = self.VVvSzQ(mode)
   mName = self.VV0RME(mode)
   if   mode == self.VVLP44  : fMode = self.VVuRg1
   elif mode == self.VVcTWm  : fMode = self.VVmYjG
   elif mode == self.VVixUj : fMode = self.VVdXHA
   elif mode == self.VVJ435 : fMode = self.VVWR8J
   if mode == self.VVJ435:
    VV5m6F = None
   else:
    VV5m6F = ("Find in %s" % mName , boundFunction(self.VVjOjQ, fMode) , [])
   VVJAKf   = ("Show List"   , boundFunction(self.VVri0f, mode) , [])
   VVv9Eb  = ("Home Menu"   , FFysPJ          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFeiXT(self, None, title=title, width=1200, header=header, VVOhES=cList, VVOmXx=widths, VVhAiY=30, VVv9Eb=VVv9Eb, VV5m6F=VV5m6F, VVJAKf=VVJAKf, VVOFb6=VVOFb6, VVYfYq=VVYfYq, VVMBDz=VVMBDz, VVuLsk=VVuLsk)
  else:
   FFy0Rl(self, "No list from server !", title=title)
  FF70nx(self)
 def VVEqPz(self, mode):
  qUrl  = self.VV4x5F(mode, self.VV5ueLData["playListURL"])
  txt, err = self.VVwnBY(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    processChanName = CCydi9()
    for item in tDict:
     category_id  = self.VViqrz(item, "category_id"  )
     category_name = self.VViqrz(item, "category_name" )
     parent_id  = self.VViqrz(item, "parent_id"  )
     category_name = processChanName.VV2hXR(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVC7nz(self, catList):
  mode  = self.VVWR8J
  qUrl  = self.VV4x5F(mode, self.VV5ueLData["playListURL"])
  txt, err = self.VVwnBY(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VV4Yqn(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVri0f(self, mode, VVrPW4, title, txt, colList):
  title = colList[1]
  FFTYCg(VVrPW4, boundFunction(self.VVx90m, mode, VVrPW4, title, txt, colList), title="Downloading ...")
 def VVx90m(self, mode, VVrPW4, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VV0RME(mode) + " : "+ bName
  if   mode == self.VVLP44  : mode = self.VVuRg1
  elif mode == self.VVcTWm  : mode = self.VVmYjG
  elif mode == self.VVixUj : mode = self.VVdXHA
  elif mode == self.VVJ435 : mode = self.VVWR8J
  qUrl  = self.VV4x5F(mode, self.VV5ueLData["playListURL"], catID)
  txt, err = self.VVwnBY(qUrl)
  list  = []
  if not err and mode in (self.VVuRg1, self.VVmYjG, self.VVdXHA, self.VVWR8J):
   list, err = self.VV4Yqn(mode, txt)
  if err:
   FFy0Rl(self, err, title=title)
  elif list:
   VVv9Eb  = ("Home Menu"   , FFysPJ             , [])
   if mode in (self.VVuRg1, self.VVWR8J):
    VVOFb6, VVYfYq, VVMBDz, VVuLsk = self.VVvSzQ(mode)
    VVnOFk = (""     , boundFunction(self.VVdMzO, mode)     , [])
    VVvRGr = ("Download Options" , boundFunction(self.VVmuWM, mode, "", "")  , [])
    VV5m6F = ("Add ALL to Bouquet" , boundFunction(self.VV1eIO, mode, bName)  , [])
    if mode == self.VVuRg1:
     VVJAKf = ("Play"    , boundFunction(self.VV5bA9, mode, False)   , [])
    elif mode == self.VVWR8J:
     VVJAKf  = ("Programs", boundFunction(self.VVRJ6b, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVwcLv  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVmYjG:
    VVOFb6, VVYfYq, VVMBDz, VVuLsk = self.VVvSzQ(mode)
    VVJAKf  = ("Play"    , boundFunction(self.VV5bA9, mode, False)  , [])
    VVnOFk = (""     , boundFunction(self.VVdMzO, mode)    , [])
    VVvRGr = ("Download Options" , boundFunction(self.VVmuWM, mode, "v", ""), [])
    VV5m6F = ("Add ALL to Bouquet" , boundFunction(self.VV1eIO, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVwcLv  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVdXHA:
    VVOFb6, VVYfYq, VVMBDz, VVuLsk = self.VVvSzQ("series2")
    VVJAKf  = ("Show Seasons", boundFunction(self.VVg8nv, mode) , [])
    VVnOFk = ("", boundFunction(self.VV27I1, mode)  , [])
    VVvRGr = None
    VV5m6F = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVwcLv  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFeiXT(self, None, title=title, header=header, VVOhES=list, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=26, VVJAKf=VVJAKf, VVv9Eb=VVv9Eb, VVvRGr=VVvRGr, VV5m6F=VV5m6F, VVnOFk=VVnOFk, VVOFb6=VVOFb6, VVYfYq=VVYfYq, VVMBDz=VVMBDz, VVuLsk=VVuLsk, VVAanx=True, searchCol=1)
  else:
   FFy0Rl(self, "No Channels found !", title=title)
  FF70nx(self)
 def VVRJ6b(self, mode, bName, VVrPW4, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VV5ueLData["playListURL"]
  ok_fnc  = boundFunction(self.VVIl9P, hostUrl, chName, catId, streamId)
  FFTYCg(VVrPW4, boundFunction(CCxu1n.VVm07c, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVIl9P(self, chUrl, chName, catId, streamId, VVrPW4, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCxu1n.VVszTs(chUrl)
   chNum = "333"
   refCode = CCxu1n.VVxJ3z(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFqfoC(self, chUrl, VVIPM3=False)
   self.session.open(CCqamV)
  else:
   FFy0Rl(self, "Incorrect Timestamp", pTitle)
 def VVg8nv(self, mode, VVrPW4, title, txt, colList):
  title = colList[1]
  FFTYCg(VVrPW4, boundFunction(self.VVbZYH, mode, VVrPW4, title, txt, colList), title="Downloading ...")
 def VVbZYH(self, mode, VVrPW4, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VV4x5F(self.VVLODV, self.VV5ueLData["playListURL"], series_id)
  txt, err = self.VVwnBY(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VViqrz(tDict["info"], "name"   )
      category_id = self.VViqrz(tDict["info"], "category_id" )
      icon  = self.VViqrz(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VViqrz(EP, "id"     )
        episode_num   = self.VViqrz(EP, "episode_num"   )
        epTitle    = self.VViqrz(EP, "title"     )
        container_extension = self.VViqrz(EP, "container_extension" )
        seasonNum   = self.VViqrz(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFy0Rl(self, err, title=title)
  elif list:
   VVv9Eb = ("Home Menu"   , FFysPJ             , [])
   VVvRGr = ("Download Options" , boundFunction(self.VVmuWM, mode, "s", title) , [])
   VV5m6F = ("Add ALL to Bouquet" , boundFunction(self.VV1eIO, mode, title)  , [])
   VVnOFk = (""     , boundFunction(self.VVdMzO, mode)     , [])
   VVJAKf  = ("Play"    , boundFunction(self.VV5bA9, mode, False)   , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVwcLv  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFeiXT(self, None, title=title, header=header, VVOhES=list, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=26, VVv9Eb=VVv9Eb, VVvRGr=VVvRGr, VVJAKf=VVJAKf, VVnOFk=VVnOFk, VV5m6F=VV5m6F, VVOFb6="#0a00292B", VVYfYq="#0a002126", VVMBDz="#0a002126", VVuLsk="#00000000")
  else:
   FFy0Rl(self, "No Channels found !", title=title)
  FF70nx(self)
 def VVjOjQ(self, mode, VVrPW4, title, txt, colList):
  VVH93c = []
  VVH93c.append(("Keyboard"  , "manualEntry"))
  VVH93c.append(("From Filter" , "fromFilter"))
  FFSEnE(self, boundFunction(self.VVGpKb, VVrPW4, mode), title="Input Type", VVH93c=VVH93c, width=400)
 def VVGpKb(self, VVrPW4, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFpA7M(self, boundFunction(self.VVCPvh, VVrPW4, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCxiMQ(self)
    filterObj.VVfT2H(boundFunction(self.VVCPvh, VVrPW4, mode))
 def VVCPvh(self, VVrPW4, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CCydi9()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VV3Ckg(words):
     FFy0Rl(self, processChanName.VVwmN5(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CCYzQV, barTheme=CCYzQV.VVaMkV
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VV10Mq, VVrPW4, mode, title, words, toFind, asPrefix, processChanName)
         , VVzQlc = boundFunction(self.VVefs1, mode, toFind, title))
   else:
    FFy0Rl(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VV10Mq(self, VVrPW4, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVvDFG(VVrPW4.VVyTaM())
  progBarObj.VVvkm4 = []
  for row in VVrPW4.VVPNQS():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVtXQw(1)
   progBarObj.VVdPSC_fromIptvFind(catName)
   qUrl  = self.VV4x5F(mode, self.VV5ueLData["playListURL"], catID)
   txt, err = self.VVwnBY(qUrl)
   if not err:
    tList, err = self.VV4Yqn(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VVPaiT(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VVuRg1:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VVvkm4.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVmYjG:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VVvkm4.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVdXHA:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VVvkm4.append((num, name, catID, ID, genre, catName, ext, cover))
 def VVefs1(self, mode, toFind, title, VVTmBA, VVvkm4, threadCounter, threadTotal, threadErr):
  if VVvkm4:
   title = self.VVCNUz(mode, toFind)
   if mode == self.VVuRg1 or mode == self.VVmYjG:
    if mode == self.VVmYjG : typ = "v"
    else          : typ = ""
    bName   = CCxu1n.VViIz6_forBouquet(toFind)
    VVJAKf  = ("Play"     , boundFunction(self.VV5bA9, mode, False)  , [])
    VVvRGr = ("Download Options" , boundFunction(self.VVmuWM, mode, typ, "") , [])
    VV5m6F = ("Add ALL to Bouquet" , boundFunction(self.VV1eIO, mode, bName) , [])
   elif mode == self.VVdXHA:
    VVJAKf  = ("Show Seasons"  , boundFunction(self.VVg8nv, mode)    , [])
    VV5m6F = None
    VVvRGr = None
   VVnOFk  = (""     , boundFunction(self.VVdMzO, mode)    , [])
   VVv9Eb  = ("Home Menu"   , FFysPJ            , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVwcLv  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVrPW4 = FFeiXT(self, None, title=title, header=header, VVOhES=VVvkm4, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=26, VVJAKf=VVJAKf, VVv9Eb=VVv9Eb, VVvRGr=VVvRGr, VV5m6F=VV5m6F, VVnOFk=VVnOFk, VVOFb6="#0a00292B", VVYfYq="#0a002126", VVMBDz="#0a002126", VVuLsk="#00000000", VVAanx=True, searchCol=1)
   if not VVTmBA:
    FF70nx(VVrPW4, "Stopped" , 1000)
  else:
   if VVTmBA:
    FFy0Rl(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVxBlL(self, mode, colList):
  if mode in (self.VVuRg1, self.VVWR8J):
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVmYjG:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFuz5p(chName)
  url = self.VV5ueLData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVszTs(url)
  refCode = self.VVxJ3z(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVdMzO(self, mode, VVrPW4, title, txt, colList):
  FFTYCg(VVrPW4, boundFunction(self.VVdqSi, mode, VVrPW4, title, txt, colList))
 def VVdqSi(self, mode, VVrPW4, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVxBlL(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFtcRZ(self, fncMode=CCditA.VV8dzp, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VV27I1(self, mode, VVrPW4, title, txt, colList):
  FFTYCg(VVrPW4, boundFunction(self.VVGmtY, mode, VVrPW4, title, txt, colList))
 def VVGmtY(self, mode, VVrPW4, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFtcRZ(self, fncMode=CCditA.VVjDWD, chName=name, text=txt, picUrl=Cover)
 def VV1eIO(self, mode, bName, VVrPW4, title, txt, colList):
  FFTYCg(VVrPW4, boundFunction(self.VVLqJh, mode, bName, VVrPW4, title, txt, colList), title="Adding Channels ...")
 def VVLqJh(self, mode, bName, VVrPW4, title, txt, colList):
  url = self.VV5ueLData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVszTs(url)
  bNameFile = CCxu1n.VViIz6_forBouquet(bName)
  num  = 0
  path = VVyYRZ + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVyYRZ + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVrPW4.VVPNQS():
    chName, chUrl, picUrl, refCode = self.VVxBlL(mode, row)
    f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
    f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
    totChange += 1
  FF6MIz(os.path.basename(path))
  self.VVRArg(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVmuWM(self, mode, typ, seriesName, VVrPW4, title, txt, colList):
  VVH93c = []
  VVH93c.append(("Download all PIcons"       , "dnldPicons" ))
  if typ:
   VVH93c.append(VVxSb7)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVH93c.append(("Download Selected %s" % tName    , "dnldSel"  ))
   VVH93c.append(("Add Selected %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVH93c.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCgcno.VVn4WS():
    VVH93c.append(VVxSb7)
    VVH93c.append(("Download Manager"      , "dload_stat" ))
  FFSEnE(self, boundFunction(self.VVBwCV_VVSMZi, VVrPW4, mode, typ, seriesName, colList), title="Download Options", VVH93c=VVH93c)
 def VVBwCV_VVSMZi(self, VVrPW4, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVLBC2(VVrPW4, mode)
   elif item == "dnldSel"  : self.VVaNPN(VVrPW4, mode, typ, colList, True)
   elif item == "addSel"  : self.VVaNPN(VVrPW4, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVVOlL(VVrPW4, mode, typ, seriesName)
   elif item == "dload_stat" : CCgcno.VVqtop(self)
 def VVaNPN(self, VVrPW4, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVmDv6(mode, typ, colList)
  if startDnld:
   CCgcno.VVlAZa_url(self, decodedUrl)
  else:
   self.VVSMZi_FF3096(VVrPW4, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVVOlL(self, VVrPW4, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVrPW4.VVPNQS():
   chName, decodedUrl = self.VVmDv6(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVSMZi_FF3096(VVrPW4, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVSMZi_FF3096(self, VVrPW4, title, chName, decodedUrl_list, startDnld):
  FF3096(self, boundFunction(self.VV2u3e, VVrPW4, decodedUrl_list, startDnld), chName, title=title)
 def VV2u3e(self, VVrPW4, decodedUrl_list, startDnld):
  added, skipped = CCgcno.VV4cnKList(decodedUrl_list)
  FF70nx(VVrPW4, "Added", 1000)
 def VVmDv6(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVxBlL(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVpnFu(mode, colList)
   refCode, chUrl = self.VV3Msv(self.VVBE6t, self.VV5c3V, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFxIgr(chUrl)
  return chName, decodedUrl
 def VVLBC2(self, VVrPW4, mode):
  if os.system(FFmogf("which ffmpeg")) == 0:
   self.session.open(CCYzQV, barTheme=CCYzQV.VVp06a
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VVi4WO, VVrPW4, mode)
       , VVzQlc = self.VVPJGx)
  else:
   FF3096(self, boundFunction(CCxu1n.VVNAdC, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVPJGx(self, VVTmBA, VVvkm4, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVvkm4["proces"], VVvkm4["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVvkm4["ok"], VVvkm4["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVvkm4["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVvkm4["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVvkm4["badURL"]
  txt += "PIcons Path\t\t: %s\n"    % VVvkm4["path"]
  if not VVTmBA  : color = "#11402000"
  elif VVvkm4["err"]: color = "#11201000"
  else     : color = None
  if VVvkm4["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVvkm4["err"], txt)
  title = "PIcons Download Result"
  if not VVTmBA:
   title += "  (cancelled)"
  FFNGa4(self, txt, title=title, VVMBDz=color)
 def VVi4WO(self, VVrPW4, mode, progBarObj):
  totRows = VVrPW4.VVyTaM()
  progBarObj.VVvDFG(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CCc2Xe.VVDAEE()
  progBarObj.VVvkm4 = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for row in VVrPW4.VVPNQS():
    if progBarObj.isCancelled:
     break
    progBarObj.VVvkm4["proces"] += 1
    progBarObj.VVtXQw(1)
    if mode in ("itv", "vod", "series"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVpnFu(mode, row)
     refCode = CCxu1n.VVxJ3z(catID, stID, chNum)
    else:
     chName, chUrl, picUrl, refCode = self.VVxBlL(mode, row)
    if picUrl:
     picon = refCode.replace(":", "_").rstrip("_") + ".png"
     if not fileExists(pPath + picon):
      progBarObj.VVvkm4["attempt"] += 1
      path, err = FF9cSe(picUrl, picon, timeout=1)
      if path:
       progBarObj.VVvkm4["ok"] += 1
       if FFoME1(path) > 0:
        cmd = ""
        if not mode == CCxu1n.VVuRg1:
         cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
        cmd += FFmogf("mv -f '%s' '%s'" % (path, pPath)) + ";"
        os.system(cmd)
       else:
        progBarObj.VVvkm4["size0"] += 1
        os.system(FFmogf("rm -f '%s'" % path))
      elif err:
       progBarObj.VVvkm4["fail"] += 1
       if any(x in err.lower() for x in ("time-out", "unauthorized")):
        progBarObj.VVvkm4["err"] = err.title()
        break
     else:
      progBarObj.VVvkm4["exist"] += 1
    else:
     progBarObj.VVvkm4["badURL"] += 1
  except:
   pass
 @staticmethod
 def VVNAdC(SELF):
  cmd = FFrD2J(VVzZPa, "ffmpeg")
  if cmd : FFtPYL(SELF, cmd, title="Installing FFmpeg")
  else : FFkPbc(SELF)
 def VVw4t1(self):
  self.session.open(CCYzQV, barTheme=CCYzQV.VVp06a
      , titlePrefix = ""
      , fncToRun  = self.VVSuAL
      , VVzQlc = self.VVRwO5)
 def VVSuAL(self, progBarObj):
  bName = FFvULn()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  progBarObj.VVvkm4 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = FFyRQh()
  if not progBarObj or progBarObj.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   progBarObj.VVvDFG(totCh)
   for serv in services:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVtXQw(1)
    progBarObj.VVdPSC_fromImportEPG(totEpgOK, uChName)
    fullRef  = serv[0]
    if FF9NA0(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFxIgr(fullRef)
     span = iSearch(r"(mode=.+end=)", fullRef, IGNORECASE)
     if span:
      m3u_Url = CCiL8N.VVt1C3(fullRef)
      uType, uHost, uUser, uPass, uId, uChName  = CCxu1n.VVoNlW(fullRef)
      uType, uHost, uUser, uPass, uId, uChName1 = CCxu1n.VVoNlW(m3u_Url)
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCxu1n.VVoNlW(m3u_Url)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCxu1n.VVrdy5(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCditA.VVsZqV(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
      else:
       pass
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if progBarObj:
     progBarObj.VVvkm4 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   progBarObj.VVvkm4 = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VVRwO5(self, VVTmBA, VVvkm4, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVvkm4
  title = "IPTV EPG Import"
  if err:
   FFy0Rl(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFQRKC(str(totNotIptv), VVbvoH)
    if totServErr : txt += "Server Errors\t: %s\n" % FFQRKC(str(totServErr) + t1, VVbvoH)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFQRKC(str(totInv), VVbvoH)
   if not VVTmBA:
    title += "  (stopped)"
   FFNGa4(self, txt, title=title)
 @staticmethod
 def VVrdy5(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCxu1n.VVszTs(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCxu1n.VVwnBY(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCxu1n.VViqrz(item, "description" , is_base64=True ).replace("\n", " .. ")
    has_archive   = CCxu1n.VViqrz(item, "has_archive"      )
    lang    = CCxu1n.VViqrz(item, "lang"        ).upper()
    now_playing   = CCxu1n.VViqrz(item, "now_playing"      )
    start    = CCxu1n.VViqrz(item, "start"        )
    start_timestamp  = CCxu1n.VViqrz(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCxu1n.VViqrz(item, "start_timestamp"     )
    stop_timestamp  = CCxu1n.VViqrz(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCxu1n.VViqrz(item, "stop_timestamp"      )
    tTitle    = CCxu1n.VViqrz(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVxJ3z(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCxu1n.VVvu4B(catID, MAX_4b)
  TSID = CCxu1n.VVvu4B(chNum, MAX_4b)
  ONID = CCxu1n.VVvu4B(chNum, MAX_4b)
  NS  = CCxu1n.VVvu4B(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVvu4B(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VViIz6_forBouquet(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVvSzQ(mode):
  if   mode in ("itv"  , CCxu1n.VVLP44)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCxu1n.VVcTWm)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCxu1n.VVixUj) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCxu1n.VVJ435) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCxu1n.VVWR8J    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 @staticmethod
 def VVTICz():
  path = CFG.iptvHostsPath.getValue()
  if not pathExists(path) or path == VV5FAb: return "/"
  else          : return FFIm0p(path)
 @staticmethod
 def VVm07c(SELF, hostUrl, chName, streamId, ok_fnc):
  title = "Catchup TV Programs"
  pList, err = CCxu1n.VVrdy5(hostUrl, streamId, True)
  if err:
   FFy0Rl(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVOFb6, VVYfYq, VVMBDz, VVuLsk = CCxu1n.VVvSzQ("")
   VVv9Eb = ("Home Menu" , FFysPJ, [])
   VVJAKf  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVwcLv  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFeiXT(SELF, None, title="Programs for : " + chName, header=header, VVOhES=pList, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=24, VVJAKf=VVJAKf, VVv9Eb=VVv9Eb, VVOFb6=VVOFb6, VVYfYq=VVYfYq, VVMBDz=VVMBDz, VVuLsk=VVuLsk)
  else:
   FFy0Rl(SELF, "No Programs from server", title=title)
class CCfNh8(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFvMLn(VVd6Yn, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVi17B  = 0
  self.VVilpd = 1
  self.VVg3Qo  = 2
  VVH93c = []
  VVH93c.append(("Find in All Service (from filter)" , "VV5lnq" ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Find in All (Manual Entry)"   , "VViLpb"    ))
  VVH93c.append(("Find in TV"       , "VVFuDW"    ))
  VVH93c.append(("Find in Radio"      , "VVrfkN"   ))
  if self.VV489q():
   VVH93c.append(VVxSb7)
   VVH93c.append(("Hide Channel: %s" % self.servName , "VVivfb"   ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Zap History"       , "VVcJnz"    ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("IPTV Tools"       , "iptv"      ))
  VVH93c.append(("PIcons Tools"       , "PIconsTools"     ))
  VVH93c.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FFEVgi(self, VVH93c=VVH93c, title=title)
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  FFj85G(self["myMenu"])
  FFsbO6(self)
  if self.isFindMode:
   self.VVT7iT(self.VVvHo9())
 def VVrVKJ(self):
  global VVsMrL
  VVsMrL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VViLpb"    : self.VViLpb()
   elif item == "VV5lnq" : self.VV5lnq()
   elif item == "VVFuDW"    : self.VVFuDW()
   elif item == "VVrfkN"   : self.VVrfkN()
   elif item == "VVivfb"   : self.VVivfb()
   elif item == "VVcJnz"    : self.VVcJnz()
   elif item == "iptv"       : self.session.open(CCxu1n)
   elif item == "PIconsTools"     : self.session.open(CCc2Xe)
   elif item == "ChannelsTools"    : self.session.open(CCoJ8d)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVFuDW(self) : self.VVT7iT(self.VVi17B)
 def VVrfkN(self) : self.VVT7iT(self.VVilpd)
 def VViLpb(self) : self.VVT7iT(self.VVg3Qo)
 def VVT7iT(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFpA7M(self, boundFunction(self.VVigml, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VV5lnq(self):
  filterObj = CCxiMQ(self)
  filterObj.VVfT2H(self.VVTkdx)
 def VVTkdx(self, item):
  self.VVigml(self.VVg3Qo, item)
 def VV489q(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FF9NA0(self.refCode)        : return False
  return True
 def VVigml(self, mode, VVQaWq):
  FFTYCg(self, boundFunction(self.VVV6rR, mode, VVQaWq), title="Searching ...")
 def VVV6rR(self, mode, VVQaWq):
  if VVQaWq:
   self.findTxt = VVQaWq
   if   mode == self.VVi17B  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVilpd : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVQaWq)
   if len(title) > 55:
    title = title[:55] + ".."
   VVYnAG = self.VVBmNY(VVQaWq, servTypes)
   if self.isFindMode or mode == self.VVg3Qo:
    VVYnAG += self.VVepVG(VVQaWq)
   if VVYnAG:
    VVYnAG.sort(key=lambda x: x[0].lower())
    VVFj4L = self.VVM6xU
    VVJAKf  = ("Zap"   , self.VVRTdi    , [])
    VVvRGr = ("Current Service", self.VVrCqG , [])
    VV5m6F = ("Options"  , self.VV8qQ1 , [])
    VVnOFk = (""    , self.VVMwkx , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVwcLv  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFeiXT(self, None, title=title, header=header, VVOhES=VVYnAG, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=26, VVJAKf=VVJAKf, VVFj4L=VVFj4L, VVvRGr=VVvRGr, VV5m6F=VV5m6F, VVnOFk=VVnOFk)
   else:
    self.VVT7iT(self.VVvHo9())
    FFM9af(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVBmNY(self, VVQaWq, servTypes):
  VVwjcZ  = eServiceCenter.getInstance()
  VVYY7F   = '%s ORDER BY name' % servTypes
  VVr4kY   = eServiceReference(VVYY7F)
  VVIq0K = VVwjcZ.list(VVr4kY)
  if VVIq0K: VVOhES = VVIq0K.getContent("CN", False)
  else     : VVOhES = None
  VVYnAG = []
  if VVOhES:
   VV926r, VVvNfE = FFdJvq()
   tp   = CCD09M()
   words, asPrefix = CCxiMQ.VVCW7j(VVQaWq)
   colorYellow  = CCyp6T.VVfxV9(VVllxZ)
   colorWhite  = CCyp6T.VVfxV9(VVbEpi)
   for s in VVOhES:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFpaqk(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VV926r:
        STYPE = VVvNfE[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVRCxv(refCode)
       if not "-S" in syst:
        sat = syst
       VVYnAG.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVYnAG
 def VVepVG(self, VVQaWq):
  VVQaWq = VVQaWq.lower()
  VVtyRo = FFq54s()
  VVYnAG = []
  colorYellow  = CCyp6T.VVfxV9(VVllxZ)
  colorWhite  = CCyp6T.VVfxV9(VVbEpi)
  if VVtyRo:
   for b in VVtyRo:
    VVs172  = b[0]
    VVqb6x  = b[1].toString()
    VV6yNw = eServiceReference(VVqb6x)
    VVFiXm = FFSDRx(VV6yNw)
    for service in VVFiXm:
     refCode  = service[0]
     if FF9NA0(refCode):
      servName = service[1]
      if VVQaWq in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VVQaWq), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VVYnAG.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVYnAG
 def VVvHo9(self):
  VV6K6N = InfoBar.instance
  if VV6K6N:
   VVomKR = VV6K6N.servicelist
   if VVomKR:
    return VVomKR.mode == 1
  return self.VVg3Qo
 def VVM6xU(self, VVrPW4):
  self.close()
  VVrPW4.cancel()
 def VVRTdi(self, VVrPW4, title, txt, colList):
  FFqfoC(VVrPW4, colList[2], VVIPM3=False, checkParentalControl=True)
 def VVrCqG(self, VVrPW4, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(VVrPW4)
  if refCode:
   VVrPW4.VVG4Jh(2, FF3zgs(refCode, iptvRef, chName), True)
 def VV8qQ1(self, VVrPW4, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CCgMGZ(self, VVrPW4, 2)
  mSel.VVQRMb(servName, refCode)
 def VVMwkx(self, VVrPW4, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFtcRZ(self, fncMode=CCditA.VVU6Z9, refCode=refCode, chName=chName, text=txt)
 def VVivfb(self):
  FF3096(self, self.VVs9ik, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVs9ik(self):
  ret = FFNElJ(self.refCode, True)
  if ret:
   self.VVsHR3()
   self.close()
  else:
   FF70nx(self, "Cannot change state" , 1000)
 def VVsHR3(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VV4zOe()
  except:
   self.VVluwQ()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFpY3C(self, serviceRef)
 def VV4ZRA(self):
  VV6K6N = InfoBar.instance
  if VV6K6N:
   VVomKR = VV6K6N.servicelist
   if VVomKR:
    VVomKR.setMode()
 def VV4zOe(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VV6K6N = InfoBar.instance
   if VV6K6N:
    VVomKR = VV6K6N.servicelist
    if VVomKR:
     hList = VVomKR.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVomKR.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVomKR.history  = newList
       VVomKR.history_pos = pos
 def VVluwQ(self):
  VV6K6N = InfoBar.instance
  if VV6K6N:
   VVomKR = VV6K6N.servicelist
   if VVomKR:
    VVomKR.history  = []
    VVomKR.history_pos = 0
 def VVcJnz(self):
  VV6K6N = InfoBar.instance
  VVYnAG = []
  if VV6K6N:
   VVomKR = VV6K6N.servicelist
   if VVomKR:
    VV926r, VVvNfE = FFdJvq()
    for chParams in VVomKR.history:
     refCode = chParams[-1].toString()
     chName = FFdST5(refCode)
     isIptv = FF9NA0(refCode)
     if isIptv: sat = "-"
     else  : sat = FFpaqk(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VV926r:
       STYPE = VVvNfE[sTypeInt]
     VVYnAG.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVYnAG:
   VVJAKf  = ("Zap"   , self.VV6B2A   , [])
   VV5m6F = ("Clear History" , self.VVDdAe   , [])
   VVnOFk = (""    , self.VVDBi9FromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVwcLv  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFeiXT(self, None, title=title, header=header, VVOhES=VVYnAG, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=28, VVJAKf=VVJAKf, VV5m6F=VV5m6F, VVnOFk=VVnOFk)
  else:
   FFM9af(self, "Not found", title=title)
 def VV6B2A(self, VVrPW4, title, txt, colList):
  FFqfoC(VVrPW4, colList[3], VVIPM3=False, checkParentalControl=True)
 def VVDdAe(self, VVrPW4, title, txt, colList):
  FF3096(self, boundFunction(self.VVW9kN, VVrPW4), "Clear Zap History ?")
 def VVW9kN(self, VVrPW4):
  self.VVluwQ()
  VVrPW4.cancel()
 def VVDBi9FromZapHistory(self, VVrPW4, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFtcRZ(self, fncMode=CCditA.VVGsdV, refCode=refCode, chName=chName, text=txt)
class CCc2Xe(Screen):
 VVKEfG   = 0
 VVytIL  = 1
 VVoYH1  = 2
 VVuDIT  = 3
 VV2u5G  = 4
 VVAJRW  = 5
 VVWYHa  = 6
 VVcH4L  = 7
 VVYsmd = 8
 VVafQr = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFvMLn(VVZeZP, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFEVgi(self, self.Title)
  FFUxNa(self["keyRed"] , "OK = Zap")
  FFUxNa(self["keyGreen"] , "Current Service")
  FFUxNa(self["keyYellow"], "Page Options")
  FFUxNa(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCc2Xe.VVDAEE()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVOhES    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV5cui        ,
   "green"   : self.VVTvul       ,
   "yellow"  : self.VVsXc5        ,
   "blue"   : self.VVTOhz        ,
   "menu"   : self.VVf22V        ,
   "info"   : self.VVDBi9         ,
   "up"   : self.VV95Cz          ,
   "down"   : self.VVgVbh         ,
   "left"   : self.VV1LAe         ,
   "right"   : self.VVMG16         ,
   "pageUp"  : boundFunction(self.VVb4wA, True) ,
   "chanUp"  : boundFunction(self.VVb4wA, True) ,
   "pageDown"  : boundFunction(self.VVb4wA, False) ,
   "chanDown"  : boundFunction(self.VVb4wA, False) ,
   "next"   : self.VVLCGG        ,
   "last"   : self.VViiFO         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  FFUVmx(self)
  FFcxMz(self)
  FFAt0z(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFTYCg(self, boundFunction(self.VVDG9g, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVf22V(self):
  if not self.isBusy:
   VVH93c = []
   VVH93c.append(("Statistics"           , "VVkbSO"    ))
   VVH93c.append(VVxSb7)
   VVH93c.append(("Suggest PIcons for Current Channel"     , "VVqCSU"   ))
   VVH93c.append(("Set to Current Channel (copy file)"     , "VVvHem_file"  ))
   VVH93c.append(("Set to Current Channel (as SymLink)"     , "VVvHem_link"  ))
   VVH93c.append(VVxSb7)
   VVH93c.append(CCc2Xe.VVWiYg())
   VVH93c.append(VVxSb7)
   if self.filterTitle == "PIcons without Channels":
    c = VVbvoH
    VVH93c.append((FFQRKC("Move Unused PIcons to a Directory", c) , "VV92af"  ))
    VVH93c.append((FFQRKC("DELETE Unused PIcons", c)    , "VVoaN3" ))
    VVH93c.append(VVxSb7)
   VVH93c.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVCiQO"  ))
   VVH93c.append(VVxSb7)
   VVH93c += CCc2Xe.VVx2U7()
   VVH93c.append(VVxSb7)
   VVH93c.append(("RCU Keys Help"          , "VVoNZL"    ))
   FFSEnE(self, self.VVBwCV, title=self.Title, VVH93c=VVH93c)
 def VVBwCV(self, item=None):
  if item is not None:
   if   item == "VVkbSO"     : self.VVkbSO()
   elif item == "VVqCSU"    : self.VVqCSU()
   elif item == "VVvHem_file"   : self.VVvHem(0)
   elif item == "VVvHem_link"   : self.VVvHem(1)
   elif item == "VVTjDf_file"  : self.VVTjDf(0)
   elif item == "VVTjDf_link"  : self.VVTjDf(1)
   elif item == "VVCEqU"   : self.VVCEqU()
   elif item == "VVVnDs"  : self.VVVnDs()
   elif item == "VV92af"    : self.VV92af()
   elif item == "VVoaN3"   : self.VVoaN3()
   elif item == "VVCiQO"   : self.VVCiQO()
   elif item == "VVYdVI"   : CCc2Xe.VVYdVI(self)
   elif item == "VVxj3t"   : CCc2Xe.VVxj3t(self)
   elif item == "findPiconBrokenSymLinks"  : CCc2Xe.VV7va1(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCc2Xe.VV7va1(self, False)
   elif item == "VVoNZL"      : self.VVoNZL()
 def VVsXc5(self):
  if not self.isBusy:
   VVH93c = []
   VVH93c.append(("Go to First PIcon"  , "VVFazn"  ))
   VVH93c.append(("Go to Last PIcon"   , "VVGL8O"  ))
   VVH93c.append(VVxSb7)
   VVH93c.append(("Sort by Channel Name"     , "sortByChan" ))
   VVH93c.append(("Sort by File Name"  , "sortByFile" ))
   VVH93c.append(VVxSb7)
   VVH93c.append(("Find from File List .." , "VVAJhG" ))
   FFSEnE(self, self.VVFDpz, title=self.Title, VVH93c=VVH93c)
 def VVFDpz(self, item=None):
  if item is not None:
   if   item == "VVFazn"   : self.VVFazn()
   elif item == "VVGL8O"   : self.VVGL8O()
   elif item == "sortByChan"  : self.VVUVj0(2)
   elif item == "sortByFile"  : self.VVUVj0(0)
   elif item == "VVAJhG"  : self.VVAJhG()
 def VVoNZL(self):
  FFoJme(self, VVHIBy + "_help_picons", "PIcons Manager (Keys Help)")
 def VV95Cz(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVGL8O()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVEYXB()
 def VVgVbh(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVFazn()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVEYXB()
 def VV1LAe(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVGL8O()
  else:
   self.curCol -= 1
   self.VVEYXB()
 def VVMG16(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVFazn()
  else:
   self.curCol += 1
   self.VVEYXB()
 def VViiFO(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVEYXB(True)
 def VVLCGG(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVEYXB(True)
 def VVFazn(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVEYXB(True)
 def VVGL8O(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVEYXB(True)
 def VVAJhG(self):
  VVH93c = []
  for item in self.VVOhES:
   VVH93c.append((item[0], item[0]))
  FFSEnE(self, self.VV6Xuf, title='PIcons ".png" Files', VVH93c=VVH93c, VVjijr=True)
 def VV6Xuf(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VV8Rx9(ndx)
 def VV5cui(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVxg2x()
   if refCode:
    FFqfoC(self, refCode)
    self.VVYw9H()
    self.VV1jyq()
 def VVb4wA(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVYw9H()
   self.VV1jyq()
  except:
   pass
 def VVTvul(self):
  if self["keyGreen"].getVisible():
   self.VV8Rx9(self.curChanIndex)
 def VV8Rx9(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVEYXB(True)
  else:
   FF70nx(self, "Not found", 1000)
 def VVUVj0(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFTYCg(self, boundFunction(self.VVDG9g, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVvHem(self, mode):
  title = "Change Current Channel PIcon"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVxg2x()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVH93c = []
     VVH93c.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVH93c.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFSEnE(self, boundFunction(self.VVRwVB, mode, curChF, selPiconF), VVH93c=VVH93c, title="Current Channel PIcon (already exists)")
    else:
     self.VVRwVB(mode, curChF, selPiconF, "overwrite")
   else:
    FFy0Rl(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFy0Rl(self, "Could not read current channel info. !", title=title)
 def VVRwVB(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFTYCg(self, boundFunction(self.VVDG9g, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVTjDf(self, mode):
  pass
 def VVCEqU(self):
  pass
 def VVVnDs(self):
  pass
 def VV92af(self):
  defDir = FFIm0p(CCc2Xe.VVDAEE() + "picons_backup")
  os.system(FFmogf("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(boundFunction(self.VVw8RH, defDir), boundFunction(CCw1Kh
         , mode=CCw1Kh.VVhLeF, VVLZO1=CCc2Xe.VVDAEE()))
 def VVw8RH(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCc2Xe.VVDAEE():
    FFy0Rl(self, "Cannot move to same directory !", title=title)
   else:
    if not FFIm0p(path) == FFIm0p(defDir):
     self.VV8x08(defDir)
    FF3096(self, boundFunction(FFTYCg, self, boundFunction(self.VVOau6, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVOhES), path), title=title)
  else:
   self.VV8x08(defDir)
 def VVOau6(self, title, defDir, toPath):
  try:
   from shutil import move as iMove
  except:
   self.VV8x08(defDir)
   FFy0Rl(self, 'Could not load "shutil" module !', title=title)
   return
  toPath = FFIm0p(toPath)
  pPath = CCc2Xe.VVDAEE()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVOhES:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVOhES)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFNGa4(self, txt, title=title, VVMBDz="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVP1g9("all")
 def VV8x08(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVoaN3(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVOhES)
  s = "s" if tot > 1 else ""
  FF3096(self, boundFunction(FFTYCg, self, boundFunction(self.VV8pfA, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, s), title=title)
 def VV8pfA(self, title):
  pPath = CCc2Xe.VVDAEE()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVOhES:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVOhES)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFQRKC(str(totErr), VVbvoH)
  FFNGa4(self, txt, title=title)
 def VVCiQO(self):
  lines = FF8QLc("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FF3096(self, boundFunction(self.VVdxsO, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVZH0D=True)
  else:
   FFM9af(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVdxsO(self, fList):
  os.system(FFmogf("find -L '%s' -type l -delete" % self.pPath))
  FFM9af(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVDBi9(self):
  FFTYCg(self, self.VVegiI)
 def VVegiI(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVxg2x()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFQRKC("PIcon Directory:\n", VVq6Xr)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FF6jLD(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FF6jLD(path)
   txt += FFQRKC("PIcon File:\n", VVq6Xr)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FF8QLc(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFQRKC("Found %d SymLink%s to this file from:\n" % (tot, s), VVq6Xr)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFdST5(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFQRKC(tChName, VVoiSL)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFQRKC(line, VVIbxt), tChName)
    txt += "\n"
   if chName:
    txt += FFQRKC("Channel:\n", VVq6Xr)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFQRKC(chName, VVoiSL)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFQRKC("Remarks:\n", VVq6Xr)
    txt += "  %s\n" % FFQRKC("Unused", VVbvoH)
  else:
   txt = "No info found"
  FFtcRZ(self, fncMode=CCditA.VVSPbK, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVxg2x(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVOhES[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFovAP(sat)
  return fName, refCode, chName, sat, inDB
 def VVYw9H(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVOhES):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VV1jyq(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVxg2x()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFQRKC("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVq6Xr))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVxg2x()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFQRKC(self.curChanName, VVllxZ)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVkbSO(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VVOhES:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFCdzs("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFNGa4(self, txt, title=self.Title)
 def VVTOhz(self):
  if not self.isBusy:
   VVH93c = []
   VVH93c.append(("All"         , "all"   ))
   VVH93c.append(VVxSb7)
   VVH93c.append(("Used by Channels"      , "used"  ))
   VVH93c.append(("Unused PIcons"      , "unused"  ))
   VVH93c.append(VVxSb7)
   VVH93c.append(("PIcons Files"       , "pFiles"  ))
   VVH93c.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVH93c.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVH93c.append(VVxSb7)
   VVH93c.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVH93c.append(VVxSb7)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFp4Mi(val)
      VVH93c.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCxiMQ(self)
   filterObj.VVXtzW(VVH93c, self.nsList, self.VVTMXp)
 def VVTMXp(self, item=None):
  if item is not None:
   self.VVP1g9(item)
 def VVP1g9(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVKEfG   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVytIL   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVoYH1  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVuDIT  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VV2u5G  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVAJRW  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVWYHa   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVcH4L   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVYsmd , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVAJRW:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FF8QLc("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FF70nx(self, "Not found", 1000)
     return
   elif mode == self.VVafQr:
    return
   else:
    words, asPrefix = CCxiMQ.VVCW7j(words)
   if not words and mode in (self.VVcH4L, self.VVYsmd):
    FF70nx(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFTYCg(self, boundFunction(self.VVDG9g, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVqCSU(self):
  self.session.open(CCYzQV, barTheme=CCYzQV.VVaMkV
      , titlePrefix = ""
      , fncToRun  = self.VVba89
      , VVzQlc = self.VVkSOD)
 def VVba89(self, progBarObj):
  lameDbChans = CCoJ8d.VVEJIr(self, CCoJ8d.VVYINn, VVU9Vj=False, VVDPmC=False)
  files = []
  words = []
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVvkm4 = []
  progBarObj.VVvDFG(len(lameDbChans))
  if lameDbChans:
   processChanName = CCydi9()
   curCh = processChanName.VVTrFW(self.curChanName)
   for refCode in lameDbChans:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVtXQw(1, True)
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCc2Xe.VVBQIn(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCc2Xe.VVaF4R(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       progBarObj.VVvkm4.append(f.replace(".png", ""))
 def VVkSOD(self, VVTmBA, VVvkm4, threadCounter, threadTotal, threadErr):
  if VVvkm4:
   self.timer = eTimer()
   fnc = boundFunction(FFTYCg, self, boundFunction(self.VVDG9g, mode=self.VVafQr, words=VVvkm4), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FF70nx(self, "Not found", 2000)
 def VVDG9g(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVEFVJ(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCoJ8d.VVEJIr(self, CCoJ8d.VVYINn, VVU9Vj=False, VVDPmC=False)
  iptvRefList = self.VVyGYf()
  tList = []
  for fName, fType in CCc2Xe.VVvfy6(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVKEfG:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVytIL  and chName         : isAdd = True
   elif mode == self.VVoYH1 and not chName        : isAdd = True
   elif mode == self.VVuDIT  and fType == 0        : isAdd = True
   elif mode == self.VV2u5G  and fType == 1        : isAdd = True
   elif mode == self.VVAJRW  and fName in words       : isAdd = True
   elif mode == self.VVafQr and fName in words       : isAdd = True
   elif mode == self.VVWYHa  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVcH4L  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVYsmd:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVOhES   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FF70nx(self)
  else:
   self.isBusy = False
   FF70nx(self, "Not found", 1000)
   return
  self.VVOhES.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVYw9H()
  self.totalPIcons = len(self.VVOhES)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVEYXB(True)
 def VVEFVJ(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCc2Xe.VVvfy6(self.pPath):
    if fName:
     return True
   if isFirstTime : FFy0Rl(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FF70nx(self, "Not found", 1000)
  else:
   FFy0Rl(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVyGYf(self):
  VVYnAG = {}
  files  = CCxu1n.VVoYPl(self)
  if files:
   for path in files:
    txt = FF1gqL(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVYnAG[refCode] = item[1]
  return VVYnAG
 def VVEYXB(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVgtR0 = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVgtR0: self.curPage = VVgtR0
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVhD9J()
  if self.curPage == VVgtR0:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VV1jyq()
  filName, refCode, chName, sat, inDB = self.VVxg2x()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVhD9J(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVOhES[ndx]
   fName = self.VVOhES[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFQRKC(chName, VVoiSL))
    else : lbl.setText("-")
   except:
    lbl.setText(FFQRKC(chName, VV0P8J))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVBQIn(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVWiYg():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVYdVI"   )
 @staticmethod
 def VVx2U7():
  VVH93c = []
  VVH93c.append(("Find SymLinks (to PIcon Directory)"   , "VVxj3t"   ))
  VVH93c.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVH93c.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVH93c
 @staticmethod
 def VVYdVI(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(SELF)
  png, path = CCc2Xe.VV4353(refCode)
  if path : CCc2Xe.VVJyjp(SELF, png, path)
  else : FFy0Rl(SELF, "No PIcon found for current channel in:\n\n%s" % CCc2Xe.VVDAEE())
 @staticmethod
 def VVxj3t(SELF):
  if VVllxZ:
   sed1 = FFa6r1("->", VVllxZ)
   sed2 = FFa6r1("picon", VVbvoH)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VV0P8J, VVbEpi)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFYoKS(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFJQpq(), grep, sed1, sed2, sed3))
 @staticmethod
 def VV7va1(SELF, isPIcon):
  sed1 = FFa6r1("->", VV0P8J)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFa6r1("picon", VVbvoH)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFYoKS(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFJQpq(), grep, sed1, sed2))
 @staticmethod
 def VVvfy6(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVDAEE():
  path = CFG.PIconsPath.getValue()
  return FFIm0p(path)
 @staticmethod
 def VV4353(refCode, chName=None):
  if FF9NA0(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFxIgr(refCode)
  allPath, fName, refCodeFile, pList = CCc2Xe.VVaF4R(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVJyjp(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFa6r1("%s%s" % (dest, png), VVoiSL))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFa6r1(errTxt, VVo2ZM))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FF4bPN(SELF, cmd)
 @staticmethod
 def VVaF4R(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCc2Xe.VVDAEE()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFuz5p(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCmDnr():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VV2kXC  = None
  self.VVsM8n = ""
  self.VVbShY  = noService
  self.VVxaI9 = 0
  self.VVHSXS  = noService
  self.VVxDJ3 = 0
  self.VVsURl  = "-"
  self.VVaW6M = 0
  self.VVK6cg  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVYQsN(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VV2kXC = frontEndStatus
     self.VVw7VA()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVw7VA(self):
  if self.VV2kXC:
   val = self.VV2kXC.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVsM8n = "%3.02f dB" % (val / 100.0)
   else         : self.VVsM8n = ""
   val = self.VV2kXC.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVxaI9 = int(val)
   self.VVbShY  = "%d%%" % val
   val = self.VV2kXC.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVxDJ3 = int(val)
   self.VVHSXS  = "%d%%" % val
   val = self.VV2kXC.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVsURl  = "%d" % val
   val = int(val * 100 / 500)
   self.VVaW6M = min(500, val)
   val = self.VV2kXC.get("tuner_locked", 0)
   if val == 1 : self.VVK6cg = "Locked"
   else  : self.VVK6cg = "Not locked"
 def VVQBXa(self)   : return self.VVsM8n
 def VVnSTK(self)   : return self.VVbShY
 def VVkQXY(self)  : return self.VVxaI9
 def VVsAY1(self)   : return self.VVHSXS
 def VVjMDT(self)  : return self.VVxDJ3
 def VVuXyV(self)   : return self.VVsURl
 def VV3F6n(self)  : return self.VVaW6M
 def VVj7q6(self)   : return self.VVK6cg
 def VVRee8(self) : return self.serviceName
class CCD09M():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVvhiG(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFzGKJ(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVyaEk(self.ORPOS  , mod=1   )
      self.sat2  = self.VVyaEk(self.ORPOS  , mod=2   )
      self.freq  = self.VVyaEk(self.FREQ  , mod=3   )
      self.sr   = self.VVyaEk(self.SR   , mod=4   )
      self.inv  = self.VVyaEk(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVyaEk(self.POL  , self.D_POL )
      self.fec  = self.VVyaEk(self.FEC  , self.D_FEC )
      self.syst  = self.VVyaEk(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVyaEk("modulation" , self.D_MOD )
       self.rolof = self.VVyaEk("rolloff"  , self.D_ROLOF )
       self.pil = self.VVyaEk("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVyaEk("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVyaEk("pls_code"  )
       self.iStId = self.VVyaEk("is_id"   )
       self.t2PlId = self.VVyaEk("t2mi_plp_id" )
       self.t2PId = self.VVyaEk("t2mi_pid"  )
 def VVyaEk(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFp4Mi(val)
  elif mod == 2   : return FFB3KB(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVwoQB(self, refCode):
  txt = ""
  self.VVvhiG(refCode)
  if self.data:
   def VVQGQz(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVQGQz("System"   , self.syst)
    txt += VVQGQz("Satellite"  , self.sat2)
    txt += VVQGQz("Frequency"  , self.freq)
    txt += VVQGQz("Inversion"  , self.inv)
    txt += VVQGQz("Symbol Rate"  , self.sr)
    txt += VVQGQz("Polarization" , self.pol)
    txt += VVQGQz("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVQGQz("Modulation" , self.mod)
     txt += VVQGQz("Roll-Off" , self.rolof)
     txt += VVQGQz("Pilot"  , self.pil)
     txt += VVQGQz("Input Stream", self.iStId)
     txt += VVQGQz("T2MI PLP ID" , self.t2PlId)
     txt += VVQGQz("T2MI PID" , self.t2PId)
     txt += VVQGQz("PLS Mode" , self.plsMod)
     txt += VVQGQz("PLS Code" , self.plsCod)
   else:
    txt += VVQGQz("System"   , self.txMedia)
    txt += VVQGQz("Frequency"  , self.freq)
  return txt, self.namespace
 def VV7a1f(self, refCode):
  txt = "Transpoder : ?"
  self.VVvhiG(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VVq6Xr + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVRCxv(self, refCode):
  self.data = None
  servRef = eServiceReference(refCode)
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFzGKJ(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVyaEk(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVyaEk(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVyaEk(self.SYST, self.D_SYS_S)
     freq = self.VVyaEk(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVyaEk(self.POL , self.D_POL)
      fec = self.VVyaEk(self.FEC , self.D_FEC)
      sr = self.VVyaEk(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVvjlJ(self, refCode):
  self.data = None
  self.VVvhiG(refCode)
  if self.data and self.freq : return True
  else      : return False
class CC6xEh():
 def __init__(self, VV5VNh, path, VVzQlc=None, curRowNum=-1):
  self.VV5VNh  = VV5VNh
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVzQlc  = VVzQlc
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFmogf("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVxlmC(curRowNum)
  else:
   FFy0Rl(self.VV5VNh, "Error while preparing edit!")
 def VVxlmC(self, curRowNum):
  VVYnAG = self.VVb1j5()
  VVv9Eb = None #("Delete Line" , self.deleteLine  , [])
  VVvRGr = ("Save Changes" , self.VVhs88   , [])
  VVJAKf  = ("Edit Line"  , self.VV28iJ    , [])
  VVx5V8 = ("Line Options" , self.VV3qbc   , [])
  VVS0Uh = (""    , self.VVINQa , [])
  VVFj4L = self.VVUhIQ
  VVBpTW  = self.VVy2rz
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVwcLv  = (CENTER  , LEFT  )
  VVrPW4 = FFeiXT(self.VV5VNh, None, title=self.Title, header=header, VVOhES=VVYnAG, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=26, VVv9Eb=VVv9Eb, VVvRGr=VVvRGr, VVJAKf=VVJAKf, VVx5V8=VVx5V8, VVFj4L=VVFj4L, VVBpTW=VVBpTW, VVS0Uh=VVS0Uh, VVAanx=True
    , VVOFb6   = "#11001111"
    , VVYfYq   = "#11001111"
    , VVMBDz   = "#11001111"
    , VVuLsk  = "#05333333"
    , VVCiIJ  = "#00222222"
    , VViPgN  = "#11331133"
    )
  VVrPW4.VV5ETD(curRowNum)
 def VV3qbc(self, VVrPW4, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVrPW4.VVFWie()
  VVH93c = []
  VVH93c.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVH93c.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVv0Dx"  ))
  VVH93c.append(VVxSb7)
  VVH93c.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVCYgA:
   VVH93c.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVH93c.append(VVxSb7)
  VVH93c.append(  ("Delete Line"         , "deleteLine"   ))
  FFSEnE(self.VV5VNh, boundFunction(self.VVtaik, VVrPW4, lineNum), VVH93c=VVH93c, title="Line Options")
 def VVtaik(self, VVrPW4, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVOupo("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVrPW4)
   elif item == "VVv0Dx"  : self.VVv0Dx(VVrPW4, lineNum)
   elif item == "copyToClipboard"  : self.VVZQOt(VVrPW4, lineNum)
   elif item == "pasteFromClipboard" : self.VV7jO0(VVrPW4, lineNum)
   elif item == "deleteLine"   : self.VVOupo("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVrPW4)
 def VVy2rz(self, VVrPW4):
  VVrPW4.VVd3gr()
 def VVINQa(self, VVrPW4, title, txt, colList):
  if   self.insertMode == 1: VVrPW4.VV3XlJ()
  elif self.insertMode == 2: VVrPW4.VVxsxd()
  self.insertMode = 0
 def VVv0Dx(self, VVrPW4, lineNum):
  if lineNum == VVrPW4.VVFWie():
   self.insertMode = 1
   self.VVOupo("echo '' >> '%s'" % self.tmpFile, VVrPW4)
  else:
   self.insertMode = 2
   self.VVOupo("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVrPW4)
 def VVZQOt(self, VVrPW4, lineNum):
  global VVCYgA
  VVCYgA = FFCdzs("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVrPW4.VVjBbc("Copied to clipboard")
 def VVhs88(self, VVrPW4, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFmogf("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFmogf("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVrPW4.VVjBbc("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVrPW4.VVd3gr()
    else:
     FFy0Rl(self.VV5VNh, "Cannot save file!")
   else:
    FFy0Rl(self.VV5VNh, "Cannot create backup copy of original file!")
 def VVUhIQ(self, VVrPW4):
  if self.fileChanged:
   FF3096(self.VV5VNh, boundFunction(self.VVWeOP, VVrPW4), "Cancel changes ?")
  else:
   finalOK = os.system(FFmogf("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVWeOP(VVrPW4)
 def VVWeOP(self, VVrPW4):
  VVrPW4.cancel()
  os.system(FFmogf("rm -f '%s'" % self.tmpFile))
  if self.VVzQlc:
   self.VVzQlc(self.fileSaved)
 def VV28iJ(self, VVrPW4, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVbEpi + "ORIGINAL TEXT:\n" + VVIbxt + lineTxt
  FFpA7M(self.VV5VNh, boundFunction(self.VVc755, lineNum, VVrPW4), title="File Line", defaultText=lineTxt, message=message)
 def VVc755(self, lineNum, VVrPW4, VVNEJF):
  if not VVNEJF is None:
   if VVrPW4.VVFWie() <= 1:
    self.VVOupo("echo %s > '%s'" % (VVNEJF, self.tmpFile), VVrPW4)
   else:
    self.VVSnvf(VVrPW4, lineNum, VVNEJF)
 def VV7jO0(self, VVrPW4, lineNum):
  if lineNum == VVrPW4.VVFWie() and VVrPW4.VVFWie() == 1:
   self.VVOupo("echo %s >> '%s'" % (VVCYgA, self.tmpFile), VVrPW4)
  else:
   self.VVSnvf(VVrPW4, lineNum, VVCYgA)
 def VVSnvf(self, VVrPW4, lineNum, newTxt):
  VVrPW4.VVSUEO("Saving ...")
  lines = FFxHei(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVrPW4.VVijfm()
  VVYnAG = self.VVb1j5()
  VVrPW4.VVH1wF(VVYnAG)
 def VVOupo(self, cmd, VVrPW4):
  tCons = CC9sFI()
  tCons.ePopen(cmd, boundFunction(self.VVIksH, VVrPW4))
  self.fileChanged = True
  VVrPW4.VVijfm()
 def VVIksH(self, VVrPW4, result, retval):
  VVYnAG = self.VVb1j5()
  VVrPW4.VVH1wF(VVYnAG)
 def VVb1j5(self):
  if fileExists(self.tmpFile):
   lines = FFxHei(self.tmpFile)
   VVYnAG = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVYnAG.append((str(ndx), line.strip()))
   if not VVYnAG:
    VVYnAG.append((str(1), ""))
   return VVYnAG
  else:
   FFZZL8(self.VV5VNh, self.tmpFile)
class CCxiMQ():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVH93c   = []
  self.satList   = []
 def VVfT2H(self, VVzQlc):
  self.VVH93c = []
  VVH93c, VVZZgM = self.VV9E2x(False, True)
  if VVH93c:
   self.VVH93c += VVH93c
   self.VVeEJZ(VVzQlc, VVZZgM)
 def VVvyHH(self, mode, VVrPW4, satCol, VVzQlc):
  VVrPW4.VVSUEO("Loading Filters ...")
  self.VVH93c = []
  self.VVH93c.append(("All Services" , "all"))
  if mode == 1:
   self.VVH93c.append(VVxSb7)
   self.VVH93c.append(("Parental Control", "parentalControl"))
   self.VVH93c.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVH93c.append(VVxSb7)
   self.VVH93c.append(("Selected Transponder"   , "selectedTP" ))
   self.VVH93c.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VV4oRw(VVrPW4, satCol)
  VVH93c, VVZZgM = self.VV9E2x(True, False)
  if VVH93c:
   VVH93c.insert(0, VVxSb7)
   self.VVH93c += VVH93c
  VVrPW4.VVztP3()
  self.VVeEJZ(VVzQlc, VVZZgM)
 def VVXtzW(self, VVH93c, sats, VVzQlc):
  self.VVH93c = VVH93c
  VVH93c, VVZZgM = self.VV9E2x(True, False)
  if VVH93c:
   self.VVH93c.append(VVxSb7)
   self.VVH93c += VVH93c
  self.VVeEJZ(VVzQlc, VVZZgM)
 def VVZv4q(self, VVH93c, sats, VVzQlc):
  self.VVH93c = VVH93c
  VVH93c, VVZZgM = self.VV9E2x(True, False)
  if VVH93c:
   self.VVH93c.append(VVxSb7)
   self.VVH93c += VVH93c
  self.VVeEJZ(VVzQlc, VVZZgM)
 def VVeEJZ(self, VVzQlc, VVZZgM):
  VVSptY = ("Edit Filter", boundFunction(self.VVSfBm, VVZZgM))
  VVM3vl  = ("Filter Help", boundFunction(self.VVUEMu, VVZZgM))
  FFSEnE(self.callingSELF, boundFunction(self.VVcgPE, VVzQlc), VVH93c=self.VVH93c, title="Select Filter", VVSptY=VVSptY, VVM3vl=VVM3vl)
 def VVcgPE(self, VVzQlc, item):
  if item:
   VVzQlc(item)
 def VVSfBm(self, VVZZgM, VVzEsrObj, sel):
  if fileExists(VVZZgM) : CC6xEh(self.callingSELF, VVZZgM, VVzQlc=None)
  else       : FFZZL8(self.callingSELF, VVZZgM)
  VVzEsrObj.cancel()
 def VVUEMu(self, VVZZgM, VVzEsrObj, sel):
  FFoJme(self.callingSELF, VVHIBy + "_help_service_filter", "Service Filter")
 def VV4oRw(self, VVrPW4, satColNum):
  if not self.satList:
   satList = VVrPW4.VVePxH(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFovAP(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VVxSb7)
  if self.VVH93c:
   self.VVH93c += self.satList
 def VV9E2x(self, addTag, VVkUjI):
  FFGAvG()
  fileName  = "ajpanel_services_filter"
  VVZZgM = VVBgPY + fileName
  VVH93c  = []
  if not fileExists(VVZZgM):
   os.system(FFmogf("cp -f '%s' '%s'" % (VVHIBy + fileName, VVZZgM)))
  fileFound = False
  if fileExists(VVZZgM):
   fileFound = True
   lines = FFxHei(VVZZgM)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVH93c.append((line, "__w__" + line))
       else  : VVH93c.append((line, line))
  if VVkUjI:
   if   not fileFound : FFZZL8(self.callingSELF , VVZZgM)
   elif not VVH93c : FFk2jj(self.callingSELF , VVZZgM)
  return VVH93c, VVZZgM
 @staticmethod
 def VVCW7j(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CCgMGZ():
 def __init__(self, callingSELF, VVrPW4, refCodeColNum):
  self.callingSELF = callingSELF
  self.VVrPW4 = VVrPW4
  self.refCodeColNum = refCodeColNum
  self.VVH93c = []
  iMulSel = self.VVrPW4.VV8Wu1()
  if iMulSel : self.VVH93c.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVH93c.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVrPW4.VVXZ7c()
  self.VVH93c.append(    ("Select all"    , "selectAll"  ))
  if tot > 0:
   self.VVH93c.append(   ("Unselect all"    , "unselectAll"  ))
  self.VVH93c.append(VVxSb7)
 def VVQRMb(self, servName, refCode):
  tot = self.VVrPW4.VVXZ7c()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVH93c.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VV55LF_multi" ))
  else    : self.VVH93c.append( ("Add to Bouquet : %s"      % servName , "VV55LF_one" ))
  self.VVkgK4(servName, refCode)
 def VVyR3I(self, servName, refCode, pcState, hidState):
  self.VVH93c = []
  if pcState == "No" : self.VVH93c.append(("Add to Parental Control"  , "parentalControl_add"  ))
  else    : self.VVH93c.append(("Remove from Parental Control" , "parentalControl_remove" ))
  if hidState == "No" : self.VVH93c.append(("Add to Hidden Services"  , "hiddenServices_add"  ))
  else    : self.VVH93c.append(("Remove from Hidden Services" , "hiddenServices_remove" ))
  self.VVkgK4(servName, refCode)
 def VVkgK4(self, servName, refCode):
  FFSEnE(self.callingSELF, boundFunction(self.VVBtxK, servName, refCode), title="Options", VVH93c=self.VVH93c)
 def VVBtxK(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"    : self.VVrPW4.VVggAY(True)
   elif item == "MultSelDisab"    : self.VVrPW4.VVggAY(False)
   elif item == "selectAll"    : self.VVrPW4.VVGeom()
   elif item == "unselectAll"    : self.VVrPW4.VV8Dkw()
   elif item == "parentalControl_add"  : self.callingSELF.VVlJlv(self.VVrPW4, refCode, True)
   elif item == "parentalControl_remove" : self.callingSELF.VVlJlv(self.VVrPW4, refCode, False)
   elif item == "hiddenServices_add"  : self.callingSELF.VVQVjy(self.VVrPW4, refCode, True)
   elif item == "hiddenServices_remove" : self.callingSELF.VVQVjy(self.VVrPW4, refCode, False)
   elif item == "VV55LF_multi" : self.VV55LF(refCode, True)
   elif item == "VV55LF_one" : self.VV55LF(refCode, False)
 def VV55LF(self, refCode, isMulti):
  bouquets = FFq54s()
  if bouquets:
   VVH93c = []
   for item in bouquets:
    VVH93c.append((item[0], item[1].toString()))
   VVSptY = ("Create New", boundFunction(self.VVgd3m, refCode, isMulti))
   FFSEnE(self.callingSELF, boundFunction(self.VVqu3J, refCode, isMulti), VVH93c=VVH93c, title="Add to Bouquet", VVSptY=VVSptY, VVjijr=True, VVcKlq=True)
  else:
   FF3096(self.callingSELF, boundFunction(self.VVqF1i, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVqu3J(self, refCode, isMulti, bName=None):
  if bName:
   FFTYCg(self.VVrPW4, boundFunction(self.VVUUgY, refCode, isMulti, bName), title="Adding Channels ...")
 def VVUUgY(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVSpOj(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VV6K6N = InfoBar.instance
    if VV6K6N:
     VVomKR = VV6K6N.servicelist
     if VVomKR:
      mutableList = VVomKR.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVrPW4.VVztP3()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFM9af(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FFy0Rl(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVSpOj(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVrPW4.VVEEtt(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VVgd3m(self, refCode, isMulti, VVzEsrObj, path):
  self.VVqF1i(refCode, isMulti)
 def VVqF1i(self, refCode, isMulti):
  FFpA7M(self.callingSELF, boundFunction(self.VVRsbf, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVRsbf(self, refCode, isMulti, name):
  if name:
   FFTYCg(self.VVrPW4, boundFunction(self.VVnztD, refCode, isMulti, name), title="Adding Channels ...")
 def VVnztD(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVSpOj(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VV6K6N = InfoBar.instance
    if VV6K6N:
     VVomKR = VV6K6N.servicelist
     if VVomKR:
      try:
       VVomKR.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVomKR.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVrPW4.VVztP3()
   title = "Add to Bouquet"
   if allOK: FFM9af(self.callingSELF, "Added to : %s" % name, title=title)
   else : FFy0Rl(self.callingSELF, "Nothing added!", title=title)
class CCi74Y(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFvMLn(VVLcyG, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFEVgi(self)
  FFUxNa(self["keyRed"]  , "Exit")
  FFUxNa(self["keyGreen"]  , "Save")
  FFUxNa(self["keyYellow"] , "Refresh")
  FFUxNa(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVIitv  ,
   "green"   : self.VVKz5g ,
   "yellow"  : self.VVb2fw  ,
   "blue"   : self.VV6jyg   ,
   "up"   : self.VV95Cz    ,
   "down"   : self.VVgVbh   ,
   "left"   : self.VV1LAe   ,
   "right"   : self.VVMG16   ,
   "cancel"  : self.VVIitv
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVb2fw()
  self.VVOsZa()
  FFcxMz(self)
 def VVIitv(self) : self.close(True)
 def VV0cNe(self) : self.close(False)
 def VV6jyg(self):
  self.session.openWithCallback(self.VViMH1, boundFunction(CC6xlm))
 def VViMH1(self, closeAll):
  if closeAll:
   self.close()
 def VV95Cz(self):
  self.VVGKV4(1)
 def VVgVbh(self):
  self.VVGKV4(-1)
 def VV1LAe(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVOsZa()
 def VVMG16(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVOsZa()
 def VVGKV4(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VV85Xx(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VV85Xx(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VV85Xx(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVoo3T(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVoo3T(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVOsZa(self):
  for obj in self.list:
   FFAt0z(obj, "#11404040")
  FFAt0z(self.list[self.index], "#11ff8000")
 def VVb2fw(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVKz5g(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CC9sFI()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVMomT)
 def VVMomT(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFM9af(self, "Nothing returned from the system!")
  else:
   FFM9af(self, str(result))
class CC6xlm(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFvMLn(VVARMy, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFEVgi(self, addLabel=True)
  FFUxNa(self["keyRed"]  , "Exit")
  FFUxNa(self["keyGreen"]  , "Sync")
  FFUxNa(self["keyYellow"] , "Refresh")
  FFUxNa(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVIitv   ,
   "green"   : self.VVxiwC  ,
   "yellow"  : self.VVxGQ6 ,
   "blue"   : self.VVjvTE  ,
   "cancel"  : self.VVIitv
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVxE9e()
  self.onShow.append(self.start)
 def start(self):
  FFpblr(self.refresh)
  FFcxMz(self)
 def refresh(self):
  self.VVVSaI()
  self.VV2B53(False)
 def VVIitv(self)  : self.close(True)
 def VVjvTE(self) : self.close(False)
 def VVxE9e(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVVSaI(self):
  self.VVVPxa()
  self.VVMfNd()
  self.VV5A45()
  self.VVOgi3()
 def VVxGQ6(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVxE9e()
   self.VVVSaI()
   FFpblr(self.refresh)
 def VVxiwC(self):
  if len(self["keyGreen"].getText()) > 0:
   FF3096(self, self.VVKQOD, "Synchronize with Internet Date/Time ?")
 def VVKQOD(self):
  self.VVVSaI()
  FFpblr(boundFunction(self.VV2B53, True))
 def VVVPxa(self)  : self["keyRed"].show()
 def VVX5O0(self)  : self["keyGreen"].show()
 def VVDEAC(self) : self["keyYellow"].show()
 def VVWqNI(self)  : self["keyBlue"].show()
 def VVMfNd(self)  : self["keyGreen"].hide()
 def VV5A45(self) : self["keyYellow"].hide()
 def VVOgi3(self)  : self["keyBlue"].hide()
 def VV2B53(self, sync):
  localTime = FFgdpv()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVake0(server)
   if epoch_time is not None:
    ntpTime = FFI3l2(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CC9sFI()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVMomT, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVDEAC()
  self.VVWqNI()
  if ok:
   self.VVX5O0()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVMomT(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VV2B53(False)
  except:
   pass
 def VVake0(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFbBOf():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCf48Y(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFvMLn(VVjmzI, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFEVgi(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  FFpblr(self.VVocic)
 def VVocic(self):
  if FFbBOf(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFAt0z(self["myBody"], color)
   FFAt0z(self["myLabel"], color)
  except:
   pass
class CCmJYl(Screen):
 def __init__(self, session, isFromExternal=False):
  size = CFG.signalSize.getValue()
  screenW = FFI2oD()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFvMLn(VVHWzd, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self.isFromExternal  = isFromExternal
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CC0meJ(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CC0meJ(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CC0meJ(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCmDnr()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFEVgi(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VV95Cz          ,
   "down"  : self.VVgVbh         ,
   "left"  : self.VV1LAe         ,
   "right"  : self.VVMG16         ,
   "info"  : self.VVbF1b        ,
   "epg"  : self.VVbF1b        ,
   "menu"  : self.VVoNZL         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "blue"  : self.VV77pV       ,
   "last"  : boundFunction(self.VVm5NI, -1)  ,
   "next"  : boundFunction(self.VVm5NI, 1)  ,
   "pageUp" : boundFunction(self.VVps2M, True) ,
   "chanUp" : boundFunction(self.VVps2M, True) ,
   "pageDown" : boundFunction(self.VVps2M, False) ,
   "chanDown" : boundFunction(self.VVps2M, False) ,
   "0"   : boundFunction(self.VVm5NI, 0)  ,
   "1"   : boundFunction(self.VVf3UQ, pos=1) ,
   "2"   : boundFunction(self.VVf3UQ, pos=2) ,
   "3"   : boundFunction(self.VVf3UQ, pos=3) ,
   "4"   : boundFunction(self.VVf3UQ, pos=4) ,
   "5"   : boundFunction(self.VVf3UQ, pos=5) ,
   "6"   : boundFunction(self.VVf3UQ, pos=6) ,
   "7"   : boundFunction(self.VVf3UQ, pos=7) ,
   "8"   : boundFunction(self.VVf3UQ, pos=8) ,
   "9"   : boundFunction(self.VVf3UQ, pos=9) ,
  }, -1)
  self.onShown.append(self.VVYVvL)
  self.onClose.append(self.onExit)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  self.sliderSNR.VVmUke()
  self.sliderAGC.VVmUke()
  self.sliderBER.VVmUke(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVf3UQ()
  self.VVzRuAInfo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVzRuA)
  except:
   self.timer.callback.append(self.VVzRuA)
  self.timer.start(500, False)
 def VVzRuAInfo(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVYQsN(service)
  serviceName = self.tunerInfo.VVRee8()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(self)
  tp = CCD09M()
  txt = tp.VV7a1f(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVzRuA(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVYQsN(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVQBXa())
   self["mySNR"].setText(self.tunerInfo.VVnSTK())
   self["myAGC"].setText(self.tunerInfo.VVsAY1())
   self["myBER"].setText(self.tunerInfo.VVuXyV())
   self.sliderSNR.VV0END(self.tunerInfo.VVkQXY())
   self.sliderAGC.VV0END(self.tunerInfo.VVjMDT())
   self.sliderBER.VV0END(self.tunerInfo.VV3F6n())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VV0END(0)
   self.sliderAGC.VV0END(0)
   self.sliderBER.VV0END(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(self)
    if state and not state == "Tuned":
     FF70nx(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVbF1b(self):
  FFtcRZ(self, fncMode=CCditA.VVbEj0)
 def VVoNZL(self):
  FFoJme(self, VVHIBy + "_help_signal", "Signal Monitor (Keys)")
 def VV77pV(self):
  self.session.open(CCqamV, isFromExternal=self.isFromExternal)
  self.close()
 def VV95Cz(self)  : self.VVf3UQ(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVgVbh(self) : self.VVf3UQ(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VV1LAe(self) : self.VVf3UQ(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVMG16(self) : self.VVf3UQ(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVf3UQ(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVm5NI(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFjbSc(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVps2M(self, isUp):
  FF70nx(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVzRuAInfo()
  except:
   pass
class CC0meJ(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVmUke(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFAt0z(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVHIBy +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFAt0z(self.covObj, self.covColor)
   else:
    FFAt0z(self.covObj, "#00006688")
    self.isColormode = True
  self.VV0END(0)
 def VV0END(self, val):
  val  = FFjbSc(val, self.minN, self.maxN)
  width = int(FF2Zt3(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFjbSc(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCYzQV(Screen):
 VVaMkV    = 0
 VVp06a = 1
 VV1pui = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVzQlc=None, barTheme=VVaMkV):
  ratio = self.VVSPKV(barTheme)
  self.skin, self.skinParam = FFvMLn(VVooHc, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVzQlc = VVzQlc
  self.isCancelled = False
  self.isError  = False
  self.curValue  = 0
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVvkm4 = None
  self.timer   = eTimer()
  self.myThread  = None
  FFEVgi(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVYVvL)
  self.onClose.append(self.onExit)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  self.VV5YyM()
  self["myProgBarVal"].setText("0%")
  FFAt0z(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVnOPU()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVnOPU)
  except:
   self.timer.callback.append(self.VVnOPU)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def VVvDFG(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVdPSC_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVvkm4), self.counter, self.maxValue, catName)
 def VVdPSC_fromImportEPG(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVtXQw(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VVvkm4), self.counter, self.maxValue)
  except:
   pass
 def VVQZMB(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVOKyX(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVuUXd(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FF70nx(self, "Cancelling ...")
  self.isCancelled = True
  self.VVDfmh(False)
 def VVDfmh(self, isDone):
  if self.VVzQlc:
   self.VVzQlc(isDone, self.VVvkm4, self.counter, self.maxValue, self.isError)
  self.close()
 def VVnOPU(self):
  val = FFjbSc(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FF2Zt3(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VVDfmh(True)
 def VV5YyM(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVp06a, self.VV1pui):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVSPKV(self, barTheme):
  if   barTheme == self.VVp06a : return 0.7
  if   barTheme == self.VV1pui : return 0.5
  else             : return 1
class CC9sFI(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVzQlc = {}
  self.commandRunning = False
  self.VVa20Y  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVzQlc, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVzQlc[name] = VVzQlc
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVa20Y:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVtCm1, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVyYIj , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVtCm1, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVyYIj , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVyYIj(name, retval)
  return True
 def VVtCm1(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVyYIj(self, name, retval):
  if not self.VVa20Y:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVzQlc[name]:
   self.VVzQlc[name](self.appResults[name], retval)
  del self.VVzQlc[name]
 def VVNam4(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCyVhv(Screen):
 def __init__(self, session, title="", VVYCFx=None, VVMIXO=False, VVCSaZ=False, VVkHo4=False, VVFNXU=False, VVp8kb=False, VVH1oe=False, VVTcLD=VV64Ja, VVD4UQ=None, VVj7my=False, VV5I5h=None, VV2vCv="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFvMLn(VVAxwO, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFEVgi(self, addScrollLabel=True)
  if not VV2vCv:
   VV2vCv = "Processing ..."
  self["myLabel"].setText("   %s" % VV2vCv)
  self.VVMIXO   = VVMIXO
  self.VVCSaZ   = VVCSaZ
  self.VVkHo4   = VVkHo4
  self.VVFNXU  = VVFNXU
  self.VVp8kb = VVp8kb
  self.VVH1oe = VVH1oe
  self.VVTcLD   = VVTcLD
  self.VVD4UQ = VVD4UQ
  self.VVj7my  = VVj7my
  self.VV5I5h  = VV5I5h
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CC9sFI()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFjCXZ()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVYCFx, str):
   self.VVYCFx = [VVYCFx]
  else:
   self.VVYCFx = VVYCFx
  if self.VVkHo4 or self.VVFNXU:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVkthi, VVkthi)
   self.VVYCFx.append("echo -e '\n%s\n' %s" % (restartNote, FFa6r1(restartNote, VVllxZ)))
   if self.VVkHo4:
    self.VVYCFx.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVYCFx.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVp8kb:
   FF70nx(self, "Processing ...")
  self.onLayoutFinish.append(self.VVsIU3)
  self.onClose.append(self.VVMFPf)
 def VVsIU3(self):
  self["myLabel"].VVaX06(textOutFile="console" if self.enableSaveRes else "")
  if self.VVMIXO:
   self["myLabel"].VV55as()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVgfwW()
  else:
   self.VV7h5f()
 def VVgfwW(self):
  if FFbBOf():
   self["myLabel"].setText("Processing ...")
   self.VV7h5f()
  else:
   self["myLabel"].setText(FFQRKC("\n   No connection to internet!", VVbvoH))
 def VV7h5f(self):
  allOK = self.container.ePopen(self.VVYCFx[0], self.VVY7AG, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVY7AG("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVH1oe or self.VVkHo4 or self.VVFNXU:
    self["myLabel"].setText(FFwzVc("STARTED", VVllxZ) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VV5I5h:
   colorWhite = CCyp6T.VVfxV9(VVbEpi)
   color  = CCyp6T.VVfxV9(self.VV5I5h[0])
   words  = self.VV5I5h[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVTcLD=self.VVTcLD)
 def VVY7AG(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVYCFx):
   allOK = self.container.ePopen(self.VVYCFx[self.cmdNum], self.VVY7AG, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVY7AG("Cannot connect to Console!", -1)
  else:
   if self.VVp8kb and FFvNec(self):
    FF70nx(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVH1oe:
    self["myLabel"].appendText("\n" + FFwzVc("FINISHED", VVllxZ), self.VVTcLD)
   if self.VVMIXO or self.VVCSaZ:
    self["myLabel"].VV55as()
   if self.VVD4UQ is not None:
    self.VVD4UQ()
   if not retval and self.VVj7my:
    self.VVMFPf()
 def VVMFPf(self):
  if self.container.VVNam4():
   self.container.killAll()
class CCZ8hP(Screen):
 def __init__(self, session, VVYCFx=None, VVp8kb=False):
  self.skin, self.skinParam = FFvMLn(VVAxwO, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVBgPY + "ajpanel_terminal.history"
  self.customCommandsFile = VVBgPY + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFCdzs("pwd") or "/home/root"
  self.container   = CC9sFI()
  FFEVgi(self, addScrollLabel=True)
  FFUxNa(self["keyRed"] , "Exit = Stop Command")
  FFUxNa(self["keyGreen"] , "OK = History")
  FFUxNa(self["keyYellow"], "Menu = Custom Cmds")
  FFUxNa(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVCmRp ,
   "cancel" : self.VVTQIp  ,
   "menu"  : self.VVBZX1 ,
   "last"  : self.VVgVHn  ,
   "next"  : self.VVgVHn  ,
   "1"   : self.VVgVHn  ,
   "2"   : self.VVgVHn  ,
   "3"   : self.VVgVHn  ,
   "4"   : self.VVgVHn  ,
   "5"   : self.VVgVHn  ,
   "6"   : self.VVgVHn  ,
   "7"   : self.VVgVHn  ,
   "8"   : self.VVgVHn  ,
   "9"   : self.VVgVHn  ,
   "0"   : self.VVgVHn
  })
  self.onLayoutFinish.append(self.VVYVvL)
  self.onClose.append(self.VVN7v6)
 def VVYVvL(self):
  self["myLabel"].VVaX06(isResizable=False, textOutFile="terminal")
  FFQGsp(self["keyRed"]  , "#00ff8000")
  FFAt0z(self["keyRed"]  , self.skinParam["titleColor"])
  FFAt0z(self["keyGreen"]  , self.skinParam["titleColor"])
  FFAt0z(self["keyYellow"] , self.skinParam["titleColor"])
  FFAt0z(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVuA7b(FFCdzs("date"), 5)
  result = FFCdzs("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVuW9E()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVHIBy + "LinuxCommands.lst"
   newTemplate = VVHIBy + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFmogf("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFmogf("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVN7v6(self):
  if self.container.VVNam4():
   self.container.killAll()
   self.VVuA7b("Process killed\n", 4)
   self.VVuW9E()
 def VVTQIp(self):
  if self.container.VVNam4():
   self.VVN7v6()
  else:
   FF3096(self, self.close, "Exit ?", VVKUzC=False)
 def VVuW9E(self):
  self.VVuA7b(self.prompt, 1)
  self["keyRed"].hide()
 def VVuA7b(self, txt, mode):
  if   mode == 1 : color = VVllxZ
  elif mode == 2 : color = VVq6Xr
  elif mode == 3 : color = VVbEpi
  elif mode == 4 : color = VVbvoH
  elif mode == 5 : color = VVIbxt
  elif mode == 6 : color = VVtSyw
  else   : color = VVbEpi
  try:
   self["myLabel"].appendText(FFQRKC(txt, color))
  except:
   pass
 def VVHNYa(self, cmd):
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVuA7b(cmd, 2)
   self.VVuA7b("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVuA7b(ch, 0)
   self.VVuA7b("\nor\n", 4)
   self.VVuA7b("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVuW9E()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFQRKC(parts[0].strip(), VVq6Xr)
    right = FFQRKC("#" + parts[1].strip(), VVtSyw)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVuA7b(txt, 2)
   lastLine = self.VVz1Mm()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVHFT6(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVY7AG, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFy0Rl(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVuA7b(data, 3)
 def VVY7AG(self, data, retval):
  if not retval == 0:
   self.VVuA7b("Exit Code : %d\n" % retval, 4)
  self.VVuW9E()
 def VVCmRp(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVz1Mm() == "":
   self.VVHFT6("cd /tmp")
   self.VVHFT6("ls")
  VVYnAG = []
  if fileExists(self.commandHistoryFile):
   lines  = FFxHei(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVYnAG.append((str(c), line, str(lNum)))
   self.VVoS7o(VVYnAG, title, self.commandHistoryFile, isHistory=True)
  else:
   FFZZL8(self, self.commandHistoryFile, title=title)
 def VVz1Mm(self):
  lastLine = FFCdzs("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVHFT6(self, cmd):
  os.system("echo '%s' >> %s" % (cmd, self.commandHistoryFile))
 def VVBZX1(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFxHei(self.customCommandsFile)
   lastLineIsSep = False
   VVYnAG = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVYnAG.append((str(c), line, str(lNum)))
   self.VVoS7o(VVYnAG, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFZZL8(self, self.customCommandsFile, title=title)
 def VVoS7o(self, VVYnAG, title, filePath=None, isHistory=False):
  if VVYnAG:
   VVuLsk = "#05333333"
   if isHistory: VVOFb6 = VVYfYq = VVMBDz = "#11000020"
   else  : VVOFb6 = VVYfYq = VVMBDz = "#06002020"
   VV5m6F = VVx5V8 = None
   VVJAKf   = ("Send"   , self.VVBjXN        , [])
   VVvRGr  = ("Modify & Send" , self.VVMntq        , [])
   if isHistory:
    VV5m6F = ("Clear History" , self.VV79Ue        , [])
   elif filePath:
    VVx5V8 = ("Edit File"  , boundFunction(self.VVPamJ, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVwcLv     = (CENTER  , LEFT   , CENTER )
   FFeiXT(self, None, title=title, header=header, VVOhES=VVYnAG, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=26, VVJAKf=VVJAKf, VVvRGr=VVvRGr, VV5m6F=VV5m6F, VVx5V8=VVx5V8, VVAanx=True
     , VVOFb6   = VVOFb6
     , VVYfYq   = VVYfYq
     , VVMBDz   = VVMBDz
     , VV3m2y  = "#05ffff00"
     , VVuLsk  = VVuLsk
    )
  else:
   FFk2jj(self, filePath, title=title)
 def VVBjXN(self, VVrPW4, title, txt, colList):
  cmd = colList[1].strip()
  VVrPW4.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVuA7b("\n%s\n" % cmd, 6)
   self.VVuA7b(self.prompt, 1)
  else:
   self.VVHNYa(cmd)
 def VVMntq(self, VVrPW4, title, txt, colList):
  cmd = colList[1]
  self.VVVR04(VVrPW4, cmd)
 def VV79Ue(self, VVrPW4, title, txt, colList):
  FF3096(self, boundFunction(self.VVFHuc, VVrPW4), "Reset History File ?", title="Command History")
 def VVFHuc(self, VVrPW4):
  os.system(FFmogf("echo '' > %s" % self.commandHistoryFile))
  VVrPW4.cancel()
 def VVPamJ(self, filePath, VVrPW4, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CC6xEh(self, filePath, VVzQlc=boundFunction(self.VV5aba, VVrPW4), curRowNum=rowNum)
  else     : FFZZL8(self, filePath)
 def VV5aba(self, VVrPW4, fileChanged):
  if fileChanged:
   VVrPW4.cancel()
   FFpblr(self.VVBZX1)
 def VVgVHn(self):
  self.VVVR04(None, self.lastCommand)
 def VVVR04(self, VVrPW4, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFpA7M(self, boundFunction(self.VVbWHF, VVrPW4), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVbWHF(self, VVrPW4, cmd):
  if cmd and len(cmd) > 0:
   self.VVHNYa(cmd)
   if VVrPW4:
    VVrPW4.cancel()
class CC76eZ(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVNEJF="", VVCa4c=False, VVUrNP=False, isTrimEnds=True):
  self.skin, self.skinParam = FFvMLn(VVzxpQ, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFEVgi(self, title, addLabel=True)
  FFUxNa(self["keyRed"] , "Up/Down = Change")
  FFUxNa(self["keyGreen"] , "Overwrite")
  FFUxNa(self["keyYellow"], "Pick Key Map")
  FFUxNa(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVUrNP   = VVUrNP
  self.VVCa4c  = VVCa4c
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVNEJF, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVvCBx      ,
   "green"    : self.VVOoX2    ,
   "yellow"   : self.VVbrTa      ,
   "blue"    : self.VVnUwl     ,
   "menu"    : self.VV8jcX     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVmQDR, True) ,
   "down"    : boundFunction(self.VVmQDR, False) ,
   "left"    : self.VV3Brf       ,
   "right"    : self.VVIC8s       ,
   "home"    : self.VVuKzw       ,
   "end"    : self.VVLRvG       ,
   "next"    : self.VVkG1w      ,
   "last"    : self.VVlr9k      ,
   "deleteForward"  : self.VVkG1w      ,
   "deleteBackward" : self.VVlr9k      ,
   "tab"    : self.VVkYHv       ,
   "toggleOverwrite" : self.VVOoX2    ,
   "0"     : self.VVfOKM     ,
   "1"     : self.VVfOKM     ,
   "2"     : self.VVfOKM     ,
   "3"     : self.VVfOKM     ,
   "4"     : self.VVfOKM     ,
   "5"     : self.VVfOKM     ,
   "6"     : self.VVfOKM     ,
   "7"     : self.VVfOKM     ,
   "8"     : self.VVfOKM     ,
   "9"     : self.VVfOKM
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VV0sxv()
  self.onShown.append(self.VVYVvL)
  self.onClose.append(self.onExit)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  FFUVmx(self)
  self["myLabel"].setText(self.message)
  self.VV34JO()
  if self.VVCa4c : self.VVOoX2()
  else    : self.VVRASm()
  FFcxMz(self)
  FFAt0z(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVvxd8)
  except:
   self.timer.callback.append(self.VVvxd8)
 def onExit(self):
  self.timer.stop()
 def VVvCBx(self):
  self.VVaT02()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVaT02()
  self.close(None)
 def VV8jcX(self):
  VVH93c = []
  VVH93c.append(("Home"         , "home"    ))
  VVH93c.append(("End"         , "end"     ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Clear All"       , "clearAll"   ))
  VVH93c.append(("Clear To Home"      , "clearToHome"   ))
  VVH93c.append(("Clear To End"       , "clearToEnd"   ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVCYgA:
   VVH93c.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("To Capital Letters"     , "toCapital"   ))
  VVH93c.append(("To Small Letters"      , "toSmall"    ))
  FFSEnE(self, self.VVMkXD, title="Edit Options", VVH93c=VVH93c)
 def VVMkXD(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVuKzw()
   elif item == "end"     : self.VVLRvG()
   elif item == "clearAll"    : self.VVEaj8()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVuKzw()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVCYgA
    VVCYgA = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVCYgA)
    self.VVuKzw()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVvxd8(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVOoX2(self):
  self["myInput"].toggleOverwrite()
  self.VVRASm()
 def VVbrTa(self):
  self.session.openWithCallback(self.VVvcul, boundFunction(CCgH8F, mode=self.charMode, VVUrNP=self.VVUrNP))
 def VVvcul(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VV34JO()
 def VVRASm(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VV0sxv(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVaT02(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VV5946(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VV3Brf(self)     : self.VV2059(self["myInput"].left)
 def VVIC8s(self)     : self.VV2059(self["myInput"].right)
 def VVkG1w(self)     : self.VV2059(self["myInput"].delete)
 def VVuKzw(self)     : self.VV2059(self["myInput"].home)
 def VVLRvG(self)     : self.VV2059(self["myInput"].end)
 def VVlr9k(self)    : self.VV2059(self["myInput"].deleteBackward)
 def VVkYHv(self)     : self.VV2059(self["myInput"].tab)
 def VVEaj8(self)     : self["myInput"].setText("")
 def VV2059(self, fnc):
  fnc()
  self.VVvxd8()
 def VVfOKM(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VV5946(newChar, overwrite)
   self.VVoiWm(newChar, self["myInput"].mapping[number])
 def VVmQDR(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCgH8F.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCgH8F.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VV5946(newChar, True)
   for group in groups:
    if newChar in group:
     self.VVoiWm(newChar, group)
     break
 def VVoiWm(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVbEpi:
    group = VVIbxt + group.replace(newChar, FFQRKC(newChar, VVbEpi, VVIbxt))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVnUwl(self):
  if self.VVUrNP : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VV34JO()
 def VV34JO(self):
  self["myInput"].mapping = CCgH8F.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCgH8F.RCU_MAP_TITLES[self.charMode])
class CCgH8F(Screen):
 VVMOuI  = 0
 VVcBBu  = 1
 VVp5BL  = 2
 VVz99N  = 3
 VVAdIg = 4
 VVTfLN = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols, arabic_nums1, arabic1)
       , ( symbols, arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A" , u"\u0628")
       , (u"\u0647" , u"\u062A")
       )
 def __init__(self, session, mode=VVMOuI, VVUrNP=False):
  self.skin, self.skinParam = FFvMLn(VVaOxX, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVUrNP  = VVUrNP
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFEVgi(self, title=self.Title)
  FFUxNa(self["keyRed"] ,"OK = Select")
  FFUxNa(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVLYN6     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVlBxg, -1) ,
   "next"  : boundFunction(self.VVlBxg, +1) ,
   "left"  : boundFunction(self.VVlBxg, -1) ,
   "right"  : boundFunction(self.VVlBxg, +1) ,
  }, -1)
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  FFAt0z(self["keyRed"], "#11222222")
  FFAt0z(self["keyGreen"], "#11222222")
  self.VVMxBB()
 def VVMxBB(self):
  self.VVVrWy()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVVrWy(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVlBxg(self, direction):
  if self.VVUrNP : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVMxBB()
 def VVLYN6(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCzUcj(Screen):
 def __init__(self, session, title="", message="", VVTcLD=VV64Ja, VVFdco=False, VVMBDz=None, VVhAiY=30):
  self.skin, self.skinParam = FFvMLn(VVAxwO, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVhAiY)
  self.session   = session
  FFEVgi(self, title, addScrollLabel=True)
  self.VVTcLD   = VVTcLD
  self.VVFdco   = VVFdco
  self.VVMBDz   = VVMBDz
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  self["myLabel"].VVaX06(VVFdco=self.VVFdco)
  self["myLabel"].setText(self.message, self.VVTcLD)
  if self.VVMBDz:
   FFAt0z(self["myBody"], self.VVMBDz)
   FFAt0z(self["myLabel"], self.VVMBDz)
   FFQOQY(self["myLabel"], self.VVMBDz)
  self["myLabel"].VV55as()
class CCziej(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFvMLn(VVzWll, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFEVgi(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  FFmJlY(self["errPic"], "err")
class CCTCEp(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FFvMLn(VVbZPn, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", 20)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FFEVgi(self, " ", addCloser=True)
class CCEVRA():
 def __init__(self, tSession, txt):
  self.win = tSession.instantiateDialog(CCTCEp, txt)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  self.timer   = eTimer()
  self.timerCounter = 0
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVWVBw)
  except:
   self.timer.callback.append(self.VVWVBw)
  self.timer.start(100, False)
 def VVWVBw(self):
  self.timerCounter += 1
  if self.timerCounter > 15:
   self.timer.stop()
   self.win.hide()
class CCgcno():
 VVxj63    = 0
 VVryHc  = 1
 VVHQc2   = ""
 VVijQO    = "ajpDownload"
 VVLwiR    = "/home/root/ajpanel_downloads"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVrPW4   = None
  self.timer     = eTimer()
  self.VV1xb6   = 0
  self.VV32kC  = 1
  self.VVvMyO  = 2
  self.VVa3fL   = 3
  self.VV5GFM   = 4
  VVYnAG = self.VVKmWi()
  if VVYnAG:
   self.VVrPW4 = self.VViytW(VVYnAG)
  if not VVYnAG and mode == self.VVxj63:
   self.VVkUjIor("Download list is empty !")
   self.cancel()
  if mode == self.VVryHc:
   FFTYCg(self.VVrPW4 or self.SELF, boundFunction(self.VVjsJc, startDnld, decodedUrl), title="Checking Server ...")
  self.VV4wvH(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV4wvH)
  except:
   self.timer.callback.append(self.VV4wvH)
  self.timer.start(1000, False)
 def VViytW(self, VVYnAG):
  VVYnAG.sort(key=lambda x: int(x[0]))
  VVFj4L = self.VVjMu5
  VVJAKf  = ("Play"  , self.VVCYfN , [])
  VVnOFk = (""   , self.VVnJeu  , [])
  VVv9Eb = ("Stop"  , self.VV8jLl  , [])
  VVvRGr = ("Resume"  , self.VVCnxC , [])
  VV5m6F = ("Options" , self.VVf22V  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVwcLv  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFeiXT(self.SELF, None, title=self.Title, header=header, VVOhES=VVYnAG, VVwcLv=VVwcLv, VVOmXx=widths, VVhAiY=26, VVJAKf=VVJAKf, VVnOFk=VVnOFk, VVFj4L=VVFj4L, VVv9Eb=VVv9Eb, VVvRGr=VVvRGr, VV5m6F=VV5m6F, VVYfYq="#11110011", VVOFb6="#11220022", VVMBDz="#11110011", VV3m2y="#00ffff00", VVuLsk="#00223025", VVCiIJ="#0a333333", VViPgN="#0a400040", VVAanx=True, searchCol=1)
 def VVKmWi(self):
  lines = CCgcno.VVO6Qi()
  VVYnAG = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",")
     left  = parts[0].strip()
     decodedUrl = ",".join(parts[1:]).strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVbJ2M(decodedUrl)
      if fName:
       if   "/movie/" in decodedUrl : sType = "Movie"
       elif "/series/" in decodedUrl : sType = "Series"
       else       : sType = ""
       path = self.VV3EEL(url, fName)
       if size > -1: sizeTxt = CCw1Kh.VV78Il(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVYnAG.append((str(len(VVYnAG) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVYnAG
 def VVrRVE(self):
  VVYnAG = self.VVKmWi()
  if VVYnAG:
   if self.VVrPW4 : self.VVrPW4.VVH1wF(VVYnAG, VVxE9eMsg=False)
   else     : self.VVrPW4 = self.VViytW(VVYnAG)
  else:
   self.cancel()
 def VV4wvH(self, force=False):
  if self.VVrPW4:
   thrList = self.VVrYsk()
   VVYnAG = []
   changed = False
   for ndx, row in enumerate(self.VVrPW4.VVPNQS()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VV1xb6
    if m3u8Log:
     percent = self.VVjdSi(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVa3fL , "%.2f %%" % percent
      else   : flag, progr = self.VV5GFM , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFoME1(mPath)
     if curSize > -1:
      fSize = CCw1Kh.VV78Il(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCw1Kh.VV78Il(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFoME1(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVa3fL , "%.2f %%" % percent
       else   : flag, progr = self.VV5GFM , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCw1Kh.VV78Il(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrList:
     flag = self.VVvMyO
     if m3u8Log :
      if not speed and not force : flag = self.VV32kC
      elif curSize == -1   : self.VVbvWj(False)
    if flag == self.VV1xb6:
     speed = progr = ""
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VV1xb6  : color2 = "#f#00555555#"
    elif flag == self.VV32kC : color2 = "#f#0000FFFF#"
    elif flag == self.VVvMyO : color2 = "#f#0000FFFF#"
    elif flag == self.VVa3fL  : color2 = "#f#00FF8000#"
    elif flag == self.VV5GFM  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VV8MyN(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVYnAG.append(row)
   if changed or force:
    self.VVrPW4.VVH1wF(VVYnAG, VVxE9eMsg=False)
 def VV8MyN(self, flag):
  tDict = { self.VV1xb6: "Not started", self.VV32kC: "Connecting", self.VVvMyO: "Downloading", self.VVa3fL: "Stopped", self.VV5GFM: "Completed" }
  return tDict.get(flag, "?")
 def VVCphn(self, title):
  colList = self.VVrPW4.VVvl4a()
  path = colList[6]
  url  = colList[8]
  if self.VV58kK() : self.VVkUjIor("Cannot delete !\n\nFile is downloading.")
  else      : FF3096(self.SELF, boundFunction(self.VVkTVi, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVkTVi(self, path, url):
  m3u8Log = self.VVrPW4.VVvl4a()[12].strip()
  if m3u8Log : os.system(FFmogf("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFmogf("rm -r '%s'" % path))
  self.VVYPk6()
  self.VVrRVE()
 def VVYPk6(self):
  if self.VV58kK():
   FF70nx(self.VVrPW4, self.VV8MyN(self.VVvMyO), 500)
  else:
   colList  = self.VVrPW4.VVvl4a()
   path  = colList[6].strip()
   decodedUrl = colList[9].strip()
   if fileExists(path):
    self.VVkUjIor("Cannot remove partial download !\n\nYou can delete the file (from options).")
   else:
    lines = CCgcno.VVO6Qi()
    newLines = []
    found = False
    for line in lines:
     if CCgcno.VVQED9(decodedUrl, line):
      found = True
     else:
      newLines.append(line)
    if found:
     self.VVvQ3V(newLines)
     self.VVrRVE()
     FF70nx(self.VVrPW4, "Removed.", 1000)
    else:
     FF70nx(self.VVrPW4, "Not found.", 1000)
 def VV0c4T(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FF3096(self.SELF, boundFunction(self.VVI60a, flag), ques, title=title)
 def VVI60a(self, flag):
  list = []
  for ndx, row in enumerate(self.VVrPW4.VVPNQS()):
   path  = row[6].strip()
   size  = row[7].strip()
   decodedUrl = row[9].strip()
   m3u8Log  = row[12].strip()
   inc   = False
   if m3u8Log:
    if   flag == self.VV5GFM and fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log) : inc = True
    elif flag == self.VV1xb6 and not fileExists(m3u8Log[:-9])        : inc = True
   else:
    if   flag == self.VV5GFM and size != "-1" and str(FFoME1(path)) == size   : inc = True #
    elif flag == self.VV1xb6 and not fileExists(path)          : inc = True
   if inc:
    list.append(decodedUrl)
  lines = CCgcno.VVO6Qi()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVvQ3V(newLines)
   self.VVrRVE()
   FF70nx(self.VVrPW4, "%d removed." % totRem, 1000)
  else:
   FF70nx(self.VVrPW4, "Not found.", 1000)
 def VVnJeu(self, VVrPW4, title, txt, colList):
  def VVvSHN(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVQGQz(key, val) : return "\n%s:\n%s\n" % (FFQRKC(key, COLOR_CONS_BRIGHT_YELLOW), val.strip())
  heads  = self.VVrPW4.VVYGfw()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVvSHN(heads[i]  , CCw1Kh.VV78Il(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVvSHN("Downloaded" , CCw1Kh.VV78Il(int(curSize), mode=0))
   else:
    txt += VVvSHN(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVQGQz(heads[i], colList[i])
  FFNGa4(self.SELF, txt, title=title)
 def VVCYfN(self, VVrPW4, title, txt, colList):
  path = colList[6].strip()
  if fileExists(path) : CCw1Kh.VVZGwk(self.SELF, path)
  else    : FF70nx(self.VVrPW4, "File not found", 1000)
 def VVjMu5(self, VVrPW4):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVrPW4:
   self.VVrPW4.cancel()
  del self
 def VVf22V(self, VVrPW4, title, txt, colList):
  if CFG.downloadAutoResume.getValue(): resumeTxt = "Disable"
  else        : resumeTxt = "Enable"
  VVH93c = []
  VVH93c.append(("Remove current row"      , "VVYPk6"  ))
  VVH93c.append(VVxSb7)
  VVH93c.append(('Remove all "Completed"'     , "remFinished"    ))
  VVH93c.append(('Remove all "Not started"'     , "remPending"    ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Delete the file (and remove from list)" , "VVCphn" ))
  VVH93c.append(VVxSb7)
  VVH93c.append((resumeTxt + " Auto Resume"     , "VVCiS7"  ))
  FFSEnE(self.SELF, self.VVsGTA, VVH93c=VVH93c, title=self.Title, VVjijr=True, VVcKlq=True)
 def VVsGTA(self, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVYPk6"  : self.VVYPk6()
   elif ref == "remFinished"   : self.VV0c4T(self.VV5GFM, txt)
   elif ref == "remPending"   : self.VV0c4T(self.VV1xb6, txt)
   elif ref == "VVCphn" : self.VVCphn(txt)
   elif ref == "VVCiS7"  : self.VVCiS7()
 def VVjsJc(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCiL8N.VV5pNt(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVkUjIor("Could not get download link !\n\nTry again later.")
     return
  for line in CCgcno.VVO6Qi():
   if CCgcno.VVQED9(decodedUrl, line):
    self.VVtPI5(decodedUrl)
    FFpblr(boundFunction(FF70nx, self.VVrPW4, "Already listed !", 2000))
    break
  else:
   params = self.VV7XuP(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVkUjIor(params[0])
   elif len(params) == 2:
    self.VVPATJ(params[0], decodedUrl)
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCw1Kh.VV78Il(fSize)
    FF3096(self.SELF, boundFunction(self.VVzMYt, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVzMYt(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCgcno.VVLwiR, "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVrRVE()
  if self.VVrPW4:
   self.VVrPW4.VVxsxd()
  if startDnld:
   threadName = self.VVijQO + decodedUrl
   self.VViGIv(threadName, url, decodedUrl, path, resp)
 def VVtPI5(self, decodedUrl):
  for ndx, row in enumerate(self.VVrPW4.VVPNQS()):
   decodedUrl2 = row[9].strip()
   if decodedUrl == decodedUrl2 and self.VVrPW4:
    self.VVrPW4.VV4mn9(ndx)
    break
 def VV7XuP(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVbJ2M(decodedUrl)
  if not fName:
   return ["Cannot process this channel !"]
  path = self.VV3EEL(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCiL8N.VV5pNt(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCiL8N.VVvqEYHeader()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Error %d\n\n%s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head["Content-Length"]
   cType = head["Content-Type"]
   if not "video" in cType:
    if resp.url.endswith(".m3u8"):
     return [resp, 1]
    else:
     return ["Cannot download this video !\n\nNot allowed by server."]
   if "Accept-Ranges" in head:
    resume = head["Accept-Ranges"]
    if not resume == "none":
     resumable = True
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  err = CCgcno.VVgcUS(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVPATJ(self, resp, decodedUrl):
  if not os.system(FFmogf("which ffmpeg")) == 0:
   FF3096(self.SELF, boundFunction(CCxu1n.VVNAdC, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVbJ2M(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VV05Ue(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FF3096(self.SELF, boundFunction(self.VV8fqX, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VV8fqX(rTxt, rUrl)
  else:
   self.VVkUjIor("Cannot process m3u8 file !")
 def VV05Ue(self, rTxt, rUrl):
  lst  = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVH93c = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = self.VV3BF1(rUrl, fPath)
   VVH93c.append((resol, fullUrl))
  if VVH93c:
   FFSEnE(self.SELF, self.VVcJfy, VVH93c=VVH93c, title="Resolution", VVjijr=True, VVcKlq=True)
  else:
   self.VVkUjIor("Cannot get Resolutions list from server !")
 def VVcJfy(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FF3096(self.SELF, boundFunction(FFpblr, boundFunction(self.VV5EQB, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFpblr(boundFunction(self.VV5EQB, resolUrl))
 def VV5EQB(self, resolUrl):
  txt, err =  self.VVWKQi(resolUrl)
  if err : self.VVkUjIor(err)
  else : self.VV8fqX(txt, resolUrl)
 def VV3BF1(self, rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VVdeK5(self, logF, decodedUrl):
  found = False
  lines = CCgcno.VVO6Qi()
  with open(CCgcno.VVLwiR, "w") as f:
   for line in lines:
    if CCgcno.VVQED9(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCgcno.VVLwiR, "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVrRVE()
 def VV8fqX(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = self.VV3BF1(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVkUjIor("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVdeK5(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFmogf("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = self.VVijQO + decodedUrl
  myThread = iThread(name=threadName, target=boundFunction(os.system, cmd))
  myThread.start()
 def VVWKQi(self, url):
  try:
   import requests
   resp = requests.get(url, headers=CCiL8N.VVvqEYHeader(), timeout=3, verify=False)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 def VVjdSi(self, dnldLog):
  if fileExists(dnldLog):
   dur = self.VV8oMV(dnldLog)
   if dur > -1:
    tim = self.VVpcnm(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 def VV8oMV(self, dnldLog):
  lines = FF8QLc("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVpcnm(self, dnldLog):
  lines = FF8QLc("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VV3EEL(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if "/series/" in url:
   span = iSearch(r"(.+)_Season_[0-9]*_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFmogf("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VViGIv(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVrPW4.VVvl4a()[7].strip())
  myThread = iThread(name=threadName, target=boundFunction(self.VVbfBA, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVbfBA(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if CCgcno.VVHQc2 == path:
       break
     else:
      break
  except:
   return
  if CCgcno.VVHQc2:
   CCgcno.VVHQc2 = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFoME1(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VV7XuP(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVbfBA(url, decodedUrl, path, resp, totFileSize, True)
 def VV8jLl(self, VVrPW4, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVxTEQ() : FF70nx(self.VVrPW4, self.VV8MyN(self.VV5GFM), 500)
  elif not self.VV58kK() : FF70nx(self.VVrPW4, self.VV8MyN(self.VVa3fL), 500)
  elif m3u8Log      : FF3096(self.SELF, self.VVbvWj, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVrYsk():
    CCgcno.VVHQc2 = colList[6]
    FF70nx(self.VVrPW4, "Stopping ...", 1000)
   else:
    FF70nx(self.VVrPW4, "Stopped", 500)
 def VVbvWj(self, withMsg=True):
  if withMsg:
   FF70nx(self.VVrPW4, "Stopping ...", 1000)
  os.system(FFmogf("killall -INT ffmpeg"))
 def VVCiS7(self):
  CFG.downloadAutoResume.setValue(not CFG.downloadAutoResume.getValue())
  CFG.downloadAutoResume.save()
  configfile.save()
 def VVCnxC(self, *args):
  if   self.VVxTEQ() : FF70nx(self.VVrPW4, self.VV8MyN(self.VV5GFM) , 500)
  elif self.VV58kK() : FF70nx(self.VVrPW4, self.VV8MyN(self.VVvMyO), 500)
  else:
   resume = False
   m3u8Log = self.VVrPW4.VVvl4a()[12].strip()
   if m3u8Log:
    if fileExists(m3u8Log) : FF3096(self.SELF, boundFunction(self.VV6sD5, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVRRWt():
    resume = True
   if resume: FFTYCg(self.VVrPW4, boundFunction(self.VVltQm), title="Checking Server ...")
   else  : FF70nx(self.VVrPW4, "Cannot resume !", 500)
 def VV6sD5(self, m3u8Log):
  os.system(FFmogf("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FFTYCg(self.VVrPW4, boundFunction(self.VVltQm), title="Checking Server ...")
 def VVltQm(self):
  colList  = self.VVrPW4.VVvl4a()
  path  = colList[6].strip()
  size  = colList[7].strip()
  decodedUrl = colList[9].strip()
  if "j.php" in decodedUrl:
   url = CCiL8N.VV5pNt(decodedUrl)
   if url:
    decodedUrl = self.VVpXbI(decodedUrl, url)
   else:
    self.VVkUjIor("Could not get download link !\n\nTry again later.")
    return
  curSize = FFoME1(path)
  params = self.VV7XuP(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVkUjIor(params[0])
   return
  elif len(params) == 2:
   self.VVPATJ(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVpXbI(decodedUrl, url, fSize)
  threadName = self.VVijQO + decodedUrl
  if resumable: self.VViGIv(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVkUjIor("Cannot resume from server !")
 def VVbJ2M(self, decodedUrl):
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(http:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  if url and fName and chName:
   mix  = fName + chName
   fName =  mix.split(":")[0]
   chName = ":".join(mix.split(":")[1:])
   fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
   url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVkUjIor(self, txt):
  FFy0Rl(self.SELF, txt, title=self.Title)
 def VVrYsk(self):
  thrList = []
  for thr in iEnumerate():
   if self.VVijQO in thr.name:
    thrList.append(thr.name.replace(self.VVijQO, ""))
  return thrList
 def VV58kK(self):
  decodedUrl = self.VVrPW4.VVvl4a()[9].strip()
  return decodedUrl in self.VVrYsk()
 def VVxTEQ(self):
  colList = self.VVrPW4.VVvl4a()
  path = colList[6].strip()
  size = colList[7].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFoME1(path)) == size
 def VVRRWt(self):
  colList = self.VVrPW4.VVvl4a()
  path = colList[6].strip()
  size = int(colList[7].strip())
  curSize = FFoME1(path)
  if curSize > -1:
   size -= curSize
  err = CCgcno.VVgcUS(size)
  if err:
   FFy0Rl(self.SELF, err, title=self.Title)
   return False
  return True
 def VVvQ3V(self, list):
  with open(CCgcno.VVLwiR, "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVpXbI(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCgcno.VVO6Qi()
  url = decodedUrl
  with open(CCgcno.VVLwiR, "w") as f:
   for line in lines:
    if CCgcno.VVQED9(decodedUrl, line):
     parts = line.split(",")
     oldUrl = ",".join(parts[1:]).strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVrRVE()
  return url
 @staticmethod
 def VVO6Qi():
  list = []
  if fileExists(CCgcno.VVLwiR):
   for line in FFxHei(CCgcno.VVLwiR):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVQED9(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVgcUS(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCw1Kh.VVONyB(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCw1Kh.VV78Il(size), CCw1Kh.VV78Il(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVxXLh(SELF):
  tot = CCgcno.VVGvPM()
  if tot:
   FFy0Rl(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVGvPM():
  c = 0
  for thread in iEnumerate():
   if thread.name.startswith(CCgcno.VVijQO):
    c += 1
  return c
 @staticmethod
 def VVn4WS():
  return len(CCgcno.VVO6Qi()) == 0
 @staticmethod
 def VV5N3A():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVFeSR():
  mPoints = CCgcno.VV5N3A()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFmogf("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVqtop(SELF):
  CCgcno.VVPSVh(SELF, CCgcno.VVxj63)
 @staticmethod
 def VVlAZa_cur(SELF):
  CCgcno.VVPSVh(SELF, CCgcno.VVryHc, startDnld=True)
 @staticmethod
 def VVlAZa_url(SELF, url):
  CCgcno.VVPSVh(SELF, CCgcno.VVryHc, startDnld=True, decodedUrl=url)
 @staticmethod
 def VV4cnKCurrent(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(SELF)
  added, skipped = CCgcno.VV4cnKList([decodedUrl])
  FF70nx(SELF, "Added", 1000)
 @staticmethod
 def VV4cnKList(list):
  added = skipped = 0
  for line in CCgcno.VVO6Qi():
   for ndx, url in enumerate(list):
    if url and CCgcno.VVQED9(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCgcno.VVLwiR, "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVPSVh(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCQctb.VVvc3e(SELF):
   return
  if mode == CCgcno.VVxj63 and CCgcno.VVn4WS():
   FFy0Rl(SELF, "Download list is empty !", title=title)
  else:
   inst = CCgcno(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
class CCqamV(Screen, CCqMtN):
 VV0ERI = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False, enableDownloadMenu=True):
  self.skin, self.skinParam = FFvMLn(VVIl27, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCqMtN.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  FFEVgi(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VV1sye())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayDnld"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVrVKJ         ,
   "info"  : self.VVbF1b        ,
   "epg"  : self.VVbF1b        ,
   "menu"  : self.VV8o19       ,
   "cancel" : self.cancel         ,
   "blue"  : self.VVVOUJ        ,
   "green"  : self.VVqlZ2    ,
   "yellow" : self.VVEQV7   ,
   "left"  : boundFunction(self.VVPdwI, -1)   ,
   "right"  : boundFunction(self.VVPdwI,  1)   ,
   "play"  : self.VVGZ63        ,
   "pause"  : self.VVGZ63        ,
   "playPause" : self.VVGZ63        ,
   "stop"  : self.VVGZ63        ,
   "rewind" : self.VVG8ic        ,
   "forward" : self.VVk5Ec        ,
   "rewindDm" : self.VVG8ic        ,
   "forwardDm" : self.VVk5Ec        ,
   "last"  : boundFunction(self.VVleHf, 0)    ,
   "next"  : self.VVr6uo        ,
   "pageUp" : boundFunction(self.VVMqtC, True) ,
   "pageDown" : boundFunction(self.VVMqtC, False) ,
   "chanUp" : boundFunction(self.VVMqtC, True) ,
   "chanDown" : boundFunction(self.VVMqtC, False) ,
   "up"  : boundFunction(self.VVMqtC, True) ,
   "down"  : boundFunction(self.VVMqtC, False) ,
   "audio"  : boundFunction(self.VVAR8i, True) ,
   "subtitle" : boundFunction(self.VVAR8i, False) ,
   "0"   : boundFunction(self.VVchRI , 10)  ,
   "1"   : boundFunction(self.VVchRI , 1)  ,
   "2"   : boundFunction(self.VVchRI , 2)  ,
   "3"   : boundFunction(self.VVchRI , 3)  ,
   "4"   : boundFunction(self.VVchRI , 4)  ,
   "5"   : boundFunction(self.VVchRI , 5)  ,
   "6"   : boundFunction(self.VVchRI , 6)  ,
   "7"   : boundFunction(self.VVchRI , 7)  ,
   "8"   : boundFunction(self.VVchRI , 8)  ,
   "9"   : boundFunction(self.VVchRI , 9)
  }, -1)
  self.onShown.append(self.VVYVvL)
  self.onClose.append(self.onExit)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  FFUVmx(self)
  if not CCqamV.VV0ERI or self.portalTableParam:
   CCqamV.VV0ERI = self
  else:
   self.close()
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  self["myPlayDnld"].instance.move(ePoint(int(left - self.skinParam["titleH"]), int(top)))
  self["myPlayDnld"].hide()
  FFmJlY(self["myPlayDnld"], "dnld")
  self.VVzP5R()
  self.instance.move(ePoint(40, 40))
  self.VVpzHU(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVy0D0)
  except:
   self.timer.callback.append(self.VVy0D0)
  self.timer.start(250, False)
  self.VVy0D0("Checking ...")
  self.VVD6Sp()
 def VVqlZ2(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(self)
  if "chCode" in iptvRef:
   if CCQctb.VVvc3e(self):
    self.VVD6Sp(True)
 def VVzP5R(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl:
   color = "#1120002a"
   self["myPlayGrn"].show()
  else:
   color = "#1100202a"
   self["myPlayGrn"].hide()
  FFAt0z(self["myTitle"], color)
 def VV8o19(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(self)
  VVH93c = []
  if self.isFromExternal:
   VVH93c.append(("IPTV Menu"     , "iptv"  ))
   VVH93c.append(VVxSb7)
  if FF9NA0(iptvRef) and not "&end=" in decodedUrl and not any(x in decodedUrl for x in ("/movie/", "/series/")):
   uType, uHost, uUser, uPass, uId, uChName = CCxu1n.VVoNlW(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVH93c.append(("Catchup Programs"   , "catchup"  ))
    VVH93c.append(VVxSb7)
  VVH93c.append(("Stop Current Service"    , "stop"  ))
  VVH93c.append(("Restart Current Service"   , "restart"  ))
  VVH93c.append(VVxSb7)
  isMovieSeries = any(x in decodedUrl for x in ("/movie/", "/series/"))
  if isMovieSeries:
   VVH93c.append(("File Size"     , "fileSize" ))
   VVH93c.append(VVxSb7)
  if self.enableDownloadMenu:
   addSep = False
   if FF9NA0(iptvRef) and isMovieSeries:
    VVH93c.append(("Start Download"   , "dload_cur" ))
    VVH93c.append(("Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCgcno.VVn4WS():
    VVH93c.append(("Download Manager"   , "dload_stat" ))
    addSep = True
   if addSep:
    VVH93c.append(VVxSb7)
  if not CCw1Kh.VVSBRv:
   fPath, fName = CCw1Kh.VVRdh2(self)
   if fPath:
    VVH93c.append((VVllxZ + "Open path in File Manager", "VVjTZL"))
    VVH93c.append(VVxSb7)
  VVH93c.append(("Move to Top"      , "top"   ))
  VVH93c.append(("Move to Bottom"     , "botm"  ))
  VVH93c.append(("Help"        , "help"  ))
  FFSEnE(self, self.VVIUX6, VVH93c=VVH93c, width=550, title="Options")
 def VVIUX6(self, item=None):
  if item:
   if item == "iptv"  :
    self.session.open(CCxu1n)
    self.close()
   elif item == "catchup"   : self.VVEQV7()
   elif item == "stop"    : self.VVJua4(0)
   elif item == "restart"   : self.VVJua4(1)
   elif item == "fileSize"   : FFTYCg(self, boundFunction(CCditA.VVAJtV, self), title="Checking Server")
   elif item == "dload_cur"  : CCgcno.VVlAZa_cur(self)
   elif item == "addToDload"  : CCgcno.VV4cnKCurrent(self)
   elif item == "dload_stat"  : CCgcno.VVqtop(self)
   elif item == "VVjTZL" : self.VVjTZL()
   elif item == "botm"    : self.VVpzHU(0)
   elif item == "top"    : self.VVpzHU(1)
   elif item == "help"    : FFoJme(self, VVHIBy + "_help_player", "Player Controller (Keys)")
 def onExit(self):
  self.timer.stop()
  CCqamV.VV0ERI = None
 def VVjTZL(self):
  self.session.open(CCw1Kh, gotoMovie=True)
  if CCqamV.VV0ERI:
   self.session.open(CCqamV, enableZapping= False, enableDownloadMenu=False)
 def VVJua4(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.close()
   elif typ == 1:
    self.VVy0D0("Restarting Service ...")
    FFpblr(boundFunction(self.VVDmC7, serv))
 def VVDmC7(self, serv):
  self.session.nav.stopService()
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(self)
  if "&end=" in decodedUrl: boundFunction(self.VVD6Sp, True)
  else     : self.session.nav.playService(serv)
 def VVpzHU(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VVrVKJ(self):
  if self.isManualSeek:
   self.VVtkHj()
   self.VVleHf(self.manualSeekPts)
  else:
   if self.shown: self.hide()
   else   : self.show()
 def cancel(self):
  if self.isManualSeek:
   self.VVtkHj()
  else:
   self.close()
 def VVbF1b(self):
  FFtcRZ(self, fncMode=CCditA.VVgdNI)
 def VVGZ63(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except Exception as e:
   pass
  self.VVy0D0("Toggling Play/Pause ...")
 def VVtkHj(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVPdwI(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVmWAE()
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.jumpMinutes * 60.0
   else:
    self.manualSeekSec += direc * self.jumpMinutes * 60.0
    self.manualSeekSec = FFjbSc(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FF2Zt3(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFEQDX(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVchRI(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   FFUxNa(self["myPlayJmp"], self.VV1sye())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVy0D0("Changed Jump Minutes to : %d" % val)
 def VV1sye(self):
  return "Jump:%dm" % self.jumpMinutes
 def VVy0D0(self, stateTxt="", highlight=False):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(self)
  fr = res = ""
  if info:
   w = FFYzNX(info, iServiceInformation.sVideoWidth) or -1
   h = FFYzNX(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFYzNX(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CCditA.VVPlHO(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVmWAE()
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FFjbSc(percVal, 0, 100)
    width = int(FF2Zt3(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not posTxt: self["myPlayPos"].setText("")
  if not remTxt: self["myPlayRem"].setText("")
  if not durTxt:
   if   prov : txt = prov
   elif posTxt : txt = ">>>>"
   else  : txt = "...."
   self["myPlayVal"].setText(txt)
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText("")
   FFAt0z(self["myPlayBarBG"], "#1100202a")
   self["myPlayBarF"].hide()
  else:
   FFAt0z(self["myPlayBarBG"], "#11000000")
   self["myPlayBarF"].show()
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VV5cjX() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   if highlight: FFQGsp(self["myPlayMsg"], "#0000ffff")
   else  : FFQGsp(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   self["myPlayMsg"].setText("-" if decodedUrl else FFpaqk(refCode, True))
   FFQGsp(self["myPlayMsg"], "#00ff8066")
  tot = CCgcno.VVGvPM()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVN3WU()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VVleHf(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
  state = self.VVAJxP()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFQGsp(self["myPlayMsg"], "#0000ff00")
  else     : FFQGsp(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVmWAE(self):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = self.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFEQDX(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFEQDX(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal
      remTxt = FFEQDX(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVN3WU(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVVOUJ(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VV5cjX()
   if cList:
    VVH93c = []
    for pts, what in cList:
     txt = FFEQDX(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVH93c.append((txt, pts))
    FFSEnE(self, self.VV0KVo, VVH93c=VVH93c, title="Cut List")
   else:
    self.VVy0D0("No Cut-List for this channel !")
 def VV0KVo(self, item=None):
  if item:
   self.VVleHf(item)
 def VV5cjX(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVk5Ec(self) : self.VV36Ts(self.jumpMinutes)
 def VVG8ic(self) : self.VV36Ts(-self.jumpMinutes)
 def VV36Ts(self, mins):
  try:
   inst = InfoBar.instance
   inst.doSeekRelative(mins * 60 * 90000)
   inst.hide()
   if   mins > 0 : self.VVy0D0("Forawrd (%d min) ..." % self.jumpMinutes)
   elif mins < 0 : self.VVy0D0("Rewind (%d min) ..." % self.jumpMinutes)
  except:
   self.VVy0D0("Cannot jump")
 def VVT8Qw(self):
  InfoBar.instance.VVT8Qw()
 def VVleHf(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVy0D0("Changing Time ...")
 def VVr6uo(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVmWAE()
   if durVal > 0:
    pts = int(durVal * 60 * 90000)
    InfoBar.instance.doSeek(pts)
    self.VVy0D0("Jumping to end ...")
  except:
   pass
 def VVAJxP(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVMqtC(self, isUp):
  if self.enableZapping:
   self.VVy0D0("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVtkHj()
   if self.portalTableParam:
    self.VVgpJU(isUp)
   else:
    try:
     if isUp : InfoBar.instance.zapDown()
     else : InfoBar.instance.zapUp()
    except:
     pass
    self.lastPlayPos = 0
    self.VVzP5R()
    self.VVD6Sp()
 def VVgpJU(self, isUp):
  CCxu1n_inatance, VVrPW4, mode = self.portalTableParam
  if isUp : VVrPW4.VV4uMC()
  else : VVrPW4.VVgZlV()
  FFTYCg(VVrPW4, boundFunction(self.VV3u83, mode, VVrPW4, CCxu1n_inatance), title="Playing ...")
 def VV3u83(self, mode, VVrPW4, CCxu1n_inatance):
  colList = VVrPW4.VVvl4a()
  if mode == "localIptv":
   CCxu1n_inatance.VVwmLV(True, VVrPW4, "", "", colList)
  elif isinstance(mode, int):
   CCxu1n_inatance.VV5bA9(mode, True, VVrPW4, "", "", colList)
  else:
   CCxu1n_inatance.VVVv9c(mode, True, VVrPW4, "", "", colList)
  self.close()
 def VVD6Sp(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVmWAE()
    if posTxt:
     return
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(self)
   if not self.VVuf5p(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVy0D0("Refreshing Portal")
   FFpblr(self.VVsdkB)
  except:
   pass
 def VVsdkB(self):
  self.restoreLastPlayPos = self.VV7P1a()
 def VVEQV7(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFF0On(self)
  if not decodedUrl or any(x in decodedUrl for x in ("/movie/", "/series/")):
   self.VVy0D0("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCxu1n.VVoNlW(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVy0D0("Reading Program List ...")
   ok_fnc = boundFunction(self.VVxGjq, refCode, chName, streamId, uHost, uUser, uPass)
   FFpblr(boundFunction(CCxu1n.VVm07c, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVy0D0("Cannot process this channel")
 def VVxGjq(self, refCode, chName, streamId, uHost, uUser, uPass, VVrPW4, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVrPW4.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVy0D0("Changing Program ...")
   FFpblr(boundFunction(self.VVq5ms, chUrl))
  else:
   self.VVy0D0("Incorrect Timestamp !")
 def VVq5ms(self, chUrl):
   FFqfoC(self, chUrl, VVIPM3=False)
   self.lastPlayPos = 0
   self.VVzP5R()
 def VVAR8i(self, isAudio):
  try:
   VV6K6N = InfoBar.instance
   if VV6K6N:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VV6K6N)
    else  : self.session.open(SubtitleSelection, VV6K6N)
  except:
   pass
class CCR9wL(Screen):
 def __init__(self, session, title="", VVWYUn="Continue?", VVKUzC=True, VVZH0D=False):
  self.skin, self.skinParam = FFvMLn(VVWdqz, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVWYUn = VVWYUn
  self.VVZH0D = VVZH0D
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVKUzC : VVH93c = [no , yes]
  else   : VVH93c = [yes, no ]
  FFEVgi(self, title, VVH93c=VVH93c, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVrVKJ ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVWYUn)
  if self.VVZH0D:
   self["myLabel"].instance.setHAlign(0)
  self.VVr8rX()
  FFj85G(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFl807(self["myMenu"])
  FFqmQB(self, self["myMenu"])
 def VVrVKJ(self):
  item = FF5QLc(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVr8rX(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCMlqI(Screen):
 def __init__(self, session, title="", VVH93c=None, width=1000, OKBtnFnc=None, VVURxH=None, VVDeB1=None, VVSptY=None, VVM3vl=None, VVjijr=False, VVcKlq=False):
  self.skin, self.skinParam = FFvMLn(VVd6Yn, width, 850, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVH93c   = VVH93c
  self.OKBtnFnc   = OKBtnFnc
  self.VVURxH   = VVURxH
  self.VVDeB1  = VVDeB1
  self.VVSptY  = VVSptY
  self.VVM3vl   = VVM3vl
  self.VVjijr  = VVjijr
  self.VVcKlq  = VVcKlq
  FFEVgi(self, title, VVH93c=VVH93c)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVrVKJ          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVW6B5         ,
   "green"  : self.VVJzAE         ,
   "yellow" : self.VVSUNG         ,
   "blue"  : self.VVhV5z         ,
   "pageUp" : self.VVhmDY       ,
   "chanUp" : self.VVhmDY       ,
   "pageDown" : self.VVF42w        ,
   "chanDown" : self.VVF42w
  }, -1)
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  FFj85G(self["myMenu"])
  FFsbO6(self)
  self.VVxXgM(self["keyRed"]  , self.VVURxH )
  self.VVxXgM(self["keyGreen"] , self.VVDeB1 )
  self.VVxXgM(self["keyYellow"] , self.VVSptY )
  self.VVxXgM(self["keyBlue"]  , self.VVM3vl )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFcxMz(self)
 def VVxXgM(self, btnObj, btnFnc):
  if btnFnc:
   FFUxNa(btnObj, btnFnc[0])
 def VVrVKJ(self):
  item = FF5QLc(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVjijr: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVW6B5(self)  : self.VV2059(self.VVURxH)
 def VVJzAE(self) : self.VV2059(self.VVDeB1)
 def VVSUNG(self) : self.VV2059(self.VVSptY)
 def VVhV5z(self) : self.VV2059(self.VVM3vl)
 def VV2059(self, btnFnc):
  if btnFnc:
   item = FF5QLc(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVcKlq:
    self.cancel()
 def VV8Y9R(self, VVH93c):
  if len(VVH93c) > 0:
   newList = []
   for item in VVH93c:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVBJmX(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVhmDY(self):
  self["myMenu"].moveToIndex(0)
 def VVF42w(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCnr9g(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VVOhES=None, VVwcLv=None, VVOmXx=None, VVhAiY=26, VVAanx=False, VVJAKf=None, VVnOFk=None, VVv9Eb=None, VVvRGr=None, VV5m6F=None, VVx5V8=None, VVBpTW=None, VVS0Uh=None, VVFj4L=None, VVdn6v=-1, VV5c0a=False, searchCol=0, VVOFb6=None, VVYfYq=None, VV0aPr="#00dddddd", VVMBDz="#11002233", VV3m2y="#00ff8833", VVuLsk="#11111111", VVCiIJ="#0a555555", VVsRsD="#0affffff", VViPgN="#11552200", VVtp7t="#0055ff55"):
  self.skin, self.skinParam = FFvMLn(VVRJjU, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFEVgi(self, title)
  self.header     = header
  self.VVOhES     = VVOhES
  self.totalCols    = len(VVOhES[0])
  self.VVwXa0   = 0
  self.lastSortModeIsReverese = False
  self.VVAanx   = VVAanx
  self.VV7ZDO   = 0.01
  self.VVK0sX   = 0.02
  self.VVnwvN = 0.03
  self.VVpClu  = 1
  self.VVOmXx = VVOmXx
  self.colWidthPixels   = []
  self.VVJAKf   = VVJAKf
  self.OKButtonObj   = None
  self.VVnOFk   = VVnOFk
  self.VVv9Eb   = VVv9Eb
  self.VVvRGr   = VVvRGr
  self.VV5m6F  = VV5m6F
  self.VVx5V8   = VVx5V8
  self.VVBpTW    = VVBpTW
  self.VVS0Uh   = VVS0Uh
  self.VVFj4L  = VVFj4L
  self.VVdn6v    = VVdn6v
  self.VV5c0a   = VV5c0a
  self.searchCol    = searchCol
  self.VVwcLv    = VVwcLv
  self.keyPressed    = -1
  self.VVhAiY    = FFTViU(VVhAiY)
  self.VVAdb2    = FFh7wR(self.VVhAiY, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVOFb6    = VVOFb6
  self.VVYfYq      = VVYfYq
  self.VV0aPr    = FFzKP2(VV0aPr)
  self.VVMBDz    = FFzKP2(VVMBDz)
  self.VV3m2y    = FFzKP2(VV3m2y)
  self.VVuLsk    = FFzKP2(VVuLsk)
  self.VVCiIJ   = FFzKP2(VVCiIJ)
  self.VVsRsD    = FFzKP2(VVsRsD)
  self.VViPgN    = FFzKP2(VViPgN)
  self.VVtp7t   = FFzKP2(VVtp7t)
  self.VVFahg  = False
  self.selectedItems   = 0
  self.VVGskC   = FFzKP2("#01fefe01")
  self.VVhAJV   = FFzKP2("#11400040")
  self.VVeDwz  = self.VVGskC
  self.VVw53K  = self.VVuLsk
  if self.VV5c0a:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVLAZ1  ,
   "red"   : self.VVqNAb  ,
   "green"   : self.VV6baX ,
   "yellow"  : self.VVuKY1 ,
   "blue"   : self.VVjBHN  ,
   "menu"   : self.VV6GqC ,
   "info"   : self.VVwQFT  ,
   "cancel"  : self.VVo7ma  ,
   "up"   : self.VVgZlV    ,
   "down"   : self.VV4uMC  ,
   "left"   : self.VViiFO   ,
   "right"   : self.VVLCGG  ,
   "pageUp"  : self.VVEL3V  ,
   "chanUp"  : self.VVEL3V  ,
   "pageDown"  : self.VVxsxd  ,
   "chanDown"  : self.VVxsxd
  }, -1)
  FF9Mg2(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  FFUVmx(self)
  try:
   self.VVQ1IO()
  except Exception as err:
   FFy0Rl(self, str(err))
   self.close(None)
 def VVQ1IO(self):
  FFcxMz(self)
  if self.VVOFb6:
   FFAt0z(self["myTitle"], self.VVOFb6)
  if self.VVYfYq:
   FFAt0z(self["myBody"] , self.VVYfYq)
   FFAt0z(self["myTableH"] , self.VVYfYq)
   FFAt0z(self["myTable"] , self.VVYfYq)
   FFAt0z(self["myBar"]  , self.VVYfYq)
  self.VVxXgM(self.VVv9Eb  , self["keyRed"])
  self.VVxXgM(self.VVvRGr  , self["keyGreen"])
  self.VVxXgM(self.VV5m6F , self["keyYellow"])
  self.VVxXgM(self.VVx5V8  , self["keyBlue"])
  if self.VVJAKf:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVJAKf[0])
    FFAt0z(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVAdb2)
  self["myTableH"].l.setFont(0, gFont(VVXu7B, self.VVhAiY))
  self["myTable"].l.setItemHeight(self.VVAdb2)
  self["myTable"].l.setFont(0, gFont(VVXu7B, self.VVhAiY))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVAdb2)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVAdb2))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVAdb2)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVAdb2
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVAdb2 * len(self.VVOhES) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVOmXx:
   self.VVOmXx = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVOmXx)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVwcLv:
   self.VVwcLv = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVwcLv
   self.VVwcLv = []
   for item in tmpList:
    self.VVwcLv.append(item | RT_VALIGN_CENTER)
  self.VVU20B()
  if self.VVBpTW:
   self.VVBpTW(self)
 def VVxXgM(self, btnFnc, btn):
  if btnFnc : FFUxNa(btn, btnFnc[0])
  else  : FFUxNa(btn, "")
 def VVRgzv(self, waitTxt):
  FFTYCg(self, self.VVU20B, title=waitTxt)
 def VVU20B(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVwxq4(0, self.header, self.VVsRsD, self.VViPgN, self.VVsRsD, self.VViPgN, self.VVtp7t)])
   rows = []
   for c, row in enumerate(self.VVOhES):
    rows.append(self.VVwxq4(c, row, self.VV0aPr, self.VVMBDz, self.VV3m2y, self.VVuLsk, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVdn6v > -1:
    self["myTable"].moveToIndex(self.VVdn6v )
   self.VVzJUw()
   if self.VV5c0a:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVAdb2 * len(self.VVOhES)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVS0Uh:
    self.VV2059(self.VVS0Uh, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFy0Rl(self, str(err))
    self.close()
   except:
    pass
 def VVwxq4(self, keyIndex, columns, VV0aPr, VVMBDz, VV3m2y, VVuLsk, VVtp7t):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVtp7t and ndx == self.VVwXa0 : textColor = VVtp7t
   else           : textColor = VV0aPr
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFzKP2(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVMBDz = c
    entry = span.group(3)
   if self.VVwcLv[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVAdb2)
           , font   = 0
           , flags   = self.VVwcLv[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVMBDz
           , color_sel  = VV3m2y
           , backcolor_sel = VVuLsk
           , border_width = 1
           , border_color = self.VVCiIJ
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVwQFT(self):
  rowData = self.VVYwps()
  if rowData:
   title, txt, colList = rowData
   if self.VVnOFk:
    fnc  = self.VVnOFk[1]
    params = self.VVnOFk[2]
    fnc(self, title, txt, colList)
   else:
    FFNGa4(self, txt, title)
 def VVLAZ1(self):
  if   self.VVFahg : self.VV26qf(self.VV61YO(), mode=2)
  elif self.VVJAKf  : self.VV2059(self.VVJAKf, None)
  else      : self.VVwQFT()
 def VVqNAb(self) : self.VV2059(self.VVv9Eb , self["keyRed"])
 def VV6baX(self) : self.VV2059(self.VVvRGr , self["keyGreen"])
 def VVuKY1(self): self.VV2059(self.VV5m6F , self["keyYellow"])
 def VVjBHN(self) : self.VV2059(self.VVx5V8 , self["keyBlue"])
 def VV2059(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FF70nx(self, buttonFnc[3])
    FFpblr(boundFunction(self.VVqsk5, buttonFnc))
   else:
    self.VVqsk5(buttonFnc)
 def VVqsk5(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVYwps()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VV26qf(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VVOhES[ndx]
   isSelected = row[1][9] == self.VVGskC
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVwxq4(ndx, item, self.VV0aPr, self.VVMBDz, self.VV3m2y, self.VVuLsk, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVwxq4(ndx, item, self.VVGskC, self.VVhAJV, self.VVeDwz, self.VVw53K, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVzJUw()
 def VVGeom(self):
  FFTYCg(self, self.VVOtsn, title="Selecting all ...")
 def VVOtsn(self):
  self.VVggAY(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVGskC
   if not isSelected:
    item = self.VVOhES[ndx]
    newRow = self.VVwxq4(ndx, item, self.VVGskC, self.VVhAJV, self.VVeDwz, self.VVw53K, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVzJUw()
  self.VVdbBs()
 def VV8Dkw(self):
  FFTYCg(self, self.VVKlFr, title="Unselecting all ...")
 def VVKlFr(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVGskC:
    item = self.VVOhES[ndx]
    newRow = self.VVwxq4(ndx, item, self.VV0aPr, self.VVMBDz, self.VV3m2y, self.VVuLsk, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVzJUw()
  self.VVdbBs()
 def VVdbBs(self):
  self.hide()
  self.show()
 def VVYwps(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVOmXx[i] > 1 or self.VVOmXx[i] == self.VV7ZDO or self.VVOmXx[i] == self.VVnwvN:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VVOhES))
   return rowNum, txt, colList
  else:
   return None
 def VVo7ma(self):
  if self.VVFj4L : self.VVFj4L(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVWfT2(self):
  return self["myTitle"].getText().strip()
 def VVYGfw(self):
  return self.header
 def VVBxdF(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVSUEO(self, txt):
  FF70nx(self, txt)
 def VVjBbc(self, txt):
  FF70nx(self, txt, 1000)
 def VVztP3(self):
  FF70nx(self)
 def VVFWie(self):
  return len(self.VVOhES)
 def VVijfm(self): self["keyGreen"].show()
 def VVd3gr(self): self["keyGreen"].hide()
 def VV61YO(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVyTaM(self):
  return len(self["myTable"].list)
 def VVggAY(self, isOn):
  self.VVFahg = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu"].hide()
   if self.VVx5V8: self["keyBlue"].hide()
   if self.VVJAKf and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVx5V8: self["keyBlue"].show()
   if self.VVJAKf and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVJAKf[0])
   self.VV8Dkw()
  FFAt0z(self["myTitle"], color)
  FFAt0z(self["myBar"]  , color)
 def VV8Wu1(self):
  return self.VVFahg
 def VVXZ7c(self):
  return self.selectedItems
 def VV5ETD(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VVzJUw()
 def VV3XlJ(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVzJUw()
 def VV71pE(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VVOhES:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVamuF(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVFWie()
  txt += FFwzVc("Total Unique Items", VVbvoH)
  for i in range(self.totalCols):
   if self.VVOmXx[i - 1] > 1 or self.VVOmXx[i - 1] == self.VV7ZDO or self.VVOmXx[i - 1] == self.VVnwvN:
    name, tot = self.VV71pE(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFNGa4(self, txt)
 def VVvKjl(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVvl4a(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVH1wF(self, newList, newTitle="", VVxE9eMsg=True):
  if newList:
   self.VVOhES = newList
   if self.VVAanx and self.VVwXa0 == 0:
    self.VVOhES = sorted(self.VVOhES, key=lambda x: int(x[self.VVwXa0])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VVOhES = sorted(self.VVOhES, key=lambda x: x[self.VVwXa0].lower(), reverse=self.lastSortModeIsReverese)
   if VVxE9eMsg : self.VVRgzv("Refreshing ...")
   else   : self.VVU20B()
   if newTitle:
    self.VVBxdF(newTitle)
  else:
   FFy0Rl(self, "Cannot refresh list")
   self.cancel()
 def VVKR3H(self, data):
  ndx = self.VV61YO()
  newRow = self.VVwxq4(ndx, data, self.VV0aPr, self.VVMBDz, self.VV3m2y, self.VVuLsk, None)
  if newRow:
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVzJUw()
   return True
  else:
   return False
 def VVG4Jh(self, colNum, textToFind, VVkUjI=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVzJUw()
    break
  else:
   if VVkUjI:
    FF70nx(self, "Not found", 1000)
 def VV5KJx(self, colDict, VVkUjI=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVzJUw()
    return
  if VVkUjI:
   FF70nx(self, "Not found", 1000)
 def VV5KJx_partial(self, colDict, VVkUjI=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVzJUw()
    return
  if VVkUjI:
   FF70nx(self, "Not found", 1000)
 def VVePxH(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVEEtt(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVGskC:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVPNQS(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VV6GqC(self):
  if not self["keyMenu"].getVisible() or self.VV5c0a:
   return
  VVH93c = []
  VVH93c.append(("Table Statistcis"             , "tableStat"  ))
  VVH93c.append(VVxSb7)
  VVH93c.append((FFQRKC("Export Table to .html"     , VVbvoH) , "VVqC61" ))
  VVH93c.append((FFQRKC("Export Table to .csv"     , VVbvoH) , "VVyk3l" ))
  VVH93c.append((FFQRKC("Export Table to .txt (Tab Separated)", VVbvoH) , "VVn8PO" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVOmXx[i] > 1 or self.VVOmXx[i] == self.VVK0sX:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVH93c.append(VVxSb7)
   if tot == 1 : VVH93c.append(("Sort", sList[0][1]))
   else  : VVH93c += sList
  FFSEnE(self, self.VVWCwB, VVH93c=VVH93c, title=self.VVWfT2())
 def VVWCwB(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVamuF()
   elif item == "VVqC61": FFTYCg(self, self.VVqC61, title=title)
   elif item == "VVyk3l" : FFTYCg(self, self.VVyk3l , title=title)
   elif item == "VVn8PO" : FFTYCg(self, self.VVn8PO , title=title)
   else:
    isReversed = False
    if self.VVwXa0 == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVAanx and item == 0:
     self.VVOhES = sorted(self.VVOhES, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VVOhES = sorted(self.VVOhES, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVwXa0 = item
    self.VVRgzv("Sorting ...")
 def VVgZlV(self):
  self["myTable"].up()
  self.VVzJUw()
 def VV4uMC(self):
  self["myTable"].down()
  self.VVzJUw()
 def VViiFO(self):
  self["myTable"].pageUp()
  self.VVzJUw()
 def VVLCGG(self):
  self["myTable"].pageDown()
  self.VVzJUw()
 def VVEL3V(self):
  self["myTable"].moveToIndex(0)
  self.VVzJUw()
 def VVxsxd(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVzJUw()
 def VV4mn9(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVzJUw()
 def VVn8PO(self):
  expFile = self.VVNlPJ() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVdh1U()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VVOhES:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVOmXx[ndx] > self.VVpClu or self.VVOmXx[ndx] == self.VVnwvN:
      col = self.VVvfKB(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVu99V(expFile)
 def VVyk3l(self):
  expFile = self.VVNlPJ() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVdh1U()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VVOhES:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVOmXx[ndx] > self.VVpClu or self.VVOmXx[ndx] == self.VVnwvN:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVvfKB(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVu99V(expFile)
 def VVqC61(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVWfT2(), PLUGIN_NAME, VVIPCs)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVWfT2()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVdh1U()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVOmXx:
   colgroup += '   <colgroup>'
   for w in self.VVOmXx:
    if w > self.VVpClu or w == self.VVnwvN:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVNlPJ() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VVOhES:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVOmXx[ndx] > self.VVpClu or self.VVOmXx[ndx] == self.VVnwvN:
      col = self.VVvfKB(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVu99V(expFile)
 def VVdh1U(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVOmXx[ndx] > self.VVpClu or self.VVOmXx[ndx] == self.VVnwvN:
     newRow.append(col.strip())
  return newRow
 def VVvfKB(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFuz5p(col)
 def VVNlPJ(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVWfT2())
  fileName = fileName.replace("__", "_")
  path  = FFIm0p(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFVgvw()
  return expFile
 def VVu99V(self, expFile):
  FFM9af(self, "File exported to:\n\n%s" % expFile, title=self.VVWfT2())
 def VVzJUw(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCXZqm(Screen):
 def __init__(self, session, Title="", VVigoX=None):
  self.skin, self.skinParam = FFvMLn(VVbXcF, 1400, 800, 50, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FFEVgi(self, Title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VVigoX = VVigoX
  if len(Title) == 0 : Title = FFjCXZ()
  else    : Title = "File : %s" % VVigoX
  self["myTitle"] = Label("  %s" % Title)
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  allOK = FFrbJa(self["myLabel"], self.VVigoX)
  if not allOK:
   FFy0Rl(self, "Could not view this picture file")
   self.close()
class CCPaCW(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFvMLn(VVr5yh, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 26, barHeight=40, topRightBtns=1)
  self.session  = session
  FFEVgi(self)
  FFUxNa(self["keyGreen"], "Save")
  self.VVOhES = []
  self.VVOhES.append(getConfigListEntry("Show in Main Menu"          , CFG.showInMainMenu   ))
  self.VVOhES.append(getConfigListEntry("Show in Extensions Menu"         , CFG.showInExtensionMenu  ))
  self.VVOhES.append(getConfigListEntry("Show in Channel List Context Menu"      , CFG.showInChannelListMenu  ))
  self.VVOhES.append(getConfigListEntry("Show in Events Info Menu"        , CFG.EventsInfoMenu   ))
  self.VVOhES.append(getConfigListEntry("Input Type"            , CFG.keyboard     ))
  self.VVOhES.append(getConfigListEntry("Signal & Player Cotroller Hotkey"      , CFG.hotkey_signal    ))
  if VVAEGR:
   self.VVOhES.append(getConfigListEntry("EPG Translation Language"       , CFG.epgLanguage    ))
  self.VVOhES.append(getConfigListEntry(VVkthi *2             ,         ))
  self.VVOhES.append(getConfigListEntry("Default IPTV Reference Type"        , CFG.iptvAddToBouquetRefType ))
  self.VVOhES.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"  , CFG.autoResetFrozenIptvChan ))
  self.VVOhES.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"     , CFG.hideIptvServerAdultWords ))
  self.VVOhES.append(getConfigListEntry('Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)'  , CFG.hideIptvServerChannPrefix ))
  self.VVOhES.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"   , CFG.iptvHostsPath    ))
  self.VVOhES.append(getConfigListEntry("Movie/Series Download Path"        , CFG.MovieDownloadPath   ))
  self.VVOhES.append(getConfigListEntry(VVkthi *2             ,         ))
  self.VVOhES.append(getConfigListEntry("PIcons Path"            , CFG.PIconsPath    ))
  self.VVOhES.append(getConfigListEntry(VVkthi *2             ,         ))
  self.VVOhES.append(getConfigListEntry("Backup/Restore Path"          , CFG.backupPath    ))
  self.VVOhES.append(getConfigListEntry("Created Package Files (IPK/DEB)"       , CFG.packageOutputPath   ))
  self.VVOhES.append(getConfigListEntry("Downloaded Packages (from feeds)"      , CFG.downloadedPackagesPath ))
  self.VVOhES.append(getConfigListEntry("Exported Tables"           , CFG.exportedTablesPath  ))
  self.VVOhES.append(getConfigListEntry("Exported PIcons"           , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, self.VVOhES, session)
  self["setupActions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard", "OkCancelActions"],
  {
   "ok"  : self.VVrVKJ   ,
   "OK"  : self.VVrVKJ   ,
   "green"  : self.VVd423  ,
   "menu"  : self.VVnBxX ,
   "cancel" : self.VVrueG
  }, -1)
  self.titleText = "  Settings"
  self["myTitle"].setText(self.titleText)
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  FFUVmx(self)
  FFj85G(self["config"])
  FFsbO6(self,  self["config"])
  FFcxMz(self)
 def VVrVKJ(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsPath   : self.VV6cTU()
   elif item == CFG.MovieDownloadPath   : self.VVV1LW(item, self["config"].getCurrent()[0])
   elif item == CFG.PIconsPath    : self.VVX6xa(item)
   elif item == CFG.backupPath    : self.VVX6xa(item)
   elif item == CFG.packageOutputPath  : self.VVX6xa(item)
   elif item == CFG.downloadedPackagesPath : self.VVX6xa(item)
   elif item == CFG.exportedTablesPath  : self.VVX6xa(item)
   elif item == CFG.exportedPIconsPath  : self.VVX6xa(item)
 def VVV1LW(self, item, title):
  tot = CCgcno.VVGvPM()
  if tot : FFy0Rl(self, "Cannot change while downloading.", title=title)
  else : self.VVX6xa(item)
 def VV6cTU(self):
  VVH93c = []
  VVH93c.append(("Auto Find" , "auto"))
  VVH93c.append(("Custom Path" , "path"))
  FFSEnE(self, self.VVzxSP, VVH93c=VVH93c, title="IPTV Hosts Files Path")
 def VVzxSP(self, item=None):
  if item:
   if   item == "auto": CFG.iptvHostsPath.setValue(VV5FAb)
   elif item == "path": self.VVX6xa(CFG.iptvHostsPath)
 def VVX6xa(self, configObj):
  sDir = configObj.getValue()
  if sDir == VV5FAb:
   sDir = "/"
  self.session.openWithCallback(boundFunction(self.VV4RBw, configObj)
         , boundFunction(CCw1Kh, mode=CCw1Kh.VVhLeF, VVLZO1=sDir))
 def VV4RBw(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVrueG(self):
  if CFG.showInMainMenu.isChanged()    or \
   CFG.showInExtensionMenu.isChanged()   or \
   CFG.showInChannelListMenu.isChanged()  or \
   CFG.EventsInfoMenu.isChanged()    or \
   CFG.keyboard.isChanged()     or \
   CFG.hotkey_signal.isChanged()    or \
   CFG.epgLanguage.isChanged()     or \
   CFG.iptvAddToBouquetRefType.isChanged()  or \
   CFG.autoResetFrozenIptvChan.isChanged()  or \
   CFG.hideIptvServerAdultWords.isChanged() or \
   CFG.hideIptvServerChannPrefix.isChanged() or \
   CFG.iptvHostsPath.isChanged()    or \
   CFG.MovieDownloadPath.isChanged()   or \
   CFG.PIconsPath.isChanged()     or \
   CFG.backupPath.isChanged()     or \
   CFG.packageOutputPath.isChanged()   or \
   CFG.downloadedPackagesPath.isChanged()  or \
   CFG.exportedTablesPath.isChanged()   or \
   CFG.exportedPIconsPath.isChanged():
    FF3096(self, self.VVd423, "Save Changes ?", callBack_No=self.cancel)
  else:
   self.cancel()
 def VVd423(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVgMdK()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVnBxX(self):
  VVH93c = []
  VVH93c.append(("Use Backup directory in all other paths"      , "VVWwpE"   ))
  VVH93c.append(("Reset all to default (including File Manager bookmarks)"  , "VVhqUq"   ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Backup %s Settings" % PLUGIN_NAME        , "VVVzx3"  ))
  VVH93c.append(("Restore %s Settings" % PLUGIN_NAME       , "VVdA8e"  ))
  if fileExists(VVBgPY + VV8o8r):
   VVH93c.append(VVxSb7)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVH93c.append(('%s Checking for Update' % txt1       , txt2     ))
   VVH93c.append(("Reinstall %s" % PLUGIN_NAME        , "VVQgxn"  ))
   VVH93c.append(("Update %s" % PLUGIN_NAME        , "VV9OA8"   ))
  FFSEnE(self, self.VVEKTo, VVH93c=VVH93c, title="Config. Options")
 def VVEKTo(self, item=None):
  if item:
   if   item == "VVWwpE"  : FF3096(self, self.VVWwpE , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVhqUq"  : FF3096(self, self.VVhqUq, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCyp6T)
   elif item == "VVVzx3" : self.VVVzx3()
   elif item == "VVdA8e" : FFTYCg(self, self.VVdA8e, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVlLjS(True)
   elif item == "disableChkUpdate" : self.VVlLjS(False)
   elif item == "VVQgxn" : FFTYCg(self, self.VVQgxn , "Checking Server ...")
   elif item == "VV9OA8"  : FFTYCg(self, self.VV9OA8  , "Checking Server ...")
 def VVVzx3(self):
  path = "%sajpanel_settings_%s" % (VVBgPY, FFVgvw())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFM9af(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVdA8e(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FF8QLc("find / %s -iname '%s*' | grep %s" % (FFJQpq(1), name, name))
  if lines:
   lines.sort()
   VVH93c = []
   for line in lines:
    VVH93c.append((line, line))
   FFSEnE(self, boundFunction(self.VVzwUS, title), title=title, VVH93c=VVH93c, width=1200)
  else:
   FFy0Rl(self, "No settings files found !", title=title)
 def VVzwUS(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFxHei(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVgMdK()
    FFGAvG()
   else:
    FFZZL8(SELF, path, title=title)
 def VVlLjS(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVWwpE(self):
  newPath = FFIm0p(VVBgPY)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVgMdK()
 @staticmethod
 def VVZTQR():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVhqUq(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.EventsInfoMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.epgLanguage.setValue("off")
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.autoResetFrozenIptvChan.setValue(False)
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.iptvHostsPath.setValue(VV5FAb)
  CFG.MovieDownloadPath.setValue(CCgcno.VVFeSR())
  CFG.PIconsPath.setValue(VVRqVx)
  CFG.backupPath.setValue(CCPaCW.VVZTQR())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  CFG.showInMainMenu.save()
  CFG.showInExtensionMenu.save()
  CFG.showInChannelListMenu.save()
  CFG.EventsInfoMenu.save()
  CFG.keyboard.save()
  CFG.hotkey_signal.save()
  CFG.epgLanguage.save()
  CFG.iptvAddToBouquetRefType.save()
  CFG.autoResetFrozenIptvChan.save()
  CFG.hideIptvServerAdultWords.save()
  CFG.hideIptvServerChannPrefix.save()
  CFG.iptvHostsPath.save()
  CFG.MovieDownloadPath.save()
  CFG.PIconsPath.save()
  CFG.backupPath.save()
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  CFG.browserStartPath.save()
  CFG.browserBookmarks.save()
  self.VVgMdK()
  self.close()
 def VVgMdK(self):
  configfile.save()
  global VVBgPY
  VVBgPY = CFG.backupPath.getValue()
  FFNXhB()
 def VV9OA8(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVflv0(title)
  if webVer:
   FF3096(self, boundFunction(FFTYCg, self, boundFunction(self.VV3PWK, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVQgxn(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVflv0(title, True)
  if webVer:
   FF3096(self, boundFunction(FFTYCg, self, boundFunction(self.VV3PWK, webVer, title)), "Install and Restart ?", title=title)
 def VV3PWK(self, webVer, title):
  url = self.VVpmQj(self, title)
  if url:
   VVa20Y = FFWFvN() == "dpkg"
   if VVa20Y == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVa20Y else "ipk")
   path, err = FF9cSe(url + fName, fName, timeout=2)
   if path:
    cmd = FFrD2J(VVGnsR, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFtPYL(self, cmd)
    else:
     FFkPbc(self, title=title)
   else:
    FFy0Rl(self, err, title=title)
 def VVflv0(self, title, anyVer=False):
  url = self.VVpmQj(self, title)
  if not url:
   return ""
  path, err = FF9cSe(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFy0Rl(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FF1gqL(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFy0Rl(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVIPCs.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FF8QLc(cmd)
   if list and curVer == list[0]:
    return webVer
  FFM9af(self, FFQRKC("No update required.", VVoiSL) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVpmQj(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVBgPY + VV8o8r
  if fileExists(path):
   span = iSearch(r"(http.+)", FF1gqL(path), IGNORECASE)
   if span : url = FFIm0p(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFy0Rl(SELF, err, title)
  return url
 @staticmethod
 def VV7BvF(url):
  path, err = FF9cSe(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FF1gqL(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVIPCs.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FF8QLc(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCyp6T(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFvMLn(VV52Mj, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVKAZP
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFEVgi(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVp7zn("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVp7zn("\c00888888", i) + sp + "GREY\n"
   txt += self.VVp7zn("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVp7zn("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVp7zn("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVp7zn("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVp7zn("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVp7zn("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVp7zn("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVp7zn("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVp7zn("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVp7zn("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVrVKJ ,
   "green"   : self.VVrVKJ ,
   "left"   : self.VV1LAe ,
   "right"   : self.VVMG16 ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  self.VVAtGv()
 def VVrVKJ(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FF3096(self, self.VVrO6F, "Change to : %s" % txt, title=self.Title)
 def VVrO6F(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVKAZP
  VVKAZP = self.cursorPos
  self.VVIYWR()
  self.close()
 def VV1LAe(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVAtGv()
 def VVMG16(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVAtGv()
 def VVAtGv(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVp7zn(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVfxV9(color):
  if VVllxZ: return "\\" + color
  else    : return ""
 @staticmethod
 def VVIYWR():
  global VVtSyw, VVIbxt, VVo2ZM, VVbvoH, VVMjkH, VVQrXh, VVoiSL, VVllxZ, COLOR_CONS_BRIGHT_YELLOW, VVq6Xr, VVvFue, VV0P8J, VVbEpi
  VVbEpi   = CCyp6T.VVp7zn("\c00FFFFFF", VVKAZP)
  VVIbxt    = CCyp6T.VVp7zn("\c00888888", VVKAZP)
  VVtSyw  = CCyp6T.VVp7zn("\c005A5A5A", VVKAZP)
  VVQrXh    = CCyp6T.VVp7zn("\c00FF0000", VVKAZP)
  VVo2ZM   = CCyp6T.VVp7zn("\c00FF5000", VVKAZP)
  VVllxZ   = CCyp6T.VVp7zn("\c00FFFF00", VVKAZP)
  COLOR_CONS_BRIGHT_YELLOW = CCyp6T.VVp7zn("\c00FFFFAA", VVKAZP)
  VVoiSL   = CCyp6T.VVp7zn("\c0000FF00", VVKAZP)
  VVMjkH    = CCyp6T.VVp7zn("\c000066FF", VVKAZP)
  VVq6Xr    = CCyp6T.VVp7zn("\c0000FFFF", VVKAZP)
  VVvFue  = CCyp6T.VVp7zn("\c00DSFFFF", VVKAZP)  #
  VV0P8J   = CCyp6T.VVp7zn("\c00FA55E7", VVKAZP)
  VVbvoH    = CCyp6T.VVp7zn("\c00FF8F5F", VVKAZP)
CCyp6T.VVIYWR()
class CCXdvo(Screen):
 def __init__(self, session, path, VVa20Y):
  self.skin, self.skinParam = FFvMLn(VVARMy, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVXfKC   = path
  self.VVO1AL   = ""
  self.VVTTGE   = ""
  self.VVa20Y    = VVa20Y
  self.VVEMOr    = ""
  self.VVWErH  = ""
  self.VV3vcb    = False
  self.VVasns  = False
  self.postInstAcion   = 0
  self.VVeMYG  = "enigma2-plugin-extensions"
  self.VVX46d  = "enigma2-plugin-systemplugins"
  self.VVnMTW = "enigma2"
  self.VV32zC  = 0
  self.VVkvhB  = 1
  self.VVQI7f  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVxpnA = "DEBIAN"
  else        : self.VVxpnA = "CONTROL"
  self.controlPath = self.Path + self.VVxpnA
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVa20Y:
   self.packageExt  = ".deb"
   self.VVMBDz  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVMBDz  = "#11001020"
  FFEVgi(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFUxNa(self["keyRed"] , "Create")
  FFUxNa(self["keyGreen"] , "Post Install")
  FFUxNa(self["keyYellow"], "Installation Path")
  FFUxNa(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVlDBN  ,
   "green"   : self.VV6mtk ,
   "yellow"  : self.VVokba  ,
   "blue"   : self.VVGtKa  ,
   "cancel"  : self.VVIitv
  }, -1)
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  FFcxMz(self)
  if self.VVMBDz:
   FFAt0z(self["myBody"], self.VVMBDz)
   FFAt0z(self["myLabel"], self.VVMBDz)
  self.VV5BgG(True)
  self.VVDBi9(True)
 def VVDBi9(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VV48Uc()
  if isFirstTime:
   if   package.startswith(self.VVeMYG) : self.VVXfKC = VVTqTJ + self.VVEMOr + "/"
   elif package.startswith(self.VVX46d) : self.VVXfKC = VV38TZ + self.VVEMOr + "/"
   else            : self.VVXfKC = self.Path
  if self.VV3vcb : myColor = VVbvoH
  else    : myColor = VVbEpi
  txt  = ""
  txt += "Source Path\t: %s\n" % FFQRKC(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFQRKC(self.VVXfKC, VVllxZ)
  if self.VVTTGE : txt += "Package File\t: %s\n" % FFQRKC(self.VVTTGE, VVIbxt)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFQRKC("Check Control File fields : %s" % errTxt, VVo2ZM)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFQRKC("Restart GUI", VVbvoH)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFQRKC("Reboot Device", VVbvoH)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FFQRKC("Post Install", VVoiSL), act)
  if not errTxt and VVo2ZM in controlInfo:
   txt += "Warning\t: %s\n" % FFQRKC("Errors in control file may affect the result package.", VVo2ZM)
  txt += "\nControl File\t: %s\n" % FFQRKC(self.controlFile, VVIbxt)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VV6mtk(self):
  VVH93c = []
  VVH93c.append(("No Action"    , "noAction"  ))
  VVH93c.append(("Restart GUI"    , "VVkHo4"  ))
  VVH93c.append(("Reboot Device"   , "rebootDev"  ))
  FFSEnE(self, self.VVtqgW, title="Package Installation Option (after completing installation)", VVH93c=VVH93c)
 def VVtqgW(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVkHo4"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VV5BgG(False)
   self.VVDBi9()
 def VVokba(self):
  rootPath = FFQRKC("/%s/" % self.VVEMOr, VVtSyw)
  VVH93c = []
  VVH93c.append(("Current Path"        , "toCurrent"  ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Extension Path"       , "toExtensions" ))
  VVH93c.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVH93c.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFSEnE(self, self.VVVYMt, title="Installation Path", VVH93c=VVH93c)
 def VVVYMt(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVQQQp(FF1zN0(self.Path, True))
   elif item == "toExtensions"  : self.VVQQQp(VVTqTJ)
   elif item == "toSystemPlugins" : self.VVQQQp(VV38TZ)
   elif item == "toRootPath"  : self.VVQQQp("/")
   elif item == "toRoot"   : self.VVQQQp("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVonj8, boundFunction(CCw1Kh, mode=CCw1Kh.VVhLeF, VVLZO1=VVBgPY))
 def VVonj8(self, path):
  if len(path) > 0:
   self.VVQQQp(path)
 def VVQQQp(self, parent, withPackageName=True):
  if withPackageName : self.VVXfKC = parent + self.VVEMOr + "/"
  else    : self.VVXfKC = "/"
  mode = self.VVJlIJ()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VViGz8(mode), self.controlFile))
  self.VVDBi9()
 def VVGtKa(self):
  if fileExists(self.controlFile):
   lines = FFxHei(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFpA7M(self, self.VV6b2Z, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFy0Rl(self, "Version not found or incorrectly set !")
  else:
   FFZZL8(self, self.controlFile)
 def VV6b2Z(self, VVNEJF):
  if VVNEJF:
   version, color = self.VVyfa6(VVNEJF, False)
   if color == VVq6Xr:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVNEJF, self.controlFile))
    self.VVDBi9()
   else:
    FFy0Rl(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVIitv(self):
  if self.newControlPath:
   if self.VV3vcb:
    self.VV8ZBk()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFQRKC(self.newControlPath, VVIbxt)
    txt += FFQRKC("Do you want to keep these files ?", VVllxZ)
    FF3096(self, self.close, txt, callBack_No=self.VV8ZBk, title="Create Package", VVZH0D=True)
  else:
   self.close()
 def VV8ZBk(self):
  os.system(FFmogf("rm -r '%s'" % self.newControlPath))
  self.close()
 def VViGz8(self, mode):
  if   mode == self.VVkvhB : prefix = self.VVeMYG
  elif mode == self.VVQI7f : prefix = self.VVX46d
  else        : prefix = self.VVnMTW
  return prefix + "-" + self.VVWErH
 def VVJlIJ(self):
  if   self.VVXfKC.startswith(VVTqTJ) : return self.VVkvhB
  elif self.VVXfKC.startswith(VV38TZ) : return self.VVQI7f
  else            : return self.VV32zC
 def VV5BgG(self, isFirstTime):
  self.VVEMOr   = os.path.basename(os.path.normpath(self.Path))
  self.VVEMOr   = "_".join(self.VVEMOr.split())
  self.VVWErH = self.VVEMOr.lower()
  self.VV3vcb = self.VVWErH == VV92IV.lower()
  if self.VV3vcb and self.VVWErH.endswith("ajpan"):
   self.VVWErH += "el"
  if self.VV3vcb : self.VVO1AL = VVBgPY
  else    : self.VVO1AL = CFG.packageOutputPath.getValue()
  self.VVO1AL = FFIm0p(self.VVO1AL)
  if not pathExists(self.controlPath):
   os.system(FFmogf("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VV3vcb : t = PLUGIN_NAME
  else    : t = self.VVEMOr
  self.VVMHP3(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVEdhy.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VV3vcb : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVMHP3(self.postrmFile, txt)
  if self.VV3vcb:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVIPCs)
   self.VVMHP3(self.preinstFile, txt)
  else:
   self.VVMHP3(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVEMOr)
  mode = self.VVJlIJ()
  if isFirstTime and not mode == self.VV32zC:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVkthi
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVMHP3(self.postinstFile, txt, VVCa4c=True)
  os.system(FFmogf("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VV3vcb : version, descripton, maintainer = VVIPCs , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVEMOr , self.VVEMOr
   txt = ""
   txt += "Package: %s\n"  % self.VViGz8(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVMHP3(self, path, lines, VVCa4c=False):
  if not fileExists(path) or VVCa4c:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VV48Uc(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFxHei(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFQRKC(line, VVo2ZM)
     elif not line.startswith(" ")    : line = FFQRKC(line, VVo2ZM)
     else          : line = FFQRKC(line, VVq6Xr)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVq6Xr
   else   : color = VVo2ZM
   descr = FFQRKC(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVo2ZM
     elif line.startswith((" ", "\t")) : color = VVo2ZM
     elif line.startswith("#")   : color = VVIbxt
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVyfa6(val, True)
      elif key == "Version"  : version, color = self.VVyfa6(val, False)
      elif key == "Maintainer" : maint  , color = val, VVq6Xr
      elif key == "Architecture" : arch  , color = val, VVq6Xr
      else:
       color = VVq6Xr
      if not key == "OE" and not key.istitle():
       color = VVo2ZM
     else:
      color = VVbvoH
     txt += FFQRKC(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVTTGE = self.VVO1AL + packageName
   self.VVasns = True
   errTxt = ""
  else:
   self.VVTTGE  = ""
   self.VVasns = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVyfa6(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVq6Xr
  else          : return val, VVo2ZM
 def VVlDBN(self):
  if not self.VVasns:
   FFy0Rl(self, "Please fix Control File errors first.")
   return
  if self.VVa20Y: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FF1zN0(self.VVXfKC, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVEMOr
  symlinkTo  = FFEMdz(self.Path)
  dataDir   = self.VVXfKC.rstrip("/")
  removePorjDir = FFmogf("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFmogf("rm -f '%s'" % self.VVTTGE) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFHrkw()
  if self.VVa20Y:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFG2Ge("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VV3vcb:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVXfKC == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVxpnA)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVTTGE, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVTTGE
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVTTGE, FFa6r1(result  , VVoiSL))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVXfKC, FFa6r1(instPath, VVq6Xr))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFa6r1(failed, VVo2ZM))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFtPYL(self, cmd)
class CCw1Kh(Screen):
 VVzBXb   = 0
 VVhLeF  = 1
 VVYJQQ = 20
 VVSBRv  = None
 def __init__(self, session, VVLZO1="/", mode=VVzBXb, VVsBgM="Select", VVhAiY=30, gotoMovie=False):
  self.skin, self.skinParam = FFvMLn(VVd6Yn, 1400, 920, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFEVgi(self)
  FFUxNa(self["keyRed"] , "Exit")
  FFUxNa(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVsBgM = VVsBgM
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  CCw1Kh.VVSBRv = self
  if self.gotoMovie        : VVG5Ta, self.VVLZO1 = True, CCw1Kh.VVRdh2(self)[0] or "/"
  elif   self.mode == self.VVzBXb : VVG5Ta, self.VVLZO1 = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVhLeF : VVG5Ta, self.VVLZO1 = False, VVLZO1
  else           : VVG5Ta, self.VVLZO1 = True , VVLZO1
  self.VVLZO1 = FFIm0p(self.VVLZO1)
  self["myMenu"] = CCbhaU(  directory   = "/"
         , VVG5Ta   = VVG5Ta
         , VVCVAP = True
         , VVjn7O   = self.skinParam["width"]
         , VVhAiY   = self.skinParam["bodyFontSize"]
         , VVAdb2  = self.skinParam["bodyLineH"]
         , VVAG9n  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVrVKJ      ,
   "red"    : self.VVrDmM     ,
   "green"    : self.VVXEnc    ,
   "yellow"   : self.VVqpa3   ,
   "blue"    : self.VVVAJC   ,
   "menu"    : self.VVGJEz    ,
   "info"    : self.VV7Tpe    ,
   "cancel"   : self.VVxH6T     ,
   "pageUp"   : self.VVxH6T     ,
   "chanUp"   : self.VVxH6T
  }, -1)
  FF9Mg2(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVOsZa)
 def onExit(self):
  CCw1Kh.VVSBRv = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVOsZa)
  FFUVmx(self)
  FFj85G(self["myMenu"], bg="#06003333")
  FFcxMz(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode == self.VVhLeF:
   FFUxNa(self["keyGreen"], self.VVsBgM)
   color = "#22000022"
   FFAt0z(self["myBody"], color)
   FFAt0z(self["myMenu"], color)
   color = "#22220000"
   FFAt0z(self["myTitle"], color)
   FFAt0z(self["myBar"], color)
  self.VVOsZa()
  if self.VVx1U5(self.VVLZO1) > self.bigDirSize:
   FF70nx(self, "Changing directory...")
   FFpblr(self.VVwEyr)
  else:
   self.VVwEyr()
 def VVwEyr(self):
  self["myMenu"].VVyrDC(self.VVLZO1)
  if self.gotoMovie:
   self.VVJEOe(chDir=False)
 def VV4mn9(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVVWf0(self):
  self["myMenu"].refresh()
  FFi4Qv()
 def VVx1U5(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VVrVKJ(self):
  if self["myMenu"].VVP1PY():
   path = self.VV0Hzy(self.VVzEsr())
   if self.VVx1U5(path) > self.bigDirSize:
    FF70nx(self, "Changing directory...")
    FFpblr(self.VVqMlz)
   else:
    self.VVqMlz()
  else:
   self.VVlBVz()
 def VVqMlz(self):
  self["myMenu"].descent()
  self.VVOsZa()
 def VVxH6T(self):
  if self["myMenu"].VVD695():
   self["myMenu"].moveToIndex(0)
   self.VVqMlz()
 def VVrDmM(self):
  if not FFvNec(self):
   self.close("")
 def VVXEnc(self):
  if self.mode == self.VVhLeF:
   path = self.VV0Hzy(self.VVzEsr())
   self.close(path)
 def VV7Tpe(self):
  FFTYCg(self, self.VVNVlV, title="Calculating size ...")
 def VVNVlV(self):
  path = self.VV0Hzy(self.VVzEsr())
  param = self.VVk8CZ(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFCdzs("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCw1Kh.VVPwKI(path)
     freeSize = CCw1Kh.VVONyB(path)
     size = totSize - freeSize
     totSize  = CCw1Kh.VV78Il(totSize)
     freeSize = CCw1Kh.VV78Il(freeSize)
    else:
     size = FFCdzs("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CCw1Kh.VV78Il(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFQRKC(pathTxt, VVbvoH) + "\n"
   if slBroken : fileTime = self.VVi3f3(path)
   else  : fileTime = self.VVKbHe(path)
   def VVvSHN(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVvSHN("Path"    , pathTxt)
   txt += VVvSHN("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVvSHN("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVvSHN("Total Size"   , "%s" % totSize)
    txt += VVvSHN("Used Size"   , "%s" % usedSize)
    txt += VVvSHN("Free Size"   , "%s" % freeSize)
   else:
    txt += VVvSHN("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVvSHN("Owner"    , owner)
   txt += VVvSHN("Group"    , group)
   txt += VVvSHN("Perm. (User)"  , permUser)
   txt += VVvSHN("Perm. (Group)"  , permGroup)
   txt += VVvSHN("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVvSHN("Perm. (Ext.)" , permExtra)
   txt += VVvSHN("iNode"    , iNode)
   txt += VVvSHN("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVkthi, VVkthi)
    txt += hLinkedFiles
   txt += self.VV4o4d(path)
  else:
   FFy0Rl(self, "Cannot access information !")
  if len(txt) > 0:
   FFNGa4(self, txt)
 def VVk8CZ(self, path):
  path = path.strip()
  path = FFEMdz(path)
  result = FFCdzs("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVbQBW(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVbQBW(perm, 1, 4)
   permGroup = VVbQBW(perm, 4, 7)
   permOther = VVbQBW(perm, 7, 10)
   permExtra = VVbQBW(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFgni4("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VV4o4d(self, path):
  txt  = ""
  res  = FFCdzs("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFQRKC("File Attributes:", VV0P8J), txt)
  return txt
 def VVKbHe(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFI3l2(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFI3l2(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFI3l2(os.path.getctime(path))
  return txt
 def VVi3f3(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFCdzs("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFCdzs("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFCdzs("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VV0Hzy(self, currentSel):
  currentDir  = self["myMenu"].VVD695()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVP1PY():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVzEsr(self):
  return self["myMenu"].getSelection()[0]
 def VVOsZa(self):
  FF70nx(self)
  path = self.VV0Hzy(self.VVzEsr())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VVOhES = self.VVpZlQ()
  if VVOhES and len(VVOhES) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VVW7ED(path)
  if self.mode == self.VVzBXb and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
 def VVW7ED(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVcTh6(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVGJEz(self):
  if self.mode == self.VVzBXb:
   path  = self.VV0Hzy(self.VVzEsr())
   isDir  = os.path.isdir(path)
   VVH93c = []
   VVH93c.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVBXSo(path):
     sepShown = True
     VVH93c.append(VVxSb7)
     VVH93c.append( (VVbvoH + "Archiving / Packaging"      , "VV3PAF"  ))
    if self.VVGa5E(path):
     if not sepShown:
      VVH93c.append(VVxSb7)
     VVH93c.append( (VVbvoH + "Read Backup information"     , "VVOMBS"  ))
     VVH93c.append( (VVbvoH + "Compress Octagon Image (to zip File)"  , "VV0Kt2" ))
   elif os.path.isfile(path):
    selFile = self.VVzEsr()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar")) : VVH93c.extend(self.VVjm9b(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVH93c.extend(self.VVFSM2(True))
    elif selFile.endswith(".m3u")              : VVH93c.extend(self.VVZd3r(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FFwvx4(path):
     VVH93c.append(VVxSb7)
     VVH93c.append((VVbvoH + "View" , "text_View" ))
     VVH93c.append((VVbvoH + "Edit" , "text_Edit" ))
    if len(txt) > 0:
     VVH93c.append(VVxSb7)
     VVH93c.append(   (VVbvoH + txt      , "VVlBVz"  ))
   VVH93c.append(VVxSb7)
   VVH93c.append(     ("Create SymLink"       , "VVv8Qu" ))
   if not self.VVBXSo(path):
    VVH93c.append(   ("Rename"          , "VVYYAQ" ))
    VVH93c.append(   ("Copy"           , "copyFileOrDir" ))
    VVH93c.append(   ("Move"           , "moveFileOrDir" ))
    VVH93c.append(   ("DELETE"          , "VVVOo7" ))
    if fileExists(path):
     VVH93c.append(VVxSb7)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVH93c.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVH93c.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVH93c.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVH93c.append(VVxSb7)
   VVH93c.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVH93c.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fName = CCw1Kh.VVRdh2(self)
   if fPath:
    VVH93c.append(VVxSb7)
    VVH93c.append(   (VVllxZ + "Go to current movie"  , "VVJEOe"))
   VVH93c.append(VVxSb7)
   VVH93c.append(    ("Set current directory as \"Startup Path\"" , "VVvpbB" ))
   FFSEnE(self, self.VV2Ojt, title="Options", VVH93c=VVH93c)
 def VV2Ojt(self, item=None):
  if self.mode == self.VVzBXb:
   if item is not None:
    path = self.VV0Hzy(self.VVzEsr())
    selFile = self.VVzEsr()
    if   item == "properties"    : self.VV7Tpe()
    elif item == "VV3PAF"  : self.VV3PAF(path)
    elif item == "VVOMBS"  : self.VVOMBS(path)
    elif item == "VV0Kt2" : self.VV0Kt2(path)
    elif item.startswith("extract_")  : self.VVjxKY(path, selFile, item)
    elif item.startswith("script_")   : self.VVMbr6(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVBwCVItem_m3u(path, selFile, item)
    elif item.startswith("text_View")  : FFdAGY(self, path)
    elif item.startswith("text_Edit")  : CC6xEh(self, path)
    elif item == "chmod644"     : self.VVWwhp(path, selFile, "644")
    elif item == "chmod755"     : self.VVWwhp(path, selFile, "755")
    elif item == "chmod777"     : self.VVWwhp(path, selFile, "777")
    elif item == "VVv8Qu"   : self.VVv8Qu(path, selFile)
    elif item == "VVYYAQ"   : self.VVYYAQ(path, selFile)
    elif item == "copyFileOrDir"   : self.VVIn4T(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVIn4T(path, selFile, True)
    elif item == "VVVOo7"   : self.VVVOo7(path, selFile)
    elif item == "createNewFile"   : self.VVzf2y(path, True)
    elif item == "createNewDir"    : self.VVzf2y(path, False)
    elif item == "VVJEOe"   : self.VVJEOe()
    elif item == "VVvpbB"   : self.VVvpbB(path)
    elif item == "VVlBVz"    : self.VVlBVz()
    else         : self.close()
 def VVlBVz(self):
  selFile = self.VVzEsr()
  path  = self.VV0Hzy(selFile)
  if os.path.isfile(path):
   VVYCFx = []
   category = self["myMenu"].VVHjc1(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVLWB2(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FFzr12(self, selFile, path)
   elif category == "txt"         : FFdAGY(self, path)
   elif category in ("tar", "zip", "rar")     : self.VVm1Tg(path, selFile)
   elif category == "scr"         : self.VVbm1G(path, selFile)
   elif category == "m3u"         : self.VVbk0J(path, selFile)
   elif category in ("ipk", "deb")       : self.VV4bOF(path, selFile)
   elif category == "mus"         : self.VVZGwk(self, path)
   elif category == "mov"         : self.VVZGwk(self, path)
   elif not FFwvx4(path)        : FFdAGY(self, path)
 def VVqpa3(self):
  path = self.VV0Hzy(self.VVzEsr())
  action = self.VVW7ED(path)
  if action == 1:
   self.VVcQiu(path)
   FF70nx(self, "Added", 500)
  elif action == -1:
   self.VVRp9c(path)
   FF70nx(self, "Removed", 500)
  self.VVW7ED(path)
 def VVcQiu(self, path):
  VVOhES = self.VVpZlQ()
  if not VVOhES:
   VVOhES = []
  if len(VVOhES) >= self.VVYJQQ:
   FFy0Rl(SELF, "Max bookmarks reached (max=%d)." % self.VVYJQQ)
  elif not path in VVOhES:
   VVOhES = [path] + VVOhES
   self.VVFWdW(VVOhES)
 def VVVAJC(self):
  VVOhES = self.VVpZlQ()
  if VVOhES:
   newList = []
   for line in VVOhES:
    newList.append((line, line))
   VVURxH  = ("Delete"  , self.VVEFA9 )
   VVSptY = ("Move Up"   , self.VV4p6O )
   VVM3vl  = ("Move Down" , self.VVuZj2 )
   self.bookmarkMenu = FFSEnE(self, self.VVhJL4, title="Bookmarks", VVH93c=newList, VVURxH=VVURxH, VVSptY=VVSptY, VVM3vl=VVM3vl)
 def VVEFA9(self, VVzEsrObj, path):
  if self.bookmarkMenu:
   VVOhES = self.VVRp9c(path)
   self.bookmarkMenu.VV8Y9R(VVOhES)
 def VV4p6O(self, VVzEsrObj, path):
  if self.bookmarkMenu:
   VVOhES = self.bookmarkMenu.VVBJmX(True)
   if VVOhES:
    self.VVFWdW(VVOhES)
 def VVuZj2(self, VVzEsrObj, path):
  if self.bookmarkMenu:
   VVOhES = self.bookmarkMenu.VVBJmX(False)
   if VVOhES:
    self.VVFWdW(VVOhES)
 def VVhJL4(self, folder=None):
  if folder:
   folder = FFIm0p(folder)
   self["myMenu"].VVyrDC(folder)
   self["myMenu"].moveToIndex(0)
  self.VVOsZa()
 def VVpZlQ(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVcTh6(self, path):
  VVOhES = self.VVpZlQ()
  if VVOhES and path in VVOhES:
   return True
  else:
   return False
 def VV61Oa(self):
  if VVpZlQ():
   return True
  else:
   return False
 def VVFWdW(self, VVOhES):
  line = ",".join(VVOhES)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVRp9c(self, path):
  VVOhES = self.VVpZlQ()
  if VVOhES:
   while path in VVOhES:
    VVOhES.remove(path)
   self.VVFWdW(VVOhES)
   return VVOhES
 def VVJEOe(self, chDir=True):
  fPath, fName = CCw1Kh.VVRdh2(self)
  if fPath and fName:
   if chDir:
    fPath = FFIm0p(fPath)
    self["myMenu"].VVyrDC(fPath)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FF70nx(self, "Not found", 1000)
 def VVvpbB(self, path):
  if not os.path.isdir(path):
   path = FF1zN0(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVLWB2(self, selFile, VVWYUn, command):
  FF3096(self, boundFunction(FFtPYL, self, command, VVD4UQ=self.VVVWf0), "%s\n\n%s" % (VVWYUn, selFile))
 def VVjm9b(self, path, calledFromMenu):
  destPath = self.VVR1Rp(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVH93c = []
  if calledFromMenu:
   VVH93c.append(VVxSb7)
   color = VVbvoH
  else:
   color = ""
  VVH93c.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVH93c.append(VVxSb7)
  VVH93c.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVH93c.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVH93c.append((color + "Extract Here"            , "extract_here"  ))
  if VVLoj5 and path.endswith(".tar.gz"):
   VVH93c.append(VVxSb7)
   VVH93c.append((color + 'Convert to ".ipk" Package' , "VV4tst"  ))
   VVH93c.append((color + 'Convert to ".deb" Package' , "VVIeOL"  ))
  return VVH93c
 def VVm1Tg(self, path, selFile):
  FFSEnE(self, boundFunction(self.VVjxKY, path, selFile), title="Compressed File Options", VVH93c=self.VVjm9b(path, False))
 def VVjxKY(self, path, selFile, item=None):
  if item is not None:
   parent  = FF1zN0(path, False)
   destPath = self.VVR1Rp(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVkthi
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFG2Ge("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFG2Ge("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVkthi, VVkthi)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFYoKS(self, cmd)
   elif path.endswith(".zip"):
    self.VVvSok(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif path.endswith(".rar"):
    self.VV55Qh(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFmogf("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVLWB2(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVLWB2(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FF1zN0(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVLWB2(selFile, "Extract Here ?"      , cmd)
   elif item == "VV4tst" : self.VV4tst(path)
   elif item == "VVIeOL" : self.VVIeOL(path)
 def VVR1Rp(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVvSok(self, item, path, parent, destPath, VVWYUn):
  FF3096(self, boundFunction(self.VVLnlv, item, path, parent, destPath), VVWYUn)
 def VVLnlv(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVkthi
  cmd  = FFG2Ge("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFa6r1(destPath, VVoiSL))
  cmd +=   sep
  cmd += "fi;"
  FF68Dg(self, cmd, VVD4UQ=self.VVVWf0)
 def VV55Qh(self, item, path, parent, destPath, VVWYUn):
  FF3096(self, boundFunction(self.VVO4v2, item, path, parent, destPath), VVWYUn)
 def VVO4v2(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFIm0p(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVkthi
  cmd  = FFG2Ge("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFa6r1(destPath, VVoiSL))
  cmd +=   sep
  cmd += "fi;"
  FF68Dg(self, cmd, VVD4UQ=self.VVVWf0)
 def VVFSM2(self, addSep=False):
  VVH93c = []
  if addSep:
   VVH93c.append(VVxSb7)
  VVH93c.append((VVbvoH + "View Script File"  , "script_View"  ))
  VVH93c.append((VVbvoH + "Execute Script File" , "script_Execute" ))
  VVH93c.append((VVbvoH + "Edit"     , "script_Edit" ))
  return VVH93c
 def VVbm1G(self, path, selFile):
  FFSEnE(self, boundFunction(self.VVMbr6, path, selFile), title="Script File Options", VVH93c=self.VVFSM2())
 def VVMbr6(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFdAGY(self, path)
   elif item == "script_Execute" : self.VVLWB2(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CC6xEh(self, path)
 def VVZd3r(self, addSep=False):
  VVH93c = []
  if addSep:
   VVH93c.append(VVxSb7)
  VVH93c.append((VVbvoH + "View"      , "m3u_View" ))
  VVH93c.append((VVbvoH + "Edit"      , "m3u_Edit" ))
  VVH93c.append((VVbvoH + "Convert to IPTV Bouquet" , "m3u_Convert" ))
  return VVH93c
 def VVbk0J(self, path, selFile):
  FFSEnE(self, boundFunction(self.VVBwCVItem_m3u, path, selFile), title="M3U File Options", VVH93c=self.VVZd3r())
 def VVBwCVItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_View"  : FFdAGY(self, path)
   elif item == "m3u_Edit"  : CC6xEh(self, path)
   elif item == "m3u_Convert" : CCxu1n.VVR0Wv(self, path, False)
 def VVWwhp(self, path, selFile, newChmod):
  FF3096(self, boundFunction(self.VV2nvL, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VV2nvL(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VV0PME)
  result = FFCdzs(cmd)
  if result == "Successful" : FFM9af(self, result)
  else      : FFy0Rl(self, result)
 def VVv8Qu(self, path, selFile):
  parent = FF1zN0(path, False)
  self.session.openWithCallback(self.VVRVV9, boundFunction(CCw1Kh, mode=CCw1Kh.VVhLeF, VVLZO1=parent, VVsBgM="Create Symlink here"))
 def VVRVV9(self, newPath):
  if len(newPath) > 0:
   target = self.VV0Hzy(self.VVzEsr())
   target = FFEMdz(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFIm0p(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFy0Rl(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FF3096(self, boundFunction(self.VVQf6e, target, link), "Create Soft Link ?\n\n%s" % txt, VVZH0D=True)
 def VVQf6e(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VV0PME)
  result = FFCdzs(cmd)
  if result == "Successful" : FFM9af(self, result)
  else      : FFy0Rl(self, result)
 def VVYYAQ(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFpA7M(self, boundFunction(self.VVmny3, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVmny3(self, path, selFile, VVNEJF):
  if VVNEJF:
   parent = FF1zN0(path, True)
   if os.path.isdir(path):
    path = FFEMdz(path)
   newName = parent + VVNEJF
   cmd = "mv '%s' '%s' %s" % (path, newName, VV0PME)
   if VVNEJF:
    if selFile != VVNEJF:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FF3096(self, boundFunction(self.VV0Lf6, cmd), message, title="Rename file?")
    else:
     FFy0Rl(self, "Cannot use same name!", title="Rename")
 def VV0Lf6(self, cmd):
  result = FFCdzs(cmd)
  if "Fail" in result:
   FFy0Rl(self, result)
  self.VVVWf0()
 def VVIn4T(self, path, selFile, isMove):
  if isMove : VVsBgM = "Move to here"
  else  : VVsBgM = "Copy to here"
  parent = FF1zN0(path, False)
  self.session.openWithCallback(boundFunction(self.VVQiHJ, isMove, path, selFile)
         , boundFunction(CCw1Kh, mode=CCw1Kh.VVhLeF, VVLZO1=parent, VVsBgM=VVsBgM))
 def VVQiHJ(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFEMdz(path)
   newPath = FFIm0p(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FF3096(self, boundFunction(FF4bPN, self, cmd, VVD4UQ=self.VVVWf0), txt, VVZH0D=True)
   else:
    FFy0Rl(self, "Cannot %s to same directory !" % action.lower())
 def VVVOo7(self, path, fileName):
  path = FFEMdz(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FF3096(self, boundFunction(self.VV7EAN, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VV7EAN(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VVVWf0()
 def VVBXSo(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVcuSx and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVzf2y(self, path, isFile):
  dirName = FFIm0p(os.path.dirname(path))
  if isFile : objName, VVNEJF = "File"  , self.edited_newFile
  else  : objName, VVNEJF = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFpA7M(self, boundFunction(self.VVMnK2, dirName, isFile, title), title=title, defaultText=VVNEJF, message="Enter %s Name:" % objName)
 def VVMnK2(self, dirName, isFile, title, VVNEJF):
  if VVNEJF:
   if isFile : self.edited_newFile = VVNEJF
   else  : self.edited_newDir  = VVNEJF
   path = dirName + VVNEJF
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VV0PME)
    else  : cmd = "mkdir '%s' %s" % (path, VV0PME)
    result = FFCdzs(cmd)
    if "Fail" in result:
     FFy0Rl(self, result)
    self.VVVWf0()
   else:
    FFy0Rl(self, "Name already exists !\n\n%s" % path, title)
 def VV4bOF(self, path, selFile):
  VVH93c = []
  VVH93c.append(("List Package Files"          , "VVARv2"     ))
  VVH93c.append(("Package Information"          , "VV0EE5"     ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Install Package"           , "VVPLZv_CheckVersion" ))
  VVH93c.append(("Install Package (force reinstall)"      , "VVPLZv_ForceReinstall" ))
  VVH93c.append(("Install Package (force downgrade)"      , "VVPLZv_ForceDowngrade" ))
  VVH93c.append(("Install Package (ignore failed dependencies)"    , "VVPLZv_IgnoreDepends" ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Remove Related Package"         , "VVnX7h_ExistingPackage" ))
  VVH93c.append(("Remove Related Package (force remove)"     , "VVnX7h_ForceRemove"  ))
  VVH93c.append(("Remove Related Package (ignore failed dependencies)"  , "VVnX7h_IgnoreDepends" ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("Extract Files"           , "VVtMwO"     ))
  VVH93c.append(("Unbuild Package"           , "VVpati"     ))
  FFSEnE(self, boundFunction(self.VVVOlf, path, selFile), VVH93c=VVH93c)
 def VVVOlf(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVARv2"      : self.VVARv2(path, selFile)
   elif item == "VV0EE5"      : self.VV0EE5(path)
   elif item == "VVPLZv_CheckVersion"  : self.VVPLZv(path, selFile, VVzZPa     )
   elif item == "VVPLZv_ForceReinstall" : self.VVPLZv(path, selFile, VVGnsR )
   elif item == "VVPLZv_ForceDowngrade" : self.VVPLZv(path, selFile, VVs217 )
   elif item == "VVPLZv_IgnoreDepends" : self.VVPLZv(path, selFile, VV1pls )
   elif item == "VVnX7h_ExistingPackage" : self.VVnX7h(path, selFile, VVuYpF     )
   elif item == "VVnX7h_ForceRemove"  : self.VVnX7h(path, selFile, VVJmSo  )
   elif item == "VVnX7h_IgnoreDepends"  : self.VVnX7h(path, selFile, VV4AUp )
   elif item == "VVtMwO"     : self.VVtMwO(path, selFile)
   elif item == "VVpati"     : self.VVpati(path, selFile)
   else           : self.close()
 def VVARv2(self, path, selFile):
  if FFeAYH("ar") : cmd = "allOK='1';"
  else    : cmd  = FFHrkw()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVkthi, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVkthi, VVkthi)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFasfN(self, cmd, VVD4UQ=self.VVVWf0)
 def VVtMwO(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FF1zN0(path, True) + selFile[:-4]
  cmd  =  FFHrkw()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFmogf("mkdir '%s'" % dest) + ";"
  cmd +=    FFmogf("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFa6r1(dest, VVoiSL))
  cmd += "fi;"
  FFtPYL(self, cmd, VVD4UQ=self.VVVWf0)
 def VVpati(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVWm9U = os.path.splitext(path)[0]
  else        : VVWm9U = path + "_"
  if path.endswith(".deb")   : VVxpnA = "DEBIAN"
  else        : VVxpnA = "CONTROL"
  cmd  = FFHrkw()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVWm9U, FFSt8V())
  cmd += "  mkdir '%s';"    % VVWm9U
  cmd += "  CONTPATH='%s/%s';"  % (VVWm9U, VVxpnA)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVWm9U
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVWm9U, VVWm9U)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVWm9U
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVWm9U, VVWm9U)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVWm9U
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVWm9U
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVWm9U, FFa6r1(VVWm9U, VVoiSL))
  cmd += "fi;"
  FFtPYL(self, cmd, VVD4UQ=self.VVVWf0)
 def VV0EE5(self, path):
  listCmd  = FFfvin(VVhRz7, "")
  infoCmd  = FFrD2J(VVxXfv , "")
  filesCmd = FFrD2J(VV2shS, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFfq9Z(VVllxZ)
   notInst = "Package not installed."
   cmd  = FF0v1F("File Info", VVllxZ)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FF0v1F("System Info", VVllxZ)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFa6r1(notInst, VVbvoH))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FF0v1F("Related Files", VVllxZ)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFYoKS(self, cmd)
  else:
   FFkPbc(self)
 def VVPLZv(self, path, selFile, cmdOpt):
  cmd = FFrD2J(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FF3096(self, boundFunction(FFtPYL, self, cmd, VVD4UQ=FFi4Qv), "Install Package ?\n\n%s" % selFile)
  else:
   FFkPbc(self)
 def VVnX7h(self, path, selFile, cmdOpt):
  listCmd  = FFfvin(VVhRz7, "")
  infoCmd  = FFrD2J(VVxXfv, "")
  instRemCmd = FFrD2J(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFa6r1(errTxt, VVbvoH))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFa6r1(cannotTxt, VVbvoH))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFa6r1(tryTxt, VVbvoH))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FF3096(self, boundFunction(FFtPYL, self, cmd, VVD4UQ=FFi4Qv), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFkPbc(self)
 def VVeYDd(self, path):
  hostName = FFCdzs("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVGa5E(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVeYDd(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VV3PAF(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVH93c = []
  VVH93c.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVH93c.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVH93c.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVH93c.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVH93c.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVH93c.append(VVxSb7)
  VVH93c.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVH93c.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVH93c.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVH93c.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVH93c.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVH93c.append(VVxSb7)
  VVH93c.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVH93c.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FFSEnE(self, boundFunction(self.VVnbxd, path), VVH93c=VVH93c)
 def VVnbxd(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VViluP(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VViluP(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VViluP(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VViluP(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VViluP(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VViluP(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VViluP(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VViluP(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VViluP(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VViluP(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVP6t6(path, False)
   elif item == "convertDirToDeb"   : self.VVP6t6(path, True)
   else         : self.close()
 def VVP6t6(self, path, VVa20Y):
  self.session.openWithCallback(self.VVVWf0, boundFunction(CCXdvo, path=path, VVa20Y=VVa20Y))
 def VViluP(self, path, fileExt, preserveDirStruct):
  parent  = FF1zN0(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFG2Ge("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFG2Ge("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFG2Ge("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVkthi
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFmogf("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FFa6r1(resultFile, VVoiSL))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FFa6r1(failed, VVo2ZM))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFasfN(self, cmd, VVD4UQ=self.VVVWf0)
 def VVOMBS(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFdAGY(self, versionFile)
 def VV0Kt2(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVeYDd(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFy0Rl(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFxHei(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FF1zN0(path, False)
  VVWm9U = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FFa6r1(errCmd, VVo2ZM))
  installCmd = FFrD2J(VVzZPa , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VVWm9U, VVWm9U)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VVWm9U
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VVWm9U
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VVWm9U, VVWm9U)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFtPYL(self, cmd, VVD4UQ=self.VVVWf0)
 def VV4tst(self, path):
  FFy0Rl(self, "Under Construction.")
 def VVIeOL(self, path):
  FFy0Rl(self, "Under Construction.")
 @staticmethod
 def VVZGwk(SELF, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   SELF.session.open(CCqamV, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVRdh2(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  path = serv and serv.getPath()
  if path and fileExists(path):
   Dir, fName = os.path.split(path)
   return FFIm0p(Dir), fName
  return "", ""
 @staticmethod
 def VVPwKI(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVONyB(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VV78Il(size, mode=0):
  txt = CCw1Kh.VVWxXI(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVWxXI(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
class CCbhaU(MenuList):
 def __init__(self, VVCVAP=False, directory="/", VVC6CA=True, VVG5Ta=True, VV4gQE=True, VVrXXU=None, VVNQTP=False, VVPKQH=False, VV1lrC=False, isTop=False, VV25VB=None, VVjn7O=1000, VVhAiY=30, VVAdb2=30, VVAG9n="#00000000"):
  MenuList.__init__(self, list, VVCVAP, eListboxPythonMultiContent)
  self.VVC6CA  = VVC6CA
  self.VVG5Ta    = VVG5Ta
  self.VV4gQE  = VV4gQE
  self.VVrXXU  = VVrXXU
  self.VVNQTP   = VVNQTP
  self.VVPKQH   = VVPKQH or []
  self.VV1lrC   = VV1lrC or []
  self.isTop     = isTop
  self.additional_extensions = VV25VB
  self.VVjn7O    = VVjn7O
  self.VVhAiY    = VVhAiY
  self.VVAdb2    = VVAdb2
  self.pngBGColor    = FFzKP2(VVAG9n)
  self.EXTENSIONS    = self.VVbhEV()
  self.VVwjcZ   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVXu7B, self.VVhAiY))
  self.l.setItemHeight(self.VVAdb2)
  self.png_mem   = self.VVZjXl("mem")
  self.png_usb   = self.VVZjXl("usb")
  self.png_fil   = self.VVZjXl("fil")
  self.png_dir   = self.VVZjXl("dir")
  self.png_dirup   = self.VVZjXl("dirup")
  self.png_srv   = self.VVZjXl("srv")
  self.png_slwfil   = self.VVZjXl("slwfil")
  self.png_slbfil   = self.VVZjXl("slbfil")
  self.png_slwdir   = self.VVZjXl("slwdir")
  self.VVqSkc()
  self.VVyrDC(directory)
 def VVZjXl(self, category):
  return LoadPixmap("%s%s.png" % (VVHIBy, category), getDesktop(0))
 def VVbhEV(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "rar" : "rar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u"
  }
 def VVLKea(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFEMdz(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFQRKC(" -> " , VVllxZ) + FFQRKC(os.readlink(path), VVoiSL)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVAdb2 + 10, 0, self.VVjn7O, self.VVAdb2, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VViIbq: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVAdb2-4, self.VVAdb2-4, png, self.pngBGColor, self.pngBGColor, VViIbq))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVAdb2-4, self.VVAdb2-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVHjc1(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVqSkc(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVq3am(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VV2PyO(self, file):
  if os.path.realpath(file) == file:
   return self.VVq3am(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVq3am(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVq3am(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVrHwZ(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVwjcZ.info(l[0][0]).getEvent(l[0][0])
 def VV2QdB(self):
  return self.list
 def VVYVUX(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVyrDC(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VV4gQE:
    self.current_mountpoint = self.VV2PyO(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VV4gQE:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VV1lrC and not self.VVYVUX(path, self.VVPKQH):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVLKea(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVNQTP:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVwjcZ = eServiceCenter.getInstance()
   list = VVwjcZ.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVC6CA and not self.isTop:
   if directory == self.current_mountpoint and self.VV4gQE:
    self.list.append(self.VVLKea(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VV1lrC and self.VVq3am(directory) in self.VV1lrC):
    self.list.append(self.VVLKea(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVC6CA:
   for x in directories:
    if not (self.VV1lrC and self.VVq3am(x) in self.VV1lrC) and not self.VVYVUX(x, self.VVPKQH):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVLKea(name = name, absolute = x, isDir = True, png = png))
  if self.VVG5Ta:
   for x in files:
    if self.VVNQTP:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFQRKC(" -> " , VVllxZ) + FFQRKC(target, VVoiSL)
       else:
        png = self.png_slbfil
        name += FFQRKC(" -> " , VVllxZ) + FFQRKC(target, VVo2ZM)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVHjc1(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVHIBy, category))
    if (self.VVrXXU is None) or iCompile(self.VVrXXU).search(path):
     self.list.append(self.VVLKea(name = name, absolute = x , isDir = False, png = png))
  if self.VV4gQE and len(self.list) == 0:
   self.list.append(self.VVLKea(name = FFQRKC("No USB connected", VVIbxt), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVD695(self):
  return self.current_directory
 def VVP1PY(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVyrDC(self.getSelection()[0], select = self.current_directory)
 def VVot8T(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVatAQ(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVxygX)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVxygX)
 def refresh(self):
  self.VVyrDC(self.current_directory, self.VVot8T())
 def VVxygX(self, action, device):
  self.VVqSkc()
  if self.current_directory is None:
   self.refresh()
class CCnw9u(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FFvMLn(VVAwpk, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVOhES   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVUeuD(defFG, "#00FFFFFF")
  self.defBG   = self.VVUeuD(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFEVgi(self, self.Title)
  self["keyRed"].show()
  FFUxNa(self["keyGreen"] , "< > Transp.")
  FFUxNa(self["keyYellow"], "Foreground")
  FFUxNa(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVy2vd        ,
   "yellow"   : boundFunction(self.VV7IlD, False)  ,
   "blue"   : boundFunction(self.VV7IlD, True)  ,
   "up"   : self.VV95Cz          ,
   "down"   : self.VVgVbh         ,
   "left"   : self.VV1LAe         ,
   "right"   : self.VVMG16         ,
   "last"   : boundFunction(self.VVpow6, -5) ,
   "next"   : boundFunction(self.VVpow6, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVYVvL)
 def VVYVvL(self):
  self.onShown.remove(self.VVYVvL)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFAt0z(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFAt0z(self["keyRed"] , c)
  FFAt0z(self["keyGreen"] , c)
  self.VVz8WJ()
  self.VVmtGG()
  FFQGsp(self["myColorTst"], self.defFG)
  FFAt0z(self["myColorTst"], self.defBG)
 def VVUeuD(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVmtGG(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVLCHa(0, 0)
     return
 def VVy2vd(self):
  self.close(self.defFG, self.defBG)
 def VV95Cz(self): self.VVLCHa(-1, 0)
 def VVgVbh(self): self.VVLCHa(1, 0)
 def VV1LAe(self): self.VVLCHa(0, -1)
 def VVMG16(self): self.VVLCHa(0, 1)
 def VVLCHa(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVpylL()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVv5sE()
 def VVz8WJ(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVv5sE(self):
  color = self.VVpylL()
  if self.isBgMode: FFAt0z(self["myColorTst"], color)
  else   : FFQGsp(self["myColorTst"], color)
 def VV7IlD(self, isBg):
  self.isBgMode = isBg
  self.VVz8WJ()
  self.VVmtGG()
 def VVpow6(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVLCHa(0, 0)
 def VVlT8g(self):
  return hex(self.transp)[2:].zfill(2)
 def VVpylL(self):
  return ("#%s%s" % (self.VVlT8g(), self.colors[self.curRow][self.curCol])).upper()
class CCXDUQ(ScrollLabel):
 def __init__(self, parentSELF, text="", VVcO9q=True):
  ScrollLabel.__init__(self, text)
  self.VVcO9q=VVcO9q
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VV7vW9  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVhAiY    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close   ,
   "cancel"  : parentSELF.close   ,
   "red"   : self.VV9M8M   ,
   "green"   : self.VV5AUB  ,
   "yellow"  : self.VVtAhT  ,
   "blue"   : self.VVmPkc  ,
   "up"   : self.pageUp    ,
   "down"   : self.pageDown    ,
   "left"   : self.pageUp    ,
   "right"   : self.pageDown    ,
   "pageUp"  : self.VVXlI9    ,
   "chanUp"  : self.VVXlI9    ,
   "pageDown"  : self.VVgtR0    ,
   "chanDown"  : self.VVgtR0
  }, -1)
 def VVaX06(self, isResizable=True, VVFdco=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FFcxMz(self.parentSELF, True)
  self.isResizable = isResizable
  if VVFdco:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVhAiY  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFAt0z(self, color)
 def FFAt0zColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VV7vW9 - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVXvfX()
 def pageUp(self):
  if self.VV7vW9 > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VV7vW9 > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVXlI9(self):
  self.setPos(0)
 def VVgtR0(self):
  self.setPos(self.VV7vW9-self.pageHeight)
 def VVZM8I(self):
  return self.VV7vW9 <= self.pageHeight or self.curPos == self.VV7vW9 - self.pageHeight
 def VVXvfX(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VV7vW9, 3))
   start = int((100 - vis) * self.curPos / (self.VV7vW9 - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVTcLD=VV64Ja):
  old_VVZM8I = self.VVZM8I()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VV7vW9 = self.long_text.calculateSize().height()
   if self.VVcO9q and self.VV7vW9 > self.pageHeight:
    self.scrollbar.show()
    self.VVXvfX()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VV7vW9))
   if   VVTcLD == VV9wvN: self.setPos(0)
   elif VVTcLD == VVpBFp : self.VVgtR0()
   elif old_VVZM8I    : self.VVgtR0()
 def appendText(self, text, VVTcLD=VVpBFp):
  self.setText(self.message + str(text), VVTcLD)
 def VVtAhT(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVeRsj(size)
 def VVmPkc(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVeRsj(size)
 def VV5AUB(self):
  self.VVeRsj(self.VVhAiY)
 def VVeRsj(self, VVhAiY):
  self.long_text.setFont(gFont(self.fontFamily, VVhAiY))
  self.setText(self.message, VVTcLD=VV64Ja)
  self.VV55as(calledFromFontSizer=True)
 def VV9M8M(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FFIm0p(expPath), self.textOutFile, FFVgvw())
    with open(outF, "w") as f:
     f.write(FFuz5p(self.message))
    FFM9af(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FFy0Rl(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VV55as(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VV7vW9 > 0 and self.pageHeight > 0:
   if self.VV7vW9 < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VV7vW9
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
