import os
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import ceil as iCeil
from time      import localtime, mktime, strftime, time as iTime
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVTPuM   = "v3.3.0"
VVTh9m    = "26-12-2021"
EASY_MODE    = 0
VVYUqF   = 0
VVFHVA   = 0
VVgQjM  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVdP4f  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVaZdT    = "/media/usb/"
VV4dqz    = "/usr/share/enigma2/picon/"
VVVAau   = "/etc/enigma2/"
VVvxim  = "ajpanel_update_url"
VVHFp6   = "AJPan"
VVl5oV    = "AUTO FIND"
VVD5fX    = ""
VVOYdo    = "Regular"
VV1xmU      = "-" * 80;
VV8PP6    = ("-" * 100, )
VVXLue    = ""
VVOmuD   = " && echo 'Successful' || echo 'Failed!'"
VVuOU2    = []
VVhENq  = "Cannot continue (No Enough Memory) !"
VVJl2a     = 0
VVsbWy    = ""
VVcBAa  = False
VVlmpc  = False
VVrFFh = False
VVwo8o     = 0
VVfta0    = 1
VVMgH3    = 2
VVuN0K   = 3
VVLYwe    = 4
VVayJ6    = 5
VVI3k3 = 6
VVdxXE = 7
VV6Mem  = 8
VVZ2Wm   = 9
VV3lRK   = 10
VVOZNr   = 11
VVN2xn  = 12
VV9ZKP  = 13
VVkvWJ    = 14
VVvMST   = 15
VVGuYX   = 16
VVSsGW    = 17
VV8Sie    = 18
VVCfSO  = 15
VVbrHn   = 0
VVyd8y   = 1
VVtGrg   = 2
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices = [ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices = [ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices = [ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices = [ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsPath    = ConfigDirectory(default=VVl5oV, visible_width=51)
CFG.PIconsPath     = ConfigDirectory(default=VV4dqz, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVaZdT, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
def FFPRBQ():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVy7yj  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVzemk = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVy7yj  : return 0
  elif VVzemk : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVnAll = FFPRBQ()
VVcwMp = VVPTHk = VVu486 = VVEAFU = VVSsUL = VVVFfb = VVFGoE = VVclxO = COLOR_CONS_BRIGHT_YELLOW = VVylYU = VVrHls = VV6kBj = VVYHoM = ""
def FF5fUA(FF5fUAText="", addSep=True):
 if VVYUqF:
  FF5fUAText = str(FF5fUAText)
  if "\n" in FF5fUAText: FF5fUAText = "\n" + FF5fUAText
  txt = VV1xmU + "\n" if addSep else ""
  txt += ">>>> %s >>  %s" % (PLUGIN_NAME, str(FF5fUAText))
  os.system("cat << '_EOF' \n" + txt + "\n_EOF")
def FF2qTy(txt, isAppend=True, ignoreErr=False):
 if VVYUqF:
  tm = FFjtVU()
  err = ""
  if not ignoreErr:
   try:
    from traceback import format_exc, format_stack
    trace = format_exc()
    if trace and len(trace) > 5:
     stack = format_stack()[:-1]
     sep = "*" * 70
     err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
     err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   except:
    pass
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FF5fUA(err)
  FF5fUA("Output Log File : %s" % fileName)
VVuOU2 = []
def FFn48g(win):
 global VVuOU2
 if not win in VVuOU2:
  VVuOU2.append(win)
def FFQSOu(*args):
 global VVuOU2
 for win in VVuOU2:
  try:
   win.close()
  except:
   pass
 VVuOU2 = []
def FF3LhQ():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVxRFr = FF3LhQ()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FF53fi()     : return PluginDescriptor(fnc=FFola8, where=[PluginDescriptor.WHERE_SESSIONSTART] , needsRestart=True   , description="AJPanel Startup")
def FFh9Fj()      : return getDescriptor(FFcpvI   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFnGLo()       : return getDescriptor(FFVXTy  , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFGoB4()   : return getDescriptor(FFj52V , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFeW8D(): return getDescriptor(FFFhM4 , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player"  , descr="Signal Monitor / Player")
def FFUqgi()  : return getDescriptor(FFvoXg  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV"     , descr="IPTV Menu")
def FF6hmp()     : return getDescriptor(FFOaTM , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info."    , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFh9Fj() , FFnGLo() , FF53fi() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFGoB4())
  result.append(FFeW8D())
  result.append(FFUqgi())
 if CFG.EventsInfoMenu.getValue():
  result.append(FF6hmp())
 return result
def FFola8(reason, **kwargs):
 if reason == 0:
  FFFuoG()
  if "session" in kwargs:
   session = kwargs["session"]
   FFXUoN(session)
   CCv82q(session)
def FFVXTy(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFcpvI, PLUGIN_NAME, 45)]
 else:
  return []
def FFcpvI(session, **kwargs):
 session.open(Main_Menu)
def FFj52V(session, **kwargs):
 session.open(CCQ4SG)
def FFFhM4(session, **kwargs):
 FFWYRU(session, isFromSession=True)
def FFvoXg(session, **kwargs):
 session.open(CCfvbT)
def FFOaTM(session, **kwargs):
 session.open(CCf574, fncMode=CCf574.VVaQXu)
def FFaRWQ():
 FFWDWC(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFGoB4(), FFeW8D(), FFUqgi() ])
 FFWDWC(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FF6hmp() ])
def FFWDWC(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VVyz99 = None
def FFFuoG():
 try:
  global VVyz99
  if VVyz99 is None:
   VVyz99    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFOVvx
  ChannelContextMenu.FFXNKz = FFXNKz
 except:
  pass
def FFOVvx(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVyz99(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFXNKz, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFXNKz, title1, csel, isFind=True))))
def FFXNKz(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFPdrd(refCode)
 except:
  pass
 self.session.open(boundFunction(CC9DrC, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFXUoN(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FFbL74, session, "lok")
 hk.actions['longCancel'] = boundFunction(FFbL74, session, "lesc")
 hk.actions['longRed']  = boundFunction(FFbL74, session, "lred")
def FFbL74(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFWYRU(session, isFromSession=True)
def FFSskZ(SELF, title="", addLabel=False, addScrollLabel=False, VVY2K2=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FF39sf()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 if SELF.skinParam["topRightBtns"] > 0:
  SELF["keyMenu2F"]  = Label()
  SELF["keyMenu2"]  = Label("Menu")
  if SELF.skinParam["topRightBtns"] > 1:
   SELF["keyMenu1F"] = Label()
   SELF["keyMenu1"] = Label("Info")
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCkXXD(SELF)
 if VVY2K2:
  SELF["myMenu"] = MenuList(VVY2K2)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVtv5z        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFwhUD(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FF52VR, SELF, "0") ,
  "1"    : boundFunction(FF52VR, SELF, "1") ,
  "2"    : boundFunction(FF52VR, SELF, "2") ,
  "3"    : boundFunction(FF52VR, SELF, "3") ,
  "4"    : boundFunction(FF52VR, SELF, "4") ,
  "5"    : boundFunction(FF52VR, SELF, "5") ,
  "6"    : boundFunction(FF52VR, SELF, "6") ,
  "7"    : boundFunction(FF52VR, SELF, "7") ,
  "8"    : boundFunction(FF52VR, SELF, "8") ,
  "9"    : boundFunction(FF52VR, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FFJ8KQ, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FF52VR(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVYHoM:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVYHoM + SELF.keyPressed + VVPTHk)
    txt = VVPTHk + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FF3ty7(SELF, txt)
def FFJ8KQ(SELF, tableObj, colNum):
 FF3ty7(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     tableObj.moveToIndex(i)
     SELF.VVmUOr()
     break
 except:
  pass
def FF1kqe(SELF, setMenuAction=True):
 if setMenuAction:
  global VVXLue
  VVXLue = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FF39sf():
 return ("  %s" % VVXLue)
def FFkqlb(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFt6bT(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFnbxL(color):
 return parseColor(color).argb()
def FFRivu(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFidK4(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFy83Z(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFAawR(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVYHoM)
 else:
  return ""
def FFamyI(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VV1xmU, word, VV1xmU, VVYHoM)
 else : return "echo -e '%s\n--- %s\n%s';" % (VV1xmU, word, VV1xmU)
def FFARnG(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVYHoM
def FF12CE(color):
 if color: return "echo -e '%s' %s;" % (VV1xmU, FFAawR(VV1xmU, VVclxO))
 else : return "echo -e '%s';" % VV1xmU
def FFmLFC(title, color):
 title = "%s\n%s\n%s\n" % (VV1xmU, title, VV1xmU)
 return FFARnG(title, color)
def FFUwX1(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FF8Kyd(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFo2XQ(callBackFunction):
 tCons = CCKt5L()
 tCons.ePopen("echo", boundFunction(FFQSIf, callBackFunction))
def FFQSIf(callBackFunction, result, retval):
 callBackFunction()
def FFjQre(SELF, fnc, title="Processing ...", clearMsg=True):
 FF3ty7(SELF, title)
 tCons = CCKt5L()
 tCons.ePopen("echo", boundFunction(FFM6vG, SELF, fnc, clearMsg))
def FFM6vG(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FF3ty7(SELF)
def FFEP7o(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVhENq
  else       : return ""
def FFVHBJ(cmd):
 txt = FFEP7o(cmd)
 if txt:
  txt.strip()
  if "\n" in txt:
   txt = txt.splitlines()
   return list(map(str.strip, txt))
  else:
   return [txt]
 else:
  return []
def FF3QAx(cmd):
 lines = FFVHBJ(cmd)
 if lines: return lines[0]
 else : return ""
def FFxfUU(SELF, cmd):
 lines = FFVHBJ(cmd)
 VVx2Uc = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVx2Uc.append((key, val))
  elif line:
   VVx2Uc.append((line, ""))
 if VVx2Uc:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFp1uk(SELF, None, header=header, VVSmWK=VVx2Uc, VVO0tX=widths, VV715D=28)
 else:
  FF0eWo(SELF, cmd)
def FF0eWo(    SELF, cmd, **kwargs): SELF.session.open(CC96KM, VVrfZj=cmd, VVlzOH=True, VV51s0=VVyd8y, **kwargs)
def FFBFZP(  SELF, cmd, **kwargs): SELF.session.open(CC96KM, VVrfZj=cmd, **kwargs)
def FFTlgq(   SELF, cmd, **kwargs): SELF.session.open(CC96KM, VVrfZj=cmd, VVkCgR=True, VVBUWp=True, VV51s0=VVyd8y, **kwargs)
def FF9imV(  SELF, cmd, **kwargs): SELF.session.open(CC96KM, VVrfZj=cmd, VVkCgR=True, VVBUWp=True, VV51s0=VVtGrg, **kwargs)
def FFRQmD(  SELF, cmd, **kwargs): SELF.session.open(CC96KM, VVrfZj=cmd, VVe1SL=True , **kwargs)
def FFp3XA( SELF, cmd, **kwargs): SELF.session.open(CC96KM, VVrfZj=cmd, VV4aBN=True   , **kwargs)
def FFQCpM( SELF, cmd, **kwargs): SELF.session.open(CC96KM, VVrfZj=cmd, VVnZoU=True  , **kwargs)
def FFdgmD(cmd):
 return cmd + " > /dev/null 2>&1"
def FFdhfa():
 return " > /dev/null 2>&1"
def FFC4Sn(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFXsco(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFwItZ():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FF3QAx(cmd)
VVSxeo     = 0
VV1smy      = 1
VV42eY   = 2
VV4TlP      = 3
VVjQPZ      = 4
VV4d6C     = 5
VVXJyy     = 6
VVwrhV  = 7
VVPsXk = 8
VVhTwG  = 9
VVppV2     = 10
VV9MSv  = 11
VVZWgG  = 12
def FFBzKc(parmNum, grepTxt):
 if   parmNum == VVSxeo  : param = ["update"   , "dpkg update" ]
 elif parmNum == VV1smy   : param = ["list"   , "apt list" ]
 elif parmNum == VV42eY: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFwItZ()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FF6Z6k(parmNum, package):
 if   parmNum == VV4TlP      : param = ["info"      , "apt show"         ]
 elif parmNum == VVjQPZ      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VV4d6C     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVXJyy     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVwrhV  : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVPsXk : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVhTwG  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVppV2     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VV9MSv  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVZWgG  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFwItZ()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFWCzm():
 result = FF3QAx("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FF6Z6k(VVXJyy , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFdgmD("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFdgmD("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFAawR(failed1, VVclxO))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFAawR(failed2, VVclxO))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFAawR(failed3, VVu486))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FF1ECy(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FF6Z6k(VVXJyy , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFdgmD("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFAawR(failed1, VVclxO))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFAawR(failed2, VVu486))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFje6c(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFdgmD('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFdgmD("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFJ07K(path, maxSize=-1):
 from io import open as ioOpen
 encodings = (None, "utf-8", "ISO8859-15", 'iso6937', "windows-1250", "windows-1252")
 txt = ""
 for enc in encodings:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFrxQp(path, keepends=False, maxSize=-1):
 lines = FFJ07K(path, maxSize)
 return lines.splitlines(keepends)
def FFruOl(SELF, path):
 title = os.path.basename(path)
 if fileExists(path):
  fSize = os.path.getsize(path)
  maxSize = 60000
  if (fSize > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFrxQp(path, maxSize=maxSize)
  if lines: FF0fhx(SELF, lines, title=title, VV51s0=VVyd8y)
  else : FFvbMM(SELF, path, title=title)
 else:
  FFQ3EB(SELF, path, title)
def FFjWVm(SELF, path, title):
 if fileExists(path):
  txt = FFJ07K(path)
  txt = txt.replace("#W#", VVYHoM)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVPTHk)
  txt = txt.replace("#C#", VVylYU)
  txt = txt.replace("#P#", VVEAFU)
  FF0fhx(SELF, txt, title=title)
 else:
  FFQ3EB(SELF, path, title)
def FFQBQX(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FFc3Q8(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFXMLs(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FF0hsM(parent)
 else    : return FFaMIL(parent)
def FFg3Y3(path):
 try:
  return os.path.getsize(path)
 except:
  return 0
def FF0hsM(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFaMIL(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFTpGD():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVgQjM)
 paths.append(VVgQjM.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFc3Q8(ba)
 for p in list:
  p = ba + p + VVgQjM
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVHFp6, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVgQjM, VVHFp6 , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVtYzD, VVCmbD = FFTpGD()
def FF4CvA():
 def VVvTUq(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 iPath = CFG.iptvHostsPath.getValue()
 if not iPath == VVl5oV and not pathExists(iPath):
  CFG.iptvHostsPath.setValue(VVl5oV)
  CFG.iptvHostsPath.save()
  oldIptvHostsPath = VVl5oV
 else:
  oldIptvHostsPath = ""
 VVl1Iq  = VVvTUq(CFG.backupPath, CCPM5F.VVM8Bo())
 VVv1EX  = VVvTUq(CFG.downloadedPackagesPath, t)
 VVbB6x = VVvTUq(CFG.exportedTablesPath, t)
 VV5c8u = VVvTUq(CFG.exportedPIconsPath, t)
 VVMsdi  = VVvTUq(CFG.packageOutputPath, t)
 global VVaZdT
 VVaZdT = FF0hsM(CFG.backupPath.getValue())
 if VVl1Iq or VVMsdi or VVv1EX or VVbB6x or VV5c8u or oldIptvHostsPath:
  configfile.save()
 return VVl1Iq, VVMsdi, VVv1EX, VVbB6x, VV5c8u, oldIptvHostsPath
def FFlN40(path):
 path = FFaMIL(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFXHzQ(SELF, pathList, tarFileName, addTimeStamp=True):
 VVSmWK = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVSmWK.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVSmWK.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVSmWK.append(path)
 if not VVSmWK:
  FFGIBw(SELF, "Files not found!")
 elif not pathExists(VVaZdT):
  FFGIBw(SELF, "Path not found!\n\n%s" % VVaZdT)
 else:
  VV8RGu = FF0hsM(VVaZdT)
  tarFileName = "%s%s" % (VV8RGu, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFgfmJ())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVSmWK:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VV1xmU
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFAawR(tarFileName, VVFGoE))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFAawR(failed, VVFGoE))
  cmd += "fi;"
  cmd +=  sep
  FFBFZP(SELF, cmd)
def FFQUuK(SELF, title, VVOtK1):
 SELF.session.open(boundFunction(CCSXqH, Title=title, VVOtK1=VVOtK1))
def FFYffG(labelObj, VVOtK1):
 if VVOtK1 and fileExists(VVOtK1):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VVETsW(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VVETsW)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VVOtK1)
   return True
  except:
   pass
 return False
def FFKq5s(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFHRLV(satNum)
  return satName
def FFHRLV(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFXnj4(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFKq5s(val)
  else  : sat = FFHRLV(val)
 return sat
def FFPQrv(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFKq5s(num)
 except:
  pass
 return sat
def FF5EWS(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFlPZP(SELF, isFromSession=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFzECc(info, iServiceInformation.sServiceref)
   prov = FFzECc(info, iServiceInformation.sProvider)
   state = str(FFzECc(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFRlBi(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFSPfg(refCode)
 return info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFzECc(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFnNMM(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFPdrd(refCode):
 info = FFG2FV(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFQhMf(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFVKj3(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFG2FV(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVAWP7 = eServiceCenter.getInstance()
  if VVAWP7:
   info = VVAWP7.info(service)
 return info
def FFBoZM(SELF, refCode, VVBdIn=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  FFZQnl(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVBdIn:
   FFWYRU(SELF, isFromSession)
 try:
  VVG5iL = InfoBar.instance
  if VVG5iL:
   VVzmom = VVG5iL.servicelist
   if VVzmom:
    servRef = eServiceReference(refCode)
    VVzmom.saveChannel(servRef)
 except:
  pass
def FFZQnl(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFlPZP(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCUbe9()
    if pr.VVyaMN(refCode, chName, decodedUrl, iptvRef):
     pr.VVC3JO(SELF, isFromSession)
def FFRlBi(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFSPfg(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFpzGx(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FF77qu(userBfile):
 txt = ""
 bFile = VVVAau + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVVAau + userBfile):
  fTxt = FFJ07K(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FF3QAx('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
 return
def FFpzGx(url):
 if iUnquote : return iUnquote(url)
 else  : return url
def FFA0q6(url):
 if iQuote : return iQuote(url)
 else  : return url
def FFa9gW(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFF9cg(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFIaxV(txt):
 try:
  return FFa9gW(FFF9cg(txt)) == txt
 except:
  return False
def FFWYRU(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFlPZP(SELF, isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCpspP, isFromExternal=isFromSession)
 else      : FFvq1G(session, reopen=True)
def FFvq1G(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFvq1G, session), CCr7D5)
  except:
   try:
    FFlUBi(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFTzh3(refCode):
 tp = CC8VoG()
 if tp.VVPhtL(refCode) : return True
 else        : return False
def FFKliL(refCode, isHide):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFCe2y():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FF8UC9():
 VVG5iL = InfoBar.instance
 if VVG5iL:
  VVzmom = VVG5iL.servicelist
  if VVzmom:
   return VVzmom.getBouquetList()
 return None
def FF4aaj():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFnWjn():
 path = FF4aaj()
 if path:
  txt = FFJ07K(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FFrJ62():
 return FFCCnL(InfoBar.instance.servicelist.getRoot())
def FFCCnL(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVAWP7 = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVAWP7.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FFfZ3i():
 VVEr7j = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVBag4 = list(VVEr7j)
 return VVBag4, VVEr7j
def FFUTZz():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFmALg(session, VVOZE2):
 VVEB6n, VVGX5G, VV1Exq, camCommand = FF6UDi()
 if VVGX5G:
  runLog = False
  if   VVOZE2 == CCB2G3.VVYGGv : runLog = True
  elif VVOZE2 == CCB2G3.VVrIe2 : runLog = True
  elif not VV1Exq          : FFlUBi(session, message="SoftCam not started yet!")
  elif fileExists(VV1Exq)        : runLog = True
  else             : FFlUBi(session, message="File not found !\n\n%s" % VV1Exq)
  if runLog:
   session.open(boundFunction(CCB2G3, VVEB6n=VVEB6n, VVGX5G=VVGX5G, VV1Exq=VV1Exq, VVOZE2=VVOZE2))
 else:
  FFlUBi(session, message="No active OSCam/NCam found !", title="Live Log")
def FF6UDi():
 VVEB6n = "/etc/tuxbox/config/"
 VVGX5G = None
 VV1Exq  = None
 camCommand = FF3QAx("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVGX5G = "oscam"
 elif "ncam"  in camCommand : VVGX5G = "ncam"
 if VVGX5G:
  path = FF3QAx(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FF0hsM(path)
  if pathExists(path):
   VVEB6n = path
  tFile = VVEB6n + VVGX5G + ".conf"
  tFile = FF3QAx("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VV1Exq = tFile
 return VVEB6n, VVGX5G, VV1Exq, camCommand
def FFXzY3(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFsPaE():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFgfmJ():
 return FFsPaE().replace(" ", "_").replace("-", "").replace(":", "")
def FFBS4u(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFjtVU():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFV6A0(url, outFile, timeout=3):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCfvbT.VV1Nl0(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCfvbT.VVlP8P(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFdgmD("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFS6MX(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFqKBE(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFaBCG():
 return int(FFEP7o("cat /proc/meminfo | grep MemFree | awk '{print $2}'"))
def FFXnwc():
 global VVJl2a_TIME, VVsbWy
 VVsbWy  = int(FFaBCG())
 VVJl2a_TIME = iTime()
def FFdppn():
 elapsed = iTime() - VVJl2a_TIME
 elapsed = "{:.6f}".format(elapsed).rstrip("0").rstrip(".")
 mem  = FFaBCG() - VVsbWy
 FF5fUA(">>>>>> Elapsed\t: {} seconds ... Memory\t: {} bytes".format(elapsed, mem))
def FFrLx8(SELF, message, title=""):
 SELF.session.open(boundFunction(CCRH5K, title=title, message=message, VVug7i=True))
def FF0fhx(SELF, message, title="", VV51s0=VVyd8y, **kwargs):
 SELF.session.open(boundFunction(CCRH5K, title=title, message=message, VV51s0=VV51s0, **kwargs))
def FFGIBw(SELF, message, title="")  : FFlUBi(SELF.session, message, title)
def FFQ3EB(SELF, path, title="") : FFlUBi(SELF.session, "File not found !\n\n%s" % path, title)
def FFvbMM(SELF, path, title="") : FFlUBi(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFvteW(SELF, title="")  : FFlUBi(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFlUBi(session, message, title="") : session.open(boundFunction(CCkCQ6, title=title, message=message))
def FFwT6k(SELF, VVzqy9, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVzqy9, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVzqy9, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVzqy9, boundFunction(CC6h6M, title=title, message=message, VVL1IG=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFGIBw(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFhMkA(SELF, callBack_Yes, VVVbzS, callBack_No=None, title="", VVydGz=False, VV5nZq=True):
 SELF.session.openWithCallback(boundFunction(FFvpkE, callBack_Yes, callBack_No)
        , boundFunction(CCM8lm, title=title, VVVbzS=VVVbzS, VV5nZq=VV5nZq, VVydGz=VVydGz))
def FFvpkE(callBack_Yes, callBack_No, FFhMkAed):
 if FFhMkAed : callBack_Yes()
 elif callBack_No: callBack_No()
def FF3ty7(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFidK4(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFAqRv(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFTgC4(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVNJpJ = eTimer()
def FFAqRv(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFjHOg, SELF))
 fnc = boundFunction(FFjHOg, SELF)
 try:
  t = VVNJpJ.timeout.connect(fnc)
 except:
  VVNJpJ.callback.append(fnc)
 VVNJpJ.start(milliSeconds, 1)
def FFjHOg(SELF):
 VVNJpJ.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFp1uk(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCkweT, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCkweT, **kwargs))
  FFn48g(win)
  return win
 except:
  return None
def FFlTf2(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCZyZG, **kwargs))
 FFn48g(win)
 return win
def FFzRsg(SELF, **kwargs):
 SELF.session.open(CCf574, **kwargs)
def FF65Ci(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   obj = SELF[name]
   SELF[name].instance.setBorderColor(parseColor("#000000"))
   SELF[name].instance.setBorderWidth(3)
   SELF[name].instance.setNoWrap(True)
  except:
   pass
def FFDdCE(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVOYdo, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FF2Dma(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFDdCE(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FF5zEi():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFa4NK(VV715D):
 screenSize  = FF5zEi()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VV715D)
 return bodyFontSize
def FFPtj8(VV715D, extraSpace):
 font = gFont(VVOYdo, VV715D)
 VVENRM = fontRenderClass.getInstance().getLineHeight(font) or (VV715D * 1.25)
 return int(VVENRM + VVENRM * extraSpace)
def FFN2sm(fontName):
 fList = None
 try:
  from enigma import getFontFaces
  fList = getFontFaces()
 except:
  try:
   from skin import getFontFaces
   fList = getFontFaces()
  except:
   pass
 if fList and fontName in fList : return fontName
 else       : return VVOYdo
def FFdxjB(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FF5zEi()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * VVCfSO)
 bodyFontStr  = 'font="%s;%d"' % (VVOYdo, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFPtj8(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVOYdo, titleFontSize, alignLeftCenter)
 if winType == VVwo8o or winType == VVfta0:
  if winType == VVfta0 : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VV8Sie:
  pass
 elif winType == VVkvWJ:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FFrLx8L = b2Left2 + timeW + marginLeft
  FFrLx8W = b2Left3 - marginLeft - FFrLx8L
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FFrLx8L  , b2Top, FFrLx8W , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00aa7777", "#00aa7777", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
 elif winType == VVvMST:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVLYwe:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVMgH3:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVuN0K:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVOYdo, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVOYdo, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VV3lRK:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFrLx8H = int(bodyH * 0.5)
  inpTop = bodyTop + FFrLx8H
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFrLx8H, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVOYdo, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVOYdo, mapF, alignCenter)
 elif winType == VVOZNr:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVN2xn:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVOYdo, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVGuYX:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVOYdo, fontH, alignCenter)
 elif winType == VV9ZKP:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVOYdo, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVOYdo, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVOYdo, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVSsGW:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 else:
  if   winType == VVdxXE : align = alignLeftCenter
  elif winType == VVI3k3 : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVZ2Wm:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VVayJ6:
   moreParams = ""
  else:
   fontStr = bodyFontStr
   if usefixedFont and winType == VVI3k3:
    fontStr = 'font="%s;%d"' % (FFN2sm("Fixed"), bodyFontSize)
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" %s %s ' % (bodyColor, fontStr, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VV715D = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVOYdo, VV715D, alignCenter)
 if topRightBtns > 0:
  btnW = int(ratioW * 80)
  btnH = int(titleH * 0.7)
  btnTop = int(titleH * 0.15)
  btnLeft = width - (btnW + btnTop)
  btnFont = int(btnH * 0.6)
  tmp += '<widget name="keyMenu2F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
  tmp += '<widget name="keyMenu2"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VVOYdo, btnFont, alignCenter)
  if topRightBtns > 1:
   btnLeft = btnLeft - btnW - 8
   tmp += '<widget name="keyMenu1F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="keyMenu1"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VVOYdo, btnFont, alignCenter)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVSwM6 = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVOYdo, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVSwM6[i], VVOYdo, barFont, alignCenter)
   left += btnW + gap
 if winType == VVI3k3:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVSwM6 = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVSwM6[i], VVOYdo, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFdxjB(VVwo8o, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.hiddenMenuPass = ""
  self.themsList  = []
  VVY2K2 = []
  if VVFHVA:
   VVY2K2.append(("-- MY TEST --"    , "myTest"   ))
  VVY2K2.append(("  File Manager"     , "FileManager"  ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("  Services/Channels"    , "ChannelsTools" ))
  VVY2K2.append(("  IPTV"       , "IptvTools"  ))
  VVY2K2.append(("  PIcons"       , "PIconsTools"  ))
  VVY2K2.append(("  SoftCam"      , "SoftCam"   ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("  Plugins"      , "PluginsTools" ))
  VVY2K2.append(("  Terminal"      , "Terminal"  ))
  VVY2K2.append(("  Backup & Restore"    , "BackupRestore" ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("  Date/Time"      , "Date_Time"  ))
  VVY2K2.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVY2K2)
  FFSskZ(self, VVY2K2=VVY2K2)
  FFkqlb(self["keyRed"] , "Exit")
  FFkqlb(self["keyGreen"] , "Settings")
  FFkqlb(self["keyYellow"], "Dev. Info.")
  FFkqlb(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VVHaGG       ,
   "yellow"  : self.VVJbMK       ,
   "blue"   : self.VVCVgc       ,
   "info"   : self.VVCVgc       ,
   "last"   : self.VVM81g      ,
   "next"   : self.VV0HEt       ,
   "menu"   : self.VVHSjB     ,
   "0"    : boundFunction(self.VV4QE5, 0) ,
   "1"    : boundFunction(self.VVMrkr, 1)   ,
   "2"    : boundFunction(self.VVMrkr, 2)   ,
   "3"    : boundFunction(self.VVMrkr, 3)   ,
   "4"    : boundFunction(self.VVMrkr, 4)   ,
   "5"    : boundFunction(self.VVMrkr, 5)   ,
   "6"    : boundFunction(self.VVMrkr, 6)   ,
   "7"    : boundFunction(self.VVMrkr, 7)   ,
   "8"    : boundFunction(self.VVMrkr, 8)   ,
   "9"    : boundFunction(self.VVMrkr, 9)
  })
  self.onShown.append(self.VVJId3)
  self.onClose.append(self.onExit)
  global VVcBAa, VVlmpc, VVrFFh
  VVcBAa = VVlmpc = VVrFFh = False
 def VVtv5z(self):
  item = FF1kqe(self)
  self.VVMrkr(item)
 def VVMrkr(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVEc3w()
   elif item in ("FileManager"  , 1) : self.session.open(CCQ4SG)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCJkx4)
   elif item in ("IptvTools"  , 3) : self.session.open(CCfvbT)
   elif item in ("PIconsTools"  , 4) : self.VVWpzF()
   elif item in ("SoftCam"   , 5) : self.session.open(CCXcT8)
   elif item in ("PluginsTools" , 6) : self.session.open(CCtwWm)
   elif item in ("Terminal"  , 7) : self.session.open(CCjVWP)
   elif item in ("BackupRestore" , 8) : self.session.open(CCMEJv)
   elif item in ("Date_Time"  , 9) : self.session.open(CCQq4F)
   elif item in ("CheckInternet" , 10) : self.session.open(CCBzmY)
   else         : self.close()
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  FFUwX1(self["myMenu"])
  FF2Dma(self)
  FF65Ci(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVTPuM)
  self["myTitle"].setText(title)
  VVl1Iq, VVMsdi, VVv1EX, VVbB6x, VV5c8u, oldIptvHostsPath = FF4CvA()
  self.VViL15()
  if VVl1Iq or VVMsdi or VVv1EX or VVbB6x or VV5c8u or oldIptvHostsPath:
   VVOxXn = lambda path, subj: "%s:\n%s\n\n" % (subj, FFARnG(path, VVu486)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVOxXn(oldIptvHostsPath  , "IPTV Hosts Files Path"   )
   txt += VVOxXn(VVl1Iq   , "Backup/Restore Path"    )
   txt += VVOxXn(VVMsdi  , "Created Package Files (IPK/DEB)" )
   txt += VVOxXn(VVv1EX  , "Download Packages (from feeds)" )
   txt += VVOxXn(VVbB6x , "Exported Tables"     )
   txt += VVOxXn(VV5c8u , "Exported PIcons"     )
   txt += "\nYou can change paths from Settings.\n"
   FF0fhx(self, txt, title="Settings Paths")
  if (EASY_MODE or VVYUqF or VVFHVA):
   FFidK4(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FF3ty7(self, "Welcome", 300)
  FFo2XQ(boundFunction(self.VVLjHT, title))
 def VVLjHT(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCPM5F.VVTzA4()
   if url:
    newWebVer = CCPM5F.VVIPqc(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFdgmD("rm /tmp/ajpanel*"))
  global VVcBAa, VVlmpc, VVrFFh
  VVcBAa = VVlmpc = VVrFFh = False
 def VV4QE5(self, digit):
  self.hiddenMenuPass += str(digit)
  ln = len(self.hiddenMenuPass)
  global VVcBAa, VVrFFh
  if ln == 4:
   if self.hiddenMenuPass == "0" * ln:
    VVcBAa = True
    FFidK4(self["myTitle"], "#800080")
   else:
    self.hiddenMenuPass = "x"
  elif self.hiddenMenuPass == "0" * ln:
   VVrFFh = True
 def VV0HEt(self):
  self.hiddenMenuPass += ">"
  if self.hiddenMenuPass == "0" * 4 + ">" * 2:
   global VVlmpc
   VVlmpc = True
   FFidK4(self["myTitle"], "#dd5588")
 def VVM81g(self):
  self.hiddenMenuPass += "<"
  if self.hiddenMenuPass == "0" * 4 + "<" * 2:
   ok = False
   fnt = "ae_AlMateen.ttf"
   fontFile = "/usr/share/fonts/%s" % fnt
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    try:
     addFont(fontFile, fontName, 100, True)
     ok = True
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      ok = True
     except:
      pass
   if ok: txt = 'Added Font: "%s"' % fnt
   else : txt = '"%s" Not Found' % fnt
   FF3ty7(self, txt, 2000, isGrn=ok)
 def VVWpzF(self):
  found = False
  pPath = CCJRmr.VVFZXX()
  if pathExists(pPath):
   for fName, fType in CCJRmr.VVRMRU(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCJRmr)
  else:
   VVY2K2 = []
   VVY2K2.append(("PIcons Manager" , "CCJRmr" ))
   VVY2K2.append(VV8PP6)
   VVY2K2.append(CCJRmr.VVWIro())
   VVY2K2.append(VV8PP6)
   VVY2K2 += CCJRmr.VV7Es5()
   FFlTf2(self, self.VVWF2e, VVY2K2=VVY2K2)
 def VVWF2e(self, item=None):
  if item:
   if   item == "CCJRmr"   : self.session.open(CCJRmr)
   elif item == "VVqEdh"  : CCJRmr.VVqEdh(self)
   elif item == "VV4a0V"  : CCJRmr.VV4a0V(self)
   elif item == "findPiconBrokenSymLinks" : CCJRmr.VVnoCN(self, True)
   elif item == "FindAllBrokenSymLinks" : CCJRmr.VVnoCN(self, False)
 def VVHaGG(self):
  self.session.open(CCPM5F)
 def VVJbMK(self):
  self.session.open(CCPWJG)
 def VVCVgc(self):
  changeLogFile = VVCmbD + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FFrxQp(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFARnG("\n%s\n%s\n%s" % (VV1xmU, line, VV1xmU), VVEAFU, VVYHoM)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FFARnG(line, VVPTHk, VVYHoM)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FF0fhx(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VVTPuM), VV715D=26)
 def VVHSjB(self):
  VVY2K2 = []
  VVY2K2.append(("Title Colors"   , "title" ))
  VVY2K2.append(("Menu Area Colors"  , "body" ))
  VVY2K2.append(("Menu Pointer Colors" , "cursor" ))
  VVY2K2.append(("Bottom Bar Colors" , "bar"  ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Reset"    , "reset" ))
  FFlTf2(self, self.VVPH84, VVY2K2=VVY2K2, width=500, title="Main Menu Colors")
 def VVPH84(self, item=None):
  if item:
   if item == "reset":
    os.system(FFdgmD("rm %s" % self.VVXdLH()))
    self.close()
   else:
    tDict = self.VVLUF4()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VVKm2V, tDict, item), CChG66, defFG=fg, defBG=bg)
 def VVXdLH(self):
  return VVaZdT + "ajpanel_colors"
 def VVLUF4(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVXdLH()
  if fileExists(p):
   txt = FFJ07K(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVKm2V(self, tDict, item, fg, bg):
  if fg:
   self.VVICaP(item, fg)
   self.VVF0DT(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVmHrv(tDict)
 def VVmHrv(self, tDict):
   p = self.VVXdLH()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVICaP(self, item, fg):
  if   item == "title" : FFRivu(self["myTitle"], fg)
  elif item == "body"  :
   FFRivu(self["myMenu"], fg)
   FFRivu(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFidK4(self["myBar"], fg)
   FFRivu(self["keyRed"], fg)
   FFRivu(self["keyGreen"], fg)
   FFRivu(self["keyYellow"], fg)
   FFRivu(self["keyBlue"], fg)
 def VVF0DT(self, item, bg):
  if   item == "title" : FFidK4(self["myTitle"], bg)
  elif item == "body"  :
   FFidK4(self["myMenu"], bg)
   FFidK4(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFidK4(self["myBar"], bg)
 def VViL15(self):
  tDict = self.VVLUF4()
  self.VVGFzP(tDict, "title")
  self.VVGFzP(tDict, "body")
  self.VVGFzP(tDict, "cursor")
  self.VVGFzP(tDict, "bar")
 def VVGFzP(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVICaP(name, fg)
  if bg: self.VVF0DT(name, bg)
 def VVEc3w(self):
  pass
class CCPWJG(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFdxjB(VVwo8o, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVY2K2 = []
  VVY2K2.append(("Settings File"        , "SettingsFile"   ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Box Info"          , "VVaCnr"    ))
  VVY2K2.append(("Tuners Info"         , "VVWozt"   ))
  VVY2K2.append(("Python Version"        , "VVaZct"   ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Screen Size"         , "ScreenSize"    ))
  VVY2K2.append(("Locale"          , "Locale"     ))
  VVY2K2.append(("Processor"         , "Processor"    ))
  VVY2K2.append(("Operating System"        , "OperatingSystem"   ))
  VVY2K2.append(("Drivers"          , "drivers"     ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("System Users"         , "SystemUsers"    ))
  VVY2K2.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVY2K2.append(("Uptime"          , "Uptime"     ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Host Name"         , "HostName"    ))
  VVY2K2.append(("MAC Address"         , "MACAddress"    ))
  VVY2K2.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVY2K2.append(("Network Status"        , "NetworkStatus"   ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Disk Usage"         , "VVXY5D"    ))
  VVY2K2.append(("Mount Points"         , "MountPoints"    ))
  VVY2K2.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVY2K2.append(("USB Devices"         , "USB_Devices"    ))
  VVY2K2.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVY2K2.append(("Directory Size"        , "DirectorySize"   ))
  VVY2K2.append(("Memory"          , "Memory"     ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVY2K2.append(("Running Processes"       , "RunningProcesses"  ))
  VVY2K2.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFSskZ(self, VVY2K2=VVY2K2, title="Device Information")
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  FFUwX1(self["myMenu"])
  FF2Dma(self)
 def VVtv5z(self):
  global VVXLue
  VVXLue = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCszYd)
   elif item == "VVaCnr"    : self.VVaCnr()
   elif item == "VVWozt"   : self.VVWozt()
   elif item == "VVaZct"   : self.VVaZct()
   elif item == "ScreenSize"    : FF0fhx(self, "Width\t: %s\nHeight\t: %s" % (FF5zEi()[0], FF5zEi()[1]))
   elif item == "Locale"     : self.VVd6z6()
   elif item == "Processor"    : self.VVIxdQ()
   elif item == "OperatingSystem"   : FF0eWo(self, "uname -a"        )
   elif item == "drivers"     : self.VVZBhe()
   elif item == "SystemUsers"    : FF0eWo(self, "id"          )
   elif item == "LoggedInUsers"   : FF0eWo(self, "who -a"         )
   elif item == "Uptime"     : FF0eWo(self, "uptime"         )
   elif item == "HostName"     : FF0eWo(self, "hostname"        )
   elif item == "MACAddress"    : self.VVe2DO()
   elif item == "NetworkConfiguration"  : FF0eWo(self, "ifconfig %s %s" % (FFAawR("HWaddr", VV6kBj), FFAawR("addr:", VVclxO)))
   elif item == "NetworkStatus"   : FF0eWo(self, "netstat -tulpn"       )
   elif item == "VVXY5D"    : self.VVXY5D()
   elif item == "MountPoints"    : FF0eWo(self, "mount %s" % (FFAawR(" on ", VVclxO)))
   elif item == "FileSystemTable"   : FF0eWo(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FF0eWo(self, "lsusb"         )
   elif item == "listBlockDevices"   : FF0eWo(self, "blkid"         )
   elif item == "DirectorySize"   : FF0eWo(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVMzQ2="Reading size ...")
   elif item == "Memory"     : FF0eWo(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VV2m87()
   elif item == "RunningProcesses"   : FF0eWo(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FF0eWo(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVFlJN()
   else         : self.close()
 def VVe2DO(self):
  res = FFEP7o("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FF0fhx(self, txt)
  else:
   FF0eWo(self, "ip link")
 def VVHLWY(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFVHBJ(cmd)
  return lines
 def VVU6lp(self, lines, headerRepl, widths, VVD84s):
  VVx2Uc = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVx2Uc.append(parts)
  if VVx2Uc and len(header) == len(widths):
   VVx2Uc.sort(key=lambda x: x[0].lower())
   FFp1uk(self, None, header=header, VVSmWK=VVx2Uc, VVD84s=VVD84s, VVO0tX=widths, VV715D=28, VVGwLR=True)
   return True
  else:
   return False
 def VVXY5D(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VVHLWY(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVD84s = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VVU6lp(lines, headerRepl, widths, VVD84s)
  if not allOK:
   lines = FFVHBJ(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFaMIL(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVFGoE:
     note = "\n%s" % FFARnG("Green = Mounted Partitions", VVFGoE)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVclxO
     elif line.endswith(mountList) : color = VVFGoE
     else       : color = VVPTHk
     txt += FFARnG(line, color) + "\n"
    FF0fhx(self, txt + note)
   else:
    FFGIBw(self, "Not data from system !")
 def VV2m87(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVHLWY(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVD84s = (LEFT , CENTER, LEFT )
  allOK = self.VVU6lp(lines, headerRepl, widths, VVD84s)
  if not allOK:
   FF0eWo(self, cmd)
 def VVd6z6(self):
  from locale import getdefaultlocale
  loc = getdefaultlocale()
  FF0fhx(self, "Language\t: %s\nEncoding\t: %s" % (loc[0], loc[1]))
 def VVZBhe(self):
  cmd = FFBzKc(VV42eY, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FF0eWo(self, cmd)
  else : FFvteW(self)
 def VVIxdQ(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FF0eWo(self, cmd)
 def VVFlJN(self):
  cmd = FFBzKc(VV1smy, "| grep secondstage")
  if cmd : FF0eWo(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFvteW(self)
 def VVaCnr(self):
  c = VVFGoE
  VVSmWK = []
  VVSmWK.append((FFARnG("Box Type"  , c), FFARnG(self.VV3lPW("boxtype").upper(), c)))
  VVSmWK.append((FFARnG("Board Version", c), FFARnG(self.VV3lPW("board_revision") , c)))
  VVSmWK.append((FFARnG("Chipset"  , c), FFARnG(self.VV3lPW("chipset")  , c)))
  VVSmWK.append((FFARnG("S/N"   , c), FFARnG(self.VV3lPW("sn")    , c)))
  VVSmWK.append((FFARnG("Version"  , c), FFARnG(self.VV3lPW("version")  , c)))
  VVEO9H   = []
  VV3zAM = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VV3zAM = SystemInfo[key]
     else:
      VVEO9H.append((FFARnG(str(key), VVylYU), FFARnG(str(SystemInfo[key]), VVylYU)))
  except:
   pass
  if VV3zAM:
   VVJ09b = self.VVFRsV(VV3zAM)
   if VVJ09b:
    VVJ09b.sort(key=lambda x: x[0].lower())
    VVSmWK += VVJ09b
  if VVEO9H:
   VVEO9H.sort(key=lambda x: x[0].lower())
   VVSmWK += VVEO9H
  if VVSmWK:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFp1uk(self, None, header=header, VVSmWK=VVSmWK, VVO0tX=widths, VV715D=28, VVGwLR=True)
  else:
   FF0fhx(self, "Could not read info!")
 def VV3lPW(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFrxQp(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVFRsV(self, mbDict):
  try:
   mbList = list(mbDict)
   VVSmWK = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVSmWK.append((FFARnG(subject, VVclxO), FFARnG(value, VVclxO)))
  except:
   pass
  return VVSmWK
 def VVWozt(self):
  txt = self.VVq1HM("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVq1HM("/proc/bus/nim_sockets")
  if not txt: txt = self.VVBhWQ()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FF0fhx(self, txt)
 def VVBhWQ(self):
  txt = ""
  VVOxXn = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVOxXn("Slot Name" , slot.getSlotName())
     txt += FFARnG(slotName, VVclxO)
     txt += VVOxXn("Description"  , slot.getFullDescription())
     txt += VVOxXn("Frontend ID"  , slot.frontend_id)
     txt += VVOxXn("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVq1HM(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFrxQp(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFARnG(line, VVclxO)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVaZct(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FF0fhx(self, txt)
class CCszYd(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFdxjB(VVwo8o, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVY2K2 = []
  VVY2K2.append(("Settings (All)"   , "Settings_All"   ))
  VVY2K2.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVY2K2.append(("Settings (FHDG-17)"  , "Settings_FHDG_17"  ))
  VVY2K2.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVY2K2.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVY2K2.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVY2K2.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVY2K2.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFSskZ(self, VVY2K2=VVY2K2)
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  FFUwX1(self["myMenu"])
  FF2Dma(self)
 def VVtv5z(self):
  global VVXLue
  VVXLue = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FF0eWo(self, cmd                )
   elif item == "Settings_HotKeys"   : FF0eWo(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FF0eWo(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FF0eWo(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FF0eWo(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FF0eWo(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FF0eWo(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FF0eWo(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCXcT8(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFdxjB(VVwo8o, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVEB6n, VVGX5G, VV1Exq, camCommand = FF6UDi()
  self.VVGX5G = VVGX5G
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVY2K2 = []
  VVY2K2.append(("OSCam Files"        , "OSCamFiles"  ))
  VVY2K2.append(("NCam Files"        , "NCamFiles"  ))
  VVY2K2.append(("CCcam Files"        , "CCcamFiles"  ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVY2K2.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVY2K2.append(VV8PP6)
  if VVGX5G:
   if   "oscam" in VVGX5G : camName = "OSCam"
   elif "ncam"  in VVGX5G : camName = "NCam"
   VVY2K2.append((camName + " Info."      , "camInfo"   ))
   VVY2K2.append((camName + " Live Status"    , "camLiveStatus" ))
   VVY2K2.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVY2K2.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVY2K2.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFSskZ(self, VVY2K2=VVY2K2)
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  FFUwX1(self["myMenu"])
  FF2Dma(self)
 def VVtv5z(self):
  global VVXLue
  VVXLue = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCy5gn, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCy5gn, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCy5gn, "cccam"))
   elif item == "OSCamReaders"  : self.VVHFHL("os")
   elif item == "NSCamReaders"  : self.VVHFHL("n")
   elif item == "camInfo"   : FFxfUU(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFmALg(self.session, CCB2G3.VVYGGv)
   elif item == "camLiveReaders" : FFmALg(self.session, CCB2G3.VVrIe2)
   elif item == "camLiveLog"  : FFmALg(self.session, CCB2G3.VV9DWl)
   else       : self.close()
 def VVHFHL(self, camPrefix):
  VVx2Uc = self.VVi16t(camPrefix)
  if VVx2Uc:
   VVx2Uc.sort(key=lambda x: int(x[0]))
   if self.VVGX5G and self.VVGX5G.startswith(camPrefix):
    VV4tKk = ("Toggle State", self.VVUXLh, [camPrefix], "Changing State ...")
   else:
    VV4tKk = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVD84s  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFp1uk(self, None, header=header, VVSmWK=VVx2Uc, VVD84s=VVD84s, VVO0tX=widths, VV715D=26, VV4tKk=VV4tKk, VVzUt6=True)
 def VVi16t(self, camPrefix):
  readersFile = self.VVEB6n + camPrefix + "cam.server"
  VVx2Uc = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFrxQp(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVx2Uc.append((str(len(VVx2Uc) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVx2Uc:
    FFGIBw(self, "No readers found !")
  else:
   FFQ3EB(self, readersFile)
  return VVx2Uc
 def VVUXLh(self, VV3o52, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVEB6n, camPrefix)
  readerState  = VV3o52.VViajA(1)
  readerLabel  = VV3o52.VViajA(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCXcT8.VVHF40(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VV3o52.VVU8jU()
    FFGIBw(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVx2Uc = self.VVi16t(camPrefix)
   if VVx2Uc:
    VV3o52.VVnh9K(VVx2Uc)
 @staticmethod
 def VVHF40(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFrxQp(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFGIBw(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFGIBw(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFQ3EB(SELF, confFile)
   return None
  if not iRequest:
   FFGIBw(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FFGIBw(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FFGIBw(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCy5gn(Screen):
 def __init__(self, VVAFxh, session, args=0):
  self.skin, self.skinParam = FFdxjB(VVwo8o, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVEB6n, VVGX5G, VV1Exq, camCommand = FF6UDi()
  if   VVAFxh == "ncam" : self.prefix = "n"
  elif VVAFxh == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVY2K2 = []
  if self.prefix == "":
   VVY2K2.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVY2K2.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVY2K2.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVY2K2.append(("constant.cw"         , "x_constant_cw" ))
   VVY2K2.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVY2K2.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVY2K2.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVY2K2.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVY2K2.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVY2K2.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVY2K2.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVY2K2.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVY2K2.append(VV8PP6)
   VVY2K2.append(("SoftCam.Key"         , "x_SoftCam_Key" ))
   VVY2K2.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVY2K2.append(VV8PP6)
   VVY2K2.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVY2K2.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVY2K2.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFSskZ(self, VVY2K2=VVY2K2)
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  FFUwX1(self["myMenu"])
  FF2Dma(self)
 def VVtv5z(self):
  global VVXLue
  VVXLue = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFruOl(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFruOl(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFruOl(self, self.VVEB6n + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFruOl(self, self.VVEB6n + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVn7jm("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVn7jm("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVn7jm("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVn7jm("cam.provid"        )
   elif item == "x_cam_server"  : self.VVn7jm("cam.server"        )
   elif item == "x_cam_services" : self.VVn7jm("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVn7jm("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVn7jm("cam.user"        )
   elif item == "x_VV1xmU"   : pass
   elif item == "x_SoftCam_Key" : FFruOl(self, self.VVEB6n + "SoftCam.Key"   )
   elif item == "x_CCcam_cfg"  : FFruOl(self, self.VVEB6n + "CCcam.cfg"    )
   elif item == "x_VV1xmU"   : pass
   elif item == "x_cam_log"  : FFruOl(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFruOl(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFruOl(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVn7jm(self, fileName):
  FFruOl(self, self.VVEB6n + self.prefix + fileName)
class CCB2G3(Screen):
 VVYGGv  = 0
 VVrIe2 = 1
 VV9DWl = 2
 def __init__(self, session, VVEB6n="", VVGX5G="", VV1Exq="", VVOZE2=VVYGGv):
  self.skin, self.skinParam = FFdxjB(VVI3k3, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VV1Exq   = VV1Exq
  self.VVOZE2  = VVOZE2
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVEB6n + VVGX5G + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVGX5G : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVEB6n, self.camPrefix)
  if self.VVOZE2 == self.VVYGGv:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVOZE2 == self.VVrIe2:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFSskZ(self, self.Title, addScrollLabel=True)
  FFkqlb(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVLFfd
  self.onShown.append(self.VVJId3)
  self.onClose.append(self.onExit)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  self["myLabel"].VVwJt1(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FF65Ci(self)
  self.VVLFfd()
 def onExit(self):
  self.timer.stop()
 def VVI86z(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVQ4Lw)
  except:
   self.timer.callback.append(self.VVQ4Lw)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FF3ty7(self, "Started", 1000)
 def VVDhIP(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVQ4Lw)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FF3ty7(self, "Stopped", 1000)
 def VVLFfd(self):
  if self.timerRunning:
   self.VVDhIP()
  else:
   self.VVI86z()
   if self.VVOZE2 == self.VVYGGv or self.VVOZE2 == self.VVrIe2:
    if self.VVOZE2 == self.VVYGGv : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCXcT8.VVHF40(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFo2XQ(self.VVVUIq)
    else:
     self.close()
   else:
    self.VVl2S6()
 def VVQ4Lw(self):
  if self.timerRunning:
   if   self.VVOZE2 == self.VVYGGv : self.VVZPm4()
   elif self.VVOZE2 == self.VVrIe2 : self.VVZPm4()
   else            : self.VVl2S6()
 def VVl2S6(self):
  if fileExists(self.VV1Exq):
   fTime = FFXzY3(os.path.getmtime(self.VV1Exq))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVNMko(), VV51s0=VVtGrg)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VV1Exq)
 def VVVUIq(self):
  self.VVZPm4()
 def VVZPm4(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFARnG("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVEAFU))
   self.camWebIfErrorFound = True
   self.VVDhIP()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVOZE2 == self.VVYGGv : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFARnG("Error while parsing data elements !\n\nError = %s" % str(e), VVu486)
   self.camWebIfErrorFound = True
   self.VVDhIP()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVdD2P(root)
  self["myLabel"].setText(txt, VV51s0=VVtGrg)
  self["myBar"].setText("Last Update : %s" % FFsPaE())
 def VVdD2P(self, rootElement):
  def VVOxXn(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVOZE2 == self.VVYGGv:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFARnG(status, VVFGoE)
    else          : status = FFARnG(status, VVu486)
    txt += VV1xmU + "\n"
    txt += VVOxXn("Name"  , name)
    txt += VVOxXn("Description" , desc)
    txt += VVOxXn("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVOxXn("Protocol" , protocol)
    txt += VVOxXn("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFARnG("Yes", VVFGoE)
    else    : enabTxt = FFARnG("No", VVu486)
    txt += VV1xmU + "\n"
    txt += VVOxXn("Label"  , label)
    txt += VVOxXn("Protocol" , protocol)
    txt += VVOxXn("Enabled" , enabTxt)
  return txt
 def VVNMko(self):
  wordsDict = self.VVgSk5()
  color = [ VVclxO, VV6kBj, VVFGoE, VVu486, VVylYU, VVSsUL]
  lines = FFVHBJ("tail -n %d %s" % (100, self.VV1Exq))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVEAFU + line[:19] + VVPTHk + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVYHoM + line[ndx + 3:] + VVPTHk
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVclxO + line[ndx + 8 : ndx1 + 4] + VVPTHk + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVPTHk)
   elif line.startswith("----") or ">>" in line:
    line = FFARnG(line, VVclxO)
   txt += line + "\n"
  return txt
 def VVgSk5(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFrxQp(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCMEJv(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFdxjB(VVwo8o, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVY2K2 = []
  VVY2K2.append(("Backup Channels"        , "VVDPOs"   ))
  VVY2K2.append(("Restore Channels"        , "Restore_Channels"  ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Backup SoftCAM Files"       , "VV22iF" ))
  VVY2K2.append(("Restore SoftCAM Files"      , "Restore_SoftCAM_Files" ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Backup Tuner Settings"      , "Backup_TunerDiSEqC"  ))
  VVY2K2.append(("Restore Tuner Settings"      , "Restore_TunerDiSEqC"  ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Backup HotKeys & FHDG17 Settings"    , "Backup_Hotkey_FHDG17" ))
  VVY2K2.append(("Restore HotKeys & FHDG17 Settings"   , "Restore_Hotkey_FHDG17" ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Backup Network Settings"      , "VVm5uS"   ))
  VVY2K2.append(("Restore Network Settings"      , "Restore_Network"   ))
  if VVlmpc:
   VVY2K2.append(VV8PP6)
   VVY2K2.append((VVEAFU + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME , "VVXMCU"   ))
   VVY2K2.append((VVFGoE + "2- Create %s for IPK"   % PLUGIN_NAME , "createMyIpk"   ))
   VVY2K2.append((VVFGoE + "3- Create %s for DEB"   % PLUGIN_NAME , "createMyDeb"   ))
   VVY2K2.append((VVylYU + "Create %s TAR (Absolute Path)" % PLUGIN_NAME , "createMyTar"   ))
   VVY2K2.append((VVylYU + "Decode %s Crash Report"   % PLUGIN_NAME , "VVME5Q" ))
  FFSskZ(self, VVY2K2=VVY2K2)
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  FFUwX1(self["myMenu"])
  FF2Dma(self)
 def VVtv5z(self):
  global VVXLue
  VVXLue = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVDPOs"    : self.VVDPOs()
   elif item == "Restore_Channels"    : self.VVZDI7("channels_backup*.tar.gz", self.VVumcM)
   elif item == "VV22iF"   : self.VV22iF()
   elif item == "Restore_SoftCAM_Files"  : self.VVZDI7("softcam_backup*.tar.gz", self.VVVeE4)
   elif item == "Backup_TunerDiSEqC"   : self.VVXmDj("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVZDI7("tuner_backup*.backup", boundFunction(self.VVTbs5, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVXmDj("hotkey_fhdg17_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVZDI7("hotkey_fhdg17_backup*.backup", boundFunction(self.VVTbs5, "misc"))
   elif item == "VVm5uS"    : self.VVm5uS()
   elif item == "Restore_Network"    : self.VVZDI7("network_backup*.tar.gz", self.VV3pLJ)
   elif item == "VVXMCU"     : FFhMkA(self, boundFunction(FFjQre, self, boundFunction(CCMEJv.VVXMCU, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VV7Tpo(False)
   elif item == "createMyDeb"     : self.VV7Tpo(True)
   elif item == "createMyTar"     : self.VVxQcn()
   elif item == "VVME5Q"   : self.VVME5Q()
 @staticmethod
 def VVXMCU(SELF):
  OBF_Path = VVtYzD + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVtYzD, VVTPuM, VVTh9m)
   if err : FFGIBw(SELF, err)
   else : FF0fhx(SELF, txt)
  else:
   FFQ3EB(SELF, OBF_Path)
 def VV7Tpo(self, VV49od):
  OBF_Path = VVtYzD + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFGIBw(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVtYzD)
  os.system("mv -f %s %s" % (VVtYzD + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVtYzD + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVtYzD + "plugin.py"))
  self.session.openWithCallback(self.VV7Tpo1, boundFunction(CCQGzc, path=VVtYzD, VV49od=VV49od))
 def VV7Tpo1(self):
  os.system("mv -f %s %s" % (VVtYzD + "OBF/main.py"  , VVtYzD))
  os.system("mv -f %s %s" % (VVtYzD + "OBF/plugin.py" , VVtYzD))
 def VVME5Q(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFGIBw(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFGIBw(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVmzKU("%s*.list" % path)
  if err:
   FFQ3EB(self, path + "*.list")
   return
  srcF, err = self.VVmzKU("%s*main_final.py" % path)
  if err:
   FFQ3EB(self, path + "*.final.py")
   return
  VVSmWK = []
  for f in files:
   f = os.path.basename(f)
   VVSmWK.append((f, f))
  FFlTf2(self, boundFunction(self.VVLSoH, path, codF, srcF), VVY2K2=VVSmWK)
 def VVLSoH(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFQ3EB(self, logF)
   else     : FFjQre(self, boundFunction(self.VVfu32, logF, codF, srcF))
 def VVfu32(self, logF, codF, srcF):
  lst  = []
  lines = FFrxQp(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFGIBw(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVGigi(lst, logF, newLogF)
  totSrc  = self.VVGigi(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FF0fhx(self, txt)
 def VVmzKU(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVGigi(self, lst, f1, f2):
  txt = FFJ07K(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVxQcn(self):
  VVSmWK = []
  VVSmWK.append("%s%s" % (VVtYzD, "*.py"))
  VVSmWK.append("%s%s" % (VVtYzD, "*.png"))
  VVSmWK.append("%s%s" % (VVtYzD, "*.xml"))
  VVSmWK.append("%s"  % (VVCmbD))
  FFXHzQ(self, VVSmWK, "%s_%s" % (PLUGIN_NAME, VVTPuM), addTimeStamp=False)
 def VVDPOs(self):
  path1 = VVVAau
  path2 = "/etc/tuxbox/"
  VVSmWK = []
  VVSmWK.append("%s%s" % (path1, "*.tv"))
  VVSmWK.append("%s%s" % (path1, "*.radio"))
  VVSmWK.append("%s%s" % (path1, "*list"))
  VVSmWK.append("%s%s" % (path1, "lamedb*"))
  VVSmWK.append("%s%s" % (path2, "*.xml"))
  FFXHzQ(self, VVSmWK, "channels_backup", addTimeStamp=True)
 def VV22iF(self):
  VVSmWK = []
  VVSmWK.append("/etc/tuxbox/config/")
  VVSmWK.append("/usr/keys/")
  VVSmWK.append("/usr/scam/")
  VVSmWK.append("/etc/CCcam.cfg")
  FFXHzQ(self, VVSmWK, "softcam_backup", addTimeStamp=True)
 def VVm5uS(self):
  VVSmWK = []
  VVSmWK.append("/etc/hostname")
  VVSmWK.append("/etc/default_gw")
  VVSmWK.append("/etc/resolv.conf")
  VVSmWK.append("/etc/wpa_supplicant*.conf")
  VVSmWK.append("/etc/network/interfaces")
  VVSmWK.append("/etc/enigma2/nameserversdns.conf")
  FFXHzQ(self, VVSmWK, "network_backup", addTimeStamp=True)
 def VVumcM(self, fileName):
  if fileName:
   FFhMkA(self, boundFunction(self.VVn2NW, fileName), "Overwrite current channels ?")
 def VVn2NW(self, fileName):
  path = "%s%s" % (VVaZdT, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCJkx4.VVAbsl()
   lamedb5File, diabled5File = CCJkx4.VV7IJt()
   cmd = ""
   cmd += FFdgmD("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFdgmD("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFCe2y()
   if res == 0 : FFrLx8(self, "Channels Restored.")
   else  : FFGIBw(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFQ3EB(self, path)
 def VVVeE4(self, fileName):
  if fileName:
   FFhMkA(self, boundFunction(self.VVDR8H, fileName), "Overwrite SoftCAM files ?")
 def VVDR8H(self, fileName):
  fileName = "%s%s" % (VVaZdT, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VV1xmU
   note = "You may need to restart your SoftCAM."
   FF9imV(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFAawR(note, VVclxO), sep))
  else:
   FFQ3EB(self, fileName)
 def VV3pLJ(self, fileName):
  if fileName:
   FFhMkA(self, boundFunction(self.VVmvgI, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVmvgI(self, fileName):
  fileName = "%s%s" % (VVaZdT, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFRQmD(self,  cmd)
  else:
   FFQ3EB(self, fileName)
 def VVZDI7(self, pattern, callBackFunction, isTuner=False):
  title = FF39sf()
  if pathExists(VVaZdT):
   myFiles = iGlob("%s%s" % (VVaZdT, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVSmWK = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVSmWK.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVZPKj = ("Sat. List", self.VVNmp0)
    else  : VVZPKj = None
    VVHN3c = ("Delete File", boundFunction(self.VVXAU4, boundFunction(self.VVZDI7, pattern, callBackFunction, isTuner)))
    FFlTf2(self, callBackFunction, title=title, VVY2K2=VVSmWK, VVZPKj=VVZPKj, VVHN3c=VVHN3c)
   else:
    FFGIBw(self, "No files found in:\n\n%s" % VVaZdT, title)
  else:
   FFGIBw(self, "Path not found:\n\n%s" % VVaZdT, title)
 def VVXAU4(self, cbFnc, VVmQZXObj, path):
  FFhMkA(self, boundFunction(self.VVfwj7, cbFnc, VVmQZXObj, path), "Delete this file ?\n\n%s" % path)
 def VVfwj7(self, cbFnc, VVmQZXObj, path):
  os.system(FFdgmD("rm -f '%s%s'" % (VVaZdT, path)))
  cbFnc()
  VVmQZXObj.cancel()
 def VVXmDj(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCKt5L()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VVp1hh, filePrefix))
 def VVp1hh(self, filePrefix, result, retval):
  title = FF39sf()
  if pathExists(VVaZdT):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFGIBw(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVaZdT, filePrefix, FFgfmJ())
    try:
     VVSmWK = str(result.strip()).split()
     if VVSmWK:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVSmWK:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VV1xmU, FFARnG(fName, VVclxO), VV1xmU)
       FF0fhx(self, txt, title=title, VV51s0=VVtGrg)
      else:
       FFGIBw(self, "File creation failed!", title)
     else:
      FFGIBw(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFdgmD("rm %s" % fName))
     FFGIBw(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFdgmD("rm %s" % fName))
     FFGIBw(self, "Error while writing file.")
  else:
   FFGIBw(self, "Path not found:\n\n%s" % VVaZdT, title)
 def VVTbs5(self, mode, path):
  if path:
   path = "%s%s" % (VVaZdT, path)
   if fileExists(path):
    lines = FFrxQp(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys/FHDG17"
     FFhMkA(self, boundFunction(self.VVufgM, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFvbMM(self, path, title=FF39sf())
   else:
    FFQ3EB(self, path)
 def VVufgM(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVrfZj = []
  VVrfZj.append("echo -e 'Reading current settings ...'")
  VVrfZj.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVrfZj.append("echo -e 'Preparing new settings ...'")
  VVrfZj.append(settingsLines)
  VVrfZj.append("echo -e 'Applying new settings ...'")
  VVrfZj.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFQCpM(self, VVrfZj)
 def VVNmp0(self, VVmQZXObj, path):
  if not path:
   return
  path = VVaZdT + path
  if not fileExists(path):
   FFQ3EB(self, path)
   return
  txt = FFJ07K(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVSmWK  = []
   for item in satList:
    VVSmWK.append("%s\t%s" % (item[0], FFKq5s(item[1])))
   FF0fhx(self, VVSmWK, title="  Satellites List")
  else:
   FFGIBw(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCtwWm(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFdxjB(VVwo8o, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVY2K2 = []
  VVY2K2.append(("Plugins Browser List"       , "VVzGKK"   ))
  VVY2K2.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVY2K2.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVY2K2.append(("Remove Packages (show all)"     , "VVhQHNsAll"   ))
  VVY2K2.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Update List of Available Packages"   , "VVhUjP"   ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Packaging Tool"        , "VVYFQG"    ))
  VVY2K2.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFSskZ(self, VVY2K2=VVY2K2)
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  FFUwX1(self["myMenu"])
  FF2Dma(self)
 def VVtv5z(self):
  global VVXLue
  VVXLue = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVzGKK"   : self.VVzGKK()
   elif item == "pluginsMenus"     : self.VVTQNo(0)
   elif item == "pluginsStartup"    : self.VVTQNo(1)
   elif item == "pluginsDirList"    : self.VVoPoC()
   elif item == "downloadInstallPackages"  : FFjQre(self, boundFunction(self.VVQjKe, 0, ""))
   elif item == "VVhQHNsAll"   : FFjQre(self, boundFunction(self.VVQjKe, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFjQre(self, boundFunction(self.VVQjKe, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVhUjP"   : self.VVhUjP()
   elif item == "VVYFQG"    : self.VVYFQG()
   elif item == "packagesFeeds"    : self.VVCRM5()
   else          : self.close()
 def VVoPoC(self):
  extDirs  = FFc3Q8(VVgQjM)
  sysDirs  = FFc3Q8(VVdP4f)
  VVSmWK  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVSmWK.append((item, VVgQjM + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVSmWK.append((item, VVdP4f + item))
  if VVSmWK:
   VVSmWK = sorted(VVSmWK, key=lambda x: x[0].lower())
   VVBoAr = ("Package Info.", self.VVmaKY, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFp1uk(self, None, header=header, VVSmWK=VVSmWK, VVO0tX=widths, VV715D=28, VVBoAr=VVBoAr)
  else:
   FFGIBw(self, "Nothing found!")
 def VVmaKY(self, VV3o52, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVgQjM) : loc = "extensions"
  elif path.startswith(VVdP4f) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VV0Rus(package)
  else:
   FFGIBw(self, "No info!")
 def VVCRM5(self):
  pkg = FFwItZ()
  if pkg : FF0eWo(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFvteW(self)
 def VVzGKK(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVOxXn(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VV1xmU + "\n"
    txt += VVOxXn("Number"   , str(c))
    txt += VVOxXn("Name"   , FFARnG(str(p.name), VVclxO))
    txt += VVOxXn("Path"  , p.path  )
    txt += VVOxXn("Description" , p.description )
    txt += VVOxXn("Icon"  , p.iconstr  )
    txt += VVOxXn("Wakeup Fnc" , p.wakeupfnc )
    txt += VVOxXn("NeedsRestart", p.needsRestart)
    txt += VVOxXn("Internal" , p.internal )
    txt += VVOxXn("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FF0fhx(self, txt)
 def VVTQNo(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVSmWK = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVSmWK.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVSmWK:
   VVSmWK.sort(key=lambda x: x[0].lower())
   header  = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths  = (19  , 25 , 20  , 27   , 9  )
   FFp1uk(self, None, title=title, header=header, VVSmWK=VVSmWK, VVO0tX=widths, VV715D=26)
  else:
   FFGIBw(self, "Nothing Found", title=title)
 def VVhUjP(self):
  cmd = FFBzKc(VVSxeo, "")
  if cmd : FFRQmD(self, cmd, checkNetAccess=True)
  else : FFvteW(self)
 def VVYFQG(self):
  pkg = FFwItZ()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFrLx8(self, txt)
 def VVQjKe(self, mode, grep, VV3o52=None, title=""):
  if   mode == 0: cmd = FFBzKc(VV1smy    , grep)
  elif mode == 1: cmd = FFBzKc(VV42eY , grep)
  elif mode == 2: cmd = FFBzKc(VV42eY , grep)
  if not cmd:
   FFvteW(self)
   return
  VVx2Uc = FFVHBJ(cmd)
  if not VVx2Uc:
   if VV3o52: VV3o52.VVU8jU()
   FFGIBw(self, "No packages found!")
   return
  elif len(VVx2Uc) == 1 and VVx2Uc[0] == VVhENq:
   FFGIBw(self, VVhENq)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVSmWK  = []
  for item in VVx2Uc:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVSmWK.append((name, package, version))
  if mode > 0:
   extensions = FFVHBJ("ls %s -l | grep '^d' | awk '{print $9}'" % VVgQjM)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVSmWK:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVSmWK.append((name, VVgQjM + item, "-"))
   systemPlugins = FFVHBJ("ls %s -l | grep '^d' | awk '{print $9}'" % VVdP4f)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVSmWK:
      if item.lower() == row[0].lower():
       break
     else:
      VVSmWK.append((item, VVdP4f + item, "-"))
  if not VVSmWK:
   FFGIBw(self, "No packages found!")
   return
  if VV3o52:
   VVSmWK.sort(key=lambda x: x[0].lower())
   VV3o52.VVnh9K(VVSmWK, title)
  else:
   widths = (20, 50, 30)
   VV4tKk = None
   VVMZtN = None
   if mode == 0:
    VVPAO4 = ("Install" , self.VVSoKZ   , [])
    VV4tKk = ("Download" , self.VVvx9T   , [])
    VVMZtN = ("Filter"  , self.VVnekJ , [])
   elif mode == 1:
    VVPAO4 = ("Uninstall", self.VVhQHN, [])
   elif mode == 2:
    VVPAO4 = ("Uninstall", self.VVhQHN, [])
    widths= (18, 57, 25)
   VVSmWK = sorted(VVSmWK, key=lambda x: x[0].lower())
   VVBoAr = ("Package Info.", self.VVNjNA, [])
   header   = ("Name" ,"Package" , "Version" )
   FFp1uk(self, None, header=header, VVSmWK=VVSmWK, VVO0tX=widths, VV715D=28, VVPAO4=VVPAO4, VV4tKk=VV4tKk, VVBoAr=VVBoAr, VVMZtN=VVMZtN, VVvwsy=self.lastSelectedRow
     , VVdawd="#22110011", VV2xlz="#22191111", VVSwM6="#22191111", VVb1yt="#00003030", VVBWV3="#00333333")
 def VVNjNA(self, VV3o52, title, txt, colList):
  package = colList[1]
  self.VV0Rus(package)
 def VVnekJ(self, VV3o52, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVY2K2 = []
  VVY2K2.append(("All Packages", "all"))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVY2K2.append(VV8PP6)
  for word in words:
   VVY2K2.append((word, word))
  FFlTf2(self, boundFunction(self.VVYh2n, VV3o52), VVY2K2=VVY2K2, title="Select Filter")
 def VVYh2n(self, VV3o52, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFjQre(VV3o52, boundFunction(self.VVQjKe, 0, grep, VV3o52, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVhQHN(self, VV3o52, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVgQjM, VVdP4f)):
   FFhMkA(self, boundFunction(self.VVxADV, VV3o52, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVY2K2 = []
   VVY2K2.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVY2K2.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVY2K2.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFlTf2(self, boundFunction(self.VVZRKC, VV3o52, package), VVY2K2=VVY2K2)
 def VVxADV(self, VV3o52, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVOmuD)
  FFRQmD(self, cmd, VVB9mM=boundFunction(self.VVv02S, VV3o52))
 def VVZRKC(self, VV3o52, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVppV2
   elif item == "remove_ForceRemove"  : cmdOpt = VV9MSv
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVZWgG
   FFhMkA(self, boundFunction(self.VV01Ch, VV3o52, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VV01Ch(self, VV3o52, package, cmdOpt):
  self.lastSelectedRow = VV3o52.VViQry()
  cmd = FF6Z6k(cmdOpt, package)
  if cmd : FFRQmD(self, cmd, VVB9mM=boundFunction(self.VVv02S, VV3o52))
  else : FFvteW(self)
 def VVv02S(self, VV3o52):
  VV3o52.cancel()
  FFUTZz()
 def VVSoKZ(self, VV3o52, title, txt, colList):
  package  = colList[1]
  VVY2K2 = []
  VVY2K2.append(("Install Package"         , "install_CheckVersion" ))
  VVY2K2.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVY2K2.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVY2K2.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFlTf2(self, boundFunction(self.VV35fL, package), VVY2K2=VVY2K2)
 def VV35fL(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVXJyy
   elif item == "install_ForceReinstall" : cmdOpt = VVwrhV
   elif item == "install_ForceDowngrade" : cmdOpt = VVPsXk
   elif item == "install_IgnoreDepends" : cmdOpt = VVhTwG
   FFhMkA(self, boundFunction(self.VVkggv, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVkggv(self, package, cmdOpt):
  cmd = FF6Z6k(cmdOpt, package)
  if cmd : FFRQmD(self, cmd, VVB9mM=FFUTZz, checkNetAccess=True)
  else : FFvteW(self)
 def VVvx9T(self, VV3o52, title, txt, colList):
  package  = colList[1]
  FFhMkA(self, boundFunction(self.VVGOjo, package), "Download Package ?\n\n%s" % package)
 def VVGOjo(self, package):
  if FFje6c():
   cmd = FF6Z6k(VV4d6C, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFAawR(success, VVFGoE))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFAawR(fail, VVu486))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFRQmD(self, cmd, VVN4E2=[VVu486, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFvteW(self)
  else:
   FFGIBw(self, "No internet connection !")
 def VV0Rus(self, package):
  infoCmd  = FF6Z6k(VV4TlP, package)
  filesCmd = FF6Z6k(VVjQPZ, package)
  listInstCmd = FFBzKc(VV42eY, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FF12CE(VVclxO)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFAawR(notInst, VVEAFU))
   cmd += "else "
   cmd +=   FFamyI("System Info", VVclxO)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFamyI("Related Files", VVclxO)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFTlgq(self, cmd)
  else:
   FFvteW(self)
class CCJkx4(Screen):
 VV65D8  = 0
 VV3wqu = 1
 VVmeMm  = 2
 VVINAl  = 3
 VVZjyx = 4
 VVuxjO = 5
 VVtwfp = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFdxjB(VVwo8o, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VV9jmg = None
  self.lastfilterUsed  = None
  VVY2K2 = self.VVQHbD()
  FFSskZ(self, VVY2K2=VVY2K2, title="Services/Channels")
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self["myMenu"].setList(self.VVQHbD())
  FFUwX1(self["myMenu"])
  FF2Dma(self)
 def VVQHbD(self):
  VVY2K2 = []
  VVY2K2.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VVY2K2.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Services (Reference)"      , "lameDB_allChannels_with_refCode"  ))
  VVY2K2.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVY2K2.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVY2K2.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVY2K2.append(("Services with PIcons for the System"  , "VVLiQO"     ))
  VVY2K2.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVY2K2.append(VV8PP6)
  lamedbFile, disabledFile = CCJkx4.VVAbsl()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVY2K2.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVY2K2.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVY2K2.append(("Reset Parental Control Settings"   , "VV2A2D"    ))
  VVY2K2.append(("Delete Channels with no names"   , "VV0orW"    ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Reload Channels and Bouquets"    , "VVayXs"      ))
  return VVY2K2
 def VVtv5z(self):
  global VVXLue
  VVXLue = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFWYRU(self)
   elif item == "currentServiceInfo"     : FFzRsg(self, fncMode=CCf574.VVaQXu)
   elif item == "TranspondersStats"     : FFjQre(self, self.VVcD3T     )
   elif item == "lameDB_allChannels_with_refCode"  : FFjQre(self, self.VVyNBB )
   elif item == "lameDB_allChannels_with_tranaponder" : FFjQre(self, self.VVENK9)
   elif item == "lameDB_allChannels_with_details"  : FFjQre(self, self.VVHGrv )
   elif item == "parentalControlChannels"    : FFjQre(self, self.VVIxb3   )
   elif item == "showHiddenChannels"     : FFjQre(self, self.VVkQKh     )
   elif item == "VVLiQO"     : FFjQre(self, self.VV885M     )
   elif item == "servicesWithMissingPIcons"   : FFjQre(self, self.VVSoFg   )
   elif item == "enableHiddenChannels"     : self.VVcG0B(True)
   elif item == "disableHiddenChannels"    : self.VVcG0B(False)
   elif item == "VV2A2D"    : FFhMkA(self, self.VV2A2D, "Reset and Restart ?" )
   elif item == "VV0orW"    : FFjQre(self, self.VV0orW)
   elif item == "VVayXs"      : FFjQre(self, boundFunction(CCJkx4.VVayXs, self))
   else            : self.close()
 @staticmethod
 def VVayXs(SELF):
  FFCe2y()
  FFrLx8(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVyNBB(self):
  self.VV9jmg = None
  self.lastfilterUsed  = None
  self.filterObj   = CCD6d0(self)
  VVx2Uc = CCJkx4.VVbEdM(self, self.VV65D8)
  if VVx2Uc:
   VVx2Uc.sort(key=lambda x: x[0].lower())
   VVuedc  = ("Zap"   , self.VVI903     , [])
   VVGP73 = (""    , self.VVzzrI   , [])
   VVBoAr = ("Options"  , self.VVK5IL , [])
   VV4tKk = ("Current Service", self.VVYLSH , [])
   VVMZtN = ("Filter"   , self.VVk7tZ  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVD84s  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFp1uk(self, None, header=header, VVSmWK=VVx2Uc, VVD84s=VVD84s, VVO0tX=widths, VV715D=26, VVuedc=VVuedc, VVGP73=VVGP73, VV4tKk=VV4tKk, VVBoAr=VVBoAr, VVMZtN=VVMZtN)
 def VVENK9(self):
  self.VV9jmg = None
  self.lastfilterUsed  = None
  self.filterObj   = CCD6d0(self)
  VVx2Uc = CCJkx4.VVbEdM(self, self.VV3wqu)
  if VVx2Uc:
   VVx2Uc.sort(key=lambda x: x[0].lower())
   VVuedc  = ("Zap"   , self.VVI903      , [])
   VVGP73 = (""    , self.VVzzrI    , [])
   VV4tKk = ("Current Service", self.VVYLSH  , [])
   VVBoAr = ("Options"  , self.VV22Eo , [])
   VVMZtN = ("Filter"   , self.VV6RHt  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVD84s  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFp1uk(self, None, header=header, VVSmWK=VVx2Uc, VVD84s=VVD84s, VVO0tX=widths, VV715D=26, VVuedc=VVuedc, VVGP73=VVGP73, VV4tKk=VV4tKk, VVBoAr=VVBoAr, VVMZtN=VVMZtN)
 def VVK5IL(self, VV3o52, title, txt, colList):
  servName = colList[0]
  refCode  = colList[3]
  pcState  = colList[4]
  hidState = colList[5]
  mSel  = CCZ5ac(self, VV3o52, 3)
  mSel.VVN7xP(servName, refCode, pcState, hidState)
 def VV22Eo(self, VV3o52, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CCZ5ac(self, VV3o52, 3)
  mSel.VV4V4u(servName, refCode)
 def VVzzZo(self, VV3o52, refCode, isAddToBlackList):
  self.VV9jmg = None
  self.lastfilterUsed  = None
  VV3o52.VVxOlm("Changing state ...")
  path = "/etc/enigma2/blacklist"
  if not fileExists(path):
   os.system("echo '' > %s" % path)
  if fileExists(path):
   if not refCode.endswith(":"):
    refCode += ":"
   if isAddToBlackList :
    os.system("sed -i '/%s/d' %s" % (refCode, path))
    os.system("echo '%s' >> %s" % (refCode, path))
   else:
    os.system("sed -i '/%s/d' %s" % (refCode, path))
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   if refCode.endswith(":"):
    refCode = refCode[:-1]
   FFjQre(self, boundFunction(self.VV9GNv, VV3o52, refCode))
  else:
   FFQ3EB(self, path)
 def VVfcbw(self, VV3o52, refCode, isHide):
  self.VV9jmg = None
  self.lastfilterUsed  = None
  VV3o52.VVxOlm("Changing state ...")
  if FFTzh3(refCode):
   ret = FFKliL(refCode, isHide)
   if ret : FFjQre(self, boundFunction(self.VV9GNv, VV3o52, refCode))
   else : FFGIBw(self, "Cannot Hide/Unhide this channel.")
  else:
   FFGIBw(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)")
 def VV9GNv(self, VV3o52, refCode):
  VVx2Uc = CCJkx4.VVbEdM(self, self.VV65D8, VVN3lc=[3, [refCode], False])
  done = False
  if VVx2Uc:
   data = VVx2Uc[0]
   if data[3] == refCode:
    done = VV3o52.VV98qP(data)
  if not done:
   self.VVGAkx(VV3o52, VV3o52.VV8QuM(), self.VV65D8)
  VV3o52.VVU8jU()
 def VVk7tZ(self, VV3o52, title, txt, colList):
  self.filterObj.VVOMlh(1, VV3o52, 2, boundFunction(self.VVxG6Q, VV3o52))
 def VVxG6Q(self, VV3o52, item):
  self.VVzwTW(VV3o52, item, 2, self.VV65D8)
 def VV6RHt(self, VV3o52, title, txt, colList):
  self.filterObj.VVOMlh(2, VV3o52, 4, boundFunction(self.VVbIm9, VV3o52))
 def VVbIm9(self, VV3o52, item):
  self.VVzwTW(VV3o52, item, 4, self.VV3wqu)
 def VV7o8k(self, VV3o52, title, txt, colList):
  self.filterObj.VVOMlh(0, VV3o52, 4, boundFunction(self.VVuvFy, VV3o52))
 def VVuvFy(self, VV3o52, item):
  self.VVzwTW(VV3o52, item, 4, self.VVmeMm)
 def VVzwTW(self, VV3o52, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VV3o52.VViajA(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VV9jmg = None
  else:
   words, asPrefix = CCD6d0.VVGIe9(words)
   self.VV9jmg = [col, words, asPrefix]
  if words: FFjQre(self, boundFunction(self.VVGAkx, VV3o52, title, mode), title="Reading Services ...")
  else : FF3ty7(VV3o52, "Incorrect filter", 2000)
 def VVGAkx(self, VV3o52, title, mode):
  VVx2Uc = CCJkx4.VVbEdM(self, mode, VVN3lc=self.VV9jmg, VVPUZv=False)
  if VVx2Uc:
   VVx2Uc.sort(key=lambda x: x[0].lower())
   VV3o52.VVnh9K(VVx2Uc, title)
  else:
   VV3o52.VVU8jU()
   FF3ty7(VV3o52, "Not found!", 1500)
 def VV86Vl(self, VVSmWK, VVuedc=None, VVGP73=None, VVPAO4=None, VV4tKk=None, VVBoAr=None, VVMZtN=None):
  VV4tKk = ("Current Service", self.VVYLSH, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVD84s = (LEFT  , LEFT  , CENTER, LEFT    )
  FFp1uk(self, None, header=header, VVSmWK=VVSmWK, VVD84s=VVD84s, VVO0tX=widths, VV715D=26, VVuedc=VVuedc, VVGP73=VVGP73, VVPAO4=VVPAO4, VV4tKk=VV4tKk, VVBoAr=VVBoAr, VVMZtN=VVMZtN)
 def VVYLSH(self, VV3o52, title, txt, colList):
  self.VVtqWv(VV3o52)
 def VV1d3L(self, VV3o52, title, txt, colList):
  self.VVtqWv(VV3o52, True)
 def VVtqWv(self, VV3o52, isFromDetails=False):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFlPZP(self)
  if refCode:
   if isFromDetails:
    chName  = info.getName()
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VV3o52.VV7yyv(colDict, VVA3IL=True)
   else:
    VV3o52.VVV2sO(3, refCode, True)
   return
  FFGIBw(self, "Colud not read current Reference Code !")
 def VVHGrv(self):
  self.VV9jmg = None
  self.lastfilterUsed  = None
  self.filterObj   = CCD6d0(self)
  VVx2Uc = CCJkx4.VVbEdM(self, self.VVmeMm)
  if VVx2Uc:
   VVx2Uc.sort(key=lambda x: x[0].lower())
   VVGP73 = (""    , self.VVuovg , []      )
   VV4tKk = ("Current Service", self.VV1d3L  , []      )
   VVMZtN = ("Filter"   , self.VV7o8k   , [], "Loading Filters ..." )
   VVuedc  = ("Zap"   , self.VVENIe      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVD84s  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFp1uk(self, None, header=header, VVSmWK=VVx2Uc, VVD84s=VVD84s, VVO0tX=widths, VV715D=26, VVuedc=VVuedc, VVGP73=VVGP73, VV4tKk=VV4tKk, VVMZtN=VVMZtN)
 def VVuovg(self, VV3o52, title, txt, colList):
  refCode  = self.VVgACX(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFzRsg(self, fncMode=CCf574.VVCPND, refCode=refCode, chName=chName, text=txt)
 def VVENIe(self, VV3o52, title, txt, colList):
  refCode = self.VVgACX(colList)
  FFBoZM(self, refCode)
 def VVI903(self, VV3o52, title, txt, colList):
  FFBoZM(self, colList[3])
 def VVgACX(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVbEdM(SELF, mode, VVN3lc=None, VVPUZv=True, VVGmkd=True):
  lamedbFile, disabledFile = CCJkx4.VVAbsl()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVN3lc:
    filterCol = VVN3lc[0]
    filterWords = VVN3lc[1]
    asPrefix = VVN3lc[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCJkx4.VV65D8:
    blackList = None
    path = "/etc/enigma2/blacklist"
    if fileExists(path):
     blackList = FFrxQp(path)
     if blackList:
      blackList = set(blackList)
   elif mode == CCJkx4.VV3wqu:
    tp = CC8VoG()
   VVBag4, VVEr7j = FFfZ3i()
   tagFound  = False
   if mode in (CCJkx4.VVuxjO, CCJkx4.VVtwfp):
    VVx2Uc = {}
   else:
    VVx2Uc = []
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFHRLV(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CCJkx4.VVmeMm:
        if sTypeInt in VVBag4:
         STYPE = VVEr7j[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVx2Uc.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVx2Uc.append(tRow)
        else:
         VVx2Uc.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCJkx4.VVuxjO:
         VVx2Uc[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCJkx4.VVtwfp:
         VVx2Uc[chName] = refCode
        elif mode == CCJkx4.VV65D8:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVx2Uc.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVx2Uc.append(tRow)
         else:
          VVx2Uc.append(tRow)
        elif mode == CCJkx4.VV3wqu:
         if sTypeInt in VVBag4:
          STYPE = VVEr7j[sTypeInt]
         freq, pol, fec, sr, syst = tp.VVcF7q(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVx2Uc.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVx2Uc.append(tRow)
         else:
          VVx2Uc.append(tRow)
        elif mode == CCJkx4.VVINAl:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VVx2Uc.append((chName, chProv, sat, refCode))
        elif mode == CCJkx4.VVZjyx:
         VVx2Uc.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VVx2Uc and VVPUZv:
    FFGIBw(SELF, "No services found!")
   return VVx2Uc
  else:
   if VVGmkd:
    FFQ3EB(SELF, lamedbFile)
   return None
 def VVIxb3(self):
  path = "/etc/enigma2/blacklist"
  if fileExists(path):
   lines = FFrxQp(path)
   if lines:
    newRows  = []
    VVx2Uc = CCJkx4.VVbEdM(self, self.VVZjyx)
    if VVx2Uc:
     lines = set(lines)
     for item in VVx2Uc:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVx2Uc = newRows
      VVx2Uc.sort(key=lambda x: x[0].lower())
      VVGP73 = ("", self.VVzzrI, [])
      VVuedc = ("Zap", self.VVI903, [])
      self.VV86Vl(VVSmWK=VVx2Uc, VVuedc=VVuedc, VVGP73=VVGP73)
     else:
      FF0fhx(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVx2Uc)))
   else:
    FFrLx8(self, "No active Parental Control services.", FF39sf())
  else:
   FFQ3EB(self, path)
 def VVkQKh(self):
  VVx2Uc = CCJkx4.VVbEdM(self, self.VVINAl)
  if VVx2Uc:
   VVx2Uc.sort(key=lambda x: x[0].lower())
   VVGP73 = ("" , self.VVzzrI, [])
   VVuedc  = ("Zap", self.VVI903, [])
   self.VV86Vl(VVSmWK=VVx2Uc, VVuedc=VVuedc, VVGP73=VVGP73)
  else:
   FFrLx8(self, "No hidden services.", FF39sf())
 def VVcD3T(self):
  totT, totC, totA, totS, totS2, satList = self.VVaZN9()
  txt = FFARnG("Total Transponders:\n\n", VVylYU)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFARnG("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVylYU)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FF5EWS(item), satList.count(item))
  FF0fhx(self, txt)
 def VVaZN9(self):
  lamedbFile, disabledFile = CCJkx4.VVAbsl()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFQ3EB(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VV885M(self)   : self.VVLiQO(True)
 def VVSoFg(self) : self.VVLiQO(False)
 def VVLiQO(self, isWithPIcons):
  piconsPath = CCJRmr.VVFZXX()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCJRmr.VVRMRU(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVx2Uc = CCJkx4.VVbEdM(self, self.VVZjyx)
    if VVx2Uc:
     channels = []
     for (chName, chProv, sat, refCode) in VVx2Uc:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFVKj3(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVx2Uc)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVOxXn(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVOxXn("PIcons Path"  , piconsPath)
     txt += VVOxXn("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVOxXn("Total services" , totalServices)
     txt += VVOxXn("With PIcons"  , totalWithPIcons)
     txt += VVOxXn("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FF0fhx(self, txt)
     else:
      VVGP73     = (""      , self.VVzzrI , [])
      if isWithPIcons : VVMZtN = ("Export Current PIcon", self.VVM3hV  , [])
      else   : VVMZtN = None
      VVBoAr     = ("Statistics", FF0fhx, [txt])
      VVuedc      = ("Zap", self.VVI903, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VV86Vl(VVSmWK=channels, VVuedc=VVuedc, VVGP73=VVGP73, VVBoAr=VVBoAr, VVMZtN=VVMZtN)
   else:
    FFGIBw(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFGIBw(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVzzrI(self, VV3o52, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFzRsg(self, fncMode=CCf574.VVCPND, refCode=refCode, chName=chName, text=txt)
 def VVM3hV(self, VV3o52, title, txt, colList):
  png, path = CCJRmr.VVh50m(colList[3], colList[0])
  if path:
   CCJRmr.VV3K2k(self, png, path)
 @staticmethod
 def VVAbsl():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VV7IJt():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVcG0B(self, isEnable):
  lamedbFile, disabledFile = CCJkx4.VVAbsl()
  if isEnable and not fileExists(disabledFile):
   FFrLx8(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FFGIBw(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFhMkA(self, boundFunction(self.VVk5lL, isEnable), "%s Hidden Channels ?" % word)
 def VVk5lL(self, isEnable):
  lamedbFile , disabledFile = CCJkx4.VVAbsl()
  lamedb5File, diabled5File = CCJkx4.VV7IJt()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FFCe2y()
  if res == 0 : FFrLx8(self, "Hidden List %s" % word)
  else  : FFGIBw(self, "Error while restoring:\n\n%s" % fileName)
 def VV2A2D(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFQCpM(self, cmd)
 def VV0orW(self):
  lamedbFile, disabledFile = CCJkx4.VVAbsl()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFdgmD("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFrxQp(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFdgmD("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FFCe2y()
   FF0fhx(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFQ3EB(self, lamedbFile)
class CCf574(Screen):
 VVaQXu  = 0
 VVSOLR   = 1
 VViYuI   = 2
 VVCPND    = 3
 VVHJnm    = 4
 VVSTlF   = 5
 VVjfHv   = 6
 VVTnNa    = 7
 VVzoSk   = 8
 VVXOHw   = 9
 VVTN1O   = 10
 VVwj6q   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFdxjB(VVI3k3, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVaQXu)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFARnG("%s\n", VVcwMp) % VV1xmU
  FFSskZ(self, title="Channel Info", addScrollLabel=True)
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  self["myLabel"].VVwJt1(textOutFile="chann_info")
  if   self.fncMode == self.VVaQXu : fnc = self.VVoRKT_VVaQXu
  elif self.fncMode == self.VVSOLR  : fnc = self.VVoRKT_VVaQXu
  elif self.fncMode == self.VViYuI  : fnc = self.VVoRKT_VVaQXu
  elif self.fncMode == self.VVCPND  : fnc = self.VVoRKT_VVCPND
  elif self.fncMode == self.VVHJnm  : fnc = self.VVoRKT_VVHJnm
  elif self.fncMode == self.VVSTlF  : fnc = self.VVoRKT_VVSTlF
  elif self.fncMode == self.VVjfHv  : fnc = self.VVoRKT_VVjfHv
  elif self.fncMode == self.VVTnNa  : fnc = self.VVoRKT_VVTnNa
  elif self.fncMode == self.VVzoSk  : fnc = self.VVoRKT_VVzoSk
  elif self.fncMode == self.VVXOHw : fnc = self.VVoRKT_VVXOHw
  elif self.fncMode == self.VVTN1O  : fnc = self.VVoRKT_VVTN1O
  elif self.fncMode == self.VVwj6q : fnc = self.VVoRKT_VVwj6q
  self["myLabel"].setText("\n   Reading Info ...")
  FFo2XQ(fnc)
 def VVVANR(self, err):
  self["myLabel"].setText(err)
  FFidK4(self["myTitle"], "#22200000")
  FFidK4(self["myBody"], "#22200000")
  self["myLabel"].FFidK4Color("#22200000")
  self["myLabel"].VVhchq()
 def VVoRKT_VVaQXu(self):
  try:
   dum = self.session
  except:
   return
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFlPZP(self)
  self.refCode = refCode
  self.VVca7y(chName)
 def VVoRKT_VVCPND(self):
  self.VVca7y(self.chName)
 def VVoRKT_VVHJnm(self):
  self.VVca7y(self.chName)
 def VVoRKT_VVSTlF(self):
  self.VVca7y(self.chName)
 def VVoRKT_VVjfHv(self):
  self.VVca7y("Picon Info")
 def VVoRKT_VVTnNa(self):
  self.VVca7y(self.chName)
 def VVoRKT_VVzoSk(self):
  self.VVca7y(self.chName)
 def VVoRKT_VVXOHw(self):
  self.VVca7y(self.chName)
 def VVoRKT_VVTN1O(self):
  self.chUrl = self.refCode + self.callingSELF.VVhBqE(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVca7y(self.chName)
 def VVoRKT_VVwj6q(self):
  self.VVca7y(self.chName)
 def VVca7y(self, title):
  self.VVEZQY(title)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFlPZP(self)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VV5vif(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFARnG(self.VV6k70(tUrl), VVPTHk)
  if not self.epg:
   epg = self.VVrXRl(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VV11yW(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCJRmr.VVh50m(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VV11yW(path)
  self.VVweHx()
  self.VVRHf1()
  self["myLabel"].setText(self.text, VV51s0=VVyd8y)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVhchq(minHeight=minH)
 def VVRHf1(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFRlBi(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVzI81(FFpzGx(url))
  if epg:
   self.text += "\n" + FFmLFC("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVweHx()
 def VVweHx(self):
  if not self.piconShown and self.picUrl:
   path, err = FFV6A0(self.picUrl, "ajpanel_tmp.png", timeout=2)
   if path:
    self.piconShown = self.VV11yW(path)
    if self.piconShown and self.refCode:
     self.VVHiMA(path, self.refCode)
 def VVHiMA(self, path, refCode):
  if path and fileExists(path) and os.system(FFdgmD("which ffmpeg")) == 0:
   pPath = CCJRmr.VVFZXX()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
    cmd += FFdgmD("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VV11yW(self, path):
  if path and fileExists(path):
   err, w, h = self.VVQK1e(path)
   if not err:
    if h > w:
     self.VVaJwh(self["myPicF"], w, h, True)
     self.VVaJwh(self["myPic"] , w, h, False)
   allOK = FFYffG(self["myPic"], path)
   if allOK:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVaJwh(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVQK1e(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FF3QAx(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVEZQY(self, chName):
  if chName:
   self["myTitle"].setText("  " + chName + "  ")
 def VV5vif(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFARnG(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVOxXn(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFARnG(state, VVEAFU)
   txt += "State\t: %s\n" % state
  w = FFzECc(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFzECc(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVRDJC(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVOxXn(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVOxXn(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVOxXn(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  isIptv = len(iptvRef) > 0
  if iptvRef:
   txt += "Service Type\t: %s\n" % FFARnG("IPTV", VVylYU)
   txt += self.VVum2W(iptvRef)
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not refCode:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    path = serv.getPath()
    if path:
     txt += "Path\t: %s\n" % path
  txt += "\n"
  txt += self.VVoCo7(refCode, iptvRef, chName)
  if not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CC8VoG()
    tpTxt, namespace = tp.VVNbt0(refCode)
    del tp
    if tpTxt:
     txt += FFARnG("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFARnG("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVOxXn(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVOxXn(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVOxXn(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVOxXn(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVOxXn(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVOxXn(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVOxXn(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVOxXn(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVOxXn(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVRDJC(info):
  if info:
   aspect = FFzECc(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVOxXn(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFzECc(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVuSTx(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVuSTx(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVoCo7(self, refCode, iptvRef, chName):
  refCode = FFnNMM(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFJ07K(VVVAau + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFJ07K(VVVAau + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VVSmWK = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVVAau + item
   if fileExists(path):
    txt = FFJ07K(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVSmWK.append(bName)
  txt = self.Sep
  if VVSmWK:
   if len(VVSmWK) == 1:
    txt += "%s\t: %s\n" % (FFARnG("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VVSmWK[0])
   else:
    txt += FFARnG("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VVSmWK):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVrXRl(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVO6Fa(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVO6Fa(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVO6Fa(event, 0)
     except:
      pass
  return epg
 def VVO6Fa(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName().strip()    or ""
   evTime = event.getBeginTime()      or ""
   evDur = event.getDuration()      or ""
   evShort = event.getShortDescription() .strip() or ""
   evDesc = event.getExtendedDescription().strip() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = self.VV9xbF(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FFARnG(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FFARnG(evNameTransl, COLOR_CONS_BRIGHT_YELLOW))
    if evTime           : txt += "Start Time\t: %s\n" % FFXzY3(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFXzY3(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFBS4u(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFBS4u(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFBS4u(evTime - now)
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFARnG(evShort, VVrHls)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFARnG(evDesc , VVrHls)
    if txt:
     txt = FFARnG("\n%s\n%s Event:\n%s\n" % (VV1xmU, ("Current", "Next")[evNum], VV1xmU), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVum2W(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFSPfg(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCuZpw()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVnTCL(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFARnG("URL:", VVylYU) + "\n%s\n" % self.VV6k70(decodedUrl)
  else:
   txt = "\n"
   txt += FFARnG("Reference:", VVylYU) + "\n%s\n" % refCode
  return txt
 def VV6k70(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVlmpc:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VVzI81(self, decodedUrl):
  if not FFje6c():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCfvbT.VV1Nl0(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (not a subscription ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCfvbT.VVhcFk(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVS8mx(tDict)
   elif uType == "movie" : epg, picUrl = self.VVtdlu(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVS8mx(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCfvbT.VV1IeQ(item, "title"    , is_base64=True )
     lang    = CCfvbT.VV1IeQ(item, "lang"         ).upper()
     description   = CCfvbT.VV1IeQ(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCfvbT.VV1IeQ(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCfvbT.VV1IeQ(item, "start_timestamp"      )
     stop_timestamp  = CCfvbT.VV1IeQ(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCfvbT.VV1IeQ(item, "stop_timestamp"       )
     now_playing   = CCfvbT.VV1IeQ(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVYHoM, ""
      else     : color, txt = VVEAFU , "    (CURRENT EVENT)"
      epg += FFARnG("_" * 32 + "\n", VVcwMp)
      epg += FFARnG("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFARnG(description, VVPTHk)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVrfH2(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VVtdlu(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCfvbT.VV1IeQ(item, "movie_image" )
    genre  = CCfvbT.VV1IeQ(item, "genre"   ) or "-"
    plot  = CCfvbT.VV1IeQ(item, "plot"   ) or "-"
    cast  = CCfvbT.VV1IeQ(item, "cast"   ) or "-"
    rating  = CCfvbT.VV1IeQ(item, "rating"   ) or "-"
    director = CCfvbT.VV1IeQ(item, "director"  ) or "-"
    releasedate = CCfvbT.VV1IeQ(item, "releasedate" ) or "-"
    duration = CCfvbT.VV1IeQ(item, "duration"  ) or "-"
    try:
     lang = CCfvbT.VV1IeQ(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFARnG(cast, VVPTHk)
    epg += "Plot:\n%s"    % FFARnG(self.VV9xbF(plot), VVPTHk)
   except:
    pass
  return epg, movie_image
 def VV9xbF(self, evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = self.VVHbvj(evTxt, lang)
   return self.VVMj8r(txt).strip() or evTxt
 def VVMj8r(self, txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VVHbvj(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFA0q6(txt))
   txt, err = CCfvbT.VVhcFk(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFpzGx(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVrfH2(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
class CCuZpw():
 def __init__(self):
  self.VVr7B5  = ""
  self.VVbEdr   = ""
  self.VV4Dg1  = ""
  self.colored_user  = "#f#11ffffaa#User"
  self.colored_server  = "#f#11aaffff#Server"
 def VVMgiU(self, url, mac, VVA3IL=True):
  self.VVr7B5 = ""
  self.VVbEdr  = ""
  self.VV4Dg1 = ""
  host = self.VV9eN6(url)
  if not host:
   if VVA3IL:
    self.VVA3ILor("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVa1oU(mac)
  if not host:
   if VVA3IL:
    self.VVA3ILor("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVr7B5 = host
  self.VVbEdr  = mac
  self.VV4Dg1 = ""
  return True
 def VVpB00(self):
  res, err = self.VVSKJS(self.VVr7B5, useCookies=False)
  if err:
   self.VVA3ILor(err, "Connect to Portal")
   return False
  if (res.status_code == 301):
   title = "Redirection"
   newUrl = res.headers['location']
   res, err = self.VVSKJS(newUrl, res.cookies)
   if err:
    self.VVA3ILor(err, "URL Redirection")
    return False
   else:
    host = self.VV9eN6(newUrl)
    if not host:
     self.VVA3ILor("Incorrect Redirection-URL Format !\n\n%s" % newUrl)
     return False
    self.VVr7B5 = host
  token, profile = self.VVVmSL()
  if not token:
   return False
  return True
 def VV9eN6(self, url):
  ndx = url.lower().find("mac=")
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  if url.lower().endswith("/stalker_portal"): url = url[:-15]
  return url
 def VVa1oU(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVVmSL(self, VVA3IL=True):
  try:
   token = self.VVJtbr()
   if token:
    self.VV4Dg1 = token
   else:
    if VVA3IL:
     self.VVA3ILor("Could not get Token from server !")
    return "", ""
   return token, self.VVXQq2()
  except:
   return "", ""
 def VVJtbr(self):
  token  = ""
  res, err = self.VVSKJS(self.VV1htn())
  if not err:
   try:
    tDict = jLoads(res.text)
    token = CCfvbT.VV1IeQ(tDict["js"], "token")
   except:
    pass
  return token.strip()
 def VVXQq2(self):
  res, err = self.VVSKJS(self.VVwK37())
  if not err:
   try:
    profJson = jLoads(res.text)
    return profJson
   except:
    pass
  return ""
 def VV390P(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVXnmo()
  if len(rows) < 10:
   rows = self.VV3kcA()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVr7B5 ))
   rows.append(("MAC (from URL)" , self.VVbEdr ))
   rows.append(("Token"   , self.VV4Dg1 ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VVbEdr ))
   rows.append(("2", self.colored_server, "Host" , self.VVr7B5 ))
   rows.append(("2", self.colored_server, "Token" , self.VV4Dg1 ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVuFp2(self, isPhp=True):
  token, profile = self.VVVmSL()
  if not token:
   return ""
  m3u_Url = ""
  url = self.VVY1h0()
  res, err = self.VVSKJS(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCfvbT.VV1IeQ(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFA0q6(span.group(2))
     pass1 = FFA0q6(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url
 def VVXnmo(self):
  m3u_Url = self.VVuFp2()
  rows = []
  if m3u_Url:
   res, err = self.VVSKJS(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFXzY3(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFXzY3(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VV3kcA(self):
  token, profile = self.VVVmSL()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFIaxV(val): val = FFF9cg(val.decode("UTF-8"))
     else     : val = self.VVbEdr
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFXzY3(int(parts[1]))
      if parts[2] : ends = FFXzY3(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFXzY3(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVhBqE(self, mode, chCm, epNum, epId):
  crLinkUrl = self.VVybHU(mode, chCm, epNum, epId)
  token, profile = self.VVVmSL(VVA3IL=False)
  if not token:
   return ""
  res, err = self.VVSKJS(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCfvbT.VV1IeQ(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  return chUrl
 def VVEYFK(self):
  return self.VVr7B5 + "/server/load.php?"
 def VV1htn(self):
  return self.VVEYFK() + "type=stb&action=handshake&token=&mac=%s" % self.VVbEdr
 def VVwK37(self):
  return self.VVEYFK() + "type=stb&action=get_profile"
 def VVwRKi(self, mode):
  url = self.VVEYFK() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVmzxh(self, catID):
  return self.VVEYFK() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVPS6U(self, mode, catID, page):
  url = self.VVEYFK() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "series" : url += "category=%s" % catID
  else    : url += "genre=%s&force_ch_link_check=" % catID
  return url
 def VVCuRp(self, mode, searchName, page):
  return self.VVEYFK() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VVFJJX(self, mode, catID):
  return self.VVEYFK() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVybHU(self, mode, chCm, serCode, serId):
  url = self.VVEYFK() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVY1h0(self):
  return self.VVEYFK() + "type=itv&action=create_link"
 def VV3Vb5(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVEYmj(catID, stID, chNum)
  query = self.VVZKRf(mode, FFa9gW(host), FFa9gW(mac), serCode, serId, chCm)
  chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVZKRf(self, mode, host, mac, serCode, serId, chCm):
  query = "mode=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVnTCL(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVZKRf(mode, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFF9cg(host)
  mac   = FFF9cg(mac)
  valid = False
  if self.VV9eN6(playHost) and self.VV9eN6(host) and self.VV9eN6(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVSKJS(self, url, useCookies=True):
  err = ""
  try:
   import requests
   cookies = { "mac" : self.VVbEdr, "stb_lang" : "en" }
   headers = { 'User-Agent':  'Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3', }
   if self.VV4Dg1:
    headers["Authorization"] = "Bearer %s" % self.VV4Dg1
   if useCookies : res = requests.get(url, headers=headers, allow_redirects=False, timeout=2, cookies=cookies)
   else   : res = requests.get(url, headers=headers, allow_redirects=False, timeout=2)
   res.raise_for_status()
   return res, ""
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.exceptions.HTTPError as e  : err = "HTTP Error"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[120]
  return "", err + "\n\n" + url
 @staticmethod
 def VVR89v(host, mac, tType, action, keysList=[]):
  myPortal = CCuZpw()
  ok = myPortal.VVMgiU(host, mac)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile = myPortal.VVVmSL()
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s/server/load.php?type=%s&action=%s" % (host, tType, action)
  res, err = myPortal.VVSKJS(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVEO2K(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVEO2K(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVA3ILor(self, err, title="Portal Browser"):
  FFGIBw(self, str(err), title=title)
 def VVkTIB(self, mode):
  if   mode in ("itv"  , CCfvbT.VVQrdO , CCfvbT.VVtQFB)  : return "Live"
  elif mode in ("vod"  , CCfvbT.VV4v5x , CCfvbT.VVnIak)  : return "VOD"
  elif mode in ("series" , CCfvbT.VVisQM , CCfvbT.VVdB9d) : return "Series"
  else                          : return "IPTV"
 def VVlvxV(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVkTIB(mode), searchName)
 def VVlFyt(self, catchup=False):
  VVY2K2 = []
  VVY2K2.append(("Live"    , "live"  ))
  VVY2K2.append(("VOD"    , "vod"   ))
  VVY2K2.append(("Series"   , "series"  ))
  if catchup:
   VVY2K2.append(VV8PP6)
   VVY2K2.append(("Catchup TV" , "catchup"  ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Account Info." , "accountInfo" ))
  return VVY2K2
 @staticmethod
 def VVzCYS(decodedUrl):
  m3u_Url = ""
  p = CCuZpw()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVnTCL(decodedUrl)
  if valid:
   ok = p.VVMgiU(host, mac, VVA3IL=False)
   if ok:
    m3u_Url = p.VVuFp2(isPhp=False)
    span = iSearch(r".+ch\/(.+)_", decodedUrl, IGNORECASE)
    if span:
     m3u_Url += span.group(1)
  return m3u_Url
class CCUbe9(CCuZpw):
 def __init__(self):
  CCuZpw.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVyaMN(self, refCode, chName, decodedUrl, iptvRef):
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVnTCL(decodedUrl)
  if valid:
   if self.VVMgiU(host, mac, VVA3IL=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVC3JO(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVhBqE(self.mode, self.chCm, self.epNum, self.epId)
  except:
   pass
  if not chUrl:
   return
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = self.refCode + chUrl.strip() + ":" + self.chName
  newIptvRef = ""
  ndx = chUrl.find("play_token=")
  if ndx > -1:
   ndx = chUrl.find(":", ndx)
   if ndx > -1:
    left  = chUrl[:ndx]
    right  = chUrl[ndx:]
    newIptvRef = left + "&" + self.query + right
  if newIptvRef:
   success = self.VVECy4(self.iptvRef, newIptvRef)
   if passedSELF:
    FFBoZM(passedSELF, newIptvRef, VVBdIn=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFBoZM(self, newIptvRef, VVBdIn=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VVECy4(self, oldCode, newCode):
  bPath = FF4aaj()
  if bPath:
   txt = FFJ07K(bPath)
   if oldCode in txt:
    txt = txt.replace(oldCode, newCode)
    with open(bPath, "w") as f:
     f.write(txt)
    FFCe2y()
    return True
  return False
class CC4LTw(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFdxjB(VV8Sie, 10, 10, 50, 30, 20, "#22002020", "#22001122", 30)
  self.session = session
  FFSskZ(self, "")
  self.close()
class CCv82q(CCUbe9):
 def __init__(self, passedSession):
  CCUbe9.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.timer1   = eTimer()
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={ iPlayableService.evEnd: self.VVSZvs})
  except:
   pass
 def VVSZvs(self):
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVEm0s)
  except:
   self.timer1.callback.append(self.VVEm0s)
  self.timer1.start(100, True)
 def VVEm0s(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFlPZP(self.passedSession, isFromSession=True)
  valid = False
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if not ref == self.lastRef:
     valid = self.VVyaMN(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if not CCpspP.PLAYER_INSTANCE:
       self.VVC3JO(self.passedSession, isFromSession=True)
class CCkPk2():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.adultWords  = ("adult", "sex", "porn", "xxx", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.nameTagPatt = r"(?:\s*[(|:]\s*)?[A-Z]{2}\s*.?\s*[)|:]\s*(?:.+[|:]\s*)*(.+)"
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
 def VV5E8s(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCfvbT.VVK6ry(name):
   return CCfvbT.VVBnrt(name)
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name, IGNORECASE)
   if span:
    name = span.group(1)
  return name.strip() or name
 def VVneR5(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  span = iSearch(self.nameTagPatt, name, IGNORECASE)
  if span:
   name = span.group(1)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VV4ZfA(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  else:
   return name.strip()
 def VVJMgS(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVNX6e(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCWhMT(CCuZpw):
 def __init__(self):
  CCuZpw.__init__(self)
 def VV5FxZ(self):
  try:
   import requests
   FFjQre(self, self.VVGShu, title="Searching ...")
  except:
   FFhMkA(self, self.VVcOnR, '"Requests Library" is required to read Portal.\n\nInstall the library ?')
 def VVRLMh(self, winSession, url, mac):
  if self.VVMgiU(url, mac):
   FFjQre(winSession, self.VV9v2d, title="Checking Server ...")
  else:
   FFGIBw(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVcOnR(self):
  from sys import version_info
  cmdUpd = FFBzKc(VVSxeo, "")
  if cmdUpd:
   cmdInst = FF6Z6k(VVXJyy, "python-requests")
   if version_info[0] >= 3:
    cmdInst = cmdInst.replace("python-", "python3-")
   cmd = cmdUpd + " && " + cmdInst
   FFRQmD(self, cmd, checkNetAccess=True, title="Installing Requests Library")
  else:
   FFvteW(self)
 def VVGShu(self):
  path = CCfvbT.VVkhu0()
  lines = FFVHBJ('find %s %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % (path, FFXsco(1)))
  if lines:
   lines.sort()
   VVY2K2 = []
   for line in lines:
    VVY2K2.append((line, line))
   OKBtnFnc = self.VVi2Bs
   VVHN3c = ("Delete File", boundFunction(self.VV705l, boundFunction(FFjQre, self, self.VVGShu, title="Searching ...")))
   FFlTf2(self, None, title="Select Portals File", VVY2K2=VVY2K2, width=1200, OKBtnFnc=OKBtnFnc, VVHN3c=VVHN3c)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFGIBw(self, 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt)
 def VV705l(self, cbFnc, VVmQZXObj, path):
  FFhMkA(self, boundFunction(self.VVVPmc, cbFnc, VVmQZXObj, path), "Delete this file ?\n\n%s" % path)
 def VVVPmc(self, cbFnc, VVmQZXObj, path):
  os.system(FFdgmD("rm -f '%s'" % path))
  VVmQZXObj.cancel()
  cbFnc()
 def VVi2Bs(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   self.session.open(CCvPFp, barTheme=CCvPFp.VVR24C
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VVrfcE, path)
       , VVzqy9 = boundFunction(self.VVvdou, menuInstance, path))
 def VVrfcE(self, path, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with open(path, "r") as f:
   for line in f:
    totLines += 1
  progBarObj.VVzcj3(totLines)
  progBarObj.VV5404 = []
  lineNum = 0
  with open(path, "r") as f:
   for line in f:
    lineNum += 1
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVoDTW(1, True)
    line = line.strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip() or "-"
     host = self.VV9eN6(url)
     mac  = self.VVa1oU(mac)
     if host and mac and progBarObj:
      progBarObj.VV5404.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip() or "-"
      host = self.VV9eN6(url)
      mac  = self.VVa1oU(mac)
      if host and mac and not mac.startswith("AC") and progBarObj:
       progBarObj.VV5404.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVvdou(self, menuInstance, path, VVUvIC, VV5404, threadCounter, threadTotal, threadErr):
  title = "Portals List File"
  if VV5404:
   VVPAO4  = ("Home Menu", FFQSOu, [])
   VVMZtN  = None #("Check & Filter" , boundFunction(self.filterPortalAuthorizedServers, path), [])
   VVBoAr = ("Edit File" , boundFunction(self.VVQSaD, path) , [])
   VV4tKk = ("Open as M3U", self.VVxWXV     , [])
   VVuedc  = ("Select"  , self.VVRLMh_fromMacFiles   , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVD84s  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VV3o52 = FFp1uk(self, None, title=title, header=header, VVSmWK=VV5404, VVD84s=VVD84s, VVO0tX=widths, VV715D=26, VVuedc=VVuedc, VVPAO4=VVPAO4, VV4tKk=VV4tKk, VVBoAr=VVBoAr, VVMZtN=VVMZtN, VVdawd="#0a001122", VV2xlz="#0a001122", VVSwM6="#0a001122", VVb1yt="#00004455", VVBWV3="#0a333333", VVYh87="#11331100", VVzUt6=True, searchCol=1)
   if not VVUvIC:
    FF3ty7(VV3o52, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVUvIC:
    FFGIBw(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVxWXV(self, VV3o52, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  FFjQre(VV3o52, boundFunction(self.VVnboV, VV3o52, host, mac), title="Checking Server ...")
 def VVnboV(self, VV3o52, host, mac):
  p = CCuZpw()
  m3u_Url = ""
  ok = p.VVMgiU(host, mac, VVA3IL=False)
  if ok:
   m3u_Url = p.VVuFp2()
  title = "Browsing M3U Server from Portal Data"
  if m3u_Url:
   self.VViuO2(title, m3u_Url)
  else:
   FFGIBw(self, "No response from Server !", title=title)
 def VVRLMh_fromMacFiles(self, VV3o52, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVRLMh(VV3o52, url, mac)
 def VVQSaD(self, path, VV3o52, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCs3j1(self, path, VVzqy9=boundFunction(self.VVro6J, VV3o52), curRowNum=rowNum)
  else    : FFQ3EB(self, path)
 def VVMa95(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFF9cg(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VV9v2d(self):
  if self.VVpB00():
   VVY2K2  = self.VVlFyt()
   OKBtnFnc = self.VVbJI1
   VVMVMB = ("Home Menu", FFQSOu)
   FFlTf2(self, None, title="Portal Resources (MAC=%s)" % self.VVbEdr, VVY2K2=VVY2K2, OKBtnFnc=OKBtnFnc, VVMVMB=VVMVMB)
 def VVbJI1(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFjQre(menuInstance, boundFunction(self.VVzmwo, mode), title="Reading Categories ...")
   else : FFjQre(menuInstance, boundFunction(self.VVQAHe, menuInstance, title), title="Reading Account ...")
 def VVQAHe(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VV390P(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVbEdr)
  VVPAO4  = ("Home Menu" , FFQSOu, [])
  if totCols == 2:
   VVMZtN = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
   VVMZtN = ("More Info.", boundFunction(self.VVpVGd, menuInstance) , [])
  FFp1uk(self, None, title=title, width=1200, header=header, VVSmWK=rows, VVO0tX=widths, VV715D=26, VVPAO4=VVPAO4, VVMZtN=VVMZtN, VVdawd="#0a00292B", VV2xlz="#0a002126", VVSwM6="#0a002126", VVb1yt="#00000000", searchCol=searchCol)
 def VVpVGd(self, menuInstance, VV3o52, title, txt, colList):
  VV3o52.cancel()
  FFjQre(menuInstance, boundFunction(self.VVQAHe, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVzmwo(self, mode):
  token, profile = self.VVVmSL()
  if not token:
   return
  res, err = self.VVSKJS(self.VVwRKi(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CCkPk2()
     chList = tDict["js"]
     for item in chList:
      Id   = CCfvbT.VV1IeQ(item, "id"       )
      Title  = CCfvbT.VV1IeQ(item, "title"      )
      censored = CCfvbT.VV1IeQ(item, "censored"     )
      Title = processChanName.VV4ZfA(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVcBAa:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVkTIB(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVdawd, VV2xlz, VVSwM6, VVb1yt = self.VVu5ZW(mode)
   mName = self.VVkTIB(mode)
   VVuedc   = ("Show List"   , boundFunction(self.VV0gl8, mode) , [])
   VVPAO4  = ("Home Menu"   , FFQSOu         , [])
   if mode in ("vod", "series"):
    VVBoAr = ("Find in %s" % mName , boundFunction(self.VVOlEE, mode), [])
   else:
    VVBoAr = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FFp1uk(self, None, title=title, width=1200, header=header, VVSmWK=list, VVO0tX=widths, VV715D=30, VVPAO4=VVPAO4, VVBoAr=VVBoAr, VVuedc=VVuedc, VVdawd=VVdawd, VV2xlz=VV2xlz, VVSwM6=VVSwM6, VVb1yt=VVb1yt)
  else:
   FFGIBw(self, "Could not get Categories from server!", title=title)
 def VVVXa5(self, mode, VV3o52, title, txt, colList):
  FFjQre(VV3o52, boundFunction(self.VV2BnJ, mode, VV3o52, title, txt, colList), title="Downloading ...")
 def VV2BnJ(self, mode, VV3o52, title, txt, colList):
  token, profile = self.VVVmSL()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVSKJS(self.VVmzxh(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCfvbT.VV1IeQ(item, "id"    )
      actors   = CCfvbT.VV1IeQ(item, "actors"   )
      added   = CCfvbT.VV1IeQ(item, "added"   )
      age    = CCfvbT.VV1IeQ(item, "age"   )
      category_id  = CCfvbT.VV1IeQ(item, "category_id" )
      description  = CCfvbT.VV1IeQ(item, "description" )
      director  = CCfvbT.VV1IeQ(item, "director"  )
      genres_str  = CCfvbT.VV1IeQ(item, "genres_str"  )
      name   = CCfvbT.VV1IeQ(item, "name"   )
      path   = CCfvbT.VV1IeQ(item, "path"   )
      screenshot_uri = CCfvbT.VV1IeQ(item, "screenshot_uri" )
      series   = CCfvbT.VV1IeQ(item, "series"   )
      cmd    = CCfvbT.VV1IeQ(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VVuedc  = ("Play"  , boundFunction(self.VV9D53, mode, False)      , [])
   VVGP73 = (""   , boundFunction(self.VV4X5y, mode)      , [])
   VVPAO4 = ("Home Menu" , FFQSOu                , [])
   VV4tKk = ("Download PIcons" , boundFunction(self.VV0cxW, mode)      , [])
   VVBoAr = ("Add ALL to Bouquet" , boundFunction(self.VVnPB4, mode, seriesName) , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVD84s  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFp1uk(self, None, title=seriesName, width=1200, header=header, VVSmWK=list, VVD84s=VVD84s, VVO0tX=widths, VV715D=26, VVPAO4=VVPAO4, VV4tKk=VV4tKk, VVBoAr=VVBoAr, VVuedc=VVuedc, VVGP73=VVGP73, VVdawd="#0a00292B", VV2xlz="#0a002126", VVSwM6="#0a002126", VVb1yt="#00000000")
  else:
   FFGIBw(self, "Could not get Episodes from server!", title=seriesName)
 def VVOlEE(self, mode, VV3o52, title, txt, colList):
  VVY2K2 = []
  VVY2K2.append(("Keyboard"  , "manualEntry"))
  VVY2K2.append(("From Filter" , "fromFilter"))
  FFlTf2(self, boundFunction(self.VVeTOR, VV3o52, mode), title="Input Type", VVY2K2=VVY2K2, width=400)
 def VVeTOR(self, VV3o52, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFwT6k(self, boundFunction(self.VVapDs, VV3o52, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCD6d0(self)
    filterObj.VVeTEi(boundFunction(self.VVapDs, VV3o52, mode))
 def VVapDs(self, VV3o52, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VVlvxV(mode, searchName)
   if len(searchName) < 3:
    FFGIBw(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CCkPk2()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVJMgS([searchName]):
     FFGIBw(self, processChanName.VVNX6e(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VV9cnR(mode, searchName, "", searchName)
 def VV0gl8(self, mode, VV3o52, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VV9cnR(mode, bName, catID, "")
 def VV9cnR(self, mode, bName, catID, searchName):
  self.session.open(CCvPFp, barTheme=CCvPFp.VVSLuW
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVGbI8, mode, bName, catID, searchName)
      , VVzqy9 = boundFunction(self.VVzaSt, mode, bName, catID, searchName))
 def VVzaSt(self, mode, bName, catID, searchName, VVUvIC, VV5404, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVlvxV(mode, searchName)
  else   : title = "%s : %s" % (self.VVkTIB(mode), bName)
  if VV5404:
   if mode == "series":
    VVdawd, VV2xlz, VVSwM6, VVb1yt = self.VVu5ZW("series2")
    VVuedc  = ("Episodes", boundFunction(self.VVVXa5, mode) , [])
    VV4tKk = None
    VVBoAr = None
   else:
    VVdawd, VV2xlz, VVSwM6, VVb1yt = self.VVu5ZW("")
    VVuedc  = ("Play"    , boundFunction(self.VV9D53, mode, False)   , [])
    VV4tKk = ("Download PIcons" , boundFunction(self.VV0cxW, mode)     , [])
    VVBoAr = ("Add ALL to Bouquet" , boundFunction(self.VVnPB4, mode, bName) , [])
   VVGP73 = (""      , boundFunction(self.VVkLuo, mode)    , [])
   VVPAO4 = ("Home Menu"    , FFQSOu             , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVD84s  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , CENTER)
   VV3o52 = FFp1uk(self, None, title=title, header=header, VVSmWK=VV5404, VVD84s=VVD84s, VVO0tX=widths, VV715D=26, VVPAO4=VVPAO4, VV4tKk=VV4tKk, VVBoAr=VVBoAr, VVuedc=VVuedc, VVGP73=VVGP73, VVdawd=VVdawd, VV2xlz=VV2xlz, VVSwM6=VVSwM6, VVb1yt=VVb1yt, VVzUt6=True, searchCol=1)
   if not VVUvIC:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VV3o52.VVzMY4(VV3o52.VV8QuM() + tot)
    if threadErr: FF3ty7(VV3o52, "Error while reading !", 2000)
    else  : FF3ty7(VV3o52, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFGIBw(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFGIBw(self, "Could not get list from server !", title=title)
 def VVkLuo(self, mode, VV3o52, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFzRsg(self, fncMode=CCf574.VVwj6q, portalHost=self.VVr7B5, portalMac=self.VVbEdr, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVuz0n(mode, VV3o52, title, txt, colList)
 def VV4X5y(self, mode, VV3o52, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFARnG(colList[10], VVPTHk)
  txt += "Description:\n%s" % FFARnG(colList[11], VVPTHk)
  self.VVuz0n(mode, VV3o52, title, txt, colList)
 def VVuz0n(self, mode, VV3o52, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV0clR(mode, colList)
  refCode, chUrl = self.VV3Vb5(self.VVr7B5, self.VVbEdr, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFzRsg(self, fncMode=CCf574.VVTN1O, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVGbI8(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile = self.VVVmSL()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VV5404, total_items, max_page_items, err = self.VVmaUz(mode, catID, 1, 1, searchName)
   if progBarObj.isCancelled:
    return
   if progBarObj.VV5404 and total_items > -1 and max_page_items > -1:
    progBarObj.VVzcj3(total_items)
    progBarObj.VVoDTW(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVmaUz(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VVOD8l()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VV5404 += list
      progBarObj.VVoDTW(len(list), True)
  except:
   pass
 def VVmaUz(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVCuRp(mode, searchName, page)
  else   : url = self.VVPS6U(mode, catID, page)
  res, err = self.VVSKJS(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVTxtU(CCfvbT.VV1IeQ(item, "total_items" ))
     max_page_items = self.VVTxtU(CCfvbT.VV1IeQ(item, "max_page_items" ))
     processChanName = CCkPk2()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCfvbT.VV1IeQ(item, "id"    )
      name   = CCfvbT.VV1IeQ(item, "name"   )
      tv_genre_id  = CCfvbT.VV1IeQ(item, "tv_genre_id" )
      number   = CCfvbT.VV1IeQ(item, "number"   ) or str(counter)
      logo   = CCfvbT.VV1IeQ(item, "logo"   )
      screenshot_uri = CCfvbT.VV1IeQ(item, "screenshot_uri" )
      cmd    = CCfvbT.VV1IeQ(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      if mode == "itv" and not cmdStr in cmd:
       span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
      picon   = logo or screenshot_uri
      counter += 1
      name = processChanName.VV5E8s(name)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVnPB4(self, mode, bName, VV3o52, title, txt, colList):
  FFjQre(VV3o52, boundFunction(self.VVcYhy, mode, bName, VV3o52, title, txt, colList), title="Adding Channels ...")
 def VVcYhy(self, mode, bName, VV3o52, title, txt, colList):
  bNameFile = CCfvbT.VVlP8P(bName)
  num  = 0
  path = VVVAau + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVVAau + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VV3o52.VVevLM():
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV0clR(mode, row)
    refCode, chUrl = self.VV3Vb5(self.VVr7B5, self.VVbEdr, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
    totChange += 1
  FF77qu(os.path.basename(path))
  self.VVfiaX(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVTxtU(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VV9D53(self, mode, fromPlayer, VV3o52, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV0clR(mode, colList)
  refCode, chUrl = self.VV3Vb5(self.VVr7B5, self.VVbEdr, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if fromPlayer:
   self.VVUmsE(mode, VV3o52, chUrl)
  elif self.VVK6ry(chName):
   FF3ty7(VV3o52, "This is a marker!", 300)
  else:
   FFjQre(VV3o52, boundFunction(self.VVUmsE, mode, VV3o52, chUrl), title="Playing ...")
 def VVUmsE(self, mode, VV3o52, chUrl):
  FFBoZM(self, chUrl, VVBdIn=False)
  self.session.open(CCpspP, portalTableParam=(self, VV3o52, mode))
 def VV0clR(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName, catID, stID, chNum, chCm, serCode, serId, picUrl
class CCfvbT(Screen, CCWhMT):
 VVlOxC = 0
 VVTYnb = 1
 VV8kG0 = 2
 VVcZhu = 3
 VV29HS  = 4
 VVWzS0  = 5
 VVcgYs  = 6
 VVcQ6b  = 7
 VVjREZ   = 8
 VVyXWB  = 9
 VVzCYW  = 10
 VVExqE  = 11
 VVLYXl  = 12
 VVaCoU   = 13
 VVuX1V   = 14
 VVm8UL   = 15
 VVzXb4   = 16
 VVP01c   = 17
 VVNm5p    = 0
 VVQrdO   = 1
 VV4v5x   = 2
 VVisQM   = 3
 VV3Uhm  = 4
 VVS4SR  = 5
 VVtQFB   = 6
 VVnIak   = 7
 VVdB9d  = 8
 VVZWI6  = 9
 VVbM5y  = 10
 def __init__(self, session):
  self.skin, self.skinParam = FFdxjB(VVwo8o, 1000, 1050, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.VV3o52  = None
  self.tableTitle   = "IPTV Channels List"
  self.VVajIbData  = {}
  self.lastFindIptvName = ""
  CCWhMT.__init__(self)
  VVY2K2= self.VVmx2s()
  FFSskZ(self, title="IPTV", VVY2K2=VVY2K2)
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  FFUwX1(self["myMenu"])
  FF2Dma(self)
  FFn48g(self)
 def VVmx2s(self):
  files = self.VVA64c()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"    , "VVajIb_fromPlayList" ))
  tList.append(("IPTV Server Browser (from Portal File)"    , "VVajIb_fromMac"  ))
  tList.append(("IPTV Server Browser (from M3U File)"     , "VVajIb_fromM3u"  ))
  qUrl, iptvRef = self.VVDNKV()
  if qUrl:
   tList.append(("IPTV Server Browser (from Current Channel)"  , "VVajIb_fromCurrChan" ))
  VVY2K2 = []
  if files:
   if self.VV3o52:
    VVY2K2.append(("Add Current List to a New Bouquet"      , "VVberQ"  ))
    VVY2K2.append(VV8PP6)
    VVY2K2.append(("Change Current List References to Unique Codes"   , "VVdZaF"))
    VVY2K2.append(("Change Current List References to Identical Codes"  , "VV7Gjm_rows" ))
    VVY2K2.append(VV8PP6)
    VVY2K2.append(("Share Reference with Satellite/C/T Service (manual entry)", "VV8A7O"   ))
    VVY2K2.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VVTz4W"   ))
   else:
    VVY2K2 += tList
    VVY2K2.append(VV8PP6)
    VVY2K2.append(("Local IPTV Channels"          , "iptvTable_all"   ))
    if qUrl:
     VVY2K2.append(VV8PP6)
     VVY2K2.append(("Update Current Bouquet EPG (from IPTV Server)"  , "refreshIptvEPG"   ))
    VVY2K2.append(VV8PP6)
    VVY2K2.append(("Count Available IPTV Channels"       , "VVUFCz"    ))
    VVY2K2.append(("Check Reference Codes Format"        , "VVb3xR"   ))
    VVY2K2.append(("Check System Acceptable Reference Types"     , "VVh2go"   ))
    VVY2K2.append(VV8PP6)
    VVY2K2.append(("Share Reference with Sat./C/T (Only Matching Names)"  , "VViESK" ))
    VVY2K2.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVwugY"  ))
    VVY2K2.append(("Change ALL References to Unique Codes"     , "VVaLbL" ))
    VVY2K2.append(("Change ALL References to Identical Codes"     , "VV7Gjm_all" ))
  if not self.VV3o52:
   if not files:
    VVY2K2 += tList
   VVY2K2.append(VV8PP6)
   VVY2K2.append(("M3U Files Tools ..."           , "VVzcv1"   ))
   VVY2K2.append(VV8PP6)
   VVY2K2.append(("Reload Channels and Bouquets"         , "VVayXs"   ))
  return VVY2K2
 def VVMrkr(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   if   item == "VVberQ"   : FFwT6k(self, self.VVberQ, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVdZaF" : FFhMkA(self, boundFunction(FFjQre, self.VV3o52, self.VVdZaF ), "Change Current List References to Unique Codes ?")
   elif item == "VV7Gjm_rows" : FFhMkA(self, boundFunction(FFjQre, self.VV3o52, self.VV7Gjm   ), "Change Current List References to Identical Codes ?")
   elif item == "VV8A7O"   : self.VV8A7O(tTitle)
   elif item == "VVTz4W"   : self.VVTz4W(tTitle)
   elif item == "VVajIb_fromPlayList" : FFjQre(self, boundFunction(self.VV9iWu, True), title="Searching ...")
   elif item == "VVajIb_fromM3u"  : FFjQre(self, boundFunction(self.VVlXpM, 0), title="Searching ...")
   elif item == "VVajIb_fromMac"  : self.VV5FxZ()
   elif item == "VVajIb_fromCurrChan" : self.VVRLMh_fromCurrChan()
   elif item == "iptvTable_live"   : FFjQre(self, boundFunction(self.VV9wQw, self.VVcQ6b ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFjQre(self, boundFunction(self.VV9wQw, self.VVlOxC) , title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VVGdgW()
   elif item == "VVUFCz"    : FFjQre(self, self.VVUFCz)
   elif item == "VVb3xR"    : FFjQre(self, self.VVb3xR)
   elif item == "VVh2go"   : FFjQre(self, self.VVh2go)
   elif item == "VViESK"  : FFhMkA(self, boundFunction(FFjQre, self, self.VViESK ), "Continue ?")
   elif item == "VVwugY"  : self.VVwugY()
   elif item == "VVaLbL" : FFhMkA(self, boundFunction(FFjQre, self, self.VVaLbL ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VV7Gjm_all" : FFhMkA(self, boundFunction(FFjQre, self, self.VV7Gjm  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "VVzcv1"   : self.VVzcv1()
   elif item == "VVayXs"   : FFjQre(self, boundFunction(CCJkx4.VVayXs, self))
 def VVzcv1(self):
  VVY2K2 = []
  VVY2K2.append(("Analyse m3u File"            , "VVkX5n"   ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Convert m3u File to Bouquet (from File Manager)"    , "VVeOcA" ))
  VVY2K2.append(("Convert m3u File to Bouquet (from m3u File List)"    , "VVg75t" ))
  VVY2K2.append(('Convert m3u File to Bouquet (Download from "Play Lists")'  , "VVB103" ))
  FFlTf2(self, self.VVnAK4, title="M3U Files Tools", VVY2K2=VVY2K2)
 def VVnAK4(self, item):
  if item is not None:
   t = "Searching ..."
   if   item == "VVkX5n"   : FFjQre(self, boundFunction(self.VVlXpM, 1), title="Searching ...")
   elif item == "VVeOcA" : self.VVeOcA()
   elif item == "VVg75t" : FFjQre(self, boundFunction(self.VVlXpM, 2), title=t)
   elif item == "VVB103" : FFjQre(self, boundFunction(self.VV9iWu, False), title=t)
 def VVtv5z(self):
  global VVXLue
  VVXLue = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVMrkr(item)
 def VV9wQw(self, mode):
  VVx2Uc = self.VVman4(mode)
  if VVx2Uc:
   VV4tKk = ("Current Service", self.VVARl3    , [])
   VVBoAr = ("Options"  , self.VVXCLQ      , [])
   VVMZtN = ("Filter"   , self.VVByUh       , [])
   VVuedc  = ("Play"   , boundFunction(self.VVObyA, False) , [])
   VVGP73 = (""    , self.VVMZGj       , [])
   VVqeE2 = (""    , self.VV0kle        , [])
   VVO3oT = (""    , self.VV3Fnf       , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVD84s  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFp1uk(self, None, header=header, VVSmWK=VVx2Uc, VVD84s=VVD84s, VVO0tX=widths, VV715D=26
     , VVuedc=VVuedc, VV4tKk=VV4tKk, VVBoAr=VVBoAr, VVMZtN=VVMZtN, VVGP73=VVGP73, VVqeE2=VVqeE2
     , VVdawd="#0a00292B", VV2xlz="#0a002126", VVSwM6="#0a002126", VVb1yt="#00000000", VVzUt6=True, searchCol=1)
  else:
   if mode == self.VVcQ6b: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFGIBw(self, err)
 def VV0kle(self, VV3o52, title, txt, colList):
  self.VV3o52 = VV3o52
 def VV3Fnf(self, VV3o52):
  self.VV3o52 = None
 def VVXCLQ(self, VV3o52, title, txt, colList):
  VVY2K2= self.VVmx2s()
  FFlTf2(self, self.VVMrkr, title="IPTV Tools", VVY2K2=VVY2K2)
 def VVByUh(self, VV3o52, title, txt, colList):
  VVY2K2 = []
  VVY2K2.append(("All"         , "all"   ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Prefix of Selected Channel"   , "sameName" ))
  VVY2K2.append(("Suggest Words from Selected Channel" , "partName" ))
  VVY2K2.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Live TV"        , "live"  ))
  VVY2K2.append(("VOD"         , "vod"   ))
  VVY2K2.append(("Series"        , "series"  ))
  VVY2K2.append(("Uncategorised"      , "uncat"  ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Video"        , "video"  ))
  VVY2K2.append(("Audio"        , "audio"  ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("MKV"         , "MKV"   ))
  VVY2K2.append(("MP4"         , "MP4"   ))
  VVY2K2.append(("MP3"         , "MP3"   ))
  VVY2K2.append(("AVI"         , "AVI"   ))
  VVY2K2.append(("FLV"         , "FLV"   ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVli0O()
  if bNames:
   bNames.sort()
   VVY2K2.append(VV8PP6)
   for item in bNames:
    VVY2K2.append((item, "__b__" + item))
  filterObj = CCD6d0(self)
  filterObj.VVPpX8(VVY2K2, VVY2K2, boundFunction(self.VVq6LW, VV3o52))
 def VVq6LW(self, VV3o52, item=None):
  prefix = VV3o52.VViajA(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVlOxC, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVTYnb , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VV8kG0 , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVcZhu , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVcQ6b  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVjREZ   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVyXWB  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVzCYW  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVExqE  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVLYXl  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVaCoU   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVuX1V   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVm8UL   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVzXb4   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVP01c   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVcgYs  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VV29HS  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVWzS0  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VV8kG0:
   VVY2K2 = []
   chName = VV3o52.VViajA(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVY2K2.append((item, item))
    if not VVY2K2 and chName:
     VVY2K2.append((chName, chName))
    FFlTf2(self, boundFunction(self.VVA9zk_partOfName, title), title="Words from Current Selection", VVY2K2=VVY2K2)
   else:
    VV3o52.VVSUkD("Invalid Channel Name")
  else:
   words, asPrefix = CCD6d0.VVGIe9(words)
   if not words and mode in (self.VV29HS, self.VVWzS0):
    FF3ty7(self.VV3o52, "Incorrect filter", 2000)
   else:
    FFjQre(self.VV3o52, boundFunction(self.VVIFdp, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVA9zk_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFjQre(self.VV3o52, boundFunction(self.VVIFdp, self.VV8kG0, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVBnrt(txt):
  return "#f#11ffff00#" + txt
 def VVIFdp(self, mode, words, asPrefix, title):
  VVx2Uc = self.VVman4(mode=mode, words=words, asPrefix=asPrefix)
  if VVx2Uc : self.VV3o52.VVnh9K(VVx2Uc, title)
  else  : self.VV3o52.VVSUkD("Not found")
 def VVman4(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VVx2Uc = []
  files  = self.VVA64c()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFJ07K(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVeZiw = span.group(1)
    else : VVeZiw = ""
    VVeZiw_lCase = VVeZiw.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVK6ry(chName): chNameMod = self.VVBnrt(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVeZiw, chType, refCode, url)
     ok = False
     tUrl = FFpzGx(url).lower()
     if mode == self.VVlOxC       : ok = True
     elif mode == self.VVcgYs       : ok = True
     elif mode == self.VVExqE:
      if CCfvbT.VV1Nl0(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVLYXl:
      if CCfvbT.VV1Nl0(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVcQ6b:
      if CCfvbT.VV1Nl0(tUrl, compareType="live")  : ok = True
     elif mode == self.VVjREZ:
      if CCfvbT.VV1Nl0(tUrl, compareType="movie") : ok = True
     elif mode == self.VVyXWB:
      if CCfvbT.VV1Nl0(tUrl, compareType="series") : ok = True
     elif mode == self.VVzCYW:
      if CCfvbT.VV1Nl0(tUrl, compareType="")   : ok = True
     elif mode == self.VVaCoU:
      if CCfvbT.VV1Nl0(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVuX1V:
      if CCfvbT.VV1Nl0(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVm8UL:
      if CCfvbT.VV1Nl0(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVzXb4:
      if CCfvbT.VV1Nl0(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVP01c:
      if CCfvbT.VV1Nl0(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVTYnb:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VV8kG0:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVcZhu:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VV29HS:
      if words[0] == VVeZiw_lCase:
       ok = True
     elif mode == self.VVWzS0:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VVx2Uc.append(row)
      chNum += 1
  if VVx2Uc and mode == self.VVcgYs:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VVx2Uc)
   for item in VVx2Uc:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VVx2Uc = newRows
  return VVx2Uc
 def VVberQ(self, bName):
  if bName:
   FFjQre(self.VV3o52, boundFunction(self.VVdCJj, bName), title="Adding Channels ...")
 def VVdCJj(self, bName):
  num = 0
  path = VVVAau + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVVAau + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VV3o52.VVevLM():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFt6bT(row[1]))
    totChange += 1
  FF77qu(os.path.basename(path))
  self.VVfiaX(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVwugY(self):
  txt = "Stream Type "
  VVY2K2 = []
  VVY2K2.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVY2K2.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVY2K2.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVY2K2.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVY2K2.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVY2K2.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFlTf2(self, self.VVId2m, title="Change Reference Types to:", VVY2K2=VVY2K2)
 def VVId2m(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVX7RL("1"   )
   elif item == "RT_4097" : self.VVX7RL("4097")
   elif item == "RT_5001" : self.VVX7RL("5001")
   elif item == "RT_5002" : self.VVX7RL("5002")
   elif item == "RT_8192" : self.VVX7RL("8192")
   elif item == "RT_8193" : self.VVX7RL("8193")
 def VVX7RL(self, rType):
  FFhMkA(self, boundFunction(FFjQre, self, boundFunction(self.VVLmFm, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVLmFm(self, refType):
  totChange = 0
  files  = self.VVA64c()
  if files:
   for path in files:
    txt = FFJ07K(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FF77qu(os.path.basename(path))
  self.VVfiaX(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVUFCz(self):
  totFiles = 0
  files  = self.VVA64c()
  if files:
   totFiles = len(files)
  totChans = 0
  VVx2Uc = self.VVman4()
  if VVx2Uc:
   totChans = len(VVx2Uc)
  FF0fhx(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVb3xR(self):
  files  = self.VVA64c()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFJ07K(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVFGoE
   else    : color = VVEAFU
   totInvalid = FFARnG(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFARnG("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FF0fhx(self, txt, title="Check IPTV References")
 def VVh2go(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVVAau + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FF77qu(os.path.basename(path))
  FFCe2y()
  acceptedList = []
  VVdyHg = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVdyHg:
   VVP8q8 = FFCCnL(VVdyHg)
   if VVP8q8:
    for service in VVP8q8:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVVAau + userBName
  bFile = VVVAau + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFdgmD("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFdgmD("rm -f '%s'" % path)
  os.system(cmd)
  FFCe2y()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVFGoE
    else     : res, color = "No" , VVEAFU
    txt += "    %s\t: %s\n" % (item, FFARnG(res, color))
   FF0fhx(self, txt, title=title)
  else:
   txt = FFGIBw(self, "Could not complete the test on your system!", title=title)
 def VViESK(self):
  lameDbChans = CCJkx4.VVbEdM(self, CCJkx4.VVtwfp)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVA64c():
    toSave = False
    txt = FFJ07K(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVfiaX(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFGIBw(self, 'No channels in "lamedb" !')
 def VVaLbL(self):
  files  = self.VVA64c()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFrxQp(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VV3w1o(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVfiaX(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVdZaF(self):
  iptvRefList = []
  files  = self.VVA64c()
  if files:
   for path in files:
    txt = FFJ07K(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VV3o52.VVcS0p(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VV3w1o(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVA64c()
  if files:
   for path in files:
    lines = FFrxQp(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVfiaX(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VV3w1o(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VV7Gjm(self):
  list = None
  if self.VV3o52:
   list = []
   for row in self.VV3o52.VVevLM():
    list.append(row[4] + row[5])
  files  = self.VVA64c()
  totChange = 0
  if files:
   for path in files:
    lines = FFrxQp(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVfiaX(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVfiaX(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFCe2y()
   if refreshTable and self.VV3o52:
    VVx2Uc = self.VVman4()
    if VVx2Uc and self.VV3o52:
     self.VV3o52.VVnh9K(VVx2Uc, self.tableTitle)
     self.VV3o52.VVSUkD(txt)
   FF0fhx(self, txt, title=title)
  else:
   FFrLx8(self, "No changes.")
 def VVli0O(self):
  files = self.VVA64c()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with open(path, "r") as f:
     span = iSearch(r"#NAME\s+(.*)", f.readline(), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VVRZvC = FF8UC9()
    if VVRZvC:
     for b in VVRZvC:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVA64c(self):
  return CCfvbT.VVhTUg(self)
 @staticmethod
 def VVhTUg(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVVAau + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFJ07K(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVMZGj(self, VV3o52, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFpzGx(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFzRsg(self, fncMode=CCf574.VVTnNa, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVObyA(self, fromPlayer, VV3o52, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  self.VViAFA(fromPlayer, VV3o52, chName, chUrl, "localIptv")
 def VVlNGW(self, mode, fromPlayer, VV3o52, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVC9ss(mode, colList)
  self.VViAFA(fromPlayer, VV3o52, chName, chUrl, mode)
 def VViAFA(self, fromPlayer, VV3o52, chName, chUrl, playerFlag):
  chName = FFt6bT(chName)
  if fromPlayer:
   self.VVaUAV(VV3o52, chUrl, playerFlag)
  elif self.VVK6ry(chName):
   FF3ty7(VV3o52, "This is a marker!", 300)
  else:
   FFjQre(VV3o52, boundFunction(self.VVaUAV, VV3o52, chUrl, playerFlag), title="Playing ...")
 def VVaUAV(self, VV3o52, chUrl, playerFlag):
  FFBoZM(self, chUrl, VVBdIn=False)
  self.session.open(CCpspP, portalTableParam=(self, VV3o52, playerFlag))
 @staticmethod
 def VVK6ry(chName):
  mark = ("--", "__", "==", "##", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVARl3(self, VV3o52, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFlPZP(self)
  if refCode:
   bName = FFnWjn()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFnNMM(refCode, origUrl, chName) }
   VV3o52.VV7yyv_partial(colDict, VVA3IL=True)
 def VVeOcA(self):
  self.session.open(CCQ4SG)
  self.close()
 def VVlXpM(self, m3uMode):
  path = CCfvbT.VVkhu0()
  lines = FFVHBJ("find %s %s -iname '*.m3u' | grep -i '.m3u'" % (path, FFXsco(1)))
  if lines:
   lines.sort()
   VVY2K2 = []
   for line in lines:
    VVY2K2.append((line, line))
   if   m3uMode == 0 : title = "Browse Server from M3U URLs"
   elif m3uMode == 1 : title = "Analyse M3U File"
   else    : title = "Convert M3U File to Bouquet"
   if m3uMode in [0, 2]: VVfEjQ = ("All to Playlist", self.VVP2lm)
   else    : VVfEjQ = None
   OKBtnFnc = boundFunction(self.VVA5zG, m3uMode, title)
   VVZPKj = ("Show Full Path", self.VVsYLy)
   VVHN3c = ("Delete File", boundFunction(self.VV705l, boundFunction(FFjQre, self, boundFunction(self.VVlXpM, m3uMode), title="Searching ...")))
   FFlTf2(self, None, title=title, VVY2K2=VVY2K2, OKBtnFnc=OKBtnFnc, VVZPKj=VVZPKj, VVHN3c=VVHN3c, VVfEjQ=VVfEjQ)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n\n%s" % path
   FFGIBw(self, 'No ".m3u" files found %s' % txt)
 def VVsYLy(self, VVmQZXObj, url):
  FF0fhx(self, url, title="Full Path")
 def VVA5zG(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if   m3uMode == 0 : FFjQre(menuInstance, boundFunction(self.VVfPHP, title, path))
   elif m3uMode == 1 : self.VVkX5n(title, path)
   else    : self.VVciDg(menuInstance, path)
 def VVP2lm(self, VVmQZXObj, item=None):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVmQZXObj.VVY2K2):
    path = item[1]
    if fileExists(path):
     with open(path, "r") as f:
      for line in f:
       url = self.VVH9P0(line)
       if url:
        if not url in pList : pList.append(url)
        else    : dupl += 1
        break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCfvbT.VVkhu0()
    if path == "/":
     path = CFG.exportedTablesPath.getValue()
    pListF = "%sPlaylist_%s.txt" % (FF0hsM(path), FFgfmJ())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVmQZXObj.VVY2K2)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FF0fhx(self, txt, title=title)
   else:
    FFGIBw(self, "Could not obtain URLs from this file list !", title=title)
 def VVkX5n(self, title, path):
  if fileExists(path):
   self.session.open(CCvPFp, barTheme=CCvPFp.VVR24C
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VVBiWl, path)
       , VVzqy9 = boundFunction(self.VVj1hp, title, path))
  else:
   FFGIBw(SELF, "Cannot open file :\n\n%s" % path, title=title)
 def VVj1hp(self, title, path, VVUvIC, VV5404, threadCounter, threadTotal, threadErr):
  if VVUvIC:
   FF0fhx(self, VV5404, title=title)
 def VVBiWl(self, path, progBarObj):
  totChan   = 0
  totLive   = 0
  totVod   = 0
  totSeries  = 0
  totUncat  = 0
  totVideo  = 0
  totAudio  = 0
  txt = FFJ07K(path)
  lst = iFindall(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?((.+)(:[^:\/]+$)|.+)", txt, IGNORECASE)
  txt = ""
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VV5404 = ""
  progBarObj.VVzcj3(len(lst))
  for item in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVoDTW(1, True)
   totChan += 1
   chName  = item[0].strip()
   fullUrl  = item[1].strip()
   urlPart1 = item[2]
   if urlPart1 : tUrl = urlPart1
   else  : tUrl = fullUrl
   tUrl = FFpzGx(tUrl).lower()
   chType, host, username, password, streamId, chName = CCfvbT.VV1Nl0(tUrl)
   if   chType == "live" : totLive += 1
   elif chType == "movie" : totVod += 1
   elif chType == "series" : totSeries += 1
   else     : totUncat += 1
   aud_vid = CCfvbT.VV1Nl0(tUrl, getAudVid=True)
   if   aud_vid == "vid" : totVideo += 1
   elif aud_vid == "aud" : totAudio += 1
  txt = ""
  txt += FFARnG("File:\n", VVylYU)
  txt += "    %s\n"   % path
  txt += "\n"
  txt += FFARnG("Channels:\n", VVylYU)
  if lst:
   txt += "    Total\t: %d\n" % totChan
   txt += "\n"
   txt += FFARnG("Category:\n", VVylYU)
   txt += "    Live\t: %d\n" % totLive
   txt += "    VOD\t: %d\n" % totVod
   txt += "    Series\t: %d\n" % totSeries
   txt += "    Uncat.\t: %d\n" % totUncat
   txt += "\n"
   txt += FFARnG("Content:\n", VVylYU)
   txt += "    Video\t: %d\n" % totVideo
   txt += "    Audio\t: %d\n" % totAudio
   txt += "\n"
  else:
   txt += "    No channels  (or invalid file file format)"
  if progBarObj:
   progBarObj.VV5404 = txt
 def VV9iWu(self, isBrowseServer):
  path = CCfvbT.VVkhu0()
  lines = FFVHBJ('find %s %s -iname "*playlist*" | grep -i ".txt"' % (path, FFXsco(1)))
  if lines:
   lines.sort()
   VVY2K2 = []
   for line in lines:
    VVY2K2.append((line, line))
   OKBtnFnc = boundFunction(self.VVEhJa, isBrowseServer)
   VVHN3c = ("Delete File", boundFunction(self.VV705l, boundFunction(FFjQre, self, boundFunction(self.VV9iWu, isBrowseServer), title="Searching ...")))
   FFlTf2(self, None, title="Select Playlist File", VVY2K2=VVY2K2, width=1200, OKBtnFnc=OKBtnFnc, VVHN3c=VVHN3c)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFGIBw(self, 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt)
 def VVEhJa(self, isBrowseServer, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFjQre(menuInstance, boundFunction(self.VVN7nm, menuInstance, path, isBrowseServer), title="Processing File ...")
 def VVN7nm(self, fileMenuInstance, path, isBrowseServer):
  VVx2Uc = []
  num = lineNum = 0
  with open(path) as f:
   for line in f:
    line = line.strip()
    lineNum += 1
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FF0hsM(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCfvbT.VVSNqh(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVx2Uc:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(filter(None, [item[5], item[0]]))
     num += 1
     VVx2Uc.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVx2Uc:
   if isBrowseServer : title = "Playlist File"
   else    : title = "Convert to Bouquet"
   VVuedc  = ("Start"   , boundFunction(self.VVo2Bj, isBrowseServer, title) , [])
   VVPAO4 = ("Home Menu"  , FFQSOu            , [])
   VVBoAr = ("Edit File"  , boundFunction(self.VVRVOG, path)    , [])
   VVMZtN = ("Check & Filter" , boundFunction(self.VVd4dW, fileMenuInstance, path, isBrowseServer), [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVD84s  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFp1uk(self, None, title=title, header=header, VVSmWK=VVx2Uc, VVD84s=VVD84s, VVO0tX=widths, VV715D=26, VVuedc=VVuedc, VVPAO4=VVPAO4, VVMZtN=VVMZtN, VVBoAr=VVBoAr, VVdawd="#11001116", VV2xlz="#11001116", VVSwM6="#11001116", VVb1yt="#00003635", VVBWV3="#0a333333", VVYh87="#11331100", VVzUt6=True)
  else:
   FFGIBw(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVRVOG(self, path, VV3o52, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCs3j1(self, path, VVzqy9=boundFunction(self.VVro6J, VV3o52), curRowNum=rowNum)
  else    : FFQ3EB(self, path)
 def VVro6J(self, VV3o52, fileChanged):
  if fileChanged:
   VV3o52.cancel()
 def VVo2Bj(self, isBrowseServer, Title, VV3o52, title, txt, colList):
  url = colList[6]
  if isBrowseServer:
   FFjQre(VV3o52, boundFunction(self.VViuO2, Title, url), title="Checking Server ...")
  else:
   t = "&type=m3u"
   if not url.endswith(t):
    url += t
   url = url.replace("player_api.php", "get.php" )
   FFhMkA(self, boundFunction(FFjQre, VV3o52, boundFunction(self.VVMz95, VV3o52, url), title="Downloading ..."), "Download m3u file from this URL ?\n\n%s" % url, title=Title)
 def VVMz95(self, VV3o52, url):
  path, err = FFV6A0(url, "ajpanel_tmp.m3u", timeout=3)
  title = "Download Problem"
  if err:
   FFGIBw(self, err, title=title)
  else:
   if fileExists(path):
    txt = FFJ07K(path)
    if '{"user_info":{"auth":0}}' in txt:
     FFGIBw(self, "Unauthorized", title=title)
     os.system(FFdgmD("rm -f '%s'" % path))
     return
   self.VVciDg(VV3o52, path)
 def VV8A7O(self, title):
  curChName = self.VV3o52.VViajA(1)
  FFwT6k(self, boundFunction(self.VVw7Er, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVw7Er(self, title, name):
  if name:
   lameDbChans = CCJkx4.VVbEdM(self, CCJkx4.VVZjyx, VVPUZv=False, VVGmkd=False)
   list = []
   if lameDbChans:
    processChanName = CCkPk2()
    name = processChanName.VVneR5(name)
    ratio = "1"
    for item in lameDbChans:
     if name in item[0].lower():
      list.append((item[0], FFPQrv(item[2]), item[3], ratio))
   if list : self.VVEQS8(list, title)
   else : FFGIBw(self, "Not found:\n\n%s" % name, title=title)
 def VVTz4W(self, title):
  curChName = self.VV3o52.VViajA(1)
  self.session.open(CCvPFp, barTheme=CCvPFp.VVR24C
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVFdRm
      , VVzqy9 = boundFunction(self.VVX8Gp, title, curChName))
 def VVFdRm(self, progBarObj):
  curChName = self.VV3o52.VViajA(1)
  lameDbChans = CCJkx4.VVbEdM(self, CCJkx4.VVuxjO, VVPUZv=False, VVGmkd=False)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VV5404 = []
  progBarObj.VVzcj3(len(lameDbChans))
  processChanName = CCkPk2()
  curCh = processChanName.VVneR5(curChName)
  for refCode in lameDbChans:
   chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
   ratio = CCJRmr.VV2jEf(chName.lower(), curCh)
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVoDTW(1, True)
   if ratio > 50:
    progBarObj.VV5404.append((chName, FFPQrv(sat), refCode.replace("_", ":"), str(ratio)))
 def VVX8Gp(self, title, curChName, VVUvIC, VV5404, threadCounter, threadTotal, threadErr):
  if VV5404 : self.VVEQS8(VV5404, title)
  elif VVUvIC : FFGIBw(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVEQS8(self, VVx2Uc, title):
  curChName = self.VV3o52.VViajA(1)
  curRefCode = self.VV3o52.VViajA(4)
  curUrl  = self.VV3o52.VViajA(5)
  VVx2Uc = sorted(VVx2Uc, key=lambda x: (100-int(x[3]), x[0].lower()))
  VVuedc  = ("Share Sat/C/T Ref.", boundFunction(self.VVZi4M, title, curChName, curRefCode, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFp1uk(self, None, title=title, header=header, VVSmWK=VVx2Uc, VVO0tX=widths, VV715D=26, VVuedc=VVuedc, VVdawd="#0a00112B", VV2xlz="#0a001126", VVSwM6="#0a001126", VVb1yt="#00000000")
 def VVZi4M(self, newtitle, curChName, curRefCode, curUrl, VV3o52, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFhMkA(self.VV3o52, boundFunction(FFjQre, self.VV3o52, boundFunction(self.VVvW4o, VV3o52, data)), ques, title=newtitle, VVydGz=True)
 def VVvW4o(self, VV3o52, data):
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  if curFullUrl and newFullUrl:
   for path in self.VVA64c():
    txt = FFJ07K(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFCe2y()
    newRow = []
    for i in range(6):
     newRow.append(self.VV3o52.VViajA(i))
    newRow[4] = newRefCode
    done = self.VV3o52.VV98qP(newRow)
    FFrLx8(self, "Done", title=title)
   else:
    FFGIBw(self, "Not found in IPTV files !", title=title)
  else:
   FFGIBw(self, "Could not read channel info !", title=title)
  VV3o52.cancel()
 def VVd4dW(self, fileMenuInstance, path, isBrowseServer, VV3o52, title, txt, colList):
  self.session.open(CCvPFp, barTheme=CCvPFp.VVR24C
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VVkNzk, VV3o52)
      , VVzqy9 = boundFunction(self.VVxD2m, fileMenuInstance, path, isBrowseServer, VV3o52))
 def VVkNzk(self, VV3o52, progBarObj):
  progBarObj.VVzcj3(VV3o52.VVt5sd())
  progBarObj.VV5404 = []
  for row in VV3o52.VVevLM():
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVoDTW(1, True)
   qUrl = self.VVdWrg(self.VVNm5p, row[6])
   txt, err = self.VVhcFk(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VV1IeQ(item, "auth") == "0":
       progBarObj.VV5404.append(qUrl)
    except:
     pass
 def VVxD2m(self, fileMenuInstance, path, isBrowseServer, VV3o52, VVUvIC, VV5404, threadCounter, threadTotal, threadErr):
  if VVUvIC:
   list = VV5404
   title = "Authorized Servers"
   if list:
    totChk = VV3o52.VVt5sd()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFgfmJ()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VV9iWu(isBrowseServer)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFARnG(str(totAuth), VVFGoE)
     txt += "%s\n\n%s"    %  (FFARnG("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FF0fhx(self, txt, title=title)
     VV3o52.close()
     fileMenuInstance.close()
    else:
     FFrLx8(self, "All URLs are authorized.", title=title)
   else:
    FFGIBw(self, "No authorized URL found !", title=title)
 def VVciDg(self, parentInstant, path):
  files = CCfvbT.VVhTUg(self, atLeastOne=True)
  if files: exitCurWin = False
  else : exitCurWin = True
  CCfvbT.VVhHO5(parentInstant, path, exitCurWin)
 @staticmethod
 def VVhHO5(SELF, path, exitCurWin):
  FFhMkA(SELF, boundFunction(FFjQre, SELF, boundFunction(CCfvbT.VVhrFF, SELF, path, exitCurWin), title="Converting ...")
    , "Convert file to bouquet ?\n\n%s" % path, title="Convert m3u file")
 @staticmethod
 def VVhrFF(SELF, path, exitCurWin):
  SID = TSID = ONID = 0
  MAX = 65535
  title = "Convert m3u File to Bouquet"
  if not fileExists(path):
   FFGIBw(SELF, "Cannot open file :\n\n%s" % path, title=title)
   return
  bName  = os.path.basename(path)
  bName  = os.path.splitext(bName)[0]
  bName   = CCfvbT.VVlP8P(bName)
  bName  = "IPTV_" + bName
  bFileName = "userbouquet.%s.tv" % bName
  if fileExists(VVVAau + bFileName):
   while True:
    SID += 1
    tmpBName = "%s_%d" % (bName, SID)
    bFileName = "userbouquet.%s.tv" % tmpBName
    if not fileExists(VVVAau + bFileName):
     bName = tmpBName
     break
  txt = FFJ07K(path)
  pattern = r"#EXTINF.+,(.+)\n(.+)"
  span = iSearch(r"#EXTINF.+,(.+)\n(.+)", txt, IGNORECASE)
  if span:
   with open(VVVAau + bFileName, "w") as f:
    totChan = 0
    f.write("#NAME %s\n" % bName.replace("IPTV_", "IPTV - ", 1))
    for match in iFinditer(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?(.+)", txt, IGNORECASE):
     TSID += 1
     if TSID > MAX:
      TSID = MAX
      ONID += 1
      if ONID > MAX:
       ONID = 0
     chName = match.group(1).strip()
     url  = FFA0q6(match.group(2).strip())
     rType = CFG.iptvAddToBouquetRefType.getValue()
     refCode = "%s:0:1:%s:%s:%s:0:0:0:0:" % (rType, hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:])
     line1 = "#SERVICE %s%s\n" % (refCode.upper(), url)
     line2 = "#DESCRIPTION %s\n" % chName
     f.write(line1 + line2)
     totChan += 1
   FF77qu(bFileName)
   FFCe2y()
   FFrLx8(SELF, 'New Bouquet = %s\n\nTotal Channels = %d' % (bName, totChan), title=title)
  else:
   FFGIBw(SELF, "No channels found in file (or invalid file format) !\n\n%s" % path, title=title)
  if exitCurWin:
   SELF.close()
 @staticmethod
 def VVhcFk(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   res = res.read().decode("UTF-8")
   if res:
    if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server !"
    else           : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVSNqh(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VV1Nl0(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = parts[1]
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVdWrg(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVSNqh(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVNm5p   : return "%s"            % url
  elif mode == self.VVQrdO   : return "%s&action=get_live_categories"     % url
  elif mode == self.VV4v5x   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVisQM  : return "%s&action=get_series_categories"     % url
  elif mode == self.VV3Uhm  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVS4SR : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVtQFB   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVnIak    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVdB9d  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVbM5y : return "%s&action=get_live_streams"      % url
  elif mode == self.VVZWI6  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VV1IeQ(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFXzY3(int(val))
    elif is_base64 : val = FFF9cg(val)
    elif isToHHMMSS : val = FFBS4u(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVfPHP(self, title, path):
  if fileExists(path):
   qUrl = ""
   with open(path, "r") as f:
    for line in f:
     qUrl = self.VVH9P0(line)
     if qUrl:
      break
   if qUrl : self.VViuO2(title, qUrl)
   else : FFGIBw(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFGIBw(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVRLMh_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVDNKV()
  if qUrl:
   host, mac, isPortalUrl = self.VVMa95(iptvRef)
   if isPortalUrl:
    if host and mac : self.VVRLMh(self, host, mac)
    else   : FFGIBw(self, "Error in current channel URL/MAC !", title=title)
   else:
    FFjQre(self, boundFunction(self.VViuO2, title, qUrl), title="Checking Server ...")
  else:
   FFGIBw(self, "Error in current channel URL !", title=title)
 def VVDNKV(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFlPZP(self)
  qUrl = self.VVH9P0(decodedUrl)
  return qUrl, iptvRef
 def VVH9P0(self, url):
  if url.startswith("#"):
   return ""
  url = url.lstrip(" /").rstrip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) >= 2 : return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else    : return ""
 def VViuO2(self, title, url):
  self.VVajIbData = {}
  qUrl = self.VVdWrg(self.VVNm5p, url)
  txt, err = self.VVhcFk(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVajIbData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVajIbData["username"    ] = self.VV1IeQ(item, "username"        )
    self.VVajIbData["password"    ] = self.VV1IeQ(item, "password"        )
    self.VVajIbData["message"    ] = self.VV1IeQ(item, "message"        )
    self.VVajIbData["auth"     ] = self.VV1IeQ(item, "auth"         )
    self.VVajIbData["status"    ] = self.VV1IeQ(item, "status"        )
    self.VVajIbData["exp_date"    ] = self.VV1IeQ(item, "exp_date"    , isDate=True )
    self.VVajIbData["is_trial"    ] = self.VV1IeQ(item, "is_trial"        )
    self.VVajIbData["active_cons"   ] = self.VV1IeQ(item, "active_cons"       )
    self.VVajIbData["created_at"   ] = self.VV1IeQ(item, "created_at"   , isDate=True )
    self.VVajIbData["max_connections"  ] = self.VV1IeQ(item, "max_connections"      )
    self.VVajIbData["allowed_output_formats"] = self.VV1IeQ(item, "allowed_output_formats"    )
    lst = []
    key = "allowed_output_formats"
    if key in item:
     for item in item[key]:
      lst.append(str(item))
     self.VVajIbData[key] = lst
    item = tDict["server_info"]
    self.VVajIbData["url"    ] = self.VV1IeQ(item, "url"        )
    self.VVajIbData["port"    ] = self.VV1IeQ(item, "port"        )
    self.VVajIbData["https_port"  ] = self.VV1IeQ(item, "https_port"      )
    self.VVajIbData["server_protocol" ] = self.VV1IeQ(item, "server_protocol"     )
    self.VVajIbData["rtmp_port"   ] = self.VV1IeQ(item, "rtmp_port"       )
    self.VVajIbData["timezone"   ] = self.VV1IeQ(item, "timezone"       )
    self.VVajIbData["timestamp_now"  ] = self.VV1IeQ(item, "timestamp_now"  , isDate=True )
    self.VVajIbData["time_now"   ] = self.VV1IeQ(item, "time_now"       )
    VVY2K2  = self.VVlFyt(True)
    OKBtnFnc = self.VVajIbOptions
    VVMVMB = ("Home Menu", FFQSOu)
    FFlTf2(self, None, title="IPTV Server Resources", VVY2K2=VVY2K2, OKBtnFnc=OKBtnFnc, VVMVMB=VVMVMB)
   else:
    err = "Could not get data from server !"
  if err:
   FFGIBw(self, err, title=title)
  FF3ty7(self)
 def VVajIbOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFjQre(menuInstance, boundFunction(self.VVpgok, self.VVQrdO  , title=title), title=wTxt)
   elif ref == "vod"   : FFjQre(menuInstance, boundFunction(self.VVpgok, self.VV4v5x  , title=title), title=wTxt)
   elif ref == "series"  : FFjQre(menuInstance, boundFunction(self.VVpgok, self.VVisQM , title=title), title=wTxt)
   elif ref == "catchup"  : FFjQre(menuInstance, boundFunction(self.VVpgok, self.VV3Uhm , title=title), title=wTxt)
   elif ref == "accountInfo" : FFjQre(menuInstance, boundFunction(self.VVGwWB           , title=title), title=wTxt)
 def VVGwWB(self, title):
  rows = []
  for key, val in self.VVajIbData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VVPAO4 = ("Home Menu", FFQSOu, [])
  header   = ("Num", "User/Server" , "Subject" , "Value" )
  widths   = (0 , 15   , 35  , 50  )
  FFp1uk(self, None, title=title, width=1200, header=header, VVSmWK=rows, VVO0tX=widths, VV715D=26, VVPAO4=VVPAO4, VVdawd="#0a00292B", VV2xlz="#0a002126", VVSwM6="#0a002126", VVb1yt="#00000000", searchCol=2)
 def VVoh45(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CCkPk2()
    if mode in (self.VVtQFB, self.VVZWI6):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VV1IeQ(item, "num"         )
      name     = self.VV1IeQ(item, "name"        )
      stream_id    = self.VV1IeQ(item, "stream_id"       )
      stream_icon    = self.VV1IeQ(item, "stream_icon"       )
      epg_channel_id   = self.VV1IeQ(item, "epg_channel_id"      )
      added     = self.VV1IeQ(item, "added"    , isDate=True )
      is_adult    = self.VV1IeQ(item, "is_adult"       )
      category_id    = self.VV1IeQ(item, "category_id"       )
      tv_archive    = self.VV1IeQ(item, "tv_archive"       )
      name = processChanName.VV5E8s(name)
      if name:
       if mode == self.VVtQFB or mode == self.VVZWI6 and tv_archive == "1":
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVnIak:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VV1IeQ(item, "num"         )
      name    = self.VV1IeQ(item, "name"        )
      stream_id   = self.VV1IeQ(item, "stream_id"       )
      stream_icon   = self.VV1IeQ(item, "stream_icon"       )
      added    = self.VV1IeQ(item, "added"    , isDate=True )
      is_adult   = self.VV1IeQ(item, "is_adult"       )
      category_id   = self.VV1IeQ(item, "category_id"       )
      container_extension = self.VV1IeQ(item, "container_extension"     ) or "mp4"
      name = processChanName.VV5E8s(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVdB9d:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VV1IeQ(item, "num"        )
      name    = self.VV1IeQ(item, "name"       )
      series_id   = self.VV1IeQ(item, "series_id"      )
      cover    = self.VV1IeQ(item, "cover"       )
      genre    = self.VV1IeQ(item, "genre"       )
      episode_run_time = self.VV1IeQ(item, "episode_run_time"    )
      category_id   = self.VV1IeQ(item, "category_id"      )
      container_extension = self.VV1IeQ(item, "container_extension"    ) or "mp4"
      name = processChanName.VV5E8s(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVpgok(self, mode, title):
  cList, err = self.VVgoov(mode)
  if cList and mode == self.VV3Uhm:
   cList = self.VVFm6P(cList)
  if err:
   FFGIBw(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVdawd, VV2xlz, VVSwM6, VVb1yt = self.VVu5ZW(mode)
   mName = self.VVkTIB(mode)
   if   mode == self.VVQrdO  : fMode = self.VVtQFB
   elif mode == self.VV4v5x  : fMode = self.VVnIak
   elif mode == self.VVisQM : fMode = self.VVdB9d
   elif mode == self.VV3Uhm : fMode = self.VVZWI6
   if mode == self.VV3Uhm:
    VVBoAr = None
   else:
    VVBoAr = ("Find in %s" % mName , boundFunction(self.VVXh4K, fMode) , [])
   VVuedc   = ("Show List"   , boundFunction(self.VV9QN8, mode) , [])
   VVPAO4  = ("Home Menu"   , FFQSOu          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFp1uk(self, None, title=title, width=1200, header=header, VVSmWK=cList, VVO0tX=widths, VV715D=30, VVPAO4=VVPAO4, VVBoAr=VVBoAr, VVuedc=VVuedc, VVdawd=VVdawd, VV2xlz=VV2xlz, VVSwM6=VVSwM6, VVb1yt=VVb1yt)
  else:
   FFGIBw(self, "No list from server !", title=title)
  FF3ty7(self)
 def VVgoov(self, mode):
  qUrl  = self.VVdWrg(mode, self.VVajIbData["playListURL"])
  txt, err = self.VVhcFk(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    processChanName = CCkPk2()
    for item in tDict:
     category_id  = self.VV1IeQ(item, "category_id"  )
     category_name = self.VV1IeQ(item, "category_name" )
     parent_id  = self.VV1IeQ(item, "parent_id"  )
     category_name = processChanName.VV4ZfA(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVFm6P(self, catList):
  mode  = self.VVZWI6
  qUrl  = self.VVdWrg(mode, self.VVajIbData["playListURL"])
  txt, err = self.VVhcFk(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVoh45(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VV9QN8(self, mode, VV3o52, title, txt, colList):
  title = colList[1]
  FFjQre(VV3o52, boundFunction(self.VVLMxz, mode, VV3o52, title, txt, colList), title="Downloading ...")
 def VVLMxz(self, mode, VV3o52, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVkTIB(mode) + " : "+ bName
  if   mode == self.VVQrdO  : mode = self.VVtQFB
  elif mode == self.VV4v5x  : mode = self.VVnIak
  elif mode == self.VVisQM : mode = self.VVdB9d
  elif mode == self.VV3Uhm : mode = self.VVZWI6
  qUrl  = self.VVdWrg(mode, self.VVajIbData["playListURL"], catID)
  txt, err = self.VVhcFk(qUrl)
  list  = []
  if not err and mode in (self.VVtQFB, self.VVnIak, self.VVdB9d, self.VVZWI6):
   list, err = self.VVoh45(mode, txt)
  if err:
   FFGIBw(self, err, title=title)
  elif list:
   VVPAO4  = ("Home Menu"   , FFQSOu             , [])
   if mode in (self.VVtQFB, self.VVZWI6):
    VVdawd, VV2xlz, VVSwM6, VVb1yt = self.VVu5ZW(mode)
    VVGP73 = (""     , boundFunction(self.VVKOkU, mode)     , [])
    VV4tKk = ("Download PIcons" , boundFunction(self.VV0cxW, mode)     , [])
    VVBoAr = ("Add ALL to Bouquet" , boundFunction(self.VVZqrd, mode, bName)  , [])
    if mode == self.VVtQFB:
     VVuedc = ("Play"    , boundFunction(self.VVlNGW, mode, False)   , [])
    elif mode == self.VVZWI6:
     VVuedc  = ("Programs", boundFunction(self.VVsO81, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVD84s  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVnIak:
    VVdawd, VV2xlz, VVSwM6, VVb1yt = self.VVu5ZW(mode)
    VVuedc  = ("Play"    , boundFunction(self.VVlNGW, mode, False)  , [])
    VVGP73 = (""     , boundFunction(self.VVKOkU, mode)    , [])
    VV4tKk = ("Download PIcons" , boundFunction(self.VV0cxW, mode)    , [])
    VVBoAr = ("Add ALL to Bouquet" , boundFunction(self.VVZqrd, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVD84s  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVdB9d:
    VVdawd, VV2xlz, VVSwM6, VVb1yt = self.VVu5ZW("series2")
    VVuedc  = ("Show Seasons", boundFunction(self.VVOh4M, mode) , [])
    VVGP73 = ("", boundFunction(self.VV10y4, mode)  , [])
    VV4tKk = None
    VVBoAr = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVD84s  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFp1uk(self, None, title=title, header=header, VVSmWK=list, VVD84s=VVD84s, VVO0tX=widths, VV715D=26, VVuedc=VVuedc, VVPAO4=VVPAO4, VV4tKk=VV4tKk, VVBoAr=VVBoAr, VVGP73=VVGP73, VVdawd=VVdawd, VV2xlz=VV2xlz, VVSwM6=VVSwM6, VVb1yt=VVb1yt, VVzUt6=True, searchCol=1)
  else:
   FFGIBw(self, "No Channels found !", title=title)
  FF3ty7(self)
 def VVsO81(self, mode, bName, VV3o52, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVajIbData["playListURL"]
  ok_fnc  = boundFunction(self.VV4QjI, hostUrl, chName, catId, streamId)
  FFjQre(VV3o52, boundFunction(CCfvbT.VV8Uly, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VV4QjI(self, chUrl, chName, catId, streamId, VV3o52, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCfvbT.VVSNqh(chUrl)
   chNum = "333"
   refCode = CCfvbT.VVEYmj(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFBoZM(self, chUrl, VVBdIn=False)
   self.session.open(CCpspP)
  else:
   FFGIBw(self, "Incorrect Timestamp", pTitle)
 def VVOh4M(self, mode, VV3o52, title, txt, colList):
  title = colList[1]
  FFjQre(VV3o52, boundFunction(self.VVB6zM, mode, VV3o52, title, txt, colList), title="Downloading ...")
 def VVB6zM(self, mode, VV3o52, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVdWrg(self.VVS4SR, self.VVajIbData["playListURL"], series_id)
  txt, err = self.VVhcFk(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VV1IeQ(tDict["info"], "name"   )
      category_id = self.VV1IeQ(tDict["info"], "category_id" )
      icon  = self.VV1IeQ(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VV1IeQ(EP, "id"     )
        episode_num   = self.VV1IeQ(EP, "episode_num"   )
        epTitle    = self.VV1IeQ(EP, "title"     )
        container_extension = self.VV1IeQ(EP, "container_extension" )
        seasonNum   = self.VV1IeQ(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFGIBw(self, err, title=title)
  elif list:
   VVPAO4 = ("Home Menu"   , FFQSOu            , [])
   VV4tKk = ("Download PIcons" , boundFunction(self.VV0cxW , mode)   , [])
   VVBoAr = ("Add ALL to Bouquet" , boundFunction(self.VVZqrd, mode, title) , [])
   VVGP73 = (""     , boundFunction(self.VVKOkU, mode)    , [])
   VVuedc  = ("Play"    , boundFunction(self.VVlNGW, mode, False)  , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVD84s  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFp1uk(self, None, title=title, header=header, VVSmWK=list, VVD84s=VVD84s, VVO0tX=widths, VV715D=26, VVPAO4=VVPAO4, VV4tKk=VV4tKk, VVuedc=VVuedc, VVGP73=VVGP73, VVBoAr=VVBoAr, VVdawd="#0a00292B", VV2xlz="#0a002126", VVSwM6="#0a002126", VVb1yt="#00000000")
  else:
   FFGIBw(self, "No Channels found !", title=title)
  FF3ty7(self)
 def VVXh4K(self, mode, VV3o52, title, txt, colList):
  VVY2K2 = []
  VVY2K2.append(("Keyboard"  , "manualEntry"))
  VVY2K2.append(("From Filter" , "fromFilter"))
  FFlTf2(self, boundFunction(self.VVFTNQ, VV3o52, mode), title="Input Type", VVY2K2=VVY2K2, width=400)
 def VVFTNQ(self, VV3o52, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFwT6k(self, boundFunction(self.VVMfbZ, VV3o52, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCD6d0(self)
    filterObj.VVeTEi(boundFunction(self.VVMfbZ, VV3o52, mode))
 def VVMfbZ(self, VV3o52, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CCkPk2()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVJMgS(words):
     FFGIBw(self, processChanName.VVNX6e(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CCvPFp, barTheme=CCvPFp.VVR24C
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VVIsh8, VV3o52, mode, title, words, toFind, asPrefix, processChanName)
         , VVzqy9 = boundFunction(self.VVXzsJ, mode, toFind, title))
   else:
    FFGIBw(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VVIsh8(self, VV3o52, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVzcj3(VV3o52.VVC6zJ())
  progBarObj.VV5404 = []
  for row in VV3o52.VVevLM():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVoDTW(1)
   progBarObj.VVAsDB_fromIptvFind(catName)
   qUrl  = self.VVdWrg(mode, self.VVajIbData["playListURL"], catID)
   txt, err = self.VVhcFk(qUrl)
   if not err:
    tList, err = self.VVoh45(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VV5E8s(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VVtQFB:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VV5404.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVnIak:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VV5404.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVdB9d:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VV5404.append((num, name, catID, ID, genre, catName, ext, cover))
 def VVXzsJ(self, mode, toFind, title, VVUvIC, VV5404, threadCounter, threadTotal, threadErr):
  if VV5404:
   title = self.VVlvxV(mode, toFind)
   if mode == self.VVtQFB or mode == self.VVnIak:
    bName   = CCfvbT.VVlP8P(toFind)
    VVuedc  = ("Play"     , boundFunction(self.VVlNGW, mode, False)  , [])
    VVBoAr = ("Add ALL to Bouquet" , boundFunction(self.VVZqrd, mode, bName) , [])
    VV4tKk = ("Download PIcons" , boundFunction(self.VV0cxW, mode)    , [])
   elif mode == self.VVdB9d:
    VVuedc  = ("Show Seasons"  , boundFunction(self.VVOh4M, mode)    , [])
    VVBoAr = None
    VV4tKk = None
   VVGP73 = (""   , boundFunction(self.VVKOkU, mode) , [])
   VVPAO4 = ("Home Menu" , FFQSOu         , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVD84s  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VV3o52 = FFp1uk(self, None, title=title, header=header, VVSmWK=VV5404, VVD84s=VVD84s, VVO0tX=widths, VV715D=26, VVuedc=VVuedc, VVPAO4=VVPAO4, VV4tKk=VV4tKk, VVBoAr=VVBoAr, VVGP73=VVGP73, VVdawd="#0a00292B", VV2xlz="#0a002126", VVSwM6="#0a002126", VVb1yt="#00000000", VVzUt6=True, searchCol=1)
   if not VVUvIC:
    FF3ty7(VV3o52, "Stopped" , 1000)
  else:
   if VVUvIC:
    FFGIBw(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVC9ss(self, mode, colList):
  if mode in (self.VVtQFB, self.VVZWI6):
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVnIak:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFt6bT(chName)
  url = self.VVajIbData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVSNqh(url)
  refCode = self.VVEYmj(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVKOkU(self, mode, VV3o52, title, txt, colList):
  FFjQre(VV3o52, boundFunction(self.VVbOZE, mode, VV3o52, title, txt, colList))
 def VVbOZE(self, mode, VV3o52, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVC9ss(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFzRsg(self, fncMode=CCf574.VVzoSk, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VV10y4(self, mode, VV3o52, title, txt, colList):
  FFjQre(VV3o52, boundFunction(self.VVWUzR, mode, VV3o52, title, txt, colList))
 def VVWUzR(self, mode, VV3o52, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFzRsg(self, fncMode=CCf574.VVXOHw, chName=name, text=txt, picUrl=Cover)
 def VVZqrd(self, mode, bName, VV3o52, title, txt, colList):
  FFjQre(VV3o52, boundFunction(self.VVxugr, mode, bName, VV3o52, title, txt, colList), title="Adding Channels ...")
 def VVxugr(self, mode, bName, VV3o52, title, txt, colList):
  url = self.VVajIbData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVSNqh(url)
  bNameFile = CCfvbT.VVlP8P(bName)
  num  = 0
  path = VVVAau + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVVAau + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VV3o52.VVevLM():
    chName, chUrl, picUrl, refCode = self.VVC9ss(mode, row)
    f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
    f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
    totChange += 1
  FF77qu(os.path.basename(path))
  self.VVfiaX(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VV0cxW(self, mode, VV3o52, title, txt, colList):
  if os.system(FFdgmD("which ffmpeg")) == 0:
   self.session.open(CCvPFp, barTheme=CCvPFp.VV4LTD
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VVM3gg, VV3o52, mode)
       , VVzqy9 = self.VVzKN7)
  else:
   FFhMkA(self, self.VVDRRX, '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?')
 def VVzKN7(self, VVUvIC, VV5404, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VV5404["proces"], VV5404["total"])
  txt += "Download Success\t: %d of %s\n"  % (VV5404["ok"], VV5404["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VV5404["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VV5404["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VV5404["badURL"]
  txt += "PIcons Path\t\t: %s\n"    % VV5404["path"]
  if not VVUvIC  : color = "#11402000"
  elif VV5404["err"]: color = "#11201000"
  else     : color = None
  if VV5404["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VV5404["err"], txt)
  title = "PIcons Download Result"
  if not VVUvIC:
   title += "  (cancelled)"
  FF0fhx(self, txt, title=title, VVSwM6=color)
 def VVM3gg(self, VV3o52, mode, progBarObj):
  totRows = VV3o52.VVC6zJ()
  progBarObj.VVzcj3(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CCJRmr.VVFZXX()
  progBarObj.VV5404 = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for row in VV3o52.VVevLM():
    if progBarObj.isCancelled:
     break
    progBarObj.VV5404["proces"] += 1
    progBarObj.VVoDTW(1)
    if mode in ("itv", "vod", "series"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV0clR(mode, row)
     refCode = CCfvbT.VVEYmj(catID, stID, chNum)
    else:
     chName, chUrl, picUrl, refCode = self.VVC9ss(mode, row)
    if picUrl:
     picon = refCode.replace(":", "_").rstrip("_") + ".png"
     if not fileExists(pPath + picon):
      progBarObj.VV5404["attempt"] += 1
      path, err = FFV6A0(picUrl, picon, timeout=1)
      if path:
       progBarObj.VV5404["ok"] += 1
       if FFg3Y3(path) > 0:
        cmd = ""
        if not mode == CCfvbT.VVtQFB:
         cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
        cmd += FFdgmD("mv -f '%s' '%s'" % (path, pPath)) + ";"
        os.system(cmd)
       else:
        progBarObj.VV5404["size0"] += 1
        os.system(FFdgmD("rm -f '%s'" % path))
      elif err:
       progBarObj.VV5404["fail"] += 1
       if any(x in err.lower() for x in ("time-out", "unauthorized")):
        progBarObj.VV5404["err"] = err.title()
        break
     else:
      progBarObj.VV5404["exist"] += 1
    else:
     progBarObj.VV5404["badURL"] += 1
  except:
   pass
 def VVDRRX(self):
  cmd = FF6Z6k(VVXJyy, "ffmpeg")
  if cmd : FFRQmD(self, cmd, title="Installing FFmpeg")
  else : FFvteW(self)
 def VVGdgW(self):
  self.session.open(CCvPFp, barTheme=CCvPFp.VVGS5G
      , titlePrefix = ""
      , fncToRun  = self.VVUAIC
      , VVzqy9 = self.VVt6tK)
 def VVUAIC(self, progBarObj):
  bName = FFnWjn()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  progBarObj.VV5404 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = FFrJ62()
  if not progBarObj or progBarObj.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   progBarObj.VVzcj3(totCh)
   for serv in services:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVoDTW(1)
    progBarObj.VVAsDB_fromImportEPG(totEpgOK, uChName)
    fullRef  = serv[0]
    if FFRlBi(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFSPfg(fullRef)
     span = iSearch(r"(mode=.+end=)", fullRef, IGNORECASE)
     if span:
      m3u_Url = CCuZpw.VVzCYS(fullRef)
      uType, uHost, uUser, uPass, uId, uChName  = CCfvbT.VV1Nl0(fullRef)
      uType, uHost, uUser, uPass, uId, uChName1 = CCfvbT.VV1Nl0(m3u_Url)
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCfvbT.VV1Nl0(m3u_Url)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCfvbT.VV1kZc(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCf574.VVrfH2(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
      else:
       pass
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if progBarObj:
     progBarObj.VV5404 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   progBarObj.VV5404 = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VVt6tK(self, VVUvIC, VV5404, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VV5404
  title = "IPTV EPG Import"
  if err:
   FFGIBw(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFARnG(str(totNotIptv), VVEAFU)
    if totServErr : txt += "Server Errors\t: %s\n" % FFARnG(str(totServErr) + t1, VVEAFU)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFARnG(str(totInv), VVEAFU)
   if not VVUvIC:
    title += "  (stopped)"
   FF0fhx(self, txt, title=title)
 @staticmethod
 def VV1kZc(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCfvbT.VVSNqh(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCfvbT.VVhcFk(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCfvbT.VV1IeQ(item, "description" , is_base64=True ).replace("\n", " .. ")
    has_archive   = CCfvbT.VV1IeQ(item, "has_archive"      )
    lang    = CCfvbT.VV1IeQ(item, "lang"        ).upper()
    now_playing   = CCfvbT.VV1IeQ(item, "now_playing"      )
    start    = CCfvbT.VV1IeQ(item, "start"        )
    start_timestamp  = CCfvbT.VV1IeQ(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCfvbT.VV1IeQ(item, "start_timestamp"     )
    stop_timestamp  = CCfvbT.VV1IeQ(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCfvbT.VV1IeQ(item, "stop_timestamp"      )
    tTitle    = CCfvbT.VV1IeQ(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVEYmj(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCfvbT.VVoCbm(catID, MAX_4b)
  TSID = CCfvbT.VVoCbm(chNum, MAX_4b)
  ONID = CCfvbT.VVoCbm(chNum, MAX_4b)
  NS  = CCfvbT.VVoCbm(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVoCbm(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVlP8P(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVu5ZW(mode):
  if   mode in ("itv"  , CCfvbT.VVQrdO)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCfvbT.VV4v5x)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCfvbT.VVisQM) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCfvbT.VV3Uhm) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCfvbT.VVZWI6    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 @staticmethod
 def VVkhu0():
  path = CFG.iptvHostsPath.getValue()
  if not pathExists(path) or path == VVl5oV: return "/"
  else          : return FF0hsM(path)
 @staticmethod
 def VV8Uly(SELF, hostUrl, chName, streamId, ok_fnc):
  title = "Catchup TV Programs"
  pList, err = CCfvbT.VV1kZc(hostUrl, streamId, True)
  if err:
   FFGIBw(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVdawd, VV2xlz, VVSwM6, VVb1yt = CCfvbT.VVu5ZW("")
   VVPAO4 = ("Home Menu" , FFQSOu, [])
   VVuedc  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVD84s  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFp1uk(SELF, None, title="Programs for : " + chName, header=header, VVSmWK=pList, VVD84s=VVD84s, VVO0tX=widths, VV715D=24, VVuedc=VVuedc, VVPAO4=VVPAO4, VVdawd=VVdawd, VV2xlz=VV2xlz, VVSwM6=VVSwM6, VVb1yt=VVb1yt)
  else:
   FFGIBw(SELF, "No Programs from server", title=title)
class CC9DrC(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFdxjB(VVwo8o, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVnXYd  = 0
  self.VVGuaT = 1
  self.VVbwaH  = 2
  VVY2K2 = []
  VVY2K2.append(("Find in All Service (from filter)" , "VVOgUJ" ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Find in All (Manual Entry)"   , "VVMvit"    ))
  VVY2K2.append(("Find in TV"       , "VVjUY5"    ))
  VVY2K2.append(("Find in Radio"      , "VV0GYH"   ))
  if self.VVXZM5():
   VVY2K2.append(VV8PP6)
   VVY2K2.append(("Hide Channel: %s" % self.servName , "VVJkSB"   ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Zap History"       , "VVFtO7"    ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("IPTV Tools"       , "iptv"      ))
  VVY2K2.append(("PIcons Tools"       , "PIconsTools"     ))
  VVY2K2.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FFSskZ(self, VVY2K2=VVY2K2, title=title)
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  FFUwX1(self["myMenu"])
  FF2Dma(self)
  if self.isFindMode:
   self.VV4IqD(self.VVJbkL())
 def VVtv5z(self):
  global VVXLue
  VVXLue = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVMvit"    : self.VVMvit()
   elif item == "VVOgUJ" : self.VVOgUJ()
   elif item == "VVjUY5"    : self.VVjUY5()
   elif item == "VV0GYH"   : self.VV0GYH()
   elif item == "VVJkSB"   : self.VVJkSB()
   elif item == "VVFtO7"    : self.VVFtO7()
   elif item == "iptv"       : self.session.open(CCfvbT)
   elif item == "PIconsTools"     : self.session.open(CCJRmr)
   elif item == "ChannelsTools"    : self.session.open(CCJkx4)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVjUY5(self) : self.VV4IqD(self.VVnXYd)
 def VV0GYH(self) : self.VV4IqD(self.VVGuaT)
 def VVMvit(self) : self.VV4IqD(self.VVbwaH)
 def VV4IqD(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFwT6k(self, boundFunction(self.VVKwlu, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVOgUJ(self):
  filterObj = CCD6d0(self)
  filterObj.VVeTEi(self.VVof3e)
 def VVof3e(self, item):
  self.VVKwlu(self.VVbwaH, item)
 def VVXZM5(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFRlBi(self.refCode)        : return False
  return True
 def VVKwlu(self, mode, VV4DL4):
  FFjQre(self, boundFunction(self.VVqgNv, mode, VV4DL4), title="Searching ...")
 def VVqgNv(self, mode, VV4DL4):
  if VV4DL4:
   self.findTxt = VV4DL4
   if   mode == self.VVnXYd  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVGuaT : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VV4DL4)
   if len(title) > 55:
    title = title[:55] + ".."
   VVx2Uc = self.VVcVTw(VV4DL4, servTypes)
   if self.isFindMode or mode == self.VVbwaH:
    VVx2Uc += self.VVgFRU(VV4DL4)
   if VVx2Uc:
    VVx2Uc.sort(key=lambda x: x[0].lower())
    VVO3oT = self.VVYjGB
    VVuedc  = ("Zap"   , self.VVhTvc    , [])
    VV4tKk = ("Current Service", self.VVBzVW , [])
    VVBoAr = ("Options"  , self.VVbi3B , [])
    VVGP73 = (""    , self.VVRjpm , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVD84s  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFp1uk(self, None, title=title, header=header, VVSmWK=VVx2Uc, VVD84s=VVD84s, VVO0tX=widths, VV715D=26, VVuedc=VVuedc, VVO3oT=VVO3oT, VV4tKk=VV4tKk, VVBoAr=VVBoAr, VVGP73=VVGP73)
   else:
    self.VV4IqD(self.VVJbkL())
    FFrLx8(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVcVTw(self, VV4DL4, servTypes):
  VVAWP7  = eServiceCenter.getInstance()
  VVukg6   = '%s ORDER BY name' % servTypes
  VVuyuR   = eServiceReference(VVukg6)
  VV8vYX = VVAWP7.list(VVuyuR)
  if VV8vYX: VVSmWK = VV8vYX.getContent("CN", False)
  else     : VVSmWK = None
  VVx2Uc = []
  if VVSmWK:
   VVBag4, VVEr7j = FFfZ3i()
   tp   = CC8VoG()
   words, asPrefix = CCD6d0.VVGIe9(VV4DL4)
   colorYellow  = CC1Ai0.VV33nE(VVclxO)
   colorWhite  = CC1Ai0.VV33nE(VVYHoM)
   for s in VVSmWK:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFXnj4(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVBag4:
        STYPE = VVEr7j[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVcF7q(refCode)
       if not "-S" in syst:
        sat = syst
       VVx2Uc.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVx2Uc
 def VVgFRU(self, VV4DL4):
  VV4DL4 = VV4DL4.lower()
  VVRZvC = FF8UC9()
  VVx2Uc = []
  colorYellow  = CC1Ai0.VV33nE(VVclxO)
  colorWhite  = CC1Ai0.VV33nE(VVYHoM)
  if VVRZvC:
   for b in VVRZvC:
    VVeZiw  = b[0]
    VV45oD  = b[1].toString()
    VVdyHg = eServiceReference(VV45oD)
    VVP8q8 = FFCCnL(VVdyHg)
    for service in VVP8q8:
     refCode  = service[0]
     if FFRlBi(refCode):
      servName = service[1]
      if VV4DL4 in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VV4DL4), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VVx2Uc.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVx2Uc
 def VVJbkL(self):
  VVG5iL = InfoBar.instance
  if VVG5iL:
   VVzmom = VVG5iL.servicelist
   if VVzmom:
    return VVzmom.mode == 1
  return self.VVbwaH
 def VVYjGB(self, VV3o52):
  self.close()
  VV3o52.cancel()
 def VVhTvc(self, VV3o52, title, txt, colList):
  FFBoZM(VV3o52, colList[2], VVBdIn=False, checkParentalControl=True)
 def VVBzVW(self, VV3o52, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFlPZP(VV3o52)
  if refCode:
   VV3o52.VVV2sO(2, FFnNMM(refCode, iptvRef, chName), True)
 def VVbi3B(self, VV3o52, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CCZ5ac(self, VV3o52, 2)
  mSel.VV4V4u(servName, refCode)
 def VVRjpm(self, VV3o52, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFzRsg(self, fncMode=CCf574.VVHJnm, refCode=refCode, chName=chName, text=txt)
 def VVJkSB(self):
  FFhMkA(self, self.VVYHku, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVYHku(self):
  ret = FFKliL(self.refCode, True)
  if ret:
   self.VVzFe4()
   self.close()
  else:
   FF3ty7(self, "Cannot change state" , 1000)
 def VVzFe4(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVZeHU()
  except:
   self.VVY9Br()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFZQnl(self, serviceRef)
 def VVZ6vf(self):
  VVG5iL = InfoBar.instance
  if VVG5iL:
   VVzmom = VVG5iL.servicelist
   if VVzmom:
    VVzmom.setMode()
 def VVZeHU(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVG5iL = InfoBar.instance
   if VVG5iL:
    VVzmom = VVG5iL.servicelist
    if VVzmom:
     hList = VVzmom.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVzmom.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVzmom.history  = newList
       VVzmom.history_pos = pos
 def VVY9Br(self):
  VVG5iL = InfoBar.instance
  if VVG5iL:
   VVzmom = VVG5iL.servicelist
   if VVzmom:
    VVzmom.history  = []
    VVzmom.history_pos = 0
 def VVFtO7(self):
  VVG5iL = InfoBar.instance
  VVx2Uc = []
  if VVG5iL:
   VVzmom = VVG5iL.servicelist
   if VVzmom:
    VVBag4, VVEr7j = FFfZ3i()
    for chParams in VVzmom.history:
     refCode = chParams[-1].toString()
     chName = FFPdrd(refCode)
     isIptv = FFRlBi(refCode)
     if isIptv: sat = "-"
     else  : sat = FFXnj4(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVBag4:
       STYPE = VVEr7j[sTypeInt]
     VVx2Uc.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVx2Uc:
   VVuedc  = ("Zap"   , self.VVfOfb   , [])
   VVBoAr = ("Clear History" , self.VVBiAA   , [])
   VVGP73 = (""    , self.VVoRKTFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVD84s  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFp1uk(self, None, title=title, header=header, VVSmWK=VVx2Uc, VVD84s=VVD84s, VVO0tX=widths, VV715D=28, VVuedc=VVuedc, VVBoAr=VVBoAr, VVGP73=VVGP73)
  else:
   FFrLx8(self, "Not found", title=title)
 def VVfOfb(self, VV3o52, title, txt, colList):
  FFBoZM(VV3o52, colList[3], VVBdIn=False, checkParentalControl=True)
 def VVBiAA(self, VV3o52, title, txt, colList):
  FFhMkA(self, boundFunction(self.VVu8EU, VV3o52), "Clear Zap History ?")
 def VVu8EU(self, VV3o52):
  self.VVY9Br()
  VV3o52.cancel()
 def VVoRKTFromZapHistory(self, VV3o52, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFzRsg(self, fncMode=CCf574.VVSTlF, refCode=refCode, chName=chName, text=txt)
class CCJRmr(Screen):
 VVh9zI   = 0
 VVMb7h  = 1
 VV7hOm  = 2
 VV2gxK  = 3
 VVSmLu  = 4
 VV4udy  = 5
 VVLsR6  = 6
 VVqH69  = 7
 VV43vl = 8
 VVvlGW = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFdxjB(VV9ZKP, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFSskZ(self, self.Title)
  FFkqlb(self["keyRed"] , "OK = Zap")
  FFkqlb(self["keyGreen"] , "Current Service")
  FFkqlb(self["keyYellow"], "Page Options")
  FFkqlb(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCJRmr.VVFZXX()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVSmWK    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVDwuA        ,
   "green"   : self.VVj78J       ,
   "yellow"  : self.VV5Kj9        ,
   "blue"   : self.VVn7yj        ,
   "menu"   : self.VVC5Le        ,
   "info"   : self.VVoRKT         ,
   "up"   : self.VVq2Fv          ,
   "down"   : self.VVTlAE         ,
   "left"   : self.VVVkoz         ,
   "right"   : self.VV07jt         ,
   "pageUp"  : boundFunction(self.VV00TR, True) ,
   "chanUp"  : boundFunction(self.VV00TR, True) ,
   "pageDown"  : boundFunction(self.VV00TR, False) ,
   "chanDown"  : boundFunction(self.VV00TR, False) ,
   "next"   : self.VVoUEV        ,
   "last"   : self.VV7kR4         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  FF65Ci(self)
  FFidK4(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFjQre(self, boundFunction(self.VVKNHe, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVC5Le(self):
  if not self.isBusy:
   VVY2K2 = []
   VVY2K2.append(("Statistics"           , "VVayUU"    ))
   VVY2K2.append(VV8PP6)
   VVY2K2.append(("Suggest PIcons for Current Channel"     , "VViiT6"   ))
   VVY2K2.append(("Set to Current Channel (copy file)"     , "VV0899_file"  ))
   VVY2K2.append(("Set to Current Channel (as SymLink)"     , "VV0899_link"  ))
   VVY2K2.append(VV8PP6)
   VVY2K2.append(CCJRmr.VVWIro())
   VVY2K2.append(VV8PP6)
   if self.filterTitle == "PIcons without Channels":
    c = VVEAFU
    VVY2K2.append((FFARnG("Move Unused PIcons to a Directory", c) , "VVW8mu"  ))
    VVY2K2.append((FFARnG("DELETE Unused PIcons", c)    , "VVrBs8" ))
    VVY2K2.append(VV8PP6)
   VVY2K2.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VV5cu7"  ))
   VVY2K2.append(VV8PP6)
   VVY2K2 += CCJRmr.VV7Es5()
   VVY2K2.append(VV8PP6)
   VVY2K2.append(("RCU Keys Help"          , "VVEOst"    ))
   FFlTf2(self, self.VVMrkr, title=self.Title, VVY2K2=VVY2K2)
 def VVMrkr(self, item=None):
  if item is not None:
   if   item == "VVayUU"     : self.VVayUU()
   elif item == "VViiT6"    : self.VViiT6()
   elif item == "VV0899_file"   : self.VV0899(0)
   elif item == "VV0899_link"   : self.VV0899(1)
   elif item == "VVYSz6_file"  : self.VVYSz6(0)
   elif item == "VVYSz6_link"  : self.VVYSz6(1)
   elif item == "VVRkCB"   : self.VVRkCB()
   elif item == "VVkGep"  : self.VVkGep()
   elif item == "VVW8mu"    : self.VVW8mu()
   elif item == "VVrBs8"   : self.VVrBs8()
   elif item == "VV5cu7"   : self.VV5cu7()
   elif item == "VVqEdh"   : CCJRmr.VVqEdh(self)
   elif item == "VV4a0V"   : CCJRmr.VV4a0V(self)
   elif item == "findPiconBrokenSymLinks"  : CCJRmr.VVnoCN(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCJRmr.VVnoCN(self, False)
   elif item == "VVEOst"      : self.VVEOst()
 def VV5Kj9(self):
  if not self.isBusy:
   VVY2K2 = []
   VVY2K2.append(("Go to First PIcon"  , "VVWTtg"  ))
   VVY2K2.append(("Go to Last PIcon"   , "VVyDvc"  ))
   VVY2K2.append(VV8PP6)
   VVY2K2.append(("Sort by Channel Name"     , "sortByChan" ))
   VVY2K2.append(("Sort by File Name"  , "sortByFile" ))
   VVY2K2.append(VV8PP6)
   VVY2K2.append(("Find from File List .." , "VV8FuZ" ))
   FFlTf2(self, self.VVLAsj, title=self.Title, VVY2K2=VVY2K2)
 def VVLAsj(self, item=None):
  if item is not None:
   if   item == "VVWTtg"   : self.VVWTtg()
   elif item == "VVyDvc"   : self.VVyDvc()
   elif item == "sortByChan"  : self.VVl7n5(2)
   elif item == "sortByFile"  : self.VVl7n5(0)
   elif item == "VV8FuZ"  : self.VV8FuZ()
 def VVEOst(self):
  FFjWVm(self, VVCmbD + "_help_picons", "PIcons Manager (Keys Help)")
 def VVq2Fv(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVyDvc()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVRCfR()
 def VVTlAE(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVWTtg()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVRCfR()
 def VVVkoz(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVyDvc()
  else:
   self.curCol -= 1
   self.VVRCfR()
 def VV07jt(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVWTtg()
  else:
   self.curCol += 1
   self.VVRCfR()
 def VV7kR4(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVRCfR(True)
 def VVoUEV(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVRCfR(True)
 def VVWTtg(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVRCfR(True)
 def VVyDvc(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVRCfR(True)
 def VV8FuZ(self):
  VVY2K2 = []
  for item in self.VVSmWK:
   VVY2K2.append((item[0], item[0]))
  FFlTf2(self, self.VV81Rh, title='PIcons ".png" Files', VVY2K2=VVY2K2, VVTY2d=True)
 def VV81Rh(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVfkKL(ndx)
 def VVDwuA(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VV2e1l()
   if refCode:
    FFBoZM(self, refCode)
    self.VVxMgQ()
    self.VV7388()
 def VV00TR(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVxMgQ()
   self.VV7388()
  except:
   pass
 def VVj78J(self):
  if self["keyGreen"].getVisible():
   self.VVfkKL(self.curChanIndex)
 def VVfkKL(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVRCfR(True)
  else:
   FF3ty7(self, "Not found", 1000)
 def VVl7n5(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFjQre(self, boundFunction(self.VVKNHe, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VV0899(self, mode):
  title = "Change Current Channel PIcon"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFlPZP(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VV2e1l()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVY2K2 = []
     VVY2K2.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVY2K2.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFlTf2(self, boundFunction(self.VVWEQL, mode, curChF, selPiconF), VVY2K2=VVY2K2, title="Current Channel PIcon (already exists)")
    else:
     self.VVWEQL(mode, curChF, selPiconF, "overwrite")
   else:
    FFGIBw(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFGIBw(self, "Could not read current channel info. !", title=title)
 def VVWEQL(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFjQre(self, boundFunction(self.VVKNHe, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVYSz6(self, mode):
  pass
 def VVRkCB(self):
  pass
 def VVkGep(self):
  pass
 def VVW8mu(self):
  defDir = FF0hsM(CCJRmr.VVFZXX() + "picons_backup")
  os.system(FFdgmD("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(boundFunction(self.VVHIy9, defDir), boundFunction(CCQ4SG
         , mode=CCQ4SG.VVMcRv, VVbrP2=CCJRmr.VVFZXX()))
 def VVHIy9(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCJRmr.VVFZXX():
    FFGIBw(self, "Cannot move to same directory !", title=title)
   else:
    if not FF0hsM(path) == FF0hsM(defDir):
     self.VVyNgr(defDir)
    FFhMkA(self, boundFunction(FFjQre, self, boundFunction(self.VVKJXh, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVSmWK), path), title=title)
  else:
   self.VVyNgr(defDir)
 def VVKJXh(self, title, defDir, toPath):
  try:
   from shutil import move as iMove
  except:
   self.VVyNgr(defDir)
   FFGIBw(self, 'Could not load "shutil" module !', title=title)
   return
  toPath = FF0hsM(toPath)
  pPath = CCJRmr.VVFZXX()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVSmWK:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVSmWK)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FF0fhx(self, txt, title=title, VVSwM6="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVA9zk("all")
 def VVyNgr(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVrBs8(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVSmWK)
  s = "s" if tot > 1 else ""
  FFhMkA(self, boundFunction(FFjQre, self, boundFunction(self.VVXZaj, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, s), title=title)
 def VVXZaj(self, title):
  pPath = CCJRmr.VVFZXX()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVSmWK:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVSmWK)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFARnG(str(totErr), VVEAFU)
  FF0fhx(self, txt, title=title)
 def VV5cu7(self):
  lines = FFVHBJ("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFhMkA(self, boundFunction(self.VVVpK1, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVydGz=True)
  else:
   FFrLx8(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVVpK1(self, fList):
  os.system(FFdgmD("find -L '%s' -type l -delete" % self.pPath))
  FFrLx8(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVoRKT(self):
  FFjQre(self, self.VV69XV)
 def VV69XV(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VV2e1l()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFARnG("PIcon Directory:\n", VVylYU)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FFlN40(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFlN40(path)
   txt += FFARnG("PIcon File:\n", VVylYU)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFVHBJ(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFARnG("Found %d SymLink%s to this file from:\n" % (tot, s), VVylYU)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFPdrd(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFARnG(tChName, VVFGoE)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFARnG(line, VVPTHk), tChName)
    txt += "\n"
   if chName:
    txt += FFARnG("Channel:\n", VVylYU)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFARnG(chName, VVFGoE)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFARnG("Remarks:\n", VVylYU)
    txt += "  %s\n" % FFARnG("Unused", VVEAFU)
  else:
   txt = "No info found"
  FFzRsg(self, fncMode=CCf574.VVjfHv, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VV2e1l(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVSmWK[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFPQrv(sat)
  return fName, refCode, chName, sat, inDB
 def VVxMgQ(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFlPZP(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVSmWK):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VV7388(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VV2e1l()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFARnG("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVylYU))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VV2e1l()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFARnG(self.curChanName, VVclxO)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVayUU(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VVSmWK:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FF3QAx("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FF0fhx(self, txt, title=self.Title)
 def VVn7yj(self):
  if not self.isBusy:
   VVY2K2 = []
   VVY2K2.append(("All"         , "all"   ))
   VVY2K2.append(VV8PP6)
   VVY2K2.append(("Used by Channels"      , "used"  ))
   VVY2K2.append(("Unused PIcons"      , "unused"  ))
   VVY2K2.append(VV8PP6)
   VVY2K2.append(("PIcons Files"       , "pFiles"  ))
   VVY2K2.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVY2K2.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVY2K2.append(VV8PP6)
   VVY2K2.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVY2K2.append(VV8PP6)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFHRLV(val)
      VVY2K2.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCD6d0(self)
   filterObj.VV2X0u(VVY2K2, self.nsList, self.VVOK7v)
 def VVOK7v(self, item=None):
  if item is not None:
   self.VVA9zk(item)
 def VVA9zk(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVh9zI   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVMb7h   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VV7hOm  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VV2gxK  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVSmLu  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VV4udy  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVLsR6   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVqH69   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VV43vl , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VV4udy:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFVHBJ("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FF3ty7(self, "Not found", 1000)
     return
   elif mode == self.VVvlGW:
    return
   else:
    words, asPrefix = CCD6d0.VVGIe9(words)
   if not words and mode in (self.VVqH69, self.VV43vl):
    FF3ty7(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFjQre(self, boundFunction(self.VVKNHe, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VViiT6(self):
  self.session.open(CCvPFp, barTheme=CCvPFp.VVR24C
      , titlePrefix = ""
      , fncToRun  = self.VVNAQC
      , VVzqy9 = self.VV1nRT)
 def VVNAQC(self, progBarObj):
  lameDbChans = CCJkx4.VVbEdM(self, CCJkx4.VVuxjO, VVPUZv=False, VVGmkd=False)
  files = []
  words = []
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VV5404 = []
  progBarObj.VVzcj3(len(lameDbChans))
  if lameDbChans:
   processChanName = CCkPk2()
   curCh = processChanName.VVneR5(self.curChanName)
   for refCode in lameDbChans:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVoDTW(1, True)
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCJRmr.VV2jEf(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCJRmr.VVLw24(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       progBarObj.VV5404.append(f.replace(".png", ""))
 def VV1nRT(self, VVUvIC, VV5404, threadCounter, threadTotal, threadErr):
  if VV5404:
   self.timer = eTimer()
   fnc = boundFunction(FFjQre, self, boundFunction(self.VVKNHe, mode=self.VVvlGW, words=VV5404), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FF3ty7(self, "Not found", 2000)
 def VVKNHe(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVuQVQ(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCJkx4.VVbEdM(self, CCJkx4.VVuxjO, VVPUZv=False, VVGmkd=False)
  iptvRefList = self.VVCVlQ()
  tList = []
  for fName, fType in CCJRmr.VVRMRU(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVh9zI:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVMb7h  and chName         : isAdd = True
   elif mode == self.VV7hOm and not chName        : isAdd = True
   elif mode == self.VV2gxK  and fType == 0        : isAdd = True
   elif mode == self.VVSmLu  and fType == 1        : isAdd = True
   elif mode == self.VV4udy  and fName in words       : isAdd = True
   elif mode == self.VVvlGW and fName in words       : isAdd = True
   elif mode == self.VVLsR6  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVqH69  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VV43vl:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVSmWK   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FF3ty7(self)
  else:
   self.isBusy = False
   FF3ty7(self, "Not found", 1000)
   return
  self.VVSmWK.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVxMgQ()
  self.totalPIcons = len(self.VVSmWK)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVRCfR(True)
 def VVuQVQ(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCJRmr.VVRMRU(self.pPath):
    if fName:
     return True
   if isFirstTime : FFGIBw(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FF3ty7(self, "Not found", 1000)
  else:
   FFGIBw(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVCVlQ(self):
  VVx2Uc = {}
  files  = CCfvbT.VVhTUg(self)
  if files:
   for path in files:
    txt = FFJ07K(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVx2Uc[refCode] = item[1]
  return VVx2Uc
 def VVRCfR(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVi1CT = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVi1CT: self.curPage = VVi1CT
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVOEBB()
  if self.curPage == VVi1CT:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VV7388()
  filName, refCode, chName, sat, inDB = self.VV2e1l()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVOEBB(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVSmWK[ndx]
   fName = self.VVSmWK[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFARnG(chName, VVFGoE))
    else : lbl.setText("-")
   except:
    lbl.setText(FFARnG(chName, VV6kBj))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VV2jEf(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVWIro():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVqEdh"   )
 @staticmethod
 def VV7Es5():
  VVY2K2 = []
  VVY2K2.append(("Find SymLinks (to PIcon Directory)"   , "VV4a0V"   ))
  VVY2K2.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVY2K2.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVY2K2
 @staticmethod
 def VVqEdh(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFlPZP(SELF)
  png, path = CCJRmr.VVh50m(refCode)
  if path : CCJRmr.VV3K2k(SELF, png, path)
  else : FFGIBw(SELF, "No PIcon found for current channel in:\n\n%s" % CCJRmr.VVFZXX())
 @staticmethod
 def VV4a0V(SELF):
  if VVclxO:
   sed1 = FFAawR("->", VVclxO)
   sed2 = FFAawR("picon", VVEAFU)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VV6kBj, VVYHoM)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFTlgq(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFXsco(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVnoCN(SELF, isPIcon):
  sed1 = FFAawR("->", VV6kBj)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFAawR("picon", VVEAFU)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFTlgq(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFXsco(), grep, sed1, sed2))
 @staticmethod
 def VVRMRU(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVFZXX():
  path = CFG.PIconsPath.getValue()
  return FF0hsM(path)
 @staticmethod
 def VVh50m(refCode, chName=None):
  if FFRlBi(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFSPfg(refCode)
  allPath, fName, refCodeFile, pList = CCJRmr.VVLw24(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VV3K2k(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFAawR("%s%s" % (dest, png), VVFGoE))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFAawR(errTxt, VVu486))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FF0eWo(SELF, cmd)
 @staticmethod
 def VVLw24(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCJRmr.VVFZXX()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFt6bT(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCiLKR():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVZjdD  = None
  self.VVhrAs = ""
  self.VVdsAW  = noService
  self.VVbwbT = 0
  self.VV8pgr  = noService
  self.VV15mN = 0
  self.VV0p8v  = "-"
  self.VVYsEs = 0
  self.VVWour  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VV7JG8(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVZjdD = frontEndStatus
     self.VVTSXF()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVTSXF(self):
  if self.VVZjdD:
   val = self.VVZjdD.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVhrAs = "%3.02f dB" % (val / 100.0)
   else         : self.VVhrAs = ""
   val = self.VVZjdD.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVbwbT = int(val)
   self.VVdsAW  = "%d%%" % val
   val = self.VVZjdD.get("tuner_signal_power" , 0) * 100 / 65536
   self.VV15mN = int(val)
   self.VV8pgr  = "%d%%" % val
   val = self.VVZjdD.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VV0p8v  = "%d" % val
   val = int(val * 100 / 500)
   self.VVYsEs = min(500, val)
   val = self.VVZjdD.get("tuner_locked", 0)
   if val == 1 : self.VVWour = "Locked"
   else  : self.VVWour = "Not locked"
 def VV69En(self)   : return self.VVhrAs
 def VVPVTR(self)   : return self.VVdsAW
 def VVkYdd(self)  : return self.VVbwbT
 def VVFZeH(self)   : return self.VV8pgr
 def VVCYYN(self)  : return self.VV15mN
 def VVnFlK(self)   : return self.VV0p8v
 def VVQzys(self)  : return self.VVYsEs
 def VVL40I(self)   : return self.VVWour
 def VV41QR(self) : return self.serviceName
class CC8VoG():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVFbj7(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFQhMf(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVt0M2(self.ORPOS  , mod=1   )
      self.sat2  = self.VVt0M2(self.ORPOS  , mod=2   )
      self.freq  = self.VVt0M2(self.FREQ  , mod=3   )
      self.sr   = self.VVt0M2(self.SR   , mod=4   )
      self.inv  = self.VVt0M2(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVt0M2(self.POL  , self.D_POL )
      self.fec  = self.VVt0M2(self.FEC  , self.D_FEC )
      self.syst  = self.VVt0M2(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVt0M2("modulation" , self.D_MOD )
       self.rolof = self.VVt0M2("rolloff"  , self.D_ROLOF )
       self.pil = self.VVt0M2("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVt0M2("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVt0M2("pls_code"  )
       self.iStId = self.VVt0M2("is_id"   )
       self.t2PlId = self.VVt0M2("t2mi_plp_id" )
       self.t2PId = self.VVt0M2("t2mi_pid"  )
 def VVt0M2(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFHRLV(val)
  elif mod == 2   : return FFKq5s(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVNbt0(self, refCode):
  txt = ""
  self.VVFbj7(refCode)
  if self.data:
   def VVOxXn(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVOxXn("System"   , self.syst)
    txt += VVOxXn("Satellite"  , self.sat2)
    txt += VVOxXn("Frequency"  , self.freq)
    txt += VVOxXn("Inversion"  , self.inv)
    txt += VVOxXn("Symbol Rate"  , self.sr)
    txt += VVOxXn("Polarization" , self.pol)
    txt += VVOxXn("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVOxXn("Modulation" , self.mod)
     txt += VVOxXn("Roll-Off" , self.rolof)
     txt += VVOxXn("Pilot"  , self.pil)
     txt += VVOxXn("Input Stream", self.iStId)
     txt += VVOxXn("T2MI PLP ID" , self.t2PlId)
     txt += VVOxXn("T2MI PID" , self.t2PId)
     txt += VVOxXn("PLS Mode" , self.plsMod)
     txt += VVOxXn("PLS Code" , self.plsCod)
   else:
    txt += VVOxXn("System"   , self.txMedia)
    txt += VVOxXn("Frequency"  , self.freq)
  return txt, self.namespace
 def VVvbUZ(self, refCode):
  txt = "Transpoder : ?"
  self.VVFbj7(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VVylYU + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVcF7q(self, refCode):
  self.data = None
  servRef = eServiceReference(refCode)
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFQhMf(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVt0M2(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVt0M2(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVt0M2(self.SYST, self.D_SYS_S)
     freq = self.VVt0M2(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVt0M2(self.POL , self.D_POL)
      fec = self.VVt0M2(self.FEC , self.D_FEC)
      sr = self.VVt0M2(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVPhtL(self, refCode):
  self.data = None
  self.VVFbj7(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCs3j1():
 def __init__(self, VVGpFM, path, VVzqy9=None, curRowNum=-1):
  self.VVGpFM  = VVGpFM
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVzqy9  = VVzqy9
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFdgmD("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVXDsM(curRowNum)
  else:
   FFGIBw(self.VVGpFM, "Error while preparing edit!")
 def VVXDsM(self, curRowNum):
  VVx2Uc = self.VVCjor()
  VVPAO4 = None #("Delete Line" , self.deleteLine  , [])
  VV4tKk = ("Save Changes" , self.VVD1YO   , [])
  VVuedc  = ("Edit Line"  , self.VVJ2p3    , [])
  VVMZtN = ("Line Options" , self.VV6YQb   , [])
  VVqeE2 = (""    , self.VVyBRM , [])
  VVO3oT = self.VVyq8e
  VVdowC  = self.VVs7fy
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVD84s  = (CENTER  , LEFT  )
  VV3o52 = FFp1uk(self.VVGpFM, None, title=self.Title, header=header, VVSmWK=VVx2Uc, VVD84s=VVD84s, VVO0tX=widths, VV715D=26, VVPAO4=VVPAO4, VV4tKk=VV4tKk, VVuedc=VVuedc, VVMZtN=VVMZtN, VVO3oT=VVO3oT, VVdowC=VVdowC, VVqeE2=VVqeE2, VVzUt6=True
    , VVdawd   = "#11001111"
    , VV2xlz   = "#11001111"
    , VVSwM6   = "#11001111"
    , VVb1yt  = "#05333333"
    , VVBWV3  = "#00222222"
    , VVYh87  = "#11331133"
    )
  VV3o52.VV6YEF(curRowNum)
 def VV6YQb(self, VV3o52, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VV3o52.VVt5sd()
  VVY2K2 = []
  VVY2K2.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVY2K2.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVVWAo"  ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVD5fX:
   VVY2K2.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(  ("Delete Line"         , "deleteLine"   ))
  FFlTf2(self.VVGpFM, boundFunction(self.VVdefY, VV3o52, lineNum), VVY2K2=VVY2K2, title="Line Options")
 def VVdefY(self, VV3o52, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVOqEE("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VV3o52)
   elif item == "VVVWAo"  : self.VVVWAo(VV3o52, lineNum)
   elif item == "copyToClipboard"  : self.VVjyRM(VV3o52, lineNum)
   elif item == "pasteFromClipboard" : self.VVMztd(VV3o52, lineNum)
   elif item == "deleteLine"   : self.VVOqEE("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VV3o52)
 def VVs7fy(self, VV3o52):
  VV3o52.VVO9Hu()
 def VVyBRM(self, VV3o52, title, txt, colList):
  if   self.insertMode == 1: VV3o52.VVDHrO()
  elif self.insertMode == 2: VV3o52.VVIB40()
  self.insertMode = 0
 def VVVWAo(self, VV3o52, lineNum):
  if lineNum == VV3o52.VVt5sd():
   self.insertMode = 1
   self.VVOqEE("echo '' >> '%s'" % self.tmpFile, VV3o52)
  else:
   self.insertMode = 2
   self.VVOqEE("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VV3o52)
 def VVjyRM(self, VV3o52, lineNum):
  global VVD5fX
  VVD5fX = FF3QAx("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VV3o52.VVSUkD("Copied to clipboard")
 def VVD1YO(self, VV3o52, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFdgmD("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFdgmD("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VV3o52.VVSUkD("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VV3o52.VVO9Hu()
    else:
     FFGIBw(self.VVGpFM, "Cannot save file!")
   else:
    FFGIBw(self.VVGpFM, "Cannot create backup copy of original file!")
 def VVyq8e(self, VV3o52):
  if self.fileChanged:
   FFhMkA(self.VVGpFM, boundFunction(self.VVONrq, VV3o52), "Cancel changes ?")
  else:
   finalOK = os.system(FFdgmD("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVONrq(VV3o52)
 def VVONrq(self, VV3o52):
  VV3o52.cancel()
  os.system(FFdgmD("rm -f '%s'" % self.tmpFile))
  if self.VVzqy9:
   self.VVzqy9(self.fileSaved)
 def VVJ2p3(self, VV3o52, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVYHoM + "ORIGINAL TEXT:\n" + VVPTHk + lineTxt
  FFwT6k(self.VVGpFM, boundFunction(self.VVJDe5, lineNum, VV3o52), title="File Line", defaultText=lineTxt, message=message)
 def VVJDe5(self, lineNum, VV3o52, VVL1IG):
  if not VVL1IG is None:
   if VV3o52.VVt5sd() <= 1:
    self.VVOqEE("echo %s > '%s'" % (VVL1IG, self.tmpFile), VV3o52)
   else:
    self.VVUiQ9(VV3o52, lineNum, VVL1IG)
 def VVMztd(self, VV3o52, lineNum):
  if lineNum == VV3o52.VVt5sd() and VV3o52.VVt5sd() == 1:
   self.VVOqEE("echo %s >> '%s'" % (VVD5fX, self.tmpFile), VV3o52)
  else:
   self.VVUiQ9(VV3o52, lineNum, VVD5fX)
 def VVUiQ9(self, VV3o52, lineNum, newTxt):
  VV3o52.VVxOlm("Saving ...")
  lines = FFrxQp(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VV3o52.VV08aL()
  VVx2Uc = self.VVCjor()
  VV3o52.VVnh9K(VVx2Uc)
 def VVOqEE(self, cmd, VV3o52):
  tCons = CCKt5L()
  tCons.ePopen(cmd, boundFunction(self.VViHkj, VV3o52))
  self.fileChanged = True
  VV3o52.VV08aL()
 def VViHkj(self, VV3o52, result, retval):
  VVx2Uc = self.VVCjor()
  VV3o52.VVnh9K(VVx2Uc)
 def VVCjor(self):
  if fileExists(self.tmpFile):
   lines = FFrxQp(self.tmpFile)
   VVx2Uc = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVx2Uc.append((str(ndx), line.strip()))
   if not VVx2Uc:
    VVx2Uc.append((str(1), ""))
   return VVx2Uc
  else:
   FFQ3EB(self.VVGpFM, self.tmpFile)
class CCD6d0():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVY2K2   = []
  self.satList   = []
 def VVeTEi(self, VVzqy9):
  self.VVY2K2 = []
  VVY2K2, VVz3Cn = self.VVs7tS(False, True)
  if VVY2K2:
   self.VVY2K2 += VVY2K2
   self.VVWuMH(VVzqy9, VVz3Cn)
 def VVOMlh(self, mode, VV3o52, satCol, VVzqy9):
  VV3o52.VVxOlm("Loading Filters ...")
  self.VVY2K2 = []
  self.VVY2K2.append(("All Services" , "all"))
  if mode == 1:
   self.VVY2K2.append(VV8PP6)
   self.VVY2K2.append(("Parental Control", "parentalControl"))
   self.VVY2K2.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVY2K2.append(VV8PP6)
   self.VVY2K2.append(("Selected Transponder"   , "selectedTP" ))
   self.VVY2K2.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVMyRK(VV3o52, satCol)
  VVY2K2, VVz3Cn = self.VVs7tS(True, False)
  if VVY2K2:
   VVY2K2.insert(0, VV8PP6)
   self.VVY2K2 += VVY2K2
  VV3o52.VVU8jU()
  self.VVWuMH(VVzqy9, VVz3Cn)
 def VV2X0u(self, VVY2K2, sats, VVzqy9):
  self.VVY2K2 = VVY2K2
  VVY2K2, VVz3Cn = self.VVs7tS(True, False)
  if VVY2K2:
   self.VVY2K2.append(VV8PP6)
   self.VVY2K2 += VVY2K2
  self.VVWuMH(VVzqy9, VVz3Cn)
 def VVPpX8(self, VVY2K2, sats, VVzqy9):
  self.VVY2K2 = VVY2K2
  VVY2K2, VVz3Cn = self.VVs7tS(True, False)
  if VVY2K2:
   self.VVY2K2.append(VV8PP6)
   self.VVY2K2 += VVY2K2
  self.VVWuMH(VVzqy9, VVz3Cn)
 def VVWuMH(self, VVzqy9, VVz3Cn):
  VVHN3c = ("Edit Filter", boundFunction(self.VVN860, VVz3Cn))
  VVfEjQ  = ("Filter Help", boundFunction(self.VV5MMZ, VVz3Cn))
  FFlTf2(self.callingSELF, boundFunction(self.VVPsf1, VVzqy9), VVY2K2=self.VVY2K2, title="Select Filter", VVHN3c=VVHN3c, VVfEjQ=VVfEjQ)
 def VVPsf1(self, VVzqy9, item):
  if item:
   VVzqy9(item)
 def VVN860(self, VVz3Cn, VVmQZXObj, sel):
  if fileExists(VVz3Cn) : CCs3j1(self.callingSELF, VVz3Cn, VVzqy9=None)
  else       : FFQ3EB(self.callingSELF, VVz3Cn)
  VVmQZXObj.cancel()
 def VV5MMZ(self, VVz3Cn, VVmQZXObj, sel):
  FFjWVm(self.callingSELF, VVCmbD + "_help_service_filter", "Service Filter")
 def VVMyRK(self, VV3o52, satColNum):
  if not self.satList:
   satList = VV3o52.VVcS0p(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFPQrv(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VV8PP6)
  if self.VVY2K2:
   self.VVY2K2 += self.satList
 def VVs7tS(self, addTag, VVA3IL):
  FF4CvA()
  fileName  = "ajpanel_services_filter"
  VVz3Cn = VVaZdT + fileName
  VVY2K2  = []
  if not fileExists(VVz3Cn):
   os.system(FFdgmD("cp -f '%s' '%s'" % (VVCmbD + fileName, VVz3Cn)))
  fileFound = False
  if fileExists(VVz3Cn):
   fileFound = True
   lines = FFrxQp(VVz3Cn)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVY2K2.append((line, "__w__" + line))
       else  : VVY2K2.append((line, line))
  if VVA3IL:
   if   not fileFound : FFQ3EB(self.callingSELF , VVz3Cn)
   elif not VVY2K2 : FFvbMM(self.callingSELF , VVz3Cn)
  return VVY2K2, VVz3Cn
 @staticmethod
 def VVGIe9(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CCZ5ac():
 def __init__(self, callingSELF, VV3o52, refCodeColNum):
  self.callingSELF = callingSELF
  self.VV3o52 = VV3o52
  self.refCodeColNum = refCodeColNum
  self.VVY2K2 = []
  iMulSel = self.VV3o52.VVNwNp()
  if iMulSel : self.VVY2K2.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVY2K2.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VV3o52.VVa4K4()
  self.VVY2K2.append(    ("Select all"    , "selectAll"  ))
  if tot > 0:
   self.VVY2K2.append(   ("Unselect all"    , "unselectAll"  ))
  self.VVY2K2.append(VV8PP6)
 def VV4V4u(self, servName, refCode):
  tot = self.VV3o52.VVa4K4()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVY2K2.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVgL5q_multi" ))
  else    : self.VVY2K2.append( ("Add to Bouquet : %s"      % servName , "VVgL5q_one" ))
  self.VVZ325(servName, refCode)
 def VVN7xP(self, servName, refCode, pcState, hidState):
  self.VVY2K2 = []
  if pcState == "No" : self.VVY2K2.append(("Add to Parental Control"  , "parentalControl_add"  ))
  else    : self.VVY2K2.append(("Remove from Parental Control" , "parentalControl_remove" ))
  if hidState == "No" : self.VVY2K2.append(("Add to Hidden Services"  , "hiddenServices_add"  ))
  else    : self.VVY2K2.append(("Remove from Hidden Services" , "hiddenServices_remove" ))
  self.VVZ325(servName, refCode)
 def VVZ325(self, servName, refCode):
  FFlTf2(self.callingSELF, boundFunction(self.VVtK29, servName, refCode), title="Options", VVY2K2=self.VVY2K2)
 def VVtK29(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"    : self.VV3o52.VVIsma(True)
   elif item == "MultSelDisab"    : self.VV3o52.VVIsma(False)
   elif item == "selectAll"    : self.VV3o52.VV14Uj()
   elif item == "unselectAll"    : self.VV3o52.VVHNeR()
   elif item == "parentalControl_add"  : self.callingSELF.VVzzZo(self.VV3o52, refCode, True)
   elif item == "parentalControl_remove" : self.callingSELF.VVzzZo(self.VV3o52, refCode, False)
   elif item == "hiddenServices_add"  : self.callingSELF.VVfcbw(self.VV3o52, refCode, True)
   elif item == "hiddenServices_remove" : self.callingSELF.VVfcbw(self.VV3o52, refCode, False)
   elif item == "VVgL5q_multi" : self.VVgL5q(refCode, True)
   elif item == "VVgL5q_one" : self.VVgL5q(refCode, False)
 def VVgL5q(self, refCode, isMulti):
  bouquets = FF8UC9()
  if bouquets:
   VVY2K2 = []
   for item in bouquets:
    VVY2K2.append((item[0], item[1].toString()))
   VVHN3c = ("Create New", boundFunction(self.VV785q, refCode, isMulti))
   FFlTf2(self.callingSELF, boundFunction(self.VVXDwU, refCode, isMulti), VVY2K2=VVY2K2, title="Add to Bouquet", VVHN3c=VVHN3c, VVTY2d=True, VVzTdE=True)
  else:
   FFhMkA(self.callingSELF, boundFunction(self.VVS4a4, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVXDwU(self, refCode, isMulti, bName=None):
  if bName:
   FFjQre(self.VV3o52, boundFunction(self.VVthFA, refCode, isMulti, bName), title="Adding Channels ...")
 def VVthFA(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVmqZa(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVG5iL = InfoBar.instance
    if VVG5iL:
     VVzmom = VVG5iL.servicelist
     if VVzmom:
      mutableList = VVzmom.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VV3o52.VVU8jU()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFrLx8(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FFGIBw(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVmqZa(self, refCode, isMulti):
  if isMulti : refCodeList = self.VV3o52.VVLUuL(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VV785q(self, refCode, isMulti, VVmQZXObj, path):
  self.VVS4a4(refCode, isMulti)
 def VVS4a4(self, refCode, isMulti):
  FFwT6k(self.callingSELF, boundFunction(self.VVE8rH, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVE8rH(self, refCode, isMulti, name):
  if name:
   FFjQre(self.VV3o52, boundFunction(self.VVo5t3, refCode, isMulti, name), title="Adding Channels ...")
 def VVo5t3(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVmqZa(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVG5iL = InfoBar.instance
    if VVG5iL:
     VVzmom = VVG5iL.servicelist
     if VVzmom:
      try:
       VVzmom.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVzmom.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VV3o52.VVU8jU()
   title = "Add to Bouquet"
   if allOK: FFrLx8(self.callingSELF, "Added to : %s" % name, title=title)
   else : FFGIBw(self.callingSELF, "Nothing added!", title=title)
class CCQq4F(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFdxjB(VVuN0K, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFSskZ(self)
  FFkqlb(self["keyRed"]  , "Exit")
  FFkqlb(self["keyGreen"]  , "Save")
  FFkqlb(self["keyYellow"] , "Refresh")
  FFkqlb(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVdmcd  ,
   "green"   : self.VVi9gb ,
   "yellow"  : self.VVIpDa  ,
   "blue"   : self.VVFQOa   ,
   "up"   : self.VVq2Fv    ,
   "down"   : self.VVTlAE   ,
   "left"   : self.VVVkoz   ,
   "right"   : self.VV07jt   ,
   "cancel"  : self.VVdmcd
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVIpDa()
  self.VVH5ui()
  FF65Ci(self)
 def VVdmcd(self) : self.close(True)
 def VVz7hm(self) : self.close(False)
 def VVFQOa(self):
  self.session.openWithCallback(self.VVXdvj, boundFunction(CCQHwi))
 def VVXdvj(self, closeAll):
  if closeAll:
   self.close()
 def VVq2Fv(self):
  self.VVQ1TK(1)
 def VVTlAE(self):
  self.VVQ1TK(-1)
 def VVVkoz(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVH5ui()
 def VV07jt(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVH5ui()
 def VVQ1TK(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVCBAW(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVCBAW(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVCBAW(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVcdrj(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVcdrj(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVH5ui(self):
  for obj in self.list:
   FFidK4(obj, "#11404040")
  FFidK4(self.list[self.index], "#11ff8000")
 def VVIpDa(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVi9gb(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCKt5L()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVIVoL)
 def VVIVoL(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFrLx8(self, "Nothing returned from the system!")
  else:
   FFrLx8(self, str(result))
class CCQHwi(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFdxjB(VVdxXE, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFSskZ(self, addLabel=True)
  FFkqlb(self["keyRed"]  , "Exit")
  FFkqlb(self["keyGreen"]  , "Sync")
  FFkqlb(self["keyYellow"] , "Refresh")
  FFkqlb(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVdmcd   ,
   "green"   : self.VVtYj5  ,
   "yellow"  : self.VVtEc9 ,
   "blue"   : self.VVKSFR  ,
   "cancel"  : self.VVdmcd
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVkaIt()
  self.onShow.append(self.start)
 def start(self):
  FFo2XQ(self.refresh)
  FF65Ci(self)
 def refresh(self):
  self.VVJfWB()
  self.VV85Fq(False)
 def VVdmcd(self)  : self.close(True)
 def VVKSFR(self) : self.close(False)
 def VVkaIt(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVJfWB(self):
  self.VVdbJG()
  self.VV9kaQ()
  self.VVG2hP()
  self.VVPSwL()
 def VVtEc9(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVkaIt()
   self.VVJfWB()
   FFo2XQ(self.refresh)
 def VVtYj5(self):
  if len(self["keyGreen"].getText()) > 0:
   FFhMkA(self, self.VVWCS8, "Synchronize with Internet Date/Time ?")
 def VVWCS8(self):
  self.VVJfWB()
  FFo2XQ(boundFunction(self.VV85Fq, True))
 def VVdbJG(self)  : self["keyRed"].show()
 def VVPuqi(self)  : self["keyGreen"].show()
 def VVdhnf(self) : self["keyYellow"].show()
 def VV48PN(self)  : self["keyBlue"].show()
 def VV9kaQ(self)  : self["keyGreen"].hide()
 def VVG2hP(self) : self["keyYellow"].hide()
 def VVPSwL(self)  : self["keyBlue"].hide()
 def VV85Fq(self, sync):
  localTime = FFsPaE()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VV5PrW(server)
   if epoch_time is not None:
    ntpTime = FFXzY3(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCKt5L()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVIVoL, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVdhnf()
  self.VV48PN()
  if ok:
   self.VVPuqi()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVIVoL(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VV85Fq(False)
  except:
   pass
 def VV5PrW(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFje6c():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCBzmY(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFdxjB(VV6Mem, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFSskZ(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  FFo2XQ(self.VVXKdw)
 def VVXKdw(self):
  if FFje6c(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFidK4(self["myBody"], color)
   FFidK4(self["myLabel"], color)
  except:
   pass
class CCr7D5(Screen):
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FF5zEi()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFdxjB(VVN2xn, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CC6GuO(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CC6GuO(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CC6GuO(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCiLKR()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFSskZ(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVq2Fv          ,
   "down"  : self.VVTlAE         ,
   "left"  : self.VVVkoz         ,
   "right"  : self.VV07jt         ,
   "info"  : self.VVpOpN        ,
   "epg"  : self.VVpOpN        ,
   "menu"  : self.VVEOst         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "last"  : boundFunction(self.VV2dzk, -1)  ,
   "next"  : boundFunction(self.VV2dzk, 1)  ,
   "pageUp" : boundFunction(self.VVaHPf, True) ,
   "chanUp" : boundFunction(self.VVaHPf, True) ,
   "pageDown" : boundFunction(self.VVaHPf, False) ,
   "chanDown" : boundFunction(self.VVaHPf, False) ,
   "0"   : boundFunction(self.VV2dzk, 0)  ,
   "1"   : boundFunction(self.VVgaFV, pos=1) ,
   "2"   : boundFunction(self.VVgaFV, pos=2) ,
   "3"   : boundFunction(self.VVgaFV, pos=3) ,
   "4"   : boundFunction(self.VVgaFV, pos=4) ,
   "5"   : boundFunction(self.VVgaFV, pos=5) ,
   "6"   : boundFunction(self.VVgaFV, pos=6) ,
   "7"   : boundFunction(self.VVgaFV, pos=7) ,
   "8"   : boundFunction(self.VVgaFV, pos=8) ,
   "9"   : boundFunction(self.VVgaFV, pos=9) ,
  }, -1)
  self.onShown.append(self.VVJId3)
  self.onClose.append(self.onExit)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  self.sliderSNR.VV8dMv()
  self.sliderAGC.VV8dMv()
  self.sliderBER.VV8dMv(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVgaFV()
  self.VVTsb2Info()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVTsb2)
  except:
   self.timer.callback.append(self.VVTsb2)
  self.timer.start(500, False)
 def VVTsb2Info(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VV7JG8(service)
  serviceName = self.tunerInfo.VV41QR()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFlPZP(self)
  tp = CC8VoG()
  txt = tp.VVvbUZ(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVTsb2(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VV7JG8(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VV69En())
   self["mySNR"].setText(self.tunerInfo.VVPVTR())
   self["myAGC"].setText(self.tunerInfo.VVFZeH())
   self["myBER"].setText(self.tunerInfo.VVnFlK())
   self.sliderSNR.VV4c32(self.tunerInfo.VVkYdd())
   self.sliderAGC.VV4c32(self.tunerInfo.VVCYYN())
   self.sliderBER.VV4c32(self.tunerInfo.VVQzys())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VV4c32(0)
   self.sliderAGC.VV4c32(0)
   self.sliderBER.VV4c32(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFlPZP(self)
    if state and not state == "Tuned":
     FF3ty7(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVpOpN(self):
  FFzRsg(self, fncMode=CCf574.VVSOLR)
 def VVEOst(self):
  FFjWVm(self, VVCmbD + "_help_signal", "Signal Monitor (Keys)")
 def VVq2Fv(self)  : self.VVgaFV(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVTlAE(self) : self.VVgaFV(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVVkoz(self) : self.VVgaFV(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VV07jt(self) : self.VVgaFV(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVgaFV(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VV2dzk(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFS6MX(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVaHPf(self, isUp):
  FF3ty7(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVTsb2Info()
  except:
   pass
class CC6GuO(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VV8dMv(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFidK4(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVCmbD +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFidK4(self.covObj, self.covColor)
   else:
    FFidK4(self.covObj, "#00006688")
    self.isColormode = True
  self.VV4c32(0)
 def VV4c32(self, val):
  val  = FFS6MX(val, self.minN, self.maxN)
  width = int(FFqKBE(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFS6MX(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCvPFp(Screen):
 VVR24C    = 0
 VV4LTD = 1
 VVSLuW = 2
 VVGS5G  = 3
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVzqy9=None, barTheme=VVR24C):
  ratio = self.VVXg5W(barTheme)
  self.skin, self.skinParam = FFdxjB(VVGuYX, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVzqy9 = VVzqy9
  self.isCancelled = False
  self.isError  = False
  self.curValue  = 0
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VV5404 = None
  self.timer   = eTimer()
  self.myThread  = None
  FFSskZ(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVJId3)
  self.onClose.append(self.onExit)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  self.VVnyid()
  self["myProgBarVal"].setText("0%")
  FFidK4(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVJYgf()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVJYgf)
  except:
   self.timer.callback.append(self.VVJYgf)
  self.timer.start(300, False)
  from threading import Thread as iThread
  self.myThread = iThread(name="threadFnc", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def onExit(self):
  self.timer.stop()
 def VVzcj3(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVAsDB_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VV5404), self.counter, self.maxValue, catName)
 def VVAsDB_fromImportEPG(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVoDTW(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VV5404), self.counter, self.maxValue)
  except:
   pass
 def VVOD8l(self):
  self.isError = True
  self.cancel()
 def cancel(self):
  FF3ty7(self, "Cancelling ...")
  self.isCancelled = True
  if self.VVzqy9:
   self.VVzqy9(False, self.VV5404, self.counter, self.maxValue, self.isError)
  self.close()
 def VVJYgf(self):
  val = FFS6MX(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFqKBE(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if self.VVzqy9 and not self.isCancelled:
    self.VVzqy9(True, self.VV5404, self.counter, self.maxValue, self.isError)
   self.close()
 def VVnyid(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VV4LTD, self.VVGS5G):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
  elif self.barTheme == self.VVSLuW:
   pass
 def VVXg5W(self, barTheme):
  if   barTheme == self.VV4LTD : return 0.7
  elif barTheme == self.VVSLuW : return 1
  elif barTheme == self.VVGS5G  : return 0.7
  else              : return 1
class CCKt5L(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVzqy9 = {}
  self.commandRunning = False
  self.VV49od  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVzqy9, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVzqy9[name] = VVzqy9
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VV49od:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVT1p9, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVKxEj , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVT1p9, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVKxEj , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVKxEj(name, retval)
  return True
 def VVT1p9(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVKxEj(self, name, retval):
  if not self.VV49od:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVzqy9[name]:
   self.VVzqy9[name](self.appResults[name], retval)
  del self.VVzqy9[name]
 def VVKIw8(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CC96KM(Screen):
 def __init__(self, session, title="", VVrfZj=None, VVlzOH=False, VVBUWp=False, VV4aBN=False, VVnZoU=False, VVkCgR=False, VVe1SL=False, VV51s0=VVbrHn, VVB9mM=None, VVGG3k=False, VVN4E2=None, VVMzQ2="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFdxjB(VVI3k3, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFSskZ(self, addScrollLabel=True)
  if not VVMzQ2:
   VVMzQ2 = "Processing ..."
  self["myLabel"].setText("   %s" % VVMzQ2)
  self.VVlzOH   = VVlzOH
  self.VVBUWp   = VVBUWp
  self.VV4aBN   = VV4aBN
  self.VVnZoU  = VVnZoU
  self.VVkCgR = VVkCgR
  self.VVe1SL = VVe1SL
  self.VV51s0   = VV51s0
  self.VVB9mM = VVB9mM
  self.VVGG3k  = VVGG3k
  self.VVN4E2  = VVN4E2
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCKt5L()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FF39sf()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVrfZj, str):
   self.VVrfZj = [VVrfZj]
  else:
   self.VVrfZj = VVrfZj
  if self.VV4aBN or self.VVnZoU:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VV1xmU, VV1xmU)
   self.VVrfZj.append("echo -e '\n%s\n' %s" % (restartNote, FFAawR(restartNote, VVclxO)))
   if self.VV4aBN:
    self.VVrfZj.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVrfZj.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVkCgR:
   FF3ty7(self, "Processing ...")
  self.onLayoutFinish.append(self.VVb4lY)
  self.onClose.append(self.VVnoIl)
 def VVb4lY(self):
  self["myLabel"].VVwJt1(textOutFile="console" if self.enableSaveRes else "")
  if self.VVlzOH:
   self["myLabel"].VVhchq()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVtuBQ()
  else:
   self.VVUz6q()
 def VVtuBQ(self):
  if FFje6c():
   self["myLabel"].setText("Processing ...")
   self.VVUz6q()
  else:
   self["myLabel"].setText(FFARnG("\n   No connection to internet!", VVEAFU))
 def VVUz6q(self):
  allOK = self.container.ePopen(self.VVrfZj[0], self.VVkfEL, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVkfEL("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVe1SL or self.VV4aBN or self.VVnZoU:
    self["myLabel"].setText(FFmLFC("STARTED", VVclxO) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVN4E2:
   colorWhite = CC1Ai0.VV33nE(VVYHoM)
   color  = CC1Ai0.VV33nE(self.VVN4E2[0])
   words  = self.VVN4E2[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VV51s0=self.VV51s0)
 def VVkfEL(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVrfZj):
   allOK = self.container.ePopen(self.VVrfZj[self.cmdNum], self.VVkfEL, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVkfEL("Cannot connect to Console!", -1)
  else:
   if self.VVkCgR and FFTgC4(self):
    FF3ty7(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVe1SL:
    self["myLabel"].appendText("\n" + FFmLFC("FINISHED", VVclxO), self.VV51s0)
   if self.VVlzOH or self.VVBUWp:
    self["myLabel"].VVhchq()
   if self.VVB9mM is not None:
    self.VVB9mM()
   if not retval and self.VVGG3k:
    self.VVnoIl()
 def VVnoIl(self):
  if self.container.VVKIw8():
   self.container.killAll()
class CCjVWP(Screen):
 def __init__(self, session, VVrfZj=None, VVkCgR=False):
  self.skin, self.skinParam = FFdxjB(VVI3k3, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVaZdT + "ajpanel_terminal.history"
  self.customCommandsFile = VVaZdT + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FF3QAx("pwd") or "/home/root"
  self.container   = CCKt5L()
  FFSskZ(self, addScrollLabel=True)
  FFkqlb(self["keyRed"] , "Exit = Stop Command")
  FFkqlb(self["keyGreen"] , "OK = History")
  FFkqlb(self["keyYellow"], "Menu = Custom Cmds")
  FFkqlb(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVguAr ,
   "cancel" : self.VVIzzX  ,
   "menu"  : self.VV7Kz7 ,
   "last"  : self.VVYCwC  ,
   "next"  : self.VVYCwC  ,
   "1"   : self.VVYCwC  ,
   "2"   : self.VVYCwC  ,
   "3"   : self.VVYCwC  ,
   "4"   : self.VVYCwC  ,
   "5"   : self.VVYCwC  ,
   "6"   : self.VVYCwC  ,
   "7"   : self.VVYCwC  ,
   "8"   : self.VVYCwC  ,
   "9"   : self.VVYCwC  ,
   "0"   : self.VVYCwC
  })
  self.onLayoutFinish.append(self.VVJId3)
  self.onClose.append(self.VVyNnN)
 def VVJId3(self):
  self["myLabel"].VVwJt1(isResizable=False, textOutFile="terminal")
  FFRivu(self["keyRed"]  , "#00ff8000")
  FFidK4(self["keyRed"]  , self.skinParam["titleColor"])
  FFidK4(self["keyGreen"]  , self.skinParam["titleColor"])
  FFidK4(self["keyYellow"] , self.skinParam["titleColor"])
  FFidK4(self["keyBlue"] , self.skinParam["titleColor"])
  self.VV7LUQ(FF3QAx("date"), 5)
  result = FF3QAx("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVs7hR()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVCmbD + "LinuxCommands.lst"
   newTemplate = VVCmbD + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFdgmD("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFdgmD("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVyNnN(self):
  if self.container.VVKIw8():
   self.container.killAll()
   self.VV7LUQ("Process killed\n", 4)
   self.VVs7hR()
 def VVIzzX(self):
  if self.container.VVKIw8():
   self.VVyNnN()
  else:
   FFhMkA(self, self.close, "Exit ?", VV5nZq=False)
 def VVs7hR(self):
  self.VV7LUQ(self.prompt, 1)
  self["keyRed"].hide()
 def VV7LUQ(self, txt, mode):
  if   mode == 1 : color = VVclxO
  elif mode == 2 : color = VVylYU
  elif mode == 3 : color = VVYHoM
  elif mode == 4 : color = VVEAFU
  elif mode == 5 : color = VVPTHk
  elif mode == 6 : color = VVcwMp
  else   : color = VVYHoM
  try:
   self["myLabel"].appendText(FFARnG(txt, color))
  except:
   pass
 def VVfBNW(self, cmd):
  self["keyRed"].show()
  cmd = cmd.strip()
  if "#" in cmd:
   parts = cmd.split("#")
   left  = FFARnG(parts[0].strip(), VVylYU)
   right = FFARnG("#" + parts[1].strip(), VVcwMp)
   txt = "%s    %s\n" % (left, right)
  else:
   txt = "%s\n" % cmd
  self.VV7LUQ(txt, 2)
  lastLine = self.VV4jS6()
  if not lastLine or not cmd == lastLine:
   self.lastCommand = cmd
   self.VV6CmM(cmd)
  span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
  if span:
   self.curDir = span.group(1)
  allOK = self.container.ePopen(cmd, self.VVkfEL, dataAvailFnc=self.dataAvail, curDir=self.curDir)
  if not allOK:
   FFGIBw(self, "Cannot connect to Console!")
  self.lastCommand = cmd
 def dataAvail(self, data):
  self.VV7LUQ(data, 3)
 def VVkfEL(self, data, retval):
  if not retval == 0:
   self.VV7LUQ("Exit Code : %d\n" % retval, 4)
  self.VVs7hR()
 def VVguAr(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VV4jS6() == "":
   self.VV6CmM("cd /tmp")
   self.VV6CmM("ls")
  VVx2Uc = []
  if fileExists(self.commandHistoryFile):
   lines  = FFrxQp(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVx2Uc.append((str(c), line, str(lNum)))
   self.VVzn6e(VVx2Uc, title, self.commandHistoryFile, isHistory=True)
  else:
   FFQ3EB(self, self.commandHistoryFile, title=title)
 def VV4jS6(self):
  lastLine = FF3QAx("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VV6CmM(self, cmd):
  os.system("echo '%s' >> %s" % (cmd, self.commandHistoryFile))
 def VV7Kz7(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFrxQp(self.customCommandsFile)
   lastLineIsSep = False
   VVx2Uc = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVx2Uc.append((str(c), line, str(lNum)))
   self.VVzn6e(VVx2Uc, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFQ3EB(self, self.customCommandsFile, title=title)
 def VVzn6e(self, VVx2Uc, title, filePath=None, isHistory=False):
  if VVx2Uc:
   VVb1yt = "#05333333"
   if isHistory: VVdawd = VV2xlz = VVSwM6 = "#11000020"
   else  : VVdawd = VV2xlz = VVSwM6 = "#06002020"
   VVBoAr = VVMZtN = None
   VVuedc   = ("Send"   , self.VVsaVR        , [])
   VV4tKk  = ("Modify & Send" , self.VVYHqj        , [])
   if isHistory:
    VVBoAr = ("Clear History" , self.VVEtC2        , [])
   elif filePath:
    VVMZtN = ("Edit File"  , boundFunction(self.VVytMh, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVD84s     = (CENTER  , LEFT   , CENTER )
   FFp1uk(self, None, title=title, header=header, VVSmWK=VVx2Uc, VVD84s=VVD84s, VVO0tX=widths, VV715D=26, VVuedc=VVuedc, VV4tKk=VV4tKk, VVBoAr=VVBoAr, VVMZtN=VVMZtN, VVzUt6=True
     , VVdawd   = VVdawd
     , VV2xlz   = VV2xlz
     , VVSwM6   = VVSwM6
     , VVYYmR  = "#05ffff00"
     , VVb1yt  = VVb1yt
    )
  else:
   FFvbMM(self, filePath, title=title)
 def VVsaVR(self, VV3o52, title, txt, colList):
  cmd = colList[1].strip()
  VV3o52.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VV7LUQ("\n%s\n" % cmd, 6)
   self.VV7LUQ(self.prompt, 1)
  else:
   if cmd.startswith("passwd"):
    self.VV7LUQ(cmd, 2)
    self.VV7LUQ("\nCannot change passwrod from Console this way. Try using:\n", 4)
    txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
    for ch in txt:
     if not ch == "#":
      self.VV7LUQ(ch, 0)
    self.VV7LUQ("\nor\n", 4)
    self.VV7LUQ("echo root:NEW_PASSWORD | chpasswd\n", 0)
    self.VVs7hR()
   else:
    self.VVfBNW(cmd)
 def VVYHqj(self, VV3o52, title, txt, colList):
  cmd = colList[1]
  self.VV4CCA(VV3o52, cmd)
 def VVEtC2(self, VV3o52, title, txt, colList):
  FFhMkA(self, boundFunction(self.VVKkrj, VV3o52), "Reset History File ?", title="Command History")
 def VVKkrj(self, VV3o52):
  os.system(FFdgmD("echo '' > %s" % self.commandHistoryFile))
  VV3o52.cancel()
 def VVytMh(self, filePath, VV3o52, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCs3j1(self, filePath, VVzqy9=boundFunction(self.VVVwyy, VV3o52), curRowNum=rowNum)
  else     : FFQ3EB(self, filePath)
 def VVVwyy(self, VV3o52, fileChanged):
  if fileChanged:
   VV3o52.cancel()
   FFo2XQ(self.VV7Kz7)
 def VVYCwC(self):
  self.VV4CCA(None, self.lastCommand)
 def VV4CCA(self, VV3o52, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFwT6k(self, boundFunction(self.VVLTL1, VV3o52), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVLTL1(self, VV3o52, cmd):
  if cmd and len(cmd) > 0:
   self.VVfBNW(cmd)
   if VV3o52:
    VV3o52.cancel()
class CC6h6M(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVL1IG="", VVDnpG=False, VVlS1B=False, isTrimEnds=True):
  self.skin, self.skinParam = FFdxjB(VV3lRK, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFSskZ(self, title, addLabel=True)
  FFkqlb(self["keyRed"] , "Up/Down = Change")
  FFkqlb(self["keyGreen"] , "Overwrite")
  FFkqlb(self["keyYellow"], "Pick Key Map")
  FFkqlb(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVlS1B   = VVlS1B
  self.VVDnpG  = VVDnpG
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVL1IG, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VV4fXm      ,
   "green"    : self.VVkvaH    ,
   "yellow"   : self.VVfeh5      ,
   "blue"    : self.VVa2qG     ,
   "menu"    : self.VVWHPz     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVjGCn, True) ,
   "down"    : boundFunction(self.VVjGCn, False) ,
   "left"    : self.VVFy9W       ,
   "right"    : self.VVOZlZ       ,
   "home"    : self.VV94bD       ,
   "end"    : self.VV8Bcs       ,
   "next"    : self.VV3hHh      ,
   "last"    : self.VV8WnJ      ,
   "deleteForward"  : self.VV3hHh      ,
   "deleteBackward" : self.VV8WnJ      ,
   "tab"    : self.VVWzrK       ,
   "toggleOverwrite" : self.VVkvaH    ,
   "0"     : self.VVVp2D     ,
   "1"     : self.VVVp2D     ,
   "2"     : self.VVVp2D     ,
   "3"     : self.VVVp2D     ,
   "4"     : self.VVVp2D     ,
   "5"     : self.VVVp2D     ,
   "6"     : self.VVVp2D     ,
   "7"     : self.VVVp2D     ,
   "8"     : self.VVVp2D     ,
   "9"     : self.VVVp2D
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVyv9L()
  self.onShown.append(self.VVJId3)
  self.onClose.append(self.onExit)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  self["myLabel"].setText(self.message)
  self.VVhuSW()
  if self.VVDnpG : self.VVkvaH()
  else    : self.VVDoOh()
  FF65Ci(self)
  FFidK4(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV69Ei)
  except:
   self.timer.callback.append(self.VV69Ei)
 def onExit(self):
  self.timer.stop()
 def VV4fXm(self):
  self.VV0Kj1()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VV0Kj1()
  self.close(None)
 def VVWHPz(self):
  VVY2K2 = []
  VVY2K2.append(("Home"         , "home"    ))
  VVY2K2.append(("End"         , "end"     ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Clear All"       , "clearAll"   ))
  VVY2K2.append(("Clear To Home"      , "clearToHome"   ))
  VVY2K2.append(("Clear To End"       , "clearToEnd"   ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVD5fX:
   VVY2K2.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("To Capital Letters"     , "toCapital"   ))
  VVY2K2.append(("To Small Letters"      , "toSmall"    ))
  FFlTf2(self, self.VVY7ZJ, title="Edit Options", VVY2K2=VVY2K2)
 def VVY7ZJ(self, item=None):
  if item is not None:
   if   item == "home"     : self.VV94bD()
   elif item == "end"     : self.VV8Bcs()
   elif item == "clearAll"    : self.VVngUv()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VV94bD()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVD5fX
    VVD5fX = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVD5fX)
    self.VV94bD()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VV69Ei(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVkvaH(self):
  self["myInput"].toggleOverwrite()
  self.VVDoOh()
 def VVfeh5(self):
  self.session.openWithCallback(self.VVWDV4, boundFunction(CCGi8c, mode=self.charMode, VVlS1B=self.VVlS1B))
 def VVWDV4(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVhuSW()
 def VVDoOh(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVyv9L(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VV0Kj1(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VV3CN4(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVFy9W(self)     : self.VVHMyJ(self["myInput"].left)
 def VVOZlZ(self)     : self.VVHMyJ(self["myInput"].right)
 def VV3hHh(self)     : self.VVHMyJ(self["myInput"].delete)
 def VV94bD(self)     : self.VVHMyJ(self["myInput"].home)
 def VV8Bcs(self)     : self.VVHMyJ(self["myInput"].end)
 def VV8WnJ(self)    : self.VVHMyJ(self["myInput"].deleteBackward)
 def VVWzrK(self)     : self.VVHMyJ(self["myInput"].tab)
 def VVngUv(self)     : self["myInput"].setText("")
 def VVHMyJ(self, fnc):
  fnc()
  self.VV69Ei()
 def VVVp2D(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VV3CN4(newChar, overwrite)
   self.VV3xDY(newChar, self["myInput"].mapping[number])
 def VVjGCn(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCGi8c.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCGi8c.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VV3CN4(newChar, True)
   for group in groups:
    if newChar in group:
     self.VV3xDY(newChar, group)
     break
 def VV3xDY(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVYHoM:
    group = VVPTHk + group.replace(newChar, FFARnG(newChar, VVYHoM, VVPTHk))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVa2qG(self):
  if self.VVlS1B : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVhuSW()
 def VVhuSW(self):
  self["myInput"].mapping = CCGi8c.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCGi8c.RCU_MAP_TITLES[self.charMode])
class CCGi8c(Screen):
 VVjetz  = 0
 VVyqeG  = 1
 VVWb5W  = 2
 VVcwtP  = 3
 VVICmf = 4
 VVGyu8 = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols, arabic_nums1, arabic1)
       , ( symbols, arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A" , u"\u0628")
       , (u"\u0647" , u"\u062A")
       )
 def __init__(self, session, mode=VVjetz, VVlS1B=False):
  self.skin, self.skinParam = FFdxjB(VVOZNr, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVlS1B  = VVlS1B
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFSskZ(self, title=self.Title)
  FFkqlb(self["keyRed"] ,"OK = Select")
  FFkqlb(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVAePW     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVgUNO, -1) ,
   "next"  : boundFunction(self.VVgUNO, +1) ,
   "left"  : boundFunction(self.VVgUNO, -1) ,
   "right"  : boundFunction(self.VVgUNO, +1) ,
  }, -1)
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  FFidK4(self["keyRed"], "#11222222")
  FFidK4(self["keyGreen"], "#11222222")
  self.VVy11z()
 def VVy11z(self):
  self.VV1Yao()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VV1Yao(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVgUNO(self, direction):
  if self.VVlS1B : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVy11z()
 def VVAePW(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCRH5K(Screen):
 def __init__(self, session, title="", message="", VV51s0=VVbrHn, VVug7i=False, VVSwM6=None, VV715D=30):
  self.skin, self.skinParam = FFdxjB(VVI3k3, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VV715D)
  self.session   = session
  FFSskZ(self, title, addScrollLabel=True)
  self.VV51s0   = VV51s0
  self.VVug7i   = VVug7i
  self.VVSwM6   = VVSwM6
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  self["myLabel"].VVwJt1(VVug7i=self.VVug7i)
  self["myLabel"].setText(self.message, self.VV51s0)
  if self.VVSwM6:
   FFidK4(self["myBody"], self.VVSwM6)
   FFidK4(self["myLabel"], self.VVSwM6)
   FFy83Z(self["myLabel"], self.VVSwM6)
  self["myLabel"].VVhchq()
class CCkCQ6(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFdxjB(VVZ2Wm, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFSskZ(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  path = VVCmbD + "err.png"
  if fileExists(path):
   self["errPic"].instance.setScale(1)
   self["errPic"].instance.setPixmapFromFile(path)
class CCpspP(Screen, CCUbe9):
 PLAYER_INSTANCE = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False):
  self.skin, self.skinParam = FFdxjB(VVkvWJ, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCUbe9.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  FFSskZ(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVZNh0())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVtv5z         ,
   "info"  : self.VVpOpN        ,
   "epg"  : self.VVpOpN        ,
   "menu"  : self.FFlTf2         ,
   "cancel" : self.cancel         ,
   "red"  : self.VVsn6C        ,
   "blue"  : self.VVlEbx        ,
   "green"  : boundFunction(self.VV8lYq, True),
   "yellow" : self.VVXcnN   ,
   "left"  : boundFunction(self.VVnWMG, -1)   ,
   "right"  : boundFunction(self.VVnWMG,  1)   ,
   "play"  : self.VVsn6C        ,
   "pause"  : self.VVsn6C        ,
   "playPause" : self.VVsn6C        ,
   "stop"  : self.VVsn6C        ,
   "rewind" : self.VVA7a4        ,
   "forward" : self.VVq7NG        ,
   "rewindDm" : self.VVA7a4        ,
   "forwardDm" : self.VVq7NG        ,
   "last"  : boundFunction(self.VVaKZk, 0)    ,
   "next"  : self.VVzEv1        ,
   "pageUp" : boundFunction(self.VVe1Vh, True) ,
   "pageDown" : boundFunction(self.VVe1Vh, False) ,
   "chanUp" : boundFunction(self.VVe1Vh, True) ,
   "chanDown" : boundFunction(self.VVe1Vh, False) ,
   "up"  : boundFunction(self.VVe1Vh, True) ,
   "down"  : boundFunction(self.VVe1Vh, False) ,
   "0"   : boundFunction(self.VVZi8M , 10)  ,
   "1"   : boundFunction(self.VVZi8M , 1)  ,
   "2"   : boundFunction(self.VVZi8M , 2)  ,
   "3"   : boundFunction(self.VVZi8M , 3)  ,
   "4"   : boundFunction(self.VVZi8M , 4)  ,
   "5"   : boundFunction(self.VVZi8M , 5)  ,
   "6"   : boundFunction(self.VVZi8M , 6)  ,
   "7"   : boundFunction(self.VVZi8M , 7)  ,
   "8"   : boundFunction(self.VVZi8M , 8)  ,
   "9"   : boundFunction(self.VVZi8M , 9)
  }, -1)
  self.onShown.append(self.VVJId3)
  self.onClose.append(self.onExit)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  if not CCpspP.PLAYER_INSTANCE or self.portalTableParam:
   CCpspP.PLAYER_INSTANCE = self
  else:
   self.close()
  self.VVlRz2()
  self.instance.move(ePoint(40, 40))
  self.VVjfQo(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVookt)
  except:
   self.timer.callback.append(self.VVookt)
  self.timer.start(250, False)
  self.VVookt("Checking ...")
  self.VV8lYq()
 def onExit(self):
  self.timer.stop()
  CCpspP.PLAYER_INSTANCE = None
 def VVlRz2(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFlPZP(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl:
   color = "#1120002a"
   self["myPlayGrn"].show()
  else:
   color = "#1100202a"
   self["myPlayGrn"].hide()
  FFidK4(self["myTitle"], color)
 def FFlTf2(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFlPZP(self)
  VVY2K2 = []
  if self.isFromExternal:
   VVY2K2.append(("IPTV Menu"    , "iptv" ))
   VVY2K2.append(VV8PP6)
  if FFRlBi(iptvRef) and not "&end=" in decodedUrl and not any(x in decodedUrl for x in ("/movie/", "/series/")):
   uType, uHost, uUser, uPass, uId, uChName = CCfvbT.VV1Nl0(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVY2K2.append(("Catchup Programs"  , "catchup" ))
    VVY2K2.append(VV8PP6)
  VVY2K2.append(("Stop Current Service"   , "stop" ))
  if not "&end=" in decodedUrl:
   VVY2K2.append(("Restart Current Service" , "restart" ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Move to Top"     , "top"  ))
  VVY2K2.append(("Move to Bottom"    , "botm" ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Help"       , "help" ))
  FFlTf2(self, self.VVvDPN, VVY2K2=VVY2K2, width=550, title="Options")
 def VVvDPN(self, item=None):
  if item:
   if item == "iptv"  :
    self.session.open(CCfvbT)
    self.close()
   elif item == "catchup" : self.VVXcnN()
   elif item == "stop"  : self.VV0mbt(0)
   elif item == "restart" : self.VV0mbt(1)
   elif item == "botm"  : self.VVjfQo(0)
   elif item == "top"  : self.VVjfQo(1)
   elif item == "help"  : FFjWVm(self, VVCmbD + "_help_player", "Player Controller (Keys)")
 def VV0mbt(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.close()
   elif typ == 1:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
 def VVjfQo(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VVtv5z(self):
  if self.isManualSeek:
   self.VVZrNt()
   self.VVaKZk(self.manualSeekPts)
  else:
   if self.shown: self.hide()
   else   : self.show()
 def cancel(self):
  if self.isManualSeek:
   self.VVZrNt()
  else:
   self.close()
 def VVpOpN(self):
  FFzRsg(self, fncMode=CCf574.VViYuI)
 def VVsn6C(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
   inst.playpauseStreamService()
  except Exception as e:
   pass
  self.VVookt("Toggling Play/Pause ...")
 def VVZrNt(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVnWMG(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVVQgz()
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.jumpMinutes * 60.0
   else:
    self.manualSeekSec += direc * self.jumpMinutes * 60.0
    self.manualSeekSec = FFS6MX(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFqKBE(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFBS4u(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVZi8M(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   FFkqlb(self["myPlayJmp"], self.VVZNh0())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVookt("Changed Jump Minutes to : %d" % val)
 def VVZNh0(self):
  return "Jump:%dm" % self.jumpMinutes
 def VVookt(self, stateTxt=""):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFlPZP(self)
  fr = res = ""
  if info:
   w = FFzECc(info, iServiceInformation.sVideoWidth) or -1
   h = FFzECc(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFzECc(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CCf574.VVRDJC(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVVQgz()
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FFS6MX(percVal, 0, 100)
    width = int(FFqKBE(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   FFRivu(self["myPlayMsg"], "#00ff8066")
   self["myPlayMsg"].setText("-" if decodedUrl else FFXnj4(refCode, True))
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not durTxt:
   self["myPlayVal"].setText(">>>>>")
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText(prov)
  if not posTxt:
   self["myPlayPos"].setText("")
  if not remTxt:
   self["myPlayRem"].setText("")
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VVgs5z() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   FFRivu(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVnxTK()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VVaKZk(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
  state = self.VVIrqj()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFRivu(self["myPlayMsg"], "#0000ff00")
  else     : FFRivu(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVVQgz(self):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = self.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFBS4u(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFBS4u(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal
      remTxt = FFBS4u(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVlEbx(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VVgs5z()
   if cList:
    VVY2K2 = []
    for pts, what in cList:
     txt = FFBS4u(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVY2K2.append((txt, pts))
    FFlTf2(self, self.VVagKu, VVY2K2=VVY2K2, title="Cut List")
   else:
    self.VVookt("No Cut-List for this channel !")
 def VVagKu(self, item=None):
  if item:
   self.VVaKZk(item)
 def VVgs5z(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVq7NG(self) : self.VVc0tX(self.jumpMinutes)
 def VVA7a4(self) : self.VVc0tX(-self.jumpMinutes)
 def VVc0tX(self, mins):
  try:
   inst = InfoBar.instance
   inst.doSeekRelative(mins * 60 * 90000)
   inst.hide()
   if   mins > 0 : self.VVookt("Forawrd (%d min) ..." % self.jumpMinutes)
   elif mins < 0 : self.VVookt("Rewind (%d min) ..." % self.jumpMinutes)
  except:
   self.VVookt("Cannot jump")
 def VVPkZZ(self):
  InfoBar.instance.VVPkZZ()
 def VVaKZk(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVookt("Changing Time ...")
 def VVzEv1(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVVQgz()
   if durVal > 0:
    pts = int(durVal * 60 * 90000)
    InfoBar.instance.doSeek(pts)
    self.VVookt("Jumping to end ...")
  except:
   pass
 def VVnxTK(self):
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVIrqj(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVe1Vh(self, isUp):
  if self.enableZapping:
   self.VVookt("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVZrNt()
   if self.portalTableParam:
    self.VVliLZ(isUp)
   else:
    try:
     if isUp : InfoBar.instance.zapDown()
     else : InfoBar.instance.zapUp()
    except:
     pass
    self.lastPlayPos = 0
    self.VVlRz2()
    self.VV8lYq()
 def VVliLZ(self, isUp):
  CCfvbT_inatance, VV3o52, mode = self.portalTableParam
  if isUp : VV3o52.VVjUdl()
  else : VV3o52.VVaD09()
  FFjQre(VV3o52, boundFunction(self.VV25CJ, mode, VV3o52, CCfvbT_inatance), title="Playing ...")
 def VV25CJ(self, mode, VV3o52, CCfvbT_inatance):
  colList = VV3o52.VVovNe()
  if mode == "localIptv":
   CCfvbT_inatance.VVObyA(True, VV3o52, "", "", colList)
  elif isinstance(mode, int):
   CCfvbT_inatance.VVlNGW(mode, True, VV3o52, "", "", colList)
  else:
   CCfvbT_inatance.VV9D53(mode, True, VV3o52, "", "", colList)
  self.close()
 def VV8lYq(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVVQgz()
    if posTxt:
     return
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFlPZP(self)
   if not self.VVyaMN(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVookt("Refreshing Portal")
   FFo2XQ(self.VVJGiR)
  except:
   pass
 def VVJGiR(self):
  self.restoreLastPlayPos = self.VVC3JO()
 def VVXcnN(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFlPZP(self)
  if not decodedUrl or any(x in decodedUrl for x in ("/movie/", "/series/")):
   self.VVookt("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.index(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCfvbT.VV1Nl0(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVookt("Reading Program List ...")
   ok_fnc = boundFunction(self.VVtkov, refCode, chName, streamId, uHost, uUser, uPass)
   FFo2XQ(boundFunction(CCfvbT.VV8Uly, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVookt("Cannot process this channel")
 def VVtkov(self, refCode, chName, streamId, uHost, uUser, uPass, VV3o52, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VV3o52.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVookt("Changing Program ...")
   FFo2XQ(boundFunction(self.VVOHzZ, chUrl))
  else:
   self.VVookt("Incorrect Timestamp !")
 def VVOHzZ(self, chUrl):
   FFBoZM(self, chUrl, VVBdIn=False)
   self.lastPlayPos = 0
   self.VVlRz2()
class CCM8lm(Screen):
 def __init__(self, session, title="", VVVbzS="Continue?", VV5nZq=True, VVydGz=False):
  self.skin, self.skinParam = FFdxjB(VVLYwe, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVVbzS = VVVbzS
  self.VVydGz = VVydGz
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VV5nZq : VVY2K2 = [no , yes]
  else   : VVY2K2 = [yes, no ]
  FFSskZ(self, title, VVY2K2=VVY2K2, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVtv5z ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVVbzS)
  if self.VVydGz:
   self["myLabel"].instance.setHAlign(0)
  self.VVbhSs()
  FFUwX1(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FF8Kyd(self["myMenu"])
  FFDdCE(self, self["myMenu"])
 def VVtv5z(self):
  item = FF1kqe(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVbhSs(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCZyZG(Screen):
 def __init__(self, session, title="", VVY2K2=None, width=1000, OKBtnFnc=None, VVMVMB=None, VVZPKj=None, VVHN3c=None, VVfEjQ=None, VVTY2d=False, VVzTdE=False):
  self.skin, self.skinParam = FFdxjB(VVwo8o, width, 850, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVY2K2   = VVY2K2
  self.OKBtnFnc   = OKBtnFnc
  self.VVMVMB   = VVMVMB
  self.VVZPKj  = VVZPKj
  self.VVHN3c  = VVHN3c
  self.VVfEjQ   = VVfEjQ
  self.VVTY2d  = VVTY2d
  self.VVzTdE  = VVzTdE
  FFSskZ(self, title, VVY2K2=VVY2K2)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVtv5z          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVgoOm         ,
   "green"  : self.VVBkI7         ,
   "yellow" : self.VVHwBv         ,
   "blue"  : self.VVgbGM         ,
   "pageUp" : self.VVRmyW       ,
   "chanUp" : self.VVRmyW       ,
   "pageDown" : self.VVgtcJ        ,
   "chanDown" : self.VVgtcJ
  }, -1)
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  FFUwX1(self["myMenu"])
  FF2Dma(self)
  self.VVEkmL(self["keyRed"]  , self.VVMVMB )
  self.VVEkmL(self["keyGreen"] , self.VVZPKj )
  self.VVEkmL(self["keyYellow"] , self.VVHN3c )
  self.VVEkmL(self["keyBlue"]  , self.VVfEjQ )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FF65Ci(self)
 def VVEkmL(self, btnObj, btnFnc):
  if btnFnc:
   FFkqlb(btnObj, btnFnc[0])
 def VVtv5z(self):
  item = FF1kqe(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVTY2d: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVgoOm(self)  : self.VVHMyJ(self.VVMVMB)
 def VVBkI7(self) : self.VVHMyJ(self.VVZPKj)
 def VVHwBv(self) : self.VVHMyJ(self.VVHN3c)
 def VVgbGM(self) : self.VVHMyJ(self.VVfEjQ)
 def VVHMyJ(self, btnFnc):
  if btnFnc:
   item = FF1kqe(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVzTdE:
    self.cancel()
 def VVC83f(self, VVY2K2):
  if len(VVY2K2) > 0:
   newList = []
   for item in VVY2K2:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVUrdH(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVRmyW(self):
  self["myMenu"].moveToIndex(0)
 def VVgtcJ(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCkweT(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VVSmWK=None, VVD84s=None, VVO0tX=None, VV715D=26, VVzUt6=False, VVuedc=None, VVGP73=None, VVPAO4=None, VV4tKk=None, VVBoAr=None, VVMZtN=None, VVdowC=None, VVqeE2=None, VVO3oT=None, VVvwsy=-1, VVGwLR=False, searchCol=0, VVdawd=None, VV2xlz=None, VVJjVS="#00dddddd", VVSwM6="#11002233", VVYYmR="#00ff8833", VVb1yt="#11111111", VVBWV3="#0a555555", VVtEUm="#0affffff", VVYh87="#11552200", VV4oMZ="#0055ff55"):
  self.skin, self.skinParam = FFdxjB(VVMgH3, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFSskZ(self, title)
  self.header     = header
  self.VVSmWK     = VVSmWK
  self.totalCols    = len(VVSmWK[0])
  self.VVrJt6   = 0
  self.lastSortModeIsReverese = False
  self.VVzUt6   = VVzUt6
  self.VVOSec   = 0.01
  self.VVjtZJ   = 0.02
  self.VVo6Np = 0.03
  self.VV1kpw  = 1
  self.VVO0tX = VVO0tX
  self.colWidthPixels   = []
  self.VVuedc   = VVuedc
  self.OKButtonObj   = None
  self.VVGP73   = VVGP73
  self.VVPAO4   = VVPAO4
  self.VV4tKk   = VV4tKk
  self.VVBoAr  = VVBoAr
  self.VVMZtN   = VVMZtN
  self.VVdowC    = VVdowC
  self.VVqeE2   = VVqeE2
  self.VVO3oT  = VVO3oT
  self.VVvwsy    = VVvwsy
  self.VVGwLR   = VVGwLR
  self.searchCol    = searchCol
  self.VVD84s    = VVD84s
  self.keyPressed    = -1
  self.VV715D    = FFa4NK(VV715D)
  self.VVENRM    = FFPtj8(self.VV715D, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVdawd    = VVdawd
  self.VV2xlz      = VV2xlz
  self.VVJjVS    = FFnbxL(VVJjVS)
  self.VVSwM6    = FFnbxL(VVSwM6)
  self.VVYYmR    = FFnbxL(VVYYmR)
  self.VVb1yt    = FFnbxL(VVb1yt)
  self.VVBWV3   = FFnbxL(VVBWV3)
  self.VVtEUm    = FFnbxL(VVtEUm)
  self.VVYh87    = FFnbxL(VVYh87)
  self.VV4oMZ   = FFnbxL(VV4oMZ)
  self.VV3XTV  = False
  self.selectedItems   = 0
  self.VVvFnE   = FFnbxL("#01fefe01")
  self.VVgaED   = FFnbxL("#11400040")
  self.VVu6DC  = self.VVvFnE
  self.VVsTK1  = self.VVb1yt
  if self.VVGwLR:
   self["keyMenu1F"].hide()
   self["keyMenu1"].hide()
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVzWBw  ,
   "red"   : self.VVSeFe  ,
   "green"   : self.VVBflO ,
   "yellow"  : self.VVtX08 ,
   "blue"   : self.VVd1U3  ,
   "menu"   : self.VVIQpF ,
   "info"   : self.VVGjbp  ,
   "cancel"  : self.VV1MHk  ,
   "up"   : self.VVaD09    ,
   "down"   : self.VVjUdl  ,
   "left"   : self.VV7kR4   ,
   "right"   : self.VVoUEV  ,
   "pageUp"  : self.VV8deo  ,
   "chanUp"  : self.VV8deo  ,
   "pageDown"  : self.VVIB40  ,
   "chanDown"  : self.VVIB40
  }, -1)
  FFwhUD(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  try:
   self.VV2TLk()
  except Exception as err:
   FFGIBw(self, str(err))
   self.close(None)
 def VV2TLk(self):
  FF65Ci(self)
  if self.VVdawd:
   FFidK4(self["myTitle"], self.VVdawd)
  if self.VV2xlz:
   FFidK4(self["myBody"] , self.VV2xlz)
   FFidK4(self["myTableH"] , self.VV2xlz)
   FFidK4(self["myTable"] , self.VV2xlz)
   FFidK4(self["myBar"]  , self.VV2xlz)
  self.VVEkmL(self.VVPAO4  , self["keyRed"])
  self.VVEkmL(self.VV4tKk  , self["keyGreen"])
  self.VVEkmL(self.VVBoAr , self["keyYellow"])
  self.VVEkmL(self.VVMZtN  , self["keyBlue"])
  if self.VVuedc:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVuedc[0])
    FFidK4(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVENRM)
  self["myTableH"].l.setFont(0, gFont(VVOYdo, self.VV715D))
  self["myTable"].l.setItemHeight(self.VVENRM)
  self["myTable"].l.setFont(0, gFont(VVOYdo, self.VV715D))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVENRM)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVENRM))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVENRM)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVENRM
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVENRM * len(self.VVSmWK) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVO0tX:
   self.VVO0tX = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVO0tX)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVD84s:
   self.VVD84s = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVD84s
   self.VVD84s = []
   for item in tmpList:
    self.VVD84s.append(item | RT_VALIGN_CENTER)
  self.VVIFnK()
  if self.VVdowC:
   self.VVdowC(self)
 def VVEkmL(self, btnFnc, btn):
  if btnFnc : FFkqlb(btn, btnFnc[0])
  else  : FFkqlb(btn, "")
 def VVB5pc(self, waitTxt):
  FFjQre(self, self.VVIFnK, title=waitTxt)
 def VVIFnK(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VV4jQb(0, self.header, self.VVtEUm, self.VVYh87, self.VVtEUm, self.VVYh87, self.VV4oMZ)])
   rows = []
   for c, row in enumerate(self.VVSmWK):
    rows.append(self.VV4jQb(c, row, self.VVJjVS, self.VVSwM6, self.VVYYmR, self.VVb1yt, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVvwsy > -1:
    self["myTable"].moveToIndex(self.VVvwsy )
   self.VVmUOr()
   if self.VVGwLR:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVENRM * len(self.VVSmWK)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVqeE2:
    self.VVHMyJ(self.VVqeE2, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFGIBw(self, str(err))
    self.close()
   except:
    pass
 def VV4jQb(self, keyIndex, columns, VVJjVS, VVSwM6, VVYYmR, VVb1yt, VV4oMZ):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VV4oMZ and ndx == self.VVrJt6 : textColor = VV4oMZ
   else           : textColor = VVJjVS
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFnbxL(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVSwM6 = c
    entry = span.group(3)
   if self.VVD84s[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVENRM)
           , font   = 0
           , flags   = self.VVD84s[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVSwM6
           , color_sel  = VVYYmR
           , backcolor_sel = VVb1yt
           , border_width = 1
           , border_color = self.VVBWV3
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVGjbp(self):
  rowData = self.VV2pX3()
  if rowData:
   title, txt, colList = rowData
   if self.VVGP73:
    fnc  = self.VVGP73[1]
    params = self.VVGP73[2]
    fnc(self, title, txt, colList)
   else:
    FF0fhx(self, txt, title)
 def VVzWBw(self):
  if   self.VV3XTV : self.VV0eKy(self.VViQry(), mode=2)
  elif self.VVuedc  : self.VVHMyJ(self.VVuedc, None)
  else      : self.VVGjbp()
 def VVSeFe(self) : self.VVHMyJ(self.VVPAO4 , self["keyRed"])
 def VVBflO(self) : self.VVHMyJ(self.VV4tKk , self["keyGreen"])
 def VVtX08(self): self.VVHMyJ(self.VVBoAr , self["keyYellow"])
 def VVd1U3(self) : self.VVHMyJ(self.VVMZtN , self["keyBlue"])
 def VVHMyJ(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FF3ty7(self, buttonFnc[3])
    FFo2XQ(boundFunction(self.VVKk3F, buttonFnc))
   else:
    self.VVKk3F(buttonFnc)
 def VVKk3F(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VV2pX3()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VV0eKy(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VVSmWK[ndx]
   isSelected = row[1][9] == self.VVvFnE
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VV4jQb(ndx, item, self.VVJjVS, self.VVSwM6, self.VVYYmR, self.VVb1yt, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VV4jQb(ndx, item, self.VVvFnE, self.VVgaED, self.VVu6DC, self.VVsTK1, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVmUOr()
 def VV14Uj(self):
  FFjQre(self, self.VV0reX, title="Selecting all ...")
 def VV0reX(self):
  self.VVIsma(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVvFnE
   if not isSelected:
    item = self.VVSmWK[ndx]
    newRow = self.VV4jQb(ndx, item, self.VVvFnE, self.VVgaED, self.VVu6DC, self.VVsTK1, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVmUOr()
  self.VVuiS4()
 def VVHNeR(self):
  FFjQre(self, self.VVRYa2, title="Unselecting all ...")
 def VVRYa2(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVvFnE:
    item = self.VVSmWK[ndx]
    newRow = self.VV4jQb(ndx, item, self.VVJjVS, self.VVSwM6, self.VVYYmR, self.VVb1yt, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVmUOr()
  self.VVuiS4()
 def VVuiS4(self):
  self.hide()
  self.show()
 def VV2pX3(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVO0tX[i] > 1 or self.VVO0tX[i] == self.VVOSec or self.VVO0tX[i] == self.VVo6Np:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VVSmWK))
   return rowNum, txt, colList
  else:
   return None
 def VV1MHk(self):
  if self.VVO3oT : self.VVO3oT(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VV8QuM(self):
  return self["myTitle"].getText().strip()
 def VVzMY4(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVxOlm(self, txt):
  FF3ty7(self, txt)
 def VVSUkD(self, txt):
  FF3ty7(self, txt, 1000)
 def VVU8jU(self):
  FF3ty7(self)
 def VVt5sd(self):
  return len(self.VVSmWK)
 def VV08aL(self): self["keyGreen"].show()
 def VVO9Hu(self): self["keyGreen"].hide()
 def VViQry(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVC6zJ(self):
  return len(self["myTable"].list)
 def VVIsma(self, isOn):
  self.VV3XTV = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   if self.VVMZtN: self["keyBlue"].hide()
   if self.VVuedc and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
   if self.VVMZtN: self["keyBlue"].show()
   if self.VVuedc and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVuedc[0])
   self.VVHNeR()
  FFidK4(self["myTitle"], color)
  FFidK4(self["myBar"]  , color)
 def VVNwNp(self):
  return self.VV3XTV
 def VVa4K4(self):
  return self.selectedItems
 def VV6YEF(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VVmUOr()
 def VVDHrO(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVmUOr()
 def VVilfI(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VVSmWK:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVZgwH(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVt5sd()
  txt += FFmLFC("Total Unique Items", VVEAFU)
  for i in range(self.totalCols):
   if self.VVO0tX[i - 1] > 1 or self.VVO0tX[i - 1] == self.VVOSec or self.VVO0tX[i - 1] == self.VVo6Np:
    name, tot = self.VVilfI(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FF0fhx(self, txt)
 def VViajA(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVovNe(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVnh9K(self, newList, newTitle=""):
  if newList:
   self.VVSmWK = newList
   if self.VVzUt6 and self.VVrJt6 == 0:
    self.VVSmWK = sorted(self.VVSmWK, key=lambda x: int(x[self.VVrJt6])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VVSmWK = sorted(self.VVSmWK, key=lambda x: x[self.VVrJt6].lower(), reverse=self.lastSortModeIsReverese)
   self.VVB5pc("Refreshing ...")
   if newTitle:
    self.VVzMY4(newTitle)
  else:
   FFGIBw(self, "Cannot refresh list")
   self.cancel()
 def VV98qP(self, data):
  ndx = self.VViQry()
  newRow = self.VV4jQb(ndx, data, self.VVJjVS, self.VVSwM6, self.VVYYmR, self.VVb1yt, None)
  if newRow:
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVmUOr()
   return True
  else:
   return False
 def VVV2sO(self, colNum, textToFind, VVA3IL=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVmUOr()
    break
  else:
   if VVA3IL:
    FF3ty7(self, "Not found", 1000)
 def VV7yyv(self, colDict, VVA3IL=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVmUOr()
    return
  if VVA3IL:
   FF3ty7(self, "Not found", 1000)
 def VV7yyv_partial(self, colDict, VVA3IL=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVmUOr()
    return
  if VVA3IL:
   FF3ty7(self, "Not found", 1000)
 def VVcS0p(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVLUuL(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVvFnE:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVevLM(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVIQpF(self):
  if not self["keyMenu2F"].getVisible() or self.VVGwLR:
   return
  VVY2K2 = []
  VVY2K2.append(("Table Statistcis"             , "tableStat"  ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append((FFARnG("Export Table to .html"     , VVEAFU) , "VVcmOm" ))
  VVY2K2.append((FFARnG("Export Table to .csv"     , VVEAFU) , "VVbaJS" ))
  VVY2K2.append((FFARnG("Export Table to .txt (Tab Separated)", VVEAFU) , "VVaI4g" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVO0tX[i] > 1 or self.VVO0tX[i] == self.VVjtZJ:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVY2K2.append(VV8PP6)
   if tot == 1 : VVY2K2.append(("Sort", sList[0][1]))
   else  : VVY2K2 += sList
  FFlTf2(self, self.VVVh6i, VVY2K2=VVY2K2, title=self.VV8QuM())
 def VVVh6i(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVZgwH()
   elif item == "VVcmOm": FFjQre(self, self.VVcmOm, title=title)
   elif item == "VVbaJS" : FFjQre(self, self.VVbaJS , title=title)
   elif item == "VVaI4g" : FFjQre(self, self.VVaI4g , title=title)
   else:
    isReversed = False
    if self.VVrJt6 == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVzUt6 and item == 0:
     self.VVSmWK = sorted(self.VVSmWK, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VVSmWK = sorted(self.VVSmWK, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVrJt6 = item
    self.VVB5pc("Sorting ...")
 def VVaD09(self):
  self["myTable"].up()
  self.VVmUOr()
 def VVjUdl(self):
  self["myTable"].down()
  self.VVmUOr()
 def VV7kR4(self):
  self["myTable"].pageUp()
  self.VVmUOr()
 def VVoUEV(self):
  self["myTable"].pageDown()
  self.VVmUOr()
 def VV8deo(self):
  self["myTable"].moveToIndex(0)
  self.VVmUOr()
 def VVIB40(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVmUOr()
 def VVaI4g(self):
  expFile = self.VV9x2P() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVd61x()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VVSmWK:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVO0tX[ndx] > self.VV1kpw or self.VVO0tX[ndx] == self.VVo6Np:
      col = self.VVxhcE(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVcLdS(expFile)
 def VVbaJS(self):
  expFile = self.VV9x2P() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVd61x()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VVSmWK:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVO0tX[ndx] > self.VV1kpw or self.VVO0tX[ndx] == self.VVo6Np:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVxhcE(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVcLdS(expFile)
 def VVcmOm(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VV8QuM(), PLUGIN_NAME, VVTPuM)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VV8QuM()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVd61x()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVO0tX:
   colgroup += '   <colgroup>'
   for w in self.VVO0tX:
    if w > self.VV1kpw or w == self.VVo6Np:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VV9x2P() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VVSmWK:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVO0tX[ndx] > self.VV1kpw or self.VVO0tX[ndx] == self.VVo6Np:
      col = self.VVxhcE(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVcLdS(expFile)
 def VVd61x(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVO0tX[ndx] > self.VV1kpw or self.VVO0tX[ndx] == self.VVo6Np:
     newRow.append(col.strip())
  return newRow
 def VVxhcE(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFt6bT(col)
 def VV9x2P(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VV8QuM())
  fileName = fileName.replace("__", "_")
  path  = FF0hsM(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFgfmJ()
  return expFile
 def VVcLdS(self, expFile):
  FFrLx8(self, "File exported to:\n\n%s" % expFile, title=self.VV8QuM())
 def VVmUOr(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCSXqH(Screen):
 def __init__(self, session, Title="", VVOtK1=None):
  self.skin, self.skinParam = FFdxjB(VVayJ6, 1400, 800, 50, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FFSskZ(self, Title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VVOtK1 = VVOtK1
  if len(Title) == 0 : Title = FF39sf()
  else    : Title = "File : %s" % VVOtK1
  self["myTitle"] = Label("  %s" % Title)
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  allOK = FFYffG(self["myLabel"], self.VVOtK1)
  if not allOK:
   FFGIBw(self, "Could not view this picture file")
   self.close()
class CCPM5F(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFdxjB(VVfta0, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 28, barHeight=40, topRightBtns=1)
  self.session  = session
  FFSskZ(self)
  FFkqlb(self["keyGreen"], "Save")
  self.VVSmWK = []
  self.VVSmWK.append(getConfigListEntry("Show in Main Menu"         , CFG.showInMainMenu   ))
  self.VVSmWK.append(getConfigListEntry("Show in Extensions Menu"        , CFG.showInExtensionMenu  ))
  self.VVSmWK.append(getConfigListEntry("Show in Channel List Context Menu"     , CFG.showInChannelListMenu  ))
  self.VVSmWK.append(getConfigListEntry("Show in Events Info Menu"       , CFG.EventsInfoMenu   ))
  self.VVSmWK.append(getConfigListEntry("Input Type"           , CFG.keyboard     ))
  self.VVSmWK.append(getConfigListEntry("Signal & Player Cotroller Hotkey"     , CFG.hotkey_signal    ))
  if VVrFFh:
   self.VVSmWK.append(getConfigListEntry("EPG Translation Language"      , CFG.epgLanguage    ))
  self.VVSmWK.append(getConfigListEntry(VV1xmU *2            ,         ))
  self.VVSmWK.append(getConfigListEntry("Default IPTV Reference Type"       , CFG.iptvAddToBouquetRefType ))
  self.VVSmWK.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"    , CFG.hideIptvServerAdultWords ))
  self.VVSmWK.append(getConfigListEntry('Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)' , CFG.hideIptvServerChannPrefix ))
  self.VVSmWK.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"  , CFG.iptvHostsPath    ))
  self.VVSmWK.append(getConfigListEntry(VV1xmU *2            ,         ))
  self.VVSmWK.append(getConfigListEntry("PIcons Path"           , CFG.PIconsPath    ))
  self.VVSmWK.append(getConfigListEntry(VV1xmU *2            ,         ))
  self.VVSmWK.append(getConfigListEntry("Backup/Restore Path"         , CFG.backupPath    ))
  self.VVSmWK.append(getConfigListEntry("Created Package Files (IPK/DEB)"      , CFG.packageOutputPath   ))
  self.VVSmWK.append(getConfigListEntry("Downloaded Packages (from feeds)"     , CFG.downloadedPackagesPath ))
  self.VVSmWK.append(getConfigListEntry("Exported Tables"          , CFG.exportedTablesPath  ))
  self.VVSmWK.append(getConfigListEntry("Exported PIcons"          , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, self.VVSmWK, session)
  self["setupActions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard", "OkCancelActions"],
  {
   "ok"  : self.VVtv5z   ,
   "OK"  : self.VVtv5z   ,
   "green"  : self.VVh4xT  ,
   "menu"  : self.VVbOTb ,
   "cancel" : self.VVZIHp
  }, -1)
  self.titleText = "  Settings"
  self["myTitle"].setText(self.titleText)
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  FFUwX1(self["config"])
  FF2Dma(self,  self["config"])
  FF65Ci(self)
 def VVtv5z(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsPath   : self.VVLprE()
   elif item == CFG.PIconsPath    : self.VVJp2x(item)
   elif item == CFG.backupPath    : self.VVJp2x(item)
   elif item == CFG.packageOutputPath  : self.VVJp2x(item)
   elif item == CFG.downloadedPackagesPath : self.VVJp2x(item)
   elif item == CFG.exportedTablesPath  : self.VVJp2x(item)
   elif item == CFG.exportedPIconsPath  : self.VVJp2x(item)
 def VVLprE(self):
  VVY2K2 = []
  VVY2K2.append(("Auto Find" , "auto"))
  VVY2K2.append(("Custom Path" , "path"))
  FFlTf2(self, self.VV3PF9, VVY2K2=VVY2K2, title="IPTV Hosts Files Path")
 def VV3PF9(self, item=None):
  if item:
   if   item == "auto": CFG.iptvHostsPath.setValue(VVl5oV)
   elif item == "path": self.VVJp2x(CFG.iptvHostsPath)
 def VVJp2x(self, configObj):
  sDir = configObj.getValue()
  if sDir == VVl5oV:
   sDir = "/"
  self.session.openWithCallback(boundFunction(self.VViCbx, configObj)
         , boundFunction(CCQ4SG, mode=CCQ4SG.VVMcRv, VVbrP2=sDir))
 def VViCbx(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVZIHp(self):
  if CFG.showInMainMenu.isChanged()    or \
   CFG.showInExtensionMenu.isChanged()   or \
   CFG.showInChannelListMenu.isChanged()  or \
   CFG.EventsInfoMenu.isChanged()    or \
   CFG.keyboard.isChanged()     or \
   CFG.hotkey_signal.isChanged()    or \
   CFG.epgLanguage.isChanged()     or \
   CFG.iptvAddToBouquetRefType.isChanged()  or \
   CFG.hideIptvServerAdultWords.isChanged() or \
   CFG.hideIptvServerChannPrefix.isChanged() or \
   CFG.iptvHostsPath.isChanged()    or \
   CFG.PIconsPath.isChanged()     or \
   CFG.backupPath.isChanged()     or \
   CFG.packageOutputPath.isChanged()   or \
   CFG.downloadedPackagesPath.isChanged()  or \
   CFG.exportedTablesPath.isChanged()   or \
   CFG.exportedPIconsPath.isChanged():
    FFhMkA(self, self.VVh4xT, "Save Changes ?", callBack_No=self.cancel)
  else:
   self.cancel()
 def VVh4xT(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVqHfG()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVbOTb(self):
  VVY2K2 = []
  VVY2K2.append(("Use Backup directory in all other paths"      , "VV6pZa"   ))
  VVY2K2.append(("Reset all to default (including File Manager bookmarks)"  , "VVUkom"   ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Backup %s Settings" % PLUGIN_NAME        , "VVa5bC"  ))
  VVY2K2.append(("Restore %s Settings" % PLUGIN_NAME       , "VVaWTi"  ))
  if fileExists(VVaZdT + VVvxim):
   VVY2K2.append(VV8PP6)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVY2K2.append(('%s Checking for Update' % txt1       , txt2     ))
   VVY2K2.append(("Reinstall %s" % PLUGIN_NAME        , "VV5RHJ"  ))
   VVY2K2.append(("Update %s" % PLUGIN_NAME        , "VVGF8i"   ))
  FFlTf2(self, self.VVN97C, VVY2K2=VVY2K2, title="Config. Options")
 def VVN97C(self, item=None):
  if item:
   if   item == "VV6pZa"  : FFhMkA(self, self.VV6pZa , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVUkom"  : FFhMkA(self, self.VVUkom, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CC1Ai0)
   elif item == "VVa5bC" : self.VVa5bC()
   elif item == "VVaWTi" : FFjQre(self, self.VVaWTi, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVaeQh(True)
   elif item == "disableChkUpdate" : self.VVaeQh(False)
   elif item == "VV5RHJ" : FFjQre(self, self.VV5RHJ , "Checking Server ...")
   elif item == "VVGF8i"  : FFjQre(self, self.VVGF8i  , "Checking Server ...")
 def VVa5bC(self):
  path = "%sajpanel_settings_%s" % (VVaZdT, FFgfmJ())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFrLx8(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVaWTi(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFVHBJ("find / %s -iname '%s*' | grep %s" % (FFXsco(1), name, name))
  if lines:
   lines.sort()
   VVY2K2 = []
   for line in lines:
    VVY2K2.append((line, line))
   FFlTf2(self, boundFunction(self.VVFwrX, title), title=title, VVY2K2=VVY2K2, width=1200)
  else:
   FFGIBw(self, "No settings files found !", title=title)
 def VVFwrX(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFrxQp(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVqHfG()
    FF4CvA()
   else:
    FFQ3EB(SELF, path, title=title)
 def VVaeQh(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VV6pZa(self):
  newPath = FF0hsM(VVaZdT)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVqHfG()
 @staticmethod
 def VVM8Bo():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVUkom(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.EventsInfoMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.epgLanguage.setValue("off")
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.iptvHostsPath.setValue(VVl5oV)
  CFG.PIconsPath.setValue(VV4dqz)
  CFG.backupPath.setValue(CCPM5F.VVM8Bo())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  CFG.showInMainMenu.save()
  CFG.showInExtensionMenu.save()
  CFG.showInChannelListMenu.save()
  CFG.EventsInfoMenu.save()
  CFG.keyboard.save()
  CFG.hotkey_signal.save()
  CFG.epgLanguage.save()
  CFG.iptvAddToBouquetRefType.save()
  CFG.hideIptvServerAdultWords.save()
  CFG.hideIptvServerChannPrefix.save()
  CFG.iptvHostsPath.save()
  CFG.PIconsPath.save()
  CFG.backupPath.save()
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  CFG.browserStartPath.save()
  CFG.browserBookmarks.save()
  self.VVqHfG()
  self.close()
 def VVqHfG(self):
  configfile.save()
  global VVaZdT
  VVaZdT = CFG.backupPath.getValue()
  FFaRWQ()
 def VVGF8i(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VV5CRs(title)
  if webVer:
   FFhMkA(self, boundFunction(FFjQre, self, boundFunction(self.VVEttF, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VV5RHJ(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VV5CRs(title, True)
  if webVer:
   FFhMkA(self, boundFunction(FFjQre, self, boundFunction(self.VVEttF, webVer, title)), "Install and Restart ?", title=title)
 def VVEttF(self, webVer, title):
  url = self.VVTzA4(self, title)
  if url:
   VV49od = FFwItZ() == "dpkg"
   if VV49od == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VV49od else "ipk")
   path, err = FFV6A0(url + fName, fName, timeout=2)
   if path:
    cmd = FF6Z6k(VVwrhV, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFRQmD(self, cmd)
    else:
     FFvteW(self, title=title)
   else:
    FFGIBw(self, err, title=title)
 def VV5CRs(self, title, anyVer=False):
  url = self.VVTzA4(self, title)
  if not url:
   return ""
  path, err = FFV6A0(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFGIBw(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFJ07K(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFGIBw(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVTPuM.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFVHBJ(cmd)
   if list and curVer == list[0]:
    return webVer
  FFrLx8(self, FFARnG("No update required.", VVFGoE) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVTzA4(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVaZdT + VVvxim
  if fileExists(path):
   span = iSearch(r"(http.+)", FFJ07K(path), IGNORECASE)
   if span : url = FF0hsM(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFGIBw(SELF, err, title)
  return url
 @staticmethod
 def VVIPqc(url):
  path, err = FFV6A0(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFJ07K(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVTPuM.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFVHBJ(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CC1Ai0(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFdxjB(VVvMST, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVnAll
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFSskZ(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVogL3("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVogL3("\c00888888", i) + sp + "GREY\n"
   txt += self.VVogL3("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVogL3("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVogL3("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVogL3("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVogL3("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVogL3("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVogL3("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVogL3("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVogL3("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVogL3("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVtv5z ,
   "green"   : self.VVtv5z ,
   "left"   : self.VVVkoz ,
   "right"   : self.VV07jt ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  self.VVBlw1()
 def VVtv5z(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFhMkA(self, self.VVLtRY, "Change to : %s" % txt, title=self.Title)
 def VVLtRY(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVnAll
  VVnAll = self.cursorPos
  self.VVeHny()
  self.close()
 def VVVkoz(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVBlw1()
 def VV07jt(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVBlw1()
 def VVBlw1(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVogL3(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VV33nE(color):
  if VVclxO: return "\\" + color
  else    : return ""
 @staticmethod
 def VVeHny():
  global VVcwMp, VVPTHk, VVu486, VVEAFU, VVSsUL, VVVFfb, VVFGoE, VVclxO, COLOR_CONS_BRIGHT_YELLOW, VVylYU, VVrHls, VV6kBj, VVYHoM
  VVYHoM   = CC1Ai0.VVogL3("\c00FFFFFF", VVnAll)
  VVPTHk    = CC1Ai0.VVogL3("\c00888888", VVnAll)
  VVcwMp  = CC1Ai0.VVogL3("\c005A5A5A", VVnAll)
  VVVFfb    = CC1Ai0.VVogL3("\c00FF0000", VVnAll)
  VVu486   = CC1Ai0.VVogL3("\c00FF5000", VVnAll)
  VVclxO   = CC1Ai0.VVogL3("\c00FFFF00", VVnAll)
  COLOR_CONS_BRIGHT_YELLOW = CC1Ai0.VVogL3("\c00FFFFAA", VVnAll)
  VVFGoE   = CC1Ai0.VVogL3("\c0000FF00", VVnAll)
  VVSsUL    = CC1Ai0.VVogL3("\c000066FF", VVnAll)
  VVylYU    = CC1Ai0.VVogL3("\c0000FFFF", VVnAll)
  VVrHls  = CC1Ai0.VVogL3("\c00DSFFFF", VVnAll)  #
  VV6kBj   = CC1Ai0.VVogL3("\c00FA55E7", VVnAll)
  VVEAFU    = CC1Ai0.VVogL3("\c00FF8F5F", VVnAll)
CC1Ai0.VVeHny()
class CCQGzc(Screen):
 def __init__(self, session, path, VV49od):
  self.skin, self.skinParam = FFdxjB(VVdxXE, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVUtqU   = path
  self.VV1XBK   = ""
  self.VVJByi   = ""
  self.VV49od    = VV49od
  self.VVf2Jv    = ""
  self.VVx88g  = ""
  self.VV4WgR    = False
  self.VVVbU9  = False
  self.postInstAcion   = 0
  self.VVt48E  = "enigma2-plugin-extensions"
  self.VVvLRg  = "enigma2-plugin-systemplugins"
  self.VVw52h = "enigma2"
  self.VVQS4e  = 0
  self.VVhTin  = 1
  self.VVzSxQ  = 2
  if pathExists(self.Path + "DEBIAN") : self.VV5TJJ = "DEBIAN"
  else        : self.VV5TJJ = "CONTROL"
  self.controlPath = self.Path + self.VV5TJJ
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VV49od:
   self.packageExt  = ".deb"
   self.VVSwM6  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVSwM6  = "#11001020"
  FFSskZ(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFkqlb(self["keyRed"] , "Create")
  FFkqlb(self["keyGreen"] , "Post Install")
  FFkqlb(self["keyYellow"], "Installation Path")
  FFkqlb(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVm7pa  ,
   "green"   : self.VVbguz ,
   "yellow"  : self.VVZvcX  ,
   "blue"   : self.VVKqEN  ,
   "cancel"  : self.VVdmcd
  }, -1)
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  FF65Ci(self)
  if self.VVSwM6:
   FFidK4(self["myBody"], self.VVSwM6)
   FFidK4(self["myLabel"], self.VVSwM6)
  self.VVOh0N(True)
  self.VVoRKT(True)
 def VVoRKT(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VV3vA2()
  if isFirstTime:
   if   package.startswith(self.VVt48E) : self.VVUtqU = VVgQjM + self.VVf2Jv + "/"
   elif package.startswith(self.VVvLRg) : self.VVUtqU = VVdP4f + self.VVf2Jv + "/"
   else            : self.VVUtqU = self.Path
  if self.VV4WgR : myColor = VVEAFU
  else    : myColor = VVYHoM
  txt  = ""
  txt += "Source Path\t: %s\n" % FFARnG(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFARnG(self.VVUtqU, VVclxO)
  if self.VVJByi : txt += "Package File\t: %s\n" % FFARnG(self.VVJByi, VVPTHk)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFARnG("Check Control File fields : %s" % errTxt, VVu486)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFARnG("Restart GUI", VVEAFU)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFARnG("Reboot Device", VVEAFU)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FFARnG("Post Install", VVFGoE), act)
  if not errTxt and VVu486 in controlInfo:
   txt += "Warning\t: %s\n" % FFARnG("Errors in control file may affect the result package.", VVu486)
  txt += "\nControl File\t: %s\n" % FFARnG(self.controlFile, VVPTHk)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVbguz(self):
  VVY2K2 = []
  VVY2K2.append(("No Action"    , "noAction"  ))
  VVY2K2.append(("Restart GUI"    , "VV4aBN"  ))
  VVY2K2.append(("Reboot Device"   , "rebootDev"  ))
  FFlTf2(self, self.VV5sG5, title="Package Installation Option (after completing installation)", VVY2K2=VVY2K2)
 def VV5sG5(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VV4aBN"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVOh0N(False)
   self.VVoRKT()
 def VVZvcX(self):
  rootPath = FFARnG("/%s/" % self.VVf2Jv, VVcwMp)
  VVY2K2 = []
  VVY2K2.append(("Current Path"        , "toCurrent"  ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Extension Path"       , "toExtensions" ))
  VVY2K2.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVY2K2.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFlTf2(self, self.VVPGsC, title="Installation Path", VVY2K2=VVY2K2)
 def VVPGsC(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VV9L5U(FFXMLs(self.Path, True))
   elif item == "toExtensions"  : self.VV9L5U(VVgQjM)
   elif item == "toSystemPlugins" : self.VV9L5U(VVdP4f)
   elif item == "toRootPath"  : self.VV9L5U("/")
   elif item == "toRoot"   : self.VV9L5U("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VV69yF, boundFunction(CCQ4SG, mode=CCQ4SG.VVMcRv, VVbrP2=VVaZdT))
 def VV69yF(self, path):
  if len(path) > 0:
   self.VV9L5U(path)
 def VV9L5U(self, parent, withPackageName=True):
  if withPackageName : self.VVUtqU = parent + self.VVf2Jv + "/"
  else    : self.VVUtqU = "/"
  mode = self.VVFilw()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VV14np(mode), self.controlFile))
  self.VVoRKT()
 def VVKqEN(self):
  if fileExists(self.controlFile):
   lines = FFrxQp(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFwT6k(self, self.VVDOxK, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFGIBw(self, "Version not found or incorrectly set !")
  else:
   FFQ3EB(self, self.controlFile)
 def VVDOxK(self, VVL1IG):
  if VVL1IG:
   version, color = self.VV7Cn1(VVL1IG, False)
   if color == VVylYU:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVL1IG, self.controlFile))
    self.VVoRKT()
   else:
    FFGIBw(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVdmcd(self):
  if self.newControlPath:
   if self.VV4WgR:
    self.VV6a0l()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFARnG(self.newControlPath, VVPTHk)
    txt += FFARnG("Do you want to keep these files ?", VVclxO)
    FFhMkA(self, self.close, txt, callBack_No=self.VV6a0l, title="Create Package", VVydGz=True)
  else:
   self.close()
 def VV6a0l(self):
  os.system(FFdgmD("rm -r '%s'" % self.newControlPath))
  self.close()
 def VV14np(self, mode):
  if   mode == self.VVhTin : prefix = self.VVt48E
  elif mode == self.VVzSxQ : prefix = self.VVvLRg
  else        : prefix = self.VVw52h
  return prefix + "-" + self.VVx88g
 def VVFilw(self):
  if   self.VVUtqU.startswith(VVgQjM) : return self.VVhTin
  elif self.VVUtqU.startswith(VVdP4f) : return self.VVzSxQ
  else            : return self.VVQS4e
 def VVOh0N(self, isFirstTime):
  self.VVf2Jv   = os.path.basename(os.path.normpath(self.Path))
  self.VVf2Jv   = "_".join(self.VVf2Jv.split())
  self.VVx88g = self.VVf2Jv.lower()
  self.VV4WgR = self.VVx88g == VVHFp6.lower()
  if self.VV4WgR and self.VVx88g.endswith("ajpan"):
   self.VVx88g += "el"
  if self.VV4WgR : self.VV1XBK = VVaZdT
  else    : self.VV1XBK = CFG.packageOutputPath.getValue()
  self.VV1XBK = FF0hsM(self.VV1XBK)
  if not pathExists(self.controlPath):
   os.system(FFdgmD("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VV4WgR : t = PLUGIN_NAME
  else    : t = self.VVf2Jv
  self.VVihYw(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVtYzD.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VV4WgR : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVihYw(self.postrmFile, txt)
  if self.VV4WgR:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVTPuM)
   self.VVihYw(self.preinstFile, txt)
  else:
   self.VVihYw(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVf2Jv)
  mode = self.VVFilw()
  if isFirstTime and not mode == self.VVQS4e:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VV1xmU
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVihYw(self.postinstFile, txt, VVDnpG=True)
  os.system(FFdgmD("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VV4WgR : version, descripton, maintainer = VVTPuM , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVf2Jv , self.VVf2Jv
   txt = ""
   txt += "Package: %s\n"  % self.VV14np(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVihYw(self, path, lines, VVDnpG=False):
  if not fileExists(path) or VVDnpG:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VV3vA2(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFrxQp(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFARnG(line, VVu486)
     elif not line.startswith(" ")    : line = FFARnG(line, VVu486)
     else          : line = FFARnG(line, VVylYU)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVylYU
   else   : color = VVu486
   descr = FFARnG(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVu486
     elif line.startswith((" ", "\t")) : color = VVu486
     elif line.startswith("#")   : color = VVPTHk
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VV7Cn1(val, True)
      elif key == "Version"  : version, color = self.VV7Cn1(val, False)
      elif key == "Maintainer" : maint  , color = val, VVylYU
      elif key == "Architecture" : arch  , color = val, VVylYU
      else:
       color = VVylYU
      if not key == "OE" and not key.istitle():
       color = VVu486
     else:
      color = VVEAFU
     txt += FFARnG(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVJByi = self.VV1XBK + packageName
   self.VVVbU9 = True
   errTxt = ""
  else:
   self.VVJByi  = ""
   self.VVVbU9 = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VV7Cn1(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVylYU
  else          : return val, VVu486
 def VVm7pa(self):
  if not self.VVVbU9:
   FFGIBw(self, "Please fix Control File errors first.")
   return
  if self.VV49od: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFXMLs(self.VVUtqU, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVf2Jv
  symlinkTo  = FFaMIL(self.Path)
  dataDir   = self.VVUtqU.rstrip("/")
  removePorjDir = FFdgmD("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFdgmD("rm -f '%s'" % self.VVJByi) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFWCzm()
  if self.VV49od:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FF1ECy("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VV4WgR:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVUtqU == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VV5TJJ)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVJByi, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVJByi
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVJByi, FFAawR(result  , VVFGoE))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVUtqU, FFAawR(instPath, VVylYU))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFAawR(failed, VVu486))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFRQmD(self, cmd)
class CCQ4SG(Screen):
 VVCpDL   = 0
 VVMcRv  = 1
 VVzKAo = 20
 def __init__(self, session, VVbrP2="/", mode=VVCpDL, VVbPwT="Select", VV715D=30):
  self.skin, self.skinParam = FFdxjB(VVwo8o, 1400, 820, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFSskZ(self)
  FFkqlb(self["keyRed"] , "Exit")
  FFkqlb(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVbPwT = VVbPwT
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  if   self.mode == self.VVCpDL  : VV58dD, self.VVbrP2 = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVMcRv : VV58dD, self.VVbrP2 = False, VVbrP2
  else           : VV58dD, self.VVbrP2 = True , VVbrP2
  self.VVbrP2 = FF0hsM(self.VVbrP2)
  self["myMenu"] = CC4dTO(  directory   = "/"
         , VV58dD   = VV58dD
         , VV82RO = True
         , VVN7KF   = self.skinParam["width"]
         , VV715D   = self.skinParam["bodyFontSize"]
         , VVENRM  = self.skinParam["bodyLineH"]
         , VVIxZg  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVtv5z      ,
   "red"    : self.cancel      ,
   "green"    : self.VVnLj9    ,
   "yellow"   : self.VVxpfv   ,
   "blue"    : self.VVA4u1   ,
   "menu"    : self.VVAf10    ,
   "info"    : self.VVxU4o    ,
   "cancel"   : self.VVWfzy     ,
   "pageUp"   : self.VVWfzy     ,
   "chanUp"   : self.VVWfzy
  }, -1)
  FFwhUD(self, self["myMenu"])
  self.onShown.append(self.start)
  self["myMenu"].onSelectionChanged.append(self.VVH5ui)
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVH5ui)
  FFUwX1(self["myMenu"], bg="#06003333")
  FF65Ci(self)
  self.maxTitleWidth = self["keyMenu1"].getPosition()[0] - 40
  if self.mode == self.VVMcRv:
   FFkqlb(self["keyGreen"], self.VVbPwT)
   color = "#22000022"
   FFidK4(self["myBody"], color)
   FFidK4(self["myMenu"], color)
   color = "#22220000"
   FFidK4(self["myTitle"], color)
   FFidK4(self["myBar"], color)
  self.VVH5ui()
  if self.VVMkxc(self.VVbrP2) > self.bigDirSize:
   FF3ty7(self, "Changing directory...")
   FFo2XQ(self.VVdpBa)
  else:
   self.VVdpBa()
 def VVdpBa(self):
  self["myMenu"].VV32nw(self.VVbrP2)
 def VVTuXk(self):
  self["myMenu"].refresh()
  FFUTZz()
 def VVMkxc(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VVtv5z(self):
  if self["myMenu"].VVh5Xt():
   path = self.VVVN3a(self.VVmQZX())
   if self.VVMkxc(path) > self.bigDirSize:
    FF3ty7(self, "Changing directory...")
    FFo2XQ(self.VV8fNF)
   else:
    self.VV8fNF()
  else:
   self.VVpFK3()
 def VV8fNF(self):
  self["myMenu"].descent()
  self["myMenu"].moveToIndex(0)
  self.VVH5ui()
 def VVWfzy(self):
  if self["myMenu"].VVp3Vb():
   self["myMenu"].moveToIndex(0)
   self.VV8fNF()
 def cancel(self):
  if not FFTgC4(self):
   self.close("")
 def VVnLj9(self):
  if self.mode == self.VVMcRv:
   path = self.VVVN3a(self.VVmQZX())
   self.close(path)
 def VVxU4o(self):
  FFjQre(self, self.VVwDsB, title="Calculating size ...")
 def VVwDsB(self):
  path = self.VVVN3a(self.VVmQZX())
  param = self.VVmBB4(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = ""
   if typeChar == "d":
    result = FF3QAx("myDir='%s'; totDirs=$(find $myDir -type d | wc -l); totFiles=$(find $myDir ! -type d | wc -l); echo $totDirs','$totFiles" % path)
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents  = "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
    size = FF3QAx("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    size = int(size)
   if size >= 1024 : size = "%s  ( %s bytes )" % (self.VV1kb4(size), format(size, ',d'))
   else   : size = "%s" % self.VV1kb4(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFARnG(pathTxt, VVEAFU) + "\n"
   if slBroken : fileTime = self.VVWgH3(path)
   else  : fileTime = self.VVLYfj(path)
   def VVaWk1(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVaWk1("Path"    , pathTxt)
   txt += VVaWk1("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVaWk1("Target"   , slTarget)
   txt += VVaWk1("Size"    , "%s" % size)
   txt += contents
   txt += "\n"
   txt += VVaWk1("Owner"    , owner)
   txt += VVaWk1("Group"    , group)
   txt += VVaWk1("Perm. (User)"  , permUser)
   txt += VVaWk1("Perm. (Group)"  , permGroup)
   txt += VVaWk1("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVaWk1("Perm. (Ext.)" , permExtra)
   txt += VVaWk1("iNode"    , iNode)
   txt += VVaWk1("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VV1xmU, VV1xmU)
    txt += hLinkedFiles
   txt += self.VVya4D(path)
  else:
   FFGIBw(self, "Cannot access information !")
  if len(txt) > 0:
   FF0fhx(self, txt)
 def VVmBB4(self, path):
  path = path.strip()
  path = FFaMIL(path)
  result = FF3QAx("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVuidh(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVuidh(perm, 1, 4)
   permGroup = VVuidh(perm, 4, 7)
   permOther = VVuidh(perm, 7, 10)
   permExtra = VVuidh(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFEP7o("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVya4D(self, path):
  txt  = ""
  res  = FF3QAx("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFARnG("File Attributes:", VV6kBj), txt)
  return txt
 def VVLYfj(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFXzY3(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFXzY3(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFXzY3(os.path.getctime(path))
  return txt
 def VVWgH3(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FF3QAx("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FF3QAx("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FF3QAx("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VV1kb4(self, size):
  power = 1024.0
  n = 0
  power_labels = {0 : 'B', 1: 'kB', 2: 'MB', 3: 'GB', 4: 'TB'}
  while size > power:
   size /= power
   n += 1
  size = "%.1f" % size
  if size.endswith(".0"):
   size = size[:-2]
  return "%s %s" % (size, power_labels[n])
 def VVVN3a(self, currentSel):
  currentDir  = self["myMenu"].VVp3Vb()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVh5Xt():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVmQZX(self):
  return self["myMenu"].getSelection()[0]
 def VVH5ui(self):
  FF3ty7(self)
  path = self.VVVN3a(self.VVmQZX())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VVSmWK = self.VV3kaT()
  if VVSmWK and len(VVSmWK) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VV6GRg(path)
  if self.mode == self.VVCpDL and len(path) > 0:
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
  else:
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
 def VV6GRg(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVBeRt(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVAf10(self):
  if self.mode == self.VVCpDL:
   path  = self.VVVN3a(self.VVmQZX())
   isDir  = os.path.isdir(path)
   VVY2K2 = []
   VVY2K2.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVjKzk(path):
     sepShown = True
     VVY2K2.append(VV8PP6)
     VVY2K2.append( (VVEAFU + "Archiving / Packaging"      , "VVGXfo"  ))
    if self.VVGPkp(path):
     if not sepShown:
      VVY2K2.append(VV8PP6)
     VVY2K2.append( (VVEAFU + "Read Backup information"     , "VVfhwN"  ))
     VVY2K2.append( (VVEAFU + "Compress Octagon Image (to zip File)"  , "VVKx3T" ))
   elif os.path.isfile(path):
    selFile = self.VVmQZX()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar")) : VVY2K2.extend(self.VVflCz(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVY2K2.extend(self.VVro7X(True))
    elif selFile.endswith(".m3u")              : VVY2K2.extend(self.VVQhkw(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FFQBQX(path):
     VVY2K2.append(VV8PP6)
     VVY2K2.append((VVEAFU + "View" , "text_View" ))
     VVY2K2.append((VVEAFU + "Edit" , "text_Edit" ))
    if len(txt) > 0:
     VVY2K2.append(VV8PP6)
     VVY2K2.append(   (VVEAFU + txt      , "VVpFK3"  ))
   VVY2K2.append(VV8PP6)
   VVY2K2.append(     ("Create SymLink"       , "VVXPQR" ))
   if not self.VVjKzk(path):
    VVY2K2.append(   ("Rename"          , "VV5v6m" ))
    VVY2K2.append(   ("Copy"           , "copyFileOrDir" ))
    VVY2K2.append(   ("Move"           , "moveFileOrDir" ))
    VVY2K2.append(   ("DELETE"          , "VVVxoR" ))
    if fileExists(path):
     VVY2K2.append(VV8PP6)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVY2K2.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVY2K2.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVY2K2.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVY2K2.append(VV8PP6)
   VVY2K2.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVY2K2.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   VVY2K2.append(VV8PP6)
   VVY2K2.append(    ("Set current directory as \"Startup Path\"" , "VVeYQG" ))
   FFlTf2(self, self.VVzkRL, title="Options", VVY2K2=VVY2K2)
 def VVzkRL(self, item=None):
  if self.mode == self.VVCpDL:
   if item is not None:
    path = self.VVVN3a(self.VVmQZX())
    selFile = self.VVmQZX()
    if   item == "properties"    : self.VVxU4o()
    elif item == "VVGXfo"  : self.VVGXfo(path)
    elif item == "VVfhwN"  : self.VVfhwN(path)
    elif item == "VVKx3T" : self.VVKx3T(path)
    elif item.startswith("extract_")  : self.VVKFgE(path, selFile, item)
    elif item.startswith("script_")   : self.VVuX18(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVMrkrItem_m3u(path, selFile, item)
    elif item.startswith("text_View")  : FFruOl(self, path)
    elif item.startswith("text_Edit")  : CCs3j1(self, path)
    elif item == "chmod644"     : self.VVoSA9(path, selFile, "644")
    elif item == "chmod755"     : self.VVoSA9(path, selFile, "755")
    elif item == "chmod777"     : self.VVoSA9(path, selFile, "777")
    elif item == "VVXPQR"   : self.VVXPQR(path, selFile)
    elif item == "VV5v6m"   : self.VV5v6m(path, selFile)
    elif item == "copyFileOrDir"   : self.VVVyUs(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVVyUs(path, selFile, True)
    elif item == "VVVxoR"   : self.VVVxoR(path, selFile)
    elif item == "createNewFile"   : self.VVbBXc(path, True)
    elif item == "createNewDir"    : self.VVbBXc(path, False)
    elif item == "VVeYQG"   : self.VVeYQG(path)
    elif item == "VVpFK3"    : self.VVpFK3()
    else         : self.close()
 def VVpFK3(self):
  selFile = self.VVmQZX()
  path  = self.VVVN3a(selFile)
  if os.path.isfile(path):
   VVrfZj = []
   category = self["myMenu"].VVkTXZ(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVZdGR(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FFQUuK(self, selFile, path)
   elif category == "txt"         : FFruOl(self, path)
   elif category in ("tar", "zip", "rar")     : self.VVIO2r(path, selFile)
   elif category == "scr"         : self.VV1v9Z(path, selFile)
   elif category == "m3u"         : self.VVstBh(path, selFile)
   elif category in ("ipk", "deb")       : self.VV9JJD(path, selFile)
   elif category == "mus"         : self.VVmtu3(path)
   elif category == "mov"         : self.VVmtu3(path)
   elif not FFQBQX(path)        : FFruOl(self, path)
 def VVmtu3(self, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   FFBoZM(self, refCode)
  except:
   pass
 def VVxpfv(self):
  path = self.VVVN3a(self.VVmQZX())
  action = self.VV6GRg(path)
  if action == 1:
   self.VVpNUE(path)
   FF3ty7(self, "Added", 500)
  elif action == -1:
   self.VV6PcN(path)
   FF3ty7(self, "Removed", 500)
  self.VV6GRg(path)
 def VVpNUE(self, path):
  VVSmWK = self.VV3kaT()
  if not VVSmWK:
   VVSmWK = []
  if len(VVSmWK) >= self.VVzKAo:
   FFGIBw(SELF, "Max bookmarks reached (max=%d)." % self.VVzKAo)
  elif not path in VVSmWK:
   VVSmWK = [path] + VVSmWK
   self.VVEjyo(VVSmWK)
 def VVA4u1(self):
  VVSmWK = self.VV3kaT()
  if VVSmWK:
   newList = []
   for line in VVSmWK:
    newList.append((line, line))
   VVMVMB  = ("Delete"  , self.VVQcmE )
   VVHN3c = ("Move Up"   , self.VV8WxS )
   VVfEjQ  = ("Move Down" , self.VVbFxs )
   self.bookmarkMenu = FFlTf2(self, self.VVzG6C, title="Bookmarks", VVY2K2=newList, VVMVMB=VVMVMB, VVHN3c=VVHN3c, VVfEjQ=VVfEjQ)
 def VVQcmE(self, VVmQZXObj, path):
  if self.bookmarkMenu:
   VVSmWK = self.VV6PcN(path)
   self.bookmarkMenu.VVC83f(VVSmWK)
 def VV8WxS(self, VVmQZXObj, path):
  if self.bookmarkMenu:
   VVSmWK = self.bookmarkMenu.VVUrdH(True)
   if VVSmWK:
    self.VVEjyo(VVSmWK)
 def VVbFxs(self, VVmQZXObj, path):
  if self.bookmarkMenu:
   VVSmWK = self.bookmarkMenu.VVUrdH(False)
   if VVSmWK:
    self.VVEjyo(VVSmWK)
 def VVzG6C(self, folder=None):
  if folder:
   if not folder.endswith("/"):
    folder += "/"
   self["myMenu"].VV32nw(folder)
   self["myMenu"].moveToIndex(0)
  self.VVH5ui()
 def VV3kaT(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVBeRt(self, path):
  VVSmWK = self.VV3kaT()
  if VVSmWK and path in VVSmWK:
   return True
  else:
   return False
 def VVeUlc(self):
  if VV3kaT():
   return True
  else:
   return False
 def VVEjyo(self, VVSmWK):
  line = ",".join(VVSmWK)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VV6PcN(self, path):
  VVSmWK = self.VV3kaT()
  if VVSmWK:
   while path in VVSmWK:
    VVSmWK.remove(path)
   self.VVEjyo(VVSmWK)
   return VVSmWK
 def VVeYQG(self, path):
  if not os.path.isdir(path):
   path = FFXMLs(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVZdGR(self, selFile, VVVbzS, command):
  FFhMkA(self, boundFunction(FFRQmD, self, command, VVB9mM=self.VVTuXk), "%s\n\n%s" % (VVVbzS, selFile))
 def VVflCz(self, path, calledFromMenu):
  destPath = self.VVdZ4C(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVY2K2 = []
  if calledFromMenu:
   VVY2K2.append(VV8PP6)
   color = VVEAFU
  else:
   color = ""
  VVY2K2.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVY2K2.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVY2K2.append((color + "Extract Here"            , "extract_here"  ))
  if VVlmpc and path.endswith(".tar.gz"):
   VVY2K2.append(VV8PP6)
   VVY2K2.append((color + 'Convert to ".ipk" Package' , "VVTkuB"  ))
   VVY2K2.append((color + 'Convert to ".deb" Package' , "VV09Xe"  ))
  return VVY2K2
 def VVIO2r(self, path, selFile):
  FFlTf2(self, boundFunction(self.VVKFgE, path, selFile), title="Compressed File Options", VVY2K2=self.VVflCz(path, False))
 def VVKFgE(self, path, selFile, item=None):
  if item is not None:
   parent  = FFXMLs(path, False)
   destPath = self.VVdZ4C(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VV1xmU
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FF1ECy("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FF1ECy("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VV1xmU, VV1xmU)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFTlgq(self, cmd)
   elif path.endswith(".zip"):
    self.VVZl33(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif path.endswith(".rar"):
    self.VVcBhM(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFdgmD("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVZdGR(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVZdGR(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFXMLs(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVZdGR(selFile, "Extract Here ?"      , cmd)
   elif item == "VVTkuB" : self.VVTkuB(path)
   elif item == "VV09Xe" : self.VV09Xe(path)
 def VVdZ4C(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVZl33(self, item, path, parent, destPath, VVVbzS):
  FFhMkA(self, boundFunction(self.VVEfj8, item, path, parent, destPath), VVVbzS)
 def VVEfj8(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VV1xmU
  cmd  = FF1ECy("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFAawR(destPath, VVFGoE))
  cmd +=   sep
  cmd += "fi;"
  FF9imV(self, cmd, VVB9mM=self.VVTuXk)
 def VVcBhM(self, item, path, parent, destPath, VVVbzS):
  FFhMkA(self, boundFunction(self.VVqVIS, item, path, parent, destPath), VVVbzS)
 def VVqVIS(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FF0hsM(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VV1xmU
  cmd  = FF1ECy("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFAawR(destPath, VVFGoE))
  cmd +=   sep
  cmd += "fi;"
  FF9imV(self, cmd, VVB9mM=self.VVTuXk)
 def VVro7X(self, addSep=False):
  VVY2K2 = []
  if addSep:
   VVY2K2.append(VV8PP6)
  VVY2K2.append((VVEAFU + "View Script File"  , "script_View"  ))
  VVY2K2.append((VVEAFU + "Execute Script File" , "script_Execute" ))
  VVY2K2.append((VVEAFU + "Edit"     , "script_Edit" ))
  return VVY2K2
 def VV1v9Z(self, path, selFile):
  FFlTf2(self, boundFunction(self.VVuX18, path, selFile), title="Script File Options", VVY2K2=self.VVro7X())
 def VVuX18(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFruOl(self, path)
   elif item == "script_Execute" : self.VVZdGR(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCs3j1(self, path)
 def VVQhkw(self, addSep=False):
  VVY2K2 = []
  if addSep:
   VVY2K2.append(VV8PP6)
  VVY2K2.append((VVEAFU + "View"      , "m3u_View" ))
  VVY2K2.append((VVEAFU + "Edit"      , "m3u_Edit" ))
  VVY2K2.append((VVEAFU + "Convert to IPTV Bouquet" , "m3u_Convert" ))
  return VVY2K2
 def VVstBh(self, path, selFile):
  FFlTf2(self, boundFunction(self.VVMrkrItem_m3u, path, selFile), title="M3U File Options", VVY2K2=self.VVQhkw())
 def VVMrkrItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_View"  : FFruOl(self, path)
   elif item == "m3u_Edit"  : CCs3j1(self, path)
   elif item == "m3u_Convert" : CCfvbT.VVhHO5(self, path, False)
 def VVoSA9(self, path, selFile, newChmod):
  FFhMkA(self, boundFunction(self.VVBC2n, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVBC2n(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVOmuD)
  result = FF3QAx(cmd)
  if result == "Successful" : FFrLx8(self, result)
  else      : FFGIBw(self, result)
 def VVXPQR(self, path, selFile):
  parent = FFXMLs(path, False)
  self.session.openWithCallback(self.VVlYZ9, boundFunction(CCQ4SG, mode=CCQ4SG.VVMcRv, VVbrP2=parent, VVbPwT="Create Symlink here"))
 def VVlYZ9(self, newPath):
  if len(newPath) > 0:
   target = self.VVVN3a(self.VVmQZX())
   target = FFaMIL(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FF0hsM(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFGIBw(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFhMkA(self, boundFunction(self.VVl8e3, target, link), "Create Soft Link ?\n\n%s" % txt, VVydGz=True)
 def VVl8e3(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVOmuD)
  result = FF3QAx(cmd)
  if result == "Successful" : FFrLx8(self, result)
  else      : FFGIBw(self, result)
 def VV5v6m(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFwT6k(self, boundFunction(self.VVfMti, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVfMti(self, path, selFile, VVL1IG):
  if VVL1IG:
   parent = FFXMLs(path, True)
   if os.path.isdir(path):
    path = FFaMIL(path)
   newName = parent + VVL1IG
   cmd = "mv '%s' '%s' %s" % (path, newName, VVOmuD)
   if VVL1IG:
    if selFile != VVL1IG:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFhMkA(self, boundFunction(self.VV1sjM, cmd), message, title="Rename file?")
    else:
     FFGIBw(self, "Cannot use same name!", title="Rename")
 def VV1sjM(self, cmd):
  result = FF3QAx(cmd)
  if "Fail" in result:
   FFGIBw(self, result)
  self.VVTuXk()
 def VVVyUs(self, path, selFile, isMove):
  if isMove : VVbPwT = "Move to here"
  else  : VVbPwT = "Copy to here"
  parent = FFXMLs(path, False)
  self.session.openWithCallback(boundFunction(self.VVwvdF, isMove, path, selFile)
         , boundFunction(CCQ4SG, mode=CCQ4SG.VVMcRv, VVbrP2=parent, VVbPwT=VVbPwT))
 def VVwvdF(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFaMIL(path)
   newPath = FF0hsM(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFhMkA(self, boundFunction(FF0eWo, self, cmd, VVB9mM=self.VVTuXk), txt, VVydGz=True)
   else:
    FFGIBw(self, "Cannot %s to same directory !" % action.lower())
 def VVVxoR(self, path, fileName):
  path = FFaMIL(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFhMkA(self, boundFunction(self.VVFKOz, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVFKOz(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VVTuXk()
 def VVjKzk(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVcBAa and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVbBXc(self, path, isFile):
  dirName = FF0hsM(os.path.dirname(path))
  if isFile : objName, VVL1IG = "File"  , self.edited_newFile
  else  : objName, VVL1IG = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFwT6k(self, boundFunction(self.VVS4iK, dirName, isFile, title), title=title, defaultText=VVL1IG, message="Enter %s Name:" % objName)
 def VVS4iK(self, dirName, isFile, title, VVL1IG):
  if VVL1IG:
   if isFile : self.edited_newFile = VVL1IG
   else  : self.edited_newDir  = VVL1IG
   path = dirName + VVL1IG
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVOmuD)
    else  : cmd = "mkdir '%s' %s" % (path, VVOmuD)
    result = FF3QAx(cmd)
    if "Fail" in result:
     FFGIBw(self, result)
    self.VVTuXk()
   else:
    FFGIBw(self, "Name already exists !\n\n%s" % path, title)
 def VV9JJD(self, path, selFile):
  VVY2K2 = []
  VVY2K2.append(("List Package Files"          , "VVdiAJ"     ))
  VVY2K2.append(("Package Information"          , "VVhSbd"     ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Install Package"           , "VVJMKS_CheckVersion" ))
  VVY2K2.append(("Install Package (force reinstall)"      , "VVJMKS_ForceReinstall" ))
  VVY2K2.append(("Install Package (force downgrade)"      , "VVJMKS_ForceDowngrade" ))
  VVY2K2.append(("Install Package (ignore failed dependencies)"    , "VVJMKS_IgnoreDepends" ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Remove Related Package"         , "VVpMOV_ExistingPackage" ))
  VVY2K2.append(("Remove Related Package (force remove)"     , "VVpMOV_ForceRemove"  ))
  VVY2K2.append(("Remove Related Package (ignore failed dependencies)"  , "VVpMOV_IgnoreDepends" ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("Extract Files"           , "VVXjko"     ))
  VVY2K2.append(("Unbuild Package"           , "VVSYuF"     ))
  FFlTf2(self, boundFunction(self.VVEDWc, path, selFile), VVY2K2=VVY2K2)
 def VVEDWc(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVdiAJ"      : self.VVdiAJ(path, selFile)
   elif item == "VVhSbd"      : self.VVhSbd(path)
   elif item == "VVJMKS_CheckVersion"  : self.VVJMKS(path, selFile, VVXJyy     )
   elif item == "VVJMKS_ForceReinstall" : self.VVJMKS(path, selFile, VVwrhV )
   elif item == "VVJMKS_ForceDowngrade" : self.VVJMKS(path, selFile, VVPsXk )
   elif item == "VVJMKS_IgnoreDepends" : self.VVJMKS(path, selFile, VVhTwG )
   elif item == "VVpMOV_ExistingPackage" : self.VVpMOV(path, selFile, VVppV2     )
   elif item == "VVpMOV_ForceRemove"  : self.VVpMOV(path, selFile, VV9MSv  )
   elif item == "VVpMOV_IgnoreDepends"  : self.VVpMOV(path, selFile, VVZWgG )
   elif item == "VVXjko"     : self.VVXjko(path, selFile)
   elif item == "VVSYuF"     : self.VVSYuF(path, selFile)
   else           : self.close()
 def VVdiAJ(self, path, selFile):
  if FFC4Sn("ar") : cmd = "allOK='1';"
  else    : cmd  = FFWCzm()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VV1xmU, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VV1xmU, VV1xmU)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFBFZP(self, cmd, VVB9mM=self.VVTuXk)
 def VVXjko(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFXMLs(path, True) + selFile[:-4]
  cmd  =  FFWCzm()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFdgmD("mkdir '%s'" % dest) + ";"
  cmd +=    FFdgmD("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFAawR(dest, VVFGoE))
  cmd += "fi;"
  FFRQmD(self, cmd, VVB9mM=self.VVTuXk)
 def VVSYuF(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VV8RGu = os.path.splitext(path)[0]
  else        : VV8RGu = path + "_"
  if path.endswith(".deb")   : VV5TJJ = "DEBIAN"
  else        : VV5TJJ = "CONTROL"
  cmd  = FFWCzm()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VV8RGu, FFdhfa())
  cmd += "  mkdir '%s';"    % VV8RGu
  cmd += "  CONTPATH='%s/%s';"  % (VV8RGu, VV5TJJ)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VV8RGu
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VV8RGu, VV8RGu)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VV8RGu
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VV8RGu, VV8RGu)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VV8RGu
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VV8RGu
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VV8RGu, FFAawR(VV8RGu, VVFGoE))
  cmd += "fi;"
  FFRQmD(self, cmd, VVB9mM=self.VVTuXk)
 def VVhSbd(self, path):
  listCmd  = FFBzKc(VV42eY, "")
  infoCmd  = FF6Z6k(VV4TlP , "")
  filesCmd = FF6Z6k(VVjQPZ, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FF12CE(VVclxO)
   notInst = "Package not installed."
   cmd  = FFamyI("File Info", VVclxO)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFamyI("System Info", VVclxO)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFAawR(notInst, VVEAFU))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFamyI("Related Files", VVclxO)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFTlgq(self, cmd)
  else:
   FFvteW(self)
 def VVJMKS(self, path, selFile, cmdOpt):
  cmd = FF6Z6k(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFhMkA(self, boundFunction(FFRQmD, self, cmd, VVB9mM=FFUTZz), "Install Package ?\n\n%s" % selFile)
  else:
   FFvteW(self)
 def VVpMOV(self, path, selFile, cmdOpt):
  listCmd  = FFBzKc(VV42eY, "")
  infoCmd  = FF6Z6k(VV4TlP, "")
  instRemCmd = FF6Z6k(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFAawR(errTxt, VVEAFU))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFAawR(cannotTxt, VVEAFU))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFAawR(tryTxt, VVEAFU))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFhMkA(self, boundFunction(FFRQmD, self, cmd, VVB9mM=FFUTZz), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFvteW(self)
 def VVUdiI(self, path):
  hostName = FF3QAx("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVGPkp(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVUdiI(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVGXfo(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVY2K2 = []
  VVY2K2.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVY2K2.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVY2K2.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVY2K2.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVY2K2.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVY2K2.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVY2K2.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVY2K2.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVY2K2.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVY2K2.append(VV8PP6)
  VVY2K2.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVY2K2.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FFlTf2(self, boundFunction(self.VVFXJB, path), VVY2K2=VVY2K2)
 def VVFXJB(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVlNmY(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVlNmY(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVlNmY(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVlNmY(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVlNmY(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVlNmY(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVlNmY(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVlNmY(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVlNmY(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVlNmY(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VV9Opw(path, False)
   elif item == "convertDirToDeb"   : self.VV9Opw(path, True)
   else         : self.close()
 def VV9Opw(self, path, VV49od):
  self.session.openWithCallback(self.VVTuXk, boundFunction(CCQGzc, path=path, VV49od=VV49od))
 def VVlNmY(self, path, fileExt, preserveDirStruct):
  parent  = FFXMLs(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FF1ECy("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FF1ECy("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FF1ECy("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VV1xmU
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFdgmD("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FFAawR(resultFile, VVFGoE))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FFAawR(failed, VVu486))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFBFZP(self, cmd, VVB9mM=self.VVTuXk)
 def VVfhwN(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFruOl(self, versionFile)
 def VVKx3T(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVUdiI(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFGIBw(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFrxQp(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFXMLs(path, False)
  VV8RGu = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FFAawR(errCmd, VVu486))
  installCmd = FF6Z6k(VVXJyy , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VV8RGu, VV8RGu)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VV8RGu
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VV8RGu
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VV8RGu, VV8RGu)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFRQmD(self, cmd, VVB9mM=self.VVTuXk)
 def VVTkuB(self, path):
  FFGIBw(self, "Under Construction.")
 def VV09Xe(self, path):
  FFGIBw(self, "Under Construction.")
class CC4dTO(MenuList):
 def __init__(self, VV82RO=False, directory="/", VVjPmp=True, VV58dD=True, VVJRr3=True, VVTQyO=None, VV3w0t=False, VVKa0Y=False, VVRow4=False, isTop=False, VVfDzo=None, VVN7KF=1000, VV715D=30, VVENRM=30, VVIxZg="#00000000"):
  MenuList.__init__(self, list, VV82RO, eListboxPythonMultiContent)
  self.VVjPmp  = VVjPmp
  self.VV58dD    = VV58dD
  self.VVJRr3  = VVJRr3
  self.VVTQyO  = VVTQyO
  self.VV3w0t   = VV3w0t
  self.VVKa0Y   = VVKa0Y or []
  self.VVRow4   = VVRow4 or []
  self.isTop     = isTop
  self.additional_extensions = VVfDzo
  self.VVN7KF    = VVN7KF
  self.VV715D    = VV715D
  self.VVENRM    = VVENRM
  self.pngBGColor    = FFnbxL(VVIxZg)
  self.EXTENSIONS    = self.VV13B2()
  self.VVAWP7   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVOYdo, self.VV715D))
  self.l.setItemHeight(self.VVENRM)
  self.png_mem   = self.VVMIp8("mem")
  self.png_usb   = self.VVMIp8("usb")
  self.png_fil   = self.VVMIp8("fil")
  self.png_dir   = self.VVMIp8("dir")
  self.png_dirup   = self.VVMIp8("dirup")
  self.png_srv   = self.VVMIp8("srv")
  self.png_slwfil   = self.VVMIp8("slwfil")
  self.png_slbfil   = self.VVMIp8("slbfil")
  self.png_slwdir   = self.VVMIp8("slwdir")
  self.VVal0l()
  self.VV32nw(directory)
 def VVMIp8(self, category):
  return LoadPixmap("%s%s.png" % (VVCmbD, category), getDesktop(0))
 def VV13B2(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "rar" : "rar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u"
  }
 def VVObAf(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFaMIL(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFARnG(" -> " , VVclxO) + FFARnG(os.readlink(path), VVFGoE)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVENRM + 10, 0, self.VVN7KF, self.VVENRM, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVxRFr: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVENRM-4, self.VVENRM-4, png, self.pngBGColor, self.pngBGColor, VVxRFr))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVENRM-4, self.VVENRM-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVkTXZ(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVal0l(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVcv03(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVgnPw(self, file):
  if os.path.realpath(file) == file:
   return self.VVcv03(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVcv03(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVcv03(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVHcfz(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVAWP7.info(l[0][0]).getEvent(l[0][0])
 def VVETSW(self):
  return self.list
 def VVhhmn(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VV32nw(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVJRr3:
    self.current_mountpoint = self.VVgnPw(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVJRr3:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVRow4 and not self.VVhhmn(path, self.VVKa0Y):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVObAf(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VV3w0t:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVAWP7 = eServiceCenter.getInstance()
   list = VVAWP7.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVjPmp and not self.isTop:
   if directory == self.current_mountpoint and self.VVJRr3:
    self.list.append(self.VVObAf(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVRow4 and self.VVcv03(directory) in self.VVRow4):
    self.list.append(self.VVObAf(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVjPmp:
   for x in directories:
    if not (self.VVRow4 and self.VVcv03(x) in self.VVRow4) and not self.VVhhmn(x, self.VVKa0Y):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVObAf(name = name, absolute = x, isDir = True, png = png))
  if self.VV58dD:
   for x in files:
    if self.VV3w0t:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFARnG(" -> " , VVclxO) + FFARnG(target, VVFGoE)
       else:
        png = self.png_slbfil
        name += FFARnG(" -> " , VVclxO) + FFARnG(target, VVu486)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVkTXZ(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVCmbD, category))
    if (self.VVTQyO is None) or iCompile(self.VVTQyO).search(path):
     self.list.append(self.VVObAf(name = name, absolute = x , isDir = False, png = png))
  if self.VVJRr3 and len(self.list) == 0:
   self.list.append(self.VVObAf(name = FFARnG("No USB connected", VVPTHk), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVp3Vb(self):
  return self.current_directory
 def VVh5Xt(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VV32nw(self.getSelection()[0], select = self.current_directory)
 def VVztgB(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VV4jNo(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVBnHE)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVBnHE)
 def refresh(self):
  self.VV32nw(self.current_directory, self.VVztgB())
 def VVBnHE(self, action, device):
  self.VVal0l()
  if self.current_directory is None:
   self.refresh()
class CChG66(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FFdxjB(VVSsGW, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVSmWK   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVLouD(defFG, "#00FFFFFF")
  self.defBG   = self.VVLouD(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFSskZ(self, self.Title)
  self["keyRed"].show()
  FFkqlb(self["keyGreen"] , "< > Transp.")
  FFkqlb(self["keyYellow"], "Foreground")
  FFkqlb(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVbXW0        ,
   "yellow"   : boundFunction(self.VVUlAY, False)  ,
   "blue"   : boundFunction(self.VVUlAY, True)  ,
   "up"   : self.VVq2Fv          ,
   "down"   : self.VVTlAE         ,
   "left"   : self.VVVkoz         ,
   "right"   : self.VV07jt         ,
   "last"   : boundFunction(self.VV3G2a, -5) ,
   "next"   : boundFunction(self.VV3G2a, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVJId3)
 def VVJId3(self):
  self.onShown.remove(self.VVJId3)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFidK4(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFidK4(self["keyRed"] , c)
  FFidK4(self["keyGreen"] , c)
  self.VVW0kR()
  self.VVfENm()
  FFRivu(self["myColorTst"], self.defFG)
  FFidK4(self["myColorTst"], self.defBG)
 def VVLouD(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVfENm(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VV9eWd(0, 0)
     return
 def VVbXW0(self):
  self.close(self.defFG, self.defBG)
 def VVq2Fv(self): self.VV9eWd(-1, 0)
 def VVTlAE(self): self.VV9eWd(1, 0)
 def VVVkoz(self): self.VV9eWd(0, -1)
 def VV07jt(self): self.VV9eWd(0, 1)
 def VV9eWd(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVscom()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVPV6A()
 def VVW0kR(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVPV6A(self):
  color = self.VVscom()
  if self.isBgMode: FFidK4(self["myColorTst"], color)
  else   : FFRivu(self["myColorTst"], color)
 def VVUlAY(self, isBg):
  self.isBgMode = isBg
  self.VVW0kR()
  self.VVfENm()
 def VV3G2a(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VV9eWd(0, 0)
 def VV3Pgw(self):
  return hex(self.transp)[2:].zfill(2)
 def VVscom(self):
  return ("#%s%s" % (self.VV3Pgw(), self.colors[self.curRow][self.curCol])).upper()
class CCkXXD(ScrollLabel):
 def __init__(self, parentSELF, text="", VVe0mT=True):
  ScrollLabel.__init__(self, text)
  self.VVe0mT=VVe0mT
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VV0WTc  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VV715D    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close   ,
   "cancel"  : parentSELF.close   ,
   "red"   : self.VVYOx8   ,
   "green"   : self.VV3CR6  ,
   "yellow"  : self.VVA9Sh  ,
   "blue"   : self.VVJZE6  ,
   "up"   : self.pageUp    ,
   "down"   : self.pageDown    ,
   "left"   : self.pageUp    ,
   "right"   : self.pageDown    ,
   "pageUp"  : self.VVEhZA    ,
   "chanUp"  : self.VVEhZA    ,
   "pageDown"  : self.VVi1CT    ,
   "chanDown"  : self.VVi1CT
  }, -1)
 def VVwJt1(self, isResizable=True, VVug7i=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FF65Ci(self.parentSELF, True)
  self.isResizable = isResizable
  if VVug7i:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VV715D  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFidK4(self, color)
 def FFidK4Color(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VV0WTc - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVcWBP()
 def pageUp(self):
  if self.VV0WTc > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VV0WTc > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVEhZA(self):
  self.setPos(0)
 def VVi1CT(self):
  self.setPos(self.VV0WTc-self.pageHeight)
 def VVikEx(self):
  return self.VV0WTc <= self.pageHeight or self.curPos == self.VV0WTc - self.pageHeight
 def VVcWBP(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VV0WTc, 3))
   start = int((100 - vis) * self.curPos / (self.VV0WTc - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VV51s0=VVbrHn):
  old_VVikEx = self.VVikEx()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VV0WTc = self.long_text.calculateSize().height()
   if self.VVe0mT and self.VV0WTc > self.pageHeight:
    self.scrollbar.show()
    self.VVcWBP()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VV0WTc))
   if   VV51s0 == VVyd8y: self.setPos(0)
   elif VV51s0 == VVtGrg : self.VVi1CT()
   elif old_VVikEx    : self.VVi1CT()
 def appendText(self, text, VV51s0=VVtGrg):
  self.setText(self.message + str(text), VV51s0)
 def VVA9Sh(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVfRVi(size)
 def VVJZE6(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVfRVi(size)
 def VV3CR6(self):
  self.VVfRVi(self.VV715D)
 def VVfRVi(self, VV715D):
  self.long_text.setFont(gFont(self.fontFamily, VV715D))
  self.setText(self.message, VV51s0=VVbrHn)
  self.VVhchq(calledFromFontSizer=True)
 def VVYOx8(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FF0hsM(expPath), self.textOutFile, FFgfmJ())
    with open(outF, "w") as f:
     f.write(FFt6bT(self.message))
    FFrLx8(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FFGIBw(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVhchq(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VV0WTc > 0 and self.pageHeight > 0:
   if self.VV0WTc < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VV0WTc
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
