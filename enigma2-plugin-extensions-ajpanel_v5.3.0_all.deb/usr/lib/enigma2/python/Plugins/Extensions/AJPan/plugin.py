import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVbLfP   = "v5.3.0"
VVrtM3    = "03-06-2022"
EASY_MODE    = 0
VVg2uT   = 0
VVaEMk   = 0
VVkYQ0  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVnpau  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVGttK    = "/media/usb/"
VVbCMJ    = "/usr/share/enigma2/picon/"
VVvHjp = "/etc/enigma2/blacklist"
VVqs92   = "/etc/enigma2/"
VVb9f3  = "ajpanel_update_url"
VVD897   = "AJPan"
VVvRbf    = "AUTO FIND"
VVvtte    = ""
VVreXb    = "Regular"
VVG0cy      = "-" * 80
VVXQs5    = ("-" * 100, )
VVTyjD    = ""
VVAkQm   = " && echo 'Successful' || echo 'Failed!'"
VVnu0S    = []
VVx0qB  = "Cannot continue (No Enough Memory) !"
VVafbh  = False
VVZAX8  = False
VVI4VL = False
VVj3bT     = 0
VVdC1L    = 1
VV1Iri    = 2
VVtWog   = 3
VVZxuI    = 4
VVD1kn    = 5
VV0am5 = 6
VVOKrh = 7
VVkhdk  = 8
VVa0bl   = 9
VV3flR   = 10
VV1Occ   = 11
VVPrvy  = 12
VVmLkW  = 13
VVCR3g    = 14
VVFreb   = 15
VVSBiu   = 16
VVA69d    = 17
WINDOW_SUBTITLE    = 18
VVMHcp  = 19
VVJRBN   = 0
VV8XxG   = 1
VV08dq   = 2
def FFk1a9():
 fList = None
 try:
  from enigma import getFontFaces
  return set(getFontFaces())
 except:
  try:
   from skin import getFontFaces
   return set(getFontFaces())
  except:
   pass
 return [VVreXb]
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices=[ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.forceUtf8Encoding   = ConfigYesNo(default=True)
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsPath    = ConfigDirectory(default=VVvRbf, visible_width=51)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=51)
CFG.PIconsPath     = ConfigDirectory(default=VVbCMJ, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVGttK, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
tmp = [("srt", "From SRT File"), ("#FFFFFF", "White"), ("#C0C0C0", "Silver"), ("#808080", "Gray"), ("#000000", "Black"), ("#FF0000", "Red"), ("#800000", "Maroon"), ("#FFFF00", "Yellow"), ("#808000", "Olive"), ("#00FF00", "Lime"), ("#008000", "Green"), ("#00FFFF", "Aqua"), ("#008080", "Teal"), ("#0000FF", "Blue"), ("#000080", "Navy"), ("#FF00FF", "Fuchsia"), ("#800080", "Purple")]
CFG.subtDelay     = ConfigSelection(default="0.0", choices=[ (str(x/10.0),  str(x/10.0)) for x in range(-600, 600, 5) ])
CFG.subtTextFg     = ConfigSelection(default="srt", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVreXb, choices=[ (x,  x) for x in FFk1a9() ])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=80, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[ ("0", "Left"), ("1", "Center"), ("2", "Right") ])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=0, stepwidth=10, min=-140, max=140, wraparound=False)
del tmp
def FFQfFw():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVeh4M  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVbgGJ = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVeh4M  : return 0
  elif VVbgGJ : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVFj9r = FFQfFw()
VV0hxT = VVaDOU = VVlcHo = VVy89V = VVlVgH = VVGjTd = VV09cj = VVN5SF = COLOR_CONS_BRIGHT_YELLOW = VVO27w = VVbIFj = VVjxiW = VVodRY = ""
def FFiiWn()  : FFExw4(FFNSeu())
def FFBYwt()  : FFExw4(FFj46j())
def FFtUmM(tDict): FFExw4(iDumps(tDict, indent=4, sort_keys=True))
def FF7hKU(*args): FFYpPi(True, False, *args)
def FFExw4(*args) : FFYpPi(True , True , *args)
def FF977D(*args): FFYpPi(False, True , *args)
def FFYpPi(addSep=True, oneLine=True, *args):
 if VVg2uT:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if oneLine:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  else:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item:
      txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFVqie(txt, isAppend=True, ignoreErr=False):
 if VVg2uT:
  tm = FFg7GH()
  err = ""
  if not ignoreErr:
   err = FFj46j()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFExw4(err)
  FFExw4("Output Log File : %s" % fileName)
def FFj46j():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFg7GH()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except Exception as e:
  return "Cannot Trace !"
def FFNSeu():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVnu0S = []
def FFVdFu(win):
 global VVnu0S
 if not win in VVnu0S:
  VVnu0S.append(win)
def FFAsVx(*args):
 global VVnu0S
 for win in VVnu0S:
  try:
   win.close()
  except:
   pass
 VVnu0S = []
def FFo8m8():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VViyTm = FFo8m8()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFIgTf()     : return PluginDescriptor(fnc=FF2T1z, where=[PluginDescriptor.WHERE_SESSIONSTART] , needsRestart=True   , description="AJPanel Startup")
def FFcGu1()      : return getDescriptor(FFoLNh   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFSFlj()       : return getDescriptor(FFgm4R  , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFCRdd()   : return getDescriptor(FF3aAU , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFkYs5(): return getDescriptor(FFT5HA , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player"  , descr="Signal Monitor / Player")
def FFUJvr()  : return getDescriptor(FFCThJ  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV"     , descr="IPTV Menu")
def FFfDv7()     : return getDescriptor(FFBEKE , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info."    , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFcGu1() , FFSFlj() , FFIgTf() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFCRdd())
  result.append(FFkYs5())
  result.append(FFUJvr())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFfDv7())
 return result
def FF2T1z(reason, **kwargs):
 if reason == 0:
  FFhhIh()
  if "session" in kwargs:
   session = kwargs["session"]
   FFqZo5(session)
   CCswDV(session)
  CCgkMM.VVll3H()
def FFgm4R(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFoLNh, PLUGIN_NAME, 45)]
 else:
  return []
def FFoLNh(session, **kwargs):
 session.open(Main_Menu)
def FF3aAU(session, **kwargs):
 session.open(CC3ls7)
def FFT5HA(session, **kwargs):
 FFOftR(session, isFromSession=True)
def FFCThJ(session, **kwargs):
 session.open(CCSfuP)
def FFBEKE(session, **kwargs):
 session.open(CCXD20, fncMode=CCXD20.VVtcRb)
def FF3gAd():
 FFuMa3(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFCRdd(), FFkYs5(), FFUJvr() ])
 FFuMa3(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFfDv7() ])
def FFuMa3(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VVoQFM = None
def FFhhIh():
 try:
  global VVoQFM
  if VVoQFM is None:
   VVoQFM    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFmHHx
  ChannelContextMenu.FFAvfo = FFAvfo
 except:
  pass
def FFmHHx(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVoQFM(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFAvfo, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFAvfo, title1, csel, isFind=True))))
def FFAvfo(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFakZx(refCode)
 except:
  pass
 self.session.open(boundFunction(CC8CAz, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFqZo5(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FFcfOH, session, "lok")
 hk.actions['longCancel'] = boundFunction(FFcfOH, session, "lesc")
 hk.actions['longRed']  = boundFunction(FFcfOH, session, "lred")
def FFcfOH(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFOftR(session, isFromSession=True)
def FFeVzc(SELF, title="", addLabel=False, addScrollLabel=False, VVZCgs=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFgas2()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CC7jtx(SELF)
 if VVZCgs:
  SELF["myMenu"] = MenuList(VVZCgs)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVh5RL        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFotoW(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FFMqTv, SELF, "0") ,
  "1"    : boundFunction(FFMqTv, SELF, "1") ,
  "2"    : boundFunction(FFMqTv, SELF, "2") ,
  "3"    : boundFunction(FFMqTv, SELF, "3") ,
  "4"    : boundFunction(FFMqTv, SELF, "4") ,
  "5"    : boundFunction(FFMqTv, SELF, "5") ,
  "6"    : boundFunction(FFMqTv, SELF, "6") ,
  "7"    : boundFunction(FFMqTv, SELF, "7") ,
  "8"    : boundFunction(FFMqTv, SELF, "8") ,
  "9"    : boundFunction(FFMqTv, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FFeOSK, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFMqTv(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVodRY:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVodRY + SELF.keyPressed + VVaDOU)
    txt = VVaDOU + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFSoSp(SELF, txt)
def FFeOSK(SELF, tableObj, colNum):
 FFSoSp(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     SELF.VVXXtO(i)
     break
 except:
  pass
def FFNpLs(SELF, setMenuAction=True):
 if setMenuAction:
  global VVTyjD
  VVTyjD = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFgas2():
 return ("  %s" % VVTyjD)
def FFFMjq(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FF3aqm(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FF43YG(color):
 return parseColor(color).argb()
def FFdouS(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FF1BAe(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFXAgH(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFR6WL(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVodRY)
 else:
  return ""
def FFY0kl(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVG0cy, word, VVG0cy, VVodRY)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVG0cy, word, VVG0cy)
def FFc8cv(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVodRY
def FF9CYr(color):
 if color: return "echo -e '%s' %s;" % (VVG0cy, FFR6WL(VVG0cy, VVN5SF))
 else : return "echo -e '%s';" % VVG0cy
def FFE5E0(title, color):
 title = "%s\n%s\n%s\n" % (VVG0cy, title, VVG0cy)
 return FFc8cv(title, color)
def FFDd6I(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFb3C9(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFzMXn(callBackFunction):
 tCons = CCIDk1()
 tCons.ePopen("echo", boundFunction(FFNXT4, callBackFunction))
def FFNXT4(callBackFunction, result, retval):
 callBackFunction()
def FF9BOI(SELF, fnc, title="Processing ...", clearMsg=True):
 FFSoSp(SELF, title)
 tCons = CCIDk1()
 tCons.ePopen("echo", boundFunction(FFWbkR, SELF, fnc, clearMsg))
def FFWbkR(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFSoSp(SELF)
def FFNxEm(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVx0qB
  else       : return ""
def FFqFDg(cmd):
 txt = FFNxEm(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFgBpG(cmd):
 lines = FFqFDg(cmd)
 if lines: return lines[0]
 else : return ""
def FFpUsV(SELF, cmd):
 lines = FFqFDg(cmd)
 VV5uoU = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VV5uoU.append((key, val))
  elif line:
   VV5uoU.append((line, ""))
 if VV5uoU:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFuN9x(SELF, None, header=header, VVUQjT=VV5uoU, VV5Xly=widths, VVz3yz=28)
 else:
  FFGSHZ(SELF, cmd)
def FFGSHZ(    SELF, cmd, **kwargs): SELF.session.open(CCqLW6, VVk8hn=cmd, VVO0fm=True, VVRj8X=VV8XxG, **kwargs)
def FFzYJm(  SELF, cmd, **kwargs): SELF.session.open(CCqLW6, VVk8hn=cmd, **kwargs)
def FFO1e4(   SELF, cmd, **kwargs): SELF.session.open(CCqLW6, VVk8hn=cmd, VVCAUi=True, VVXjBW=True, VVRj8X=VV8XxG, **kwargs)
def FFYn0Z(  SELF, cmd, **kwargs): SELF.session.open(CCqLW6, VVk8hn=cmd, VVCAUi=True, VVXjBW=True, VVRj8X=VV08dq, **kwargs)
def FFeerf(  SELF, cmd, **kwargs): SELF.session.open(CCqLW6, VVk8hn=cmd, VVfpaM=True , **kwargs)
def FFpRGA( SELF, cmd, **kwargs): SELF.session.open(CCqLW6, VVk8hn=cmd, VVTbRA=True   , **kwargs)
def FFIszd( SELF, cmd, **kwargs): SELF.session.open(CCqLW6, VVk8hn=cmd, VV2MS9=True  , **kwargs)
def FF8avg(cmd):
 return cmd + " > /dev/null 2>&1"
def FFtj4I():
 return " > /dev/null 2>&1"
def FFIeTh(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FF1d0b(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFz9Zw():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFgBpG(cmd)
VVDa2A     = 0
VVs1Qc      = 1
VVKG32   = 2
VV22kn      = 3
VVtwsD      = 4
VVumyh     = 5
VVQ5tW     = 6
VVak7B = 7
VVtBDT = 8
VVTLRM = 9
VVuTFQ  = 10
VVsDlf     = 11
VVgKMV  = 12
VVoirB  = 13
def FFxiGu(parmNum, grepTxt):
 if   parmNum == VVDa2A  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVs1Qc   : param = ["list"   , "apt list" ]
 elif parmNum == VVKG32: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFz9Zw()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFfBk8(parmNum, package):
 if   parmNum == VV22kn      : param = ["info"      , "apt show"         ]
 elif parmNum == VVtwsD      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVumyh     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVQ5tW     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVak7B : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVtBDT : param = ["install --force-overwrite" , "dpkg -i --force-overwrite -y"    ]
 elif parmNum == VVTLRM : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVuTFQ  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVsDlf     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVgKMV  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVoirB  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFz9Zw()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFUx1o():
 result = FFgBpG("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFfBk8(VVQ5tW , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FF8avg("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FF8avg("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFR6WL(failed1, VVN5SF))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFR6WL(failed2, VVN5SF))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFR6WL(failed3, VVlcHo))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FF9qFB(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFfBk8(VVQ5tW , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FF8avg("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFR6WL(failed1, VVN5SF))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFR6WL(failed2, VVlcHo))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFnTgI(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FF8avg('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FF8avg("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FF1mdj(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCgkMM.VVsUfv()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FF5Wuv(path, keepends=False, maxSize=-1, encLst=None):
 txt = FF1mdj(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFtC7A(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFtcdQ(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FF1mdj(path, maxSize=maxSize, encLst=encLst)
  if lines: FFfnpN(SELF, lines, title=title, VVRj8X=VV8XxG)
  else : FFKXSw(SELF, path, title=title)
 else:
  FFzAsS(SELF, path, title)
def FFmggU(SELF, path, title):
 if fileExists(path):
  txt = FF1mdj(path)
  txt = txt.replace("#W#", VVodRY)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVaDOU)
  txt = txt.replace("#C#", VVO27w)
  txt = txt.replace("#P#", VVy89V)
  FFfnpN(SELF, txt, title=title)
 else:
  FFzAsS(SELF, path, title)
def FF3UaK(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FF5kOg(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFFeKp(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FF8MLZ(parent)
 else    : return FF2KYY(parent)
def FFtcdQ(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FF8MLZ(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FF2KYY(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFyCkg():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVkYQ0)
 paths.append(VVkYQ0.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FF5kOg(ba)
 for p in list:
  p = ba + p + VVkYQ0
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVD897, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVkYQ0, VVD897 , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVGEhl, VVMuIV = FFyCkg()
def FFuF9Y():
 def VVPveY(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 iPath = CFG.iptvHostsPath.getValue()
 if not iPath == VVvRbf and not pathExists(iPath):
  CFG.iptvHostsPath.setValue(VVvRbf)
  CFG.iptvHostsPath.save()
  oldIptvHostsPath = VVvRbf
 else:
  oldIptvHostsPath = ""
 oldMovieDownloadPath = VVPveY(CFG.MovieDownloadPath, CCXZq2.VVntBL())
 VVHaRU   = VVPveY(CFG.backupPath, CCrJRc.VV27e1())
 VVCKQy   = VVPveY(CFG.downloadedPackagesPath, t)
 VVbKQs  = VVPveY(CFG.exportedTablesPath, t)
 VVeIIS  = VVPveY(CFG.exportedPIconsPath, t)
 VVqQWA   = VVPveY(CFG.packageOutputPath, t)
 global VVGttK
 VVGttK = FF8MLZ(CFG.backupPath.getValue())
 if VVHaRU or VVqQWA or VVCKQy or VVbKQs or VVeIIS or oldIptvHostsPath or oldMovieDownloadPath:
  configfile.save()
 return VVHaRU, VVqQWA, VVCKQy, VVbKQs, VVeIIS, oldIptvHostsPath, oldMovieDownloadPath
def FFdi5c(path):
 path = FF2KYY(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFBXM8(SELF, pathList, tarFileName, addTimeStamp=True):
 VVUQjT = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVUQjT.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVUQjT.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVUQjT.append(path)
 if not VVUQjT:
  FF2VP5(SELF, "Files not found!")
 elif not pathExists(VVGttK):
  FF2VP5(SELF, "Path not found!\n\n%s" % VVGttK)
 else:
  VVieY5 = FF8MLZ(VVGttK)
  tarFileName = "%s%s" % (VVieY5, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFNMff())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVUQjT:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVG0cy
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFR6WL(tarFileName, VV09cj))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFR6WL(failed, VV09cj))
  cmd += "fi;"
  cmd +=  sep
  FFzYJm(SELF, cmd)
def FFCNiP(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFFfOJ(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFFfOJ(SELF["keyInfo"], "info")
def FFFfOJ(barObj, fName):
 path = "%s%s%s" % (VVMuIV, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFR6Ro(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFyBpM(satNum)
  return satName
def FFyBpM(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFWdKi(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFR6Ro(val)
  else  : sat = FFyBpM(val)
 return sat
def FFlT3U(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFR6Ro(num)
 except:
  pass
 return sat
def FF5e08(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFYxsR(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FF6SKb(info, iServiceInformation.sServiceref)
   prov = FF6SKb(info, iServiceInformation.sProvider)
   state = str(FF6SKb(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFKADs(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFlxg0(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FF6SKb(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFtv9b(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFakZx(refCode):
 info = FF0RcE(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFQQw0(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFwqN1(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FF0RcE(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVBJ9x = eServiceCenter.getInstance()
  if VVBJ9x:
   info = VVBJ9x.info(service)
 return info
def FFqYTj(SELF, refCode, VVEWCU=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  FFy4b2(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVEWCU:
   FFOftR(SELF, isFromSession)
 try:
  VVTjEU = InfoBar.instance
  if VVTjEU:
   VVd4be = VVTjEU.servicelist
   if VVd4be:
    servRef = eServiceReference(refCode)
    VVd4be.saveChannel(servRef)
 except:
  pass
def FFy4b2(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCDxGJ()
    if pr.VVOdui(refCode, chName, decodedUrl, iptvRef):
     pr.VVWmGa(SELF, isFromSession)
def FFKADs(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFyuoc(url): return FFM2IP(url) or FFOFuI(url)
def FFM2IP(url)  : return any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFOFuI(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FFlxg0(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFELTf(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FF4ns5(userBfile):
 txt = ""
 bFile = VVqs92 + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVqs92 + userBfile):
  fTxt = FF1mdj(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFgBpG('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
def FFELTf(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFEQKM(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFZHFJ(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FF65Vf(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFVr9Y(txt):
 try:
  return FFZHFJ(FF65Vf(txt)) == txt
 except:
  return False
def FFOftR(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCkg2V, isFromExternal=isFromSession)
 else      : FFqRsJ(session, reopen=True, isFromExternal=isFromSession)
def FFqRsJ(session, reopen=False, isFromExternal=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFqRsJ, session, isFromExternal=isFromExternal), boundFunction(CCTK9b, isFromExternal=isFromExternal))
  except:
   try:
    FF1fvG(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFOWnG(refCode):
 tp = CC14a1()
 if tp.VVo8eY(refCode) : return True
 else        : return False
def FFxJGc(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFg8wn():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FFEetI():
 VVTjEU = InfoBar.instance
 if VVTjEU:
  VVd4be = VVTjEU.servicelist
  if VVd4be:
   return VVd4be.getBouquetList()
 return None
def FFNRgf():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFVUtv():
 path = FFNRgf()
 if path:
  txt = FF1mdj(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FFUuQF():
 return FFfahj(InfoBar.instance.servicelist.getRoot())
def FFfahj(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVBJ9x = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVBJ9x.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FF1AA1():
 VVBltM = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VV1eve = list(VVBltM)
 return VV1eve, VVBltM
def FFv7fK():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFy2Gu(session, VVYbql):
 VV81MW, VVpAfT, VVn2a7, camCommand = FFUyst()
 if VVpAfT:
  runLog = False
  if   VVYbql == CCK8xN.VVflKA : runLog = True
  elif VVYbql == CCK8xN.VVFcmf : runLog = True
  elif not VVn2a7          : FF1fvG(session, message="SoftCam not started yet!")
  elif fileExists(VVn2a7)        : runLog = True
  else             : FF1fvG(session, message="File not found !\n\n%s" % VVn2a7)
  if runLog:
   session.open(boundFunction(CCK8xN, VV81MW=VV81MW, VVpAfT=VVpAfT, VVn2a7=VVn2a7, VVYbql=VVYbql))
 else:
  FF1fvG(session, message="No active OSCam/NCam found !", title="Live Log")
def FFUyst():
 VV81MW = "/etc/tuxbox/config/"
 VVpAfT = None
 VVn2a7  = None
 camCommand = FFgBpG("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVpAfT = "oscam"
 elif "ncam"  in camCommand : VVpAfT = "ncam"
 if VVpAfT:
  path = FFgBpG(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FF8MLZ(path)
  if pathExists(path):
   VV81MW = path
  tFile = VV81MW + VVpAfT + ".conf"
  tFile = FFgBpG("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVn2a7 = tFile
 return VV81MW, VVpAfT, VVn2a7, camCommand
def FF2SnK(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FF5AoR():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFNMff():
 return FF5AoR().replace(" ", "_").replace("-", "").replace(":", "")
def FFzrBt(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFg7GH():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFTJ9u(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCSfuP.VVhkWC(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCSfuP.VVZnMM_forBouquet(fName)
     phpFile = tmpDir + fName + ext
     os.system(FF8avg("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFir3e(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFe825(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
VVDKg5 = 0
def FF7oiO():
 global VVDKg5
 VVDKg5 = iTime()
def FFBZP8():
 FFExw4(">>>>>> Elapsed\t: {:.6f} seconds".format(iTime() - VVDKg5).rstrip("0").rstrip("."))
def FFiM80(SELF, message, title=""):
 SELF.session.open(boundFunction(CCxgSv, title=title, message=message, VVe8u6=True))
def FFfnpN(SELF, message, title="", VVRj8X=VV8XxG, **kwargs):
 SELF.session.open(boundFunction(CCxgSv, title=title, message=message, VVRj8X=VVRj8X, **kwargs))
def FF2VP5(SELF, message, title="")  : FF1fvG(SELF.session, message, title)
def FFzAsS(SELF, path, title="") : FF1fvG(SELF.session, "File not found !\n\n%s" % path, title)
def FFKXSw(SELF, path, title="") : FF1fvG(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFh46b(SELF, title="")  : FF1fvG(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FF1fvG(session, message, title="") : session.open(boundFunction(CCibc7, title=title, message=message))
def FFIPSl(SELF, VVx6WR, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVx6WR, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVx6WR, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVx6WR, boundFunction(CCi6Jy, title=title, message=message, VVr5f9=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FF2VP5(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFS238(SELF, callBack_Yes, VVg7BJ, callBack_No=None, title="", VVvjmj=False, VVLTw9=True):
 SELF.session.openWithCallback(boundFunction(FFaENo, callBack_Yes, callBack_No)
        , boundFunction(CCuwDV, title=title, VVg7BJ=VVg7BJ, VVLTw9=VVLTw9, VVvjmj=VVvjmj))
def FFaENo(callBack_Yes, callBack_No, FFS238ed):
 if FFS238ed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFSoSp(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FF1BAe(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFhm2L(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFJEIf(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVEI4o = eTimer()
def FFhm2L(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFgDO4, SELF))
 fnc = boundFunction(FFgDO4, SELF)
 try:
  t = VVEI4o.timeout.connect(fnc)
 except:
  VVEI4o.callback.append(fnc)
 VVEI4o.start(milliSeconds, 1)
def FFgDO4(SELF):
 VVEI4o.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFuN9x(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCO3DQ, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCO3DQ, **kwargs))
  FFVdFu(win)
  return win
 except:
  return None
def FF9y9t(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCWi2y, **kwargs))
 FFVdFu(win)
 return win
def FFQvwR(SELF, **kwargs):
 SELF.session.open(CCXD20, **kwargs)
def FFRpf0(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFeb2S(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVreXb, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFGCoH(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFeb2S(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFcFDM():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFLfoe(VVz3yz):
 screenSize  = FFcFDM()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVz3yz)
 return bodyFontSize
def FFwqPy(VVz3yz, extraSpace):
 font = gFont(VVreXb, VVz3yz)
 VVEXXT = fontRenderClass.getInstance().getLineHeight(font) or (VVz3yz * 1.25)
 return int(VVEXXT + VVEXXT * extraSpace)
def FFZerm(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFcFDM()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVreXb, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFwqPy(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVreXb, titleFontSize, alignLeftCenter)
 if winType == VVj3bT or winType == VVdC1L:
  if winType == VVdC1L : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVMHcp:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == WINDOW_SUBTITLE:
  lineH = int((height - 8) / 3.0)
  top = 2
  tmp += '<widget name="mySubtFr" position="0,0" size="%d,%d" zPosition="10" backgroundColor="#00FFFF00" />' % (width, height)
  for i in range(3):
   tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="11" foregroundColor="#ffffff" shadowColor="#555555" shadowOffset="-2,-2" backgroundColor="#ff000000" %s %s />' % (i, top + 2, width - 2, lineH - 2, bodyFontStr, alignCenter)
   top += lineH
 elif winType == VVCR3g:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FFiM80L = b2Left2 + timeW + marginLeft
  FFiM80W = b2Left3 - marginLeft - FFiM80L
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FFiM80L  , b2Top, FFiM80W , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
 elif winType == VVFreb:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVZxuI:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VV1Iri:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVtWog:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVreXb, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVreXb, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VV3flR:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFiM80H = int(bodyH * 0.5)
  inpTop = bodyTop + FFiM80H
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFiM80H, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVreXb, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVreXb, mapF, alignCenter)
 elif winType == VV1Occ:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVPrvy:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVreXb, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVSBiu:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVreXb, fontH, alignCenter)
 elif winType == VVmLkW:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVreXb, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVreXb, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVreXb, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVA69d:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVD1kn:
  tmp += '<widget name="myPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (marginLeft, bodyTop, bodyW, bodyH)
 else:
  if   winType == VVOKrh : align = alignLeftCenter
  elif winType == VV0am5 : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVa0bl:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVreXb
  if usefixedFont and winType == VV0am5:
   fnt = "Fixed"
   if fnt in FFk1a9():
    fontName = "Fixed"
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVz3yz = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVreXb, VVz3yz, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVJbor = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVreXb, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVJbor[i], VVreXb, barFont, alignCenter)
   left += btnW + gap
 if winType == VV0am5:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVJbor = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVJbor[i], VVreXb, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFZerm(VVj3bT, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.VV9Hgr = ""
  self.themsList  = []
  VVZCgs = []
  if VVaEMk:
   VVZCgs.append(("-- MY TEST --"    , "myTest"   ))
  VVZCgs.append(("  File Manager"     , "FileManager"  ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("  Services/Channels"    , "ChannelsTools" ))
  VVZCgs.append(("  IPTV"       , "IptvTools"  ))
  VVZCgs.append(("  PIcons"       , "PIconsTools"  ))
  VVZCgs.append(("  SoftCam"      , "SoftCam"   ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("  Plugins"      , "PluginsTools" ))
  VVZCgs.append(("  Terminal"      , "Terminal"  ))
  VVZCgs.append(("  Backup & Restore"    , "BackupRestore" ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("  Date/Time"      , "Date_Time"  ))
  VVZCgs.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVZCgs)
  FFeVzc(self, VVZCgs=VVZCgs)
  FFFMjq(self["keyRed"] , "Exit")
  FFFMjq(self["keyGreen"] , "Settings")
  FFFMjq(self["keyYellow"], "Dev. Info.")
  FFFMjq(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VV4ZQU       ,
   "yellow"  : self.VVyX6V       ,
   "blue"   : self.VVRhNh       ,
   "info"   : self.VVRhNh       ,
   "next"   : self.VV9FKm       ,
   "menu"   : self.VV9JSY     ,
   "text"   : self.VVJx55      ,
   "0"    : boundFunction(self.VVqk90, 0) ,
   "1"    : boundFunction(self.VVNhyA, 1)   ,
   "2"    : boundFunction(self.VVNhyA, 2)   ,
   "3"    : boundFunction(self.VVNhyA, 3)   ,
   "4"    : boundFunction(self.VVNhyA, 4)   ,
   "5"    : boundFunction(self.VVNhyA, 5)   ,
   "6"    : boundFunction(self.VVNhyA, 6)   ,
   "7"    : boundFunction(self.VVNhyA, 7)   ,
   "8"    : boundFunction(self.VVNhyA, 8)   ,
   "9"    : boundFunction(self.VVNhyA, 9)
  })
  self.onShown.append(self.VV3HNB)
  self.onClose.append(self.onExit)
  global VVafbh, VVZAX8, VVI4VL
  VVafbh = VVZAX8 = VVI4VL = False
 def VVh5RL(self):
  item = FFNpLs(self)
  self.VVNhyA(item)
 def VVNhyA(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVvnCM()
   elif item in ("FileManager"  , 1) : self.session.open(CC3ls7)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCze4R)
   elif item in ("IptvTools"  , 3) : self.session.open(CCSfuP)
   elif item in ("PIconsTools"  , 4) : self.VVAJCG()
   elif item in ("SoftCam"   , 5) : self.session.open(CCx7K4)
   elif item in ("PluginsTools" , 6) : self.session.open(CCFy5w)
   elif item in ("Terminal"  , 7) : self.session.open(CCoVeG)
   elif item in ("BackupRestore" , 8) : self.session.open(CC7PGU)
   elif item in ("Date_Time"  , 9) : self.session.open(CCR1l9)
   elif item in ("CheckInternet" , 10) : self.session.open(CCxU8N)
   else         : self.close()
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FFDd6I(self["myMenu"])
  FFGCoH(self)
  FFRpf0(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVbLfP)
  self["myTitle"].setText(title)
  VVHaRU, VVqQWA, VVCKQy, VVbKQs, VVeIIS, oldIptvHostsPath, oldMovieDownloadPath = FFuF9Y()
  self.VVx4JO()
  if VVHaRU or VVqQWA or VVCKQy or VVbKQs or VVeIIS or oldIptvHostsPath or oldMovieDownloadPath:
   VVeeeC = lambda path, subj: "%s:\n%s\n\n" % (subj, FFc8cv(path, VVlcHo)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVeeeC(oldIptvHostsPath  , "IPTV Hosts Files Path"   )
   txt += VVeeeC(VVHaRU   , "Backup/Restore Path"    )
   txt += VVeeeC(VVqQWA  , "Created Package Files (IPK/DEB)" )
   txt += VVeeeC(VVCKQy  , "Download Packages (from feeds)" )
   txt += VVeeeC(VVbKQs , "Exported Tables"     )
   txt += VVeeeC(VVeIIS , "Exported PIcons"     )
   txt += VVeeeC(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFfnpN(self, txt, title="Settings Paths")
  if (EASY_MODE or VVg2uT or VVaEMk):
   FF1BAe(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFSoSp(self, "Welcome", 300)
  FFzMXn(boundFunction(self.VVDBFU, title))
 def VVDBFU(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCrJRc.VVkIPZ()
   if url:
    newWebVer = CCrJRc.VVlVRr(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FF8avg("rm /tmp/ajpanel*"))
  global VVafbh, VVZAX8, VVI4VL
  VVafbh = VVZAX8 = VVI4VL = False
 def VVqk90(self, digit):
  self.VV9Hgr += str(digit)
  ln = len(self.VV9Hgr)
  global VVafbh, VVI4VL
  if ln == 4:
   if self.VV9Hgr == "0" * ln:
    VVafbh = True
    FF1BAe(self["myTitle"], "#800080")
   else:
    self.VV9Hgr = "x"
  elif self.VV9Hgr == "0" * 8:
   VVI4VL = True
 def VV9FKm(self):
  self.VV9Hgr += ">"
  if self.VV9Hgr == "0" * 4 + ">" * 2:
   global VVZAX8
   VVZAX8 = True
   FF1BAe(self["myTitle"], "#dd5588")
 def VVJx55(self):
  if self.VV9Hgr == "0" * 4:
   ok = False
   fnt = "ae_AlMateen.ttf"
   fontFile = "/usr/share/fonts/%s" % fnt
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    try:
     addFont(fontFile, fontName, 100, True)
     ok = True
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      ok = True
     except:
      pass
   if ok: txt = 'Added Font: "%s"' % fnt
   else : txt = '"%s" Not Found' % fnt
   FFSoSp(self, txt, 2000, isGrn=ok)
 def VVAJCG(self):
  found = False
  pPath = CCUKiz.VVxUr1()
  if pathExists(pPath):
   for fName, fType in CCUKiz.VVIB3P(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCUKiz)
  else:
   VVZCgs = []
   VVZCgs.append(("PIcons Manager" , "CCUKiz" ))
   VVZCgs.append(VVXQs5)
   VVZCgs.append(CCUKiz.VVQ6E3())
   VVZCgs.append(VVXQs5)
   VVZCgs += CCUKiz.VVQJbe()
   FF9y9t(self, self.VVMcDH, VVZCgs=VVZCgs)
 def VVMcDH(self, item=None):
  if item:
   if   item == "CCUKiz"   : self.session.open(CCUKiz)
   elif item == "VVdhjd"  : CCUKiz.VVdhjd(self)
   elif item == "VVgFdx"  : CCUKiz.VVgFdx(self)
   elif item == "findPiconBrokenSymLinks" : CCUKiz.VVr9S7(self, True)
   elif item == "FindAllBrokenSymLinks" : CCUKiz.VVr9S7(self, False)
 def VV4ZQU(self):
  self.session.open(CCrJRc)
 def VVyX6V(self):
  self.session.open(CCvDn4)
 def VVRhNh(self):
  changeLogFile = VVMuIV + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FF5Wuv(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFc8cv("\n%s\n%s\n%s" % (VVG0cy, line, VVG0cy), VVN5SF, VVodRY)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FFc8cv(line, VVaDOU, VVodRY)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFfnpN(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVbLfP, PLUGIN_DESCRIPTION), VVz3yz=26)
 def VV9JSY(self):
  VVZCgs = []
  VVZCgs.append(("Title Colors"   , "title" ))
  VVZCgs.append(("Menu Area Colors"  , "body" ))
  VVZCgs.append(("Menu Pointer Colors" , "cursor" ))
  VVZCgs.append(("Bottom Bar Colors" , "bar"  ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Reset Colors"   , "reset" ))
  title = "Main Menu Colors"
  FF9y9t(self, boundFunction(self.VV4MQ2, title), VVZCgs=VVZCgs, width=500, title=title)
 def VV4MQ2(self, title, item=None):
  if item:
   if item == "reset":
    FFS238(self, self.VV3P70, "Reset to default colors ?", title=title)
   else:
    tDict = self.VViuiu()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VVtLBI, tDict, item), CCEJPF, defFG=fg, defBG=bg)
 def VVB5qt(self):
  return VVGttK + "ajpanel_colors"
 def VViuiu(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVB5qt()
  if fileExists(p):
   txt = FF1mdj(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVtLBI(self, tDict, item, fg, bg):
  if fg:
   self.VVX6er(item, fg)
   self.VVVMk3(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVccGs(tDict)
 def VVccGs(self, tDict):
   p = self.VVB5qt()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVX6er(self, item, fg):
  if   item == "title" : FFdouS(self["myTitle"], fg)
  elif item == "body"  :
   FFdouS(self["myMenu"], fg)
   FFdouS(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FF1BAe(self["myBar"], fg)
   FFdouS(self["keyRed"], fg)
   FFdouS(self["keyGreen"], fg)
   FFdouS(self["keyYellow"], fg)
   FFdouS(self["keyBlue"], fg)
 def VVVMk3(self, item, bg):
  if   item == "title" : FF1BAe(self["myTitle"], bg)
  elif item == "body"  :
   FF1BAe(self["myMenu"], bg)
   FF1BAe(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FF1BAe(self["myBar"], bg)
 def VV3P70(self):
  os.system(FF8avg("rm %s" % self.VVB5qt()))
  self.close()
 def VVx4JO(self):
  tDict = self.VViuiu()
  self.VVsVlc(tDict, "title")
  self.VVsVlc(tDict, "body")
  self.VVsVlc(tDict, "cursor")
  self.VVsVlc(tDict, "bar")
 def VVsVlc(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVX6er(name, fg)
  if bg: self.VVVMk3(name, bg)
 def VVvnCM(self):
  FFOftR(self)
class CCgkMM():
 @staticmethod
 def VVsUfv():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVll3H(isApply=False):
  global VVbykp, VVNTnI
  VVbykp  = True
  VVNTnI = CCgkMM.VVjBiH()
  CCgkMM.VVDMUk()
 @staticmethod
 def VVDMUk():
  if VVNTnI:
   global VVbykp
   if CFG.forceUtf8Encoding.getValue():
    if CCgkMM.VVc7NP() : VVbykp = True
    else        : VVbykp = False
   else:
    CCgkMM.VVEmic()
    VVbykp = False
 @staticmethod
 def VVjBiH(isApply=False):
  from sys import version_info
  if version_info[0] >= 3 and version_info[1] >= 10:
   path = "/etc/issue"
   if fileExists(path):
    path = "/etc/issue"
    if fileExists(path):
     txt = FF1mdj(path)
     span = iSearch(r"open.?vision", txt, IGNORECASE)
     if span:
      return True
  return False
 @staticmethod
 def VVc7NP():
  import locale
  enc = locale.getdefaultlocale()[1]
  span = iSearch(r"UTF.?8", enc, IGNORECASE)
  if not span:
   try:
    import locale
    return locale.setlocale(locale.LC_ALL, "en_GB.UTF-8")
   except:
    pass
  return None
 @staticmethod
 def VVEmic():
  try:
   import locale
   return locale.setlocale(locale.LC_ALL, "")
  except:
   return None
 @staticmethod
 def VV6wNY(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFuN9x(SELF, None, VVUQjT=lst, VVz3yz=30, VV4ne7=True)
 @staticmethod
 def VVGNzE(path, SELF=None):
  for enc in CCgkMM.VVsUfv():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FF2VP5(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVWPoW(SELF, path, cbFnc, defEnc="", pos=0):
  FFSoSp(SELF)
  lst = CCgkMM.VVs5FR(path)
  if lst:
   VVZCgs = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if defEnc == enc:
     txt = FFc8cv(txt, VV09cj)
    VVZCgs.append((txt, enc))
   win = FF9y9t(SELF, cbFnc, title="Select Encoding", VVZCgs=VVZCgs, width=900, height=500 if pos == 1 else 0)
   if pos == 1:
    win.instance.move(ePoint(40, 40))
  else:
   FFSoSp(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVs5FR(path):
  encLst = []
  cPath = VVMuIV + "codecs"
  if fileExists(cPath):
   lines = FF5Wuv(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCgkMM.VVsUfv())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    try:
     with ioOpen(path, "r", encoding=enc) as f:
      for line in f:
       pass
     lst.append((item[0], enc))
    except:
     pass
  return lst
class CCvDn4(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFZerm(VVj3bT, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVZCgs = []
  VVZCgs.append(("Settings File"        , "SettingsFile"   ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Box Info"          , "VVB2MD"    ))
  VVZCgs.append(("Tuners Info"         , "VVQ6Rq"   ))
  VVZCgs.append(("Python Version"        , "VVJh2u"   ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Screen Size"         , "ScreenSize"    ))
  VVZCgs.append(("Language/Locale"        , "Locale"     ))
  VVZCgs.append(("Processor"         , "Processor"    ))
  VVZCgs.append(("Operating System"        , "OperatingSystem"   ))
  VVZCgs.append(("Drivers"          , "drivers"     ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("System Users"         , "SystemUsers"    ))
  VVZCgs.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVZCgs.append(("Uptime"          , "Uptime"     ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Host Name"         , "HostName"    ))
  VVZCgs.append(("MAC Address"         , "MACAddress"    ))
  VVZCgs.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVZCgs.append(("Network Status"        , "NetworkStatus"   ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Disk Usage"         , "VVbVdr"    ))
  VVZCgs.append(("Mount Points"         , "MountPoints"    ))
  VVZCgs.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVZCgs.append(("USB Devices"         , "USB_Devices"    ))
  VVZCgs.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVZCgs.append(("Directory Size"        , "DirectorySize"   ))
  VVZCgs.append(("Memory"          , "Memory"     ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVZCgs.append(("Running Processes"       , "RunningProcesses"  ))
  VVZCgs.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFeVzc(self, VVZCgs=VVZCgs, title="Device Information")
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FFDd6I(self["myMenu"])
  FFGCoH(self)
 def VVh5RL(self):
  global VVTyjD
  VVTyjD = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCkaCj)
   elif item == "VVB2MD"    : self.VVB2MD()
   elif item == "VVQ6Rq"   : self.VVQ6Rq()
   elif item == "VVJh2u"   : self.VVJh2u()
   elif item == "ScreenSize"    : FFfnpN(self, "Width\t: %s\nHeight\t: %s" % (FFcFDM()[0], FFcFDM()[1]))
   elif item == "Locale"     : CCgkMM.VV6wNY(self)
   elif item == "Processor"    : self.VVIw6m()
   elif item == "OperatingSystem"   : FFGSHZ(self, "uname -a"        )
   elif item == "drivers"     : self.VVg6Cs()
   elif item == "SystemUsers"    : FFGSHZ(self, "id"          )
   elif item == "LoggedInUsers"   : FFGSHZ(self, "who -a"         )
   elif item == "Uptime"     : FFGSHZ(self, "uptime"         )
   elif item == "HostName"     : FFGSHZ(self, "hostname"        )
   elif item == "MACAddress"    : self.VVhiKW()
   elif item == "NetworkConfiguration"  : FFGSHZ(self, "ifconfig %s %s" % (FFR6WL("HWaddr", VVjxiW), FFR6WL("addr:", VVN5SF)))
   elif item == "NetworkStatus"   : FFGSHZ(self, "netstat -tulpn"       )
   elif item == "VVbVdr"    : self.VVbVdr()
   elif item == "MountPoints"    : FFGSHZ(self, "mount %s" % (FFR6WL(" on ", VVN5SF)))
   elif item == "FileSystemTable"   : FFGSHZ(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFGSHZ(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFGSHZ(self, "blkid"         )
   elif item == "DirectorySize"   : FFGSHZ(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVGkGe="Reading size ...")
   elif item == "Memory"     : FFGSHZ(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVfRx1()
   elif item == "RunningProcesses"   : FFGSHZ(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFGSHZ(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVyjFt()
   else         : self.close()
 def VVhiKW(self):
  res = FFNxEm("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFfnpN(self, txt)
  else:
   FFGSHZ(self, "ip link")
 def VVxxT6(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFqFDg(cmd)
  return lines
 def VVI8jW(self, lines, headerRepl, widths, VVYecm):
  VV5uoU = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VV5uoU.append(parts)
  if VV5uoU and len(header) == len(widths):
   VV5uoU.sort(key=lambda x: x[0].lower())
   FFuN9x(self, None, header=header, VVUQjT=VV5uoU, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=28, VV4ne7=True)
   return True
  else:
   return False
 def VVbVdr(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFNxEm(cmd)
  if not "invalid option" in txt:
   lines  = self.VVxxT6(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VVYecm = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVI8jW(lines, headerRepl, widths, VVYecm)
  else:
   cmd = "df -h"
   lines  = self.VVxxT6(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VVYecm = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVI8jW(lines, headerRepl, widths, VVYecm)
  if not allOK:
   lines = FFqFDg(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FF2KYY(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VV09cj:
     note = "\n%s" % FFc8cv("Green = Mounted Partitions", VV09cj)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVN5SF
     elif line.endswith(mountList) : color = VV09cj
     else       : color = VVaDOU
     txt += FFc8cv(line, color) + "\n"
    FFfnpN(self, txt + note)
   else:
    FF2VP5(self, "Not data from system !")
 def VVfRx1(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVxxT6(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVYecm = (LEFT , CENTER, LEFT )
  allOK = self.VVI8jW(lines, headerRepl, widths, VVYecm)
  if not allOK:
   FFGSHZ(self, cmd)
 def VVg6Cs(self):
  cmd = FFxiGu(VVKG32, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFGSHZ(self, cmd)
  else : FFh46b(self)
 def VVIw6m(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFGSHZ(self, cmd)
 def VVyjFt(self):
  cmd = FFxiGu(VVs1Qc, "| grep secondstage")
  if cmd : FFGSHZ(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFh46b(self)
 def VVB2MD(self):
  c = VV09cj
  VVUQjT = []
  VVUQjT.append((FFc8cv("Box Type"  , c), FFc8cv(self.VVXfPG("boxtype").upper(), c)))
  VVUQjT.append((FFc8cv("Board Version", c), FFc8cv(self.VVXfPG("board_revision") , c)))
  VVUQjT.append((FFc8cv("Chipset"  , c), FFc8cv(self.VVXfPG("chipset")  , c)))
  VVUQjT.append((FFc8cv("S/N"   , c), FFc8cv(self.VVXfPG("sn")    , c)))
  VVUQjT.append((FFc8cv("Version"  , c), FFc8cv(self.VVXfPG("version")  , c)))
  VV6VHP   = []
  VV69AN = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VV69AN = SystemInfo[key]
     else:
      VV6VHP.append((FFc8cv(str(key), VVO27w), FFc8cv(str(SystemInfo[key]), VVO27w)))
  except:
   pass
  if VV69AN:
   VVI57u = self.VVhuQc(VV69AN)
   if VVI57u:
    VVI57u.sort(key=lambda x: x[0].lower())
    VVUQjT += VVI57u
  if VV6VHP:
   VV6VHP.sort(key=lambda x: x[0].lower())
   VVUQjT += VV6VHP
  if VVUQjT:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFuN9x(self, None, header=header, VVUQjT=VVUQjT, VV5Xly=widths, VVz3yz=28, VV4ne7=True)
  else:
   FFfnpN(self, "Could not read info!")
 def VVXfPG(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FF5Wuv(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVhuQc(self, mbDict):
  try:
   mbList = list(mbDict)
   VVUQjT = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVUQjT.append((FFc8cv(subject, VVN5SF), FFc8cv(value, VVN5SF)))
  except:
   pass
  return VVUQjT
 def VVQ6Rq(self):
  txt = self.VV6X3e("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VV6X3e("/proc/bus/nim_sockets")
  if not txt: txt = self.VV0OGz()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFfnpN(self, txt)
 def VV0OGz(self):
  txt = ""
  VVeeeC = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVeeeC("Slot Name" , slot.getSlotName())
     txt += FFc8cv(slotName, VVN5SF)
     txt += VVeeeC("Description"  , slot.getFullDescription())
     txt += VVeeeC("Frontend ID"  , slot.frontend_id)
     txt += VVeeeC("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VV6X3e(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FF5Wuv(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFc8cv(line, VVN5SF)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVJh2u(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFfnpN(self, txt)
class CCkaCj(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFZerm(VVj3bT, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVZCgs = []
  VVZCgs.append(("Settings (All)"   , "Settings_All"   ))
  VVZCgs.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  if VVZAX8:
   VVZCgs.append(("Settings (FHDG-17)" , "Settings_FHDG_17"  ))
  VVZCgs.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVZCgs.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVZCgs.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVZCgs.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVZCgs.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFeVzc(self, VVZCgs=VVZCgs)
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FFDd6I(self["myMenu"])
  FFGCoH(self)
 def VVh5RL(self):
  global VVTyjD
  VVTyjD = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFGSHZ(self, cmd                )
   elif item == "Settings_HotKeys"   : FFGSHZ(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFGSHZ(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFGSHZ(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFGSHZ(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFGSHZ(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFGSHZ(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFGSHZ(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCx7K4(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFZerm(VVj3bT, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VV81MW, VVpAfT, VVn2a7, camCommand = FFUyst()
  self.VVpAfT = VVpAfT
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVZCgs = []
  VVZCgs.append(("OSCam Files"        , "OSCamFiles"  ))
  VVZCgs.append(("NCam Files"        , "NCamFiles"  ))
  VVZCgs.append(("CCcam Files"        , "CCcamFiles"  ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVZCgs.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVZCgs.append(VVXQs5)
  if VVpAfT:
   if   "oscam" in VVpAfT : camName = "OSCam"
   elif "ncam"  in VVpAfT : camName = "NCam"
   VVZCgs.append((camName + " Info."      , "camInfo"   ))
   VVZCgs.append((camName + " Live Status"    , "camLiveStatus" ))
   VVZCgs.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVZCgs.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVZCgs.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFeVzc(self, VVZCgs=VVZCgs)
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FFDd6I(self["myMenu"])
  FFGCoH(self)
 def VVh5RL(self):
  global VVTyjD
  VVTyjD = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCeR2U, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCeR2U, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCeR2U, "cccam"))
   elif item == "OSCamReaders"  : self.VVOVt6("os")
   elif item == "NSCamReaders"  : self.VVOVt6("n")
   elif item == "camInfo"   : FFpUsV(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFy2Gu(self.session, CCK8xN.VVflKA)
   elif item == "camLiveReaders" : FFy2Gu(self.session, CCK8xN.VVFcmf)
   elif item == "camLiveLog"  : FFy2Gu(self.session, CCK8xN.VVGjPD)
   else       : self.close()
 def VVOVt6(self, camPrefix):
  VV5uoU = self.VVihLS(camPrefix)
  if VV5uoU:
   VV5uoU.sort(key=lambda x: int(x[0]))
   if self.VVpAfT and self.VVpAfT.startswith(camPrefix):
    VVmZVX = ("Toggle State", self.VVhFvT, [camPrefix], "Changing State ...")
   else:
    VVmZVX = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVYecm  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFuN9x(self, None, header=header, VVUQjT=VV5uoU, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=26, VVmZVX=VVmZVX, VVfaqm=True)
 def VVihLS(self, camPrefix):
  readersFile = self.VV81MW + camPrefix + "cam.server"
  VV5uoU = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FF5Wuv(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VV5uoU.append((str(len(VV5uoU) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VV5uoU:
    FF2VP5(self, "No readers found !")
  else:
   FFzAsS(self, readersFile)
  return VV5uoU
 def VVhFvT(self, VVK0Qb, camPrefix):
  confFile  = "%s%scam.conf" % (self.VV81MW, camPrefix)
  readerState  = VVK0Qb.VVPPM9(1)
  readerLabel  = VVK0Qb.VVPPM9(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCx7K4.VV31QK(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVK0Qb.VVKn4K()
    FF2VP5(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VV5uoU = self.VVihLS(camPrefix)
   if VV5uoU:
    VVK0Qb.VVOukU(VV5uoU)
 @staticmethod
 def VV31QK(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FF5Wuv(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FF2VP5(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FF2VP5(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFzAsS(SELF, confFile)
   return None
  if not iRequest:
   FF2VP5(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FF2VP5(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FF2VP5(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCeR2U(Screen):
 def __init__(self, VVUmNQ, session, args=0):
  self.skin, self.skinParam = FFZerm(VVj3bT, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VV81MW, VVpAfT, VVn2a7, camCommand = FFUyst()
  if   VVUmNQ == "ncam" : self.prefix = "n"
  elif VVUmNQ == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVZCgs = []
  if self.prefix == "":
   VVZCgs.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVZCgs.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVZCgs.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVZCgs.append(("constant.cw"         , "x_constant_cw" ))
   VVZCgs.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVZCgs.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVZCgs.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVZCgs.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVZCgs.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVZCgs.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVZCgs.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVZCgs.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVZCgs.append(VVXQs5)
   VVZCgs.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVZCgs.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVZCgs.append(VVXQs5)
   VVZCgs.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVZCgs.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVZCgs.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFeVzc(self, VVZCgs=VVZCgs)
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FFDd6I(self["myMenu"])
  FFGCoH(self)
 def VVh5RL(self):
  global VVTyjD
  VVTyjD = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFtC7A(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFtC7A(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFtC7A(self, self.VV81MW + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFtC7A(self, self.VV81MW + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VV88Xq("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VV88Xq("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VV88Xq("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VV88Xq("cam.provid"        )
   elif item == "x_cam_server"  : self.VV88Xq("cam.server"        )
   elif item == "x_cam_services" : self.VV88Xq("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VV88Xq("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VV88Xq("cam.user"        )
   elif item == "x_VVG0cy"   : pass
   elif item == "x_SoftCam_Key" : self.VVp7Wb()
   elif item == "x_CCcam_cfg"  : FFtC7A(self, self.VV81MW + "CCcam.cfg"    )
   elif item == "x_VVG0cy"   : pass
   elif item == "x_cam_log"  : FFtC7A(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFtC7A(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFtC7A(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VV88Xq(self, fileName):
  FFtC7A(self, self.VV81MW + self.prefix + fileName)
 def VVp7Wb(self):
  path = self.VV81MW + "SoftCam.Key"
  if fileExists(path) : FFtC7A(self, path)
  else    : FFtC7A(self, path.replace(".Key", ".key"))
class CCK8xN(Screen):
 VVflKA  = 0
 VVFcmf = 1
 VVGjPD = 2
 def __init__(self, session, VV81MW="", VVpAfT="", VVn2a7="", VVYbql=VVflKA):
  self.skin, self.skinParam = FFZerm(VV0am5, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVn2a7   = VVn2a7
  self.VVYbql  = VVYbql
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VV81MW + VVpAfT + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVpAfT : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VV81MW, self.camPrefix)
  if self.VVYbql == self.VVflKA:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVYbql == self.VVFcmf:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFeVzc(self, self.Title, addScrollLabel=True)
  FFFMjq(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVG5U2
  self.onShown.append(self.VV3HNB)
  self.onClose.append(self.onExit)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  self["myLabel"].VVy70T(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFRpf0(self)
  self.VVG5U2()
 def onExit(self):
  self.timer.stop()
 def VV11w6(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV2e7x)
  except:
   self.timer.callback.append(self.VV2e7x)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFSoSp(self, "Started", 1000)
 def VVmCk0(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VV2e7x)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFSoSp(self, "Stopped", 1000)
 def VVG5U2(self):
  if self.timerRunning:
   self.VVmCk0()
  else:
   self.VV11w6()
   if self.VVYbql == self.VVflKA or self.VVYbql == self.VVFcmf:
    if self.VVYbql == self.VVflKA : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCx7K4.VV31QK(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFzMXn(self.VVUvmW)
    else:
     self.close()
   else:
    self.VVML40()
 def VV2e7x(self):
  if self.timerRunning:
   if   self.VVYbql == self.VVflKA : self.VVuxhA()
   elif self.VVYbql == self.VVFcmf : self.VVuxhA()
   else            : self.VVML40()
 def VVML40(self):
  if fileExists(self.VVn2a7):
   fTime = FF2SnK(os.path.getmtime(self.VVn2a7))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVMzB7(), VVRj8X=VV08dq)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVn2a7)
 def VVUvmW(self):
  self.VVuxhA()
 def VVuxhA(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFc8cv("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVy89V))
   self.camWebIfErrorFound = True
   self.VVmCk0()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVYbql == self.VVflKA : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFc8cv("Error while parsing data elements !\n\nError = %s" % str(e), VVlcHo)
   self.camWebIfErrorFound = True
   self.VVmCk0()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VV6FbD(root)
  self["myLabel"].setText(txt, VVRj8X=VV08dq)
  self["myBar"].setText("Last Update : %s" % FF5AoR())
 def VV6FbD(self, rootElement):
  def VVeeeC(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVYbql == self.VVflKA:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFc8cv(status, VV09cj)
    else          : status = FFc8cv(status, VVlcHo)
    txt += VVG0cy + "\n"
    txt += VVeeeC("Name"  , name)
    txt += VVeeeC("Description" , desc)
    txt += VVeeeC("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVeeeC("Protocol" , protocol)
    txt += VVeeeC("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFc8cv("Yes", VV09cj)
    else    : enabTxt = FFc8cv("No", VVlcHo)
    txt += VVG0cy + "\n"
    txt += VVeeeC("Label"  , label)
    txt += VVeeeC("Protocol" , protocol)
    txt += VVeeeC("Enabled" , enabTxt)
  return txt
 def VVMzB7(self):
  wordsDict = self.VVay2N()
  color = [ VVN5SF, VVjxiW, VV09cj, VVlcHo, VVO27w, VVlVgH]
  lines = FFqFDg("tail -n %d %s" % (100, self.VVn2a7))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVy89V + line[:19] + VVaDOU + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVodRY + line[ndx + 3:] + VVaDOU
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVN5SF + line[ndx + 8 : ndx1 + 4] + VVaDOU + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVaDOU)
   elif line.startswith("----") or ">>" in line:
    line = FFc8cv(line, VVN5SF)
   txt += line + "\n"
  return txt
 def VVay2N(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FF5Wuv(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CC7PGU(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFZerm(VVj3bT, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVZCgs = []
  VVZCgs.append(("Backup Channels"    , "VVCwQZ"   ))
  VVZCgs.append(("Restore Channels"    , "Restore_Channels"  ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Backup SoftCAM Files"   , "VVJSsJ" ))
  VVZCgs.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVZCgs.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVZCgs.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Backup Network Settings"  , "VVIBnu"   ))
  VVZCgs.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVZAX8:
   VVZCgs.append(VVXQs5)
   VVZCgs.append((VVy89V + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VVMWMg"   ))
   VVZCgs.append((VV09cj + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVrtM3) , "createMyIpk"   ))
   VVZCgs.append((VV09cj + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVrtM3) , "createMyDeb"   ))
   VVZCgs.append((VVO27w + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVZCgs.append((VVO27w + "Decode %s Crash Report"   % PLUGIN_NAME     , "VV48LB" ))
  FFeVzc(self, VVZCgs=VVZCgs)
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FFDd6I(self["myMenu"])
  FFGCoH(self)
 def VVh5RL(self):
  global VVTyjD
  VVTyjD = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVCwQZ"    : self.VVCwQZ()
   elif item == "Restore_Channels"    : self.VVZ8UH("channels_backup*.tar.gz", self.VVMlvs)
   elif item == "VVJSsJ"   : self.VVJSsJ()
   elif item == "Restore_SoftCAM_Files"  : self.VVZ8UH("softcam_backup*.tar.gz", self.VVHBdG)
   elif item == "Backup_TunerDiSEqC"   : self.VVnm1V("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVZ8UH("tuner_backup*.backup", boundFunction(self.VVPr2P, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVnm1V("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVZ8UH("hotkey_*backup*.backup", boundFunction(self.VVPr2P, "misc"))
   elif item == "VVIBnu"    : self.VVIBnu()
   elif item == "Restore_Network"    : self.VVZ8UH("network_backup*.tar.gz", self.VVxXHu)
   elif item == "VVMWMg"     : FFS238(self, boundFunction(FF9BOI, self, boundFunction(CC7PGU.VVMWMg, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VV3OBg(False)
   elif item == "createMyDeb"     : self.VV3OBg(True)
   elif item == "createMyTar"     : self.VVyJNX()
   elif item == "VV48LB"   : self.VV48LB()
 @staticmethod
 def VVMWMg(SELF):
  OBF_Path = VVGEhl + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVGEhl, VVbLfP, VVrtM3)
   if err : FF2VP5(SELF, err)
   else : FFfnpN(SELF, txt)
  else:
   FFzAsS(SELF, OBF_Path)
 def VV3OBg(self, VVZhoG):
  OBF_Path = VVGEhl + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FF2VP5(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVGEhl)
  os.system("mv -f %s %s" % (VVGEhl + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVGEhl + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVGEhl + "plugin.py"))
  self.session.openWithCallback(self.VV3OBg1, boundFunction(CCI31K, path=VVGEhl, VVZhoG=VVZhoG))
 def VV3OBg1(self):
  os.system("mv -f %s %s" % (VVGEhl + "OBF/main.py"  , VVGEhl))
  os.system("mv -f %s %s" % (VVGEhl + "OBF/plugin.py" , VVGEhl))
 def VV48LB(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FF2VP5(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FF2VP5(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVYgg5("%s*.list" % path)
  if err:
   FFzAsS(self, path + "*.list")
   return
  srcF, err = self.VVYgg5("%s*main_final.py" % path)
  if err:
   FFzAsS(self, path + "*.final.py")
   return
  VVUQjT = []
  for f in files:
   f = os.path.basename(f)
   VVUQjT.append((f, f))
  FF9y9t(self, boundFunction(self.VVK0Fs, path, codF, srcF), VVZCgs=VVUQjT)
 def VVK0Fs(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFzAsS(self, logF)
   else     : FF9BOI(self, boundFunction(self.VVbmPW, logF, codF, srcF))
 def VVbmPW(self, logF, codF, srcF):
  lst  = []
  lines = FF5Wuv(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FF2VP5(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VV4exY(lst, logF, newLogF)
  totSrc  = self.VV4exY(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFfnpN(self, txt)
 def VVYgg5(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VV4exY(self, lst, f1, f2):
  txt = FF1mdj(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVyJNX(self):
  VVUQjT = []
  VVUQjT.append("%s%s" % (VVGEhl, "*.py"))
  VVUQjT.append("%s%s" % (VVGEhl, "*.png"))
  VVUQjT.append("%s%s" % (VVGEhl, "*.xml"))
  VVUQjT.append("%s"  % (VVMuIV))
  FFBXM8(self, VVUQjT, "%s_%s" % (PLUGIN_NAME, VVbLfP), addTimeStamp=False)
 def VVCwQZ(self):
  path1 = VVqs92
  path2 = "/etc/tuxbox/"
  VVUQjT = []
  VVUQjT.append("%s%s" % (path1, "*.tv"))
  VVUQjT.append("%s%s" % (path1, "*.radio"))
  VVUQjT.append("%s%s" % (path1, "*list"))
  VVUQjT.append("%s%s" % (path1, "lamedb*"))
  VVUQjT.append("%s%s" % (path2, "*.xml"))
  FFBXM8(self, VVUQjT, "channels_backup", addTimeStamp=True)
 def VVJSsJ(self):
  VVUQjT = []
  VVUQjT.append("/etc/tuxbox/config/")
  VVUQjT.append("/usr/keys/")
  VVUQjT.append("/usr/scam/")
  VVUQjT.append("/etc/CCcam.cfg")
  FFBXM8(self, VVUQjT, "softcam_backup", addTimeStamp=True)
 def VVIBnu(self):
  VVUQjT = []
  VVUQjT.append("/etc/hostname")
  VVUQjT.append("/etc/default_gw")
  VVUQjT.append("/etc/resolv.conf")
  VVUQjT.append("/etc/wpa_supplicant*.conf")
  VVUQjT.append("/etc/network/interfaces")
  VVUQjT.append("/etc/enigma2/nameserversdns.conf")
  FFBXM8(self, VVUQjT, "network_backup", addTimeStamp=True)
 def VVMlvs(self, fileName=None):
  if fileName:
   FFS238(self, boundFunction(self.VVAzCJ, fileName), "Overwrite current channels ?")
 def VVAzCJ(self, fileName):
  path = "%s%s" % (VVGttK, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCze4R.VVDx9i()
   lamedb5File, diabled5File = CCze4R.VVwqYc()
   cmd = ""
   cmd += FF8avg("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FF8avg("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFg8wn()
   if res == 0 : FFiM80(self, "Channels Restored.")
   else  : FF2VP5(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFzAsS(self, path)
 def VVHBdG(self, fileName=None):
  if fileName:
   FFS238(self, boundFunction(self.VVl0oE, fileName), "Overwrite SoftCAM files ?")
 def VVl0oE(self, fileName):
  fileName = "%s%s" % (VVGttK, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVG0cy
   note = "You may need to restart your SoftCAM."
   FFYn0Z(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFR6WL(note, VVN5SF), sep))
  else:
   FFzAsS(self, fileName)
 def VVxXHu(self, fileName=None):
  if fileName:
   FFS238(self, boundFunction(self.VVK7Sf, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVK7Sf(self, fileName):
  fileName = "%s%s" % (VVGttK, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFeerf(self,  cmd)
  else:
   FFzAsS(self, fileName)
 def VVZ8UH(self, pattern, callBackFunction, isTuner=False):
  title = FFgas2()
  if pathExists(VVGttK):
   myFiles = iGlob("%s%s" % (VVGttK, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVUQjT = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVUQjT.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVP7wO = ("Sat. List", self.VVBtgK)
    else  : VVP7wO = None
    VVjOrH = ("Delete File", self.VVCJie)
    FF9y9t(self, callBackFunction, title=title, VVZCgs=VVUQjT, VVP7wO=VVP7wO, VVjOrH=VVjOrH)
   else:
    FF2VP5(self, "No files found in:\n\n%s" % VVGttK, title)
  else:
   FF2VP5(self, "Path not found:\n\n%s" % VVGttK, title)
 def VVCJie(self, VVF9lIObj, path):
  FFS238(self, boundFunction(self.VVEyQO, VVF9lIObj, path), "Delete this file ?\n\n%s" % path)
 def VVEyQO(self, VVF9lIObj, path):
  path = VVGttK + path
  os.system(FF8avg("rm -f '%s'" % path))
  if fileExists(path) : FFSoSp(VVF9lIObj, "Not deleted", 1000)
  else    : VVF9lIObj.VVjh1C()
 def VVnm1V(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCIDk1()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VVJCl6, filePrefix))
 def VVJCl6(self, filePrefix, result, retval):
  title = FFgas2()
  if pathExists(VVGttK):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FF2VP5(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVGttK, filePrefix, FFNMff())
    try:
     VVUQjT = str(result.strip()).split()
     if VVUQjT:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVUQjT:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVG0cy, FFc8cv(fName, VVN5SF), VVG0cy)
       FFfnpN(self, txt, title=title, VVRj8X=VV08dq)
      else:
       FF2VP5(self, "File creation failed!", title)
     else:
      FF2VP5(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FF8avg("rm %s" % fName))
     FF2VP5(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FF8avg("rm %s" % fName))
     FF2VP5(self, "Error while writing file.")
  else:
   FF2VP5(self, "Path not found:\n\n%s" % VVGttK, title)
 def VVPr2P(self, mode, path=None):
  if path:
   path = "%s%s" % (VVGttK, path)
   if fileExists(path):
    lines = FF5Wuv(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFS238(self, boundFunction(self.VVGM2a, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFKXSw(self, path, title=FFgas2())
   else:
    FFzAsS(self, path)
 def VVGM2a(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVk8hn = []
  VVk8hn.append("echo -e 'Reading current settings ...'")
  VVk8hn.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVk8hn.append("echo -e 'Preparing new settings ...'")
  VVk8hn.append(settingsLines)
  VVk8hn.append("echo -e 'Applying new settings ...'")
  VVk8hn.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFIszd(self, VVk8hn)
 def VVBtgK(self, VVF9lIObj, path):
  if not path:
   return
  path = VVGttK + path
  if not fileExists(path):
   FFzAsS(self, path)
   return
  txt = FF1mdj(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVUQjT  = []
   for item in satList:
    VVUQjT.append("%s\t%s" % (item[0], FFR6Ro(item[1])))
   FFfnpN(self, VVUQjT, title="  Satellites List")
  else:
   FF2VP5(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCFy5w(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFZerm(VVj3bT, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVZCgs = []
  VVZCgs.append(("Plugins Browser List"       , "VVTdcJ"   ))
  VVZCgs.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVZCgs.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVZCgs.append(("Remove Packages (show all)"     , "VVyOTLsAll"   ))
  VVZCgs.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Update List of Available Packages"   , "VVntje"   ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Packaging Tool"        , "VVayf6"    ))
  VVZCgs.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFeVzc(self, VVZCgs=VVZCgs)
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FFDd6I(self["myMenu"])
  FFGCoH(self)
 def VVh5RL(self):
  global VVTyjD
  VVTyjD = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVTdcJ"   : self.VVTdcJ()
   elif item == "pluginsMenus"     : self.VV1o8e(0)
   elif item == "pluginsStartup"    : self.VV1o8e(1)
   elif item == "pluginsDirList"    : self.VV7sTD()
   elif item == "downloadInstallPackages"  : FF9BOI(self, boundFunction(self.VVXJOk, 0, ""))
   elif item == "VVyOTLsAll"   : FF9BOI(self, boundFunction(self.VVXJOk, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FF9BOI(self, boundFunction(self.VVXJOk, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVntje"   : self.VVntje()
   elif item == "VVayf6"    : self.VVayf6()
   elif item == "packagesFeeds"    : self.VVhqUo()
   else          : self.close()
 def VV7sTD(self):
  extDirs  = FF5kOg(VVkYQ0)
  sysDirs  = FF5kOg(VVnpau)
  VVUQjT  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVUQjT.append((item, VVkYQ0 + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVUQjT.append((item, VVnpau + item))
  if VVUQjT:
   VVUQjT = sorted(VVUQjT, key=lambda x: x[0].lower())
   VVvAyR = ("Package Info.", self.VVEd4Y, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFuN9x(self, None, header=header, VVUQjT=VVUQjT, VV5Xly=widths, VVz3yz=28, VVvAyR=VVvAyR)
  else:
   FF2VP5(self, "Nothing found!")
 def VVEd4Y(self, VVK0Qb, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVkYQ0) : loc = "extensions"
  elif path.startswith(VVnpau) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVgbH4(package)
  else:
   FF2VP5(self, "No info!")
 def VVhqUo(self):
  pkg = FFz9Zw()
  if pkg : FFGSHZ(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFh46b(self)
 def VVTdcJ(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVeeeC(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVG0cy + "\n"
    txt += VVeeeC("Number"   , str(c))
    txt += VVeeeC("Name"   , FFc8cv(str(p.name), VVN5SF))
    txt += VVeeeC("Path"  , p.path  )
    txt += VVeeeC("Description" , p.description )
    txt += VVeeeC("Icon"  , p.iconstr  )
    txt += VVeeeC("Wakeup Fnc" , p.wakeupfnc )
    txt += VVeeeC("NeedsRestart", p.needsRestart)
    txt += VVeeeC("Internal" , p.internal )
    txt += VVeeeC("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFfnpN(self, txt)
 def VV1o8e(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVUQjT = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVUQjT.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVUQjT:
   VVUQjT.sort(key=lambda x: x[0].lower())
   header  = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths  = (19  , 25 , 20  , 27   , 9  )
   FFuN9x(self, None, title=title, header=header, VVUQjT=VVUQjT, VV5Xly=widths, VVz3yz=26)
  else:
   FF2VP5(self, "Nothing Found", title=title)
 def VVntje(self):
  cmd = FFxiGu(VVDa2A, "")
  if cmd : FFeerf(self, cmd, checkNetAccess=True)
  else : FFh46b(self)
 def VVayf6(self):
  pkg = FFz9Zw()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFiM80(self, txt)
 def VVXJOk(self, mode, grep, VVK0Qb=None, title=""):
  if   mode == 0: cmd = FFxiGu(VVs1Qc    , grep)
  elif mode == 1: cmd = FFxiGu(VVKG32 , grep)
  elif mode == 2: cmd = FFxiGu(VVKG32 , grep)
  if not cmd:
   FFh46b(self)
   return
  VV5uoU = FFqFDg(cmd)
  if not VV5uoU:
   if VVK0Qb: VVK0Qb.VVKn4K()
   FF2VP5(self, "No packages found!")
   return
  elif len(VV5uoU) == 1 and VV5uoU[0] == VVx0qB:
   FF2VP5(self, VVx0qB)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVUQjT  = []
  for item in VV5uoU:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVUQjT.append((name, package, version))
  if mode > 0:
   extensions = FFqFDg("ls %s -l | grep '^d' | awk '{print $9}'" % VVkYQ0)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVUQjT:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVUQjT.append((name, VVkYQ0 + item, "-"))
   systemPlugins = FFqFDg("ls %s -l | grep '^d' | awk '{print $9}'" % VVnpau)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVUQjT:
      if item.lower() == row[0].lower():
       break
     else:
      VVUQjT.append((item, VVnpau + item, "-"))
  if not VVUQjT:
   FF2VP5(self, "No packages found!")
   return
  if VVK0Qb:
   VVUQjT.sort(key=lambda x: x[0].lower())
   VVK0Qb.VVOukU(VVUQjT, title)
  else:
   widths = (20, 50, 30)
   VVmZVX = None
   VVjzKl = None
   if mode == 0:
    VVt4yB = ("Install" , self.VVrul4   , [])
    VVmZVX = ("Download" , self.VVFp7U   , [])
    VVjzKl = ("Filter"  , self.VV5WSP , [])
   elif mode == 1:
    VVt4yB = ("Uninstall", self.VVyOTL, [])
   elif mode == 2:
    VVt4yB = ("Uninstall", self.VVyOTL, [])
    widths= (18, 57, 25)
   VVUQjT = sorted(VVUQjT, key=lambda x: x[0].lower())
   VVvAyR = ("Package Info.", self.VVvOwN, [])
   header   = ("Name" ,"Package" , "Version" )
   FFuN9x(self, None, header=header, VVUQjT=VVUQjT, VV5Xly=widths, VVz3yz=28, VVt4yB=VVt4yB, VVmZVX=VVmZVX, VVvAyR=VVvAyR, VVjzKl=VVjzKl, VVZbs7=self.lastSelectedRow
     , VVZOs8="#22110011", VVEkOu="#22191111", VVJbor="#22191111", VVsesB="#00003030", VV1Ceb="#00333333")
 def VVvOwN(self, VVK0Qb, title, txt, colList):
  package = colList[1]
  self.VVgbH4(package)
 def VV5WSP(self, VVK0Qb, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVZCgs = []
  VVZCgs.append(("All Packages", "all"))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVZCgs.append(VVXQs5)
  for word in words:
   VVZCgs.append((word, word))
  FF9y9t(self, boundFunction(self.VVKW9N, VVK0Qb), VVZCgs=VVZCgs, title="Select Filter")
 def VVKW9N(self, VVK0Qb, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FF9BOI(VVK0Qb, boundFunction(self.VVXJOk, 0, grep, VVK0Qb, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVyOTL(self, VVK0Qb, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVkYQ0, VVnpau)):
   FFS238(self, boundFunction(self.VVlFop, VVK0Qb, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVZCgs = []
   VVZCgs.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVZCgs.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVZCgs.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FF9y9t(self, boundFunction(self.VVUdnJ, VVK0Qb, package), VVZCgs=VVZCgs)
 def VVlFop(self, VVK0Qb, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVAkQm)
  FFeerf(self, cmd, VVDwGo=boundFunction(self.VV8Jrl, VVK0Qb))
 def VVUdnJ(self, VVK0Qb, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVsDlf
   elif item == "remove_ForceRemove"  : cmdOpt = VVgKMV
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVoirB
   FFS238(self, boundFunction(self.VVoZRV, VVK0Qb, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVoZRV(self, VVK0Qb, package, cmdOpt):
  self.lastSelectedRow = VVK0Qb.VVQNsd()
  cmd = FFfBk8(cmdOpt, package)
  if cmd : FFeerf(self, cmd, VVDwGo=boundFunction(self.VV8Jrl, VVK0Qb))
  else : FFh46b(self)
 def VV8Jrl(self, VVK0Qb):
  VVK0Qb.cancel()
  FFv7fK()
 def VVrul4(self, VVK0Qb, title, txt, colList):
  package  = colList[1]
  VVZCgs = []
  VVZCgs.append(("Install Package"         , "install_CheckVersion" ))
  VVZCgs.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVZCgs.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VVZCgs.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVZCgs.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FF9y9t(self, boundFunction(self.VVzRH6, package), VVZCgs=VVZCgs)
 def VVzRH6(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVQ5tW
   elif item == "install_ForceReinstall" : cmdOpt = VVak7B
   elif item == "install_ForceOverwrite" : cmdOpt = VVtBDT
   elif item == "install_ForceDowngrade" : cmdOpt = VVTLRM
   elif item == "install_IgnoreDepends" : cmdOpt = VVuTFQ
   FFS238(self, boundFunction(self.VV5Qfm, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VV5Qfm(self, package, cmdOpt):
  cmd = FFfBk8(cmdOpt, package)
  if cmd : FFeerf(self, cmd, VVDwGo=FFv7fK, checkNetAccess=True)
  else : FFh46b(self)
 def VVFp7U(self, VVK0Qb, title, txt, colList):
  package  = colList[1]
  FFS238(self, boundFunction(self.VVS4bv, package), "Download Package ?\n\n%s" % package)
 def VVS4bv(self, package):
  if FFnTgI():
   cmd = FFfBk8(VVumyh, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFR6WL(success, VV09cj))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFR6WL(fail, VVlcHo))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFeerf(self, cmd, VVz8Vu=[VVlcHo, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFh46b(self)
  else:
   FF2VP5(self, "No internet connection !")
 def VVgbH4(self, package):
  infoCmd  = FFfBk8(VV22kn, package)
  filesCmd = FFfBk8(VVtwsD, package)
  listInstCmd = FFxiGu(VVKG32, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FF9CYr(VVN5SF)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFR6WL(notInst, VVy89V))
   cmd += "else "
   cmd +=   FFY0kl("System Info", VVN5SF)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFY0kl("Related Files", VVN5SF)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFO1e4(self, cmd)
  else:
   FFh46b(self)
class CCze4R(Screen):
 VVa0UL  = 0
 VVy79d = 1
 VVhTuq  = 2
 VV8R0Z  = 3
 VVpjyl = 4
 VVObOI = 5
 VV0e7k = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFZerm(VVj3bT, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VV83I7 = None
  self.lastfilterUsed  = None
  VVZCgs = self.VV5Sxh()
  FFeVzc(self, VVZCgs=VVZCgs, title="Services/Channels")
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self["myMenu"].setList(self.VV5Sxh())
  FFDd6I(self["myMenu"])
  FFGCoH(self)
 def VV5Sxh(self):
  VVZCgs = []
  VVZCgs.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VVZCgs.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Services (Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVZCgs.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVZCgs.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVZCgs.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVZCgs.append(("Services with PIcons for the System"  , "VVWlmw"     ))
  VVZCgs.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVZCgs.append(VVXQs5)
  lamedbFile, disabledFile = CCze4R.VVDx9i()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVZCgs.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVZCgs.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVZCgs.append(("Reset Parental Control Settings"   , "VVP76u"    ))
  VVZCgs.append(("Delete Channels with no names"   , "VVU0TZ"    ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Reload Channels and Bouquets"    , "VVopFb"      ))
  return VVZCgs
 def VVh5RL(self):
  global VVTyjD
  VVTyjD = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFOftR(self)
   elif item == "currentServiceInfo"     : FFQvwR(self, fncMode=CCXD20.VVtcRb)
   elif item == "TranspondersStats"     : FF9BOI(self, self.VVvCKi     )
   elif item == "lameDB_allChannels_with_refCode"  : FF9BOI(self, self.VVtLqu )
   elif item == "lameDB_allChannels_with_tranaponder" : FF9BOI(self, self.VVNNno)
   elif item == "lameDB_allChannels_with_details"  : FF9BOI(self, self.VVyESo )
   elif item == "parentalControlChannels"    : FF9BOI(self, self.VVcpzK   )
   elif item == "showHiddenChannels"     : FF9BOI(self, self.VVmw9y     )
   elif item == "VVWlmw"     : FF9BOI(self, self.VV9c3Z     )
   elif item == "servicesWithMissingPIcons"   : FF9BOI(self, self.VVFdgE   )
   elif item == "enableHiddenChannels"     : self.VVg3g4(True)
   elif item == "disableHiddenChannels"    : self.VVg3g4(False)
   elif item == "VVP76u"    : FFS238(self, self.VVP76u, "Reset and Restart ?" )
   elif item == "VVU0TZ"    : FF9BOI(self, self.VVU0TZ)
   elif item == "VVopFb"      : FF9BOI(self, boundFunction(CCze4R.VVopFb, self))
   else            : self.close()
 @staticmethod
 def VVopFb(SELF):
  FFg8wn()
  FFiM80(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVtLqu(self):
  self.VV83I7 = None
  self.lastfilterUsed  = None
  self.filterObj   = CC3CTD(self)
  VV5uoU = CCze4R.VVEbjS(self, self.VVa0UL)
  if VV5uoU:
   VV5uoU.sort(key=lambda x: x[0].lower())
   VViSv2  = ("Zap"   , self.VV7KUL     , [])
   VV7Iri = (""    , self.VVcdHh   , [])
   VVvAyR = ("Options"  , self.VVHTkU , [])
   VVmZVX = ("Current Service", self.VVumOB , [])
   VVjzKl = ("Filter"   , self.VVPp9T  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVYecm  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFuN9x(self, None, header=header, VVUQjT=VV5uoU, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=26, VViSv2=VViSv2, VV7Iri=VV7Iri, VVmZVX=VVmZVX, VVvAyR=VVvAyR, VVjzKl=VVjzKl)
 def VVNNno(self):
  self.VV83I7 = None
  self.lastfilterUsed  = None
  self.filterObj   = CC3CTD(self)
  VV5uoU = CCze4R.VVEbjS(self, self.VVy79d)
  if VV5uoU:
   VV5uoU.sort(key=lambda x: x[0].lower())
   VViSv2  = ("Zap"   , self.VV7KUL      , [])
   VV7Iri = (""    , self.VVcdHh    , [])
   VVmZVX = ("Current Service", self.VVumOB  , [])
   VVvAyR = ("Options"  , self.VVwPLN , [])
   VVjzKl = ("Filter"   , self.VVtB0o  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVYecm  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFuN9x(self, None, header=header, VVUQjT=VV5uoU, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=26, VViSv2=VViSv2, VV7Iri=VV7Iri, VVmZVX=VVmZVX, VVvAyR=VVvAyR, VVjzKl=VVjzKl)
 def VVHTkU(self, VVK0Qb, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel  = CCrBxE(self, VVK0Qb, 3)
  mSel.VVINdo(servName, refCode, pcState, hidState)
 def VVwPLN(self, VVK0Qb, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CCrBxE(self, VVK0Qb, 3)
  mSel.VVGJ1R(servName, refCode)
 def VVkUWD(self, VVK0Qb, refCode, isAddToBlackList):
  VVK0Qb.VV1Sed("Processing ...")
  FFzMXn(boundFunction(self.VVqfSg, VVK0Qb, [refCode], isAddToBlackList))
 def VVO5U5(self, VVK0Qb, isAddToBlackList):
  refCodeList = VVK0Qb.VVsVJQ(3)
  if not refCodeList:
   FF2VP5(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVK0Qb.VV1Sed("Processing ...")
  FFzMXn(boundFunction(self.VVqfSg, VVK0Qb, refCodeList, isAddToBlackList))
 def VVqfSg(self, VVK0Qb, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVvHjp, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVvHjp):
   lines = FF5Wuv(VVvHjp)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVvHjp, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVK0Qb.VVFxSi
   if isMulti:
    self.VVwhsE(VVK0Qb, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVl0fN(VVK0Qb, refCode)
    VVK0Qb.VVKn4K()
  else:
   VVK0Qb.VV5V7a("No changes")
 def VVNIge(self, VVK0Qb, refCode, isHide):
  title = "Change Hidden State"
  if FFOWnG(refCode):
   VVK0Qb.VV1Sed("Processing ...")
   ret = FFxJGc(refCode, isHide)
   if ret : FF9BOI(self, boundFunction(self.VVl0fN, VVK0Qb, refCode))
   else : FF2VP5(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FF2VP5(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVl0fN(self, VVK0Qb, refCode):
  VV5uoU = CCze4R.VVEbjS(self, self.VVa0UL, VVqA59=[3, [refCode], False])
  done = False
  if VV5uoU:
   data = VV5uoU[0]
   if data[3] == refCode:
    done = VVK0Qb.VVOJEz(data)
  if not done:
   self.VVB31N(VVK0Qb, VVK0Qb.VVf2AE(), self.VVa0UL)
  VVK0Qb.VVKn4K()
 def VVwhsE(self, VVK0Qb, totRefCodes):
  VV5uoU = CCze4R.VVEbjS(self, self.VVa0UL, VVqA59=self.VV83I7)
  VVK0Qb.VVOukU(VV5uoU)
  VVK0Qb.VVzlVd(False)
  VVK0Qb.VV5V7a("%d Processed" % totRefCodes)
 def VVhDZa(self, VVK0Qb, isHide):
  refCodeList = VVK0Qb.VVsVJQ(3)
  if not refCodeList:
   FF2VP5(self, "Nothing selected", title="Change Hidden State")
   return
  VVK0Qb.VV1Sed("Processing ...")
  FFzMXn(boundFunction(self.VVhCk3, VVK0Qb, refCodeList, isHide))
 def VVhCk3(self, VVK0Qb, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFxJGc(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   db = eDVBDB.getInstance()
   if db:
    db.saveServicelist()
    db.reloadServicelist()
    db.reloadBouquets()
   self.VVwhsE(VVK0Qb, len(refCodeList))
  else:
   VVK0Qb.VV5V7a("No changes")
 def VVPp9T(self, VVK0Qb, title, txt, colList):
  self.filterObj.VVgllc(1, VVK0Qb, 2, boundFunction(self.VVSpHV, VVK0Qb))
 def VVSpHV(self, VVK0Qb, item):
  self.VVNN6o(VVK0Qb, item, 2, self.VVa0UL)
 def VVtB0o(self, VVK0Qb, title, txt, colList):
  self.filterObj.VVgllc(2, VVK0Qb, 4, boundFunction(self.VVezT9, VVK0Qb))
 def VVezT9(self, VVK0Qb, item):
  self.VVNN6o(VVK0Qb, item, 4, self.VVy79d)
 def VVDKua(self, VVK0Qb, title, txt, colList):
  self.filterObj.VVgllc(0, VVK0Qb, 4, boundFunction(self.VVSAm5, VVK0Qb))
 def VVSAm5(self, VVK0Qb, item):
  self.VVNN6o(VVK0Qb, item, 4, self.VVhTuq)
 def VVNN6o(self, VVK0Qb, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVK0Qb.VVPPM9(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VV83I7 = None
  else:
   words, asPrefix = CC3CTD.VVsnwy(words)
   self.VV83I7 = [col, words, asPrefix]
  if words: FF9BOI(self, boundFunction(self.VVB31N, VVK0Qb, title, mode), title="Reading Services ...")
  else : FFSoSp(VVK0Qb, "Incorrect filter", 2000)
 def VVB31N(self, VVK0Qb, title, mode):
  VV5uoU = CCze4R.VVEbjS(self, mode, VVqA59=self.VV83I7, VVhlvh=False)
  if VV5uoU:
   VV5uoU.sort(key=lambda x: x[0].lower())
   VVK0Qb.VVOukU(VV5uoU, title)
  else:
   VVK0Qb.VVKn4K()
   FFSoSp(VVK0Qb, "Not found!", 1500)
 def VVIHwo(self, VVUQjT, VViSv2=None, VV7Iri=None, VVt4yB=None, VVmZVX=None, VVvAyR=None, VVjzKl=None):
  VVmZVX = ("Current Service", self.VVumOB, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVYecm = (LEFT  , LEFT  , CENTER, LEFT    )
  FFuN9x(self, None, header=header, VVUQjT=VVUQjT, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=26, VViSv2=VViSv2, VV7Iri=VV7Iri, VVt4yB=VVt4yB, VVmZVX=VVmZVX, VVvAyR=VVvAyR, VVjzKl=VVjzKl)
 def VVumOB(self, VVK0Qb, title, txt, colList):
  self.VV67oE(VVK0Qb)
 def VVwZXn(self, VVK0Qb, title, txt, colList):
  self.VV67oE(VVK0Qb, True)
 def VV67oE(self, VVK0Qb, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVK0Qb.VVZeWW(colDict, VVFzkD=True)
   else:
    VVK0Qb.VVXwUN(3, refCode, True)
   return
  FF2VP5(self, "Colud not read current Reference Code !")
 def VVyESo(self):
  self.VV83I7 = None
  self.lastfilterUsed  = None
  self.filterObj   = CC3CTD(self)
  VV5uoU = CCze4R.VVEbjS(self, self.VVhTuq)
  if VV5uoU:
   VV5uoU.sort(key=lambda x: x[0].lower())
   VV7Iri = (""    , self.VVfN4M , []      )
   VVmZVX = ("Current Service", self.VVwZXn  , []      )
   VVjzKl = ("Filter"   , self.VVDKua   , [], "Loading Filters ..." )
   VViSv2  = ("Zap"   , self.VV2Mz5      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVYecm  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFuN9x(self, None, header=header, VVUQjT=VV5uoU, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=26, VViSv2=VViSv2, VV7Iri=VV7Iri, VVmZVX=VVmZVX, VVjzKl=VVjzKl)
 def VVfN4M(self, VVK0Qb, title, txt, colList):
  refCode  = self.VVYHqC(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFQvwR(self, fncMode=CCXD20.VVTf9k, refCode=refCode, chName=chName, text=txt)
 def VV2Mz5(self, VVK0Qb, title, txt, colList):
  refCode = self.VVYHqC(colList)
  FFqYTj(self, refCode)
 def VV7KUL(self, VVK0Qb, title, txt, colList):
  FFqYTj(self, colList[3])
 def VVYHqC(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVEbjS(SELF, mode, VVqA59=None, VVhlvh=True, VVz7qy=True):
  lamedbFile, disabledFile = CCze4R.VVDx9i()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVqA59:
    filterCol = VVqA59[0]
    filterWords = VVqA59[1]
    asPrefix = VVqA59[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCze4R.VVa0UL:
    blackList = None
    if fileExists(VVvHjp):
     blackList = FF5Wuv(VVvHjp)
     if blackList:
      blackList = set(blackList)
   elif mode == CCze4R.VVy79d:
    tp = CC14a1()
   VV1eve, VVBltM = FF1AA1()
   tagFound  = False
   if mode in (CCze4R.VVObOI, CCze4R.VV0e7k):
    VV5uoU = {}
   else:
    VV5uoU = []
   with ioOpen(lamedbFile, "r", encoding="utf-8") as f:
    lines = []
    for line in f:
     line = str(line).strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFyBpM(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CCze4R.VVhTuq:
        if sTypeInt in VV1eve:
         STYPE = VVBltM[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VV5uoU.append(tRow)
         elif any(x in tmp for x in filterWords)    : VV5uoU.append(tRow)
        else:
         VV5uoU.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCze4R.VVObOI:
         VV5uoU[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCze4R.VV0e7k:
         VV5uoU[chName] = refCode
        elif mode == CCze4R.VVa0UL:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VV5uoU.append(tRow)
          elif any(x in tmp for x in filterWords)    : VV5uoU.append(tRow)
         else:
          VV5uoU.append(tRow)
        elif mode == CCze4R.VVy79d:
         if sTypeInt in VV1eve:
          STYPE = VVBltM[sTypeInt]
         freq, pol, fec, sr, syst = tp.VVMLMx(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VV5uoU.append(tRow)
          elif any(x in tmp for x in filterWords)    : VV5uoU.append(tRow)
         else:
          VV5uoU.append(tRow)
        elif mode == CCze4R.VV8R0Z:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VV5uoU.append((chName, chProv, sat, refCode))
        elif mode == CCze4R.VVpjyl:
         VV5uoU.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VV5uoU and VVhlvh:
    FF2VP5(SELF, "No services found!")
   return VV5uoU
  else:
   if VVz7qy:
    FFzAsS(SELF, lamedbFile)
   return None
 def VVcpzK(self):
  if fileExists(VVvHjp):
   lines = FF5Wuv(VVvHjp)
   if lines:
    newRows  = []
    VV5uoU = CCze4R.VVEbjS(self, self.VVpjyl)
    if VV5uoU:
     lines = set(lines)
     for item in VV5uoU:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VV5uoU = newRows
      VV5uoU.sort(key=lambda x: x[0].lower())
      VV7Iri = ("", self.VVcdHh, [])
      VViSv2 = ("Zap", self.VV7KUL, [])
      self.VVIHwo(VVUQjT=VV5uoU, VViSv2=VViSv2, VV7Iri=VV7Iri)
     else:
      FFfnpN(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VV5uoU)))
   else:
    FFiM80(self, "No active Parental Control services.", FFgas2())
  else:
   FFzAsS(self, VVvHjp)
 def VVmw9y(self):
  VV5uoU = CCze4R.VVEbjS(self, self.VV8R0Z)
  if VV5uoU:
   VV5uoU.sort(key=lambda x: x[0].lower())
   VV7Iri = ("" , self.VVcdHh, [])
   VViSv2  = ("Zap", self.VV7KUL, [])
   self.VVIHwo(VVUQjT=VV5uoU, VViSv2=VViSv2, VV7Iri=VV7Iri)
  else:
   FFiM80(self, "No hidden services.", FFgas2())
 def VVvCKi(self):
  totT, totC, totA, totS, totS2, satList = self.VVjHeb()
  txt = FFc8cv("Total Transponders:\n\n", VVO27w)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFc8cv("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVO27w)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FF5e08(item), satList.count(item))
  FFfnpN(self, txt)
 def VVjHeb(self):
  lamedbFile, disabledFile = CCze4R.VVDx9i()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with ioOpen(lamedbFile, "r", encoding="utf-8") as f:
    lines = []
    for line in f:
     line = str(line).strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFzAsS(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VV9c3Z(self)   : self.VVWlmw(True)
 def VVFdgE(self) : self.VVWlmw(False)
 def VVWlmw(self, isWithPIcons):
  piconsPath = CCUKiz.VVxUr1()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCUKiz.VVIB3P(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VV5uoU = CCze4R.VVEbjS(self, self.VVpjyl)
    if VV5uoU:
     channels = []
     for (chName, chProv, sat, refCode) in VV5uoU:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFwqN1(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VV5uoU)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVeeeC(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVeeeC("PIcons Path"  , piconsPath)
     txt += VVeeeC("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVeeeC("Total services" , totalServices)
     txt += VVeeeC("With PIcons"  , totalWithPIcons)
     txt += VVeeeC("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFfnpN(self, txt)
     else:
      VV7Iri     = (""      , self.VVcdHh , [])
      if isWithPIcons : VVjzKl = ("Export Current PIcon", self.VV6IVN  , [])
      else   : VVjzKl = None
      VVvAyR     = ("Statistics", FFfnpN, [txt])
      VViSv2      = ("Zap", self.VV7KUL, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVIHwo(VVUQjT=channels, VViSv2=VViSv2, VV7Iri=VV7Iri, VVvAyR=VVvAyR, VVjzKl=VVjzKl)
   else:
    FF2VP5(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FF2VP5(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVcdHh(self, VVK0Qb, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFQvwR(self, fncMode=CCXD20.VVTf9k, refCode=refCode, chName=chName, text=txt)
 def VV6IVN(self, VVK0Qb, title, txt, colList):
  png, path = CCUKiz.VV0MtI(colList[3], colList[0])
  if path:
   CCUKiz.VVcYn8(self, png, path)
 @staticmethod
 def VVDx9i():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVwqYc():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVg3g4(self, isEnable):
  lamedbFile, disabledFile = CCze4R.VVDx9i()
  if isEnable and not fileExists(disabledFile):
   FFiM80(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FF2VP5(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFS238(self, boundFunction(self.VVg4A8, isEnable), "%s Hidden Channels ?" % word)
 def VVg4A8(self, isEnable):
  lamedbFile , disabledFile = CCze4R.VVDx9i()
  lamedb5File, diabled5File = CCze4R.VVwqYc()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FFg8wn()
  if res == 0 : FFiM80(self, "Hidden List %s" % word)
  else  : FF2VP5(self, "Error while restoring:\n\n%s" % fileName)
 def VVP76u(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFIszd(self, cmd)
 def VVU0TZ(self):
  lamedbFile, disabledFile = CCze4R.VVDx9i()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FF8avg("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FF5Wuv(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FF8avg("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FFg8wn()
   FFfnpN(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFzAsS(self, lamedbFile)
class CCXD20(Screen):
 VVtcRb  = 0
 VVAg4g   = 1
 VVB1Vt   = 2
 VVTf9k    = 3
 VVYpC6    = 4
 VV5ZdR   = 5
 VVnJ0G   = 6
 VVBiry    = 7
 VVvuVR   = 8
 VV1Bl4   = 9
 VV1hWt   = 10
 VVuce4   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFZerm(VV0am5, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVtcRb)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFc8cv("%s\n", VV0hxT) % VVG0cy
  self.picViewer  = None
  FFeVzc(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVjVId })
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VV3HNB)
  self.onClose.append(self.onExit)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  self["myLabel"].VVy70T(textOutFile="chann_info")
  if   self.fncMode == self.VVtcRb : fnc = self.VVIxqi_VVtcRb
  elif self.fncMode == self.VVAg4g  : fnc = self.VVIxqi_VVtcRb
  elif self.fncMode == self.VVB1Vt  : fnc = self.VVIxqi_VVtcRb
  elif self.fncMode == self.VVTf9k  : fnc = self.VVIxqi_VVTf9k
  elif self.fncMode == self.VVYpC6  : fnc = self.VVIxqi_VVYpC6
  elif self.fncMode == self.VV5ZdR  : fnc = self.VVIxqi_VV5ZdR
  elif self.fncMode == self.VVnJ0G  : fnc = self.VVIxqi_VVnJ0G
  elif self.fncMode == self.VVBiry  : fnc = self.VVIxqi_VVBiry
  elif self.fncMode == self.VVvuVR  : fnc = self.VVIxqi_VVvuVR
  elif self.fncMode == self.VV1Bl4 : fnc = self.VVIxqi_VV1Bl4
  elif self.fncMode == self.VV1hWt  : fnc = self.VVIxqi_VV1hWt
  elif self.fncMode == self.VVuce4 : fnc = self.VVIxqi_VVuce4
  self["myLabel"].setText("\n   Reading Info ...")
  FFzMXn(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVNMtv()
 def VVPdQn(self, err):
  self["myLabel"].setText(err)
  FF1BAe(self["myTitle"], "#22200000")
  FF1BAe(self["myBody"], "#22200000")
  self["myLabel"].FF1BAeColor("#22200000")
  self["myLabel"].VVjvAc()
 def VVIxqi_VVtcRb(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self)
  self.refCode = refCode
  self.VVW3Dy(chName)
 def VVIxqi_VVTf9k(self):
  self.VVW3Dy(self.chName)
 def VVIxqi_VVYpC6(self):
  self.VVW3Dy(self.chName)
 def VVIxqi_VV5ZdR(self):
  self.VVW3Dy(self.chName)
 def VVIxqi_VVnJ0G(self):
  self.VVW3Dy("Picon Info")
 def VVIxqi_VVBiry(self):
  self.VVW3Dy(self.chName)
 def VVIxqi_VVvuVR(self):
  self.VVW3Dy(self.chName)
 def VVIxqi_VV1Bl4(self):
  self.VVW3Dy(self.chName)
 def VVIxqi_VV1hWt(self):
  self.chUrl = self.refCode + self.callingSELF.VVlW1E(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVW3Dy(self.chName)
 def VVIxqi_VVuce4(self):
  self.VVW3Dy(self.chName)
 def VVW3Dy(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFYxsR(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVCTnb(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFc8cv(self.VVrU83(tUrl), VVaDOU)
  if not self.epg:
   epg = self.VVqX9s(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVZYsz(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCUKiz.VV0MtI(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVZYsz(path)
  self.VVCxZp()
  self.VVK6O9()
  self["myLabel"].setText(self.text, VVRj8X=VV8XxG)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVjvAc(minHeight=minH)
 def VVK6O9(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFKADs(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVI1vD(FFELTf(url))
  if epg:
   self.text += "\n" + FFE5E0("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVCxZp()
 def VVCxZp(self):
  if not self.piconShown and self.picUrl:
   path, err = FFTJ9u(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVZYsz(path)
    if self.piconShown and self.refCode:
     self.VVVoXm(path, self.refCode)
 def VVVoXm(self, path, refCode):
  if path and fileExists(path) and os.system(FF8avg("which ffmpeg")) == 0:
   pPath = CCUKiz.VVxUr1()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
    cmd += FF8avg("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVZYsz(self, path):
  if path and fileExists(path):
   err, w, h = self.VV9NIg(path)
   if not err:
    if h > w:
     self.VVeeCl(self["myPicF"], w, h, True)
     self.VVeeCl(self["myPic"] , w, h, False)
   self.picViewer = CCTMgS.VVgEsH(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVeeCl(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VV9NIg(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFgBpG(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVCTnb(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFc8cv(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVeeeC(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFc8cv(state, VVy89V)
   txt += "State\t: %s\n" % state
  w = FF6SKb(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FF6SKb(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VV5l3A(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVeeeC(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVeeeC(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVeeeC(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVxwRQ()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVVGdu()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCXD20.VVqF3O(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFc8cv("IPTV", VVO27w)
   txt += self.VVtFZW(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVAqMv(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CC14a1()
    tpTxt, namespace = tp.VVW4ho(refCode)
    del tp
    if tpTxt:
     txt += FFc8cv("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFc8cv("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVeeeC(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVeeeC(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVeeeC(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVeeeC(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVeeeC(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVeeeC(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVeeeC(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVeeeC(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVeeeC(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VV5l3A(info):
  if info:
   aspect = FF6SKb(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVeeeC(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FF6SKb(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVOvuY(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVOvuY(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVxwRQ(self):
  try:
   service = self.session.nav.getCurrentService()
   audio = service and service.audioTracks()
   return audio and audio.getNumberOfTracks() or 0
  except:
   pass
  return -1
 def VVVGdu(self):
  try:
   service   = self.session.nav.getCurrentService()
   subtitle  = service and service.subtitle()
   subtitlelist = subtitle and subtitle.getSubtitleList()
   return len(subtitlelist)
  except:
   pass
  return -1
 def VVAqMv(self, refCode, iptvRef, chName):
  refCode = FFtv9b(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FF1mdj(VVqs92 + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FF1mdj(VVqs92 + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VVUQjT = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVqs92 + item
   if fileExists(path):
    txt = FF1mdj(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVUQjT.append(bName)
  txt = self.Sep
  if VVUQjT:
   if len(VVUQjT) == 1:
    txt += "%s\t: %s\n" % (FFc8cv("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VVUQjT[0])
   else:
    txt += FFc8cv("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VVUQjT):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVqX9s(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVS0Os(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVS0Os(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVS0Os(event, 0)
     except:
      pass
  return epg
 def VVS0Os(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName().strip()    or ""
   evTime = event.getBeginTime()      or ""
   evDur = event.getDuration()      or ""
   evShort = event.getShortDescription().strip()  or ""
   evDesc = event.getExtendedDescription().strip() or ""
   genre, PR = CCXD20.VVhZBL(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = self.VV4Cjx(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FFc8cv(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FFc8cv(evNameTransl, COLOR_CONS_BRIGHT_YELLOW))
    if evTime           : txt += "Start Time\t: %s\n" % FF2SnK(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FF2SnK(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFzrBt(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFzrBt(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFzrBt(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFc8cv(evShort, VVbIFj)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFc8cv(evDesc , VVbIFj)
    if txt:
     txt = FFc8cv("\n%s\n%s Event:\n%s\n" % (VVG0cy, ("Current", "Next")[evNum], VVG0cy), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVtFZW(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFlxg0(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCzEzL()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVwEfn(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFc8cv("URL:", VVO27w) + "\n%s\n" % self.VVrU83(decodedUrl)
  else:
   txt = "\n"
   txt += FFc8cv("Reference:", VVO27w) + "\n%s\n" % refCode
  return txt
 def VVrU83(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVZAX8:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VVI1vD(self, decodedUrl):
  if not FFnTgI():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCSfuP.VVhkWC(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCSfuP.VVkQoO(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVpRAz(tDict)
   elif uType == "movie" : epg, picUrl = self.VVGoGs(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVpRAz(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCSfuP.VVY1fi(item, "title"    , is_base64=True )
     lang    = CCSfuP.VVY1fi(item, "lang"         ).upper()
     description   = CCSfuP.VVY1fi(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCSfuP.VVY1fi(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCSfuP.VVY1fi(item, "start_timestamp"      )
     stop_timestamp  = CCSfuP.VVY1fi(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCSfuP.VVY1fi(item, "stop_timestamp"       )
     now_playing   = CCSfuP.VVY1fi(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVodRY, ""
      else     : color, txt = VVy89V , "    (CURRENT EVENT)"
      epg += FFc8cv("_" * 32 + "\n", VV0hxT)
      epg += FFc8cv("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFc8cv(description, VVaDOU)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVJ9ho(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VVGoGs(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCSfuP.VVY1fi(item, "movie_image" )
    genre  = CCSfuP.VVY1fi(item, "genre"   ) or "-"
    plot  = CCSfuP.VVY1fi(item, "plot"   ) or "-"
    cast  = CCSfuP.VVY1fi(item, "cast"   ) or "-"
    rating  = CCSfuP.VVY1fi(item, "rating"   ) or "-"
    director = CCSfuP.VVY1fi(item, "director"  ) or "-"
    releasedate = CCSfuP.VVY1fi(item, "releasedate" ) or "-"
    duration = CCSfuP.VVY1fi(item, "duration"  ) or "-"
    try:
     lang = CCSfuP.VVY1fi(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFc8cv(cast, VVaDOU)
    epg += "Plot:\n%s"    % FFc8cv(self.VV4Cjx(plot), VVaDOU)
   except:
    pass
  return epg, movie_image
 def VV4Cjx(self, evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = self.VVdHkl(evTxt, lang)
   return CCXD20.VVtJXL(txt).strip() or evTxt
 def VVjVId(self):
  if VVZAX8:
   def VVeeeC(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVeeeC(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCzEzL()
    valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVwEfn(decodedUrl)
    n = ("valid", "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVeeeC(n[i], v[i])
   with open("/tmp/ajp_channel_details", "a") as f:
    f.write("%s\n%s\n" % (VVG0cy, txt))
   FFSoSp(self, "Saved to:", 1000)
 @staticmethod
 def VVtJXL(txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VVdHkl(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFEQKM(txt))
   txt, err = CCSfuP.VVkQoO(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFELTf(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVJ9ho(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
 @staticmethod
 def VV0XNU(SELF):
  if not CCVmD8.VVlKkZ(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(SELF)
  err = url =  fSize = resumable = ""
  if FFyuoc(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCzEzL.VVuhBD(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCzEzL.VVo2tKHeader(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FF2VP5(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CC3ls7.VV3UfA(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFc8cv(" (M3U/M3U8 File)", VVaDOU)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCXZq2.VV3G9F(resp) else "No"
   except requests.Timeout as e     : err = "Connection Timeout"
   except Exception as e       : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVYMjy(subj, val):
   return "%s\n%s\n\n" % (FFc8cv("%s:" % subj, COLOR_CONS_BRIGHT_YELLOW), val)
  title = "File Size"
  txt  = VVYMjy(title , fSize or "?")
  txt += VVYMjy("Name" , chName)
  txt += VVYMjy("URL" , url)
  if resumable: txt += VVYMjy("Supports Download-Resume", resumable)
  if err  : txt += FFc8cv("Error:\n", VVy89V) + err
  FFfnpN(SELF, txt, title=title)
 @staticmethod
 def VVqF3O(SELF):
  fPath, fDir, fName = CC3ls7.VVAmF7(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg", "mvi"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVhZBL(event):
  genre = PR = ""
  try:
   genre  = CCXD20.VVT6Ta(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCXD20.VVTXfs(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVTXfs(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVT6Ta(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCXD20.VV5kUg()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VV5kUg():
  path = VVMuIV + "genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FF1mdj(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FF1mdj(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
class CCzEzL():
 def __init__(self):
  self.VVV50h   = ""
  self.VV5uIO    = ""
  self.VVQQbm   = ""
  self.portal_moreAuthRand = ""
  self.portal_moreAuthMsg  = ""
  self.portal_moreAuthType = 0
  self.colored_user   = "#f#11ffffaa#User"
  self.colored_server   = "#f#11aaffff#Server"
 def VVq0Ex(self, url, mac, VVFzkD=True):
  self.VVV50h   = ""
  self.VV5uIO    = ""
  self.VVQQbm   = ""
  self.portal_moreAuthRand = ""
  self.portal_moreAuthMsg  = ""
  self.portal_moreAuthType = 0
  host = self.VV5TFk(url)
  if not host:
   if VVFzkD:
    self.VVFzkDor("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVPM44(mac)
  if not host:
   if VVFzkD:
    self.VVFzkDor("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVV50h = host
  self.VV5uIO  = mac
  return True
 def VV5TFk(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVPM44(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVEMEE(self):
  res, err = self.VVMG8e(self.VVQ4wF())
  urlPath = "/stalker_portal"
  if "404" in err and urlPath in self.VVV50h:
   self.VVV50h = self.VVV50h.replace(urlPath, "")
   res, err = self.VVMG8e(self.VVQ4wF())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCSfuP.VVY1fi(tDict["js"], "token")
    rand  = CCSfuP.VVY1fi(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVi4na(self, VVFzkD=True):
  err = blkMsg = FFiM80Txt = ""
  try:
   token, rand, err = self.VVEMEE()
   if token:
    self.VVQQbm = token
    self.portal_moreAuthRand = rand
    if rand:
     self.portal_moreAuthType = 2
    prof, retTxt = self.VVwqQE(True)
    if prof:
     self.portal_moreAuthMsg = retTxt
     if "device_id mismatch" in retTxt:
      self.portal_moreAuthType = 3
      prof, retTxt = self.VVwqQE(False)
      if retTxt:
       self.portal_moreAuthMsg = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFiM80Txt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFiM80Txt: tErr += "\n%s" % FFiM80Txt
  if VVFzkD:
   self.VVFzkDor(tErr)
  return "", "", tErr
 def VVwqQE(self, capMac):
  res, err = self.VVMG8e(self.VVZNbn(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCSfuP.VVY1fi(tDict["js"], "block_%s" % word)
    FFiM80Txt = CCSfuP.VVY1fi(tDict["js"], word)
    return tDict, FFiM80Txt.strip() or blkMsg.strip()
   except Exception as e:
    pass
  return "", ""
 def VVZNbn(self, capMac):
  if self.portal_moreAuthMsg or self.portal_moreAuthRand:
   import hashlib
   if capMac: mac = self.VV5uIO.upper()
   else  : mac = self.VV5uIO.lower()
   macUtf8 = mac.encode('utf-8')
   sn = hashlib.md5(macUtf8).hexdigest().upper()[:13]
   Id = hashlib.sha256(macUtf8).hexdigest().upper()
   sig = hashlib.sha256((sn + mac).encode('utf-8')).hexdigest().upper()
   param  = ""
   param += "&sn=%s"   % sn
   param += "&device_id=%s" % Id
   param += "&device_id2=%s" % Id
   param += "&signature=%s" % sig
   param += '&auth_second_step=1'
   param += '&hw_version=2.17-IB-00&hw_version_2=62'
   param += '&metrics={"mac":"%s","sn":"%s","type":"STB","model":"MAG250","random":"%s"}' % (self.VV5uIO, sn, self.portal_moreAuthRand)
  else:
   param = ""
  return self.VVAJrJ() + "type=stb&action=get_profile" + param
 def VVDlFf(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVcPgz()
  if len(rows) < 10:
   rows = self.VVeKWk()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVV50h ))
   rows.append(("MAC (from URL)" , self.VV5uIO ))
   rows.append(("Token"   , self.VVQQbm ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VV5uIO ))
   rows.append(("2", self.colored_server, "Host" , self.VVV50h ))
   rows.append(("2", self.colored_server, "Token" , self.VVQQbm ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVyAzS(self, isPhp=True, VVFzkD=False):
  token, profile, tErr = self.VVi4na(VVFzkD)
  if not token:
   return "", tErr
  m3u_Url = ""
  url = self.VViedj()
  res, err = self.VVMG8e(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCSfuP.VVY1fi(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFEQKM(span.group(2))
     pass1 = FFEQKM(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, err
 def VVcPgz(self):
  m3u_Url, err = self.VVyAzS()
  rows = []
  if m3u_Url:
   res, err = self.VVMG8e(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FF2SnK(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FF2SnK(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVeKWk(self):
  token, profile, tErr = self.VVi4na()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFVr9Y(val): val = FF65Vf(val.decode("UTF-8"))
     else     : val = self.VV5uIO
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FF2SnK(int(parts[1]))
      if parts[2] : ends = FF2SnK(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FF2SnK(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVlW1E(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVi4na(VVFzkD=False)
  if not token:
   return ""
  crLinkUrl = self.VVapwq(mode, chCm, epNum, epId)
  res, err = self.VVMG8e(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCSfuP.VVY1fi(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVAJrJ(self):
  return self.VVV50h + "/server/load.php?"
 def VVQ4wF(self):
  return self.VVAJrJ() + "type=stb&action=handshake&token=&mac=%s" % self.VV5uIO
 def VVcq8U(self, mode):
  url = self.VVAJrJ() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVtikk(self, catID):
  return self.VVAJrJ() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVFwvv(self, mode, catID, page):
  url = self.VVAJrJ() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVHVpN(self, mode, searchName, page):
  return self.VVAJrJ() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VVQuJA(self, mode, catID):
  return self.VVAJrJ() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVapwq(self, mode, chCm, serCode, serId):
  url = self.VVAJrJ() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=false" % (mode, chCm)
  return url
 def VViedj(self):
  return self.VVAJrJ() + "type=itv&action=create_link"
 def VVqq9x(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVtzsE(catID, stID, chNum)
  query = self.VVoK8S(mode, FFZHFJ(host), FFZHFJ(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVoK8S(self, mode, host, mac, serCode, serId, chCm):
  query = "mode=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVwEfn(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVoK8S(mode, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FF65Vf(host)
  mac   = FF65Vf(mac)
  valid = False
  if self.VV5TFk(playHost) and self.VV5TFk(host) and self.VV5TFk(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVMG8e(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCzEzL.VVo2tKHeader()
   if self.VVQQbm:
    headers["Authorization"] = "Bearer %s" % self.VVQQbm
   if useCookies : cookies = {"mac": self.VV5uIO, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok : return res, ""
   else  : err = "Err-%d : %s" % (res.status_code, res.reason or "Unknown")
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVpMrE(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCzEzL.VVo2tKHeader(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVo2tKHeader():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVHFvZ(host, mac, tType, action, keysList=[]):
  myPortal = CCzEzL()
  ok = myPortal.VVq0Ex(host, mac)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVi4na(VVFzkD=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s/server/load.php?type=%s&action=%s" % (host, tType, action)
  res, err = myPortal.VVMG8e(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVZQIs(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVZQIs(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVFzkDor(self, err, title="Portal Browser"):
  FF2VP5(self, str(err), title=title)
 def VVCtEi(self, mode):
  if   mode in ("itv"  , CCSfuP.VVWiBs , CCSfuP.VV5kjU)  : return "Live"
  elif mode in ("vod"  , CCSfuP.VVCwmY , CCSfuP.VVPByC)  : return "VOD"
  elif mode in ("series" , CCSfuP.VVGITW , CCSfuP.VVCdMD) : return "Series"
  else                          : return "IPTV"
 def VVX8aB(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVCtEi(mode), searchName)
 def VV9srb(self, catchup=False):
  VVZCgs = []
  VVZCgs.append(("Live"    , "live"  ))
  VVZCgs.append(("VOD"    , "vod"   ))
  VVZCgs.append(("Series"   , "series"  ))
  if catchup:
   VVZCgs.append(VVXQs5)
   VVZCgs.append(("Catchup TV" , "catchup"  ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Account Info." , "accountInfo" ))
  return VVZCgs
 @staticmethod
 def VV3hlt(decodedUrl):
  m3u_Url = ""
  p = CCzEzL()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVwEfn(decodedUrl)
  if valid:
   ok = p.VVq0Ex(host, mac, VVFzkD=False)
   if ok:
    m3u_Url, err = p.VVyAzS(isPhp=False, VVFzkD=False)
    span = iSearch(r".+ch\/(.+)_", decodedUrl, IGNORECASE)
    if span:
     m3u_Url += span.group(1)
  return m3u_Url
 @staticmethod
 def VVuhBD(decodedUrl):
  p = CCzEzL()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVwEfn(decodedUrl)
  if valid:
   if CCzEzL.VV8FVJ(chCm):
    return FFELTf(chCm)
   else:
    ok = p.VVq0Ex(host, mac, VVFzkD=False)
    if ok:
     try:
      chUrl = p.VVlW1E(mode, chCm, epNum, epId)
      return FFELTf(chUrl)
     except Exception as e:
      pass
  return ""
 @staticmethod
 def VV8FVJ(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
class CCDxGJ(CCzEzL):
 def __init__(self):
  CCzEzL.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVOdui(self, refCode, chName, decodedUrl, iptvRef):
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVwEfn(decodedUrl)
  if valid:
   if self.VVq0Ex(host, mac, VVFzkD=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVWmGa(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVlW1E(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CCzEzL.VV8FVJ(self.chCm):
   chUrl = FFELTf(self.chCm)
   chUrl = FFEQKM(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
   isDirect = True
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
   isDirect = True
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVlHJ6(chUrl)
  if newIptvRef:
   success = self.VV878S(self.iptvRef, newIptvRef, isDirect)
   if passedSELF:
    FFqYTj(passedSELF, newIptvRef, VVEWCU=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFqYTj(self, newIptvRef, VVEWCU=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VVlHJ6(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VV878S(self, oldCode, newCode, isDirect):
  bPath = FFNRgf()
  if bPath:
   if isDirect:
    patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
    span = iSearch(patt, newCode, IGNORECASE)
    if span:
     newRef = span.group(1)
     newPar = span.group(2)
     lines = FF5Wuv(bPath)
     for ndx, line in enumerate(lines):
      span = iSearch(patt, line, IGNORECASE)
      if span and newRef == span.group(1) and newPar == span.group(2):
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f:
        for line in lines:
         f.write(line + "\n")
       FFg8wn()
       return True
   else:
    txt = FF1mdj(bPath)
    if oldCode in txt:
     txt = txt.replace(oldCode, newCode)
     with open(bPath, "w") as f:
      f.write(txt)
     FFg8wn()
     return True
  return False
class CCswDV(CCDxGJ):
 def __init__(self, passedSession):
  CCDxGJ.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.isFromEOF  = False
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVnB5T, iPlayableService.evEOF: self.VV5MKS, iPlayableService.evEnd: self.VVHqu5})
  except:
   pass
 def VVnB5T(self):
  self.startTime = iTime()
 def VV5MKS(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self.passedSession, isFromSession=True)
    if iptvRef:
     span = iSearch(r"(mode=itv.+end=)", decodedUrl, IGNORECASE)
     if span:
      self.isFromEOF = True
      CC6e0r(self.passedSession, "Refreshing")
      self.passedSession.nav.stopService()
      self.passedSession.nav.playService(serv)
      InfoBar.instance.hide()
      self.startTime = iTime()
 def VVHqu5(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VV8BVM)
  except:
   self.timer1.callback.append(self.VV8BVM)
  self.timer1.start(100, True)
 def VV8BVM(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVOdui(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCkg2V.VVxiX0:
       self.isFromEOF = False
       self.VVWmGa(self.passedSession, isFromSession=True)
class CCTBCX():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.nameTagPatt = r"\s*.{1,2}\s*[\[(|:]{1,2}\s*(.+)|\s*[\[(|:].{1,5}[\])|:](.+)|\s*(?:[^a-z]+:)*(.+)"
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.missingUtf8 = VVNTnI and not VVbykp
  self.adultWords  = ("adult", "aduld", "sex", "porn", "xxx", "xxi", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.adultWords2 = ("\u042d\u0440\u043e\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0435", "dla doros\u0142ych")
 def VV6xdz(self, name,  censored=""):
  if self.missingUtf8:
   name = str(name.encode('ascii', 'replace').decode('utf-8'))
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCSfuP.VVje6C(name):
   return CCSfuP.VVzzP3(name)
  name = self.VVELfV(name)
  return name.strip() or name
 def VVELfV(self, name):
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    return span.group(1) or span.group(2) or span.group(3)
  return name
 def VVmWyd(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVELfV(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVA5Nn(self, name):
  if self.hideAdult:
   if any(x in name.lower() for x in self.adultWords):
    return ""
   elif any(x in name.encode('ascii', 'backslashreplace').decode('utf-8').lower() for x in self.adultWords2):
    return ""
  return name.strip()
 def VVqc4w(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VV0ADu(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCVmD8(CCzEzL):
 def __init__(self):
  CCzEzL.__init__(self)
 def VV9484(self):
  if CCVmD8.VVlKkZ(self):
   FF9BOI(self, self.VVZ1o3, title="Searching ...")
 def VVbaYP(self, winSession, url, mac):
  if CCVmD8.VVlKkZ(self):
   if self.VVq0Ex(url, mac):
    FF9BOI(winSession, self.VVqS2O, title="Checking Server ...")
   else:
    FF2VP5(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVZ1o3(self):
  path = CCSfuP.VVK2u2()
  lines = FFqFDg('find %s %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % (path, FF1d0b(1)))
  if lines:
   if len(lines) == 1 and lines[0] == VVx0qB:
    FF2VP5(self, VVx0qB)
   else:
    lines.sort()
    VVZCgs = []
    for line in lines:
     VVZCgs.append((line, line))
    OKBtnFnc  = self.VVDbBl
    VVjOrH = ("Delete File", self.VV31N9)
    FF9y9t(self, None, title="Select Portals File", VVZCgs=VVZCgs, width=1200, OKBtnFnc=OKBtnFnc, VVjOrH=VVjOrH)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FF2VP5(self, 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt)
 def VV31N9(self, VVF9lIObj, path):
  FFS238(self, boundFunction(self.VVWHGs, VVF9lIObj, path), "Delete this file ?\n\n%s" % path)
 def VVWHGs(self, VVF9lIObj, path):
  os.system(FF8avg("rm -f '%s'" % path))
  if fileExists(path) : FFSoSp(VVF9lIObj, "Not deleted", 1000)
  else    : VVF9lIObj.VVjh1C()
 def VVDbBl(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = CCgkMM.VVGNzE(path, self)
   if enc == -1:
    return
   self.session.open(CCX8Rl, barTheme=CCX8Rl.VVXb36
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VV06xu, path, enc)
       , VVx6WR = boundFunction(self.VVmIIl, menuInstance, path))
 def VV06xu(self, path, enc, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  progBarObj.VV90iS(totLines)
  progBarObj.VVssld = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVbzgZ(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VV5TFk(url)
     mac  = self.VVPM44(mac)
     if host and mac and progBarObj:
      progBarObj.VVssld.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VV5TFk(url)
      mac  = self.VVPM44(mac)
      if host and mac and not mac.startswith("AC") and progBarObj:
       progBarObj.VVssld.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVmIIl(self, menuInstance, path, VV98Ew, VVssld, threadCounter, threadTotal, threadErr):
  title = "Portals List File"
  if VVssld:
   VVt4yB  = ("Home Menu"  , FFAsVx               , [])
   VVvAyR = ("Edit File"  , boundFunction(self.VVmGTV, path)       , [])
   VVmZVX = ("Open as M3U" , self.VV9DcN           , [])
   VVjzKl = ("Check & Filter" , boundFunction(self.VVkPD4, menuInstance, path) , [])
   VViSv2  = ("Select"  , self.VVbaYP_fromMacFiles   , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVYecm  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVK0Qb = FFuN9x(self, None, title=title, header=header, VVUQjT=VVssld, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=26, VViSv2=VViSv2, VVt4yB=VVt4yB, VVmZVX=VVmZVX, VVvAyR=VVvAyR, VVjzKl=VVjzKl, VVZOs8="#0a001122", VVEkOu="#0a001122", VVJbor="#0a001122", VVsesB="#00004455", VV1Ceb="#0a333333", VVEtDu="#11331100", VVfaqm=True, searchCol=1)
   if not VV98Ew:
    FFSoSp(VVK0Qb, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VV98Ew:
    FF2VP5(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VV9DcN(self, VVK0Qb, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  FF9BOI(VVK0Qb, boundFunction(self.VVtj2X, VVK0Qb, host, mac), title="Checking Server ...")
 def VVtj2X(self, VVK0Qb, host, mac):
  p = CCzEzL()
  m3u_Url = ""
  ok = p.VVq0Ex(host, mac, VVFzkD=False)
  err = ""
  if ok:
   m3u_Url, err = p.VVyAzS(VVFzkD=False)
  title = "Browsing M3U Server from Portal Data"
  if m3u_Url:
   self.VV2Rwk(title, m3u_Url)
  else:
   FF2VP5(self, err or "No response from Server !", title=title)
 def VVbaYP_fromMacFiles(self, VVK0Qb, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVbaYP(VVK0Qb, url, mac)
 def VVmGTV(self, path, VVK0Qb, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCLioI(self, path, VVx6WR=boundFunction(self.VVVDae, VVK0Qb), curRowNum=rowNum)
  else    : FFzAsS(self, path)
 def VVkPD4(self, menuInstance, path, VVK0Qb, title, txt, colList):
  self.session.open(CCX8Rl, barTheme=CCX8Rl.VVBfB6
      , titlePrefix = "Checking Portals"
      , fncToRun  = boundFunction(self.VVqG28, VVK0Qb)
      , VVx6WR = boundFunction(self.VVL82T, menuInstance, VVK0Qb, path))
 def VVqG28(self, VVK0Qb, progBarObj):
  progBarObj.VVssld = []
  progBarObj.VV90iS(VVK0Qb.VVUBSs())
  for row in VVK0Qb.VVotmZ():
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVbzgZ(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVq0Ex(host, mac, VVFzkD=False):
    token, profile, tErr = self.VVi4na(VVFzkD=False)
    if token and progBarObj and not progBarObj.isCancelled:
     res, err = self.VVMG8e(self.VVcq8U("itv"))
     if res and progBarObj and not progBarObj.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       progBarObj.VVbzgZ(0, showFound=True)
       progBarObj.VVssld.append((titl, host, mac, cmnt))
      except:
       pass
   if not progBarObj:
    return
 def VVL82T(self, menuInstance, VVK0Qb, path, VV98Ew, VVssld, threadCounter, threadTotal, threadErr):
  if VVssld:
   VVK0Qb.close()
   menuInstance.close()
   newPath = "%s_OK_%s.txt" % (path, FFNMff())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVssld:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FFc8cv(str(threadCounter), VVy89V)
    skipped = FFc8cv(str(threadTotal - threadCounter), VVy89V)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVssld)
   txt += "%s\n\n%s"    %  (FFc8cv("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
   FFfnpN(self, txt, title="Accessible Portals")
  elif VV98Ew:
   FF2VP5(self, "No portal access found !", title="Accessible Portals")
 def VVmVY8(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FF65Vf(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVqS2O(self):
  token, profile, tErr = self.VVi4na()
  if token:
   dots = "." * self.portal_moreAuthType
   VVZCgs  = self.VV9srb()
   OKBtnFnc = self.VVFbYm
   VVV04i = ("Home Menu", FFAsVx)
   VVcc6k = ("Bookmark Server", boundFunction(CCSfuP.VVNYSX, self, True, self.VVV50h + "\t" + self.VV5uIO))
   FF9y9t(self, None, title="Portal Resources (MAC=%s) %s" % (self.VV5uIO, dots), VVZCgs=VVZCgs, OKBtnFnc=OKBtnFnc, VVV04i=VVV04i, VVcc6k=VVcc6k)
 def VVFbYm(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FF9BOI(menuInstance, boundFunction(self.VV521V, mode), title="Reading Categories ...")
   else : FF9BOI(menuInstance, boundFunction(self.VV8YSg, menuInstance, title), title="Reading Account ...")
 def VV8YSg(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVDlFf(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VV5uIO)
  VVt4yB  = ("Home Menu" , FFAsVx            , [])
  VVmZVX  = None
  if VVafbh:
   VVmZVX = ("Get JS"  , boundFunction(self.VVzmit, self.VVV50h) , [])
  if totCols == 2:
   VVjzKl = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVjzKl = ("More Info.", boundFunction(self.VV3IkZ, menuInstance) , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFuN9x(self, None, title=title, width=1200, header=header, VVUQjT=rows, VV5Xly=widths, VVz3yz=26, VVt4yB=VVt4yB, VVmZVX=VVmZVX, VVjzKl=VVjzKl, VVZOs8="#0a00292B", VVEkOu="#0a002126", VVJbor="#0a002126", VVsesB="#00000000", searchCol=searchCol)
 def VVzmit(self, url, VVK0Qb, title, txt, colList):
  FF9BOI(VVK0Qb, boundFunction(self.VVF427, url), title="Getting JS ...")
 def VVF427(self, url):
  txt = "// Host\t: %s\n" % url
  res, err = self.VVMG8e("%s/c/version.js" % url)
  if not err: ver = res.text
  else   : ver = "Error: %s" % err
  txt += "// Version\t: %s\n" % ver
  res, err = self.VVMG8e("%s/c/xpcom.common.js" % url)
  if not err: js = res.text
  else   : js = "Error: %s" % err
  txt += "\n%s" % js
  FFfnpN(self, txt, title="JS Info", canSaveToFile="Server_xpcom.common.js")
 def VV3IkZ(self, menuInstance, VVK0Qb, title, txt, colList):
  VVK0Qb.cancel()
  FF9BOI(menuInstance, boundFunction(self.VV8YSg, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VV521V(self, mode):
  token, profile, tErr = self.VVi4na()
  if not token:
   return
  res, err = self.VVMG8e(self.VVcq8U(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CCTBCX()
     chList = tDict["js"]
     for item in chList:
      Id   = CCSfuP.VVY1fi(item, "id"       )
      Title  = CCSfuP.VVY1fi(item, "title"      )
      censored = CCSfuP.VVY1fi(item, "censored"     )
      Title = processChanName.VVA5Nn(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVafbh:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVCtEi(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVZOs8, VVEkOu, VVJbor, VVsesB = self.VVX0mC(mode)
   mName = self.VVCtEi(mode)
   VViSv2   = ("Show List"   , boundFunction(self.VVPu2q, mode) , [])
   VVt4yB  = ("Home Menu"   , FFAsVx         , [])
   if mode in ("vod", "series"):
    VVvAyR = ("Find in %s" % mName , boundFunction(self.VVMcdw, mode), [])
   else:
    VVvAyR = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FFuN9x(self, None, title=title, width=1200, header=header, VVUQjT=list, VV5Xly=widths, VVz3yz=30, VVt4yB=VVt4yB, VVvAyR=VVvAyR, VViSv2=VViSv2, VVZOs8=VVZOs8, VVEkOu=VVEkOu, VVJbor=VVJbor, VVsesB=VVsesB)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.portal_moreAuthMsg:
     txt += "\n\n( %s )" % self.portal_moreAuthMsg
   else:
    txt = "Could not get Categories from server!"
   FF2VP5(self, txt, title=title)
 def VVoKKy(self, mode, VVK0Qb, title, txt, colList):
  FF9BOI(VVK0Qb, boundFunction(self.VVIMbD, mode, VVK0Qb, title, txt, colList), title="Downloading ...")
 def VVIMbD(self, mode, VVK0Qb, title, txt, colList):
  token, profile, tErr = self.VVi4na()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVMG8e(self.VVtikk(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCSfuP.VVY1fi(item, "id"    )
      actors   = CCSfuP.VVY1fi(item, "actors"   )
      added   = CCSfuP.VVY1fi(item, "added"   )
      age    = CCSfuP.VVY1fi(item, "age"   )
      category_id  = CCSfuP.VVY1fi(item, "category_id" )
      description  = CCSfuP.VVY1fi(item, "description" )
      director  = CCSfuP.VVY1fi(item, "director"  )
      genres_str  = CCSfuP.VVY1fi(item, "genres_str"  )
      name   = CCSfuP.VVY1fi(item, "name"   )
      path   = CCSfuP.VVY1fi(item, "path"   )
      screenshot_uri = CCSfuP.VVY1fi(item, "screenshot_uri" )
      series   = CCSfuP.VVY1fi(item, "series"   )
      cmd    = CCSfuP.VVY1fi(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VViSv2  = ("Play"    , boundFunction(self.VVlO9l, mode)       , [])
   VV7Iri = (""     , boundFunction(self.VV5gNS, mode)     , [])
   VVt4yB = ("Home Menu"   , FFAsVx               , [])
   VVmZVX = ("Download Options" , boundFunction(self.VVEPGa, mode, "sp", seriesName) , [])
   VVvAyR = ("Options" , boundFunction(self.VVWYED, 0, "pEp", mode, seriesName)  , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVYecm  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFuN9x(self, None, title=seriesName, width=1200, header=header, VVUQjT=list, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=26, VVt4yB=VVt4yB, VVmZVX=VVmZVX, VVvAyR=VVvAyR, VViSv2=VViSv2, VV7Iri=VV7Iri, VVZOs8="#0a00292B", VVEkOu="#0a002126", VVJbor="#0a002126", VVsesB="#00000000")
  else:
   FF2VP5(self, "Could not get Episodes from server!", title=seriesName)
 def VVMcdw(self, mode, VVK0Qb, title, txt, colList):
  VVZCgs = []
  VVZCgs.append(("Keyboard"  , "manualEntry"))
  VVZCgs.append(("From Filter" , "fromFilter"))
  FF9y9t(self, boundFunction(self.VVDA8N, VVK0Qb, mode), title="Input Type", VVZCgs=VVZCgs, width=400)
 def VVDA8N(self, VVK0Qb, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFIPSl(self, boundFunction(self.VV7uxF, VVK0Qb, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CC3CTD(self)
    filterObj.VVxSFA(boundFunction(self.VV7uxF, VVK0Qb, mode))
 def VV7uxF(self, VVK0Qb, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VVX8aB(mode, searchName)
   if len(searchName) < 3:
    FF2VP5(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CCTBCX()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVqc4w([searchName]):
     FF2VP5(self, processChanName.VV0ADu(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VV85wz(mode, searchName, "", searchName)
 def VVPu2q(self, mode, VVK0Qb, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VV85wz(mode, bName, catID, "")
 def VV85wz(self, mode, bName, catID, searchName):
  self.session.open(CCX8Rl, barTheme=CCX8Rl.VVXb36
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVrjGe, mode, bName, catID, searchName)
      , VVx6WR = boundFunction(self.VVLMB3, mode, bName, catID, searchName))
 def VVLMB3(self, mode, bName, catID, searchName, VV98Ew, VVssld, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVX8aB(mode, searchName)
  else   : title = "%s : %s" % (self.VVCtEi(mode), bName)
  if VVssld:
   VVmZVX = None
   VVvAyR = None
   if mode == "series":
    VVZOs8, VVEkOu, VVJbor, VVsesB = self.VVX0mC("series2")
    VViSv2  = ("Episodes", boundFunction(self.VVoKKy, mode) , [])
   else:
    VVZOs8, VVEkOu, VVJbor, VVsesB = self.VVX0mC("")
    VViSv2  = ("Play"    , boundFunction(self.VVlO9l, mode)           , [])
    VVmZVX = ("Download Options" , boundFunction(self.VVEPGa, mode, "vp" if mode == "vod" else "", "") , [])
    VVvAyR = ("Options"   , boundFunction(self.VVWYED, 1, "pCh", mode, bName)      , [])
   VV7Iri = (""      , boundFunction(self.VVnQI8, mode)          , [])
   VVt4yB = ("Home Menu"    , FFAsVx                   , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVYecm  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT )
   VVK0Qb = FFuN9x(self, None, title=title, header=header, VVUQjT=VVssld, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=26, VVt4yB=VVt4yB, VVmZVX=VVmZVX, VVvAyR=VVvAyR, VViSv2=VViSv2, VV7Iri=VV7Iri, VVZOs8=VVZOs8, VVEkOu=VVEkOu, VVJbor=VVJbor, VVsesB=VVsesB, VVfaqm=True, searchCol=1)
   if not VV98Ew:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVK0Qb.VVcvJH(VVK0Qb.VVf2AE() + tot)
    if threadErr: FFSoSp(VVK0Qb, "Error while reading !", 2000)
    else  : FFSoSp(VVK0Qb, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FF2VP5(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FF2VP5(self, "Could not get list from server !", title=title)
 def VVnQI8(self, mode, VVK0Qb, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFQvwR(self, fncMode=CCXD20.VVuce4, portalHost=self.VVV50h, portalMac=self.VV5uIO, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VV570X(mode, VVK0Qb, title, txt, colList)
 def VV5gNS(self, mode, VVK0Qb, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFc8cv(colList[10], VVaDOU)
  txt += "Description:\n%s" % FFc8cv(colList[11], VVaDOU)
  self.VV570X(mode, VVK0Qb, title, txt, colList)
 def VV570X(self, mode, VVK0Qb, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVwOyE(mode, colList)
  refCode, chUrl = self.VVqq9x(self.VVV50h, self.VV5uIO, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFQvwR(self, fncMode=CCXD20.VV1hWt, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVrjGe(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile, tErr = self.VVi4na()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VVssld, total_items, max_page_items, err = self.VVZBIl(mode, catID, 1, 1, searchName)
   if progBarObj.isCancelled:
    return
   if progBarObj.VVssld and total_items > -1 and max_page_items > -1:
    progBarObj.VV90iS(total_items)
    progBarObj.VVbzgZ(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVZBIl(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VVgg2g()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VVssld += list
      progBarObj.VVbzgZ(len(list), True)
  except:
   pass
 def VVZBIl(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVHVpN(mode, searchName, page)
  else   : url = self.VVFwvv(mode, catID, page)
  res, err = self.VVMG8e(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVRjzp(CCSfuP.VVY1fi(item, "total_items" ))
     max_page_items = self.VVRjzp(CCSfuP.VVY1fi(item, "max_page_items" ))
     processChanName = CCTBCX()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCSfuP.VVY1fi(item, "id"    )
      name   = CCSfuP.VVY1fi(item, "name"   )
      o_name   = CCSfuP.VVY1fi(item, "o_name"   )
      tv_genre_id  = CCSfuP.VVY1fi(item, "tv_genre_id" )
      number   = CCSfuP.VVY1fi(item, "number"   ) or str(counter)
      logo   = CCSfuP.VVY1fi(item, "logo"   )
      screenshot_uri = CCSfuP.VVY1fi(item, "screenshot_uri" )
      cmd    = CCSfuP.VVY1fi(item, "cmd"   )
      censored  = CCSfuP.VVY1fi(item, "censored"  )
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       span = iSearch(r"stream=(.+)&", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
       else:
        span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVV50h + picon).replace(sp * 2, sp)
      counter += 1
      name = processChanName.VV6xdz(name, censored)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVkeCL(self, mode, bName, VVK0Qb, title, txt, colList):
  bNameFile = CCSfuP.VVZnMM_forBouquet(bName)
  num  = 0
  path = VVqs92 + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVqs92 + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   isMulti = VVK0Qb.VVFxSi
   for ndx, row in enumerate(VVK0Qb.VVotmZ()):
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVwOyE(mode, row)
    refCode, chUrl = self.VVqq9x(self.VVV50h, self.VV5uIO, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    if not isMulti or VVK0Qb.VVT0y1(ndx):
     f.write("#SERVICE %s\n"  % chUrl)
     f.write("#DESCRIPTION %s\n" % chName)
     totChange += 1
  FF4ns5(os.path.basename(path))
  self.VV7PMG(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVRjzp(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVlO9l(self, mode, VVK0Qb, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVwOyE(mode, colList)
  refCode, chUrl = self.VVqq9x(self.VVV50h, self.VV5uIO, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVje6C(chName):
   FFSoSp(VVK0Qb, "This is a marker!", 300)
  else:
   FF9BOI(VVK0Qb, boundFunction(self.VVo9BJ, mode, VVK0Qb, chUrl), title="Playing ...")
 def VVo9BJ(self, mode, VVK0Qb, chUrl):
  FFqYTj(self, chUrl, VVEWCU=False)
  self.session.open(CCkg2V, portalTableParam=(self, VVK0Qb, mode))
 def VVOJa6(self, mode, VVK0Qb, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVwOyE(mode, colList)
  refCode, chUrl = self.VVqq9x(self.VVV50h, self.VV5uIO, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVwOyE(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVlKkZ(SELF):
  try:
   import requests
   return True
  except:
   title = 'Install "Requests"'
   VVZCgs = []
   VVZCgs.append((title        , "inst" ))
   VVZCgs.append(("Update Packages then %s" % title , "updInst" ))
   FF9y9t(SELF, boundFunction(CCVmD8.VVpPTv, SELF), title='This requires Python "Requests" library', VVZCgs=VVZCgs)
   return False
 @staticmethod
 def VVpPTv(SELF, item=None):
  if item:
   from sys import version_info
   cmdUpd = FFxiGu(VVDa2A, "")
   if cmdUpd:
    cmdInst = FFfBk8(VVQ5tW, "python-requests")
    if version_info[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFeerf(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library')
   else:
    FFh46b(SELF)
class CCSfuP(Screen, CCVmD8):
 VVZ3qm    = 0
 VVuKRo    = 1
 VVaWUp    = 2
 VV9ngY    = 3
 VV6wF2     = 4
 VV8aq7     = 5
 VVSXCN     = 6
 VVojTD     = 7
 VVTBRg      = 8
 VVUEvP     = 9
 VVzUoc     = 10
 VVC9k4     = 11
 VVFmS2     = 12
 VVSRYl      = 13
 VVRSQQ      = 14
 VVK5pU      = 15
 VVoBkc      = 16
 VVarkj      = 17
 VV6Mha    = 0
 VVWiBs   = 1
 VVCwmY   = 2
 VVGITW   = 3
 VVnSxw  = 4
 VVueES  = 5
 VV5kjU   = 6
 VVPByC   = 7
 VVCdMD  = 8
 VVcX68  = 9
 VV9aB1  = 10
 VVhFbZ = 0
 VVVI4o = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFZerm(VVj3bT, 1000, 1000, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.m3uOrM3u8File  = m3uOrM3u8File
  self.m3uOrM3u8BName  = ""
  self.VVK0Qb  = None
  self.tableTitle   = "IPTV Channels List"
  self.VVvCh2Data  = {}
  self.lastFindIptvName = ""
  CCVmD8.__init__(self)
  VVZCgs= self.VV8ZJ8()
  FFeVzc(self, title="IPTV", VVZCgs=VVZCgs)
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FFDd6I(self["myMenu"])
  FFGCoH(self)
  FFVdFu(self)
  if self.m3uOrM3u8File:
   self.VVkF7T(self.m3uOrM3u8File)
 def VV8ZJ8(self):
  files = self.VVEbyK()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"        , "VVvCh2_fromPlayList" ))
  tList.append(("IPTV Server Browser (from Portal List)"        , "VVvCh2_fromMac"  ))
  tList.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)"    , "VVvCh2_fromM3u"  ))
  qUrl, iptvRef = self.VVm3Hn()
  if qUrl or "chCode" in iptvRef:
   tList.append(("IPTV Server Browser (from Current Channel)"      , "VVvCh2_fromCurrChan" ))
  VVZCgs = []
  if files:
   if self.VVK0Qb:
    VVZCgs.append(("Add Current List to a New Bouquet"      , "VV0fjf"  ))
    VVZCgs.append(VVXQs5)
    VVZCgs.append(("Change Current List References to Unique Codes"   , "VVW5c6"))
    VVZCgs.append(("Change Current List References to Identical Codes"  , "VVLzNJ_rows" ))
    VVZCgs.append(VVXQs5)
    VVZCgs.append(("Share Reference with Satellite/C/T Service (manual entry)", "VVyYfC"   ))
    VVZCgs.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VVK3Gg"   ))
   else:
    VVZCgs += tList
    VVZCgs.append(VVXQs5)
    VVZCgs.append(("M3U/M3U8 File Browser"         , "VVJ5jg"   ))
    VVZCgs.append(("Local IPTV Channels"          , "iptvTable_all"   ))
    if qUrl:
     VVZCgs.append(VVXQs5)
     VVZCgs.append(("Update Current Bouquet EPG (from IPTV Server)"  , "refreshIptvEPG"   ))
    VVZCgs.append(VVXQs5)
    VVZCgs.append(("Count Available IPTV Channels"       , "VVUjhl"    ))
    VVZCgs.append(("Check Reference Codes Format"        , "VVQ6Vw"   ))
    VVZCgs.append(("Check System Acceptable Reference Types"     , "VVf4mF"   ))
    VVZCgs.append(VVXQs5)
    VVZCgs.append(("Share Reference with Sat./C/T (Only Matching Names)"  , "VVRedv" ))
    VVZCgs.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVmgWI"  ))
    VVZCgs.append(("Change ALL References to Unique Codes"     , "VV0htw" ))
    VVZCgs.append(("Change ALL References to Identical Codes"     , "VVLzNJ_all" ))
  if not self.VVK0Qb:
   if not files:
    VVZCgs += tList
   if not CCXZq2.VVnprH():
    VVZCgs.append(VVXQs5)
    VVZCgs.append(("Download Manager"           , "dload_stat"    ))
  return VVZCgs
 def VVNhyA(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VV0fjf"   : FFIPSl(self, self.VV0fjf, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVW5c6" : FFS238(self, boundFunction(FF9BOI, self.VVK0Qb, self.VVW5c6 ), "Change Current List References to Unique Codes ?")
   elif item == "VVLzNJ_rows" : FFS238(self, boundFunction(FF9BOI, self.VVK0Qb, self.VVLzNJ   ), "Change Current List References to Identical Codes ?")
   elif item == "VVyYfC"   : self.VVyYfC(tTitle)
   elif item == "VVK3Gg"   : self.VVK3Gg(tTitle)
   elif item == "VVvCh2_fromPlayList" : FF9BOI(self, self.VVB328, title=title)
   elif item == "VVvCh2_fromM3u"  : FF9BOI(self, boundFunction(self.VVzm4r, 0), title=title)
   elif item == "VVvCh2_fromMac"  : self.VV9484()
   elif item == "VVvCh2_fromCurrChan" : self.VVbaYP_fromCurrChan()
   elif item == "VVJ5jg"   : self.VVJ5jg()
   elif item == "iptvTable_live"   : FF9BOI(self, boundFunction(self.VVxC7D, self.VVojTD ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FF9BOI(self, boundFunction(self.VVxC7D, self.VVZ3qm) , title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VVXFT0()
   elif item == "VVUjhl"    : FF9BOI(self, self.VVUjhl)
   elif item == "VVQ6Vw"    : FF9BOI(self, self.VVQ6Vw)
   elif item == "VVf4mF"   : FF9BOI(self, self.VVf4mF)
   elif item == "VVRedv"  : FFS238(self, boundFunction(FF9BOI, self, self.VVRedv ), "Continue ?")
   elif item == "VVmgWI"  : self.VVmgWI()
   elif item == "VV0htw" : FFS238(self, boundFunction(FF9BOI, self, self.VV0htw ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVLzNJ_all" : FFS238(self, boundFunction(FF9BOI, self, self.VVLzNJ  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "dload_stat"    : CCXZq2.VV4PEQ(self)
   elif item == "VVopFb"   : FF9BOI(self, boundFunction(CCze4R.VVopFb, self))
 def VVJ5jg(self):
  if CCVmD8.VVlKkZ(self):
   FF9BOI(self, boundFunction(self.VVzm4r, 1), title="Searching ...")
 def VVh5RL(self):
  global VVTyjD
  VVTyjD = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVNhyA(item)
 def VVxC7D(self, mode):
  VV5uoU = self.VVZr4E(mode)
  if VV5uoU:
   VVmZVX = ("Current Service", self.VVlzM5  , [])
   VVvAyR = ("Options"  , self.VVwJVI    , [])
   VVjzKl = ("Filter"   , self.VVXhyf    , [])
   VViSv2  = ("Play"   , boundFunction(self.VVbQEg) , [])
   VV7Iri = (""    , self.VVsQd0     , [])
   VVyNAY = (""    , self.VV6OEl      , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVYecm  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFuN9x(self, None, header=header, VVUQjT=VV5uoU, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=26
     , VViSv2=VViSv2, VVmZVX=VVmZVX, VVvAyR=VVvAyR, VVjzKl=VVjzKl, VV7Iri=VV7Iri, VVyNAY=VVyNAY
     , VVZOs8="#0a00292B", VVEkOu="#0a002126", VVJbor="#0a002126", VVsesB="#00000000", VVfaqm=True, searchCol=1)
  else:
   if mode == self.VVojTD: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FF2VP5(self, err)
 def VV6OEl(self, VVK0Qb, title, txt, colList):
  self.VVK0Qb = VVK0Qb
 def VVwJVI(self, VVK0Qb, title, txt, colList):
  VVZCgs= self.VV8ZJ8()
  FF9y9t(self, self.VVNhyA, title="IPTV Tools", VVZCgs=VVZCgs)
 def VVXhyf(self, VVK0Qb, title, txt, colList):
  VVZCgs = []
  VVZCgs.append(("All"         , "all"   ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Prefix of Selected Channel"   , "sameName" ))
  VVZCgs.append(("Suggest Words from Selected Channel" , "partName" ))
  VVZCgs.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Live TV"        , "live"  ))
  VVZCgs.append(("VOD"         , "vod"   ))
  VVZCgs.append(("Series"        , "series"  ))
  VVZCgs.append(("Uncategorised"      , "uncat"  ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Video"        , "video"  ))
  VVZCgs.append(("Audio"        , "audio"  ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("MKV"         , "MKV"   ))
  VVZCgs.append(("MP4"         , "MP4"   ))
  VVZCgs.append(("MP3"         , "MP3"   ))
  VVZCgs.append(("AVI"         , "AVI"   ))
  VVZCgs.append(("FLV"         , "FLV"   ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VV4w9O()
  if bNames:
   bNames.sort()
   VVZCgs.append(VVXQs5)
   for item in bNames:
    VVZCgs.append((item, "__b__" + item))
  filterObj = CC3CTD(self)
  filterObj.VVAM7J(VVZCgs, VVZCgs, boundFunction(self.VVDjq9, VVK0Qb))
 def VVDjq9(self, VVK0Qb, item=None):
  prefix = VVK0Qb.VVPPM9(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVZ3qm, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVuKRo , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVaWUp , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VV9ngY , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVojTD  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVTBRg   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVUEvP  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVzUoc  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVC9k4  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVFmS2  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVSRYl   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVRSQQ   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVK5pU   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVoBkc   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVarkj   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVSXCN  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VV6wF2  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VV8aq7  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVaWUp:
   VVZCgs = []
   chName = VVK0Qb.VVPPM9(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVZCgs.append((item, item))
    if not VVZCgs and chName:
     VVZCgs.append((chName, chName))
    FF9y9t(self, boundFunction(self.VVZjzo_partOfName, title), title="Words from Current Selection", VVZCgs=VVZCgs)
   else:
    VVK0Qb.VV5V7a("Invalid Channel Name")
  else:
   words, asPrefix = CC3CTD.VVsnwy(words)
   if not words and mode in (self.VV6wF2, self.VV8aq7):
    FFSoSp(self.VVK0Qb, "Incorrect filter", 2000)
   else:
    FF9BOI(self.VVK0Qb, boundFunction(self.VVoL7x, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVZjzo_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FF9BOI(self.VVK0Qb, boundFunction(self.VVoL7x, self.VVaWUp, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVzzP3(txt):
  return "#f#11ffff00#" + txt
 def VVoL7x(self, mode, words, asPrefix, title):
  VV5uoU = self.VVZr4E(mode=mode, words=words, asPrefix=asPrefix)
  if VV5uoU : self.VVK0Qb.VVOukU(VV5uoU, title)
  else  : self.VVK0Qb.VV5V7a("Not found")
 def VVZr4E(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VV5uoU = []
  files  = self.VVEbyK()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FF1mdj(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVVnCp = span.group(1)
    else : VVVnCp = ""
    VVVnCp_lCase = VVVnCp.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVje6C(chName): chNameMod = self.VVzzP3(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVVnCp, chType, refCode, url)
     ok = False
     tUrl = FFELTf(url).lower()
     if mode == self.VVZ3qm       : ok = True
     elif mode == self.VVSXCN       : ok = True
     elif mode == self.VVC9k4:
      if CCSfuP.VVhkWC(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVFmS2:
      if CCSfuP.VVhkWC(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVojTD:
      if CCSfuP.VVhkWC(tUrl, compareType="live")  : ok = True
     elif mode == self.VVTBRg:
      if CCSfuP.VVhkWC(tUrl, compareType="movie") : ok = True
     elif mode == self.VVUEvP:
      if CCSfuP.VVhkWC(tUrl, compareType="series") : ok = True
     elif mode == self.VVzUoc:
      if CCSfuP.VVhkWC(tUrl, compareType="")   : ok = True
     elif mode == self.VVSRYl:
      if CCSfuP.VVhkWC(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVRSQQ:
      if CCSfuP.VVhkWC(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVK5pU:
      if CCSfuP.VVhkWC(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVoBkc:
      if CCSfuP.VVhkWC(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVarkj:
      if CCSfuP.VVhkWC(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVuKRo:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVaWUp:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VV9ngY:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VV6wF2:
      if words[0] == VVVnCp_lCase:
       ok = True
     elif mode == self.VV8aq7:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VV5uoU.append(row)
      chNum += 1
  if VV5uoU and mode == self.VVSXCN:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VV5uoU)
   for item in VV5uoU:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VV5uoU = newRows
  return VV5uoU
 def VV0fjf(self, bName):
  if bName:
   FF9BOI(self.VVK0Qb, boundFunction(self.VVU0hB, bName), title="Adding Channels ...")
 def VVU0hB(self, bName):
  num = 0
  path = VVqs92 + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVqs92 + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVK0Qb.VVotmZ():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FF3aqm(row[1]))
    totChange += 1
  FF4ns5(os.path.basename(path))
  self.VV7PMG(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVmgWI(self):
  txt = "Stream Type "
  VVZCgs = []
  VVZCgs.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVZCgs.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVZCgs.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVZCgs.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVZCgs.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVZCgs.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FF9y9t(self, self.VVnd6G, title="Change Reference Types to:", VVZCgs=VVZCgs)
 def VVnd6G(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVZMRo("1"   )
   elif item == "RT_4097" : self.VVZMRo("4097")
   elif item == "RT_5001" : self.VVZMRo("5001")
   elif item == "RT_5002" : self.VVZMRo("5002")
   elif item == "RT_8192" : self.VVZMRo("8192")
   elif item == "RT_8193" : self.VVZMRo("8193")
 def VVZMRo(self, rType):
  FFS238(self, boundFunction(FF9BOI, self, boundFunction(self.VVu9kV, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVu9kV(self, refType):
  totChange = 0
  files  = self.VVEbyK()
  if files:
   for path in files:
    txt = FF1mdj(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FF4ns5(os.path.basename(path))
  self.VV7PMG(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVUjhl(self):
  totFiles = 0
  files  = self.VVEbyK()
  if files:
   totFiles = len(files)
  totChans = 0
  VV5uoU = self.VVZr4E()
  if VV5uoU:
   totChans = len(VV5uoU)
  FFfnpN(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVQ6Vw(self):
  files  = self.VVEbyK()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FF1mdj(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VV09cj
   else    : color = VVy89V
   totInvalid = FFc8cv(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFc8cv("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFfnpN(self, txt, title="Check IPTV References")
 def VVf4mF(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVqs92 + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FF4ns5(os.path.basename(path))
  FFg8wn()
  acceptedList = []
  VVyuYG = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVyuYG:
   VVkVfI = FFfahj(VVyuYG)
   if VVkVfI:
    for service in VVkVfI:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVqs92 + userBName
  bFile = VVqs92 + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FF8avg("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FF8avg("rm -f '%s'" % path)
  os.system(cmd)
  FFg8wn()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VV09cj
    else     : res, color = "No" , VVy89V
    txt += "    %s\t: %s\n" % (item, FFc8cv(res, color))
   FFfnpN(self, txt, title=title)
  else:
   txt = FF2VP5(self, "Could not complete the test on your system!", title=title)
 def VVRedv(self):
  lameDbChans = CCze4R.VVEbjS(self, CCze4R.VV0e7k)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVEbyK():
    toSave = False
    txt = FF1mdj(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VV7PMG(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FF2VP5(self, 'No channels in "lamedb" !')
 def VV0htw(self):
  files  = self.VVEbyK()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FF5Wuv(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVe8f0(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VV7PMG(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVW5c6(self):
  iptvRefList = []
  files  = self.VVEbyK()
  if files:
   for path in files:
    txt = FF1mdj(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVK0Qb.VVP4oe(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVe8f0(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVEbyK()
  if files:
   for path in files:
    lines = FF5Wuv(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VV7PMG(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVe8f0(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVLzNJ(self):
  list = None
  if self.VVK0Qb:
   list = []
   for row in self.VVK0Qb.VVotmZ():
    list.append(row[4] + row[5])
  files  = self.VVEbyK()
  totChange = 0
  if files:
   for path in files:
    lines = FF5Wuv(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VV7PMG(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VV7PMG(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFg8wn()
   if refreshTable and self.VVK0Qb:
    VV5uoU = self.VVZr4E()
    if VV5uoU and self.VVK0Qb:
     self.VVK0Qb.VVOukU(VV5uoU, self.tableTitle)
     self.VVK0Qb.VV5V7a(txt)
   FFfnpN(self, txt, title=title)
  else:
   FFiM80(self, "No changes.")
 def VV4w9O(self):
  files = self.VVEbyK()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with ioOpen(path, "r", encoding="utf-8") as f:
     span = iSearch(r"#NAME\s+(.*)", str(f.readline()), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VVpaei = FFEetI()
    if VVpaei:
     for b in VVpaei:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVEbyK(self):
  return CCSfuP.VVp7Ds(self)
 @staticmethod
 def VVp7Ds(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVqs92 + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FF1mdj(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVsQd0(self, VVK0Qb, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFELTf(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFQvwR(self, fncMode=CCXD20.VVBiry, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVyPNI(self, VVK0Qb, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVbQEg(self, VVK0Qb, title, txt, colList):
  chName, chUrl = self.VVyPNI(VVK0Qb, colList)
  self.VVguTo(VVK0Qb, chName, chUrl, "localIptv")
 def VVQ8fG(self, mode, VVK0Qb, colList):
  chName, chUrl, picUrl, refCode = self.VVmg49(mode, colList)
  return chName, chUrl
 def VV6JtK(self, mode, VVK0Qb, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVmg49(mode, colList)
  self.VVguTo(VVK0Qb, chName, chUrl, mode)
 def VVguTo(self, VVK0Qb, chName, chUrl, playerFlag):
  chName = FF3aqm(chName)
  if self.VVje6C(chName):
   FFSoSp(VVK0Qb, "This is a marker!", 300)
  else:
   FF9BOI(VVK0Qb, boundFunction(self.VVKsQe, VVK0Qb, chUrl, playerFlag), title="Playing ...")
 def VVKsQe(self, VVK0Qb, chUrl, playerFlag):
  FFqYTj(self, chUrl, VVEWCU=False)
  self.session.open(CCkg2V, portalTableParam=(self, VVK0Qb, playerFlag))
 @staticmethod
 def VVje6C(chName):
  mark = ("--", "__", "==", "##",  "**", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVlzM5(self, VVK0Qb, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self)
  if refCode:
   bName = FFVUtv()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFtv9b(refCode, origUrl, chName) }
   VVK0Qb.VVZeWW_partial(colDict, VVFzkD=True)
 def VVzm4r(self, m3uMode):
  path = CCSfuP.VVK2u2()
  lines = FFqFDg("find %s %s -iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'" % (path, FF1d0b(1)))
  if lines:
   lines.sort()
   VVZCgs = []
   for line in lines:
    VVZCgs.append((line, line))
   if m3uMode == self.VVhFbZ:
    title = "Browse Server from M3U URLs"
    VVcc6k = ("All to Playlist", self.VVUd3t)
   else:
    title = "M3U/M3U8 File Browser"
    VVcc6k = None
   OKBtnFnc = boundFunction(self.VVswAg, m3uMode, title)
   VVP7wO  = ("Show Full Path", self.VViEy7)
   VVjOrH = ("Delete File", self.VV31N9)
   FF9y9t(self, None, title=title, VVZCgs=VVZCgs, width=1200, OKBtnFnc=OKBtnFnc, VVP7wO=VVP7wO, VVjOrH=VVjOrH, VVcc6k=VVcc6k)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n\n%s" % path
   FF2VP5(self, 'No ".m3u" files found %s' % txt)
 def VViEy7(self, VVF9lIObj, url):
  FFfnpN(self, url, title="Full Path")
 def VVswAg(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == self.VVhFbZ:
    FF9BOI(menuInstance, boundFunction(self.VVCz2y, title, path))
   else:
    FF9BOI(menuInstance, boundFunction(self.VVkF7T, path))
 def VVkF7T(self, srcPath):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FF1mdj(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  processChanName = CCTBCX()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VV6EgT(propLine, "group-title") or "-"
   if not group == "-" and processChanName.VV6xdz(group):
    groups.add(group)
  VV5uoU = []
  if len(groups) > 0:
   title = "Groups"
   for group in groups:
    VV5uoU.append((group, group))
   VV5uoU.append(("ALL", ""))
   VV5uoU.sort(key=lambda x: x[0].lower())
   VVVVpp = self.VVqfbh
   VViSv2  = ("Select" , boundFunction(self.VV3kBO, srcPath), [])
   widths   = (100  , 0)
   VVYecm  = (LEFT  , LEFT)
   FFuN9x(self, None, title=title, width= 800, header=None, VVUQjT=VV5uoU, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=30, VViSv2=VViSv2, VVVVpp=VVVVpp
     , VVZOs8="#11110022", VVEkOu="#11110022", VVJbor="#11110022", VVsesB="#00444400")
  else:
   txt = FF1mdj(srcPath)
   self.VVYF4C(txt, filterGroup="")
 def VV3kBO(self, srcPath, VVK0Qb, title, txt, colList):
  group = colList[1]
  txt = FF1mdj(srcPath)
  self.VVYF4C(txt, filterGroup=group)
 def VVYF4C(self, txt, filterGroup=""):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = "Group : %s" % (filterGroup or "ALL")
  if lst:
   self.session.open(CCX8Rl, barTheme=CCX8Rl.VVXb36
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VVAl7z, lst, filterGroup)
       , VVx6WR = boundFunction(self.VVM6fX, title, bName))
  else:
   self.VVXOZd("No valid lines found !", title)
 def VVAl7z(self, lst, filterGroup, progBarObj):
  progBarObj.VVssld = []
  progBarObj.VV90iS(len(lst))
  processChanName = CCTBCX()
  num = 0
  for cols in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVbzgZ(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VV6EgT(propLine, "tvg-logo")
   group = self.VV6EgT(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if group and not processChanName.VV6xdz(group) : skip = True
    if chName and not processChanName.VV6xdz(chName): skip = True
    if not skip and progBarObj:
     num += 1
     progBarObj.VVssld.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if progBarObj:
   progBarObj.VVfB1l_forcedUpdate("Loading %d Channels" % len(progBarObj.VVssld))
 def VVM6fX(self, title, bName, VV98Ew, VVssld, threadCounter, threadTotal, threadErr):
  if VVssld:
   VVVVpp = self.VVqfbh
   VViSv2  = ("Select"    , boundFunction(self.VV7jVx, title) , [])
   VV7Iri = (""     , self.VVARc4         , [])
   VVmZVX = ("Download PIcons" , self.VVw4To        , [])
   VVvAyR = ("Options" , boundFunction(self.VVWYED, 1, "m3Ch", "", bName)  , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVYecm  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFuN9x(self, None, title=title, header=header, VVUQjT=VVssld, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=28, VViSv2=VViSv2, VVVVpp=VVVVpp, VV7Iri=VV7Iri, VVmZVX=VVmZVX, VVvAyR=VVvAyR, VVfaqm=True, searchCol=1
     , VVZOs8="#0a00192B", VVEkOu="#0a00192B", VVJbor="#0a00192B", VVsesB="#00000000")
  else:
   self.VVXOZd("No valid lines found !", title)
 def VVw4To(self, VVK0Qb, title, txt, colList):
  self.VV4spf(VVK0Qb, "m3u/m3u8")
 def VVLPsq(self, mode, bName, VVK0Qb, title, txt, colList):
  bNameFile = CCSfuP.VVZnMM_forBouquet(bName)
  num  = 0
  path = VVqs92 + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVqs92 + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   catID = "33"
   rowNum = 0
   isMulti = VVK0Qb.VVFxSi
   for ndx, row in enumerate(VVK0Qb.VVotmZ()):
    chName = row[1].strip()
    url  = row[3].strip()
    chUrl = self.VVL3pu(rowNum, url, chName)
    rowNum += 1
    if not isMulti or VVK0Qb.VVT0y1(ndx):
     f.write("#SERVICE %s\n"  % chUrl)
     f.write("#DESCRIPTION %s\n" % chName)
     totChange += 1
  FF4ns5(os.path.basename(path))
  self.VV7PMG(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVL3pu(self, rowNum, url, chName):
  refCode = self.VV3liB(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFEQKM(url), chName)
  return chUrl
 def VV3liB(self, rowNum, url, chName):
  span = iSearch(r"\/(\d{2,})", url, IGNORECASE)
  if span : stID = span.group(1)
  else : stID = "444"
  catID = "333"
  chNum = str(rowNum + 1)
  refCode = self.VVtzsE(catID, stID, chNum)
  return refCode
 def VV6EgT(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VV7jVx(self, Title, VVK0Qb, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FF9BOI(VVK0Qb, boundFunction(self.VVIhXb, Title, VVK0Qb, colList), title="Checking Server ...")
  else:
   self.VVkSby(VVK0Qb, url, chName)
 def VVIhXb(self, title, VVK0Qb, colList):
  if not CCVmD8.VVlKkZ(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCzEzL.VVpMrE(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVZCgs = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCSfuP.VVRVFF(url, fPath)
     VVZCgs.append((resol, fullUrl))
    if VVZCgs:
     if len(VVZCgs) > 1:
      FF9y9t(self, boundFunction(self.VVZXg5, VVK0Qb, chName), VVZCgs=VVZCgs, title="Resolution", VVmULe=True, VVnHgO=True)
     else:
      self.VVkSby(VVK0Qb, VVZCgs[0][1], chName)
    else:
     self.VVFzkDor("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVYF4C(txt, filterGroup="")
      return
    self.VVkSby(VVK0Qb, url, chName)
   else:
    self.VVXOZd("Cannot process this channel !", title)
  else:
   self.VVXOZd(err, title)
 def VVZXg5(self, VVK0Qb, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVkSby(VVK0Qb, resolUrl, chName)
 def VVkSby(self, VVK0Qb, url, chName):
  FF9BOI(VVK0Qb, boundFunction(self.VV9Ctd, VVK0Qb, url, chName), title="Playing ...")
 def VV9Ctd(self, VVK0Qb, url, chName):
  chUrl = self.VVL3pu(VVK0Qb.VVQNsd(), url, chName)
  FFqYTj(self, chUrl, VVEWCU=False)
  self.session.open(CCkg2V, portalTableParam=(self, VVK0Qb, "m3u/m3u8"))
 def VVjCUY(self, VVK0Qb, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVL3pu(VVK0Qb.VVQNsd(), url, chName)
  return chName, chUrl
 def VVARc4(self, VVK0Qb, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFQvwR(self, fncMode=CCXD20.VVBiry, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVXOZd(self, err, title):
  FF2VP5(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVqfbh(self, VVK0Qb):
  if self.m3uOrM3u8File:
   self.close()
  VVK0Qb.cancel()
 def VVUd3t(self, VVF9lIObj, item=None):
  FF9BOI(VVF9lIObj, boundFunction(self.VVKk6g, VVF9lIObj, item))
 def VVKk6g(self, VVF9lIObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVF9lIObj.VVZCgs):
    path = item[1]
    if fileExists(path):
     enc = CCgkMM.VVGNzE(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = self.VVB3Oi(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCSfuP.VVK2u2(orExportPath=True)
    pListF = "%sPlaylist_%s.txt" % (path, FFNMff())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVF9lIObj.VVZCgs)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFfnpN(self, txt, title=title)
   else:
    FF2VP5(self, "Could not obtain URLs from this file list !", title=title)
 def VVB328(self):
  path = CCSfuP.VVK2u2()
  lines = FFqFDg('find %s %s -iname "*playlist*" | grep -i ".txt"' % (path, FF1d0b(1)))
  if lines:
   lines.sort()
   VVZCgs = []
   for line in lines:
    VVZCgs.append((line, line))
   OKBtnFnc  = self.VVLpD7
   VVjOrH = ("Delete File", self.VV31N9)
   FF9y9t(self, None, title="Select Playlist File", VVZCgs=VVZCgs, width=1200, OKBtnFnc=OKBtnFnc, VVjOrH=VVjOrH)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FF2VP5(self, 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt)
 def VVLpD7(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FF9BOI(menuInstance, boundFunction(self.VV6oa2, menuInstance, path), title="Processing File ...")
 def VV6oa2(self, fileMenuInstance, path):
  enc = CCgkMM.VVGNzE(path, self)
  if enc == -1:
   return
  VV5uoU = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0]
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FF8MLZ(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCSfuP.VVuQis(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VV5uoU:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(filter(None, [item[5], item[0]]))
     num += 1
     VV5uoU.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VV5uoU:
   title = "Playlist File"
   VViSv2  = ("Start"    , boundFunction(self.VVa1gv, title)  , [])
   VVt4yB = ("Home Menu"   , FFAsVx         , [])
   VVmZVX = ("Download M3U File" , self.VV0jjl     , [])
   VVvAyR = ("Edit File"   , boundFunction(self.VVFixO, path) , [])
   VVjzKl = ("Check & Filter"  , boundFunction(self.VVEBlI, fileMenuInstance, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVYecm  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFuN9x(self, None, title=title, header=header, VVUQjT=VV5uoU, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=26, VViSv2=VViSv2, VVt4yB=VVt4yB, VVjzKl=VVjzKl, VVmZVX=VVmZVX, VVvAyR=VVvAyR, VVZOs8="#11001116", VVEkOu="#11001116", VVJbor="#11001116", VVsesB="#00003635", VV1Ceb="#0a333333", VVEtDu="#11331100", VVfaqm=True)
  else:
   FF2VP5(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VV0jjl(self, VVK0Qb, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFS238(self, boundFunction(FF9BOI, VVK0Qb, boundFunction(self.VVhOjQ, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVhOjQ(self, title, url):
  path, err = FFTJ9u(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FF2VP5(self, err, title=errTitle)
  elif fileExists(path):
   txt = FF1mdj(path)
   if '{"user_info":{"auth":0}}' in txt:
    os.system(FF8avg("rm -f '%s'" % path))
    FF2VP5(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    os.system(FF8avg("rm -f '%s'" % path))
    FF2VP5(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCSfuP.VVK2u2(orExportPath=True) + fName
    os.system(FF8avg("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FFiM80(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FF2VP5(self, "Could not download the M3U file!", title=errTitle)
 def VVa1gv(self, Title, VVK0Qb, title, txt, colList):
  url = colList[6]
  FF9BOI(VVK0Qb, boundFunction(self.VV2Rwk, Title, url), title="Checking Server ...")
 def VVFixO(self, path, VVK0Qb, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCLioI(self, path, VVx6WR=boundFunction(self.VVVDae, VVK0Qb), curRowNum=rowNum)
  else    : FFzAsS(self, path)
 def VVVDae(self, VVK0Qb, fileChanged):
  if fileChanged:
   VVK0Qb.cancel()
 def VVyYfC(self, title):
  curChName = self.VVK0Qb.VVPPM9(1)
  FFIPSl(self, boundFunction(self.VVFopz, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVFopz(self, title, name):
  if name:
   lameDbChans = CCze4R.VVEbjS(self, CCze4R.VVpjyl, VVhlvh=False, VVz7qy=False)
   list = []
   if lameDbChans:
    processChanName = CCTBCX()
    name = processChanName.VVmWyd(name)
    ratio = "1"
    for item in lameDbChans:
     if name in item[0].lower():
      list.append((item[0], FFlT3U(item[2]), item[3], ratio))
   if list : self.VVWPQ5(list, title)
   else : FF2VP5(self, "Not found:\n\n%s" % name, title=title)
 def VVK3Gg(self, title):
  curChName = self.VVK0Qb.VVPPM9(1)
  self.session.open(CCX8Rl, barTheme=CCX8Rl.VVXb36
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVebCa
      , VVx6WR = boundFunction(self.VVJtnC, title, curChName))
 def VVebCa(self, progBarObj):
  curChName = self.VVK0Qb.VVPPM9(1)
  lameDbChans = CCze4R.VVEbjS(self, CCze4R.VVObOI, VVhlvh=False, VVz7qy=False)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVssld = []
  progBarObj.VV90iS(len(lameDbChans))
  processChanName = CCTBCX()
  curCh = processChanName.VVmWyd(curChName)
  for refCode in lameDbChans:
   chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
   ratio = CCUKiz.VV0ZEA(chName.lower(), curCh)
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVbzgZ(1, True)
   if progBarObj and ratio > 50:
    progBarObj.VVssld.append((chName, FFlT3U(sat), refCode.replace("_", ":"), str(ratio)))
 def VVJtnC(self, title, curChName, VV98Ew, VVssld, threadCounter, threadTotal, threadErr):
  if VVssld: self.VVWPQ5(VVssld, title)
  elif VV98Ew: FF2VP5(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVWPQ5(self, VV5uoU, title):
  curChName = self.VVK0Qb.VVPPM9(1)
  curRefCode = self.VVK0Qb.VVPPM9(4)
  curUrl  = self.VVK0Qb.VVPPM9(5)
  VV5uoU = sorted(VV5uoU, key=lambda x: (100-int(x[3]), x[0].lower()))
  VViSv2  = ("Share Sat/C/T Ref.", boundFunction(self.VVGeC7, title, curChName, curRefCode, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFuN9x(self, None, title=title, header=header, VVUQjT=VV5uoU, VV5Xly=widths, VVz3yz=26, VViSv2=VViSv2, VVZOs8="#0a00112B", VVEkOu="#0a001126", VVJbor="#0a001126", VVsesB="#00000000")
 def VVGeC7(self, newtitle, curChName, curRefCode, curUrl, VVK0Qb, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFS238(self.VVK0Qb, boundFunction(FF9BOI, self.VVK0Qb, boundFunction(self.VV16Sj, VVK0Qb, data)), ques, title=newtitle, VVvjmj=True)
 def VV16Sj(self, VVK0Qb, data):
  VVK0Qb.cancel()
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVEbyK():
    txt = FF1mdj(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFg8wn()
    newRow = []
    for i in range(6):
     newRow.append(self.VVK0Qb.VVPPM9(i))
    newRow[4] = newRefCode
    done = self.VVK0Qb.VVOJEz(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFzMXn(boundFunction(FFiM80 , self, resTxt, title=title))
  elif resErr: FFzMXn(boundFunction(FF2VP5 , self, resErr, title=title))
 def VVEBlI(self, fileMenuInstance, path, VVK0Qb, title, txt, colList):
  self.session.open(CCX8Rl, barTheme=CCX8Rl.VVBfB6
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VVclMd, VVK0Qb)
      , VVx6WR = boundFunction(self.VVdaBq, fileMenuInstance, path, VVK0Qb))
 def VVclMd(self, VVK0Qb, progBarObj):
  progBarObj.VV90iS(VVK0Qb.VVI5uD())
  progBarObj.VVssld = []
  for row in VVK0Qb.VVotmZ():
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVbzgZ(1, True)
   qUrl = self.VVGEie(self.VV6Mha, row[6])
   txt, err = self.VVkQoO(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVY1fi(item, "auth") == "0":
       progBarObj.VVssld.append(qUrl)
    except:
     pass
 def VVdaBq(self, fileMenuInstance, path, VVK0Qb, VV98Ew, VVssld, threadCounter, threadTotal, threadErr):
  if VV98Ew:
   list = VVssld
   title = "Authorized Servers"
   if list:
    totChk = VVK0Qb.VVI5uD()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFNMff()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVB328()
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFc8cv(str(totAuth), VV09cj)
     txt += "%s\n\n%s"    %  (FFc8cv("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFfnpN(self, txt, title=title)
     VVK0Qb.close()
     fileMenuInstance.close()
    else:
     FFiM80(self, "All URLs are authorized.", title=title)
   else:
    FF2VP5(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVkQoO(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   cont = res.headers.get("Content-Type")
   if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
    return "", "Unexpected server data type ( %s )" % cont
   res = res.read().decode("UTF-8")
   if res:
    if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server !"
    else           : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVuQis(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVhkWC(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVGEie(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVuQis(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VV6Mha   : return "%s"            % url
  elif mode == self.VVWiBs   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVCwmY   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVGITW  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVnSxw  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVueES : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VV5kjU   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVPByC    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVCdMD  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VV9aB1 : return "%s&action=get_live_streams"      % url
  elif mode == self.VVcX68  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVY1fi(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FF2SnK(int(val))
    elif is_base64 : val = FF65Vf(val)
    elif isToHHMMSS : val = FFzrBt(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVCz2y(self, title, path):
  if fileExists(path):
   enc = CCgkMM.VVGNzE(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = self.VVB3Oi(line)
     if qUrl:
      break
   if qUrl : self.VV2Rwk(title, qUrl)
   else : FF2VP5(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FF2VP5(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVbaYP_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVm3Hn()
  if qUrl or "chCode" in iptvRef:
   p = CCzEzL()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVwEfn(iptvRef)
   if valid:
    self.VVbaYP(self, host, mac)
    return
   elif qUrl:
    FF9BOI(self, boundFunction(self.VV2Rwk, title, qUrl), title="Checking Server ...")
    return
  FF2VP5(self, "Error in current channel URL !", title=title)
 def VVm3Hn(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self)
  qUrl = self.VVB3Oi(decodedUrl)
  return qUrl, iptvRef
 def VVB3Oi(self, url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VV2Rwk(self, title, url):
  self.VVvCh2Data = {}
  qUrl = self.VVGEie(self.VV6Mha, url)
  txt, err = self.VVkQoO(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVvCh2Data = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVvCh2Data["username"    ] = self.VVY1fi(item, "username"        )
    self.VVvCh2Data["password"    ] = self.VVY1fi(item, "password"        )
    self.VVvCh2Data["message"    ] = self.VVY1fi(item, "message"        )
    self.VVvCh2Data["auth"     ] = self.VVY1fi(item, "auth"         )
    self.VVvCh2Data["status"    ] = self.VVY1fi(item, "status"        )
    self.VVvCh2Data["exp_date"    ] = self.VVY1fi(item, "exp_date"    , isDate=True )
    self.VVvCh2Data["is_trial"    ] = self.VVY1fi(item, "is_trial"        )
    self.VVvCh2Data["active_cons"   ] = self.VVY1fi(item, "active_cons"       )
    self.VVvCh2Data["created_at"   ] = self.VVY1fi(item, "created_at"   , isDate=True )
    self.VVvCh2Data["max_connections"  ] = self.VVY1fi(item, "max_connections"      )
    self.VVvCh2Data["allowed_output_formats"] = self.VVY1fi(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVvCh2Data[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVvCh2Data["url"    ] = self.VVY1fi(item, "url"        )
    self.VVvCh2Data["port"    ] = self.VVY1fi(item, "port"        )
    self.VVvCh2Data["https_port"  ] = self.VVY1fi(item, "https_port"      )
    self.VVvCh2Data["server_protocol" ] = self.VVY1fi(item, "server_protocol"     )
    self.VVvCh2Data["rtmp_port"   ] = self.VVY1fi(item, "rtmp_port"       )
    self.VVvCh2Data["timezone"   ] = self.VVY1fi(item, "timezone"       )
    self.VVvCh2Data["timestamp_now"  ] = self.VVY1fi(item, "timestamp_now"  , isDate=True )
    self.VVvCh2Data["time_now"   ] = self.VVY1fi(item, "time_now"       )
    VVZCgs  = self.VV9srb(True)
    OKBtnFnc = self.VVvCh2Options
    VVV04i = ("Home Menu", FFAsVx)
    VVcc6k = ("Bookmark Server", boundFunction(CCSfuP.VVNYSX, self, False, self.VVvCh2Data["playListURL"]))
    FF9y9t(self, None, title="IPTV Server Resources", VVZCgs=VVZCgs, OKBtnFnc=OKBtnFnc, VVV04i=VVV04i, VVcc6k=VVcc6k)
   else:
    err = "Could not get data from server !"
  if err:
   FF2VP5(self, err, title=title)
  FFSoSp(self)
 def VVvCh2Options(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FF9BOI(menuInstance, boundFunction(self.VVEMWI, self.VVWiBs  , title=title), title=wTxt)
   elif ref == "vod"   : FF9BOI(menuInstance, boundFunction(self.VVEMWI, self.VVCwmY  , title=title), title=wTxt)
   elif ref == "series"  : FF9BOI(menuInstance, boundFunction(self.VVEMWI, self.VVGITW , title=title), title=wTxt)
   elif ref == "catchup"  : FF9BOI(menuInstance, boundFunction(self.VVEMWI, self.VVnSxw , title=title), title=wTxt)
   elif ref == "accountInfo" : FF9BOI(menuInstance, boundFunction(self.VVXtgR           , title=title), title=wTxt)
 def VVXtgR(self, title):
  rows = []
  for key, val in self.VVvCh2Data.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VVt4yB  = ("Home Menu", FFAsVx, [])
  VVmZVX  = None
  if VVafbh:
   VVmZVX = ("Get JS" , boundFunction(self.VVzmit, "/".join(self.VVvCh2Data["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFuN9x(self, None, title=title, width=1200, header=header, VVUQjT=rows, VV5Xly=widths, VVz3yz=26, VVt4yB=VVt4yB, VVmZVX=VVmZVX, VVZOs8="#0a00292B", VVEkOu="#0a002126", VVJbor="#0a002126", VVsesB="#00000000", searchCol=2)
 def VVDnqA(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CCTBCX()
    if mode in (self.VV5kjU, self.VVcX68):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVY1fi(item, "num"         )
      name     = self.VVY1fi(item, "name"        )
      stream_id    = self.VVY1fi(item, "stream_id"       )
      stream_icon    = self.VVY1fi(item, "stream_icon"       )
      epg_channel_id   = self.VVY1fi(item, "epg_channel_id"      )
      added     = self.VVY1fi(item, "added"    , isDate=True )
      is_adult    = self.VVY1fi(item, "is_adult"       )
      category_id    = self.VVY1fi(item, "category_id"       )
      tv_archive    = self.VVY1fi(item, "tv_archive"       )
      name = processChanName.VV6xdz(name)
      if name:
       if mode == self.VV5kjU or mode == self.VVcX68 and tv_archive == "1":
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVPByC:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVY1fi(item, "num"         )
      name    = self.VVY1fi(item, "name"        )
      stream_id   = self.VVY1fi(item, "stream_id"       )
      stream_icon   = self.VVY1fi(item, "stream_icon"       )
      added    = self.VVY1fi(item, "added"    , isDate=True )
      is_adult   = self.VVY1fi(item, "is_adult"       )
      category_id   = self.VVY1fi(item, "category_id"       )
      container_extension = self.VVY1fi(item, "container_extension"     ) or "mp4"
      name = processChanName.VV6xdz(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVCdMD:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVY1fi(item, "num"        )
      name    = self.VVY1fi(item, "name"       )
      series_id   = self.VVY1fi(item, "series_id"      )
      cover    = self.VVY1fi(item, "cover"       )
      genre    = self.VVY1fi(item, "genre"       )
      episode_run_time = self.VVY1fi(item, "episode_run_time"    )
      category_id   = self.VVY1fi(item, "category_id"      )
      container_extension = self.VVY1fi(item, "container_extension"    ) or "mp4"
      name = processChanName.VV6xdz(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVEMWI(self, mode, title):
  cList, err = self.VVbHhC(mode)
  if cList and mode == self.VVnSxw:
   cList = self.VVWYEu(cList)
  if err:
   FF2VP5(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVZOs8, VVEkOu, VVJbor, VVsesB = self.VVX0mC(mode)
   mName = self.VVCtEi(mode)
   if   mode == self.VVWiBs  : fMode = self.VV5kjU
   elif mode == self.VVCwmY  : fMode = self.VVPByC
   elif mode == self.VVGITW : fMode = self.VVCdMD
   elif mode == self.VVnSxw : fMode = self.VVcX68
   if mode == self.VVnSxw:
    VVvAyR = None
   else:
    VVvAyR = ("Find in %s" % mName , boundFunction(self.VVSKDK, fMode) , [])
   VViSv2   = ("Show List"   , boundFunction(self.VViuaz, mode) , [])
   VVt4yB  = ("Home Menu"   , FFAsVx          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFuN9x(self, None, title=title, width=1200, header=header, VVUQjT=cList, VV5Xly=widths, VVz3yz=30, VVt4yB=VVt4yB, VVvAyR=VVvAyR, VViSv2=VViSv2, VVZOs8=VVZOs8, VVEkOu=VVEkOu, VVJbor=VVJbor, VVsesB=VVsesB)
  else:
   FF2VP5(self, "No list from server !", title=title)
  FFSoSp(self)
 def VVbHhC(self, mode):
  qUrl  = self.VVGEie(mode, self.VVvCh2Data["playListURL"])
  txt, err = self.VVkQoO(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    processChanName = CCTBCX()
    for item in tDict:
     category_id  = self.VVY1fi(item, "category_id"  )
     category_name = self.VVY1fi(item, "category_name" )
     parent_id  = self.VVY1fi(item, "parent_id"  )
     category_name = processChanName.VVA5Nn(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVWYEu(self, catList):
  mode  = self.VVcX68
  qUrl  = self.VVGEie(mode, self.VVvCh2Data["playListURL"])
  txt, err = self.VVkQoO(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVDnqA(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VViuaz(self, mode, VVK0Qb, title, txt, colList):
  title = colList[1]
  FF9BOI(VVK0Qb, boundFunction(self.VVu73F, mode, VVK0Qb, title, txt, colList), title="Downloading ...")
 def VVu73F(self, mode, VVK0Qb, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVCtEi(mode) + " : "+ bName
  if   mode == self.VVWiBs  : mode = self.VV5kjU
  elif mode == self.VVCwmY  : mode = self.VVPByC
  elif mode == self.VVGITW : mode = self.VVCdMD
  elif mode == self.VVnSxw : mode = self.VVcX68
  qUrl  = self.VVGEie(mode, self.VVvCh2Data["playListURL"], catID)
  txt, err = self.VVkQoO(qUrl)
  list  = []
  if not err and mode in (self.VV5kjU, self.VVPByC, self.VVCdMD, self.VVcX68):
   list, err = self.VVDnqA(mode, txt)
  if err:
   FF2VP5(self, err, title=title)
  elif list:
   VVt4yB  = ("Home Menu"   , FFAsVx             , [])
   if mode in (self.VV5kjU, self.VVcX68):
    VVZOs8, VVEkOu, VVJbor, VVsesB = self.VVX0mC(mode)
    VV7Iri = (""     , boundFunction(self.VV1NT7, mode)     , [])
    VVmZVX = ("Download Options" , boundFunction(self.VVEPGa, mode, "", "")  , [])
    VVvAyR = ("Options" , boundFunction(self.VVWYED, 1, "lv", mode, bName)  , [])
    if mode == self.VV5kjU:
     VViSv2 = ("Play"    , boundFunction(self.VV6JtK, mode)     , [])
    elif mode == self.VVcX68:
     VViSv2  = ("Programs", boundFunction(self.VV3Slx_fromIptvTable, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVYecm  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVPByC:
    VVZOs8, VVEkOu, VVJbor, VVsesB = self.VVX0mC(mode)
    VViSv2  = ("Play"    , boundFunction(self.VV6JtK, mode)    , [])
    VV7Iri = (""     , boundFunction(self.VV1NT7, mode)    , [])
    VVmZVX = ("Download Options" , boundFunction(self.VVEPGa, mode, "v", ""), [])
    VVvAyR = ("Options" , boundFunction(self.VVWYED, 1, "v", mode, bName)  , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVYecm  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVCdMD:
    VVZOs8, VVEkOu, VVJbor, VVsesB = self.VVX0mC("series2")
    VViSv2  = ("Show Seasons", boundFunction(self.VV7cUr, mode) , [])
    VV7Iri = ("", boundFunction(self.VVXFZy, mode)  , [])
    VVmZVX = None
    VVvAyR = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVYecm  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFuN9x(self, None, title=title, header=header, VVUQjT=list, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=26, VViSv2=VViSv2, VVt4yB=VVt4yB, VVmZVX=VVmZVX, VVvAyR=VVvAyR, VV7Iri=VV7Iri, VVZOs8=VVZOs8, VVEkOu=VVEkOu, VVJbor=VVJbor, VVsesB=VVsesB, VVfaqm=True, searchCol=1)
  else:
   FF2VP5(self, "No Channels found !", title=title)
  FFSoSp(self)
 def VV3Slx_fromIptvTable(self, mode, bName, VVK0Qb, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVvCh2Data["playListURL"]
  ok_fnc  = boundFunction(self.VV6SmN, hostUrl, chName, catId, streamId)
  FF9BOI(VVK0Qb, boundFunction(CCSfuP.VV3Slx, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VV6SmN(self, chUrl, chName, catId, streamId, VVK0Qb, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCSfuP.VVuQis(chUrl)
   chNum = "333"
   refCode = CCSfuP.VVtzsE(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFqYTj(self, chUrl, VVEWCU=False)
   self.session.open(CCkg2V)
  else:
   FF2VP5(self, "Incorrect Timestamp", pTitle)
 def VV7cUr(self, mode, VVK0Qb, title, txt, colList):
  title = colList[1]
  FF9BOI(VVK0Qb, boundFunction(self.VVjrs1, mode, VVK0Qb, title, txt, colList), title="Downloading ...")
 def VVjrs1(self, mode, VVK0Qb, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVGEie(self.VVueES, self.VVvCh2Data["playListURL"], series_id)
  txt, err = self.VVkQoO(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVY1fi(tDict["info"], "name"   )
      category_id = self.VVY1fi(tDict["info"], "category_id" )
      icon  = self.VVY1fi(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVY1fi(EP, "id"     )
        episode_num   = self.VVY1fi(EP, "episode_num"   )
        epTitle    = self.VVY1fi(EP, "title"     )
        container_extension = self.VVY1fi(EP, "container_extension" )
        seasonNum   = self.VVY1fi(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FF2VP5(self, err, title=title)
  elif list:
   VVt4yB = ("Home Menu"   , FFAsVx             , [])
   VVmZVX = ("Download Options" , boundFunction(self.VVEPGa, mode, "s", title) , [])
   VVvAyR = ("Options" , boundFunction(self.VVWYED, 0, "s", mode, title)  , [])
   VV7Iri = (""     , boundFunction(self.VV1NT7, mode)     , [])
   VViSv2  = ("Play"    , boundFunction(self.VV6JtK, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVYecm  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFuN9x(self, None, title=title, header=header, VVUQjT=list, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=26, VVt4yB=VVt4yB, VVmZVX=VVmZVX, VViSv2=VViSv2, VV7Iri=VV7Iri, VVvAyR=VVvAyR, VVZOs8="#0a00292B", VVEkOu="#0a002126", VVJbor="#0a002126", VVsesB="#00000000")
  else:
   FF2VP5(self, "No Channels found !", title=title)
  FFSoSp(self)
 def VVSKDK(self, mode, VVK0Qb, title, txt, colList):
  VVZCgs = []
  VVZCgs.append(("Keyboard"  , "manualEntry"))
  VVZCgs.append(("From Filter" , "fromFilter"))
  FF9y9t(self, boundFunction(self.VVYg0f, VVK0Qb, mode), title="Input Type", VVZCgs=VVZCgs, width=400)
 def VVYg0f(self, VVK0Qb, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFIPSl(self, boundFunction(self.VVlx3S, VVK0Qb, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CC3CTD(self)
    filterObj.VVxSFA(boundFunction(self.VVlx3S, VVK0Qb, mode))
 def VVlx3S(self, VVK0Qb, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CCTBCX()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVqc4w(words):
     FF2VP5(self, processChanName.VV0ADu(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CCX8Rl, barTheme=CCX8Rl.VVXb36
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VVxzxu, VVK0Qb, mode, title, words, toFind, asPrefix, processChanName)
         , VVx6WR = boundFunction(self.VVQs3z, mode, toFind, title))
   else:
    FF2VP5(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VVxzxu(self, VVK0Qb, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VV90iS(VVK0Qb.VVUBSs())
  progBarObj.VVssld = []
  for row in VVK0Qb.VVotmZ():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVbzgZ(1)
   progBarObj.VVfB1l_fromIptvFind(catName)
   qUrl  = self.VVGEie(mode, self.VVvCh2Data["playListURL"], catID)
   txt, err = self.VVkQoO(qUrl)
   if not err:
    tList, err = self.VVDnqA(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VV6xdz(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VV5kjU:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VVssld.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVPByC:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VVssld.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVCdMD:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VVssld.append((num, name, catID, ID, genre, catName, ext, cover))
 def VVQs3z(self, mode, toFind, title, VV98Ew, VVssld, threadCounter, threadTotal, threadErr):
  if VVssld:
   title = self.VVX8aB(mode, toFind)
   if mode == self.VV5kjU or mode == self.VVPByC:
    if mode == self.VVPByC : typ = "v"
    else          : typ = ""
    bName   = CCSfuP.VVZnMM_forBouquet(toFind)
    VViSv2  = ("Play"     , boundFunction(self.VV6JtK, mode)    , [])
    VVmZVX = ("Download Options" , boundFunction(self.VVEPGa, mode, typ, ""), [])
    VVvAyR = ("Options" , boundFunction(self.VVWYED, 1, "fnd", mode, bName)  , [])
   elif mode == self.VVCdMD:
    VViSv2  = ("Show Seasons"  , boundFunction(self.VV7cUr, mode)    , [])
    VVvAyR = None
    VVmZVX = None
   VV7Iri  = (""     , boundFunction(self.VV1NT7, mode)    , [])
   VVt4yB  = ("Home Menu"   , FFAsVx            , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVYecm  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVK0Qb = FFuN9x(self, None, title=title, header=header, VVUQjT=VVssld, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=26, VViSv2=VViSv2, VVt4yB=VVt4yB, VVmZVX=VVmZVX, VVvAyR=VVvAyR, VV7Iri=VV7Iri, VVZOs8="#0a00292B", VVEkOu="#0a002126", VVJbor="#0a002126", VVsesB="#00000000", VVfaqm=True, searchCol=1)
   if not VV98Ew:
    FFSoSp(VVK0Qb, "Stopped" , 1000)
  else:
   if VV98Ew:
    FF2VP5(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVmg49(self, mode, colList):
  if mode in (self.VV5kjU, self.VVcX68):
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVPByC:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FF3aqm(chName)
  url = self.VVvCh2Data["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVuQis(url)
  refCode = self.VVtzsE(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VV1NT7(self, mode, VVK0Qb, title, txt, colList):
  FF9BOI(VVK0Qb, boundFunction(self.VV2bH5, mode, VVK0Qb, title, txt, colList))
 def VV2bH5(self, mode, VVK0Qb, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVmg49(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFQvwR(self, fncMode=CCXD20.VVvuVR, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVXFZy(self, mode, VVK0Qb, title, txt, colList):
  FF9BOI(VVK0Qb, boundFunction(self.VV1l62, mode, VVK0Qb, title, txt, colList))
 def VV1l62(self, mode, VVK0Qb, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFQvwR(self, fncMode=CCXD20.VV1Bl4, chName=name, text=txt, picUrl=Cover)
 def VVAKGg(self, mode, bName, VVK0Qb, title, txt, colList):
  url = self.VVvCh2Data["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVuQis(url)
  bNameFile = CCSfuP.VVZnMM_forBouquet(bName)
  num  = 0
  path = VVqs92 + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVqs92 + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   isMulti = VVK0Qb.VVFxSi
   for ndx, row in enumerate(VVK0Qb.VVotmZ()):
    chName, chUrl, picUrl, refCode = self.VVmg49(mode, row)
    if not isMulti or VVK0Qb.VVT0y1(ndx):
     f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
     f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
     totChange += 1
  FF4ns5(os.path.basename(path))
  self.VV7PMG(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVEPGa(self, mode, typ, seriesName, VVK0Qb, title, txt, colList):
  VVZCgs = []
  isMulti = VVK0Qb.VVFxSi
  tot  = VVK0Qb.VVahci()
  if isMulti:
   if tot < 1:
    FFSoSp(VVK0Qb, "Select rows first.", 1000)
    return
   else:
    s = "s" if tot > 1 else ""
    name = "%d Selected" % tot
  else:
   s = "s"
   name = "ALL"
  VVZCgs.append(("Download %s PIcon%s" % (name, s), "dnldPicons" ))
  if typ:
   VVZCgs.append(VVXQs5)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVZCgs.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVZCgs.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVZCgs.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCXZq2.VVnprH():
    VVZCgs.append(VVXQs5)
    VVZCgs.append(("Download Manager"      , "dload_stat" ))
  FF9y9t(self, boundFunction(self.VVNhyA_VVKJ8y, VVK0Qb, mode, typ, seriesName, colList), title="Download Options", VVZCgs=VVZCgs)
 def VVNhyA_VVKJ8y(self, VVK0Qb, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VV4spf(VVK0Qb, mode)
   elif item == "dnldSel"  : self.VV5OcT(VVK0Qb, mode, typ, colList, True)
   elif item == "addSel"  : self.VV5OcT(VVK0Qb, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VV8WQv(VVK0Qb, mode, typ, seriesName)
   elif item == "dload_stat" : CCXZq2.VV4PEQ(self)
 def VV5OcT(self, VVK0Qb, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVjc55(mode, typ, colList)
  if startDnld:
   CCXZq2.VVmZum_url(self, decodedUrl)
  else:
   self.VVKJ8y_FFS238(VVK0Qb, "Add to Download list", chName, [decodedUrl], startDnld)
 def VV8WQv(self, VVK0Qb, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVK0Qb.VVotmZ():
   chName, decodedUrl = self.VVjc55(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVKJ8y_FFS238(VVK0Qb, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVKJ8y_FFS238(self, VVK0Qb, title, chName, decodedUrl_list, startDnld):
  FFS238(self, boundFunction(self.VVjGNX, VVK0Qb, decodedUrl_list, startDnld), chName, title=title)
 def VVjGNX(self, VVK0Qb, decodedUrl_list, startDnld):
  added, skipped = CCXZq2.VVIxjHList(decodedUrl_list)
  FFSoSp(VVK0Qb, "Added", 1000)
 def VVjc55(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVmg49(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVwOyE(mode, colList)
   refCode, chUrl = self.VVqq9x(self.VVV50h, self.VV5uIO, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFlxg0(chUrl)
  return chName, decodedUrl
 def VV4spf(self, VVK0Qb, mode):
  if os.system(FF8avg("which ffmpeg")) == 0:
   self.session.open(CCX8Rl, barTheme=CCX8Rl.VVBfB6
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VVRo82, VVK0Qb, mode)
       , VVx6WR = self.VVJn5L)
  else:
   FFS238(self, boundFunction(CCSfuP.VVhq1D, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVJn5L(self, VV98Ew, VVssld, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVssld["proces"], VVssld["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVssld["ok"], VVssld["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVssld["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVssld["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVssld["badURL"]
  txt += "Download Failure\t: %d\n"   % VVssld["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVssld["path"]
  if not VV98Ew  : color = "#11402000"
  elif VVssld["err"]: color = "#11201000"
  else     : color = None
  if VVssld["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVssld["err"], txt)
  title = "PIcons Download Result"
  if not VV98Ew:
   title += "  (cancelled)"
  FFfnpN(self, txt, title=title, VVJbor=color)
 def VVRo82(self, VVK0Qb, mode, progBarObj):
  isMulti = VVK0Qb.VVFxSi
  if isMulti : totRows = VVK0Qb.VVahci()
  else  : totRows = VVK0Qb.VVUBSs()
  progBarObj.VV90iS(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CCUKiz.VVxUr1()
  progBarObj.VVssld = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for rowNum, row in enumerate(VVK0Qb.VVotmZ()):
    if progBarObj.isCancelled:
     break
    if not isMulti or VVK0Qb.VVT0y1(rowNum):
     progBarObj.VVssld["proces"] += 1
     progBarObj.VVbzgZ(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVwOyE(mode, row)
      refCode = CCSfuP.VVtzsE(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VV3liB(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVmg49(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       progBarObj.VVssld["attempt"] += 1
       path, err = FFTJ9u(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        progBarObj.VVssld["ok"] += 1
        if FFtcdQ(path) > 0:
         cmd = ""
         if not mode == CCSfuP.VV5kjU:
          cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
         cmd += FF8avg("mv -f '%s' '%s'" % (path, pPath)) + ";"
         os.system(cmd)
        else:
         progBarObj.VVssld["size0"] += 1
         os.system(FF8avg("rm -f '%s'" % path))
       elif err:
        progBarObj.VVssld["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         progBarObj.VVssld["err"] = err.title()
         break
      else:
       progBarObj.VVssld["exist"] += 1
     else:
      progBarObj.VVssld["badURL"] += 1
  except:
   pass
 @staticmethod
 def VVhq1D(SELF):
  cmd = FFfBk8(VVQ5tW, "ffmpeg")
  if cmd : FFeerf(SELF, cmd, title="Installing FFmpeg")
  else : FFh46b(SELF)
 def VVXFT0(self):
  self.session.open(CCX8Rl, barTheme=CCX8Rl.VVBfB6
      , titlePrefix = ""
      , fncToRun  = self.VVgRTi
      , VVx6WR = self.VVRXmE)
 def VVgRTi(self, progBarObj):
  bName = FFVUtv()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  progBarObj.VVssld = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = FFUuQF()
  if not progBarObj or progBarObj.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   progBarObj.VV90iS(totCh)
   for serv in services:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVbzgZ(1)
    progBarObj.VVfB1l_fromImportEPG(totEpgOK, uChName)
    fullRef  = serv[0]
    if FFKADs(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFlxg0(fullRef)
     span = iSearch(r"(mode=.+end=)", fullRef, IGNORECASE)
     if span:
      m3u_Url = CCzEzL.VV3hlt(fullRef)
      uType, uHost, uUser, uPass, uId, uChName  = CCSfuP.VVhkWC(fullRef)
      uType, uHost, uUser, uPass, uId, uChName1 = CCSfuP.VVhkWC(m3u_Url)
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCSfuP.VVhkWC(m3u_Url)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCSfuP.VVDIEa(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCXD20.VVJ9ho(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
      else:
       pass
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if progBarObj:
     progBarObj.VVssld = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   progBarObj.VVssld = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VVRXmE(self, VV98Ew, VVssld, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVssld
  title = "IPTV EPG Import"
  if err:
   FF2VP5(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFc8cv(str(totNotIptv), VVy89V)
    if totServErr : txt += "Server Errors\t: %s\n" % FFc8cv(str(totServErr) + t1, VVy89V)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFc8cv(str(totInv), VVy89V)
   if not VV98Ew:
    title += "  (stopped)"
   FFfnpN(self, txt, title=title)
 @staticmethod
 def VVDIEa(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCSfuP.VVuQis(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCSfuP.VVkQoO(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCSfuP.VVY1fi(item, "description" , is_base64=True ).replace("\n", " .. ")
    has_archive   = CCSfuP.VVY1fi(item, "has_archive"      )
    lang    = CCSfuP.VVY1fi(item, "lang"        ).upper()
    now_playing   = CCSfuP.VVY1fi(item, "now_playing"      )
    start    = CCSfuP.VVY1fi(item, "start"        )
    start_timestamp  = CCSfuP.VVY1fi(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCSfuP.VVY1fi(item, "start_timestamp"     )
    stop_timestamp  = CCSfuP.VVY1fi(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCSfuP.VVY1fi(item, "stop_timestamp"      )
    tTitle    = CCSfuP.VVY1fi(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVtzsE(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCSfuP.VVx2SM(catID, MAX_4b)
  TSID = CCSfuP.VVx2SM(chNum, MAX_4b)
  ONID = CCSfuP.VVx2SM(chNum, MAX_4b)
  NS  = CCSfuP.VVx2SM(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVx2SM(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVZnMM_forBouquet(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVX0mC(mode):
  if   mode in ("itv"  , CCSfuP.VVWiBs)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCSfuP.VVCwmY)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCSfuP.VVGITW) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCSfuP.VVnSxw) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCSfuP.VVcX68    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 @staticmethod
 def VVK2u2(orExportPath=False):
  path = CFG.iptvHostsPath.getValue()
  if not pathExists(path) or path == VVvRbf:
   if orExportPath : path = CFG.exportedTablesPath.getValue()
   else   : path ="/"
  return FF8MLZ(path)
 @staticmethod
 def VV3Slx(SELF, hostUrl, chName, streamId, ok_fnc):
  title = "Catchup TV Programs"
  pList, err = CCSfuP.VVDIEa(hostUrl, streamId, True)
  if err:
   FF2VP5(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVZOs8, VVEkOu, VVJbor, VVsesB = CCSfuP.VVX0mC("")
   VVt4yB = ("Home Menu" , FFAsVx, [])
   VViSv2  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVYecm  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFuN9x(SELF, None, title="Programs for : " + chName, header=header, VVUQjT=pList, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=24, VViSv2=VViSv2, VVt4yB=VVt4yB, VVZOs8=VVZOs8, VVEkOu=VVEkOu, VVJbor=VVJbor, VVsesB=VVsesB)
  else:
   FF2VP5(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVRVFF(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 @staticmethod
 def VVNYSX(SELF, isPortal, line, VVF9lIObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCSfuP.VVK2u2(orExportPath=True)
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FF2VP5(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFiM80(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FF2VP5(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVWYED(self, nameCol, source, mode, bName, VVK0Qb, title, txt, colList):
  isMulti = VVK0Qb.VVFxSi
  mSel = CCrBxE(self, VVK0Qb, nameCol, addSep=False)
  title = ""
  if isMulti:
   tot = VVK0Qb.VVahci()
   if tot > 0:
    s = "s" if tot > 1 else ""
    title = "Add %d Service%s to Bouquet" % (tot, s)
  else:
   title = "Add ALL to Bouquet"
  if title:
   mSel.VVZCgs.append(VVXQs5)
   mSel.VVZCgs.append((title        , "addToBoquet"))
  FF9y9t(self, boundFunction(self.VVO1Tv, mSel, source, mode, bName, VVK0Qb, title, txt, colList), title="Options", VVZCgs=mSel.VVZCgs)
 def VVO1Tv(self, mSelObj, source, mode, bName, VVK0Qb, title, txt, colList, item):
  if item:
   if   item == "multSelEnab"     : mSelObj.VVK0Qb.VVzlVd(True)
   elif item == "MultSelDisab"     : mSelObj.VVK0Qb.VVzlVd(False)
   elif item == "selectAll"     : mSelObj.VVK0Qb.VVF9hK()
   elif item == "unselectAll"     : mSelObj.VVK0Qb.VVgfYT()
   elif item == "addToBoquet"     :
    if   source == "pEp" : fnc = self.VVkeCL
    elif source == "pCh" : fnc = self.VVkeCL
    elif source == "m3Ch" : fnc = self.VVLPsq
    elif source == "lv"  : fnc = self.VVAKGg
    elif source == "v"  : fnc = self.VVAKGg
    elif source == "s"  : fnc = self.VVAKGg
    elif source == "fnd" : fnc = self.VVAKGg
    else     : return
    FF9BOI(VVK0Qb, boundFunction(fnc, mode, bName, VVK0Qb, title, txt, colList), title="Adding Channels ...")
class CC8CAz(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFZerm(VVj3bT, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVvwBZ  = 0
  self.VVB5vB = 1
  self.VVvcyB  = 2
  VVZCgs = []
  VVZCgs.append(("Find in All Service (from filter)" , "VVUvtj" ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Find in All (Manual Entry)"   , "VVnUqu"    ))
  VVZCgs.append(("Find in TV"       , "VVkSNt"    ))
  VVZCgs.append(("Find in Radio"      , "VV5EVf"   ))
  if self.VVZqUo():
   VVZCgs.append(VVXQs5)
   VVZCgs.append(("Hide Channel: %s" % self.servName , "VVcLdX"   ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Zap History"       , "VViAx1"    ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("IPTV Tools"       , "iptv"      ))
  VVZCgs.append(("PIcons Tools"       , "PIconsTools"     ))
  VVZCgs.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FFeVzc(self, VVZCgs=VVZCgs, title=title)
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FFDd6I(self["myMenu"])
  FFGCoH(self)
  if self.isFindMode:
   self.VVfB8Y(self.VVJIMV())
 def VVh5RL(self):
  global VVTyjD
  VVTyjD = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVnUqu"    : self.VVnUqu()
   elif item == "VVUvtj" : self.VVUvtj()
   elif item == "VVkSNt"    : self.VVkSNt()
   elif item == "VV5EVf"   : self.VV5EVf()
   elif item == "VVcLdX"   : self.VVcLdX()
   elif item == "VViAx1"    : self.VViAx1()
   elif item == "iptv"       : self.session.open(CCSfuP)
   elif item == "PIconsTools"     : self.session.open(CCUKiz)
   elif item == "ChannelsTools"    : self.session.open(CCze4R)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVkSNt(self) : self.VVfB8Y(self.VVvwBZ)
 def VV5EVf(self) : self.VVfB8Y(self.VVB5vB)
 def VVnUqu(self) : self.VVfB8Y(self.VVvcyB)
 def VVfB8Y(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFIPSl(self, boundFunction(self.VVgZOP, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVUvtj(self):
  filterObj = CC3CTD(self)
  filterObj.VVxSFA(self.VVOIF4)
 def VVOIF4(self, item):
  self.VVgZOP(self.VVvcyB, item)
 def VVZqUo(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFKADs(self.refCode)        : return False
  return True
 def VVgZOP(self, mode, VVKSzX):
  FF9BOI(self, boundFunction(self.VVc5XS, mode, VVKSzX), title="Searching ...")
 def VVc5XS(self, mode, VVKSzX):
  if VVKSzX:
   self.findTxt = VVKSzX
   if   mode == self.VVvwBZ  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVB5vB : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVKSzX)
   if len(title) > 55:
    title = title[:55] + ".."
   VV5uoU = self.VVhZ0H(VVKSzX, servTypes)
   if self.isFindMode or mode == self.VVvcyB:
    VV5uoU += self.VV9Yeb(VVKSzX)
   if VV5uoU:
    VV5uoU.sort(key=lambda x: x[0].lower())
    VVVVpp = self.VVVPXE
    VViSv2  = ("Zap"   , self.VViHE3    , [])
    VVmZVX = ("Current Service", self.VVE7c1 , [])
    VVvAyR = ("Options"  , self.VVdRQ3 , [])
    VV7Iri = (""    , self.VVsQIY , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVYecm  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFuN9x(self, None, title=title, header=header, VVUQjT=VV5uoU, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=26, VViSv2=VViSv2, VVVVpp=VVVVpp, VVmZVX=VVmZVX, VVvAyR=VVvAyR, VV7Iri=VV7Iri)
   else:
    self.VVfB8Y(self.VVJIMV())
    FFiM80(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVhZ0H(self, VVKSzX, servTypes):
  VVBJ9x  = eServiceCenter.getInstance()
  VVqSWg   = '%s ORDER BY name' % servTypes
  VVX1nG   = eServiceReference(VVqSWg)
  VVsRL4 = VVBJ9x.list(VVX1nG)
  if VVsRL4: VVUQjT = VVsRL4.getContent("CN", False)
  else     : VVUQjT = None
  VV5uoU = []
  if VVUQjT:
   VV1eve, VVBltM = FF1AA1()
   tp   = CC14a1()
   words, asPrefix = CC3CTD.VVsnwy(VVKSzX)
   colorYellow  = CCdIk5.VV2H87(VVN5SF)
   colorWhite  = CCdIk5.VV2H87(VVodRY)
   for s in VVUQjT:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFWdKi(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VV1eve:
        STYPE = VVBltM[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVMLMx(refCode)
       if not "-S" in syst:
        sat = syst
       VV5uoU.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VV5uoU
 def VV9Yeb(self, VVKSzX):
  VVKSzX = VVKSzX.lower()
  VVpaei = FFEetI()
  VV5uoU = []
  colorYellow  = CCdIk5.VV2H87(VVN5SF)
  colorWhite  = CCdIk5.VV2H87(VVodRY)
  if VVpaei:
   for b in VVpaei:
    VVVnCp  = b[0]
    VVZZTB  = b[1].toString()
    VVyuYG = eServiceReference(VVZZTB)
    VVkVfI = FFfahj(VVyuYG)
    for service in VVkVfI:
     refCode  = service[0]
     if FFKADs(refCode):
      servName = service[1]
      if VVKSzX in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VVKSzX), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VV5uoU.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VV5uoU
 def VVJIMV(self):
  VVTjEU = InfoBar.instance
  if VVTjEU:
   VVd4be = VVTjEU.servicelist
   if VVd4be:
    return VVd4be.mode == 1
  return self.VVvcyB
 def VVVPXE(self, VVK0Qb):
  self.close()
  VVK0Qb.cancel()
 def VViHE3(self, VVK0Qb, title, txt, colList):
  FFqYTj(VVK0Qb, colList[2], VVEWCU=False, checkParentalControl=True)
 def VVE7c1(self, VVK0Qb, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(VVK0Qb)
  if refCode:
   VVK0Qb.VVXwUN(2, FFtv9b(refCode, iptvRef, chName), True)
 def VVdRQ3(self, VVK0Qb, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CCrBxE(self, VVK0Qb, 2)
  mSel.VVGJ1R(servName, refCode)
 def VVsQIY(self, VVK0Qb, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFQvwR(self, fncMode=CCXD20.VVYpC6, refCode=refCode, chName=chName, text=txt)
 def VVcLdX(self):
  FFS238(self, self.VVZwPy, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVZwPy(self):
  ret = FFxJGc(self.refCode, True)
  if ret:
   self.VV0kc0()
   self.close()
  else:
   FFSoSp(self, "Cannot change state" , 1000)
 def VV0kc0(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVSoEm()
  except:
   self.VVmSjH()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFy4b2(self, serviceRef)
 def VV3hLI(self):
  VVTjEU = InfoBar.instance
  if VVTjEU:
   VVd4be = VVTjEU.servicelist
   if VVd4be:
    VVd4be.setMode()
 def VVSoEm(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVTjEU = InfoBar.instance
   if VVTjEU:
    VVd4be = VVTjEU.servicelist
    if VVd4be:
     hList = VVd4be.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVd4be.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVd4be.history  = newList
       VVd4be.history_pos = pos
 def VVmSjH(self):
  VVTjEU = InfoBar.instance
  if VVTjEU:
   VVd4be = VVTjEU.servicelist
   if VVd4be:
    VVd4be.history  = []
    VVd4be.history_pos = 0
 def VViAx1(self):
  VVTjEU = InfoBar.instance
  VV5uoU = []
  if VVTjEU:
   VVd4be = VVTjEU.servicelist
   if VVd4be:
    VV1eve, VVBltM = FF1AA1()
    for chParams in VVd4be.history:
     refCode = chParams[-1].toString()
     chName = FFakZx(refCode)
     isIptv = FFKADs(refCode)
     if isIptv: sat = "-"
     else  : sat = FFWdKi(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VV1eve:
       STYPE = VVBltM[sTypeInt]
     VV5uoU.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VV5uoU:
   VViSv2  = ("Zap"   , self.VVGOOG   , [])
   VVvAyR = ("Clear History" , self.VVRCq3   , [])
   VV7Iri = (""    , self.VVIxqiFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVYecm  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFuN9x(self, None, title=title, header=header, VVUQjT=VV5uoU, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=28, VViSv2=VViSv2, VVvAyR=VVvAyR, VV7Iri=VV7Iri)
  else:
   FFiM80(self, "Not found", title=title)
 def VVGOOG(self, VVK0Qb, title, txt, colList):
  FFqYTj(VVK0Qb, colList[3], VVEWCU=False, checkParentalControl=True)
 def VVRCq3(self, VVK0Qb, title, txt, colList):
  FFS238(self, boundFunction(self.VVOn3h, VVK0Qb), "Clear Zap History ?")
 def VVOn3h(self, VVK0Qb):
  self.VVmSjH()
  VVK0Qb.cancel()
 def VVIxqiFromZapHistory(self, VVK0Qb, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFQvwR(self, fncMode=CCXD20.VV5ZdR, refCode=refCode, chName=chName, text=txt)
class CCUKiz(Screen):
 VVWeYH   = 0
 VV4Z1i  = 1
 VVKqZW  = 2
 VV7WUu  = 3
 VV7uSA  = 4
 VV5orO  = 5
 VVgM2x  = 6
 VVlfAn  = 7
 VV0CxV = 8
 VVdlnz = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFZerm(VVmLkW, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFeVzc(self, self.Title)
  FFFMjq(self["keyRed"] , "OK = Zap")
  FFFMjq(self["keyGreen"] , "Current Service")
  FFFMjq(self["keyYellow"], "Page Options")
  FFFMjq(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCUKiz.VVxUr1()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVUQjT    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVdE1H        ,
   "green"   : self.VVgldG       ,
   "yellow"  : self.VVPPiK        ,
   "blue"   : self.VVSBcc        ,
   "menu"   : self.VVc0QD        ,
   "info"   : self.VVIxqi         ,
   "up"   : self.VVCQ08          ,
   "down"   : self.VVGRpP         ,
   "left"   : self.VVHJ83         ,
   "right"   : self.VVEyK2         ,
   "pageUp"  : boundFunction(self.VVfAS8, True) ,
   "chanUp"  : boundFunction(self.VVfAS8, True) ,
   "pageDown"  : boundFunction(self.VVfAS8, False) ,
   "chanDown"  : boundFunction(self.VVfAS8, False) ,
   "next"   : self.VVW0nv        ,
   "last"   : self.VVqVkQ         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FFCNiP(self)
  FFRpf0(self)
  FF1BAe(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FF9BOI(self, boundFunction(self.VV2k9u, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVc0QD(self):
  if not self.isBusy:
   VVZCgs = []
   VVZCgs.append(("Statistics"           , "VVU8L3"    ))
   VVZCgs.append(VVXQs5)
   VVZCgs.append(("Suggest PIcons for Current Channel"     , "VVugQh"   ))
   VVZCgs.append(("Set to Current Channel (copy file)"     , "VVnra9_file"  ))
   VVZCgs.append(("Set to Current Channel (as SymLink)"     , "VVnra9_link"  ))
   VVZCgs.append(VVXQs5)
   VVZCgs.append(CCUKiz.VVQ6E3())
   VVZCgs.append(VVXQs5)
   if self.filterTitle == "PIcons without Channels":
    c = VVy89V
    VVZCgs.append((FFc8cv("Move Unused PIcons to a Directory", c) , "VVGaze"  ))
    VVZCgs.append((FFc8cv("DELETE Unused PIcons", c)    , "VV4yhG" ))
    VVZCgs.append(VVXQs5)
   VVZCgs.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVPu4e"  ))
   VVZCgs.append(VVXQs5)
   VVZCgs += CCUKiz.VVQJbe()
   VVZCgs.append(VVXQs5)
   VVZCgs.append(("RCU Keys Help"          , "VVaPgp"    ))
   FF9y9t(self, self.VVNhyA, title=self.Title, VVZCgs=VVZCgs)
 def VVNhyA(self, item=None):
  if item is not None:
   if   item == "VVU8L3"     : self.VVU8L3()
   elif item == "VVugQh"    : self.VVugQh()
   elif item == "VVnra9_file"   : self.VVnra9(0)
   elif item == "VVnra9_link"   : self.VVnra9(1)
   elif item == "VVRsh6_file"  : self.VVRsh6(0)
   elif item == "VVRsh6_link"  : self.VVRsh6(1)
   elif item == "VVouFf"   : self.VVouFf()
   elif item == "VVbR4U"  : self.VVbR4U()
   elif item == "VVGaze"    : self.VVGaze()
   elif item == "VV4yhG"   : self.VV4yhG()
   elif item == "VVPu4e"   : self.VVPu4e()
   elif item == "VVdhjd"   : CCUKiz.VVdhjd(self)
   elif item == "VVgFdx"   : CCUKiz.VVgFdx(self)
   elif item == "findPiconBrokenSymLinks"  : CCUKiz.VVr9S7(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCUKiz.VVr9S7(self, False)
   elif item == "VVaPgp"      : self.VVaPgp()
 def VVPPiK(self):
  if not self.isBusy:
   VVZCgs = []
   VVZCgs.append(("Go to First PIcon"  , "VVa7N4"  ))
   VVZCgs.append(("Go to Last PIcon"   , "VV36Kt"  ))
   VVZCgs.append(VVXQs5)
   VVZCgs.append(("Sort by Channel Name"     , "sortByChan" ))
   VVZCgs.append(("Sort by File Name"  , "sortByFile" ))
   VVZCgs.append(VVXQs5)
   VVZCgs.append(("Find from File List .." , "VVM2KK" ))
   FF9y9t(self, self.VVlFYt, title=self.Title, VVZCgs=VVZCgs)
 def VVlFYt(self, item=None):
  if item is not None:
   if   item == "VVa7N4"   : self.VVa7N4()
   elif item == "VV36Kt"   : self.VV36Kt()
   elif item == "sortByChan"  : self.VVu2bS(2)
   elif item == "sortByFile"  : self.VVu2bS(0)
   elif item == "VVM2KK"  : self.VVM2KK()
 def VVaPgp(self):
  FFmggU(self, VVMuIV + "_help_picons", "PIcons Manager (Keys Help)")
 def VVCQ08(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VV36Kt()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVK1XC()
 def VVGRpP(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVa7N4()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVK1XC()
 def VVHJ83(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VV36Kt()
  else:
   self.curCol -= 1
   self.VVK1XC()
 def VVEyK2(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVa7N4()
  else:
   self.curCol += 1
   self.VVK1XC()
 def VVqVkQ(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVK1XC(True)
 def VVW0nv(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVK1XC(True)
 def VVa7N4(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVK1XC(True)
 def VV36Kt(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVK1XC(True)
 def VVM2KK(self):
  VVZCgs = []
  for item in self.VVUQjT:
   VVZCgs.append((item[0], item[0]))
  FF9y9t(self, self.VV35oI, title='PIcons ".png" Files', VVZCgs=VVZCgs, VVmULe=True)
 def VV35oI(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVNV13(ndx)
 def VVdE1H(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVVLCH()
   if refCode:
    FFqYTj(self, refCode)
    self.VVFFks()
    self.VVuchW()
 def VVfAS8(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVFFks()
   self.VVuchW()
  except:
   pass
 def VVgldG(self):
  if self["keyGreen"].getVisible():
   self.VVNV13(self.curChanIndex)
 def VVNV13(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVK1XC(True)
  else:
   FFSoSp(self, "Not found", 1000)
 def VVu2bS(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FF9BOI(self, boundFunction(self.VV2k9u, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVnra9(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVVLCH()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVZCgs = []
     VVZCgs.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVZCgs.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FF9y9t(self, boundFunction(self.VVkJc9, mode, curChF, selPiconF), VVZCgs=VVZCgs, title="Current Channel PIcon (already exists)")
    else:
     self.VVkJc9(mode, curChF, selPiconF, "overwrite")
   else:
    FF2VP5(self, "Cannot change PIcon to itself !", title=title)
  else:
   FF2VP5(self, "Could not read current channel info. !", title=title)
 def VVkJc9(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FF9BOI(self, boundFunction(self.VV2k9u, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVRsh6(self, mode):
  pass
 def VVouFf(self):
  pass
 def VVbR4U(self):
  pass
 def VVGaze(self):
  defDir = FF8MLZ(CCUKiz.VVxUr1() + "picons_backup")
  os.system(FF8avg("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(boundFunction(self.VV2a02, defDir), boundFunction(CC3ls7
         , mode=CC3ls7.VVR0D8, VVvxsk=CCUKiz.VVxUr1()))
 def VV2a02(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCUKiz.VVxUr1():
    FF2VP5(self, "Cannot move to same directory !", title=title)
   else:
    if not FF8MLZ(path) == FF8MLZ(defDir):
     self.VVlq7g(defDir)
    FFS238(self, boundFunction(FF9BOI, self, boundFunction(self.VVpu34, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVUQjT), path), title=title)
  else:
   self.VVlq7g(defDir)
 def VVpu34(self, title, defDir, toPath):
  try:
   from shutil import move as iMove
  except:
   self.VVlq7g(defDir)
   FF2VP5(self, 'Could not load "shutil" module !', title=title)
   return
  toPath = FF8MLZ(toPath)
  pPath = CCUKiz.VVxUr1()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVUQjT:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVUQjT)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFfnpN(self, txt, title=title, VVJbor="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVZjzo("all")
 def VVlq7g(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VV4yhG(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVUQjT)
  s = "s" if tot > 1 else ""
  FFS238(self, boundFunction(FF9BOI, self, boundFunction(self.VVH0xa, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, s), title=title)
 def VVH0xa(self, title):
  pPath = CCUKiz.VVxUr1()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVUQjT:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVUQjT)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFc8cv(str(totErr), VVy89V)
  FFfnpN(self, txt, title=title)
 def VVPu4e(self):
  lines = FFqFDg("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFS238(self, boundFunction(self.VVvNk9, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVvjmj=True)
  else:
   FFiM80(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVvNk9(self, fList):
  os.system(FF8avg("find -L '%s' -type l -delete" % self.pPath))
  FFiM80(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVIxqi(self):
  FF9BOI(self, self.VVk4bD)
 def VVk4bD(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVVLCH()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFc8cv("PIcon Directory:\n", VVO27w)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FFdi5c(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFdi5c(path)
   txt += FFc8cv("PIcon File:\n", VVO27w)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFqFDg(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFc8cv("Found %d SymLink%s to this file from:\n" % (tot, s), VVO27w)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFakZx(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFc8cv(tChName, VV09cj)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFc8cv(line, VVaDOU), tChName)
    txt += "\n"
   if chName:
    txt += FFc8cv("Channel:\n", VVO27w)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFc8cv(chName, VV09cj)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFc8cv("Remarks:\n", VVO27w)
    txt += "  %s\n" % FFc8cv("Unused", VVy89V)
  else:
   txt = "No info found"
  FFQvwR(self, fncMode=CCXD20.VVnJ0G, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVVLCH(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVUQjT[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFlT3U(sat)
  return fName, refCode, chName, sat, inDB
 def VVFFks(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVUQjT):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVuchW(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVVLCH()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFc8cv("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVO27w))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVVLCH()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFc8cv(self.curChanName, VVN5SF)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVU8L3(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VVUQjT:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFgBpG("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFfnpN(self, txt, title=self.Title)
 def VVSBcc(self):
  if not self.isBusy:
   VVZCgs = []
   VVZCgs.append(("All"         , "all"   ))
   VVZCgs.append(VVXQs5)
   VVZCgs.append(("Used by Channels"      , "used"  ))
   VVZCgs.append(("Unused PIcons"      , "unused"  ))
   VVZCgs.append(VVXQs5)
   VVZCgs.append(("PIcons Files"       , "pFiles"  ))
   VVZCgs.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVZCgs.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVZCgs.append(VVXQs5)
   VVZCgs.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVZCgs.append(VVXQs5)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFyBpM(val)
      VVZCgs.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CC3CTD(self)
   filterObj.VVAM7J(VVZCgs, self.nsList, self.VVhuNW)
 def VVhuNW(self, item=None):
  if item is not None:
   self.VVZjzo(item)
 def VVZjzo(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVWeYH   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VV4Z1i   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVKqZW  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VV7WUu  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VV7uSA  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VV5orO  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVgM2x   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVlfAn   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VV0CxV , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VV5orO:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFqFDg("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFSoSp(self, "Not found", 1000)
     return
   elif mode == self.VVdlnz:
    return
   else:
    words, asPrefix = CC3CTD.VVsnwy(words)
   if not words and mode in (self.VVlfAn, self.VV0CxV):
    FFSoSp(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FF9BOI(self, boundFunction(self.VV2k9u, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVugQh(self):
  self.session.open(CCX8Rl, barTheme=CCX8Rl.VVXb36
      , titlePrefix = ""
      , fncToRun  = self.VVemFs
      , VVx6WR = self.VVK7VU)
 def VVemFs(self, progBarObj):
  lameDbChans = CCze4R.VVEbjS(self, CCze4R.VVObOI, VVhlvh=False, VVz7qy=False)
  files = []
  words = []
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVssld = []
  progBarObj.VV90iS(len(lameDbChans))
  if lameDbChans:
   processChanName = CCTBCX()
   curCh = processChanName.VVmWyd(self.curChanName)
   for refCode in lameDbChans:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVbzgZ(1, True)
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCUKiz.VV0ZEA(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCUKiz.VVPvyQ(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       progBarObj.VVssld.append(f.replace(".png", ""))
 def VVK7VU(self, VV98Ew, VVssld, threadCounter, threadTotal, threadErr):
  if VVssld:
   self.timer = eTimer()
   fnc = boundFunction(FF9BOI, self, boundFunction(self.VV2k9u, mode=self.VVdlnz, words=VVssld), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FFSoSp(self, "Not found", 2000)
 def VV2k9u(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVFKEP(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCze4R.VVEbjS(self, CCze4R.VVObOI, VVhlvh=False, VVz7qy=False)
  iptvRefList = self.VVX3TX()
  tList = []
  for fName, fType in CCUKiz.VVIB3P(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVWeYH:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VV4Z1i  and chName         : isAdd = True
   elif mode == self.VVKqZW and not chName        : isAdd = True
   elif mode == self.VV7WUu  and fType == 0        : isAdd = True
   elif mode == self.VV7uSA  and fType == 1        : isAdd = True
   elif mode == self.VV5orO  and fName in words       : isAdd = True
   elif mode == self.VVdlnz and fName in words       : isAdd = True
   elif mode == self.VVgM2x  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVlfAn  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VV0CxV:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVUQjT   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FFSoSp(self)
  else:
   self.isBusy = False
   FFSoSp(self, "Not found", 1000)
   return
  self.VVUQjT.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVFFks()
  self.totalPIcons = len(self.VVUQjT)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVK1XC(True)
 def VVFKEP(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCUKiz.VVIB3P(self.pPath):
    if fName:
     return True
   if isFirstTime : FF2VP5(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFSoSp(self, "Not found", 1000)
  else:
   FF2VP5(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVX3TX(self):
  VV5uoU = {}
  files  = CCSfuP.VVp7Ds(self)
  if files:
   for path in files:
    txt = FF1mdj(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VV5uoU[refCode] = item[1]
  return VV5uoU
 def VVK1XC(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVloHE = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVloHE: self.curPage = VVloHE
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVsFTe()
  if self.curPage == VVloHE:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVuchW()
  filName, refCode, chName, sat, inDB = self.VVVLCH()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVsFTe(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVUQjT[ndx]
   fName = self.VVUQjT[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFc8cv(chName, VV09cj))
    else : lbl.setText("-")
   except:
    lbl.setText(FFc8cv(chName, VVjxiW))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VV0ZEA(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVQ6E3():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVdhjd"   )
 @staticmethod
 def VVQJbe():
  VVZCgs = []
  VVZCgs.append(("Find SymLinks (to PIcon Directory)"   , "VVgFdx"   ))
  VVZCgs.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVZCgs.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVZCgs
 @staticmethod
 def VVdhjd(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(SELF)
  png, path = CCUKiz.VV0MtI(refCode)
  if path : CCUKiz.VVcYn8(SELF, png, path)
  else : FF2VP5(SELF, "No PIcon found for current channel in:\n\n%s" % CCUKiz.VVxUr1())
 @staticmethod
 def VVgFdx(SELF):
  if VVN5SF:
   sed1 = FFR6WL("->", VVN5SF)
   sed2 = FFR6WL("picon", VVy89V)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVjxiW, VVodRY)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFO1e4(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FF1d0b(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVr9S7(SELF, isPIcon):
  sed1 = FFR6WL("->", VVjxiW)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFR6WL("picon", VVy89V)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFO1e4(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FF1d0b(), grep, sed1, sed2))
 @staticmethod
 def VVIB3P(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVxUr1():
  path = CFG.PIconsPath.getValue()
  return FF8MLZ(path)
 @staticmethod
 def VV0MtI(refCode, chName=None):
  if FFKADs(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFlxg0(refCode)
  allPath, fName, refCodeFile, pList = CCUKiz.VVPvyQ(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVcYn8(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFR6WL("%s%s" % (dest, png), VV09cj))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFR6WL(errTxt, VVlcHo))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFGSHZ(SELF, cmd)
 @staticmethod
 def VVPvyQ(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCUKiz.VVxUr1()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FF3aqm(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCtHKN():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVtIUm  = None
  self.VVwVou = ""
  self.VVQo8f  = noService
  self.VV13J4 = 0
  self.VV2aBe  = noService
  self.VVmXa7 = 0
  self.VVipMG  = "-"
  self.VVg575 = 0
  self.VVOgwC  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVKMNu(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVtIUm = frontEndStatus
     self.VV5SRM()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VV5SRM(self):
  if self.VVtIUm:
   val = self.VVtIUm.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVwVou = "%3.02f dB" % (val / 100.0)
   else         : self.VVwVou = ""
   val = self.VVtIUm.get("tuner_signal_quality", 0) * 100 / 65536
   self.VV13J4 = int(val)
   self.VVQo8f  = "%d%%" % val
   val = self.VVtIUm.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVmXa7 = int(val)
   self.VV2aBe  = "%d%%" % val
   val = self.VVtIUm.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVipMG  = "%d" % val
   val = int(val * 100 / 500)
   self.VVg575 = min(500, val)
   val = self.VVtIUm.get("tuner_locked", 0)
   if val == 1 : self.VVOgwC = "Locked"
   else  : self.VVOgwC = "Not locked"
 def VVdjYB(self)   : return self.VVwVou
 def VVdjhm(self)   : return self.VVQo8f
 def VVJcwI(self)  : return self.VV13J4
 def VV4JbO(self)   : return self.VV2aBe
 def VVKyuy(self)  : return self.VVmXa7
 def VVc6e4(self)   : return self.VVipMG
 def VVrC8d(self)  : return self.VVg575
 def VVgNLU(self)   : return self.VVOgwC
 def VVKIFy(self) : return self.serviceName
class CC14a1():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVLC6T(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFQQw0(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVyWtc(self.ORPOS  , mod=1   )
      self.sat2  = self.VVyWtc(self.ORPOS  , mod=2   )
      self.freq  = self.VVyWtc(self.FREQ  , mod=3   )
      self.sr   = self.VVyWtc(self.SR   , mod=4   )
      self.inv  = self.VVyWtc(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVyWtc(self.POL  , self.D_POL )
      self.fec  = self.VVyWtc(self.FEC  , self.D_FEC )
      self.syst  = self.VVyWtc(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVyWtc("modulation" , self.D_MOD )
       self.rolof = self.VVyWtc("rolloff"  , self.D_ROLOF )
       self.pil = self.VVyWtc("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVyWtc("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVyWtc("pls_code"  )
       self.iStId = self.VVyWtc("is_id"   )
       self.t2PlId = self.VVyWtc("t2mi_plp_id" )
       self.t2PId = self.VVyWtc("t2mi_pid"  )
 def VVyWtc(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFyBpM(val)
  elif mod == 2   : return FFR6Ro(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVW4ho(self, refCode):
  txt = ""
  self.VVLC6T(refCode)
  if self.data:
   def VVeeeC(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVeeeC("System"   , self.syst)
    txt += VVeeeC("Satellite"  , self.sat2)
    txt += VVeeeC("Frequency"  , self.freq)
    txt += VVeeeC("Inversion"  , self.inv)
    txt += VVeeeC("Symbol Rate"  , self.sr)
    txt += VVeeeC("Polarization" , self.pol)
    txt += VVeeeC("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVeeeC("Modulation" , self.mod)
     txt += VVeeeC("Roll-Off" , self.rolof)
     txt += VVeeeC("Pilot"  , self.pil)
     txt += VVeeeC("Input Stream", self.iStId)
     txt += VVeeeC("T2MI PLP ID" , self.t2PlId)
     txt += VVeeeC("T2MI PID" , self.t2PId)
     txt += VVeeeC("PLS Mode" , self.plsMod)
     txt += VVeeeC("PLS Code" , self.plsCod)
   else:
    txt += VVeeeC("System"   , self.txMedia)
    txt += VVeeeC("Frequency"  , self.freq)
  return txt, self.namespace
 def VVElYu(self, refCode):
  txt = "Transpoder : ?"
  self.VVLC6T(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VVO27w + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVMLMx(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFQQw0(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVyWtc(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVyWtc(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVyWtc(self.SYST, self.D_SYS_S)
     freq = self.VVyWtc(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVyWtc(self.POL , self.D_POL)
      fec = self.VVyWtc(self.FEC , self.D_FEC)
      sr = self.VVyWtc(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVo8eY(self, refCode):
  self.data = None
  self.VVLC6T(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCLioI():
 def __init__(self, VVeMPk, path, VVx6WR=None, curRowNum=-1):
  self.VVeMPk  = VVeMPk
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVx6WR  = VVx6WR
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FF8avg("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVstl4(curRowNum)
  else:
   FF2VP5(self.VVeMPk, "Error while preparing edit!")
 def VVstl4(self, curRowNum):
  VV5uoU = self.VVmvef()
  VVt4yB = None #("Delete Line" , self.deleteLine  , [])
  VVmZVX = ("Save Changes" , self.VV3MxO   , [])
  VViSv2  = ("Edit Line"  , self.VVhSnz    , [])
  VVjzKl = ("Line Options" , self.VVNViE   , [])
  VVyNAY = (""    , self.VVfQJR , [])
  VVVVpp = self.VVuYYw
  VV08pm  = self.VVUZyC
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVYecm  = (CENTER  , LEFT  )
  VVK0Qb = FFuN9x(self.VVeMPk, None, title=self.Title, header=header, VVUQjT=VV5uoU, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=26, VVt4yB=VVt4yB, VVmZVX=VVmZVX, VViSv2=VViSv2, VVjzKl=VVjzKl, VVVVpp=VVVVpp, VV08pm=VV08pm, VVyNAY=VVyNAY, VVfaqm=True
    , VVZOs8   = "#11001111"
    , VVEkOu   = "#11001111"
    , VVJbor   = "#11001111"
    , VVsesB  = "#05333333"
    , VV1Ceb  = "#00222222"
    , VVEtDu  = "#11331133"
    )
  VVK0Qb.VV7QnH(curRowNum)
 def VVNViE(self, VVK0Qb, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVK0Qb.VVI5uD()
  VVZCgs = []
  VVZCgs.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVZCgs.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVSx3d"  ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVvtte:
   VVZCgs.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(  ("Delete Line"         , "deleteLine"   ))
  FF9y9t(self.VVeMPk, boundFunction(self.VVRWzc, VVK0Qb, lineNum), VVZCgs=VVZCgs, title="Line Options")
 def VVRWzc(self, VVK0Qb, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVr06K("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVK0Qb)
   elif item == "VVSx3d"  : self.VVSx3d(VVK0Qb, lineNum)
   elif item == "copyToClipboard"  : self.VVjSMS(VVK0Qb, lineNum)
   elif item == "pasteFromClipboard" : self.VVR9kj(VVK0Qb, lineNum)
   elif item == "deleteLine"   : self.VVr06K("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVK0Qb)
 def VVUZyC(self, VVK0Qb):
  VVK0Qb.VV19lI()
 def VVfQJR(self, VVK0Qb, title, txt, colList):
  if   self.insertMode == 1: VVK0Qb.VVl1gh()
  elif self.insertMode == 2: VVK0Qb.VVFCMO()
  self.insertMode = 0
 def VVSx3d(self, VVK0Qb, lineNum):
  if lineNum == VVK0Qb.VVI5uD():
   self.insertMode = 1
   self.VVr06K("echo '' >> '%s'" % self.tmpFile, VVK0Qb)
  else:
   self.insertMode = 2
   self.VVr06K("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVK0Qb)
 def VVjSMS(self, VVK0Qb, lineNum):
  global VVvtte
  VVvtte = FFgBpG("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVK0Qb.VV5V7a("Copied to clipboard")
 def VV3MxO(self, VVK0Qb, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FF8avg("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FF8avg("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVK0Qb.VV5V7a("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVK0Qb.VV19lI()
    else:
     FF2VP5(self.VVeMPk, "Cannot save file!")
   else:
    FF2VP5(self.VVeMPk, "Cannot create backup copy of original file!")
 def VVuYYw(self, VVK0Qb):
  if self.fileChanged:
   FFS238(self.VVeMPk, boundFunction(self.VVTcYQ, VVK0Qb), "Cancel changes ?")
  else:
   finalOK = os.system(FF8avg("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVTcYQ(VVK0Qb)
 def VVTcYQ(self, VVK0Qb):
  VVK0Qb.cancel()
  os.system(FF8avg("rm -f '%s'" % self.tmpFile))
  if self.VVx6WR:
   self.VVx6WR(self.fileSaved)
 def VVhSnz(self, VVK0Qb, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVodRY + "ORIGINAL TEXT:\n" + VVaDOU + lineTxt
  FFIPSl(self.VVeMPk, boundFunction(self.VVbgX0, lineNum, VVK0Qb), title="File Line", defaultText=lineTxt, message=message)
 def VVbgX0(self, lineNum, VVK0Qb, VVr5f9):
  if not VVr5f9 is None:
   if VVK0Qb.VVI5uD() <= 1:
    self.VVr06K("echo %s > '%s'" % (VVr5f9, self.tmpFile), VVK0Qb)
   else:
    self.VV5bQD(VVK0Qb, lineNum, VVr5f9)
 def VVR9kj(self, VVK0Qb, lineNum):
  if lineNum == VVK0Qb.VVI5uD() and VVK0Qb.VVI5uD() == 1:
   self.VVr06K("echo %s >> '%s'" % (VVvtte, self.tmpFile), VVK0Qb)
  else:
   self.VV5bQD(VVK0Qb, lineNum, VVvtte)
 def VV5bQD(self, VVK0Qb, lineNum, newTxt):
  VVK0Qb.VV1Sed("Saving ...")
  lines = FF5Wuv(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVK0Qb.VVEiHk()
  VV5uoU = self.VVmvef()
  VVK0Qb.VVOukU(VV5uoU)
 def VVr06K(self, cmd, VVK0Qb):
  tCons = CCIDk1()
  tCons.ePopen(cmd, boundFunction(self.VVNNEU, VVK0Qb))
  self.fileChanged = True
  VVK0Qb.VVEiHk()
 def VVNNEU(self, VVK0Qb, result, retval):
  VV5uoU = self.VVmvef()
  VVK0Qb.VVOukU(VV5uoU)
 def VVmvef(self):
  if fileExists(self.tmpFile):
   lines = FF5Wuv(self.tmpFile)
   VV5uoU = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VV5uoU.append((str(ndx), line.strip()))
   if not VV5uoU:
    VV5uoU.append((str(1), ""))
   return VV5uoU
  else:
   FFzAsS(self.VVeMPk, self.tmpFile)
class CC3CTD():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVZCgs   = []
  self.satList   = []
 def VVxSFA(self, VVx6WR):
  self.VVZCgs = []
  VVZCgs, VVqCuf = self.VVH1Nr(False, True)
  if VVZCgs:
   self.VVZCgs += VVZCgs
   self.VVlp3u(VVx6WR, VVqCuf)
 def VVgllc(self, mode, VVK0Qb, satCol, VVx6WR):
  VVK0Qb.VV1Sed("Loading Filters ...")
  self.VVZCgs = []
  self.VVZCgs.append(("All Services" , "all"))
  if mode == 1:
   self.VVZCgs.append(VVXQs5)
   self.VVZCgs.append(("Parental Control", "parentalControl"))
   self.VVZCgs.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVZCgs.append(VVXQs5)
   self.VVZCgs.append(("Selected Transponder"   , "selectedTP" ))
   self.VVZCgs.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVdUNU(VVK0Qb, satCol)
  VVZCgs, VVqCuf = self.VVH1Nr(True, False)
  if VVZCgs:
   VVZCgs.insert(0, VVXQs5)
   self.VVZCgs += VVZCgs
  VVK0Qb.VVKn4K()
  self.VVlp3u(VVx6WR, VVqCuf)
 def VVAM7J(self, VVZCgs, sats, VVx6WR):
  self.VVZCgs = VVZCgs
  VVZCgs, VVqCuf = self.VVH1Nr(True, False)
  if VVZCgs:
   self.VVZCgs.append(VVXQs5)
   self.VVZCgs += VVZCgs
  self.VVlp3u(VVx6WR, VVqCuf)
 def VVlp3u(self, VVx6WR, VVqCuf):
  VVjOrH = ("Edit Filter", boundFunction(self.VVXXSJ, VVqCuf))
  VVcc6k  = ("Filter Help", boundFunction(self.VVC0Mt, VVqCuf))
  FF9y9t(self.callingSELF, boundFunction(self.VVVV6y, VVx6WR), VVZCgs=self.VVZCgs, title="Select Filter", VVjOrH=VVjOrH, VVcc6k=VVcc6k)
 def VVVV6y(self, VVx6WR, item):
  if item:
   VVx6WR(item)
 def VVXXSJ(self, VVqCuf, VVF9lIObj, sel):
  if fileExists(VVqCuf) : CCLioI(self.callingSELF, VVqCuf, VVx6WR=None)
  else       : FFzAsS(self.callingSELF, VVqCuf)
  VVF9lIObj.cancel()
 def VVC0Mt(self, VVqCuf, VVF9lIObj, sel):
  FFmggU(self.callingSELF, VVMuIV + "_help_service_filter", "Service Filter")
 def VVdUNU(self, VVK0Qb, satColNum):
  if not self.satList:
   satList = VVK0Qb.VVP4oe(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFlT3U(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VVXQs5)
  if self.VVZCgs:
   self.VVZCgs += self.satList
 def VVH1Nr(self, addTag, VVFzkD):
  FFuF9Y()
  fileName  = "ajpanel_services_filter"
  VVqCuf = VVGttK + fileName
  VVZCgs  = []
  if not fileExists(VVqCuf):
   os.system(FF8avg("cp -f '%s' '%s'" % (VVMuIV + fileName, VVqCuf)))
  fileFound = False
  if fileExists(VVqCuf):
   fileFound = True
   lines = FF5Wuv(VVqCuf)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVZCgs.append((line, "__w__" + line))
       else  : VVZCgs.append((line, line))
  if VVFzkD:
   if   not fileFound : FFzAsS(self.callingSELF , VVqCuf)
   elif not VVZCgs : FFKXSw(self.callingSELF , VVqCuf)
  return VVZCgs, VVqCuf
 @staticmethod
 def VVsnwy(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CCrBxE():
 def __init__(self, callingSELF, VVK0Qb, refCodeColNum, addSep=True):
  self.callingSELF = callingSELF
  self.VVK0Qb = VVK0Qb
  self.refCodeColNum = refCodeColNum
  self.VVZCgs = []
  iMulSel = self.VVK0Qb.VVYYAp()
  if iMulSel : self.VVZCgs.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVZCgs.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVK0Qb.VVahci()
  self.VVZCgs.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVZCgs.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVZCgs.append(VVXQs5)
 def VV7agu(self, servName):
  tot = self.VVK0Qb.VVahci()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVZCgs.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVDQk5_multi" ))
  else    : self.VVZCgs.append( ("Add to Bouquet : %s"      % servName , "VVDQk5_one" ))
 def VVGJ1R(self, servName, refCode):
  self.VV7agu(servName)
  self.VVoqUc(servName, refCode)
 def VVINdo(self, servName, refCode, pcState, hidState):
  isMulti = self.VVK0Qb.VVFxSi
  if isMulti:
   refCodeList = self.VVK0Qb.VVsVJQ(3)
   if refCodeList:
    self.VVZCgs.append(("Add Selection to Parental Control"    , "parentalControl_sel_add"  ))
    self.VVZCgs.append(("Remove Selection from Parental Control"   , "parentalControl_sel_remove" ))
    self.VVZCgs.append(VVXQs5)
    self.VVZCgs.append(("Add Selection to Hidden Services"    , "hiddenServices_sel_add"  ))
    self.VVZCgs.append(("Remove Selection from Hidden Services"   , "hiddenServices_sel_remove" ))
   else:
    self.VVZCgs.pop(len(self.VVZCgs) - 1)
  else:
   if pcState == "No" : self.VVZCgs.append(("Add to Parental Control"  , "parentalControl_add"   ))
   else    : self.VVZCgs.append(("Remove from Parental Control" , "parentalControl_remove"  ))
   self.VVZCgs.append(VVXQs5)
   if hidState == "No" : self.VVZCgs.append(("Add to Hidden Services"  , "hiddenServices_add"   ))
   else    : self.VVZCgs.append(("Remove from Hidden Services" , "hiddenServices_remove"  ))
  self.VVZCgs.append(VVXQs5)
  self.VV7agu(servName)
  self.VVoqUc(servName, refCode)
 def VVoqUc(self, servName, refCode):
  FF9y9t(self.callingSELF, boundFunction(self.VVaix4, servName, refCode), title="Options", VVZCgs=self.VVZCgs)
 def VVaix4(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"     : self.VVK0Qb.VVzlVd(True)
   elif item == "MultSelDisab"     : self.VVK0Qb.VVzlVd(False)
   elif item == "selectAll"     : self.VVK0Qb.VVF9hK()
   elif item == "unselectAll"     : self.VVK0Qb.VVgfYT()
   elif item == "parentalControl_add"   : self.callingSELF.VVkUWD(self.VVK0Qb, refCode, True)
   elif item == "parentalControl_remove"  : self.callingSELF.VVkUWD(self.VVK0Qb, refCode, False)
   elif item == "hiddenServices_add"   : self.callingSELF.VVNIge(self.VVK0Qb, refCode, True)
   elif item == "hiddenServices_remove"  : self.callingSELF.VVNIge(self.VVK0Qb, refCode, False)
   elif item == "parentalControl_sel_add"  : self.callingSELF.VVO5U5(self.VVK0Qb, True)
   elif item == "parentalControl_sel_remove" : self.callingSELF.VVO5U5(self.VVK0Qb, False)
   elif item == "hiddenServices_sel_add"  : self.callingSELF.VVhDZa(self.VVK0Qb, True)
   elif item == "hiddenServices_sel_remove" : self.callingSELF.VVhDZa(self.VVK0Qb, False)
   elif item == "VVDQk5_multi"  : self.VVDQk5(refCode, True)
   elif item == "VVDQk5_one"  : self.VVDQk5(refCode, False)
 def VVlkbK(self, VVK0Qb):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  mSel   = CCrBxE(self, VVK0Qb, 3)
  mSel.VVGJ1R(servName, refCode)
 def VVDQk5(self, refCode, isMulti):
  bouquets = FFEetI()
  if bouquets:
   VVZCgs = []
   for item in bouquets:
    VVZCgs.append((item[0], item[1].toString()))
   VVjOrH = ("Create New", boundFunction(self.VVFHtd, refCode, isMulti))
   FF9y9t(self.callingSELF, boundFunction(self.VV2x1A, refCode, isMulti), VVZCgs=VVZCgs, title="Add to Bouquet", VVjOrH=VVjOrH, VVmULe=True, VVnHgO=True)
  else:
   FFS238(self.callingSELF, boundFunction(self.VVA0qa, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VV2x1A(self, refCode, isMulti, bName=None):
  if bName:
   FF9BOI(self.VVK0Qb, boundFunction(self.VVxgfz, refCode, isMulti, bName), title="Adding Channels ...")
 def VVxgfz(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVqInj(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVTjEU = InfoBar.instance
    if VVTjEU:
     VVd4be = VVTjEU.servicelist
     if VVd4be:
      mutableList = VVd4be.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVK0Qb.VVKn4K()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFiM80(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FF2VP5(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVqInj(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVK0Qb.VVsVJQ(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VVFHtd(self, refCode, isMulti, VVF9lIObj, path):
  self.VVA0qa(refCode, isMulti)
 def VVA0qa(self, refCode, isMulti):
  FFIPSl(self.callingSELF, boundFunction(self.VVatfl, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVatfl(self, refCode, isMulti, name):
  if name:
   FF9BOI(self.VVK0Qb, boundFunction(self.VVOMDL, refCode, isMulti, name), title="Adding Channels ...")
 def VVOMDL(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVqInj(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVTjEU = InfoBar.instance
    if VVTjEU:
     VVd4be = VVTjEU.servicelist
     if VVd4be:
      try:
       VVd4be.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVd4be.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVK0Qb.VVKn4K()
   title = "Add to Bouquet"
   if allOK: FFiM80(self.callingSELF, "Added to : %s" % name, title=title)
   else : FF2VP5(self.callingSELF, "Nothing added!", title=title)
class CCR1l9(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFZerm(VVtWog, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFeVzc(self)
  FFFMjq(self["keyRed"]  , "Exit")
  FFFMjq(self["keyGreen"]  , "Save")
  FFFMjq(self["keyYellow"] , "Refresh")
  FFFMjq(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVrSVn  ,
   "green"   : self.VV1KlM ,
   "yellow"  : self.VVa1PL  ,
   "blue"   : self.VVPSD9   ,
   "up"   : self.VVCQ08    ,
   "down"   : self.VVGRpP   ,
   "left"   : self.VVHJ83   ,
   "right"   : self.VVEyK2   ,
   "cancel"  : self.VVrSVn
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVa1PL()
  self.VVfyHt()
  FFRpf0(self)
 def VVrSVn(self) : self.close(True)
 def VV0OIG(self) : self.close(False)
 def VVPSD9(self):
  self.session.openWithCallback(self.VVpu6B, boundFunction(CCtdoU))
 def VVpu6B(self, closeAll):
  if closeAll:
   self.close()
 def VVCQ08(self):
  self.VVI8fM(1)
 def VVGRpP(self):
  self.VVI8fM(-1)
 def VVHJ83(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVfyHt()
 def VVEyK2(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVfyHt()
 def VVI8fM(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VV6PWE(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VV6PWE(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VV6PWE(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVVGl1(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVVGl1(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVfyHt(self):
  for obj in self.list:
   FF1BAe(obj, "#11404040")
  FF1BAe(self.list[self.index], "#11ff8000")
 def VVa1PL(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VV1KlM(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCIDk1()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVBAUm)
 def VVBAUm(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFiM80(self, "Nothing returned from the system!")
  else:
   FFiM80(self, str(result))
class CCtdoU(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFZerm(VVOKrh, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFeVzc(self, addLabel=True)
  FFFMjq(self["keyRed"]  , "Exit")
  FFFMjq(self["keyGreen"]  , "Sync")
  FFFMjq(self["keyYellow"] , "Refresh")
  FFFMjq(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVrSVn   ,
   "green"   : self.VVTyjz  ,
   "yellow"  : self.VVstHL ,
   "blue"   : self.VV3BDV  ,
   "cancel"  : self.VVrSVn
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVfGUJ()
  self.onShow.append(self.start)
 def start(self):
  FFzMXn(self.refresh)
  FFRpf0(self)
 def refresh(self):
  self.VVIFhj()
  self.VVjdEN(False)
 def VVrSVn(self)  : self.close(True)
 def VV3BDV(self) : self.close(False)
 def VVfGUJ(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVIFhj(self):
  self.VVqamM()
  self.VV9JYd()
  self.VVlHmV()
  self.VVn2uA()
 def VVstHL(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVfGUJ()
   self.VVIFhj()
   FFzMXn(self.refresh)
 def VVTyjz(self):
  if len(self["keyGreen"].getText()) > 0:
   FFS238(self, self.VV0rft, "Synchronize with Internet Date/Time ?")
 def VV0rft(self):
  self.VVIFhj()
  FFzMXn(boundFunction(self.VVjdEN, True))
 def VVqamM(self)  : self["keyRed"].show()
 def VVPByn(self)  : self["keyGreen"].show()
 def VVVhR1(self) : self["keyYellow"].show()
 def VVaixm(self)  : self["keyBlue"].show()
 def VV9JYd(self)  : self["keyGreen"].hide()
 def VVlHmV(self) : self["keyYellow"].hide()
 def VVn2uA(self)  : self["keyBlue"].hide()
 def VVjdEN(self, sync):
  localTime = FF5AoR()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVfDzS(server)
   if epoch_time is not None:
    ntpTime = FF2SnK(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCIDk1()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVBAUm, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVVhR1()
  self.VVaixm()
  if ok:
   self.VVPByn()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVBAUm(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVjdEN(False)
  except:
   pass
 def VVfDzS(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFnTgI():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCxU8N(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFZerm(VVkhdk, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFeVzc(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FFzMXn(self.VVCWNn)
 def VVCWNn(self):
  if FFnTgI(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FF1BAe(self["myBody"], color)
   FF1BAe(self["myLabel"], color)
  except:
   pass
class CCTK9b(Screen):
 def __init__(self, session, isFromExternal=False):
  size = CFG.signalSize.getValue()
  screenW = FFcFDM()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFZerm(VVPrvy, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self.isFromExternal  = isFromExternal
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCttZ8(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCttZ8(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCttZ8(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCtHKN()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFeVzc(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVCQ08          ,
   "down"  : self.VVGRpP         ,
   "left"  : self.VVHJ83         ,
   "right"  : self.VVEyK2         ,
   "info"  : self.VVySTB        ,
   "epg"  : self.VVySTB        ,
   "menu"  : self.VVaPgp         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "blue"  : self.VV9UzF       ,
   "last"  : boundFunction(self.VVAXop, -1)  ,
   "next"  : boundFunction(self.VVAXop, 1)  ,
   "pageUp" : boundFunction(self.VVuLOa, True) ,
   "chanUp" : boundFunction(self.VVuLOa, True) ,
   "pageDown" : boundFunction(self.VVuLOa, False) ,
   "chanDown" : boundFunction(self.VVuLOa, False) ,
   "0"   : boundFunction(self.VVAXop, 0)  ,
   "1"   : boundFunction(self.VVe96A, pos=1) ,
   "2"   : boundFunction(self.VVe96A, pos=2) ,
   "3"   : boundFunction(self.VVe96A, pos=3) ,
   "4"   : boundFunction(self.VVe96A, pos=4) ,
   "5"   : boundFunction(self.VVe96A, pos=5) ,
   "6"   : boundFunction(self.VVe96A, pos=6) ,
   "7"   : boundFunction(self.VVe96A, pos=7) ,
   "8"   : boundFunction(self.VVe96A, pos=8) ,
   "9"   : boundFunction(self.VVe96A, pos=9) ,
  }, -1)
  self.onShown.append(self.VV3HNB)
  self.onClose.append(self.onExit)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  self.sliderSNR.VVlDjZ()
  self.sliderAGC.VVlDjZ()
  self.sliderBER.VVlDjZ(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVe96A()
  self.VVfVb2Info()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVfVb2)
  except:
   self.timer.callback.append(self.VVfVb2)
  self.timer.start(500, False)
 def VVfVb2Info(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVKMNu(service)
  serviceName = self.tunerInfo.VVKIFy()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self)
  tp = CC14a1()
  txt = tp.VVElYu(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVfVb2(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVKMNu(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVdjYB())
   self["mySNR"].setText(self.tunerInfo.VVdjhm())
   self["myAGC"].setText(self.tunerInfo.VV4JbO())
   self["myBER"].setText(self.tunerInfo.VVc6e4())
   self.sliderSNR.VVH6ky(self.tunerInfo.VVJcwI())
   self.sliderAGC.VVH6ky(self.tunerInfo.VVKyuy())
   self.sliderBER.VVH6ky(self.tunerInfo.VVrC8d())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVH6ky(0)
   self.sliderAGC.VVH6ky(0)
   self.sliderBER.VVH6ky(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self)
    if state and not state == "Tuned":
     FFSoSp(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVySTB(self):
  FFQvwR(self, fncMode=CCXD20.VVAg4g)
 def VVaPgp(self):
  FFmggU(self, VVMuIV + "_help_signal", "Signal Monitor (Keys)")
 def VV9UzF(self):
  self.session.open(CCkg2V, isFromExternal=self.isFromExternal)
  self.close()
 def VVCQ08(self)  : self.VVe96A(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVGRpP(self) : self.VVe96A(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVHJ83(self) : self.VVe96A(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVEyK2(self) : self.VVe96A(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVe96A(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVAXop(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFir3e(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVuLOa(self, isUp):
  FFSoSp(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVfVb2Info()
  except:
   pass
class CCttZ8(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVlDjZ(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FF1BAe(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVMuIV +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FF1BAe(self.covObj, self.covColor)
   else:
    FF1BAe(self.covObj, "#00006688")
    self.isColormode = True
  self.VVH6ky(0)
 def VVH6ky(self, val):
  val  = FFir3e(val, self.minN, self.maxN)
  width = int(FFe825(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFir3e(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCX8Rl(Screen):
 VVXb36    = 0
 VVBfB6 = 1
 VV29ca = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVx6WR=None, barTheme=VVXb36):
  ratio = self.VVQBsB(barTheme)
  self.skin, self.skinParam = FFZerm(VVSBiu, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVx6WR = VVx6WR
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVssld = None
  self.timer   = eTimer()
  self.myThread  = None
  FFeVzc(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VV3HNB)
  self.onClose.append(self.onExit)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  self.VVemKa()
  self["myProgBarVal"].setText("0%")
  FF1BAe(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVlG0L()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVlG0L)
  except:
   self.timer.callback.append(self.VVlG0L)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def VV90iS(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVfB1l_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVssld), self.counter, self.maxValue, catName)
 def VVfB1l_fromImportEPG(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVfB1l_forcedUpdate(self, title):
  self.newTitle = title
  try:
   self.VVlG0L()
  except:
   pass
 def VVbzgZ(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VVssld), self.counter, self.maxValue)
  except:
   pass
 def VV2dny(self, val):
  try:
   self.counter = val
  except:
   pass
 def VV9kgv(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVgg2g(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFSoSp(self, "Cancelling ...")
  self.isCancelled = True
  self.VVahnt(False)
 def VVahnt(self, isDone):
  if self.VVx6WR:
   self.VVx6WR(isDone, self.VVssld, self.counter, self.maxValue, self.isError)
  self.close()
 def VVlG0L(self):
  val = FFir3e(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFe825(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VVahnt(True)
 def VVemKa(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVBfB6, self.VV29ca):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVQBsB(self, barTheme):
  if   barTheme == self.VVBfB6 : return 0.7
  if   barTheme == self.VV29ca : return 0.5
  else             : return 1
class CCIDk1(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVx6WR = {}
  self.commandRunning = False
  self.VVZhoG  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVx6WR, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVx6WR[name] = VVx6WR
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVZhoG:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVXssC, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVMbN3 , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVXssC, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVMbN3 , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVMbN3(name, retval)
  return True
 def VVXssC(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVMbN3(self, name, retval):
  if not self.VVZhoG:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVx6WR[name]:
   self.VVx6WR[name](self.appResults[name], retval)
  del self.VVx6WR[name]
 def VVanLU(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCqLW6(Screen):
 def __init__(self, session, title="", VVk8hn=None, VVO0fm=False, VVXjBW=False, VVTbRA=False, VV2MS9=False, VVCAUi=False, VVfpaM=False, VVRj8X=VVJRBN, VVDwGo=None, VVRP7U=False, VVz8Vu=None, VVGkGe="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFZerm(VV0am5, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFeVzc(self, addScrollLabel=True)
  if not VVGkGe:
   VVGkGe = "Processing ..."
  self["myLabel"].setText("   %s" % VVGkGe)
  self.VVO0fm   = VVO0fm
  self.VVXjBW   = VVXjBW
  self.VVTbRA   = VVTbRA
  self.VV2MS9  = VV2MS9
  self.VVCAUi = VVCAUi
  self.VVfpaM = VVfpaM
  self.VVRj8X   = VVRj8X
  self.VVDwGo = VVDwGo
  self.VVRP7U  = VVRP7U
  self.VVz8Vu  = VVz8Vu
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCIDk1()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFgas2()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVk8hn, str):
   self.VVk8hn = [VVk8hn]
  else:
   self.VVk8hn = VVk8hn
  if self.VVTbRA or self.VV2MS9:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVG0cy, VVG0cy)
   self.VVk8hn.append("echo -e '\n%s\n' %s" % (restartNote, FFR6WL(restartNote, VVN5SF)))
   if self.VVTbRA:
    self.VVk8hn.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVk8hn.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVCAUi:
   FFSoSp(self, "Processing ...")
  self.onLayoutFinish.append(self.VVufuQ)
  self.onClose.append(self.VVfIig)
 def VVufuQ(self):
  self["myLabel"].VVy70T(textOutFile="console" if self.enableSaveRes else "")
  if self.VVO0fm:
   self["myLabel"].VVjvAc()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VV6pOI()
  else:
   self.VVC41r()
 def VV6pOI(self):
  if FFnTgI():
   self["myLabel"].setText("Processing ...")
   self.VVC41r()
  else:
   self["myLabel"].setText(FFc8cv("\n   No connection to internet!", VVy89V))
 def VVC41r(self):
  allOK = self.container.ePopen(self.VVk8hn[0], self.VVh6aq, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVh6aq("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVfpaM or self.VVTbRA or self.VV2MS9:
    self["myLabel"].setText(FFE5E0("STARTED", VVN5SF) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVz8Vu:
   colorWhite = CCdIk5.VV2H87(VVodRY)
   color  = CCdIk5.VV2H87(self.VVz8Vu[0])
   words  = self.VVz8Vu[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVRj8X=self.VVRj8X)
 def VVh6aq(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVk8hn):
   allOK = self.container.ePopen(self.VVk8hn[self.cmdNum], self.VVh6aq, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVh6aq("Cannot connect to Console!", -1)
  else:
   if self.VVCAUi and FFJEIf(self):
    FFSoSp(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVfpaM:
    self["myLabel"].appendText("\n" + FFE5E0("FINISHED", VVN5SF), self.VVRj8X)
   if self.VVO0fm or self.VVXjBW:
    self["myLabel"].VVjvAc()
   if self.VVDwGo is not None:
    self.VVDwGo()
   if not retval and self.VVRP7U:
    self.VVfIig()
 def VVfIig(self):
  if self.container.VVanLU():
   self.container.killAll()
class CCoVeG(Screen):
 def __init__(self, session, VVk8hn=None, VVCAUi=False):
  self.skin, self.skinParam = FFZerm(VV0am5, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVGttK + "ajpanel_terminal.history"
  self.customCommandsFile = VVGttK + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFgBpG("pwd") or "/home/root"
  self.container   = CCIDk1()
  FFeVzc(self, addScrollLabel=True)
  FFFMjq(self["keyRed"] , "Exit = Stop Command")
  FFFMjq(self["keyGreen"] , "OK = History")
  FFFMjq(self["keyYellow"], "Menu = Custom Cmds")
  FFFMjq(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VV7Xhz ,
   "cancel" : self.VVztRi  ,
   "menu"  : self.VVU8PQ ,
   "last"  : self.VVHGy2  ,
   "next"  : self.VVHGy2  ,
   "1"   : self.VVHGy2  ,
   "2"   : self.VVHGy2  ,
   "3"   : self.VVHGy2  ,
   "4"   : self.VVHGy2  ,
   "5"   : self.VVHGy2  ,
   "6"   : self.VVHGy2  ,
   "7"   : self.VVHGy2  ,
   "8"   : self.VVHGy2  ,
   "9"   : self.VVHGy2  ,
   "0"   : self.VVHGy2
  })
  self.onLayoutFinish.append(self.VV3HNB)
  self.onClose.append(self.VVAqrT)
 def VV3HNB(self):
  self["myLabel"].VVy70T(isResizable=False, textOutFile="terminal")
  FFdouS(self["keyRed"]  , "#00ff8000")
  FF1BAe(self["keyRed"]  , self.skinParam["titleColor"])
  FF1BAe(self["keyGreen"]  , self.skinParam["titleColor"])
  FF1BAe(self["keyYellow"] , self.skinParam["titleColor"])
  FF1BAe(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVTPnV(FFgBpG("date"), 5)
  result = FFgBpG("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVsBSN()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVMuIV + "LinuxCommands.lst"
   newTemplate = VVMuIV + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FF8avg("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FF8avg("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVAqrT(self):
  if self.container.VVanLU():
   self.container.killAll()
   self.VVTPnV("Process killed\n", 4)
   self.VVsBSN()
 def VVztRi(self):
  if self.container.VVanLU():
   self.VVAqrT()
  else:
   FFS238(self, self.close, "Exit ?", VVLTw9=False)
 def VVsBSN(self):
  self.VVTPnV(self.prompt, 1)
  self["keyRed"].hide()
 def VVTPnV(self, txt, mode):
  if   mode == 1 : color = VVN5SF
  elif mode == 2 : color = VVO27w
  elif mode == 3 : color = VVodRY
  elif mode == 4 : color = VVy89V
  elif mode == 5 : color = VVaDOU
  elif mode == 6 : color = VV0hxT
  else   : color = VVodRY
  try:
   self["myLabel"].appendText(FFc8cv(txt, color))
  except:
   pass
 def VVz2BW(self, cmd):
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVTPnV(cmd, 2)
   self.VVTPnV("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVTPnV(ch, 0)
   self.VVTPnV("\nor\n", 4)
   self.VVTPnV("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVsBSN()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFc8cv(parts[0].strip(), VVO27w)
    right = FFc8cv("#" + parts[1].strip(), VV0hxT)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVTPnV(txt, 2)
   lastLine = self.VVFO4c()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVnpJc(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVh6aq, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FF2VP5(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVTPnV(data, 3)
 def VVh6aq(self, data, retval):
  if not retval == 0:
   self.VVTPnV("Exit Code : %d\n" % retval, 4)
  self.VVsBSN()
 def VV7Xhz(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVFO4c() == "":
   self.VVnpJc("cd /tmp")
   self.VVnpJc("ls")
  VV5uoU = []
  if fileExists(self.commandHistoryFile):
   lines  = FF5Wuv(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VV5uoU.append((str(c), line, str(lNum)))
   self.VVxV3V(VV5uoU, title, self.commandHistoryFile, isHistory=True)
  else:
   FFzAsS(self, self.commandHistoryFile, title=title)
 def VVFO4c(self):
  lastLine = FFgBpG("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVnpJc(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVU8PQ(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FF5Wuv(self.customCommandsFile)
   lastLineIsSep = False
   VV5uoU = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VV5uoU.append((str(c), line, str(lNum)))
   self.VVxV3V(VV5uoU, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFzAsS(self, self.customCommandsFile, title=title)
 def VVxV3V(self, VV5uoU, title, filePath=None, isHistory=False):
  if VV5uoU:
   VVsesB = "#05333333"
   if isHistory: VVZOs8 = VVEkOu = VVJbor = "#11000020"
   else  : VVZOs8 = VVEkOu = VVJbor = "#06002020"
   VVvAyR = VVjzKl = None
   VViSv2   = ("Send"   , self.VVZiWi        , [])
   VVmZVX  = ("Modify & Send" , self.VVUEsa        , [])
   if isHistory:
    VVvAyR = ("Clear History" , self.VVoK7j        , [])
   elif filePath:
    VVjzKl = ("Edit File"  , boundFunction(self.VVZ39R, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVYecm     = (CENTER  , LEFT   , CENTER )
   FFuN9x(self, None, title=title, header=header, VVUQjT=VV5uoU, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=26, VViSv2=VViSv2, VVmZVX=VVmZVX, VVvAyR=VVvAyR, VVjzKl=VVjzKl, VVfaqm=True
     , VVZOs8   = VVZOs8
     , VVEkOu   = VVEkOu
     , VVJbor   = VVJbor
     , VVjawb  = "#05ffff00"
     , VVsesB  = VVsesB
    )
  else:
   FFKXSw(self, filePath, title=title)
 def VVZiWi(self, VVK0Qb, title, txt, colList):
  cmd = colList[1].strip()
  VVK0Qb.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVTPnV("\n%s\n" % cmd, 6)
   self.VVTPnV(self.prompt, 1)
  else:
   self.VVz2BW(cmd)
 def VVUEsa(self, VVK0Qb, title, txt, colList):
  cmd = colList[1]
  self.VVdo2W(VVK0Qb, cmd)
 def VVoK7j(self, VVK0Qb, title, txt, colList):
  FFS238(self, boundFunction(self.VVH0Kj, VVK0Qb), "Reset History File ?", title="Command History")
 def VVH0Kj(self, VVK0Qb):
  os.system(FF8avg("echo '' > %s" % self.commandHistoryFile))
  VVK0Qb.cancel()
 def VVZ39R(self, filePath, VVK0Qb, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCLioI(self, filePath, VVx6WR=boundFunction(self.VVymug, VVK0Qb), curRowNum=rowNum)
  else     : FFzAsS(self, filePath)
 def VVymug(self, VVK0Qb, fileChanged):
  if fileChanged:
   VVK0Qb.cancel()
   FFzMXn(self.VVU8PQ)
 def VVHGy2(self):
  self.VVdo2W(None, self.lastCommand)
 def VVdo2W(self, VVK0Qb, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFIPSl(self, boundFunction(self.VV0viX, VVK0Qb), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VV0viX(self, VVK0Qb, cmd):
  if cmd and len(cmd) > 0:
   self.VVz2BW(cmd)
   if VVK0Qb:
    VVK0Qb.cancel()
class CCi6Jy(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVr5f9="", VVYtfU=False, VVh9PT=False, isTrimEnds=True):
  self.skin, self.skinParam = FFZerm(VV3flR, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFeVzc(self, title, addLabel=True)
  FFFMjq(self["keyRed"] , "Up/Down = Change")
  FFFMjq(self["keyGreen"] , "Overwrite")
  FFFMjq(self["keyYellow"], "Pick Key Map")
  FFFMjq(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVh9PT   = VVh9PT
  self.VVYtfU  = VVYtfU
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVr5f9, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVSfeX      ,
   "green"    : self.VV17yN    ,
   "yellow"   : self.VVG73j      ,
   "blue"    : self.VVUv2Z     ,
   "menu"    : self.VVHdNt     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVqr24, True) ,
   "down"    : boundFunction(self.VVqr24, False) ,
   "left"    : self.VViD0F       ,
   "right"    : self.VV5V6f       ,
   "home"    : self.VVwHb0       ,
   "end"    : self.VVs2QX       ,
   "next"    : self.VVaLdQ      ,
   "last"    : self.VVS3kM      ,
   "deleteForward"  : self.VVaLdQ      ,
   "deleteBackward" : self.VVS3kM      ,
   "tab"    : self.VVAJfU       ,
   "toggleOverwrite" : self.VV17yN    ,
   "0"     : self.VV443u     ,
   "1"     : self.VV443u     ,
   "2"     : self.VV443u     ,
   "3"     : self.VV443u     ,
   "4"     : self.VV443u     ,
   "5"     : self.VV443u     ,
   "6"     : self.VV443u     ,
   "7"     : self.VV443u     ,
   "8"     : self.VV443u     ,
   "9"     : self.VV443u
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVq81i()
  self.onShown.append(self.VV3HNB)
  self.onClose.append(self.onExit)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FFCNiP(self)
  self["myLabel"].setText(self.message)
  self.VVlnby()
  if self.VVYtfU : self.VV17yN()
  else    : self.VVEc2K()
  FFRpf0(self)
  FF1BAe(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV7qs9)
  except:
   self.timer.callback.append(self.VV7qs9)
 def onExit(self):
  self.timer.stop()
 def VVSfeX(self):
  self.VVO7md()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVO7md()
  self.close(None)
 def VVHdNt(self):
  VVZCgs = []
  VVZCgs.append(("Home"         , "home"    ))
  VVZCgs.append(("End"         , "end"     ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Clear All"       , "clearAll"   ))
  VVZCgs.append(("Clear To Home"      , "clearToHome"   ))
  VVZCgs.append(("Clear To End"       , "clearToEnd"   ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVvtte:
   VVZCgs.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("To Capital Letters"     , "toCapital"   ))
  VVZCgs.append(("To Small Letters"      , "toSmall"    ))
  FF9y9t(self, self.VVnUau, title="Edit Options", VVZCgs=VVZCgs)
 def VVnUau(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVwHb0()
   elif item == "end"     : self.VVs2QX()
   elif item == "clearAll"    : self.VVF6IJ()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVwHb0()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVvtte
    VVvtte = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVvtte)
    self.VVwHb0()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VV7qs9(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VV17yN(self):
  self["myInput"].toggleOverwrite()
  self.VVEc2K()
 def VVG73j(self):
  self.session.openWithCallback(self.VV5TVz, boundFunction(CCbDA8, mode=self.charMode, VVh9PT=self.VVh9PT))
 def VV5TVz(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVlnby()
 def VVEc2K(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVq81i(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVO7md(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVGorl(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VViD0F(self)     : self.VVTi7L(self["myInput"].left)
 def VV5V6f(self)     : self.VVTi7L(self["myInput"].right)
 def VVaLdQ(self)     : self.VVTi7L(self["myInput"].delete)
 def VVwHb0(self)     : self.VVTi7L(self["myInput"].home)
 def VVs2QX(self)     : self.VVTi7L(self["myInput"].end)
 def VVS3kM(self)    : self.VVTi7L(self["myInput"].deleteBackward)
 def VVAJfU(self)     : self.VVTi7L(self["myInput"].tab)
 def VVF6IJ(self)     : self["myInput"].setText("")
 def VVTi7L(self, fnc):
  fnc()
  self.VV7qs9()
 def VV443u(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVGorl(newChar, overwrite)
   self.VVbiHl(newChar, self["myInput"].mapping[number])
 def VVqr24(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCbDA8.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCbDA8.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVGorl(newChar, True)
   for group in groups:
    if newChar in group:
     self.VVbiHl(newChar, group)
     break
 def VVbiHl(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVodRY:
    group = VVaDOU + group.replace(newChar, FFc8cv(newChar, VVodRY, VVaDOU))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVUv2Z(self):
  if self.VVh9PT : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVlnby()
 def VVlnby(self):
  self["myInput"].mapping = CCbDA8.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCbDA8.RCU_MAP_TITLES[self.charMode])
class CCbDA8(Screen):
 VVba1q  = 0
 VVLFFG  = 1
 VVwZpS  = 2
 VVsq4w  = 3
 VVi3Pf = 4
 VVhgBd = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols , arabic_nums1, arabic1)
       , ( symbols , arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A", u"\u0628")
       , (u"\u0647", u"\u062A")
       )
 def __init__(self, session, mode=VVba1q, VVh9PT=False):
  self.skin, self.skinParam = FFZerm(VV1Occ, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVh9PT  = VVh9PT
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFeVzc(self, title=self.Title)
  FFFMjq(self["keyRed"] ,"OK = Select")
  FFFMjq(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVb0Wg     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVUQ1o, -1) ,
   "next"  : boundFunction(self.VVUQ1o, +1) ,
   "left"  : boundFunction(self.VVUQ1o, -1) ,
   "right"  : boundFunction(self.VVUQ1o, +1) ,
  }, -1)
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FF1BAe(self["keyRed"], "#11222222")
  FF1BAe(self["keyGreen"], "#11222222")
  self.VVI9OO()
 def VVI9OO(self):
  self.VVqZ3R()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVqZ3R(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVUQ1o(self, direction):
  if self.VVh9PT : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVI9OO()
 def VVb0Wg(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCxgSv(Screen):
 def __init__(self, session, title="", message="", VVRj8X=VVJRBN, VVe8u6=False, VVJbor=None, VVz3yz=30, canSaveToFile=""):
  self.skin, self.skinParam = FFZerm(VV0am5, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVz3yz)
  self.session   = session
  FFeVzc(self, title, addScrollLabel=True)
  self.VVRj8X   = VVRj8X
  self.VVe8u6   = VVe8u6
  self.VVJbor   = VVJbor
  self.canSaveToFile  = canSaveToFile
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  self["myLabel"].VVy70T(VVe8u6=self.VVe8u6, textOutFile=self.canSaveToFile)
  self["myLabel"].setText(self.message, self.VVRj8X)
  if self.VVJbor:
   FF1BAe(self["myBody"], self.VVJbor)
   FF1BAe(self["myLabel"], self.VVJbor)
   FFXAgH(self["myLabel"], self.VVJbor)
  self["myLabel"].VVjvAc()
class CCibc7(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFZerm(VVa0bl, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFeVzc(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FFFfOJ(self["errPic"], "err")
class CCwu33(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FFZerm(VVMHcp, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", 20)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FFeVzc(self, " ", addCloser=True)
class CC6e0r():
 def __init__(self, session, txt):
  self.win = session.instantiateDialog(CCwu33, txt)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  self.session = session
  self.timer  = eTimer()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVmOGk)
  except:
   self.timer.callback.append(self.VVmOGk)
  self.timer.start(1500, True)
 def VVmOGk(self):
  self.session.deleteDialog(self.win)
class CCXZq2():
 VVGXH3    = 0
 VV6mO8  = 1
 VVEg0H   = ""
 VVNTNa    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVK0Qb   = None
  self.timer     = eTimer()
  self.VViYby   = 0
  self.VVU10g  = 1
  self.VVJaLT  = 2
  self.VVo5RZ   = 3
  self.VV5fWi   = 4
  VV5uoU = self.VVH8kY()
  if VV5uoU:
   self.VVK0Qb = self.VVb7OK(VV5uoU)
  if not VV5uoU and mode == self.VVGXH3:
   self.VVFzkDor("Download list is empty !")
   self.cancel()
  if mode == self.VV6mO8:
   FF9BOI(self.VVK0Qb or self.SELF, boundFunction(self.VVcMgt, startDnld, decodedUrl), title="Checking Server ...")
  self.VVmVRd(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVmVRd)
  except:
   self.timer.callback.append(self.VVmVRd)
  self.timer.start(1000, False)
 def VVb7OK(self, VV5uoU):
  VV5uoU.sort(key=lambda x: int(x[0]))
  VVVVpp = self.VVtXz8
  VViSv2  = ("Play"  , self.VVcucf , [])
  VV7Iri = (""   , self.VVwEBI  , [])
  VVt4yB = ("Stop"  , self.VVNU7q  , [])
  VVmZVX = ("Resume"  , self.VVlyrT , [])
  VVvAyR = ("Options" , self.VVc0QD  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVYecm  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFuN9x(self.SELF, None, title=self.Title, header=header, VVUQjT=VV5uoU, VVYecm=VVYecm, VV5Xly=widths, VVz3yz=26, VViSv2=VViSv2, VV7Iri=VV7Iri, VVVVpp=VVVVpp, VVt4yB=VVt4yB, VVmZVX=VVmZVX, VVvAyR=VVvAyR, VVEkOu="#11110011", VVZOs8="#11220022", VVJbor="#11110011", VVjawb="#00ffff00", VVsesB="#00223025", VV1Ceb="#0a333333", VVEtDu="#0a400040", VVfaqm=True, searchCol=1)
 def VVH8kY(self):
  lines = CCXZq2.VVTyxu()
  VV5uoU = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",")
     left  = parts[0].strip()
     decodedUrl = ",".join(parts[1:]).strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVrUi7(decodedUrl)
      if fName:
       if   FFM2IP(decodedUrl) : sType = "Movie"
       elif FFOFuI(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VV07Il(decodedUrl, fName)
       if size > -1: sizeTxt = CC3ls7.VV3UfA(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VV5uoU.append((str(len(VV5uoU) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VV5uoU
 def VVQvbB(self):
  VV5uoU = self.VVH8kY()
  if VV5uoU:
   if self.VVK0Qb : self.VVK0Qb.VVOukU(VV5uoU, VVfGUJMsg=False)
   else     : self.VVK0Qb = self.VVb7OK(VV5uoU)
  else:
   self.cancel()
 def VVmVRd(self, force=False):
  if self.VVK0Qb:
   thrList = self.VVBsDK()
   VV5uoU = []
   changed = False
   for ndx, row in enumerate(self.VVK0Qb.VVotmZ()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VViYby
    if m3u8Log:
     percent = self.VVRvfD(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVo5RZ , "%.2f %%" % percent
      else   : flag, progr = self.VV5fWi , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFtcdQ(mPath)
     if curSize > -1:
      fSize = CC3ls7.VV3UfA(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CC3ls7.VV3UfA(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFtcdQ(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVo5RZ , "%.2f %%" % percent
       else   : flag, progr = self.VV5fWi , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CC3ls7.VV3UfA(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrList:
     flag = self.VVJaLT
     if m3u8Log :
      if not speed and not force : flag = self.VVU10g
      elif curSize == -1   : self.VVqm4L(False)
    elif flag == self.VViYby  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VViYby  : color2 = "#f#00555555#"
    elif flag == self.VVU10g : color2 = "#f#0000FFFF#"
    elif flag == self.VVJaLT : color2 = "#f#0000FFFF#"
    elif flag == self.VVo5RZ  : color2 = "#f#00FF8000#"
    elif flag == self.VV5fWi  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVrLqh(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VV5uoU.append(row)
   if changed or force:
    self.VVK0Qb.VVOukU(VV5uoU, VVfGUJMsg=False)
 def VVrLqh(self, flag):
  tDict = self.VVlctS()
  return tDict.get(flag, "?")
 def VVERYk(self, state):
  for flag, txt in self.VVlctS().items():
   if txt == state:
    return flag
  return -1
 def VVlctS(self):
  return { self.VViYby: "Not started", self.VVU10g: "Connecting", self.VVJaLT: "Downloading", self.VVo5RZ: "Stopped", self.VV5fWi: "Completed" }
 def VVL9X2(self, title):
  colList = self.VVK0Qb.VV8yVS()
  path = colList[6]
  url  = colList[8]
  if self.VVmhf4() : self.VVFzkDor("Cannot delete !\n\nFile is downloading.")
  else      : FFS238(self.SELF, boundFunction(self.VVehIk, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVehIk(self, path, url):
  m3u8Log = self.VVK0Qb.VV8yVS()[12].strip()
  if m3u8Log : os.system(FF8avg("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FF8avg("rm -r '%s'" % path))
  self.VVRCrQ(False)
  self.VVQvbB()
 def VVRCrQ(self, VVFzkD=True):
  if self.VVmhf4():
   FFSoSp(self.VVK0Qb, self.VVrLqh(self.VVJaLT), 500)
  else:
   colList  = self.VVK0Qb.VV8yVS()
   state  = colList[4].strip()
   decodedUrl = colList[9].strip()
   if self.VVERYk(state) in (self.VViYby, self.VV5fWi, self.VVo5RZ):
    lines = CCXZq2.VVTyxu()
    newLines = []
    found = False
    for line in lines:
     if CCXZq2.VVIzZ2(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVE8zX(newLines)
     self.VVQvbB()
     FFSoSp(self.VVK0Qb, "Removed.", 1000)
    else:
     FFSoSp(self.VVK0Qb, "Not found.", 1000)
   elif VVFzkD:
    self.VVFzkDor("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVCJxB(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFS238(self.SELF, boundFunction(self.VVIW9b, flag), ques, title=title)
 def VVIW9b(self, flag):
  list = []
  for ndx, row in enumerate(self.VVK0Qb.VVotmZ()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVERYk(state)
   if   flag == flagVal == self.VV5fWi: list.append(decodedUrl)
   elif flag == flagVal == self.VViYby : list.append(decodedUrl)
  lines = CCXZq2.VVTyxu()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVE8zX(newLines)
   self.VVQvbB()
   FFSoSp(self.VVK0Qb, "%d removed." % totRem, 1000)
  else:
   FFSoSp(self.VVK0Qb, "Not found.", 1000)
 def VVfsbR(self):
  colList  = self.VVK0Qb.VV8yVS()
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFSoSp(self.VVK0Qb, "Poster exists", 1500)
  else    : FF9BOI(self.VVK0Qb, boundFunction(self.VVBK9Q, decodedUrl, path, png), title="Checking Server ...")
 def VVBK9Q(self, decodedUrl, path, png):
  err = self.VVRQXy(decodedUrl, path, png)
  if err:
   FF2VP5(self.SELF, err, title="Poster Download")
 def VVRQXy(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCzEzL.VVuhBD(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCSfuP.VVhkWC(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCSfuP.VVkQoO(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCSfuP.VVY1fi(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFTJ9u(pUrl, "ajpanel_tmp%s", timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   os.system(FF8avg("mv -f '%s' '%s'" % (tPath, png)))
   CCtLih.VVIHWr(self.SELF, VVZ4xB=png, showGrnMsg="Downloaded")
   return ""
 def VVwEBI(self, VVK0Qb, title, txt, colList):
  def VVYMjy(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVeeeC(key, val) : return "\n%s:\n%s\n" % (FFc8cv(key, COLOR_CONS_BRIGHT_YELLOW), val.strip())
  heads  = self.VVK0Qb.VVklrU()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVYMjy(heads[i]  , CC3ls7.VV3UfA(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVYMjy("Downloaded" , CC3ls7.VV3UfA(int(curSize), mode=0))
   else:
    txt += VVYMjy(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVeeeC(heads[i], colList[i])
  FFfnpN(self.SELF, txt, title=title)
 def VVcucf(self, VVK0Qb, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CC3ls7.VV2a6o(self.SELF, path)
  else    : FFSoSp(self.VVK0Qb, "File not found", 1000)
 def VVtXz8(self, VVK0Qb):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVK0Qb:
   self.VVK0Qb.cancel()
  del self
 def VVc0QD(self, VVK0Qb, title, txt, colList):
  decodedUrl = colList[9].strip()
  if CFG.downloadAutoResume.getValue(): resumeTxt = "Disable"
  else        : resumeTxt = "Enable"
  VVZCgs = []
  VVZCgs.append(("Remove current row"      , "VVRCrQ"  ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(('Remove all "Completed"'     , "remFinished"    ))
  VVZCgs.append(('Remove all "Not started"'     , "remPending"    ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Delete the file (and remove from list)" , "VVL9X2" ))
  if FFM2IP(decodedUrl):
   VVZCgs.append(VVXQs5)
   VVZCgs.append(("Download Movie Poster (from server)" , "VVfsbR"   ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append((resumeTxt + " Auto Resume"     , "VVCj6v"  ))
  FF9y9t(self.SELF, self.VVWsq1, VVZCgs=VVZCgs, title=self.Title, VVmULe=True, VVnHgO=True)
 def VVWsq1(self, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVRCrQ"  : self.VVRCrQ()
   elif ref == "remFinished"   : self.VVCJxB(self.VV5fWi, txt)
   elif ref == "remPending"   : self.VVCJxB(self.VViYby, txt)
   elif ref == "VVL9X2" : self.VVL9X2(txt)
   elif ref == "VVfsbR"  : self.VVfsbR()
   elif ref == "VVCj6v"  : self.VVCj6v()
 def VVcMgt(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCzEzL.VVuhBD(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVFzkDor("Could not get download link !\n\nTry again later.")
     return
  for line in CCXZq2.VVTyxu():
   if CCXZq2.VVIzZ2(decodedUrl, line):
    self.VVDAd5(decodedUrl)
    FFzMXn(boundFunction(FFSoSp, self.VVK0Qb, "Already listed !", 2000))
    break
  else:
   params = self.VVZKRH(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVFzkDor(params[0])
   elif len(params) == 2:
    FFS238(self.SELF, boundFunction(self.VVhTdf, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CC3ls7.VV3UfA(fSize)
    FFS238(self.SELF, boundFunction(self.VVGnVE, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVGnVE(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCXZq2.VVwB31(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVQvbB()
  if self.VVK0Qb:
   self.VVK0Qb.VVFCMO()
  if startDnld:
   threadName = self.VVNTNa + decodedUrl
   self.VVVads(threadName, url, decodedUrl, path, resp)
 def VVDAd5(self, decodedUrl):
  for ndx, row in enumerate(self.VVK0Qb.VVotmZ()):
   decodedUrl2 = row[9].strip()
   if decodedUrl == decodedUrl2 and self.VVK0Qb:
    self.VVK0Qb.VVXXtO(ndx)
    break
 def VVZKRH(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVrUi7(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VV07Il(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCzEzL.VVuhBD(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCzEzL.VVo2tKHeader()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCXZq2.VV3G9F(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCXZq2.VVtDtU(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVhTdf(self, resp, decodedUrl):
  if not os.system(FF8avg("which ffmpeg")) == 0:
   FFS238(self.SELF, boundFunction(CCSfuP.VVhq1D, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVrUi7(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVYd3h(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFS238(self.SELF, boundFunction(self.VVSRbU, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVSRbU(rTxt, rUrl)
  else:
   self.VVFzkDor("Cannot process m3u8 file !")
 def VVYd3h(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVZCgs = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCSfuP.VVRVFF(rUrl, fPath)
   VVZCgs.append((resol, fullUrl))
  if VVZCgs:
   FF9y9t(self.SELF, self.VVrSj1, VVZCgs=VVZCgs, title="Resolution", VVmULe=True, VVnHgO=True)
  else:
   self.VVFzkDor("Cannot get Resolutions list from server !")
 def VVrSj1(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFS238(self.SELF, boundFunction(FFzMXn, boundFunction(self.VVbXlO, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFzMXn(boundFunction(self.VVbXlO, resolUrl))
 def VVbXlO(self, resolUrl):
  txt, err = CCzEzL.VVpMrE(resolUrl)
  if err : self.VVFzkDor(err)
  else : self.VVSRbU(txt, resolUrl)
 def VV0PBN(self, logF, decodedUrl):
  found = False
  lines = CCXZq2.VVTyxu()
  with open(CCXZq2.VVwB31(), "w") as f:
   for line in lines:
    if CCXZq2.VVIzZ2(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCXZq2.VVwB31(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVQvbB()
  if self.VVK0Qb:
   self.VVK0Qb.VVFCMO()
 def VVSRbU(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCSfuP.VVRVFF(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVFzkDor("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VV0PBN(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FF8avg("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = self.VVNTNa + decodedUrl
  myThread = iThread(name=threadName, target=boundFunction(os.system, cmd))
  myThread.start()
 def VVRvfD(self, dnldLog):
  if fileExists(dnldLog):
   dur = self.VVvMKb(dnldLog)
   if dur > -1:
    tim = self.VVyffA(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 def VVvMKb(self, dnldLog):
  lines = FFqFDg("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVyffA(self, dnldLog):
  lines = FFqFDg("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VV07Il(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFOFuI(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FF8avg("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVVads(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVK0Qb.VV8yVS()[7].strip())
  myThread = iThread(name=threadName, target=boundFunction(self.VVvIN0, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVvIN0(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if CCXZq2.VVEg0H == path:
       break
     else:
      break
  except:
   return
  if CCXZq2.VVEg0H:
   CCXZq2.VVEg0H = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFtcdQ(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVZKRH(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVvIN0(url, decodedUrl, path, resp, totFileSize, True)
 def VVNU7q(self, VVK0Qb, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVOolp() : FFSoSp(self.VVK0Qb, self.VVrLqh(self.VV5fWi), 500)
  elif not self.VVmhf4() : FFSoSp(self.VVK0Qb, self.VVrLqh(self.VVo5RZ), 500)
  elif m3u8Log      : FFS238(self.SELF, self.VVqm4L, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVBsDK():
    CCXZq2.VVEg0H = colList[6]
    FFSoSp(self.VVK0Qb, "Stopping ...", 1000)
   else:
    FFSoSp(self.VVK0Qb, "Stopped", 500)
 def VVqm4L(self, withMsg=True):
  if withMsg:
   FFSoSp(self.VVK0Qb, "Stopping ...", 1000)
  os.system(FF8avg("killall -INT ffmpeg"))
 def VVCj6v(self):
  CFG.downloadAutoResume.setValue(not CFG.downloadAutoResume.getValue())
  CFG.downloadAutoResume.save()
  configfile.save()
 def VVlyrT(self, *args):
  if   self.VVOolp() : FFSoSp(self.VVK0Qb, self.VVrLqh(self.VV5fWi) , 500)
  elif self.VVmhf4() : FFSoSp(self.VVK0Qb, self.VVrLqh(self.VVJaLT), 500)
  else:
   resume = False
   m3u8Log = self.VVK0Qb.VV8yVS()[12].strip()
   if m3u8Log:
    if fileExists(m3u8Log) : FFS238(self.SELF, boundFunction(self.VVYN4L, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVs97q():
    resume = True
   if resume: FF9BOI(self.VVK0Qb, boundFunction(self.VVMuH7), title="Checking Server ...")
   else  : FFSoSp(self.VVK0Qb, "Cannot resume !", 500)
 def VVYN4L(self, m3u8Log):
  os.system(FF8avg("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FF9BOI(self.VVK0Qb, boundFunction(self.VVMuH7), title="Checking Server ...")
 def VVMuH7(self):
  colList  = self.VVK0Qb.VV8yVS()
  path  = colList[6].strip()
  size  = colList[7].strip()
  decodedUrl = colList[9].strip()
  if "j.php" in decodedUrl:
   url = CCzEzL.VVuhBD(decodedUrl)
   if url:
    decodedUrl = self.VVfw9F(decodedUrl, url)
   else:
    self.VVFzkDor("Could not get download link !\n\nTry again later.")
    return
  curSize = FFtcdQ(path)
  params = self.VVZKRH(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVFzkDor(params[0])
   return
  elif len(params) == 2:
   self.VVhTdf(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVfw9F(decodedUrl, url, fSize)
  threadName = self.VVNTNa + decodedUrl
  if resumable: self.VVVads(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVFzkDor("Cannot resume from server !")
 def VVrUi7(self, decodedUrl):
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(http:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   x = decodedUrl.find("&mode")
   if x > -1: url = decodedUrl[:x]
   fName = ".mp4"
   x = decodedUrl.find("&end=")
   if x > -1: chName = decodedUrl[x+5:]
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + ".mp4"
     fixName = False
     ok  = True
   if not ok and FFyuoc(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + ".mp4"
     fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    fName =  mix.split(":")[0]
    chName = ":".join(mix.split(":")[1:])
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVFzkDor(self, txt):
  FF2VP5(self.SELF, txt, title=self.Title)
 def VVBsDK(self):
  thrList = []
  for thr in iEnumerate():
   if self.VVNTNa in thr.name:
    thrList.append(thr.name.replace(self.VVNTNa, ""))
  return thrList
 def VVmhf4(self):
  decodedUrl = self.VVK0Qb.VV8yVS()[9].strip()
  return decodedUrl in self.VVBsDK()
 def VVOolp(self):
  colList = self.VVK0Qb.VV8yVS()
  path = colList[6].strip()
  size = colList[7].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFtcdQ(path)) == size
 def VVs97q(self):
  colList = self.VVK0Qb.VV8yVS()
  path = colList[6].strip()
  size = int(colList[7].strip())
  curSize = FFtcdQ(path)
  if curSize > -1:
   size -= curSize
  err = CCXZq2.VVtDtU(size)
  if err:
   FF2VP5(self.SELF, err, title=self.Title)
   return False
  return True
 def VVE8zX(self, list):
  with open(CCXZq2.VVwB31(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVfw9F(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCXZq2.VVTyxu()
  url = decodedUrl
  with open(CCXZq2.VVwB31(), "w") as f:
   for line in lines:
    if CCXZq2.VVIzZ2(decodedUrl, line):
     parts = line.split(",")
     oldUrl = ",".join(parts[1:]).strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVQvbB()
  return url
 @staticmethod
 def VVTyxu():
  list = []
  if fileExists(CCXZq2.VVwB31()):
   for line in FF5Wuv(CCXZq2.VVwB31()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVIzZ2(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVtDtU(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CC3ls7.VVjHPj(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CC3ls7.VV3UfA(size), CC3ls7.VV3UfA(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VV73Yi(SELF):
  tot = CCXZq2.VV28ry()
  if tot:
   FF2VP5(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VV28ry():
  c = 0
  for thread in iEnumerate():
   if thread.name.startswith(CCXZq2.VVNTNa):
    c += 1
  return c
 @staticmethod
 def VVnprH():
  return len(CCXZq2.VVTyxu()) == 0
 @staticmethod
 def VVLw24():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVntBL():
  mPoints = CCXZq2.VVLw24()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FF8avg("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVwB31():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VV4PEQ(SELF):
  CCXZq2.VVQYzF(SELF, CCXZq2.VVGXH3)
 @staticmethod
 def VVmZum_cur(SELF):
  CCXZq2.VVQYzF(SELF, CCXZq2.VV6mO8, startDnld=True)
 @staticmethod
 def VVmZum_url(SELF, url):
  CCXZq2.VVQYzF(SELF, CCXZq2.VV6mO8, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVIxjHCurrent(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(SELF)
  added, skipped = CCXZq2.VVIxjHList([decodedUrl])
  FFSoSp(SELF, "Added", 1000)
 @staticmethod
 def VVIxjHList(list):
  added = skipped = 0
  for line in CCXZq2.VVTyxu():
   for ndx, url in enumerate(list):
    if url and CCXZq2.VVIzZ2(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCXZq2.VVwB31(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVQYzF(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCVmD8.VVlKkZ(SELF):
   return
  if mode == CCXZq2.VVGXH3 and CCXZq2.VVnprH():
   FF2VP5(SELF, "Download list is empty !", title=title)
  else:
   inst = CCXZq2(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VV3G9F(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCkg2V(Screen, CCDxGJ):
 VVxiX0 = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False, enableDownloadMenu=True):
  self.skin, self.skinParam = FFZerm(VVCR3g, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCDxGJ.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  self.SubtWin    = None
  FFeVzc(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VV4tr4())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVh5RL         ,
   "info"  : self.VVySTB        ,
   "epg"  : self.VVySTB        ,
   "menu"  : self.VVcqmS       ,
   "cancel" : self.cancel         ,
   "blue"  : self.VVnza5        ,
   "green"  : self.VVWpde    ,
   "yellow" : self.VV36Lv   ,
   "left"  : boundFunction(self.VVl928, -1)   ,
   "right"  : boundFunction(self.VVl928,  1)   ,
   "play"  : self.VV2I9g        ,
   "pause"  : self.VV2I9g        ,
   "playPause" : self.VV2I9g        ,
   "stop"  : self.VV2I9g        ,
   "rewind" : self.VVvcm7        ,
   "forward" : self.VVOI5m        ,
   "rewindDm" : self.VVvcm7        ,
   "forwardDm" : self.VVOI5m        ,
   "last"  : self.VVXJfL        ,
   "next"  : self.VVLUBs        ,
   "pageUp" : boundFunction(self.VVd30L, True) ,
   "pageDown" : boundFunction(self.VVd30L, False) ,
   "chanUp" : boundFunction(self.VVd30L, True) ,
   "chanDown" : boundFunction(self.VVd30L, False) ,
   "up"  : boundFunction(self.VVd30L, True) ,
   "down"  : boundFunction(self.VVd30L, False) ,
   "audio"  : boundFunction(self.VVjUNZ, True) ,
   "subtitle" : boundFunction(self.VVjUNZ, False) ,
   "0"   : boundFunction(self.VVmeM6 , 10)  ,
   "1"   : boundFunction(self.VVmeM6 , 1)  ,
   "2"   : boundFunction(self.VVmeM6 , 2)  ,
   "3"   : boundFunction(self.VVmeM6 , 3)  ,
   "4"   : boundFunction(self.VVmeM6 , 4)  ,
   "5"   : boundFunction(self.VVmeM6 , 5)  ,
   "6"   : boundFunction(self.VVmeM6 , 6)  ,
   "7"   : boundFunction(self.VVmeM6 , 7)  ,
   "8"   : boundFunction(self.VVmeM6 , 8)  ,
   "9"   : boundFunction(self.VVmeM6 , 9)
  }, -1)
  self.onShown.append(self.VV3HNB)
  self.onClose.append(self.onExit)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FFCNiP(self)
  if not CCkg2V.VVxiX0:
   CCkg2V.VVxiX0 = self
  else:
   self.close()
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFFfOJ(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFFfOJ(self["myPlayRpt"], "rpt")
  self.VVuiOt()
  self.instance.move(ePoint(40, 40))
  self.VVevRf(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV5kBt)
  except:
   self.timer.callback.append(self.VV5kBt)
  self.timer.start(250, False)
  self.VV5kBt("Checking ...")
  self.VVnidP()
 def VVWpde(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self)
  if "chCode" in iptvRef:
   if CCVmD8.VVlKkZ(self):
    self.VVnidP(True)
 def VVuiOt(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl:
   if "get_download_link" in origUrl: color = "#1120101a"
   else        : color = "#1120002a"
   self["myPlayGrn"].show()
  else:
   color = "#1100202a"
   self["myPlayGrn"].hide()
  FF1BAe(self["myTitle"], color)
 def VVcqmS(self):
  if self.SubtWin:
   self.SubtWin.VVeb4G()
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self)
  VVZCgs = []
  if self.isFromExternal:
   VVZCgs.append(("IPTV Menu"     , "iptv"  ))
   VVZCgs.append(VVXQs5)
  if FFKADs(iptvRef) and not "&end=" in decodedUrl and not FFyuoc(decodedUrl):
   uType, uHost, uUser, uPass, uId, uChName = CCSfuP.VVhkWC(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVZCgs.append(("Catchup Programs"   , "catchup"  ))
    VVZCgs.append(VVXQs5)
  VVZCgs.append(("Stop Current Service"    , "stop"  ))
  VVZCgs.append(("Restart Current Service"   , "restart"  ))
  VVZCgs.append(VVXQs5)
  FFM2IPSeries = FFyuoc(decodedUrl)
  if FFM2IPSeries:
   VVZCgs.append(("File Size"     , "fileSize" ))
   VVZCgs.append(VVXQs5)
  if self.enableDownloadMenu:
   addSep = False
   if FFKADs(iptvRef) and FFM2IPSeries:
    VVZCgs.append(("Start Download"   , "dload_cur" ))
    VVZCgs.append(("Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCXZq2.VVnprH():
    VVZCgs.append(("Download Manager"   , "dload_stat" ))
    addSep = True
   if addSep:
    VVZCgs.append(VVXQs5)
  fPath, fDir, fName = CC3ls7.VVAmF7(self)
  if fPath:
   if not CC3ls7.VVRPwc:
    VVZCgs.append((VVN5SF + "Open path in File Manager", "VV1cio" ))
   VVZCgs.append((VVN5SF + 'Add to "My Movies" Bouquet' , "VVNRbM" ))
   VVZCgs.append((VVN5SF + "Start Subtitle"    , "VVADzs"  ))
   VVZCgs.append(VVXQs5)
   VVZCgs.append(("%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVAFEy" ))
   VVZCgs.append(VVXQs5)
  if CFG.playerPos.getValue() : VVZCgs.append(("Move Bar to Bottom"  , "botm"  ))
  else      : VVZCgs.append(("Move Bar to Top"  , "top"   ))
  VVZCgs.append(("Help"             , "help"  ))
  FF9y9t(self, self.VVakGZ, VVZCgs=VVZCgs, width=550, title="Options")
 def VVakGZ(self, item=None):
  if item:
   if item == "iptv"     : self.VVKsLZ()
   elif item == "catchup"    : self.VV36Lv()
   elif item == "stop"     : self.VVOw84(0)
   elif item == "restart"    : self.VVOw84(1)
   elif item == "fileSize"    : FF9BOI(self, boundFunction(CCXD20.VV0XNU, self), title="Checking Server")
   elif item == "dload_cur"   : CCXZq2.VVmZum_cur(self)
   elif item == "addToDload"   : CCXZq2.VVIxjHCurrent(self)
   elif item == "dload_stat"   : CCXZq2.VV4PEQ(self)
   elif item == "VV1cio" : self.VV1cio()
   elif item == "VVNRbM" : FF9BOI(self, self.VVNRbM)
   elif item == "VVADzs"  : self.VVADzs(CCYf21.VVhWlR)
   elif item == "VVAFEy"  : self.VVAFEy()
   elif item == "botm"     : self.VVevRf(0)
   elif item == "top"     : self.VVevRf(1)
   elif item == "help"     : FFmggU(self, VVMuIV + "_help_player", "Player Controller (Keys)")
 def onExit(self):
  self.timer.stop()
  CCkg2V.VVxiX0 = None
  self.VVTV1e()
 def VVS1S3(self):
  if CCkg2V.VVxiX0:
   self.session.open(CCkg2V, enableZapping= False, enableDownloadMenu=False)
  self.close()
 def VV1cio(self):
  self.session.open(CC3ls7, gotoMovie=True)
  self.VVS1S3()
 def VVKsLZ(self):
  self.session.open(CCSfuP)
  self.VVS1S3()
 def VVOw84(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.close()
   elif typ == 1:
    self.VV5kBt("Restarting Service ...")
    FFzMXn(boundFunction(self.VVnUK1, serv))
 def VVnUK1(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self)
  if "&end=" in decodedUrl: boundFunction(self.VVnidP, True)
  else     : self.session.nav.playService(serv)
 def VVNRbM(self):
  title = "Add Movie to Bouquet"
  bName = "My Movies"
  path  = VVqs92 + "userbouquet.my_local_movies.tv"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self)
  fPath, fDir, fName = CC3ls7.VVAmF7(self)
  if not fPath or not chName:
   FF2VP5(self, "Cannot read Path or Channel Name", title=title)
   return
  isNew = False
  if not fileExists(path):
   isNew = True
   with open(path, "w") as f:
    f.write("#NAME %s\n" % bName)
  catID, stID, chNum = "1638", "6", "6"
  refCode = CCSfuP.VVtzsE(catID, stID, chNum)
  if not isNew:
   fTxt = FF1mdj(path)
   chUrl_noRef = "%s:%s" % (fPath, chName)
   if chUrl_noRef in fTxt:
    FF2VP5(self, "Already added to bouquet:\n\n%s" % bName, title=title)
    return
   for ns in range(1, 65535 - 1):
    catID, stID, chNum = "1638", str(ns), "6"
    refCode = CCSfuP.VVtzsE(catID, stID, chNum)
    if not refCode in fTxt:
     break
   else:
    FF2VP5(self, "Cannot create a unique Reference Code", title=title)
    return
  if refCode and fPath and chName:
   chUrl = "%s%s:%s" % (refCode, fPath, chName)
   with open(path, "a") as f:
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
   piconOk = self.VV0RMQ(refCode)
   FF4ns5(os.path.basename(path))
   FFg8wn()
   FFiM80(self, "Added to bouquet:\n\n%s" % bName, title=title + (" (with PIcon)" if piconOk else ""))
  else:
   FF2VP5(self, "Cannot create a unique Reference Code", title=title)
   return
 def VVAFEy(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCkg2V.VV801B(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VV5kBt(txt, highlight=ok)
 def VVADzs(self, mode, useSubtFile=""):
  self.hide()
  self.SubtWin = self.session.instantiateDialog(CCYf21, mode=mode, endCallback=self.VVmYGO)
  self.SubtWin.show()
  self.SubtWin.VVPAo2(useSubtFile)
 def VVmYGO(self, err):
  if err:
   if err == "noResume": self.VVTV1e(False)
   else    : self.VVTV1e(True)
   if   err == "noResume" : return
   if   err == "noErr"  : return
   elif err == "noAutoSrt" : CCYf21.VVur9h(self, self.VV1Z64)
   else      : FFSoSp(self, err, 2000)
 def VV1Z64(self, path):
  if path:
   self.VVADzs(CCYf21.VVhWlR, useSubtFile=path)
 def VV0RMQ(self, refCode):
  fPath, fDir, fName, picFile = CCXD20.VVqF3O(self)
  pPath = CCUKiz.VVxUr1()
  if fileExists(pPath) and pathExists(picFile):
   pFile = refCode.replace(":", "_").strip("_") + ".png"
   dest = os.path.join(pPath, pFile)
   os.system(FF8avg("cp -f '%s' '%s'" % (picFile, dest)))
   os.system(FF8avg("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (dest, dest)))
   return True
  return False
 def VVevRf(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VVh5RL(self):
  if self.isManualSeek:
   self.VVBm3W()
   self.VVnVVJ(self.manualSeekPts)
  else:
   if self.shown:
    self.hide()
    self.VVADzs(CCYf21.VVX6xs)
   else:
    self.VVTV1e()
 def VVTV1e(self, showBar=True):
  if self.SubtWin:
   self.session.deleteDialog(self.SubtWin)
   self.SubtWin = None
  if showBar:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVBm3W()
  elif self.SubtWin : self.VVTV1e()
  else    : self.close()
 def VVySTB(self):
  if self.SubtWin:
   self.SubtWin.VVpixK("noErr")
  FFQvwR(self, fncMode=CCXD20.VVB1Vt)
 def VV2I9g(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except Exception as e:
   pass
  self.VV5kBt("Toggling Play/Pause ...")
 def VVBm3W(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVl928(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCkg2V.VV801B(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVpQ00()
   else:
    self.manualSeekSec += direc * self.VVpQ00()
    self.manualSeekSec = FFir3e(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFe825(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFzrBt(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVmeM6(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VV4tr4())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VV5kBt("Changed Seek Time to : %d%s" % (val, self.VVFixC()))
 def VV4tr4(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVFixC())
 def VVFixC(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVHeYs(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVpQ00(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VV5kBt(self, stateTxt="", highlight=False):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFYxsR(self, addInfoObj=True)
  fr = res = ""
  if info:
   w = FF6SKb(info, iServiceInformation.sVideoWidth) or -1
   h = FF6SKb(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FF6SKb(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CCXD20.VV5l3A(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCkg2V.VV801B(self)
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FFir3e(percVal, 0, 100)
    width = int(FFe825(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not posTxt: self["myPlayPos"].setText("")
  if not remTxt: self["myPlayRem"].setText("")
  if not durTxt:
   if   prov : txt = prov
   elif posTxt : txt = ">>>>"
   else  : txt = "...."
   self["myPlayVal"].setText(txt)
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText("")
   FF1BAe(self["myPlayBarBG"], "#1100202a")
   self["myPlayBarF"].hide()
  else:
   FF1BAe(self["myPlayBarBG"], "#11000000")
   self["myPlayBarF"].show()
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VVAd3U() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   if highlight: FFdouS(self["myPlayMsg"], "#0000ffff")
   else  : FFdouS(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   self["myPlayMsg"].setText("-" if decodedUrl else FFWdKi(refCode, True))
   FFdouS(self["myPlayMsg"], "#00ff8066")
  tot = CCXZq2.VV28ry()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVhPGe()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VVnVVJ(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVXJfL()
  state = self.VVD2DK()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFdouS(self["myPlayMsg"], "#0000ff00")
  else     : FFdouS(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 @staticmethod
 def VV801B(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFzrBt(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFzrBt(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFzrBt(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVhPGe(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVnza5(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VVAd3U()
   if cList:
    VVZCgs = []
    for pts, what in cList:
     txt = FFzrBt(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVZCgs.append((txt, pts))
    FF9y9t(self, self.VVzdwl, VVZCgs=VVZCgs, title="Cut List")
   else:
    self.VV5kBt("No Cut-List for this channel !")
 def VVzdwl(self, item=None):
  if item:
   self.VVnVVJ(item)
 def VVAd3U(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVOI5m(self) : self.VVNzNM(1)
 def VVvcm7(self) : self.VVNzNM(-1)
 def VVNzNM(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCkg2V.VV801B(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVpQ00() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVHeYs())
    self.VV5kBt(txt)
  except:
   self.VV5kBt("Cannot jump")
 def VVnVVJ(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VV5kBt("Changing Time ...")
 def VVXJfL(self):
  self.VVOw84(1)
  self.VV5kBt("Replaying ...")
  self.VVBm3W()
 def VVLUBs(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCkg2V.VV801B(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VV5kBt("Jumping to end ...")
  except:
   pass
 def VVD2DK(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVd30L(self, isUp):
  if self.enableZapping:
   self.VV5kBt("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVBm3W()
   if self.portalTableParam:
    FFzMXn(boundFunction(self.VVD65z, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self)
    if "/timeshift/" in decodedUrl:
     self.VV5kBt("Cannot Zap Catcup TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVGK72()
 def VVGK72(self):
  self.lastPlayPos = 0
  self.VVuiOt()
  self.VVnidP()
 def VVD65z(self, isUp):
  CCSfuP_inatance, VVK0Qb, mode = self.portalTableParam
  if isUp : VVK0Qb.VVPj6K()
  else : VVK0Qb.VVkX78()
  colList = VVK0Qb.VV8yVS()
  if mode == "localIptv":
   chName, chUrl = CCSfuP_inatance.VVyPNI(VVK0Qb, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCSfuP_inatance.VVjCUY(VVK0Qb, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCSfuP_inatance.VVQ8fG(mode, VVK0Qb, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCSfuP_inatance.VVOJa6(mode, VVK0Qb, colList)
  else:
   self.VV5kBt("Cannot Zap")
   return
  FFqYTj(self, chUrl, VVEWCU=False)
  self.VVGK72()
 def VVnidP(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCkg2V.VV801B(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self)
   if not self.VVOdui(refCode, chName, decodedUrl, iptvRef):
    return
   self.VV5kBt("Refreshing Portal")
   FFzMXn(self.VVLxJ4)
  except:
   pass
 def VVLxJ4(self):
  self.restoreLastPlayPos = self.VVWmGa()
 def VV36Lv(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFYxsR(self)
  if not decodedUrl or FFyuoc(decodedUrl):
   self.VV5kBt("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCSfuP.VVhkWC(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VV5kBt("Reading Program List ...")
   ok_fnc = boundFunction(self.VVWFaH, refCode, chName, streamId, uHost, uUser, uPass)
   FFzMXn(boundFunction(CCSfuP.VV3Slx, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VV5kBt("Cannot process this channel")
 def VVWFaH(self, refCode, chName, streamId, uHost, uUser, uPass, VVK0Qb, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVK0Qb.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VV5kBt("Changing Program ...")
   FFzMXn(boundFunction(self.VVNWep, chUrl))
  else:
   self.VV5kBt("Incorrect Timestamp !")
 def VVNWep(self, chUrl):
   FFqYTj(self, chUrl, VVEWCU=False)
   self.lastPlayPos = 0
   self.VVuiOt()
 def VVjUNZ(self, isAudio):
  try:
   VVTjEU = InfoBar.instance
   if VVTjEU:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVTjEU)
    else  : self.session.open(SubtitleSelection, VVTjEU)
  except:
   pass
class CCuwDV(Screen):
 def __init__(self, session, title="", VVg7BJ="Continue?", VVLTw9=True, VVvjmj=False):
  self.skin, self.skinParam = FFZerm(VVZxuI, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVg7BJ = VVg7BJ
  self.VVvjmj = VVvjmj
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVLTw9 : VVZCgs = [no , yes]
  else   : VVZCgs = [yes, no ]
  FFeVzc(self, title, VVZCgs=VVZCgs, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVh5RL ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVg7BJ)
  if self.VVvjmj:
   self["myLabel"].instance.setHAlign(0)
  self.VVsyoG()
  FFDd6I(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFb3C9(self["myMenu"])
  FFeb2S(self, self["myMenu"])
 def VVh5RL(self):
  item = FFNpLs(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVsyoG(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCWi2y(Screen):
 def __init__(self, session, title="", VVZCgs=None, width=1000, height=0, OKBtnFnc=None, VVV04i=None, VVP7wO=None, VVjOrH=None, VVcc6k=None, VVmULe=False, VVnHgO=False):
  if height == 0: height = 850
  self.skin, self.skinParam = FFZerm(VVj3bT, width, height, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVZCgs   = VVZCgs
  self.OKBtnFnc   = OKBtnFnc
  self.VVV04i   = VVV04i
  self.VVP7wO  = VVP7wO
  self.VVjOrH  = VVjOrH
  self.VVcc6k   = VVcc6k
  self.VVmULe  = VVmULe
  self.VVnHgO  = VVnHgO
  FFeVzc(self, title, VVZCgs=VVZCgs)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVh5RL          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVKCdz         ,
   "green"  : self.VVW79h         ,
   "yellow" : self.VVNI2Z         ,
   "blue"  : self.VVEWlR         ,
   "pageUp" : self.VVuDGY       ,
   "chanUp" : self.VVuDGY       ,
   "pageDown" : self.VVtKQ3        ,
   "chanDown" : self.VVtKQ3
  }, -1)
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FFDd6I(self["myMenu"])
  FFGCoH(self)
  self.VVf56r(self["keyRed"]  , self.VVV04i )
  self.VVf56r(self["keyGreen"] , self.VVP7wO )
  self.VVf56r(self["keyYellow"] , self.VVjOrH )
  self.VVf56r(self["keyBlue"]  , self.VVcc6k )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFRpf0(self)
 def VVf56r(self, btnObj, btnFnc):
  if btnFnc:
   FFFMjq(btnObj, btnFnc[0])
 def VVh5RL(self):
  item = FFNpLs(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVmULe: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVKCdz(self)  : self.VVTi7L(self.VVV04i)
 def VVW79h(self) : self.VVTi7L(self.VVP7wO)
 def VVNI2Z(self) : self.VVTi7L(self.VVjOrH)
 def VVEWlR(self) : self.VVTi7L(self.VVcc6k)
 def VVTi7L(self, btnFnc):
  if btnFnc:
   item = FFNpLs(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVnHgO:
    self.cancel()
 def VVjh1C(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVZCgs = self["myMenu"].list
  VVZCgs.pop(ndx)
  if len(VVZCgs) > 0: self["myMenu"].setList(VVZCgs)
  else    : self.close()
 def VVN866(self, VVZCgs):
  if len(VVZCgs) > 0:
   newList = []
   for item in VVZCgs:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVrBXd(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVuDGY(self):
  self["myMenu"].moveToIndex(0)
 def VVtKQ3(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCO3DQ(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VVUQjT=None, VVYecm=None, VV5Xly=None, VVz3yz=26, VVfaqm=False, VViSv2=None, VV7Iri=None, VVt4yB=None, VVmZVX=None, VVvAyR=None, VVjzKl=None, VV08pm=None, VVyNAY=None, VVVVpp=None, VVZbs7=-1, VV4ne7=False, searchCol=0, VVZOs8=None, VVEkOu=None, VVaYuh="#00dddddd", VVJbor="#11002233", VVjawb="#00ff8833", VVsesB="#11111111", VV1Ceb="#0a555555", VV4lcF="#0affffff", VVEtDu="#11552200", VV2raL="#0055ff55"):
  self.skin, self.skinParam = FFZerm(VV1Iri, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFeVzc(self, title)
  self.header     = header
  self.VVUQjT     = VVUQjT
  self.totalCols    = len(VVUQjT[0])
  self.VVeRmY   = 0
  self.lastSortModeIsReverese = False
  self.VVfaqm   = VVfaqm
  self.VVEGKt   = 0.01
  self.VVKLdW   = 0.02
  self.VVcl2a = 0.03
  self.VVoWv6  = 1
  self.VV5Xly = VV5Xly
  self.colWidthPixels   = []
  self.VViSv2   = VViSv2
  self.OKButtonObj   = None
  self.VV7Iri   = VV7Iri
  self.VVt4yB   = VVt4yB
  self.VVmZVX   = VVmZVX
  self.VVvAyR  = VVvAyR
  self.VVjzKl   = VVjzKl
  self.VV08pm    = VV08pm
  self.VVyNAY   = VVyNAY
  self.VVVVpp  = VVVVpp
  self.VVZbs7    = VVZbs7
  self.VV4ne7   = VV4ne7
  self.searchCol    = searchCol
  self.VVYecm    = VVYecm
  self.keyPressed    = -1
  self.VVz3yz    = FFLfoe(VVz3yz)
  self.VVEXXT    = FFwqPy(self.VVz3yz, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVZOs8    = VVZOs8
  self.VVEkOu      = VVEkOu
  self.VVaYuh    = FF43YG(VVaYuh)
  self.VVJbor    = FF43YG(VVJbor)
  self.VVjawb    = FF43YG(VVjawb)
  self.VVsesB    = FF43YG(VVsesB)
  self.VV1Ceb   = FF43YG(VV1Ceb)
  self.VV4lcF    = FF43YG(VV4lcF)
  self.VVEtDu    = FF43YG(VVEtDu)
  self.VV2raL   = FF43YG(VV2raL)
  self.VVFxSi  = False
  self.selectedItems   = 0
  self.VV4zHd   = FF43YG("#01fefe01")
  self.VVTv1O   = FF43YG("#11400040")
  self.VV512j  = self.VV4zHd
  self.VVNlqw  = self.VVsesB
  if self.VV4ne7:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVgaZm  ,
   "red"   : self.VVLe01  ,
   "green"   : self.VV5zBn ,
   "yellow"  : self.VVvHhZ ,
   "blue"   : self.VVquM4  ,
   "menu"   : self.VVPItk ,
   "info"   : self.VVLSuq  ,
   "cancel"  : self.VVXT6d  ,
   "up"   : self.VVkX78    ,
   "down"   : self.VVPj6K  ,
   "left"   : self.VVqVkQ   ,
   "right"   : self.VVW0nv  ,
   "pageUp"  : self.VVmrd7  ,
   "chanUp"  : self.VVmrd7  ,
   "pageDown"  : self.VVFCMO  ,
   "chanDown"  : self.VVFCMO
  }, -1)
  FFotoW(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FFCNiP(self)
  try:
   self.VVZlUR()
  except Exception as err:
   FF2VP5(self, str(err))
   self.close(None)
 def VVZlUR(self):
  FFRpf0(self)
  if self.VVZOs8:
   FF1BAe(self["myTitle"], self.VVZOs8)
  if self.VVEkOu:
   FF1BAe(self["myBody"] , self.VVEkOu)
   FF1BAe(self["myTableH"] , self.VVEkOu)
   FF1BAe(self["myTable"] , self.VVEkOu)
   FF1BAe(self["myBar"]  , self.VVEkOu)
  self.VVf56r(self.VVt4yB  , self["keyRed"])
  self.VVf56r(self.VVmZVX  , self["keyGreen"])
  self.VVf56r(self.VVvAyR , self["keyYellow"])
  self.VVf56r(self.VVjzKl  , self["keyBlue"])
  if self.VViSv2:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VViSv2[0])
    FF1BAe(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVEXXT)
  self["myTableH"].l.setFont(0, gFont(VVreXb, self.VVz3yz))
  self["myTable"].l.setItemHeight(self.VVEXXT)
  self["myTable"].l.setFont(0, gFont(VVreXb, self.VVz3yz))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVEXXT)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVEXXT))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVEXXT)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVEXXT
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVEXXT * len(self.VVUQjT) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VV5Xly:
   self.VV5Xly = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VV5Xly)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVYecm:
   self.VVYecm = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVYecm
   self.VVYecm = []
   for item in tmpList:
    self.VVYecm.append(item | RT_VALIGN_CENTER)
  self.VVGNLN()
  if self.VV08pm:
   self.VV08pm(self)
 def VVf56r(self, btnFnc, btn):
  if btnFnc : FFFMjq(btn, btnFnc[0])
  else  : FFFMjq(btn, "")
 def VVTmHb(self, waitTxt):
  FF9BOI(self, self.VVGNLN, title=waitTxt)
 def VVGNLN(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVPt1l(0, self.header, self.VV4lcF, self.VVEtDu, self.VV4lcF, self.VVEtDu, self.VV2raL)])
   rows = []
   for c, row in enumerate(self.VVUQjT):
    rows.append(self.VVPt1l(c, row, self.VVaYuh, self.VVJbor, self.VVjawb, self.VVsesB, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVZbs7 > -1:
    self["myTable"].moveToIndex(self.VVZbs7 )
   self.VVHpQN()
   if self.VV4ne7:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVEXXT * len(self.VVUQjT)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVyNAY:
    self.VVTi7L(self.VVyNAY, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FF2VP5(self, str(err))
    self.close()
   except:
    pass
 def VVPt1l(self, keyIndex, columns, VVaYuh, VVJbor, VVjawb, VVsesB, VV2raL):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VV2raL and ndx == self.VVeRmY : textColor = VV2raL
   else           : textColor = VVaYuh
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FF43YG(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVJbor = c
    entry = span.group(3)
   if self.VVYecm[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVEXXT)
           , font   = 0
           , flags   = self.VVYecm[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVJbor
           , color_sel  = VVjawb
           , backcolor_sel = VVsesB
           , border_width = 1
           , border_color = self.VV1Ceb
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVLSuq(self):
  rowData = self.VVwz6m()
  if rowData:
   title, txt, colList = rowData
   if self.VV7Iri:
    fnc  = self.VV7Iri[1]
    params = self.VV7Iri[2]
    fnc(self, title, txt, colList)
   else:
    FFfnpN(self, txt, title)
 def VVgaZm(self):
  if   self.VVFxSi : self.VVmAQA(self.VVQNsd(), mode=2)
  elif self.VViSv2  : self.VVTi7L(self.VViSv2, None)
  else      : self.VVLSuq()
 def VVLe01(self) : self.VVTi7L(self.VVt4yB , self["keyRed"])
 def VV5zBn(self) : self.VVTi7L(self.VVmZVX , self["keyGreen"])
 def VVvHhZ(self): self.VVTi7L(self.VVvAyR , self["keyYellow"])
 def VVquM4(self) : self.VVTi7L(self.VVjzKl , self["keyBlue"])
 def VVTi7L(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFSoSp(self, buttonFnc[3])
    FFzMXn(boundFunction(self.VVtVod, buttonFnc))
   else:
    self.VVtVod(buttonFnc)
 def VVtVod(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVwz6m()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVmAQA(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VVUQjT[ndx]
   isSelected = row[1][9] == self.VV4zHd
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVPt1l(ndx, item, self.VVaYuh, self.VVJbor, self.VVjawb, self.VVsesB, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVPt1l(ndx, item, self.VV4zHd, self.VVTv1O, self.VV512j, self.VVNlqw, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVHpQN()
 def VVF9hK(self):
  FF9BOI(self, self.VVsh3K, title="Selecting all ...")
 def VVsh3K(self):
  self.VVzlVd(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VV4zHd
   if not isSelected:
    item = self.VVUQjT[ndx]
    newRow = self.VVPt1l(ndx, item, self.VV4zHd, self.VVTv1O, self.VV512j, self.VVNlqw, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVHpQN()
  self.VVL2TA()
 def VVgfYT(self):
  FF9BOI(self, self.VVvWtB, title="Unselecting all ...")
 def VVvWtB(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VV4zHd:
    item = self.VVUQjT[ndx]
    newRow = self.VVPt1l(ndx, item, self.VVaYuh, self.VVJbor, self.VVjawb, self.VVsesB, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVHpQN()
  self.VVL2TA()
 def VVL2TA(self):
  self.hide()
  self.show()
 def VVwz6m(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VV5Xly[i] > 1 or self.VV5Xly[i] == self.VVEGKt or self.VV5Xly[i] == self.VVcl2a:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VVUQjT))
   return rowNum, txt, colList
  else:
   return None
 def VVXT6d(self):
  if self.VVVVpp : self.VVVVpp(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVf2AE(self):
  return self["myTitle"].getText().strip()
 def VVklrU(self):
  return self.header
 def VVcvJH(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VV1Sed(self, txt):
  FFSoSp(self, txt)
 def VV5V7a(self, txt):
  FFSoSp(self, txt, 1000)
 def VVKn4K(self):
  FFSoSp(self)
 def VVI5uD(self):
  return len(self.VVUQjT)
 def VVEiHk(self): self["keyGreen"].show()
 def VV19lI(self): self["keyGreen"].hide()
 def VVQNsd(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVUBSs(self):
  return len(self["myTable"].list)
 def VVzlVd(self, isOn):
  self.VVFxSi = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu"].hide()
   if self.VVjzKl: self["keyBlue"].hide()
   if self.VViSv2 and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVjzKl: self["keyBlue"].show()
   if self.VViSv2 and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VViSv2[0])
   self.VVgfYT()
  FF1BAe(self["myTitle"], color)
  FF1BAe(self["myBar"]  , color)
 def VVYYAp(self):
  return self.VVFxSi
 def VVahci(self):
  return self.selectedItems
 def VV7QnH(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VVHpQN()
 def VVl1gh(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVHpQN()
 def VVfUbm(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VVUQjT:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVnW3H(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVI5uD()
  txt += FFE5E0("Total Unique Items", VVy89V)
  for i in range(self.totalCols):
   if self.VV5Xly[i - 1] > 1 or self.VV5Xly[i - 1] == self.VVEGKt or self.VV5Xly[i - 1] == self.VVcl2a:
    name, tot = self.VVfUbm(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFfnpN(self, txt)
 def VVPPM9(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VV8yVS(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVOukU(self, newList, newTitle="", VVfGUJMsg=True):
  if newList:
   self.VVUQjT = newList
   if self.VVfaqm and self.VVeRmY == 0:
    self.VVUQjT = sorted(self.VVUQjT, key=lambda x: int(x[self.VVeRmY])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VVUQjT = sorted(self.VVUQjT, key=lambda x: x[self.VVeRmY].lower(), reverse=self.lastSortModeIsReverese)
   if VVfGUJMsg : self.VVTmHb("Refreshing ...")
   else   : self.VVGNLN()
   if newTitle:
    self.VVcvJH(newTitle)
  else:
   FF2VP5(self, "Cannot refresh list")
   self.cancel()
 def VVOJEz(self, data):
  ndx = self.VVQNsd()
  newRow = self.VVPt1l(ndx, data, self.VVaYuh, self.VVJbor, self.VVjawb, self.VVsesB, None)
  if newRow:
   self.VVUQjT[ndx] = data
   self["myTable"].list[ndx] = newRow
   self.VVHpQN()
   return True
  else:
   return False
 def VVXwUN(self, colNum, textToFind, VVFzkD=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVHpQN()
    break
  else:
   if VVFzkD:
    FFSoSp(self, "Not found", 1000)
 def VVZeWW(self, colDict, VVFzkD=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVHpQN()
    return
  if VVFzkD:
   FFSoSp(self, "Not found", 1000)
 def VVZeWW_partial(self, colDict, VVFzkD=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVHpQN()
    return
  if VVFzkD:
   FFSoSp(self, "Not found", 1000)
 def VVP4oe(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVsVJQ(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VV4zHd:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVT0y1(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VV4zHd: return True
  else        : return False
 def VVotmZ(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVPItk(self):
  if not self["keyMenu"].getVisible() or self.VV4ne7:
   return
  VVZCgs = []
  VVZCgs.append(("Table Statistcis"             , "tableStat"  ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append((FFc8cv("Export Table to .html"     , VVy89V) , "VVRZFn" ))
  VVZCgs.append((FFc8cv("Export Table to .csv"     , VVy89V) , "VV4Z5k" ))
  VVZCgs.append((FFc8cv("Export Table to .txt (Tab Separated)", VVy89V) , "VV33v4" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VV5Xly[i] > 1 or self.VV5Xly[i] == self.VVKLdW:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVZCgs.append(VVXQs5)
   if tot == 1 : VVZCgs.append(("Sort", sList[0][1]))
   else  : VVZCgs += sList
  FF9y9t(self, self.VVr5r9, VVZCgs=VVZCgs, title=self.VVf2AE())
 def VVr5r9(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVnW3H()
   elif item == "VVRZFn": FF9BOI(self, self.VVRZFn, title=title)
   elif item == "VV4Z5k" : FF9BOI(self, self.VV4Z5k , title=title)
   elif item == "VV33v4" : FF9BOI(self, self.VV33v4 , title=title)
   else:
    isReversed = False
    if self.VVeRmY == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVfaqm and item == 0:
     self.VVUQjT = sorted(self.VVUQjT, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VVUQjT = sorted(self.VVUQjT, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVeRmY = item
    self.VVTmHb("Sorting ...")
 def VVkX78(self):
  self["myTable"].up()
  self.VVHpQN()
 def VVPj6K(self):
  self["myTable"].down()
  self.VVHpQN()
 def VVqVkQ(self):
  self["myTable"].pageUp()
  self.VVHpQN()
 def VVW0nv(self):
  self["myTable"].pageDown()
  self.VVHpQN()
 def VVmrd7(self):
  self["myTable"].moveToIndex(0)
  self.VVHpQN()
 def VVFCMO(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVHpQN()
 def VVXXtO(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVHpQN()
 def VV33v4(self):
  expFile = self.VVTw9a() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVmkGn()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VVUQjT:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VV5Xly[ndx] > self.VVoWv6 or self.VV5Xly[ndx] == self.VVcl2a:
      col = self.VVFxEe(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVc2tC(expFile)
 def VV4Z5k(self):
  expFile = self.VVTw9a() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVmkGn()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VVUQjT:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VV5Xly[ndx] > self.VVoWv6 or self.VV5Xly[ndx] == self.VVcl2a:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVFxEe(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVc2tC(expFile)
 def VVRZFn(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVf2AE(), PLUGIN_NAME, VVbLfP)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVf2AE()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVmkGn()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VV5Xly:
   colgroup += '   <colgroup>'
   for w in self.VV5Xly:
    if w > self.VVoWv6 or w == self.VVcl2a:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVTw9a() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VVUQjT:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VV5Xly[ndx] > self.VVoWv6 or self.VV5Xly[ndx] == self.VVcl2a:
      col = self.VVFxEe(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVc2tC(expFile)
 def VVmkGn(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VV5Xly[ndx] > self.VVoWv6 or self.VV5Xly[ndx] == self.VVcl2a:
     newRow.append(col.strip())
  return newRow
 def VVFxEe(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FF3aqm(col)
 def VVTw9a(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVf2AE())
  fileName = fileName.replace("__", "_")
  path  = FF8MLZ(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFNMff()
  return expFile
 def VVc2tC(self, expFile):
  FFiM80(self, "File exported to:\n\n%s" % expFile, title=self.VVf2AE())
 def VVHpQN(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCTMgS():
 def __init__(self, pixmapObj, picPath):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
 def VVwnST(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VViQtM)
    except Exception as e:
     self.picLoad.PictureData.get().append(self.VViQtM)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, "#2200002a"])
    self.picLoad.startDecode(self.picPath)
    return True
   except Exception as e:
    pass
  return False
 def VViQtM(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    self.pixmapObj.instance.setPixmap(ptr)
 def VVNMtv(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVgEsH(pixmapObj, path):
  cl = CCTMgS(pixmapObj, path)
  ok = cl.VVwnST()
  if ok: return cl
  else : return None
class CCtLih(Screen):
 def __init__(self, session, title="", VVZ4xB=None, showGrnMsg=""):
  self.skin, self.skinParam = FFZerm(VVD1kn, 1400, 800, 30, 40, 20, "#22000060", "#2200002a", 30)
  if not title:
   title = os.path.basename(VVZ4xB),
  self.session = session
  FFeVzc(self, title, addCloser=True)
  self["myPic"]  = Pixmap()
  self.VVZ4xB = VVZ4xB
  self.showGrnMsg  = showGrnMsg
  self.picViewer  = None
  self.onShown.append(self.VV3HNB)
  self.onClose.append(self.onExit)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  self.picViewer = CCTMgS.VVgEsH(self["myPic"], self.VVZ4xB)
  if self.picViewer:
   if self.showGrnMsg:
    FFSoSp(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FF2VP5(self, "Cannot view picture file:\n\n%s" % self.VVZ4xB)
   self.close()
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVNMtv()
 @staticmethod
 def VVIHWr(SELF, VVZ4xB, title="", showGrnMsg=""):
  SELF.session.open(boundFunction(CCtLih, title=title, VVZ4xB=VVZ4xB, showGrnMsg=showGrnMsg))
class CCrJRc(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFZerm(VVdC1L, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 26, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFeVzc(self, title=self.Title)
  FFFMjq(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Signal & Player Cotroller Hotkey"       , CFG.hotkey_signal    ))
  if VVI4VL:
   lst.append(getConfigListEntry("EPG Translation Language"        , CFG.epgLanguage    ))
  if VVNTnI:
   lst.append(getConfigListEntry("Force UTF-8 Encoding (only OpenVision Python-3.10.2+)" , CFG.forceUtf8Encoding   ))
  lst.append(getConfigListEntry(VVG0cy *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type"         , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsPath    ))
  lst.append(getConfigListEntry("Movie/Series Download Path"         , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(VVG0cy *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(VVG0cy *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB)"        , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons"            , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VV95XR()
  self.onShown.append(self.VV3HNB)
 def VV95XR(self):
  kList = {
    "ok"  : self.VVh5RL    ,
    "green"  : self.VVoSjD   ,
    "menu"  : self.VVVwXQ  ,
    "cancel" : self.VVFQrW  ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"]  = boundFunction(self["config"].handleKey, kLeft)
   kList["right"]  = boundFunction(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = boundFunction(self["config"].VV1P8r, 0)
     kList["chanDown"] = boundFunction(self["config"].VV1P8r, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FFCNiP(self)
  FFDd6I(self["config"])
  FFGCoH(self, self["config"])
  FFRpf0(self)
 def VVh5RL(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsPath   : self.VVFfoo()
   elif item == CFG.MovieDownloadPath   : self.VVbS5h(item, self["config"].getCurrent()[0])
   elif item == CFG.PIconsPath    : self.VV0NwD(item)
   elif item == CFG.backupPath    : self.VV0NwD(item)
   elif item == CFG.packageOutputPath  : self.VV0NwD(item)
   elif item == CFG.downloadedPackagesPath : self.VV0NwD(item)
   elif item == CFG.exportedTablesPath  : self.VV0NwD(item)
   elif item == CFG.exportedPIconsPath  : self.VV0NwD(item)
 def VVbS5h(self, item, title):
  tot = CCXZq2.VV28ry()
  if tot : FF2VP5(self, "Cannot change while downloading.", title=title)
  else : self.VV0NwD(item)
 def VVFfoo(self):
  VVZCgs = []
  VVZCgs.append(("Auto Find" , "auto"))
  VVZCgs.append(("Custom Path" , "path"))
  FF9y9t(self, self.VVc77b, VVZCgs=VVZCgs, title="IPTV Hosts Files Path")
 def VVc77b(self, item=None):
  if item:
   if   item == "auto": CFG.iptvHostsPath.setValue(VVvRbf)
   elif item == "path": self.VV0NwD(CFG.iptvHostsPath)
 def VV0NwD(self, configObj):
  sDir = configObj.getValue()
  if sDir == VVvRbf:
   sDir = "/"
  self.session.openWithCallback(boundFunction(self.VVhEjc, configObj)
         , boundFunction(CC3ls7, mode=CC3ls7.VVR0D8, VVvxsk=sDir))
 def VVhEjc(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVFQrW(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFS238(self, self.VVoSjD, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVoSjD(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVUFoS()
  self.VV6WHY()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VV6WHY(self):
  CCgkMM.VVDMUk()
 def VVVwXQ(self):
  VVZCgs = []
  VVZCgs.append(("Use Backup directory in all other paths"      , "VVTmvK"   ))
  VVZCgs.append(("Reset all to default (including File Manager bookmarks)"  , "VVh1vb"   ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Backup %s Settings" % PLUGIN_NAME        , "VVtJLv"  ))
  VVZCgs.append(("Restore %s Settings" % PLUGIN_NAME       , "VVpY2j"  ))
  if fileExists(VVGttK + VVb9f3):
   VVZCgs.append(VVXQs5)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVZCgs.append(('%s Checking for Update' % txt1       , txt2     ))
   VVZCgs.append(("Reinstall %s" % PLUGIN_NAME        , "VVDQ7p"  ))
   VVZCgs.append(("Update %s" % PLUGIN_NAME        , "VVTeym"   ))
  FF9y9t(self, self.VVwTnz, VVZCgs=VVZCgs, title="Config. Options")
 def VVwTnz(self, item=None):
  if item:
   if   item == "VVTmvK"  : FFS238(self, self.VVTmvK , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVh1vb"  : FFS238(self, self.VVh1vb, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCdIk5)
   elif item == "VVtJLv" : self.VVtJLv()
   elif item == "VVpY2j" : FF9BOI(self, self.VVpY2j, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVPQEb(True)
   elif item == "disableChkUpdate" : self.VVPQEb(False)
   elif item == "VVDQ7p" : FF9BOI(self, self.VVDQ7p , "Checking Server ...")
   elif item == "VVTeym"  : FF9BOI(self, self.VVTeym  , "Checking Server ...")
 def VVtJLv(self):
  path = "%sajpanel_settings_%s" % (VVGttK, FFNMff())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFiM80(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVpY2j(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFqFDg("find / %s -iname '%s*' | grep %s" % (FF1d0b(1), name, name))
  if lines:
   lines.sort()
   VVZCgs = []
   for line in lines:
    VVZCgs.append((line, line))
   FF9y9t(self, boundFunction(self.VVXeti, title), title=title, VVZCgs=VVZCgs, width=1200)
  else:
   FF2VP5(self, "No settings files found !", title=title)
 def VVXeti(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FF5Wuv(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVUFoS()
    FFuF9Y()
   else:
    FFzAsS(SELF, path, title=title)
 def VVPQEb(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVTmvK(self):
  newPath = FF8MLZ(VVGttK)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVUFoS()
 @staticmethod
 def VV27e1():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVh1vb(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.EventsInfoMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.epgLanguage.setValue("off")
  CFG.forceUtf8Encoding.setValue(True)
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.autoResetFrozenIptvChan.setValue(True)
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.iptvHostsPath.setValue(VVvRbf)
  CFG.MovieDownloadPath.setValue(CCXZq2.VVntBL())
  CFG.PIconsPath.setValue(VVbCMJ)
  CFG.backupPath.setValue(CCrJRc.VV27e1())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVUFoS()
  self.close()
 def VVUFoS(self):
  configfile.save()
  global VVGttK
  VVGttK = CFG.backupPath.getValue()
  FF3gAd()
 def VVTeym(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVXVOm(title)
  if webVer:
   FFS238(self, boundFunction(FF9BOI, self, boundFunction(self.VVfJtD, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVDQ7p(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVXVOm(title, True)
  if webVer:
   FFS238(self, boundFunction(FF9BOI, self, boundFunction(self.VVfJtD, webVer, title, True)), "Install and Restart ?", title=title)
 def VVfJtD(self, webVer, title, isReinst=False):
  url = self.VVkIPZ(self, title)
  if url:
   VVZhoG = FFz9Zw() == "dpkg"
   if VVZhoG == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVZhoG else "ipk")
   path, err = FFTJ9u(url + fName, fName, timeout=2)
   if path:
    if isReinst : cmd = FFfBk8(VVak7B, path)
    else  : cmd = FFfBk8(VVtBDT, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFeerf(self, cmd)
    else:
     FFh46b(self, title=title)
   else:
    FF2VP5(self, err, title=title)
 def VVXVOm(self, title, anyVer=False):
  url = self.VVkIPZ(self, title)
  if not url:
   return ""
  path, err = FFTJ9u(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FF2VP5(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FF1mdj(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FF2VP5(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVbLfP.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFqFDg(cmd)
   if list and curVer == list[0]:
    return webVer
  FFiM80(self, FFc8cv("No update required.", VV09cj) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVkIPZ(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVGttK + VVb9f3
  if fileExists(path):
   span = iSearch(r"(http.+)", FF1mdj(path), IGNORECASE)
   if span : url = FF8MLZ(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FF2VP5(SELF, err, title)
  return url
 @staticmethod
 def VVlVRr(url):
  path, err = FFTJ9u(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FF1mdj(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVbLfP.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFqFDg(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCdIk5(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFZerm(VVFreb, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVFj9r
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFeVzc(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVx728("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVx728("\c00888888", i) + sp + "GREY\n"
   txt += self.VVx728("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVx728("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVx728("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVx728("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVx728("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVx728("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVx728("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVx728("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVx728("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVx728("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVh5RL ,
   "green"   : self.VVh5RL ,
   "left"   : self.VVHJ83 ,
   "right"   : self.VVEyK2 ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  self.VVagTG()
 def VVh5RL(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFS238(self, self.VV2cdb, "Change to : %s" % txt, title=self.Title)
 def VV2cdb(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVFj9r
  VVFj9r = self.cursorPos
  self.VVmrLJ()
  self.close()
 def VVHJ83(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVagTG()
 def VVEyK2(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVagTG()
 def VVagTG(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVx728(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VV2H87(color):
  if VVN5SF: return "\\" + color
  else    : return ""
 @staticmethod
 def VVmrLJ():
  global VV0hxT, VVaDOU, VVlcHo, VVy89V, VVlVgH, VVGjTd, VV09cj, VVN5SF, COLOR_CONS_BRIGHT_YELLOW, VVO27w, VVbIFj, VVjxiW, VVodRY
  VVodRY   = CCdIk5.VVx728("\c00FFFFFF", VVFj9r)
  VVaDOU    = CCdIk5.VVx728("\c00888888", VVFj9r)
  VV0hxT  = CCdIk5.VVx728("\c005A5A5A", VVFj9r)
  VVGjTd    = CCdIk5.VVx728("\c00FF0000", VVFj9r)
  VVlcHo   = CCdIk5.VVx728("\c00FF5000", VVFj9r)
  VVN5SF   = CCdIk5.VVx728("\c00FFFF00", VVFj9r)
  COLOR_CONS_BRIGHT_YELLOW = CCdIk5.VVx728("\c00FFFFAA", VVFj9r)
  VV09cj   = CCdIk5.VVx728("\c0000FF00", VVFj9r)
  VVlVgH    = CCdIk5.VVx728("\c000066FF", VVFj9r)
  VVO27w    = CCdIk5.VVx728("\c0000FFFF", VVFj9r)
  VVbIFj  = CCdIk5.VVx728("\c00DSFFFF", VVFj9r)  #
  VVjxiW   = CCdIk5.VVx728("\c00FA55E7", VVFj9r)
  VVy89V    = CCdIk5.VVx728("\c00FF8F5F", VVFj9r)
CCdIk5.VVmrLJ()
class CCI31K(Screen):
 def __init__(self, session, path, VVZhoG):
  self.skin, self.skinParam = FFZerm(VVOKrh, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVItim   = path
  self.VVtwGs   = ""
  self.VVVzuc   = ""
  self.VVZhoG    = VVZhoG
  self.VVfEMl    = ""
  self.VVqv6D  = ""
  self.VVfaDU    = False
  self.VVVmJD  = False
  self.postInstAcion   = 0
  self.VVKzDs  = "enigma2-plugin-extensions"
  self.VVAJhr  = "enigma2-plugin-systemplugins"
  self.VVASGH = "enigma2"
  self.VVrceE  = 0
  self.VVbDa6  = 1
  self.VVFt26  = 2
  if pathExists(self.Path + "DEBIAN") : self.VV5kpJ = "DEBIAN"
  else        : self.VV5kpJ = "CONTROL"
  self.controlPath = self.Path + self.VV5kpJ
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVZhoG:
   self.packageExt  = ".deb"
   self.VVJbor  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVJbor  = "#11001020"
  FFeVzc(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFFMjq(self["keyRed"] , "Create")
  FFFMjq(self["keyGreen"] , "Post Install")
  FFFMjq(self["keyYellow"], "Installation Path")
  FFFMjq(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVTlIT  ,
   "green"   : self.VVObWS ,
   "yellow"  : self.VVslCK  ,
   "blue"   : self.VVPDR4  ,
   "cancel"  : self.VVrSVn
  }, -1)
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FFRpf0(self)
  if self.VVJbor:
   FF1BAe(self["myBody"], self.VVJbor)
   FF1BAe(self["myLabel"], self.VVJbor)
  self.VVxv13(True)
  self.VVIxqi(True)
 def VVIxqi(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVEkIc()
  if isFirstTime:
   if   package.startswith(self.VVKzDs) : self.VVItim = VVkYQ0 + self.VVfEMl + "/"
   elif package.startswith(self.VVAJhr) : self.VVItim = VVnpau + self.VVfEMl + "/"
   else            : self.VVItim = self.Path
  if self.VVfaDU : myColor = VVy89V
  else    : myColor = VVodRY
  txt  = ""
  txt += "Source Path\t: %s\n" % FFc8cv(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFc8cv(self.VVItim, VVN5SF)
  if self.VVVzuc : txt += "Package File\t: %s\n" % FFc8cv(self.VVVzuc, VVaDOU)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFc8cv("Check Control File fields : %s" % errTxt, VVlcHo)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFc8cv("Restart GUI", VVy89V)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFc8cv("Reboot Device", VVy89V)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FFc8cv("Post Install", VV09cj), act)
  if not errTxt and VVlcHo in controlInfo:
   txt += "Warning\t: %s\n" % FFc8cv("Errors in control file may affect the result package.", VVlcHo)
  txt += "\nControl File\t: %s\n" % FFc8cv(self.controlFile, VVaDOU)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVObWS(self):
  VVZCgs = []
  VVZCgs.append(("No Action"    , "noAction"  ))
  VVZCgs.append(("Restart GUI"    , "VVTbRA"  ))
  VVZCgs.append(("Reboot Device"   , "rebootDev"  ))
  FF9y9t(self, self.VVDtYH, title="Package Installation Option (after completing installation)", VVZCgs=VVZCgs)
 def VVDtYH(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVTbRA"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVxv13(False)
   self.VVIxqi()
 def VVslCK(self):
  rootPath = FFc8cv("/%s/" % self.VVfEMl, VV0hxT)
  VVZCgs = []
  VVZCgs.append(("Current Path"        , "toCurrent"  ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Extension Path"       , "toExtensions" ))
  VVZCgs.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVZCgs.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FF9y9t(self, self.VVeKrs, title="Installation Path", VVZCgs=VVZCgs)
 def VVeKrs(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVBBPh(FFFeKp(self.Path, True))
   elif item == "toExtensions"  : self.VVBBPh(VVkYQ0)
   elif item == "toSystemPlugins" : self.VVBBPh(VVnpau)
   elif item == "toRootPath"  : self.VVBBPh("/")
   elif item == "toRoot"   : self.VVBBPh("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVQoN2, boundFunction(CC3ls7, mode=CC3ls7.VVR0D8, VVvxsk=VVGttK))
 def VVQoN2(self, path):
  if len(path) > 0:
   self.VVBBPh(path)
 def VVBBPh(self, parent, withPackageName=True):
  if withPackageName : self.VVItim = parent + self.VVfEMl + "/"
  else    : self.VVItim = "/"
  mode = self.VVDu8o()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVQzDS(mode), self.controlFile))
  self.VVIxqi()
 def VVPDR4(self):
  if fileExists(self.controlFile):
   lines = FF5Wuv(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFIPSl(self, self.VVNxQC, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FF2VP5(self, "Version not found or incorrectly set !")
  else:
   FFzAsS(self, self.controlFile)
 def VVNxQC(self, VVr5f9):
  if VVr5f9:
   version, color = self.VV8gWz(VVr5f9, False)
   if color == VVO27w:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVr5f9, self.controlFile))
    self.VVIxqi()
   else:
    FF2VP5(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVrSVn(self):
  if self.newControlPath:
   if self.VVfaDU:
    self.VVvekH()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFc8cv(self.newControlPath, VVaDOU)
    txt += FFc8cv("Do you want to keep these files ?", VVN5SF)
    FFS238(self, self.close, txt, callBack_No=self.VVvekH, title="Create Package", VVvjmj=True)
  else:
   self.close()
 def VVvekH(self):
  os.system(FF8avg("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVQzDS(self, mode):
  if   mode == self.VVbDa6 : prefix = self.VVKzDs
  elif mode == self.VVFt26 : prefix = self.VVAJhr
  else        : prefix = self.VVASGH
  return prefix + "-" + self.VVqv6D
 def VVDu8o(self):
  if   self.VVItim.startswith(VVkYQ0) : return self.VVbDa6
  elif self.VVItim.startswith(VVnpau) : return self.VVFt26
  else            : return self.VVrceE
 def VVxv13(self, isFirstTime):
  self.VVfEMl   = os.path.basename(os.path.normpath(self.Path))
  self.VVfEMl   = "_".join(self.VVfEMl.split())
  self.VVqv6D = self.VVfEMl.lower()
  self.VVfaDU = self.VVqv6D == VVD897.lower()
  if self.VVfaDU and self.VVqv6D.endswith("ajpan"):
   self.VVqv6D += "el"
  if self.VVfaDU : self.VVtwGs = VVGttK
  else    : self.VVtwGs = CFG.packageOutputPath.getValue()
  self.VVtwGs = FF8MLZ(self.VVtwGs)
  if not pathExists(self.controlPath):
   os.system(FF8avg("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVfaDU : t = PLUGIN_NAME
  else    : t = self.VVfEMl
  self.VVSuw7(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVGEhl.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVfaDU : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVSuw7(self.postrmFile, txt)
  if self.VVfaDU:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVbLfP)
   self.VVSuw7(self.preinstFile, txt)
  else:
   self.VVSuw7(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVfEMl)
  mode = self.VVDu8o()
  if isFirstTime and not mode == self.VVrceE:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVG0cy
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVSuw7(self.postinstFile, txt, VVYtfU=True)
  os.system(FF8avg("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVfaDU : version, descripton, maintainer = VVbLfP , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVfEMl , self.VVfEMl
   txt = ""
   txt += "Package: %s\n"  % self.VVQzDS(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVSuw7(self, path, lines, VVYtfU=False):
  if not fileExists(path) or VVYtfU:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVEkIc(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FF5Wuv(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFc8cv(line, VVlcHo)
     elif not line.startswith(" ")    : line = FFc8cv(line, VVlcHo)
     else          : line = FFc8cv(line, VVO27w)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVO27w
   else   : color = VVlcHo
   descr = FFc8cv(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVlcHo
     elif line.startswith((" ", "\t")) : color = VVlcHo
     elif line.startswith("#")   : color = VVaDOU
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VV8gWz(val, True)
      elif key == "Version"  : version, color = self.VV8gWz(val, False)
      elif key == "Maintainer" : maint  , color = val, VVO27w
      elif key == "Architecture" : arch  , color = val, VVO27w
      else:
       color = VVO27w
      if not key == "OE" and not key.istitle():
       color = VVlcHo
     else:
      color = VVy89V
     txt += FFc8cv(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVVzuc = self.VVtwGs + packageName
   self.VVVmJD = True
   errTxt = ""
  else:
   self.VVVzuc  = ""
   self.VVVmJD = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VV8gWz(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVO27w
  else          : return val, VVlcHo
 def VVTlIT(self):
  if not self.VVVmJD:
   FF2VP5(self, "Please fix Control File errors first.")
   return
  if self.VVZhoG: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFFeKp(self.VVItim, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVfEMl
  symlinkTo  = FF2KYY(self.Path)
  dataDir   = self.VVItim.rstrip("/")
  removePorjDir = FF8avg("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FF8avg("rm -f '%s'" % self.VVVzuc) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFUx1o()
  if self.VVZhoG:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FF9qFB("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVfaDU:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVItim == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VV5kpJ)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVVzuc, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVVzuc
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVVzuc, FFR6WL(result  , VV09cj))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVItim, FFR6WL(instPath, VVO27w))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFR6WL(failed, VVlcHo))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFeerf(self, cmd)
class CC3ls7(Screen):
 VVPnal   = 0
 VVR0D8  = 1
 VV586p = 20
 VVRPwc  = None
 def __init__(self, session, VVvxsk="/", mode=VVPnal, VVAVDz="Select", VVz3yz=30, gotoMovie=False):
  self.skin, self.skinParam = FFZerm(VVj3bT, 1400, 920, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFeVzc(self)
  FFFMjq(self["keyRed"] , "Exit")
  FFFMjq(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVAVDz = VVAVDz
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  CC3ls7.VVRPwc = self
  if   self.gotoMovie        : VVqGAw, self.VVvxsk = True , CC3ls7.VVAmF7(self)[1] or "/"
  elif self.mode == self.VVPnal  : VVqGAw, self.VVvxsk = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVR0D8 : VVqGAw, self.VVvxsk = False, VVvxsk
  else           : VVqGAw, self.VVvxsk = True , VVvxsk
  self.VVvxsk = FF8MLZ(self.VVvxsk)
  self["myMenu"] = CCiOcp(  directory   = "/"
         , VVqGAw   = VVqGAw
         , VVTdNh = True
         , VVdVup   = self.skinParam["width"]
         , VVz3yz   = self.skinParam["bodyFontSize"]
         , VVEXXT  = self.skinParam["bodyLineH"]
         , VVy9Q9  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVh5RL      ,
   "red"    : self.VV36JP     ,
   "green"    : self.VVul5C    ,
   "yellow"   : self.VVVd9c   ,
   "blue"    : self.VVQH35   ,
   "menu"    : self.VVUW4t    ,
   "info"    : self.VVMCtS    ,
   "cancel"   : self.VVDLmi     ,
   "pageUp"   : self.VVDLmi     ,
   "chanUp"   : self.VVDLmi
  }, -1)
  FFotoW(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVfyHt)
 def onExit(self):
  CC3ls7.VVRPwc = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVfyHt)
  FFCNiP(self)
  FFDd6I(self["myMenu"], bg="#06003333")
  FFRpf0(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode == self.VVR0D8:
   FFFMjq(self["keyGreen"], self.VVAVDz)
   color = "#22000022"
   FF1BAe(self["myBody"], color)
   FF1BAe(self["myMenu"], color)
   color = "#22220000"
   FF1BAe(self["myTitle"], color)
   FF1BAe(self["myBar"], color)
  self.VVfyHt()
  if self.VV8IR4(self.VVvxsk) > self.bigDirSize:
   FFSoSp(self, "Changing directory...")
   FFzMXn(self.VVmG7s)
  else:
   self.VVmG7s()
 def VVmG7s(self):
  self["myMenu"].VVuvFC(self.VVvxsk)
  if self.gotoMovie:
   self.VVdhPl(chDir=False)
 def VVXXtO(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVOm78(self):
  self["myMenu"].refresh()
  FFv7fK()
 def VV8IR4(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VVh5RL(self):
  if self["myMenu"].VV78P1():
   path = self.VVR7m7(self.VVF9lI())
   if self.VV8IR4(path) > self.bigDirSize:
    FFSoSp(self, "Changing directory...")
    FFzMXn(self.VV0AiY)
   else:
    self.VV0AiY()
  else:
   self.VV6ri7()
 def VV0AiY(self):
  self["myMenu"].descent()
  self.VVfyHt()
 def VVDLmi(self):
  if self["myMenu"].VV0DXo():
   self["myMenu"].moveToIndex(0)
   self.VV0AiY()
 def VV36JP(self):
  if not FFJEIf(self):
   self.close("")
 def VVul5C(self):
  if self.mode == self.VVR0D8:
   path = self.VVR7m7(self.VVF9lI())
   self.close(path)
 def VVMCtS(self):
  FF9BOI(self, self.VVZZgM, title="Calculating size ...")
 def VVZZgM(self):
  path = self.VVR7m7(self.VVF9lI())
  param = self.VVZ12s(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFgBpG("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CC3ls7.VVv08m(path)
     freeSize = CC3ls7.VVjHPj(path)
     size = totSize - freeSize
     totSize  = CC3ls7.VV3UfA(totSize)
     freeSize = CC3ls7.VV3UfA(freeSize)
    else:
     size = FFgBpG("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CC3ls7.VV3UfA(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFc8cv(pathTxt, VVy89V) + "\n"
   if slBroken : fileTime = self.VVLJtd(path)
   else  : fileTime = self.VVHANL(path)
   def VVYMjy(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVYMjy("Path"    , pathTxt)
   txt += VVYMjy("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVYMjy("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVYMjy("Total Size"   , "%s" % totSize)
    txt += VVYMjy("Used Size"   , "%s" % usedSize)
    txt += VVYMjy("Free Size"   , "%s" % freeSize)
   else:
    txt += VVYMjy("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVYMjy("Owner"    , owner)
   txt += VVYMjy("Group"    , group)
   txt += VVYMjy("Perm. (User)"  , permUser)
   txt += VVYMjy("Perm. (Group)"  , permGroup)
   txt += VVYMjy("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVYMjy("Perm. (Ext.)" , permExtra)
   txt += VVYMjy("iNode"    , iNode)
   txt += VVYMjy("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVG0cy, VVG0cy)
    txt += hLinkedFiles
   txt += self.VVQ3Rq(path)
  else:
   FF2VP5(self, "Cannot access information !")
  if len(txt) > 0:
   FFfnpN(self, txt)
 def VVZ12s(self, path):
  path = path.strip()
  path = FF2KYY(path)
  result = FFgBpG("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVjlEU(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVjlEU(perm, 1, 4)
   permGroup = VVjlEU(perm, 4, 7)
   permOther = VVjlEU(perm, 7, 10)
   permExtra = VVjlEU(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFNxEm("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVQ3Rq(self, path):
  txt  = ""
  res  = FFgBpG("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFc8cv("File Attributes:", VVjxiW), txt)
  return txt
 def VVHANL(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FF2SnK(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FF2SnK(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FF2SnK(os.path.getctime(path))
  return txt
 def VVLJtd(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFgBpG("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFgBpG("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFgBpG("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVR7m7(self, currentSel):
  currentDir  = self["myMenu"].VV0DXo()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VV78P1():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVF9lI(self):
  return self["myMenu"].getSelection()[0]
 def VVfyHt(self):
  FFSoSp(self)
  path = self.VVR7m7(self.VVF9lI())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VVUQjT = self.VVJcaV()
  if VVUQjT and len(VVUQjT) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VV7t6f(path)
  if self.mode == self.VVPnal and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
 def VV7t6f(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVVaku(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVUW4t(self):
  if self.mode == self.VVPnal:
   path  = self.VVR7m7(self.VVF9lI())
   isDir  = os.path.isdir(path)
   VVZCgs = []
   VVZCgs.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVIyrL(path):
     sepShown = True
     VVZCgs.append(VVXQs5)
     VVZCgs.append( (VVy89V + "Archiving / Packaging"      , "VVQk9b"  ))
    if self.VVfqB1(path):
     if not sepShown:
      VVZCgs.append(VVXQs5)
     VVZCgs.append( (VVy89V + "Read Backup information"     , "VV42NN"  ))
     VVZCgs.append( (VVy89V + "Compress Octagon Image (to zip File)"  , "VVSoIE" ))
   elif os.path.isfile(path):
    selFile = self.VVF9lI()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar")) : VVZCgs.extend(self.VVI8Rr(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVZCgs.extend(self.VVNDLx(True))
    elif selFile.endswith(".m3u")              : VVZCgs.extend(self.VVetCV(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FF3UaK(path):
     VVZCgs.append(VVXQs5)
     VVZCgs.append((VVy89V + "View"     , "textView_def" ))
     VVZCgs.append((VVy89V + "View (Select Encoder)" , "textView_enc" ))
     VVZCgs.append((VVy89V + "Edit"     , "text_Edit"  ))
    if len(txt) > 0:
     VVZCgs.append(VVXQs5)
     VVZCgs.append(   (VVy89V + txt      , "VV6ri7"  ))
   VVZCgs.append(VVXQs5)
   VVZCgs.append(     ("Create SymLink"       , "VVpU9F" ))
   if not self.VVIyrL(path):
    VVZCgs.append(   ("Rename"          , "VVT3PK" ))
    VVZCgs.append(   ("Copy"           , "copyFileOrDir" ))
    VVZCgs.append(   ("Move"           , "moveFileOrDir" ))
    VVZCgs.append(   ("DELETE"          , "VVLbLb" ))
    if fileExists(path):
     VVZCgs.append(VVXQs5)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVZCgs.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVZCgs.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVZCgs.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVZCgs.append(VVXQs5)
   VVZCgs.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVZCgs.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CC3ls7.VVAmF7(self)
   if fPath:
    VVZCgs.append(VVXQs5)
    VVZCgs.append(   (VVN5SF + "Go to current movie"  , "VVdhPl"))
   VVZCgs.append(VVXQs5)
   VVZCgs.append(    ("Set current directory as \"Startup Path\"" , "VVVfoj" ))
   FF9y9t(self, self.VVotnO, title="Options", VVZCgs=VVZCgs)
 def VVotnO(self, item=None):
  if self.mode == self.VVPnal:
   if item is not None:
    path = self.VVR7m7(self.VVF9lI())
    selFile = self.VVF9lI()
    if   item == "properties"    : self.VVMCtS()
    elif item == "VVQk9b"  : self.VVQk9b(path)
    elif item == "VV42NN"  : self.VV42NN(path)
    elif item == "VVSoIE" : self.VVSoIE(path)
    elif item.startswith("extract_")  : self.VVAvBO(path, selFile, item)
    elif item.startswith("script_")   : self.VVyDpy(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVNhyAItem_m3u(path, selFile, item)
    elif item.startswith("textView_def") : FFtC7A(self, path)
    elif item.startswith("textView_enc") : self.VVJ9fk(path)
    elif item.startswith("text_Edit")  : CCLioI(self, path)
    elif item == "chmod644"     : self.VVqQsO(path, selFile, "644")
    elif item == "chmod755"     : self.VVqQsO(path, selFile, "755")
    elif item == "chmod777"     : self.VVqQsO(path, selFile, "777")
    elif item == "VVpU9F"   : self.VVpU9F(path, selFile)
    elif item == "VVT3PK"   : self.VVT3PK(path, selFile)
    elif item == "copyFileOrDir"   : self.VVrW7D(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVrW7D(path, selFile, True)
    elif item == "VVLbLb"   : self.VVLbLb(path, selFile)
    elif item == "createNewFile"   : self.VVZZoi(path, True)
    elif item == "createNewDir"    : self.VVZZoi(path, False)
    elif item == "VVdhPl"   : self.VVdhPl()
    elif item == "VVVfoj"   : self.VVVfoj(path)
    elif item == "VV6ri7"    : self.VV6ri7()
    else         : self.close()
 def VV6ri7(self):
  selFile = self.VVF9lI()
  path  = self.VVR7m7(selFile)
  if os.path.isfile(path):
   VVk8hn = []
   category = self["myMenu"].VV8RIk(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVhoki(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : CCtLih.VVIHWr(self, path)
   elif category == "txt"         : FFtC7A(self, path)
   elif category in ("tar", "zip", "rar")     : self.VVoRCX(path, selFile)
   elif category == "scr"         : self.VVghtW(path, selFile)
   elif category == "m3u"         : self.VVHYr6(path, selFile)
   elif category in ("ipk", "deb")       : self.VVUMZV(path, selFile)
   elif category == "mus"         : self.VV2a6o(self, path)
   elif category == "mov"         : self.VV2a6o(self, path)
   elif not FF3UaK(path)        : FFtC7A(self, path)
 def VVVd9c(self):
  path = self.VVR7m7(self.VVF9lI())
  action = self.VV7t6f(path)
  if action == 1:
   self.VVH4HF(path)
   FFSoSp(self, "Added", 500)
  elif action == -1:
   self.VVgRV4(path)
   FFSoSp(self, "Removed", 500)
  self.VV7t6f(path)
 def VVH4HF(self, path):
  VVUQjT = self.VVJcaV()
  if not VVUQjT:
   VVUQjT = []
  if len(VVUQjT) >= self.VV586p:
   FF2VP5(SELF, "Max bookmarks reached (max=%d)." % self.VV586p)
  elif not path in VVUQjT:
   VVUQjT = [path] + VVUQjT
   self.VVVu59(VVUQjT)
 def VVQH35(self):
  VVUQjT = self.VVJcaV()
  if VVUQjT:
   newList = []
   for line in VVUQjT:
    newList.append((line, line))
   VVV04i  = ("Delete"  , self.VVZ6Pw )
   VVjOrH = ("Move Up"   , self.VVIRCN )
   VVcc6k  = ("Move Down" , self.VVnjCz )
   self.bookmarkMenu = FF9y9t(self, self.VVw2GT, title="Bookmarks", VVZCgs=newList, VVV04i=VVV04i, VVjOrH=VVjOrH, VVcc6k=VVcc6k)
 def VVZ6Pw(self, VVF9lIObj, path):
  if self.bookmarkMenu:
   VVUQjT = self.VVgRV4(path)
   self.bookmarkMenu.VVN866(VVUQjT)
 def VVIRCN(self, VVF9lIObj, path):
  if self.bookmarkMenu:
   VVUQjT = self.bookmarkMenu.VVrBXd(True)
   if VVUQjT:
    self.VVVu59(VVUQjT)
 def VVnjCz(self, VVF9lIObj, path):
  if self.bookmarkMenu:
   VVUQjT = self.bookmarkMenu.VVrBXd(False)
   if VVUQjT:
    self.VVVu59(VVUQjT)
 def VVw2GT(self, folder=None):
  if folder:
   folder = FF8MLZ(folder)
   self["myMenu"].VVuvFC(folder)
   self["myMenu"].moveToIndex(0)
  self.VVfyHt()
 def VVJcaV(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVVaku(self, path):
  VVUQjT = self.VVJcaV()
  if VVUQjT and path in VVUQjT:
   return True
  else:
   return False
 def VVflvw(self):
  if VVJcaV():
   return True
  else:
   return False
 def VVVu59(self, VVUQjT):
  line = ",".join(VVUQjT)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVgRV4(self, path):
  VVUQjT = self.VVJcaV()
  if VVUQjT:
   while path in VVUQjT:
    VVUQjT.remove(path)
   self.VVVu59(VVUQjT)
   return VVUQjT
 def VVdhPl(self, chDir=True):
  fPath, fDir, fName = CC3ls7.VVAmF7(self)
  if fPath:
   if chDir:
    self["myMenu"].VVuvFC(fDir)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFSoSp(self, "Not found", 1000)
 def VVVfoj(self, path):
  if not os.path.isdir(path):
   path = FFFeKp(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVhoki(self, selFile, VVg7BJ, command):
  FFS238(self, boundFunction(FFeerf, self, command, VVDwGo=self.VVOm78), "%s\n\n%s" % (VVg7BJ, selFile))
 def VVI8Rr(self, path, calledFromMenu):
  destPath = self.VV2LWg(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVZCgs = []
  if calledFromMenu:
   VVZCgs.append(VVXQs5)
   color = VVy89V
  else:
   color = ""
  VVZCgs.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVZCgs.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVZCgs.append((color + "Extract Here"            , "extract_here"  ))
  if VVZAX8 and path.endswith(".tar.gz"):
   VVZCgs.append(VVXQs5)
   VVZCgs.append((color + 'Convert to ".ipk" Package' , "VVHciS"  ))
   VVZCgs.append((color + 'Convert to ".deb" Package' , "VVEW95"  ))
  return VVZCgs
 def VVoRCX(self, path, selFile):
  FF9y9t(self, boundFunction(self.VVAvBO, path, selFile), title="Compressed File Options", VVZCgs=self.VVI8Rr(path, False))
 def VVAvBO(self, path, selFile, item=None):
  if item is not None:
   parent  = FFFeKp(path, False)
   destPath = self.VV2LWg(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVG0cy
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FF9qFB("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FF9qFB("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVG0cy, VVG0cy)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFO1e4(self, cmd)
   elif path.endswith(".zip"):
    self.VVEr1y(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif path.endswith(".rar"):
    self.VV6g0F(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FF8avg("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVhoki(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVhoki(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFFeKp(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVhoki(selFile, "Extract Here ?"      , cmd)
   elif item == "VVHciS" : self.VVHciS(path)
   elif item == "VVEW95" : self.VVEW95(path)
 def VV2LWg(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVEr1y(self, item, path, parent, destPath, VVg7BJ):
  FFS238(self, boundFunction(self.VVCNiR, item, path, parent, destPath), VVg7BJ)
 def VVCNiR(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVG0cy
  cmd  = FF9qFB("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFR6WL(destPath, VV09cj))
  cmd +=   sep
  cmd += "fi;"
  FFYn0Z(self, cmd, VVDwGo=self.VVOm78)
 def VV6g0F(self, item, path, parent, destPath, VVg7BJ):
  FFS238(self, boundFunction(self.VVYnUj, item, path, parent, destPath), VVg7BJ)
 def VVYnUj(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FF8MLZ(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVG0cy
  cmd  = FF9qFB("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFR6WL(destPath, VV09cj))
  cmd +=   sep
  cmd += "fi;"
  FFYn0Z(self, cmd, VVDwGo=self.VVOm78)
 def VVNDLx(self, addSep=False):
  VVZCgs = []
  if addSep:
   VVZCgs.append(VVXQs5)
  VVZCgs.append((VVy89V + "View Script File"  , "script_View"  ))
  VVZCgs.append((VVy89V + "Execute Script File" , "script_Execute" ))
  VVZCgs.append((VVy89V + "Edit"     , "script_Edit" ))
  return VVZCgs
 def VVghtW(self, path, selFile):
  FF9y9t(self, boundFunction(self.VVyDpy, path, selFile), title="Script File Options", VVZCgs=self.VVNDLx())
 def VVyDpy(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFtC7A(self, path)
   elif item == "script_Execute" : self.VVhoki(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCLioI(self, path)
 def VVetCV(self, addSep=False):
  VVZCgs = []
  if addSep:
   VVZCgs.append(VVXQs5)
  VVZCgs.append((VVy89V + "Browse IPTV Channels"  , "m3u_Browse" ))
  VVZCgs.append((VVy89V + "Edit"      , "m3u_Edit" ))
  VVZCgs.append((VVy89V + "View"      , "m3u_View" ))
  return VVZCgs
 def VVHYr6(self, path, selFile):
  FF9y9t(self, boundFunction(self.VVNhyAItem_m3u, path, selFile), title="M3U/M3U8 File Options", VVZCgs=self.VVetCV())
 def VVNhyAItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FF9BOI(self, boundFunction(self.session.open, CCSfuP, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCLioI(self, path)
   elif item == "m3u_View"  : FFtC7A(self, path)
 def VVJ9fk(self, path):
  if fileExists(path) : FF9BOI(self, boundFunction(CCgkMM.VVWPoW, self, path, boundFunction(self.VVGQks, path), defEnc=None), title="Loading Codecs ...", clearMsg=False)
  else    : FFzAsS(self, path)
 def VVGQks(self, path, item=None):
  if item:
   FFtC7A(self, path, encLst=item)
 def VVqQsO(self, path, selFile, newChmod):
  FFS238(self, boundFunction(self.VV2us9, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VV2us9(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVAkQm)
  result = FFgBpG(cmd)
  if result == "Successful" : FFiM80(self, result)
  else      : FF2VP5(self, result)
 def VVpU9F(self, path, selFile):
  parent = FFFeKp(path, False)
  self.session.openWithCallback(self.VVZ3GL, boundFunction(CC3ls7, mode=CC3ls7.VVR0D8, VVvxsk=parent, VVAVDz="Create Symlink here"))
 def VVZ3GL(self, newPath):
  if len(newPath) > 0:
   target = self.VVR7m7(self.VVF9lI())
   target = FF2KYY(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FF8MLZ(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FF2VP5(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFS238(self, boundFunction(self.VVgWbL, target, link), "Create Soft Link ?\n\n%s" % txt, VVvjmj=True)
 def VVgWbL(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVAkQm)
  result = FFgBpG(cmd)
  if result == "Successful" : FFiM80(self, result)
  else      : FF2VP5(self, result)
 def VVT3PK(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFIPSl(self, boundFunction(self.VVYnUQ, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVYnUQ(self, path, selFile, VVr5f9):
  if VVr5f9:
   parent = FFFeKp(path, True)
   if os.path.isdir(path):
    path = FF2KYY(path)
   newName = parent + VVr5f9
   cmd = "mv '%s' '%s' %s" % (path, newName, VVAkQm)
   if VVr5f9:
    if selFile != VVr5f9:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFS238(self, boundFunction(self.VV3V4P, cmd), message, title="Rename file?")
    else:
     FF2VP5(self, "Cannot use same name!", title="Rename")
 def VV3V4P(self, cmd):
  result = FFgBpG(cmd)
  if "Fail" in result:
   FF2VP5(self, result)
  self.VVOm78()
 def VVrW7D(self, path, selFile, isMove):
  if isMove : VVAVDz = "Move to here"
  else  : VVAVDz = "Copy to here"
  parent = FFFeKp(path, False)
  self.session.openWithCallback(boundFunction(self.VVQRXu, isMove, path, selFile)
         , boundFunction(CC3ls7, mode=CC3ls7.VVR0D8, VVvxsk=parent, VVAVDz=VVAVDz))
 def VVQRXu(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FF2KYY(path)
   newPath = FF8MLZ(newPath)
   dest = newPath + lastPart
   if os.path.isdir(path) and os.path.isdir(dest):
    if isMove:
     FF2VP5(self, 'Same directory already exists:\n\n%s\n\n( Try to copy then delete the source )' % dest)
     return
    else:
     dest = newPath
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFS238(self, boundFunction(FFGSHZ, self, cmd, VVDwGo=self.VVOm78), txt, VVvjmj=True)
   else:
    FF2VP5(self, "Cannot %s to same directory !" % action.lower())
 def VVLbLb(self, path, fileName):
  path = FF2KYY(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFS238(self, boundFunction(self.VVZhSm, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVZhSm(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VVOm78()
 def VVIyrL(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVafbh and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVZZoi(self, path, isFile):
  dirName = FF8MLZ(os.path.dirname(path))
  if isFile : objName, VVr5f9 = "File"  , self.edited_newFile
  else  : objName, VVr5f9 = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFIPSl(self, boundFunction(self.VV1meo, dirName, isFile, title), title=title, defaultText=VVr5f9, message="Enter %s Name:" % objName)
 def VV1meo(self, dirName, isFile, title, VVr5f9):
  if VVr5f9:
   if isFile : self.edited_newFile = VVr5f9
   else  : self.edited_newDir  = VVr5f9
   path = dirName + VVr5f9
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVAkQm)
    else  : cmd = "mkdir '%s' %s" % (path, VVAkQm)
    result = FFgBpG(cmd)
    if "Fail" in result:
     FF2VP5(self, result)
    self.VVOm78()
   else:
    FF2VP5(self, "Name already exists !\n\n%s" % path, title)
 def VVUMZV(self, path, selFile):
  VVZCgs = []
  VVZCgs.append(("List Package Files"          , "VVuTFt"     ))
  VVZCgs.append(("Package Information"          , "VVuiog"     ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Install Package"           , "VV4vGL_CheckVersion" ))
  VVZCgs.append(("Install Package (force reinstall)"      , "VV4vGL_ForceReinstall" ))
  VVZCgs.append(("Install Package (force overwrite)"      , "VV4vGL_ForceOverwrite" ))
  VVZCgs.append(("Install Package (force downgrade)"      , "VV4vGL_ForceDowngrade" ))
  VVZCgs.append(("Install Package (ignore failed dependencies)"    , "VV4vGL_IgnoreDepends" ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Remove Related Package"         , "VVVf7s_ExistingPackage" ))
  VVZCgs.append(("Remove Related Package (force remove)"     , "VVVf7s_ForceRemove"  ))
  VVZCgs.append(("Remove Related Package (ignore failed dependencies)"  , "VVVf7s_IgnoreDepends" ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("Extract Files"           , "VVxoRL"     ))
  VVZCgs.append(("Unbuild Package"           , "VVKbWr"     ))
  FF9y9t(self, boundFunction(self.VVRsiU, path, selFile), VVZCgs=VVZCgs)
 def VVRsiU(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVuTFt"      : self.VVuTFt(path, selFile)
   elif item == "VVuiog"      : self.VVuiog(path)
   elif item == "VV4vGL_CheckVersion"  : self.VV4vGL(path, selFile, VVQ5tW     )
   elif item == "VV4vGL_ForceReinstall" : self.VV4vGL(path, selFile, VVak7B )
   elif item == "VV4vGL_ForceOverwrite" : self.VV4vGL(path, selFile, VVtBDT )
   elif item == "VV4vGL_ForceDowngrade" : self.VV4vGL(path, selFile, VVTLRM )
   elif item == "VV4vGL_IgnoreDepends" : self.VV4vGL(path, selFile, VVuTFQ )
   elif item == "VVVf7s_ExistingPackage" : self.VVVf7s(path, selFile, VVsDlf     )
   elif item == "VVVf7s_ForceRemove"  : self.VVVf7s(path, selFile, VVgKMV  )
   elif item == "VVVf7s_IgnoreDepends"  : self.VVVf7s(path, selFile, VVoirB )
   elif item == "VVxoRL"     : self.VVxoRL(path, selFile)
   elif item == "VVKbWr"     : self.VVKbWr(path, selFile)
   else           : self.close()
 def VVuTFt(self, path, selFile):
  if FFIeTh("ar") : cmd = "allOK='1';"
  else    : cmd  = FFUx1o()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVG0cy, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVG0cy, VVG0cy)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFzYJm(self, cmd, VVDwGo=self.VVOm78)
 def VVxoRL(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFFeKp(path, True) + selFile[:-4]
  cmd  =  FFUx1o()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FF8avg("mkdir '%s'" % dest) + ";"
  cmd +=    FF8avg("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFR6WL(dest, VV09cj))
  cmd += "fi;"
  FFeerf(self, cmd, VVDwGo=self.VVOm78)
 def VVKbWr(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVieY5 = os.path.splitext(path)[0]
  else        : VVieY5 = path + "_"
  if path.endswith(".deb")   : VV5kpJ = "DEBIAN"
  else        : VV5kpJ = "CONTROL"
  cmd  = FFUx1o()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVieY5, FFtj4I())
  cmd += "  mkdir '%s';"    % VVieY5
  cmd += "  CONTPATH='%s/%s';"  % (VVieY5, VV5kpJ)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVieY5
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVieY5, VVieY5)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVieY5
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVieY5, VVieY5)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVieY5
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVieY5
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVieY5, FFR6WL(VVieY5, VV09cj))
  cmd += "fi;"
  FFeerf(self, cmd, VVDwGo=self.VVOm78)
 def VVuiog(self, path):
  listCmd  = FFxiGu(VVKG32, "")
  infoCmd  = FFfBk8(VV22kn , "")
  filesCmd = FFfBk8(VVtwsD, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FF9CYr(VVN5SF)
   notInst = "Package not installed."
   cmd  = FFY0kl("File Info", VVN5SF)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFY0kl("System Info", VVN5SF)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFR6WL(notInst, VVy89V))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFY0kl("Related Files", VVN5SF)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFO1e4(self, cmd)
  else:
   FFh46b(self)
 def VV4vGL(self, path, selFile, cmdOpt):
  cmd = FFfBk8(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFS238(self, boundFunction(FFeerf, self, cmd, VVDwGo=FFv7fK), "Install Package ?\n\n%s" % selFile)
  else:
   FFh46b(self)
 def VVVf7s(self, path, selFile, cmdOpt):
  listCmd  = FFxiGu(VVKG32, "")
  infoCmd  = FFfBk8(VV22kn, "")
  instRemCmd = FFfBk8(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFR6WL(errTxt, VVy89V))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFR6WL(cannotTxt, VVy89V))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFR6WL(tryTxt, VVy89V))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFS238(self, boundFunction(FFeerf, self, cmd, VVDwGo=FFv7fK), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFh46b(self)
 def VVijDn(self, path):
  hostName = FFgBpG("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVfqB1(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVijDn(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVQk9b(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVZCgs = []
  VVZCgs.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVZCgs.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVZCgs.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVZCgs.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVZCgs.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVZCgs.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVZCgs.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVZCgs.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVZCgs.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVZCgs.append(VVXQs5)
  VVZCgs.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVZCgs.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FF9y9t(self, boundFunction(self.VVFrJm, path), VVZCgs=VVZCgs)
 def VVFrJm(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVeIEM(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVeIEM(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVeIEM(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVeIEM(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVeIEM(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVeIEM(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVeIEM(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVeIEM(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVeIEM(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVeIEM(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVkNPf(path, False)
   elif item == "convertDirToDeb"   : self.VVkNPf(path, True)
   else         : self.close()
 def VVkNPf(self, path, VVZhoG):
  self.session.openWithCallback(self.VVOm78, boundFunction(CCI31K, path=path, VVZhoG=VVZhoG))
 def VVeIEM(self, path, fileExt, preserveDirStruct):
  parent  = FFFeKp(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FF9qFB("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FF9qFB("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FF9qFB("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVG0cy
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FF8avg("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FFR6WL(resultFile, VV09cj))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FFR6WL(failed, VVlcHo))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFzYJm(self, cmd, VVDwGo=self.VVOm78)
 def VV42NN(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFtC7A(self, versionFile)
 def VVSoIE(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVijDn(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FF2VP5(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FF5Wuv(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFFeKp(path, False)
  VVieY5 = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FFR6WL(errCmd, VVlcHo))
  installCmd = FFfBk8(VVQ5tW , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VVieY5, VVieY5)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VVieY5
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VVieY5
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VVieY5, VVieY5)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFeerf(self, cmd, VVDwGo=self.VVOm78)
 def VVHciS(self, path):
  FF2VP5(self, "Under Construction.")
 def VVEW95(self, path):
  FF2VP5(self, "Under Construction.")
 @staticmethod
 def VV2a6o(SELF, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   SELF.session.open(CCkg2V, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVAmF7(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FF8MLZ(fDir), fName
  return "", "", ""
 @staticmethod
 def VVv08m(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVjHPj(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VV3UfA(size, mode=0):
  txt = CC3ls7.VV3Rwi(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VV3Rwi(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
class CCiOcp(MenuList):
 def __init__(self, VVTdNh=False, directory="/", VVSsY3=True, VVqGAw=True, VVQjLI=True, VV5tfc=None, VV1EhY=False, VVKRtE=False, VVutYO=False, isTop=False, VVy64T=None, VVdVup=1000, VVz3yz=30, VVEXXT=30, VVy9Q9="#00000000"):
  MenuList.__init__(self, list, VVTdNh, eListboxPythonMultiContent)
  self.VVSsY3  = VVSsY3
  self.VVqGAw    = VVqGAw
  self.VVQjLI  = VVQjLI
  self.VV5tfc  = VV5tfc
  self.VV1EhY   = VV1EhY
  self.VVKRtE   = VVKRtE or []
  self.VVutYO   = VVutYO or []
  self.isTop     = isTop
  self.additional_extensions = VVy64T
  self.VVdVup    = VVdVup
  self.VVz3yz    = VVz3yz
  self.VVEXXT    = VVEXXT
  self.pngBGColor    = FF43YG(VVy9Q9)
  self.EXTENSIONS    = self.VVXbmj()
  self.VVBJ9x   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVreXb, self.VVz3yz))
  self.l.setItemHeight(self.VVEXXT)
  self.png_mem   = self.VVjPEJ("mem")
  self.png_usb   = self.VVjPEJ("usb")
  self.png_fil   = self.VVjPEJ("fil")
  self.png_dir   = self.VVjPEJ("dir")
  self.png_dirup   = self.VVjPEJ("dirup")
  self.png_srv   = self.VVjPEJ("srv")
  self.png_slwfil   = self.VVjPEJ("slwfil")
  self.png_slbfil   = self.VVjPEJ("slbfil")
  self.png_slwdir   = self.VVjPEJ("slwdir")
  self.VVyUS3()
  self.VVuvFC(directory)
 def VVjPEJ(self, category):
  return LoadPixmap("%s%s.png" % (VVMuIV, category), getDesktop(0))
 def VVXbmj(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "rar" : "rar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u" ,
   "m3u8" : "m3u"
  }
 def VVgVPP(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FF2KYY(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFc8cv(" -> " , VVN5SF) + FFc8cv(os.readlink(path), VV09cj)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVEXXT + 10, 0, self.VVdVup, self.VVEXXT, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VViyTm: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVEXXT-4, self.VVEXXT-4, png, self.pngBGColor, self.pngBGColor, VViyTm))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVEXXT-4, self.VVEXXT-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VV8RIk(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVyUS3(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVeNpo(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVpz6J(self, file):
  if os.path.realpath(file) == file:
   return self.VVeNpo(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVeNpo(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVeNpo(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VV0mDm(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVBJ9x.info(l[0][0]).getEvent(l[0][0])
 def VVcxHL(self):
  return self.list
 def VVbBr2(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVuvFC(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVQjLI:
    self.current_mountpoint = self.VVpz6J(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVQjLI:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVutYO and not self.VVbBr2(path, self.VVKRtE):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVgVPP(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VV1EhY:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVBJ9x = eServiceCenter.getInstance()
   list = VVBJ9x.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVSsY3 and not self.isTop:
   if directory == self.current_mountpoint and self.VVQjLI:
    self.list.append(self.VVgVPP(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVutYO and self.VVeNpo(directory) in self.VVutYO):
    self.list.append(self.VVgVPP(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVSsY3:
   for x in directories:
    if not (self.VVutYO and self.VVeNpo(x) in self.VVutYO) and not self.VVbBr2(x, self.VVKRtE):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVgVPP(name = name, absolute = x, isDir = True, png = png))
  if self.VVqGAw:
   for x in files:
    if self.VV1EhY:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFc8cv(" -> " , VVN5SF) + FFc8cv(target, VV09cj)
       else:
        png = self.png_slbfil
        name += FFc8cv(" -> " , VVN5SF) + FFc8cv(target, VVlcHo)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VV8RIk(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVMuIV, category))
    if (self.VV5tfc is None) or iCompile(self.VV5tfc).search(path):
     self.list.append(self.VVgVPP(name = name, absolute = x , isDir = False, png = png))
  if self.VVQjLI and len(self.list) == 0:
   self.list.append(self.VVgVPP(name = FFc8cv("No USB connected", VVaDOU), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VV0DXo(self):
  return self.current_directory
 def VV78P1(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVuvFC(self.getSelection()[0], select = self.current_directory)
 def VVU3k0(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVjzVR(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VV29pn)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VV29pn)
 def refresh(self):
  self.VVuvFC(self.current_directory, self.VVU3k0())
 def VV29pn(self, action, device):
  self.VVyUS3()
  if self.current_directory is None:
   self.refresh()
class CCEJPF(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FFZerm(VVA69d, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVUQjT   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVWVm8(defFG, "#00FFFFFF")
  self.defBG   = self.VVWVm8(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFeVzc(self, self.Title)
  self["keyRed"].show()
  FFFMjq(self["keyGreen"] , "< > Transp.")
  FFFMjq(self["keyYellow"], "Foreground")
  FFFMjq(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV4UmB        ,
   "yellow"   : boundFunction(self.VVe96C, False)  ,
   "blue"   : boundFunction(self.VVe96C, True)  ,
   "up"   : self.VVCQ08          ,
   "down"   : self.VVGRpP         ,
   "left"   : self.VVHJ83         ,
   "right"   : self.VVEyK2         ,
   "last"   : boundFunction(self.VV9kXS, -5) ,
   "next"   : boundFunction(self.VV9kXS, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FF1BAe(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FF1BAe(self["keyRed"] , c)
  FF1BAe(self["keyGreen"] , c)
  self.VVXGTG()
  self.VV13Ji()
  FFdouS(self["myColorTst"], self.defFG)
  FF1BAe(self["myColorTst"], self.defBG)
 def VVWVm8(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VV13Ji(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VV87kw(0, 0)
     return
 def VV4UmB(self):
  self.close(self.defFG, self.defBG)
 def VVCQ08(self): self.VV87kw(-1, 0)
 def VVGRpP(self): self.VV87kw(1, 0)
 def VVHJ83(self): self.VV87kw(0, -1)
 def VVEyK2(self): self.VV87kw(0, 1)
 def VV87kw(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVKGNd()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVQoFJ()
 def VVXGTG(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVQoFJ(self):
  color = self.VVKGNd()
  if self.isBgMode: FF1BAe(self["myColorTst"], color)
  else   : FFdouS(self["myColorTst"], color)
 def VVe96C(self, isBg):
  self.isBgMode = isBg
  self.VVXGTG()
  self.VV13Ji()
 def VV9kXS(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VV87kw(0, 0)
 def VVqNw0(self):
  return hex(self.transp)[2:].zfill(2)
 def VVKGNd(self):
  return ("#%s%s" % (self.VVqNw0(), self.colors[self.curRow][self.curCol])).upper()
class CCYf21(Screen):
 VVhWlR  = 0
 VVX6xs = 1
 def __init__(self, session, mode, endCallback):
  self.session  = session
  margin    = 50
  screenSize   = FFcFDM()
  w     = int(screenSize[0] - margin)
  h     = int(screenSize[1] / 2.0)
  self.skin, self.skinParam = FFZerm(WINDOW_SUBTITLE, w, h, 35, 20, 30, "#ff000000", "#ff000000", 60)
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.currentIndex  = -1
  self.subtitleMode  = mode
  self.defaultY   = 0
  self.endCallback  = endCallback
  FFeVzc(self)
  self["myTitle"].hide()
  self["mySubtFr"] = Label()
  self["mySubtFr"].hide()
  for i in range(3):
   self["mySubt%d" % i] = Label()
  self.onClose.append(self.VVpixK)
 def VVPAo2(self, path=""):
  if path :
   self.VVSDIE()
   FF9BOI(self, boundFunction(self.VVPHK2, path), title="Checking file ...", clearMsg=False)
  else:
   self.VVPHK2()
 def VVPHK2(self, path=""):
  if path:
   subtList, err = self.VVJ9Vj(path)
   if err    : self.VVpixK(err)
   elif not subtList : self.VVpixK("Invalid srt file")
   else    :
    self.subtList = subtList
    self.VVB5m2()
  else:
   if self.VVGqXf():
    self.VVB5m2()
   elif self.subtitleMode == CCYf21.VVX6xs:
    self.VVpixK("noResume")
   else:
    if self.VV7iIt(): self.VVB5m2()
    else         : self.VVpixK("noAutoSrt")
 def VVB5m2(self):
  try:
   InfoBar.instance.enableSubtitle(None)
  except:
   try:
    InfoBar.instance.setSubtitlesEnable(False)
   except:
    pass
  FFSoSp(self, "Subtitle started", 1000, isGrn=True)
  self.VVSDIE()
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVd1b3)
  except:
   self.timerUpdate.callback.append(self.VVd1b3)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VV6JNR)
  except:
   self.timerEndText.callback.append(self.VV6JNR)
  self.VVwh5F(True)
 def VVpixK(self, res=""):
  self.timerUpdate.stop()
  self.timerEndText.stop()
  self.VVwh5F(False)
  self.endCallback(res)
 def VVwh5F(self, isAdd):
  lst = [CFG.subtDelay, CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextSize, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtShadowSize, CFG.subtVerticalPos]
  notifier = self.VVSDIE
  for item in lst:
   if isAdd:
    item.addNotifier(notifier, initial_call=False)
   else:
    try:
     item.removeNotifier(notifier)
    except:
     try:
      notifier in item.notifiers and item.notifiers.remove(notifier)
      notifier in item.notifiers_final and item.notifiers_final.remove(notifier)
     except Exception as e:
      pass
 def VVGqXf(self):
  fPath, fDir, fName = CC3ls7.VVAmF7(self)
  if fPath:
   path = fPath + ".ajp"
   if fileExists(path):
    lines = FF5Wuv(path)
    srt = delay = enc = ""
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : srtPath = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay   = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc   = line.split("=")[1].strip()
    if srtPath and fileExists(srtPath):
     subtList, err = self.VVJ9Vj(srtPath, enc)
     if subtList:
      self.lastSubtEnc = enc
      self.subtList = subtList
      try:
       CFG.subtDelay.setValue("%.1f" % float(delay))
      except:
       pass
      return True
  return False
 def VV7iIt(self):
  bestSrt, bestRatio = CCYf21.VVaFHw(self)
  if bestSrt and bestRatio > 40:
   subtList, err = self.VVJ9Vj(bestSrt)
   if subtList:
    self.subtList = subtList
    return True
  return False
 def VVeb4G(self):
  VVZCgs = []
  if self.lastSubtFile:
   VVZCgs.append(("Settings"      , "set"  ))
   VVZCgs.append(("Change Encoding"    , "enc"  ))
   VVZCgs.append(("Disable Current Subtitle"  , "disab" ))
   VVZCgs.append(VVXQs5)
  VVZCgs.append(("Find all srt file"    , "findSrt" ))
  lst = CCYf21.VVc3j6(self)
  if lst:
   VVZCgs.append(VVXQs5)
   for item in lst:
    fName = os.path.basename(item)
    if self.lastSubtFile == item:
     fName = FFc8cv(fName, VV09cj)
    VVZCgs.append((fName, item))
  win = FF9y9t(self, self.VVfp5R, VVZCgs=VVZCgs, width=1200, title="Subtitle Options")
  win.instance.move(ePoint(40, 40))
 def VVfp5R(self, item=None):
  if item:
   if item == "set":
    self["mySubtFr"].show()
    for i in range(3):
     FF1BAe(self["mySubt%d" % i], "#55000000")
    self.session.openWithCallback(self.VVm4cJ, CC45Nv)
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile):
     FF9BOI(self, boundFunction(CCgkMM.VVWPoW, self, self.lastSubtFile, self.VVMKqi, defEnc=self.lastSubtEnc, pos=1), title="Loading Codecs ...", clearMsg=False)
    else:
     FFSoSp(self, "SRT File error", 1000)
   elif item == "disab":
    fPath, fDir, fName = CC3ls7.VVAmF7(self)
    os.system(FF8avg("rm -f '%s'" % fPath + ".ajp"))
    self.VVpixK("noErr")
   elif item == "findSrt":
    CCYf21.VVur9h(self, self.VVIWwa, defSrt=self.lastSubtFile, pos=1)
   else:
    self.VVIWwa(item)
 def VVm4cJ(self, res):
  self["mySubtFr"].hide()
  for i in range(3):
   FF1BAe(self["mySubt%d" % i], "#FF000000")
  if res:
   self.VV2Vlo()
   self.VVSDIE()
 def VVSDIE(self, configElement=None):
  fnt = CFG.subtTextFont.getValue()
  if not fnt in FFk1a9():
   fnt = VVreXb
  lineH = 0
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFdouS(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    inst.setHAlign(int(CFG.subtTextAlign.getValue()))
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    inst.setNoWrap(True)
    lineH = FFwqPy(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    inst.move(ePoint(int(inst.position().x()), int(lineH * i + 1)))
  except:
   pass
  try:
   height = lineH * 3 + 2
   if not self.defaultY:
    self.defaultY = int(getDesktop(0).size().height() - height - self.skinParam["marginTop"])
   if lineH:
    self.instance.resize(eSize(*(int(self.instance.size().width()), height)))
   y = int(self.defaultY + CFG.subtVerticalPos.getValue())
   y = min(y, getDesktop(0).size().height() - height - 5)
   self.instance.move(ePoint(int(self.instance.position().x()), int(y)))
   inst = self["myInfoFrame"].instance
   inst.move(ePoint(int(inst.position().x()), 2))
   inst = self["myInfoBody"].instance
   inst.move(ePoint(int(inst.position().x()), 4))
  except:
   pass
 def VVIWwa(self, path, enc=None):
  self.timerUpdate.stop()
  subtList, err = self.VVJ9Vj(path, enc)
  if err    : FFSoSp(self, err, 2000)
  elif not subtList : FFSoSp(self, "Invalid SRT file", 2000)
  else    :
   self.subtList  = subtList
   self.lastSubtInfo = ""
   self.lastSubtEnc = ""
   self.currentIndex = 0
   CFG.subtDelay.setValue("0.0")
   for i in range(3):
    FFdouS(self["mySubt%d" % i], "#ffffff")
    self["mySubt%d" % i].setText("")
   FFSoSp(self, "Subtitle started", 1000, isGrn=True)
  self.timerUpdate.start(500, False)
 def VVMKqi(self, item=None):
  if item:
   self.VVIWwa(self.lastSubtFile, item)
 @staticmethod
 def VVc3j6(SELF):
  fPath, fDir, fName = CC3ls7.VVAmF7(SELF)
  if pathExists(fDir):
   files = iGlob("%s*.srt" % fDir)
   if files:
    return files
  return []
 @staticmethod
 def VVaFHw(SELF):
  bestSrt = ""
  bestRatio = 0
  fPath, fDir, fName = CC3ls7.VVAmF7(SELF)
  if fName:
   movName = os.path.splitext(fName)[0].lower()
   files = CCYf21.VVc3j6(SELF)
   for path in files:
    fName = os.path.basename(path)
    fName = os.path.splitext(fName)[0]
    ratio = CCUKiz.VV0ZEA(movName.lower(), fName.lower())
    if ratio > bestRatio:
     bestRatio = ratio
     bestSrt = path
  return bestSrt, bestRatio
 def VVLk8r(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVJ9Vj(self, path, enc=None):
  if not fileExists(path):
   return [], "File not found"
  if (FFtcdQ(path) > 1024 * 700):
   return [], "File too big"
  capNum = frmSec = toSec = bold = italic = under = 0
  color  = ""
  subtLines = []
  subtList = []
  capFound = False
  lines  = FF5Wuv(path, encLst=enc if enc else None)
  for line in lines:
   line = line.strip()
   if line:
    if not capFound and line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVLk8r(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      subtLines.append((line.strip(), color, bold, italic, under))
   else:
    if (toSec - frmSec) > 0:
     subtList.append((capNum, frmSec, toSec, subtLines))
    capFound = False
    subtLines = []
    color = ""
    capNum = frmSec = toSec = bold = italic = under = 0
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VV2Vlo()
  return subtList, ""
 def VV2Vlo(self):
  fPath, fDir, fName = CC3ls7.VVAmF7(self)
  if fPath and pathExists(fDir):
   with open(fPath + ".ajp", "w") as f:
    f.write("srt=%s\n" % self.lastSubtFile)
    f.write("delay=%s\n" % CFG.subtDelay.getValue())
    if self.lastSubtEnc:
     f.write("enc=%s\n" % self.lastSubtEnc)
 def VVd1b3(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCkg2V.VV801B(self)
  txtDur = 0
  lines = []
  self.VVk8GG(posVal)
  if self.currentIndex == -2:
   return
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[self.currentIndex]
   if not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    for i in range(3):
     FFdouS(self["mySubt%d" % i], "#ffffff")
     self["mySubt%d" % i].setText("")
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
     txtDur = int(toSec * 1000 - frmSec * 1000)
     if txtDur > 0:
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        line = line.replace(u"\u202A", "")
        line = line.replace(u"\u202B", "")
        line = line.replace(u"\u202C", "")
        line = str(line)
        if newColor:
         FFdouS(self["mySubt%d" % ndx], newColor)
        self["mySubt%d" % ndx].setText(line)
      self.timerEndText.start(txtDur, True)
 def VVk8GG(self, posVal):
  if posVal > 0:
   delay = float(CFG.subtDelay.getValue())
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     self.currentIndex = ndx
     return
  self.currentIndex = -2
 def VV6JNR(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
 @staticmethod
 def VVur9h(SELF, cbFnc, defSrt="", pos=0):
  FF9BOI(SELF, boundFunction(CCYf21.VVFhHr, SELF, cbFnc, defSrt, pos), title="Searching for srt files", clearMsg=False)
 @staticmethod
 def VVFhHr(SELF, cbFnc, defSrt="", pos=0):
  FFSoSp(SELF)
  lines = FFqFDg('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FF1d0b(1)))
  if lines:
   lines.sort()
   VVZCgs = []
   for item in lines:
    VVZCgs.append(((VV09cj if defSrt == item else "") + item, item))
   VVP7wO = ("Show Full Path", CCYf21.VViEy7)
   win = FF9y9t(SELF, boundFunction(CCYf21.VVV6zR, cbFnc), title="Subtitle Files", VVZCgs=VVZCgs, width=1200, height=500 if pos == 1 else 900, VVP7wO=VVP7wO)
   if pos == 1:
    win.instance.move(ePoint(40, 40))
  else:
   FFSoSp(SELF, "No srt files found !", 2000)
 @staticmethod
 def VViEy7(VVF9lIObj, path):
  FFfnpN(VVF9lIObj, path, title="Full Path")
 @staticmethod
 def VVV6zR(cbFnc, item):
  if item:
   cbFnc(item)
 @staticmethod
 def VVeeOV():
  c = s = m = h = 0
  with open(VVGttK + "AJPanel_test.srt", "w") as f:
   for i in range(1, 5401):
    s += 2
    if s >= 60:
     s = 0
     m += 1
     if m >= 60:
      m = 0
      h += 1
    if i < 6:
     txt  = '<font color="#ffff00">Created by AJPanel</font>\n'
     txt += '<font color="#00ffff">Testing Subtitle Files</font>\n'
     txt += '<font color="#00ff00">Line - %d</font>\n\n' % i
    else:
     txt = '<font color="#ffffbb">Subtitle Line - %d</font>\n\n' % i
    f.write("%d\n" % i)
    f.write("%02d:%02d:%02d,001 --> %02d:%02d:%02d,001\n" % (h, m, s, h, m, s+1))
    f.write(txt)
class CC45Nv(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFZerm(VVdC1L, 600, 600, 40, 30, 10, "#11331010", "#11442020", 30, barHeight=40)
  self.session  = session
  self.Title   = "Subtitle Settings"
  FFeVzc(self, title=self.Title)
  FFFMjq(self["keyRed"] , "Exit")
  FFFMjq(self["keyGreen"] , "Save")
  FFFMjq(self["keyYellow"], "Reset")
  self.confList = []
  self.confList.append(getConfigListEntry("Delay (current movie)" , CFG.subtDelay   ))
  self.confList.append(getConfigListEntry(VVG0cy *2     ,       ))
  self.confList.append(getConfigListEntry("Text Color"   , CFG.subtTextFg  ))
  self.confList.append(getConfigListEntry("Text Font"    , CFG.subtTextFont  ))
  self.confList.append(getConfigListEntry("Text Size"    , CFG.subtTextSize  ))
  self.confList.append(getConfigListEntry("Alignment"    , CFG.subtTextAlign  ))
  self.confList.append(getConfigListEntry("Shadow Color"   , CFG.subtShadowColor ))
  self.confList.append(getConfigListEntry("Shadow Size"   , CFG.subtShadowSize ))
  self.confList.append(getConfigListEntry(VVG0cy *2     ,       ))
  self.confList.append(getConfigListEntry("Vertical Pos"   , CFG.subtVerticalPos ))
  ConfigListScreen.__init__(self, self.confList, session)
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVFQrW  ,
   "green"   : self.VVoSjD   ,
   "yellow"  : boundFunction(FFS238, self, self.VVh1vb, "Reset Subtitle Settings to default ?", title="Subtitle Settings"),
   "cancel"  : self.VVFQrW
  }, -1)
  self.onShown.append(self.VV3HNB)
 def VV3HNB(self):
  self.onShown.remove(self.VV3HNB)
  FFDd6I(self["config"])
  FFGCoH(self, self["config"])
  FFRpf0(self)
  self.instance.move(ePoint(40, 40))
 def VVFQrW(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFS238(self, self.VVoSjD, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVoSjD(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  configfile.save()
  self.close(True)
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close(False)
 def VVh1vb(self):
  CFG.subtDelay.setValue("0.0")
  CFG.subtTextFg.setValue("srt")
  CFG.subtTextFont.setValue(VVreXb)
  CFG.subtTextSize.setValue(50)
  CFG.subtTextAlign.setValue("1")
  CFG.subtShadowColor.setValue("#000080")
  CFG.subtShadowSize.setValue(5)
  CFG.subtVerticalPos.setValue(0)
  self.VVoSjD()
class CC7jtx(ScrollLabel):
 def __init__(self, parentSELF, text="", VVHWIu=True):
  ScrollLabel.__init__(self, text)
  self.VVHWIu=VVHWIu
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVDKXH  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVz3yz    = None
  self.parentW    = None
  self.parentH    = None
  self.firstTime    = True
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close     ,
   "cancel"  : parentSELF.close     ,
   "red"   : self.VVxRYJ     ,
   "green"   : self.VVSb9b    ,
   "yellow"  : self.VVlIxF    ,
   "blue"   : self.VVpWgq    ,
   "up"   : self.pageUp      ,
   "down"   : self.pageDown      ,
   "left"   : self.pageUp      ,
   "right"   : self.pageDown      ,
   "last"   : boundFunction(self.VVSHKi, 0) ,
   "next"   : boundFunction(self.VVSHKi, 2) ,
   "0"    : boundFunction(self.VVSHKi, 1) ,
   "pageUp"  : self.VVLQRe      ,
   "chanUp"  : self.VVLQRe      ,
   "pageDown"  : self.VVloHE      ,
   "chanDown"  : self.VVloHE
  }, -1)
 def VVy70T(self, isResizable=True, VVe8u6=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FFRpf0(self.parentSELF, True)
  self.isResizable = isResizable
  if VVe8u6:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVz3yz  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FF1BAe(self, color)
 def FF1BAeColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVDKXH - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVNHRA()
 def pageUp(self):
  if self.VVDKXH > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVDKXH > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVLQRe(self):
  self.setPos(0)
 def VVloHE(self):
  self.setPos(self.VVDKXH-self.pageHeight)
 def VVXcLU(self):
  return self.VVDKXH <= self.pageHeight or self.curPos == self.VVDKXH - self.pageHeight
 def VVNHRA(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVDKXH, 3))
   start = int((100 - vis) * self.curPos / (self.VVDKXH - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVRj8X=VVJRBN):
  old_VVXcLU = self.VVXcLU()
  self.message = str(text)
  if self.pageHeight:
   self.long_text.setText(self.message)
   self.VVDKXH = self.long_text.calculateSize().height()
   if self.VVHWIu and self.VVDKXH > self.pageHeight:
    self.scrollbar.show()
    self.VVNHRA()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVDKXH))
   if   VVRj8X == VV8XxG: self.setPos(0)
   elif VVRj8X == VV08dq : self.VVloHE()
   elif old_VVXcLU    : self.VVloHE()
   if self.firstTime and len(self.message) > 0:
    self.firstTime = False
    self.setText(self.message, VVRj8X=VVRj8X)
 def appendText(self, text, VVRj8X=VV08dq):
  self.setText(self.message + str(text), VVRj8X=VVRj8X)
 def VVlIxF(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVr2fT(size)
 def VVpWgq(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVr2fT(size)
 def VVSb9b(self):
  self.VVr2fT(self.VVz3yz)
 def VVr2fT(self, VVz3yz):
  self.long_text.setFont(gFont(self.fontFamily, VVz3yz))
  self.setText(self.message, VVRj8X=VVJRBN)
  self.VVjvAc(calledFromFontSizer=True)
 def VVSHKi(self, align):
  self.long_text.setHAlign(align)
 def VVxRYJ(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FF8MLZ(expPath), self.textOutFile, FFNMff())
    with open(outF, "w") as f:
     f.write(FF3aqm(self.message))
    FFiM80(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FF2VP5(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVjvAc(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVDKXH > 0 and self.pageHeight > 0:
   if self.VVDKXH < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVDKXH
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
